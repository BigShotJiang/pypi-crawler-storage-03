def test_import():
    import kwutil