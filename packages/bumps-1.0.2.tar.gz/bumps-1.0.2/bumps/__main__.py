"""
Bumps application.

Run "bumps --help" for details, or "python -m bumps -help" if
bumps isn't on your path.
"""

from bumps.webview.server.cli import main

if __name__ == "__main__":
    main()
