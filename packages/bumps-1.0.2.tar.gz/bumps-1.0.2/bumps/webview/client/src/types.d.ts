/// <reference types="@types/plotly.js" />
/// <reference types="@types/uuid"/>
/// <reference types="vite-svg-loader" />
/// <reference types="./types/mpld3" />
