def f(x):
    return (x[0] - 3) ** 2 + (x[1] - 5) ** 2
