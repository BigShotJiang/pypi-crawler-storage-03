SDS011_MODEL = 2
MOBILE_GPS = 3
PING_MODEL = 1
STATION_VERSION = "v0.8.0"
PASKAL2MMHG = 133.32
POLKA_REMOTE_WS = "wss://polkadot.rpc.robonomics.network/"
KSM_REMOTE_WS = "wss://kusama.rpc.robonomics.network"