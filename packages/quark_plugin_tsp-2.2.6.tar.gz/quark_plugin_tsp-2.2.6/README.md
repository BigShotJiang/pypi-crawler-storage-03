# QUARK-plugin-tsp


### Provided Modules:

| Module               | Upstream Interface          | Downstream Interface        |
| -------------------- | --------------------------- | --------------------------- |
| tsp_graph_provider   | None                        | quark.interface_types.graph |
| tsp_qubo_mapping     | quark.interface_types.graph | quark.interface_types.qubo  |
| classical_tsp_solver | quark.interface_types.graph | None                        |
