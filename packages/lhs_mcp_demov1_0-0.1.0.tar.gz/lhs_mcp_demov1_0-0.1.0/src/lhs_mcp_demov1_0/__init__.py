def main() -> None:
    print("Hello from lhs-mcp-demov1-0!")
