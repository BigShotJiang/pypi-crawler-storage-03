"""Sparql interface module for the DSMS"""

from dsms.knowledge.sparql_interface.sparql_interface import SparqlInterface

__all__ = ["SparqlInterface"]
