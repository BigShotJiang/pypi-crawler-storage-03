"""DSMS Semantic Queries"""

from .base import BaseSparqlQuery

__all__ = ["BaseSparqlQuery"]
