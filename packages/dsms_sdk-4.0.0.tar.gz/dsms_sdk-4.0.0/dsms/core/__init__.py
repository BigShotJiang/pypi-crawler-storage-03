"""DSMS core module
"""
from dsms.core.configuration import Configuration

__all__ = ["Configuration"]
