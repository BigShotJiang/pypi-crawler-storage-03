class SyriusTypeException(Exception):
    """ """
    pass


class FlowException(Exception):
    """ """
    pass


class FlowAPIException(Exception):
    """ """
    pass
