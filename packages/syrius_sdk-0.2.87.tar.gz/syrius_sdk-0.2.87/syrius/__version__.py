__title__ = "Syrius SDK"
__description__ = "A client for Flow generation and Flow remote execution"
__version__ = "0.2.21"
