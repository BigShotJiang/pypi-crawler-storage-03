from typing import Literal

from syrius.commands.LoopInputCommand import loopType
from syrius.commands.abstract import AbstractCommand, Command


class ReplicateKlingProCommand(Command):
    id: int = 75
    prompt: str | AbstractCommand | loopType
    negative_prompt: str | AbstractCommand | loopType = ""
    aspect_ratio: Literal["1:1", "16:9", "9:16"] | AbstractCommand | loopType = "1:1"
    guidance_scale: float | AbstractCommand | loopType = 0.5
    image: str | AbstractCommand | loopType
    duration: int | AbstractCommand | loopType = 5
    api_key: str | AbstractCommand | loopType