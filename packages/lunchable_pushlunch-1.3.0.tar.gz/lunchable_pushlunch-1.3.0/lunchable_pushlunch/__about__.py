"""
lunchable-pushlunch info file
"""

from importlib.metadata import version

__application__ = "lunchable-pushlunch"
__version__ = version(__application__)
