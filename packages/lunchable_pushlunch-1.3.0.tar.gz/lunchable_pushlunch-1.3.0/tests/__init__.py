"""
Test suite for the lunchable-pushlunch package
"""
