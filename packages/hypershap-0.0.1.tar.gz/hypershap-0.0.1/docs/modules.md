# API Reference

## HyperSHAP
::: hypershap.hypershap

## Explanation Task
::: hypershap.task

## Surrogate Model
::: hypershap.surrogate_model

## Games
::: hypershap.games

## Utils
::: hypershap.utils
