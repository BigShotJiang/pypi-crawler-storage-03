# hypershap

[![Release](https://img.shields.io/github/v/release/mwever/hypershap)](https://img.shields.io/github/v/release/mwever/hypershap)
[![Build status](https://img.shields.io/github/actions/workflow/status/mwever/hypershap/main.yml?branch=main)](https://github.com/mwever/hypershap/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/mwever/hypershap)](https://img.shields.io/github/commit-activity/m/mwever/hypershap)
[![License](https://img.shields.io/github/license/mwever/hypershap)](https://img.shields.io/github/license/mwever/hypershap)

HyperSHAP is a post-hoc explanation method for hyperparameter optimization.
