"""This module contains supported date format strings."""

GER = "%Y-%m-%d %H:%M:%S%z"
