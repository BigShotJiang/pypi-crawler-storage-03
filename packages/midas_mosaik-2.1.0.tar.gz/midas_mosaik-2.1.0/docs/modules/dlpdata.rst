Midas Default Load Profiles Simulator
=====================================

The *dlpdata* module, provided by the *midas-dlpdata* package, provides a
simulator for the default load profiles provided by the BDEW set.

Installation
------------

This package will usually installed automatically together with `midas-mosaik`,
if you opt-in the `bh` extra. It is available on pypi, so you can install it
manually with

.. code-block:: bash

    pip install midas-dlpdata

The Data
--------

The data set is taken from the `BDEW`_ (Bundesverband der Energie- und
Wasserwirtschaft e.V.). It provides eleven default load profiles; seven for
trade (G), one for houshold (H) and three for agriculture (L). Each profile is
grouped into summer, winter and transition and each season is grouped into
weekday, saturday and sunday.  A time resolution of a quarter of an hour was
chosen.

.. _`BDEW`: https://www.bdew.de/energie/standardlastprofile-strom/

======================= ============ ======== ===========
Season                    start      end       days
======================= ============ ======== ===========
Winter                     01.11      20.03     140 (141)
Summer                     15.05      14.09     123
Spring (transition)        21.03.     14.05      55
Autum (transition)         15.09.     31.10.     47
======================= ============ ======== ===========


The annaul values of the profiles are calculated starting with the 01.11 as an
monday.

======= ===== ====== =======
Profile MWh/a peak W avg kWh
======= ===== ====== =======
G0      1.154  240.4   0.131
G1      1.084  489.9   0.123
G2      1.148  251.2   0.131
G3      1.145  154.5   0.13
G4      1.155  230.5   0.131
G5      1.178  255.9   0.134
G6      1.154  298.7   0.131
H0      1.152  213.7   0.131
L0      1.137  240.4   0.13
L1      1.137  305.2   0.13
L2      1.137  213.8   0.13
======= ===== ====== =======


For more information about the specific facilities behind the profiles, take a
look at `BDEW`_.

The daily schedules of the seasons are shown below. The green graph represents
the weekday load, the blue graph is the saturday load and the yellow one stands
for the sunday load.

.. image:: dlp_season.png
    :width: 800

Usage
-----

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

Inside of midas
~~~~~~~~~~~~~~~

To use the dlp data inside of midas, add `dlpdata` to your modules

.. code-block:: yaml

    my_scenario:
      modules:
        - dlpdata
        # - ...

and provide a *scope* and a configuration:

.. code-block:: yaml

    my_scenario:
      # ...
      dlp_data_params:
        my_scenario:
          meta_scaling: 1.5
          interpolate: True
          randomize_data: True
          randomize_cos_phi: True
          active_mapping:
          15: [[G4, 262.8]]
          17: [[H0, 1038.06]]

The numbers 15 and 17 stand for the bus number which depends on the used grid.

Any Mosaik Scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `dlpdata` manually to your
`mosaik scenario`_ file. First, the entry in the `sim_config`:

.. _`mosaik scenario`: https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html

.. code-block:: python

    sim_config = {
        "DLPSimulator": {
          "python": "midas_powerseries.simulator:PowerSeriesSimulator"},
        # ...
    }

Next, you need to start the simulator (assuming a `step_size` of 900). Since
it uses a custom data model, you have to specify it here:

.. code-block:: python

    dlpdata_sim = world.start(
        "DLPSimulator",
        step_size=900,
        model_import_str="midas_dlp.model:DLPModel",
        use_custom_time_series=True,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located/",
        filename="bdew_default_load_profiles.csv",  # this is default
    )

Then the models can be started:

.. code-block:: python

    houshold = dlpdata_sim.CalculatedQTimeSeries(name="H0", scaling=1038.06)
    trade = dlpdata_sim.CalculatedQTimeSeries(name="G4", scaling=262.8)

Finally, the models need to be connected to other entities:

.. code-block:: python

    world.connect(trade, other_entity, "p_mw", "q_mvar")

The Keys, Inputs, and Outputs of the PV and Wind Data Simulator
---------------------------------------------------------------

The  PV and Wind Data Simulator is a subclass from the
:ref:`power-series-module`, it inherits all keys, inputs, and outputs from that
simulator.

Example
-------

The following example is taken from the Bremerhaven MV scenario file.

.. code-block:: yaml

      dlpdata_params:
          bremerhaven:
            meta_scaling: 0.75
            active_mapping:
              15: [[G4, 262.8]] # Weddewarden Industrielast
              17: [[H0, 1038.06]] # Weddewarden Households
              19: [[G4, 17103.9]] # Lehe Industrielast
              20: [[H0, 14454.0]] # Lehe Households - 0
              24: [[G4, 15067.2]] # Geestemünde Industrielast
              25: [[H0, 15111]] # Geestemünde Households - 0
              28: [[H0, 13271.4]] # Lehe Households - 1
              30: [[H0, 14454]] # Lehe Households - 2
              32: [[G1, 175.2]] # Erdgas Kronos Titan GmbH
              33: [[H0, 18615]] # Geestemünde Households - 1
              35: [[H0, 13140]] # Lehe Households - 3
              37: [[H0, 13140]] # Lehe Households - 4
              40: [[H0, 16206]] # Leherheide Households - 0
              44: [[G3, 4108.44]] # Klinikum Bremerhaven
              45: [[H0, 4568.34]] # Schifferdorferdamm Households
              47: [[G4, 1165.08]] # Schifferdorferdamm Industrielast
              48: [[G4, 2365.2]] # Eisarena, Stadthalle
              49: [[G4, 5676.48]] # Mitte Industrielast
              50: [[H0, 11169]] # Mitte Households - 0
              52: [[G4, 7450.38]] # Leherheide Industrielast
              53: [[H0, 11388]] # Wulsdorf Households - 0
              56: [[G4, 1362.18]] # Surheide Industrielast
              57: [[H0, 5343.6]] # Surheide Households
              59: [[G3, 1226.4]] # AMEOS Klinikum Am Bürgerpark
              60: [[G4, 1554.9]] # Innenstadt
              61: [[G3, 1182.6]] # Zoo
              62: [[G3, 1033.68]] # AMEOS Klinikum Mitte
              63: [[H0, 11169]] # Mitte Households - 1
              65: [[H0, 9636]] # Leherheide Households - 1
              67: [[H0, 8760]] # Wulsdorf Households - 1
              69: [[G4, 87.6]] # Fischereihafen Industrielast
              70: [[G4, 5150.88]] # Wulsdorf Industrielast
              71: [[H0, 12702]] # Geestemünde Households - 2
              73: [[G4, 2334.54]] # Bremerhaven Süd
              74: [[G3, 1095]] # Fischereihafen - 4
              75: [[G3, 1095]] # Fischereihafen - 3
              76: [[G3, 1095]] # Fischereihafen - 2
              77: [[G3, 1095]] # Fischereihafen - 1
              78: [[G3, 1095]] # Fischereihafen - 0
              80: [[H0, 341.64]] # Fischereihafen - Households
