Midas Weather Module
====================

This package contains a midas module providing a simulator for weather data.
Although this package is intendet to be used with midas, it can be use it in
any mosaik simulation scenario.

Installation
------------

This package will usually be installed automatically together with
`midas-mosaik` if you opt-in for the `base` extra. It is available on pypi so
you can install it manually with

.. code-block:: bash

    pip install midas-weather

The Data
--------

The data set is provided from the "Deutscher Wetterdienst" `(DWD)`_ and the
weather station located at Bremen. There are many other weather stations
available and the weather module can be configured to download those as well.
The data set includes time series for air pressure, air temperature, solar
radiation, wind speed, wind direction, cloudiness and sund hours.
In the following picture, the weather data for 2023 is shown.

.. image:: weather_data_2023.png
    :width: 800

.. _`(DWD)`: https://opendata.dwd.de/

Configuration
-------------

Intructing midas to download weather data from a different weather station is a
bit complicated but still doable.

First, you have to open your runtime config (assuming that you already
followed the installation guide). In the `data` section, find the `weather`
section, it should contain the following entries:

.. code-block:: yaml

    weather:
      - air_url: air_temperature/historical/stundenwerte_TU_00691_19490101_
        base_url: https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/
        cloud_url: cloudiness/historical/stundenwerte_N_00691_19490101_
        name: WeatherBre2009-2022.csv
        post_fix: 20221231_hist.zip
        pressure_url: pressure/historical/stundenwerte_P0_00691_19490101_
        solar_url: solar/stundenwerte_ST_00691_row.zip
        start_date: '2009-01-01 00:00:00'
        sun_url: sun/historical/stundenwerte_SD_00691_19510101_
        wind_url: wind/historical/stundenwerte_FF_00691_19260101_

These are all the links and components to construct the absolute link for
downloading different weather data sets. The `base_url` should not change but
in many of the other links you can see different numbers, e.g., the `air_url`
has ``00691_19490101`` in it. The first five numbers ``00691`` are the ID of
the weather station in Bremen. If you want to use a different station, first
you have to identify the ID of the weather station you want to download from.
You can find the IDs if you follow the `base_url`. Now replace all occurances
of ``00691`` with the new ID. The second value is the start of weather data
recording and can be different from station to station and data set to data
set. Yes, this ultimately means you have to check every link and adapt the
values. Fortunately, the data is structured similar enough so that no further
preprocessing should be necessary. `Should`! I have not tested it for them all!
Finally, it is important to change the name of the data set or it will
overwrite the weather data from Bremen.

Let's exemplarily download the weather data for Fichtelberg. Following the
base_url and then ``air_temperature -> historical`` you find a file
`TU_Stundenwerte_Beschreibung_Stationen.txt`. There you look for the desired
station and get the ID, for Fichtelberg this is ``01358``. Going back
from that file, you have to look for the data set for that ID, which is
``stundenwerte_TU_01358_19510101_20241231_hist.zip``. We take the last part
``_20241231_hist.zip`` and save it as `post_fix`, since this is the same for
each data set. The numbers ``01358_19510101`` we use to replace the `air_url`
link so that it looks like this:
``air_temperature/historical/stundenwerte_TU_01358_19510101_`` (don't forget
the trailing underscore). We will repeat this for the other links and get
something like this in your runtime configuration:

.. code-block:: yaml

    weather:
      - air_url: air_temperature/historical/stundenwerte_TU_00691_19490101_
        base_url: https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/
        cloud_url: cloudiness/historical/stundenwerte_N_00691_19490101_
        name: WeatherBre2009-2022.csv
        post_fix: 20221231_hist.zip
        pressure_url: pressure/historical/stundenwerte_P0_00691_19490101_
        solar_url: solar/stundenwerte_ST_00691_row.zip
        start_date: '2009-01-01 00:00:00'
        sun_url: sun/historical/stundenwerte_SD_00691_19510101_
        wind_url: wind/historical/stundenwerte_FF_00691_19260101_
      - air_url: air_temperature/historical/stundenwerte_TU_01358_19510101_
        base_url: https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/
        cloud_url: cloudiness/historical/stundenwerte_N_01358_19750701_
        name: WeatherFichtelberg1990-2024.csv
        post_fix: 20241231_hist.zip
        pressure_url: pressure/historical/stundenwerte_P0_01358_19871101_
        solar_url: solar/stundenwerte_ST_01358_row.zip
        start_date: '1990-01-01 00:00:00'
        sun_url: sun/historical/stundenwerte_SD_01358_19510101_
        wind_url: wind/historical/stundenwerte_FF_01358_19550101_

The start date is used to remove earlier entries, e.g., when there are data
points missing or if not all measurements start at the same time.
Note that not all weather stations have all data. Especially data sets for
solar radiation are only available at a few stations. If you want to have a
full data set, check solar first when you choose a station. Of course you can
use solar radiation from a different station then the rest of the data.

Afterwards, you can download the data with midasctl

.. code-block:: bash

    midasctl download -m weather

Another note: It is quite easy to make a mistake filling the entry for a new
station. Double-check that you have all the trailing underscores where they are
required. And check if the links work when you compose them manually, e.g.,

.. code-block:: yaml

    https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/air_temperature/historical/stundenwerte_TU_01358_19510101_20241231_hist.zip

One final note: If you're updating your runtime config with
``midasctl configure -u``, the configuration will be lost! The update creates a
backup of the old configuration but you have to manually restore the entry.


Usage
-----

Inside of midas
~~~~~~~~~~~~~~~

To use the weather data inside of midas, add `weather` to your modules

.. code-block:: yaml

    my_scenario:
      modules:
        - weather
        - ...

and configure it with

.. code-block:: yaml

  weather_params:
    my_weather_scope:
      weather_mapping:
        WeatherCurrent:
          - interpolate: true
            randomize: true


If a store module is enabled, the weather module will automatically send all
outputs to the store.

Any mosaik scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `weather` manually to your mosaik
scenario file. First, the entry in the `sim_config`:

.. code-block:: python

    sim_config = {
        "WeatherData": {
            "python": "midas_weather.simulator:WeatherDataSimulator"
        },
        # ...
    }

Next, you need to define `start_date` and `step_size`.
The `start_date` is to be provided as ISO datestring and can anything between
2009 and 2024:

.. code-block:: python

    start_date = "2021-06-08 14:00:00+0000"

The `step_size` can be anything between 1 and 3600. Higher values might be
possible, but this is untested.

Now, the simulator can be started:

.. code-block:: python

    weather_sim = world.start("WeatherData", step_size=900, start_date=start_date)

Next, a weather data model can be started:

.. code-block:: python

    weather_model = weather_sim.WeatherCurrent(interpolate=True, randomize=True)

Finally, the model needs to be connected to other models:

.. code-block:: python

    world.connect(weather_model, other_entity, "t_air_deg_celsius", "wind_v_m_per_s")

The Keys of the Weather Data Simulator
--------------------------------------

The weather data simulator is **not** a subclass of the power series simulator.
However, it still has similar keys.

data_path
    This can be used to specify the location where the dataset is. By default
    this value will be taken from the midas runtime configuration file.

filename
    This can be used to specify the filename of the data set file. By default
    this value will be taken from either the midas runtime configuration file
    or the simulator itself.

step_size
    The step size does not only affect the frequency of the simulator's step
    calls but also the access to the data set. If it is lower than the
    time resolution of the data set, the models might return the same value in
    consecutive steps, but if it is higher, some values might be skipped. For
    any such cases, the `interpolate` key can be used.


interpolate
    Setting this flag to true will activate linear interpolation for all model
    outputs. You can even use a `step_size` of 1.

randomize
    This key can be used to activate randomization of the data. If activated, a
    normally distributed noise will be added to the output values. The strength
    of the noise can be controlled with `noise_factor`.

noise_factor
    This key can be used to control the strength of the noise, when `randomize`
    is used. It defaults to 0.05, i.e., the noise is drawn with mean of
    zero (always) and a standard deviation of 0.05.

forecast_horizon_hours
    If the forecast model is used, this controls for how many hours the
    forecast should be created. It is of type float and supports values like
    0.5 for half an hour. But it has to be a multiple of the step_size.

forecast_error
    This controls how strong the error is that is put on top of the forecast.
    Works similar as the `noise_factor` for regular data.

scripted_events
    This allows to script manipulations for the output values for specific
    attributes at given times. See the scripted events section.


Scripted Events
---------------

Explaining scripted events does work best with an example:

.. code-block:: yaml

    screv_example:
      parent:
      start_date: 2021-04-13 12:00:00+0100
      store_params:
        filename: scripted_events.csv
      weather_params:
        bremen:
        scripted_events:
          "2021-05-01 08:00:00+0100":
            bh_w_per_m2: 0.05
            dh_w_per_m2: 0.05
            wind_v_m_per_s: 0.0
          "2021-05-05 14:00:00+0100": {}
          "2021-07-01 08:00:00+0100":
            bh_w_per_m2: 0.05
            dh_w_per_m2: 0.05
            wind_v_m_per_s: 0.0
          "2021-07-05 14:00:00+0100": {}
          "2021-09-01 08:00:00+0100":
            bh_w_per_m2: 0.05
            dh_w_per_m2: 0.05
            wind_v_m_per_s: 0.0
          "2021-09-14 14:00:00+0100": {}
        weather_mapping:
            WeatherCurrent:
            - interpolate: true

What's going on here? First, on the 2021-05-01 at 08:00:00 an event will start.
This event includes, that the values of `bh_w_per_m2` and `dh_w_per_m2` both
will be multiplied with 0.05 and `wind_v_m_per_s` with 0. At the time
2021-05-05 at 14:00:00, all events are cleared. Then, on 2021-07-01 at
08:00:00, another event with the same parameters will happen and end on
2021-07-05 at 14:00:00. Finally, another occurance of this event is defined
from 1st September to 14th September. The result can be seen in the followingp
ictures

.. image:: weather_scripted_dh.png
    :width: 800

.. image:: weather_scripted_wind.png
    :width: 800

Basically, events manipulate the output via multiplication with a fixed value
for a fixed time.
