Midas PV and Wind Data Simulator
================================

The *pwdata* module, provided by the *midas-pwdata* package, provides a
simulator for PV and wind time series.

Installation
------------

This package will usually installed automatically together with `midas-mosaik`,
if you opt-in the `bh` extra. It is available on pypi, so you can install it
manually with

.. code-block:: bash

    pip install midas-pwdata

The Data
--------

The data set is taken from `50Hertz`_. It provides three time series for PV, on
& offshore wind plants, as it's shown in the following table.

.. _`50Hertz`: https://www.50hertz.com/en/

============= ======== ====== =====
plant         MWh/a    peak W avg W
============= ======== ====== =====
solar_p_mw       11.19   8038  1278
onshore_p_mw     35.08  15053  4005
offshore_p_mw    4.136   1051   472
============= ======== ====== =====

The generation of those time series are visualized in this figure:

.. image:: pwdata.png
    :width: 800

Usage
-----

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

Inside of midas
~~~~~~~~~~~~~~~

To use the pwdata inside of midas, simply add `pwdata` to your modules

.. code-block:: yaml

    my_scenario:
      modules:
        - pwdata
        # - ...

and provide a *scope* and a configuration:

.. code-block:: yaml

    my_scenario:
      # ...
      pwdata_params:
        my_grid_scope:
          interpolate: True
          randomize_data: True
          randomize_cos_phi: True
          active_mapping:
            16: [[onshore_p_mw, 5]]
            17: [[solar_p_mw, 0.03]]
            20: [[solar_p_mw, 0.41]]

The mapping has to match to the grid that you're using.

Any Mosaik Scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `pwdata` manually to your
`mosaik scenario`_ file. First, the entry in the `sim_config`:

.. _`mosaik scenario`: https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html

.. code-block:: python

    sim_config = {
        "PVWindData": {"python": "midas_powerseries.simulator:PowerSeriesSimulator"},
        # ...
    }

Next, you need to start the simulator (assuming a `step_size` of 900):

.. code-block:: python

    pw_sim = world.start(
        "PVWindData",
        step_size=900,
        data_step_size=3600,
        is_load=False,
        is_sgen=True,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located/",
        filename="pvwind_profiles.csv",  # this is default
    )

Then the models can be started:

.. code-block:: python

    wind = pw_sim.CalculatedQTimeSeries(name="on_shore_p_mw", scaling=5)
    pv1 = pw_sim.CalculatedQTimeSeries(name="solar_p_mw", scaling=0.03)
    pv2 = pw_sim.CalculatedQTimeSeries(name="solar_p_mw", scaling=0.41)

Finally, the modells need to be connected to other entities:

.. code-block:: python

    world.connect(wind, other_entity, "p_mw", "q_mvar")

The Keys, Inputs, and Outputs of the PV and Wind Data Simulator
---------------------------------------------------------------

The  PV and Wind Data Simulator is a subclass from the
:ref:`power-series-module`, it inherits all keys, inputs, and outputs from that
simulator.

Example
-------

The following example is taken from the default `bremerhavenmv` scenario file.

.. code-block:: yaml

   pwdata_params:
    bremerhaven:
      meta_scaling: 0.45
      active_mapping:
        16: [[onshore_p_mw, 5]] # onshore_p_mwpark Speckenbüttel 2
        17: [[solar_p_mw, 0.03]] # solar_p_mw Weddewarden
        20: [[solar_p_mw, 0.41]] # solar_p_mw Lehe - 0
        22: [[onshore_p_mw, 5]] # onshore_p_mwpark Speckenbüttel 1
        23: [[onshore_p_mw, 5]] # onshore_p_mwpark Multibrid
        25: [[solar_p_mw, 0.83]] # solar_p_mw solar_p_mw Geesemünde - 0
        28: [[solar_p_mw, 0.44]] # solar_p_mw Lehe - 1
        30: [[solar_p_mw, 0.49]] # solar_p_mw Lehe - 2
        32: [[onshore_p_mw, 17.1]] # Unkown (CCGT)
        33: [[solar_p_mw, 0.83]] # solar_p_mw Geesemünde - 1
        35: [[solar_p_mw, 0.45]] # solar_p_mw Lehe - 3
        37: [[solar_p_mw, 0.44]] # solar_p_mw Lehe - 4
        39: [[onshore_p_mw, 5.0]] # onshore_p_mwpark Repower
        40: [[solar_p_mw, 0.46]] # solar_p_mw Leherheide
        43: [[onshore_p_mw, 10]] # onshore_p_mwpark Lehe
        45: [[solar_p_mw, 0.13]] # solar_p_mw Schiffdorferdamm
        50: [[solar_p_mw, 0.33]] # solar_p_mw Mitte - 0
        53: [[solar_p_mw, 0.33]] # solar_p_mw Wulsdorf - 0
        55: [[onshore_p_mw, 14]] # Unkown (WIP)
        57: [[solar_p_mw, 0.16]] # solar_p_mw Surheide
        63: [[solar_p_mw, 0.32]] # solar_p_mw Mitte - 1
        65: [[solar_p_mw, 0.28]] # solar_p_mw Leherheide - 1
        67: [[solar_p_mw, 0.25]] # solar_p_mw Wulsdorf - 1
        71: [[solar_p_mw, 0.83]] # solar_p_mw Geesemünde - 2
        80: [[solar_p_mw, 0.01]] # solar_p_mw Fischereihafen
