.. _power-series-module:

Midas Power Series Module
=========================

The *powerseries* module, provided by the *midas-powerseries* package, provides
a simulator for csv-based power time series. It offers a lot of flexibility for
defining and including custom csv time series. It is used by most of the other
data simulators in midas.

Installation
------------

This package will usually be installed automatically mit ``midas-mosaik`` if
you opt-in for any of the extras. It is available on pypi if you want to
install manually.

.. code-block:: bash

    pip install midas-powerseries

Usage
-----

Inside of Midas
~~~~~~~~~~~~~~~

To use the simulator inside of midas, you have to add ``powerseries`` to your
modules.

.. code-block:: yaml

    my_scenario:
      modules:
        - powerseries
        - ...

You have to provide a ``scope`` and the configuration.

.. code-block:: yaml

    my_scenario:
      # ...
      powerseries_params:
        my_grid_scope:
          data_path: "path/to/folder/containing/csvfile"
          filename: "my_time_series.csv"
          step_size: 900
          data_step_size: 900
          data_scaling: 1.0
          meta_scaling: 1.0
          active_mapping:
            0: [[load_01_p_mw, 1.0], [load_02_p_mw]]

Important: this configuration has to match you csv file. See the parameter
description below for more information.

Any Mosaik Scenario
~~~~~~~~~~~~~~~~~~~

If you want to use ``powerseries`` without midas in a mosaik scenario, you have
to add it your ``sim_config``:

.. code-block:: python

    sim_config = {
        "PowerSeriesData": {
            "python": "midas_powerseries.simulator:PowerSeriesSimulator"
        },
        # ...
    }

Next, you need to start the simulator (assuming a ``step_size`` of 900):

.. code-block:: python

    psdata_sim = world.start(
        "PowerSeriesData",
        step_size=900,
        start_date="2020-01-01 00:00:00+0100",
        data_path="path/to/folder/containing/csvfile",
        filename="my_time_series.csv",
        data_step_size=900,
    )

You can start models like this

.. code-block:: python

    d1 = psdata_sim.CalculatedQTimeSeries(name="load_01_p_mw", scaling=1.0)
    d2 = psdata_sim.CalculatedQTimeSeries(name="load_02_p_mw", scaling=1.0)

and connect them to other entities

.. code-block:: python

    world.connect(d1, other_entity, "p_mw", "q_mvar")

The Keys of the Power Series Data Simulator
-------------------------------------------

This section gives a short description for all of the keys of the
``powerseries`` module. Keys that are part of every upgrade module will only be
mentioned if the actual behavior might be unexpected.


data_path
    This can be used to specify the location where the dataset is. By default
    this value will be taken from the midas runtime configuration file.

filename
    This can be used to specify the filename of the data set file. By default
    this value will be taken from either the midas runtime configuration file
    or the simulator itself.

step_size
    The step size does not only affect the frequency of the simulator's step
    calls but also the access to the data set. If it is lower than the
    ``data_step_size``, the models might return the same value in consecutive
    steps, but if it is higher, some values might be skipped. For any such
    cases, the ``interpolate`` key can be used.

data_step_size
    This key can be used to define the time resolution of the data set. By
    default, a ``data_step_size`` of 900 seconds is assumed. With this key you
    can set it to the resolution of your data set. If it does not match the
    ``step_size`` of the simulator, have a look at ``interpolate``.

interpolate
    In cases where ``step_size`` and ``data_step_size`` do not match, this can
    be used to calculate the values in-between. Setting this flag to true will
    activate linear interpolation for all model outputs. You can even use a
    ``step_size`` of 1.

randomize_data
    This key can be used to activate randomization of the data. If activated, a
    normally distributed noise will be added to the output values. The strength
    of the noise can be controlled with ``noise_factor``. Randomization is
    applied after interpolation (if activated). If the data set contains ``P``
    and ``Q`` values, noise is calculated individually.

noise_factor
    This key can be used to control the strength of the noise, when
    ``randomize_data`` is used. It defaults to `0.2`, i.e., the noise is drawn
    with mean of zero (always) and a standard deviation of 0.2 times the
    standard deviation of the data set.

calculate_missing_power:
    If the data set does not have values for ``P`` **and** ``Q``, the missing
    value may be calculated based on the cos phi. This flag, which is enabled
    by default, controlls if the missing value is calculated or not.

randomize_cos_phi
    If the flag ``calculate_missing_power`` is actived the missing
    value will be calculated based on the value of the ``cos_phi`` key.
    The ``randomize_cos_phi`` key allows to randomize the cos phi value before
    that calculation.

data_scaling
    This scaling factor can be used to scale the whole data set. While it is
    functionally equivalent to ``meta_scaling``, the intention is to cover for
    scaling because of different units, e.g., kW to MW.

meta_scaling
    This scaling factor can be used to scale the whole data set. While it is
    functionally equivalent to ``data_scaling``, the intention is to change the
    scaling for a specific use case.

is_load/is_sgen
    Those flags can be used to controll how a data set will be handled and
    connected to the grid. The default state is ``is_load=True`` and
    ``is_sgen=False``, which means that the data set is a load time series and
    will be connected to pandapowers load entities. If both are flipped, then
    it is an sgen and will be connected to sgen entities. When both flags are
    set to True, the time series will be treated as storage time series and
    connected to the storage entities of pandapower. The special case is if
    both flags are set to False, then the actual type of a time series in the
    data set will be determined by the name, if possible, or set to storage if
    determination is not possible. This is useful for mixed-type data sets,
    which contain both loads, sgens and/or storage time series. A time series
    should then have the keywords ``load``, ``sgen`` or ``storage`` in a
    column name for this to work properly. An example for this use case is the
    sbdata module.

use_custom_time_series
    By default, the simulator will pre-select the relevant columns for a
    specific model (which represents a time series). By activating this flag,
    the full data set will be passed to the model, letting the model decide,
    which data to use. This is useful if you implement your own data model
    (see next section ``model_import_str``).

model_import_str
    If your data set is differently structured and does not work with the
    default model, you can implement your own model and provide the import
    string with this key. This is used, e.g., by the dlp data module.

active_mapping
    With this key, a mapping for time series can be defined, which contain
    values for active power. Reactive power will be calculated if
    ``compute_missing_power`` is set to True. A mapping usually looks like:

    .. code-block:: yaml

        active_mapping:
            2: [[MyCol1, 1.0], [MyCol2, 0.9]]
            4: [[MyCol3, 1.2]]

    This will assume there are columns in the data set with the names MyCol1,
    MyCol2, and MyCol3 at least. Models using those columns will be installed
    at buses 2 and 4 with individual scaling of 1.0, 0.9, and 1.2. Those values
    will be interpreted as active power.

reactive_mapping
    With this key, a mapping for time series can be defined, which contain
    values for reactive power. Active power will be calculated if
    ``compute_missing_power`` is set to True. The mapping looks similar to
    an ``active_mapping``.

combined_mapping
    This key is useful if you have a data set, which contains both active and
    reactive power values. You can specify time series for ``P`` and ``Q``
    individually.

    .. code-block:: yaml

        combined_mapping:
            2: [[[MyPCol1, MyQCol1], 1.0], [[MyPCol2, MyQCol2], 0.9]]
            4: [[[MyPCol3, MyQCol3], 1.2]]

    As you see, there is only one scaling factor for both. If you want to scale
    them individually, you should split it into active and reactive mapping
    instead.

{active, reactive, combined}_mapping_filename
    Mappings can be pre-defined in a separate file for each type of mapping.
    Csv and json mappings are supported, below an example for csv is shown for
    a combined mapping:

    .. code-block:: text

        index,bus,model_1,model_2,scaling
        0,1,Land_0,,1.0
        1,1,Land_2,,1.2
        2,4,Land_3,,2.0
        3,4,Land_2,Land_4,1.0

prefer_{active, reactive, combined}_mapping_from_file
    With this flag you can control if the mapping provided by a file should
    act as fallback or if it should be forced (if available). If set to True
    for a specific mapping, any configuration for that mapping in the scenario
    file will be ignored.

Inputs of the Power Series Data Simulator
-----------------------------------------

Since this module is a data provider, it has not many inputs:

cos_phi
    Set the cos phi for the next step for all models that use non-randomized
    calculation of missing power values.

Outputs of the Power Series Data Simulator
------------------------------------------

The models of this module have three outputs:

p_mw
  Active power output in MW.

q_mvar
  Reactive power output in MVAr.

cos_phi
  The actual cos phi used in the previous step.
