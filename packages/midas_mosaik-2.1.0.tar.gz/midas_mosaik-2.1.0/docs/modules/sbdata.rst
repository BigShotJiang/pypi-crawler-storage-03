Midas Simbench Data Simulator
=============================

The *sbdata* module, provided by the *midas-sbdata* package, provides a
simulator for simbench data sets even outside of simbench networks.

Installation
------------

This package will be installed automatically with `midas-mosaik` if you opt-in
the ``full`` extra. It is available on pypi, so you can install it manually
with

.. code-block:: bash

    pip install midas-sbdata

The Data
--------

The data originates from the `Simbench Project`_. There are data sets for
different grid topologies, containing household and other profiles as well as
power generation. By default, the data for the simbench code
``1-LV-rural3--0-sw.csv`` is downloaded, but this can be configured to your
needs.

.. _`Simbench Project`: https://simbench.de/de/

Configuration
-------------

To use a different data set then the default one, you have to open your runtime
configuration. This assumes that you have followed the :ref:`installation` and
created the runtime config with `midasctl`. Open the file
``midas-runtime-conf.yml`` and look for the ``data`` section in it. There you
will find the block with simbench:

.. code-block:: yaml

    data:
      # ...
      simbench:
        - {name: 1-LV-rural3--0-sw.csv}

To add the data set for a different simbench code, add a new line here

.. code-block:: yaml

    data:
      # ...
      simbench:
        - {name: 1-LV-rural3--0-sw.csv}
        - {name: 1-MV-urban--1-sw.csv}

and the run the download command

.. code-block:: bash

    midasctl download -m sbdata

to get the MV urban profiles. Additionally to the profiles itself, the mapping
for the corresponding simbench network will be saved alongside the profiles.
Your `midas_data` directory should now have those files

- 1-MV-urban--1-sw.csv
- 1-MV-urban--1-sw_mapping.csv

Usage
-----

The intended use-case for the simbench data simulator is to be used inside of
midas. However, it can be used in any mosaik simulation scenario.

Inside of midas
~~~~~~~~~~~~~~~

To use the simulator inside of midas, add `sbdata` to your modules:

.. code-block:: yaml

    my_scenario:
      modules:
        - sbdata
        # - ...

and provide a *scope* and a configuration:

.. code-block:: yaml

    my_scenario:
      # ...
      sndata_params:
        my_grid_scope:
          is_load: false
          is_sgen: false
          combined_mapping:
            1: [[[load_000_p_mw, load_000_q_mvar], 1.0]]
            3: [[sgen_000_p_mw, 1.0]]

There is a special case if you intend to use the data set with the
corresponding simbench network.

.. code-block:: yaml

    my_scenario:
      # ...
      sbdata_params:
        my_grid_scope:
          is_load: false
          is_sgen: false
          filename: 1-LV-rural3--0-sw.csv  # <-- change when you use a different simbench code
          combined_mapping: default

This will load the mapping file created during the download process.

Any mosaik scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `sbdata` manually to your
`mosaik scenario`_ file. First, the entry in the `sim_config`:

.. _`mosaik scenario`: https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html

.. code-block:: python

    sim_config: {
      "SimbenchData": {
        "python": "midas_powerseries.simulator:PowerSeriesSimulator",
      }
    }

Next, you need to start the simulator (assuming a `step_size` of 900):

.. code-block:: python

    sbdata_sim = world.start(
        "SimbenchData",
        step_size=900,
        is_load=False,
        is_sgen=False,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located",
        filename="1-LV-rural3--0-sw.csv",  # this is default,
    )

Then the models can be started:

.. code-block:: python

    load1 = sbdata_sim.CombindTimeSeries(name=["load_000_p_mw", "load_000_q_mvar"], scaling=1.0)
    sgen1 = sbdata_sim.CalculatedQTimeSeries(name="sgen_000_p_mw", scaling=1.0)

Finally, the models need to be connected to other entities:

.. code-block:: python

    world.connect(load1, other_entity, "p_mw", "q_mvar")

The Keys, Inputs, and Outputs of the Simbench Data Simulator
------------------------------------------------------------

The Simbench Data Simulator is a subclass from the
:ref:`power-series-module`, it inherits all keys, inputs, and outputs from that
simulator.
