Midas Commercial Data Simulator
===============================

The *comdata* module, provided by the *midas-comdata* package, provides a
simulator for a commercial building reference data set.

Installation
------------

This package will usually installed automatically together with `midas-mosaik`,
if you opt-in the `base` extra. It is available on pypi, so you can install it
manually with

.. code-block:: bash

    pip install midas-comdata

The Data
--------

The data set is taken from the project `Open Energy Data Initiative`_. It
provides 15 time series for commercial facilitys, as it's shown in the
following table.

.. _`Open Energy Data Initiative`: https://data.openei.org/about

======================== ======= ========== ======
Facility                 peak kW MWh/a      avg kW
======================== ======= ========== ======
Full Service Restaurant    0.137   601.044   0.069
Hospital                   2.805  18106.771  2.067
Large Hotel                0.876   4574.578  0.522
Large Office               3.482  12137.960  1.386
Medium Office              0.588   1445.567  0.165
Midrise Apartment          0.133    454.896  0.052
Out Patient                0.630   2643.197  0.302
Primary School             0.713   1705.623  0.195
Quick Service Restaurant   0.077    357.569  0.041
Secondary School           2.529   6396.515  0.730
Small Hotel                0.270   1147.850  0.131
Small Office               0.039    122.119  0.014
Standalone Retail          0.219    615.892  0.070
Strip Mall                 0.197    541.853  0.062
Super Market               0.568   2343.541  0.268
Warehouse                  0.186    481.342  0.055
======================== ======= ========== ======

The aggregated load of each lands is visualized in this figure:

.. image:: facilitys.png
    :width: 800

Usage
-----

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

Inside of midas
~~~~~~~~~~~~~~~

To use the store inside of midas, add `comdata` to your modules

.. code-block:: yaml

    my_scenario:
      modules:
        - comdata
        # - ...

and provide a *scope* and a configuration:

.. code-block:: yaml

    my_scenario:
      # ...
      comdata_params:
        my_grid_scope:
          interpolate: True
          randomize_data: True
          randomize_cos_phi: True
          mapping:
            22: [[Hospital, 0.002]] # industrial subgrid
            35: [[StripMall, 0.015]]

The number 22, 35 stands for the bus number, which depends on the grid.

Any Mosaik Scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `comdata` manually to your
`mosaik scenario`_ file. First, the entry in the `sim_config`:

.. _`mosaik scenario`: https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html

.. code-block:: python

  sim_config = {
      "CommercialDataSimulator": {
        "python": "midas_commercials.simulator:CommercialDataSimulator"
      },
      # ...
  }

Next, you need to start the simulator (assuming a `step_size` of 900):

.. code-block:: python

    comdata_sim = world.start(
        "CommercialDataSimulator",
        step_size=900,
        data_step_size=3600,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located/",
        filename="commercial_profiles.csv",  # this is default
    )

Then the models can be started:

.. code-block:: python

    hospital = comdata_sim.CalculatedQTimeSeries(name="Hospital", scaling=0.002)
    strip_mall = comdata_sim.CalculatedQTimeSeries(name="StripMall", scaling=0.015)

Finally, the modells need to be connected to other entities:

.. code-block:: python

    world.connect(hospital, other_entity, "p_mw", "q_mvar")

The Keys, Inputs, and Outputs of the Smart Nord Data Simulator
--------------------------------------------------------------

The Commercial Data Simulator is a subclass from the
:ref:`power-series-module`, it inherits all keys, inputs, and outputs from that
simulator.


Example
-------

The following example is taken from the default `midaslv` scenario file.

.. code-block:: yaml

  comdata_params:
    midaslv:
      interpolate: true
      randomize_data: true
      randomize_cos_phi: true
      active_mapping:
        22: [[Hospital, 0.002]] # industrial subgrid
        35: [[StripMall, 0.015]]
        36: [[Warehouse, 0.015]]
        37: [[SmallHotel, 0.0072]]
        40: [[StandaloneRetail, 0.015]]
        41: [[QuickServiceRestaurant, 0.0075]]
        42: [[MidriseApartment, 0.012]]
        43: [[SmallOffice, 0.021]]
