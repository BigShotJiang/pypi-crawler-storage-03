Midas Pysimmods Module
======================

This module is part of the pysimmods package, which has its own documentation
at `PySimMods`_. This page only contains information about the integration into
midas and not about the module itself.


Installation
------------

The package will be installed automatically with `midas-mosaik`, if you opt-in
the `base` extra. You can install it manually from pypi with

.. code-block:: bash

    pip install pysimmods

Usage
-----

To use pysimmods inside of midas you have to add it to the scenario modules. It
uses the keyword `der` (for Distributed Energy Resources):

.. code-block:: yaml

    my_scenario:
      modules:
        - der
        - weather
        - ...

Almost all models require some sort of weather data. Therefore, in almost every
case you need to load the weather module as well unless you provide a different
source for weather data. To configure it, you need to provide a mapping for
power grid connections and for weather providers. Unlike many of the other
modules, the scope does not have to match, instead you provide a `grid_name`
key that provides the scope information. This means, you can have multiple
scopes connected to the same grid.

.. code-block:: yaml

    my_scenario:
      # ...
      der_params:
        my_grid_scope_a:
          grid_name: my_grid_scope
          mapping:
            1: [[PV, 1.2], [BAT, 0.5]]
            3: [[CHP, 0.4]]
          weather_provider_mapping:
            PV: [bremen, 0]
            BAT: [bremen, 0]
            CHP: [bremen, 0]

This assumes that there is a weather configuration with scope *bremen*.

The Keys of the Pysimmods Module
--------------------------------

This section gives a short description of the keys that can be provided to the
module for the pysimmods.

step_size
    The duration of one simulation step in seconds, will be passed down to the
    models. Defaults to scenario standards.

start_date
    The start date will be passed down to the models that require it for their
    calculation. Defaults to scenario standards.

cos_phi
    The cos phi to calculate reactive power for models that support it.
    Defaults to scenario standards.

q_control
    Controls how the inverter models prioritize the calculation of reactive
    power. Can be either `prioritize_p` (default) or `prioritize_q`. See the
    inverter documentation for more information.

inverter_mode
    Controls how the inverter models output their reactive power. Can be either
    `inductive` (default) or `capacitive`. See the inverter documentation for
    more information

unit
    Controls in which unit the models should output their power values.
    Defaults to `mw`, another possible value is `kw`.

pv_is_static_t_module
    This flag allows to disable the temperature module of the Photovoltaic
    model.

pv_send_p_possible_max_mw_to_grid
    This flag will let the PV models send their theoretic power value in
    addition to the inverter output.

randomize_params
    Setting this flag to true will active procedurally generated parameter
    configurations for models which support this feature. Note that the
    result may be unrealistic configurations and those that produce weird
    behavior. Use with caution!

randomize_inits
    Setting this flag to true will active randomized initialization. It is more
    save to use than `randomize_params`.

enable_schedules
    This flag lets you activate the schedule features of the models. If a
    schedule is provided, models will follow those schedules if feasible.

prioritize_setpoint
    If activated, models will prefer setpoints even if they have a schedule.
    The schedule will only be used when no setpoint was provided.

provide_forecasts
    Activates the forecast features of the models. The models will send their
    forecast as pandas dataframe serialized to json string.

forecast_horizon_hours
    Controls how many hours into the future the models should calculate their
    forecast.

provide_flexibilities
    Activates the calculation of flexibilities. Flexibilities work similar to
    forecasts and are serialized dataframes as well.

flexibility_horizon_hours
    Controls how large the timeframe for flexibilities should be.

flexibility_horizon_start_hours
    Controls at which point in time the calculation of flexibilities should
    start.

num_schedules
    Controls how many schedules are calculated for the flexibilities.

mapping
    This configures which models should be created and connected to which bus
    of the grid. The available models are as follows. `PV`: Photovoltaic power
    plant, can have arbitrary scaling and supports reactive power. `BAT`:
    Battery model, can have arbitrary scaling. `CHP`, Combined heat and power
    model, needs one of the scalings (0.007, 0.014, 0.2, 0.4). `HVAC`: Heat
    ventilation and air conditioning, can have arbitry scaling but will select
    closest to existing configuration. `Biogas` Biogas power plant, can have
    arbitrary scaling but will select closest to existing configuration.
    `Wind` Wind power plant, can have arbitrary scaling and supports reactive
    power.

weather_provider_mapping
    This configures where the models get their weather data from. It can be
    configured for all models of a type, which can already be seen in the
    example above, or individually. To configure it individually, we need to
    have at least two weather provider. This can either be a different scope
    or a different model of the same scope.

    .. code-block:: yaml

        my_scenario:
          ...
          weather_params:
            bremen:
              weather_mapping:
                WeatherCurrent:
                  - interpolate: true  # <-- first provider of `bremen`
                    randomize: false
                  - interpolate: true  # <-- second provider of `bremen`
                    randomize: true
            fichtelberg:
              weather_mapping:
                WeatherCurrent:
                  - interpolate: true  # <-- first provider of `fichtelberg`
                    randomize: false

    Next, we need to have multiple models that we want to connect to different
    providers. For simplification, we will only use PV and CHP models, but it
    works the same for other models.

    .. code-block:: yaml

        my_scenario:
        ...
        der_params:
          my_grid_scope:
            grid_name: my_grid_scope
            mapping:
              1: [[PV, 1.0], [PV, 1.0], [CHP, 0.4]]
              2: [[CHP, 0.4]]
              3: [[PV, 1.0], [CHP, 0.4]]
            weather_provider_mapping:
              PV: [[bremen, 0], [fichtelberg, 0], [bremen, 1]]
              CHP: [[fichtelberg, 0], [bremen, 1], [bremen, 0]]

    This will connect the first PV plant at bus 1 to the first provider from
    `bremen`, the second PV plant (at bus 1 as well) to `fichtelberg`, and the
    third PV plant, at bus 3, to the second provider at  `bremen`. The first
    CHP at bus 1 gets connected to `fichtelberg`, the second CHP at bus 2 to
    the second provider of `bremen` and the third CHP at bus 3 to the first
    provider of `bremen`. For a specific model type, you cannot mix global and
    individual mapping.

weather_forecast_mapping
    If models calculate forecasts or flexibilities, they need a weather
    forecast as well. The mapping works similar to the
    `weather_provider_mapping` but requires `WeatherForecast` models defined
    in the weather params.

Inputs of the Pyimmods Simulator
--------------------------------

There are inputs that are shared by all models, which are:

p_set_mw/p_set_kw
    Provide a setpoint for active power in MW or kW. You should only provide
    one of them.

local_time
    Overwrite the time value that is saved in the simulator with a custom time.
    Is used, e.g., by the time simulator.

Models that support reactive power calculation (`PV`, `Wind`) additionally have

q_set_mvar/q_set_kvar
    Provide a setpoint for reactive power in MVAr or kVAr. You should only
    provide one of them.

Models that require weather data (all except the battery) have weather
attributes as inputs. See the weather module for available attributes and
the `PySimMods`_ documentation for concrete requirements. But those values will
be provided automatically by midas.

Outputs of the Pysimmods Simulator
----------------------------------

There are outputs that are shared by all models, which are

p_mw/p_kw
    Current active power output.

q_mvar/qkvar
    Current reactive power output if available else 0.

Each model has specific outputs that are related to their internal state.
See the `PySimMods`_ documentation for more information.

.. _`PySimMods`: https://midas-mosaik.gitlab.io/pysimmods/
