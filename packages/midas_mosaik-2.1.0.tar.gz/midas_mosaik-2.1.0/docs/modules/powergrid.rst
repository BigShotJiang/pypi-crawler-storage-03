Midas Powergrid Module
======================

The *powergrid* module, provided by the `midas-powergrid` package, contains a
simulator for pandapower networks, which will be called *grids* in the context
of midas.

Installation
------------

This package will usually installed automatically together with `midas-mosaik`,
if you opt-in any of the extras, e.g., `base` or `bh`. It is available on pypi,
so you can install it manually with

.. code-block:: bash

    pip install midas-powergrids


Usage
-----

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

Inside of midas
~~~~~~~~~~~~~~~

To use the powergrid inside of midas, simply add `powergrid` to your modules

.. code-block:: yaml

    my_scenario:
      modules:
        - powergrid
        # - ...

and provide a *scope* and a *gridfile*:

.. code-block:: yaml

    my_scenario:
      # ...
      powergrid_params:
        my_grid_scope:
          gridfile: midasmv

Other, data-providing simulators with the same scope will output their data to
this grid. Possible values for *gridfile* will be described in the *Keys*
section below.

Any Mosaik Scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `powergrid` manually to your mosaik
scenario file. First, the entry in the `sim_config`:

.. code-block:: python

    sim_config = {
        "Powergrid": {"python": "midas.modules.powergrid.simulator:PandapowerSimulator"},
        # ...
    }

Next, you need to start the simulator (assuming a `step_size` of 900):

.. code-block:: python

    grid_sim = world.start("Powergrid", step_size=900)

Finally, the model needs to be started:

.. code-block:: python

    grid = grid_sim.Grid(gridfile="midasmv")

To connect the output of the grids' buses to another model, you have to get the
list of bus models from the powergrids' children like

.. code-block:: python

    bus_models = [e for e in grid.children if "bus" in e.eid]

and then connect those models either individually or in a loop, e.g.,

.. code-block:: python

    for bus in bus_models:
        world.connect(bus, other_entity, "vm_pu", "va_degree", "p_mw", "q_mvar")

The inputs are generally handled in the same way.
Have a look at `grid.children` to get the required entity eids.

The Keys of the Powergrid Simulator
-----------------------------------

This section gives a short description for all of the keys of the *powergrid*
module. Keys that are part of every upgrade module will only be mentioned if
the actual behavior might be unexpected.

step_size
  This key is mainly ignored by the grid model itself, since the model has no
  time-based internal state.

plotting
  This key allows to enable grid plotting for certain grids. The value is of
  type bool and defaults to `false`.

plot_path
  This key specifies where the plotted grid images will be stored. The value is
  of type string and the default value is `plots`, which will create a
  directory called *plots* in the *_outputs* directory defined in
  *midas-runtime-conf.yaml*.

save_grid_json
  The value of this key is of type bool. If set to true, the grid model will
  serialize the pandapower grid to json and send it to the database. Since the
  resulting string is rather long, this option is set to `false` by default.

constraints
  This key allows to define the constraints to be used in the simulation. See
  the constraints section below for more information.

exclude_slack_bus
  In early version of midas, the slack bus was not included as `bus`. This was
  changed in 2.0 but to restore old behavior, this flag can be set to `true`.

actuator_multiplier
  For the use in ARL scenarios with certain power grid topologies, this can be
  used to control the space of actuators beyond the default values stored in
  the grid.

All above keys can be overwritten (or solely defined) within a certain scope.
However, available on scope level only are the following keys:

gridfile
  This keys defines the grid topology to be loaded.
  The type of the value is string but there are different semantics to that
  string. First, there are a few pandapower grid topologies that can be
  directly accessed with aliases. Those are `cigre_hv`, `cigre_mv` and
  `cigre_lv` for the corresponding grids. Second, a few more aliases are
  `midasmv`, `midaslv`, and `bhv`, which load certain custom grids defined
  inside of midas (*bhv* is the Bremerhaven Grid developed by a students'
  project group at the University of Oldenburg). Next, any Simbench code can be
  entered to load the corresponding grid (to get the data set of that grid, you
  have to modify the *midas-runtime-conf.yaml*, see the *sbdata* module for
  more information). Finally, a python import string to a function can be
  entered that returns a pandapower grid. This allows to define custom grids
  even outside of midas. The last segment of the import string needs to be the
  function to be called. Parameters to that function can be passed with the
  *grid_params* key. Additionally, grids can be loaded from `.json` or `.xlsx`
  files can be loaded. The full (absolute or relative) path to those files
  needs to be entered.

grid_params
  This key allows to pass additional parameters to grids that are neither .json
  nor .xlsx nor Simbench grids. The value is of type dictionary and the values
  will be passed without further checking. The default value is an empty
  dictionary.

Inputs of the Powergrid Simulator
---------------------------------

The exact number of inputs depends on the grid topology that is used. The grid
has a number of children models, representing different components of the grid.

The most important attributes of loads, sgens, and storages (not available in
every grid) are:

p_mw
  Active power in Mega Watt of the grid node. The behavior depends on the role
  (load, sgen, or storage) and multiple inputs to the same node will be summed
  up. The value is of type float.

q_mvar
  Reactive power in Mega Volt-Ampere reactive of the grid node. The behavior
  depends on the role (load, sgen, or storage) and multiple inputs to the same
  node will be summed up. The value is of type float.

Transformators have an input as well:

tap_pos
  The currently active tap position. The value is of type integer and defaults
  to 0. The *tap_pos* can be between *tap_min* and *tap_max*, defined in the
  grid itself. Currently, there is no midas simulator that makes use of this
  input.

delta_tap_pos
  For some cases it might be more convenient to only change the tap position a
  level up or down. This can be achieved with *delta_tap_pos*, which does
  exactly this: increasing or decreasing the tap position by one level. Should
  not be mixed with *tap_pos*.

Finally, there are the switches which have an input:

closed
  Controls the current state of the switch. The default setting is closed,
  i.e., *closed* is set to `true`. Currently, there is no midas simulator that
  makes use of this input.


Outputs of the Powergrid Simulator
----------------------------------

Only the most important outputs are listed here, since pandapower provides a
lot of information about the grid that can be accessed with the simulator as
well. To get the full picture, have a look at the source code in the `meta.py`
file.

The grid itself has two outputs:

health
  The average voltage magnitude per unit of all the buses in the grid.
  The value is of type float.

grid_json
  A string containing the json-serialized grid.

The bus nodes of the grid have four outputs:

vm_pu
  The voltage magnitude per unit in relation to the slack node in the grid.
  The value is of type float.

va_degree
  The angle between voltage and current.
  The value is of type float.

p_mw
  The active power that arives at the bus.
  The value is of type float.

q_mvar
  The reactive power that arives at the bus. The value is of type float.

Lines and transformators have (among others) the following output:

loading_percent
  The load utilization relative to the rated power. The value is of type float.

Additionally, the nodes that are listed in the inputs section, will send there
current input to the database if one is used.


PalaestrAI Sensors of the Powergrid Simulator
---------------------------------------------

If the *with_arl* is set either on the scenario level or on the module level,
sensor objects for the following outputs will be created.

* loading_percent (Trafo, Line) = Box(0, np.inf, (), np.float32)
* vm_pu (Bus) = Box(0.0, np.inf, (), np.float32)
* va_degree (Bus) = Box(-np.inf, np.inf, (), np.float32)
* p_mw (Load, Sgen, Storage, Ext_grid) = Box(-np.inf, np.inf, (), np.float32)
* q_mvar (Load, Sgen, Storage, Ext_grid) = Box(-np.inf, np.inf, (), np.float32)
* health (Grid) = Box(0, np.inf, (), np.float32)

PalaestrAI Actuators of the Powergrid Simulator
-----------------------------------------------

With the *with_arl* flag, the following actuators will be created.
The spaces have the same limitations as with the sensors.

* tap_pos (Trafo): Box(-np.inf, np.inf, (), np.int32)
* p_mw (Load, Sgen, Storage): Box(-np.inf, np.inf, (), np.float32)
* q_mvar (Load, Sgen, Storage): Box(-np.inf, np.inf, (), np.float32)

The creation of actuators for load, sgen and storage requires that the grid
has created those entities and provided a default value other than zero.

Constraints
-----------

The simulator includes an implementation of grid constraints based on
"Technische Anschlussregelung Mittelspannung (TAR MS)" rules in Germany.
The can be activated by providing the `constraints` keyword and one or more of
the following entries:

.. code-block:: yaml

  powergrid_params:
    gridfile: midasmv
    constraints:
      - [bus, 0.1]
      - [line, 100]
      - [load, 0.02]
      - [sgen, 0.05]
      - [storage, 0.02]
      - [trafo, 3]

The constraints in detail are

bus
  This will monitor and check the voltage at each bus. With the default value
  of 0.1, the voltage has to be in the range [1.0-0.1, 1.0+0.1]. If that is not
  the case, some of the units (load, sgen, storage) connected to this bus will
  be put out of service. In each step, it will also be checked if such disabled
  units can be put in service again.

line
  This checks the loading percentage at the lines. The default value is 100,
  meaning that the loading may not exceed 100 percent, or the line will be put
  out of service. In each step, it will be checked if the line can be put in
  service again.

load/sgen/storage
  The logic is the same for those components. This constraint will check if the
  voltage change caused by power changes over a time frame of one minute is
  below the corresponding limit (0.02/0.05), or the entity will be put out of
  service. In each step, it will be checked if entities can be put in service
  again.

trafo
  This will check how many changes of the state of the tap changer are
  performed per hour. If the number exceeds the limit (3), then the trafo is
  put out of service. In each step, it will be checked if the trafo can be put
  in service again.

Example Scenario Configuration
------------------------------

The following scenario runs the same grid twice but one instance will use the
grid constraints.

.. code-block:: yaml

  two_grid_example:
    parent:
    modules: [store, powergrid, sndata, comdata]
    start_date: 2009-01-01 00:00:00+0100
    end: 1*24*60*60
    step_size: 15*60
    store_params:
      filename: two_grid_example.csv
    powergrid_params:
      midasmv:
        gridfile: midasmv
      midas_constr:
        gridfile: midasmv
        constraints:
          - [bus, 0.1]
          - [load, 0.02]
          - [line, 100]
    sndata_params:
      midasmv:
        interpolate: true
        meta_scaling: 2
        active_mapping:
          1: [[Land_0, 1.0], [Land_2, 1.0], [Land_3, 2.0], [Land_6, 2.0], [Land_7, 1.0]]
          3: [[Land_2, 1.0], [Land_3, 1.0], [Land_6, 1.0], [Land_7, 1.0]]
          4: [[Land_0, 2.0], [Land_3, 2.0], [Land_7, 1.0]]
          5: [[Land_3, 2.0], [Land_7, 1.0]]
          6: [[Land_0, 2.0], [Land_3, 1.0]]
          7: [[Land_0, 2.0], [Land_2, 1.0], [Land_3, 2.0], [Land_7, 1.0]]
          8: [[Land_0, 1.0], [Land_3, 1.0], [Land_6, 1.0]]
          9: [[Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
          10: [[Land_0, 2.0], [Land_2, 4.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
          11: [[Land_0, 1.0], [Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
      midas_constr:
        interpolate: true
        meta_scaling: 2
        active_mapping:
          1: [[Land_0, 1.0], [Land_2, 1.0], [Land_3, 2.0], [Land_6, 2.0], [Land_7, 1.0]]
          3: [[Land_2, 1.0], [Land_3, 1.0], [Land_6, 1.0], [Land_7, 1.0]]
          4: [[Land_0, 2.0], [Land_3, 2.0], [Land_7, 1.0]]
          5: [[Land_3, 2.0], [Land_7, 1.0]]
          6: [[Land_0, 2.0], [Land_3, 1.0]]
          7: [[Land_0, 2.0], [Land_2, 1.0], [Land_3, 2.0], [Land_7, 1.0]]
          8: [[Land_0, 1.0], [Land_3, 1.0], [Land_6, 1.0]]
          9: [[Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
          10: [[Land_0, 2.0], [Land_2, 4.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
          11: [[Land_0, 1.0], [Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
    comdata:
      midasmv:
        interpolate: true
        meta_scaling: 1.5
        active_mapping:
          13: [[SuperMarket, 3.0]]
          14: [[SmallHotel, 2.0]]
      midas_constr:
        interpolate: true
        meta_scaling: 1.5
        active_mapping:
          13: [[SuperMarket, 3.0]]
          14: [[SmallHotel, 2.0]]


The first plot shows the result from the grid without constraints.

.. image:: two_grid_example-Powergrid-0_0-buses_vmpu.png
    :width: 800


The second plot shows the results from the grid with constraints. Since one
of the loads had to high values, we get an overload at line 0, which
disconnects almost all buses from the grid.

.. image:: two_grid_example-Powergrid-1_0-buses_vmpu.png
    :width: 800
