Midas Smart Nord Data Module
============================

The *sndata* module, provided by the *midas-sndata* package, provides a
simulator for the Smart Nord Data set.

Installation
------------

This package will usually installed automatically together with `midas-mosaik`,
if you opt-in for the ``base`` extra. It is available on pypi, so you can
install it manually with

.. code-block:: bash

    pip install midas-sndata

The Data
--------

The data set is a synthetic data set developed in the research project
`Smart Nord`_. The data set consists of 941 individual time series, each of
them representing one household. Those time series are further grouped into 8
*low-voltage lands* of different sizes. The following table gives an overview
over the number of households per land as well as a few statistics of the
aggregated power consumption.

.. _`Smart Nord`: http://www.smartnord.de

==== ======= ========= ===== ====== =======
Land #Houses House IDs MWh/a avg kW peak kW
==== ======= ========= ===== ====== =======
0       41     0 -  40  130   14.8   39.9
1      139    41 - 179  661   75.5  516.6
2       67   180 - 246  323   36.9  148.2
3       57   247 - 303  223   25.5   70.9
4      169   304 - 472  741   84.6  277.9
5      299   473 - 771 1377  157.2  413.7
6       66   772 - 837  309   35.3   97.5
7      103   838 - 940  421   48.1  146.4
==== ======= ========= ===== ====== =======

The aggregated load of each lands is visualized in this figure:

.. image:: smart_nord_lands.png
    :width: 800

Usage
-----

The intended use-case for the sndata simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

Inside of midas
~~~~~~~~~~~~~~~

To use the simulator inside of midas, simply add `sndata` to your modules

.. code-block:: yaml

    my_scenario:
      modules:
        - sndata
        # - ...

and provide a *scope* and a configuration:

.. code-block:: yaml

    my_scenario:
      # ...
      sndata_params:
        my_grid_scope:
          active_mapping:
            1: [[Land_0, 1.0], [Land_2, 1.5]]
            3: [[House_000, 1.0]]

The mapping has to match to the grid that you're using.

Any Mosaik Scenario
~~~~~~~~~~~~~~~~~~~

If you don't use midas, you can add the `sndata` manually to your mosaik
scenario file. First, the entry in the `sim_config`:

.. code-block:: python

    sim_config = {
      "SmartNordData": {
        "python": "midas_powerseries.simulator:PowerSeriesSimulator"
      },
      # ...
    }

Next, you need to start the simulator (assuming a `step_size` of 900):

.. code-block:: python

    sndata_sim = world.start(
      "SmartNordData",
      step_size=900,
      start_date="2020-01-01 00:00:00+0100",
      data_path="/path/to/folder/where/dataset/is/located/",
      filename="smart_nord_profiles.csv",  # this is default
    )

Then the models can be started:

.. code-block:: python

    land1 = sndata_sim.CalculatedQTimeSeries(name="Land_0", scaling=1.0)
    land2 = sndata_sim.CalculatedQTimeSeries(name="Land_2", scaling=1.5)
    house1 = sndata_sim.CalculatedQTimeSeries(name="House_000", scaling=1.0)

Finally, the modells need to be connected to other entities:

.. code-block:: python

    world.connect(land1, other_entity, "p_mw", "q_mvar")

The Keys, Inputs, and Outputs of the Smart Nord Data Simulator
--------------------------------------------------------------

The Smart Nord Data Simulator is a subclass from the
:ref:`power-series-module`, it inherits all keys, inputs, and outputs from that
simulator.


Example
-------

The following example is taken from the default `midasmv` scenario file.

.. code-block:: yaml

  midasmv_sn:
    parent:
    modules: [store, powergrid, sndata]
    step_size: 15*60
    start_date: 2020-01-01 00:00:00+0100
    end: 1*24*60*60
  store_params:
    filename: midasmv.csv
    powergrid_params:
      midasmv:
        gridfile: midasmv
  sndata_params:
    midasmv:
      interpolate: true
      randomize_data: true
      randomize_cos_phi: true
      active_mapping:
        1: [[Land_0, 1.0], [Land_2, 1.0], [Land_3, 2.0], [Land_6, 2.0], [Land_7, 1.0]]
        3: [[Land_2, 1.0], [Land_3, 1.0], [Land_6, 1.0], [Land_7, 1.0]]
        4: [[Land_0, 2.0], [Land_3, 2.0], [Land_7, 1.0]]
        5: [[Land_3, 2.0], [Land_7, 1.0]]
        6: [[Land_0, 2.0], [Land_3, 1.0]]
        7: [[Land_0, 2.0], [Land_2, 1.0], [Land_3, 2.0], [Land_7, 1.0]]
        8: [[Land_0, 1.0], [Land_3, 1.0], [Land_6, 1.0]]
        9: [[Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
        10: [[Land_0, 2.0], [Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
        11: [[Land_0, 1.0], [Land_2, 1.0], [Land_3, 1.0], [Land_6, 2.0], [Land_7, 1.0]]
