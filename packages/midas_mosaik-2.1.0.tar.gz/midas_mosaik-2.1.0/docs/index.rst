.. MIDAS documentation master file, created by
   sphinx-quickstart on Thu Oct  8 08:55:26 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MIDAS's documentation!
=================================

The MultI-DomAin test Scenario (MIDAS) is a collection of `mosaik`_ simulators
for smart grid co-simulation and contains a semi-automatic scenario
configuration tool. With midas, you can (co-)simulate a powergrid, including
time series for load and generation, weather, and more sophisticated simulation
models. In YAML scenario files, you can customize, which and how many time
series should be used, what kind of simulation models you want to use or where
the weather data should come from. Midas will construct a mosaik simulation
from your configuration and runs it for you. But midas itself is no simulator.

The scenario files can be defined cascading, allowing for reusability and easy
creation of scenario variants in single or multiple files. The data sets that
are used by the different mosaik simulators are downloaded by midas during the
installation process. This means, you get a fully working smart grid simulation
with only a few command line commands or Python statements in your code:

.. code-block:: bash

   midasctl run my_scenario

or

.. code-block:: python

   import midas

   midas.run("my_scenario")


.. _`mosaik`: https://mosaik.offis.de

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   getting_started
   next_steps
   configuration
   modules/index
