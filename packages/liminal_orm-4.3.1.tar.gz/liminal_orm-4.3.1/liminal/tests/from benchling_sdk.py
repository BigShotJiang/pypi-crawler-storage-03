from benchling_sdk.models import Dropdown, DropdownOption

print(Dropdown(id="123", name="Test", options=[DropdownOption(id="123", name="Test")]))
