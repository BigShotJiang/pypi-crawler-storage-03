from RPA.Hubspot import Hubspot


def test_init():
    lib = Hubspot()
    assert lib
