rpaframework-hubspot
====================

This library enables API-based `Hubspot`_ automation for the  `RPA Framework`_
libraries. It includes several helper keywords for common tasks, and also
includes a search function that allows for more natural language-like searching
of Hubspot objects.

.. _RPA Framework: https://rpaframework.org
.. _Hubspot: https://developers.hubspot.com/docs/api/overview
