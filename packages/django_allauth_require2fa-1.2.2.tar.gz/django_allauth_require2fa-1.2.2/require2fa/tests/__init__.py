"""Tests for require2fa app."""
