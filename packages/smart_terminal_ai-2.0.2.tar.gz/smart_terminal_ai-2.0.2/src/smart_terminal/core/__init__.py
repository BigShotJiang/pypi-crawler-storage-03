"""
Core command processing modules
""" 