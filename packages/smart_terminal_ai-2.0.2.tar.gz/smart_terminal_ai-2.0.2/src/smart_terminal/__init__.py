"""
Smart Terminal - AI-powered terminal assistant with enhanced features
"""

__version__ = "2.0.2"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "AI-powered terminal assistant with natural language processing, git integration, system monitoring, and more" 