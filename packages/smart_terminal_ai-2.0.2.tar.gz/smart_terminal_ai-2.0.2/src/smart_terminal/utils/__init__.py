"""
Utility modules for configuration and shell integration
""" 