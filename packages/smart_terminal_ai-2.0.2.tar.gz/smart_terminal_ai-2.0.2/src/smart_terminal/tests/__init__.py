"""
Test modules for Smart Terminal
""" 