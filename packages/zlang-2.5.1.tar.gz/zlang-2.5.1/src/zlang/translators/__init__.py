from .t import T
from ._py import T as _py
from ._lua import T as _lua
from ..memz import ZinkLexer as mem