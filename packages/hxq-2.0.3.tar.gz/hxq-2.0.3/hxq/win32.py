# -*- coding: utf-8 -*-
# @Time    : 2022/6/6 13:06
# @Author  : hxq
# @Software: PyCharm
# @File    : win32.py
from hxq.libs.win32 import Client

__all__ = [
    "Client"
]

