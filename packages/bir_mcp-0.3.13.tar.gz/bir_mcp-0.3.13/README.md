https://confluence.kapitalbank.az/pages/viewpage.action?spaceKey=ITG&title=Internal+AI

npx @modelcontextprotocol/inspector uvx bir_mcp