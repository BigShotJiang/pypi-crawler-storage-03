
from html_alg_lib.simplify import process_to_cls_alg_html


def general_simplify_html_str(html_str: str) -> str:
    return process_to_cls_alg_html(html_str)
