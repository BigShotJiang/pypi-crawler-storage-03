from typing import Generator


def select_typical_html(html_strs: Generator[str]) -> str:
    """从多个HTML中选出头部和尾部最复杂的html."""
    pass
