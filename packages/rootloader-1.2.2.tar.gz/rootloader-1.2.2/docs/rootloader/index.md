# Rootloader

[Rootloader Index](../README.md#rootloader-index) / Rootloader

> Auto-generated documentation for [rootloader](../../rootloader/__init__.py) module.

- [Rootloader](#rootloader)
  - [Modules](#modules)

## Modules

- [attrdict](./attrdict.md)
- [tdirectory](./tdirectory.md)
- [tfile](./tfile.md)
- [th1](./th1.md)
- [th2](./th2.md)
- [tleaf](./tleaf.md)
- [ttree](./ttree.md)
- [Version](./version.md)