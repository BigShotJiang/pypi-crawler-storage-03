import os

type PathLike = str | os.PathLike[str]
