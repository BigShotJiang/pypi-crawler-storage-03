from gen_epix.fastapp.services import auth


# Non-CRUD commands
class GetIdentityProvidersCommand(auth.GetIdentityProvidersCommand):
    pass


# CRUD commands
