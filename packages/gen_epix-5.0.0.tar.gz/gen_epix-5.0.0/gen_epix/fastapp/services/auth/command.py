from gen_epix.fastapp.model import Command


class GetIdentityProvidersCommand(Command):
    pass
