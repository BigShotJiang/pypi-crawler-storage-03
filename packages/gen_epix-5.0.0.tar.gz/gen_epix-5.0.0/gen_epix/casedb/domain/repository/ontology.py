from gen_epix.casedb.domain import model as model  # forces models to be registered now
from gen_epix.fastapp import BaseRepository


class BaseOntologyRepository(BaseRepository):
    pass
