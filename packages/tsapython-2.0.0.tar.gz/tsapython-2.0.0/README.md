# tsapython

**An Unofficial Python API for the tinySA Device Series**

[![PyPI version](https://badge.fury.io/py/tsapython.svg)](https://badge.fury.io/py/tsapython)
[![License: GPL v2](https://img.shields.io/badge/License-GPL_v2-blue.svg)](https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html)

A Non-GUI Python API for the tinySA series of spectrum analyzer devices. This library provides programmatic control over tinySA devices for automated measurements, data collection, and analysis. 

Popular features:

- **Device Discovery**: Automatic detection and serial connection to tinySA devices
- **Frequency Sweeps**: Collect data across specified frequency ranges
- **Multiple Modes**: Support for both input and output modes (device dependent)
- **Data Export**: Easy integration with matplotlib, pandas, and numpy
- **Error Handling**: Error checking and verbose output options
- **Device Control**: Full programmatic control of tinySA settings and measurements

This repository uses official resources and documentation but is **NOT** endorsed by the official tinySA product, owner, or company. Refer to official resources and support for product information. This library was built for the official tinySA device line(s), so any knock-off or custom devices may not be compatible with the library. Unofficial devices have not been tested. 




## Full Code Examples:

The README on the [main GitHub repo](https://github.com/LC-Linkous/tinySA_python) has provides examples for all of the following:

* Direct device interfacing and control
* Realtime and static waterfall plots
* Exporting data to CSV files
* Plotting live scan data

## Documentation & Examples

For comprehensive documentation, advanced examples, and troubleshooting:

- **Library GitHub Repository**: [https://github.com/LC-Linkous/tinySA_python/](https://github.com/LC-Linkous/tinySA_python/)
- **Official tinySA Documentation**: [https://tinysa.org/wiki/](https://tinysa.org/wiki/), not associated with this library

## Contributing

This is an unofficial community project. Contributions welcome!

- Report bugs and request features on [GitHub]( https://github.com/LC-Linkous/tinySA_python)

- For device information and OFFICIAL resources, check the official tinySA community at [https://groups.io/g/tinysa](https://groups.io/g/tinysa)
 - Please do NOT request features or report bugs on the official community! This is an unofficial project and they do not maintain it.

## License

GPL-2.0 - This is unofficial software with no warranty, offered AS-IS. Use at your own risk.

The licensing of this software does NOT take priority over the official releases and the decisions of the official tinySA team. This licensing does NOT take priority for any of their products, including the devices that can be used with this software.

## Acknowledgments

- tinySA device creators and community, who have created an awesome device
- Official tinySA documentation and resources, especially www.tinysa.org/wiki/
- All contributors to this library, including those who have contributed code and reached out with questions

---

**Disclaimer**: This software is unofficial and not supported by the tinySA team. For official software and support, visit [tinysa.org](https://tinysa.org). The tinySA team does not offer tech support for this software, does not maintain it, and has no responsibility for any of the contents. 


