"""
tsapython - Unofficial Python package for tinySA spectrum analyzer
"""

__version__ = "2.0.0"

# In __init__.py
from .core import tinySA

__all__ = ["tinySA"]