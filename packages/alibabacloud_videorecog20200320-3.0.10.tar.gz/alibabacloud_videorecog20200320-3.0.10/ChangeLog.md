2025-08-25 Version: 3.0.9
- Generated python 2020-03-20 for videorecog.

2025-04-21 Version: 3.0.8
- Generated python 2020-03-20 for videorecog.

2023-03-14 Version: 3.0.7
- Update SplitVideoParts.

2023-03-03 Version: 3.0.6
- Update EvaluateVideoQuality.

2023-02-22 Version: 3.0.5
- Update EvaluateVideoQuality.

2023-02-21 Version: 3.0.4
- Update EvaluateVideoQuality.

2022-10-17 Version: 3.0.3
- Update RecognizeVideoCastCrewList.

2022-09-29 Version: 3.0.2
- Update RecognizeVideoCastCrewList.

2022-06-28 Version: 3.0.1
- Update RecognizeVideoCastCrewList.

2021-02-01 Version: 3.0.0
- Release UnderstandVideoContent.

2020-12-30 Version: 2.0.0
- AMP Version Change.

