Welcome to Python TeensyToAny's documentation!
======================================

.. mdinclude:: ../README.md

Contents
========

.. toctree::
   :maxdepth: 1

   installation
   usage
   modules
   CONTRIBUTING

   AUTHORS
   HISTORY

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
