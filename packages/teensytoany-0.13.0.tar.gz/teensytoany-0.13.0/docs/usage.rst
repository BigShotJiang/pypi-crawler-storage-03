=====
Usage
=====

To use Python TeensyToAny in a project::

    import python_teensytoany
