import pytest
from pylindas.pycube import Cube
from rdflib import Graph

class TestClass:
    def test_validate_cube(self):
        pass #test fora wrapper function?