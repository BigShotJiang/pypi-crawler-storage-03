from enum import Enum


class CustomerTypeEnum(str, Enum):
    OWNER = "owner"
    DRIVER = "driver"
    BUYER = "buyer"
    CLIENT = "client"
