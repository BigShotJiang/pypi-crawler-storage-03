__version__: str = "10.1.1"  # Must be "<major>.<minor>.<patch>", all numbers
