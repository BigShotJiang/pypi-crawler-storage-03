# PYTHON_ARGCOMPLETE_OK
from .cli import cli
