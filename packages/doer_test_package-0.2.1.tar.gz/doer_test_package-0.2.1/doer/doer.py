import time
def do(n):
    while True:
        print("Doing")
        time.sleep(n)