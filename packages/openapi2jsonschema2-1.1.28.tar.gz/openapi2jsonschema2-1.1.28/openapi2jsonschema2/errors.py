#!/usr/bin/env python


class UnsupportedError(Exception):
    pass
