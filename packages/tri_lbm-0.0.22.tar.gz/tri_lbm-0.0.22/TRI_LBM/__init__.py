from TRI_LBM.lbm import LBM
