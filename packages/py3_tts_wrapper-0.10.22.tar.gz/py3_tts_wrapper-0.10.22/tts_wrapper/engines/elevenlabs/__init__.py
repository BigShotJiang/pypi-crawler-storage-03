from .client import ElevenLabsClient

# For backward compatibility
ElevenLabsTTS = ElevenLabsClient
