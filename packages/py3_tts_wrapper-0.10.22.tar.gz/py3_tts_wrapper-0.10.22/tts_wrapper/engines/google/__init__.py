from .client import GoogleClient
from .ssml import GoogleSSML

# For backward compatibility
GoogleTTS = GoogleClient
