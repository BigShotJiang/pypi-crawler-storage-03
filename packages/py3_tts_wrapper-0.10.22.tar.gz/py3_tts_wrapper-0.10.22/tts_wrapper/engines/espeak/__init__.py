from .client import eSpeakClient
from .ssml import eSpeakSSML

# For backward compatibility
eSpeakTTS = eSpeakClient
