"""OpenAI TTS engine for tts-wrapper."""

from .client import OpenAIClient

__all__ = ["OpenAIClient"]
