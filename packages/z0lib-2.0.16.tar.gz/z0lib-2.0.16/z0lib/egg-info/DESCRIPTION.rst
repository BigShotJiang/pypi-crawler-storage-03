z0lib is a simple bash and python library.

It was created to give support to bash and python software.
The package has both bash version and both python version of functions.
Since 2022, bash development was abandoned and only python code is still upgraded.

.. important::

    However, most functions are still available for bash scripts.

The available libraries are:

* z0librc: bash version library
* z0librun.py: python version library
