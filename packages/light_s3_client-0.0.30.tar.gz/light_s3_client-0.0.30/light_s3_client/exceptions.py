class BucketNotFound(Exception):
    pass


class AccessDeniedToBucket(Exception):
    pass


class UnknownBucketError(Exception):
    pass
