from .main import hello

hello()
