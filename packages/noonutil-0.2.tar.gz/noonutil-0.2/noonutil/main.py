def hello():
    print("Hello ;)")