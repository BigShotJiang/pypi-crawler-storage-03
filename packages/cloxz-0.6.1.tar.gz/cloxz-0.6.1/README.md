Installation

```shell
pip install cloxz
```

Test the installation

```shell
cxz --help
```

Start clocking

```shell
cxz [in / out] [text]
```

(optional) Add to your shell configuration

```shell
cxz status
```
