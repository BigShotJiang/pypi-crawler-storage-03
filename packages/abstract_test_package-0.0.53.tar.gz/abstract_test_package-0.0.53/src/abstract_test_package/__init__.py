def function():
    print("hello from src/__init__.py")
