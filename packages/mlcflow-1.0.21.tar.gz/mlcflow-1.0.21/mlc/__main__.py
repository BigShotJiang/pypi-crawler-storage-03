from mlc import main
main.main()
