__version__ = (7, 0, 65)

def version():
    return '%s.%s.%s' % __version__

