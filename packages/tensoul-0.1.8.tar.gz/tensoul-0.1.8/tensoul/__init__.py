from .downloader import MajsoulPaipuDownloader
