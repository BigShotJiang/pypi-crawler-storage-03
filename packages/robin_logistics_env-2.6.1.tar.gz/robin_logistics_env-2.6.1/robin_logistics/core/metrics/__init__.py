"""Metrics module for solution analysis and statistics."""

from .calculator import MetricsCalculator

__all__ = ['MetricsCalculator']
