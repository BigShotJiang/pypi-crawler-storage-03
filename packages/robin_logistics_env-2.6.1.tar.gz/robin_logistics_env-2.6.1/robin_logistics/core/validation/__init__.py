"""Validation module for solution and route validation."""

from .validator import SolutionValidator

__all__ = ['SolutionValidator']
