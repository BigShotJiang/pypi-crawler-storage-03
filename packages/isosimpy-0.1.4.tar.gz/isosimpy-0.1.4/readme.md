<img src="https://github.com/iGW-TU-Dresden/ISOSIMpy/blob/main/logo.png" width="400">

# ISOSIMpy

Lumped parameter groundwater age simulations with a simple user interface - in Python
