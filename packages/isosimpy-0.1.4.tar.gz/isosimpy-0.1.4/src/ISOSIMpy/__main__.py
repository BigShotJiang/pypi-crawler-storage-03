# src/ISOSIMpy/__main__.py
from ISOSIMpy.app import main

if __name__ == "__main__":
    main()
