from gdsfactory.components.analog.interdigital_capacitor import (
    interdigital_capacitor,
)

__all__ = ["interdigital_capacitor"]
