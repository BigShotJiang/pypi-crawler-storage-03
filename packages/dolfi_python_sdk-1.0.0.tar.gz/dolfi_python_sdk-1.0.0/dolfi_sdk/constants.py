"""
Constants for Dolfi Python SDK.
"""

# API Configuration
DOLFI_BASE_URL = "https://search-api-gateway-instance-25hl8kkc.an.gateway.dev"
