# mdtranslator

Markdown 文件翻译 CLI（OpenAI/Anthropic/Google，代码块跳过，增量翻译，429 全局退避）

## 安装
基础功能（不含模型提供商依赖）：
```bash
pip install mdtranslator
```
