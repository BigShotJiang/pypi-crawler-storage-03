from pathlib import Path
from .pymetkit import *
import importlib.metadata

__version__ = importlib.metadata.version("pymetkit")
