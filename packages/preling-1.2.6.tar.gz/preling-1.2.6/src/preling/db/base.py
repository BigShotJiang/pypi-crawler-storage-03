from sqlalchemy.orm import DeclarativeBase

__all__ = [
    'Base',
]


class Base(DeclarativeBase):
    pass
