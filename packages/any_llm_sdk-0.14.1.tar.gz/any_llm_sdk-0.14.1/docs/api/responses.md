## Responses


!!! warning

    This API is experimental and subject to changes based upon our experience as we integrate additional providers.
    Use with caution.

::: any_llm.responses
::: any_llm.aresponses
