import kochen.common  # v0.2024.2

print(kochen.common.test_identitytest(121))