from pathlib import Path

from .fixtures import *

DATA_DIR = Path(__file__).parent / "data"
