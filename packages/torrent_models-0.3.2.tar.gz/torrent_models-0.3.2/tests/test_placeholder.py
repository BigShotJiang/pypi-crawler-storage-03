def test_nothing():
    import torrent_models  # noqa: F401
