# basic torrent

intended to be used with 32kb piece size.

- `bunny` a file that is smaller than the piece size
- `wabbit` - a file that is larger than the piece size
- `duck` - a file that is exactly the piece size
- `hunny/bunny` - a file in a subdirectory with the same name as a file
  in the root directory but different size
- `wascawwy/wabbit` a file in a subdirectory with the same name as a file 
  in the root but the same size
- and this file