from .ocr import DocuOCR

__all__ = ["DocuOCR"]
__version__ = "0.1.3"
