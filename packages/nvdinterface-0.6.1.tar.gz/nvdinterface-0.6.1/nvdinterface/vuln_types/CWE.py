class CWE:

    def __init__(self):
        raise NotImplementedError()
