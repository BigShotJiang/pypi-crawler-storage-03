class InvalidParametersException(ValueError):
    pass
