from DashAI.back.dependencies.registry.component_registry import (  # noqa: F401
    ComponentRegistry,
)
