class TabularClassificationModel:
    """Class for models associated to TabularClassificationTask."""

    COMPATIBLE_COMPONENTS = ["TabularClassificationTask"]
