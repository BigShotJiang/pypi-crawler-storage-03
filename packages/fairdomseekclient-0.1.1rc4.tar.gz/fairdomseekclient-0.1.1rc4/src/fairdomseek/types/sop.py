from fairdomseek.types.base_types import BaseType


class SOP(BaseType):

    def __init__(self, metadata=None):
        super().__init__(metadata)