from fairdomseek.service.base_service import BaseService


class SopService(BaseService):

    def __init__(self):
        super().__init__()
