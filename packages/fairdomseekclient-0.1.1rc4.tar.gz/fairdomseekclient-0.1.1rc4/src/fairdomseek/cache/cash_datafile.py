import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Union

from fairdomseek.cache.cache import Cache
from openapi_client import DataFilesApi

from tenacity import (
    retry, stop_after_attempt, wait_random_exponential,
    retry_if_exception_type, retry_if_result, before_sleep_log
)

LOGGER = logging.getLogger(__name__)

class DataFileCache(Cache):

    def __init__(self, actor_service, translator, client, project_name=None):
        super().__init__(client, project_name)
        self.api = DataFilesApi(client)
        self._actor_service = actor_service
        self._translator = translator

        self._df_by_id = {}
        self._df_by_title = {}
        self._external_df = []

    def refresh(self):
        if len(self._external_df) == 0 and len(self._df_by_title) == 0 and len(self._df_by_id) == 0:
            # Fresh cache
            self.__fetch_datafiles(self._project_id)
            return

        all_df_ids = [int(d.id)  for d in self.api.list_data_files().data]
        to_evaluate = []
        for df_id in all_df_ids:
            if df_id in self._df_by_id.keys() or df_id in self._external_df:
                continue
            else:
                to_evaluate.append(df_id)

        if len(to_evaluate) != 0:
            self.__fetch_datafiles(self._project_id, to_evaluate)

    def list_datafile_by_id(self):
        return self._df_by_id

    def list_datafile_by_title(self):
        return self._df_by_title

    def get_datafile(self, datafile: Union[int, str]):
        if isinstance(datafile, int):
            return self._df_by_id.get(datafile, None)
        if isinstance(datafile, str):
            return self._df_by_title.get(datafile, None)
        return None

    def __fetch_datafiles(self, project_id: str, df_ids: List[int] = []):

        if len(df_ids) == 0:
            # evaluate everything
            df_ids_to_cache = [int(d.id)  for d in self.api.list_data_files().data]
        else:
            df_ids_to_cache = df_ids

        def is_valid(my_resp) -> bool:
            try:
                return (
                        my_resp is not None and
                        'relationships' in my_resp and
                        'projects' in my_resp['relationships'] and
                        'data' in my_resp['relationships']['projects'] and
                        'policy' in my_resp['attributes']
                )
            except Exception:
                print("Validation failed")
                return False

        @retry(
            stop=stop_after_attempt(3),  # total attempts = 3
            wait=wait_random_exponential(multiplier=0.25, max=5),  # jittery exponential backoff
            retry=(retry_if_exception_type(Exception) |  # retry on exceptions
                   retry_if_result(lambda r: not is_valid(r))),  # ...or invalid payloads
            reraise=True,
        )
        def read_df_with_retry(sid):
            return read_df(sid)

        def read_df(df_id):
            # Fetch with initial version to get latest id
            resp =  self.api.read_data_file_without_preload_content(1, df_id)
            if resp is None:
                raise Exception("Data file with id {} read failed".format(df_id))
            my_resp = json.loads(resp.data.decode('utf-8'))
            # Refetch with latest
            my_resp =  self.api.read_data_file_without_preload_content(my_resp['data']['attributes']['latest_version'], df_id)
            if my_resp is None:
                raise Exception("Data file with id {} read failed".format(df_id))
            return json.loads(resp.data.decode('utf-8'))['data']

        with ThreadPoolExecutor(max_workers=8) as executor:
            #We fetch everything we can read here, not everything belong to us
            future_to_id = {executor.submit(read_df_with_retry, sid): sid for sid in df_ids_to_cache}

            for future in as_completed(future_to_id):
                resp = future.result()
                if project_id in [project['id'] for project in resp['relationships']['projects']['data']]:
                    domain_datafile = self._translator.to_domain(resp, self._actor_service.get_actors_idx_by_id())
                    self._df_by_id[domain_datafile.external_id]  = domain_datafile
                    self._df_by_title[domain_datafile.title] = domain_datafile
                else:
                    self._external_df.append(resp.data.id)

    def set_client(self, client):
        self.api = DataFilesApi(client)
        super().set_client(client)

