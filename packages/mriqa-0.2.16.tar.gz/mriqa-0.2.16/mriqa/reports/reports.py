#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""reports.py: graphical reports of QA parameters."""

# reports refactored into separate modules now
