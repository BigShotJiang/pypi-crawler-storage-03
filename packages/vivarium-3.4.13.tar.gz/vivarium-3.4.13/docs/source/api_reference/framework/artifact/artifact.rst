.. automodule:: vivarium.framework.artifact.artifact
