.. automodule:: vivarium.framework.lookup.table
