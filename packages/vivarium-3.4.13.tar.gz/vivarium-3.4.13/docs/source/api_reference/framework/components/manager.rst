.. automodule:: vivarium.framework.components.manager
