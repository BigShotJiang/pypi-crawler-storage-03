.. automodule:: vivarium.interface.cli
