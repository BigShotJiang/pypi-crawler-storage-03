# SPDX-FileCopyrightText: 2025-present muskuloes <tuekam@lmu.de>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0"
