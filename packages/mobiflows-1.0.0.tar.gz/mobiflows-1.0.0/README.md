# mobiflows

[![test](https://github.com/muskuloes/mobiflows/actions/workflows/test.yml/badge.svg)](https://github.com/muskuloes/mobiflows/actions/workflows/test.yml)
[![PyPI - Version](https://img.shields.io/pypi/v/mobiflows.svg)](https://pypi.org/project/mobiflows)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mobiflows.svg)](https://pypi.org/project/mobiflows)

-----

## Installation

```console
pip install mobiflows
```

## License

`mobiflows` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
