"""Tools to make python interface objects for http services"""

from ho.base import route_to_func, routes_to_funcs
