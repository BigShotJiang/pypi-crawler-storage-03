"""pya2l version module"""

__version__ = "0.17.1"
