# import sys


string_type = str
