from mosheh.handlers.python import handle_python_file


__all__ = ['handle_python_file']
