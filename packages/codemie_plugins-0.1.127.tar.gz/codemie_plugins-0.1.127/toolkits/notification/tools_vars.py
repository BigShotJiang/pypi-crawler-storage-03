from codemie.toolkit import RemoteToolMetadata

EMAIL_TOOL = RemoteToolMetadata(
    name="_email_tool",
    description="Use this tool when you asked to send a notification via email.",
    label="Email tool",
)
