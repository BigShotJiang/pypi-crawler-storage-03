"""
Main components of the application: routers, config, main, pagination and create super user script.
"""

from .version import __version__

__all__ = ["__version__"]
