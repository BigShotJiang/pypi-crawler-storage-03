"""Module for the job script templates."""
