"""Custom exception for PyGrain-specific internal errors."""


class PyGrainInternalError(Exception):
  pass
