from .game import Chess4x4
