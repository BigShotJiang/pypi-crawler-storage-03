# Authors

The following individuals have contributed to the development and maintenance of the `nuxt_payload` library.

## Core Contributors

- *Jean-Marie Favreau* jeanmarie.favreau@free.fr