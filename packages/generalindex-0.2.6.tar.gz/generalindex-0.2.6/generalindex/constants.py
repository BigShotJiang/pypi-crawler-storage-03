LOGGER_NAME = 'GX_SDK'
API_ENDPOINT = 'https://api.g-x.co'
USER_AGENT = 'GX_PythonSDK_V0.1.13'

