"""Top-level package for PyVelocity."""

__author__ = """Yukihiko Shinoda"""
__email__ = "yuk.hik.future@gmail.com"
__version__ = "0.3.0"
