"""Constants used throughout PyVelocity."""

LATEST_PYTHON_VERSION = "3.13"
