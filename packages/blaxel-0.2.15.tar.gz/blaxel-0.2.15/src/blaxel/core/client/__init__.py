"""A client library for accessing Blaxel Control Plane"""

from .client import Client, client

__all__ = (
    "Client",
    "client",
)
