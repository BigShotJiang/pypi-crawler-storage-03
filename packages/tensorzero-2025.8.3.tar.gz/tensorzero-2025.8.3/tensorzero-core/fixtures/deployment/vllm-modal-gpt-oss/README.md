To deploy: `uv run modal deploy vllm_gpt_oss.py`
