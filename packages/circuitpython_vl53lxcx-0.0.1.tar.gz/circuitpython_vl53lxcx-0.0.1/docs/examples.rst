Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/vl53lxcx_simpletest.py
    :caption: examples/vl53lxcx_simpletest.py
    :linenos:
