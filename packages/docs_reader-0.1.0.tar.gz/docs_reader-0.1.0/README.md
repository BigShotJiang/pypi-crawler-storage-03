# docs_reader

- A simple tool to track previous or nearest import lines and show helper documents automatically.

## installation
```bash
pip install docs_reader
```

## usage
```python
 1. ...
 2. from doc_reader import DocsReader
 3. DocsReader()
 4. ...
 5. ...
``` 