HUGR Python API Documentation
==================================

This is the API documentation for the HUGR Python package.


.. autosummary::
   :toctree: generated
   :template: autosummary/module.rst
   :recursive:

   hugr

.. toctree::

   Github <https://github.com/CQCL/hugr>
   HUGR Specification <https://github.com/CQCL/hugr/blob/main/specification/hugr.md>
   pypi <https://pypi.org/project/hugr/>



Indices and tables
~~~~~~~~~~~~~~~~~~

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
