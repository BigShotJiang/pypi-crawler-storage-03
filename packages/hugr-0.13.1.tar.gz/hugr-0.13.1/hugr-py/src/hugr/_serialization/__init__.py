"""Serialized HUGR objects as pydantic models."""
