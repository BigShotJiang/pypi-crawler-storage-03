"""Standard extensions for collection types and operations."""
