# test_version.py
import eones


def test_version():
    assert eones.__version__ == "1.3.2"
