"""Core module initializer for Eones."""
