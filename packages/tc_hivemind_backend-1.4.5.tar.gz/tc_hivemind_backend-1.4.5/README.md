# Hivemind-backend

[![Maintainability](https://api.codeclimate.com/v1/badges/1f01c7faab6d09fa3a83/maintainability)](https://codeclimate.com/github/TogetherCrew/hivemind-backend/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/1f01c7faab6d09fa3a83/test_coverage)](https://codeclimate.com/github/TogetherCrew/hivemind-backend/test_coverage)

This repository is designed to be a shared library for our hivemind etl sctips and bot codes.
