Model
=======

.. autoclass:: hinteval.cores.model.model.AnswerAware
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.model.model.AnswerAgnostic
    :members:
    :inherited-members: