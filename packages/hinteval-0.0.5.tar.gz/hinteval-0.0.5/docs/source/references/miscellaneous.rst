Miscellaneous
=======

.. automodule:: hinteval.utils.identify_functions
   :members: