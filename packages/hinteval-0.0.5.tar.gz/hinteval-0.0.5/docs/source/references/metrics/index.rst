Metrics
==========

.. toctree::
    relevance
    readability
    convergence
    familiarity
    answer_leakage