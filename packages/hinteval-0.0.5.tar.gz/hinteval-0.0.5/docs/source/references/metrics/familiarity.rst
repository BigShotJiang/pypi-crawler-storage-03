Familiarity
=======

.. autoclass:: hinteval.cores.evaluation_metrics.familiarity.WordFrequency
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.familiarity.Wikipedia
    :members:
    :inherited-members: