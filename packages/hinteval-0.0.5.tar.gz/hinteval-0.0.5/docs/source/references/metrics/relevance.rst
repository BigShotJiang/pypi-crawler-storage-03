Relevance
=========

.. autoclass:: hinteval.cores.evaluation_metrics.relevance.Rouge
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.relevance.NonContextualEmbeddings
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.relevance.ContextualEmbeddings
    :members:
    :inherited-members:

.. autoclass:: hinteval.cores.evaluation_metrics.relevance.LlmBased
    :members:
    :inherited-members:
