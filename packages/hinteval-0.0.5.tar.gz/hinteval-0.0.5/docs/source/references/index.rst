.. _references:
📖 References
==========

Reference documents for the ``hinteval`` package.

.. toctree::
   dataset
   metrics/index
   model
   miscellaneous
