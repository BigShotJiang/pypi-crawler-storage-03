(community)=

# ❤️ Community

A well-known Persian proverb says:
<div style="display: flex; justify-content: space-between; font-size: 20px; font-style: italic; font-weight: bold;">
  <span>One hand has no sound.</span>
  <span style="direction: rtl;">یک دست صدا ندارد.</span>
</div>

<p>Our project comes to life thanks to the awesome energy, skills, and passion of our community. It’s not just about coding—it’s about people coming together to make something really special. This space is all about appreciating every little (or big!) contribution and giving a shoutout to the amazing folks who make it all happen.</p>

## **🌟 Contributors**

Get to know some of our amazing members who have made impactful contributions!

<!-- - 🌏 [Jamshid Mozafari](https://www.jmozafari.com/) -->
<!-- - 🌍 [Adam Jatowt](https://adammo12.github.io/adamjatowt/) -->
