# jenkins-auto-publish-app
Usage:
1. Import the package -> from my_complex_app.calc import Complex, sum
2. Create any two complex numbers. eg: comp1 = Complex(2,3); comp2 = Complex(4,5)
3. Invoke the sum method. eg: sum(comp1, comp2)

