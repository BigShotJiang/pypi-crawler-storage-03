Module that extends from *loyalty_criteria_multi_product* and allows to
use it's configuration in sale orders.
