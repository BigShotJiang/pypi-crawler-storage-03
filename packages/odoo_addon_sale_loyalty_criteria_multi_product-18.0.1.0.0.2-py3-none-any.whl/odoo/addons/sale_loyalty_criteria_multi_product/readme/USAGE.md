Once configured, apply the programs as usual.
