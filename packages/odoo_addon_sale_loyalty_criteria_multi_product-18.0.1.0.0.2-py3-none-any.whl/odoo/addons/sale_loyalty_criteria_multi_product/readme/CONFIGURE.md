Follow the steps described in the base module.
