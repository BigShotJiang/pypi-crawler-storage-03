"""Version information"""

VERSION = "1.3.0"
__version__ = VERSION
