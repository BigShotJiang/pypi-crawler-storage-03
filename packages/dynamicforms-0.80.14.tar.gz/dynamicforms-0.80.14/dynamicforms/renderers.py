from .template_render import ComponentDefRenderer  # noqa: F401
