brickschema package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   brickschema.brickify

Submodules
----------

brickschema.abbrmap module
--------------------------

.. automodule:: brickschema.abbrmap
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.bacnet module
-------------------------

.. automodule:: brickschema.bacnet
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.graph module
------------------------

.. automodule:: brickschema.graph
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.inference module
----------------------------

.. automodule:: brickschema.inference
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.merge module
------------------------

.. automodule:: brickschema.merge
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.namespaces module
-----------------------------

.. automodule:: brickschema.namespaces
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.orm module
----------------------

.. automodule:: brickschema.orm
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.persistent module
-----------------------------

.. automodule:: brickschema.persistent
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.tagmap module
-------------------------

.. automodule:: brickschema.tagmap
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.topquadrant\_shacl module
-------------------------------------

.. automodule:: brickschema.topquadrant_shacl
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.web module
----------------------

.. automodule:: brickschema.web
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: brickschema
   :members:
   :show-inheritance:
   :undoc-members:
