brickschema.brickify package
============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   brickschema.brickify.src

Submodules
----------

brickschema.brickify.main module
--------------------------------

.. automodule:: brickschema.brickify.main
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.brickify.util module
--------------------------------

.. automodule:: brickschema.brickify.util
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: brickschema.brickify
   :members:
   :show-inheritance:
   :undoc-members:
