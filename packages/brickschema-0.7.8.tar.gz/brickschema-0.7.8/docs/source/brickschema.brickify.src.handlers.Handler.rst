brickschema.brickify.src.handlers.Handler package
=================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   brickschema.brickify.src.handlers.Handler.HaystackHandler
   brickschema.brickify.src.handlers.Handler.RACHandler

Submodules
----------

brickschema.brickify.src.handlers.Handler.Handler module
--------------------------------------------------------

.. automodule:: brickschema.brickify.src.handlers.Handler.Handler
   :members:
   :show-inheritance:
   :undoc-members:

brickschema.brickify.src.handlers.Handler.TableHandler module
-------------------------------------------------------------

.. automodule:: brickschema.brickify.src.handlers.Handler.TableHandler
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: brickschema.brickify.src.handlers.Handler
   :members:
   :show-inheritance:
   :undoc-members:
