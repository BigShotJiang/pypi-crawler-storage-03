# Haystack

```sh
brickify "https://project-haystack.dev/example/download/charlie.ttl" --input-type haystack --output charlie-brick.ttl
```