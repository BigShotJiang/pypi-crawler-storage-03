# RAC

### Step 1
```sh
brickify tcs.xls --input-type rac --output tcs.ttl 
```
**OR**

```sh
brickify tcs.xls --input-type rac --output tcs.ttl --building-prefix tcs --building-namespace https://cmu.edu/building/tcs# --site-na
mespace https://cmu.edu/site#
```

### Step 2
```sh
Enter the Sheet IDs  [all]: 0, 1
```

