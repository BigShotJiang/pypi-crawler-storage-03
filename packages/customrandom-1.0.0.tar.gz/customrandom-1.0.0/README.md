# customrandom

Customrandom is a module for creating your own random number generators. It has a Random class which defines methods such as randint, randrange etc. to mimic Python's random.Random class.