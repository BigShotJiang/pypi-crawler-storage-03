from abc import ABC, abstractmethod

class ISchedule(ABC):
    pass