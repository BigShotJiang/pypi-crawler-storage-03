from pathlib import PurePosixPath as Path


ROOT_PATH = Path("/")
