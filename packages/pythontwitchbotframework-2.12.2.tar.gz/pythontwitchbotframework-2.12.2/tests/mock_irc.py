from twitchbot import Irc


class MockIrc(Irc):
    pass
