# *pyslider* project by Mark Veltzer

description: Pyslider is a tool to create pdf slides from markdown

project website: https://veltzer.github.io/pyslider

author: Mark Veltzer

version: 0.0.1

![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)

## github

![License](https://img.shields.io/github/license/veltzer/pyslider)

## build

![build](https://github.com/veltzer/pyslider/workflows/build/badge.svg)

## pypi

![PyPI - Status](https://img.shields.io/pypi/status/pyslider)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyslider)
![PyPI - License](https://img.shields.io/pypi/l/pyslider)
![PyPI - Package Name](https://img.shields.io/pypi/v/pyslider)
![PyPI - Format](https://img.shields.io/pypi/format/pyslider)

## pypi download

![PyPI - Downloads](https://img.shields.io/pypi/dd/pyslider)
![PyPI - Downloads](https://img.shields.io/pypi/dw/pyslider)
![PyPI - Downloads](https://img.shields.io/pypi/dm/pyslider)



## contact me
[mailto](mailto:mark.veltzer@gmail.com)
![gitter](https://img.shields.io/gitter/room/veltzer/mark.veltzer)
![discord](https://img.shields.io/discord/719336281624281119)
![discord](https://img.shields.io/discord/719336282194444302)

Mark Veltzer, Copyright © 2025
