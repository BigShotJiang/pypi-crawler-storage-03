- Laurent Mignon \<<laurent.mignon@acsone.eu>\>
  (<https://www.acsone.eu/>)
- Lindsay Marion \<<lindsay.marion@acsone.eu>\>
  (<https://www.acsone.eu/>)
- Denis Roussel \<<denis.roussel@acsone.eu>\>
  (<https://www.acsone.eu/>)
