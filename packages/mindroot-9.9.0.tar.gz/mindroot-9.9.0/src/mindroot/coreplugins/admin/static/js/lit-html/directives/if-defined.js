import{nothing as t}from"../lit-html.js";
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const o=o=>o??t;export{o as ifDefined};
//# sourceMappingURL=if-defined.js.map
