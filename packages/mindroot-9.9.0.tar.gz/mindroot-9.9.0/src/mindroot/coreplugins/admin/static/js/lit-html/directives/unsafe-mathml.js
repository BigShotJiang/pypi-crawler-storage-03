import{directive as s}from"../directive.js";import{UnsafeHTMLDirective as t}from"./unsafe-html.js";
/**
 * @license
 * Copyright 2024 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class e extends t{}e.directiveName="unsafeMath",e.resultType=3;const o=s(e);export{o as unsafeMathML};
//# sourceMappingURL=unsafe-mathml.js.map
