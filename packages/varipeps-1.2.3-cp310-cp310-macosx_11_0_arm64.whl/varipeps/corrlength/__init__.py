from . import corrlength
from .corrlength import calculate_correlation_length
