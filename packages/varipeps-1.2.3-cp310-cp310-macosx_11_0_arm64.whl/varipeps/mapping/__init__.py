from .model import Map_To_PEPS_Model
from . import florett_pentagon
from . import honeycomb
from . import kagome
from . import maple_leaf
from . import square_kagome
from . import triangular
