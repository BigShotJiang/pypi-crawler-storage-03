#!/usr/bin/env python
# Feature flags

feature_use_pyopenssl = True  # use pyopenssl API or openssl command
