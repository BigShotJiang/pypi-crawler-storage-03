In the menu *Invoicing/Accounting \> Customers \> Debit Order*, create a
new debit order and select the Payment Mode dedicated to SEPA Direct
Debit that you created during the configuration step.
