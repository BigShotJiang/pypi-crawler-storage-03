"""口袋量化策略接口。

导入后可直接使用内置对象和方法::

    from pquant import *
"""

# 策略内置对象定义
from .schemas import *
# 策略内置方法
from .method import *
