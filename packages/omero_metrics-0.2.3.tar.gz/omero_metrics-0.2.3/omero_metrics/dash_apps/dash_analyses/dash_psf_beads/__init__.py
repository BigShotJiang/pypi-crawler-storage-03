# config={
#     "displayModeBar": True,
#     "scrollZoom": True,
#     "modeBarButtonsToRemove": [
#         "lasso2d",
#         "select2d",
#     ],
# },
