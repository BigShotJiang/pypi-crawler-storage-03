from identityfunction.core import *
from identityfunction.tests import *

if __name__ == "__main__":
    main()
