from django_bulk_hooks.priority import Priority

DEFAULT_PRIORITY = Priority.NORMAL
