import nltk

# download required corpora
nltk.download('words')
nltk.download('names')
