#!/usr/bin/env python3

from . chunker import run

if __name__ == '__main__':
    run()

