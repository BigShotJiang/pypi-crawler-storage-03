# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

__all__ = ["deadline_dev_gui_main", "main"]

from . import deadline_dev_gui_main
from ._deadline_cli import main
