from .stats import linear_quantile

__all__=['linear_quantile']
