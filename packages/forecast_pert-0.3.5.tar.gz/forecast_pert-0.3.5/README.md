forecast 0.3.1 — refined layout, IEEE-aligned naming, aliases for 0.1.
