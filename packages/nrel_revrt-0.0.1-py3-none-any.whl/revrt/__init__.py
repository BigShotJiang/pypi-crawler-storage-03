"""Top-level package for Python Package Template."""

__author__ = """Guilherme Castelao"""
__email__ = 'gpimenta@nrel.gov'

from ._version import __version__
