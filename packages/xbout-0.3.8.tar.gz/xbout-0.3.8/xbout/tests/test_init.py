def test_version():
    from xbout import __version__

    assert __version__
