# -*- coding: utf-8 -*-
# All supported Atmosphere and AtmosphereGrid formats should be in this folder
# Each with its own python file
