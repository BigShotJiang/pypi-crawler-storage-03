import os
from pathlib import Path

SRC_ROOT = Path(os.path.abspath(os.path.dirname(__file__)))
