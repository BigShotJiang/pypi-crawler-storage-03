from synapse_invite_checker.invite_checker import InviteChecker  # noqa: F401
