from eszett_replacer.core import *
from eszett_replacer.tests import *

if __name__ == "__main__":
    main()
