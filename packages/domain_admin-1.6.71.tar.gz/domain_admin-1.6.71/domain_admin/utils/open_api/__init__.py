# -*- coding: utf-8 -*-
"""
@File    : __init__.py.py
@Date    : 2023-06-22

第三放开放平台接口
"""