# -*- coding: utf-8 -*-
"""
@File    : __init__.py.py
@Date    : 2023-03-25
"""

from .whois_util import get_domain_info
from .whois_util import get_domain_raw_whois
from .whois_util import resolve_domain
