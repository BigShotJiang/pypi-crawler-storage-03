# -*- coding: utf-8 -*-
"""
@File    : cert_info.py
@Date    : 2023-06-19
"""
from __future__ import print_function, unicode_literals, absolute_import, division


class CertInfo(object):
    # 开始时间 datetime
    start_time = None
    # 结束时间 datetime
    expire_time = None
