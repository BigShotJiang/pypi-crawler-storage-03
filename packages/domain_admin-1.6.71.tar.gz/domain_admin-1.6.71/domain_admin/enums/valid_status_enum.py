# -*- coding: utf-8 -*-
"""
@File    : valid_status_enum.py
@Date    : 2024-06-27
"""

class ValidStatus(object):
    """
    验证状态
    """
    PENDING = 'pending'

    VALID = 'valid'
