# -*- coding: utf-8 -*-
"""
@File    : dns_type_enum.py
@Date    : 2024-06-17
"""


class DnsTypeEnum(object):
    """
    DNS账户类型枚举
    """
    # 阿里云
    ALIYUN = 1

    # 腾讯云
    TENCENT_CLOUD = 2