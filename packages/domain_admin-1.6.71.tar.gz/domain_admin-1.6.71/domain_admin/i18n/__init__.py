# -*- coding: utf-8 -*-
"""
@File    : __init__.py
@Date    : 2023-08-04
"""
from .main import translate
