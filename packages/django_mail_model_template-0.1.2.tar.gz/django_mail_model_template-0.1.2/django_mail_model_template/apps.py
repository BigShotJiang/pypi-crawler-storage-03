from django.apps import AppConfig


class DjangoMailModelTemplateConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_mail_model_template"
