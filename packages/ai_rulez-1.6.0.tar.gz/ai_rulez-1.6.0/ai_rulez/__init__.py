"""AI Rulez - CLI tool for managing AI assistant rules."""

__version__ = "1.6.0"  # This should be updated during release