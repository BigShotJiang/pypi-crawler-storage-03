# There are no parentheses, so this isn't parsed as named expression.

x :=