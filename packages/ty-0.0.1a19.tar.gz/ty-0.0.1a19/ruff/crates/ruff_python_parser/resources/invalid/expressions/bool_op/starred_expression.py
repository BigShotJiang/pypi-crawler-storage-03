x and *y
x or *y