# FIXME(micha): This creates two syntax errors instead of just one (and overlapping ones)
if True)):
    pass
