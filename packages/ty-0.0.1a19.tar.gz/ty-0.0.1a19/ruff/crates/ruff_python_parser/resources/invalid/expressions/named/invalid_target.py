# Assignment expression target can only be an identifier

(x.y := 1)
(x[y] := 1)
(*x := 1)
([x, y] := [1, 2])