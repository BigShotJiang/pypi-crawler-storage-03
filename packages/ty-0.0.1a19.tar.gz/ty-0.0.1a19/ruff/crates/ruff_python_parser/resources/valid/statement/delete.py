del x
del (x)
del a, b,
del a, (b, c), d
del [a, b]
del [a, [b, c], d]
del x.y
del x[y]
del (
    x,
    x.y,
    x[y],
)
