yield from x
yield from x + 1
yield from x and y
yield from call()
yield from [1, 2]
yield from {3, 4}
yield from {x: 5}
yield from (x, y)
yield from x == y
yield from (x := 1)
yield from (x, *x | y)