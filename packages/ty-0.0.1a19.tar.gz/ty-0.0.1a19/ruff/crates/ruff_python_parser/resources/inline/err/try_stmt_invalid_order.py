try:
    pass
finally:
    pass
else:
    pass
