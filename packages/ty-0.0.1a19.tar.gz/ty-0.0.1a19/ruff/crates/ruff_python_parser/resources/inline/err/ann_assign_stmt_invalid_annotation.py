x: *int = 1
x: yield a = 1
x: yield from b = 1
x: y := int = 1
