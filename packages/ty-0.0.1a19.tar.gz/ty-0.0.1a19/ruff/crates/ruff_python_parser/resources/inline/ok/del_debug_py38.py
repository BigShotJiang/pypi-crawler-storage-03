# parse_options: {"target-version": "3.8"}
del __debug__
