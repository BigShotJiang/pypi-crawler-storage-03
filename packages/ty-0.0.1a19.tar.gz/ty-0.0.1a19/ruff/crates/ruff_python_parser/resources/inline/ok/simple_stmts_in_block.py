if True: pass
if True: pass;
if True: pass; continue
if True: pass; continue;
x = 1
