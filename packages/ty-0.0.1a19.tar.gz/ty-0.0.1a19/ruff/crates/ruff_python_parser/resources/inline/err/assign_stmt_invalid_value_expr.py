x = (*a and b,)
x = (42, *yield x)
x = (42, *yield from x)
x = (*lambda x: x,)
x = x := 1
