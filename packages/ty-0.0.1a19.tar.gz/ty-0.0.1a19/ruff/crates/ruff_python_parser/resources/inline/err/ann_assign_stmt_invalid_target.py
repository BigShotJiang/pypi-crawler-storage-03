"abc": str = "def"
call(): str = "no"
*x: int = 1, 2
# Tuple assignment
x,: int = 1
x, y: int = 1, 2
(x, y): int = 1, 2
# List assignment
[x]: int = 1
[x, y]: int = 1, 2
