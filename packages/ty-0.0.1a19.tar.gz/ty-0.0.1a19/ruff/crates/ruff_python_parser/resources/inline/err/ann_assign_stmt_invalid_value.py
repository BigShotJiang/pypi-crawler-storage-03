x: Any = *a and b
x: Any = x := 1
x: list = [x, *a | b, *a or b]
