def __debug__(): ...  # function name
def f[__debug__](): ...  # type parameter name
def f(__debug__): ...  # parameter name
