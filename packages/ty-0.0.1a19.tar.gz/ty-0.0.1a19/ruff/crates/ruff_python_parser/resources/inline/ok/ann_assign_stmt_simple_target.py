a: int  # simple
(a): int
a.b: int
a[0]: int
