del __debug__
del x, y, __debug__, z
__debug__ = 1
x, y, __debug__, z = 1, 2, 3, 4
