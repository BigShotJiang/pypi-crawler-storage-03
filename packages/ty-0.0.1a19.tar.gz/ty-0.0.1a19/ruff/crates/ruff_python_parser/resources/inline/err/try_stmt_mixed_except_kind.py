try:
    pass
except:
    pass
except* ExceptionGroup:
    pass
try:
    pass
except* ExceptionGroup:
    pass
except:
    pass
try:
    pass
except:
    pass
except:
    pass
except* ExceptionGroup:
    pass
except* ExceptionGroup:
    pass
