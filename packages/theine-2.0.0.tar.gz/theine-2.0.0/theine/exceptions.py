class InvalidTTL(Exception):
    pass
