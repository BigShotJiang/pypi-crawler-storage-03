import pan3d.xarray.accessor  # noqa: F401
