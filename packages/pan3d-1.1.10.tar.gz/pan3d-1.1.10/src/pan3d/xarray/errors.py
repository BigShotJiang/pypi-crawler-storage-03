class DataCopyWarning(Warning):
    pass
