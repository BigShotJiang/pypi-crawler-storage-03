## This file contains the source of all the textures present in this directory

These textures come from the Visible Earth and Blue Marble NASA webpages
https://visibleearth.nasa.gov/collection/1484/blue-marble

| File       | Source | Link                                                         |
| ---------- | ------ | ------------------------------------------------------------ |
| bathymetry | NASA   | https://neo.gsfc.nasa.gov/archive/bluemarble/bmng/world_8km/ |
| oceanmask  | NASA   | https://neo.gsfc.nasa.gov/archive/bluemarble/bmng/landmask/  |
| watermask  | NASA   | https://neo.gsfc.nasa.gov/archive/bluemarble/bmng/landmask/  |
