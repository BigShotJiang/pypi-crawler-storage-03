# Contributors

pyEQL was originally written by Prof. Ryan Kingsbury (@rkingsbury) and is primarily
developed and maintained by the Kingsbury Lab at Princeton University.

Other contributors, listed alphabetically, are:

- Arpit Bhardwaj (@abhardwaj73)
- Nikhil Dhruv (@NikhilDhruv)
- Dhruv Duseja (@DhruvDuseja)
- @githubalexliu
- Hernan Grecco (@hgrecco)
- @Ouriel Ndalamba (@Ouriel-N)
- Ugo Nwosu (@ugognw)
- Yitong Pan (@YitongPan1)
- Jaebeom Park (@Jaebeom-P)
- Kirill Pushkarev (@kirill-push)
- Andrew Rosen (@arosen93)
- Sui Xiong Tay (@SuixiongTay)

(If you think that your name belongs here, please let the maintainer know)
