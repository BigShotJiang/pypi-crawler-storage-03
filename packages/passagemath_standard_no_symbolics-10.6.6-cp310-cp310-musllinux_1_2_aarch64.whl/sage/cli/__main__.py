import sys

from sage.cli import main

sys.exit(main())
