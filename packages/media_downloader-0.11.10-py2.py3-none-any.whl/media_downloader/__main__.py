#!/usr/bin/python
# coding: utf-8
from .media_downloader_mcp import main

if __name__ == "__main__":
    main()