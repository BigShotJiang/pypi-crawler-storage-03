# mirrai

[![PyPI - Version](https://img.shields.io/pypi/v/mirrai?color=00B4FF)](https://pypi.org/project/mirrai/)
[![PyPI - License](https://img.shields.io/pypi/l/mirrai?color=AB47BC)](https://github.com/ooojustin/mirrai/blob/main/LICENSE)

A Multimodal AI agent for desktop automation via screenshots and tool use.
