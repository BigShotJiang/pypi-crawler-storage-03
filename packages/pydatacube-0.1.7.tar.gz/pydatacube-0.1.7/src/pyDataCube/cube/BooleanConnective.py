from enum import Enum


class BooleanConnective(Enum):
    AND = "AND"
    OR = "OR"
    EMPTY = ""
