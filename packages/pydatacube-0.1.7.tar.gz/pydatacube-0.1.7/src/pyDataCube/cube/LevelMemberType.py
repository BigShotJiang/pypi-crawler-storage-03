from enum import Enum


class LevelMemberType(Enum):
    STR = "str"
    INT = "int"