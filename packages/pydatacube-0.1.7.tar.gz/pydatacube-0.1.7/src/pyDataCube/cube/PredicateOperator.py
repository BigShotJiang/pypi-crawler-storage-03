from enum import Enum


class PredicateOperator(Enum):
    LT = "<"
    LEQ = "<="
    EQ = "="
    GEQ = ">="
    GT = ">"
