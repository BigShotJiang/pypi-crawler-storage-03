from abc import ABC

class Engine(ABC):
    pass