from enum import Enum


class Backend(Enum):
    MONDRIAN = 1




