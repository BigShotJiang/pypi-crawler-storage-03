"""A utility module providing simplified access to time series datasets used
for benchmarking and testing."""

from .empirical1000_dataset import Empirical1000Dataset
