VERSION = "0.2.5"

# this will be templated during the build
GIT_COMMIT = "e2df632753bc6545d94b6f4c76af47a81ea3542b"
