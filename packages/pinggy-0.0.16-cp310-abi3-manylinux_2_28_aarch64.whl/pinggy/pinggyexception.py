

class PinggyNativeLoaderError(Exception):
    pass
