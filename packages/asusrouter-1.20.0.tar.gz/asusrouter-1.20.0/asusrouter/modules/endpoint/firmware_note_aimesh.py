"""Firmware release notes for AiMesh endpoint module.

This module is an alias for the firmware release notes endpoint module.
"""
