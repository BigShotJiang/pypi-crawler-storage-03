from .rregex import *

__doc__ = rregex.__doc__
if hasattr(rregex, "__all__"):
    __all__ = rregex.__all__