from django.apps import AppConfig


class FilesfoldersConfig(AppConfig):
    name = 'filesfolders'
