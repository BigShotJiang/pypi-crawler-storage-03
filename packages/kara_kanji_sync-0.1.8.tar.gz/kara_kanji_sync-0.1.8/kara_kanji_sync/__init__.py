from kara_kanji_sync.kara_kanji_sync import KanjiSyncer

__all__ = [
    "KanjiSyncer",
]
