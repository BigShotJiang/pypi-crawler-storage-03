.. aiokatcp documentation master file, created by
   sphinx-quickstart on Sun Sep 24 20:42:31 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to aiokatcp's documentation!
====================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   intro
   user
   dev/developer
   Reference manual <modules>
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
