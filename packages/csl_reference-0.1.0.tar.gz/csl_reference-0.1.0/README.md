# CSL Reference

This package is a pydantic model of the citation-style-language schema available [here](https://github.com/citation-style-language/schema/).
It uses [citeproc-py](https://github.com/citeproc-py/citeproc-py) to validate the schema
