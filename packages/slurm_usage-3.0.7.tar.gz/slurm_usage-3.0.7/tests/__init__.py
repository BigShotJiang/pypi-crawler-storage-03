"""Tests for slurm-usage package."""
