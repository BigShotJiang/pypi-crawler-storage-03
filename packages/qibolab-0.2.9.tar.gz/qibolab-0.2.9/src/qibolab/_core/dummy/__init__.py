from .platform import create_dummy

__all__ = ["create_dummy"]
