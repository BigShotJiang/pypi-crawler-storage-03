import importlib.metadata as im

__all__ = ["__version__"]

__version__ = im.version(__package__)
