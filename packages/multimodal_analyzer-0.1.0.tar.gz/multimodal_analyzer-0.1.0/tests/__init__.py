"""Test package for Media Analyzer CLI."""
