"""Media Analyzer CLI - AI-powered image analysis tool using multiple LLM providers."""

__version__ = "0.2.0"
