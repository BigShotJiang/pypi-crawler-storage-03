"""Entry point for running sortdx as a module with -m flag."""

from .cli import app

if __name__ == "__main__":
    app()
