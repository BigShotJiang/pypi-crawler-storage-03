Go to Settings \> Technical \> Database Structure \> Product Stickers.

You can add Stickers to Attributes resulting in different behaviours:
- If an Image has no Company, it will be available to all Companies.
- If an Image has Available Models, it will be restricted to selected Models.
- If an Image has no Attribute, it will be available to all Attributes.
- If an Image has no Attribute Value, it will be available to all Attribute Values of the Attribute.
- If an Image has no Category, it will be available to all Categories.

You can mix behaviours to create a very flexible sticker system.
