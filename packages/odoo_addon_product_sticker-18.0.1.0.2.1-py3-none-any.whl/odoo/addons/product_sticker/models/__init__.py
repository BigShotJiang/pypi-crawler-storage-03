from . import product_sticker
from . import product_sticker_mixin
from . import product_attribute
from . import product_attribute_value
from . import product_template
from . import product_product
