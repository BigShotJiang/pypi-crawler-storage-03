"""
Cleaner port of some utool code
"""
