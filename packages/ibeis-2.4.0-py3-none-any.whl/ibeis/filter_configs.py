default =  {
    'fail': None,
    'success': None,
    'min_gtrank': None,
    'max_gtrank': None,
    'min_gf_timedelta': None,
    'orderby': None,  # 'gt_timedelta'
    'reverse': None,  # 'gt_timedelta'
}
