classdef DefaultClass
    properties
        a;
        b = 10;
        c = 30;
    end
end
