from django.apps import AppConfig


class PayWayConfig(AppConfig):
    name = "pay_way"
