"""
Utility functions for Strands CLI
"""
