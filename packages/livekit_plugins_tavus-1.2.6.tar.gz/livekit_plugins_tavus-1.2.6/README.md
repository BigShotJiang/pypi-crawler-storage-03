# Tavus virtual avatar plugin for LiveKit Agents

Support for the [Tavus](https://tavus.io/) virtual avatar.

See [https://docs.livekit.io/agents/integrations/avatar/tavus/](https://docs.livekit.io/agents/integrations/avatar/tavus/) for more information.

