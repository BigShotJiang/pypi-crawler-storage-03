# fastkafka\di\__init__.py
