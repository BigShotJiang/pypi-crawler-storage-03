# fastkafka\message.py
from typing import Any
from pydantic import BaseModel


class KafkaMessage(BaseModel):
    topic: str
    data: Any
    headers: Any = {}
    key: str | None = None

    model_config = {"extra": "forbid", "frozen": True, "slots": True}
