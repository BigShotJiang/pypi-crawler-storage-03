# Policyengine-data tests

This directory contains tests for the policyengine-data package.

## Test structure

The test suite is organized as follows:

- **test_basic.py**: Basic functionality tests for the package
- Coming soon...

## Running tests

To run the tests, use the following command from the project root:

```bash
make test
```
