from aicard.service.server import serve
from aicard.service.assistant import Assistant, TestAssistant