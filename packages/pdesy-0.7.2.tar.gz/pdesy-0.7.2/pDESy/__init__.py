#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""__init__."""

__version__ = "0.7.2"
