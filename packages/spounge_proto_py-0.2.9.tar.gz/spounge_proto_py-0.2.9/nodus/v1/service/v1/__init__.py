# Auto-generated __init__.py
from . import service_pb2, service_pb2_grpc

__all__ = ["service_pb2", "service_pb2_grpc"]
