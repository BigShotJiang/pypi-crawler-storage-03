# Auto-generated __init__.py
from . import type

__all__ = ["type"]
