# Auto-generated __init__.py
from . import operations_pb2, operations_pb2_grpc

__all__ = ["operations_pb2", "operations_pb2_grpc"]
