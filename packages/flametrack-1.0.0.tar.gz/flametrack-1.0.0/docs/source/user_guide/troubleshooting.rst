Troubleshooting
===============

Common problems and solutions:

**Problem:** Unable to set points.
**Solution:** Make sure an image is loaded and the correct mode is active.
