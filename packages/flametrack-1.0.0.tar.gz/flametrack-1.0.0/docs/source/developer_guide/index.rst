Developer Guide
===============

This section is aimed at developers and technically interested users.

.. toctree::
   :maxdepth: 1

   architecture
   modules
   contributing
