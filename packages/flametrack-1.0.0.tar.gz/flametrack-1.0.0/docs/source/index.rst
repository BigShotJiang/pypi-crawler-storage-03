Welcome to the FlameTrack Documentation
=======================================

.. toctree::
   :maxdepth: 2
   :caption: User Guide

   user_guide/index

.. toctree::
   :maxdepth: 2
   :caption: Developer Guide

   developer_guide/index
