from .models.linear_regression import LinearRegression
from .models.multi_linear_regression import MultiLinearRegression
from .models.decision_tree import DecisionTreeRegressor