# __init__.py file required so we can install package_data
# and load .yml files from the .egg