"""
Tests for the core models module.
"""


class TestCatalogModel:
    pass
