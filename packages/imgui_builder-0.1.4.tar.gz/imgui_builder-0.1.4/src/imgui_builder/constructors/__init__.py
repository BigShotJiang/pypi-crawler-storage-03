from ._VertDivision import VertDivision
from ._HorDivision import HorDivision
from ._Table import Table