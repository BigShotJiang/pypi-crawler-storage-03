"""CLI package for JTECH™ Installer"""
