"""Validation package for JTECH™ Installer"""
