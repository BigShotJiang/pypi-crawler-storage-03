"""System detection package for JTECH™ Installer"""
