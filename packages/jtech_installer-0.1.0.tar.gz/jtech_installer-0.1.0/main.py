def main():
    print("Hello from jtech-installer!")


if __name__ == "__main__":
    main()
