from apiGuiNew import APIConsole
from abstract_gui import *
startConsole(APIConsole)

