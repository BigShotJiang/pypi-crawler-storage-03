import sthali_backend


class Config(sthali_backend.Config):
    ...
