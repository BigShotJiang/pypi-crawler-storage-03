# we should not use the logger
import logging
plantuml = logging.getLogger('plantuml')

def print_plantuml(start_page):
    
    pass
#        plantuml.info("{0} -> {1}: 'from {2}'".format(page.id.replace('-',''), next_page.id.replace('-',''), node.label) )
#             plantuml.info('{0}[label="{1}"]'.format(next_page.id.replace('-',''),next_page.label  ))

#plantuml.info("{0} -> {1}".format(node.id.replace('-',''), target_node.id.replace('-','')))
