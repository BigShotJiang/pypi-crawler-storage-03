GUI.AddSpriteSheetItem("splashxbla", "gui/textures/texturesplashlivearcade.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashlegalps3eng", "gui/textures/texturesplashlegalps3eng.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashlegalps3jap", "gui/textures/texturesplashlegalps3jap.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashlegalxboxeng", "gui/textures/texturesplashlegalxboxeng.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashlegalxboxjap", "gui/textures/texturesplashlegalxboxjap.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashlegal", "gui/textures/texturesplashlegal.bctex", {
  TextureWidth = "512",
  TextureHeight = "256",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "400",
  VPixelScale = "240"
})
GUI.AddSpriteSheetItem("splashkonami", "gui/textures/texturesplashkonami.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashengine", "gui/textures/texturesplashengine.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashantipiracyjap", "gui/textures/texturesplashantipiracyjap.bctex", {
  TextureWidth = "2048",
  TextureHeight = "1024",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "1280",
  VPixelScale = "720"
})
GUI.AddSpriteSheetItem("splashgamelogo", "gui/textures/gamelogo.bctex", {
  TextureWidth = "512",
  TextureHeight = "256",
  UPixelOffset = "0",
  VPixelOffset = "0",
  UPixelScale = "350",
  VPixelScale = "155"
})
GUI.AddSpriteSheetItem("splashgamelogoflare", "gui/textures/gamelogo.bctex", {
  TextureWidth = "512",
  TextureHeight = "256",
  UPixelOffset = "261",
  VPixelOffset = "186",
  UPixelScale = "251",
  VPixelScale = "115"
})
GUI.AddSpriteSheetItem("splashgamelogocopyright", "gui/textures/gamelogo.bctex", {
  TextureWidth = "512",
  TextureHeight = "256",
  UPixelOffset = "0",
  VPixelOffset = "245",
  UPixelScale = "90",
  VPixelScale = "11"
})