import logging

LOG = logging.getLogger("samus_returns_patcher")
