from open_samus_returns_rando import cli

cli.main()
