# ::: griffe.Attribute
