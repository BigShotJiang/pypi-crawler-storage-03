"""Tests for docstrings."""
