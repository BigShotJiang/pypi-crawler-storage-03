VERSION = "1.0.9"
# Windows executables will use this version.
VERSION_ID = "1.0.9"
