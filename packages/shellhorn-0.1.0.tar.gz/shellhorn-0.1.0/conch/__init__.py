"""
Shellhorn - A lightweight command wrapper with notification and monitoring capabilities.
"""

__version__ = "0.1.0"