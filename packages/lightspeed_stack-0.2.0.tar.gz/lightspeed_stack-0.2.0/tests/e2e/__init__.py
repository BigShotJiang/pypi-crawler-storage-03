"""End to end tests for the lightspeed-stack REST API service."""
