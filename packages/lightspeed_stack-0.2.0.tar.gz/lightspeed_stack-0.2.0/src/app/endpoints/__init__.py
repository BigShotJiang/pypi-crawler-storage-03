"""Implementation of all endpoints."""
