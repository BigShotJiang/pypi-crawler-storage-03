class NotEnoughBalance(Exception):
    pass


class NotRegisteredError(Exception):
    pass
