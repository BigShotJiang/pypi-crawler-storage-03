class RequestLimitError(Exception):
    pass
