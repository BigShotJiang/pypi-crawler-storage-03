def main():
    print("Hello from kara_kanji_sync!")


if __name__ == "__main__":
    main()
