from kara_kanji_sync.kanji_syncer import KanjiSyncer

__all__ = [
    "KanjiSyncer",
]
