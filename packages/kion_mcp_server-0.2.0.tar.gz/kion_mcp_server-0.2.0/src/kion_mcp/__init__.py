"""Kion MCP Server - Model Context Protocol server for Kion API integration."""

__version__ = "0.2.0"