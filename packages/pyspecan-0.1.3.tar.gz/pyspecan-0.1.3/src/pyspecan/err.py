class Error(Exception):
    pass

class UnknownOption(Error):
    pass

class Overflow(Error):
    pass
