import sys

if __name__ == "__main__":
    from pyspecan._internal.main import main as _main
    sys.exit(_main())
