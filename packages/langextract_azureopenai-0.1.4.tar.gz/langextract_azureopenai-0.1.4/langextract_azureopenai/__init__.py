"""LangExtract provider plugin for AzureOpenAI."""

from langextract_azureopenai.provider import AzureOpenAILanguageModel

__all__ = ['AzureOpenAILanguageModel']
__version__ = "0.1.4"
