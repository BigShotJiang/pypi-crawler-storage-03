# Changelog

All notable changes to this project will be documented in this file.

## [0.1.1] - 2025-05-18
- Initial release: core LLM chat node system, multi-provider support (OpenAI, Anthropic, Mistral, HuggingFace, URL), sync/async API, audio completions (beta), documentation, and tests.
