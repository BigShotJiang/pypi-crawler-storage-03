# Release History

## 0.1.0b5242443 (2025-08-20)

### Features Added

- Some feature

### Breaking Changes

- Some breaking change

### Bugs Fixed

- Some bug fix

### Other Changes

- Some other change

## 0.0.18b2 (2020-09-04)

### Bugs Fixed

- Testing release tag version

## 0.0.13b1 (2020-08-27)

### Bugs Fixed

- Testing out some alpha and beta versioning

## 0.0.7 (2020-07-02)

### Bugs Fixed

- Test a successful Release

## 0.0.6 (2020-05-20)

### Bugs Fixed

- Test a successful Release

## 0.0.5 (2020-05-20)

### Bugs Fixed

- Test a successful Release

## 0.0.2 (2020-03-24)

### Bugs Fixed

- Test Release Pipeline

## 0.0.1 (2019-10-06)

### Features Added

- Template package
