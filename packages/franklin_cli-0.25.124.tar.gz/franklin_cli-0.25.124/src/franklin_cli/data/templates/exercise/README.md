# Template for course repository templates

The repository template again serve as template for exercise repos.


