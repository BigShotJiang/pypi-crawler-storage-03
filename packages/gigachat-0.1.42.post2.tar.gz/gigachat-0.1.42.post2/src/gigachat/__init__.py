from gigachat.client import GigaChatAsyncClient, GigaChatSyncClient


class GigaChat(GigaChatSyncClient, GigaChatAsyncClient):
    ...
