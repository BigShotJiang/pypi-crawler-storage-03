SELECT
    *
FROM
    {schema}.metabase_table
