SELECT
    key,
    value
FROM
    {schema}.setting
WHERE
    key = 'site-url'
