# lbp-shortcuts
Shortcuts for langbot-plugin
