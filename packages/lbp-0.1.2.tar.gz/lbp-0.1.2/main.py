def main():
    print("Hello from lbp-shortcuts!")


if __name__ == "__main__":
    main()
