from langbot_plugin.cli import main

__all__ = ["main"]