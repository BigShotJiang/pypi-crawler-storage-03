PART_CONTEXT_PROMPT = """
## Context: 

Read the context carefully.
Generate a valid JSON response based on the instructions below. 
Escape quotes (") inside text values to ensure valid JSON. Only return the JSON.

"""
