# Finder Enrichment DB Contracts

This package contains the Pydantic schemas used by the Finder Enrichment DB API and its clients. 