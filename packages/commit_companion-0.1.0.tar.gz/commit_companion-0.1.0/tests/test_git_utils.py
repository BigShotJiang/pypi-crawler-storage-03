# test_git_utils.py
from git_utils import get_staged_diff

print(get_staged_diff())