"""Commit Companion: AI-assisted commit message generator."""

__version__ = "0.1.0"