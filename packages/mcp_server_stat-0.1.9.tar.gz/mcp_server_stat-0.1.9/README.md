{"mcpServers": {
"time": {
"command": "uvx",
"args": [
"mcp-server-time"
]
}
}}