# sage_setup: distribution = sagemath-benzene
# delvewheel: patch

from sage.all__sagemath_graphs import *
