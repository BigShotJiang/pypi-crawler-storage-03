﻿geqo.operations.measurement
===========================

.. automodule:: geqo.operations.measurement

   
   .. rubric:: Classes

   .. autosummary::
   
      DropQubits
      Measure
   