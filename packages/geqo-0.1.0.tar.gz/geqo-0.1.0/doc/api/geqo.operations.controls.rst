﻿geqo.operations.controls
========================

.. automodule:: geqo.operations.controls

   
   .. rubric:: Classes

   .. autosummary::
   
      ClassicalControl
      QuantumControl
   