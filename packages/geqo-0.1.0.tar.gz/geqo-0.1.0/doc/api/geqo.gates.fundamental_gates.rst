﻿geqo.gates.fundamental\_gates
=============================

.. automodule:: geqo.gates.fundamental_gates

   
   .. rubric:: Classes

   .. autosummary::
   
      CNOT
      Hadamard
      InversePhase
      InverseSGate
      PauliX
      PauliY
      PauliZ
      Phase
      SGate
      SwapQubits
   