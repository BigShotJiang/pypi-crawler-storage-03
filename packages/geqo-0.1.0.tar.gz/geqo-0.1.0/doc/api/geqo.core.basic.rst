﻿geqo.core.basic
===============

.. automodule:: geqo.core.basic

   
   .. rubric:: Classes

   .. autosummary::
   
      BasicGate
      InverseBasicGate
   