﻿geqo.gates.multi\_qubit\_gates
==============================

.. automodule:: geqo.gates.multi_qubit_gates

   
   .. rubric:: Classes

   .. autosummary::
   
      Toffoli
   