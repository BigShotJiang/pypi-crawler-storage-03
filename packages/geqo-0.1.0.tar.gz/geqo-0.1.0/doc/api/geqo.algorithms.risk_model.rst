﻿geqo.algorithms.risk\_model
===========================

.. automodule:: geqo.algorithms.risk_model

   
   .. rubric:: Functions

   .. autosummary::
   
      RiskModel
      getRY
   