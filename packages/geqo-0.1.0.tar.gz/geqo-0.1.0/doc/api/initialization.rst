initialization
==============

.. automodule:: geqo.initialization
    :members:
    :undoc-members:
    :show-inheritance:
    :imported-members:

.. autosummary::
   :toctree: .
   :recursive:

   state
