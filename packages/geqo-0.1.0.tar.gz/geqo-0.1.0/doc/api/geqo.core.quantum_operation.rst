﻿geqo.core.quantum\_operation
============================

.. automodule:: geqo.core.quantum_operation

   
   .. rubric:: Classes

   .. autosummary::
   
      QuantumOperation
   