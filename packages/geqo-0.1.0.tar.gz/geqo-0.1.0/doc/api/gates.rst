gates
=====

.. automodule:: geqo.gates
    :members:
    :undoc-members:
    :show-inheritance:
    :imported-members:

.. autosummary::
   :toctree: .
   :recursive:

   multi_qubit_gates
   rotation_gates
   fundamental_gates
