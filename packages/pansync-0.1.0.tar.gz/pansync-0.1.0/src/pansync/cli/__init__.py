#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
命令行接口模块
"""

from .main import main, cli

__all__ = ['main', 'cli']