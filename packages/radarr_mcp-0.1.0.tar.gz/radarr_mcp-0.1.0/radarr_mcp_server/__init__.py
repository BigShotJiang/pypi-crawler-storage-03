"""
Radarr MCP Server - A Model Context Protocol server for Radarr movie management.
"""

from .server import main

__all__ = ["main"]