"""
Utilities for KeepGPU project.
"""
