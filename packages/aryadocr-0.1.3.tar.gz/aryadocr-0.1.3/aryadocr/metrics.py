import editdistance

def car_metric(gt,pred):
    correct_chars = len(gt) - editdistance.eval(pred, gt)
    return correct_chars / len(gt)

def war_metric(gt_w,pred_w):
    correct_w = len(gt_w) - editdistance.eval(pred_w, gt_w)
    return correct_w / len(gt_w)