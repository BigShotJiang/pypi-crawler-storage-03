# pjdev-excel

[![PyPI - Version](https://img.shields.io/pypi/v/pjdev-excel.svg)](https://pypi.org/project/pjdev-excel)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pjdev-excel.svg)](https://pypi.org/project/pjdev-excel)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pjdev-excel
```

## License

`pjdev-excel` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
