def test_import_daylight_evapotranspiration():
    import daylight_evapotranspiration
