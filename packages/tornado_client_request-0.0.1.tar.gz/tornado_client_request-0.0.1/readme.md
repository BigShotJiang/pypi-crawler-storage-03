# tornado.httpclient extension.

## Installation

You can install via [pypi](https://pypi.org/project/tornado_client_request/)

```console
pip install -U tornado_client_request
```

## Usage

```python
from tornado_client_request import request
```
