"""
    CharFunc/CfDomainOptimizer.py

    Copyright (c) 2024, SAXS Team, KEK-PF
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

class CfDomainOptimizer:
    def __init__(self, x, y, debug=False):
        pass

    