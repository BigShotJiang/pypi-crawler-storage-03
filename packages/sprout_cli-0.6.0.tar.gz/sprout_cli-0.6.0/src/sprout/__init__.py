"""sprout - CLI tool to automate git worktree and Docker Compose development workflows."""

__version__ = "0.6.0"
