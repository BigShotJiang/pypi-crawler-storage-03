# coding=utf-8
from .._impl import (
    upload_api_UploadService as UploadService,
)

__all__ = [
    'UploadService',
]

