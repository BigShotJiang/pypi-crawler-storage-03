# py-coloris

A wrapper around the [Coloris](https://coloris.js.org/) JS package. ([Github](https://github.com/mdbassit/Coloris))

For use in Python Shiny as native color pickers are pretty awful (and <input type="color"/> was not wrapped into Shiny).