import nonebot

config = nonebot.get_driver().config

# print(config)
