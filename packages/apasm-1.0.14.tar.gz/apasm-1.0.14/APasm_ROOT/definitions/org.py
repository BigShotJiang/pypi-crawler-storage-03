org = 0x0
currentmem = org