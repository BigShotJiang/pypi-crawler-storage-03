import unittest

from test.parxel.test_iterator import IteratorTest
from test.parxel.test_lexer import LexerTest
from test.parxel.test_parser import TextParserTest

if __name__ == '__main__':
    unittest.main()
