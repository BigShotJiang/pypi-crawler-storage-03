"""Diff parser utilities."""
