"""Shell utilities for bear_utils CLI."""
