"""A set of base classes for Bear Utils extra utilities."""
