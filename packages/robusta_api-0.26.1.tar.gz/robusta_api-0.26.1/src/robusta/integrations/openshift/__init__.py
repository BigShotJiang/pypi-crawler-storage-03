from .token import IS_OPENSHIFT, TOKEN_LOCATION, load_token
