"""Encryption operations for the Orion Finance Python SDK."""

# import subprocess
# import json
# import os


def encrypt_order_intent(order_intent: dict) -> dict:
    """Encrypt an order intent."""
    # TODO: check if orion-finance npm package is installed
    # if not, give instructions to install it and fail.

    # Absolute path to the Node bundle
    # bundle_path = os.path.join(
    #     os.path.dirname(__file__),
    #     "node_helper",
    #     "encrypt_intent.cjs"
    # )

    # result = subprocess.run(
    # ["node", bundle_path],
    # capture_output=True,
    # text=True)
    # return encrypted_intent

    raise NotImplementedError("Encryption not implemented yet.")
