"""
Post-processing functions for successful LANraragi API calls.
"""