class AuthorizationException(Exception):
    pass
