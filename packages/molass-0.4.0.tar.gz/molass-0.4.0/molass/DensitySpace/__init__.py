"""
DensitySpace.__init__.py
"""

from .VoxelSpace import VoxelSpace