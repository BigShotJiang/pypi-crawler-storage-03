def run():
    import uvicorn
    uvicorn.run("comiclib.main:app")

if __name__ == "__main__":
    run()
