To use this module, you need to:

1.  Create a new sale order and provide a 'Blocking for invoicing'.
2.  When you try to create Regular Invoice if an invoicing blocking
    reason is set on the sale order. It will show blocking reasons.
