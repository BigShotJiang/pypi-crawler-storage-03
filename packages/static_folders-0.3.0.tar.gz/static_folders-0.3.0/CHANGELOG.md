# Changelog

## Version 0.3 (August 23, 2025)
- Prevent str annotation to avoid ambiguity (#10)

## Version 0.2 (June 29, 2025)
- Add FolderPartition and EnumeratedFolderPartition classes (#4, #7)
- Make Folder root class slotted (#6)

## Version 0.1 - 0.1.3
- Initial version on PyPI with concept