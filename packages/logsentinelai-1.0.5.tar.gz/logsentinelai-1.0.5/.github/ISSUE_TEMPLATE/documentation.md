---
name: Documentation Issue
about: Report a documentation problem
labels: ['documentation']
---

## What is wrong?
Describe the documentation issue.

## Suggestion
(Optional) How can it be improved?
