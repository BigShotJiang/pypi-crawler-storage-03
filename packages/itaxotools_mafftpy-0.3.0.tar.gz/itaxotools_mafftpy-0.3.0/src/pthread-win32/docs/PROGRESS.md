Please see the ANNOUNCE file "Level of Standards Conformance"
or the web page:

http://sources.redhat.com/pthreads-win32conformance.html
