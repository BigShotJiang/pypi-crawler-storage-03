
int disttbfast( int ngui, int lgui, char **namegui, char **seqgui, int argc, char **argv, int (*callback)(int, int, char*));
int tbfast( int argc, char *argv[] );
int dvtditr( int argc, char *argv[] );
int makedirectionlist(int argc, char* argv[]);
int setdirection( int argc, char *argv[] );
