#include "mltaln.h"

int main()
{
	fprintf( stdout, VERSION );
	return( 0 );
}
