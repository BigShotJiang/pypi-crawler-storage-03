# Data Set Converter
This script converts datasets from industry adapted formats like pickle, safetensors, onnx etc. to the Magnetron data format.

