# OutlierDetector

::: histoslice.utils._process.OutlierDetector
