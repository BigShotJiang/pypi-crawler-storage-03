## 4.10.0.20250822 (2025-08-22)

Add missing defaults to third-party stubs ([#14617](https://github.com/python/typeshed/pull/14617))

## 4.10.0.20250708 (2025-07-08)

[auth0-python] Bump to 4.10.* (#14261)

## 4.9.0.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs (#14063)

## 4.9.0.20250425 (2025-04-25)

[auth0-python] Add async functions to AsyncAuth0 (#13799)

Co-authored-by: pre-commit-ci[bot] <66853113+pre-commit-ci[bot]@users.noreply.github.com>
Co-authored-by: Avasam <samuel.06@hotmail.com>

## 4.9.0.20250416 (2025-04-16)

auth0-python solve stubtest_allowlist entries (#13827)

auth0-python: Cleanup re-exports leftovers from stubgen (#13828)

## 4.9.0.20250413 (2025-04-13)

Bump auth0-python to 4.9.* (#13803)

## 4.8.0.20250404 (2025-04-04)

[auth0-python] Add auth0-python stubs (#13716)

