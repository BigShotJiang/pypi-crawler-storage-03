"""
Container Settings tools registration.
"""

from .tools import register_container_settings_tools

__all__ = ["register_container_settings_tools"]
