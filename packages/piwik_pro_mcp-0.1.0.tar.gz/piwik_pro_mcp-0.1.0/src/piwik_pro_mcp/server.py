#!/usr/bin/env python3
"""
MCP Piwik PRO Analytics Server using FastMCP

An MCP server that provides tools for interacting with Piwik PRO analytics API.
Authentication is handled via client credentials from environment variables.

Usage:
    python server.py [--env-file ENV_FILE]

Options:
    --env-file: Path to .env file to load environment variables from
"""

import argparse
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from .tools import register_all_tools


def create_mcp_server() -> FastMCP:
    """Create and configure the FastMCP server with all Piwik PRO tools."""
    mcp = FastMCP("Piwik PRO Analytics Server 📊")

    # Register all tool modules
    register_all_tools(mcp)

    return mcp


server = create_mcp_server()


def load_env_file(env_file_path):
    """Load environment variables from a .env file."""
    if not env_file_path:
        return

    env_path = Path(env_file_path)
    if not env_path.exists():
        print(f"❌ Environment file not found: {env_file_path}")
        sys.exit(1)

    try:
        load_dotenv(env_path)
        print(f"✅ Loaded environment variables from: {env_file_path}")
    except ImportError:
        print("❌ python-dotenv not installed. Install with: pip install python-dotenv")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error loading environment file: {e}")
        sys.exit(1)


def validate_environment():
    """Validate that required environment variables are set."""
    required_vars = ["PIWIK_PRO_HOST", "PIWIK_PRO_CLIENT_ID", "PIWIK_PRO_CLIENT_SECRET"]

    missing_vars = []
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)

    if missing_vars:
        print("❌ Missing required environment variables:")
        for var in missing_vars:
            print(f"   - {var}")
        print("\nEither set these in your environment or use --env-file to load from a .env file")
        sys.exit(1)


def start_server():
    """Start the server in STDIO mode for MCP client connections."""
    print("🚀 Starting MCP Piwik PRO Analytics Server...")
    print("Authentication: Client credentials from environment variables")
    print("Required environment variables: PIWIK_PRO_HOST, PIWIK_PRO_CLIENT_ID, PIWIK_PRO_CLIENT_SECRET")
    print("Server ready for MCP client connections")
    print("Press Ctrl+C to stop the server")
    print()

    validate_environment()

    try:
        server.run()
    except KeyboardInterrupt:
        print("\n✨ Server stopped gracefully")
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        sys.exit(1)


def main():
    """Main entry point with argument parsing."""
    parser = argparse.ArgumentParser(
        description="MCP Piwik PRO Analytics Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python server.py                           # Start server
  python server.py --env-file .env           # Load environment variables from .env file
  python server.py --env-file /path/to/.env  # Load from specific .env file path

Required environment variables:
  PIWIK_PRO_HOST         - Your Piwik PRO instance hostname
  PIWIK_PRO_CLIENT_ID    - OAuth client ID
  PIWIK_PRO_CLIENT_SECRET - OAuth client secret

Environment file format (.env):
  PIWIK_PRO_HOST=your-instance.piwik.pro
  PIWIK_PRO_CLIENT_ID=your-client-id
  PIWIK_PRO_CLIENT_SECRET=your-client-secret
        """,
    )

    parser.add_argument(
        "--env-file",
        type=str,
        help="Path to .env file to load environment variables from",
    )

    args = parser.parse_args()

    # Load environment variables from file if specified
    if args.env_file:
        load_env_file(args.env_file)

    start_server()


if __name__ == "__main__":
    main()
