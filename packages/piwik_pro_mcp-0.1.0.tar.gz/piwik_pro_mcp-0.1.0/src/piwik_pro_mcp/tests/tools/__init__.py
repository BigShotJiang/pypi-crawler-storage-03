"""Tests for MCP tool implementations."""
