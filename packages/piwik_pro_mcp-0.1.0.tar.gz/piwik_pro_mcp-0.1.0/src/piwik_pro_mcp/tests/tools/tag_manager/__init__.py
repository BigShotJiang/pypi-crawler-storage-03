"""Tests for Tag Manager tool implementations."""
