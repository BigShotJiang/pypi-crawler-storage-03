update printing_server set active=false;
update printing_printer set active=false;
