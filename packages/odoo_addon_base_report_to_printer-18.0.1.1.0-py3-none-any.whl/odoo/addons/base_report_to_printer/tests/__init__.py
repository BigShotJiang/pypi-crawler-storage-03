# Copyright 2016 LasLabs Inc.
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import test_printing_job
from . import test_printing_printer
from . import test_printing_printer_tray
from . import test_printing_server
from . import test_printing_tray
from . import test_report
from . import test_res_users
from . import test_ir_actions_report
from . import test_printing_printer_wizard
from . import test_printing_report_xml_action
