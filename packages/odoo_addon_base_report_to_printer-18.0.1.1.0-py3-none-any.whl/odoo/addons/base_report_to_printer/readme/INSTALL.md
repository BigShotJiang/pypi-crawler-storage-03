To install this module, you need to:

1.  Install PyCups - <https://pypi.python.org/pypi/pycups>

``` bash
sudo apt-get install cups
sudo apt-get install libcups2-dev
sudo apt-get install python3-dev
sudo pip install pycups
```
