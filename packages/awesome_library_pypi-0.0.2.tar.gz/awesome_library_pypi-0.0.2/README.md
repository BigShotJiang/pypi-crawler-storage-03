# Awesome Library

This is a simple example library that returns the string "awesome!!".

## Installation

```bash
pip install awesome_library_pypi
```

## Usage

```python
from awesome_library import awesome_function

print(awesome_function())
```
