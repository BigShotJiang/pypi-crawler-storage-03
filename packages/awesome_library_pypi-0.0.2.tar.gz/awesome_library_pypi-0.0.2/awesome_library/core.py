def awesome_function():
    return "awesome!!"
