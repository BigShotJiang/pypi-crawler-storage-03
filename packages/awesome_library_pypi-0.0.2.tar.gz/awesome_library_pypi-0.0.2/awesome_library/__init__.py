from .core import awesome_function
