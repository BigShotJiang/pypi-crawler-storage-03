__all__ = [
    "HandlerWrapper"
]

from aiogram_navigation.utils.handlerwrapper import HandlerWrapper