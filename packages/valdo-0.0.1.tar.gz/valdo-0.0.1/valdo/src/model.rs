pub mod detector;
pub mod fluctuation;
pub mod residual;
