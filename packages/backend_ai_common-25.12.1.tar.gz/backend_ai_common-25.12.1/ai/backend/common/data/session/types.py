from enum import StrEnum


class CustomizedImageVisibilityScope(StrEnum):
    USER = "user"
    PROJECT = "project"
