This module adds a description field to contact tags.
