1. Create a Tag: Navigate to Contacts > Configuration > Contact Tags and click on "Create" to add a new tag.

2. Add a Description: Provide a detailed explanation of the tag's purpose and
criteria in the newly added "Description" field.
