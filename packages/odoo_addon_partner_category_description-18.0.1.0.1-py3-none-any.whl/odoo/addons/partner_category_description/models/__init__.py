from . import res_partner_category
