from . import test_partner_category_description
