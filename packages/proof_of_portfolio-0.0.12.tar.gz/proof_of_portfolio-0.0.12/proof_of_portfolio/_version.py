# This file is auto-generated during build
__version__ = "0.0.12"
