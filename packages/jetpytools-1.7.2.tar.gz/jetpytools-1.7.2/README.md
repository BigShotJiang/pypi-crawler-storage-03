# jetpytools

Collection of stuff that's useful in general python programming

## How to install

Install `jetpytools` with the following command:

```sh
pip install jetpytools
```

Or if you want the latest git version, install it with this command:

```sh
pip install git+https://github.com/Jaded-Encoding-Thaumaturgy/jetpytools.git
```
