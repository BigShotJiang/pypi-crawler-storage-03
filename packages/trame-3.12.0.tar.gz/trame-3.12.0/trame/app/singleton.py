from trame_common.obj.singleton import Singleton

__all__ = [
    "Singleton",
]
