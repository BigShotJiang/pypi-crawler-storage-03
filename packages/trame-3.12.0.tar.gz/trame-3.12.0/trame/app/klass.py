from trame_common.obj.app import TrameApp, TrameComponent

__all__ = [
    "TrameApp",
    "TrameComponent",
]
