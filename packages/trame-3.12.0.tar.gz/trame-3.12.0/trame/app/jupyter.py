"""
This module is deprecated and is currently replaced by existing API living on the trame layout.

In Jupyter you just need to do the following to display it to the output cell:

>>> await layout.ready
>>> layout
"""
