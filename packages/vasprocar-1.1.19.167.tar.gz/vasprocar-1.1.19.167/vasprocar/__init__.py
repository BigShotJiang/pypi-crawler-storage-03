# VASProcar Copyright (C) 2023
# GNU GPL-3.0 license

# https://pypi.org/project/vasprocar
# https://doi.org/10.5281/zenodo.6343960
# https://github.com/Augusto-Dlelis/VASProcar-Tools-Python


