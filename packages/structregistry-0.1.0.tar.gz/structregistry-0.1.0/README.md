## structregistry

Work in progress..
