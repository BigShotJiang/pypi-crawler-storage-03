def hello():
    print("Hello, World")


hello()
