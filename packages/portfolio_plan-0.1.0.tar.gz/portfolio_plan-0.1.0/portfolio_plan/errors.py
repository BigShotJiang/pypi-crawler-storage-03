class ValidationError(Exception):
    pass


class PeriodOverlapError(Exception):
    pass
