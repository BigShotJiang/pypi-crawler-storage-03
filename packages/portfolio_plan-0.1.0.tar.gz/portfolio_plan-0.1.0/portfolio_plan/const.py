DEFAULT_PORTFOLIO_NAME: str = "Portfolio"
