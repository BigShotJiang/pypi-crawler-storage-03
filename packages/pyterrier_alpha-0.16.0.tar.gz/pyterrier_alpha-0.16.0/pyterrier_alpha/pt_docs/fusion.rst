Result Fusion
==================================================

.. autoclass:: pyterrier_alpha.RRFusion
    :members:

.. autofunction:: pyterrier_alpha.fusion.rr_fusion
