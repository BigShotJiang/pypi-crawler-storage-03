# pyterrier-alpha

Alpha channel of features for [PyTerrier](https://github.com/terrier-org/pyterrier).

Features in ths package are under development and intend to be merged with the main package or split into a separate package when stable.

Read the [full documentation here](https://pyterrier.readthedocs.io/en/latest/ext/pyterrier-alpha/index.html).
