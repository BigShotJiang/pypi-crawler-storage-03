from . import results

Results = results.Results
