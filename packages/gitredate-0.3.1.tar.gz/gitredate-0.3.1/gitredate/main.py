import datetime
import os
import random
import sys
from pathlib import Path

import git_filter_repo as gfr
import pytz
import typer
from businesstimedelta import BusinessTimeDelta, WorkDayRule
from git import Commit, Repo
from typing_extensions import Annotated
from tzlocal import get_localzone_name

from .chart import chart
from .utils import (
    date_to_git,
    fmt,
    make_backup_branch,
    parse_datetime_str,
    parse_time_str,
    remap,
)

local_tz = pytz.timezone(get_localzone_name())
Commit.min_datetime = property(
    lambda self: min(self.authored_datetime, self.committed_datetime)
)
Commit.max_datetime = property(
    lambda self: max(self.authored_datetime, self.committed_datetime)
)


def redate(
    base_ref: Annotated[
        str,
        typer.Argument(
            help="Base ref at which redating starts. If empty, will redate the last commit only. Set `main` to redate commits absent from `main`. Set `root` the redate the whole history.",
        ),
    ] = "HEAD~1",
    tip_ref: Annotated[
        str,
        typer.Argument(
            help="Tip ref at which redating stops. If empty, will be head.",
        ),
    ] = "HEAD",
    min_date: Annotated[
        datetime.datetime | None,
        typer.Option(
            help="Custom start date and time",
            parser=parse_datetime_str,
            metavar="YYYY-MM-DD(THH:MM(:SS))",
        ),
    ] = None,
    max_date: Annotated[
        datetime.datetime | None,
        typer.Option(
            help="Custom end date and time",
            parser=parse_datetime_str,
            metavar="YYYY-MM-DD(THH:MM(:SS))",
        ),
    ] = None,
    work_days: Annotated[
        # TODO: once https://github.com/fastapi/typer/pull/800 is merged, switch to list[int] with separator ","
        str,
        typer.Option(
            help="Working days, provide this argument for each working day (monday=1)",
        ),
    ] = "1,2,3,4,5",
    work_hour_start: Annotated[
        # TODO: try to create a datetime.time type
        str,
        typer.Option(
            help="Work day starting hour",
            metavar="HH:MM(:SS)",
        ),
    ] = "8:00",
    work_hour_end: Annotated[
        str,
        typer.Option(
            help="Work day ending hour",
            metavar="HH:MM(:SS)",
        ),
    ] = "18:00",
    distrib_f: Annotated[
        float,
        typer.Option(
            help="Factor from 0 to 1 defining how commits will be mapped to the target range. 1 means commit dates will be remapped proportionally according to the input range, 0 means commit dates will be redistributed from scratch.",
        ),
    ] = 1.0,
    random_f: Annotated[
        float,
        typer.Option(
            help="Randomness added to target commit dates. A value of 1 results in fully random commit dates. A value of 0 adds no randomness at all.",
            metavar="HH:MM(:SS)",
        ),
    ] = 0.0,
    repository: Annotated[
        Path,
        typer.Option(help="Path to the git repository"),
    ] = Path("."),
    show_chart: Annotated[
        bool,
        typer.Option(help="Display the debug chart"),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option(help="Do not prompt for confirmation"),
    ] = False,
):
    # TODO: parse with Typer (add a datetime.time type and wait for https://github.com/fastapi/typer/pull/800)
    parsed_work_days = [int(d) - 1 for d in work_days.split(",")]
    parsed_work_hour_start = parse_time_str(work_hour_start)
    parsed_work_hour_end = parse_time_str(work_hour_end)

    print(f"Will work on {repository.absolute()}")
    os.chdir(repository.absolute())

    repo = Repo()
    if base_ref == "root":
        commit_range = tip_ref
    else:
        commit_range = f"{base_ref}..{tip_ref}"
    print(f"Will redate range {commit_range}")

    # List all commits
    commits = [c for c in repo.iter_commits(commit_range)]
    if not commits:
        raise RuntimeError(f"The given range (`{commit_range}`) is empty")

    old_min_date = min(c.min_datetime for c in commits)
    old_max_date = max(c.max_datetime for c in commits)
    print(f"Old range: {fmt(old_min_date)} - {fmt(old_max_date)}")
    new_min_date = min_date or old_min_date
    new_max_date = max_date or old_max_date
    print(f"New range: {fmt(new_min_date)} - {fmt(new_max_date)}")

    # Setup the rules
    work_rule = WorkDayRule(
        start_time=parsed_work_hour_start,
        end_time=parsed_work_hour_end,
        working_days=[int(d) - 1 for d in work_days.split(",")],
        tz=local_tz,
    )
    new_work_range = work_rule.difference(new_min_date, new_max_date)
    new_total_seconds = new_work_range.hours * 3600 + new_work_range.seconds

    # Compute new dates
    randoms = sorted([random.random() for _ in commits])
    redates: dict[str, tuple[datetime.datetime, datetime.datetime]] = {}
    for i, commit in enumerate(reversed(commits)):
        old_date = commit.min_datetime

        # working seconds by distributing proportionnaly
        if old_min_date == old_max_date:
            distrib_sec = 0
        else:
            distrib_sec = remap(
                old_date, old_min_date, old_max_date, 0, new_total_seconds
            )

        # working seconds by distributing evenly
        if len(commits) == 1:
            regular_sec = 0
        else:
            regular_sec = new_total_seconds * i / (len(commits) - 1)

        # working seconds by distributing randomly
        random_sec = randoms[i] * new_total_seconds

        range_sec = distrib_f * distrib_sec + (1 - distrib_f) * regular_sec
        work_sec = random_f * random_sec + (1 - random_f) * range_sec

        new_date = new_min_date + BusinessTimeDelta(work_rule, seconds=work_sec)
        redates[commit.hexsha] = (old_date, new_date)
        print(f"Redating {commit.hexsha[:7]}:    {fmt(old_date)} → {fmt(new_date)}")

    if show_chart:
        chart(
            redates,
            old_min_date,
            old_max_date,
            new_min_date,
            new_max_date,
            parsed_work_days,
            parsed_work_hour_start,
            parsed_work_hour_end,
        )

    print()
    if not (yes or input("Do you want to apply these changes ? [yN] ").lower() == "y"):
        print("Operation cancelled by user")
        sys.exit(1)

    # Make a backup branch if needed
    make_backup_branch(repo)

    # Rewrite callback
    def redate_callback(commit: gfr.Commit, metadata):
        sha = commit.original_id.decode()
        old_date, new_date = redates[sha]
        print(f"Processing {sha[:7]} ({commit.id}/{len(commits)})", end="")
        if old_date == new_date:
            print(" unchanged")
        else:
            commit.author_date = date_to_git(new_date)
            commit.committer_date = date_to_git(new_date)
            print(" OK")

    # Do the rewrite
    filter = gfr.RepoFilter(
        gfr.FilteringOptions.parse_args(["--force", "--refs", commit_range]),
        commit_callback=redate_callback,
    )
    filter.run()
