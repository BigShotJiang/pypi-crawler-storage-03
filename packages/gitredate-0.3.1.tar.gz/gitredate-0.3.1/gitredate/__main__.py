import typer

from .main import redate

typer.run(redate)
