def execute(playerData):
    print(f"Bank balance: ${playerData['bank_balance']}")
    print("Use 'deposit <amount>' to deposit money or 'withdraw <amount>' to withdraw money.")