def execute(playerData):
    print(f"Balance: ${playerData['balance']}")
    print("Use 'deposit <amount>' to deposit money into your bank or 'withdraw <amount>' to withdraw money from your bank.")