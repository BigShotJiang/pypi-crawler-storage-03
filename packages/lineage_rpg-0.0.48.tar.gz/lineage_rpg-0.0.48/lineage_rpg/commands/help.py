def execute(playerData):
    print("Available commands:")
    print("~ help - View all commands")
    print("~ bank - Check your bank balance") 
    print("~ deposit <amount> - Deposit money into your bank")
    print("~ withdraw <amount> - Withdraw money from your bank")
    print("~ exit - Exit the game")