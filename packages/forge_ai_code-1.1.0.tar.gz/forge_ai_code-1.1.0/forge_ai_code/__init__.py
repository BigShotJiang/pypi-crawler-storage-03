"""
Forge AI Code - 智能AI编程助手
"""

__version__ = "1.1.0"
__author__ = "Forge AI Team"
__email__ = "support@forgeai.dev"

from .main import main

__all__ = ["main"]
