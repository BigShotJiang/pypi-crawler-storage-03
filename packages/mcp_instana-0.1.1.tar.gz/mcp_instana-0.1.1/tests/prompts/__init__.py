# This file makes the prompts directory a Python package
