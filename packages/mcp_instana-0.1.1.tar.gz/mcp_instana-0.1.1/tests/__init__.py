"""
Unit tests for mcp-instana
"""


