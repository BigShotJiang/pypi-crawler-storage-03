# Event tests module for MCP Instana
