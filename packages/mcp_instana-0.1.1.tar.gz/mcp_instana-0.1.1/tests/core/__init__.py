# Core tests module for MCP Instana
