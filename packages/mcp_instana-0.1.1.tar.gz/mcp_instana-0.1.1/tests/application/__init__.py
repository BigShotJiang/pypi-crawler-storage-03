# Application tests module for MCP Instana
