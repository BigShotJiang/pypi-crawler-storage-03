# moskit-cli

Client to control MOSKIT Controller via simple API

## Instalacja
```bash
pip install moskit-cli