"""
QuickClient utilities for high-level operations.
"""

from .quick_client import QuickClient

__all__ = ["QuickClient"]