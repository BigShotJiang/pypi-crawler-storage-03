utility functions and classes that quickly does some common tasks based on other modules, in principle the users can do these jobs by themselves using the low level APIs, but these quick functions and classes can save time for them.

Note that:
- this module should be a `leaf` module, other modules should not depend on this module.