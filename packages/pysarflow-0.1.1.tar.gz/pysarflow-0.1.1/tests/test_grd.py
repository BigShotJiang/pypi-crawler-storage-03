"""Test function"""
