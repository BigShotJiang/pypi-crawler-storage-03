::: nzb.InvalidNzbError
