::: nzb.Nzb
::: nzb.Meta
::: nzb.File
::: nzb.Segment
