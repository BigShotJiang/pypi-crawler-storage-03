# PySMLIGHT - SLZB-06x

A python library for controlling SMLIGHT SLZB-06 network coordinators