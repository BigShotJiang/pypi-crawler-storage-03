from .base_model import JsonBaseModel

__all__ = ["JsonBaseModel"]
