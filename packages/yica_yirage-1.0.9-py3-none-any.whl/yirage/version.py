# Version information for yirage package
__version__ = "1.0.9"
__version_info__ = (1, 0, 9)
