# -*- encoding: utf-8 -*-
"""
 Created by Ênio Viana at 01/09/2021 at 19:46:28
 Project: py_dss_toolkit [set, 2021]
"""
