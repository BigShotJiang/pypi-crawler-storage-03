#!/usr/bin/env python3
"""
Entry point for flvmeta_timestamp_analyzer module
"""

from .analyzer import cli_main

if __name__ == "__main__":
    cli_main()