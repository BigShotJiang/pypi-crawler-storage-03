r"""Functional operator package."""

from .bro import bro
from .gini import gini

__all__ = classes = [
    'bro',
    'gini',
]
