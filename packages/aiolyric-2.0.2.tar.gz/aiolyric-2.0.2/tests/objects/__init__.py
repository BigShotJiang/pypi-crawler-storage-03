"""Tests for objects."""
