"""
Authentication utilities for Google Workspace MCP.
"""

from .gauth import get_credentials

__all__ = ["get_credentials"]
