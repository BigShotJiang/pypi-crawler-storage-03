# BackendStatus


## Enum

* `OFFLINE` (value: `'offline'`)

* `IDLE` (value: `'idle'`)

* `EXECUTING` (value: `'executing'`)

* `CALIBRATING` (value: `'calibrating'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


