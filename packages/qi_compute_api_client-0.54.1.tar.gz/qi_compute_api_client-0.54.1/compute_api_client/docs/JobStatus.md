# JobStatus


## Enum

* `PLANNED` (value: `'planned'`)

* `RUNNING` (value: `'running'`)

* `COMPLETED` (value: `'completed'`)

* `CANCELLED` (value: `'cancelled'`)

* `FAILED` (value: `'failed'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


