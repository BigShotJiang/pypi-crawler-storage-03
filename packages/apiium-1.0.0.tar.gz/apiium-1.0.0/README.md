# APIium Framework 🚀

> **The Generic API Testing Framework - "Appium for APIs"**

APIium is a powerful, plug-and-play API testing framework that requires zero boilerplate code. Just provide your API specifications in YAML, and APIium handles the rest!

## 🌟 Key Features

- **Zero Boilerplate**: No classes, no complex setup - just YAML configurations
- **Universal Authentication**: Basic, Bearer, OAuth2, JWT, API Keys
- **Data-Driven Testing**: Built-in data generators and parameterization
- **Parallel Execution**: Run tests concurrently for faster feedback
- **Rich Reporting**: HTML, JSON reports with detailed insights
- **CI/CD Ready**: Seamless integration with Jenkins, GitHub Actions

## 🚀 Quick Start

### Installation

```bash
pip install -e .
```

### Create Your First Test

Create a file `my_api_test.yaml`:

```yaml
version: "1.0"

metadata:
  name: "My API Tests"

config:
  base_url: "https://httpbin.org"
  timeout: 30

tests:
  - name: "Get Test"
    method: GET
    endpoint: "/get"
    validations:
      - type: "status_code"
        expected: 200
      - type: "response_time"
        max_time: 5.0

  - name: "Post Test"
    method: POST
    endpoint: "/post"
    json_data:
      test: "data"
      framework: "APIium"
    validations:
      - type: "status_code"
        expected: 200
```

### Run Your Tests

```bash
apiium run my_api_test.yaml
```

## 📖 More Examples

### Authentication Tests

```yaml
tests:
  - name: "Basic Auth Test"
    method: GET
    endpoint: "/basic-auth/user/pass"
    auth:
      type: "basic"
      username: "user"
      password: "pass"
    validations:
      - type: "status_code"
        expected: 200

  - name: "Bearer Token Test"
    method: GET
    endpoint: "/bearer"
    auth:
      type: "bearer"
      token: "your-token-here"
    validations:
      - type: "status_code"
        expected: 200
```

## 🛠️ Commands

```bash
# Run tests
apiium run tests/

# Initialize new test file
apiium init my_test.yaml --base-url https://api.example.com

# Run with custom output
apiium run tests/ --output custom-reports/
```

## 🤝 Contributing

Contributions welcome! This framework is designed to revolutionize API testing.

## 📄 License

MIT License - see LICENSE file for details.

---

**Made with ❤️ for the API testing community**
