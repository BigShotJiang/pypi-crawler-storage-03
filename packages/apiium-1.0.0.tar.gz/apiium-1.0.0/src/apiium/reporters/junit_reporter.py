"""
APIium JUnit Reporter - Generates JUnit XML test reports
"""
import os
from datetime import datetime
from typing import List, Dict, Any
import xml.etree.ElementTree as ET


class JUnitReporter:
    def generate_report(self, results: List[Dict[str, Any]], output_file: str):
        """
        Generates a JUnit XML report file.

        Args:
            results (List[Dict[str, Any]]): List of test suite results.
            output_file (str): File path to save the XML report.
        """
        testsuites = ET.Element('testsuites')

        total_tests = 0
        total_failures = 0
        total_time = 0.0

        for suite in results:
            suite_name = suite.get('suite_name', 'Test Suite')
            tests = suite.get('total_tests', 0)
            failures = suite.get('failed_tests', 0)
            time_taken = suite.get('total_duration', 0.0)

            total_tests += tests
            total_failures += failures
            total_time += time_taken

            testsuite_attrib = {
                'name': suite_name,
                'tests': str(tests),
                'failures': str(failures),
                'errors': '0',
                'time': f'{time_taken:.3f}',
                'timestamp': datetime.now().isoformat(),
                'hostname': os.uname().nodename if hasattr(os, 'uname') else 'localhost'
            }
            testsuite_elem = ET.SubElement(testsuites, 'testsuite', testsuite_attrib)

            for test in suite.get('results', []):
                testcase_attrib = {
                    'classname': suite_name,
                    'name': test.get('name', 'Test Case'),
                    'time': f"{test.get('duration', 0.0):.3f}"
                }
                testcase_elem = ET.SubElement(testsuite_elem, 'testcase', testcase_attrib)

                if not test.get('passed', False):
                    failure_elem = ET.SubElement(testcase_elem, 'failure', {
                        'message': test.get('error', 'Test failed'),
                        'type': 'failure'
                    })
                    failure_elem.text = test.get('error', 'Test failed')

        tree = ET.ElementTree(testsuites)
        ET.indent(tree, space="  ", level=0)  # For Python 3.9+
        tree.write(output_file, encoding='utf-8', xml_declaration=True)


# Example usage:
# reporter = JUnitReporter()
# reporter.generate_report(results, "reports/junit_report.xml")
