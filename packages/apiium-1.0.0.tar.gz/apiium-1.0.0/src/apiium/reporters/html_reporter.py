"""
APIium HTML Reporter - Generate HTML test reports
"""
import json
from datetime import datetime
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class HTMLReporter:
    """Generates HTML test reports"""
    
    def generate_report(self, results: List[Dict[str, Any]], output_file: str):
        """Generate HTML report from test results"""
        summary = self._generate_summary(results)
        
        html_content = f'''<!DOCTYPE html>
<html>
<head>
    <title>APIium Test Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }}
        .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }}
        .summary-card {{ background: #f8f9fa; padding: 15px; border-radius: 6px; text-align: center; border-left: 4px solid #667eea; }}
        .passed {{ color: #28a745; font-weight: bold; }}
        .failed {{ color: #dc3545; font-weight: bold; }}
        .test-suite {{ margin-bottom: 20px; border: 1px solid #ddd; border-radius: 6px; }}
        .suite-header {{ background: #f8f9fa; padding: 15px; border-bottom: 1px solid #ddd; font-weight: bold; }}
        .test-item {{ padding: 10px; border-bottom: 1px solid #eee; }}
        .test-item:last-child {{ border-bottom: none; }}
        .test-name {{ font-weight: 500; }}
        .test-status {{ float: right; padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
        .status-passed {{ background: #d4edda; color: #155724; }}
        .status-failed {{ background: #f8d7da; color: #721c24; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 APIium Test Report</h1>
            <p>Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>
        
        <div class="summary">
            <div class="summary-card">
                <h3>Total Tests</h3>
                <div style="font-size: 2em; font-weight: bold;">{summary['total_tests']}</div>
            </div>
            <div class="summary-card">
                <h3>Passed</h3>
                <div class="passed" style="font-size: 2em;">{summary['total_passed']}</div>
            </div>
            <div class="summary-card">
                <h3>Failed</h3>
                <div class="failed" style="font-size: 2em;">{summary['total_failed']}</div>
            </div>
            <div class="summary-card">
                <h3>Success Rate</h3>
                <div style="font-size: 2em; font-weight: bold; color: #17a2b8;">{summary['success_rate']:.1f}%</div>
            </div>
        </div>
        
        <div class="test-suites">
            {self._generate_test_suites_html(results)}
        </div>
    </div>
</body>
</html>'''
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"HTML report generated: {output_file}")
    
    def _generate_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics"""
        total_tests = sum(r.get('total_tests', 0) for r in results)
        total_passed = sum(r.get('passed_tests', 0) for r in results)
        total_failed = sum(r.get('failed_tests', 0) for r in results)
        success_rate = (total_passed / total_tests * 100) if total_tests > 0 else 0
        
        return {
            'total_tests': total_tests,
            'total_passed': total_passed,
            'total_failed': total_failed,
            'success_rate': success_rate
        }
    
    def _generate_test_suites_html(self, results: List[Dict[str, Any]]) -> str:
        """Generate HTML for test suites"""
        html_parts = []
        
        for suite_result in results:
            suite_name = suite_result.get('suite_name', 'Unknown Suite')
            suite_passed = suite_result.get('failed_tests', 0) == 0
            
            html_parts.append(f'''
            <div class="test-suite">
                <div class="suite-header">
                    {suite_name}
                    <span class="test-status {'status-passed' if suite_passed else 'status-failed'}">
                        {'PASSED' if suite_passed else 'FAILED'}
                    </span>
                </div>
                {self._generate_tests_html(suite_result.get('results', []))}
            </div>
            ''')
        
        return ''.join(html_parts)
    
    def _generate_tests_html(self, test_results: List[Dict[str, Any]]) -> str:
        """Generate HTML for individual tests"""
        html_parts = []
        
        for test_result in test_results:
            test_name = test_result.get('name', 'Unknown Test')
            test_passed = test_result.get('passed', False)
            duration = test_result.get('duration', 0)
            
            html_parts.append(f'''
            <div class="test-item">
                <div class="test-name">{test_name}</div>
                <span class="test-status {'status-passed' if test_passed else 'status-failed'}">
                    {'PASSED' if test_passed else 'FAILED'}
                </span>
                <small style="color: #666; margin-left: 10px;">({duration:.3f}s)</small>
            </div>
            ''')
        
        return ''.join(html_parts)