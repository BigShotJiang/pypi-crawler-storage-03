"""
APIium JSON Reporter - Generate JSON test reports
"""
import json
from datetime import datetime
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class JSONReporter:
    """Generates JSON test reports"""
    
    def generate_report(self, results: List[Dict[str, Any]], output_file: str):
        """Generate JSON report from test results"""
        report_data = {
            'apiium_version': '1.0.0',
            'generated_at': datetime.now().isoformat(),
            'summary': self._generate_summary(results),
            'test_suites': results
        }
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
            
        logger.info(f"JSON report generated: {output_file}")
    
    def _generate_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics"""
        total_tests = sum(r.get('total_tests', 0) for r in results)
        total_passed = sum(r.get('passed_tests', 0) for r in results)
        total_failed = sum(r.get('failed_tests', 0) for r in results)
        success_rate = (total_passed / total_tests * 100) if total_tests > 0 else 0
        
        return {
            'total_tests': total_tests,
            'total_passed': total_passed,
            'total_failed': total_failed,
            'success_rate': round(success_rate, 2)
        }