"""
APIium Request Builder
"""
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)

class RequestBuilder:
    """Builds HTTP requests from configuration"""
    
    def __init__(self):
        pass
        
    def build_request_data(self, test_config: Dict[str, Any]) -> Dict[str, Any]:
        """Build complete request data from test configuration"""
        return {
            'method': test_config.get('method', 'GET').upper(),
            'endpoint': test_config.get('endpoint', '/'),
            'headers': test_config.get('headers', {}),
            'params': test_config.get('params', {}),
            'json_data': test_config.get('json_data'),
            'auth': test_config.get('auth'),
            'timeout': test_config.get('timeout'),
        }