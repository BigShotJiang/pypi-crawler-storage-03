"""
APIium Response Validator
"""
import re
import json
from typing import Dict, Any, Optional, Union, List
from .exceptions import ValidationError
import logging

logger = logging.getLogger(__name__)

class Validator:
    """
    Validates API responses against expected criteria
    """
    
    def __init__(self):
        self.custom_validators = {}
        
    def validate(self, response, validations: List[Dict[str, Any]], context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Validate response against multiple validation rules
        """
        context = context or {}
        results = {
            'passed': True,
            'total_validations': len(validations),
            'passed_validations': 0,
            'failed_validations': 0,
            'validations': []
        }
        
        for validation in validations:
            try:
                result = self._execute_single_validation(response, validation, context)
                results['validations'].append(result)
                
                if result['passed']:
                    results['passed_validations'] += 1
                else:
                    results['failed_validations'] += 1
                    results['passed'] = False
                    
            except Exception as e:
                logger.error(f"Validation error: {str(e)}")
                results['validations'].append({
                    'type': validation.get('type', 'unknown'),
                    'description': validation.get('description', 'Validation failed'),
                    'passed': False,
                    'error': str(e)
                })
                results['failed_validations'] += 1
                results['passed'] = False
                
        return results
        
    def _execute_single_validation(self, response, validation: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a single validation rule
        """
        validation_type = validation.get('type', 'equals')
        
        if validation_type == 'status_code':
            return self._validate_status_code(response, validation)
        elif validation_type == 'json_path':
            return self._validate_json_path(response, validation)
        elif validation_type == 'response_time':
            return self._validate_response_time(response, validation)
        else:
            raise ValidationError(f"Unknown validation type: {validation_type}")
            
    def _validate_status_code(self, response, validation: Dict[str, Any]) -> Dict[str, Any]:
        """Validate HTTP status code"""
        expected = validation.get('expected')
        actual = response.status_code
        passed = actual == expected
            
        return {
            'type': 'status_code',
            'description': validation.get('description', 'Status code validation'),
            'expected': expected,
            'actual': actual,
            'passed': passed
        }
        
    def _validate_json_path(self, response, validation: Dict[str, Any]) -> Dict[str, Any]:
        """Validate JSON path value"""
        path = validation.get('path')
        expected = validation.get('expected')
        
        try:
            data = response.json()
            actual = self._extract_json_path(data, path)
            passed = actual == expected
        except Exception as e:
            actual = f"Error: {str(e)}"
            passed = False
            
        return {
            'type': 'json_path',
            'description': validation.get('description', f'JSON path {path} validation'),
            'expected': expected,
            'actual': actual,
            'passed': passed,
            'path': path
        }
        
    def _validate_response_time(self, response, validation: Dict[str, Any]) -> Dict[str, Any]:
        """Validate response time"""
        max_time = validation.get('max_time')
        actual = getattr(response, 'response_time', 0)
        passed = actual <= max_time if max_time is not None else True
        
        return {
            'type': 'response_time',
            'description': validation.get('description', 'Response time validation'),
            'expected': f"<= {max_time}s",
            'actual': f"{actual:.3f}s",
            'passed': passed
        }
        
    def _extract_json_path(self, data, path):
        """Extract value from JSON using simple dot notation"""
        if not path:
            return data
            
        parts = path.split('.')
        current = data
        
        for part in parts:
            if part.startswith('[') and part.endswith(']'):
                # Array index
                index = int(part[1:-1])
                current = current[index]
            else:
                # Object key
                current = current[part]
                
        return current