"""
APIium Core Client - The main HTTP client for API testing
"""
import requests
import json
import time
from typing import Dict, Any, Optional, Union, List
from urllib.parse import urljoin, urlparse
from .exceptions import APIiumError, AuthenticationError, ValidationError
from .auth import AuthManager
from .config import Config
from .response_handler import ResponseHandler
from .request_builder import RequestBuilder
import logging

logger = logging.getLogger(__name__)

class APIClient:
    """
    Main API client class that handles HTTP requests and responses
    """
    
    def __init__(self, base_url: str = None, config: Config = None):
        self.base_url = base_url.rstrip('/') if base_url else None
        self.config = config or Config()
        self.session = requests.Session()
        self.auth_manager = AuthManager(self)
        self.response_handler = ResponseHandler()
        self.request_builder = RequestBuilder()
        
        # Set default headers
        self.session.headers.update({
            'User-Agent': f'APIium/{self.config.version}',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        
        # Setup timeout
        self.session.timeout = self.config.timeout
        
        # Request/response history for debugging
        self.history = []
        
    def request(self, 
                method: str, 
                endpoint: str, 
                headers: Dict = None, 
                params: Dict = None, 
                data: Any = None, 
                json_data: Dict = None,
                auth: Any = None,
                timeout: int = None,
                **kwargs) -> requests.Response:
        """
        Make an HTTP request with comprehensive logging and error handling
        """
        start_time = time.time()
        
        # Build the full URL
        if self.base_url:
            url = urljoin(self.base_url + '/', endpoint.lstrip('/'))
        else:
            url = endpoint
            
        # Prepare request data
        request_data = {
            'method': method.upper(),
            'url': url,
            'headers': headers or {},
            'params': params or {},
            'timeout': timeout or self.config.timeout
        }
        
        # Handle authentication
        if auth:
            auth_headers = self.auth_manager.apply_auth(auth, request_data)
            request_data['headers'].update(auth_headers)
            
        # Handle request body
        if json_data is not None:
            request_data['json'] = json_data
        elif data is not None:
            request_data['data'] = data
            
        # Update session headers
        if headers:
            request_data['headers'].update(headers)
            
        try:
            logger.info(f"Making {method.upper()} request to {url}")
            
            # Make the actual request
            response = self.session.request(**request_data, **kwargs)
            
            # Calculate response time
            response_time = time.time() - start_time
            
            # Store in history
            self.history.append({
                'request': request_data,
                'response': {
                    'status_code': response.status_code,
                    'headers': dict(response.headers),
                    'content': response.text[:1000] if len(response.text) > 1000 else response.text,
                    'response_time': response_time
                },
                'timestamp': time.time()
            })
            
            # Add response time to response object
            response.response_time = response_time
            
            logger.info(f"Response: {response.status_code} in {response_time:.3f}s")
            
            return response
            
        except requests.exceptions.Timeout:
            raise APIiumError(f"Request timeout after {timeout or self.config.timeout}s")
        except requests.exceptions.ConnectionError as e:
            raise APIiumError(f"Connection error: {str(e)}")
        except requests.exceptions.RequestException as e:
            raise APIiumError(f"Request error: {str(e)}")
            
    def get(self, endpoint: str, **kwargs) -> requests.Response:
        """Make a GET request"""
        return self.request('GET', endpoint, **kwargs)
        
    def post(self, endpoint: str, **kwargs) -> requests.Response:
        """Make a POST request"""
        return self.request('POST', endpoint, **kwargs)
        
    def put(self, endpoint: str, **kwargs) -> requests.Response:
        """Make a PUT request"""
        return self.request('PUT', endpoint, **kwargs)
        
    def delete(self, endpoint: str, **kwargs) -> requests.Response:
        """Make a DELETE request"""
        return self.request('DELETE', endpoint, **kwargs)
        
    def set_base_url(self, base_url: str):
        """Set the base URL for all requests"""
        self.base_url = base_url.rstrip('/') if base_url else None
        
    def set_auth(self, auth_type: str, **auth_params):
        """Set authentication for all requests"""
        return self.auth_manager.set_auth(auth_type, **auth_params)
    
    def add_header(self, key: str, value: str):
        """Add a default header for all requests"""
        self.session.headers[key] = value
