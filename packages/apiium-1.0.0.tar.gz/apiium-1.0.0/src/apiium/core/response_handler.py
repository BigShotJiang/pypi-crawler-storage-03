"""
APIium Response Handler
"""
import json
from typing import Any
from .exceptions import ResponseError
import logging

logger = logging.getLogger(__name__)

class ResponseHandler:
    """Handles response parsing and validation"""
    
    def __init__(self):
        pass
        
    def parse_response(self, response, parser_type: str = 'auto') -> Any:
        """Parse response content"""
        if parser_type == 'auto':
            content_type = response.headers.get('content-type', '').lower()
            if 'application/json' in content_type:
                parser_type = 'json'
            else:
                parser_type = 'text'
                
        if parser_type == 'json':
            try:
                return response.json()
            except json.JSONDecodeError as e:
                raise ResponseError(f"Invalid JSON response: {str(e)}", response)
        else:
            return response.text