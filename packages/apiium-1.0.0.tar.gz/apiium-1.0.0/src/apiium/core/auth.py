"""
APIium Authentication Manager
"""
import base64
import time
from typing import Dict, Any, Optional
from .exceptions import AuthenticationError
import logging

logger = logging.getLogger(__name__)

class AuthManager:
    """
    Handles various authentication mechanisms
    """
    
    def __init__(self, client):
        self.client = client
        self.auth_cache = {}
        
    def apply_auth(self, auth_config: Dict[str, Any], request_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Apply authentication to request and return additional headers
        """
        auth_type = auth_config.get('type', '').lower()
        
        if auth_type == 'basic':
            return self._apply_basic_auth(auth_config)
        elif auth_type == 'bearer':
            return self._apply_bearer_auth(auth_config)
        elif auth_type == 'api_key':
            return self._apply_api_key_auth(auth_config)
        else:
            logger.warning(f"Unknown authentication type: {auth_type}")
            return {}
            
    def _apply_basic_auth(self, auth_config: Dict[str, Any]) -> Dict[str, str]:
        """Apply HTTP Basic Authentication"""
        username = auth_config.get('username')
        password = auth_config.get('password')
        
        if not username or not password:
            raise AuthenticationError("Username and password required for basic auth")
            
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        
        return {'Authorization': f'Basic {encoded_credentials}'}
        
    def _apply_bearer_auth(self, auth_config: Dict[str, Any]) -> Dict[str, str]:
        """Apply Bearer Token Authentication"""
        token = auth_config.get('token')
        
        if not token:
            raise AuthenticationError("Token required for bearer auth")
            
        return {'Authorization': f'Bearer {token}'}
        
    def _apply_api_key_auth(self, auth_config: Dict[str, Any]) -> Dict[str, str]:
        """Apply API Key Authentication"""
        api_key = auth_config.get('api_key')
        key_name = auth_config.get('key_name', 'X-API-Key')
        
        if not api_key:
            raise AuthenticationError("API key required for API key auth")
            
        return {key_name: api_key}