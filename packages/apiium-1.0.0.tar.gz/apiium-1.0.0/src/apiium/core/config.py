"""
APIium Configuration Management
"""
import os
import json
import yaml
from typing import Dict, Any, Optional
from pathlib import Path

class Config:
    """
    Configuration management for APIium framework
    """
    
    def __init__(self, config_file: str = None):
        # Default configuration
        self.version = "1.0.0"
        self.timeout = 30
        self.retry_count = 3
        self.retry_delay = 1.0
        self.parallel_workers = 4
        self.log_level = "INFO"
        self.report_format = "html"
        self.output_dir = "reports"
        self.verify_ssl = True
        self.follow_redirects = True
        
        # Environment-specific settings
        self.environments = {}
        self.current_env = "default"
        
        # Load from file if provided
        if config_file:
            self.load_from_file(config_file)
            
        # Override with environment variables
        self.load_from_env()
        
    def load_from_file(self, config_file: str):
        """Load configuration from YAML or JSON file"""
        config_path = Path(config_file)
        
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_file}")
            
        try:
            with open(config_path, 'r') as f:
                if config_path.suffix.lower() in ['.yml', '.yaml']:
                    config_data = yaml.safe_load(f)
                else:
                    config_data = json.load(f)
                    
            self._merge_config(config_data)
            
        except Exception as e:
            raise ValueError(f"Failed to load configuration file: {str(e)}")
            
    def load_from_env(self):
        """Load configuration from environment variables"""
        env_mappings = {
            'APIIUM_TIMEOUT': ('timeout', int),
            'APIIUM_RETRY_COUNT': ('retry_count', int),
            'APIIUM_PARALLEL_WORKERS': ('parallel_workers', int),
            'APIIUM_LOG_LEVEL': ('log_level', str),
            'APIIUM_OUTPUT_DIR': ('output_dir', str),
        }
        
        for env_var, (attr_name, converter) in env_mappings.items():
            value = os.getenv(env_var)
            if value is not None:
                try:
                    setattr(self, attr_name, converter(value))
                except (ValueError, TypeError):
                    print(f"Warning: Invalid value for {env_var}: {value}")
                    
    def _merge_config(self, config_data: Dict[str, Any]):
        """Merge configuration data into current config"""
        for key, value in config_data.items():
            if hasattr(self, key):
                if isinstance(getattr(self, key), dict) and isinstance(value, dict):
                    getattr(self, key).update(value)
                else:
                    setattr(self, key, value)