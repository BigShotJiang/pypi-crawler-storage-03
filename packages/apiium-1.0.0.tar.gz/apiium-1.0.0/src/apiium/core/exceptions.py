"""
APIium Custom Exceptions
"""

class APIiumError(Exception):
    """Base exception for APIium framework"""
    pass

class AuthenticationError(APIiumError):
    """Raised when authentication fails"""
    pass

class ValidationError(APIiumError):
    """Raised when validation fails"""
    
    def __init__(self, message: str, expected=None, actual=None):
        super().__init__(message)
        self.expected = expected
        self.actual = actual
        
class ConfigurationError(APIiumError):
    """Raised when configuration is invalid"""
    pass

class ParseError(APIiumError):
    """Raised when parsing fails"""
    pass

class TestExecutionError(APIiumError):
    """Raised when test execution fails"""
    pass

class ResponseError(APIiumError):
    """Raised when response parsing or handling fails"""
    def __init__(self, message: str, response=None):
        super().__init__(message)
        self.response = response
