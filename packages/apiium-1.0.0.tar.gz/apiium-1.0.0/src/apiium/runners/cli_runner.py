"""
APIium CLI Runner - Command line interface
"""
import click
import sys
from pathlib import Path
from ..core.config import Config
from ..runners.test_runner import TestRunner
from ..reporters.html_reporter import HTMLReporter
from ..reporters.json_reporter import JSONReporter
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

@click.group()
@click.version_option(version='1.0.0', prog_name='APIium')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose logging')
@click.pass_context
def cli(ctx, verbose):
    """
    APIium - Generic API Testing Framework
    
    The plug-and-play API testing framework that requires no boilerplate code.
    """
    ctx.ensure_object(dict)
    
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        
    ctx.obj['config'] = Config()

@cli.command()
@click.argument('test_files', nargs=-1, required=True, type=click.Path(exists=True))
@click.option('--environment', '-e', help='Environment to run tests against')
@click.option('--output', '-o', help='Output directory for reports', default='reports')
@click.option('--format', '-f', 'report_format', 
              type=click.Choice(['html', 'json', 'all']), 
              default='html', help='Report format')
@click.pass_context
def run(ctx, test_files, environment, output, report_format):
    """
    Run API tests from YAML specification files
    """
    config = ctx.obj['config']
    
    # Setup output directory
    output_dir = Path(output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize runner
    runner = TestRunner(config)
    
    # Collect test files
    all_test_files = []
    for test_path in test_files:
        path = Path(test_path)
        if path.is_file():
            all_test_files.append(path)
        elif path.is_dir():
            all_test_files.extend(path.glob('**/*.yaml'))
            all_test_files.extend(path.glob('**/*.yml'))
            
    if not all_test_files:
        click.echo("No test files found!", err=True)
        sys.exit(1)
        
    click.echo(f"Found {len(all_test_files)} test file(s)")
    
    # Run tests
    all_results = []
    total_passed = 0
    total_failed = 0
    
    for test_file in all_test_files:
        click.echo(f"\\nRunning tests from: {test_file}")
        
        try:
            results = runner.run_file(str(test_file), environment=environment)
            all_results.append(results)
            
            total_passed += results['passed_tests']
            total_failed += results['failed_tests']
            
            click.echo(f"  Passed: {results['passed_tests']}")
            click.echo(f"  Failed: {results['failed_tests']}")
            click.echo(f"  Duration: {results['total_duration']:.2f}s")
            
        except Exception as e:
            click.echo(f"Error running {test_file}: {str(e)}", err=True)
            total_failed += 1
            continue
            
    # Generate reports
    _generate_reports(all_results, output_dir, report_format)
    
    # Final summary
    click.echo(f"\\n{'='*50}")
    click.echo(f"FINAL RESULTS")
    click.echo(f"{'='*50}")
    click.echo(f"Total Passed: {total_passed}")
    click.echo(f"Total Failed: {total_failed}")
    
    if total_failed > 0:
        sys.exit(1)

@cli.command()
@click.argument('spec_file', type=click.Path())
@click.option('--base-url', required=True, help='Base URL for the API')
def init(spec_file, base_url):
    """Initialize a new test specification file"""
    spec_content = f'''version: "1.0"

metadata:
  name: "API Test Suite"
  description: "Generated test suite"

config:
  base_url: "{base_url}"
  timeout: 30
  headers:
    Content-Type: "application/json"

tests:
  - name: "Sample Test"
    method: GET
    endpoint: "/health"
    validations:
      - type: "status_code"
        expected: 200
'''
    
    with open(spec_file, 'w') as f:
        f.write(spec_content)
        
    click.echo(f"Created test specification: {spec_file}")

def _generate_reports(results, output_dir, report_format):
    """Generate test reports"""
    if report_format in ['html', 'all']:
        html_reporter = HTMLReporter()
        html_file = output_dir / 'report.html'
        html_reporter.generate_report(results, str(html_file))
        click.echo(f"HTML report: {html_file}")
        
    if report_format in ['json', 'all']:
        json_reporter = JSONReporter()
        json_file = output_dir / 'report.json'
        json_reporter.generate_report(results, str(json_file))
        click.echo(f"JSON report: {json_file}")

if __name__ == '__main__':
    cli()