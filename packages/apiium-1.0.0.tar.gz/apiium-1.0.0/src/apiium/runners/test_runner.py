"""
APIium Test Runner - Core test execution engine
"""
import time
import logging
from typing import Dict, Any, List
from ..core.client import APIClient
from ..core.config import Config
from ..core.validator import Validator
from ..parsers.yaml_parser import YAMLParser
from ..core.exceptions import TestExecutionError

logger = logging.getLogger(__name__)

class TestResult:
    """Represents the result of a single test execution"""
    
    def __init__(self, test_config: Dict[str, Any]):
        self.test_config = test_config
        self.name = test_config.get('name', 'Unnamed Test')
        self.passed = False
        self.start_time = None
        self.end_time = None
        self.duration = 0
        self.response = None
        self.validations = []
        self.error = None
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary"""
        return {
            'name': self.name,
            'passed': self.passed,
            'duration': self.duration,
            'response': {
                'status_code': self.response.status_code if self.response else None,
                'headers': dict(self.response.headers) if self.response else {},
                'body': self.response.text if self.response else None,
                'response_time': getattr(self.response, 'response_time', 0) if self.response else 0
            } if self.response else None,
            'validations': self.validations,
            'error': self.error
        }

class TestRunner:
    """Main test execution engine"""
    
    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.client = APIClient(config=self.config)
        self.validator = Validator()
        self.parser = YAMLParser()
        
    def run_file(self, file_path: str, environment: str = None, **kwargs) -> Dict[str, Any]:
        """Run tests from a YAML file"""
        try:
            spec = self.parser.parse_file(file_path)
            return self.run_suite(spec, environment=environment, **kwargs)
        except Exception as e:
            logger.error(f"Failed to run test file {file_path}: {str(e)}")
            raise TestExecutionError(f"Failed to run test file: {str(e)}")
            
    def run_suite(self, spec: Dict[str, Any], environment: str = None, **kwargs) -> Dict[str, Any]:
        """Run a complete test suite"""
        suite_name = spec.get('metadata', {}).get('name', 'Test Suite')
        tests = spec.get('tests', [])
        config = spec.get('config', {})
        
        # Setup base URL
        if config.get('base_url'):
            self.client.set_base_url(config['base_url'])
            
        # Setup global headers
        if config.get('headers'):
            for key, value in config['headers'].items():
                self.client.add_header(key, value)
                
        logger.info(f"Running test suite '{suite_name}' with {len(tests)} tests")
        
        suite_start_time = time.time()
        results = []
        
        for test_config in tests:
            result = self._run_single_test(test_config)
            results.append(result)
            
        suite_end_time = time.time()
        
        # Generate summary
        total_tests = len(results)
        passed_tests = sum(1 for r in results if r.passed)
        failed_tests = total_tests - passed_tests
        
        return {
            'suite_name': suite_name,
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': failed_tests,
            'total_duration': suite_end_time - suite_start_time,
            'results': [result.to_dict() for result in results]
        }
        
    def _run_single_test(self, test_config: Dict[str, Any]) -> TestResult:
        """Execute a single test"""
        result = TestResult(test_config)
        result.start_time = time.time()
        
        try:
            logger.info(f"Running test: {result.name}")
            
            # Make the API request
            method = test_config.get('method', 'GET')
            endpoint = test_config['endpoint']
            headers = test_config.get('headers')
            params = test_config.get('params')
            json_data = test_config.get('json_data')
            auth = test_config.get('auth')
            timeout = test_config.get('timeout')
            
            response = self.client.request(
                method=method,
                endpoint=endpoint,
                headers=headers,
                params=params,
                json_data=json_data,
                auth=auth,
                timeout=timeout
            )
            
            result.response = response
            
            # Validate response
            validations = test_config.get('validations', [])
            if validations:
                validation_results = self.validator.validate(response, validations)
                result.validations = validation_results['validations']
                result.passed = validation_results['passed']
            else:
                result.passed = response.status_code < 400
                
            logger.info(f"Test '{result.name}' {'PASSED' if result.passed else 'FAILED'}")
            
        except Exception as e:
            result.error = str(e)
            result.passed = False
            logger.error(f"Test '{result.name}' failed: {str(e)}")
            
        finally:
            result.end_time = time.time()
            result.duration = result.end_time - result.start_time
            
        return result