"""
APIium YAML Parser - Configuration-driven test specification parser
"""
import yaml
import json
from typing import Dict, Any, List, Optional
from pathlib import Path
from ..core.exceptions import ParseError
import logging

logger = logging.getLogger(__name__)

class YAMLParser:
    """
    Parses YAML test specifications into executable test configurations
    """
    
    def __init__(self):
        self.supported_versions = ['1.0']
        
    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """Parse a YAML test specification file"""
        try:
            path = Path(file_path)
            if not path.exists():
                raise FileNotFoundError(f"Test file not found: {file_path}")
                
            with open(path, 'r', encoding='utf-8') as f:
                content = yaml.safe_load(f)
                
            if not content:
                raise ParseError(f"Empty or invalid YAML file: {file_path}")
                
            return self._process_spec(content, str(path))
            
        except yaml.YAMLError as e:
            raise ParseError(f"YAML parsing error in {file_path}: {str(e)}")
        except Exception as e:
            raise ParseError(f"Error parsing {file_path}: {str(e)}")
            
    def _process_spec(self, content: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Process and validate the parsed YAML specification"""
        if not isinstance(content, dict):
            raise ParseError(f"Root element must be a dictionary in {source}")
            
        processed = {
            'version': content.get('version', '1.0'),
            'source': source,
            'metadata': self._process_metadata(content),
            'config': self._process_config(content),
            'tests': self._process_tests(content),
            'environments': content.get('environments', {}),
            'data': content.get('data', {})
        }
        
        return processed
        
    def _process_metadata(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Process test suite metadata"""
        metadata = content.get('metadata', {})
        return {
            'name': metadata.get('name', 'Unnamed Test Suite'),
            'description': metadata.get('description', ''),
            'author': metadata.get('author', ''),
        }
        
    def _process_config(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Process global configuration"""
        config = content.get('config', {})
        return {
            'base_url': config.get('base_url'),
            'timeout': config.get('timeout', 30),
            'headers': config.get('headers', {}),
            'auth': config.get('auth', {}),
            'variables': config.get('variables', {})
        }
        
    def _process_tests(self, content: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Process test definitions"""
        tests = content.get('tests', [])
        
        if not isinstance(tests, list):
            raise ParseError("'tests' must be a list")
            
        processed_tests = []
        
        for i, test in enumerate(tests):
            if not isinstance(test, dict):
                raise ParseError(f"Test {i} must be a dictionary")
                
            if 'endpoint' not in test:
                raise ParseError(f"Test {i} missing required field 'endpoint'")
                
            processed_test = {
                'name': test.get('name', f'Test {i + 1}'),
                'description': test.get('description', ''),
                'method': test.get('method', 'GET').upper(),
                'endpoint': test['endpoint'],
                'headers': test.get('headers', {}),
                'params': test.get('params', {}),
                'json_data': test.get('json_data') or test.get('body'),
                'auth': test.get('auth'),
                'timeout': test.get('timeout'),
                'validations': test.get('validations', [])
            }
            
            processed_tests.append(processed_test)
                
        return processed_tests