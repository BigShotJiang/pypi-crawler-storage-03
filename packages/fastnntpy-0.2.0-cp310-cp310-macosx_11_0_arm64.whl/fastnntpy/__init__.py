from .fastnntpy import *

__doc__ = fastnntpy.__doc__
if hasattr(fastnntpy, "__all__"):
    __all__ = fastnntpy.__all__