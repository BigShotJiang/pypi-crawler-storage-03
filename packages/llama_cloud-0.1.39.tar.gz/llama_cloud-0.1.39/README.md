# LlamaIndex Python Client

This client is auto-generated using [Fern](https://buildwithfern.com/docs/intro)

To publish:
- update the version in `pyproject.toml`
- run `poetry publish --build` 

Setup credentials:
- run `poetry config pypi-token.pypi <my-token>`
    - Get token form PyPi once logged in with credentials in [1Password](https://start.1password.com/open/i?a=32SA66TZ3JCRXOCMASLSDCT5TI&v=lhv7hvb5o46cwo257c3hviqkle&i=yvslwei7jtf6tgqamzcdantqi4&h=llamaindex.1password.com)
