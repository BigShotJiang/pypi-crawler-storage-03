PyBacting |release| Documentation
===================================
.. automodule:: pybacting

.. toctree::
   :maxdepth: 2
   :caption: Getting Started
   :name: start

   installation
   managers

Indices and Tables
------------------
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
