Managers
========
.. automodapi:: pybacting.api
    :no-heading:
    :headings: --
    :include-all-objects:
