# SPDX-FileCopyrightText: 2025-present Flyshde <zhangyang@outlook.es>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.12"
