# CclTt

[![PyPI - Version](https://img.shields.io/pypi/v/ccltt.svg)](https://pypi.org/project/ccltt)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ccltt.svg)](https://pypi.org/project/ccltt)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install ccltt
```

## License

`ccltt` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
