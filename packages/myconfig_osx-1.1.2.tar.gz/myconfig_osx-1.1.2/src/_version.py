"""Version information"""

VERSION = "1.1.2"
__version__ = VERSION
