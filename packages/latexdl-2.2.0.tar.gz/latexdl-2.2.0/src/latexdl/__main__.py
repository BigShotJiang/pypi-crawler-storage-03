from __future__ import annotations

if __name__ == "__main__":
    from .main import main

    main()
