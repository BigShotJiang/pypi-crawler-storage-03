<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../views/components/about_dialog.py" line="42"/>
        <source>About Momovu</source>
        <translation type="unfinished">モモヴーについて</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="54"/>
        <source>&lt;h2&gt;Momovu&lt;/h2&gt;</source>
        <translation type="unfinished">&lt;h2&gt;Momovu&lt;/h2&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="62"/>
        <source>Version {version}</source>
        <translation type="unfinished">バージョン {version}</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="77"/>
        <source>A PDF viewer for book publishing workflows.

Preview and validate book layouts with precise margin visualization, trim lines, and specialized viewing modes for interior pages, covers, and dust jackets.</source>
        <translation type="unfinished">本の出版ワークフロー用PDFビューア。

正確な余白の可視化、トリムライン、内面ページ、表紙、ジャケットのための専用表示モードで、本のレイアウトをプレビューおよび検証できます。</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="93"/>
        <source>&lt;p&gt;&lt;b&gt;Features:&lt;/b&gt;&lt;/p&gt;
        &lt;ul&gt;
        &lt;li&gt;Interior, Cover, and Dustjacket viewing modes&lt;/li&gt;
        &lt;li&gt;Margin and trim line visualization&lt;/li&gt;
        &lt;li&gt;Side-by-side page viewing&lt;/li&gt;
        &lt;li&gt;Presentation mode&lt;/li&gt;
        &lt;li&gt;Barcode area display&lt;/li&gt;
        &lt;li&gt;Fold line indicators&lt;/li&gt;
        &lt;/ul&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;特徴：&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;本文・表紙・ダストジャケットの表示モード&lt;/li&gt;
&lt;li&gt;余白と切り取り線の可視化&lt;/li&gt;
&lt;li&gt;並べてページを表示&lt;/li&gt;
&lt;li&gt;プレゼンテーションモード&lt;/li&gt;
&lt;li&gt;バーコード領域の表示&lt;/li&gt;
&lt;li&gt;折り目表示&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="103"/>
        <source>&lt;p&gt;&lt;b&gt;Links:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Main page: &lt;a href=&quot;https://momovu.org&quot;&gt;https://momovu.org&lt;/a&gt;&lt;/p&gt;
        &lt;p&gt;• Source code: &lt;a href=&quot;https://spacecruft.org/books/momovu&quot;&gt;https://spacecruft.org/books/momovu&lt;/a&gt;&lt;/p&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;リンク：&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;• メインページ: &lt;a href=&quot;https://momovu.org&quot;&gt;https://momovu.org&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;• ソースコード: &lt;a href=&quot;https://spacecruft.org/books/momovu&quot;&gt;https://spacecruft.org/books/momovu&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="113"/>
        <source>&lt;p&gt;&lt;b&gt;System Information:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Python version: {python_version}&lt;/p&gt;
        &lt;p&gt;• PySide6 version: {pyside_version}&lt;/p&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;システム情報：&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Python バージョン: {python_version}&lt;/p&gt;
        &lt;p&gt;• PySide6 バージョン: {pyside_version}&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="124"/>
        <source>&lt;p&gt;&lt;b&gt;Legal:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;Copyright © 2025 Jeff Moe&lt;br&gt;
        Licensed under the Apache License, Version 2.0&lt;/p&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;法的情報:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;著作権 © 2025 ジェフ・モー&lt;br&gt;
        アパッチライセンス、バージョン2.0の下でライセンスされています&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>DialogManager</name>
    <message>
        <location filename="../views/components/dialog_manager.py" line="62"/>
        <source>Open PDF</source>
        <translation type="unfinished">PDFを開く</translation>
    </message>
    <message>
        <location filename="../views/components/dialog_manager.py" line="64"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished">PDFファイル (*.pdf)</translation>
    </message>
    <message>
        <location filename="../views/components/dialog_manager.py" line="109"/>
        <source>Go to Page</source>
        <translation type="unfinished">ページへ移動</translation>
    </message>
    <message>
        <location filename="../views/components/dialog_manager.py" line="112"/>
        <source>Enter page number (1-{total_pages}):</source>
        <translation type="unfinished">ページ番号を入力 (1-{total_pages}):</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Page: 0/0</source>
        <translation type="obsolete">ページ: 0/0</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="301"/>
        <location filename="../views/main_window.py" line="785"/>
        <source>Momovu</source>
        <translation type="unfinished">モモヴー</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="414"/>
        <source>Load Error</source>
        <translation type="unfinished">読み込みエラー</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="460"/>
        <source>Rendering Error</source>
        <translation type="unfinished">レンダリングエラー</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="461"/>
        <source>Failed to render page:
{error}</source>
        <translation type="unfinished">ページのレンダリングに失敗しました:
{error}</translation>
    </message>
    <message>
        <source>Page: {current}/{total}</source>
        <translation type="obsolete">ページ: {current}/{total}</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="526"/>
        <source>File Dialog Error</source>
        <translation type="unfinished">ファイルダイアログエラー</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="527"/>
        <source>Failed to open file dialog:
{error}</source>
        <translation type="unfinished">ファイルダイアログを開くことができませんでした:
{error}</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="1222"/>
        <source>File Not Found</source>
        <translation type="unfinished">ファイルが見つかりません</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="1223"/>
        <source>The file could not be found:
{path}</source>
        <translation type="unfinished">ファイルが見つかりません：
{path}</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="41"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;ファイル</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="45"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;開く…</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="73"/>
        <source>Open a PDF file (Ctrl+O)</source>
        <translation type="unfinished">PDFファイルを開く (Ctrl+O)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="80"/>
        <source>Open &amp;Recent</source>
        <translation type="unfinished">&amp;最近使ったものを開く</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="83"/>
        <source>Open recently used files</source>
        <translation type="unfinished">最近使用したファイルを開く</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="90"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;閉じる</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="96"/>
        <source>Close the current document (Ctrl+W)</source>
        <translation type="unfinished">現在のドキュメントを閉じる (Ctrl+W)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="107"/>
        <source>&amp;Preferences...</source>
        <translation type="unfinished">&amp;設定...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="112"/>
        <source>Open preferences dialog</source>
        <translation type="unfinished">設定ダイアログを開く</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="119"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;終了</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="128"/>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;ビュー</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="131"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">フ&amp;ルスクリーン</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="138"/>
        <source>&amp;Presentation Mode</source>
        <translation type="unfinished">&amp;プレゼンテーションモード</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="148"/>
        <source>&amp;Side by Side</source>
        <translation type="unfinished">&amp;並べて表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="157"/>
        <source>Show &amp;Margins</source>
        <translation type="unfinished">&amp;余白を表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="165"/>
        <source>Show &amp;Trim Lines</source>
        <translation type="unfinished">&amp;トリムラインを表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="174"/>
        <source>Show &amp;Barcode</source>
        <translation type="unfinished">&amp;バーコードを表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="182"/>
        <source>Show Fo&amp;ld Lines</source>
        <translation type="unfinished">&amp;折り目を表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="191"/>
        <source>Show Bl&amp;eed Lines</source>
        <translation type="unfinished">&amp;裁ち落としラインを表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="201"/>
        <source>Show bleed lines at page edges (Ctrl+R)</source>
        <translation type="unfinished">ページの端に裁ち落としラインを表示する (Ctrl+R)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="205"/>
        <source>Show G&amp;utter</source>
        <translation type="unfinished">ガ&amp;ターを表示</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="215"/>
        <source>Show gutter margin for interior documents (Ctrl+U)</source>
        <translation type="unfinished">本文ドキュメントのガターマージンを表示 (Ctrl+U)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="220"/>
        <source>&amp;Go to Page...</source>
        <translation>ページへ移動(&amp;G)...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="226"/>
        <source>Go to a specific page (Ctrl+G)</source>
        <translation>特定のページへ移動 (Ctrl+G)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="235"/>
        <source>&amp;Document</source>
        <translation type="unfinished">&amp;ドキュメント</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="238"/>
        <source>&amp;Interior</source>
        <translation type="unfinished">&amp;本文</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="244"/>
        <source>&amp;Cover</source>
        <translation type="unfinished">&amp;表紙</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="250"/>
        <source>&amp;Dustjacket</source>
        <translation type="unfinished">&amp;ダストジャケット</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="258"/>
        <source>&amp;Calculator...</source>
        <translation>計算機(&amp;C)...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="265"/>
        <source>Calculate spine width and document dimensions</source>
        <translation>背幅と文書の寸法を計算</translation>
    </message>
    <message>
        <source>&amp;Spine Width Calculator...</source>
        <translation type="obsolete">&amp;背幅計算機...</translation>
    </message>
    <message>
        <source>Calculate spine width based on page count</source>
        <translation type="obsolete">ページ数に基づいて背幅を計算する</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="273"/>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;ヘルプ</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="276"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;について</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="281"/>
        <source>&amp;Keyboard Shortcuts</source>
        <translation type="unfinished">&amp;キーボードショートカット</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="380"/>
        <location filename="../views/components/menu_builder.py" line="418"/>
        <source>No Recent Files</source>
        <translation type="unfinished">最近使用したファイルはありません</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="413"/>
        <source>&amp;Clear Recent Files</source>
        <translation type="unfinished">最&amp;近使用したファイルのクリア</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="106"/>
        <source>First</source>
        <translation type="unfinished">最初</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="124"/>
        <source>Go to first page (Home)</source>
        <translation type="unfinished">最初のページ（ホーム）へ移動してください。</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="129"/>
        <source>Previous</source>
        <translation type="unfinished">前</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="149"/>
        <source>Go to previous page</source>
        <translation type="unfinished">前のページへ戻る</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="154"/>
        <source>Next</source>
        <translation type="unfinished">次</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="172"/>
        <source>Go to next page</source>
        <translation type="unfinished">次のページへ</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="177"/>
        <source>Last</source>
        <translation type="unfinished">最後</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="195"/>
        <source>Go to last page (End)</source>
        <translation type="unfinished">最後のページへ移動（終了）</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="202"/>
        <source>Page:</source>
        <translation type="unfinished">ページ：</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="211"/>
        <source>Current page number</source>
        <translation type="unfinished">現在のページ番号</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="221"/>
        <source>Pages:</source>
        <translation type="unfinished">ページ:</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="232"/>
        <source>Number of pages for spine width calculation</source>
        <translation type="unfinished">背幅計算用のページ数</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="242"/>
        <source>Zoom In</source>
        <translation type="unfinished">ズームイン</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="251"/>
        <source>Zoom in (Ctrl++)</source>
        <translation type="unfinished">ズームイン (Ctrl++)</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="256"/>
        <source>Zoom Out</source>
        <translation type="unfinished">ズームアウト</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="265"/>
        <source>Zoom out (Ctrl+-)</source>
        <translation type="unfinished">ズームアウト（Ctrl+-）</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="270"/>
        <source>Fit Page</source>
        <translation type="unfinished">ページに合わせる</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="288"/>
        <source>Fit page to window (Ctrl+0)</source>
        <translation type="unfinished">ページをウィンドウに合わせる (Ctrl+0)</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="79"/>
        <source>Preferences</source>
        <translation type="unfinished">設定</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="98"/>
        <source>General</source>
        <translation type="unfinished">一般</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="99"/>
        <source>Language</source>
        <translation type="unfinished">言語</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="100"/>
        <source>Colors</source>
        <translation type="unfinished">色</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="101"/>
        <source>Formulas</source>
        <translation>計算式</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="102"/>
        <source>Recent Files</source>
        <translation type="unfinished">最近使用したファイル</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="118"/>
        <source>Reset all settings to default values</source>
        <translation type="unfinished">すべての設定を初期値にリセットする</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="133"/>
        <source>Auto-fit on document load</source>
        <translation type="unfinished">ドキュメントの読み込み時に自動調整</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="134"/>
        <source>Fit Options:</source>
        <translation type="unfinished">フィットオプション:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="136"/>
        <source>Auto-fit on window resize</source>
        <translation type="unfinished">ウィンドウのリサイズに合わせて自動調整</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="145"/>
        <source>Zoom Increment:</source>
        <translation type="unfinished">ズーム増分：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="148"/>
        <source>Enable smooth scrolling</source>
        <translation type="unfinished">なめらかなスクロールを有効にする</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="149"/>
        <source>Scrolling:</source>
        <translation type="unfinished">スクロール：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="153"/>
        <source> pixels</source>
        <translation type="unfinished"> ピクセル</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="154"/>
        <source>Scroll Speed:</source>
        <translation type="unfinished">スクロール速度：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="157"/>
        <source>&lt;b&gt;Performance&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;パフォーマンス&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="161"/>
        <source> pages</source>
        <translation type="unfinished"> ページ</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="162"/>
        <source>Max Cached Pages:</source>
        <translation type="unfinished">最大キャッシュページ数:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="167"/>
        <source>Max Cache Memory:</source>
        <translation type="unfinished">最大キャッシュメモリ：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="185"/>
        <source>Margin Overlay</source>
        <translation type="unfinished">マージンオーバーレイ</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="186"/>
        <source>Barcode Area</source>
        <translation type="unfinished">バーコード領域</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="187"/>
        <location filename="../views/components/preferences_dialog.py" line="220"/>
        <source>Fold Lines</source>
        <translation type="unfinished">折り目</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="188"/>
        <location filename="../views/components/preferences_dialog.py" line="221"/>
        <source>Trim Lines</source>
        <translation type="unfinished">トリムライン</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="189"/>
        <location filename="../views/components/preferences_dialog.py" line="222"/>
        <source>Bleed Lines</source>
        <translation type="unfinished">裁ち落としライン</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="190"/>
        <source>Gutter</source>
        <translation type="unfinished">ガター</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="209"/>
        <source>Opacity:</source>
        <translation type="unfinished">不透明度：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="213"/>
        <location filename="../views/components/preferences_dialog.py" line="230"/>
        <source>{label}:</source>
        <translation type="unfinished">{label}：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="216"/>
        <source>&lt;b&gt;Line Widths&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;ラインの太さ&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="239"/>
        <source>Protanopia</source>
        <translation type="unfinished">プロタノピア</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="242"/>
        <source>Apply colors optimized for red-blind vision</source>
        <translation type="unfinished">赤色弱視に最適化された色を適用する</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="248"/>
        <source>Deuteranopia</source>
        <translation type="unfinished">第二色覚異常</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="251"/>
        <source>Apply colors optimized for green-blind vision</source>
        <translation type="unfinished">緑色覚異常の視覚に最適化された色を適用する</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="257"/>
        <source>Tritanopia</source>
        <translation type="unfinished">第三色覚異常</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="260"/>
        <source>Apply colors optimized for blue-blind vision</source>
        <translation type="unfinished">青色弱視に最適化された色を適用する</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="281"/>
        <source>Recently opened PDF files:</source>
        <translation type="unfinished">最近開いたPDFファイル:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="292"/>
        <source>Remove Selected</source>
        <translation type="unfinished">選択項目を削除</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="300"/>
        <source>Clear All Recent Files</source>
        <translation type="unfinished">すべての最近使用したファイルをクリア</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="336"/>
        <source>Interface Language:</source>
        <translation type="unfinished">インターフェース言語：</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="343"/>
        <source>&lt;i&gt;Note: Changing the language requires restarting the application.&lt;/i&gt;</source>
        <translation type="unfinished">&lt;i&gt;注：言語を変更するにはアプリケーションを再起動する必要があります。&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="355"/>
        <source>&lt;b&gt;Supported Languages:&lt;/b&gt;&lt;br&gt;• Right-to-left languages (Arabic) are fully supported&lt;br&gt;• CJK languages (Chinese, Japanese, Korean) use system fonts&lt;br&gt;• All number and date formatting follows the selected locale</source>
        <translation type="unfinished">&lt;b&gt;サポートされている言語：&lt;/b&gt;&lt;br&gt;• 右から左への言語（アラビア語）は完全にサポートされています&lt;br&gt;• CJK言語（中国語、日本語、韓国語）はシステムフォントを使用します&lt;br&gt;• すべての数字と日付の書式は、選択したロケールに従います</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="377"/>
        <source>&lt;i&gt;&lt;b&gt;Disclaimer:&lt;/b&gt; These formulas are approximations based on publicly available information. This application is not affiliated with or endorsed by Lulu, Lightning Source, or any printing service. Always verify calculations with your printer&apos;s official tools before submitting files for production.&lt;/i&gt;</source>
        <translation>&lt;i&gt;&lt;b&gt;免責事項:&lt;/b&gt; これらの計算式は公開されている情報に基づく近似値です。このアプリケーションはLulu、Lightning Source、またはいかなる印刷サービスとも提携または承認されていません。製作用ファイルを提出する前に、必ず印刷業者の公式ツールで計算を確認してください。&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="394"/>
        <source>&lt;b&gt;Printer Formula Selection&lt;/b&gt;</source>
        <translation>&lt;b&gt;プリンター計算式の選択&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="402"/>
        <source>Select the printer formula to use for calculating spine width. Different printers use different formulas based on their paper and binding methods.</source>
        <translation>背幅の計算に使用するプリンター計算式を選択してください。プリンターによって、用紙と製本方法に基づいて異なる計算式を使用します。</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="410"/>
        <source>Printer Formula</source>
        <translation>プリンター計算式</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="414"/>
        <source>Lulu</source>
        <translation>Lulu</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="420"/>
        <source>Standard Lulu formula: (pages / 17.48) + 1.524mm
Works for all Lulu paper types</source>
        <translation>標準Lulu計算式: (ページ数 / 17.48) + 1.524mm
すべてのLulu用紙タイプに対応</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="424"/>
        <source>Lightning Source</source>
        <translation>Lightning Source</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="430"/>
        <source>Lightning Source formula with variable paper weights.
Requires selecting paper weight for accurate calculation.</source>
        <translation>可変用紙重量のLightning Source計算式。
正確な計算には用紙重量の選択が必要です。</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="438"/>
        <source>Paper Weight (Lightning Source)</source>
        <translation>用紙重量 (Lightning Source)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="442"/>
        <source>38 lb (Groundwood)</source>
        <translation>38ポンド (グラウンドウッド)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="443"/>
        <source>50 lb (Standard White/Creme)</source>
        <translation>50ポンド (標準白/クリーム)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="444"/>
        <source>70 lb (Thick White)</source>
        <translation>70ポンド (厚手白)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="446"/>
        <source>Paper Weight:</source>
        <translation>用紙重量:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="456"/>
        <source>&lt;b&gt;Paper Weight Guide:&lt;/b&gt;&lt;br&gt;• &lt;b&gt;38 lb:&lt;/b&gt; Thinner groundwood paper (~550 pages/inch)&lt;br&gt;• &lt;b&gt;50 lb:&lt;/b&gt; Standard white or creme paper (~472 pages/inch)&lt;br&gt;• &lt;b&gt;70 lb:&lt;/b&gt; Thicker white paper (~340 pages/inch)</source>
        <translation>&lt;b&gt;用紙重量ガイド:&lt;/b&gt;&lt;br&gt;• &lt;b&gt;38ポンド:&lt;/b&gt; 薄いグラウンドウッド紙 (~550ページ/インチ)&lt;br&gt;• &lt;b&gt;50ポンド:&lt;/b&gt; 標準白またはクリーム紙 (~472ページ/インチ)&lt;br&gt;• &lt;b&gt;70ポンド:&lt;/b&gt; 厚い白紙 (~340ページ/インチ)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="530"/>
        <source>Choose {type} Color</source>
        <translation type="unfinished">{type}色を選択してください</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="601"/>
        <source>Clear Recent Files</source>
        <translation type="unfinished">最近使用したファイルのクリア</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="602"/>
        <source>Are you sure you want to clear all recent files?</source>
        <translation type="unfinished">すべての最近使用したファイルをクリアしてもよろしいですか。</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="615"/>
        <source>Reset to Defaults</source>
        <translation type="unfinished">デフォルトに戻す</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="618"/>
        <source>Are you sure you want to reset all settings to their default values?

This action cannot be undone.</source>
        <translation type="unfinished">すべての設定を初期値にリセットしてもよろしいですか？

この操作は元に戻すことができません。</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="630"/>
        <source>Settings Reset</source>
        <translation type="unfinished">設定のリセット</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="631"/>
        <source>All settings have been reset to their default values.</source>
        <translation type="unfinished">すべての設定がデフォルト値にリセットされました。</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="815"/>
        <source>Restart Required</source>
        <translation type="unfinished">再起動が必要です</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="818"/>
        <source>The language change will take effect after restarting the application.</source>
        <translation type="unfinished">アプリケーションを再起動すると、言語の変更が有効になります。</translation>
    </message>
</context>
<context>
    <name>ShortcutsDialog</name>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="38"/>
        <location filename="../lib/shortcuts_dialog.py" line="50"/>
        <source>Keyboard Shortcuts</source>
        <translation type="unfinished">キーボードショートカット</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="58"/>
        <source>Category</source>
        <translation type="unfinished">カテゴリ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="58"/>
        <source>Action</source>
        <translation type="unfinished">アクション</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="59"/>
        <source>Shortcut</source>
        <translation type="unfinished">ショートカット</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="90"/>
        <location filename="../lib/shortcuts_dialog.py" line="91"/>
        <location filename="../lib/shortcuts_dialog.py" line="92"/>
        <source>File</source>
        <translation type="unfinished">ファイル</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="90"/>
        <source>Open Document</source>
        <translation type="unfinished">ドキュメントを開く</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="91"/>
        <source>Close Document</source>
        <translation type="unfinished">ドキュメントを閉じる</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="92"/>
        <source>Exit Application</source>
        <translation type="unfinished">アプリケーションを終了する</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="94"/>
        <location filename="../lib/shortcuts_dialog.py" line="95"/>
        <location filename="../lib/shortcuts_dialog.py" line="96"/>
        <location filename="../lib/shortcuts_dialog.py" line="98"/>
        <location filename="../lib/shortcuts_dialog.py" line="102"/>
        <location filename="../lib/shortcuts_dialog.py" line="103"/>
        <location filename="../lib/shortcuts_dialog.py" line="104"/>
        <location filename="../lib/shortcuts_dialog.py" line="105"/>
        <location filename="../lib/shortcuts_dialog.py" line="107"/>
        <location filename="../lib/shortcuts_dialog.py" line="112"/>
        <location filename="../lib/shortcuts_dialog.py" line="117"/>
        <location filename="../lib/shortcuts_dialog.py" line="121"/>
        <source>Navigation</source>
        <translation type="unfinished">ナビゲーション</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="94"/>
        <source>Next Page</source>
        <translation type="unfinished">次のページ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="95"/>
        <source>Next Page (alternative)</source>
        <translation type="unfinished">次のページ（代替）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="96"/>
        <source>Previous Page</source>
        <translation type="unfinished">前のページ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="99"/>
        <source>Previous Page (alternative)</source>
        <translation type="unfinished">前のページ（代替）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="102"/>
        <source>First Page</source>
        <translation type="unfinished">最初のページ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="103"/>
        <source>Last Page</source>
        <translation type="unfinished">最後のページ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="104"/>
        <source>Go to Page (Interior only)</source>
        <translation type="unfinished">ページへ（本文のみ）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="105"/>
        <source>Navigate with Arrow Keys</source>
        <translation type="unfinished">矢印キーで移動</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="108"/>
        <source>  • When zoomed</source>
        <translation type="unfinished">  • ズームしたとき</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="109"/>
        <source>Arrow Keys = Pan document</source>
        <translation type="unfinished">矢印キー＝ドキュメントのパン</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="113"/>
        <source>  • Interior (not zoomed)</source>
        <translation type="unfinished">  • 本文（ズームしていない）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="114"/>
        <source>Left/Right = Previous/Next page</source>
        <translation type="unfinished">左／右＝前のページ／次のページ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="118"/>
        <source>  • Cover/Dustjacket</source>
        <translation type="unfinished">  • 表紙／ダストジャケット</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="119"/>
        <source>Arrow Keys = No action</source>
        <translation type="unfinished">矢印キー = 何もしない</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="121"/>
        <source>Navigate Pages</source>
        <translation type="unfinished">ページを移動する</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="123"/>
        <location filename="../lib/shortcuts_dialog.py" line="124"/>
        <location filename="../lib/shortcuts_dialog.py" line="125"/>
        <location filename="../lib/shortcuts_dialog.py" line="126"/>
        <source>View</source>
        <translation type="unfinished">ビュー</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="123"/>
        <source>Fullscreen</source>
        <translation type="unfinished">フルスクリーン</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="124"/>
        <source>Presentation Mode</source>
        <translation type="unfinished">プレゼンテーションモード</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="125"/>
        <source>Exit Presentation/Fullscreen</source>
        <translation type="unfinished">プレゼンテーション/フルスクリーンを終了する</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="126"/>
        <source>Side by Side View</source>
        <translation type="unfinished">サイドバイサイドビュー</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="128"/>
        <source>Document</source>
        <translation type="unfinished">ドキュメント</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="128"/>
        <source>Spine Width Calculator</source>
        <translation type="unfinished">背幅計算機</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="130"/>
        <location filename="../lib/shortcuts_dialog.py" line="131"/>
        <location filename="../lib/shortcuts_dialog.py" line="133"/>
        <location filename="../lib/shortcuts_dialog.py" line="137"/>
        <location filename="../lib/shortcuts_dialog.py" line="139"/>
        <location filename="../lib/shortcuts_dialog.py" line="144"/>
        <source>Display</source>
        <translation type="unfinished">表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="130"/>
        <source>Show/Hide Margins</source>
        <translation type="unfinished">余白の表示/非表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="131"/>
        <source>Show/Hide Trim Lines</source>
        <translation type="unfinished">トリムラインの表示/非表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="134"/>
        <source>Show/Hide Barcode</source>
        <translation type="unfinished">バーコードの表示/非表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="135"/>
        <source>Ctrl+B (Cover/Dustjacket only)</source>
        <translation type="unfinished">Ctrl+B（表紙/ジャケットのみ）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="137"/>
        <source>Show/Hide Fold Lines</source>
        <translation type="unfinished">折り線の表示/非表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="140"/>
        <source>Show/Hide Bleed Lines</source>
        <translation type="unfinished">裁ち落としラインの表示/非表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="141"/>
        <source>Ctrl+R (Cover/Dustjacket only)</source>
        <translation type="unfinished">Ctrl+R（表紙/ジャケットのみ）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="145"/>
        <source>Show/Hide Gutter</source>
        <translation type="unfinished">ガターの表示/非表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="146"/>
        <source>Ctrl+U (Interior only)</source>
        <translation type="unfinished">Ctrl+U (本文のみ)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="149"/>
        <location filename="../lib/shortcuts_dialog.py" line="150"/>
        <location filename="../lib/shortcuts_dialog.py" line="151"/>
        <location filename="../lib/shortcuts_dialog.py" line="152"/>
        <location filename="../lib/shortcuts_dialog.py" line="153"/>
        <source>Zoom</source>
        <translation type="unfinished">ズーム</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="149"/>
        <source>Zoom In</source>
        <translation type="unfinished">ズームイン</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="150"/>
        <source>Zoom Out</source>
        <translation type="unfinished">ズームアウト</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="151"/>
        <source>Fit to Page</source>
        <translation type="unfinished">ページに合わせる</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="152"/>
        <source>Fit to Page (alternative)</source>
        <translation type="unfinished">ページに合わせる（代替）</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="153"/>
        <source>Zoom with Mouse</source>
        <translation type="unfinished">マウスでズーム</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="155"/>
        <location filename="../lib/shortcuts_dialog.py" line="156"/>
        <source>Help</source>
        <translation type="unfinished">ヘルプ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="155"/>
        <source>Show Keyboard Shortcuts</source>
        <translation type="unfinished">キーボードショートカットを表示</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="156"/>
        <source>About</source>
        <translation type="unfinished">について</translation>
    </message>
</context>
<context>
    <name>SpineWidthCalculatorDialog</name>
    <message>
        <source>Spine Width Calculator</source>
        <translation type="obsolete">背幅計算機</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="89"/>
        <source>Calculator</source>
        <translation>計算機</translation>
    </message>
    <message>
        <source>Calculate spine width based on page count and document type.
Enter the number of pages and select the document type.</source>
        <translation type="obsolete">ページ数とドキュメントタイプに基づいて背幅を計算します。  
ページ数を入力し、ドキュメントタイプを選択してください。</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="117"/>
        <source>Number of Pages:</source>
        <translation type="unfinished">ページ数：</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="123"/>
        <source>Enter the total number of pages (1-999)</source>
        <translation type="unfinished">ページ総数を入力してください（1〜999）</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="130"/>
        <source>Document Type</source>
        <translation type="unfinished">ドキュメントタイプ</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="136"/>
        <source>Cover</source>
        <translation type="unfinished">表紙</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="140"/>
        <source>Dustjacket</source>
        <translation type="unfinished">ダストジャケット</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="214"/>
        <source>Minimum {pages} pages required for dustjackets</source>
        <translation type="unfinished">ダストジャケットには最低{pages}ページが必要です</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="393"/>
        <source>Dimension</source>
        <translation type="unfinished">寸法</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="394"/>
        <source>Value</source>
        <translation type="unfinished">値</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="395"/>
        <source>Notes</source>
        <translation type="unfinished">備考</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="468"/>
        <location filename="../views/components/calculator_dialog.py" line="504"/>
        <source>Barcode Area</source>
        <translation type="unfinished">バーコード領域</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="470"/>
        <location filename="../views/components/calculator_dialog.py" line="506"/>
        <source>ISBN barcode placement area</source>
        <translation type="unfinished">ISBNバーコード配置エリア</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="474"/>
        <location filename="../views/components/calculator_dialog.py" line="510"/>
        <source>Bleed Area</source>
        <translation type="unfinished">裁ち落としエリア</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="476"/>
        <location filename="../views/components/calculator_dialog.py" line="512"/>
        <source>Extends beyond trim edge</source>
        <translation type="unfinished">トリムエッジを超えて延長</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="480"/>
        <location filename="../views/components/calculator_dialog.py" line="528"/>
        <source>Gutter Width (per page)</source>
        <translation type="unfinished">ガター幅（ページごと）</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="482"/>
        <location filename="../views/components/calculator_dialog.py" line="530"/>
        <source>Added to safety margin for binding</source>
        <translation type="unfinished">製本用の安全マージンに追加</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="486"/>
        <location filename="../views/components/calculator_dialog.py" line="534"/>
        <source>Safety Margin</source>
        <translation type="unfinished">安全マージン</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="488"/>
        <location filename="../views/components/calculator_dialog.py" line="536"/>
        <source>Minimum distance from trim edge</source>
        <translation type="unfinished">トリムエッジからの最小距離</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="492"/>
        <location filename="../views/components/calculator_dialog.py" line="540"/>
        <source>Spine Width</source>
        <translation type="unfinished">背幅</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="494"/>
        <location filename="../views/components/calculator_dialog.py" line="542"/>
        <source>Calculated based on {pages} pages</source>
        <translation type="unfinished">{pages}ページに基づいて計算</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="516"/>
        <source>Flap Width</source>
        <translation type="unfinished">フラップ幅</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="518"/>
        <source>Width of front and back flaps</source>
        <translation type="unfinished">前後のフラップの幅</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="522"/>
        <source>Fold Safety Margin</source>
        <translation type="unfinished">折り目安全マージン</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="524"/>
        <source>Safety margin at fold lines</source>
        <translation type="unfinished">折り線での安全マージン</translation>
    </message>
    <message>
        <source>Calculated Spine Width</source>
        <translation type="obsolete">計算された背幅</translation>
    </message>
    <message>
        <source>Spine Width: {width}mm</source>
        <translation type="obsolete">背幅: {width}mm</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="153"/>
        <source>Document Dimensions</source>
        <translation>ドキュメントの寸法</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="163"/>
        <source>Production Details</source>
        <translation type="unfinished">製作詳細</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="207"/>
        <source>Minimum {pages} pages required for covers</source>
        <translation type="unfinished">表紙に必要な最小{pages}ページ数</translation>
    </message>
    <message>
        <source>Spine Width: --</source>
        <translation type="obsolete">背幅：--</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="250"/>
        <source>Error calculating spine width</source>
        <translation>背幅の計算エラー</translation>
    </message>
    <message>
        <source>Note: Page count outside standard range</source>
        <translation type="obsolete">注意：ページ数が標準範囲外です</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="262"/>
        <source>Book Format</source>
        <translation>本の形式</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="263"/>
        <source>Trim Size</source>
        <translation>仕上がりサイズ</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="264"/>
        <source>Total Document Size</source>
        <translation>総ドキュメントサイズ</translation>
    </message>
</context>
</TS>
