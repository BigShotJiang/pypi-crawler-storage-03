"""SQS model."""
