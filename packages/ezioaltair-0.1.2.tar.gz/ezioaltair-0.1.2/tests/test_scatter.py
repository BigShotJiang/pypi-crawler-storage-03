
import polars as pl


def test_scatterchart():
    pass