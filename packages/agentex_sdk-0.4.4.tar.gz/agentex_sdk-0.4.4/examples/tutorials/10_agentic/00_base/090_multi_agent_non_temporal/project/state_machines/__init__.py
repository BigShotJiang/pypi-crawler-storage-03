# State machines package for multi-agent orchestration
