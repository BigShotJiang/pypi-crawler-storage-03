"""Package for grid3d_average_map and grid3d_hc_thickness"""

__author__ = """Jan C. Rivenaes"""
__email__ = "jriv@equinor."
