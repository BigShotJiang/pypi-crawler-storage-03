"""Integrations with popular frameworks"""
