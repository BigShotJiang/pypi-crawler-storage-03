import glob
import os
import sys
from io import StringIO
from typing import Union

import argparse

from sinol_make import util
from sinol_make.commands.inwer import TestResult, TableData
from sinol_make.helpers import compile, package_util
from sinol_make.helpers import compiler
from sinol_make.interfaces.Errors import CompilationError


def get_inwer_path(task_id: str, path=None) -> Union[str, None]:
    """
    Returns path to inwer executable for given task or None if no inwer was found.
    """
    if path is None:
        inwers = package_util.get_files_matching_pattern(task_id, f'{task_id}inwer.*')
        if len(inwers) == 0:
            return None
        return inwers[0]
    else:
        inwer = os.path.join(os.getcwd(), path)
        if os.path.exists(inwer):
            return inwer
        return None


def compile_inwer(inwer_path: str, args: argparse.Namespace, compilation_flags='default', use_fsanitize=False):
    """
    Compiles inwer and returns path to compiled executable and path to compile log.
    """
    compilers = compiler.verify_compilers(args, [inwer_path])
    inwer_exe, compile_log_path = compile.compile_file(inwer_path, package_util.get_executable(inwer_path), compilers,
                                                       compilation_flags, use_fsanitize=use_fsanitize,
                                                       additional_flags='-D_INWER', use_extras=False)

    if inwer_exe is None:
        compile.print_compile_log(compile_log_path)
        util.exit_with_error('Failed inwer compilation.')
    else:
        print(util.info('Compilation successful.'))
    return inwer_exe


def sort_tests(tests, task_id):
    # First sort by group, then by test name.
    tests.sort(key=lambda test: [package_util.get_group(test, task_id), test])
    return tests


def print_view(term_width, term_height, table_data: TableData):
    """
    Prints current results of test verification.
    """

    previous_stdout = sys.stdout
    new_stdout = StringIO()
    sys.stdout = new_stdout

    results = table_data.results
    column_lengths = [0, len('Group') + 1, len('Status') + 1, 0]
    tests = []
    for result in results.values():
        column_lengths[0] = max(column_lengths[0], len(result.test_name))
        column_lengths[1] = max(column_lengths[1], len(result.test_group))
        tests.append(result.test_path)
    tests = sort_tests(tests, table_data.task_id)

    column_lengths[3] = max(10, term_width - column_lengths[0] - column_lengths[1] - column_lengths[
        2] - 9 - 3)  # 9 is for " | " between columns, 3 for margin.
    margin = "  "

    def print_line_separator():
        res = "-" * (column_lengths[0] + 3) + "+" + "-" * (column_lengths[1] + 1) + "+" + "-" * (
                    column_lengths[2] + 1) + "+"
        res += "-" * (term_width - len(res) - 1)
        print(res)

    print_line_separator()

    print(margin + "Test".ljust(column_lengths[0]) + " | " + "Group".ljust(column_lengths[1] - 1) + " | " + "Status" +
          " | " + "Output")
    print_line_separator()

    last_group = None
    for test_path in tests:
        result = results[test_path]
        if last_group is not None and last_group != result.test_group:
            print_line_separator()
        last_group = result.test_group
        print(margin + result.test_name.ljust(column_lengths[0]) + " | ", end='')
        print(result.test_group.ljust(column_lengths[1] - 1) + " | ", end='')

        if result.verified:
            if result.valid:
                print(util.info("OK".ljust(column_lengths[2] - 1)), end='')
            else:
                print(util.error("ERROR".ljust(column_lengths[2] - 1)), end='')
        else:
            print(util.warning("...".ljust(column_lengths[2] - 1)), end='')
        print(" | ", end='')

        output = []
        if result.verified:
            split_output = result.output.split('\n')
            for line in split_output:
                output += [line[i:i + column_lengths[3]] for i in range(0, len(line), column_lengths[3])]
        else:
            output.append("")

        if output == []:
            print(util.color_gray("No output"))
        else:
            print(output[0].ljust(column_lengths[3]))
            output.pop(0)

            for line in output:
                print(" " * (column_lengths[0] + 2) + " | " + " " * (column_lengths[1] - 1) + " | " +
                      " " * (column_lengths[2] - 1) + " | " + line.ljust(column_lengths[3]))

    print_line_separator()
    print()
    print()

    sys.stdout = previous_stdout
    return new_stdout.getvalue().splitlines(), None, "Use arrows to move."
