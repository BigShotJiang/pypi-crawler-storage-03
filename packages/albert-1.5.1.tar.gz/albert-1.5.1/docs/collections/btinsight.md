::: albert.collections.btinsight.BTInsightCollection
