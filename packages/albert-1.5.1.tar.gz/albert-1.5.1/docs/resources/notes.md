::: albert.resources.notes
