from . import n64 as n64
from . import ps2 as ps2
from . import psx as psx
from . import psp as psp
