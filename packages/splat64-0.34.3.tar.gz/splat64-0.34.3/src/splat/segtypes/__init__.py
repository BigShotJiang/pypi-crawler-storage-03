from . import linker_entry as linker_entry
from . import segment as segment

from . import common as common
from . import n64 as n64
from . import ps2 as ps2
from . import psx as psx
from . import psp as psp
