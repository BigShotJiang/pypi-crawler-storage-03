Critical:

- add important singular message such as connect/disconn/close/etc

Secondary:

- on_pipeline_create
- on_instance_create

- session method to get list of all online nodes from supervisor

- change DecentrAIObject to ratio1 Edge ProtocolObject