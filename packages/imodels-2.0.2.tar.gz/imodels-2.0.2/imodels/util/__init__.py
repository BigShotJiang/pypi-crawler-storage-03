'''Shared utilities for implementing different interpretable models.
'''