This README contains the full documentation for your script.

You auto-generate this README file from your script YML file using the `demisto-sdk generate-docs` command.

For more information see the [documentation article](https://xsoar.pan.dev/docs/integrations/integration-docs).
