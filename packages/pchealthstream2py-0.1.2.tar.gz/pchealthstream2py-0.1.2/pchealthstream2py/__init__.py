"""Getting streams of PC stats"""
