"""Constants for a DrX device connection"""

DEFAULT_PORT = 7
DEFAULT_TIMEOUT = 10

RSA_KEY_BITS = 2048
AES_salt = b"\x9c\xfc\x02\x87\xfe\x7e\xdf\x7f"
