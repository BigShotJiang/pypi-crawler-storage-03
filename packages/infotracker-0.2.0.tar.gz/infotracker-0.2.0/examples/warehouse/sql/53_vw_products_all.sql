CREATE VIEW EDW_CORE.dbo.vw_products_all AS
SELECT *
FROM STG.dbo.Products; 