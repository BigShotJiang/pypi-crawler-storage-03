
Changelog
=========


Version 1.0
-----------

Released 2025-08-19

* Initial release.
