"""Common environment functionality"""
