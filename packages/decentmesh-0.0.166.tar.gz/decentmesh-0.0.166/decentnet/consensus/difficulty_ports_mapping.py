from decentnet.consensus.blockchain_params import BlockchainParams

PORT_DIFFICULTY_CONFIG = {
    8888: BlockchainParams(),
    8889: BlockchainParams(),
    8890: BlockchainParams(),
    8891: BlockchainParams(),
    8892: BlockchainParams()
}
