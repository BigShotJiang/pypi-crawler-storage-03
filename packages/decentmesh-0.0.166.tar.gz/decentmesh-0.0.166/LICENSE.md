Jiri Otoupal Commercial Attribution License (JO-CAL)

Version 1.0

PLEASE READ THIS LICENSE AGREEMENT ("LICENSE") CAREFULLY BEFORE USING THE SOFTWARE. BY USING THE SOFTWARE, YOU ARE AGREEING TO BE BOUND BY THE TERMS
OF THIS LICENSE. IF YOU DO NOT AGREE TO THE TERMS OF THIS LICENSE, DO NOT USE THE SOFTWARE.

    Definitions.
        "Software" refers to the copyrighted software by Jiri Otoupal, including any associated documentation, source code, and executable files.
        "Commercial Use" means using the Software directly or indirectly in connection with any business or commercial activity.
        "Proprietary Use" means using the Software in a way that incorporates it into proprietary software, which is not released under an open-source license compatible with this License.

    Grant of License.
        Jiri Otoupal hereby grants you a worldwide, non-exclusive, non-transferable license to use the Software for any purpose, including Commercial Use, subject to the terms and conditions of this License.

    Attribution.
        You must give appropriate credit to Jiri Otoupal, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

    Compensation for Proprietary Use.
        If you wish to use the Software for Proprietary Use, you must obtain a separate license from Jiri Otoupal for such use. Terms and compensation for Proprietary Use will be negotiated on a case-by-case basis.

    Restrictions.
        You may not distribute the Software or any derivative works of the Software under a proprietary license without obtaining a separate license from Jiri Otoupal for Proprietary Use.
        You may not remove or alter any copyright, trademark, or attribution notices within the Software.

    Termination.
        This License is effective until terminated. Your rights under this License will terminate automatically without notice from Jiri Otoupal if you fail to comply with any term(s) of this License.

    Disclaimer of Warranty.
        THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    General.
        This License constitutes the entire agreement between the parties with respect to the use of the Software licensed hereunder and supersedes all prior or contemporaneous understandings regarding such subject matter.