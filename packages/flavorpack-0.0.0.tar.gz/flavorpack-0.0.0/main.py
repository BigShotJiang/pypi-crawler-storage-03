def main():
    print("Hello from flavorpack!")


if __name__ == "__main__":
    main()
