"""
CLI entry point for DuoTalk.
"""

from .main import app

if __name__ == "__main__":
    app()
