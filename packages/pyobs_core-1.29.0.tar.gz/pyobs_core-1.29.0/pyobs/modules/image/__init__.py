"""
Modules for image operations.
TODO: write doc
"""

__title__ = "Image operations"

from .imagewatcher import ImageWatcher
from .imagewriter import ImageWriter
from .pipeline import Pipeline
from .seeing import Seeing
