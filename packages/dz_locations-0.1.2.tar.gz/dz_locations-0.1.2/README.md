# dz_locations

**DZ Locations** is a Django package that provides **Algerian wilayas (states) and communes (municipalities)** ready to use in your Django projects.

This package helps you quickly populate your database with all Algerian locations and access them via Django Admin or API.

---

## **Installation**

Install the package via pip:

```bash
pip install dz-locations
```

---

## **Features**

- Preloaded data for all Algerian wilayas and communes.
- Management commands to load data into your database.
- Easy integration with Django Admin.
- API-ready serializers for quick development.

---

## **Usage**

1. Add `dz_locations` to your `INSTALLED_APPS` in `settings.py`:

    ```python
    INSTALLED_APPS = [
        ...
        'dz_locations',
    ]
    ```

2. Run the management command to load data:

    ```bash
    python manage.py loaddz
    ```

3. Access the data via Django Admin or use the serializers provided for API development.

---

## **Contributing**

Contributions are welcome! If you'd like to contribute, please follow these steps:

1. Fork the repository.
2. Create a new branch for your feature or bugfix.
3. Commit your changes and push them to your fork.
4. Submit a pull request.

---

## **License**

This project is licensed under the MIT License. See the LICENSE file for details.