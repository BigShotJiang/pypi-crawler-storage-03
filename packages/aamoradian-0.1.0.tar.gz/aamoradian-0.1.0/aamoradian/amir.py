print("builder amir abbas moradian!!")
class amir():
    def chap(self):
            print(type(self))
            print(self)

