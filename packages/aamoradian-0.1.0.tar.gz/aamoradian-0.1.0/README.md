# yourlibname

یک کتابخانه ساده پایتون برای تست انتشار در PyPI.

## نصب

`bash
pip install yourlibname