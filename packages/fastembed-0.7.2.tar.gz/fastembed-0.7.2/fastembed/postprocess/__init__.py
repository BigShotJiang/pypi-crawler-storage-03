from fastembed.postprocess.muvera import Muvera

__all__ = ["Muvera"]
