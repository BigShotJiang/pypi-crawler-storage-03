from packaging.version import Version

__version__ = Version("0.35.0")
