#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

__version_info__ = ("0", "11", "0")
__version__ = '.'.join(__version_info__)
