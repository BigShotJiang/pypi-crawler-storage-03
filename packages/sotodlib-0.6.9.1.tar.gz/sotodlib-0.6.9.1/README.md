
# SO TOD Library

![!Build and Test](https://github.com/simonsobs/sotodlib/workflows/Build%20and%20Test/badge.svg)
[![Documentation Status](https://readthedocs.org/projects/sotodlib/badge/?version=latest)](https://sotodlib.readthedocs.io/en/latest/?badge=latest)
[![PyPI - Version](https://img.shields.io/pypi/v/sotodlib.svg)](https://pypi.org/project/sotodlib)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/sotodlib.svg)](https://pypi.org/project/sotodlib)

Tools for working with real and simulated time ordered data.

Full documentation here:

https://sotodlib.readthedocs.io/en/latest/
