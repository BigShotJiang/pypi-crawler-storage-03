# confetti

Configure your scripts with magic.