#!/usr/bin/env python3
"""setup.py - 安装脚本

此文件用于向后兼容，主要配置在pyproject.toml中定义。
"""

from setuptools import setup

if __name__ == "__main__":
    setup()