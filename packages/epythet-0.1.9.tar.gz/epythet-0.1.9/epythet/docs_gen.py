"""
Documentation generation
"""

from epythet.setup_docsrc import make_docsrc
from epythet.autogen import make_autodocs
from epythet.call_make import make
