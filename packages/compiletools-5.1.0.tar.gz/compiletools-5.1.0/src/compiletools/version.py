""" Use bumpversion to increment version.py, and README.rst, and ..., 
    simultaneously.  Also add the flags to git tag and commit everything
    in one operation.
"""
__version__ = "5.1.0"
