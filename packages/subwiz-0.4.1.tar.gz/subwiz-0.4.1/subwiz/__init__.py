from subwiz.main import run

__all__ = ["run"]
