.. _bbo-examples:

Black-box optimization
----------------------