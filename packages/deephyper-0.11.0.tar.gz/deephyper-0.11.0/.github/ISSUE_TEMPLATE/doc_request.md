---
name: Doc request
about: Create a documentation request to help us improve
title: "[DOC]"
labels: docs
assignees: ''

---

**Description of the question**
A clear and concise description of what should be documented.
