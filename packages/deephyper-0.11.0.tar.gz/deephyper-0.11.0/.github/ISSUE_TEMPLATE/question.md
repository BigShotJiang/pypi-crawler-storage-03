---
name: Question
about: Ask a question about how to use the software
title: '[FAQ]'
labels: question
assignees: ''

---

**Context**
Gives some context if needed (environment, system, hardware).

**Describe the task you are trying to achieve.**
A clear and concise description of what the task is.

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

