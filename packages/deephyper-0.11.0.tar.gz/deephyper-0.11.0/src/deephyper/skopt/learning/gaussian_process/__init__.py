from .gpr import GaussianProcessRegressor  # noqa: F401

__all__ = "GaussianProcessRegressor"
