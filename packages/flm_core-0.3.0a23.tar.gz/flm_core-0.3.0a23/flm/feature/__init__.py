r"""
Base module for feature definitions.
"""


from ._base import Feature, SimpleLatexDefinitionsFeature
