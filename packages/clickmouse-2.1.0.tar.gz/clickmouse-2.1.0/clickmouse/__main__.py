"""
ClickMouse命令行工具
"""

import argparse
from . import click_mouse
from .version import version

# 常量
__version__ = version

def main():
    """
    ClickMouse命令行工具的函数
    """
    print('ClickMouse命令行工具未实现，敬请期待')

if __name__ == '__main__':
    main()