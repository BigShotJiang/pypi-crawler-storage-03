CREATE TABLE gqlite_metadata(name TEXT PRIMARY KEY, value TEXT NOT NULL)
