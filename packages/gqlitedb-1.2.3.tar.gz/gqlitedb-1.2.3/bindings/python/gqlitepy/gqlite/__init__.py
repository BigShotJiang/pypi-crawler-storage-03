from gqlite.gqlite import Connection, Error


def connect(*args):
    return Connection(*args)
