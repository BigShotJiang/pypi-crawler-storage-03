# -------------------------------------------------------------------------

from gitlabcis import benchmarks  # noqa: F401
from gitlabcis.cli.output import output  # noqa: F401
from gitlabcis.utils import countRecommendations  # noqa: F401
from gitlabcis.utils import mapRecommendations  # noqa: F401
from gitlabcis.utils import readRecommendations  # noqa: F401

# -------------------------------------------------------------------------

__author__ = 'nmcdonald+gitlabcis@gitlab.com'
__version__ = '1.15.7'  # noqa: E999
