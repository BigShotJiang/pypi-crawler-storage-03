"""Contextualize robot data."""
