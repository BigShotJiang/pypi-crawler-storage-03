## cdf 

### Added

- [alpha] New command `cdf upload` and with the subcommand `cdf upload
raw`.

## templates

No changes.