# This folder holds basic sanity checks for the distributed version of chromadb
# while it is in development. In the future, it may hold more extensive tests
# in tandem with the main test suite, targeted at the distributed version.
