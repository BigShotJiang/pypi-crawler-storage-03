"""
`browsr` version file.
"""

from importlib.metadata import version

__author__: str = "Justin Flannery"
__email__: str = "justin.flannery@juftin.com"
__application__: str = "browsr"
__version__: str = version(__application__)
