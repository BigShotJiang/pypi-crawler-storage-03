# Import key functions and classes
from .HakObserverLinuxpy import InitiateCollection  # Import the function from the correct module

# Optional: Define a version number for the package
__version__ = "2.2.3"

# Optional: Define the package's public interface
__all__ = ["InitiateCollecection"]

# # Import key functions and classes