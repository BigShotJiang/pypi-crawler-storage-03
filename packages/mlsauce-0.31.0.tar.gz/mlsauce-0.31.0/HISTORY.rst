=======
History
=======


1. Version 0.1.0 (2019-12-19)

* First version


2. Version 0.2.0 (2020-05-08)

* First release on PyPI.


3. Version 0.3.0 (2020-05-31)

* Include cython parallel processing Pt.1
* Include manhattan distance