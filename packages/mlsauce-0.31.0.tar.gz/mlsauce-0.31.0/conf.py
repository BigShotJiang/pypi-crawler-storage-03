# Add napoleon to the extensions list
extensions = ['sphinxcontrib.napoleon', 'recommonmark']