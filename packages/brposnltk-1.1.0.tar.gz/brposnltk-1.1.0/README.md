# brposNLTK

A Part-of-Speech (POS) Tagger for Bengali dialects, built using an LSTM-based deep learning model.

## Installation

To install the package locally, navigate to the root directory and run:

```bash
pip install .