# Python tests

The sole purpose of the Python tests is to check the export of classes and functions, and check that they behave as expected.

Unit testing, integration testing, and regression tests all happen in the Rust tests. Please refer to those [here](../../anise/tests/) for details.
