import scCAMEL as scm
from scCAMEL import CamelPrefiltering
from scCAMEL import CamelSwapline
from scCAMEL import CamelEvo
from scCAMEL import CamelVicuna
from scCAMEL import CamelGuanACoWig