# mltools

## 介绍

mltools：一个专注于机器学习工具开发的开源项目。

## 安装命令

```bash
pip install wliafe-mltools
```

建议使用uv安装。

```bash
uv add wliafe-mltools [--extra <cuda版本>]
```

cuda版本：cpu、cu118、cu121、cu124、cu126、cu128

## 使用说明

1. mltools需要python3.8及以上版本。
2. 样例可以参考example文件夹。
