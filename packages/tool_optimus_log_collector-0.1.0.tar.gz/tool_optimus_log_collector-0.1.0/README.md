# azure-blob-logger-async

An asynchronous logging handler that writes logs to Azure Blob Storage using `append_blob`.

## Install

```bash
pip install git+https://github.com/your-org/azure-blob-logger-async.git
