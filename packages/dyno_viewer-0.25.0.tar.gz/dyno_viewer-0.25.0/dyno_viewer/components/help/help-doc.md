# Help

Dyno-viewer is a kiss (keep it simple stupid) viewer for dynamodb tables 

## keybindings

| key | action |
| --- | --- |
| `[` | previous page |
| `]` | next page |
| `CTRL + r` | change table cursor type i.e entire row/col |
| `c` | copy row |
| `q` | show query menu |
| `p` | select an aws profile (configured via the aws cli) |
| `r` | select aws region in main screen/will run query in query menu |
| `?` | show help |
| `q` | quit app |

