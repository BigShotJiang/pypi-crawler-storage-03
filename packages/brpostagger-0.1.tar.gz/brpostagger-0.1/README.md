# POS Tagger Library

## Installation
To install the POS Tagger Library, use:

```bash
pip install .
