# trustra/__init__.py
from .core import TrustRA

__version__ = "1.0.0"
__all__ = ["TrustRA"]