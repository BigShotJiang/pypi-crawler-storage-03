from .base import BaseFloat


class Float32(BaseFloat):
    def __init__(self):
        super().__init__()


class Float64(BaseFloat):
    def __init__(self):
        super().__init__()
