.. _changelog:

============
Geschiedenis
============

.. include:: ../CHANGES.rst
