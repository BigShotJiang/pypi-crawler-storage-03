"""
Utility modules for the CARLA Driving Simulator.
"""
