# gestionatr
[![Tests](https://github.com/gisce/gestionatr/actions/workflows/python-app.yml/badge.svg)](https://github.com/gisce/gestionatr/actions/workflows/python-app.yml)

Libreria para la generación y carga de ficheros de gestion ATR según define
la CNMC para Electricidad
