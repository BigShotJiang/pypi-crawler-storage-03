class P0FaultError(Exception):
    pass


class A529FaultError(Exception):
    pass
