"""Incogniton API client module."""

from .client import IncognitonClient

__all__ = ["IncognitonClient"] 