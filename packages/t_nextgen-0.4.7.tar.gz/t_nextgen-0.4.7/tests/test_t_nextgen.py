#!/usr/bin/env python
"""Tests for `t_nextgen` package."""


class TestTNextgen:
    """Smoke tests of the package."""

    def test_example(self):
        """Smoke test."""
        assert True
