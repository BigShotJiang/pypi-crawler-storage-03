# JTECH™ Installer

> **Instalador Enterprise para Framework JTECH™ Core**  
> Solução automatizada para configuração de ambientes de desenvolvimento orientados por IA

[![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)](https://gitlab.com/veolia.com/brasil/jtech/jtech-generative-ai/jtech-installer)
[![Python](https://img.shields.io/badge/python-3.12+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)](LICENSE)
[![Veolia](https://img.shields.io/badge/Veolia-JTech-green.svg)](https://veolia.com)

## Visão Geral

O **JTECH™ Installer** é uma ferramenta enterprise desenvolvida pela Veolia para automatizar a configuração e instalação do framework JTECH™ Core em ambientes de desenvolvimento. Este instalador configura automaticamente agentes especializados, workflows, templates e integrações necessárias para desenvolvimento orientado por IA.

### Principais Características

- 🚀 **Instalação Automatizada**: Configuração completa em um único comando
- 🤖 **Agentes Especializados**: 10+ agentes IA para diferentes funções (PM, Dev, QA, etc.)
- 🏗️ **Templates Enterprise**: Templates padronizados para documentação e arquitetura
- 🔧 **Integração IDE**: Configuração automática para VS Code e GitHub Copilot
- 📋 **Workflows Padronizados**: Processos de desenvolvimento pré-configurados
- ✅ **Validação Automatizada**: Verificação de integridade pós-instalação

## Pré-requisitos

### Ambiente Mínimo
- **Python**: 3.12.9+
- **Sistema Operacional**: Linux, macOS, Windows
- **Memória**: 4GB RAM (recomendado: 8GB+)
- **Armazenamento**: 500MB livres

### Dependências
- Git configurado
- VS Code (opcional, mas recomendado)
- GitHub Copilot (para funcionalidades avançadas)

## Instalação

### Via PyPI (Recomendado)
```bash
pip install jtech-installer
```

### Via Source (Desenvolvimento)
```bash
git clone https://gitlab.com/veolia.com/brasil/jtech/jtech-generative-ai/jtech-installer.git
cd jtech-installer
pip install -e .
```

## Uso

### Comando Principal
```bash
jtech-installer [OPTIONS] COMMAND [ARGS]...
```

### Instalação Básica
```bash
# Instalação padrão (team fullstack)
jtech-installer install

# Instalação com team específico
jtech-installer install --team ide-minimal

# Instalação forçada (sobrescreve instalação existente)
jtech-installer install --force
```

### Comandos Disponíveis

| Comando | Descrição | Exemplo |
|---------|-----------|---------|
| `install` | Instala JTECH™ Core no diretório atual | `jtech-installer install` |
| `reinstall` | Reinstala forçadamente o framework | `jtech-installer reinstall` |
| `validate` | Valida instalação existente | `jtech-installer validate` |

### Opções Globais

| Opção | Descrição | Valores |
|-------|-----------|---------|
| `-t, --team` | Tipo de equipe/configuração | `fullstack`, `ide-minimal`, `all`, `no-ui` |
| `-f, --force` | Forçar reinstalação | - |
| `--validate-only` | Apenas validar instalação | - |
| `-v, --version` | Mostrar versão | - |
| `-h, --help` | Mostrar ajuda | - |

## Configurações de Team

### Team Fullstack (Padrão)
**Ideal para**: Desenvolvimento web completo, aplicações enterprise
```yaml
agentes: [analyst, pm, ux-expert, architect, po, dev, qa]
workflows: [greenfield-fullstack, brownfield-fullstack]
templates: [prd, architecture, front-end-spec]
```

### Team IDE Minimal
**Ideal para**: Desenvolvimento ágil, prototipagem rápida
```yaml
agentes: [pm, architect, dev]
workflows: [greenfield-service]
templates: [project-brief, architecture]
```

### Team All
**Ideal para**: Projetos complexos, grandes equipes
```yaml
agentes: [analyst, pm, po, architect, dev, qa, ux-expert, sm]
workflows: [todos os workflows disponíveis]
templates: [todos os templates disponíveis]
```

### Team No-UI
**Ideal para**: APIs, microserviços, backend
```yaml
agentes: [analyst, pm, architect, dev, qa]
workflows: [greenfield-service, brownfield-service]
templates: [prd, architecture]
```

## Estrutura Instalada

### Hierarquia de Arquivos
```
projeto/
├── .jtech-core/                 # 🏗️ Framework Core
│   ├── agents/                  # 🤖 Agentes especializados
│   │   ├── pm.md               # Product Manager
│   │   ├── dev.md              # Developer
│   │   ├── architect.md        # Software Architect
│   │   └── ...
│   ├── templates/               # 📄 Templates
│   │   ├── prd-tmpl.yaml       # Product Requirements
│   │   ├── architecture-tmpl.yaml
│   │   └── ...
│   ├── workflows/               # ⚡ Workflows
│   │   ├── greenfield-fullstack.yaml
│   │   ├── brownfield-service.yaml
│   │   └── ...
│   ├── tasks/                   # 📋 Tarefas Executáveis
│   ├── checklists/             # ✅ Checklists de Qualidade
│   └── core-config.yml         # ⚙️ Configuração Principal
├── .github/
│   └── chatmodes/              # 🔗 GitHub Copilot Integration
├── .vscode/
│   └── settings.json           # 🛠️ VS Code Configuration
└── docs/                       # 📚 Documentação Inicial
```

### Agentes Especializados

| Agente | Função | Responsabilidades |
|--------|--------|------------------|
| **Analyst** | Analista de Negócio | Levantamento de requisitos, análise de viabilidade |
| **PM** | Product Manager | Gestão de produto, roadmap, priorização |
| **PO** | Product Owner | Definição de features, critérios de aceitação |
| **Architect** | Arquiteto de Software | Design de arquitetura, padrões, tecnologias |
| **Dev** | Desenvolvedor | Implementação, code review, testes unitários |
| **QA** | Quality Assurance | Testes, validação, automação de QA |
| **UX Expert** | UX Designer | Interface, experiência do usuário, usabilidade |
| **SM** | Scrum Master | Facilitação ágil, remoção de impedimentos |

## Validação e Troubleshooting

### Verificar Instalação
```bash
# Validação completa
jtech-installer validate

# Verificar agentes instalados
ls .jtech-core/agents/

# Verificar configuração
cat .jtech-core/core-config.yml
```

### Problemas Comuns

| Problema | Solução |
|----------|---------|
| Comando não encontrado | Execute `pyenv rehash` ou reinicie terminal |
| Permissões insuficientes | Execute com `sudo` ou verifique permissões de diretório |
| Instalação incompleta | Use `jtech-installer reinstall --force` |

## Desenvolvimento

### Setup Ambiente de Desenvolvimento
```bash
# Clonar repositório
git clone https://gitlab.com/veolia.com/brasil/jtech/jtech-generative-ai/jtech-installer.git
cd jtech-installer

# Instalar dependências
make install-dev

# Executar testes
make test

# Lint e formatação
make format-check
make lint
```

### Estrutura do Projeto
```
jtech-installer/
├── src/jtech_installer/         # 📦 Código fonte
│   ├── cli/                     # Interface de linha de comando
│   ├── core/                    # Motor de instalação
│   ├── installer/               # Módulos de instalação
│   ├── validator/               # Validadores
│   └── assets/                  # Assets do framework
├── tests/                       # 🧪 Testes
├── scripts/                     # 🔧 Scripts auxiliares
└── docs/                        # 📚 Documentação
```

### Comandos Make Disponíveis
```bash
make install-dev     # Instalar dependências de desenvolvimento
make test           # Executar testes
make format         # Formatar código
make lint          # Verificar lint
make build-internal # Build para distribuição interna Veolia
make validate-build # Validar build
```

### Distribuição Interna
⚠️ **IMPORTANTE**: Este é um software proprietário da Veolia e NÃO deve ser publicado em repositórios públicos.

```bash
# Build para distribuição interna
make build-internal

# Instalação local para testes
pip install dist/*.whl

# Para compartilhar internamente
# 1. Compartilhe o arquivo .whl gerado em dist/
# 2. Ou configure repositório PyPI privado da Veolia
```

## Licença e Copyright

**Copyright © 2024 Veolia Environnement S.A.**

Este software é propriedade da Veolia e está licenciado exclusivamente para uso interno. 
Distribuição, modificação ou uso não autorizado é estritamente proibido.

**PROPRIETARY SOFTWARE - ALL RIGHTS RESERVED**

## Suporte e Contato

- **Documentação**: [docs.jtech.dev](https://docs.jtech.dev/installer)
- **Issues**: [GitLab Issues](https://gitlab.com/veolia.com/brasil/jtech/jtech-generative-ai/jtech-installer/-/issues)
- **Email**: jtech-support@veolia.com
- **Teams**: Canal #jtech-core

---

**JTECH™ Framework** | Desenvolvido com ❤️ pela equipe Veolia Brasil | Versão 0.1.0
