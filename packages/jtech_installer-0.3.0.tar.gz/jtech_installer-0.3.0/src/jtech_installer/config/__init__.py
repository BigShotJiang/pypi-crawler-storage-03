"""Configuration generation package for JTECH™ Installer"""
