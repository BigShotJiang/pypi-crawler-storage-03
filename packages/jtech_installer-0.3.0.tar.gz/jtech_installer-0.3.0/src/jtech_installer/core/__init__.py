"""Core engine package for JTECH™ Installer"""
