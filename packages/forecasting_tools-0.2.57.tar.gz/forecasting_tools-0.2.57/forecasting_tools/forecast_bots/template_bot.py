from forecasting_tools.forecast_bots.official_bots.fall_template_bot import (
    FallTemplateBot2025,
)


class TemplateBot(FallTemplateBot2025):
    pass
