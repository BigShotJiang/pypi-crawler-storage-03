class HandledError(Exception):
    pass
