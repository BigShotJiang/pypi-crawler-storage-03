rest\_api package
==========================

rest module
------------------------------

.. automodule:: rfserver.rest_api.rest
   :members:
   :show-inheritance:
   :undoc-members:
