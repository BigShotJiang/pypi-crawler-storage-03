===============
Code of conduct
===============

.. include:: ../../../CODE_OF_CONDUCT.md
