from .goodness_of_fit import GoodnessFit

__all__ = [
    'GoodnessFit'
]