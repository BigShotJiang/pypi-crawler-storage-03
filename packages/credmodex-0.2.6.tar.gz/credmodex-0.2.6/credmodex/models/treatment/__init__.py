from .treatment_func import TreatmentFunc

__all__ = [
    'TreatmentFunc'
]