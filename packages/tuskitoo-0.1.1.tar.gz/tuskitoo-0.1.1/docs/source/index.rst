:github_url: https://github.com/felavila/tuskitoo

tuskitoo documentation
=====================

.. toctree::
   :maxdepth: 2
   :caption: Getting Started 
   
   getting_started

.. toctree::
   :maxdepth: 2
   :caption: API Reference

   api/tuskitoo

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`