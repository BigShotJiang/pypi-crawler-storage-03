def test_import_module():
    import tuskitoo

    assert tuskitoo is not None
