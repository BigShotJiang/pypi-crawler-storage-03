Filterinfo
============

add text 