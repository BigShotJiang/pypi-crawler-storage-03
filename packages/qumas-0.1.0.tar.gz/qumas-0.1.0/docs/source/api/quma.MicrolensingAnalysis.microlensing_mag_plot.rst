qumas.MicrolensingAnalysis.microlensing\_mag\_plot module
========================================================

.. automodule:: qumas.MicrolensingAnalysis.microlensing_mag_plot
   :members:
   :show-inheritance:
   :undoc-members:
