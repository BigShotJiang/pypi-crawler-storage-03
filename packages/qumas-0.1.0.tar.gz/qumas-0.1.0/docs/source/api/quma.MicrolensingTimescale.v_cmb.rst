qumas.MicrolensingTimescale.v\_cmb module
========================================

.. automodule:: qumas.MicrolensingTimescale.v_cmb
   :members:
   :show-inheritance:
   :undoc-members:
