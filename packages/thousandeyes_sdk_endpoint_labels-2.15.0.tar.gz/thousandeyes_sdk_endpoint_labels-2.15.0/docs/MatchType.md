# MatchType

Specifies how the filters are combined for matching this label.  * `and`: All filters must be matched. * `or`: Any of the filters should match. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


