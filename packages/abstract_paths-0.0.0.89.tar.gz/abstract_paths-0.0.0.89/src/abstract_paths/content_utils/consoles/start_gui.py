from finderConsole import reactRunnerConsole,ContentFinderConsole,MainShell
from diffParserGui import diffParserTab
from abstract_gui.QT6.startConsole import  startConsole

startConsole(diffParserTab)
