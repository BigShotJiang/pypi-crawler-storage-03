#!/usr/bin/env python
"""
This file does nothing except to mock a optimizer which does not work.
"""
import sys

print('Bad JPEG file')
sys.exit(1)
