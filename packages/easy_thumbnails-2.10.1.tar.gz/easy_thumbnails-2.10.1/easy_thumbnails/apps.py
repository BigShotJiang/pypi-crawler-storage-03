from django.apps import AppConfig


class EasyThumbnailsConfig(AppConfig):
    name = 'easy_thumbnails'

    default_auto_field = 'django.db.models.AutoField'
