# Function Reference

# API Reference

## `distortions.geometry`

::: distortions.geometry
    options:
        members:
            - Geometry
            - bind_metric
            - boxplot_data
            - local_distortions
            - neighborhood_distances
            - neighborhoods
            - local_distortions

## `distortions.visualization`

::: distortions.visualization
    options:
        members:
            - dplot
            - scanpy_umap