Gambit is a package for representing, manuipulating, and analysing
finite noncooperative games in extensive and normal form.

See the project homepage at www.gambit-project.org for more information.

Documentation of Gambit is hosted at https://gambitproject.readthedocs.io.
