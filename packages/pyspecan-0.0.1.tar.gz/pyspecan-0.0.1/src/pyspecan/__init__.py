"""
pyspecan

A spectrum analyzer library

Github: https://github.com/Anonoei/pyspecan

PyPI: https://pypi.org/project/pyspecan/
"""

__version__ = "0.0.1"
__author__ = "Anonoei <to+dev@an0.cx>"
