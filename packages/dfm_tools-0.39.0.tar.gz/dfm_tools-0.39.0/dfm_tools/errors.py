class OutOfRangeError(Exception):
    pass
