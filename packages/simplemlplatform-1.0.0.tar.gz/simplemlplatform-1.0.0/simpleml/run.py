"""
Run class for SimpleML SDK.
"""

import os
import requests
from typing import Dict, List, Optional, Any, Union
from .exceptions import SimpleMLError, APIError


class Run:
    """Represents a training run within an experiment."""
    
    def __init__(self, client, run_id: str, experiment_id: str, name: str,
                 hyperparameters: Optional[Dict[str, Any]] = None,
                 tags: Optional[Dict[str, str]] = None,
                 status: str = 'RUNNING',
                 created_at: Optional[str] = None,
                 completed_at: Optional[str] = None,
                 **kwargs):
        """
        Initialize Run.
        
        Args:
            client: SimpleMLClient instance
            run_id: Unique run identifier
            experiment_id: Parent experiment ID
            name: Run name
            hyperparameters: Hyperparameters used in this run
            tags: Optional tags
            status: Run status
            created_at: Creation timestamp
            completed_at: Completion timestamp
        """
        self.client = client
        self.run_id = run_id
        self.experiment_id = experiment_id
        self.name = name
        self.hyperparameters = hyperparameters or {}
        self.tags = tags or {}
        self.status = status
        self.created_at = created_at
        self.completed_at = completed_at
        self._is_completed = status in ['COMPLETED', 'FAILED']
    
    
    def log_metrics(self, metrics: Dict[str, float], step: Optional[int] = None) -> None:
        """
        Log multiple metrics.
        
        Args:
            metrics: Dictionary of metric names to values
            step: Optional step number
        """
        if self._is_completed:
            raise SimpleMLError(f"Cannot log metrics to completed run {self.run_id}")
        
        self.client.log_metrics(self.run_id, metrics, step)
    
    
    def log_params(self, params: Dict[str, Any]) -> None:
        """
        Log multiple parameters.
        
        Args:
            params: Dictionary of parameter names to values
        """
        # Update local hyperparameters
        self.hyperparameters.update(params)
        # Note: Backend doesn't currently support updating hyperparameters after creation
        # This would need to be implemented if required
    
    def upload_artifact(self, file_path: str, filename: Optional[str] = None,
                       artifact_type: str = 'unknown') -> Dict[str, Any]:
        """
        Upload an artifact file.
        
        Args:
            file_path: Path to the file to upload
            filename: Optional custom filename (defaults to basename of file_path)
            artifact_type: Type of artifact (e.g., 'model', 'plot', 'data')
            
        Returns:
            Artifact information
        """
        if not os.path.exists(file_path):
            raise SimpleMLError(f"File not found: {file_path}")
        
        if filename is None:
            filename = os.path.basename(file_path)
        
        # Get upload URL
        upload_info = self.client.get_upload_url(self.run_id, filename, artifact_type)
        
        # Upload file using presigned POST
        upload_url = upload_info['upload_url']
        fields = upload_info['fields']
        
        try:
            with open(file_path, 'rb') as f:
                files = {'file': (filename, f)}
                response = requests.post(upload_url, data=fields, files=files)
                response.raise_for_status()
            
            return {
                'artifact_id': upload_info['artifact_id'],
                'filename': filename,
                'artifact_type': artifact_type
            }
            
        except requests.exceptions.RequestException as e:
            raise APIError(f"Failed to upload artifact: {e}")
    
    def list_artifacts(self) -> List[Dict[str, Any]]:
        """List all artifacts for this run."""
        return self.client.list_artifacts(self.run_id)
    
    def download_artifact(self, artifact_id: str, local_path: str) -> None:
        """
        Download an artifact.
        
        Args:
            artifact_id: ID of the artifact to download
            local_path: Local path to save the file
        """
        download_url = self.client.get_download_url(artifact_id)
        
        try:
            response = requests.get(download_url)
            response.raise_for_status()
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            
            with open(local_path, 'wb') as f:
                f.write(response.content)
                
        except requests.exceptions.RequestException as e:
            raise APIError(f"Failed to download artifact: {e}")
    
    def register_model(self, model_name: str, artifacts: Optional[List[str]] = None,
                      description: Optional[str] = None, tags: Optional[Dict[str, str]] = None,
                      stage: str = 'staging') -> Dict[str, Any]:
        """
        Register a model from this run.
        
        Args:
            model_name: Name of the model
            artifacts: List of artifact filenames to include
            description: Optional model description
            tags: Optional model tags
            stage: Model stage ('staging', 'production', 'archived')
            
        Returns:
            Model version information
        """
        if artifacts is None:
            # Get all artifacts for this run
            run_artifacts = self.list_artifacts()
            artifacts = [art['filename'] for art in run_artifacts]
        
        return self.client.register_model(
            model_name=model_name,
            run_id=self.run_id,
            artifacts=artifacts,
            description=description,
            tags=tags,
            stage=stage
        )
    
    def complete(self, status: str = 'COMPLETED') -> None:
        """
        Mark the run as completed.
        
        Args:
            status: Final status ('COMPLETED' or 'FAILED')
        """
        if self._is_completed:
            raise SimpleMLError(f"Run {self.run_id} is already completed")
        
        self.client.complete_run(self.run_id, status)
        self.status = status
        self._is_completed = True
    
    def fail(self) -> None:
        """Mark the run as failed."""
        self.complete('FAILED')
    
    def get_metrics(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get all metrics for this run.
        
        Returns:
            Dictionary mapping metric names to list of data points
        """
        # Use the client's internal method to get metrics
        # This will need to be implemented in the client
        return self.client._get_run_metrics(self.run_id)
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - automatically complete or fail the run."""
        if not self._is_completed:
            if exc_type is not None:
                # Exception occurred, mark as failed
                try:
                    self.fail()
                except:
                    pass  # Don't raise another exception during cleanup
            else:
                # Normal completion
                self.complete()
    
    def __repr__(self) -> str:
        return f"Run(id='{self.run_id}', name='{self.name}', status='{self.status}')"
    
    def __str__(self) -> str:
        return f"Run '{self.name}' ({self.run_id}) - {self.status}"