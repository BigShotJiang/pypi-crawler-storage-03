"""
Command line interface for SimpleML SDK.
"""

import argparse
import sys
import json
from typing import Optional

import simpleml
from .exceptions import SimpleMLError


def configure_command(args):
    """Configure SimpleML SDK."""
    try:
        client = simpleml.configure(
            stack_name=args.stack_name,
            region=args.region,
            api_endpoint=args.api_endpoint,
            api_key=args.api_key
        )
        
        # Test connection
        health = client.health_check()
        print(f"✅ SimpleML configured successfully!")
        print(f"   Service: {health.get('service', 'Unknown')}")
        print(f"   Version: {health.get('version', 'Unknown')}")
        
        if args.stack_name:
            try:
                stack_info = client.get_stack_info()
                print(f"   Stack: {stack_info.get('stack_name', 'Unknown')}")
                print(f"   Region: {stack_info.get('region', 'Unknown')}")
            except:
                pass
                
    except SimpleMLError as e:
        print(f"❌ Configuration failed: {e}")
        sys.exit(1)


def list_experiments_command(args):
    """List experiments."""
    try:
        client = simpleml.get_client()
        experiments = client.list_experiments()
        
        if not experiments:
            print("No experiments found.")
            return
        
        print(f"Found {len(experiments)} experiments:")
        print()
        
        for exp in experiments:
            print(f"📁 {exp.name}")
            print(f"   ID: {exp.experiment_id}")
            if exp.description:
                print(f"   Description: {exp.description}")
            print(f"   Created: {exp.created_at}")
            if exp.tags:
                tags_str = ", ".join([f"{k}={v}" for k, v in exp.tags.items()])
                print(f"   Tags: {tags_str}")
            print()
            
    except SimpleMLError as e:
        print(f"❌ Failed to list experiments: {e}")
        sys.exit(1)


def create_experiment_command(args):
    """Create experiment."""
    try:
        tags = {}
        if args.tags:
            for tag in args.tags:
                if '=' in tag:
                    key, value = tag.split('=', 1)
                    tags[key] = value
                else:
                    tags[tag] = ''
        
        experiment = simpleml.create_experiment(
            name=args.name,
            description=args.description,
            tags=tags
        )
        
        print(f"✅ Created experiment: {experiment.name}")
        print(f"   ID: {experiment.experiment_id}")
        
    except SimpleMLError as e:
        print(f"❌ Failed to create experiment: {e}")
        sys.exit(1)


def list_models_command(args):
    """List models."""
    try:
        client = simpleml.get_client()
        models = client.list_models()
        
        if not models:
            print("No models found.")
            return
        
        print(f"Found {len(models)} models:")
        print()
        
        for model in models:
            print(f"📦 {model['model_name']}")
            print(f"   Latest Version: v{model['latest_version']}")
            print(f"   Versions: {len(model['versions'])}")
            print(f"   Created: {model['created_at']}")
            print()
            
    except SimpleMLError as e:
        print(f"❌ Failed to list models: {e}")
        sys.exit(1)


def health_command(args):
    """Check API health."""
    try:
        client = simpleml.get_client()
        health = client.health_check()
        
        print("🔍 SimpleML API Health Check:")
        print(f"   Status: {health.get('status', 'Unknown')}")
        print(f"   Service: {health.get('service', 'Unknown')}")
        print(f"   Version: {health.get('version', 'Unknown')}")
        print(f"   Timestamp: {health.get('timestamp', 'Unknown')}")
        
        if health.get('status') == 'healthy':
            print("✅ API is healthy")
        else:
            print("❌ API is not healthy")
            sys.exit(1)
            
    except SimpleMLError as e:
        print(f"❌ Health check failed: {e}")
        sys.exit(1)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(description='SimpleML SDK CLI')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Configure command
    config_parser = subparsers.add_parser('configure', help='Configure SimpleML SDK')
    config_parser.add_argument('--stack-name', help='CloudFormation stack name')
    config_parser.add_argument('--region', help='AWS region')
    config_parser.add_argument('--api-endpoint', help='API endpoint URL')
    config_parser.add_argument('--api-key', help='API key')
    config_parser.set_defaults(func=configure_command)
    
    # List experiments command
    list_exp_parser = subparsers.add_parser('experiments', help='List experiments')
    list_exp_parser.set_defaults(func=list_experiments_command)
    
    # Create experiment command
    create_exp_parser = subparsers.add_parser('create-experiment', help='Create experiment')
    create_exp_parser.add_argument('name', help='Experiment name')
    create_exp_parser.add_argument('--description', help='Experiment description')
    create_exp_parser.add_argument('--tags', nargs='*', help='Tags (key=value format)')
    create_exp_parser.set_defaults(func=create_experiment_command)
    
    # List models command
    list_models_parser = subparsers.add_parser('models', help='List models')
    list_models_parser.set_defaults(func=list_models_command)
    
    # Health check command
    health_parser = subparsers.add_parser('health', help='Check API health')
    health_parser.set_defaults(func=health_command)
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Execute command
    args.func(args)


if __name__ == '__main__':
    main()