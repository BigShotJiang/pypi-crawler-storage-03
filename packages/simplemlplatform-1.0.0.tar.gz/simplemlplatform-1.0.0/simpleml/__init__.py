"""
SimpleML SDK - A lightweight MLOps SDK for experiment tracking and model registry.
"""

from .client import SimpleMLClient
from .experiment import Experiment
from .run import Run
from .exceptions import SimpleMLError, AuthenticationError, NotFoundError

# Global client instance
_client = None

def configure(api_key, api_endpoint=None):
    """
    Configure the SimpleML SDK with just an API key.
    
    Args:
        api_key: API key for authentication
        api_endpoint: API endpoint URL (optional, uses default SimpleML endpoint)
    
    Returns:
        Configured SimpleMLClient instance
    """
    global _client
    
    if not api_key:
        raise SimpleMLError("API key is required")
    
    # Use default SimpleML endpoint if not provided
    if not api_endpoint:
        api_endpoint = "https://9xhgvaz5fk.execute-api.eu-west-1.amazonaws.com/Prod"  # Default production endpoint
    
    _client = SimpleMLClient(api_endpoint=api_endpoint, api_key=api_key)
    return _client

# Convenience function matching user's desired interface
def simpleml(api_key, api_endpoint=None):
    """
    Initialize SimpleML with just an API key.
    
    Args:
        api_key: API key for authentication
        api_endpoint: API endpoint URL (optional, uses default SimpleML endpoint)
    
    Returns:
        Configured SimpleMLClient instance
    """
    return configure(api_key, api_endpoint)

def get_client():
    """Get the current SimpleML client."""
    global _client
    if _client is None:
        raise SimpleMLError("SimpleML not configured. Call simpleml(api_key) first.")
    return _client

# Convenience functions that delegate to the client
def create_experiment(name, description=None, tags=None):
    """Create a new experiment."""
    return get_client().get_or_create_experiment(name, description, tags)

def get_or_create_experiment(name, description=None, tags=None):
    """Get existing experiment by name or create if it doesn't exist."""
    return get_client().get_or_create_experiment(name, description, tags)

def get_experiment(experiment_id):
    """Get an experiment by ID."""
    return get_client().get_experiment(experiment_id)

def list_experiments():
    """List all experiments."""
    return get_client().list_experiments()

def get_run(run_id):
    """Get a run by ID."""
    return get_client().get_run(run_id)

def start_run(experiment_name_or_id, name=None, hyperparameters=None, tags=None):
    """Start a new run."""
    return get_client().start_run(experiment_name_or_id, name, hyperparameters, tags)

def list_models():
    """List all registered models."""
    return get_client().list_models()

def update_model_stage(model_name, version, stage):
    """Update a model version's stage."""
    return get_client().update_model_stage(model_name, version, stage)

__version__ = "1.0.0"
__all__ = [
    "simpleml",
    "configure",
    "get_client", 
    "create_experiment",
    "get_or_create_experiment",
    "get_experiment",
    "list_experiments",
    "get_run",
    "start_run",
    "list_models",
    "update_model_stage",
    "SimpleMLError",
    "AuthenticationError", 
    "NotFoundError",
    "Experiment",
    "Run",
    "SimpleMLClient"
]