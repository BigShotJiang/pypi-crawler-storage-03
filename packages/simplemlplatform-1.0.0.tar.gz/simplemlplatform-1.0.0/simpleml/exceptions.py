"""
SimpleML SDK exceptions.
"""

class SimpleMLError(Exception):
    """Base exception for SimpleML SDK."""
    pass

class AuthenticationError(SimpleMLError):
    """Raised when authentication fails."""
    pass

class NotFoundError(SimpleMLError):
    """Raised when a resource is not found."""
    pass

class ValidationError(SimpleMLError):
    """Raised when input validation fails."""
    pass

class APIError(SimpleMLError):
    """Raised when API request fails."""
    pass

class ConfigurationError(SimpleMLError):
    """Raised when configuration is invalid."""
    pass