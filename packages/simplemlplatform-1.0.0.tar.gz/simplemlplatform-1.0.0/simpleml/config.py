"""
Configuration management for SimpleML SDK.
"""

import os
import boto3
from typing import Optional
from .client import SimpleMLClient
from .exceptions import ConfigurationError


def configure(
    stack_name: Optional[str] = None,
    region: Optional[str] = None,
    api_endpoint: Optional[str] = None,
    api_key: Optional[str] = None,
    tenant_id: Optional[str] = None
) -> SimpleMLClient:
    """
    Configure the SimpleML SDK.
    
    Args:
        stack_name: CloudFormation stack name for auto-configuration
        region: AWS region (defaults to current session region)
        api_endpoint: API endpoint URL (manual configuration)
        api_key: API key for authentication
        tenant_id: Tenant ID (optional, usually derived from API key)
    
    Returns:
        Configured SimpleMLClient instance
    """
    
    # Check environment variables first
    stack_name = stack_name or os.getenv('SIMPLEML_STACK_NAME')
    region = region or os.getenv('AWS_DEFAULT_REGION', 'eu-west-1')
    api_endpoint = api_endpoint or os.getenv('SIMPLEML_API_ENDPOINT')
    api_key = api_key or os.getenv('SIMPLEML_API_KEY')
    tenant_id = tenant_id or os.getenv('SIMPLEML_TENANT_ID')
    
    # Auto-configuration from CloudFormation stack
    if stack_name:
        try:
            cf_client = boto3.client('cloudformation', region_name=region)
            
            # Get stack outputs
            response = cf_client.describe_stacks(StackName=stack_name)
            stack = response['Stacks'][0]
            
            outputs = {output['OutputKey']: output['OutputValue'] 
                      for output in stack.get('Outputs', [])}
            
            # Extract SDK endpoint
            if 'SdkEndpoint' in outputs:
                api_endpoint = outputs['SdkEndpoint']
            elif 'ApiEndpoint' in outputs:
                api_endpoint = outputs['ApiEndpoint']
            else:
                raise ConfigurationError(f"No API endpoint found in stack {stack_name} outputs")
            
            # Try to get stack info endpoint for configuration validation
            if api_endpoint and not api_key:
                # We can still make public API calls to get stack info
                pass
                
        except Exception as e:
            if 'does not exist' in str(e):
                raise ConfigurationError(f"CloudFormation stack '{stack_name}' not found in region {region}")
            else:
                raise ConfigurationError(f"Failed to auto-configure from stack {stack_name}: {e}")
    
    # Validate configuration
    if not api_endpoint:
        raise ConfigurationError(
            "API endpoint not configured. Either provide 'stack_name' for auto-configuration "
            "or set 'api_endpoint' manually."
        )
    
    if not api_key:
        # Check if we can get it from the public stack info endpoint
        if stack_name:
            print(f"⚠️  No API key provided. You'll need to create one through the web UI.")
            print(f"   Stack: {stack_name}")
            print(f"   Region: {region}")
        else:
            raise ConfigurationError(
                "API key not configured. Set 'api_key' parameter or SIMPLEML_API_KEY environment variable."
            )
    
    return SimpleMLClient(
        api_endpoint=api_endpoint,
        api_key=api_key,
        tenant_id=tenant_id
    )


def get_client() -> SimpleMLClient:
    """Get the current SimpleML client."""
    # This will be implemented by the main module
    raise NotImplementedError("Use simpleml.get_client() instead")