"""
Experiment class for SimpleML SDK.
"""

from typing import Dict, List, Optional, Any
from .run import Run


class Experiment:
    """Represents an ML experiment."""
    
    def __init__(self, client, experiment_id: str, name: str, description: Optional[str] = None,
                 tags: Optional[Dict[str, str]] = None, created_at: Optional[str] = None, **kwargs):
        """
        Initialize Experiment.
        
        Args:
            client: SimpleMLClient instance
            experiment_id: Unique experiment identifier
            name: Experiment name
            description: Optional description
            tags: Optional tags
            created_at: Creation timestamp
        """
        self.client = client
        self.experiment_id = experiment_id
        self.name = name
        self.description = description
        self.tags = tags or {}
        self.created_at = created_at
    
    def start_run(self, name: Optional[str] = None, hyperparameters: Optional[Dict[str, Any]] = None,
                  tags: Optional[Dict[str, str]] = None) -> Run:
        """
        Start a new run in this experiment.
        
        Args:
            name: Optional run name
            hyperparameters: Optional hyperparameters
            tags: Optional tags
            
        Returns:
            Run instance
        """
        return self.client.create_run(
            experiment_id=self.experiment_id,
            name=name,
            hyperparameters=hyperparameters,
            tags=tags
        )
    
    def list_runs(self) -> List[Run]:
        """List all runs in this experiment."""
        return self.client._list_experiment_runs(self.experiment_id)
    
    def __repr__(self) -> str:
        return f"Experiment(id='{self.experiment_id}', name='{self.name}')"
    
    def __str__(self) -> str:
        return f"Experiment '{self.name}' ({self.experiment_id})"