"""
SimpleML API client.
"""

import os
import json
import time
from typing import Dict, List, Optional, Any, Union
from urllib.parse import urljoin
import requests
from ulid import ULID
from .exceptions import SimpleMLError, AuthenticationError, NotFoundError, APIError
from .experiment import Experiment
from .run import Run


class SimpleMLClient:
    """Main client for interacting with SimpleML API."""
    
    def __init__(self, api_endpoint: str, api_key: Optional[str] = None, tenant_id: Optional[str] = None):
        """
        Initialize SimpleML client.
        
        Args:
            api_endpoint: Base URL for the SimpleML API
            api_key: API key for authentication
            tenant_id: Tenant ID (optional, usually derived from API key)
        """
        self.api_endpoint = api_endpoint.rstrip('/')
        self.api_key = api_key
        self.tenant_id = tenant_id
        self.session = requests.Session()
        
        # Set default headers
        if api_key:
            self.session.headers.update({
                'x-api-key': api_key,  # AWS API Gateway standard header
                'Content-Type': 'application/json'
            })
    
    def _make_request(self, method: str, path: str, **kwargs) -> requests.Response:
        """Make HTTP request to the API."""
        url = urljoin(self.api_endpoint + '/', path.lstrip('/'))
        
        try:
            response = self.session.request(method, url, **kwargs)
            
            # Handle authentication errors
            if response.status_code == 401:
                error_data = response.json() if response.content else {}
                raise AuthenticationError(error_data.get('error', 'Authentication failed'))
            
            # Handle not found errors
            if response.status_code == 404:
                error_data = response.json() if response.content else {}
                raise NotFoundError(error_data.get('error', 'Resource not found'))
            
            # Handle other client/server errors
            if not response.ok:
                try:
                    error_data = response.json()
                    error_message = error_data.get('error', f'HTTP {response.status_code}')
                except:
                    error_message = f'HTTP {response.status_code}: {response.text}'
                
                raise APIError(f"API request failed: {error_message}")
            
            return response
            
        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error: {e}")
    
    def _get(self, path: str, **kwargs) -> Dict[str, Any]:
        """Make GET request and return JSON response."""
        response = self._make_request('GET', path, **kwargs)
        return response.json()
    
    def _post(self, path: str, data: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make POST request and return JSON response."""
        if data:
            kwargs['json'] = data
        response = self._make_request('POST', path, **kwargs)
        return response.json()
    
    def _put(self, path: str, data: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make PUT request and return JSON response."""
        if data:
            kwargs['json'] = data
        response = self._make_request('PUT', path, **kwargs)
        return response.json()
    
    def _delete(self, path: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Make DELETE request and return JSON response if any."""
        response = self._make_request('DELETE', path, **kwargs)
        return response.json() if response.content else None
    
    # Experiment methods
    def get_or_create_experiment(self, name: str, description: Optional[str] = None, 
                                tags: Optional[Dict[str, str]] = None) -> Experiment:
        """Get existing experiment by name or create if it doesn't exist."""
        # First try to find existing experiment by name
        try:
            experiments = self.list_experiments()
            for exp in experiments:
                if exp.name == name:
                    # Found existing experiment - update description/tags if provided
                    if description or tags:
                        # Note: Backend would need update_experiment endpoint for this
                        pass
                    return exp
        except Exception as e:
            # If listing fails, continue to creation
            pass
        
        # Experiment doesn't exist, create it
        data = {
            'name': name,
            'description': description,
            'tags': tags or {}
        }
        
        response = self._post('/api/sdk/experiments', data)
        experiment_data = response['experiment']
        return Experiment(client=self, **experiment_data)

    
    def get_experiment(self, experiment_id: str) -> Experiment:
        """Get experiment by ID."""
        response = self._get(f'/api/sdk/experiments/{experiment_id}')
        experiment_data = response['experiment']
        return Experiment(client=self, **experiment_data)
    
    def list_experiments(self) -> List[Experiment]:
        """List all experiments."""
        response = self._get('/api/sdk/experiments')
        experiments = response['experiments']
        return [Experiment(client=self, **exp) for exp in experiments]
    
    # Run methods
    def create_run(self, experiment_id: str, name: Optional[str] = None,
                   hyperparameters: Optional[Dict[str, Any]] = None,
                   tags: Optional[Dict[str, str]] = None) -> Run:
        """Create a new run."""
        # Generate ULID if no name provided (sortable by creation time)
        if name is None:
            name = str(ULID())
            
        data = {
            'name': name,
            'hyperparameters': hyperparameters or {},
            'tags': tags or {}
        }
        
        response = self._post(f'/api/sdk/experiments/{experiment_id}/runs', data)
        run_data = response['run']
        return Run(client=self, **run_data)
    
    def get_run(self, run_id: str) -> Run:
        """Get run by ID."""
        response = self._get(f'/api/sdk/runs/{run_id}')
        run_data = response['run']
        return Run(client=self, **run_data)
    
    def complete_run(self, run_id: str, status: str = 'COMPLETED') -> Dict[str, Any]:
        """Mark a run as completed."""
        data = {'status': status}
        return self._put(f'/api/sdk/runs/{run_id}/complete', data)
    
    # Metrics methods
    def log_metrics(self, run_id: str, metrics: Dict[str, float], step: Optional[int] = None) -> Dict[str, Any]:
        """Log metrics for a run."""
        data = {
            'metrics': metrics,
            'step': step
        }
        return self._post(f'/api/sdk/runs/{run_id}/metrics', data)
    
    def _get_run_metrics(self, run_id: str) -> Dict[str, List[Dict[str, Any]]]:
        """Get all metrics for a run (internal method)."""
        response = self._get(f'/api/sdk/runs/{run_id}/metrics')
        return response.get('metrics', {})
    
    def _list_experiment_runs(self, experiment_id: str) -> List[Run]:
        """List all runs for an experiment (internal method)."""
        # This would use a backend endpoint to get runs for the experiment
        # For now, we'll make a simple implementation
        response = self._get(f'/api/sdk/experiments/{experiment_id}/runs')
        runs_data = response.get('runs', [])
        return [Run(client=self, **run_data) for run_data in runs_data]
    
    # Artifact methods
    def get_upload_url(self, run_id: str, filename: str, artifact_type: str = 'unknown') -> Dict[str, Any]:
        """Get presigned URL for artifact upload."""
        data = {
            'filename': filename,
            'artifact_type': artifact_type
        }
        return self._post(f'/api/sdk/runs/{run_id}/artifacts/upload', data)
    
    def list_artifacts(self, run_id: str) -> List[Dict[str, Any]]:
        """List artifacts for a run."""
        response = self._get(f'/api/sdk/runs/{run_id}/artifacts')
        return response['artifacts']
    
    def get_download_url(self, artifact_id: str) -> str:
        """Get presigned URL for artifact download."""
        response = self._get(f'/api/sdk/artifacts/{artifact_id}/download')
        return response['download_url']
    
    # Model registry methods
    def register_model(self, model_name: str, run_id: str, artifacts: List[str],
                      description: Optional[str] = None, tags: Optional[Dict[str, str]] = None,
                      stage: str = 'staging') -> Dict[str, Any]:
        """Register a model in the model registry."""
        data = {
            'model_name': model_name,
            'run_id': run_id,
            'artifacts': artifacts,
            'description': description,
            'tags': tags or {},
            'stage': stage
        }
        response = self._post('/api/sdk/models/register', data)
        return response['model_version']
    
    def list_models(self) -> List[Dict[str, Any]]:
        """List all registered models."""
        response = self._get('/api/sdk/models')
        return response['models']
    
    def update_model_stage(self, model_name: str, version: str, stage: str) -> Dict[str, Any]:
        """Update a model version's stage."""
        data = {'stage': stage}
        return self._put(f'/api/sdk/models/{model_name}/{version}/stage', data)
    
    # Convenience methods
    def start_run(self, experiment_name_or_id: str, name: Optional[str] = None,
                  hyperparameters: Optional[Dict[str, Any]] = None,
                  tags: Optional[Dict[str, str]] = None) -> Run:
        """Start a new run in an experiment (by name or ID)."""
        # Try to get experiment by ID first
        try:
            experiment = self.get_experiment(experiment_name_or_id)
        except NotFoundError:
            # Try to find by name
            experiments = self.list_experiments()
            matching = [exp for exp in experiments if exp.name == experiment_name_or_id]
            
            if not matching:
                raise NotFoundError(f"Experiment not found: {experiment_name_or_id}")
            elif len(matching) > 1:
                raise SimpleMLError(f"Multiple experiments found with name: {experiment_name_or_id}")
            
            experiment = matching[0]
        
        return experiment.start_run(name, hyperparameters, tags)
    
    def health_check(self) -> Dict[str, Any]:
        """Check API health."""
        return self._get('/api/public/health')
    
    def get_stack_info(self) -> Dict[str, Any]:
        """Get stack information for configuration."""
        return self._get('/api/public/stack-info')