from nornir_srl import __version__


def test_version():
    assert __version__ == "0.2.22"
