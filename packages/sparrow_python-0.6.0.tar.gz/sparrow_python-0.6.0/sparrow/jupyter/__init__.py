from .utils import display_np_arrays
