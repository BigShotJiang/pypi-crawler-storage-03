from .core import expand_template, Substituter
