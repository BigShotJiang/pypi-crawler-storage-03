[**English**](./README_ZH.md) | **中文**

<h1 align="center">
    <br>
    {{project_name}}
    <br>
</h1>
<p align="center">
    <b> {{project_name}} <br/>
    The fastest way to ... </b>
</p>

<p align="center">
    <a href="https://pypi.org/project/{{project_name}}/"><img src="https://img.shields.io/pypi/v/{{project_name}}?color=brightgreen" alt="PyPI version" ></a>
    <a href="https://github.com/beidongjiedeguang/{{project_name}}/blob/main/LICENSE">
        <img alt="License" src="https://img.shields.io/github/license/beidongjiedeguang/{{project_name}}.svg?color=blue&style=flat-square">
    </a>
    <a href="https://github.com/beidongjiedeguang/{{project_name}}/releases">
        <img alt="Release (latest by date)" src="https://img.shields.io/github/v/release/beidongjiedeguang/{{project_name}}">
    </a>
    <a href="https://github.com/beidongjiedeguang/{{project_name}}">
        <img alt="GitHub repo size" src="https://img.shields.io/github/repo-size/beidongjiedeguang/{{project_name}}">
    </a>
    <a href="https://hub.docker.com/r/beidongjiedeguang/{{project_name}}">
        <img alt="docer image size" src="https://img.shields.io/docker/image-size/beidongjiedeguang/{{project_name}}?style=flat&label=docker image">
    </a>
    <a href="https://github.com/beidongjiedeguang/{{project_name}}/actions/workflows/run_tests.yaml">
        <img alt="tests" src="https://img.shields.io/github/actions/workflow/status/beidongjiedeguang/{{project_name}}/run_tests.yml?label=tests">
    </a>
    <a href="https://pypi.org/project/{{project_name}}/">
        <img alt="pypi downloads" src="https://img.shields.io/pypi/dm/{{project_name}}">
    </a>

</p>