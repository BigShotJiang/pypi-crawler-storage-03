.. xof documentation master file, created by
   sphinx-quickstart on Sat Jul 27 23:21:22 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.md
   :parser: myst_parser.sphinx_

