# Classify

::: pkglite.classify
    options:
      members:
        - is_text_file
        - classify_file
      show_root_heading: true
      show_source: false
