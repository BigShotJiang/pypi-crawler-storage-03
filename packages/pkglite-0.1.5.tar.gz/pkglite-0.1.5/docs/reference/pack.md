# Pack

::: pkglite.pack
    options:
      members:
        - pack
      show_root_heading: true
      show_source: false
