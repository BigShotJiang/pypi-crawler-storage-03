"""Tests for cache providers."""
