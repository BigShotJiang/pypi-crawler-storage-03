import unittest


class TestClients(unittest.TestCase):
    def test_aways_true(self) -> None:
        self.assertTrue(True)
