import pytest
import os
import tempfile
import zipfile
from unittest.mock import Mock, patch, PropertyMock
from pathlib import Path
from docx import Document as DocxDocument
from docx.shared import Inches
from docx.text.paragraph import Paragraph
from docx.table import Table, _Cell
from docx.oxml.text.paragraph import CT_P
from docx.oxml.table import CT_Tbl, CT_TcPr
from lxml import etree
import docx.parts.image
from src.raw_docx.raw_docx import RawDocx
from src.raw_docx.raw_document import RawDocument


@pytest.fixture
def raw_docx():
    return RawDocx("tests/test_files/example_1.docx")


@pytest.fixture
def temp_docx(tmp_path):
    """Create a test docx file with various content"""
    doc_path = tmp_path / "test.docx"
    doc = DocxDocument()

    # Add regular paragraph
    doc.add_paragraph("Regular paragraph")

    # Add list items using standard list style
    doc.add_paragraph("First bullet point", style="List Bullet")
    doc.add_paragraph("Second bullet point", style="List Bullet")

    # Add table with merged cells
    table = doc.add_table(rows=2, cols=2)
    table.cell(0, 0).merge(table.cell(0, 1))  # Merge first row
    table.cell(0, 0).text = "Merged cell"
    table.cell(1, 0).text = "Cell 1"
    table.cell(1, 1).text = "Cell 2"

    # Add image if test file exists
    image_path = os.path.join(os.path.dirname(__file__), "test_files", "test_image.png")
    if os.path.exists(image_path):
        doc.add_picture(image_path, width=Inches(1.0))

    # Save the document
    doc.save(doc_path)
    return str(doc_path)


@pytest.fixture
def simple_docx(tmp_path):
    """Create a simple test docx file"""
    doc_path = tmp_path / "simple_test.docx"
    doc = DocxDocument()
    doc.add_paragraph("Simple paragraph")
    doc.save(doc_path)
    return str(doc_path)


# Integration Tests
def test_to_dict_with_document(raw_docx):
    """Test converting RawDocx to dictionary with loaded document"""
    result = raw_docx.to_dict()
    assert result["type"] == "raw_docx"
    assert result["document"] is not None
    assert result["document"]["type"] == "document"
    assert isinstance(result["document"]["sections"], list)


def test_initialization_and_processing(temp_docx):
    """Test document initialization and processing"""
    from raw_docx.raw_document import RawDocument
    docx = RawDocx(temp_docx)
    assert os.path.exists(docx.image_path)
    assert isinstance(docx.target_document, RawDocument)
    assert len(docx.target_document.sections) > 0


def test_table_processing(temp_docx):
    """Test table processing with merged cells"""
    docx = RawDocx(temp_docx)
    tables = docx.target_document.sections[0].tables()
    assert len(tables) > 0

    # Check merged cells
    first_table = tables[0]
    first_row = first_table.rows[0]
    assert len(first_row.cells) == 2
    assert first_row.cells[0].h_span == 2  # Horizontally merged
    assert first_row.cells[0].first is True
    assert first_row.cells[1].first is False


def test_image_processing(temp_docx):
    """Test image extraction and processing"""
    docx = RawDocx(temp_docx)

    # Check if image directory was created
    assert os.path.exists(docx.image_path)

    # Check if image is referenced in document
    image_path = os.path.join(os.path.dirname(__file__), "test_files", "test_image.png")
    if os.path.exists(image_path):
        found_image = False
        for section in docx.target_document.sections:
            for item in section.items:
                if hasattr(item, "filepath") and item.filepath.endswith(
                    (".png", ".jpg", ".jpeg")
                ):
                    found_image = True
                    break
        assert found_image, "Image not found in document"


def test_error_handling(tmp_path):
    """Test error handling for invalid files and directories"""
    # Test with non-existent file
    with pytest.raises(Exception):
        RawDocx(str(tmp_path / "nonexistent.docx"))

    # Test with invalid file format
    invalid_file = tmp_path / "invalid.txt"
    invalid_file.write_text("Not a docx file")
    with pytest.raises(Exception):
        RawDocx(str(invalid_file))


# Coverage Tests - Error Handling and Edge Cases
def test_organise_dir_permission_error(simple_docx):
    """Test _organise_dir with permission error"""
    with patch('os.mkdir', side_effect=PermissionError("Permission denied")):
        with patch.object(RawDocx, '_process'):
            docx = RawDocx.__new__(RawDocx)
            docx.errors = Mock()
            docx.image_path = "/some/path"
            docx._organise_dir()
            docx.errors.exception.assert_called_once()


def test_process_exception_handling(simple_docx):
    """Test _process with exception in processing"""
    with patch.object(RawDocx, '_organise_dir'):
        with patch.object(RawDocx, '_process_images'):
            docx = RawDocx.__new__(RawDocx)
            docx.errors = Mock()
            docx.target_document = Mock()
            docx.target_document.current_section.return_value = Mock()
            
            with patch.object(docx, '_iter_block_items', side_effect=Exception("Test error")):
                docx._process()
                docx.errors.exception.assert_called()


# Coverage Tests - _is_heading Method
def test_is_heading_comprehensive(simple_docx):
    """Test _is_heading method comprehensively"""
    docx = RawDocx(simple_docx)
    
    # Test valid patterns
    assert docx._is_heading("Heading 1") == (True, 1)
    assert docx._is_heading("Heading 2") == (True, 2)
    assert docx._is_heading("heading 3") == (True, 3)  # Case insensitive
    assert docx._is_heading("HEADING 10") == (True, 10)
    assert docx._is_heading("Some text with Heading 5 in it") == (True, 5)
    assert docx._is_heading("Heading   7") == (True, 7)  # Multiple spaces
    
    # Test invalid patterns
    assert docx._is_heading("Not a heading") == (False, 0)
    assert docx._is_heading("Header 1") == (False, 0)
    assert docx._is_heading("Heading") == (False, 0)
    assert docx._is_heading("Heading abc") == (False, 0)
    assert docx._is_heading("1 Heading") == (False, 0)
    
    # Test edge cases
    assert docx._is_heading("") == (False, 0)
    assert docx._is_heading(None) == (False, 0)


# Coverage Tests - List Processing
def test_get_list_level_with_mock(simple_docx):
    """Test get_list_level with properly mocked paragraph"""
    docx = RawDocx(simple_docx)
    
    # Create mock paragraph with _p attribute
    mock_paragraph = Mock()
    mock_p = Mock()
    mock_p.xpath.return_value = ['2']
    mock_paragraph._p = mock_p
    
    level = docx.get_list_level(mock_paragraph)
    assert level == 2
    
    # Test with no level
    mock_p.xpath.return_value = []
    level = docx.get_list_level(mock_paragraph)
    assert level == 0


def test_is_list_comprehensive(simple_docx):
    """Test _is_list method comprehensively"""
    docx = RawDocx(simple_docx)
    
    # Test with xpath level
    mock_paragraph = Mock()
    mock_p = Mock()
    mock_p.xpath.return_value = ['1']
    mock_paragraph._p = mock_p
    mock_paragraph.style = Mock()
    mock_paragraph.style.name = "Normal"
    mock_paragraph.text = "Regular text"
    
    result = docx._is_list(mock_paragraph)
    assert result is True
    
    # Test with bullet styles
    mock_p.xpath.return_value = []
    mock_paragraph.style.name = "CPT_List Bullet"
    result = docx._is_list(mock_paragraph)
    assert result is True
    
    mock_paragraph.style.name = "List Bullet"
    result = docx._is_list(mock_paragraph)
    assert result is True
    
    # Test with bullet character
    mock_paragraph.style.name = "Normal"
    mock_paragraph.text = "• Bullet point"
    result = docx._is_list(mock_paragraph)
    assert result is True
    
    # Test false cases
    mock_paragraph.text = "Regular text"
    result = docx._is_list(mock_paragraph)
    assert result is False
    
    mock_paragraph.text = ""
    result = docx._is_list(mock_paragraph)
    assert result is False
    
    mock_paragraph.text = None
    result = docx._is_list(mock_paragraph)
    assert result is False


# Coverage Tests - Image Processing
def test_extract_images_with_media(simple_docx):
    """Test _extract_images when zipfile contains media files"""
    docx = RawDocx.__new__(RawDocx)
    docx.full_path = simple_docx
    docx.image_path = "/tmp/test_images"
    
    # Create mock zipfile with media files
    mock_file = Mock()
    mock_file.filename = "word/media/image1.png"
    
    mock_archive = Mock()
    mock_archive.filelist = [mock_file]
    
    # Mock the context manager for archive.open
    mock_source = Mock()
    mock_source.read.return_value = b"fake image data"
    mock_archive.open.return_value.__enter__ = Mock(return_value=mock_source)
    mock_archive.open.return_value.__exit__ = Mock(return_value=None)
    
    # Mock the file writing
    mock_target = Mock()
    mock_target.__enter__ = Mock(return_value=mock_target)
    mock_target.__exit__ = Mock(return_value=None)
    mock_target.write = Mock()
    
    with patch('zipfile.ZipFile', return_value=mock_archive):
        with patch('builtins.open', return_value=mock_target):
            docx._extract_images()
            # Should have tried to extract the image
            mock_archive.open.assert_called()


# Coverage Tests - Utility Methods
def test_tree_method(simple_docx):
    """Test _tree method with nested children"""
    docx = RawDocx(simple_docx)
    
    # Create nested mock structure
    grandchild = Mock()
    grandchild.__iter__ = Mock(return_value=iter([]))
    
    child = Mock()
    child.__iter__ = Mock(return_value=iter([grandchild]))
    
    root = Mock()
    root.__iter__ = Mock(return_value=iter([child]))
    
    # Should traverse the tree without errors
    docx._tree(root)


def test_to_dict_edge_cases(simple_docx):
    """Test to_dict method edge cases"""
    # Test without target_document attribute
    docx = RawDocx.__new__(RawDocx)
    result = docx.to_dict()
    assert result == {"type": "raw_docx", "document": None}
    
    # Test with target_document that doesn't have to_dict method
    docx.target_document = "not a proper document"
    result = docx.to_dict()
    assert result == {"type": "raw_docx", "document": None}
    
    # Test with proper target_document
    docx = RawDocx(simple_docx)
    result = docx.to_dict()
    assert result["type"] == "raw_docx"
    assert result["document"] is not None
    assert isinstance(result["document"], dict)


def test_iter_block_items_string_handling(simple_docx):
    """Test _iter_block_items handles string children gracefully"""
    docx = RawDocx(simple_docx)
    
    # Mock iterchildren to return a string (should be handled gracefully)
    with patch.object(docx.source_document.element.body, 'iterchildren', return_value=["string_child"]):
        items = list(docx._iter_block_items(docx.source_document))
        # Should handle gracefully and continue without error


def test_process_table_bottom_exception(simple_docx):
    """Test _process_table when accessing bottom raises exception"""
    docx = RawDocx(simple_docx)
    
    # Create a mock table structure
    mock_table = Mock()
    mock_row = Mock()
    mock_cell = Mock()
    mock_tc = Mock()
    mock_tc.right = 2
    mock_tc.left = 1
    mock_tc.top = 1
    
    # Make bottom property raise an exception
    type(mock_tc).bottom = PropertyMock(side_effect=Exception("Bottom error"))
    mock_cell._tc = mock_tc
    mock_row.cells = [mock_cell]
    mock_table.rows = [mock_row]
    
    with patch.object(docx, '_iter_block_items', return_value=[]):
        target_section = docx.target_document.current_section()
        # Should handle the exception and set bottom = top + 1
        docx._process_table(mock_table, target_section)


def test_logic_error_exception():
    """Test LogicError exception can be raised"""
    with pytest.raises(RawDocx.LogicError):
        raise RawDocx.LogicError("Test error")


# Additional Coverage Tests for Missing Lines
def test_process_with_unknown_block_item(simple_docx):
    """Test _process with unknown block item type (lines 66-67)"""
    with patch.object(RawDocx, '_organise_dir'):
        with patch.object(RawDocx, '_process_images'):
            docx = RawDocx.__new__(RawDocx)
            docx.errors = Mock()
            docx.target_document = Mock()
            docx.target_document.current_section.return_value = Mock()
            
            # Mock _iter_block_items to return unknown type that will trigger warning and ValueError
            unknown_item = 123  # Not a Paragraph or Table
            with patch.object(docx, '_iter_block_items', return_value=[unknown_item]):
                docx._process()
                # Should catch the exception and log it
                docx.errors.exception.assert_called()




def test_process_table_with_invalid_child_type(simple_docx):
    """Test _process_table with invalid child type (lines 153-163)"""
    docx = RawDocx(simple_docx)
    
    mock_table = Mock()
    mock_row = Mock()
    mock_cell = Mock()
    mock_tc = Mock()
    mock_tc.right = 2
    mock_tc.left = 1
    mock_tc.top = 1
    mock_tc.bottom = 2
    mock_cell._tc = mock_tc
    mock_row.cells = [mock_cell]
    mock_table.rows = [mock_row]
    
    # Return invalid child type
    invalid_child = "invalid_type"
    
    with patch.object(docx, '_iter_block_items', return_value=[invalid_child]):
        target_section = docx.target_document.current_section()
        with pytest.raises(RawDocx.LogicError, match="something's not right with a child"):
            docx._process_table(mock_table, target_section)


def test_process_paragraph_with_graphic_and_matching_rid(simple_docx):
    """Test _process_paragraph with graphic containing matching rId (lines 198-201)"""
    docx = RawDocx(simple_docx)
    
    # Create mock paragraph with graphic
    mock_paragraph = Mock(spec=Paragraph)
    mock_paragraph.style = Mock()
    mock_paragraph.style.name = "Normal"
    mock_paragraph._p = Mock()
    mock_paragraph._p.xml = "Some xml content with rId1 reference and Graphic"
    mock_paragraph.extract_runs.return_value = []
    
    target_section = Mock()
    image_rels = {"rId1": "/path/to/image.png"}
    
    with patch.object(docx, '_is_heading', return_value=(False, 0)):
        with patch.object(docx, '_is_list', return_value=False):
            with patch('src.raw_docx.raw_docx.RawImage') as mock_image_class:
                mock_image = Mock()
                mock_image_class.return_value = mock_image
                
                docx._process_paragraph(mock_paragraph, target_section, image_rels)
                # Should have created and added image
                mock_image_class.assert_called_with("/path/to/image.png", docx.errors)
                target_section.add.assert_called_with(mock_image)


def test_is_heading_with_exception_handling(simple_docx):
    """Test _is_heading exception handling (line 230-231)"""
    docx = RawDocx(simple_docx)
    
    # Mock re.search to return a match but int() raises ValueError
    with patch('src.raw_docx.raw_docx.re.search') as mock_search:
        mock_match = Mock()
        mock_match.group.side_effect = ValueError("Invalid conversion")
        mock_search.return_value = mock_match
        
        result = docx._is_heading("Heading 1")
        # Should return (True, 0) when exception occurs during conversion
        assert result == (True, 0)


def test_is_heading_with_index_error(simple_docx):
    """Test _is_heading with IndexError (line 230-231)"""
    docx = RawDocx(simple_docx)
    
    with patch('src.raw_docx.raw_docx.re.search') as mock_search:
        mock_match = Mock()
        mock_match.group.side_effect = IndexError("Index error")
        mock_search.return_value = mock_match
        
        result = docx._is_heading("Heading 1")
        # Should return (True, 0) when IndexError occurs
        assert result == (True, 0)


def test_process_images_with_image_part(simple_docx):
    """Test _process_images when document has image parts (line 76)"""
    raw_docx_instance = RawDocx.__new__(RawDocx)
    raw_docx_instance.errors = Mock()
    raw_docx_instance.image_path = "/tmp/test"
    raw_docx_instance.image_rels = {}
    
    # Mock source document with image parts
    mock_source_doc = Mock()
    mock_part = Mock()
    mock_rels = Mock()
    
    # Create mock image part
    import docx.parts.image
    mock_image_part = Mock(spec=docx.parts.image.ImagePart)
    mock_image_part.partname = "/word/media/image1.png"
    
    mock_rel = Mock()
    mock_rel._target = mock_image_part
    mock_rel.rId = "rId1"
    
    mock_rels.values.return_value = [mock_rel]
    mock_part.rels = mock_rels
    mock_source_doc.part = mock_part
    raw_docx_instance.source_document = mock_source_doc
    
    with patch.object(raw_docx_instance, '_extract_images'):
        raw_docx_instance._process_images()
        # Should have added image to image_rels
        assert "rId1" in raw_docx_instance.image_rels
        assert raw_docx_instance.image_rels["rId1"].endswith("image1.png")


def test_iter_block_items_invalid_parent(simple_docx):
    """Test _iter_block_items with invalid parent type (line 93)"""
    docx = RawDocx(simple_docx)
    
    # Test with invalid parent type
    invalid_parent = "not_a_document_or_cell"
    
    with pytest.raises(ValueError, match="something's not right with the parent"):
        list(docx._iter_block_items(invalid_parent))


def test_iter_block_items_unknown_child_type(simple_docx):
    """Test _iter_block_items with unknown child type (line 117)"""
    from docx.document import Document
    docx = RawDocx(simple_docx)
    
    # Mock document with unknown child type
    mock_doc = Mock(spec=Document)
    mock_body = Mock()
    
    # Create unknown child type
    unknown_child = Mock()
    unknown_child.__class__ = type('UnknownType', (), {})
    
    mock_body.iterchildren.return_value = [unknown_child]
    mock_doc.element = Mock()
    mock_doc.element.body = mock_body
    
    with pytest.raises(ValueError, match="something's not right with a child"):
        list(docx._iter_block_items(mock_doc))


def test_process_table_cell_none(simple_docx):
    """Test _process_table when cell._tc is None (lines 145-146)"""
    docx = RawDocx(simple_docx)
    
    # Create mock table with cell._tc = None
    mock_table = Mock()
    mock_row = Mock()
    mock_cell = Mock()
    mock_cell._tc = None  # This triggers lines 145-146
    # Need to mock the attributes that are accessed when _tc is None
    mock_cell.top = 0
    mock_cell.left = 0
    mock_row.cells = [mock_cell]
    mock_table.rows = [mock_row]
    
    with patch.object(docx, '_iter_block_items', return_value=[]):
        target_section = docx.target_document.current_section()
        docx._process_table(mock_table, target_section)
        # Should handle None _tc and set default spans


def test_process_table_nested_table(simple_docx):
    """Test _process_table with nested table (line 154)"""
    docx = RawDocx(simple_docx)
    
    # Create mock table structure
    mock_table = Mock()
    mock_row = Mock()
    mock_cell = Mock()
    mock_tc = Mock()
    mock_tc.right = 2
    mock_tc.left = 1
    mock_tc.top = 1
    mock_tc.bottom = 2
    mock_cell._tc = mock_tc
    mock_row.cells = [mock_cell]
    mock_table.rows = [mock_row]
    
    # Create nested table
    nested_table = Mock(spec=Table)
    
    with patch.object(docx, '_iter_block_items', return_value=[nested_table]):
        target_section = docx.target_document.current_section()
        with pytest.raises(RawDocx.LogicError, match="Table within table detected"):
            docx._process_table(mock_table, target_section)


def test_process_table_with_etree_element_ct_tcpr(simple_docx):
    """Test _process_table with CT_TcPr etree element (lines 156-157)"""
    docx = RawDocx(simple_docx)
    
    # Create mock table structure
    mock_table = Mock()
    mock_row = Mock()
    mock_cell = Mock()
    mock_tc = Mock()
    mock_tc.right = 2
    mock_tc.left = 1
    mock_tc.top = 1
    mock_tc.bottom = 2
    mock_cell._tc = mock_tc
    mock_row.cells = [mock_cell]
    mock_table.rows = [mock_row]
    
    # Create etree element with CT_TcPr tag
    etree_element = Mock(spec=etree._Element)
    etree_element.tag = CT_TcPr
    
    with patch.object(docx, '_iter_block_items', return_value=[etree_element]):
        target_section = docx.target_document.current_section()
        # Should pass through CT_TcPr elements without error
        docx._process_table(mock_table, target_section)


def test_process_table_with_unknown_etree_element(simple_docx):
    """Test _process_table with unknown etree element (lines 158-159)"""
    docx = RawDocx(simple_docx)
    
    # Create mock table structure
    mock_table = Mock()
    mock_row = Mock()
    mock_cell = Mock()
    mock_tc = Mock()
    mock_tc.right = 2
    mock_tc.left = 1
    mock_tc.top = 1
    mock_tc.bottom = 2
    mock_cell._tc = mock_tc
    mock_row.cells = [mock_cell]
    mock_table.rows = [mock_row]
    
    # Create etree element with unknown tag
    etree_element = Mock(spec=etree._Element)
    etree_element.tag = "unknown_tag"
    
    with patch.object(docx, '_iter_block_items', return_value=[etree_element]):
        target_section = docx.target_document.current_section()
        with patch.object(docx.errors, 'warning') as mock_warning:
            docx._process_table(mock_table, target_section)
            # Should log warning for unknown etree element
            mock_warning.assert_called()
