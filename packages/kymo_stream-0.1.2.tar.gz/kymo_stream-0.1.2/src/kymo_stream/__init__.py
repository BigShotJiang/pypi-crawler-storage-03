"""Kymo Stream - Camera stream viewer."""

__version__ = "0.1.2"