from setuptools import setup

setup(
    name="envoyou",
    version="0.0.1",
    description="Placeholder for Envoyou package",
    py_modules=["envoyou"],
)
