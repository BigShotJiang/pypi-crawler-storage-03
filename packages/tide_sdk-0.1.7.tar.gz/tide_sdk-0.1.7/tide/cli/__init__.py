"""
Tide CLI module.
"""

from tide.cli.main import main, create_parser

__all__ = ['main', 'create_parser']
