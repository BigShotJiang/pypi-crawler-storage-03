# dms-variant
Lightweight parser of single- and multi-mutation variants in DMS experiment results.

HGVS-like but not strictly compliant.
