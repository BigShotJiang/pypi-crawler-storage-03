# Write it in 2025.8
# hi = "Hi, this module was made by me."
# my_feel_of_it = "I think that is nice."
# say_thanks = [None]
# version = "1.0.0"
# advice = ["Never run it", "advice[1] was joked by me"]
# print(f"{hi}\n{my_feel_of_it}\n Say /"thanks/" to {say_thanks}")