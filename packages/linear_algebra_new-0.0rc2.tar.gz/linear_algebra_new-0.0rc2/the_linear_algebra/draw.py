from the_2D.vector import Vector2D
from the_2D.matrix import Matrix2D


# 向量绘制功能
def draw_vector2D(vec: Vector2D, draw_speed: int = 0) -> None:
    """绘制二维向量"""
    from turtle import speed as set_speed, goto, penup, pendown, left, forward, write, home, pos, backward

    x = int(vec.x)

    set_speed(draw_speed)
    penup()
    home()  # 回到原点
    pendown()

    # 绘制向量线
    goto(float(x), float(vec.y))

    # 绘制箭头
    left(150)
    arrow_length = max(5, min(abs(x), abs(vec.y)) / 10)  # 箭头长度自适应
    forward(arrow_length)
    penup()
    backward(arrow_length)
    left(60)
    pendown()
    forward(arrow_length)

    # 标注坐标
    penup()
    goto(float(x) * 1.1, float(vec.y) * 1.1)  # 稍微偏移一点
    write(f"({vec.x}, {vec.y})")

    print(f"向量终点位置: {pos()}")
    penup()
    home()


def draw_matrix2D(mat: Matrix2D, draw_speed: int = 0) -> None:
    """绘制二维矩阵的行向量"""
    draw_vector2D(mat.i, draw_speed)
    draw_vector2D(mat.j, draw_speed)