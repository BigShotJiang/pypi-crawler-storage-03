---
name: Documentation request
about: Help us make the documentation better
title: "[DOC]"
labels: docs
assignees: ''

---

**What were you looking for/trying to do?**:

**What was missing from the docs or not clear enough?**:

**How could the docs be improved? Additional examples, different wording, etc.**
