---
name: "Release Reminder"
about: "Automated reminder to release a new xgcm version"
labels: "type: maintenance"
title: "Time to issue a new release"
---
This is a reminder to release a shiny new version of xgcm.

You can find instructions [here](https://xgcm.readthedocs.io/en/latest/contributor_guide.html#how-to-release-a-new-version-of-xgcm-for-maintainers-only).

@rabernat, @jbusecke, @TomNicholas
