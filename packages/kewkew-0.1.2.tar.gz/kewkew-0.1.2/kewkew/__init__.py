"""A tiny Queue library leveraging asyncio."""

from kewkew.kew import Kew

__all__ = ["Kew"]
