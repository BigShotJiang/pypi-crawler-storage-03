import unittest as ut


if __name__ == "__main__":
    ut.main(verbosity=2)
