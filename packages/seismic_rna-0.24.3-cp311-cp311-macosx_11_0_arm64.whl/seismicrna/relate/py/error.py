class RelateError(RuntimeError):
    """ Any error that occurs during the relate algorithm. """
