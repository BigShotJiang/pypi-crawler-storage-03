Boa Restrictor Linter
=====================

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   features/disclaimer.md
   features/configuration.md
   features/rules/python_rule_index.rst
   features/rules/django_rule_index.rst
   features/changelog.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
