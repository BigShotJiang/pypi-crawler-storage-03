Django rules
============

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   django/001_prohibit_assert_raises.md
   django/002_avoid_django_db_imports_in_views.md
   django/003_prohibit_assert_true_false.md
   django/004_prohibit_datetime_now.md
   django/005_avoid_django_db_imports_in_api.md
