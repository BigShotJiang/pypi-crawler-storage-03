from replan2eplus.ezobjects.base import EZObject
from dataclasses import dataclass

@dataclass
class Material(EZObject):
    pass