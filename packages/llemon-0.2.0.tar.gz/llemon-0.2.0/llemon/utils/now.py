import datetime as dt


def now() -> dt.datetime:
    return dt.datetime.now(dt.UTC)
