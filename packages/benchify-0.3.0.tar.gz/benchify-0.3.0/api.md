# Shared Types

```python
from benchify.types import ResponseMeta
```

# Fixer

Types:

```python
from benchify.types import DiagnosticResponse, FileChange, FixerRunResponse
```

Methods:

- <code title="post /v1/fixer">client.fixer.<a href="./src/benchify/resources/fixer.py">run</a>(\*\*<a href="src/benchify/types/fixer_run_params.py">params</a>) -> <a href="./src/benchify/types/fixer_run_response.py">FixerRunResponse</a></code>
