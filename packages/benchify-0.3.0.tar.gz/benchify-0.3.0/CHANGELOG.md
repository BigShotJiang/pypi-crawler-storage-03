# Changelog

## 0.3.0 (2025-08-18)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/Benchify/benchify-sdk-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([61c8d1b](https://github.com/Benchify/benchify-sdk-python/commit/61c8d1b4f0d79570c17ff2d70362d6f1d4dba623))

## 0.2.0 (2025-08-18)

Full Changelog: [v0.1.3...v0.2.0](https://github.com/Benchify/benchify-sdk-python/compare/v0.1.3...v0.2.0)

### Features

* **api:** api update ([d02ae03](https://github.com/Benchify/benchify-sdk-python/commit/d02ae03649ef0970a556c301f03279fcce34768a))
* **api:** api update ([429df1a](https://github.com/Benchify/benchify-sdk-python/commit/429df1a7e793d18ca7160acb424ef0f95d0fea54))
* **api:** api update ([d1e52a2](https://github.com/Benchify/benchify-sdk-python/commit/d1e52a2d248db65cfaea5e1f330043d71def9ab2))


### Chores

* **internal:** codegen related update ([3d981f1](https://github.com/Benchify/benchify-sdk-python/commit/3d981f1e780b2cf74fbe5c9244b3488c923d5518))

## 0.1.3 (2025-08-11)

Full Changelog: [v0.0.1...v0.1.3](https://github.com/Benchify/benchify-sdk-python/compare/v0.0.1...v0.1.3)

### Chores

* configure new SDK language ([b2947a6](https://github.com/Benchify/benchify-sdk-python/commit/b2947a6d28b64d77a43add29773e1f5044a4b793))
* update SDK settings ([6744a08](https://github.com/Benchify/benchify-sdk-python/commit/6744a084c082925416efd1f4eaf2a3fa6319a8fe))
* update SDK settings ([94d44df](https://github.com/Benchify/benchify-sdk-python/commit/94d44dfa86ec52e67c81c1bce48f7551cdd2e551))
