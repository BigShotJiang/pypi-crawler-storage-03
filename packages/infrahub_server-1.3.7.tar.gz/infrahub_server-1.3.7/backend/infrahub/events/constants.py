EVENT_NAMESPACE = "infrahub"
