# aiohttp request extension.

## Installation

You can install via [pypi](https://pypi.org/project/aiohttp_client_request/)

```console
pip install -U aiohttp_client_request
```

## Usage

```python
from aiohttp_client_request import request
```
