"""PyVista plugin for static type-checking with mypy."""
