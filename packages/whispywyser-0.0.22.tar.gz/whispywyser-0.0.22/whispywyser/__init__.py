"""Wyoming server for WhispyWyser."""
__version__ = "0.0.22"
__all__ = ["__version__"]
