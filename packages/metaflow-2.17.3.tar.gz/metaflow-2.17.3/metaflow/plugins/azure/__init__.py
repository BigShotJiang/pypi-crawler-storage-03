from .azure_credential import (
    create_cacheable_azure_credential as create_azure_credential,
)
