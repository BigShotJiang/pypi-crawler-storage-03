'''
Home for platform specific code such as thishost info.

*all* platform modules *must* be importable from any platform.

( guard any platform specific code with appropriate conditionals )

'''
