import logging

logger = logging.getLogger(__name__)

def initHostInfo():
    return {
        'format': 'elf',
        'platform': 'freebsd',
    }
