from .tts import LMNTTTS
 
__all__ = [
    'LMNTTTS',
] 