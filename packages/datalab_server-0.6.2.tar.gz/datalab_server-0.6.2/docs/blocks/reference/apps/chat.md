title: Whinchat (LLM assistant)
::: pydatalab.apps.chat
