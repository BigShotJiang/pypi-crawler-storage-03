# Single Sign-On

Synapse supports single sign-on through the SAML, Open ID Connect or CAS protocols. 
LDAP and other login methods are supported through first and third-party password
auth provider modules.