# Define the version number
__version__ = "1.0.0rc5"
