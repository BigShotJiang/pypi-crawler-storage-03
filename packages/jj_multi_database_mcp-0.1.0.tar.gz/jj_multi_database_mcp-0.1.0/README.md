﻿# JJ MCP - 多数据库 MCP 服务器

一个全面的 MCP (Model Context Protocol) 服务器，支持多种数据库和文件系统操作。

## 功能特性

- **SQL Server 支持**: 查询、执行、表结构获取等完整功能
- **Oracle 数据库支持**: 完整的 Oracle 数据库操作支持
- **MySQL 数据库支持**: 完整的 MySQL 数据库操作支持
- **Redis 支持**: 基本的 Redis 操作（get、set、delete、keys 等）
- **文件系统操作**: 安全的文件读写和目录操作
- **安全控制**: 路径访问控制、文件扩展名限制等
- **环境变量配置**: 灵活的配置管理
- **跨平台支持**: Windows、Linux、macOS

## 安装

### 基础安装

```bash
pip install jj-multi-database-mcp
```

### 数据库支持安装（按需）

根据您需要使用的数据库，安装相应的扩展：

#### SQL Server 支持
```bash
# 安装 SQL Server 支持
pip install jj-multi-database-mcp[sqlserver]

# 需要安装 ODBC Driver for SQL Server
# 下载地址: https://docs.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server
```

#### Oracle 支持
```bash
# 安装 Oracle 支持
pip install jj-multi-database-mcp[oracle]

# 可能需要安装 Oracle Instant Client
# 下载地址: https://www.oracle.com/database/technologies/instant-client.html
```

#### MySQL 支持
```bash
# 安装 MySQL 支持
pip install jj-multi-database-mcp[mysql]
```

#### Redis 支持
```bash
# 安装 Redis 支持
pip install jj-multi-database-mcp[redis]
```

#### 安装所有数据库支持
```bash
# 一次性安装所有数据库支持
pip install jj-multi-database-mcp[all-databases]
```

**注意**: 如果不安装某个数据库的扩展，对应的数据库功能将不可用，但不会影响其他功能的正常使用。

## 配置

### 1. 创建配置文件

复制示例配置文件并修改：

```bash
cp .env.example .env
```

### 2. 配置数据库连接

编辑 `.env` 文件，启用并配置需要的数据库：

```env
# SQL Server
SQLSERVER_ENABLED=true
SQLSERVER_HOST=localhost
SQLSERVER_PORT=1433
SQLSERVER_DATABASE=mydb
SQLSERVER_USERNAME=myuser
SQLSERVER_PASSWORD=mypass

# Oracle
ORACLE_ENABLED=true
ORACLE_HOST=localhost
ORACLE_PORT=1521
ORACLE_SERVICE_NAME=ORCL
ORACLE_USERNAME=myuser
ORACLE_PASSWORD=mypass

# MySQL
MYSQL_ENABLED=true
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_DATABASE=mydb
MYSQL_USERNAME=myuser
MYSQL_PASSWORD=mypass

# Redis
REDIS_ENABLED=true
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=mypass
```

### 3. 文件系统安全配置

```env
# 限制访问路径（推荐用于生产环境）
FS_ALLOWED_PATHS=/home/user/data,/tmp

# 限制文件类型
FS_ALLOWED_EXTENSIONS=.txt,.py,.json,.csv

# 禁用删除操作（推荐用于生产环境）
FS_ENABLE_DELETE=false
```

### 4. 云数据库配置示例

#### 阿里云 RDS for MySQL
```env
MYSQL_ENABLED=true
MYSQL_HOST=rm-xxxxxxxx.mysql.rds.aliyuncs.com
MYSQL_PORT=3306
MYSQL_DATABASE=mydb
MYSQL_USERNAME=myuser
MYSQL_PASSWORD=mypass
MYSQL_USE_SSL=true
MYSQL_RDS_INSTANCE_ID=rm-xxxxxxxx
MYSQL_REGION=cn-hangzhou
```

#### Azure SQL Database
```env
SQLSERVER_ENABLED=true
SQLSERVER_HOST=myserver.database.windows.net
SQLSERVER_PORT=1433
SQLSERVER_DATABASE=mydb
SQLSERVER_USERNAME=myuser@myserver
SQLSERVER_PASSWORD=mypass
SQLSERVER_ENCRYPT=true
SQLSERVER_TRUST_CERT=false
SQLSERVER_AUTHENTICATION=ActiveDirectoryPassword
```

#### AWS RDS for MySQL
```env
MYSQL_ENABLED=true
MYSQL_HOST=mydb.xxxxxxxx.us-east-1.rds.amazonaws.com
MYSQL_PORT=3306
MYSQL_DATABASE=mydb
MYSQL_USERNAME=myuser
MYSQL_PASSWORD=mypass
MYSQL_USE_SSL=true
MYSQL_REGION=us-east-1
```

## 使用方法

### 启动服务器

```bash
# 直接运行
jj-multi-database-mcp
# 或者使用短名称
jj-mcp

# 或者使用 Python 模块
python -m jj_mcp
```

### MCP 工具

服务器提供以下工具：

#### SQL Server 工具
- `sql_query_mcp-sqlserver-filesystem`: 执行 SELECT 查询
- `sql_execute_mcp-sqlserver-filesystem`: 执行 INSERT/UPDATE/DELETE
- `get_table_schema_mcp-sqlserver-filesystem`: 获取表结构
- `list_tables_mcp-sqlserver-filesystem`: 列出所有表

#### Oracle 工具
- `oracle_query`: 执行 Oracle SELECT 查询
- `oracle_execute`: 执行 Oracle INSERT/UPDATE/DELETE
- `oracle_table_schema`: 获取 Oracle 表结构
- `oracle_list_tables`: 列出 Oracle 表

#### MySQL 工具
- `mysql_query`: 执行 MySQL SELECT 查询
- `mysql_execute`: 执行 MySQL INSERT/UPDATE/DELETE
- `mysql_table_schema`: 获取 MySQL 表结构
- `mysql_list_tables`: 列出 MySQL 表

#### Redis 工具
- `redis_get`: 获取键值
- `redis_set`: 设置键值
- `redis_delete`: 删除键
- `redis_keys`: 获取匹配的键列表
- `redis_exists`: 检查键是否存在

#### 文件系统工具
- `read_file_mcp-sqlserver-filesystem`: 读取文件内容
- `write_file_mcp-sqlserver-filesystem`: 写入文件内容
- `list_directory_mcp-sqlserver-filesystem`: 列出目录内容

## 前置条件

### SQL Server
- 安装 ODBC Driver for SQL Server
- 确保 SQL Server 允许远程连接
- 配置正确的防火墙规则
- 支持 Azure SQL Database（使用 ActiveDirectory 认证）
- 支持高级连接选项（MARS、加密、应用程序意图等）

### Oracle
- 安装 Oracle Instant Client（如果使用 thick 模式）
- 配置 TNS 或使用 Easy Connect 字符串
- 确保网络连接正常

### MySQL
- MySQL 服务器运行中
- 配置正确的用户权限
- 确保网络连接和端口开放
- **支持云服务**：
  - 阿里云 RDS for MySQL
  - AWS RDS for MySQL
  - 腾讯云 CDB for MySQL
  - 其他兼容 MySQL 协议的云数据库
- 支持 SSL/TLS 加密连接
- 支持自定义字符集和排序规则

### Redis
- Redis 服务器运行中
- 配置正确的认证信息（如果启用）

## 故障排除

### 常见问题

1. **SQL Server 连接失败**
   - 检查 ODBC 驱动是否正确安装
   - 验证连接字符串和认证信息
   - 确认 SQL Server 允许远程连接

2. **Oracle 连接失败**
   - 检查 Oracle 客户端库是否安装
   - 验证 TNS 配置或连接字符串
   - 确认网络连接和端口开放

3. **Redis 连接失败**
   - 检查 Redis 服务是否运行
   - 验证主机、端口和认证信息
   - 检查防火墙设置

4. **文件系统权限错误**
   - 检查路径访问权限
   - 验证 `FS_ALLOWED_PATHS` 配置
   - 确认文件扩展名在允许列表中

### 日志调试

启用调试日志：

```env
MCP_LOG_LEVEL=DEBUG
```

## 安全注意事项

1. **生产环境配置**
   - 限制文件系统访问路径
   - 禁用不必要的数据库功能
   - 使用强密码和加密连接

2. **网络安全**
   - 配置防火墙规则
   - 使用 VPN 或专用网络
   - 启用数据库加密连接

3. **访问控制**
   - 使用最小权限原则
   - 定期审查配置
   - 监控访问日志

## 许可证

MIT License

## 作者

PJ (peng.it@qq.com)

## 贡献

欢迎提交 Issue 和 Pull Request！
