﻿"""Tool handlers for Redis and filesystem operations."""

import logging
from typing import Any, Dict, List
from mcp.types import TextContent

logger = logging.getLogger(__name__)


def handle_redis_tools(name: str, arguments: Dict[str, Any], redis_manager) -> List[TextContent]:
    """Handle Redis tool calls."""
    
    if name == "redis_get":
        if not redis_manager or not redis_manager.is_available():
            return [TextContent(
                type="text",
                text=f"❌ Redis is not available: {redis_manager.get_connection_error() if redis_manager else 'Manager not initialized'}"
            )]
        
        key = arguments.get("key")
        
        try:
            value = redis_manager.get(key)
            if value is not None:
                return [TextContent(type="text", text=f"✅ Redis GET {key}: {value}")]
            else:
                return [TextContent(type="text", text=f"❌ Redis key '{key}' not found")]
                
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Redis GET failed: {str(e)}")]

    elif name == "redis_set":
        if not redis_manager or not redis_manager.is_available():
            return [TextContent(
                type="text",
                text=f"❌ Redis is not available: {redis_manager.get_connection_error() if redis_manager else 'Manager not initialized'}"
            )]
        
        key = arguments.get("key")
        value = arguments.get("value")
        expire = arguments.get("expire")
        
        try:
            success = redis_manager.set(key, value, expire)
            if success:
                expire_text = f" (expires in {expire}s)" if expire else ""
                return [TextContent(type="text", text=f"✅ Redis SET {key}: {value}{expire_text}")]
            else:
                return [TextContent(type="text", text=f"❌ Redis SET failed for key '{key}'")]
                
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Redis SET failed: {str(e)}")]

    elif name == "redis_delete":
        if not redis_manager or not redis_manager.is_available():
            return [TextContent(
                type="text",
                text=f"❌ Redis is not available: {redis_manager.get_connection_error() if redis_manager else 'Manager not initialized'}"
            )]
        
        key = arguments.get("key")
        
        try:
            success = redis_manager.delete(key)
            if success:
                return [TextContent(type="text", text=f"✅ Redis DELETE {key}: key deleted")]
            else:
                return [TextContent(type="text", text=f"❌ Redis key '{key}' not found")]
                
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Redis DELETE failed: {str(e)}")]

    elif name == "redis_keys":
        if not redis_manager or not redis_manager.is_available():
            return [TextContent(
                type="text",
                text=f"❌ Redis is not available: {redis_manager.get_connection_error() if redis_manager else 'Manager not initialized'}"
            )]
        
        pattern = arguments.get("pattern", "*")
        
        try:
            keys = redis_manager.keys(pattern)
            if keys:
                keys_text = "\n".join(f"- {key}" for key in keys)
                return [TextContent(type="text", text=f"✅ Redis KEYS {pattern} ({len(keys)} found):\n{keys_text}")]
            else:
                return [TextContent(type="text", text=f"❌ No Redis keys found matching pattern '{pattern}'")]
                
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Redis KEYS failed: {str(e)}")]

    elif name == "redis_exists":
        if not redis_manager or not redis_manager.is_available():
            return [TextContent(
                type="text",
                text=f"❌ Redis is not available: {redis_manager.get_connection_error() if redis_manager else 'Manager not initialized'}"
            )]
        
        key = arguments.get("key")
        
        try:
            exists = redis_manager.exists(key)
            return [TextContent(type="text", text=f"✅ Redis EXISTS {key}: {'exists' if exists else 'not exists'}")]
                
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Redis EXISTS failed: {str(e)}")]

    return [TextContent(type="text", text=f"❌ Unknown Redis tool: {name}")]


def handle_filesystem_tools(name: str, arguments: Dict[str, Any], fs_manager) -> List[TextContent]:
    """Handle filesystem tool calls."""
    
    if name == "read_file_mcp-sqlserver-filesystem":
        file_path = arguments.get("file_path")
        encoding = arguments.get("encoding", "utf-8")
        
        try:
            content = fs_manager.read_file(file_path, encoding)
            return [TextContent(type="text", text=f"✅ File read successfully: {file_path}\n\nContent:\n{content}")]
            
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Failed to read file: {str(e)}")]

    elif name == "write_file_mcp-sqlserver-filesystem":
        file_path = arguments.get("file_path")
        content = arguments.get("content")
        encoding = arguments.get("encoding", "utf-8")
        create_dirs = arguments.get("create_dirs", True)
        
        try:
            fs_manager.write_file(file_path, content, encoding, create_dirs)
            return [TextContent(type="text", text=f"✅ File written successfully: {file_path}")]
            
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Failed to write file: {str(e)}")]

    elif name == "list_directory_mcp-sqlserver-filesystem":
        dir_path = arguments.get("dir_path")
        recursive = arguments.get("recursive", False)
        
        try:
            items = fs_manager.list_directory(dir_path, recursive)
            
            if items:
                # Format as table
                headers = ["Name", "Type", "Size", "Modified"]
                table_lines = [" | ".join(headers)]
                table_lines.append(" | ".join(["-" * len(h) for h in headers]))
                
                for item in items:
                    row_values = [
                        item.get("name", ""),
                        item.get("type", ""),
                        str(item.get("size", "")),
                        item.get("modified", "")
                    ]
                    table_lines.append(" | ".join(row_values))
                
                table_text = "\n".join(table_lines)
                response_text = f"✅ Directory listing for {dir_path} ({len(items)} items):\n\n{table_text}"
            else:
                response_text = f"❌ Directory {dir_path} is empty or not found."
            
            return [TextContent(type="text", text=response_text)]
            
        except Exception as e:
            return [TextContent(type="text", text=f"❌ Failed to list directory: {str(e)}")]

    return [TextContent(type="text", text=f"❌ Unknown filesystem tool: {name}")]
