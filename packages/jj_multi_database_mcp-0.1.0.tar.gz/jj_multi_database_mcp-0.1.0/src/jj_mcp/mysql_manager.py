﻿"""MySQL database manager."""

import logging
from typing import Any, Dict, List, Optional
from contextlib import contextmanager

try:
    import pymysql
    import mysql.connector
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False
    pymysql = None
    mysql = None

try:
    from sqlalchemy import create_engine, text, MetaData
    from sqlalchemy.engine import Engine
    from sqlalchemy.pool import QueuePool
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False
    create_engine = None
    text = None
    MetaData = None
    Engine = None
    QueuePool = None

from .database_manager import SQLDatabaseManager, DatabaseConnectionError
from .config import get_config

logger = logging.getLogger(__name__)


class MySQLManager(SQLDatabaseManager):
    """Manages MySQL database connections and operations."""
    
    def __init__(self):
        super().__init__(None)  # Pass None as config, will get from get_config()
    
    def _initialize(self) -> None:
        """Initialize MySQL engine with connection pooling."""
        try:
            config = get_config()
            if not config.mysql.enabled:
                logger.info("MySQL is disabled in configuration")
                return
            
            if not MYSQL_AVAILABLE:
                logger.error("MySQL libraries not available. Install with: pip install pymysql mysql-connector-python")
                self._connection_error = "MySQL libraries not installed"
                return
            
            if not SQLALCHEMY_AVAILABLE:
                logger.error("SQLAlchemy not available. Install with: pip install sqlalchemy")
                self._connection_error = "SQLAlchemy not installed"
                return
            
            # Build connection string
            connection_string = self._build_connection_string()
            
            self._engine = create_engine(
                connection_string,
                poolclass=QueuePool,
                pool_size=config.mysql.pool_size,
                max_overflow=config.mysql.max_overflow,
                pool_pre_ping=True,
                pool_recycle=3600,
                echo=config.log_level == "DEBUG",
            )
            
            self._metadata = MetaData()
            
            # Test the connection
            if self.test_connection():
                self._is_available = True
                self._connection_error = None
                logger.info("MySQL engine initialized and connection test successful")
            else:
                self._is_available = False
                self._connection_error = "Connection test failed"
                logger.warning("MySQL engine initialized but connection test failed")
                
        except Exception as e:
            self._is_available = False
            self._connection_error = str(e)
            logger.warning(f"Failed to initialize MySQL engine: {e}")
    
    def _build_connection_string(self) -> str:
        """Build MySQL connection string."""
        config = get_config().mysql
        
        if config.connection_string:
            return config.connection_string
        
        # Build connection string from components
        if config.username and config.password:
            auth_part = f"{config.username}:{config.password}@"
        else:
            auth_part = ""
        
        # Base connection string
        connection_string = f"mysql+pymysql://{auth_part}{config.host}:{config.port}"
        
        if config.database:
            connection_string += f"/{config.database}"
        
        # Add connection parameters
        params = []
        params.append(f"charset={config.charset}")

        if config.collation:
            params.append(f"collation={config.collation}")

        # SSL configuration
        if config.use_ssl:
            params.append("ssl_disabled=false")
            if config.ssl_ca:
                params.append(f"ssl_ca={config.ssl_ca}")
            if config.ssl_cert:
                params.append(f"ssl_cert={config.ssl_cert}")
            if config.ssl_key:
                params.append(f"ssl_key={config.ssl_key}")
            if not config.ssl_verify_cert:
                params.append("ssl_check_hostname=false")
            if not config.ssl_verify_identity:
                params.append("ssl_verify_identity=false")
        else:
            params.append("ssl_disabled=true")

        # Connection timeouts
        params.append(f"connect_timeout={config.connect_timeout}")
        if config.read_timeout:
            params.append(f"read_timeout={config.read_timeout}")
        if config.write_timeout:
            params.append(f"write_timeout={config.write_timeout}")

        # Other options
        if config.autocommit:
            params.append("autocommit=true")

        if config.use_unicode:
            params.append("use_unicode=true")

        if config.sql_mode:
            params.append(f"sql_mode={config.sql_mode}")

        if config.init_command:
            params.append(f"init_command={config.init_command}")

        # Cloud service specific (for monitoring/logging)
        if config.rds_instance_id:
            # This can be used for application-level monitoring
            params.append(f"program_name=JJ-MCP-{config.rds_instance_id}")

        if params:
            connection_string += "?" + "&".join(params)
        
        return connection_string
    
    def test_connection(self) -> bool:
        """Test MySQL connection."""
        if not self._engine:
            return False
        
        try:
            with self.get_connection() as conn:
                conn.execute(text("SELECT 1"))
                return True
        except Exception as e:
            logger.error(f"MySQL connection test failed: {e}")
            return False
    
    def reconnect(self) -> bool:
        """Attempt to reconnect to MySQL."""
        logger.info("Attempting to reconnect to MySQL...")
        self._initialize()
        return self._is_available
    
    @contextmanager
    def get_connection(self):
        """Get a MySQL connection with automatic cleanup."""
        if not self._is_available:
            raise DatabaseConnectionError(f"MySQL is not available: {self._connection_error}")
        
        if not self._engine:
            raise DatabaseConnectionError("MySQL engine not initialized")
        
        connection = None
        try:
            connection = self._engine.connect()
            yield connection
        except Exception as e:
            logger.error(f"MySQL connection error: {e}")
            self._is_available = False
            self._connection_error = str(e)
            if connection:
                connection.rollback()
            raise
        finally:
            if connection:
                connection.close()
    
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a SELECT query and return results."""
        if not self._is_available:
            raise DatabaseConnectionError(f"MySQL is not available: {self._connection_error}")
        
        self._validate_sql_query(query)
        
        try:
            with self.get_connection() as conn:
                result = conn.execute(text(query), parameters or {})
                
                # Convert result to list of dictionaries
                columns = list(result.keys())
                rows = []
                for row in result:
                    row_dict = {}
                    for i, col_name in enumerate(columns):
                        row_dict[col_name] = row[i]
                    rows.append(row_dict)
                
                logger.info(f"MySQL query executed successfully, returned {len(rows)} rows")
                return {
                    'columns': columns,
                    'rows': rows,
                    'row_count': len(rows)
                }
                
        except Exception as e:
            logger.error(f"MySQL query execution failed: {e}")
            raise
    
    def execute_non_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> int:
        """Execute an INSERT, UPDATE, or DELETE query and return affected rows count."""
        if not self._is_available:
            raise DatabaseConnectionError(f"MySQL is not available: {self._connection_error}")
        
        self._validate_sql_query(query)
        
        try:
            with self.get_connection() as conn:
                result = conn.execute(text(query), parameters or {})
                conn.commit()
                
                affected_rows = result.rowcount
                logger.info(f"MySQL non-query executed successfully, affected {affected_rows} rows")
                return affected_rows
                
        except Exception as e:
            logger.error(f"MySQL non-query execution failed: {e}")
            raise

    def get_table_schema(self, table_name: str, schema_name: str = None) -> Dict[str, Any]:
        """Get table schema information."""
        if not self._is_available:
            raise DatabaseConnectionError(f"MySQL is not available: {self._connection_error}")

        # Use current database if no schema specified
        if not schema_name:
            schema_name = "DATABASE()"
            query = """
            SELECT
                COLUMN_NAME,
                DATA_TYPE,
                IS_NULLABLE,
                COLUMN_DEFAULT,
                CHARACTER_MAXIMUM_LENGTH,
                NUMERIC_PRECISION,
                NUMERIC_SCALE,
                CASE WHEN COLUMN_KEY = 'PRI' THEN 1 ELSE 0 END AS IS_PRIMARY_KEY,
                EXTRA
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name
            ORDER BY ORDINAL_POSITION
            """
            params = {'table_name': table_name}
        else:
            query = """
            SELECT
                COLUMN_NAME,
                DATA_TYPE,
                IS_NULLABLE,
                COLUMN_DEFAULT,
                CHARACTER_MAXIMUM_LENGTH,
                NUMERIC_PRECISION,
                NUMERIC_SCALE,
                CASE WHEN COLUMN_KEY = 'PRI' THEN 1 ELSE 0 END AS IS_PRIMARY_KEY,
                EXTRA
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = :schema_name AND TABLE_NAME = :table_name
            ORDER BY ORDINAL_POSITION
            """
            params = {'schema_name': schema_name, 'table_name': table_name}

        try:
            result = self.execute_query(query, params)

            return {
                'table_name': table_name,
                'schema_name': schema_name,
                'columns': result['rows']
            }

        except Exception as e:
            logger.error(f"Failed to get MySQL table schema: {e}")
            raise

    def list_tables(self, schema_name: str = None) -> List[Dict[str, Any]]:
        """List all tables in the database."""
        if not self._is_available:
            raise DatabaseConnectionError(f"MySQL is not available: {self._connection_error}")

        if not schema_name:
            query = """
            SELECT
                TABLE_SCHEMA,
                TABLE_NAME,
                TABLE_TYPE,
                ENGINE,
                TABLE_ROWS,
                DATA_LENGTH,
                CREATE_TIME,
                UPDATE_TIME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
            ORDER BY TABLE_NAME
            """
            params = {}
        else:
            query = """
            SELECT
                TABLE_SCHEMA,
                TABLE_NAME,
                TABLE_TYPE,
                ENGINE,
                TABLE_ROWS,
                DATA_LENGTH,
                CREATE_TIME,
                UPDATE_TIME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = :schema_name
            ORDER BY TABLE_NAME
            """
            params = {'schema_name': schema_name}

        try:
            result = self.execute_query(query, params)
            return result['rows']

        except Exception as e:
            logger.error(f"Failed to list MySQL tables: {e}")
            raise
