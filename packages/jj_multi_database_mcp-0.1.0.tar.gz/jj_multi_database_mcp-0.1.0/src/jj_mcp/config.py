﻿"""Configuration management for JJ MCP server."""

import os
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class FilesystemConfig(BaseModel):
    """Filesystem configuration."""
    allowed_paths: List[str] = Field(default_factory=lambda: ["*"])
    allowed_extensions: List[str] = Field(default_factory=lambda: ["*"])
    max_file_size: int = Field(default=100 * 1024 * 1024)  # 100MB
    enable_write: bool = Field(default=True)
    enable_delete: bool = Field(default=False)
    ignore_file_locks: bool = Field(default=False)
    
    @property
    def is_full_access_mode(self) -> bool:
        """Check if filesystem is in full access mode."""
        return "*" in self.allowed_paths


class DatabaseConfig(BaseModel):
    """Base database configuration."""
    host: str = Field(default="localhost")
    port: Optional[int] = Field(default=None)
    database: Optional[str] = Field(default=None)
    username: Optional[str] = Field(default=None)
    password: Optional[str] = Field(default=None)
    connection_string: Optional[str] = Field(default=None)
    pool_size: int = Field(default=5)
    max_overflow: int = Field(default=10)
    pool_timeout: int = Field(default=30)
    enabled: bool = Field(default=False)


class SqlServerConfig(DatabaseConfig):
    """SQL Server configuration."""
    port: int = Field(default=1433)
    driver: str = Field(default="ODBC Driver 17 for SQL Server")
    trust_server_certificate: bool = Field(default=True)
    encrypt: bool = Field(default=False)
    multiple_active_result_sets: bool = Field(default=True)
    application_name: str = Field(default="JJ-Multi-Database-MCP")
    connection_timeout: int = Field(default=30)
    command_timeout: int = Field(default=30)
    # Azure SQL specific
    authentication: Optional[str] = Field(default=None)  # ActiveDirectoryPassword, ActiveDirectoryIntegrated, etc.
    # Additional connection options
    mars_connection: bool = Field(default=True)
    packet_size: Optional[int] = Field(default=None)
    application_intent: Optional[str] = Field(default=None)  # ReadOnly, ReadWrite


class OracleConfig(DatabaseConfig):
    """Oracle database configuration."""
    port: int = Field(default=1521)
    service_name: Optional[str] = Field(default=None)
    sid: Optional[str] = Field(default=None)
    thick_mode: bool = Field(default=False)


class MySQLConfig(DatabaseConfig):
    """MySQL database configuration."""
    port: int = Field(default=3306)
    charset: str = Field(default="utf8mb4")
    collation: Optional[str] = Field(default=None)
    use_ssl: bool = Field(default=False)
    ssl_ca: Optional[str] = Field(default=None)
    ssl_cert: Optional[str] = Field(default=None)
    ssl_key: Optional[str] = Field(default=None)
    ssl_verify_cert: bool = Field(default=True)
    ssl_verify_identity: bool = Field(default=True)
    autocommit: bool = Field(default=True)
    # Connection options
    connect_timeout: int = Field(default=10)
    read_timeout: Optional[int] = Field(default=None)
    write_timeout: Optional[int] = Field(default=None)
    # Cloud service support (阿里云RDS, AWS RDS, etc.)
    use_unicode: bool = Field(default=True)
    sql_mode: Optional[str] = Field(default=None)
    init_command: Optional[str] = Field(default=None)
    # RDS specific options
    rds_instance_id: Optional[str] = Field(default=None)  # For cloud monitoring
    region: Optional[str] = Field(default=None)  # Cloud region


class RedisConfig(BaseModel):
    """Redis configuration."""
    host: str = Field(default="localhost")
    port: int = Field(default=6379)
    database: int = Field(default=0)
    password: Optional[str] = Field(default=None)
    username: Optional[str] = Field(default=None)
    ssl: bool = Field(default=False)
    ssl_cert_reqs: Optional[str] = Field(default=None)
    ssl_ca_certs: Optional[str] = Field(default=None)
    ssl_certfile: Optional[str] = Field(default=None)
    ssl_keyfile: Optional[str] = Field(default=None)
    max_connections: int = Field(default=10)
    socket_timeout: int = Field(default=30)
    socket_connect_timeout: int = Field(default=30)
    enabled: bool = Field(default=False)


class MCPConfig(BaseSettings):
    """Main MCP server configuration."""
    
    # Server settings
    server_name: str = Field(default="jj-mcp")
    server_version: str = Field(default="0.1.0")
    log_level: str = Field(default="INFO")
    
    # Component configurations
    filesystem: FilesystemConfig = Field(default_factory=FilesystemConfig)
    sqlserver: SqlServerConfig = Field(default_factory=SqlServerConfig)
    oracle: OracleConfig = Field(default_factory=OracleConfig)
    mysql: MySQLConfig = Field(default_factory=MySQLConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        env_nested_delimiter = "__"
        case_sensitive = False
        
        # Environment variable prefixes for each section
        env_prefix = ""
        
    @classmethod
    def from_env(cls) -> "MCPConfig":
        """Create configuration from environment variables."""
        return cls(
            # Filesystem settings
            filesystem=FilesystemConfig(
                allowed_paths=os.getenv("FS_ALLOWED_PATHS", "*").split(",") if os.getenv("FS_ALLOWED_PATHS") else ["*"],
                allowed_extensions=os.getenv("FS_ALLOWED_EXTENSIONS", "*").split(",") if os.getenv("FS_ALLOWED_EXTENSIONS") else ["*"],
                max_file_size=int(os.getenv("FS_MAX_FILE_SIZE", "104857600")),  # 100MB
                enable_write=os.getenv("FS_ENABLE_WRITE", "true").lower() == "true",
                enable_delete=os.getenv("FS_ENABLE_DELETE", "false").lower() == "true",
                ignore_file_locks=os.getenv("FS_IGNORE_FILE_LOCKS", "false").lower() == "true",
            ),
            # SQL Server settings
            sqlserver=SqlServerConfig(
                enabled=os.getenv("SQLSERVER_ENABLED", "false").lower() == "true",
                host=os.getenv("SQLSERVER_HOST", "localhost"),
                port=int(os.getenv("SQLSERVER_PORT", "1433")),
                database=os.getenv("SQLSERVER_DATABASE"),
                username=os.getenv("SQLSERVER_USERNAME"),
                password=os.getenv("SQLSERVER_PASSWORD"),
                connection_string=os.getenv("SQLSERVER_CONNECTION_STRING"),
                driver=os.getenv("SQLSERVER_DRIVER", "ODBC Driver 17 for SQL Server"),
                trust_server_certificate=os.getenv("SQLSERVER_TRUST_CERT", "true").lower() == "true",
                encrypt=os.getenv("SQLSERVER_ENCRYPT", "false").lower() == "true",
                multiple_active_result_sets=os.getenv("SQLSERVER_MARS", "true").lower() == "true",
                application_name=os.getenv("SQLSERVER_APP_NAME", "JJ-Multi-Database-MCP"),
                connection_timeout=int(os.getenv("SQLSERVER_CONN_TIMEOUT", "30")),
                command_timeout=int(os.getenv("SQLSERVER_CMD_TIMEOUT", "30")),
                authentication=os.getenv("SQLSERVER_AUTHENTICATION"),
                mars_connection=os.getenv("SQLSERVER_MARS_CONN", "true").lower() == "true",
                packet_size=int(os.getenv("SQLSERVER_PACKET_SIZE")) if os.getenv("SQLSERVER_PACKET_SIZE") else None,
                application_intent=os.getenv("SQLSERVER_APP_INTENT"),
            ),
            # Oracle settings
            oracle=OracleConfig(
                enabled=os.getenv("ORACLE_ENABLED", "false").lower() == "true",
                host=os.getenv("ORACLE_HOST", "localhost"),
                port=int(os.getenv("ORACLE_PORT", "1521")),
                database=os.getenv("ORACLE_DATABASE"),
                username=os.getenv("ORACLE_USERNAME"),
                password=os.getenv("ORACLE_PASSWORD"),
                connection_string=os.getenv("ORACLE_CONNECTION_STRING"),
                service_name=os.getenv("ORACLE_SERVICE_NAME"),
                sid=os.getenv("ORACLE_SID"),
                thick_mode=os.getenv("ORACLE_THICK_MODE", "false").lower() == "true",
            ),
            # MySQL settings
            mysql=MySQLConfig(
                enabled=os.getenv("MYSQL_ENABLED", "false").lower() == "true",
                host=os.getenv("MYSQL_HOST", "localhost"),
                port=int(os.getenv("MYSQL_PORT", "3306")),
                database=os.getenv("MYSQL_DATABASE"),
                username=os.getenv("MYSQL_USERNAME"),
                password=os.getenv("MYSQL_PASSWORD"),
                connection_string=os.getenv("MYSQL_CONNECTION_STRING"),
                charset=os.getenv("MYSQL_CHARSET", "utf8mb4"),
                collation=os.getenv("MYSQL_COLLATION"),
                use_ssl=os.getenv("MYSQL_USE_SSL", "false").lower() == "true",
                ssl_ca=os.getenv("MYSQL_SSL_CA"),
                ssl_cert=os.getenv("MYSQL_SSL_CERT"),
                ssl_key=os.getenv("MYSQL_SSL_KEY"),
                ssl_verify_cert=os.getenv("MYSQL_SSL_VERIFY_CERT", "true").lower() == "true",
                ssl_verify_identity=os.getenv("MYSQL_SSL_VERIFY_IDENTITY", "true").lower() == "true",
                autocommit=os.getenv("MYSQL_AUTOCOMMIT", "true").lower() == "true",
                connect_timeout=int(os.getenv("MYSQL_CONNECT_TIMEOUT", "10")),
                read_timeout=int(os.getenv("MYSQL_READ_TIMEOUT")) if os.getenv("MYSQL_READ_TIMEOUT") else None,
                write_timeout=int(os.getenv("MYSQL_WRITE_TIMEOUT")) if os.getenv("MYSQL_WRITE_TIMEOUT") else None,
                use_unicode=os.getenv("MYSQL_USE_UNICODE", "true").lower() == "true",
                sql_mode=os.getenv("MYSQL_SQL_MODE"),
                init_command=os.getenv("MYSQL_INIT_COMMAND"),
                rds_instance_id=os.getenv("MYSQL_RDS_INSTANCE_ID"),
                region=os.getenv("MYSQL_REGION"),
            ),
            # Redis settings
            redis=RedisConfig(
                enabled=os.getenv("REDIS_ENABLED", "false").lower() == "true",
                host=os.getenv("REDIS_HOST", "localhost"),
                port=int(os.getenv("REDIS_PORT", "6379")),
                database=int(os.getenv("REDIS_DATABASE", "0")),
                username=os.getenv("REDIS_USERNAME"),
                password=os.getenv("REDIS_PASSWORD"),
                ssl=os.getenv("REDIS_SSL", "false").lower() == "true",
                max_connections=int(os.getenv("REDIS_MAX_CONNECTIONS", "10")),
            ),
            # Server settings
            server_name=os.getenv("MCP_SERVER_NAME", "jj-mcp"),
            server_version=os.getenv("MCP_SERVER_VERSION", "0.1.0"),
            log_level=os.getenv("MCP_LOG_LEVEL", "INFO"),
        )


# Global configuration instance
_config: Optional[MCPConfig] = None


def get_config() -> MCPConfig:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = MCPConfig.from_env()
    return _config


def reload_config() -> MCPConfig:
    """Reload configuration from environment."""
    global _config
    _config = MCPConfig.from_env()
    return _config
