﻿"""Database connection managers for multiple database types."""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class DatabaseError(Exception):
    """Base exception for database operations."""
    pass


class DatabaseConnectionError(DatabaseError):
    """Raised when database connection fails."""
    pass


class DatabaseSecurityError(DatabaseError):
    """Raised when a database operation fails security checks."""
    pass


class BaseDatabaseManager(ABC):
    """Abstract base class for database managers."""
    
    def __init__(self, config):
        self.config = config
        self._is_available = False
        self._connection_error: Optional[str] = None
        self._initialize()
    
    @abstractmethod
    def _initialize(self) -> None:
        """Initialize the database connection."""
        pass
    
    @abstractmethod
    def test_connection(self) -> bool:
        """Test database connection."""
        pass
    
    @abstractmethod
    def reconnect(self) -> bool:
        """Attempt to reconnect to the database."""
        pass
    
    def is_available(self) -> bool:
        """Check if database is available for operations."""
        return self._is_available
    
    def get_connection_error(self) -> Optional[str]:
        """Get the last connection error message."""
        return self._connection_error
    
    @abstractmethod
    @contextmanager
    def get_connection(self):
        """Get a database connection with automatic cleanup."""
        pass


class SQLDatabaseManager(BaseDatabaseManager):
    """Base class for SQL database managers (SQL Server, Oracle)."""
    
    def __init__(self, config):
        self._engine = None
        self._metadata = None
        super().__init__(config)
    
    def _validate_sql_query(self, query: str) -> None:
        """Validate SQL query for security issues."""
        # Skip validation if security is disabled
        if not getattr(self.config, 'enable_sql_injection_protection', True):
            logger.debug("SQL security validation skipped - full access mode enabled")
            return
        
        # Check query length
        max_length = getattr(self.config, 'max_query_length', 100000)
        if len(query) > max_length:
            raise DatabaseSecurityError(f"Query exceeds maximum length of {max_length}")
        
        logger.debug("SQL query passed security validation")
    
    @abstractmethod
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a SELECT query and return results."""
        pass
    
    @abstractmethod
    def execute_non_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> int:
        """Execute an INSERT, UPDATE, or DELETE query and return affected rows count."""
        pass
    
    @abstractmethod
    def get_table_schema(self, table_name: str, schema_name: str = "dbo") -> Dict[str, Any]:
        """Get table schema information."""
        pass
    
    @abstractmethod
    def list_tables(self, schema_name: str = "dbo") -> List[Dict[str, Any]]:
        """List all tables in the database."""
        pass


class NoSQLDatabaseManager(BaseDatabaseManager):
    """Base class for NoSQL database managers (Redis)."""
    
    @abstractmethod
    def get(self, key: str) -> Optional[str]:
        """Get value by key."""
        pass
    
    @abstractmethod
    def set(self, key: str, value: str, expire: Optional[int] = None) -> bool:
        """Set key-value pair with optional expiration."""
        pass
    
    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete key."""
        pass
    
    @abstractmethod
    def keys(self, pattern: str = "*") -> List[str]:
        """Get keys matching pattern."""
        pass
    
    @abstractmethod
    def exists(self, key: str) -> bool:
        """Check if key exists."""
        pass
