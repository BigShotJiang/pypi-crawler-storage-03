﻿"""Oracle database manager."""

import logging
from typing import Any, Dict, List, Optional
from contextlib import contextmanager

try:
    import oracledb
    import cx_Oracle
    ORACLE_AVAILABLE = True
except ImportError:
    ORACLE_AVAILABLE = False
    oracledb = None
    cx_Oracle = None

try:
    from sqlalchemy import create_engine, text, MetaData
    from sqlalchemy.engine import Engine
    from sqlalchemy.pool import QueuePool
    SQLALCHEMY_AVAILABLE = True
except ImportError:
    SQLALCHEMY_AVAILABLE = False
    create_engine = None
    text = None
    MetaData = None
    Engine = None
    QueuePool = None

from .database_manager import SQLDatabaseManager, DatabaseConnectionError
from .config import get_config

logger = logging.getLogger(__name__)


class OracleManager(SQLDatabaseManager):
    """Manages Oracle database connections and operations."""

    def __init__(self):
        super().__init__(None)  # Pass None as config, will get from get_config()

    def _initialize(self) -> None:
        """Initialize Oracle engine with connection pooling."""
        try:
            config = get_config()
            if not config.oracle.enabled:
                logger.info("Oracle is disabled in configuration")
                return
            
            if not ORACLE_AVAILABLE:
                logger.error("Oracle libraries not available. Install with: pip install oracledb cx-Oracle")
                self._connection_error = "Oracle libraries not installed"
                return

            if not SQLALCHEMY_AVAILABLE:
                logger.error("SQLAlchemy not available. Install with: pip install sqlalchemy")
                self._connection_error = "SQLAlchemy not installed"
                return
            
            # Initialize Oracle client if needed
            if config.oracle.thick_mode:
                try:
                    oracledb.init_oracle_client()
                    logger.info("Oracle thick mode initialized")
                except Exception as e:
                    logger.warning(f"Failed to initialize Oracle thick mode: {e}")
            
            # Build connection string
            connection_string = self._build_connection_string()
            sqlalchemy_url = f"oracle+oracledb://{connection_string}"
            
            self._engine = create_engine(
                sqlalchemy_url,
                poolclass=QueuePool,
                pool_size=config.oracle.pool_size,
                max_overflow=config.oracle.max_overflow,
                pool_pre_ping=True,
                pool_recycle=3600,
                echo=config.log_level == "DEBUG",
            )
            
            self._metadata = MetaData()
            
            # Test the connection
            if self.test_connection():
                self._is_available = True
                self._connection_error = None
                logger.info("Oracle engine initialized and connection test successful")
            else:
                self._is_available = False
                self._connection_error = "Connection test failed"
                logger.warning("Oracle engine initialized but connection test failed")
                
        except Exception as e:
            self._is_available = False
            self._connection_error = str(e)
            logger.warning(f"Failed to initialize Oracle engine: {e}")
    
    def _build_connection_string(self) -> str:
        """Build Oracle connection string."""
        config = get_config().oracle
        
        if config.connection_string:
            return config.connection_string
        
        # Build connection string from components
        if config.username and config.password:
            auth_part = f"{config.username}:{config.password}@"
        else:
            auth_part = ""
        
        # Build host part
        if config.service_name:
            host_part = f"{config.host}:{config.port}/{config.service_name}"
        elif config.sid:
            host_part = f"{config.host}:{config.port}/{config.sid}"
        else:
            host_part = f"{config.host}:{config.port}"
        
        return f"{auth_part}{host_part}"
    
    def test_connection(self) -> bool:
        """Test Oracle connection."""
        if not self._engine:
            return False
        
        try:
            with self.get_connection() as conn:
                conn.execute(text("SELECT 1 FROM DUAL"))
                return True
        except Exception as e:
            logger.error(f"Oracle connection test failed: {e}")
            return False
    
    def reconnect(self) -> bool:
        """Attempt to reconnect to Oracle."""
        logger.info("Attempting to reconnect to Oracle...")
        self._initialize()
        return self._is_available
    
    @contextmanager
    def get_connection(self):
        """Get an Oracle connection with automatic cleanup."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Oracle is not available: {self._connection_error}")
        
        if not self._engine:
            raise DatabaseConnectionError("Oracle engine not initialized")
        
        connection = None
        try:
            connection = self._engine.connect()
            yield connection
        except Exception as e:
            logger.error(f"Oracle connection error: {e}")
            self._is_available = False
            self._connection_error = str(e)
            if connection:
                connection.rollback()
            raise
        finally:
            if connection:
                connection.close()
    
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a SELECT query and return results."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Oracle is not available: {self._connection_error}")
        
        self._validate_sql_query(query)
        
        try:
            with self.get_connection() as conn:
                result = conn.execute(text(query), parameters or {})
                
                # Convert result to list of dictionaries
                columns = list(result.keys())
                rows = []
                for row in result:
                    row_dict = {}
                    for i, col_name in enumerate(columns):
                        row_dict[col_name] = row[i]
                    rows.append(row_dict)
                
                logger.info(f"Oracle query executed successfully, returned {len(rows)} rows")
                return {
                    'columns': columns,
                    'rows': rows,
                    'row_count': len(rows)
                }
                
        except Exception as e:
            logger.error(f"Oracle query execution failed: {e}")
            raise
    
    def execute_non_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> int:
        """Execute an INSERT, UPDATE, or DELETE query and return affected rows count."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Oracle is not available: {self._connection_error}")
        
        self._validate_sql_query(query)
        
        try:
            with self.get_connection() as conn:
                result = conn.execute(text(query), parameters or {})
                conn.commit()
                
                affected_rows = result.rowcount
                logger.info(f"Oracle non-query executed successfully, affected {affected_rows} rows")
                return affected_rows
                
        except Exception as e:
            logger.error(f"Oracle non-query execution failed: {e}")
            raise

    def get_table_schema(self, table_name: str, schema_name: str = None) -> Dict[str, Any]:
        """Get table schema information."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Oracle is not available: {self._connection_error}")

        # If no schema specified, use current user
        if not schema_name:
            schema_name = "USER_TABLES"
            query = """
            SELECT
                COLUMN_NAME,
                DATA_TYPE,
                NULLABLE,
                DATA_DEFAULT,
                DATA_LENGTH,
                DATA_PRECISION,
                DATA_SCALE,
                CASE WHEN CONSTRAINT_TYPE = 'P' THEN 1 ELSE 0 END AS IS_PRIMARY_KEY
            FROM USER_TAB_COLUMNS c
            LEFT JOIN (
                SELECT cc.COLUMN_NAME, c.CONSTRAINT_TYPE
                FROM USER_CONSTRAINTS c
                JOIN USER_CONS_COLUMNS cc ON c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
                WHERE c.TABLE_NAME = :table_name AND c.CONSTRAINT_TYPE = 'P'
            ) pk ON c.COLUMN_NAME = pk.COLUMN_NAME
            WHERE c.TABLE_NAME = UPPER(:table_name)
            ORDER BY c.COLUMN_ID
            """
            params = {'table_name': table_name.upper()}
        else:
            query = """
            SELECT
                COLUMN_NAME,
                DATA_TYPE,
                NULLABLE,
                DATA_DEFAULT,
                DATA_LENGTH,
                DATA_PRECISION,
                DATA_SCALE,
                CASE WHEN CONSTRAINT_TYPE = 'P' THEN 1 ELSE 0 END AS IS_PRIMARY_KEY
            FROM ALL_TAB_COLUMNS c
            LEFT JOIN (
                SELECT cc.COLUMN_NAME, c.CONSTRAINT_TYPE
                FROM ALL_CONSTRAINTS c
                JOIN ALL_CONS_COLUMNS cc ON c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
                WHERE c.OWNER = UPPER(:schema_name)
                AND c.TABLE_NAME = UPPER(:table_name)
                AND c.CONSTRAINT_TYPE = 'P'
            ) pk ON c.COLUMN_NAME = pk.COLUMN_NAME
            WHERE c.OWNER = UPPER(:schema_name) AND c.TABLE_NAME = UPPER(:table_name)
            ORDER BY c.COLUMN_ID
            """
            params = {'schema_name': schema_name.upper(), 'table_name': table_name.upper()}

        try:
            result = self.execute_query(query, params)

            return {
                'table_name': table_name,
                'schema_name': schema_name,
                'columns': result['rows']
            }

        except Exception as e:
            logger.error(f"Failed to get Oracle table schema: {e}")
            raise

    def list_tables(self, schema_name: str = None) -> List[Dict[str, Any]]:
        """List all tables in the database."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Oracle is not available: {self._connection_error}")

        if not schema_name:
            query = """
            SELECT
                USER AS TABLE_SCHEMA,
                TABLE_NAME,
                'TABLE' AS TABLE_TYPE
            FROM USER_TABLES
            ORDER BY TABLE_NAME
            """
            params = {}
        else:
            query = """
            SELECT
                OWNER AS TABLE_SCHEMA,
                TABLE_NAME,
                'TABLE' AS TABLE_TYPE
            FROM ALL_TABLES
            WHERE OWNER = UPPER(:schema_name)
            ORDER BY TABLE_NAME
            """
            params = {'schema_name': schema_name.upper()}

        try:
            result = self.execute_query(query, params)
            return result['rows']

        except Exception as e:
            logger.error(f"Failed to list Oracle tables: {e}")
            raise
