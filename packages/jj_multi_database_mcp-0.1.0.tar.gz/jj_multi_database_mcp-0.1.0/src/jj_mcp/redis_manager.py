﻿"""Redis database manager."""

import logging
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager
import json

try:
    import redis
    import aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    redis = None
    aioredis = None

from .database_manager import NoSQLDatabaseManager, DatabaseConnectionError
from .config import get_config

logger = logging.getLogger(__name__)


class RedisManager(NoSQLDatabaseManager):
    """Manages Redis connections and operations."""

    def __init__(self):
        self._client = None
        super().__init__(None)  # Pass None as config, will get from get_config()
    
    def _initialize(self) -> None:
        """Initialize Redis client."""
        try:
            config = get_config()
            if not config.redis.enabled:
                logger.info("Redis is disabled in configuration")
                return
            
            if not REDIS_AVAILABLE:
                logger.error("Redis libraries not available. Install with: pip install redis aioredis")
                self._connection_error = "Redis libraries not installed"
                return
            
            # Build Redis connection parameters
            connection_params = {
                'host': config.redis.host,
                'port': config.redis.port,
                'db': config.redis.database,
                'socket_timeout': config.redis.socket_timeout,
                'socket_connect_timeout': config.redis.socket_connect_timeout,
                'max_connections': config.redis.max_connections,
                'decode_responses': True,  # Automatically decode responses to strings
            }
            
            # Add authentication if provided
            if config.redis.password:
                connection_params['password'] = config.redis.password
            
            if config.redis.username:
                connection_params['username'] = config.redis.username
            
            # Add SSL configuration if enabled
            if config.redis.ssl:
                connection_params['ssl'] = True
                if config.redis.ssl_cert_reqs:
                    connection_params['ssl_cert_reqs'] = config.redis.ssl_cert_reqs
                if config.redis.ssl_ca_certs:
                    connection_params['ssl_ca_certs'] = config.redis.ssl_ca_certs
                if config.redis.ssl_certfile:
                    connection_params['ssl_certfile'] = config.redis.ssl_certfile
                if config.redis.ssl_keyfile:
                    connection_params['ssl_keyfile'] = config.redis.ssl_keyfile
            
            # Create Redis connection pool
            self._client = redis.Redis(**connection_params)
            
            # Test the connection
            if self.test_connection():
                self._is_available = True
                self._connection_error = None
                logger.info("Redis client initialized and connection test successful")
            else:
                self._is_available = False
                self._connection_error = "Connection test failed"
                logger.warning("Redis client initialized but connection test failed")
                
        except Exception as e:
            self._is_available = False
            self._connection_error = str(e)
            logger.warning(f"Failed to initialize Redis client: {e}")
    
    def test_connection(self) -> bool:
        """Test Redis connection."""
        if not self._client:
            return False
        
        try:
            self._client.ping()
            return True
        except Exception as e:
            logger.error(f"Redis connection test failed: {e}")
            return False
    
    def reconnect(self) -> bool:
        """Attempt to reconnect to Redis."""
        logger.info("Attempting to reconnect to Redis...")
        self._initialize()
        return self._is_available
    
    @contextmanager
    def get_connection(self):
        """Get a Redis connection (for compatibility with base class)."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")
        
        if not self._client:
            raise DatabaseConnectionError("Redis client not initialized")
        
        try:
            yield self._client
        except Exception as e:
            logger.error(f"Redis connection error: {e}")
            self._is_available = False
            self._connection_error = str(e)
            raise
    
    def get(self, key: str) -> Optional[str]:
        """Get value by key."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")
        
        try:
            with self.get_connection() as client:
                value = client.get(key)
                logger.debug(f"Redis GET {key}: {'found' if value else 'not found'}")
                return value
                
        except Exception as e:
            logger.error(f"Redis GET operation failed: {e}")
            raise
    
    def set(self, key: str, value: str, expire: Optional[int] = None) -> bool:
        """Set key-value pair with optional expiration."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")
        
        try:
            with self.get_connection() as client:
                result = client.set(key, value, ex=expire)
                logger.debug(f"Redis SET {key}: {'success' if result else 'failed'}")
                return bool(result)
                
        except Exception as e:
            logger.error(f"Redis SET operation failed: {e}")
            raise
    
    def delete(self, key: str) -> bool:
        """Delete key."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")
        
        try:
            with self.get_connection() as client:
                result = client.delete(key)
                logger.debug(f"Redis DELETE {key}: {result} keys deleted")
                return result > 0
                
        except Exception as e:
            logger.error(f"Redis DELETE operation failed: {e}")
            raise
    
    def keys(self, pattern: str = "*") -> List[str]:
        """Get keys matching pattern."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")
        
        try:
            with self.get_connection() as client:
                keys = client.keys(pattern)
                logger.debug(f"Redis KEYS {pattern}: found {len(keys)} keys")
                return keys
                
        except Exception as e:
            logger.error(f"Redis KEYS operation failed: {e}")
            raise
    
    def exists(self, key: str) -> bool:
        """Check if key exists."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")
        
        try:
            with self.get_connection() as client:
                result = client.exists(key)
                logger.debug(f"Redis EXISTS {key}: {'exists' if result else 'not exists'}")
                return bool(result)
                
        except Exception as e:
            logger.error(f"Redis EXISTS operation failed: {e}")
            raise

    def expire(self, key: str, seconds: int) -> bool:
        """Set expiration time for a key."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                result = client.expire(key, seconds)
                logger.debug(f"Redis EXPIRE {key} {seconds}s: {'success' if result else 'failed'}")
                return bool(result)

        except Exception as e:
            logger.error(f"Redis EXPIRE operation failed: {e}")
            raise

    def ttl(self, key: str) -> int:
        """Get time to live for a key."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                result = client.ttl(key)
                logger.debug(f"Redis TTL {key}: {result}")
                return result

        except Exception as e:
            logger.error(f"Redis TTL operation failed: {e}")
            raise

    def hget(self, name: str, key: str) -> Optional[str]:
        """Get field value from hash."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                value = client.hget(name, key)
                logger.debug(f"Redis HGET {name} {key}: {'found' if value else 'not found'}")
                return value

        except Exception as e:
            logger.error(f"Redis HGET operation failed: {e}")
            raise

    def hset(self, name: str, key: str, value: str) -> bool:
        """Set field value in hash."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                result = client.hset(name, key, value)
                logger.debug(f"Redis HSET {name} {key}: {'new field' if result else 'updated'}")
                return True

        except Exception as e:
            logger.error(f"Redis HSET operation failed: {e}")
            raise

    def hgetall(self, name: str) -> Dict[str, str]:
        """Get all fields and values from hash."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                result = client.hgetall(name)
                logger.debug(f"Redis HGETALL {name}: {len(result)} fields")
                return result

        except Exception as e:
            logger.error(f"Redis HGETALL operation failed: {e}")
            raise

    def lpush(self, name: str, *values: str) -> int:
        """Push values to the left of a list."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                result = client.lpush(name, *values)
                logger.debug(f"Redis LPUSH {name}: list length now {result}")
                return result

        except Exception as e:
            logger.error(f"Redis LPUSH operation failed: {e}")
            raise

    def rpop(self, name: str) -> Optional[str]:
        """Pop value from the right of a list."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                value = client.rpop(name)
                logger.debug(f"Redis RPOP {name}: {'found' if value else 'empty list'}")
                return value

        except Exception as e:
            logger.error(f"Redis RPOP operation failed: {e}")
            raise

    def lrange(self, name: str, start: int = 0, end: int = -1) -> List[str]:
        """Get range of elements from list."""
        if not self._is_available:
            raise DatabaseConnectionError(f"Redis is not available: {self._connection_error}")

        try:
            with self.get_connection() as client:
                result = client.lrange(name, start, end)
                logger.debug(f"Redis LRANGE {name} {start} {end}: {len(result)} elements")
                return result

        except Exception as e:
            logger.error(f"Redis LRANGE operation failed: {e}")
            raise
