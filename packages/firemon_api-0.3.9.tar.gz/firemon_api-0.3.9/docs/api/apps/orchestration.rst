Orchestration
=============

The Orchestration application is used to directly execute automation without having to make Policy Planner tickets.

.. toctree::
   :maxdepth: 1

   orchestration/changes