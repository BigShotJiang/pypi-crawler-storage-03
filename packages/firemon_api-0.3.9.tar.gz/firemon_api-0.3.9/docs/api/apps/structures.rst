Structures
==========

Start documenting all the structures that may be used in different APIs

.. automodule:: firemon_api.apps.structure
    :members:
    :undoc-members:
    :show-inheritance:
