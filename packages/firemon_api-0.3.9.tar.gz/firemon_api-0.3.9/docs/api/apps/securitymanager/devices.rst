firemon_api.apps.securitymanager.devices
========================================

.. automodule:: firemon_api.apps.securitymanager.devices
    :members:
    :undoc-members:
    :show-inheritance: