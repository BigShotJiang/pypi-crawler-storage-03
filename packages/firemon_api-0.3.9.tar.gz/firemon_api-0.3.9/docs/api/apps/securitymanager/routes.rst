firemon_api.apps.securitymanager.routes
=======================================

.. automodule:: firemon_api.apps.securitymanager.routes
    :members:
    :undoc-members:
    :show-inheritance: