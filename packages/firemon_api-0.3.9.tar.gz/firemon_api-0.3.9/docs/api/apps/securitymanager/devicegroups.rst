firemon_api.apps.securitymanager.devicegroups
=============================================

.. automodule:: firemon_api.apps.securitymanager.devicegroups
    :members:
    :undoc-members:
    :show-inheritance: