firemon_api.apps.securitymanager.centralsyslogs
===============================================

.. automodule:: firemon_api.apps.securitymanager.centralsyslogs
    :members:
    :undoc-members:
    :show-inheritance: