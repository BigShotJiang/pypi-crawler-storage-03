firemon_api.apps.securitymanager.collectionconfigs
==================================================

.. automodule:: firemon_api.apps.securitymanager.collectionconfigs
    :members:
    :undoc-members:
    :show-inheritance: