firemon_api.apps.securitymanager.rulerec
========================================

.. automodule:: firemon_api.apps.securitymanager.rulerec
    :members:
    :undoc-members:
    :show-inheritance: