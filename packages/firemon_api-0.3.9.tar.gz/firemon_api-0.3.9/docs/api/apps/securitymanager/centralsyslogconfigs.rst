firemon_api.apps.securitymanager.centralsyslogconfigs
=====================================================

.. automodule:: firemon_api.apps.securitymanager.centralsyslogconfigs
    :members:
    :undoc-members:
    :show-inheritance: