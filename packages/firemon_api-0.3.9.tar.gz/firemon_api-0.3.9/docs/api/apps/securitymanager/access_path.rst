firemon_api.apps.securitymanager.access_path
============================================

.. automodule:: firemon_api.apps.securitymanager.access_path
    :members:
    :undoc-members:
    :show-inheritance: