import time


def get_timestamp_name():
    return time.strftime("%y%m%d%H%M%S")
