# see Yfiles_Kuzu_Graphs.py

from .Yfiles_Kuzu_Graphs import KuzuGraphWidget
