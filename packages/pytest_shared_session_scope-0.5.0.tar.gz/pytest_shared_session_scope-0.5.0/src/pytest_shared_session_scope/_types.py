import pytest

tests_started = pytest.StashKey[list[str]]()
