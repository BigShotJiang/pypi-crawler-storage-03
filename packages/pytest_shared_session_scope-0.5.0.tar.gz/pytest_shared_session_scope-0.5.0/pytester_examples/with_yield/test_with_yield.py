def test_with_yield_1(my_fixture):
    assert my_fixture == 123

def test_with_yield_2(my_fixture):
    assert my_fixture == 123

def test_with_yield_3(my_fixture):
    assert my_fixture == 123

def test_with_yield_4(my_fixture):
    assert my_fixture == 123

def test_with_yield_5(my_fixture):
    assert my_fixture == 123
