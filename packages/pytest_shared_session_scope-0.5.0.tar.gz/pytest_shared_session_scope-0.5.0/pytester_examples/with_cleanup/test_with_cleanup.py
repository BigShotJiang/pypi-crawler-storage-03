def test_with_cleanup_1(my_fixture):
    assert my_fixture == 123

def test_with_cleanup_2(my_fixture):
    assert my_fixture == 123

def test_with_cleanup_3(my_fixture):
    assert my_fixture == 123

def test_with_cleanup_4(my_fixture):
    assert my_fixture == 123

def test_with_cleanup_5(my_fixture):
    assert my_fixture == 123
