def test_simple(fix):
    assert fix == 1
