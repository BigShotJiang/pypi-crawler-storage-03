def test_with_return_1(my_fixture):
    assert my_fixture == 123

def test_with_return_2(my_fixture):
    assert my_fixture == 123

def test_with_return_3(my_fixture):
    assert my_fixture == 123

def test_with_return_4(my_fixture):
    assert my_fixture == 123

def test_with_return_5(my_fixture):
    assert my_fixture == 123
