#  Quapp Platform Project
#  job_status_const.py
#  Copyright © CITYNOW Co. Ltd. All rights reserved.
FAILED = 'FAILED'
COMPLETED = 'COMPLETED'
STATUS = 'status'
