gherila
-------

An async package destioned to fetch information from different platforms

contributing
------------

U can help with new platforms, ideas & bug fixes by making a pull request.
