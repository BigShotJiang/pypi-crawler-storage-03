from ..main.code_injection.codec import pascal_to_snake
