"""
assetful class
"""

__all__ = ["assetful"]


class assetful:

    def __init__(self) -> None:
        pass
