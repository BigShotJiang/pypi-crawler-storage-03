"""
config class
"""

__all__ = ["config", "config_langful", "config_assetful"]


class config:

    def __init__(self) -> None:
        pass


class config_langful(config):

    def __init__(self) -> None:
        pass


class config_assetful(config):

    def __init__(self) -> None:
        pass
