"""
provides internationalization for python
"""

from .func import *
from .default import *
from .langful import *

__version__ = "1.0.6"
