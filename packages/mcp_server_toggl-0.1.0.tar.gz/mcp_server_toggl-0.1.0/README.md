# Toggl MCP Server

A Model Context Protocol server that provides tools to fetch and manage Toggl Track data.

> [!CAUTION]
> This server can access the Toggl Track website and may represent a security risk. Exercise caution when using this MCP server to ensure this does not expose any sensitive data.

