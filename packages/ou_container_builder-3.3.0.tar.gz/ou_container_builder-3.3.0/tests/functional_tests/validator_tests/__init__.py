"""Tests for the settings validation."""
