"""The main OU Container Builder commandline application.

Run ``ou-container-builder --help`` for help with the command-line parameters.
"""

from ou_container_builder.cli import app

if __name__ == "__main__":
    app()
