"""The core CLI Typer app."""

from ou_container_builder.cli import clean, build, generate, version  # noqa: I001, F401
from ou_container_builder.cli.base import app  # noqa: F401
