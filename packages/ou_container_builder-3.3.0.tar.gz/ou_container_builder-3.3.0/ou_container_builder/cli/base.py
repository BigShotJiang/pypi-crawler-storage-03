"""The core CLI typer App."""

import typer

app = typer.Typer()
