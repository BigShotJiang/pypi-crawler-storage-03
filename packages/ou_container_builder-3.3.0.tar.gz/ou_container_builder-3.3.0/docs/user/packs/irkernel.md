# IRkernel

Use the `irkernel` pack to install the [IRkernel](https://irkernel.github.io/) into the user python environment.
This provides an R kernel for notebooks in either the {doc}`jupyterlab` or {doc}`notebook` interfaces:

:::{code-block} yaml
packs:
  irkernel: {}
:::
