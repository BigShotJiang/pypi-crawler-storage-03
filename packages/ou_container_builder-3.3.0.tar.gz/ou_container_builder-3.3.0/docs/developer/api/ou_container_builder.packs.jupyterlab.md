# `ou_container_builder.packs.jupyterlab`

```{eval-rst}
.. automodule:: ou_container_builder.packs.jupyterlab
   :members:
```
