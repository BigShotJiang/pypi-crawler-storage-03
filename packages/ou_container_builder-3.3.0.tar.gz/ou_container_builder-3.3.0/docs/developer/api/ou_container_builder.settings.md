# `ou_container_builder.settings`

```{eval-rst}
.. automodule:: ou_container_builder.settings
   :members:
```
