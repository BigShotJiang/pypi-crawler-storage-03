# `ou_container_builder.__about__`

```{eval-rst}
.. automodule:: ou_container_builder.__about__
   :members:
```
