# `ou_container_builder.cli.clean`

```{eval-rst}
.. automodule:: ou_container_builder.cli.clean
   :members:
```
