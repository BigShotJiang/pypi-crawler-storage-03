# `ou_container_builder.packs.ipykernel`

```{eval-rst}
.. automodule:: ou_container_builder.packs.ipykernel
   :members:
```
