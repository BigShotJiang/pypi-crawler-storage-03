from .readconfig import CONFIG  # noqa: F401
