from __future__ import annotations


__all__ = ['router_logger']


from logging import getLogger


router_logger = getLogger('eventry')
