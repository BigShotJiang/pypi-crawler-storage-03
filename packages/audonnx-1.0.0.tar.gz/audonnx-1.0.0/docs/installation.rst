Installation
============

To install :mod:`audonnx` run:

.. code-block:: bash

    $ # Create and activate Python virtual environment, e.g.
    $ # virtualenv --no-download --python=python3 ${HOME}/.envs/audonnx
    $ # source ${HOME}/.envs/audonnx/bin/activate
    $ pip install audonnx
