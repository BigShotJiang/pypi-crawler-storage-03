from audonnx.core.testing import create_model
from audonnx.core.testing import create_model_proto
