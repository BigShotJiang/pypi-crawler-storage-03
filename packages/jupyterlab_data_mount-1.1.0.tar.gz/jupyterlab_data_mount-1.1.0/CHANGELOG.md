# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 1.1.0

([Full Changelog](https://github.com/jsc-jupyter/jupyterlab-data-mount/compare/v1.0.0...8c402a601f3a5b16d3a87f5442982568f62ddb45))

### Enhancements made

- 3 add nfs [#8](https://github.com/jsc-jupyter/jupyterlab-data-mount/pull/8) ([@kreuzert](https://github.com/kreuzert))
- add remember feature [#7](https://github.com/jsc-jupyter/jupyterlab-data-mount/pull/7) ([@kreuzert](https://github.com/kreuzert))
- remove element from sidebar when unmount fails [#6](https://github.com/jsc-jupyter/jupyterlab-data-mount/pull/6) ([@kreuzert](https://github.com/kreuzert))

### Bugs fixed

- support dark theme [#4](https://github.com/jsc-jupyter/jupyterlab-data-mount/pull/4) ([@kreuzert](https://github.com/kreuzert))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jsc-jupyter/jupyterlab-data-mount/graphs/contributors?from=2025-05-16&to=2025-08-19&type=c))

[@kreuzert](https://github.com/search?q=repo%3Ajsc-jupyter%2Fjupyterlab-data-mount+involves%3Akreuzert+updated%3A2025-05-16..2025-08-19&type=Issues)

<!-- <END NEW CHANGELOG ENTRY> -->

## 1.0.0

No merged PRs

## 0.2.0

No merged PRs

## 0.1.7

No merged PRs

## 0.1.6

No merged PRs

## 0.1.5

No merged PRs

## 0.1.4

No merged PRs

## 0.1.3

No merged PRs

## 0.1.2

No merged PRs

## 0.1.1

No merged PRs
