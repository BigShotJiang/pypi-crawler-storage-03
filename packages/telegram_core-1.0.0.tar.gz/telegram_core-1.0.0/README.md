# telegram-core
The modern MTProto wrapper and Telegram user API client
