Command-line (``ome_zarr.cli``)
===============================

.. automodule:: ome_zarr.cli
   :members:
