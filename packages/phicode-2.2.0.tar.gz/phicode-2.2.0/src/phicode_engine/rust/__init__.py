from .phirust_accelerator import try_rust_acceleration
from .phirust_cli import handle_rust_commands

__all__ = ["try_rust_acceleration", "handle_rust_commands"]