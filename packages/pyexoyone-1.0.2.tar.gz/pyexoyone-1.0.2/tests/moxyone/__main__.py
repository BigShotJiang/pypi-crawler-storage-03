# type: ignore

"""Make MoxyOne runnable as a module."""

from .moxyone import app

app()
