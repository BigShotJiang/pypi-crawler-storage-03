# ExoyOne CLI.

from .cli import app

__all__ = ["app"]
