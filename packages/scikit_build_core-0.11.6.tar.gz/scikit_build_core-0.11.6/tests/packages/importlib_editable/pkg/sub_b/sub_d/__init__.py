# ruff: noqa: I001, F401
# mypy: ignore-errors

from .pmod_e import square as psquare_e
from .emod_e import square as esquare_e
