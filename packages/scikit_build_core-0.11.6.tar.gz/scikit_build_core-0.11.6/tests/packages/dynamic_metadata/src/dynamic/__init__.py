from ._module import square

__all__ = ["square"]
