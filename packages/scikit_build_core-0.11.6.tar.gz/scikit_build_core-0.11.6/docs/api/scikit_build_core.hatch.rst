scikit\_build\_core.hatch package
=================================

.. automodule:: scikit_build_core.hatch
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

scikit\_build\_core.hatch.hooks module
--------------------------------------

.. automodule:: scikit_build_core.hatch.hooks
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.hatch.plugin module
---------------------------------------

.. automodule:: scikit_build_core.hatch.plugin
   :members:
   :show-inheritance:
   :undoc-members:
