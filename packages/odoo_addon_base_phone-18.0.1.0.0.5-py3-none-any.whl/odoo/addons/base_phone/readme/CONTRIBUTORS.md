- Alexis de Lattre \<<alexis.delattre@akretion.com>\>
- Sébastien Beau \<<sebastien.beau@akretion.com>\>
- [Dixmit](https://www.dixmit.com):
  - Luis David Rodríguez
  - Enric Tobella
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia

