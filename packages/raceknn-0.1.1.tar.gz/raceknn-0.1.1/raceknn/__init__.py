# src/raceknn/__init__.py
from .raceknn import RACEKNNClassifier
