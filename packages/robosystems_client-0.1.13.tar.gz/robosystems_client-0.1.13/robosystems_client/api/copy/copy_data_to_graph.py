from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.copy_response import CopyResponse
from ...models.data_frame_copy_request import DataFrameCopyRequest
from ...models.http_validation_error import HTTPValidationError
from ...models.s3_copy_request import S3CopyRequest
from ...models.url_copy_request import URLCopyRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
  graph_id: str,
  *,
  body: Union["DataFrameCopyRequest", "S3CopyRequest", "URLCopyRequest"],
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> dict[str, Any]:
  headers: dict[str, Any] = {}
  if not isinstance(authorization, Unset):
    headers["authorization"] = authorization

  cookies = {}
  if auth_token is not UNSET:
    cookies["auth-token"] = auth_token

  _kwargs: dict[str, Any] = {
    "method": "post",
    "url": f"/v1/{graph_id}/copy",
    "cookies": cookies,
  }

  _kwargs["json"]: dict[str, Any]
  if isinstance(body, S3CopyRequest):
    _kwargs["json"] = body.to_dict()
  elif isinstance(body, URLCopyRequest):
    _kwargs["json"] = body.to_dict()
  else:
    _kwargs["json"] = body.to_dict()

  headers["Content-Type"] = "application/json"

  _kwargs["headers"] = headers
  return _kwargs


def _parse_response(
  *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[CopyResponse, HTTPValidationError]]:
  if response.status_code == 200:
    response_200 = CopyResponse.from_dict(response.json())

    return response_200
  if response.status_code == 422:
    response_422 = HTTPValidationError.from_dict(response.json())

    return response_422
  if client.raise_on_unexpected_status:
    raise errors.UnexpectedStatus(response.status_code, response.content)
  else:
    return None


def _build_response(
  *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[CopyResponse, HTTPValidationError]]:
  return Response(
    status_code=HTTPStatus(response.status_code),
    content=response.content,
    headers=response.headers,
    parsed=_parse_response(client=client, response=response),
  )


def sync_detailed(
  graph_id: str,
  *,
  client: AuthenticatedClient,
  body: Union["DataFrameCopyRequest", "S3CopyRequest", "URLCopyRequest"],
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Response[Union[CopyResponse, HTTPValidationError]]:
  """Copy Data to Graph

   Copy data from external sources into the graph database.

  This endpoint supports multiple data sources through a unified interface:
  - **S3**: Copy from S3 buckets with user-provided credentials
  - **URL** (future): Copy from HTTP(S) URLs
  - **DataFrame** (future): Copy from uploaded DataFrames

  **Security:**
  - Requires write permissions to the target graph
  - **Not allowed on shared repositories** (sec, industry, economic) - these are read-only
  - User must provide their own AWS credentials for S3 access
  - All operations are logged for audit purposes

  **Tier Limits:**
  - Standard: 10GB max file size, 15 min timeout
  - Enterprise: 50GB max file size, 30 min timeout
  - Premium: 100GB max file size, 60 min timeout

  **Copy Options:**
  - `ignore_errors`: Skip duplicate/invalid rows (enables upsert-like behavior)
  - `extended_timeout`: Use extended timeout for large datasets
  - `validate_schema`: Validate source schema against target table

  Args:
      graph_id (str): Target graph identifier (user graphs only - shared repositories not
          allowed)
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (Union['DataFrameCopyRequest', 'S3CopyRequest', 'URLCopyRequest']):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Response[Union[CopyResponse, HTTPValidationError]]
  """

  kwargs = _get_kwargs(
    graph_id=graph_id,
    body=body,
    authorization=authorization,
    auth_token=auth_token,
  )

  response = client.get_httpx_client().request(
    **kwargs,
  )

  return _build_response(client=client, response=response)


def sync(
  graph_id: str,
  *,
  client: AuthenticatedClient,
  body: Union["DataFrameCopyRequest", "S3CopyRequest", "URLCopyRequest"],
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Optional[Union[CopyResponse, HTTPValidationError]]:
  """Copy Data to Graph

   Copy data from external sources into the graph database.

  This endpoint supports multiple data sources through a unified interface:
  - **S3**: Copy from S3 buckets with user-provided credentials
  - **URL** (future): Copy from HTTP(S) URLs
  - **DataFrame** (future): Copy from uploaded DataFrames

  **Security:**
  - Requires write permissions to the target graph
  - **Not allowed on shared repositories** (sec, industry, economic) - these are read-only
  - User must provide their own AWS credentials for S3 access
  - All operations are logged for audit purposes

  **Tier Limits:**
  - Standard: 10GB max file size, 15 min timeout
  - Enterprise: 50GB max file size, 30 min timeout
  - Premium: 100GB max file size, 60 min timeout

  **Copy Options:**
  - `ignore_errors`: Skip duplicate/invalid rows (enables upsert-like behavior)
  - `extended_timeout`: Use extended timeout for large datasets
  - `validate_schema`: Validate source schema against target table

  Args:
      graph_id (str): Target graph identifier (user graphs only - shared repositories not
          allowed)
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (Union['DataFrameCopyRequest', 'S3CopyRequest', 'URLCopyRequest']):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Union[CopyResponse, HTTPValidationError]
  """

  return sync_detailed(
    graph_id=graph_id,
    client=client,
    body=body,
    authorization=authorization,
    auth_token=auth_token,
  ).parsed


async def asyncio_detailed(
  graph_id: str,
  *,
  client: AuthenticatedClient,
  body: Union["DataFrameCopyRequest", "S3CopyRequest", "URLCopyRequest"],
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Response[Union[CopyResponse, HTTPValidationError]]:
  """Copy Data to Graph

   Copy data from external sources into the graph database.

  This endpoint supports multiple data sources through a unified interface:
  - **S3**: Copy from S3 buckets with user-provided credentials
  - **URL** (future): Copy from HTTP(S) URLs
  - **DataFrame** (future): Copy from uploaded DataFrames

  **Security:**
  - Requires write permissions to the target graph
  - **Not allowed on shared repositories** (sec, industry, economic) - these are read-only
  - User must provide their own AWS credentials for S3 access
  - All operations are logged for audit purposes

  **Tier Limits:**
  - Standard: 10GB max file size, 15 min timeout
  - Enterprise: 50GB max file size, 30 min timeout
  - Premium: 100GB max file size, 60 min timeout

  **Copy Options:**
  - `ignore_errors`: Skip duplicate/invalid rows (enables upsert-like behavior)
  - `extended_timeout`: Use extended timeout for large datasets
  - `validate_schema`: Validate source schema against target table

  Args:
      graph_id (str): Target graph identifier (user graphs only - shared repositories not
          allowed)
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (Union['DataFrameCopyRequest', 'S3CopyRequest', 'URLCopyRequest']):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Response[Union[CopyResponse, HTTPValidationError]]
  """

  kwargs = _get_kwargs(
    graph_id=graph_id,
    body=body,
    authorization=authorization,
    auth_token=auth_token,
  )

  response = await client.get_async_httpx_client().request(**kwargs)

  return _build_response(client=client, response=response)


async def asyncio(
  graph_id: str,
  *,
  client: AuthenticatedClient,
  body: Union["DataFrameCopyRequest", "S3CopyRequest", "URLCopyRequest"],
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Optional[Union[CopyResponse, HTTPValidationError]]:
  """Copy Data to Graph

   Copy data from external sources into the graph database.

  This endpoint supports multiple data sources through a unified interface:
  - **S3**: Copy from S3 buckets with user-provided credentials
  - **URL** (future): Copy from HTTP(S) URLs
  - **DataFrame** (future): Copy from uploaded DataFrames

  **Security:**
  - Requires write permissions to the target graph
  - **Not allowed on shared repositories** (sec, industry, economic) - these are read-only
  - User must provide their own AWS credentials for S3 access
  - All operations are logged for audit purposes

  **Tier Limits:**
  - Standard: 10GB max file size, 15 min timeout
  - Enterprise: 50GB max file size, 30 min timeout
  - Premium: 100GB max file size, 60 min timeout

  **Copy Options:**
  - `ignore_errors`: Skip duplicate/invalid rows (enables upsert-like behavior)
  - `extended_timeout`: Use extended timeout for large datasets
  - `validate_schema`: Validate source schema against target table

  Args:
      graph_id (str): Target graph identifier (user graphs only - shared repositories not
          allowed)
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (Union['DataFrameCopyRequest', 'S3CopyRequest', 'URLCopyRequest']):

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Union[CopyResponse, HTTPValidationError]
  """

  return (
    await asyncio_detailed(
      graph_id=graph_id,
      client=client,
      body=body,
      authorization=authorization,
      auth_token=auth_token,
    )
  ).parsed
