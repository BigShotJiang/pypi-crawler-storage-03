# Reference

## Report Generation

::: shirotsubaki.report.Report

::: shirotsubaki.report.ReportWithTabs
