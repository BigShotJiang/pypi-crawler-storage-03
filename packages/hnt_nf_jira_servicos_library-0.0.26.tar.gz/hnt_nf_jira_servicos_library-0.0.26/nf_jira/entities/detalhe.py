from pydantic import BaseModel

class Detalhe(BaseModel):
    ctg_nf: str="Y6"