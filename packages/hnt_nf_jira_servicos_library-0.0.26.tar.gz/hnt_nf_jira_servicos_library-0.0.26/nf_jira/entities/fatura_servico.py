from pydantic import BaseModel

class FaturaServico(BaseModel):
    cod_imposto : str