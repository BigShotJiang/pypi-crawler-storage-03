# License AGPL-3 - See https://www.gnu.org/licenses/agpl-3.0
from . import product_template
from . import account_move_line
