- Add initial fee information to membership analysis.

- Add some criteria for adding initial fee:  
  - Add initial fee if last membership ended x weeks/months/years ago
  - Add initial fee if last membership product_id is different
