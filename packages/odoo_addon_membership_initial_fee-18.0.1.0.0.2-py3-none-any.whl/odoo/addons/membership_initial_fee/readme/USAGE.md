Define a member product, and select 'Fixed amount' or 'Percentage of the
price' for invoicing an extra charge in the first invoice that is
created with this member product.

By default, a line with the description *Membership initial fee*. If you
want to change this text, you can set a different sale description in
the product used for the fee.
