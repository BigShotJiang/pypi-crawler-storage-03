Charge an initial fee when a partner is invoiced for the first time with
a member product.
