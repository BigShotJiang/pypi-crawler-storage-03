"""API package for the Multi-Agent Bot Framework.

Provides FastAPI endpoints for bot interactions and services.
"""
