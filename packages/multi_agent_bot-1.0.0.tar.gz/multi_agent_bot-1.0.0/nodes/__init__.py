# Nodes package initialization
# Contains LangGraph node implementations for the ProductBot application
