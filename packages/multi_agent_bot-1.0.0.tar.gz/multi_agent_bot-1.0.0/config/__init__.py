"""Configuration package for the Multi-Agent Bot Framework."""
