"""
Main Bot Implementations

Contains the different bot implementations that use the BaseBot class.
"""
