run the `git add -A && git status` and then `uv run precommit`
1. take whatever files changes that ruff format give you, no need to change by yourself
2. fix unit test
3. fix other
