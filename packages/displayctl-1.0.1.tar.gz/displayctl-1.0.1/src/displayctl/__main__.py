"""Allow displayctl to be run as a module with python -m displayctl."""

from displayctl.cli import main

if __name__ == '__main__':
    main()
