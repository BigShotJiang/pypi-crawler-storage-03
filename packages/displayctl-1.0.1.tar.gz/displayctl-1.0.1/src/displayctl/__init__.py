"""DisplayCtl - Display Configuration Manager for GNOME."""

__version__ = "1.0.0"
__author__ = "DisplayCtl Contributors"
__description__ = "Display Configuration Manager for GNOME"
