import pytest
import torch as th
from math import prod
from vidrial.kernels.reduce.binding import binding
from vidrial.py_utils.test_utils import diff

class SumReduce:
    str = "return a + b;"
    reference = lambda X, reduce_dims: th.sum(X, dim=reduce_dims)

class MaxReduce:
    str = "return a > b ? a : b;"
    @staticmethod
    def reference(X, reduce_dims):
        for i in reversed(sorted(reduce_dims)):
            X = th.max(X, dim=i).values
        return X

@pytest.mark.parametrize(
    ["dtype", "reduce_fn", "X_shape", "reduce_dims", "X_tile_shape", "thread_num", "smem_buffer_size"],
    [
        (int, SumReduce, (4, 8), (0,), None, 1, 512),
        (int, SumReduce, (4, 8), (1,), None, 2, 512),
        (int, SumReduce, (4, 8, 16), (2,), None, 4, 512),
        # (int, SumReduce, (4, 8), (0, 1), None, 8, 32), # TODO: support reducing all the dimensions
        (th.int32, SumReduce, (4, 8, 16), (0,2), None, 16, 256),
        (th.int32, SumReduce, (128, 32), (0,), None, 64, 512),
        (th.int32, SumReduce, (128, 32), (0,), None, 32, 512),
        (th.int32, SumReduce, (16, 8), (0,), None, 32, 128),
        (th.int32, SumReduce, (4, 8), (0,), None, 32, 32),
        (th.int32, SumReduce, (128, 1024), (0,), (128, 32), 32, 512),
        (th.float, SumReduce, (256, 1024), (1,), (4, 1024), 32, 4096),
        (th.float16, SumReduce, (128, 1024), (0,), (128, 32), 32, 2048),
        (int, MaxReduce, (4, 8), (0,), None, 1, 512),
        (int, MaxReduce, (4, 8), (1,), None, 2, 512),
        (int, MaxReduce, (4, 8, 16), (2,), None, 4, 512),
        (th.uint8, MaxReduce, (4, 8, 16), (0,1), None, 16, 64),
        (th.int32, MaxReduce, (128, 32), (0,), None, 64, 512),
        (th.int32, MaxReduce, (128, 32), (0,), None, 32, 512),
        (th.int32, MaxReduce, (16, 8), (0,), None, 32, 128),
    ]
)
def test_binding(dtype, reduce_fn, X_shape, reduce_dims, X_tile_shape, thread_num, smem_buffer_size):
    X_tile_shape = X_shape if X_tile_shape is None else X_tile_shape
    x_shape = [X_shape[i] for i in range(len(X_shape)) if i not in reduce_dims]
    X = th.randn(X_shape, device='cuda').to(dtype)
    x = th.empty(x_shape, device='cuda', dtype=dtype)
    binding(X, x, reduce_fn.str, reduce_dims, X_tile_shape, thread_num, smem_buffer_size)
    x_ref = reduce_fn.reference(X, reduce_dims)
    tol = 1e-1 if dtype == th.float16 else 1e-4
    diff(x, x_ref, atol=tol, rtol=tol)