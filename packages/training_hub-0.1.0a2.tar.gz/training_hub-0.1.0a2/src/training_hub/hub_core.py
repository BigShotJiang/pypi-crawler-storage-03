def welcome():
    print("Hello from training-hub!")
