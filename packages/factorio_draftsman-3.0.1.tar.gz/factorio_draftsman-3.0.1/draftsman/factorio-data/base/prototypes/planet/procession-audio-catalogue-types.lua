local procession_audio_catalogue_types = {}
procession_audio_catalogue_types.pod_reentry_flames   = 100
procession_audio_catalogue_types.pod_wings            = 101
procession_audio_catalogue_types.pod_ground_land      = 102
procession_audio_catalogue_types.pod_thruster_burst_1 = 201
procession_audio_catalogue_types.pod_thruster_burst_2 = 202
procession_audio_catalogue_types.pod_thruster_burst_3 = 203
procession_audio_catalogue_types.pod_thruster_burst_4 = 204
procession_audio_catalogue_types.rocket_claws_open  = 300
return procession_audio_catalogue_types
