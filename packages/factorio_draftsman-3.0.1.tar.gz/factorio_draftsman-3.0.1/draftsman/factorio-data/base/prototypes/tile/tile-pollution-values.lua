return
{
  out_of_map = { pollution = 0.0001   },
  water =      { pollution = 0.000025 },
  grass =      { pollution = 0.000018 },
  dirt =       { pollution = 0.000018 },
  sand =       { pollution = 0.000015 },
  red_desert = { pollution = 0.000015 }
}
