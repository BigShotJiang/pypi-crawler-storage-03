data:extend(
{
  {
    type = "resource-category",
    name = "basic-solid"
  },
  {
    type = "resource-category",
    name = "basic-fluid"
  },
}
)
