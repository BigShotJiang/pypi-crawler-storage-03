data:extend(
  {
    {
      type = "virtual-signal",
      name = "signal-any-quality",
      icon = "__core__/graphics/icons/any-quality.png",
      subgroup = "qualities",
      order = "z"
    }
  }
)
