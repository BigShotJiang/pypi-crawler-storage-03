data:extend(
{
  {
    type = "equipment-grid",
    name = "huge-equipment-grid",
    width = 10,
    height = 12,
    equipment_categories = {"armor"}
  }
}
)
