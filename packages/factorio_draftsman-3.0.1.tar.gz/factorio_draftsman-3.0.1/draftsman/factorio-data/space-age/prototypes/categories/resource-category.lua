data:extend(
{
  {
    type = "resource-category",
    name = "hard-solid"
  }
})
