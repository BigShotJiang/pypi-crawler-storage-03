data:extend(
{
  {
    type = "recipe-category",
    name = "chemistry-or-cryogenics"
  },
  {
    type = "recipe-category",
    name = "pressing"
  },
  {
    type = "recipe-category",
    name = "crushing"
  },
  {
    type = "recipe-category",
    name = "crafting-with-fluid-or-metallurgy"
  },
  {
    type = "recipe-category",
    name = "metallurgy-or-assembling"
  },
  {
    type = "recipe-category",
    name = "metallurgy"
  },
  {
    type = "recipe-category",
    name = "organic"
  },
  {
    type = "recipe-category",
    name = "organic-or-hand-crafting"
  },
  {
    type = "recipe-category",
    name = "organic-or-assembling"
  },
  {
    type = "recipe-category",
    name = "organic-or-chemistry"
  },
  {
    type = "recipe-category",
    name = "captive-spawner-process"
  },
  {
    type = "recipe-category",
    name = "electronics-or-assembling"
  },
  {
    type = "recipe-category",
    name = "electronics"
  },
  {
    type = "recipe-category",
    name = "electronics-with-fluid"
  },
  {
    type = "recipe-category",
    name = "electromagnetics"
  },
  {
    type = "recipe-category",
    name = "cryogenics-or-assembling"
  },
  {
    type = "recipe-category",
    name = "cryogenics"
  }
})
