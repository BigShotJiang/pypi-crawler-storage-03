return
{
  platform_to_planet_duration_a = 400,
  platform_to_planet_duration_b = 600,
  platform_to_planet_hatch_open = 180,

  impostor_start_tick = 400,
  rocket_separation_tick = 700,
  rocket_separation_end_tick = 700 + 100,
  flight_duration = 1200,
  solo_duration = 800,
}
