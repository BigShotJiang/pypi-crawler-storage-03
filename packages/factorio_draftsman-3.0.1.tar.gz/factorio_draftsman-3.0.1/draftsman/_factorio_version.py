# _factorio_version.py

__factorio_version__ = "1.0.0.0"
__factorio_version_info__ = (1, 0, 0, 0)
