#! /usr/bin/env bash

function bluer_ai_wifi_diagnose() {
    bluer_ai_browse http://router.miwifi.com/cgi-bin/luci/diagnosis
}
