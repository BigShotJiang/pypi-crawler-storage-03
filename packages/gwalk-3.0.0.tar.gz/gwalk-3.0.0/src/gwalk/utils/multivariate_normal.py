#!/usr/bin/env python3
''' Provide links to gwalk.multivariate_normal for legacy reasons
'''
from gwalk.multivariate_normal import *
