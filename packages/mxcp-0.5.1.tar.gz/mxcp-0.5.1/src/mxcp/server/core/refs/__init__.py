"""Reference resolution for MXCP.

This module handles external reference resolution including environment variables,
file references, and external systems like Vault and 1Password.
"""
