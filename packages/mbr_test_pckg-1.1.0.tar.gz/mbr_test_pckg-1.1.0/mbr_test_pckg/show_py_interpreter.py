import sys

def show_path():
    print( '--- Start ---')
    print( 'Running skript in Python interpreter: ', sys.executable)
    print( '--- End ---')
