import versup.command_line


def main() -> None:
    versup.command_line.main()


if __name__ == "__main__":
    main()
