#!/bin/sh

set -eux

python3 -c "import ogr"
