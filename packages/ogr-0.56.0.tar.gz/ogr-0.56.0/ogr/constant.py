# Copyright Contributors to the Packit project.
# SPDX-License-Identifier: MIT

CLONE_TIMEOUT = 60
DEFAULT_RO_PREFIX_STRING = "READ ONLY: "
