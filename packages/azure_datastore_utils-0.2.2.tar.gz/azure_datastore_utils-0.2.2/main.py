
import asyncio

async def main():
    print("Running main.py ...")

if __name__ == '__main__':
    asyncio.run(main())
