# CodeBangla

<div align="center">

![CodeBangla Logo](logo.png)

**Advanced Python transpiler for writing Python code using Bangla keywords**

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Typed with mypy](http://www.mypy-lang.org/static/mypy_badge.svg)](http://mypy-lang.org/)

[Features](#-features) • [Installation](#-installation) • [Quick Start](#-quick-start) • [Documentation](#-documentation) • [Contributing](#-contributing)

</div>

---

**CodeBangla** is a professional-grade Python transpiler that enables developers to write Python code using Bangla keywords (in English transliteration). Designed to make programming more accessible for Bengali speakers while maintaining full compatibility with the Python ecosystem.

## ✨ Features

### 🚀 **Complete Python Support**
- **Modern Python Features**: Full support for async/await, type hints, decorators, context managers
- **All Python Constructs**: Classes, functions, exceptions, comprehensions, generators
- **Python 3.8+ Compatible**: Supports latest Python versions and features

### 🔧 **Advanced Transpilation Engine**
- **AST-Based Processing**: Sophisticated parsing and transformation
- **Error Recovery**: Intelligent error handling and suggestions
- **Source Mapping**: Debug transpiled code with original line numbers
- **Performance Optimized**: Fast transpilation with caching support

### 🛡️ **Professional Tooling**
- **Type Checking**: Optional static type analysis
- **Strict Mode**: Enhanced validation and error checking
- **Plugin Architecture**: Extensible with custom transformations
- **CLI Tools**: Comprehensive command-line interface

### 🌐 **Internationalization**
- **Unicode Normalized**: Proper handling of Bangla text and numerals
- **Mixed Scripts**: Support for mixed Bangla-English codebases
- **Cultural Context**: Keywords designed for Bengali programming concepts

## 📦 Installation

### Quick Install
```bash
pip install codebangla
```

### Development Install
```bash
git clone https://github.com/saky-semicolon/codebangla.git
cd codebangla
pip install -e ".[dev,docs,test]"
```

### Verify Installation
```bash
codebangla --version
codebangla info
```

## 🚀 Quick Start

### Your First Program
Create a file `hello.bp`:
```python
# hello.bp
shuru main():
    naam = neoa("আপনার নাম কি? ")
    chhap(f"আসসালামু আলাইকুম, {naam}!")

jodi __name__ == "__main__":
    main()
```

### Run It
```bash
codebangla run hello.bp
```

### Compile to Python
```bash
codebangla compile hello.bp -o hello.py
```

## 📚 Language Reference

### 🔤 Core Keywords

| Bangla | Python | Description |
|--------|--------|-------------|
| `chhap` | `print` | Print output |
| `neoa` | `input` | Get input |
| `jodi` | `if` | Conditional statement |
| `noile` | `else` | Else clause |
| `noile_jodi` | `elif` | Else-if clause |
| `jotokkhon` | `while` | While loop |
| `er_jonno` | `for` | For loop |
| `moddhe` | `in` | Membership test |
| `shuru` | `def` | Function definition |
| `classh` | `class` | Class definition |
| `phiredao` | `return` | Return statement |
| `thamo` | `break` | Break loop |
| `chaliye_jao` | `continue` | Continue loop |

### ⚡ Modern Features

| Bangla | Python | Description |
|--------|--------|-------------|
| `ashinchronous` | `async` | Async function |
| `opeksha` | `await` | Await expression |
| `sathe` | `with` | Context manager |
| `chesta_koro` | `try` | Try block |
| `dhoro` | `except` | Exception handler |
| `seshe` | `finally` | Finally block |
| `uththapon` | `raise` | Raise exception |
| `tulona` | `assert` | Assertion |

### 🏗️ Data Types

| Bangla | Python | Description |
|--------|--------|-------------|
| `shongkhya` | `int` | Integer |
| `tothyo` | `float` | Float |
| `shobdo` | `str` | String |
| `talika` | `list` | List |
| `obhidhan` | `dict` | Dictionary |
| `jora` | `tuple` | Tuple |
| `shongroho` | `set` | Set |
| `sotti` | `True` | Boolean True |
| `miththa` | `False` | Boolean False |
| `shunno` | `None` | None value |

## 📖 Advanced Examples

### Object-Oriented Programming
```python
# person.bp
classh Person:
    shuru __init__(nijei, naam: shobdo, boyosh: shongkhya):
        nijei.naam = naam
        nijei.boyosh = boyosh
    
    shuru greet(nijei) -> shobdo:
        phiredao f"আমার নাম {nijei.naam}, বয়স {nijei.boyosh}"
    
    shuru birthday(nijei):
        nijei.boyosh += 1
        chhap(f"{nijei.naam} এর জন্মদিন! এখন বয়স {nijei.boyosh}")

# Usage
person = Person("আহমেদ", 25)
chhap(person.greet())
person.birthday()
```

### Async Programming
```python
# async_example.bp
theke asyncio ano sleep

ashinchronous shuru fetch_data(url: shobdo) -> obhidhan:
    chhap(f"Fetching data from {url}")
    opeksha sleep(1)  # Simulate network delay
    phiredao {"url": url, "data": "Sample data"}

ashinchronous shuru main():
    urls = ["http://api1.com", "http://api2.com", "http://api3.com"]
    
    er_jonno url moddhe urls:
        result = opeksha fetch_data(url)
        chhap(f"Received: {result}")

jodi __name__ == "__main__":
    theke asyncio ano run
    run(main())
```

### Error Handling
```python
# error_handling.bp
shuru divide(a: tothyo, b: tothyo) -> tothyo:
    chesta_koro:
        result = a / b
        phiredao result
    dhoro ZeroDivisionError:
        chhap("ভাগ করা যায় না শূন্য দিয়ে!")
        phiredao 0.0
    dhoro TypeError hishabe e:
        chhap(f"ভুল ডাটা টাইপ: {e}")
        uththapon e
    seshe:
        chhap("গণনা সম্পন্ন")

# Usage
result1 = divide(10, 2)    # Normal case
result2 = divide(10, 0)    # Zero division
result3 = divide("10", 2)  # Type error
```

## �️ CLI Reference

### Basic Commands
```bash
# Run a CodeBangla file
codebangla run myfile.bp

# Compile to Python
codebangla compile myfile.bp -o myfile.py

# Interactive REPL
codebangla repl

# Validate code
codebangla validate myfile.bp

# Create new project
codebangla init myproject --template advanced
```

### Advanced Options
```bash
# Enable strict mode
codebangla run myfile.bp --strict

# Watch for changes
codebangla run myfile.bp --watch

# Enable profiling
codebangla compile myfile.bp --profile

# Format output
codebangla compile myfile.bp --format black

# Enable debugging
codebangla run myfile.bp --debug
```

### Project Management
```bash
# Initialize project with template
codebangla init my-web-app --template web --author "আপনার নাম"

# Show system information
codebangla info

# List available keywords
codebangla keywords --category core

# Search keywords
codebangla keywords --search "print"
```

## ⚙️ Configuration

Create `codebangla.json` in your project:
```json
{
  "name": "my-project",
  "version": "1.0.0",
  "author": "Your Name",
  "license": "MIT",
  "transpiler": {
    "strict_mode": false,
    "enable_type_checking": true,
    "enable_async_support": true,
    "target_python_version": [3, 8],
    "plugins": []
  }
}
```

## 🧪 Testing

```bash
# Run tests
pytest

# Run with coverage
pytest --cov=codebangla

# Run performance benchmarks
pytest --benchmark-only

# Run specific test categories
pytest -m "not slow"  # Skip slow tests
pytest -m integration  # Integration tests only
```

## 📊 Performance

CodeBangla is optimized for performance:

- **Fast Transpilation**: Sub-millisecond transpilation for typical files
- **Memory Efficient**: Minimal memory overhead during processing
- **Caching**: Intelligent caching of transpilation results
- **Parallel Processing**: Multi-threaded processing for large projects

### Benchmarks
```
Small file (< 1KB):     ~0.1ms
Medium file (10KB):     ~1ms
Large file (100KB):     ~10ms
Very large (1MB):       ~100ms
```

## � API Reference

### Programmatic Usage
```python
from codebangla import AdvancedTranspiler, TranspilerConfig

# Basic usage
from codebangla import transpile
result = transpile('chhap("Hello")')

# Advanced usage
config = TranspilerConfig(
    strict_mode=True,
    enable_type_checking=True,
    enable_debugging=True
)

transpiler = AdvancedTranspiler(config)
result = transpiler.transpile(source_code, filename="test.bp")

if result.success:
    print("Transpiled code:", result.code)
    exec(result.code)
else:
    print("Errors:", result.errors)
    print("Warnings:", result.warnings)
```

### Tokenization
```python
from codebangla.tokenizer import AdvancedTokenizer

tokenizer = AdvancedTokenizer()
tokens = tokenizer.tokenize('chhap("Hello")')

for token in tokens:
    print(f"{token.type}: {token.value} -> {token.python_equivalent}")
```

## 🤝 Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Development Setup
```bash
git clone https://github.com/saky-semicolon/codebangla.git
cd codebangla
pip install -e ".[dev]"
pre-commit install
```

### Code Quality
```bash
# Format code
black codebangla tests
isort codebangla tests

# Lint code
flake8 codebangla tests
mypy codebangla

# Run all checks
tox
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Inspired by the need to make programming accessible to Bengali speakers
- Built on Python's robust tokenization and AST infrastructure
- Thanks to the open-source community for tools and libraries

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/saky-semicolon/codebangla/issues)
- **Discussions**: [GitHub Discussions](https://github.com/saky-semicolon/codebangla/discussions)
- **Documentation**: [Read the Docs](https://codebangla.readthedocs.io)
- **Email**: team@codebangla.org

---

<div align="center">

**Made with ❤️ for the Bengali programming community**

[⭐ Star us on GitHub](https://github.com/saky-semicolon/codebangla) • [🐦 Follow on Twitter](https://twitter.com/codebangla) • [💬 Join Discord](https://discord.gg/codebangla)

</div>