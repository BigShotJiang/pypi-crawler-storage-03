from stimupy import components, noises, stimuli


def test_components():
    components.overview()


def test_noises():
    noises.overview()


def test_stimuli():
    stimuli.overview()
