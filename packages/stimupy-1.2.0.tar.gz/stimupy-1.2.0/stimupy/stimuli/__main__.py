from stimupy.stimuli import plot_overview

if __name__ == "__main__":
    plot_overview()
