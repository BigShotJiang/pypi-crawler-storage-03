"""S3Ranger - A terminal-based user interface for browsing and managing AWS S3 buckets and objects."""

__version__ = "1.0.0"
