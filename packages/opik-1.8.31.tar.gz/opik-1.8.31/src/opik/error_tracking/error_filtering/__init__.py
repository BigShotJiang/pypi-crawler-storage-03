from . import filter_chain_builder

sentry_filter_chain = filter_chain_builder.build_filter_chain()
