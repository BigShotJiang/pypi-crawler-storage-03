## cdf 

### Added

- [alpha] In the `cdf purge instances` you can now unlink files

## templates

No changes.