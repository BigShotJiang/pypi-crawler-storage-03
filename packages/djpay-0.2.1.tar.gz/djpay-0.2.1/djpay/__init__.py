"""
DJPay
"""

__title__ = "DJPay"
__version__ = "0.2.1"
__author__ = "Kaveh Mehrbanian"
