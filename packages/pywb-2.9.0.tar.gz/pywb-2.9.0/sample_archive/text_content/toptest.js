!function(){top!==window&&(alert("For security reasons, framing is not allowed."),top.location.replace(document.location))}
