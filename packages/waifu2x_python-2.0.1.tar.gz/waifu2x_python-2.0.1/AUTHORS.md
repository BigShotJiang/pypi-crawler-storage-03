# Authors

## Project Lead

- Gleidson Rodrigues Nunes <gleidsonrnunes@gmail.com>

## Contributors

- AI Assistant - Documentation and code improvements

## Acknowledgements

- Thanks to all contributors who have submitted issues, pull requests, and provided feedback.
- Special thanks to the developers of waifu2x-ncnn-vulkan for their amazing work.
- Thanks to the open source community for their support and contributions.
