"""
Copyright (c) 2025 by Michal Perzel. All rights reserved.

License: MIT
"""

from .common_log_line import CommonLogLineBase
from .common_logger import common_logger
