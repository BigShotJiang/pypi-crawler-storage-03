"""
Copyright (c) 2025 by Michal Perzel. All rights reserved.

License: MIT
"""

from .check_return_value_type import CheckReturnValueType
from .except_base_exception import ExceptBaseException
