def run_defender():
	pass
