# Safe winreg wrappers (stub)
