# Manage startup folder items
