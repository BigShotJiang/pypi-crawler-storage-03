def clean_browser_caches():
	pass
