def clean_windows_temp():
	pass
