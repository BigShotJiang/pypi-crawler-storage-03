# Dumps, thumbnails, font cache cleaner (stub)
