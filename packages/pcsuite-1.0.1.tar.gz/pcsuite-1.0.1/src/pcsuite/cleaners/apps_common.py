def clean_apps_common():
	pass
