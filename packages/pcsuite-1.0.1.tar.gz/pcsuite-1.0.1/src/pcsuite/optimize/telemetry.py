def optimize_telemetry():
	pass
