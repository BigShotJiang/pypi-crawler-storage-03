def optimize_explorer_ux():
	pass
