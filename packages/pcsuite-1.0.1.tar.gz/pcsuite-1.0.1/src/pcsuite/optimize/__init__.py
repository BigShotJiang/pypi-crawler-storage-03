# optimize package init
