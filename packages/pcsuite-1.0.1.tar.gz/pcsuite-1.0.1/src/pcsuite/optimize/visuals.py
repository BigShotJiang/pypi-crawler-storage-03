def optimize_visuals():
	pass
