def optimize_ssd_hdd():
	pass
