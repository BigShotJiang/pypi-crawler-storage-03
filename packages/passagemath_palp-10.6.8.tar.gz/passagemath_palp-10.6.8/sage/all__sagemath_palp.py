# sage_setup: distribution = sagemath-palp
# delvewheel: patch

from sage.all__sagemath_polyhedra import *
