"""This module implements custom YAML representer functions"""
