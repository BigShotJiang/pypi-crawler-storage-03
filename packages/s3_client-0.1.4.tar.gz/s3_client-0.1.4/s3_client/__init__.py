# -*- coding: utf-8 -*-
"""s3_client module."""

__version__ = "0.1.4"

# vim: ts=4
