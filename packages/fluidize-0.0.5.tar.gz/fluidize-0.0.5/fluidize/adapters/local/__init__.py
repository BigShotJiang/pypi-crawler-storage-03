"""
Local adapter implementation.
"""

from .adapter import LocalAdapter

__all__ = ["LocalAdapter"]
