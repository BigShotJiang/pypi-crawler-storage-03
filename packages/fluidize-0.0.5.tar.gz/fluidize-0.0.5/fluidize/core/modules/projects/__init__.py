"""Projects module for local filesystem operations."""
