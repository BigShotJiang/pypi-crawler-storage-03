# Unit tests for logger utilities
