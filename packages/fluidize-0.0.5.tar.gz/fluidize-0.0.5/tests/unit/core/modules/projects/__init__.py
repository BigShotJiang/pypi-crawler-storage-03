"""Projects module unit tests."""
