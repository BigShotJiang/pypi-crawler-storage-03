"""
Tests for the package `profile-translator`.
"""
