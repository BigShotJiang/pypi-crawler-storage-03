from .Transport import Transport

class udp(Transport):
    
    # Class variables
    protocol_name = "udp"  # Protocol name
