class StarConsumersException(Exception):
    pass


class StarConsumersCLIException(Exception):
    pass


class RetryException(Exception):
    pass


class DropException(Exception):
    pass
