from .wginteractive import main

main()
