{
  "name": "Widget-Demo",
  "version": "1.0",
  "parent_widget_id": "",
  "widget_id": "",
  "group_id": "58b32fde-a39d-58b3-b98e-30f48fd225b5",
  "cmd": "",
  "max_task_number": "",
  "data": {
    "fn_name": [
    ]
  }
}