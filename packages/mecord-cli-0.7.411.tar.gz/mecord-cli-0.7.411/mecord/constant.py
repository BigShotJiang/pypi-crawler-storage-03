#!!!!! do not change this file !!!!!
app_version="0.7.411"
app_bulld_number=7411
app_bulld_anchor="zhaojiasheng@mecord668.com_2025-08-25 11:50:41.460283"
app_name="mecord-cli"
