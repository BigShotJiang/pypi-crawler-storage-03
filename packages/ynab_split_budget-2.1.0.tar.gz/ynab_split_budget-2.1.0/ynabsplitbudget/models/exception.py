

class BudgetNotFound(Exception):
	pass


class AccountNotFound(Exception):
	pass


class SplitNotValid(Exception):
	pass


class UserNotFound(Exception):
	pass


class ConfigNotValid(Exception):
	pass


class BalancesDontMatch(Exception):
	pass
