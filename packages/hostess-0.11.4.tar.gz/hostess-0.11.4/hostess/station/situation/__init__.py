from ._textual_monkeypatch import patch_textual_invoke

patch_textual_invoke()
