"""
settings in this module override settings in config.py, and may also be
used to define settings that do not exist in config.py, none of which
are currently imagined.
"""
GENERAL_DEFAULTS = {"uname": "ubuntu"}
