----------------------------------------
Create a python platform wheel for Linux
----------------------------------------

.. literalinclude:: ../../../templates/python-create-wheel-manylinux/template.yml
   :language: yaml