----------------------------
Run a coverage job in python
----------------------------

.. literalinclude:: ../../../templates/python-run-coverage/template.yml
   :language: yaml