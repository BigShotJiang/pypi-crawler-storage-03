----------------------------------------
Create and publish a python client wheel
----------------------------------------

.. literalinclude:: ../../../templates/python-create-wheel-openapi/template.yml
   :language: yaml