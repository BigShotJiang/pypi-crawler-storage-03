---------------------------
Create a custom mirror jobs
---------------------------

.. literalinclude:: ../../../templates/project-mirror/template.yml
   :language: yaml