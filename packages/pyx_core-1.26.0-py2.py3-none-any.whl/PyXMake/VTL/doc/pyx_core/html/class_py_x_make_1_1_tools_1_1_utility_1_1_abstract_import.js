var class_py_x_make_1_1_tools_1_1_utility_1_1_abstract_import =
[
    [ "__init__", "class_py_x_make_1_1_tools_1_1_utility_1_1_abstract_import.html#af7c0bbee988df42f26c305ffcd47cf61", null ],
    [ "__new__", "class_py_x_make_1_1_tools_1_1_utility_1_1_abstract_import.html#af1b69a74c2203bce96b7b72726278d6e", null ]
];