var namespaces_dup =
[
    [ "PyXMake", "namespace_py_x_make.html", "namespace_py_x_make" ]
];