// Copyright 2016 Pixar
//
// Licensed under the terms set forth in the LICENSE.txt file available at
// https://openusd.org/license.
//
// Modified by Jeremy Retailleau.

#include "pxr/tf/pxr.h"
#include <pxr/arch/env.h>
#include "pxr/tf/setenv.h"
#include "pxr/tf/diagnostic.h"
#include <pxr/arch/errno.h>

#ifdef PXR_PYTHON_SUPPORT_ENABLED
#include "pxr/tf/pyUtils.h"
#endif // PXR_PYTHON_SUPPORT_ENABLED

TF_NAMESPACE_OPEN_SCOPE

bool
TfSetenv(const std::string & name, const std::string & value)
{
#ifdef PXR_PYTHON_SUPPORT_ENABLED
    if (TfPyIsInitialized()) {
        return TfPySetenv(name, value);
    }
#endif // PXR_PYTHON_SUPPORT_ENABLED

    if (ArchSetEnv(name.c_str(), value.c_str(), /* overwrite */ true)) {
        return true;
    }

    TF_WARN("Error setting '%s': %s", name.c_str(), ArchStrerror().c_str());
    return false;
}

bool
TfUnsetenv(const std::string & name)
{
#ifdef PXR_PYTHON_SUPPORT_ENABLED
    if (TfPyIsInitialized()) {
        return TfPyUnsetenv(name);
    }
#endif // PXR_PYTHON_SUPPORT_ENABLED

    if (ArchRemoveEnv(name.c_str())) {
        return true;
    }

    TF_WARN("Error unsetting '%s': %s", name.c_str(), ArchStrerror().c_str());
    return false;
}

TF_NAMESPACE_CLOSE_SCOPE
