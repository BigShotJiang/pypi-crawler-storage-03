When installed, this module adds a new option in shopfloor to prevent
vendor packagings from being displayed in the frontend.
