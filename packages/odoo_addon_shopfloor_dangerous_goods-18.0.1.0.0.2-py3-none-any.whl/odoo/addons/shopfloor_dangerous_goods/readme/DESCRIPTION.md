This is a glue module between shopfloor and l10n_eu_product_adr
