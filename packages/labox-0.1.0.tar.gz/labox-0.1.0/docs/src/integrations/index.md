# Overview

Labox has built-in and third-party [components](../concepts/index.md) which can be added
to a [registry](../concepts/registry.md) that you pass when
[saving](../usage/index.md#saving-storables) and
[loading](../usage/index.md#loading-storables) storables.
