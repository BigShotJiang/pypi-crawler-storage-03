"""DuckDuckGo search backend for websearch tool."""

from .backend import DDGSBackend

__all__ = ["DDGSBackend"]
