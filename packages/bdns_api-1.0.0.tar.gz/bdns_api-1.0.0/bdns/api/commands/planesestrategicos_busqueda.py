# -*- coding: utf-8 -*-
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
# You should have received a copy of the GNU General Public License along
# with this program. If not, see <https://www.gnu.org/licenses/>.

from datetime import datetime
import asyncio

import typer

from bdns.api.utils import format_date_for_api_request, format_url
from bdns.api.types import Order, Direccion, DescripcionTipoBusqueda
from bdns.api.fetch_write import fetch_and_write_paginated
from bdns.api.commands import options
from bdns.api.endpoints import BDNS_API_ENDPOINT_PLANESESTRATEGICOS_BUSQUEDA


def planesestrategicos_busqueda(
    ctx: typer.Context,
    num_pages: int = options.num_pages,
    from_page: int = options.from_page,
    pageSize: int = options.pageSize,
    order: Order = options.order,
    direccion: Direccion = options.direccion,
    descripcion: str = options.descripcion,
    descripcionTipoBusqueda: DescripcionTipoBusqueda = options.descripcionTipoBusqueda,
    tipoAdministracion: str = options.tipoAdministracion,
    organos: list[int] = options.organos,
    vigenciaDesde: datetime = options.vigenciaDesde,
    vigenciaHasta: datetime = options.vigenciaHasta,
) -> None:
    """
    Fetches the list of registered strategic plans.
    """
    params = {
        "pageSize": pageSize,
        "order": order,
        "direccion": direccion,
        "descripcion": descripcion,
        "tipoAdministracion": tipoAdministracion,
        "descripcionTipoBusqueda": descripcionTipoBusqueda,
        "vigenciaDesde": format_date_for_api_request(vigenciaDesde),
        "vigenciaHasta": format_date_for_api_request(vigenciaHasta),
        "organos": organos,
    }
    asyncio.run(
        fetch_and_write_paginated(
            url=format_url(BDNS_API_ENDPOINT_PLANESESTRATEGICOS_BUSQUEDA, params),
            output_file=ctx.obj["output_file"],
            from_page=from_page,
            num_pages=num_pages,
            max_concurrent_requests=ctx.obj["max_concurrent_requests"],
        )
    )
