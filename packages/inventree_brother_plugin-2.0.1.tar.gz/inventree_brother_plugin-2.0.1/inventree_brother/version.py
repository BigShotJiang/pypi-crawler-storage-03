"""Version information for the plugin"""

BROTHER_PLUGIN_VERSION = "2.0.1"
