* pip install pip-tools

* pip-compile --upgrade
* pip-compile dev-requirements.in

* pip-sync

OR

* pip-sync requirements.txt dev-requirements.txt


## pre-commit

* pip install pre-commit

* pre-commit install