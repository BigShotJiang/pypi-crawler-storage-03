<h2>Changelog for dt-net package</h2>
<dl>
<dt><b>10/06/24 | 0.1.18  | Updates from several versions</b></dt>
<dd>Add wifi functions for nic and AP detection</dd>
<dd>MAC address fixes</dd>
<dd>Add get_workgroup_name()</dd>
<dd>Sync with other dt-* packages</dd>
<dd>Better feedback on WOL</dd>
<br>
<dt><b>08/02/24 | 0.1.0</b></dt>
<dd>Initial upload</dd>
</dl>