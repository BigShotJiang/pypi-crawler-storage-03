"""
Progress tracking for embeddings.
"""

class IndexingProgress:
    """Simple progress tracker."""
    pass