"""
Simple cache for embeddings.
"""

class EmbeddingCache:
    """Simple embedding cache."""
    pass