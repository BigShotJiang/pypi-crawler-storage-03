"""
Simple embedding manager.
"""

class EmbeddingManager:
    """Simple embedding manager."""
    pass