"""
Simple memory for embeddings.
"""

class ConversationMemory:
    """Simple conversation memory."""
    pass