"""
Simple search service for embeddings.
"""

class SearchService:
    """Simple search service."""
    pass