"""
Simple batch processor for embeddings.
"""

class BatchProcessor:
    """Simple batch processor."""
    pass