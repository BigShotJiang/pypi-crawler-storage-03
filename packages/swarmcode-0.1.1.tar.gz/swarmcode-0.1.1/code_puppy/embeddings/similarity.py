"""
Similarity functions for embeddings.
"""

def cosine_similarity(a, b):
    """Calculate cosine similarity."""
    pass

def euclidean_distance(a, b):
    """Calculate euclidean distance."""
    pass