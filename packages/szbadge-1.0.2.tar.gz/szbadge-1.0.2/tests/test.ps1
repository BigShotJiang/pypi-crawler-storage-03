<#
.SYNOPSIS
  OS-specific test for szbadge on Windows/PowerShell.

.DESCRIPTION
  Ensures the Lambda Function URL exists and is invokable,
  then makes a couple of test badge requests.

.NOTES
  Requires AWS CLI v2.
#>

[CmdletBinding()]
param(
    [string]$label   = "40%",
    [string]$message = "Valdezium"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$_Region = $env:AWS_REGION
if (-not $_Region) { $_Region = "us-east-2" }
$_FunctionName   = $env:SZBADGE_FUNC
if (-not $_FunctionName) { $_FunctionName = "szbadge" }

function Test-AwsCliV2 {
  $ver = aws --version 2>&1
  if ($ver -notmatch "^aws-cli\/1\.42\.\d\d.+?$") {
    Write-Error "AWS CLI v2 is required (found: $ver)"
  }
}

function Get-CurlPath {
  $curl = (Get-Command curl.exe -ErrorAction SilentlyContinue)
  if (-not $curl) { throw "curl.exe not found in PATH" }
  return $curl
}

function Assert-LambdaFuncExists {
  param([string]$func, [string]$region)
  $null = aws lambda get-function --function-name $func --region $region 2>$null
  if ($LASTEXITCODE -ne 0) {
    $null = aws lambda create-function-url-config --function-name $_FunctionName --auth-type NONE --region $_Region
  }
}
function Assert-PublicInvokePerm {
  param([string]$func, [string]$region)
  $policy = aws lambda get-policy --function-name $func --region $region 2>$null
  if ($LASTEXITCODE -ne 0 -or $policy -notmatch "FunctionURLAllowPublic") {
    $null = aws lambda add-permission `
      --function-name $func `
      --statement-id FunctionURLAllowPublic `
      --action lambda:InvokeFunctionUrl `
      --principal "*" `
      --function-url-auth-type NONE `
      --region $region 2>$null
  }
}

function Get-FunctionUrl {
  param([string]$func, [string]$region)
  $URL = aws lambda get-function-url-config --function-name $func --region $region --query FunctionUrl --output text
  if (-not $URL) { throw "Failed to resolve Function URL for $func in $region" }
  return $URL
}

function UrlEncode {
    param([string]$s)
    return [System.Uri]::EscapeDataString($s)
}

Test-AwsCliV2
$CURL = Get-CurlPath
Assert-LambdaFuncExists -func $_FunctionName -region $_Region
Assert-PublicInvokePerm -func $_FunctionName -region $_Region
$URL = Get-FunctionUrl -func $_FunctionName -region $_Region

# Test calls
& $curl "$($URL)/badge/Sup/Dude?color=ff3e00" -o test.svg
& $curl "$($URL)/badge/$(UrlEncode($label))/$(UrlEncode($message))?color=dc143c&labelColor=b0b0b0&style=plastic&scale=3" -o valdezium.svg
