from tests import test_os_specific


def run_test() -> None:
    test_os_specific()

if __name__ == "__main__":
    run_test()