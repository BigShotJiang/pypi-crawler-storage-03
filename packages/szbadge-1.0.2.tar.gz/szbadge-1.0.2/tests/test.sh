#!/usr/bin/env bash
# A simple test script to ensure the Lambda function URL is set up and working.
# Requires: AWS CLI v2, curl
# MIT © 2025 DJ Stomp

set -euo pipefail

REGION="${AWS_REGION:-us-east-2}"
FUNC="${SZBADGE_FUNC:-szbadge}"

command -v aws >/dev/null 2>&1 || { echo "aws CLI not found"; exit 1; }
command -v curl >/dev/null 2>&1 || { echo "curl not found"; exit 1; }

# Ensure a Function URL exists (idempotent)
aws lambda get-function-url-config --function-name "$FUNC" --region "$REGION" >/dev/null 2>&1 \
  || aws lambda create-function-url-config --function-name "$FUNC" --auth-type NONE --region "$REGION" >/dev/null

# Ensure public invoke permission exists (idempotent)
aws lambda add-permission \
  --function-name "$FUNC" \
  --statement-id FunctionURLAllowPublic \
  --action lambda:InvokeFunctionUrl \
  --principal "*" \
  --function-url-auth-type NONE \
  --region "$REGION" >/dev/null 2>&1 || true

# Fetch the URL dynamically
URL="$(aws lambda get-function-url-config --function-name "$FUNC" --region "$REGION" --query 'FunctionUrl' --output text)"
[ -n "$URL" ] || { echo "Failed to resolve Function URL"; exit 1; }
echo "$URL"

# Test calls
curl -sSfL "$URL/badge/Sup/Dude?color=ff3e00" -o test.svg

# Full-params badge (percent-encoding already in the path)
curl -sSfL "$URL/badge/40%25/Valdezium?color=dc143c&labelColor=b0b0b0&style=plastic&scale=3" -o valdezium.svg
