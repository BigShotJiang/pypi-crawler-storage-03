import os
import platform
import shutil
import subprocess
from dataclasses import dataclass
from typing import Any, Generator, Literal, Tuple

type OSName = Literal["windows", "posix"]

@dataclass
class TestParams:
    argv: list[str]
    script: str

    def __iter__(self) -> Generator[list[str] | str, Any, None]:
        yield self.argv
        yield self.script
    
    def __next__(self) -> Tuple[list[str], str]:
        return (self.argv, self.script)


def get_os() -> OSName:
    """Return a normalized OS identifier."""
    return "windows" if platform.system().lower().startswith("win") else "posix"

def _here() -> str:
    for check in [os.path.dirname(__file__), os.getcwd()]:
        if "tests" in os.listdir(check) and "szbadge" in os.listdir(check):
            _tests = os.path.join(os.getcwd(), "tests")
            if "test.ps1" in os.listdir(_tests) and "test.sh" in os.listdir(_tests):
                return os.path.realpath(_tests)
    raise FileNotFoundError("Could not locate tests directory from __file__ or cwd.")

def get_test_for_os() -> TestParams:
    """
    Return the argv to execute and the script path for the current OS.

    On Windows: run via PowerShell with ExecutionPolicy Bypass.
    On POSIX: run via bash (respects script shebang too).
    """
    
    def test_posix(here) -> TestParams:
        script: str = os.path.join(here, "test.sh")
        bash: str = shutil.which("bash") or "/bin/bash"
        argv: list[str] = [bash, script]
        return TestParams(argv, script)

    def test_windows(here) -> TestParams:
        script: str = os.path.join(here, "test.ps1")
        pwsh: str = shutil.which("powershell") or shutil.which("pwsh") or "powershell"
        argv: list[str] = [
            pwsh,
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", script,
        ]
        return TestParams(argv, script)
    
    here: str = _here()
    test_mapping = {
        "windows": test_windows,
        "posix": test_posix,
    }
    return test_mapping[get_os()](here)
        

def run_test() -> subprocess.CompletedProcess[bytes]:
    """
    Execute the test script and capture output without raising on non-zero exit.
    """
    argv, script = get_test_for_os()
    assert os.path.exists(str(script)), f"Test file does not exist: {script}"

    return subprocess.run(argv, check=False, capture_output=True)


def test_os_specific() -> None:
    result: subprocess.CompletedProcess[bytes] = run_test()

    with open(os.path.join(os.getcwd(), "test_output.log"), "wb") as f:
        f.write(b"======\nSTDOUT\n======\n")
        f.write(result.stdout or b"")
        f.write(b"\n======\nSTDERR\n======\n")
        f.write(result.stderr or b"")

    assert result.returncode == 0, (
        f"Test script failed with return code {result.returncode}. "
        f"See test_output.log for details."
    )
