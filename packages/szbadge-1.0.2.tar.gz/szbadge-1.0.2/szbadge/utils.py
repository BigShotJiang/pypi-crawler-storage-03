# -----------------------------------------------------------------------------
# Sanitizers
# -----------------------------------------------------------------------------

import re
from typing import Optional
from urllib.parse import unquote_plus


class Sanitizer:
    """Strict, goblin-resistant input sanitizers."""
    _HEX_RX = re.compile(r"^[0-9a-fA-F]{3,6}$")
    _STYLE_SET = {"flat", "plastic"}

    @staticmethod
    def hex_color(s: Optional[str], default: str) -> str:
        """Return a lowercase 6-hex color string or the default on invalid input."""
        s = (s or "").strip().lstrip("#")
        if not Sanitizer._HEX_RX.fullmatch(s):
            return default
        if len(s) == 3:
            s = "".join(ch * 2 for ch in s)
        return s.lower()

    @staticmethod
    def style(s: Optional[str], default: str) -> str:
        v = (s or default).strip().lower()
        return v if v in Sanitizer._STYLE_SET else default

    @staticmethod
    def bounded_int(s: Optional[str], default: int, lo: int, hi: int) -> int:
        try:
            v = int(s)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return default
        if v < lo:
            return lo
        if v > hi:
            return hi
        return v

    @staticmethod
    def text(s: Optional[str], max_len: int) -> str:
        """Return a safe text value trimmed to max_len; no normalization of spaces."""
        v = (s or "")
        if len(v) > max_len:
            v = v[:max_len]
        return v

    @staticmethod
    def url_unescape(s: str) -> str:
        try:
            return unquote_plus(s)
        except Exception:
            return s


# -----------------------------------------------------------------------------
# SVG utilities
# -----------------------------------------------------------------------------

def esc_xml(s: str) -> str:
    """Escape a string for safe XML embedding."""
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def estimate_panel_width(text: str, scale: int, pad_x: int) -> int:
    """
    Cheap width estimate: len(text) * avg_em + padding.
    We then force the text to fit precisely with `textLength`.
    """
    avg_em = 7 * scale
    panel = max(1, len(text)) * avg_em + pad_x * 2
    return panel