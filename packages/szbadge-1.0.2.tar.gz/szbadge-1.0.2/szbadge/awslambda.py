import json
import logging
from typing import Dict, Optional, Tuple

from szbadge.config import AppLimits
from szbadge.render import BadgeRenderer
from szbadge.utils import Sanitizer

LIMITS = AppLimits()
RENDERER = BadgeRenderer(LIMITS)

log: logging.Logger = logging.getLogger(__name__)
log.setLevel(logging.INFO)


# -----------------------------------------------------------------------------
# Lambda handler
# -----------------------------------------------------------------------------




def _parse_path(raw_path: str) -> Optional[Tuple[str, str]]:
    parts = [p for p in (raw_path or "/").strip("/").split("/") if p]
    if len(parts) >= 3 and parts[0].lower() == "badge":
        return Sanitizer.url_unescape(parts[1]), Sanitizer.url_unescape("/".join(parts[2:]))
    return None


def _bad_request(msg: str) -> Dict[str, object]:
    return {
        "statusCode": 400,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"error": msg}),
    }

def lambda_handler(event, context):
    """
    AWS Lambda entrypoint for Function URL or API Gateway HTTP API.

    Query parameters:
      label, message, color, labelColor, style, scale
    """
    try:
        qp = event.get("queryStringParameters") or {}
        raw_path = event.get("rawPath") or "/"

        parsed = _parse_path(raw_path)
        label = qp.get("label")
        message = qp.get("message")
        if parsed:
            label, message = parsed

        if not label or not message:
            return _bad_request("Missing label or message. Use /badge/<label>/<message> or ?label=...&message=...")

        label = Sanitizer.text(label, LIMITS.max_label_len)
        message = Sanitizer.text(message, LIMITS.max_message_len)
        color = Sanitizer.hex_color(qp.get("color"), LIMITS.default_color)
        label_color = Sanitizer.hex_color(qp.get("labelColor"), LIMITS.default_label_color)
        style = Sanitizer.style(qp.get("style"), LIMITS.default_style)
        scale = Sanitizer.bounded_int(qp.get("scale"), LIMITS.default_scale, LIMITS.min_scale, LIMITS.max_scale)

        svg = RENDERER.render(label=label, message=message, color=color, label_color=label_color, style=style, scale=scale)

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "image/svg+xml; charset=utf-8",
                "Cache-Control": "max-age=300, s-maxage=300, public",
            },
            "body": svg,
        }
    except Exception as exc:
        log.exception("SZBadge error")
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": f"Server error: {exc.__class__.__name__}"}),
        }