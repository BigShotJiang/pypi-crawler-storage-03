# -----------------------------------------------------------------------------
# Renderer
# -----------------------------------------------------------------------------

from szbadge.config import AppLimits, Geometry
from szbadge.utils import esc_xml, estimate_panel_width


class BadgeRenderer:
    """Responsible for rendering the badge SVG string."""

    def __init__(self, limits: AppLimits) -> None:
        super().__init__()
        self.limits = limits

    def render(self, label: str, message: str, color: str, label_color: str, style: str, scale: int) -> str:
        geom = Geometry.for_scale_and_style(scale, style)

        lw = estimate_panel_width(label, scale, geom.pad_x)
        rw = estimate_panel_width(message, scale, geom.pad_x)
        total_w = lw + rw

        text_color = "ffffff"
        border = "00000020" if style == "plastic" else "00000000"
        label_grad = ' fill="url(#gradLabel)"' if style == "plastic" else ""
        right_grad = ' fill="url(#gradRight)"' if style == "plastic" else ""

        label_text_len = max(1, lw - geom.pad_x * 2)
        message_text_len = max(1, rw - geom.pad_x * 2)
        label_y = int(geom.height / 2) + int(geom.font_size / 3)

        label_esc = esc_xml(label)
        message_esc = esc_xml(message)

        svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}" height="{geom.height}" role="img" '
            f'aria-label="{label_esc}: {message_esc}">\n'
            f'  <title>{label_esc}: {message_esc}</title>\n'
            f'  <defs>\n'
            f'    <linearGradient id="gradLabel" x2="0" y2="1">\n'
            f'      <stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/>\n'
            f'      <stop offset="1" stop-color="#000000" stop-opacity="0.12"/>\n'
            f'    </linearGradient>\n'
            f'    <linearGradient id="gradRight" x2="0" y2="1">\n'
            f'      <stop offset="0" stop-color="#ffffff" stop-opacity="0.12"/>\n'
            f'      <stop offset="1" stop-color="#000000" stop-opacity="0.12"/>\n'
            f'    </linearGradient>\n'
            f'    <clipPath id="round">\n'
            f'      <rect width="{total_w}" height="{geom.height}" rx="{geom.radius}" ry="{geom.radius}"/>\n'
            f'    </clipPath>\n'
            f'  </defs>\n'
            f'  <g clip-path="url(#round)">\n'
            f'    <rect width="{lw}" height="{geom.height}" fill="#{label_color}"/>\n'
            f'    <rect x="{lw}" width="{rw}" height="{geom.height}" fill="#{color}"/>\n'
            f'    <rect width="{total_w}" height="{geom.height}" fill="#{border}"/>\n'
            f'    {f"<rect width={chr(34)}{lw}{chr(34)} height={chr(34)}{geom.height}{chr(34)}{label_grad}/>" if style == "plastic" else ""}\n'
            f'    {f"<rect x={chr(34)}{lw}{chr(34)} width={chr(34)}{rw}{chr(34)} height={chr(34)}{geom.height}{chr(34)}{right_grad}/>" if style == "plastic" else ""}\n'
            f'  </g>\n'
            f'  <g fill="#{text_color}" font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="{geom.font_size}">\n'
            f'    <text x="{geom.pad_x}" y="{label_y}" textLength="{label_text_len}" lengthAdjust="spacingAndGlyphs">{label_esc}</text>\n'
            f'    <text x="{lw + geom.pad_x}" y="{label_y}" textLength="{message_text_len}" lengthAdjust="spacingAndGlyphs">{message_esc}</text>\n'
            f'  </g>\n'
            f'</svg>'
        )
        return svg