"""
SZBadge — a defensive, dependency-free text→SVG badge API for AWS Lambda.

Routes
------
1) Path mode:
   /badge/<label>/<message>?color=<hex>&labelColor=<hex>&style=<flat|plastic>&scale=<1-3>
2) Query mode:
   /badge?label=<...>&message=<...>&color=<hex>&labelColor=<hex>&style=<...>&scale=<...>

Author: DJ Stomp <85457381+DJStompZone@users.noreply.github.com>
License: MIT
Repo: https://github.com/djstompzone/szbadge
PyPi: https://pypi.org/project/szbadge/
"""
from __future__ import annotations

import importlib.metadata

from szbadge.awslambda import lambda_handler

version = {importlib.metadata.version("szbadge") or "dev"}

# -----------------------------------------------------------------------------
# development harness
# -----------------------------------------------------------------------------

def main():
    print(f"SZBadge version {version}")
    event = {
        "rawPath": "/badge/Henlo/Mundo",
        "queryStringParameters": {
            "color": "ff3e00",
            "labelColor": "A44",
            "style": "plastic",
            "scale": "2"
        }
    }
    result = lambda_handler(event, None)
    print("Status:", result["statusCode"])
    print("Headers:", result["headers"])
    body = result["body"]
    if isinstance(body, str):
        with open("test.svg", "w", encoding="utf-8") as fp:
            fp.write(body)
        print("Wrote test.svg")

if __name__ == "__main__":
    main()