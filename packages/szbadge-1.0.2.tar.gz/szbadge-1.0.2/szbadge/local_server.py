"""
local_server.py — Flask harness for SZBadge

Purpose
-------
Run the Lambda handler locally via Flask so you can hit:
  http://localhost:8080/badge/Hello/World?color=ff3e00&labelColor=444&style=plastic&scale=2

Usage
-----
python local_server.py --host 127.0.0.1 --port 8080 --debug --cors "*"

Notes
-----
- This file assumes `index.py` is importable and exposes `lambda_handler(event, context)`.
- Adds a `/health` endpoint that returns 200 for quick checks.
- Optional CORS via `--cors ORIGIN` (e.g., "*" or "http://localhost:3000").
"""

from __future__ import annotations

import argparse
import sys
from typing import Any, Dict

try:
    from flask import Flask, Response, request  # type: ignore
except ImportError as exc:
    print(f"Flask is required to run this script: {exc.__class__.__name__}: {exc}", file=sys.stderr)
    raise

try:
    from szbadge.awslambda import lambda_handler
except Exception as exc:
    print(f"Failed to import index.lambda_handler: {exc.__class__.__name__}: {exc}\nPlease install with pip and retry.", file=sys.stderr)
    raise


def build_event_from_flask() -> Dict[str, Any]:
    """
    Build a minimal API Gateway/Lambda Function URL style event from the current Flask request.

    Returns
    -------
    dict
        Event containing rawPath and queryStringParameters sufficient for SZBadge.
    """
    raw_path = "/" + (request.view_args.get("path", "") if request.view_args else "")
    qs = {k: v for k, v in request.args.items()}
    event = {
        "rawPath": raw_path,
        "queryStringParameters": qs or None,
        "requestContext": {
            "http": {
                "method": request.method,
                "path": raw_path,
                "protocol": request.environ.get("SERVER_PROTOCOL", "HTTP/1.1"),
                "sourceIp": request.remote_addr or "127.0.0.1",
                "userAgent": request.headers.get("User-Agent", ""),
            }
        },
        "headers": {k.lower(): v for k, v in request.headers.items()},
        "isBase64Encoded": False,
    }
    return event


def flask_response_from_lambda_result(result: Dict[str, Any], cors_origin: str | None) -> Response:
    """
    Convert a Lambda-style result into a Flask Response.

    Parameters
    ----------
    result : dict
        The dict returned by lambda_handler with keys statusCode, headers, body.
    cors_origin : Optional[str]
        Origin to use for Access-Control-Allow-Origin header, if set.

    Returns
    -------
    flask.Response
        A response with status, headers, and body applied.
    """
    status = int(result.get("statusCode", 200))
    headers = result.get("headers", {}) or {}
    body = result.get("body", "")

    if cors_origin:
        headers = dict(headers)
        headers["Access-Control-Allow-Origin"] = cors_origin
        headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
        headers["Access-Control-Allow-Headers"] = "Content-Type"

    if isinstance(body, (bytes, bytearray)):
        return Response(body, status=status, headers=headers)
    if isinstance(body, str):
        return Response(body, status=status, headers=headers)
    return Response(str(body), status=status, headers=headers)


def create_app(cors_origin: str | None = None) -> Flask:
    """
    Factory that creates and configures the Flask app.

    Parameters
    ----------
    cors_origin : Optional[str]
        Origin string (e.g., "*" or "http://localhost:3000") to enable CORS. None disables CORS.

    Returns
    -------
    Flask
        Configured Flask application.
    """
    app = Flask(__name__)

    @app.route("/health", methods=["GET"])
    def health() -> Response: # type: ignore
        return Response("ok", status=200, mimetype="text/plain")

    @app.route("/", defaults={"path": ""}, methods=["GET", "OPTIONS"])
    @app.route("/<path:path>", methods=["GET", "OPTIONS"])
    def all_routes(path: str) -> Response: # type: ignore
        if request.method == "OPTIONS":
            resp = Response("", status=204)
            if cors_origin:
                resp.headers["Access-Control-Allow-Origin"] = cors_origin
                resp.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
                resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
            return resp

        event = build_event_from_flask()
        result = lambda_handler(event, None)
        return flask_response_from_lambda_result(result, cors_origin)

    return app


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """
    Parse CLI arguments for host/port/debug and CORS.

    Parameters
    ----------
    argv : list[str] | None
        Optional list of arguments (defaults to sys.argv)

    Returns
    -------
    argparse.Namespace
        Parsed arguments.
    """
    p = argparse.ArgumentParser(prog="local_server", description="Run SZBadge locally via Flask.")
    p.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    p.add_argument("--port", type=int, default=8080, help="Bind port (default: 8080)")
    p.add_argument("--debug", action="store_true", help="Enable Flask debug and reloader")
    p.add_argument("--cors", default=None, help='Enable CORS with this origin (e.g., "*" or "http://localhost:3000")')
    return p.parse_args(argv)


def main() -> None:
    """
    Entrypoint for running the local Flask server.
    """
    args = parse_args()
    app = create_app(cors_origin=args.cors)
    app.run(host=args.host, port=args.port, debug=args.debug, use_reloader=args.debug)


if __name__ == "__main__":
    main()
