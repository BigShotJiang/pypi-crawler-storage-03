from dataclasses import dataclass

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class Geometry:
    """Geometric constants derived from 'scale' and 'style'."""
    pad_x: int
    height: int
    radius: int
    font_size: int

    @staticmethod
    def for_scale_and_style(scale: int, style: str) -> "Geometry":
        height = 20 * scale if style == "flat" else 22 * scale
        return Geometry(
            pad_x=6 * scale,
            height=height,
            radius=4 * scale,
            font_size=11 * scale,
        )


@dataclass(frozen=True)
class AppLimits:
    """Centralized input and rendering limits."""
    max_label_len: int = 128
    max_message_len: int = 256
    min_scale: int = 1
    max_scale: int = 3
    default_scale: int = 1
    default_label_color: str = "555555"
    default_color: str = "4c1"
    default_style: str = "flat"