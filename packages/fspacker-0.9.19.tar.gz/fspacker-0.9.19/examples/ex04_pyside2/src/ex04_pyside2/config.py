from pathlib import Path

CWD = Path.cwd()
ASSETS_DIR = CWD / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
