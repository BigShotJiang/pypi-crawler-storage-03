def function_global_a():
    print("Called from function_global_a, single file")
