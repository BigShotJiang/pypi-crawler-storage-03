#proxy module for the vstack widget
# noinspection PyUnresolvedReferences,PyPep8Naming
from pydashboard.containers.vstack import Vstack as widget