def noop(s): return s


def noneg(n): return n if n >= 0 else ''
