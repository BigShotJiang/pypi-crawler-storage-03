class Optimizer:
    def update(self, params, grads):
        raise NotImplementedError
