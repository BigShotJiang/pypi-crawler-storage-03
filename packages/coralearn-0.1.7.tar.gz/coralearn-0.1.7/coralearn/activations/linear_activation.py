import numpy as np


def linear_activation(x):
    return x,1
