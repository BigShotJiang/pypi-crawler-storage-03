"""Conditional (control flows) operators subpackage"""

from monggregate.operators.conditional.cond import Cond, cond
from monggregate.operators.conditional.if_null import IfNull, if_null
from monggregate.operators.conditional.switch import Switch, switch

