"""xxx"""

# TODO
# * $accumulator
# * $function
