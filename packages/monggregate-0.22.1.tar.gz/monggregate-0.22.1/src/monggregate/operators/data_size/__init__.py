"""xxx"""

# TODO
# * $binarySize
# * $bsonSize