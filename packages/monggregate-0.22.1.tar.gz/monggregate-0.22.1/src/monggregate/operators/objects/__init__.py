"""Object Operators subpackage"""

from monggregate.operators.objects.merge_objects import MergeObjects, merge_objects
from monggregate.operators.objects.object_to_array import ObjectToArray, object_to_array

# TODO:
# * $setField
