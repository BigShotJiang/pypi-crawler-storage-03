# VideoSDK Agent SIP Plugin
This plugin provides a seamless bridge between telephony (using SIP providers) and advanced conversational AI (using VideoSDK Agents).

## Installation

```bash
pip install videosdk-plugins-sip
```
