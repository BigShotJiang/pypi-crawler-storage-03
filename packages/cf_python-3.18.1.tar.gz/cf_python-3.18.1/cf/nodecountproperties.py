import cfdm

from . import mixin


class NodeCountProperties(mixin.Properties, cfdm.NodeCountProperties):
    pass
