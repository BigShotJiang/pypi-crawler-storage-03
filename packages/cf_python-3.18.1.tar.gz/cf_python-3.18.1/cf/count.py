import cfdm

from . import mixin


class Count(mixin.PropertiesData, cfdm.Count):
    pass
