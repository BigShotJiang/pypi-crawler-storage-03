import cfdm

from . import mixin


class List(mixin.PropertiesData, cfdm.List):
    pass
