import cfdm

from . import mixin


class Index(mixin.PropertiesData, cfdm.Index):
    pass
