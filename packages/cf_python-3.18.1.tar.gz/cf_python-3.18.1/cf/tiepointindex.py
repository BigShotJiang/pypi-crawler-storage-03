import cfdm

from . import mixin


class TiePointIndex(mixin.PropertiesData, cfdm.TiePointIndex):
    pass
