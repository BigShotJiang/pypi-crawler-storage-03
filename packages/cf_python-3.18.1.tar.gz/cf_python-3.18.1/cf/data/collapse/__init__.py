from .collapse import Collapse
from .collapse_active import active_reduction_methods
