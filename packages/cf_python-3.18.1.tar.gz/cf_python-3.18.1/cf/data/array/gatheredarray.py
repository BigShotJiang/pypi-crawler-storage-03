import cfdm

from ...mixin_container import Container


class GatheredArray(Container, cfdm.GatheredArray):
    pass
