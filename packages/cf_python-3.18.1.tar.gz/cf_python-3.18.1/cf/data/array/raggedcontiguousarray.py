import cfdm

from ...mixin_container import Container


class RaggedContiguousArray(Container, cfdm.RaggedContiguousArray):
    pass
