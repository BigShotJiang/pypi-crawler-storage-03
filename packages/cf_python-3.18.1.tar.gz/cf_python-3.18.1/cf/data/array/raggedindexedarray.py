import cfdm

from ...mixin_container import Container


class RaggedIndexedArray(Container, cfdm.RaggedIndexedArray):
    pass
