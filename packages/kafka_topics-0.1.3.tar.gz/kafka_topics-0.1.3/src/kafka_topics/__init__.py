# src/kafka_topics/__init__.py
from .topics import KafkaTopics

__all__ = ["KafkaTopics"]
