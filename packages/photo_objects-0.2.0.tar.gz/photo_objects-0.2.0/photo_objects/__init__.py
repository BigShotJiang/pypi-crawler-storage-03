import logging

logger = logging.getLogger("photo-objects")
