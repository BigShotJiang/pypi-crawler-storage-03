"""Main CLI entry point for MCP Lightcast server."""

import sys

from mcp_lightcast import main

if __name__ == "__main__":
    sys.exit(main())
