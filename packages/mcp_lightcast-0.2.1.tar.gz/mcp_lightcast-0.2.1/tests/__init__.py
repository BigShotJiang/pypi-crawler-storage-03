"""Test package for MCP Lightcast server."""
