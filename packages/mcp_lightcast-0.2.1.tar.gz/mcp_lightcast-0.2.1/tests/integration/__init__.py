"""Integration tests for MCP Lightcast server."""
