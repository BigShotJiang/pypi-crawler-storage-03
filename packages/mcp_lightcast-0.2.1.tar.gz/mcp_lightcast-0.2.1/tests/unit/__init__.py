"""Unit tests for MCP Lightcast components."""
