"""
Decorators for agent tools.
"""
