..
    This file is part of Invenio.
    Copyright (C) 2016-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alexander Ioannidis
- Alizee Pace
- Andrew McCracken
- Diego Rodriguez
- Dinos Kousidis
- Emanuel Dima
- Harri Hirvonsalo
- Harris Tzovanakis
- Jan Aage Lavik
- Jiri Kuncar
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Nicola Tarocco
- Nicolas Harraudeau
- Samuele Kaplun
- Sebastian Witowski
- Tibor Simko
- Wojciech Ziółek
- Maximilian Moser
