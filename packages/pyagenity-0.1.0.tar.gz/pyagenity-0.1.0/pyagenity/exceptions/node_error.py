from .graph_error import GraphError


class NodeError(GraphError):
    """Raised when a node encounters an error."""
