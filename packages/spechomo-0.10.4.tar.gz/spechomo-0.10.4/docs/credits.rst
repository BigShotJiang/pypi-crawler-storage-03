=======
Credits
=======

.. include:: ../AUTHORS.rst


Funding
-------

The spechomo package was developed within the context of the GeoMultiSens project funded
by the German Federal Ministry of Education and Research (project grant code: 01 IS 14 010 A-C).
