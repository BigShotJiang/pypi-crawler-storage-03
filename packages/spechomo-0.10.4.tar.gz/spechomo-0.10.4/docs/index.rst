spechomo documentation
======================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about
   Source code repository <https://git.gfz-potsdam.de/geomultisens/spechomo>
   installation
   usage
   api_cli_reference
   contributing
   credits
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
