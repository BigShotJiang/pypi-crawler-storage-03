####################
Python API reference
####################

This section contains an auto-generated documentation of each Python class or function within the spechomo package.
Just browse through the package structure below:

.. toctree::
   :maxdepth: 4

   modules.rst
