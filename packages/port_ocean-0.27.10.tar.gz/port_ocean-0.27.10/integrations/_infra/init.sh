if test -e /usr/local/share/ca-certificates/cert.crt; then
  sudo update-ca-certificates
fi

ocean sail
