import time
from typing import TYPE_CHECKING
import pytest
from deltalake2db import duckdb_create_view_for_delta
import duckdb
from .utils import config_names, get_test_run_configs
import sqlglot as sg

if TYPE_CHECKING:
    from tests.conftest import DB_Connection
    from pyspark.sql import SparkSession


@pytest.mark.order(11)
@pytest.mark.parametrize("conf_name", config_names)
def test_append_inserts(
    connection: "DB_Connection", spark_session: "SparkSession", conf_name: str
):
    from odbc2deltalake import (
        write_db_to_delta,
        WriteConfig,
    )

    reader, dest = get_test_run_configs(connection, spark_session, "dbo/log")[conf_name]

    write_config = WriteConfig(
        load_mode="append_inserts", dialect=reader.source_dialect
    )
    write_db_to_delta(
        reader,
        ("dbo", "log"),
        dest,
        write_config=write_config,
    )

    with duckdb.connect() as con:
        duckdb_create_view_for_delta(
            con,
            (dest / "delta").as_delta_table(),
            "v_log",
            use_delta_ext=conf_name == "spark",
        )

        id_tuples = con.execute(
            'SELECT id, message from v_log order by "__timestamp"'
        ).fetchall()
        assert id_tuples == [(1, "The first log message")]

    time.sleep(1)
    with connection.new_connection(conf_name) as nc:
        with nc.cursor() as cursor:
            cursor.execute(
                sg.parse_one(
                    """INSERT INTO [dbo].[log] ([message])
                   SELECT 'The second log message'""",
                    dialect="tsql",
                ).sql(reader.source_dialect)
            )
    write_db_to_delta(  # some delta load
        reader,
        ("dbo", "log"),
        dest,
        write_config=write_config,
    )

    with duckdb.connect() as con:
        duckdb_create_view_for_delta(
            con,
            (dest / "delta").as_delta_table(),
            "v_log",
            use_delta_ext=conf_name == "spark",
        )

        id_tuples = con.execute(
            'SELECT id, message from v_log order by "__timestamp"'
        ).fetchall()
        assert id_tuples == [
            (1, "The first log message"),
            (2, "The second log message"),
        ]
