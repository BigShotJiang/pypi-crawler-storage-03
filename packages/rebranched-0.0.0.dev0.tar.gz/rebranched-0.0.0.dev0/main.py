def main():
   print("Hello from rebranched!")


if __name__ == "__main__":
    main()
