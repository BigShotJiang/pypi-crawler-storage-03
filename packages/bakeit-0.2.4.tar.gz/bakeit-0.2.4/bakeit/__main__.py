"""Cater for use of ``python -m bakeit``."""

from .cli import main

if __name__ == "__main__":
    main()
