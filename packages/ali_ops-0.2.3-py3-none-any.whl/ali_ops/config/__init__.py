

from .main import CONFIG 
