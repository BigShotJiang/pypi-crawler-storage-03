"""Top-level package for cidc_prism."""

__author__ = """NCI"""
__email__ = "nci-cidc-tools-admin@mail.nih.gov"
__version__ = "0.28.1"
