
def hello():

    print("hello")
