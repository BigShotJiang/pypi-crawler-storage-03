from django.apps import AppConfig


class TagsConfig(AppConfig):
    name = "flexi_tag"

    def ready(self):
        pass
