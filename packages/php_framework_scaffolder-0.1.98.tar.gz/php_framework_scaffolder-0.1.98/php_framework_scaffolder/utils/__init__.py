# Utils package for PHP Framework Scaffolder
from __future__ import annotations
