Data sources:

The data file `hsc_ratios_and_specz.hdf5` contains data products sourced from the Second HSC data release, which is described in:
[this paper](https://academic.oup.com/pasj/article/71/6/114/5602617):<br/>
Aihara, H., AlSayyad, Y., Ando, M., et al. 2019, PASJ, 71, 114<br/>
doi: 10.1093/pasj/psz103
