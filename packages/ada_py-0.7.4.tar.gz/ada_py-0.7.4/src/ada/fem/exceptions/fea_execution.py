class FEAnalysisUnableToStart(Exception):
    pass


class FEAnalysisUnsuccessfulError(Exception):
    pass
