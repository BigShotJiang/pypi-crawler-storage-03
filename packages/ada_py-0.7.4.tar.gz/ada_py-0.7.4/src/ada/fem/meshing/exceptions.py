class BadJacobians(Exception):
    pass


class MeshExtrationError(Exception):
    pass
