from ._results import read_abaqus_results

__all__ = ["read_abaqus_results"]
