class NoIfcAxesAttachedError(Exception):
    pass


class UnableToConvertBoolResToBeamException(Exception):
    pass
