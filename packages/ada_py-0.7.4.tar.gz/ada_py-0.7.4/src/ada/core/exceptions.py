class UnsupportedUnits(Exception):
    pass


class VectorNormalizeError(Exception):
    pass
