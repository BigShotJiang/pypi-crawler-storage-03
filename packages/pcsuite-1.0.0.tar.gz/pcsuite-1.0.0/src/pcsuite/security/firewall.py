def manage_firewall():
	pass
