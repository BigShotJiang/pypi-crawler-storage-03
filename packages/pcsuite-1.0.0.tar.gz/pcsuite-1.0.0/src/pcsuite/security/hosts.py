def manage_hosts():
	pass
