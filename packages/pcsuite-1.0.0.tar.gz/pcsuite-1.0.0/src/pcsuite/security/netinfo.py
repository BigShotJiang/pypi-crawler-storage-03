def get_network_info():
	pass
