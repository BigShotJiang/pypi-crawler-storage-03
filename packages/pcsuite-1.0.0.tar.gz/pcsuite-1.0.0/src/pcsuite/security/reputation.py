def check_reputation():
	pass
