def optimize_power():
	pass
