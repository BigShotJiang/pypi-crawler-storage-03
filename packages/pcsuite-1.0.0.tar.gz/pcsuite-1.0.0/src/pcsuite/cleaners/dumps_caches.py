def clean_dumps_caches():
	pass
