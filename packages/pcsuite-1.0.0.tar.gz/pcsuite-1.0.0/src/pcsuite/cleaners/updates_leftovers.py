def clean_updates_leftovers():
	pass
