# Changelog

```{changelog}
:changelog-url: https://github.com/scikit-hep/uhi/releases
:github: https://github.com/scikit-hep/uhi/releases
:pypi: https://pypi.org/project/uhi
```
