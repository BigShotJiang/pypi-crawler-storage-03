# Copyright (c) 2013 Steve Canny, https://github.com/scanny
#
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# See LICENSE in the project root for full license information.



# encoding: utf-8

"""
Sub-package module for docx.styles sub-package.
"""

from __future__ import (
    absolute_import, division, print_function, unicode_literals
)


class BabelFish(object):
    """
    Translates special-case style names from UI name (e.g. Heading 1) to
    internal/styles.xml name (e.g. heading 1) and back.
    """

    style_aliases = (
        ('Caption', 'caption'),
        ('Footer', 'footer'),
        ('Header', 'header'),
        ('Heading 1', 'heading 1'),
        ('Heading 2', 'heading 2'),
        ('Heading 3', 'heading 3'),
        ('Heading 4', 'heading 4'),
        ('Heading 5', 'heading 5'),
        ('Heading 6', 'heading 6'),
        ('Heading 7', 'heading 7'),
        ('Heading 8', 'heading 8'),
        ('Heading 9', 'heading 9'),
    )

    internal_style_names = dict(style_aliases)
    ui_style_names = dict((item[1], item[0]) for item in style_aliases)

    @classmethod
    def ui2internal(cls, ui_style_name):
        """
        Return the internal style name corresponding to *ui_style_name*, such
        as 'heading 1' for 'Heading 1'.
        """
        return cls.internal_style_names.get(ui_style_name, ui_style_name)

    @classmethod
    def internal2ui(cls, internal_style_name):
        """
        Return the user interface style name corresponding to
        *internal_style_name*, such as 'Heading 1' for 'heading 1'.
        """
        return cls.ui_style_names.get(
            internal_style_name, internal_style_name
        )
