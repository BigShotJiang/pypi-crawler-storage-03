mcstasscript.tests.test\_Plotter
================================

.. automodule:: mcstasscript.tests.test_Plotter

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      get_dummy_McStasDataBinned_1d
      get_dummy_McStasDataBinned_2d
      get_dummy_MetaDataBinned_1d
      get_dummy_MetaDataBinned_2d
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TestPlotterHelpers
   
   

   
   
   



