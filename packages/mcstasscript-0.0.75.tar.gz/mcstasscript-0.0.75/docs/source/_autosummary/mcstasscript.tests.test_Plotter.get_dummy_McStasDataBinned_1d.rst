mcstasscript.tests.test\_Plotter.get\_dummy\_McStasDataBinned\_1d
=================================================================

.. currentmodule:: mcstasscript.tests.test_Plotter

.. autofunction:: get_dummy_McStasDataBinned_1d