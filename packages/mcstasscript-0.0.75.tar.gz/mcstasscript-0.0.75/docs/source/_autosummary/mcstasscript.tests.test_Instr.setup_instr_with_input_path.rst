mcstasscript.tests.test\_Instr.setup\_instr\_with\_input\_path
==============================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_instr_with_input_path