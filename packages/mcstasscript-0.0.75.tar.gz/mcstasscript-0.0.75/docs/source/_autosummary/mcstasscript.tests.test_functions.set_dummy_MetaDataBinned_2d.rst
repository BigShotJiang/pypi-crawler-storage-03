mcstasscript.tests.test\_functions.set\_dummy\_MetaDataBinned\_2d
=================================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autofunction:: set_dummy_MetaDataBinned_2d