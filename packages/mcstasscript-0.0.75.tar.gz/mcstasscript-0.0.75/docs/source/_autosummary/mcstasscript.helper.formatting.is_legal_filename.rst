mcstasscript.helper.formatting.is\_legal\_filename
==================================================

.. currentmodule:: mcstasscript.helper.formatting

.. autofunction:: is_legal_filename