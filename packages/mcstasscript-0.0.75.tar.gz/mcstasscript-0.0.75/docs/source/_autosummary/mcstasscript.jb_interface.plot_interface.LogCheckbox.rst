mcstasscript.jb\_interface.plot\_interface.LogCheckbox
======================================================

.. currentmodule:: mcstasscript.jb_interface.plot_interface

.. autoclass:: LogCheckbox
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LogCheckbox.__init__
      ~LogCheckbox.make_widget
      ~LogCheckbox.update
   
   

   
   
   