mcstasscript.tests.test\_Instr\_reader.setup\_standard\_auto\_instr
===================================================================

.. currentmodule:: mcstasscript.tests.test_Instr_reader

.. autofunction:: setup_standard_auto_instr