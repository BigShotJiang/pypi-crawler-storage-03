mcstasscript.tests.test\_functions.setup\_McStasData\_array
===========================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autofunction:: setup_McStasData_array