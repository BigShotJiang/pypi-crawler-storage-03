mcstasscript.tests.test\_simulation\_interface
==============================================

.. automodule:: mcstasscript.tests.test_simulation_interface

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      setup_instr_root_path_McStas
      setup_instr_root_path_McXtrace
      setup_populated_instr_McStas
      setup_populated_instr_McXtrace
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      FakeChange
      TestSimulationInterface
   
   

   
   
   



