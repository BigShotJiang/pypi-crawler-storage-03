mcstasscript.data.data
======================

.. automodule:: mcstasscript.data.data

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      McStasData
      McStasDataBinned
      McStasDataEvent
      McStasMetaData
      McStasPlotOptions
   
   

   
   
   



