mcstasscript.tests.test\_simulation\_interface.FakeChange
=========================================================

.. currentmodule:: mcstasscript.tests.test_simulation_interface

.. autoclass:: FakeChange
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FakeChange.__init__
   
   

   
   
   