mcstasscript.instr\_reader.read\_definition.DefinitionReader
============================================================

.. currentmodule:: mcstasscript.instr_reader.read_definition

.. autoclass:: DefinitionReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DefinitionReader.__init__
      ~DefinitionReader.read_definition_line
      ~DefinitionReader.set_instr_name
   
   

   
   
   