mcstasscript.tests.test\_McStasData.set\_dummy\_McStasDataBinned\_1d
====================================================================

.. currentmodule:: mcstasscript.tests.test_McStasData

.. autofunction:: set_dummy_McStasDataBinned_1d