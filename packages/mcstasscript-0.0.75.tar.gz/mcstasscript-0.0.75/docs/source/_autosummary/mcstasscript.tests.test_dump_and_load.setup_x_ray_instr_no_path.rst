mcstasscript.tests.test\_dump\_and\_load.setup\_x\_ray\_instr\_no\_path
=======================================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autofunction:: setup_x_ray_instr_no_path