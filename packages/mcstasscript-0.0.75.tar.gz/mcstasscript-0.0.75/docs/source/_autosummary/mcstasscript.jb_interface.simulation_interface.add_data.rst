mcstasscript.jb\_interface.simulation\_interface.add\_data
==========================================================

.. currentmodule:: mcstasscript.jb_interface.simulation_interface

.. autofunction:: add_data