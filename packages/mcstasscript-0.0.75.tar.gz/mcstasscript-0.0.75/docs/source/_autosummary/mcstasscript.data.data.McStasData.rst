mcstasscript.data.data.McStasData
=================================

.. currentmodule:: mcstasscript.data.data

.. autoclass:: McStasData
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~McStasData.__init__
      ~McStasData.get_data_location
      ~McStasData.set_data_location
      ~McStasData.set_plot_options
      ~McStasData.set_title
      ~McStasData.set_xlabel
      ~McStasData.set_ylabel
   
   

   
   
   