mcstasscript.tests.test\_Configurator.setup\_configurator
=========================================================

.. currentmodule:: mcstasscript.tests.test_Configurator

.. autofunction:: setup_configurator