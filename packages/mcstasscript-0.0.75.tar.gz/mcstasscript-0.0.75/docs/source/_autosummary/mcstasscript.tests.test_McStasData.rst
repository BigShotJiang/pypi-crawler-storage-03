mcstasscript.tests.test\_McStasData
===================================

.. automodule:: mcstasscript.tests.test_McStasData

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      set_dummy_McStasDataBinned_1d
      set_dummy_McStasDataBinned_2d
      set_dummy_MetaDataBinned_1d
      set_dummy_MetaDataBinned_2d
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TestMcStasData
   
   

   
   
   



