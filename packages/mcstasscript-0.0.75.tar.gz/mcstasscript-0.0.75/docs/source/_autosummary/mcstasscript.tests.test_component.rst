mcstasscript.tests.test\_component
==================================

.. automodule:: mcstasscript.tests.test_component

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      setup_Component_all_keywords
      setup_Component_relative
      setup_Component_with_parameters
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TestComponent
   
   

   
   
   



