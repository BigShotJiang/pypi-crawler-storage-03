mcstasscript.helper.component\_reader.ComponentReader
=====================================================

.. currentmodule:: mcstasscript.helper.component_reader

.. autoclass:: ComponentReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ComponentReader.__init__
      ~ComponentReader.correct_for_brackets
      ~ComponentReader.load_all_components
      ~ComponentReader.read_component_file
      ~ComponentReader.read_name
      ~ComponentReader.show_categories
      ~ComponentReader.show_components_in_category
   
   

   
   
   