mcstasscript.helper.formatting.bcolors
======================================

.. currentmodule:: mcstasscript.helper.formatting

.. autoclass:: bcolors
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~bcolors.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~bcolors.BOLD
      ~bcolors.ENDC
      ~bcolors.FAIL
      ~bcolors.HEADER
      ~bcolors.OKBLUE
      ~bcolors.OKGREEN
      ~bcolors.UNDERLINE
      ~bcolors.WARNING
   
   