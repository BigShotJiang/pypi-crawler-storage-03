mcstasscript.instr\_reader.read\_initialize.InitializeReader
============================================================

.. currentmodule:: mcstasscript.instr_reader.read_initialize

.. autoclass:: InitializeReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~InitializeReader.__init__
      ~InitializeReader.read_initialize_line
      ~InitializeReader.set_instr_name
   
   

   
   
   