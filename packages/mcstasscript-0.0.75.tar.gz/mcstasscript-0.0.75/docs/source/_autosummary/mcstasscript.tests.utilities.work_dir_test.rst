mcstasscript.tests.utilities.work\_dir\_test
============================================

.. currentmodule:: mcstasscript.tests.utilities

.. autofunction:: work_dir_test