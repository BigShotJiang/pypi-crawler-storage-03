mcstasscript.tests.test\_McStasData.set\_dummy\_MetaDataBinned\_1d
==================================================================

.. currentmodule:: mcstasscript.tests.test_McStasData

.. autofunction:: set_dummy_MetaDataBinned_1d