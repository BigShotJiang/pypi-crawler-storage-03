mcstasscript.tests.test\_functions.Test\_name\_search
=====================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autoclass:: Test_name_search
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Test_name_search.__init__
      ~Test_name_search.addClassCleanup
      ~Test_name_search.addCleanup
      ~Test_name_search.addTypeEqualityFunc
      ~Test_name_search.assertAlmostEqual
      ~Test_name_search.assertAlmostEquals
      ~Test_name_search.assertCountEqual
      ~Test_name_search.assertDictContainsSubset
      ~Test_name_search.assertDictEqual
      ~Test_name_search.assertEqual
      ~Test_name_search.assertEquals
      ~Test_name_search.assertFalse
      ~Test_name_search.assertGreater
      ~Test_name_search.assertGreaterEqual
      ~Test_name_search.assertIn
      ~Test_name_search.assertIs
      ~Test_name_search.assertIsInstance
      ~Test_name_search.assertIsNone
      ~Test_name_search.assertIsNot
      ~Test_name_search.assertIsNotNone
      ~Test_name_search.assertLess
      ~Test_name_search.assertLessEqual
      ~Test_name_search.assertListEqual
      ~Test_name_search.assertLogs
      ~Test_name_search.assertMultiLineEqual
      ~Test_name_search.assertNotAlmostEqual
      ~Test_name_search.assertNotAlmostEquals
      ~Test_name_search.assertNotEqual
      ~Test_name_search.assertNotEquals
      ~Test_name_search.assertNotIn
      ~Test_name_search.assertNotIsInstance
      ~Test_name_search.assertNotRegex
      ~Test_name_search.assertNotRegexpMatches
      ~Test_name_search.assertRaises
      ~Test_name_search.assertRaisesRegex
      ~Test_name_search.assertRaisesRegexp
      ~Test_name_search.assertRegex
      ~Test_name_search.assertRegexpMatches
      ~Test_name_search.assertSequenceEqual
      ~Test_name_search.assertSetEqual
      ~Test_name_search.assertTrue
      ~Test_name_search.assertTupleEqual
      ~Test_name_search.assertWarns
      ~Test_name_search.assertWarnsRegex
      ~Test_name_search.assert_
      ~Test_name_search.countTestCases
      ~Test_name_search.debug
      ~Test_name_search.defaultTestResult
      ~Test_name_search.doClassCleanups
      ~Test_name_search.doCleanups
      ~Test_name_search.fail
      ~Test_name_search.failIf
      ~Test_name_search.failIfAlmostEqual
      ~Test_name_search.failIfEqual
      ~Test_name_search.failUnless
      ~Test_name_search.failUnlessAlmostEqual
      ~Test_name_search.failUnlessEqual
      ~Test_name_search.failUnlessRaises
      ~Test_name_search.id
      ~Test_name_search.run
      ~Test_name_search.setUp
      ~Test_name_search.setUpClass
      ~Test_name_search.shortDescription
      ~Test_name_search.skipTest
      ~Test_name_search.subTest
      ~Test_name_search.tearDown
      ~Test_name_search.tearDownClass
      ~Test_name_search.test_name_search_filename_read
      ~Test_name_search.test_name_search_read
      ~Test_name_search.test_name_search_read_duplicate
      ~Test_name_search.test_name_search_read_error
      ~Test_name_search.test_name_search_read_repeat
      ~Test_name_search.test_name_search_type_error_not_McStasData
      ~Test_name_search.test_name_search_type_error_not_list
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Test_name_search.longMessage
      ~Test_name_search.maxDiff
   
   