mcstasscript.interface.functions.name\_plot\_options
====================================================

.. currentmodule:: mcstasscript.interface.functions

.. autofunction:: name_plot_options