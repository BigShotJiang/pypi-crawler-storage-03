mcstasscript.instr\_reader.util.SectionReader
=============================================

.. currentmodule:: mcstasscript.instr_reader.util

.. autoclass:: SectionReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SectionReader.__init__
      ~SectionReader.set_instr_name
   
   

   
   
   