mcstasscript.jb\_interface.widget\_helpers.HiddenPrints
=======================================================

.. currentmodule:: mcstasscript.jb_interface.widget_helpers

.. autoclass:: HiddenPrints
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~HiddenPrints.__init__
   
   

   
   
   