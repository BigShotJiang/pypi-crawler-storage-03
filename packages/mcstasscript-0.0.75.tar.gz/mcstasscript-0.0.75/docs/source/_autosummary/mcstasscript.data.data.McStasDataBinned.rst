mcstasscript.data.data.McStasDataBinned
=======================================

.. currentmodule:: mcstasscript.data.data

.. autoclass:: McStasDataBinned
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~McStasDataBinned.__init__
      ~McStasDataBinned.get_data_location
      ~McStasDataBinned.set_data_location
      ~McStasDataBinned.set_plot_options
      ~McStasDataBinned.set_title
      ~McStasDataBinned.set_xlabel
      ~McStasDataBinned.set_ylabel
   
   

   
   
   