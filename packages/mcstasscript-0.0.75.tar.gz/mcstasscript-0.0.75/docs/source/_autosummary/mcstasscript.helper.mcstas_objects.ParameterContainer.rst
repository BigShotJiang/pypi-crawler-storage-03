mcstasscript.helper.mcstas\_objects.ParameterContainer
======================================================

.. currentmodule:: mcstasscript.helper.mcstas_objects

.. autoclass:: ParameterContainer
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ParameterContainer.__init__
      ~ParameterContainer.add
      ~ParameterContainer.check_list_type
      ~ParameterContainer.check_type
      ~ParameterContainer.from_dict
      ~ParameterContainer.from_json
      ~ParameterContainer.import_parameters
      ~ParameterContainer.new_parameter
      ~ParameterContainer.print_indented
      ~ParameterContainer.show_parameters
      ~ParameterContainer.to_dict
      ~ParameterContainer.to_json
   
   

   
   
   