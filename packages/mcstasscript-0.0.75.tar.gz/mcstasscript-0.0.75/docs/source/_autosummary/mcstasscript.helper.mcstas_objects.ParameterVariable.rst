mcstasscript.helper.mcstas\_objects.ParameterVariable
=====================================================

.. currentmodule:: mcstasscript.helper.mcstas_objects

.. autoclass:: ParameterVariable
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ParameterVariable.__init__
      ~ParameterVariable.add_interval
      ~ParameterVariable.add_option
      ~ParameterVariable.clear_intervals
      ~ParameterVariable.clear_options
      ~ParameterVariable.from_dict
      ~ParameterVariable.is_legal
      ~ParameterVariable.print_line
      ~ParameterVariable.print_paramter_constraints
      ~ParameterVariable.write_parameter
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ParameterVariable.value
   
   