mcstasscript.tests.test\_Instr.setup\_populated\_x\_ray\_instr
==============================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_populated_x_ray_instr