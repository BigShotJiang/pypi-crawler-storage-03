mcstasscript.interface.plotter.make\_plot
=========================================

.. currentmodule:: mcstasscript.interface.plotter

.. autofunction:: make_plot