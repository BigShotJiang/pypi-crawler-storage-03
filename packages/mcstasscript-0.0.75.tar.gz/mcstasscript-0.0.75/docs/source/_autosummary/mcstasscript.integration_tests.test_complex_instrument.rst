mcstasscript.integration\_tests.test\_complex\_instrument
=========================================================

.. automodule:: mcstasscript.integration_tests.test_complex_instrument

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      setup_complex_instrument
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      FakeChange
      TestComplexInstrument
   
   

   
   
   



