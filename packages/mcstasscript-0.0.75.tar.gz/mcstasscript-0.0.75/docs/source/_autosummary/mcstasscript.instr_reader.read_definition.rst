mcstasscript.instr\_reader.read\_definition
===========================================

.. automodule:: mcstasscript.instr_reader.read_definition

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      DefinitionReader
   
   

   
   
   



