mcstasscript.tests.test\_dump\_and\_load.setup\_populated\_with\_some\_options\_instr
=====================================================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autofunction:: setup_populated_with_some_options_instr