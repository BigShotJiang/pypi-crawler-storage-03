mcstasscript.tests.test\_Instr\_reader.enablePrint
==================================================

.. currentmodule:: mcstasscript.tests.test_Instr_reader

.. autofunction:: enablePrint