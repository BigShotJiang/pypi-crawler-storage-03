mcstasscript.tests.test\_McStasData.set\_dummy\_McStasDataBinned\_2d
====================================================================

.. currentmodule:: mcstasscript.tests.test_McStasData

.. autofunction:: set_dummy_McStasDataBinned_2d