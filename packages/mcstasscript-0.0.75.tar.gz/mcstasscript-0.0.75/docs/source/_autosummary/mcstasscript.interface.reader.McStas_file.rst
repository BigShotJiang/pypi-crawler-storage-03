mcstasscript.interface.reader.McStas\_file
==========================================

.. currentmodule:: mcstasscript.interface.reader

.. autoclass:: McStas_file
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~McStas_file.__init__
      ~McStas_file.add_to_instr
      ~McStas_file.write_python_file
   
   

   
   
   