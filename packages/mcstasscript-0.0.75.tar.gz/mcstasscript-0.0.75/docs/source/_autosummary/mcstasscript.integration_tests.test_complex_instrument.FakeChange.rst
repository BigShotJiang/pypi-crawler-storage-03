mcstasscript.integration\_tests.test\_complex\_instrument.FakeChange
====================================================================

.. currentmodule:: mcstasscript.integration_tests.test_complex_instrument

.. autoclass:: FakeChange
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FakeChange.__init__
   
   

   
   
   