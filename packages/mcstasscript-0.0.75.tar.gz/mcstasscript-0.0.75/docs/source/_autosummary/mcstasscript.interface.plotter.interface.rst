mcstasscript.interface.plotter.interface
========================================

.. currentmodule:: mcstasscript.interface.plotter

.. autofunction:: interface