mcstasscript.integration\_tests.test\_complex\_instrument.setup\_complex\_instrument
====================================================================================

.. currentmodule:: mcstasscript.integration_tests.test_complex_instrument

.. autofunction:: setup_complex_instrument