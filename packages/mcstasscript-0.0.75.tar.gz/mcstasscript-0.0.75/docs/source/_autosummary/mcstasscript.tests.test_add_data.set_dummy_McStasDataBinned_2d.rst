mcstasscript.tests.test\_add\_data.set\_dummy\_McStasDataBinned\_2d
===================================================================

.. currentmodule:: mcstasscript.tests.test_add_data

.. autofunction:: set_dummy_McStasDataBinned_2d