mcstasscript.jb\_interface.simulation\_interface.SimInterface
=============================================================

.. currentmodule:: mcstasscript.jb_interface.simulation_interface

.. autoclass:: SimInterface
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SimInterface.__init__
      ~SimInterface.make_live_checkmark
      ~SimInterface.make_mpi_field
      ~SimInterface.make_ncount_field
      ~SimInterface.make_parameter_widgets
      ~SimInterface.make_progress_bar
      ~SimInterface.make_run_button
      ~SimInterface.run_simulation_live
      ~SimInterface.run_simulation_thread
      ~SimInterface.show_interface
      ~SimInterface.update_mpi
      ~SimInterface.update_ncount
   
   

   
   
   