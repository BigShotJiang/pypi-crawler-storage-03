mcstasscript.tests.test\_plot\_interface
========================================

.. automodule:: mcstasscript.tests.test_plot_interface

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      fake_data
      set_dummy_McStasDataBinned_1d
      set_dummy_McStasDataBinned_2d
      set_dummy_MetaDataBinned_1d
      set_dummy_MetaDataBinned_2d
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      FakeChange
      TestPlotInterface
   
   

   
   
   



