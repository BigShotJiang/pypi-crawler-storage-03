mcstasscript.jb\_interface.widget\_helpers.get\_parameter\_default
==================================================================

.. currentmodule:: mcstasscript.jb_interface.widget_helpers

.. autofunction:: get_parameter_default