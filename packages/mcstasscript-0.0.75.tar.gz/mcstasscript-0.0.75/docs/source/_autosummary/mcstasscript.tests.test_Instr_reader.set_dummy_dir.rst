mcstasscript.tests.test\_Instr\_reader.set\_dummy\_dir
======================================================

.. currentmodule:: mcstasscript.tests.test_Instr_reader

.. autofunction:: set_dummy_dir