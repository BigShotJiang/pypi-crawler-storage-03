mcstasscript.jb\_interface.simulation\_interface
================================================

.. automodule:: mcstasscript.jb_interface.simulation_interface

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      add_data
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      ParameterWidget
      SimInterface
   
   

   
   
   



