mcstasscript.data.data.McStasDataEvent
======================================

.. currentmodule:: mcstasscript.data.data

.. autoclass:: McStasDataEvent
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~McStasDataEvent.__init__
      ~McStasDataEvent.get_data_location
      ~McStasDataEvent.set_data_location
      ~McStasDataEvent.set_plot_options
      ~McStasDataEvent.set_title
      ~McStasDataEvent.set_xlabel
      ~McStasDataEvent.set_ylabel
   
   

   
   
   