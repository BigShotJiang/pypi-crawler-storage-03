mcstasscript.integration\_tests.test\_simple\_instrument
========================================================

.. automodule:: mcstasscript.integration_tests.test_simple_instrument

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      setup_simple_instrument
      setup_simple_instrument_input_path
      setup_simple_slit_instrument
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TestSimpleInstrument
   
   

   
   
   



