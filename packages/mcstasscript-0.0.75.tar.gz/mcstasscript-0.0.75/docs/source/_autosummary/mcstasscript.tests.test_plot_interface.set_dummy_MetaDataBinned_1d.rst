mcstasscript.tests.test\_plot\_interface.set\_dummy\_MetaDataBinned\_1d
=======================================================================

.. currentmodule:: mcstasscript.tests.test_plot_interface

.. autofunction:: set_dummy_MetaDataBinned_1d