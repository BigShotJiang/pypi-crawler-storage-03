mcstasscript.tests.test\_Instr.setup\_x\_ray\_instr\_no\_path
=============================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_x_ray_instr_no_path