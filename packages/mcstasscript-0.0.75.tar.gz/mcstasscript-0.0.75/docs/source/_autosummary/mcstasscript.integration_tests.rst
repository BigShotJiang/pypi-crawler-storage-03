mcstasscript.integration\_tests
===============================

.. automodule:: mcstasscript.integration_tests

   
   
   

   
   
   

   
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: custom-module-template.rst
   :recursive:

   mcstasscript.integration_tests.test_complex_instrument
   mcstasscript.integration_tests.test_simple_instrument

