mcstasscript.interface.functions.name\_search
=============================================

.. currentmodule:: mcstasscript.interface.functions

.. autofunction:: name_search