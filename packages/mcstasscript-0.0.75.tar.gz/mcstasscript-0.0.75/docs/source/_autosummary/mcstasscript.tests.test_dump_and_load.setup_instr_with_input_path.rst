mcstasscript.tests.test\_dump\_and\_load.setup\_instr\_with\_input\_path
========================================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autofunction:: setup_instr_with_input_path