mcstasscript.helper.formatting.is\_legal\_parameter
===================================================

.. currentmodule:: mcstasscript.helper.formatting

.. autofunction:: is_legal_parameter