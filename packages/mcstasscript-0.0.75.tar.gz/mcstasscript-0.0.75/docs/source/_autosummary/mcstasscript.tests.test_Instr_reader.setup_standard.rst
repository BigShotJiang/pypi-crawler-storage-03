mcstasscript.tests.test\_Instr\_reader.setup\_standard
======================================================

.. currentmodule:: mcstasscript.tests.test_Instr_reader

.. autofunction:: setup_standard