mcstasscript.jb\_interface.plot\_interface.ColormapDropdown
===========================================================

.. currentmodule:: mcstasscript.jb_interface.plot_interface

.. autoclass:: ColormapDropdown
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ColormapDropdown.__init__
      ~ColormapDropdown.make_widget
      ~ColormapDropdown.update_cmap
      ~ColormapDropdown.update_cmap_options
   
   

   
   
   