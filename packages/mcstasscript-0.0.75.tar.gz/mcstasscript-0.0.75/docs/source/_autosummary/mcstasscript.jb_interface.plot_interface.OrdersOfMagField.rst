mcstasscript.jb\_interface.plot\_interface.OrdersOfMagField
===========================================================

.. currentmodule:: mcstasscript.jb_interface.plot_interface

.. autoclass:: OrdersOfMagField
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OrdersOfMagField.__init__
      ~OrdersOfMagField.make_widget
      ~OrdersOfMagField.update
   
   

   
   
   