mcstasscript.tests.test\_functions
==================================

.. automodule:: mcstasscript.tests.test_functions

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      set_dummy_McStasDataBinned_1d
      set_dummy_McStasDataBinned_2d
      set_dummy_MetaDataBinned_1d
      set_dummy_MetaDataBinned_2d
      setup_McStasData_array
      setup_McStasData_array_repeat
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      Test_load_data
      Test_load_metadata
      Test_load_monitor
      Test_name_plot_options
      Test_name_search
   
   

   
   
   



