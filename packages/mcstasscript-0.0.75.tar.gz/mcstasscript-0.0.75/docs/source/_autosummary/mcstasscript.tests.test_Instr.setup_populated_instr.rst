mcstasscript.tests.test\_Instr.setup\_populated\_instr
======================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_populated_instr