mcstasscript.interface.plotter.make\_animation
==============================================

.. currentmodule:: mcstasscript.interface.plotter

.. autofunction:: make_animation