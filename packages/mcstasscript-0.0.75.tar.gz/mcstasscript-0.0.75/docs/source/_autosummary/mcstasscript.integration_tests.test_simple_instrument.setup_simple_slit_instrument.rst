mcstasscript.integration\_tests.test\_simple\_instrument.setup\_simple\_slit\_instrument
========================================================================================

.. currentmodule:: mcstasscript.integration_tests.test_simple_instrument

.. autofunction:: setup_simple_slit_instrument