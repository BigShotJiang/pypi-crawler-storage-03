mcstasscript.instr\_reader.read\_declare
========================================

.. automodule:: mcstasscript.instr_reader.read_declare

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      DeclareReader
   
   

   
   
   



