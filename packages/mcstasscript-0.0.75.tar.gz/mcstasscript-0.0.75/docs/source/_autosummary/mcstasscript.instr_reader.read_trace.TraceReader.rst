mcstasscript.instr\_reader.read\_trace.TraceReader
==================================================

.. currentmodule:: mcstasscript.instr_reader.read_trace

.. autoclass:: TraceReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TraceReader.__init__
      ~TraceReader.read_trace_line
      ~TraceReader.sanitize_line
      ~TraceReader.set_instr_name
   
   

   
   
   