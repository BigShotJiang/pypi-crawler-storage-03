mcstasscript.tests.test\_add\_data.Test\_add\_data
==================================================

.. currentmodule:: mcstasscript.tests.test_add_data

.. autoclass:: Test_add_data
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Test_add_data.__init__
      ~Test_add_data.addClassCleanup
      ~Test_add_data.addCleanup
      ~Test_add_data.addTypeEqualityFunc
      ~Test_add_data.assertAlmostEqual
      ~Test_add_data.assertAlmostEquals
      ~Test_add_data.assertCountEqual
      ~Test_add_data.assertDictContainsSubset
      ~Test_add_data.assertDictEqual
      ~Test_add_data.assertEqual
      ~Test_add_data.assertEquals
      ~Test_add_data.assertFalse
      ~Test_add_data.assertGreater
      ~Test_add_data.assertGreaterEqual
      ~Test_add_data.assertIn
      ~Test_add_data.assertIs
      ~Test_add_data.assertIsInstance
      ~Test_add_data.assertIsNone
      ~Test_add_data.assertIsNot
      ~Test_add_data.assertIsNotNone
      ~Test_add_data.assertLess
      ~Test_add_data.assertLessEqual
      ~Test_add_data.assertListEqual
      ~Test_add_data.assertLogs
      ~Test_add_data.assertMultiLineEqual
      ~Test_add_data.assertNotAlmostEqual
      ~Test_add_data.assertNotAlmostEquals
      ~Test_add_data.assertNotEqual
      ~Test_add_data.assertNotEquals
      ~Test_add_data.assertNotIn
      ~Test_add_data.assertNotIsInstance
      ~Test_add_data.assertNotRegex
      ~Test_add_data.assertNotRegexpMatches
      ~Test_add_data.assertRaises
      ~Test_add_data.assertRaisesRegex
      ~Test_add_data.assertRaisesRegexp
      ~Test_add_data.assertRegex
      ~Test_add_data.assertRegexpMatches
      ~Test_add_data.assertSequenceEqual
      ~Test_add_data.assertSetEqual
      ~Test_add_data.assertTrue
      ~Test_add_data.assertTupleEqual
      ~Test_add_data.assertWarns
      ~Test_add_data.assertWarnsRegex
      ~Test_add_data.assert_
      ~Test_add_data.countTestCases
      ~Test_add_data.debug
      ~Test_add_data.defaultTestResult
      ~Test_add_data.doClassCleanups
      ~Test_add_data.doCleanups
      ~Test_add_data.fail
      ~Test_add_data.failIf
      ~Test_add_data.failIfAlmostEqual
      ~Test_add_data.failIfEqual
      ~Test_add_data.failUnless
      ~Test_add_data.failUnlessAlmostEqual
      ~Test_add_data.failUnlessEqual
      ~Test_add_data.failUnlessRaises
      ~Test_add_data.id
      ~Test_add_data.run
      ~Test_add_data.setUp
      ~Test_add_data.setUpClass
      ~Test_add_data.shortDescription
      ~Test_add_data.skipTest
      ~Test_add_data.subTest
      ~Test_add_data.tearDown
      ~Test_add_data.tearDownClass
      ~Test_add_data.test_1d_updates_correctly
      ~Test_add_data.test_1d_updates_different
      ~Test_add_data.test_2d_updates_correctly
      ~Test_add_data.test_2d_updates_different
      ~Test_add_data.test_fail
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Test_add_data.longMessage
      ~Test_add_data.maxDiff
   
   