mcstasscript.instr\_reader.read\_declare.DeclareReader
======================================================

.. currentmodule:: mcstasscript.instr_reader.read_declare

.. autoclass:: DeclareReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DeclareReader.__init__
      ~DeclareReader.read_declare_line
      ~DeclareReader.set_instr_name
   
   

   
   
   