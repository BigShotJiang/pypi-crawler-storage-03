mcstasscript.tests.test\_plot\_interface.set\_dummy\_MetaDataBinned\_2d
=======================================================================

.. currentmodule:: mcstasscript.tests.test_plot_interface

.. autofunction:: set_dummy_MetaDataBinned_2d