mcstasscript.integration\_tests.test\_simple\_instrument.setup\_simple\_instrument\_input\_path
===============================================================================================

.. currentmodule:: mcstasscript.integration_tests.test_simple_instrument

.. autofunction:: setup_simple_instrument_input_path