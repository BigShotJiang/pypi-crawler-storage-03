mcstasscript.instr\_reader.read\_trace
======================================

.. automodule:: mcstasscript.instr_reader.read_trace

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TraceReader
   
   

   
   
   



