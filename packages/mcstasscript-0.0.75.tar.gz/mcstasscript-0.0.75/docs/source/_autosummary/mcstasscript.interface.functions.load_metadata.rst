mcstasscript.interface.functions.load\_metadata
===============================================

.. currentmodule:: mcstasscript.interface.functions

.. autofunction:: load_metadata