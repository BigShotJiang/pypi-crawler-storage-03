mcstasscript.tests.test\_ComponentReader.setup\_component\_reader\_input\_path
==============================================================================

.. currentmodule:: mcstasscript.tests.test_ComponentReader

.. autofunction:: setup_component_reader_input_path