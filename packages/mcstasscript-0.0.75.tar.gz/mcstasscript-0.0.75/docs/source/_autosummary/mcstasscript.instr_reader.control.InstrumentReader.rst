mcstasscript.instr\_reader.control.InstrumentReader
===================================================

.. currentmodule:: mcstasscript.instr_reader.control

.. autoclass:: InstrumentReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~InstrumentReader.__init__
      ~InstrumentReader.add_to_instr
      ~InstrumentReader.generate_py_version
      ~InstrumentReader.update_file_name
   
   

   
   
   