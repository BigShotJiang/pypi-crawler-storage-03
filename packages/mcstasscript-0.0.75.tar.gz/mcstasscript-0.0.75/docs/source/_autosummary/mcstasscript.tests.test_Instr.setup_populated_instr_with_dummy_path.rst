mcstasscript.tests.test\_Instr.setup\_populated\_instr\_with\_dummy\_path
=========================================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_populated_instr_with_dummy_path