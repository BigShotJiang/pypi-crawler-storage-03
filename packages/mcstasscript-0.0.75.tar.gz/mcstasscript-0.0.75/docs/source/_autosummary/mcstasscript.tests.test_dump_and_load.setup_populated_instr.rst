mcstasscript.tests.test\_dump\_and\_load.setup\_populated\_instr
================================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autofunction:: setup_populated_instr