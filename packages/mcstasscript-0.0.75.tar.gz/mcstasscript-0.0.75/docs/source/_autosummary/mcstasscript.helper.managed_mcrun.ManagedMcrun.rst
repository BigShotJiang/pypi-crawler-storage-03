mcstasscript.helper.managed\_mcrun.ManagedMcrun
===============================================

.. currentmodule:: mcstasscript.helper.managed_mcrun

.. autoclass:: ManagedMcrun
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ManagedMcrun.__init__
      ~ManagedMcrun.load_results
      ~ManagedMcrun.run_simulation
   
   

   
   
   