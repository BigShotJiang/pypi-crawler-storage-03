mcstasscript.data.data.McStasPlotOptions
========================================

.. currentmodule:: mcstasscript.data.data

.. autoclass:: McStasPlotOptions
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~McStasPlotOptions.__init__
      ~McStasPlotOptions.set_options
   
   

   
   
   