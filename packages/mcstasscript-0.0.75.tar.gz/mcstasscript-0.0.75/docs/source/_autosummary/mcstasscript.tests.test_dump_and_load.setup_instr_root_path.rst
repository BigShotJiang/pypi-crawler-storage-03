mcstasscript.tests.test\_dump\_and\_load.setup\_instr\_root\_path
=================================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autofunction:: setup_instr_root_path