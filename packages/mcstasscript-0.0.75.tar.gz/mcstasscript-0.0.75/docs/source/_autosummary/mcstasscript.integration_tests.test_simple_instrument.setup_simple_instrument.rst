mcstasscript.integration\_tests.test\_simple\_instrument.setup\_simple\_instrument
==================================================================================

.. currentmodule:: mcstasscript.integration_tests.test_simple_instrument

.. autofunction:: setup_simple_instrument