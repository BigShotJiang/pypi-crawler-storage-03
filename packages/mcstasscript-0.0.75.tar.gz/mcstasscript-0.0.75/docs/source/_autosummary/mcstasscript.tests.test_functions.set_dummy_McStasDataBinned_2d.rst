mcstasscript.tests.test\_functions.set\_dummy\_McStasDataBinned\_2d
===================================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autofunction:: set_dummy_McStasDataBinned_2d