mcstasscript.helper.mcstas\_objects.DeclareVariable
===================================================

.. currentmodule:: mcstasscript.helper.mcstas_objects

.. autoclass:: DeclareVariable
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DeclareVariable.__init__
      ~DeclareVariable.write_line
   
   

   
   
   