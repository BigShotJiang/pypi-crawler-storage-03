mcstasscript.tests.test\_component.setup\_Component\_with\_parameters
=====================================================================

.. currentmodule:: mcstasscript.tests.test_component

.. autofunction:: setup_Component_with_parameters