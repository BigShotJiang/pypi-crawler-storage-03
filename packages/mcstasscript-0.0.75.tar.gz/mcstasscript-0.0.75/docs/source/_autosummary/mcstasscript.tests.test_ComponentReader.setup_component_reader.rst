mcstasscript.tests.test\_ComponentReader.setup\_component\_reader
=================================================================

.. currentmodule:: mcstasscript.tests.test_ComponentReader

.. autofunction:: setup_component_reader