mcstasscript.tests.test\_Plotter.get\_dummy\_MetaDataBinned\_2d
===============================================================

.. currentmodule:: mcstasscript.tests.test_Plotter

.. autofunction:: get_dummy_MetaDataBinned_2d