mcstasscript.tests.test\_dump\_and\_load.setup\_populated\_x\_ray\_instr\_with\_dummy\_path
===========================================================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autofunction:: setup_populated_x_ray_instr_with_dummy_path