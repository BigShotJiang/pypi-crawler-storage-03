mcstasscript.tests.test\_simulation\_interface.setup\_populated\_instr\_McXtrace
================================================================================

.. currentmodule:: mcstasscript.tests.test_simulation_interface

.. autofunction:: setup_populated_instr_McXtrace