mcstasscript.jb\_interface.plot\_interface.MonitorDropdown
==========================================================

.. currentmodule:: mcstasscript.jb_interface.plot_interface

.. autoclass:: MonitorDropdown
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MonitorDropdown.__init__
      ~MonitorDropdown.make_widget
      ~MonitorDropdown.set_data
      ~MonitorDropdown.update
   
   

   
   
   