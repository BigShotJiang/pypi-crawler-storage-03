mcstasscript.interface.functions.Configurator
=============================================

.. currentmodule:: mcstasscript.interface.functions

.. autoclass:: Configurator
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Configurator.__init__
      ~Configurator.set_line_length
      ~Configurator.set_mcrun_path
      ~Configurator.set_mcstas_path
      ~Configurator.set_mcxtrace_path
      ~Configurator.set_mxrun_path
   
   

   
   
   