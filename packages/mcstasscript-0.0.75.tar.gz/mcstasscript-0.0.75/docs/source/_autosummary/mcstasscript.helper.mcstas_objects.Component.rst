mcstasscript.helper.mcstas\_objects.Component
=============================================

.. currentmodule:: mcstasscript.helper.mcstas_objects

.. autoclass:: Component
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Component.__init__
      ~Component.append_EXTEND
      ~Component.print_long
      ~Component.print_long_deprecated
      ~Component.print_short
      ~Component.set_AT
      ~Component.set_AT_RELATIVE
      ~Component.set_GROUP
      ~Component.set_JUMP
      ~Component.set_RELATIVE
      ~Component.set_ROTATED
      ~Component.set_ROTATED_RELATIVE
      ~Component.set_SPLIT
      ~Component.set_WHEN
      ~Component.set_c_code_after
      ~Component.set_c_code_before
      ~Component.set_comment
      ~Component.set_keyword_input
      ~Component.set_parameters
      ~Component.show_parameters
      ~Component.show_parameters_simple
      ~Component.write_component
   
   

   
   
   