mcstasscript.tests.test\_functions.Test\_load\_data
===================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autoclass:: Test_load_data
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Test_load_data.__init__
      ~Test_load_data.addClassCleanup
      ~Test_load_data.addCleanup
      ~Test_load_data.addTypeEqualityFunc
      ~Test_load_data.assertAlmostEqual
      ~Test_load_data.assertAlmostEquals
      ~Test_load_data.assertCountEqual
      ~Test_load_data.assertDictContainsSubset
      ~Test_load_data.assertDictEqual
      ~Test_load_data.assertEqual
      ~Test_load_data.assertEquals
      ~Test_load_data.assertFalse
      ~Test_load_data.assertGreater
      ~Test_load_data.assertGreaterEqual
      ~Test_load_data.assertIn
      ~Test_load_data.assertIs
      ~Test_load_data.assertIsInstance
      ~Test_load_data.assertIsNone
      ~Test_load_data.assertIsNot
      ~Test_load_data.assertIsNotNone
      ~Test_load_data.assertLess
      ~Test_load_data.assertLessEqual
      ~Test_load_data.assertListEqual
      ~Test_load_data.assertLogs
      ~Test_load_data.assertMultiLineEqual
      ~Test_load_data.assertNotAlmostEqual
      ~Test_load_data.assertNotAlmostEquals
      ~Test_load_data.assertNotEqual
      ~Test_load_data.assertNotEquals
      ~Test_load_data.assertNotIn
      ~Test_load_data.assertNotIsInstance
      ~Test_load_data.assertNotRegex
      ~Test_load_data.assertNotRegexpMatches
      ~Test_load_data.assertRaises
      ~Test_load_data.assertRaisesRegex
      ~Test_load_data.assertRaisesRegexp
      ~Test_load_data.assertRegex
      ~Test_load_data.assertRegexpMatches
      ~Test_load_data.assertSequenceEqual
      ~Test_load_data.assertSetEqual
      ~Test_load_data.assertTrue
      ~Test_load_data.assertTupleEqual
      ~Test_load_data.assertWarns
      ~Test_load_data.assertWarnsRegex
      ~Test_load_data.assert_
      ~Test_load_data.countTestCases
      ~Test_load_data.debug
      ~Test_load_data.defaultTestResult
      ~Test_load_data.doClassCleanups
      ~Test_load_data.doCleanups
      ~Test_load_data.fail
      ~Test_load_data.failIf
      ~Test_load_data.failIfAlmostEqual
      ~Test_load_data.failIfEqual
      ~Test_load_data.failUnless
      ~Test_load_data.failUnlessAlmostEqual
      ~Test_load_data.failUnlessEqual
      ~Test_load_data.failUnlessRaises
      ~Test_load_data.id
      ~Test_load_data.run
      ~Test_load_data.setUp
      ~Test_load_data.setUpClass
      ~Test_load_data.shortDescription
      ~Test_load_data.skipTest
      ~Test_load_data.subTest
      ~Test_load_data.tearDown
      ~Test_load_data.tearDownClass
      ~Test_load_data.test_mcrun_load_data_PSD4PI
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Test_load_data.longMessage
      ~Test_load_data.maxDiff
   
   