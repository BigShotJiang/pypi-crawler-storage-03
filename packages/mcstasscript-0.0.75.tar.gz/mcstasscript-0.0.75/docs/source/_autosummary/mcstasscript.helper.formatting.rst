mcstasscript.helper.formatting
==============================

.. automodule:: mcstasscript.helper.formatting

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      is_legal_filename
      is_legal_parameter
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      bcolors
   
   

   
   
   



