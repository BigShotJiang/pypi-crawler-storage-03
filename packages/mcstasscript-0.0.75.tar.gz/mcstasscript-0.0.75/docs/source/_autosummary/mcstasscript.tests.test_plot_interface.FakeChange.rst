mcstasscript.tests.test\_plot\_interface.FakeChange
===================================================

.. currentmodule:: mcstasscript.tests.test_plot_interface

.. autoclass:: FakeChange
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FakeChange.__init__
   
   

   
   
   