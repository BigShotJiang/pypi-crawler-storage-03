mcstasscript.jb\_interface.plot\_interface
==========================================

.. automodule:: mcstasscript.jb_interface.plot_interface

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      ColormapDropdown
      LogCheckbox
      MonitorDropdown
      OrdersOfMagField
      PlotInterface
   
   

   
   
   



