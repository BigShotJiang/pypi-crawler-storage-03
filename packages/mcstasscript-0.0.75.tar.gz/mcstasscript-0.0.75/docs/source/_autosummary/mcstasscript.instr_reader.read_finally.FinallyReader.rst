mcstasscript.instr\_reader.read\_finally.FinallyReader
======================================================

.. currentmodule:: mcstasscript.instr_reader.read_finally

.. autoclass:: FinallyReader
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FinallyReader.__init__
      ~FinallyReader.read_finally_line
      ~FinallyReader.set_instr_name
   
   

   
   
   