mcstasscript.helper.managed\_mcrun.load\_results
================================================

.. currentmodule:: mcstasscript.helper.managed_mcrun

.. autofunction:: load_results