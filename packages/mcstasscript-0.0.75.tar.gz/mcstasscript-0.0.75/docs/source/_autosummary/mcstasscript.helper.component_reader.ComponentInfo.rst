mcstasscript.helper.component\_reader.ComponentInfo
===================================================

.. currentmodule:: mcstasscript.helper.component_reader

.. autoclass:: ComponentInfo
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ComponentInfo.__init__
   
   

   
   
   