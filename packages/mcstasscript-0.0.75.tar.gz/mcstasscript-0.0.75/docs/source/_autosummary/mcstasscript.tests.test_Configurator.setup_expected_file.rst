mcstasscript.tests.test\_Configurator.setup\_expected\_file
===========================================================

.. currentmodule:: mcstasscript.tests.test_Configurator

.. autofunction:: setup_expected_file