mcstasscript.tests.test\_Instr\_reader.blockPrint
=================================================

.. currentmodule:: mcstasscript.tests.test_Instr_reader

.. autofunction:: blockPrint