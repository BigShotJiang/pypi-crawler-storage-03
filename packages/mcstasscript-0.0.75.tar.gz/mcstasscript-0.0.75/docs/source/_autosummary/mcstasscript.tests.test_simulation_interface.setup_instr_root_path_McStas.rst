mcstasscript.tests.test\_simulation\_interface.setup\_instr\_root\_path\_McStas
===============================================================================

.. currentmodule:: mcstasscript.tests.test_simulation_interface

.. autofunction:: setup_instr_root_path_McStas