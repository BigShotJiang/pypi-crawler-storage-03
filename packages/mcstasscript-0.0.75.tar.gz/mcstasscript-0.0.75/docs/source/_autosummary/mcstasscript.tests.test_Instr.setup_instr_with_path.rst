mcstasscript.tests.test\_Instr.setup\_instr\_with\_path
=======================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_instr_with_path