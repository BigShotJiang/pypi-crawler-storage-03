mcstasscript.tests.helpers\_for\_tests.WorkInTestDir
====================================================

.. currentmodule:: mcstasscript.tests.helpers_for_tests

.. autoclass:: WorkInTestDir
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~WorkInTestDir.__init__
   
   

   
   
   