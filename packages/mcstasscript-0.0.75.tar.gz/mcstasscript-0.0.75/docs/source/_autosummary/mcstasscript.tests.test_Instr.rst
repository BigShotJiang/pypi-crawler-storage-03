mcstasscript.tests.test\_Instr
==============================

.. automodule:: mcstasscript.tests.test_Instr

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
   
      setup_instr_no_path
      setup_instr_root_path
      setup_instr_with_input_path
      setup_instr_with_input_path_relative
      setup_instr_with_path
      setup_populated_instr
      setup_populated_instr_with_dummy_path
      setup_populated_with_some_options_instr
      setup_populated_x_ray_instr
      setup_populated_x_ray_instr_with_dummy_path
      setup_x_ray_instr_no_path
      setup_x_ray_instr_root_path
      setup_x_ray_instr_with_path
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      TestMcStas_instr
   
   

   
   
   



