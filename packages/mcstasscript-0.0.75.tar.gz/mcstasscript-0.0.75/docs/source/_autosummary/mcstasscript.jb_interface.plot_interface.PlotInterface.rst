mcstasscript.jb\_interface.plot\_interface.PlotInterface
========================================================

.. currentmodule:: mcstasscript.jb_interface.plot_interface

.. autoclass:: PlotInterface
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PlotInterface.__init__
      ~PlotInterface.new_plot
      ~PlotInterface.set_colormap
      ~PlotInterface.set_current_monitor
      ~PlotInterface.set_data
      ~PlotInterface.set_log_mode
      ~PlotInterface.set_orders_of_mag
      ~PlotInterface.show_interface
      ~PlotInterface.update_plot
   
   

   
   
   