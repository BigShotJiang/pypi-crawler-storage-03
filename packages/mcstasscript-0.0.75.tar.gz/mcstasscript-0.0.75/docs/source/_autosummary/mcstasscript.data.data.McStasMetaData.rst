mcstasscript.data.data.McStasMetaData
=====================================

.. currentmodule:: mcstasscript.data.data

.. autoclass:: McStasMetaData
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~McStasMetaData.__init__
      ~McStasMetaData.add_info
      ~McStasMetaData.extract_info
      ~McStasMetaData.set_title
      ~McStasMetaData.set_xlabel
      ~McStasMetaData.set_ylabel
   
   

   
   
   