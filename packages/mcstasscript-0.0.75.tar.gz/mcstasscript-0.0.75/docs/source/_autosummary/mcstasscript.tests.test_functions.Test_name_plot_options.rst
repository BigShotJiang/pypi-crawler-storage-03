mcstasscript.tests.test\_functions.Test\_name\_plot\_options
============================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autoclass:: Test_name_plot_options
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Test_name_plot_options.__init__
      ~Test_name_plot_options.addClassCleanup
      ~Test_name_plot_options.addCleanup
      ~Test_name_plot_options.addTypeEqualityFunc
      ~Test_name_plot_options.assertAlmostEqual
      ~Test_name_plot_options.assertAlmostEquals
      ~Test_name_plot_options.assertCountEqual
      ~Test_name_plot_options.assertDictContainsSubset
      ~Test_name_plot_options.assertDictEqual
      ~Test_name_plot_options.assertEqual
      ~Test_name_plot_options.assertEquals
      ~Test_name_plot_options.assertFalse
      ~Test_name_plot_options.assertGreater
      ~Test_name_plot_options.assertGreaterEqual
      ~Test_name_plot_options.assertIn
      ~Test_name_plot_options.assertIs
      ~Test_name_plot_options.assertIsInstance
      ~Test_name_plot_options.assertIsNone
      ~Test_name_plot_options.assertIsNot
      ~Test_name_plot_options.assertIsNotNone
      ~Test_name_plot_options.assertLess
      ~Test_name_plot_options.assertLessEqual
      ~Test_name_plot_options.assertListEqual
      ~Test_name_plot_options.assertLogs
      ~Test_name_plot_options.assertMultiLineEqual
      ~Test_name_plot_options.assertNotAlmostEqual
      ~Test_name_plot_options.assertNotAlmostEquals
      ~Test_name_plot_options.assertNotEqual
      ~Test_name_plot_options.assertNotEquals
      ~Test_name_plot_options.assertNotIn
      ~Test_name_plot_options.assertNotIsInstance
      ~Test_name_plot_options.assertNotRegex
      ~Test_name_plot_options.assertNotRegexpMatches
      ~Test_name_plot_options.assertRaises
      ~Test_name_plot_options.assertRaisesRegex
      ~Test_name_plot_options.assertRaisesRegexp
      ~Test_name_plot_options.assertRegex
      ~Test_name_plot_options.assertRegexpMatches
      ~Test_name_plot_options.assertSequenceEqual
      ~Test_name_plot_options.assertSetEqual
      ~Test_name_plot_options.assertTrue
      ~Test_name_plot_options.assertTupleEqual
      ~Test_name_plot_options.assertWarns
      ~Test_name_plot_options.assertWarnsRegex
      ~Test_name_plot_options.assert_
      ~Test_name_plot_options.countTestCases
      ~Test_name_plot_options.debug
      ~Test_name_plot_options.defaultTestResult
      ~Test_name_plot_options.doClassCleanups
      ~Test_name_plot_options.doCleanups
      ~Test_name_plot_options.fail
      ~Test_name_plot_options.failIf
      ~Test_name_plot_options.failIfAlmostEqual
      ~Test_name_plot_options.failIfEqual
      ~Test_name_plot_options.failUnless
      ~Test_name_plot_options.failUnlessAlmostEqual
      ~Test_name_plot_options.failUnlessEqual
      ~Test_name_plot_options.failUnlessRaises
      ~Test_name_plot_options.id
      ~Test_name_plot_options.run
      ~Test_name_plot_options.setUp
      ~Test_name_plot_options.setUpClass
      ~Test_name_plot_options.shortDescription
      ~Test_name_plot_options.skipTest
      ~Test_name_plot_options.subTest
      ~Test_name_plot_options.tearDown
      ~Test_name_plot_options.tearDownClass
      ~Test_name_plot_options.test_name_plot_options_duplicate
      ~Test_name_plot_options.test_name_plot_options_simple
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Test_name_plot_options.longMessage
      ~Test_name_plot_options.maxDiff
   
   