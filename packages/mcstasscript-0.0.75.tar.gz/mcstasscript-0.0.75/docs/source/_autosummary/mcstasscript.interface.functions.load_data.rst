mcstasscript.interface.functions.load\_data
===========================================

.. currentmodule:: mcstasscript.interface.functions

.. autofunction:: load_data