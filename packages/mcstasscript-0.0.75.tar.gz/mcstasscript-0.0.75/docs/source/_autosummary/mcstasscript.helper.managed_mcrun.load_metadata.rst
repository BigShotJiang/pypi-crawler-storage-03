mcstasscript.helper.managed\_mcrun.load\_metadata
=================================================

.. currentmodule:: mcstasscript.helper.managed_mcrun

.. autofunction:: load_metadata