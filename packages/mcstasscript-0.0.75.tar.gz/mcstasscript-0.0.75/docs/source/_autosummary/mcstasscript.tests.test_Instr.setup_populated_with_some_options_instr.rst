mcstasscript.tests.test\_Instr.setup\_populated\_with\_some\_options\_instr
===========================================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_populated_with_some_options_instr