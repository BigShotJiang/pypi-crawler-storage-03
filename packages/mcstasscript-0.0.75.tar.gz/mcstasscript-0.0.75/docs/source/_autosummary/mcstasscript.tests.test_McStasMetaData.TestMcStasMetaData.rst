mcstasscript.tests.test\_McStasMetaData.TestMcStasMetaData
==========================================================

.. currentmodule:: mcstasscript.tests.test_McStasMetaData

.. autoclass:: TestMcStasMetaData
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TestMcStasMetaData.__init__
      ~TestMcStasMetaData.addClassCleanup
      ~TestMcStasMetaData.addCleanup
      ~TestMcStasMetaData.addTypeEqualityFunc
      ~TestMcStasMetaData.assertAlmostEqual
      ~TestMcStasMetaData.assertAlmostEquals
      ~TestMcStasMetaData.assertCountEqual
      ~TestMcStasMetaData.assertDictContainsSubset
      ~TestMcStasMetaData.assertDictEqual
      ~TestMcStasMetaData.assertEqual
      ~TestMcStasMetaData.assertEquals
      ~TestMcStasMetaData.assertFalse
      ~TestMcStasMetaData.assertGreater
      ~TestMcStasMetaData.assertGreaterEqual
      ~TestMcStasMetaData.assertIn
      ~TestMcStasMetaData.assertIs
      ~TestMcStasMetaData.assertIsInstance
      ~TestMcStasMetaData.assertIsNone
      ~TestMcStasMetaData.assertIsNot
      ~TestMcStasMetaData.assertIsNotNone
      ~TestMcStasMetaData.assertLess
      ~TestMcStasMetaData.assertLessEqual
      ~TestMcStasMetaData.assertListEqual
      ~TestMcStasMetaData.assertLogs
      ~TestMcStasMetaData.assertMultiLineEqual
      ~TestMcStasMetaData.assertNotAlmostEqual
      ~TestMcStasMetaData.assertNotAlmostEquals
      ~TestMcStasMetaData.assertNotEqual
      ~TestMcStasMetaData.assertNotEquals
      ~TestMcStasMetaData.assertNotIn
      ~TestMcStasMetaData.assertNotIsInstance
      ~TestMcStasMetaData.assertNotRegex
      ~TestMcStasMetaData.assertNotRegexpMatches
      ~TestMcStasMetaData.assertRaises
      ~TestMcStasMetaData.assertRaisesRegex
      ~TestMcStasMetaData.assertRaisesRegexp
      ~TestMcStasMetaData.assertRegex
      ~TestMcStasMetaData.assertRegexpMatches
      ~TestMcStasMetaData.assertSequenceEqual
      ~TestMcStasMetaData.assertSetEqual
      ~TestMcStasMetaData.assertTrue
      ~TestMcStasMetaData.assertTupleEqual
      ~TestMcStasMetaData.assertWarns
      ~TestMcStasMetaData.assertWarnsRegex
      ~TestMcStasMetaData.assert_
      ~TestMcStasMetaData.countTestCases
      ~TestMcStasMetaData.debug
      ~TestMcStasMetaData.defaultTestResult
      ~TestMcStasMetaData.doClassCleanups
      ~TestMcStasMetaData.doCleanups
      ~TestMcStasMetaData.fail
      ~TestMcStasMetaData.failIf
      ~TestMcStasMetaData.failIfAlmostEqual
      ~TestMcStasMetaData.failIfEqual
      ~TestMcStasMetaData.failUnless
      ~TestMcStasMetaData.failUnlessAlmostEqual
      ~TestMcStasMetaData.failUnlessEqual
      ~TestMcStasMetaData.failUnlessRaises
      ~TestMcStasMetaData.id
      ~TestMcStasMetaData.run
      ~TestMcStasMetaData.setUp
      ~TestMcStasMetaData.setUpClass
      ~TestMcStasMetaData.shortDescription
      ~TestMcStasMetaData.skipTest
      ~TestMcStasMetaData.subTest
      ~TestMcStasMetaData.tearDown
      ~TestMcStasMetaData.tearDownClass
      ~TestMcStasMetaData.test_McStasMetaData_add_info
      ~TestMcStasMetaData.test_McStasMetaData_add_info_len
      ~TestMcStasMetaData.test_McStasMetaData_add_info_title
      ~TestMcStasMetaData.test_McStasMetaData_add_info_xlabel
      ~TestMcStasMetaData.test_McStasMetaData_add_info_ylabel
      ~TestMcStasMetaData.test_McStasMetaData_init
      ~TestMcStasMetaData.test_McStasMetaData_long_read_1d
      ~TestMcStasMetaData.test_McStasMetaData_long_read_2d
      ~TestMcStasMetaData.test_McStasMetaData_return_type
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TestMcStasMetaData.longMessage
      ~TestMcStasMetaData.maxDiff
   
   