mcstasscript.jb\_interface.simulation\_interface.ParameterWidget
================================================================

.. currentmodule:: mcstasscript.jb_interface.simulation_interface

.. autoclass:: ParameterWidget
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ParameterWidget.__init__
      ~ParameterWidget.make_widget
      ~ParameterWidget.update
   
   

   
   
   