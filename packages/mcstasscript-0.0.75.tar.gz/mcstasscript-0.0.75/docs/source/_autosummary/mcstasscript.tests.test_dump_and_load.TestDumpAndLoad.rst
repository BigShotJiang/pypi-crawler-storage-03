mcstasscript.tests.test\_dump\_and\_load.TestDumpAndLoad
========================================================

.. currentmodule:: mcstasscript.tests.test_dump_and_load

.. autoclass:: TestDumpAndLoad
   :members:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TestDumpAndLoad.__init__
      ~TestDumpAndLoad.addClassCleanup
      ~TestDumpAndLoad.addCleanup
      ~TestDumpAndLoad.addTypeEqualityFunc
      ~TestDumpAndLoad.assertAlmostEqual
      ~TestDumpAndLoad.assertAlmostEquals
      ~TestDumpAndLoad.assertCountEqual
      ~TestDumpAndLoad.assertDictContainsSubset
      ~TestDumpAndLoad.assertDictEqual
      ~TestDumpAndLoad.assertEqual
      ~TestDumpAndLoad.assertEquals
      ~TestDumpAndLoad.assertFalse
      ~TestDumpAndLoad.assertGreater
      ~TestDumpAndLoad.assertGreaterEqual
      ~TestDumpAndLoad.assertIn
      ~TestDumpAndLoad.assertIs
      ~TestDumpAndLoad.assertIsInstance
      ~TestDumpAndLoad.assertIsNone
      ~TestDumpAndLoad.assertIsNot
      ~TestDumpAndLoad.assertIsNotNone
      ~TestDumpAndLoad.assertLess
      ~TestDumpAndLoad.assertLessEqual
      ~TestDumpAndLoad.assertListEqual
      ~TestDumpAndLoad.assertLogs
      ~TestDumpAndLoad.assertMultiLineEqual
      ~TestDumpAndLoad.assertNotAlmostEqual
      ~TestDumpAndLoad.assertNotAlmostEquals
      ~TestDumpAndLoad.assertNotEqual
      ~TestDumpAndLoad.assertNotEquals
      ~TestDumpAndLoad.assertNotIn
      ~TestDumpAndLoad.assertNotIsInstance
      ~TestDumpAndLoad.assertNotRegex
      ~TestDumpAndLoad.assertNotRegexpMatches
      ~TestDumpAndLoad.assertRaises
      ~TestDumpAndLoad.assertRaisesRegex
      ~TestDumpAndLoad.assertRaisesRegexp
      ~TestDumpAndLoad.assertRegex
      ~TestDumpAndLoad.assertRegexpMatches
      ~TestDumpAndLoad.assertSequenceEqual
      ~TestDumpAndLoad.assertSetEqual
      ~TestDumpAndLoad.assertTrue
      ~TestDumpAndLoad.assertTupleEqual
      ~TestDumpAndLoad.assertWarns
      ~TestDumpAndLoad.assertWarnsRegex
      ~TestDumpAndLoad.assert_
      ~TestDumpAndLoad.countTestCases
      ~TestDumpAndLoad.debug
      ~TestDumpAndLoad.defaultTestResult
      ~TestDumpAndLoad.doClassCleanups
      ~TestDumpAndLoad.doCleanups
      ~TestDumpAndLoad.fail
      ~TestDumpAndLoad.failIf
      ~TestDumpAndLoad.failIfAlmostEqual
      ~TestDumpAndLoad.failIfEqual
      ~TestDumpAndLoad.failUnless
      ~TestDumpAndLoad.failUnlessAlmostEqual
      ~TestDumpAndLoad.failUnlessEqual
      ~TestDumpAndLoad.failUnlessRaises
      ~TestDumpAndLoad.id
      ~TestDumpAndLoad.run
      ~TestDumpAndLoad.setUp
      ~TestDumpAndLoad.setUpClass
      ~TestDumpAndLoad.shortDescription
      ~TestDumpAndLoad.skipTest
      ~TestDumpAndLoad.subTest
      ~TestDumpAndLoad.tearDown
      ~TestDumpAndLoad.tearDownClass
      ~TestDumpAndLoad.test_dump_simple
      ~TestDumpAndLoad.test_load_simple
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TestDumpAndLoad.longMessage
      ~TestDumpAndLoad.maxDiff
   
   