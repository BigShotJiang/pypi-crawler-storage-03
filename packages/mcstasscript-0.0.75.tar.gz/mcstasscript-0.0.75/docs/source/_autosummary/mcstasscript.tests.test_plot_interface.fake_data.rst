mcstasscript.tests.test\_plot\_interface.fake\_data
===================================================

.. currentmodule:: mcstasscript.tests.test_plot_interface

.. autofunction:: fake_data