mcstasscript.tests.test\_functions.set\_dummy\_McStasDataBinned\_1d
===================================================================

.. currentmodule:: mcstasscript.tests.test_functions

.. autofunction:: set_dummy_McStasDataBinned_1d