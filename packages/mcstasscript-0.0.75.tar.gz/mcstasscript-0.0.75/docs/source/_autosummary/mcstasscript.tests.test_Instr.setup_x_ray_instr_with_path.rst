mcstasscript.tests.test\_Instr.setup\_x\_ray\_instr\_with\_path
===============================================================

.. currentmodule:: mcstasscript.tests.test_Instr

.. autofunction:: setup_x_ray_instr_with_path