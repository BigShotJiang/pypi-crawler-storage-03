"""Tests for domain layer components."""
