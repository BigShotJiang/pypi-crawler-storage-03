"""Application layer result formatters for domain objects."""
