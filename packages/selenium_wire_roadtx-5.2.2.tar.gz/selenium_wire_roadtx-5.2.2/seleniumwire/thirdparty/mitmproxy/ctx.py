import seleniumwire.thirdparty.mitmproxy.log
import seleniumwire.thirdparty.mitmproxy.master
import seleniumwire.thirdparty.mitmproxy.options

log: "seleniumwire.thirdparty.mitmproxy.log.Log"
master: "seleniumwire.thirdparty.mitmproxy.master.Master"
options: "seleniumwire.thirdparty.mitmproxy.options.Options"
