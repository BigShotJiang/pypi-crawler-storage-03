from enum import Enum


class Pratique(Enum):
    THE_5_X5 = "5x5"
