from enum import Enum


class Code(Enum):
    BIT = "BIT"
    BT = "BT"
    SS = "SS"
