from enum import Enum


class PublicationInternet(Enum):
    AFFICHÉE = "Affichée"
    ASC = "ASC"
