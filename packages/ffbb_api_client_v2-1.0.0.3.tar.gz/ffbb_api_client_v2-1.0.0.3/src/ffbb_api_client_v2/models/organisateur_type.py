from enum import Enum


class OrganisateurType(Enum):
    C = "C"
    L = "L"
