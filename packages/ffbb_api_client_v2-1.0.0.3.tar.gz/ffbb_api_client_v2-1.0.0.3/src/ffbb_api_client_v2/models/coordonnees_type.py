from enum import Enum


class CoordonneesType(Enum):
    POINT = "Point"
