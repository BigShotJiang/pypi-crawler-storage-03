import sys
sys.path.append('C:/wadeTools/')