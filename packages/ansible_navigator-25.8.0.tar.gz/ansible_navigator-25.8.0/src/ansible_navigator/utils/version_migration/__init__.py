"""Perform migrations between major versions."""
