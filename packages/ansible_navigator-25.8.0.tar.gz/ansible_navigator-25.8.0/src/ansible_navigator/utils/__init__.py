"""General utilities use by many subsystems."""
