"""Ansible navigator setting schema file."""
