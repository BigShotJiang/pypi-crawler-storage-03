"""
This module contains project version information.

.. currentmodule:: databutton.version
.. moduleauthor:: Databutton <support@databutton.com>
"""

__version__ = "0.38.41"
