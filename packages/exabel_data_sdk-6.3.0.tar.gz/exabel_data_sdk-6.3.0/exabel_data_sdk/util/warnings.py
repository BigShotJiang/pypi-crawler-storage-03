class ExabelDeprecationWarning(FutureWarning):
    """Warning for deprecated features that will be removed or altered in the future."""
