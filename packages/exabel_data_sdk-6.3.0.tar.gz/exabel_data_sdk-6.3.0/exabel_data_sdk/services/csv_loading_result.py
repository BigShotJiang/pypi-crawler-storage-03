"""This file aliases an import for backwards compatibility after the result object was renamed."""

# pylint: disable=unused-import
from exabel_data_sdk.services.file_loading_result import FileLoadingResult as CsvLoadingResult
