"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'exabel/api/management/v1/service.proto')
_sym_db = _symbol_database.Default()
from .....protoc_gen_openapiv2.options import annotations_pb2 as protoc__gen__openapiv2_dot_options_dot_annotations__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n&exabel/api/management/v1/service.proto\x12\x18exabel.api.management.v1\x1a.protoc_gen_openapiv2/options/annotations.protoB\xaf\x03\n\x1ccom.exabel.api.management.v1B\x0cServiceProtoP\x01Z\x1cexabel.com/api/management/v1\x92A\xdf\x02\x12U\n\x15Exabel Management API"5\n\x06Exabel\x12\x17https://www.exabel.com/\x1a\x12support@exabel.com2\x051.0.0\x1a\x19management.api.exabel.com*\x01\x022\x10application/json:\x10application/jsonZR\n#\n\x07API key\x12\x18\x08\x02\x12\x07API key\x1a\tx-api-key \x02\n+\n\x06Bearer\x12!\x08\x02\x12\x0cAccess token\x1a\rauthorization \x02b\r\n\x0b\n\x07API key\x12\x00b\x0c\n\n\n\x06Bearer\x12\x00rS\n$More about the Exabel Management API\x12+https://help.exabel.com/docs/management-apib\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'exabel.api.management.v1.service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x1ccom.exabel.api.management.v1B\x0cServiceProtoP\x01Z\x1cexabel.com/api/management/v1\x92A\xdf\x02\x12U\n\x15Exabel Management API"5\n\x06Exabel\x12\x17https://www.exabel.com/\x1a\x12support@exabel.com2\x051.0.0\x1a\x19management.api.exabel.com*\x01\x022\x10application/json:\x10application/jsonZR\n#\n\x07API key\x12\x18\x08\x02\x12\x07API key\x1a\tx-api-key \x02\n+\n\x06Bearer\x12!\x08\x02\x12\x0cAccess token\x1a\rauthorization \x02b\r\n\x0b\n\x07API key\x12\x00b\x0c\n\n\n\x06Bearer\x12\x00rS\n$More about the Exabel Management API\x12+https://help.exabel.com/docs/management-api'