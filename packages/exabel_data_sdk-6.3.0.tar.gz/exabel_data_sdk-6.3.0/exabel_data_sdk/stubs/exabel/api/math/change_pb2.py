"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 5, 29, 0, '', 'exabel/api/math/change.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1cexabel/api/math/change.proto\x12\x0fexabel.api.math*<\n\x06Change\x12\x16\n\x12CHANGE_UNSPECIFIED\x10\x00\x12\x0c\n\x08RELATIVE\x10\x01\x12\x0c\n\x08ABSOLUTE\x10\x02B9\n\x13com.exabel.api.mathB\x0bChangeProtoP\x01Z\x13exabel.com/api/mathb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'exabel.api.math.change_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x13com.exabel.api.mathB\x0bChangeProtoP\x01Z\x13exabel.com/api/math'
    _globals['_CHANGE']._serialized_start = 49
    _globals['_CHANGE']._serialized_end = 109