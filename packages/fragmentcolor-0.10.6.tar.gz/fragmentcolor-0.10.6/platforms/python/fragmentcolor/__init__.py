from .fragmentcolor import *

__doc__ = fragmentcolor.__doc__
if hasattr(fragmentcolor, "__all__"):
    __all__ = fragmentcolor.__all__
