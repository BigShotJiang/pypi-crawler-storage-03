from .main import fact
from .main import cal
from .main import fib
from .main import add_or_even