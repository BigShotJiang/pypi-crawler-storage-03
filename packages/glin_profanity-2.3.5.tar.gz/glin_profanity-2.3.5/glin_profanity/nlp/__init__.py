"""NLP components for glin-profanity."""
