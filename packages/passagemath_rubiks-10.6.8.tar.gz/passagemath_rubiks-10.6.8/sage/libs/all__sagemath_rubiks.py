# sage_setup: distribution = sagemath-rubiks
