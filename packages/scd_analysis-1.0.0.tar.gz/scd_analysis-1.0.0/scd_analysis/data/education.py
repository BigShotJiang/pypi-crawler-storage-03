# Education Processing Functions
# Handles conversion of raw HFAUDD codes via SAS format files
# Author: Generated for SCD Analysis Pipeline
# Last updated: 2025-08-22

import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

import polars as pl


def parse_sas_format(
    sas_file_path: str, target_format: str = "auto"
) -> Optional[Dict[str, Union[str, int]]]:
    """
    Parse SAS format file to create HFAUDD mapping

    This function handles both text and numeric SAS format files.
    It can detect the format type and create appropriate mappings.

    Args:
        sas_file_path: Path to SAS format file
        target_format: Target format: "text", "numeric", "level_codes", or "auto"

    Returns:
        Dict mapping HFAUDD codes to categories or None if failed
    """
    print(f"Parsing SAS format file: {Path(sas_file_path).name}")

    try:
        # Read SAS format file
        with open(sas_file_path, "r", encoding="utf-8") as f:
            sas_lines = f.readlines()

        # Find format definition lines (skip header)
        format_lines = [
            line.strip() for line in sas_lines if re.match(r"^\d+=\'.*\'", line.strip())
        ]

        if not format_lines:
            print("Warning: No format definitions found in SAS file")
            return None

        # Parse each line to extract code and value
        parsed_data = []
        for line in format_lines:
            match = re.match(r"^(\d+)=\'([^\']+)\'", line)
            if match:
                parsed_data.append(
                    {
                        "hfaudd_raw": int(match.group(1)),
                        "category_text": match.group(2).strip(),
                    }
                )

        if not parsed_data:
            print("Warning: No valid format definitions parsed")
            return None

        # Auto-detect format or create specific mapping
        if target_format == "auto":
            # Check if we have text categories that suggest level mapping
            has_education_levels = any(
                re.search(
                    r"Korte|Mellemlange|Lange|videregående|Grundskole|Gymnasiale",
                    item["category_text"],
                    re.IGNORECASE,
                )
                for item in parsed_data
            )
            target_format = "level_codes" if has_education_levels else "text"

        # Create mapping based on target format
        mapping = {}

        if target_format == "level_codes":
            # Convert text categories to 2-digit codes
            for item in parsed_data:
                text = item["category_text"]

                if re.search(r"Grundskole|Danskundervisning", text, re.IGNORECASE):
                    level_code = 10  # Primary/Basic education
                elif re.search(r"Adgangsgivende|forberedende", text, re.IGNORECASE):
                    level_code = 15  # Preparatory
                elif re.search(r"Gymnasiale", text, re.IGNORECASE):
                    level_code = 20  # Upper secondary
                elif re.search(
                    r"Erhvervsfaglige|erhvervsuddannelser", text, re.IGNORECASE
                ):
                    level_code = 30  # Vocational
                elif re.search(r"Korte videregående|KVU", text, re.IGNORECASE):
                    level_code = 40  # Academy/Short tertiary
                elif re.search(r"Mellemlange videregående|MVU", text, re.IGNORECASE):
                    level_code = 50  # Professional bachelor
                elif re.search(r"Bacheloruddannelser", text, re.IGNORECASE):
                    level_code = 60  # Bachelor
                elif re.search(
                    r"Kandidatuddannelser|Lange videregående|LVU", text, re.IGNORECASE
                ):
                    level_code = 70  # Master
                elif re.search(r"Forskeruddannelser|PhD", text, re.IGNORECASE):
                    level_code = 80  # PhD
                elif re.search(r"Uoplyst|Ukendt", text, re.IGNORECASE):
                    level_code = 90  # Unknown/Missing
                else:
                    level_code = 90  # Default to unknown

                mapping[str(item["hfaudd_raw"])] = level_code

        elif target_format == "numeric":
            # Extract numeric codes from text
            for item in parsed_data:
                match = re.search(r"^\d+", item["category_text"])
                if match:
                    mapping[str(item["hfaudd_raw"])] = int(match.group(0))

        else:
            # Return text mapping
            for item in parsed_data:
                mapping[str(item["hfaudd_raw"])] = item["category_text"]

        print(f"Created mapping for {len(mapping)} HFAUDD codes")
        return mapping

    except Exception as e:
        print(f"Error parsing SAS format file: {e}")
        return None


def convert_hfaudd_raw(
    hfaudd_raw: List[int],
    sas_file_path: Optional[str] = None,
    mapping_cache: Optional[Dict[str, int]] = None,
) -> List[int]:
    """
    Convert raw HFAUDD codes to standardized 2-digit codes

    Args:
        hfaudd_raw: List of raw 4-digit HFAUDD codes
        sas_file_path: Path to SAS format file (optional, uses built-in logic if None)
        mapping_cache: Optional pre-computed mapping to avoid re-parsing SAS file

    Returns:
        List of 2-digit education level codes
    """
    # Use cached mapping if available
    if mapping_cache is not None:
        return [mapping_cache.get(str(code), 90) for code in hfaudd_raw]

    # Parse SAS file if provided
    if sas_file_path is not None and Path(sas_file_path).exists():
        mapping = parse_sas_format(sas_file_path, target_format="level_codes")
        if mapping is not None:
            return [mapping.get(str(code), 90) for code in hfaudd_raw]

    # Fallback: Built-in logic based on HFAUDD structure
    print("Using built-in HFAUDD conversion logic")

    converted = []
    for code in hfaudd_raw:
        if 1000 <= code <= 1299:
            converted.append(10)  # Primary education
        elif 1300 <= code <= 1999:
            converted.append(20)  # Upper secondary
        elif 2000 <= code <= 3999:
            converted.append(30)  # Vocational
        elif 4000 <= code <= 4999:
            converted.append(40)  # Short tertiary
        elif 5000 <= code <= 5999:
            converted.append(50)  # Medium tertiary
        elif 6000 <= code <= 6999:
            converted.append(60)  # Long tertiary bachelor
        elif 7000 <= code <= 7999:
            converted.append(70)  # Long tertiary master
        elif code >= 8000:
            converted.append(80)  # PhD
        else:
            converted.append(90)  # Unknown/Missing

    return converted


def categorize_hfaudd_education(
    hfaudd: Union[List[int], pl.Series],
    input_format: str = "auto",
    sas_file_path: Optional[str] = None,
) -> List[str]:
    """
    Categorize HFAUDD codes into education levels

    Handles both raw 4-digit codes and converted 2-digit codes

    Args:
        hfaudd: List or Series of HFAUDD codes (can be raw or converted)
        input_format: "raw" for 4-digit codes, "converted" for 2-digit codes, "auto" to detect
        sas_file_path: Optional path to SAS format file for raw code conversion

    Returns:
        List of education categories
    """
    if isinstance(hfaudd, pl.Series):
        hfaudd = hfaudd.drop_nulls().to_list()

    # Auto-detect format
    if input_format == "auto" and hfaudd:
        max_value = max(hfaudd)
        input_format = "raw" if max_value > 100 else "converted"
        print(f"Auto-detected input format: {input_format}")

    # Convert raw codes if necessary
    if input_format == "raw":
        hfaudd_2digit = convert_hfaudd_raw(hfaudd, sas_file_path=sas_file_path)
    else:
        hfaudd_2digit = hfaudd

    # Handle special cases that require raw codes
    middle_school_codes = {
        1021,
        1022,
        1023,
        1121,
        1122,
        1123,
        1423,
        1522,
        1523,
        1721,
        1722,
        1723,
    }

    # Categorize
    result = []
    for i, code_2digit in enumerate(hfaudd_2digit):
        original_code = hfaudd[i] if input_format == "raw" else None

        if code_2digit in [10, 15]:
            result.append("Short education")
        elif code_2digit in [20, 30, 35] or (
            input_format == "raw" and original_code in middle_school_codes
        ):
            result.append("Medium education")
        elif code_2digit in [40, 50, 60, 70, 80]:
            result.append("Long education")
        else:
            result.append("No completed or missing education")

    return result


def create_hfaudd_converter(sas_file_path: str) -> Callable[[List[int]], List[int]]:
    """
    Cached SAS format parser for performance

    Args:
        sas_file_path: Path to SAS format file

    Returns:
        Cached mapping function
    """
    # Parse once and cache
    mapping_cache = parse_sas_format(sas_file_path, target_format="level_codes")

    # Return converter function with cached mapping
    def converter(hfaudd_raw: List[int]) -> List[int]:
        return convert_hfaudd_raw(hfaudd_raw, mapping_cache=mapping_cache)

    return converter


def process_education(df: pl.DataFrame, config: Dict[str, Any]) -> pl.DataFrame:
    """
    Process education data (UDDF) using lazy evaluation

    Args:
        df: DataFrame with cohort data
        config: Configuration dict

    Returns:
        DataFrame with education variables
    """
    print("Processing education data...")

    # Create cached HFAUDD converter for performance (parse SAS file once)
    hfaudd_converter = None
    if Path(config["sas_format_file"]).exists():
        print("Creating cached HFAUDD converter from SAS format file...")
        hfaudd_converter = create_hfaudd_converter(config["sas_format_file"])
    else:
        print("SAS format file not found, will use built-in conversion logic")

    # Get unique parent IDs and date range for filtering
    parent_ids_mother = df["CPR_MODER"].drop_nulls().unique().to_list()
    parent_ids_father = df["CPR_FADER"].drop_nulls().unique().to_list()
    parent_ids = list(set(parent_ids_mother + parent_ids_father))

    min_date = df["first_diag_date"].min()
    max_date = df["first_diag_date"].max()

    # Lazy load UDDF data
    uddf_path = config["parquet_path"] / "uddf"
    uddf_lf = open_data_safe(uddf_path, format="dataset")

    if uddf_lf is None:
        raise RuntimeError(f"Failed to load UDDF data from {uddf_path}")

    uddf_filtered = (
        uddf_lf.filter(pl.col("PNR").is_in(parent_ids))
        .filter(
            pl.col("HF_VTIL") >= min_date
        )  # Education end date after earliest diagnosis
        .filter(
            pl.col("HF_VFRA") <= max_date
        )  # Education start date before latest diagnosis
        .select(["HFAUDD_isced", "HF_VFRA", "HF_VTIL", "PNR"])
        .collect()
    )

    # Helper function for consistent education categorization
    def categorize_education_smart(hfaudd_codes: List[Optional[int]]) -> List[str]:
        # Filter out None values
        valid_codes = [code for code in hfaudd_codes if code is not None]
        if not valid_codes:
            return ["No completed or missing education"] * len(hfaudd_codes)

        if hfaudd_converter is not None:
            # Use cached converter
            hfaudd_2digit = hfaudd_converter(valid_codes)
            return categorize_hfaudd_education(hfaudd_2digit, input_format="converted")
        else:
            # Use auto-detection
            return categorize_hfaudd_education(valid_codes, input_format="auto")

    # Process mother's education
    mother_edu = (
        uddf_filtered.rename({"PNR": "CPR_MODER", "HFAUDD_isced": "udd_moder"})
        .join(df.select(["CPR_MODER", "first_diag_date"]), on="CPR_MODER", how="inner")
        .filter(
            (pl.col("HF_VFRA") < pl.col("first_diag_date"))
            & (pl.col("HF_VTIL") >= pl.col("first_diag_date"))
        )
        .select(["CPR_MODER", "udd_moder"])
        .unique(subset=["CPR_MODER"], keep="first")
    )

    # Process father's education
    father_edu = (
        uddf_filtered.rename({"PNR": "CPR_FADER", "HFAUDD_isced": "udd_fader"})
        .join(df.select(["CPR_FADER", "first_diag_date"]), on="CPR_FADER", how="inner")
        .filter(
            (pl.col("HF_VFRA") < pl.col("first_diag_date"))
            & (pl.col("HF_VTIL") >= pl.col("first_diag_date"))
        )
        .select(["CPR_FADER", "udd_fader"])
        .unique(subset=["CPR_FADER"], keep="first")
    )

    # Join education data and apply categorization
    df_with_edu = df.join(mother_edu, on="CPR_MODER", how="left").join(
        father_edu, on="CPR_FADER", how="left"
    )

    # Apply education categorization
    mother_codes = df_with_edu["udd_moder"].to_list()
    father_codes = df_with_edu["udd_fader"].to_list()

    mother_categories = categorize_education_smart(mother_codes)
    father_categories = categorize_education_smart(father_codes)

    df_final = df_with_edu.with_columns(
        [
            pl.lit(mother_categories).alias("education_mother"),
            pl.lit(father_categories).alias("education_father"),
        ]
    ).drop(["udd_moder", "udd_fader"])

    print(f"Education processing complete. Records: {len(df_final)}")
    return df_final
