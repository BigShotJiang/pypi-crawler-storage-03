# SCD (Severe Chronic Disease) Diagnosis Flagging Logic
# Author: Refactored from consolidated script
# Last updated: 2025-08-22


import polars as pl


def flag_scd(tab: pl.LazyFrame, diag_col: str) -> pl.LazyFrame:
    """
    Flag Severe Chronic Disease entries based on ICD-10 diagnosis codes

    This function implements the complete SCD flagging logic for identifying
    severe chronic diseases in children based on ICD-10 codes.

    Args:
        tab: Polars LazyFrame with diagnosis codes
        diag_col: Column name containing diagnosis codes

    Returns:
        LazyFrame with SCD flag added (1 = SCD, 0 = not SCD)
    """

    return (
        tab.with_columns(
            [
                # Convert to uppercase and extract diagnosis parts
                pl.col(diag_col).str.to_uppercase().alias("code")
            ]
        )
        .with_columns(
            [
                pl.col("code").str.slice(1, 4).alias("diag4"),
                pl.col("code").str.slice(1, 3).alias("diag3"),
            ]
        )
        .with_columns(
            [
                # SCD flagging logic
                pl.when(
                    # Malignant neoplasms
                    (pl.col("diag3") >= "C00") & (pl.col("diag3") <= "C99")
                )
                .then(1)
                .when(
                    # Specific blood disorders
                    pl.col("diag4").str.contains(r"^D61[0389]")
                    | (pl.col("diag4") == "D762")
                    | pl.col("diag3").str.contains(r"^D8[012]")
                )
                .then(1)
                .when(
                    # Endocrine disorders
                    (pl.col("diag3") == "E10")  # Type 1 diabetes
                    | (pl.col("diag3") == "E25")  # Adrenogenital disorders
                    | pl.col("diag3").str.contains(r"^E7[012]")
                    | (pl.col("diag4") == "E730")
                    | (pl.col("diag3") >= "E74") & (pl.col("diag3") <= "E84")
                )
                .then(1)
                .when(
                    # Neurological conditions
                    (pl.col("diag3") == "G12")  # Spinal muscular atrophy
                    | pl.col("diag4").str.contains(r"^G31[089]")
                    | (pl.col("diag3") == "G37")
                    | (pl.col("diag3") == "G40")  # Epilepsy
                    | (pl.col("diag3") == "G60")  # Hereditary neuropathy
                    | (pl.col("diag4") == "G702")  # Congenital myasthenia
                    | pl.col("diag4").str.contains(r"^G71[0123]")
                    | (pl.col("diag4") == "G736")
                    | (pl.col("diag3") == "G80")  # Cerebral palsy
                    | pl.col("diag4").is_in(["G811", "G821", "G824"])
                    | (pl.col("diag3") == "G91")
                    | (pl.col("diag4") == "G941")
                )
                .then(1)
                .when(
                    # Cardiovascular conditions
                    (pl.col("diag3") == "I12")  # Hypertensive renal disease
                    | (pl.col("diag3") == "I27")  # Pulmonary heart disease
                    | (pl.col("diag3") >= "I30") & (pl.col("diag3") <= "I52")
                )
                .then(1)
                .when(
                    # Respiratory conditions
                    (pl.col("diag4") == "J448")  # COPD
                    | (pl.col("diag3") == "J84")  # Interstitial lung disease
                )
                .then(1)
                .when(
                    # Gastrointestinal conditions
                    (pl.col("diag3") == "K21")  # GERD
                    | pl.col("diag3").str.contains(r"^K5[01]")  # IBD
                    | pl.col("diag3").str.contains(r"^K7[01234567]")  # Liver diseases
                    | (pl.col("diag3") == "K90")  # Malabsorption
                )
                .then(1)
                .when(
                    # Connective tissue disorders
                    pl.col("diag3").str.contains(r"^M3[012345]")
                )
                .then(1)
                .when(
                    # Renal conditions
                    pl.col("diag3").str.contains(r"^N0[345]")
                    | (pl.col("diag3") == "N07")
                    | (pl.col("diag3") == "N13")  # Obstructive uropathy
                    | pl.col("diag3").str.contains(r"^N1[89]")
                    | pl.col("diag3").str.contains(r"^N2[567]")
                )
                .then(1)
                .when(
                    # Perinatal conditions
                    (pl.col("diag3") == "P27")  # Chronic respiratory disease
                    | (pl.col("diag3") == "P57")  # Kernicterus
                    | pl.col("diag4").str.contains(r"^P91[012]")
                    | (pl.col("diag4") >= "P941") & (pl.col("diag4") <= "P949")
                )
                .then(1)
                .when(
                    # Congenital malformations
                    pl.col("diag3").str.contains(r"^Q0[1234567]")  # CNS malformations
                    | pl.col("diag3").str.contains(
                        r"^Q2[0123456]"
                    )  # Circulatory malformations
                    | pl.col("diag3").str.contains(
                        r"^Q3[0123]"
                    )  # Respiratory malformations
                    | pl.col("diag3").str.contains(
                        r"^Q3[4567]"
                    )  # Other respiratory/cleft
                    | (pl.col("diag3") == "Q39")
                    | pl.col("diag3").str.contains(r"^Q4[01234]")
                    | pl.col("diag4").str.contains(r"^Q45[0123]")  # GI malformations
                    | pl.col("diag3").str.contains(
                        r"^Q6[01234]"
                    )  # Urinary malformations
                    | (pl.col("diag4") == "Q790")  # Diaphragmatic hernia
                    | pl.col("diag4").str.contains(
                        r"^Q79[23]"
                    )  # Exomphalos/gastroschisis
                    | (pl.col("diag4") == "Q860")  # Fetal alcohol syndrome
                    | (pl.col("diag3") == "Q87")  # Multiple malformation syndromes
                    | pl.col("diag3").str.contains(
                        r"^Q9[0123456789]"
                    )  # Other malformations
                )
                .then(1)
                .otherwise(0)
                .alias("scd")
            ]
        )
        .drop(["code", "diag4", "diag3"])
    )
