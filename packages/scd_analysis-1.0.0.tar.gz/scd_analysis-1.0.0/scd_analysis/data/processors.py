# Data Processing Functions for SCD Analysis Pipeline
# Author: Refactored from consolidated script
# Last updated: 2025-08-22

from pathlib import Path
from typing import Any, Dict

import polars as pl

from .scd_flagging import flag_scd
from ..utils import open_data_safe


def process_lpr_data(config: Dict[str, Any]) -> pl.DataFrame:
    """
    Process LPR (hospital) data using lazy evaluation

    Args:
        config: Configuration dict

    Returns:
        DataFrame with processed LPR data
    """
    print("Processing LPR data...")

    # Study years for filtering
    study_years = list(
        range(
            config["study_period"]["start_year"], config["study_period"]["end_year"] + 1
        )
    )

    # Lazy load admission data with heavy filtering optimization
    lpr_adm_path = config["parquet_path"] / "lpr_adm"

    # Create combined filter condition for optimal predicate pushdown
    filter_condition = (
        (pl.col("C_INDM") != 1)  # Remove ER visits (integer comparison before casting)
        & (pl.col("V_ALDER") < config["age_cutoff"])  # Only children < age_cutoff years
    )

    # Load and process individual parquet files to handle mixed schemas
    lpr_adm_path = Path(lpr_adm_path)
    parquet_files = list(lpr_adm_path.glob("*.parquet"))

    if not parquet_files:
        raise RuntimeError(f"No parquet files found in {lpr_adm_path}")

    lpr_adm_dfs = []
    wanted_cols = ["PNR", "RECNUM", "D_INDDTO", "C_INDM", "V_ALDER"]

    for parquet_file in parquet_files:
        try:
            df = (
                pl.scan_parquet(parquet_file)
                .filter(filter_condition)
                .with_columns(
                    [
                        pl.col("D_INDDTO").cast(pl.Utf8),
                        pl.col("PNR").cast(pl.Utf8),
                        pl.col("RECNUM").cast(pl.Utf8),
                        pl.col("C_INDM").cast(pl.Utf8),
                        pl.col("V_ALDER").cast(pl.Utf8),
                    ]
                )
                .select(
                    [
                        col
                        for col in wanted_cols
                        if col in pl.scan_parquet(parquet_file).collect_schema()
                    ]
                )
            )
            lpr_adm_dfs.append(df)
        except Exception as e:
            print(f"Warning: Failed to process {parquet_file}: {e}")
            continue

    if not lpr_adm_dfs:
        raise RuntimeError(f"Failed to load any LPR admission data from {lpr_adm_path}")

    lpr_adm_filtered = pl.concat(lpr_adm_dfs)

    # Lazy load diagnosis data with heavy filtering optimization
    lpr_diag_path = config["parquet_path"] / "lpr_diag"

    # Create filter for primary and secondary diagnoses
    diag_filter_condition = pl.col("C_DIAGTYPE").is_in(["A", "B"])

    # Load and process individual parquet files to handle mixed schemas
    lpr_diag_path = Path(lpr_diag_path)
    diag_parquet_files = list(lpr_diag_path.glob("*.parquet"))

    if not diag_parquet_files:
        raise RuntimeError(f"No parquet files found in {lpr_diag_path}")

    lpr_diag_dfs = []
    diag_wanted_cols = ["PNR", "RECNUM", "C_DIAG", "C_DIAGTYPE"]

    for parquet_file in diag_parquet_files:
        try:
            df = (
                pl.scan_parquet(parquet_file)
                .filter(diag_filter_condition)
                .with_columns(
                    [
                        pl.col("PNR").cast(pl.Utf8),
                        pl.col("RECNUM").cast(pl.Utf8),
                        pl.col("C_DIAG").cast(pl.Utf8),
                        pl.col("C_DIAGTYPE").cast(pl.Utf8),
                    ]
                )
                .select(
                    [
                        col
                        for col in diag_wanted_cols
                        if col in pl.scan_parquet(parquet_file).collect_schema()
                    ]
                )
            )
            lpr_diag_dfs.append(df)
        except Exception as e:
            print(f"Warning: Failed to process {parquet_file}: {e}")
            continue

    if not lpr_diag_dfs:
        raise RuntimeError(
            f"Failed to load any LPR diagnosis data from {lpr_diag_path}"
        )

    lpr_diag_filtered = pl.concat(lpr_diag_dfs)

    # Collect and apply SCD flagging
    lpr_diag_collected = lpr_diag_filtered.collect()
    lpr_diag_scd = flag_scd(lpr_diag_collected.lazy(), "C_DIAG").collect()
    lpr_diag_scd = lpr_diag_scd.filter(pl.col("scd") == 1)

    # Collect admission data only after filtering
    lpr_adm_final = lpr_adm_filtered.collect()

    # Merge admission and diagnosis data
    df_merged = lpr_adm_final.join(lpr_diag_scd, on="RECNUM", how="inner")

    # Find first diagnosis date for each person
    df_first_diag = (
        df_merged.with_columns(
            pl.col("D_INDDTO").min().over("PNR").alias("first_diag_date")
        )
        .sort(["D_INDDTO", "C_DIAGTYPE"])
        .unique(subset=["PNR"], keep="first")
    )

    print(f"LPR processing complete. Records: {len(df_first_diag)}")
    return df_first_diag


def process_mfr_data(df_lpr: pl.DataFrame, config: Dict[str, Any]) -> pl.DataFrame:
    """
    Process MFR (birth registry) data using lazy evaluation

    Args:
        df_lpr: DataFrame from LPR processing
        config: Configuration dict

    Returns:
        DataFrame with MFR data merged
    """
    print("Processing MFR data...")

    study_years = list(
        range(
            config["study_period"]["start_year"], config["study_period"]["end_year"] + 1
        )
    )

    # Lazy load MFR data with optimized filtering
    mfr_path = config["parquet_path"] / "mfr"

    # Create birth year filter condition
    mfr_filter_condition = (
        pl.col("FOEDSELSDATO").dt.year() >= config["study_period"]["start_year"]
    ) & (pl.col("FOEDSELSDATO").dt.year() <= config["study_period"]["end_year"])

    mfr_lf = open_data_safe(
        mfr_path,
        format="dataset",
        hive_partitioning=True,
        use_statistics=True,
        parallel="auto",  # Use auto for birth registry data
    )

    if mfr_lf is None:
        raise RuntimeError(f"Failed to load MFR data from {mfr_path}")

    # Apply filters and rename
    mfr_filtered = mfr_lf.filter(mfr_filter_condition).rename({"CPR_BARN": "PNR"})

    # Additional birth year partition filter if available
    schema = mfr_lf.schema
    if "birth_year" in schema:
        mfr_filtered = mfr_filtered.filter(pl.col("birth_year").is_in(study_years))

    # Collect filtered MFR data
    mfr_collected = mfr_filtered.collect()

    # Keep only Danish-born children with SCD
    df_mfr = df_lpr.join(mfr_collected, on="PNR", how="inner").unique(
        subset=["PNR"], keep="first"
    )

    print(f"MFR processing complete. Records: {len(df_mfr)}")
    return df_mfr


def process_vital_status(df: pl.DataFrame, config: Dict[str, Any]) -> pl.DataFrame:
    """
    Process DOD (death registry) and VNDS (migration) data using lazy evaluation

    Args:
        df: DataFrame with cohort data
        config: Configuration dict

    Returns:
        DataFrame with vital status information
    """
    print("Processing vital status data...")

    # Get list of PNRs to filter on for performance
    pnr_list = df["PNR"].to_list()

    # Lazy load death data
    dod_path = config["parquet_path"] / "dod"
    dod_lf = open_data_safe(dod_path, format="dataset")

    if dod_lf is not None:
        dod_filtered = (
            dod_lf.filter(pl.col("PNR").is_in(pnr_list))
            .collect()
            .unique(subset=["PNR"], keep="first")
        )
    else:
        dod_filtered = pl.DataFrame({"PNR": [], "DOEDSDATO": []})

    # Lazy load migration data
    vnds_path = config["parquet_path"] / "vnds"
    vnds_lf = open_data_safe(vnds_path, format="dataset")

    if vnds_lf is not None:
        vnds_filtered = (
            vnds_lf.filter(pl.col("PNR").is_in(pnr_list))
            .filter(pl.col("INDUD_KODE") == "U")  # Emigrations only
            .collect()
            .sort("HAEND_DATO")
            .unique(subset=["PNR"], keep="first")
            .select(["PNR", pl.col("HAEND_DATO").alias("emigration_date")])
        )
    else:
        vnds_filtered = pl.DataFrame({"PNR": [], "emigration_date": []})

    # Merge vital status data
    df_vital = (
        df.join(dod_filtered, on="PNR", how="left")
        .join(vnds_filtered, on="PNR", how="left")
        .with_columns([
            pl.col("first_diag_date").cast(pl.Date),
            pl.col("emigration_date").cast(pl.Date),
        ])
        .filter(
            pl.col("emigration_date").is_null()
            | (pl.col("first_diag_date") <= pl.col("emigration_date"))
        )
    )

    print(f"Vital status processing complete. Records: {len(df_vital)}")
    return df_vital


def calculate_area_indicators(
    df: pl.DataFrame, area_level: str = "KOM"
) -> pl.DataFrame:
    """
    Calculate area-level socioeconomic indicators (SEPLINE guidelines)

    This function calculates contextual area-level characteristics
    such as mean income, proportion of immigrants, and educational levels

    Args:
        df: DataFrame with individual-level data
        area_level: Area level for aggregation ("KOM", "REG", "Sogn")

    Returns:
        DataFrame with area-level indicators
    """
    print(f"Calculating area-level indicators at {area_level} level...")

    if area_level not in df.columns:
        print(f"Warning: Area level variable {area_level} not found in data")
        return df

    # Calculate area-level indicators
    area_indicators = (
        df.filter(pl.col(area_level).is_not_null())
        .group_by(area_level)
        .agg(
            [
                pl.len().alias("n_families"),
                # Mean/median disposable household income
                pl.col("mean_income_3yr").mean().alias("area_mean_income"),
                pl.col("mean_income_3yr").median().alias("area_median_income"),
                # Proportion of immigrants/descendants (non-Western)
                (
                    pl.col("ethnicity_mother_main")
                    == "C: Non-Western Immigrants/Descendants"
                )
                .mean()
                .alias("pct_nonwestern_immigrants")
                * 100,
                # Proportion with low education (mother)
                (pl.col("education_mother") == "Short education")
                .mean()
                .alias("pct_low_education_mother")
                * 100,
                # Proportion unemployed (mother)
                (pl.col("employment_mother_main") == "B: Temporarily unemployed")
                .mean()
                .alias("pct_unemployed_mother")
                * 100,
                # Proportion single parents
                (pl.col("cohabitation_status") == "Not Married/Living Alone")
                .mean()
                .alias("pct_single_parents")
                * 100,
            ]
        )
        .with_columns(
            [
                # Categorize areas by income
                pl.when(
                    pl.col("area_median_income")
                    <= pl.col("area_median_income").quantile(1 / 3)
                )
                .then("Low-income area")
                .when(
                    pl.col("area_median_income")
                    >= pl.col("area_median_income").quantile(2 / 3)
                )
                .then("High-income area")
                .otherwise("Medium-income area")
                .alias("area_income_tertile"),
                (pl.col("area_median_income").rank() / pl.len() * 5)
                .ceil()
                .cast(pl.Int32)
                .alias("area_income_quintile"),
            ]
        )
    )

    # Add area indicators back to individual data
    df_with_area = df.join(area_indicators, on=area_level, how="left")

    # Report summary
    print(f"Area-level indicators calculated for {len(area_indicators)} areas")
    quintile_counts = (
        area_indicators["area_income_quintile"]
        .value_counts()
        .sort("area_income_quintile")
    )
    print("Income quintile distribution:")
    print(quintile_counts)

    return df_with_area
