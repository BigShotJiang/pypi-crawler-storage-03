# Data Processing Package
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Data processing modules for SCD Analysis Pipeline.

This package provides:
- Core data processors (LPR, MFR, vital status)
- Education processing (UDDF)
- Employment processing (AKM)
- Income processing (FAIK)
- SCD diagnosis flagging
- Data quality validation

Example usage:
    from scd_analysis.data import process_lpr_data, process_education
    
    config = get_default_config()
    df_lpr = process_lpr_data(config)
    df_final = process_education(df_lpr, config)
"""

from .processors import (
    process_lpr_data,
    process_mfr_data,
    process_vital_status,
    calculate_area_indicators,
)
from .education import process_education
from .employment import process_employment
from .income import process_income
from .scd_flagging import flag_scd_diagnoses

__all__ = [
    # Core processors
    "process_lpr_data",
    "process_mfr_data", 
    "process_vital_status",
    "calculate_area_indicators",
    
    # Specialized processors
    "process_education",
    "process_employment", 
    "process_income",
    
    # SCD flagging
    "flag_scd_diagnoses",
]