# Income Data Processing Functions
# Author: Tobias Kragholm
# Last updated: 2025-08-22

from typing import Any, Dict

import polars as pl

from ..utils import open_data_safe


def process_income(df: pl.DataFrame, config: Dict[str, Any]) -> pl.DataFrame:
    """
    Process income data (FAIK) using lazy evaluation and SEPLINE guidelines

    Args:
        df: DataFrame with cohort data
        config: Configuration dict

    Returns:
        DataFrame with income variables
    """
    print("Processing income data following SEPLINE guidelines...")

    # Get unique family IDs and calculate 3-year window preceding diagnosis
    family_ids = df["FAMILIE_ID"].drop_nulls().unique().to_list()
    diag_years = df["first_diag_date"].dt.year().unique().to_list()

    # Use 3 years preceding diagnosis (SEPLINE recommendation)
    all_relevant_years = []
    for year in diag_years:
        all_relevant_years.extend([year - 3, year - 2, year - 1])
    all_relevant_years = list(set(all_relevant_years))

    print(
        f"Using 3-year income window preceding diagnosis years: {min(all_relevant_years)}-{max(all_relevant_years)}"
    )

    # Lazy load FAIK data for extended time window
    faik_path = config["parquet_path"] / "faik"
    faik_lf = open_data_safe(faik_path, format="dataset")

    if faik_lf is None:
        raise RuntimeError(f"Failed to load FAIK data from {faik_path}")

    # Get all data for 3-year windows
    schema = faik_lf.schema
    year_col = "year" if "year" in schema else "Year"

    faik_all_years = (
        faik_lf.filter(pl.col(year_col).is_in(all_relevant_years))
        .select(["FAMAEKVIVADISP_13", "FAMILIE_ID", year_col])
        .collect()
        .rename({year_col: "Year"})
    )

    # Calculate 3-year mean income and apply SEPLINE categorization
    faik_cohort_means = calculate_3year_income(df, faik_all_years)
    population_quintiles = calculate_income_quintiles(faik_cohort_means)
    df_income = apply_income_categories(df, faik_cohort_means, population_quintiles)

    # Report data quality
    report_income_quality(df_income)

    print(f"Income processing complete. Records: {len(df_income)}")
    return df_income


def calculate_3year_income(
    df: pl.DataFrame, faik_all_years: pl.DataFrame
) -> pl.DataFrame:
    """
    Calculate 3-year mean income for each family (SEPLINE guidelines)

    Args:
        df: DataFrame with diagnosis dates
        faik_all_years: Income data for all relevant years

    Returns:
        DataFrame with 3-year mean income
    """
    print("Calculating 3-year mean income for cohort families...")

    # Create 3-year window for each family
    df_years = df.select(["FAMILIE_ID", "first_diag_date"]).with_columns(
        [
            (pl.col("first_diag_date").dt.year() - 1).alias("year_minus_1"),
            (pl.col("first_diag_date").dt.year() - 2).alias("year_minus_2"),
            (pl.col("first_diag_date").dt.year() - 3).alias("year_minus_3"),
        ]
    )

    # Join with income data for each year
    income_y1 = faik_all_years.rename(
        {"Year": "year_minus_1", "FAMAEKVIVADISP_13": "income_y1"}
    )
    income_y2 = faik_all_years.rename(
        {"Year": "year_minus_2", "FAMAEKVIVADISP_13": "income_y2"}
    )
    income_y3 = faik_all_years.rename(
        {"Year": "year_minus_3", "FAMAEKVIVADISP_13": "income_y3"}
    )

    result = (
        df_years.join(income_y1, on=["FAMILIE_ID", "year_minus_1"], how="left")
        .join(income_y2, on=["FAMILIE_ID", "year_minus_2"], how="left")
        .join(income_y3, on=["FAMILIE_ID", "year_minus_3"], how="left")
        .with_columns(
            [
                # Count available years
                (
                    pl.col("income_y1").is_not_null().cast(pl.Int32)
                    + pl.col("income_y2").is_not_null().cast(pl.Int32)
                    + pl.col("income_y3").is_not_null().cast(pl.Int32)
                ).alias("available_years"),
                # Calculate mean income with SEPLINE missing data handling
                pl.when(
                    (
                        pl.col("income_y1").is_not_null()
                        | pl.col("income_y2").is_not_null()
                        | pl.col("income_y3").is_not_null()
                    )
                )
                .then(
                    pl.concat_list(["income_y1", "income_y2", "income_y3"]).list.mean()
                )
                .otherwise(None)
                .alias("mean_income_3yr"),
                # Income data quality
                pl.when(pl.col("available_years") == 3)
                .then("Complete (3 years)")
                .when(pl.col("available_years") == 2)
                .then("Good (2 years)")
                .when(pl.col("available_years") == 1)
                .then("Limited (1 year)")
                .otherwise("Missing")
                .alias("income_data_quality"),
            ]
        )
        .select(
            ["FAMILIE_ID", "mean_income_3yr", "income_data_quality", "available_years"]
        )
    )

    return result


def calculate_income_quintiles(faik_cohort_means: pl.DataFrame) -> Dict[str, float]:
    """
    Calculate population-based income quintiles (SEPLINE guidelines)

    Args:
        faik_cohort_means: DataFrame with mean income

    Returns:
        Dict with quintile thresholds
    """
    print("Calculating population-based income quintiles...")

    valid_incomes = faik_cohort_means.filter(
        pl.col("mean_income_3yr").is_not_null() & (pl.col("mean_income_3yr") >= 0)
    )["mean_income_3yr"]

    return {
        "q1": valid_incomes.quantile(0.2),
        "q2": valid_incomes.quantile(0.4),
        "q3": valid_incomes.quantile(0.6),
        "q4": valid_incomes.quantile(0.8),
        "poverty_threshold": valid_incomes.quantile(0.5) * 0.5,  # 50% of median
    }


def apply_income_categories(
    df: pl.DataFrame,
    faik_cohort_means: pl.DataFrame,
    population_quintiles: Dict[str, float],
) -> pl.DataFrame:
    """
    Apply SEPLINE income categorization

    Args:
        df: Original DataFrame
        faik_cohort_means: Income means data
        population_quintiles: Quintile thresholds

    Returns:
        DataFrame with income categories
    """
    return (
        df.join(faik_cohort_means, on="FAMILIE_ID", how="left")
        .with_columns(
            [
                # Handle negative income (SEPLINE guideline)
                (pl.col("mean_income_3yr") < 0).alias("income_negative"),
                pl.when(pl.col("mean_income_3yr") < 0)
                .then(None)
                .otherwise(pl.col("mean_income_3yr"))
                .alias("income_for_analysis"),
                # SEPLINE income quintiles (1=low, 5=high)
                pl.when(pl.col("income_for_analysis").is_null())
                .then("Missing/Negative")
                .when(pl.col("income_for_analysis") <= population_quintiles["q1"])
                .then("Q1: Low income")
                .when(pl.col("income_for_analysis") <= population_quintiles["q2"])
                .then("Q2: Lower-middle income")
                .when(pl.col("income_for_analysis") <= population_quintiles["q3"])
                .then("Q3: Middle income")
                .when(pl.col("income_for_analysis") <= population_quintiles["q4"])
                .then("Q4: Upper-middle income")
                .otherwise("Q5: High income")
                .alias("income_quintile"),
                # SEPLINE 3-category version (low/medium/high)
                pl.when(pl.col("income_for_analysis").is_null())
                .then("Missing/Negative")
                .when(pl.col("income_for_analysis") <= population_quintiles["q1"])
                .then("Low income")
                .when(pl.col("income_for_analysis") > population_quintiles["q4"])
                .then("High income")
                .otherwise("Medium income")
                .alias("income_category"),
                # Poverty indicator (relative poverty threshold)
                pl.when(pl.col("income_for_analysis").is_null())
                .then(None)
                .when(
                    pl.col("income_for_analysis")
                    < population_quintiles["poverty_threshold"]
                )
                .then(True)
                .otherwise(False)
                .alias("below_poverty"),
                # Legacy tertile for backwards compatibility
                pl.when(pl.col("income_for_analysis").is_null())
                .then("missing")
                .when(pl.col("income_for_analysis") <= population_quintiles["q2"])
                .then("1")
                .when(pl.col("income_for_analysis") <= population_quintiles["q4"])
                .then("2")
                .otherwise("3")
                .alias("income_tertile"),
            ]
        )
        .with_columns(
            [
                # Convert to categorical
                pl.col("income_quintile").cast(pl.Categorical(ordering="lexical")),
                pl.col("income_category").cast(pl.Categorical(ordering="lexical")),
            ]
        )
    )


def report_income_quality(df_income: pl.DataFrame) -> None:
    """
    Report income data quality summary

    Args:
        df_income: DataFrame with income data
    """
    # Report data quality (SEPLINE recommendation)
    quality_summary = (
        df_income.group_by("income_data_quality")
        .agg(pl.len().alias("families"))
        .with_columns(
            (pl.col("families") / pl.col("families").sum() * 100).round(1).alias("pct")
        )
        .sort("income_data_quality")
    )

    print("Income data quality summary:")
    print(quality_summary)

    negative_count = df_income["income_negative"].sum()
    if negative_count > 0:
        print(
            f"Warning: {negative_count} families have negative mean income (excluded from quintiles)"
        )
