# Employment Data Processing Functions
# Author: Tobias Kragholm
# Last updated: 2025-08-22

from typing import Any, Dict

import polars as pl

from ..utils import open_data_safe


def process_employment(df: pl.DataFrame, config: Dict[str, Any]) -> pl.DataFrame:
    """
    Process employment data (AKM) using lazy evaluation

    Args:
        df: DataFrame with cohort data
        config: Configuration dict

    Returns:
        DataFrame with employment variables
    """
    print("Processing employment data...")

    # Get unique parent IDs and relevant years
    parent_ids_mother = df["CPR_MODER"].drop_nulls().unique().to_list()
    parent_ids_father = df["CPR_FADER"].drop_nulls().unique().to_list()
    parent_ids = list(set(parent_ids_mother + parent_ids_father))

    relevant_years = (df["first_diag_date"].dt.year() - 1).unique().to_list()

    # Lazy load AKM data
    akm_path = config["parquet_path"] / "akm"
    akm_lf = open_data_safe(akm_path, format="dataset")

    if akm_lf is None:
        raise RuntimeError(f"Failed to load AKM data from {akm_path}")

    # Filter and collect AKM data
    schema = akm_lf.schema
    year_col = "year" if "year" in schema else "Year"

    akm_filtered = (
        akm_lf.filter(pl.col(year_col).is_in(relevant_years))
        .filter(pl.col("PNR").is_in(parent_ids))
        .select(["SOCIO13", "PNR", year_col])
        .collect()
        .rename({year_col: "Year"})
    )

    # Join with employment data and add categories
    df_employment = (
        df.join(
            akm_filtered.rename({"PNR": "CPR_MODER", "SOCIO13": "SOCIO13_MODER"}),
            on="CPR_MODER",
            how="left",
        )
        .filter(
            (pl.col("Year") == (pl.col("first_diag_date").dt.year() - 1))
            | pl.col("Year").is_null()
        )
        .drop("Year")
        .join(
            akm_filtered.rename({"PNR": "CPR_FADER", "SOCIO13": "SOCIO13_FADER"}),
            on="CPR_FADER",
            how="left",
        )
        .filter(
            (pl.col("Year") == (pl.col("first_diag_date").dt.year() - 1))
            | pl.col("Year").is_null()
        )
        .drop("Year")
        .pipe(add_employment_categories)
        .pipe(convert_employment_factors)
    )

    print(f"Employment processing complete. Records: {len(df_employment)}")
    return df_employment


def add_employment_categories(df: pl.DataFrame) -> pl.DataFrame:
    """
    Add employment categories based on SOCIO13 codes

    Args:
        df: DataFrame with SOCIO13 codes

    Returns:
        DataFrame with employment categories
    """
    return df.with_columns(
        [
            # Main employment categories (A, B, C, D, Missing) for mother
            pl.when(
                pl.col("SOCIO13_MODER").is_in(
                    [110, 111, 112, 113, 114, 120, 131, 132, 133, 134, 135, 139, 310]
                )
            )
            .then("A: Working")
            .when(pl.col("SOCIO13_MODER").is_in([210, 410]))
            .then("B: Temporarily unemployed")
            .when(pl.col("SOCIO13_MODER").is_in([330, 220, 321]))
            .then("C: Outside workforce")
            .when(pl.col("SOCIO13_MODER").is_in([322, 323]))
            .then("D: Retired")
            .otherwise("Missing/other")
            .alias("employment_mother_main"),
            # Detailed employment subcategories for mother
            pl.when(pl.col("SOCIO13_MODER").is_in([110, 111, 112, 113, 114, 120]))
            .then("A1.1: Self-employed")
            .when(pl.col("SOCIO13_MODER").is_in([131, 132]))
            .then("A1.2: Manager or high-level employee")
            .when(pl.col("SOCIO13_MODER").is_in([133, 134, 135, 139]))
            .then("A1.3: Employee")
            .when(pl.col("SOCIO13_MODER") == 310)
            .then("A2: Student")
            .when(pl.col("SOCIO13_MODER").is_in([210, 410]))
            .then("B1: Unemployed")
            .when(pl.col("SOCIO13_MODER") == 330)
            .then("C1: Social security")
            .when(pl.col("SOCIO13_MODER") == 220)
            .then("C2: Sick Leave / other leave")
            .when(pl.col("SOCIO13_MODER") == 321)
            .then("C3: Disability pension")
            .when(pl.col("SOCIO13_MODER") == 323)
            .then("D1.1: Post-employment pension")
            .when(pl.col("SOCIO13_MODER") == 322)
            .then("D1.2: Age retirement pension")
            .otherwise("Missing/other")
            .alias("employment_mother_detailed"),
            # Legacy simplified categories for mother
            pl.when(
                pl.col("SOCIO13_MODER").is_in(
                    [110, 111, 112, 113, 114, 120, 131, 132, 133, 134, 135, 139]
                )
            )
            .then("employed")
            .when(pl.col("SOCIO13_MODER") == 310)
            .then("students")
            .when(pl.col("SOCIO13_MODER").is_in([210, 410]))
            .then("unemployed")
            .when(pl.col("SOCIO13_MODER").is_in([330, 220, 321, 322, 323]))
            .then("outside_workforce")
            .otherwise("missing")
            .alias("employment_mother"),
            # Father's employment categories (same logic)
            pl.when(
                pl.col("SOCIO13_FADER").is_in(
                    [110, 111, 112, 113, 114, 120, 131, 132, 133, 134, 135, 139, 310]
                )
            )
            .then("A: Working")
            .when(pl.col("SOCIO13_FADER").is_in([210, 410]))
            .then("B: Temporarily unemployed")
            .when(pl.col("SOCIO13_FADER").is_in([330, 220, 321]))
            .then("C: Outside workforce")
            .when(pl.col("SOCIO13_FADER").is_in([322, 323]))
            .then("D: Retired")
            .otherwise("Missing/other")
            .alias("employment_father_main"),
            # Father detailed categories
            pl.when(pl.col("SOCIO13_FADER").is_in([110, 111, 112, 113, 114, 120]))
            .then("A1.1: Self-employed")
            .when(pl.col("SOCIO13_FADER").is_in([131, 132]))
            .then("A1.2: Manager or high-level employee")
            .when(pl.col("SOCIO13_FADER").is_in([133, 134, 135, 139]))
            .then("A1.3: Employee")
            .when(pl.col("SOCIO13_FADER") == 310)
            .then("A2: Student")
            .when(pl.col("SOCIO13_FADER").is_in([210, 410]))
            .then("B1: Unemployed")
            .when(pl.col("SOCIO13_FADER") == 330)
            .then("C1: Social security")
            .when(pl.col("SOCIO13_FADER") == 220)
            .then("C2: Sick Leave / other leave")
            .when(pl.col("SOCIO13_FADER") == 321)
            .then("C3: Disability pension")
            .when(pl.col("SOCIO13_FADER") == 323)
            .then("D1.1: Post-employment pension")
            .when(pl.col("SOCIO13_FADER") == 322)
            .then("D1.2: Age retirement pension")
            .otherwise("Missing/other")
            .alias("employment_father_detailed"),
            # Legacy simplified categories for father
            pl.when(
                pl.col("SOCIO13_FADER").is_in(
                    [110, 111, 112, 113, 114, 120, 131, 132, 133, 134, 135, 139]
                )
            )
            .then("employed")
            .when(pl.col("SOCIO13_FADER") == 310)
            .then("students")
            .when(pl.col("SOCIO13_FADER").is_in([210, 410]))
            .then("unemployed")
            .when(pl.col("SOCIO13_FADER").is_in([330, 220, 321, 322, 323]))
            .then("outside_workforce")
            .otherwise("missing")
            .alias("employment_father"),
        ]
    )


def convert_employment_factors(df: pl.DataFrame) -> pl.DataFrame:
    """
    Convert employment categories to categorical with ordered levels

    Args:
        df: DataFrame with employment categories

    Returns:
        DataFrame with employment as categorical
    """
    return df.with_columns(
        [
            pl.col("employment_mother_main").cast(pl.Categorical(ordering="lexical")),
            pl.col("employment_father_main").cast(pl.Categorical(ordering="lexical")),
        ]
    )


