# Socioeconomic and Geographic Categorization
# Author: Tobias Kragholm
# Last updated: 2025-08-25

import polars as pl

from .constants import (
    CAPITAL_CITIES,
    LARGE_CITIES,
    LARGE_CITIES_STORHED,
    MARRIED_COHABITING_CODES,
    MEDIUM_CITIES,
    METROPOLITAN_AREAS,
    PROVINCIAL_TOWNS,
    REGION_CODES,
    RURAL_AREAS,
    RURAL_CODES,
    SINGLE_LIVING_ALONE_CODES,
    SMALL_CITIES,
    STORHED_DETAILED,
    URBAN_CODES,
)


class SocioeconomicCategorizer:
    """Handles socioeconomic categorization based on BEF data"""

    @staticmethod
    def add_socioeconomic_categories(df_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Add socioeconomic categories based on BEF data"""
        return df_lf.with_columns(
            [
                # SEPLINE cohabitation categorization based on Familie_type
                pl.when(pl.col("FAMILIE_TYPE").is_in(MARRIED_COHABITING_CODES))
                .then("Married/Cohabiting")
                .when(pl.col("FAMILIE_TYPE").is_in(SINGLE_LIVING_ALONE_CODES))
                .then("Not Married/Living Alone")
                .otherwise("Missing")
                .alias("cohabitation_status"),
                # Legacy family type for backwards compatibility
                pl.when(pl.col("FAMILIE_TYPE").is_in(SINGLE_LIVING_ALONE_CODES))
                .then("single")
                .when(pl.col("FAMILIE_TYPE").is_in(MARRIED_COHABITING_CODES))
                .then("co-living")
                .otherwise("missing")
                .alias("family_type"),
                # Number of children in household
                pl.when(pl.col("ANTBOERNH") == 1)
                .then("1 child")
                .when(pl.col("ANTBOERNH") == 2)
                .then("2 children")
                .when(pl.col("ANTBOERNH") >= 3)
                .then("3+ children")
                .when(pl.col("ANTBOERNH") == 0)
                .then("0 children")
                .otherwise("Missing")
                .alias("number_children"),
                # SEPLINE detailed ethnicity categorization for child (A1, A2, B1, B2, C1, C2)
                pl.when(
                    (pl.col("OPR_LAND_CHILD") == 1)
                    & (pl.col("MOR_OPR_LAND") == 1)
                    & (pl.col("FAR_OPR_LAND") == 1)
                )
                .then("A1: Danish")
                .when(
                    (pl.col("OPR_LAND_CHILD") == 1)
                    & ((pl.col("MOR_OPR_LAND") != 1) | (pl.col("FAR_OPR_LAND") != 1))
                )
                .then("A2: Mixed Background")
                .when((pl.col("OPR_LAND_CHILD") == 2) & (pl.col("IE_TYPE_CHILD") == 2))
                .then("B1: Western Immigrant")
                .when((pl.col("OPR_LAND_CHILD") == 2) & (pl.col("IE_TYPE_CHILD") == 3))
                .then("B2: Western Descendant")
                .when((pl.col("OPR_LAND_CHILD") == 3) & (pl.col("IE_TYPE_CHILD") == 2))
                .then("C1: Non-Western Immigrant")
                .when((pl.col("OPR_LAND_CHILD") == 3) & (pl.col("IE_TYPE_CHILD") == 3))
                .then("C2: Non-Western Descendant")
                .otherwise("Missing/Other")
                .alias("ethnicity_mother_detailed"),
                # SEPLINE main ethnicity categories for mother
                pl.when(pl.col("ethnicity_mother_detailed").str.starts_with("A"))
                .then("A: Danish Origin")
                .when(pl.col("ethnicity_mother_detailed").str.starts_with("B"))
                .then("B: Western Immigrants/Descendants")
                .when(pl.col("ethnicity_mother_detailed").str.starts_with("C"))
                .then("C: Non-Western Immigrants/Descendants")
                .otherwise("Missing/Other")
                .alias("ethnicity_mother_main"),
                # Legacy simplified ethnicity (backwards compatibility)
                pl.when((pl.col("MOR_OPR_LAND") == 1) & (pl.col("FAR_OPR_LAND") == 1))
                .then("Danish/Danish")
                .when((pl.col("MOR_OPR_LAND") != 1) & (pl.col("FAR_OPR_LAND") != 1))
                .then("Non-Danish/Non-Danish")
                .when(
                    ((pl.col("MOR_OPR_LAND") == 1) & (pl.col("FAR_OPR_LAND") != 1))
                    | ((pl.col("MOR_OPR_LAND") != 1) & (pl.col("FAR_OPR_LAND") == 1))
                )
                .then("Mixed (Danish/Non-Danish)")
                .otherwise("Missing")
                .alias("ethnicity"),
            ]
        )


class AreaCategorizer:
    """Handles geographic and area-based categorization"""

    @staticmethod
    def add_area_characteristics(df_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Add area-level characteristics (region, municipality, urbanization)"""
        df_with_region = AreaCategorizer._add_region_categories(df_lf)
        df_with_municipality = AreaCategorizer._add_municipality_categories(
            df_with_region
        )
        df_with_urbanization = AreaCategorizer._add_urbanization_categories(
            df_with_municipality
        )

        return df_with_urbanization

    @staticmethod
    def _add_region_categories(df_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Add Danish region categorization"""
        region_when_clauses = []
        for code, name in REGION_CODES.items():
            region_when_clauses.append(pl.when(pl.col("REG") == code).then(name))

        # Chain the when clauses together
        region_expr = region_when_clauses[0]
        for clause in region_when_clauses[1:]:
            region_expr = region_expr.when(clause.predicate).then(clause.value)
        region_expr = region_expr.otherwise("Missing/Other").alias("region")

        return df_lf.with_columns([region_expr])

    @staticmethod
    def _add_municipality_categories(df_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Add municipality-level urbanization categories"""
        return df_lf.with_columns(
            [
                pl.when(pl.col("KOM").is_in(CAPITAL_CITIES))
                .then("Capital city municipality")
                .when(pl.col("KOM").is_in(LARGE_CITIES))
                .then("Large city municipality")
                .when(pl.col("KOM").is_in(PROVINCIAL_TOWNS))
                .then("Provincial town municipality")
                .otherwise("Missing/Other")
                .alias("municipality_urbanization")
            ]
        )

    @staticmethod
    def _add_urbanization_categories(df_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Add population density and urbanization categories"""
        # Build detailed population density mapping
        storhed_when_clauses = []
        for code, description in STORHED_DETAILED.items():
            storhed_when_clauses.append(
                pl.when(pl.col("STORHED") == code).then(description)
            )

        # Chain the when clauses for detailed categorization
        detailed_expr = storhed_when_clauses[0]
        for clause in storhed_when_clauses[1:]:
            detailed_expr = detailed_expr.when(clause.predicate).then(clause.value)
        detailed_expr = detailed_expr.otherwise("Missing/Other").alias(
            "population_density_detailed"
        )

        return df_lf.with_columns(
            [
                detailed_expr,
                # Simplified urbanization categories
                pl.when(pl.col("STORHED").is_in(METROPOLITAN_AREAS))
                .then("Metropolitan areas")
                .when(pl.col("STORHED").is_in(LARGE_CITIES_STORHED))
                .then("Large cities")
                .when(pl.col("STORHED").is_in(MEDIUM_CITIES))
                .then("Medium cities")
                .when(pl.col("STORHED").is_in(SMALL_CITIES))
                .then("Small cities")
                .when(pl.col("STORHED").is_in(RURAL_AREAS))
                .then("Rural areas")
                .when(pl.col("STORHED") == 0)
                .then("No registered address")
                .otherwise("Missing/Other")
                .alias("urbanization_simple"),
                # Urban-rural binary
                pl.when(pl.col("STORHED").is_in(URBAN_CODES))
                .then("Urban")
                .when(pl.col("STORHED").is_in(RURAL_CODES))
                .then("Rural")
                .when(pl.col("STORHED") == 0)
                .then("No registered address")
                .otherwise("Missing/Other")
                .alias("urban_rural"),
            ]
        )


class FactorConverter:
    """Handles conversion of variables to categorical factors"""

    @staticmethod
    def convert_to_factors(df_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Convert socioeconomic variables to categorical for analysis"""
        # Get schema to check available columns without breaking lazy evaluation
        schema = df_lf.collect_schema()

        categorical_columns = []
        for col in [
            "cohabitation_status",
            "number_children",
            "ethnicity_mother_detailed",
            "ethnicity_mother_main",
            "ethnicity",
            "region",
            "municipality_urbanization",
            "urbanization_simple",
            "urban_rural",
            "family_type",  # Legacy column
            "population_density_detailed",
        ]:
            if col in schema:
                categorical_columns.append(
                    pl.col(col).cast(pl.Categorical(ordering="lexical"))
                )

        if categorical_columns:
            return df_lf.with_columns(categorical_columns)
        else:
            return df_lf
