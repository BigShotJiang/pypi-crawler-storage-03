# Data Joining Logic for Cohort and BEF Data
# Author: Tobias Kragholm  
# Last updated: 2025-08-25

import polars as pl

from .data_loader import BEFDataLoader


class DataJoiner:
    """Handles joining cohort data with BEF data for children and parents"""
    
    def __init__(self, data_loader: BEFDataLoader):
        self.data_loader = data_loader
    
    def join_bef_data(self, df: pl.DataFrame, bef_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Join cohort data with BEF data for children and parents using lazy evaluation"""
        # Convert main dataframe to lazy for efficient joining
        df_lazy = df.lazy()
        
        # Normalize birth date columns in BEF data
        bef_normalized = self.data_loader.normalize_birth_date_columns(bef_lf)
        
        # Get schema to check available columns
        bef_schema = bef_normalized.collect_schema()
        
        # Join child, mother, and father data sequentially
        df_with_child = self._join_child_data(df_lazy, bef_normalized, bef_schema)
        df_with_mother = self._join_mother_data(df_with_child, bef_normalized, bef_schema)
        df_with_father = self._join_father_data(df_with_mother, bef_normalized, bef_schema)
        
        return df_with_father
    
    def _join_child_data(self, df_lazy: pl.LazyFrame, bef_normalized: pl.LazyFrame, 
                        bef_schema: dict) -> pl.LazyFrame:
        """Join child BEF data"""
        # Prepare child data columns
        child_cols = ["PNR", "Year"]
        child_renames = {}
        if "OPR_LAND" in bef_schema:
            child_cols.append("OPR_LAND")
            child_renames["OPR_LAND"] = "OPR_LAND_CHILD"
        if "IE_TYPE" in bef_schema:
            child_cols.append("IE_TYPE")
            child_renames["IE_TYPE"] = "IE_TYPE_CHILD"
        
        # Join child BEF data
        child_bef = bef_normalized.select(child_cols).rename(child_renames)
        
        return (
            df_lazy.join(child_bef, on="PNR", how="left")
            .filter(
                (
                    pl.col("Year")
                    == (pl.col("first_diag_date").cast(pl.Date).dt.year() - 1)
                )
                | pl.col("Year").is_null()
            )
            .drop("Year")
        )
    
    def _join_mother_data(self, df_with_child: pl.LazyFrame, bef_normalized: pl.LazyFrame,
                         bef_schema: dict) -> pl.LazyFrame:
        """Join mother BEF data"""
        # Prepare mother data columns
        mother_cols = ["PNR", "Year"]
        mother_renames = {"PNR": "CPR_MODER"}
        
        for col, new_name in [
            ("OPR_LAND", "MOR_OPR_LAND"),
            ("FOEDSELSDATO", "MODER_FOEDSELSDATO"),
            ("ANTBOERNH", "ANTBOERNH_MOTHER"),
        ]:
            if col in bef_schema:
                mother_cols.append(col)
                mother_renames[col] = new_name
        
        # Add location columns for mothers
        for col in ["REG", "KOM", "STORHED", "FAMILIE_TYPE"]:
            if col in bef_schema:
                mother_cols.append(col)
        
        # Join mother BEF data
        mother_bef = bef_normalized.select(mother_cols).rename(mother_renames)
        
        df_with_mother = (
            df_with_child.join(mother_bef, on="CPR_MODER", how="left")
            .filter(
                (
                    pl.col("Year")
                    == (pl.col("first_diag_date").cast(pl.Date).dt.year() - 1)
                )
                | pl.col("Year").is_null()
            )
            .drop("Year")
        )
        
        # Adjust child count if mother gave birth in diagnosis year
        if "MODER_FOEDSELSDATO" in [
            mother_renames.get(col, col) for col in mother_cols
        ]:
            df_with_mother = df_with_mother.with_columns(
                pl.when(
                    pl.col("MODER_FOEDSELSDATO").dt.year()
                    == pl.col("first_diag_date").cast(pl.Date).dt.year()
                )
                .then(pl.col("ANTBOERNH_MOTHER") + 1)
                .otherwise(pl.col("ANTBOERNH_MOTHER"))
                .alias("ANTBOERNH")
            ).drop("ANTBOERNH_MOTHER")
        elif "ANTBOERNH_MOTHER" in df_with_mother.collect_schema():
            df_with_mother = df_with_mother.rename({"ANTBOERNH_MOTHER": "ANTBOERNH"})
        
        return df_with_mother
    
    def _join_father_data(self, df_with_mother: pl.LazyFrame, bef_normalized: pl.LazyFrame,
                         bef_schema: dict) -> pl.LazyFrame:
        """Join father BEF data"""
        # Prepare father data columns
        father_cols = ["PNR", "Year"]
        father_renames = {"PNR": "CPR_FADER"}
        
        for col, new_name in [
            ("OPR_LAND", "FAR_OPR_LAND"),
            ("FOEDSELSDATO", "FADER_FOEDSELSDATO"),
        ]:
            if col in bef_schema:
                father_cols.append(col)
                father_renames[col] = new_name
        
        # Join father BEF data
        father_bef = bef_normalized.select(father_cols).rename(father_renames)
        
        return (
            df_with_mother.join(father_bef, on="CPR_FADER", how="left")
            .filter(
                (
                    pl.col("Year")
                    == (pl.col("first_diag_date").cast(pl.Date).dt.year() - 1)
                )
                | pl.col("Year").is_null()
            )
            .drop("Year")
        )
    
    def report_data_quality(self, df_lf: pl.LazyFrame) -> None:
        """Report data quality metrics"""
        # Collect only necessary statistics to avoid breaking lazy evaluation
        schema = df_lf.collect_schema()
        
        quality_metrics = []
        if "MODER_FOEDSELSDATO" in schema:
            quality_metrics.append(
                pl.col("MODER_FOEDSELSDATO").count().alias("mother_birth_dates")
            )
        if "FADER_FOEDSELSDATO" in schema:
            quality_metrics.append(
                pl.col("FADER_FOEDSELSDATO").count().alias("father_birth_dates")
            )
        
        if quality_metrics:
            quality_metrics.append(pl.count().alias("total_records"))
            stats = df_lf.select(quality_metrics).collect()
            
            total_records = stats["total_records"][0]
            if "mother_birth_dates" in stats.columns:
                mother_dates = stats["mother_birth_dates"][0]
                print(
                    f"Mother birth dates available: {mother_dates} of {total_records} records"
                )
            if "father_birth_dates" in stats.columns:
                father_dates = stats["father_birth_dates"][0]
                print(
                    f"Father birth dates available: {father_dates} of {total_records} records"
                )