# Socioeconomic Data Processing Package
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Socioeconomic data processing package using lazy evaluation and SEPLINE guidelines.

This package provides:
- SocioeconomicProcessor: Main processing class
- Configuration management
- Data loading and joining
- Socioeconomic and geographic categorization
- Backwards compatibility with legacy functions

Example usage:
    from socioeconomic import process_socioeconomic
    
    config = {
        "parquet_path": "/path/to/data",
        "komgrp_format_file": "/path/to/format.sas"
    }
    result = process_socioeconomic(df, config)
"""

from typing import Any, Callable, Dict, Optional

import polars as pl

# Import main components
from .processor import SocioeconomicProcessor
from .config import SocioeconomicConfig, parse_sas_format
from .data_loader import BEFDataLoader
from .data_joiner import DataJoiner
from .categorizers import SocioeconomicCategorizer, AreaCategorizer, FactorConverter
from .constants import *

# Version info
__version__ = "2.0.0"
__author__ = "Tobias Kragholm"

# Public API - Main entry point
def process_socioeconomic(df: pl.DataFrame, config: Dict[str, Any]) -> pl.DataFrame:
    """
    Main entry point for socioeconomic processing.
    
    Args:
        df: DataFrame with cohort data
        config: Configuration dictionary with parquet_path and komgrp_format_file
        
    Returns:
        DataFrame with socioeconomic variables
    """
    processor = SocioeconomicProcessor(config)
    return processor.process(df)


# Legacy functions for backwards compatibility
def add_socioeconomic_categories(df: pl.DataFrame) -> pl.DataFrame:
    """
    Legacy function for adding socioeconomic categories.
    
    Args:
        df: DataFrame with BEF data
        
    Returns:
        DataFrame with socioeconomic categories
    """
    categorizer = SocioeconomicCategorizer()
    return categorizer.add_socioeconomic_categories(df.lazy()).collect()


def add_area_characteristics(
    df: pl.DataFrame, komgrp_converter: Optional[Callable] = None
) -> pl.DataFrame:
    """
    Legacy function for adding area characteristics.
    
    Args:
        df: DataFrame with BEF data  
        komgrp_converter: Optional municipality converter (ignored in new implementation)
        
    Returns:
        DataFrame with area characteristics
    """
    categorizer = AreaCategorizer()
    return categorizer.add_area_characteristics(df.lazy()).collect()


def convert_to_factors(df: pl.DataFrame) -> pl.DataFrame:
    """
    Legacy function for converting variables to categorical factors.
    
    Args:
        df: DataFrame with socioeconomic variables
        
    Returns:
        DataFrame with categorical variables
    """
    converter = FactorConverter()
    return converter.convert_to_factors(df.lazy()).collect()


# Export main classes and functions
__all__ = [
    # Main API
    "process_socioeconomic",
    
    # Core classes
    "SocioeconomicProcessor",
    "SocioeconomicConfig", 
    "BEFDataLoader",
    "DataJoiner",
    "SocioeconomicCategorizer",
    "AreaCategorizer", 
    "FactorConverter",
    
    # Utility functions
    "parse_sas_format",
    
    # Legacy functions
    "add_socioeconomic_categories",
    "add_area_characteristics", 
    "convert_to_factors",
    
    # Constants (imported from constants.py via *)
    "CAPITAL_CITIES",
    "LARGE_CITIES",
    "PROVINCIAL_TOWNS",
    "REGION_CODES",
    "MARRIED_COHABITING_CODES",
    "SINGLE_LIVING_ALONE_CODES",
    "STORHED_DETAILED",
    "METROPOLITAN_AREAS",
    "LARGE_CITIES_STORHED",
    "MEDIUM_CITIES",
    "SMALL_CITIES",
    "RURAL_AREAS",
    "URBAN_CODES",
    "RURAL_CODES",
]