# BEF Data Loading and Preparation
# Author: Tobias Kragholm
# Last updated: 2025-08-25

from pathlib import Path
from typing import List, Tuple

import polars as pl

from .config import SocioeconomicConfig


class BEFDataLoader:
    """Handles loading and preparation of BEF (population) data"""
    
    def __init__(self, config: SocioeconomicConfig):
        self.config = config
    
    def extract_cohort_identifiers(self, df: pl.DataFrame) -> Tuple[List[str], List[int]]:
        """Extract unique identifiers and relevant years from cohort data"""
        # Validate required columns
        required_cols = ["PNR", "first_diag_date"]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")
        
        # Use lazy evaluation to extract identifiers efficiently
        child_pnrs = df.select("PNR").drop_nulls().unique().collect()["PNR"].to_list()
        
        # Handle optional parent columns
        parent_ids_mother = []
        parent_ids_father = []
        if "CPR_MODER" in df.columns:
            parent_ids_mother = (
                df.select("CPR_MODER")
                .drop_nulls()
                .unique()
                .collect()["CPR_MODER"]
                .to_list()
            )
        if "CPR_FADER" in df.columns:
            parent_ids_father = (
                df.select("CPR_FADER")
                .drop_nulls()
                .unique()
                .collect()["CPR_FADER"]
                .to_list()
            )
        
        parent_ids = list(set(parent_ids_mother + parent_ids_father))
        all_pnrs = list(set(child_pnrs + parent_ids))
        
        if not all_pnrs:
            raise ValueError("No valid PNR identifiers found in cohort data")
        
        try:
            diag_years = (
                df.select(
                    pl.col("first_diag_date").cast(pl.Date).dt.year().alias("year")
                )
                .drop_nulls()
                .unique()
                .collect()["year"]
                .to_list()
            )
        except Exception as e:
            raise ValueError(f"Error parsing diagnosis dates: {e}")
        
        if not diag_years:
            raise ValueError("No valid diagnosis dates found in cohort data")
        
        relevant_years = [year - 1 for year in diag_years]  # Year before diagnosis
        print(
            f"Extracted {len(all_pnrs)} unique PNRs and {len(relevant_years)} relevant years"
        )
        
        return all_pnrs, relevant_years
    
    def prepare_bef_data(self, all_pnrs: List[str], relevant_years: List[int]) -> pl.LazyFrame:
        """Load and prepare BEF data using lazy evaluation"""
        bef_path = self.config.parquet_path / "bef"
        
        if not bef_path.exists():
            raise FileNotFoundError(f"BEF data directory not found: {bef_path}")
        
        # Check for parquet files
        parquet_files = list(bef_path.glob("*.parquet"))
        if not parquet_files:
            raise FileNotFoundError(
                f"No parquet files found in BEF directory: {bef_path}"
            )
        
        try:
            bef_lf = pl.scan_parquet(
                bef_path / "*.parquet",
                include_file_paths="file_path",
                extra_columns="ignore",
            )
        except Exception as e:
            raise RuntimeError(f"Failed to scan BEF parquet files: {e}")

        try:
            # Get schema to check available columns
            schema = bef_lf.collect_schema()
        except Exception as e:
            raise RuntimeError(f"Failed to collect BEF schema: {e}")
        
        # Define required and optional columns
        required_cols = ["PNR"]  # Only PNR is truly required
        recommended_cols = ["FAMILIE_TYPE", "OPR_LAND", "ANTBOERNH", "FAMILIE_ID"]
        optional_cols = [
            "IE_TYPE",
            "MOR_OPR_LAND",
            "FAR_OPR_LAND",
            "REG",
            "KOM",
            "SOGN",
            "STORHED",
            "FOEDSELSDATO",
            "FOED_DAG",
        ]
        
        # Check for required columns
        missing_required = [col for col in required_cols if col not in schema]
        if missing_required:
            raise ValueError(
                f"Missing required columns in BEF data: {missing_required}"
            )
        
        # Log missing recommended columns
        missing_recommended = [col for col in recommended_cols if col not in schema]
        if missing_recommended:
            print(
                f"Warning: Missing recommended columns in BEF data: {missing_recommended}"
            )
        
        # Select only columns that exist in the schema
        select_cols = (
            required_cols
            + [col for col in recommended_cols if col in schema]
            + [col for col in optional_cols if col in schema]
        )
        
        print(f"Using BEF columns: {select_cols}")
        
        # Return lazy frame with year extraction and filtering
        return (
            bef_lf.with_columns(
                pl.col("file_path")
                .str.extract(r"(\d{4})\d*")
                .cast(pl.Int32)
                .alias("Year")
            )
            .filter(pl.col("Year").is_in(relevant_years))
            .filter(pl.col("PNR").is_in(all_pnrs))
            .select(["Year"] + select_cols)
        )
    
    def normalize_birth_date_columns(self, bef_lf: pl.LazyFrame) -> pl.LazyFrame:
        """Normalize birth date column names and formats"""
        schema = bef_lf.collect_schema()
        
        if "FOED_DAG" in schema and "FOEDSELSDATO" not in schema:
            # Handle FOED_DAG column - assume string format that needs parsing
            return bef_lf.with_columns(
                pl.when(pl.col("FOED_DAG").is_not_null())
                .then(
                    pl.col("FOED_DAG").str.strptime(pl.Date, "%d/%m/%y", strict=False)
                )
                .otherwise(None)
                .alias("FOEDSELSDATO")
            ).drop("FOED_DAG")
        elif "FOED_DAG" in schema and "FOEDSELSDATO" in schema:
            # If both exist, prefer FOEDSELSDATO and drop FOED_DAG
            return bef_lf.drop("FOED_DAG")
        
        return bef_lf