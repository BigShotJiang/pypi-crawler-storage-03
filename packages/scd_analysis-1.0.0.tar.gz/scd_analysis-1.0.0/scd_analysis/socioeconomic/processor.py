# Main Socioeconomic Processor
# Author: Tobias Kragholm
# Last updated: 2025-08-25

from pathlib import Path
from typing import Any, Callable, Dict, Optional

import polars as pl

from .config import SocioeconomicConfig, parse_sas_format
from .data_loader import BEFDataLoader
from .data_joiner import DataJoiner
from .categorizers import SocioeconomicCategorizer, AreaCategorizer, FactorConverter


class SocioeconomicProcessor:
    """Processes socioeconomic data using lazy evaluation and SEPLINE guidelines"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = SocioeconomicConfig(
            parquet_path=config["parquet_path"],
            komgrp_format_file=config["komgrp_format_file"],
        )
        self.data_loader = BEFDataLoader(self.config)
        self.data_joiner = DataJoiner(self.data_loader)
        self.socio_categorizer = SocioeconomicCategorizer()
        self.area_categorizer = AreaCategorizer()
        self.factor_converter = FactorConverter()
        self.komgrp_converter = self._setup_municipality_converter()
    
    def _setup_municipality_converter(self) -> Optional[Callable]:
        """Setup municipality urbanization converter from SAS format file"""
        if Path(self.config.komgrp_format_file).exists():
            print("Creating cached municipality urbanization converter...")
            komgrp_mapping = parse_sas_format(
                self.config.komgrp_format_file, target_format="text"
            )
            if komgrp_mapping is not None:
                def converter(kom_codes):
                    return [
                        komgrp_mapping.get(str(code), "Missing/Other")
                        for code in kom_codes
                    ]
                return converter
        else:
            print("Municipality urbanization SAS format file not found")
        return None
    
    def process(self, df: pl.DataFrame) -> pl.DataFrame:
        """Main processing method using lazy evaluation throughout"""
        print("Processing socioeconomic data following SEPLINE guidelines...")
        
        # Extract identifiers and years
        all_pnrs, relevant_years = self.data_loader.extract_cohort_identifiers(df)
        
        # Prepare BEF data lazily
        bef_lf = self.data_loader.prepare_bef_data(all_pnrs, relevant_years)
        
        # Join all data using lazy evaluation
        df_joined_lf = self.data_joiner.join_bef_data(df, bef_lf)
        
        # Add derived variables while maintaining lazy evaluation
        df_processed_lf = (
            df_joined_lf
            .pipe(self.socio_categorizer.add_socioeconomic_categories)
            .pipe(self.area_categorizer.add_area_characteristics)
            .pipe(self.factor_converter.convert_to_factors)
        )
        
        # Note: SAS converter would break lazy evaluation, so we use built-in classification
        if self.komgrp_converter is not None:
            print("Using built-in municipality classification for lazy evaluation")
        
        # Report data quality before final collection
        self.data_joiner.report_data_quality(df_processed_lf)
        
        # Collect final result
        df_result = df_processed_lf.collect()
        
        print(f"Socioeconomic processing complete. Records: {len(df_result)}")
        return df_result