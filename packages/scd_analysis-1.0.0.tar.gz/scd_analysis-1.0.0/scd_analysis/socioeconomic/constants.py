# Constants for Socioeconomic Processing
# Author: Tobias Kragholm
# Last updated: 2025-08-25

from typing import List

# Danish municipality codes by urbanization level
CAPITAL_CITIES: List[int] = [
    101,
    147,
    151,
    157,
    159,
    161,
    163,
    165,
    167,
    169,
    173,
    175,
    183,
    185,
    187,
    190,
    201,
    240,
    253,
    259,
    260,
    270,
]

LARGE_CITIES: List[int] = [
    306,
    316,
    320,
    326,
    330,
    340,
    350,
    360,
    370,
    390,
    410,
    420,
    430,
    440,
    450,
    461,
    479,
    480,
    482,
    492,
]

PROVINCIAL_TOWNS: List[int] = [
    502,
    510,
    530,
    540,
    550,
    561,
    563,
    573,
    575,
    580,
    607,
    615,
    621,
    630,
    657,
    661,
    665,
    671,
    706,
    707,
    710,
    727,
    730,
    740,
    741,
    746,
    751,
    756,
    760,
    766,
    779,
    787,
    791,
    810,
    813,
    820,
    825,
    840,
    846,
    849,
    851,
    860,
]

# Danish region codes
REGION_CODES = {
    1084: "Capital Region",
    1083: "Region Zealand",
    1082: "Region of Southern Denmark",
    1081: "Central Denmark Region",
    1080: "North Denmark Region",
}

# Family type codes for SEPLINE categorization
MARRIED_COHABITING_CODES = [1, 2, 3, 4, 7, 8]
SINGLE_LIVING_ALONE_CODES = [5, 9, 10]

# Population density (STORHED) categorizations
STORHED_DETAILED = {
    1: "Capital Area",
    2: "Cities ≥100,000 inhabitants",
    3: "Cities 50,000-99,999 inhabitants",
    4: "Cities 40,000-49,999 inhabitants",
    5: "Cities 30,000-39,999 inhabitants",
    6: "Cities 20,000-29,999 inhabitants",
    7: "Cities 15,000-19,999 inhabitants",
    8: "Cities 10,000-14,999 inhabitants",
    9: "Cities 5,000-9,999 inhabitants",
    10: "Cities 2,000-4,999 inhabitants",
    11: "Cities 1,000-1,999 inhabitants",
    12: "Cities 200-999 inhabitants",
    13: "Cities <200 inhabitants",
    0: "No registered address",
}

# Simplified urbanization groupings
METROPOLITAN_AREAS = [1, 2]
LARGE_CITIES_STORHED = [3, 4, 5]
MEDIUM_CITIES = [6, 7, 8]
SMALL_CITIES = [9, 10, 11]
RURAL_AREAS = [12, 13]
URBAN_CODES = list(range(1, 9))  # 1-8
RURAL_CODES = list(range(9, 14))  # 9-13
