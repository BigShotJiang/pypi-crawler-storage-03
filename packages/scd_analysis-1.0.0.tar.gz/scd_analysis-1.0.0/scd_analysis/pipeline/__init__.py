# Pipeline Orchestration Package
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Pipeline orchestration modules for SCD Analysis Pipeline.

This package provides:
- Main pipeline orchestration
- Analysis pipeline components
- Pipeline configuration and execution
- Results management

Example usage:
    from scd_analysis.pipeline import run_scd_pipeline, run_descriptive_analysis

    # Run complete pipeline
    final_data = run_scd_pipeline()

    # Run analysis
    summary_stats = run_descriptive_analysis(final_data)
"""

from .analysis import run_descriptive_analysis
from .main import print_pipeline_summary, run_scd_pipeline

__all__ = [
    "run_scd_pipeline",
    "print_pipeline_summary",
    "run_descriptive_analysis",
]
