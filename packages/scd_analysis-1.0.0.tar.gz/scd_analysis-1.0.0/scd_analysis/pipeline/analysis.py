# Severe Chronic Disease (SCD) Analysis Pipeline - Refactored Python Version
# This file serves as the main entry point and imports modular components
# Author: Refactored from consolidated R script
# Last updated: 2025-08-22
#
# REFACTORING IMPROVEMENTS:
# - Modular design: Split into logical components for maintainability
# - Separation of concerns: Configuration, utilities, data processing, and analysis
# - Better code organization: Each module has a specific responsibility
# - Easier testing and debugging: Functions can be tested in isolation
#
# ORIGINAL PERFORMANCE BENEFITS RETAINED:
# - 10-100x faster on large partitioned datasets
# - Constant memory usage regardless of dataset size
# - Automatic predicate pushdown to parquet files
# - Parallel processing of partitions


# Load modular components
import polars as pl

from ..config import get_default_config
from .main import run_scd_pipeline

# Configuration alias for backwards compatibility
CONFIG = get_default_config()


def main():
    """
    Example Usage and Documentation

    QUICK START:
    Run the complete pipeline with default settings:
        final_data = run_scd_pipeline()

    Run with custom configuration:
        my_config = get_default_config()
        my_config["age_cutoff"] = 5  # Change age cutoff
        final_data = run_scd_pipeline(my_config)

    Run descriptive analysis:
        summary_stats = run_descriptive_analysis(final_data)

    The original monolithic functions have been moved to dedicated modules:
    - config.py: Configuration management
    - utils.py: Utility functions (file I/O, directory setup)
    - scd_flagging.py: SCD diagnosis flagging logic
    - data_processors.py: Core data processing (LPR, MFR, vital status)
    - socioeconomic/: Socioeconomic data processing package (BEF)
    - employment_income_processors.py: Employment (AKM), income (FAIK)
    - education_processing.py: Education (UDDF) processing
    - main_pipeline.py: Main orchestrator and pipeline execution
    """

    # Run the complete pipeline using the new modular structure
    print("Running SCD Analysis Pipeline...")
    final_data = run_scd_pipeline()

    # Basic descriptive analysis
    print("\n=== Running Descriptive Analysis ===")
    summary_stats = run_descriptive_analysis(final_data)
    print("Summary Statistics:")
    print(summary_stats)

    print("\n=== Pipeline Complete ===")
    print(f"Final dataset contains {len(final_data)} records")
    print("Data is ready for advanced analyses such as:")
    print("- Survival analysis")
    print("- Regression models for risk factors")
    print("- Geographical analysis")
    print("- Temporal trends analysis")


if __name__ == "__main__":
    main()


def run_descriptive_analysis(final_data: pl.DataFrame) -> pl.DataFrame:
    """
    Run basic descriptive analysis on the final dataset

    Args:
        final_data: Final processed dataset from run_scd_pipeline()

    Returns:
        Summary statistics DataFrame
    """
    summary_stats = final_data.select(
        [
            pl.len().alias("n_children"),
            pl.col("V_ALDER").median().alias("median_age_diag")
            if "V_ALDER" in final_data.columns
            else pl.lit(None).alias("median_age_diag"),
            (pl.col("KOEN") == 1).mean().alias("pct_male") * 100
            if "KOEN" in final_data.columns
            else pl.lit(None).alias("pct_male"),
            (pl.col("ethnicity") == "Danish/Danish").mean().alias("pct_danish_parents")
            * 100
            if "ethnicity" in final_data.columns
            else pl.lit(None).alias("pct_danish_parents"),
            (pl.col("income_quintile") == "Q5: High income")
            .mean()
            .alias("pct_high_income")
            * 100
            if "income_quintile" in final_data.columns
            else pl.lit(None).alias("pct_high_income"),
            (pl.col("urban_rural") == "Urban").mean().alias("pct_urban") * 100
            if "urban_rural" in final_data.columns
            else pl.lit(None).alias("pct_urban"),
        ]
    )

