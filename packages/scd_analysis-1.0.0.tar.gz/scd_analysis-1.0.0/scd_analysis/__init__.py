# SCD Analysis - Severe Chronic Disease Analysis Pipeline
# Author: Tobias Kragholm  
# Last updated: 2025-08-25

"""
SCD Analysis: A comprehensive pipeline for analyzing severe chronic diseases using Danish national registers.

This package provides high-performance tools for:
- Processing Danish health registers (LPR, MFR, BEF, AKM, FAIK, UDDF)
- Socioeconomic analysis with SEPLINE compliance
- SCD diagnosis flagging and cohort matching
- Lazy evaluation and memory-efficient processing

Key Features:
- 10-100x faster processing with Polars lazy evaluation
- Memory-efficient streaming for large datasets
- Modular design for research flexibility
- Comprehensive data quality validation

Quick Start:
    from scd_analysis import run_scd_pipeline, get_default_config
    
    # Run with default settings
    final_data = run_scd_pipeline()
    
    # Customize configuration
    config = get_default_config()
    config["age_cutoff"] = 5
    final_data = run_scd_pipeline(config)
"""

# Version info
__version__ = "1.0.0"
__author__ = "Tobias Kragholm"
__license__ = "MIT"

# Core imports for main API
from .config import get_default_config, validate_config
from .pipeline import run_scd_pipeline, run_descriptive_analysis
from .data import (
    process_lpr_data,
    process_mfr_data,
    process_vital_status,
    process_education,
    process_employment,
    process_income,
    flag_scd_diagnoses,
)
from .socioeconomic import process_socioeconomic, SocioeconomicProcessor

# Main public API
__all__ = [
    # Configuration
    "get_default_config",
    "validate_config",
    
    # Main pipeline
    "run_scd_pipeline", 
    "run_descriptive_analysis",
    
    # Data processing
    "process_lpr_data",
    "process_mfr_data",
    "process_vital_status", 
    "process_education",
    "process_employment",
    "process_income",
    "flag_scd_diagnoses",
    
    # Socioeconomic processing
    "process_socioeconomic",
    "SocioeconomicProcessor",
    
    # Package info
    "__version__",
    "__author__",
    "__license__",
]