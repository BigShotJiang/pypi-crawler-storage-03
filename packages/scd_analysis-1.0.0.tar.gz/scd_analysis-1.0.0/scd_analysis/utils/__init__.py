# Utilities Package
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Utility functions for SCD Analysis Pipeline.

This package provides:
- File I/O helpers
- Directory management
- Data validation utilities
- Common helper functions

Example usage:
    from scd_analysis.utils import setup_directories, open_data_safe
    
    setup_directories(config)
    df = open_data_safe("path/to/data.parquet")
"""

from .helpers import setup_directories, open_data_safe

__all__ = [
    "setup_directories",
    "open_data_safe",
]