# Utility Functions for SCD Analysis Pipeline
# Author: Tobias Kragholm
# Last updated: 2025-08-22

import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import polars as pl


def setup_directories(config: Dict[str, Any]) -> None:
    """
    Check if required directories exist and create if necessary

    Args:
        config: Configuration dict containing directory paths
    """
    dirs = [config["data_path"], config["output_path"], config["parquet_path"]]
    for dir_path in dirs:
        Path(dir_path).mkdir(parents=True, exist_ok=True)


def open_data_safe(
    dataset_path: Union[str, Path],
    format: str = "dataset",
    partitioning: Optional[str] = None,
    year_filter: Optional[List[int]] = None,
    hive_partitioning: Optional[bool] = None,
    use_statistics: bool = True,
    parallel: str = "auto",
) -> Optional[pl.LazyFrame]:
    """
    Open dataset with proper error handling, supporting partitioned data

    Uses modern Polars scan_parquet features for optimal performance including:
    - Automatic Hive partitioning detection
    - Statistics-based file pruning
    - Configurable parallelization strategies

    Args:
        dataset_path: Path to dataset (file or directory)
        format: Format of the data ("parquet", "dataset")
        partitioning: Partitioning scheme (deprecated, use hive_partitioning)
        year_filter: Optional list of years to filter (for performance)
        hive_partitioning: Enable Hive partitioning inference (None for auto-detect)
        use_statistics: Use parquet statistics to skip pages/files
        parallel: Parallelization strategy ('auto', 'columns', 'row_groups', 'prefiltered', 'none')

    Returns:
        Polars LazyFrame or None if failed
    """
    try:
        dataset_path = Path(dataset_path)

        if format == "dataset":
            # Use scan_parquet with modern Polars features
            if dataset_path.is_dir():
                # Directory - scan with glob pattern
                scan_path = dataset_path / "*.parquet"
            else:
                # Single file
                scan_path = dataset_path

            # Build scan_parquet arguments
            scan_kwargs = {
                "use_statistics": use_statistics,
                "parallel": parallel,
                "cache": True,  # Cache scan results
                "rechunk": False,  # Avoid rechunking for better streaming performance
                "low_memory": False,  # Prioritize performance over memory
                "missing_columns": "insert",  # Insert NULL columns for missing columns
                "extra_columns": "ignore",  # Ignore extra columns not in schema
            }

            # Enable Hive partitioning if specified or auto-detect for directories
            if hive_partitioning is not None:
                scan_kwargs["hive_partitioning"] = hive_partitioning
            elif dataset_path.is_dir():
                # Auto-enable for directories that might be partitioned
                scan_kwargs["hive_partitioning"] = True

            lf = pl.scan_parquet(scan_path, **scan_kwargs)

            # Apply year filter if specified (pushdown optimization)
            if year_filter is not None:
                schema = lf.schema
                if "year" in schema:
                    lf = lf.filter(pl.col("year").is_in(year_filter))

            return lf

        elif format == "parquet":
            # Single parquet file with optimizations
            return pl.scan_parquet(
                dataset_path,
                use_statistics=use_statistics,
                parallel=parallel,
                cache=True,
                low_memory=False,
                missing_columns="insert",  # Handle missing columns gracefully
                extra_columns="ignore",  # Ignore extra columns
            )

    except Exception as e:
        warnings.warn(f"Failed to open {dataset_path}: {e}")
        return None


def open_data_with_heavy_filtering(
    dataset_path: Union[str, Path], filter_condition: Optional[pl.Expr] = None, **kwargs
) -> Optional[pl.LazyFrame]:
    """
    Open dataset optimized for heavy filtering using prefiltered parallel strategy

    This is particularly useful for large datasets where you'll be filtering out
    most rows, as it evaluates filters in parallel first to determine which
    rows to read.

    Args:
        dataset_path: Path to dataset (file or directory)
        filter_condition: Polars expression for filtering (applied during scan)
        **kwargs: Additional arguments passed to open_data_safe

    Returns:
        Polars LazyFrame or None if failed
    """
    # Use prefiltered strategy for datasets with heavy filtering
    kwargs["parallel"] = "prefiltered"

    lf = open_data_safe(dataset_path, **kwargs)

    # Apply filter condition if provided
    if lf is not None and filter_condition is not None:
        lf = lf.filter(filter_condition)

    return lf


def read_data_safe(
    file_path: Union[str, Path], format: str = "parquet"
) -> Optional[pl.DataFrame]:
    """
    Read data with compatibility wrapper

    Args:
        file_path: Path to data file
        format: Data format

    Returns:
        Polars DataFrame or None if failed
    """
    lf = open_data_safe(file_path, format=format)
    if lf is not None:
        return lf.collect()
    return None
