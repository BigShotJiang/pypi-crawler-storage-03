# Examples Package
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Usage examples for SCD Analysis Pipeline.

This package provides:
- Basic usage examples
- Advanced configuration examples
- Research workflow examples
- Integration examples

Example usage:
    from scd_analysis.examples import run_basic_example

    # Run a basic example
    run_basic_example()
"""

from .basic_usage import run_basic_example, run_custom_config_example

__all__ = [
    "run_basic_example",
    "run_custom_config_example",
]
