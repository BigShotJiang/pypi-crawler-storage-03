# Basic Usage Examples for SCD Analysis
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Basic usage examples for the SCD Analysis pipeline.

These examples demonstrate:
- Running the complete pipeline
- Customizing configuration
- Processing individual components
- Descriptive analysis
"""

from pathlib import Path

import polars as pl

from scd_analysis import (
    SocioeconomicProcessor,
    get_default_config,
    process_lpr_data,
    run_descriptive_analysis,
    run_scd_pipeline,
)


def run_basic_example():
    """
    Run the complete SCD analysis pipeline with default settings.

    This is the simplest way to use the package - just call the main
    pipeline function and it will process all data steps automatically.
    """
    print("=== Basic SCD Analysis Pipeline Example ===")

    try:
        # Run the complete pipeline
        print("Running complete SCD analysis pipeline...")
        final_data = run_scd_pipeline()

        # Show basic information about the result
        print("Pipeline completed successfully!")
        print(f"Final dataset contains {len(final_data)} records")
        print(f"Columns: {len(final_data.columns)}")

        # Run descriptive analysis
        print("\nRunning descriptive analysis...")
        summary_stats = run_descriptive_analysis(final_data)
        print("Summary statistics:")
        print(summary_stats)

        return final_data

    except Exception as e:
        print(f"Pipeline failed: {e}")
        print("Make sure your data paths are configured correctly in the config.")
        return None


def run_custom_config_example():
    """
    Run the pipeline with custom configuration settings.

    This example shows how to modify the default configuration
    to suit your specific research needs.
    """
    print("=== Custom Configuration Example ===")

    # Get default configuration
    config = get_default_config()

    # Customize settings for your study
    config.update(
        {
            "age_cutoff": 5,  # Only include children under 5 years
            "study_period": {
                "start_year": 2010,
                "end_year": 2020,
            },
            "data_path": Path("my_data/"),
            "output_path": Path("my_results/"),
            "calculate_area_indicators": False,  # Skip area indicators for faster processing
        }
    )

    # Validate configuration
    from scd_analysis.config import validate_config

    errors = validate_config(config)
    if errors:
        print("Configuration errors:")
        for error in errors:
            print(f"  - {error}")
        return None

    try:
        # Run pipeline with custom config
        print("Running SCD analysis with custom configuration...")
        final_data = run_scd_pipeline(config)

        print(f"Custom pipeline completed! Dataset: {len(final_data)} records")

        return final_data

    except Exception as e:
        print(f"Custom pipeline failed: {e}")
        return None


def run_component_example():
    """
    Example of processing individual components of the pipeline.

    This shows how to use individual processing functions
    for more granular control over the analysis.
    """
    print("=== Individual Component Processing Example ===")

    config = get_default_config()

    try:
        # Process hospital data only
        print("1. Processing LPR (hospital) data...")
        df_lpr = process_lpr_data(config)
        print(f"LPR data: {len(df_lpr)} records")

        # Process socioeconomic data with custom processor
        print("2. Processing socioeconomic data...")
        socio_processor = SocioeconomicProcessor(config)
        df_socio = socio_processor.process(df_lpr)
        print(f"With socioeconomic data: {len(df_socio)} records")

        # Show available columns
        print(f"Available columns: {df_socio.columns}")

        return df_socio

    except Exception as e:
        print(f"Component processing failed: {e}")
        return None


def run_analysis_example():
    """
    Example of running various analyses on processed data.

    This demonstrates how to perform common epidemiological
    analyses after running the main pipeline.
    """
    print("=== Analysis Examples ===")

    # First get processed data
    final_data = run_basic_example()
    if final_data is None:
        print("Cannot run analysis - no data available")
        return

    print("\n--- Descriptive Statistics ---")

    # Age distribution
    if "V_ALDER" in final_data.columns:
        age_stats = final_data.select(
            [
                pl.col("V_ALDER").mean().alias("mean_age"),
                pl.col("V_ALDER").median().alias("median_age"),
                pl.col("V_ALDER").std().alias("std_age"),
                pl.col("V_ALDER").min().alias("min_age"),
                pl.col("V_ALDER").max().alias("max_age"),
            ]
        )
        print("Age at diagnosis statistics:")
        print(age_stats)

    # Gender distribution
    if "KOEN" in final_data.columns:
        gender_dist = final_data["KOEN"].value_counts().sort("KOEN")
        print("\nGender distribution:")
        print(gender_dist)

    # Socioeconomic distribution
    if "ethnicity_mother_main" in final_data.columns:
        ethnicity_dist = final_data["ethnicity_mother_main"].value_counts()
        print("\nEthnicity distribution (SEPLINE):")
        print(ethnicity_dist)

    # Temporal trends
    if "first_diag_date" in final_data.columns:
        temporal_trends = (
            final_data.with_columns(
                pl.col("first_diag_date").cast(pl.Date).dt.year().alias("diag_year")
            )
            .group_by("diag_year")
            .count()
            .sort("diag_year")
        )
        print("\nCases by diagnosis year:")
        print(temporal_trends)

    print("\nAnalysis examples completed!")


if __name__ == "__main__":
    # Run all examples
    print("Running SCD Analysis Examples")
    print("=" * 50)

    # Basic example
    run_basic_example()

    # Custom configuration
    run_custom_config_example()

    # Component processing
    run_component_example()

    # Analysis examples
    run_analysis_example()
