# Configuration Management Package
# Author: Tobias Kragholm
# Last updated: 2025-08-25

"""
Configuration management for SCD Analysis Pipeline.

This package provides:
- Default configuration settings
- Configuration validation
- Environment-specific overrides
- Path management utilities

Example usage:
    from scd_analysis.config import get_default_config
    
    config = get_default_config()
    config["age_cutoff"] = 5
"""

from .defaults import get_default_config, validate_config

__all__ = [
    "get_default_config",
    "validate_config",
]