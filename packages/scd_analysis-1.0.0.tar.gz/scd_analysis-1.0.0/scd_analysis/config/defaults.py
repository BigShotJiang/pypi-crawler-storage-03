# Default Configuration for SCD Analysis Pipeline
# Author: Tobias Kragholm
# Last updated: 2025-08-25

from datetime import date
from pathlib import Path
from typing import Any, Dict, List


def get_default_config() -> Dict[str, Any]:
    """
    Default configuration for SCD analysis pipeline

    This configuration uses Polars' lazy evaluation for optimal performance.
    Datasets can be:
    - Single parquet files: "parquet/table.parquet"
    - Partitioned datasets: "parquet/table/" (Hive partitioning supported)
    - Mixed: some tables single files, others partitioned

    Returns:
        Dict containing all configuration parameters
    """
    return {
        # Data paths
        "data_path": Path("data/"),
        "output_path": Path("output/"),
        "parquet_path": Path("parquet/"),  # Base path for parquet datasets
        
        # Study design parameters
        "study_period": {
            "start_year": 2001,
            "end_year": 2018,
            "follow_up_end": date(2022, 12, 31),
        },
        "age_cutoff": "6",
        
        # Performance tuning
        "lazy_loading": True,  # Use Polars' lazy evaluation
        "year_partitioning": True,  # Expect year-based Hive partitioning where available
        
        # Format files
        "sas_format_file": "AUDD2025.sas",  # SAS format file for HFAUDD conversion
        "komgrp_format_file": "KOMGRP_V4_KT.sas",  # Municipality urbanization format
        
        # Analysis options
        "calculate_area_indicators": True,  # Calculate contextual area-level characteristics
        
        # Register-specific settings
        "lpr_settings": {
            "include_ambulatory": True,
            "include_emergency": True,
            "min_los": 0,  # Minimum length of stay in days
        },
        
        "socioeconomic_settings": {
            "use_sepline_guidelines": True,
            "include_parental_data": True,
            "year_before_diagnosis": True,
        },
        
        "matching_settings": {
            "max_controls": 10,
            "match_on_birth_year": True,
            "match_on_gender": True,
            "match_on_municipality": False,
        },
    }


def validate_config(config: Dict[str, Any]) -> List[str]:
    """
    Validate configuration parameters
    
    Args:
        config: Configuration dictionary to validate
        
    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []
    
    # Check required paths
    required_paths = ["data_path", "output_path", "parquet_path"]
    for path_key in required_paths:
        if path_key not in config:
            errors.append(f"Missing required path: {path_key}")
        elif not isinstance(config[path_key], Path):
            try:
                config[path_key] = Path(config[path_key])
            except Exception:
                errors.append(f"Invalid path format for {path_key}: {config[path_key]}")
    
    # Check study period
    if "study_period" not in config:
        errors.append("Missing study_period configuration")
    else:
        study_period = config["study_period"]
        if "start_year" not in study_period or "end_year" not in study_period:
            errors.append("Study period must include start_year and end_year")
        elif study_period["start_year"] >= study_period["end_year"]:
            errors.append("Start year must be before end year")
    
    # Check age cutoff
    if "age_cutoff" in config:
        try:
            age_val = float(config["age_cutoff"])
            if age_val < 0 or age_val > 18:
                errors.append("Age cutoff should be between 0 and 18")
        except (ValueError, TypeError):
            errors.append(f"Invalid age_cutoff: {config['age_cutoff']}")
    
    return errors


def get_test_config() -> Dict[str, Any]:
    """
    Configuration for testing with minimal data requirements
    
    Returns:
        Test configuration dictionary
    """
    config = get_default_config()
    
    # Override with test-specific settings
    config.update({
        "data_path": Path("tests/data/"),
        "output_path": Path("tests/output/"),
        "parquet_path": Path("tests/data/parquet/"),
        "study_period": {
            "start_year": 2015,
            "end_year": 2017,
            "follow_up_end": date(2020, 12, 31),
        },
        "calculate_area_indicators": False,  # Faster for testing
    })
    
    return config