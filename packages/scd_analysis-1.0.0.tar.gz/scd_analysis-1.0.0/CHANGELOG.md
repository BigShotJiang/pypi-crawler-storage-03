# Changelog

All notable changes to the SCD Analysis package will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-08-25

### Added
- Initial release of SCD Analysis package
- Complete pipeline for severe chronic disease analysis using Danish national registers
- High-performance data processing with Polars lazy evaluation
- Modular package structure with clear separation of concerns
- SEPLINE-compliant socioeconomic categorization
- Comprehensive configuration management
- Examples and documentation for common use cases

### Package Structure
- `scd_analysis.config`: Configuration management and validation
- `scd_analysis.data`: Core data processing modules (LPR, MFR, education, employment, income)
- `scd_analysis.socioeconomic`: Socioeconomic data processing with SEPLINE compliance
- `scd_analysis.pipeline`: Pipeline orchestration and analysis functions
- `scd_analysis.utils`: Utility functions and helpers
- `scd_analysis.examples`: Usage examples and tutorials

### Features
- **Performance**: 10-100x faster processing with lazy evaluation and predicate pushdown
- **Memory Efficiency**: Constant memory usage regardless of dataset size
- **Modular Design**: Easy to extend and customize for different research questions
- **Data Quality**: Comprehensive validation and quality reporting
- **Research Ready**: Optimized for epidemiological research workflows

### Data Processing Capabilities
- Hospital discharge data (LPR) processing with SCD flagging
- Birth registry (MFR) data integration
- Socioeconomic data (BEF) with Danish regional classifications
- Employment (AKM) and income (FAIK) processing
- Education data (UDDF) with SAS format support
- Vital status (DOD/VNDS) integration

### Dependencies
- Python 3.9+
- Polars 0.20.0+
- Pandas 1.5.0+ (compatibility layer)
- NumPy 1.21.0+