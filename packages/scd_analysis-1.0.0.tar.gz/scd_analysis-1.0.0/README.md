# SCD Analysis - Severe Chronic Disease Analysis Pipeline

[![Python Version](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

A high-performance Python package for analyzing severe chronic diseases (SCD) using Danish national health registers. This package provides a complete pipeline for processing, analyzing, and matching complex epidemiological data with lazy evaluation and optimal memory usage.

### Basic Usage

```python
from scd_analysis import run_scd_pipeline, get_default_config

# Run with default configuration
final_data = run_scd_pipeline()

# Customize configuration
config = get_default_config()
config["age_cutoff"] = 5
config["study_period"]["end_year"] = 2020

final_data = run_scd_pipeline(config)

# Basic descriptive analysis
from scd_analysis.pipeline import run_descriptive_analysis
summary_stats = run_descriptive_analysis(final_data)
print(summary_stats)
```

### Advanced Usage

```python
from scd_analysis.data import process_lpr_data, process_mfr_data
from scd_analysis.socioeconomic import SocioeconomicProcessor

# Process specific components
config = get_default_config()

# Process hospital data
df_lpr = process_lpr_data(config)

# Process socioeconomic data with custom settings
socio_processor = SocioeconomicProcessor(config)
df_socio = socio_processor.process(df_lpr)
```

## Package Structure

- **`scd_analysis.config`**: Configuration management
- **`scd_analysis.data`**: Core data processing modules
- **`scd_analysis.socioeconomic`**: Socioeconomic data processing (SEPLINE-compliant)
- **`scd_analysis.pipeline`**: Pipeline orchestration and analysis
- **`scd_analysis.utils`**: Utility functions and helpers

## Data Requirements

This package is designed to work with Danish national health registers:

- **LPR**: Hospital discharge register
- **MFR**: Birth register
- **BEF**: Population register
- **AKM**: Employment register
- **FAIK**: Income register
- **UDDF**: Education register
- **DOD/VNDS**: Death/emigration registers

Data should be provided as Parquet files (single files or partitioned datasets).

## Performance Benefits

- **Lazy Evaluation**: Only loads necessary data into memory
- **Predicate Pushdown**: Filters applied at file level
- **Partitioned Support**: Efficient processing of time-partitioned data
- **Parallel Processing**: Automatic parallelization of operations
- **Memory Optimization**: Streaming processing for large datasets

## Key Features

### Socioeconomic Processing

- SEPLINE-compliant ethnicity categorization (A1, A2, B1, B2, C1, C2)
- Danish regional and municipal classifications
- Population density and urbanization categories
- Family structure and cohabitation status

### SCD Analysis

- Automated severe chronic disease flagging
- Age-appropriate diagnosis criteria
- Temporal analysis capabilities
- Cohort matching and controls

### Data Quality

- Comprehensive validation and quality checks
- Missing data reporting
- Data lineage tracking
- Performance monitoring
