from .speakers import Milan
# from milan_brzon.speakers import Milan

def main():
    Milan().print_name()

if __name__ == "__main__":
    main()