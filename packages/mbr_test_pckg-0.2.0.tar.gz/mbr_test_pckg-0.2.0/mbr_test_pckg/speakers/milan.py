from milan_brzon.speaker import Speaker

class Milan(Speaker):
    name = "Milan"