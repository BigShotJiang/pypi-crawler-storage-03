import{r}from"./react-Blzc5Mwu.js";var a=r.useLayoutEffect;export{a as i};
