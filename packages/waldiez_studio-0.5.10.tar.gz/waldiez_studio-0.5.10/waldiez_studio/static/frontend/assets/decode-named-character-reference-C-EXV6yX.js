const t=document.createElement("i");function e(e){const n="&"+e+";";t.innerHTML=n;const o=t.textContent;return(59!==o.charCodeAt(o.length-1)||"semi"===e)&&(o!==n&&o)}export{e as d};
