function o(o){if(o)throw o}export{o as b};
