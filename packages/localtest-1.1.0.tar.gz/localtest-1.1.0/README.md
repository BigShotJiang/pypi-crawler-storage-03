# Localtest

Localtest is a **CLI** tool to test stuff **locally**. This can be from **your network** to **IMPROVING** it?! That's **right**. From version *1.1* _onwards_, you'll be able to **IMPROVE** your network speeds from using **Localtest**. Use the command ```localtest help``` to view **all** available commands and flags in your **current version**, it'll be **up-to-date**. _Localtest was built for Hack Club's Summer of Making._

## Localtest Network

Use ```localtest network run``` to **start** a **quick** Network test. _If you have time on your hands_, you should do ```localtest network run -fs``` for a **full** scan, which will take _longer_, but will be more **accurate**!

## Localtest Hardware

Localtest Hardware _(tm)_ is an _upcoming_ feature for **Localtest** and it is to tell you which **games** _(and tools)_ you can **smoothly** run on and which you **can't** smoothly run. **Star** this project to see _more_ of Localtest! _:3_
