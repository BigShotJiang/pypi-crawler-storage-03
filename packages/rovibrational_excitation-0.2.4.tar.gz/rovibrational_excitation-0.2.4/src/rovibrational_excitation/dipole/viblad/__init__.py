"""Vibrational ladder system dipole matrix."""

from .cache import VibLadderDipoleMatrix

__all__ = ["VibLadderDipoleMatrix"]
