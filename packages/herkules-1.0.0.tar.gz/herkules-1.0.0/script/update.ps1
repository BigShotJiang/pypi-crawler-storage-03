Write-Output ""

uv sync --upgrade

Write-Output ""
