# Change Log

_All notable changes to this project will be documented in this
file. This change log follows the conventions of
[keepachangelog.com]._

_I tend to not use
[semantic versioning](https://semver.org/), but we will see what
happens._

<!--- ---------------------------------------------------------------------- -->

## [Unreleased]

### Changed

<!--- ---------------------------------------------------------------------- -->

## [1.0.0] - 2024-08-08

- This is the first stable release (although I have been using it professionally for over two years now).

<!--- ---------------------------------------------------------------------- -->

[keepachangelog.com]: http://keepachangelog.com/
[unreleased]: https://github.com/mzuther/Herkules/tree/develop
[1.0.0]: https://github.com/mzuther/Herkules/commits/v1.0.0
