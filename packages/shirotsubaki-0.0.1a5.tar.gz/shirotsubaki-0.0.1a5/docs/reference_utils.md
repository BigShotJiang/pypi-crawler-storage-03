## Plot

::: shirotsubaki.utils.figure_to_html
    options:
      heading_level: 4


## DataFrame

::: shirotsubaki.utils.style_float_cols
    options:
      heading_level: 4

::: shirotsubaki.utils.style_top_ranks_per_row
    options:
      heading_level: 4


## Others

::: shirotsubaki.utils.lighten_color
    options:
      heading_level: 4
