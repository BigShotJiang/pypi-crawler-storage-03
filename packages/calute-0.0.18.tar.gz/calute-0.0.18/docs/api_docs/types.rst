Types
=====

.. toctree::
   :maxdepth: 2

   types___init__
   types_agent_types
   types_chat_completion_types
   types_converters
   types_function_execution_types
   types_messages
   types_tool_calls
