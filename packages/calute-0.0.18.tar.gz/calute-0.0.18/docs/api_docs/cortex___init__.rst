calute.cortex.__init__
======================

.. automodule:: calute.cortex.__init__
    :members:
    :undoc-members:
    :show-inheritance:
