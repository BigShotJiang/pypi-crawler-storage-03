calute.cortex.blackscreen
=========================

.. automodule:: calute.cortex.blackscreen
    :members:
    :undoc-members:
    :show-inheritance:
