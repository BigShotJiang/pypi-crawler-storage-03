# SPDX-FileCopyrightText: 2025-present Kenji Kono <konoken@amazon.co.jp>
#
# SPDX-License-Identifier: MIT

from cdk_api_mcp_server.__about__ import __version__

__all__ = ["__version__"]
