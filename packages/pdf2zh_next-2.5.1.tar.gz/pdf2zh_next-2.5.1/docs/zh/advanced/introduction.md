### 高级选项

本节内容面向本软件的高级用户。您可以在此找到：

1. [**高级选项**](./advanced.md)
<br>
在本节中，您可以探索指定源/目标语言、切换翻译服务等高级选项。

2. [**语言代码**](./Language-Codes.md)
<br>
如果不确定源语言/目标语言应使用哪些语言代码，可在此处查询。

3. [**翻译服务文档**](./Documentation-of-Translation-Services.md)
<br>
如需查阅您所使用的翻译服务的文档，请参考此页面。

<div align="right"> 
<h6><small>本页面的部分内容由 GPT 翻译，可能包含错误。</small></h6>