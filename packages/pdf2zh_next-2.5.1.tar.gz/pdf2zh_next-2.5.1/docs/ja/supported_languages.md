> [!NOTE]
> 詳細については、[こちらをクリック](https://funstory-ai.github.io/BabelDOC/supported_languages/) して「*BabelDOC サポート言語*」ページに移動してください。記載されている情報は pdf2zh にも適用されます。

<div align="right"> 
<h6><small>このページの一部のコンテンツは GPT によって翻訳されており、エラーが含まれている可能性があります。</small></h6>