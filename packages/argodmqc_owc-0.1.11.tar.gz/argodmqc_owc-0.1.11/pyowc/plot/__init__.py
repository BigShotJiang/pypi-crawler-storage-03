"""Plotting stuff"""

from .dashboard import plot_diagnostics as dashboard
