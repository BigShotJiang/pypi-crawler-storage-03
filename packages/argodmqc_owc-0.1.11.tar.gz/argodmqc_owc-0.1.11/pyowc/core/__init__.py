"""Core functions"""
