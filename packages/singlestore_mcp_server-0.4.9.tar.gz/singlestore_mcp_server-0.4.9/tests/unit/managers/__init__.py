"""S2Manager tests module"""
