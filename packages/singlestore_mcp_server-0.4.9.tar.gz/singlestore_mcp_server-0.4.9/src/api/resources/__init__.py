from .resources import resources
from .register import register_resources

__all__ = ["resources", "register_resources"]
