#!/usr/bin/env python3
"""Entry point for ccux when run as a module."""

from .cli import app

if __name__ == "__main__":
    app()