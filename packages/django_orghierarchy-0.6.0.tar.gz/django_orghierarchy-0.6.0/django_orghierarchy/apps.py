from django.apps import AppConfig


class DjangoOrghierarchyConfig(AppConfig):
    name = "django_orghierarchy"
