# scikitplot/_datasets/__init__.py

"""_datasets."""

from .data_loader import *  # noqa: F403
