#ifndef __WIRTH_SELECT_H__
#define __WIRTH_SELECT_H__

double wirth_median(double a[], int n);

#endif
