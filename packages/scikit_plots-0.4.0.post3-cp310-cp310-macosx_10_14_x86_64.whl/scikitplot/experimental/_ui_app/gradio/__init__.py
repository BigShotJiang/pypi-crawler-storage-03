# Authors: The scikit-plots developers
# SPDX-License-Identifier: BSD-3-Clause

"""gradio UI."""
