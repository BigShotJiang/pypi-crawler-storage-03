"""
Supervised learning.

Analyze label quality and structure like Class balance, leakage, regression shape.
"""
