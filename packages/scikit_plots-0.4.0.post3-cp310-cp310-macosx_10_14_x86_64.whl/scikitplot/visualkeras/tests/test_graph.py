from ..graph import graph_view


def test_graph_view(model):
    graph_view(model)
