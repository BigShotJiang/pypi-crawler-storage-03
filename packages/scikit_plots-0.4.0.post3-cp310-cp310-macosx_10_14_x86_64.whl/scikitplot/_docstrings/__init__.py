# scikitplot/_docstrings/__init__.py

"""docstrings."""
