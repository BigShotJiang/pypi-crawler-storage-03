__all__ = ["Array", "Device", "DType"]

from torch import device as Device, dtype as DType, Tensor as Array
