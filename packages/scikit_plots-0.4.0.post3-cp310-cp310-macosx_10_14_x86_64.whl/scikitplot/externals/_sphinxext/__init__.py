# fmt: off
# ruff: noqa
# ruff: noqa: PGH004
# flake8: noqa
# pylint: skip-file
# mypy: ignore-errors
# type: ignore

# This module was copied from the matplotlib project.
# https://github.com/matplotlib/matplotlib/tree/main/lib/matplotlib/sphinxext

"""
sphinxext.

References
----------
.. [1] https://github.com/matplotlib/matplotlib/tree/main/lib/matplotlib/sphinxext
"""
