Update this directory using tools/maint_tools/vendor_array_api_extra.sh
