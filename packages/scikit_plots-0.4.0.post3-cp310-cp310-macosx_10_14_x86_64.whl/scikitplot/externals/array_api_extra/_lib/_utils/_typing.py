# numpydoc ignore=GL08
# pylint: disable=missing-module-docstring

Array = object
DType = object
Device = object
GetIndex = object
SetIndex = object

__all__ = ["Array", "DType", "Device", "GetIndex", "SetIndex"]
