from ..cexternals._astropy.utils.compat.numpycompat import *  # noqa: F403
