# scikitplot/_decorates/__init__.py

"""decorates."""

from ._decorate import *  # noqa: F403
