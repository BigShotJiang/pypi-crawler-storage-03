```bash
pip install -r requirements.txt 

MINDS_OF_TIME_SERVICE_URL=https://api.demo.multiplayer.app \
EPOCH_ENGINE_SERVICE_URL=https://api.demo.multiplayer.app \
VAULT_OF_TIME_SERVICE_URL=https://api.demo.multiplayer.app \
MULTIPLAYER_OTLP_KEY="{{TOKEN}}" \
python ./src/main.py
```
