"""
pytorch_retrieva.data
=====================

Functionality related to loading data.
"""
