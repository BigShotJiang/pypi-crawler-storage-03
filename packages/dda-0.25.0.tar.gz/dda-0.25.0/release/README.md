# Release assets

-----

This directory stores files related to building binaries and installers for each platform.
