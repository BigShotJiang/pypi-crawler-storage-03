"""Utilities and reference implementations for PSD."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from . import algorithms, functions
from .config import PSDConfig
from .feature_flags import FLAGS, FeatureFlags, disable, enable
from .graph import GraphConfig, find_optimal_path
from .log_analyzer import LogStats, analyze_log, summarize_logs
from .logging_utils import setup_logging

setup_logging()

try:  # Optional framework-specific optimisers
    from .framework_optimizers import PSDTensorFlow, PSDTorch
except Exception:  # pragma: no cover - dependencies may be missing
    PSDTorch = None  # type: ignore
    PSDTensorFlow = None  # type: ignore

try:
    __version__ = version("psd-optimizer")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "0.0.0"

__all__ = [
    "algorithms",
    "functions",
    "find_optimal_path",
    "GraphConfig",
    "PSDConfig",
    "FeatureFlags",
    "FLAGS",
    "enable",
    "disable",
    "PSDTorch",
    "PSDTensorFlow",
    "LogStats",
    "analyze_log",
    "summarize_logs",
    "__version__",
]
