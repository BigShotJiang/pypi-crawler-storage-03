from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PSDConfig:
    """Configuration for the :func:`psd.algorithms.psd` routine.

    The class validates basic constraints on the parameters to avoid
    silent misuse.  It is intentionally minimal and only captures the
    parameters used by the reference implementation.
    """

    epsilon: float
    ell: float
    rho: float
    delta: float = 0.1
    delta_f: float = 1.0
    max_iter: int = 100000

    def __post_init__(self) -> None:  # pragma: no cover - simple validation
        if self.epsilon <= 0:
            raise ValueError(
                f"epsilon must be positive (got {self.epsilon}). " "Example: PSDConfig(epsilon=1e-6, ell=1.0, rho=0.1)"
            )
        if self.ell <= 0:
            raise ValueError(f"ell must be positive (got {self.ell}). Example: ell=1.0")
        if self.rho < 0:
            raise ValueError(f"rho must be non-negative (got {self.rho}). " "Use 0.0 for no regularisation.")
        if not 0 < self.delta < 1:
            raise ValueError(f"delta must be in (0, 1), got {self.delta}. Typical choice is 0.1.")
        if self.delta_f <= 0:
            raise ValueError(f"delta_f must be positive (got {self.delta_f}). e.g., delta_f=1.0")
        if self.max_iter <= 0:
            raise ValueError(f"max_iter must be positive (got {self.max_iter}). Example: max_iter=100000.")


__all__ = ["PSDConfig"]
