def main() -> None:
    print("Hello from goat-mcp-add-server!")
