"""
constant for string options
"""

# Shape of the function
convex = "convex"
"""
Convex: convex function.
"""

concave = "concave"
"""
Concave: concave funciton.
"""

FUN_Categories = {
    convex: "convex function",
    concave: "concave funciton"
}

# Optimization
OPT_LOCAL = "local"
OPT_DEFAULT = None
