class TestBaseModule:
    def test_command(self) -> None:
        """Testing BaseModule.command"""

    def test_decorator(self) -> None:
        """Testing BaseModule.decorator"""

    def test_get_help_doc(self) -> None:
        """Testing BaseModule.get_help_doc"""

    def test_module(self) -> None:
        """Testing BaseModule.module"""

    def test_spaceworld(self) -> None:
        """Testing BaseModule.spaceworld"""

    def test_submodule(self) -> None:
        """Testing BaseModule.submodule"""
