class TestBaseCommand:
    def test__get_args_info(self) -> None:
        """Testing BaseCommand._get_args_info"""

    def test__get_options_info(self) -> None:
        """Testing BaseCommand._get_options_info"""

    def test_generate_example(self) -> None:
        """Testing BaseCommand.generate_example"""

    def test_get_help_doc(self) -> None:
        """Testing BaseCommand.get_help_doc"""

    def test_get_msg(self) -> None:
        """Testing BaseCommand.get_msg"""

    def test_run_async_command(self) -> None:
        """Testing BaseCommand.run_async_command"""
