# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

from .cli import main

if __name__ == "__main__":
    main()
