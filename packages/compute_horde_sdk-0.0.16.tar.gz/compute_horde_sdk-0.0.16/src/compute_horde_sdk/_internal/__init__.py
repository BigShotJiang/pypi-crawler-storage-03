"""
Internal implementation of compute_horde_sdk.

This project uses ApiVer, and as such, all imports should be done from v* submodules.
"""
