#!/use/bin/env python
# coding=utf-8
# @Author  : Shuhao Liu
# @Time    : 2025/6/26 15:56 
# @File    : _version.py

__version__ = '0.2.2'
