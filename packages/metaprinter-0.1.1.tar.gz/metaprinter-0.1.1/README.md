# SPSS Metadata Printer 📊

Easy-to-use Python package for extracting, viewing, and exporting metadata from SPSS files with beautiful formatting.

## ✨ Features

- 📋 **Pretty-print comprehensive SPSS metadata** to console
- 💾 **Export metadata summaries** to text files automatically saved to Downloads
- 🔄 **Support for Pandas** DataFrames
- 📊 **Detailed variable information** including labels, types, and value mappings
- 🎨 **Beautiful table formatting** with configurable width and display options

## 🚀 Installation

```bash
pip install metaprinter