__version__ = "0.1.18"

from autostore.autostore import AutoStore, AutoPath