This module allows painless [Sentry](https://sentry.io/) integration
with Odoo.
