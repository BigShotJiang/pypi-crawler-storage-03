"""The afl data sportsball module."""

# ruff: noqa: F401
from .combined.afl_combined_league_model import \
    AFLCombinedLeagueModel as AFLLeagueModel
