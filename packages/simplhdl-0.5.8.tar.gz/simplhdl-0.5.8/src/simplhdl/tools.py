from enum import StrEnum


class Tools(StrEnum):

    vcs = 'vcs'
    questasim = 'questasim'
    modelsim = 'modelsim'
    xcelium = 'xcelium'
    rivierapro = 'rivierapro'
    xsim = 'xsim'
    verilator = 'verilator'
    icarus = 'icarus'
    ghdl = 'ghdl'
    ise = 'ise'
    vivado = 'vivado'
    quartus = 'quartus'
