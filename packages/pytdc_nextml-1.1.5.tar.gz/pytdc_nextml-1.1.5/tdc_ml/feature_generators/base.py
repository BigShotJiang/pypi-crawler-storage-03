class FeatureGenerator(object):
    pass
