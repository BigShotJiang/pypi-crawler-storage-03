Overview text.
# Parameters
- **Parameter1**

    Description of Parameter1.
- **Parameter2**

    Description of Parameter2.
# Visuals
Visuals text.
# Data Recording
Data is written to **Random Directory**, which contains:
- **metadata.json**

    Metadata for this sequence step.
- **file1.txt**

    Description of file1.txt.
- **file2.txt**

    Description of file2.txt.