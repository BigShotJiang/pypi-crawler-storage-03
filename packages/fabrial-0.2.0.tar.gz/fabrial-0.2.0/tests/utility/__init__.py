"""Tests functions from `fabrial.utility`."""
