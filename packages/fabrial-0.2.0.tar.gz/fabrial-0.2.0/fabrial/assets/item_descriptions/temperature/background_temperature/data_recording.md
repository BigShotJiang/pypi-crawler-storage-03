- **{{ TEMPERATURE_FILE }}**

    The oven's temperature over time.
