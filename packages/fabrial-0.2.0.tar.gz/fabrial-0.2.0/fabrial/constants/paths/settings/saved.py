from pathlib import Path

SAVED_SETTINGS = Path("./saved_settings")
