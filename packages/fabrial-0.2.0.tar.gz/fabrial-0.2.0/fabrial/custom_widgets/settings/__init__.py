from .gamry import GamrySettingsTab
from .oven import OvenSettingsTab
from .sequence import SequenceSettingsTab
from .settings_description import SettingsDescriptionWidget
from .window import ApplicationSettingsWindow
