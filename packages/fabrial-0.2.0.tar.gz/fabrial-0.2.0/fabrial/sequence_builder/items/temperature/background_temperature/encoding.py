MEASUREMENT_INTERVAL = "Measurement Interval (ms)"
