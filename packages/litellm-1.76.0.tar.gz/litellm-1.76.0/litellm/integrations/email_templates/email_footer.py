EMAIL_FOOTER = """
<div class="footer">
            <p>© 2025 LiteLLM. All rights reserved.</p>
            <div class="social-links">
                <a href="https://twitter.com/litellm">Twitter</a> • 
                <a href="https://github.com/BerriAI/litellm">GitHub</a> • 
                <a href="https://litellm.ai">Website</a>
            </div>
</div>
"""
