from litellm.llms.base_llm.chat.transformation import BaseLLMException


class CometAPIException(BaseLLMException):
    """CometAPI exception handling class"""
    pass
