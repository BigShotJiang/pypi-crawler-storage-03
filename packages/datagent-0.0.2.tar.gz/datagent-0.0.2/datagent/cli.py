"""
Command-line interface for DataAgent package.

This module provides a CLI for interacting with the DataAgent functionality.
"""

import json
import logging
import sys
from typing import Optional

import click

from .core import DataAgent, create_agent


def setup_logging(verbose: bool = False) -> None:
    """Setup logging configuration."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)]
    )


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--config", "-c", type=click.Path(exists=True), help="Configuration file path")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, config: Optional[str]) -> None:
    """
    DataAgent CLI - A placeholder for future data agent project.
    
    This is a dummy CLI created as a placeholder for a future data agent project.
    The actual functionality will be implemented in future versions.
    """
    setup_logging(verbose)
    
    # Load configuration if provided
    config_data = {}
    if config:
        try:
            with open(config, 'r') as f:
                config_data = json.load(f)
        except Exception as e:
            click.echo(f"Error loading config file: {e}", err=True)
            sys.exit(1)
    
    ctx.ensure_object(dict)
    ctx.obj['config'] = config_data


@cli.command()
@click.pass_context
def version(ctx: click.Context) -> None:
    """Show DataAgent version information."""
    from . import __version__
    click.echo(f"DataAgent version {__version__}")
    click.echo("This is a placeholder implementation for a future data agent project.")


@cli.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show DataAgent status."""
    agent = create_agent(ctx.obj.get('config'))
    status_info = agent.get_status()
    
    click.echo("DataAgent Status:")
    click.echo(json.dumps(status_info, indent=2))


@cli.command()
@click.argument("data", required=False)
@click.pass_context
def process(ctx: click.Context, data: Optional[str]) -> None:
    """Process data using DataAgent."""
    agent = create_agent(ctx.obj.get('config'))
    
    if not data:
        data = "sample_data"
        click.echo("No data provided, using sample data")
    
    result = agent.process_data(data)
    click.echo("Processing Result:")
    click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("data", required=False)
@click.pass_context
def analyze(ctx: click.Context, data: Optional[str]) -> None:
    """Analyze data using DataAgent."""
    agent = create_agent(ctx.obj.get('config'))
    
    if not data:
        data = "sample_data"
        click.echo("No data provided, using sample data")
    
    result = agent.analyze_data(data)
    click.echo("Analysis Result:")
    click.echo(json.dumps(result, indent=2))


@cli.command()
@click.pass_context
def info(ctx: click.Context) -> None:
    """Show detailed information about DataAgent."""
    click.echo("DataAgent Information")
    click.echo("==================")
    click.echo()
    click.echo("This is a placeholder package for a future data agent project.")
    click.echo("The actual functionality will be implemented in future versions.")
    click.echo()
    click.echo("Available commands:")
    click.echo("  version  - Show version information")
    click.echo("  status   - Show current status")
    click.echo("  process  - Process data (placeholder)")
    click.echo("  analyze  - Analyze data (placeholder)")
    click.echo("  info     - Show this information")
    click.echo()
    click.echo("Example usage:")
    click.echo("  datagent version")
    click.echo("  datagent status")
    click.echo("  datagent process 'your data here'")
    click.echo("  datagent analyze 'your data here'")


def main() -> None:
    """Main entry point for the CLI."""
    try:
        cli()
    except KeyboardInterrupt:
        click.echo("\nOperation cancelled by user", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
