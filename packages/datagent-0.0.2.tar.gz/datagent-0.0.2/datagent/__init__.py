"""
DataAgent - A placeholder package for future data agent project.

This is a dummy PyPI package created as a placeholder for a future data agent project.
The actual functionality will be implemented in future versions.
"""

__version__ = "0.0.2"
__author__ = "Haris Jabbar"
__email__ = "haris.jabbar@gmail.com"

# Import main components
from .core import DataAgent

__all__ = ["DataAgent", "__version__"]
