"""
Unit tests for DataAgent core functionality.
"""

import pytest
from datagent.core import DataAgent, create_agent


class TestDataAgent:
    """Test cases for DataAgent class."""
    
    def test_init_default(self):
        """Test DataAgent initialization with default config."""
        agent = DataAgent()
        assert agent.config == {}
        assert agent.logger is not None
    
    def test_init_with_config(self):
        """Test DataAgent initialization with custom config."""
        config = {"test_key": "test_value"}
        agent = DataAgent(config=config)
        assert agent.config == config
    
    def test_process_data(self):
        """Test data processing functionality."""
        agent = DataAgent()
        test_data = "test_data"
        result = agent.process_data(test_data)
        
        assert result["status"] == "success"
        assert result["message"] == "Data processing completed (placeholder)"
        assert result["input_data"] == str(test_data)
        assert "processed_at" in result
    
    def test_analyze_data(self):
        """Test data analysis functionality."""
        agent = DataAgent()
        test_data = "test_data"
        result = agent.analyze_data(test_data)
        
        assert result["status"] == "success"
        assert result["message"] == "Data analysis completed (placeholder)"
        assert result["analysis_type"] == "placeholder"
        assert result["results"] == "No actual analysis performed in this version"
    
    def test_get_status(self):
        """Test status retrieval."""
        config = {"test_key": "test_value"}
        agent = DataAgent(config=config)
        status = agent.get_status()
        
        assert status["version"] == "0.0.2"
        assert status["status"] == "placeholder"
        assert status["config"] == config
        assert status["message"] == "This is a placeholder implementation"


class TestCreateAgent:
    """Test cases for create_agent factory function."""
    
    def test_create_agent_default(self):
        """Test create_agent with default config."""
        agent = create_agent()
        assert isinstance(agent, DataAgent)
        assert agent.config == {}
    
    def test_create_agent_with_config(self):
        """Test create_agent with custom config."""
        config = {"test_key": "test_value"}
        agent = create_agent(config=config)
        assert isinstance(agent, DataAgent)
        assert agent.config == config


class TestDataAgentIntegration:
    """Integration tests for DataAgent."""
    
    def test_full_workflow(self):
        """Test a complete workflow with DataAgent."""
        config = {"workflow": "test"}
        agent = DataAgent(config=config)
        
        # Test status
        status = agent.get_status()
        assert status["config"] == config
        
        # Test processing
        process_result = agent.process_data("workflow_test_data")
        assert process_result["status"] == "success"
        
        # Test analysis
        analysis_result = agent.analyze_data("workflow_test_data")
        assert analysis_result["status"] == "success"
    
    def test_different_data_types(self):
        """Test DataAgent with different data types."""
        agent = DataAgent()
        
        # Test with string
        result1 = agent.process_data("string_data")
        assert result1["status"] == "success"
        
        # Test with number
        result2 = agent.process_data(123)
        assert result2["status"] == "success"
        
        # Test with list
        result3 = agent.process_data([1, 2, 3])
        assert result3["status"] == "success"
        
        # Test with dict
        result4 = agent.process_data({"key": "value"})
        assert result4["status"] == "success"
