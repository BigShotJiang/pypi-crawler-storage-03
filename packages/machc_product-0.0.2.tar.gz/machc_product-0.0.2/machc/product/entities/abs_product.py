from typing import Generic, List, TypeVar, Optional

from .variant import AbstractVariant
from .product import ProductId
from .category import CategoryId

