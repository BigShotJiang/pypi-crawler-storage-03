# -*- coding: UTF-8 -*-

from dataquant.utils.client import init

init()
