# -*- coding: utf-8 -*-
from dataquant.apis.base.api import init, get_data, get_qdata
