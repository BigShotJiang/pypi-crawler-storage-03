"""BreakBuddy - A CLI tool that reminds developers to take breaks."""

__version__ = "0.1.1"
__author__ = "BreakBuddy Team"
__email__ = "team@breakbuddy.dev"

from .core import BreakBuddy
from .quotes import QuoteManager

__all__ = ["BreakBuddy", "QuoteManager"]
