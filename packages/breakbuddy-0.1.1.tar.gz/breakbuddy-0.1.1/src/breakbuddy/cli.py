"""CLI interface for BreakBuddy."""

import sys
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .config import SECURITY_CONFIG
from .core import BreakBuddy

app = typer.Typer(
    name="breakbuddy",
    help="A CLI tool that reminds developers to take breaks after a set time interval",
    add_completion=False,
)

console = Console()


def show_version(value: bool) -> None:
    """Show version information."""
    if value:
        from . import __version__

        console.print(f"[bold blue]BreakBuddy v{__version__}[/bold blue]")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None, "--version", "-v", callback=show_version, help="Show version and exit"
    ),
) -> None:
    """BreakBuddy - Take care of yourself, one break at a time! 🧘‍♂️"""
    pass


@app.command()
def once(
    duration: str = typer.Argument(
        ...,
        help="Duration to wait before showing reminder (e.g., '45m', '1h30m', '15')",
    ),
    message: Optional[str] = typer.Option(
        None, "--message", "-m", help="Custom message to display"
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        "-c",
        help="Quote category (zen, humor, focus, default)",
        case_sensitive=False,
    ),
    fancy: bool = typer.Option(
        True, "--fancy/--no-fancy", help="Use fancy formatting (default: fancy)"
    ),
) -> None:
    """Show a reminder once after a delay."""
    try:
        # SECURITY: Validate and sanitize inputs
        if message and len(message) > SECURITY_CONFIG["MAX_MESSAGE_LENGTH"]:
            console.print(
                f"[bold red]Error: Message too long (max {SECURITY_CONFIG['MAX_MESSAGE_LENGTH']} characters)[/bold red]"
            )
            sys.exit(1)

        if category and category.lower() not in ["zen", "humor", "focus", "default"]:
            console.print(
                "[bold red]Error: Invalid category. Use: "
                "zen, humor, focus, or default[/bold red]"
            )
            sys.exit(1)

        buddy = BreakBuddy(console)
        buddy.once(duration, message, category, fancy)
    except ValueError as e:
        console.print(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    except KeyboardInterrupt:
        console.print("\n[bold yellow]BreakBuddy stopped. Take care! 👋[/bold yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


@app.command()
def loop(
    every: str = typer.Option(
        ...,
        "--every",
        "-e",
        help="Interval between reminders (e.g., '45m', '1h30m', '15')",
    ),
    count: Optional[int] = typer.Option(
        None, "--count", "-n", help="Number of reminders to show"
    ),
    duration: Optional[str] = typer.Option(
        None,
        "--for",
        "-f",
        help="Total duration to run (overrides count, e.g., '2h', '90m')",
    ),
    message: Optional[str] = typer.Option(
        None, "--message", "-m", help="Custom message to display"
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        "-c",
        help="Quote category (zen, humor, focus, default)",
        case_sensitive=False,
    ),
    fancy: bool = typer.Option(
        True, "--fancy/--no-fancy", help="Use fancy formatting (default: fancy)"
    ),
) -> None:
    """Show recurring reminders at specified intervals."""
    try:
        # SECURITY: Validate and sanitize inputs
        if message and len(message) > SECURITY_CONFIG["MAX_MESSAGE_LENGTH"]:
            console.print(
                f"[bold red]Error: Message too long (max {SECURITY_CONFIG['MAX_MESSAGE_LENGTH']} characters)[/bold red]"
            )
            sys.exit(1)

        if category and category.lower() not in ["zen", "humor", "focus", "default"]:
            console.print(
                "[bold red]Error: Invalid category. Use: "
                "zen, humor, focus, or default[/bold red]"
            )
            sys.exit(1)

        # SECURITY: Prevent excessive reminder counts
        if count is not None:
            if count <= 0:
                console.print("[bold red]Error: Count must be positive[/bold red]")
                sys.exit(1)
            if count > SECURITY_CONFIG["MAX_REMINDER_COUNT"]:
                console.print(
                    f"[bold red]Error: Count too high (max {SECURITY_CONFIG['MAX_REMINDER_COUNT']} "
                    "reminders)[/bold red]"
                )
                sys.exit(1)

        buddy = BreakBuddy(console)
        buddy.loop(every, count, duration, message, category, fancy)
    except ValueError as e:
        console.print(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    except KeyboardInterrupt:
        console.print("\n[bold yellow]BreakBuddy stopped. Take care! 👋[/bold yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


@app.command()
def categories() -> None:
    """Show available quote categories."""
    buddy = BreakBuddy(console)
    categories_list = buddy.quote_manager.get_categories()

    console.print("[bold blue]Available quote categories:[/bold blue]")
    for category in categories_list:
        console.print(f"  • [green]{category}[/green]")


@app.command()
def quote(
    category: Optional[str] = typer.Option(
        None,
        "--category",
        "-c",
        help="Quote category (zen, humor, focus, default)",
        case_sensitive=False,
    ),
    fancy: bool = typer.Option(
        True, "--fancy/--no-fancy", help="Use fancy formatting (default: fancy)"
    ),
) -> None:
    """Show a random quote immediately."""
    try:
        # SECURITY: Validate category input
        if category and category.lower() not in ["zen", "humor", "focus", "default"]:
            console.print(
                "[bold red]Error: Invalid category. Use: zen, humor, focus, or default[/bold red]"
            )
            sys.exit(1)

        buddy = BreakBuddy(console)
        buddy.show_reminder(category=category, fancy=fancy)
    except Exception as e:
        console.print(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


@app.command()
def demo() -> None:
    """Show a demo of BreakBuddy's capabilities."""
    console.print(
        Panel(
            Text(
                "🚀 Welcome to BreakBuddy!\n\n"
                "Take care of yourself with timely break reminders.\n\n"
                "Try these commands:\n"
                "• breakbuddy once 30s\n"
                "• breakbuddy loop --every 45m\n"
                "• breakbuddy quote --category zen\n"
                "• breakbuddy categories",
                justify="center",
            ),
            title="🎯 BreakBuddy Demo",
            border_style="green",
            padding=(1, 2),
        )
    )


def main_cli() -> None:
    """Main CLI entry point."""
    try:
        app()
    except Exception as e:
        console.print(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


if __name__ == "__main__":
    main_cli()
