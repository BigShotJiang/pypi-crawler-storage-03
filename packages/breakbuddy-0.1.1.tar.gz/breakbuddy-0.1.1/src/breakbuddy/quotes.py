"""Quote management for BreakBuddy."""

import random
from typing import Dict, List, Optional

# SECURITY: Import security constants
from .config import SECURITY_CONFIG


class QuoteManager:
    """Manages motivational quotes for different categories."""

    def __init__(self) -> None:
        """Initialize the quote manager with predefined quotes."""
        self._quotes: Dict[str, List[str]] = {
            "zen": [
                "A calm mind brings power.",
                "The mind is everything. What you think you become.",
                "Peace comes from within. Do not seek it without.",
                "Happiness is not something ready-made. It comes from your own actions.",
                "Three things cannot be long hidden: the sun, the moon, and the truth.",
                "You yourself, as much as anybody in the entire universe, deserve your love and affection.",
                "The only way to do great work is to love what you do.",
                "Simplicity is the ultimate sophistication.",
                "The journey of a thousand miles begins with one step.",
                "Patience is bitter, but its fruit is sweet.",
            ],
            "humor": [
                "Time flies like an arrow. Fruit flies like a banana.",
                "Why do programmers prefer dark mode? Because light attracts bugs!",
                "A computer is like air conditioning - it becomes useless when you open Windows.",
                "Why don't scientists trust atoms? Because they make up everything!",
                "I'm reading a book about anti-gravity. It's impossible to put down!",
                "Why did the scarecrow win an award? He was outstanding in his field!",
                "What do you call a fake noodle? An impasta!",
                "Why don't eggs tell jokes? They'd crack each other up!",
                "What do you call a bear with no teeth? A gummy bear!",
                "Why don't skeletons fight each other? They don't have the guts!",
            ],
            "focus": [
                (
                    "Focus is not about saying yes to the things you've got to focus on, "
                    "but saying no to the hundred other good ideas."
                ),
                "The successful warrior is the average man, with laser-like focus.",
                (
                    "Concentrate all your thoughts upon the work at hand. The sun's rays "
                    "do not burn until brought to a focus."
                ),
                "Focus is a matter of deciding what things you're not going to do.",
                (
                    "The key to success is to focus our conscious mind on things we desire, "
                    "not things we fear."
                ),
                "Where focus goes, energy flows.",
                "The more you focus on time, the more time seems to pass.",
                "Focus on being productive instead of busy.",
                (
                    "Success is no accident. It is hard work, perseverance, learning, studying, "
                    "sacrifice and most of all, love of what you are doing."
                ),
                "The only limit to your impact is your imagination and commitment.",
            ],
            "default": [
                "Time for a stretch!",
                "Take a moment to breathe.",
                "Your brain needs a break too!",
                "Step away from the screen.",
                "Time to refuel your creativity.",
                "A short break can lead to big ideas.",
                "Rest is not idleness, it's essential.",
                "Your future self will thank you for this break.",
                "Small breaks, big results.",
                "Recharge and return stronger.",
            ],
        }

    def get_random_quote(self, category: Optional[str] = None) -> str:
        """Get a random quote from the specified category.

        Args:
            category: The quote category. If None, uses 'default'.

        Returns:
            A random quote string.
        """
        if category is None or category not in self._quotes:
            selected_category = "default"
        else:
            selected_category = category

        return random.choice(self._quotes[selected_category])

    def get_categories(self) -> List[str]:
        """Get list of available quote categories.

        Returns:
            List of category names.
        """
        return list(self._quotes.keys())

    def get_quotes_for_category(self, category: str) -> List[str]:
        """Get all quotes for a specific category.

        Args:
            category: The quote category.

        Returns:
            List of quotes for the category.

        Raises:
            KeyError: If category doesn't exist.
        """
        if category not in self._quotes:
            raise KeyError(f"Category '{category}' not found")

        return self._quotes[category].copy()

    def add_quote(self, category: str, quote: str) -> None:
        """Add a new quote to a category.

        Args:
            category: The quote category.
            quote: The quote text to add.
        """
        # SECURITY: Validate inputs
        if not isinstance(category, str) or not isinstance(quote, str):
            raise ValueError("Category and quote must be strings")

        if len(category) > SECURITY_CONFIG["MAX_CATEGORY_LENGTH"]:
            raise ValueError(
                f"Category name too long (max {SECURITY_CONFIG['MAX_CATEGORY_LENGTH']} characters)"
            )

        if len(quote) > SECURITY_CONFIG["MAX_QUOTE_LENGTH"]:
            raise ValueError(
                f"Quote too long (max {SECURITY_CONFIG['MAX_QUOTE_LENGTH']} characters)"
            )

        if not category.strip() or not quote.strip():
            raise ValueError("Category and quote cannot be empty")

        # SECURITY: Sanitize inputs
        category = category.strip().lower()
        quote = quote.strip()

        # SECURITY: Additional validation - prevent dangerous characters
        dangerous_chars = ["/", "\\", ":", "*", "?", '"', "<", ">", "|", ".."]
        if any(char in category for char in dangerous_chars):
            raise ValueError("Category contains invalid characters")

        if category not in self._quotes:
            self._quotes[category] = []

        self._quotes[category].append(quote)

    def remove_quote(self, category: str, quote: str) -> bool:
        """Remove a quote from a category.

        Args:
            category: The quote category.
            quote: The quote text to remove.

        Returns:
            True if quote was removed, False if not found.
        """
        if not category.strip() or not quote.strip():
            return False

        # SECURITY: Sanitize inputs
        category = category.strip().lower()
        quote = quote.strip()

        if category not in self._quotes:
            return False

        try:
            self._quotes[category].remove(quote)
        except ValueError:
            return False
        else:
            return True
