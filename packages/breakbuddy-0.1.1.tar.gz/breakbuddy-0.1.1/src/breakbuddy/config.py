"""Project-wide configuration and security constants."""

SECURITY_CONFIG = {
    "MAX_DURATION_STRING_LENGTH": 50,
    "MAX_MESSAGE_LENGTH": 500,
    "MAX_CATEGORY_LENGTH": 50,
    "MAX_QUOTE_LENGTH": 500,
    "MAX_MINUTES": 525600,  # 1 year
    "MAX_HOURS": 8760,  # 1 year
    "MAX_SECONDS": 31536000,  # 1 year
    "MAX_REMINDER_COUNT": 1000,
    "MIN_INTERVAL_SECONDS": 1,  # Minimum interval between reminders
    "MAX_ITERATIONS": 10000,  # Maximum iterations to prevent infinite loops
}
