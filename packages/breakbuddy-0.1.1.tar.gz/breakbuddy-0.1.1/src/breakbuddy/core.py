"""Core functionality for BreakBuddy."""

import re
import signal
import sys
import time
from types import FrameType
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .config import SECURITY_CONFIG
from .quotes import QuoteManager

# SECURITY: constants moved to config module


class BreakBuddy:
    """Main BreakBuddy class for managing break reminders."""

    def __init__(self, console: Optional[Console] = None) -> None:
        """Initialize BreakBuddy.

        Args:
            console: Rich console instance. If None, creates a new one.
        """
        self.console = console or Console()
        self.quote_manager = QuoteManager()
        self._running = False
        self._setup_signal_handlers()

    def _setup_signal_handlers(self) -> None:
        """Set up signal handlers for graceful shutdown."""
        try:
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)
        except (OSError, ValueError) as e:
            # SECURITY: Handle signal setup errors gracefully
            self.console.print(
                f"[bold red]Warning: Could not set up signal handlers: {e}[/bold red]"
            )

    def _signal_handler(self, signum: int, frame: Optional[FrameType]) -> None:
        """Handle interrupt signals gracefully.

        Args:
            signum: Signal number.
            frame: Current stack frame.
        """
        try:
            self._running = False
            self.console.print(
                "\n[bold yellow]BreakBuddy stopped. Take care! 👋[/bold yellow]"
            )
            # SECURITY: Use os._exit instead of sys.exit for signal handlers
            import os

            os._exit(0)
        except Exception:
            # SECURITY: Ensure we always exit, even if there's an error
            import os

            os._exit(1)

    def parse_duration(self, duration_str: str) -> int:
        """Parse duration string into seconds.

        Args:
            duration_str: Duration string (e.g., '45m', '1h30m', '15').

        Returns:
            Duration in seconds.

        Raises:
            ValueError: If duration string is invalid or exceeds limits.
        """
        if not duration_str:
            raise ValueError("Duration string cannot be empty")

        # SECURITY: Prevent extremely long strings that could cause DoS
        if len(duration_str) > SECURITY_CONFIG["MAX_DURATION_STRING_LENGTH"]:
            raise ValueError(
                f"Duration string too long (max {SECURITY_CONFIG['MAX_DURATION_STRING_LENGTH']} characters)"
            )

        # SECURITY: Prevent extremely large numbers that could cause integer overflow
        MAX_MINUTES = SECURITY_CONFIG["MAX_MINUTES"]
        MAX_HOURS = SECURITY_CONFIG["MAX_HOURS"]
        MAX_SECONDS = SECURITY_CONFIG["MAX_SECONDS"]

        # Handle simple number (assumed to be minutes)
        if duration_str.isdigit():
            try:
                value = int(duration_str)
                if value == 0:
                    raise ValueError("Duration cannot be zero")
                if value > MAX_MINUTES:
                    raise ValueError(f"Duration too long (max {MAX_MINUTES} minutes)")
                return value * 60
            except (ValueError, OverflowError):
                raise ValueError("Invalid duration value")

        # Handle complex formats like '1h30m', '45m', '30s'
        total_seconds = 0
        pattern = r"(\d+)([hms])"
        matches = re.findall(pattern, duration_str.lower())

        if not matches:
            raise ValueError(f"Invalid duration format: {duration_str}")

        for value, unit in matches:
            try:
                value_int = int(value)
                if value_int == 0:
                    raise ValueError("Duration values cannot be zero")

                # SECURITY: Apply limits based on unit
                if unit == "h":
                    if value_int > MAX_HOURS:
                        raise ValueError(f"Hours too long (max {MAX_HOURS} hours)")
                    total_seconds += value_int * 3600
                elif unit == "m":
                    if value_int > MAX_MINUTES:
                        raise ValueError(
                            f"Minutes too long (max {MAX_MINUTES} minutes)"
                        )
                    total_seconds += value_int * 60
                elif unit == "s":
                    if value_int > MAX_SECONDS:
                        raise ValueError(
                            f"Seconds too long (max {MAX_SECONDS} seconds)"
                        )
                    total_seconds += value_int

                # SECURITY: Check for integer overflow
                if total_seconds > MAX_SECONDS:
                    raise ValueError(
                        f"Total duration too long (max {MAX_SECONDS} seconds)"
                    )

            except (ValueError, OverflowError):
                raise ValueError(f"Invalid duration value: {value}")

        if total_seconds == 0:
            raise ValueError(f"Invalid duration format: {duration_str}")

        return total_seconds

    def format_duration(self, seconds: int) -> str:
        """Format seconds into human-readable duration.

        Args:
            seconds: Duration in seconds.

        Returns:
            Formatted duration string.
        """
        if seconds < 60:
            return f"{seconds}s"
        elif seconds < 3600:
            minutes = seconds // 60
            remaining_seconds = seconds % 60
            if remaining_seconds == 0:
                return f"{minutes}m"
            else:
                return f"{minutes}m{remaining_seconds}s"
        else:
            hours = seconds // 3600
            remaining_minutes = (seconds % 3600) // 60
            if remaining_minutes == 0:
                return f"{hours}h"
            else:
                return f"{hours}h{remaining_minutes}m"

    def show_reminder(
        self,
        message: Optional[str] = None,
        category: Optional[str] = None,
        fancy: bool = True,
    ) -> None:
        """Show a break reminder.

        Args:
            message: Custom message to display.
            category: Quote category for the reminder.
            fancy: Whether to use fancy formatting.
        """
        if message is None:
            message = self.quote_manager.get_random_quote(category)

        if fancy:
            # Create a fancy panel with emojis
            emoji = "⏰"
            title = f"{emoji} Break Time!"

            panel = Panel(
                Text(message, justify="center"),
                title=title,
                border_style="blue",
                padding=(1, 2),
                title_align="center",
            )
            self.console.print(panel)
        else:
            # Simple text output
            self.console.print(f"⏰ {message}")

    def once(
        self,
        duration: str,
        message: Optional[str] = None,
        category: Optional[str] = None,
        fancy: bool = True,
    ) -> None:
        """Show a reminder once after a delay.

        Args:
            duration: Duration to wait before showing reminder.
            message: Custom message to display.
            category: Quote category for the reminder.
            fancy: Whether to use fancy formatting.
        """
        seconds = self.parse_duration(duration)
        formatted_duration = self.format_duration(seconds)

        self.console.print(
            f"[bold blue]⏳ BreakBuddy will remind you in {formatted_duration}...[/bold blue]"
        )

        try:
            time.sleep(seconds)
            self.show_reminder(message, category, fancy)
        except KeyboardInterrupt:
            self.console.print(
                "\n[bold yellow]BreakBuddy stopped. Take care! 👋[/bold yellow]"
            )
            sys.exit(0)

    def loop(
        self,
        interval: str,
        count: Optional[int] = None,
        duration: Optional[str] = None,
        message: Optional[str] = None,
        category: Optional[str] = None,
        fancy: bool = True,
    ) -> None:
        """Show recurring reminders at specified intervals.

        Args:
            interval: Time interval between reminders.
            count: Number of reminders to show (None for infinite).
            duration: Total duration to run (overrides count).
            message: Custom message to display.
            category: Quote category for the reminder.
            fancy: Whether to use fancy formatting.
        """
        interval_seconds = self.parse_duration(interval)

        # SECURITY: CRITICAL FIX - Prevent extremely small intervals that cause DoS
        MIN_INTERVAL_SECONDS = SECURITY_CONFIG["MIN_INTERVAL_SECONDS"]
        if interval_seconds < MIN_INTERVAL_SECONDS:
            raise ValueError(
                f"Interval too short (minimum {MIN_INTERVAL_SECONDS} second)"
            )

        # SECURITY: CRITICAL FIX - Prevent excessive iterations that cause memory exhaustion
        MAX_ITERATIONS = SECURITY_CONFIG["MAX_ITERATIONS"]
        if count is None and duration is None:
            # If no count/duration specified, limit to reasonable maximum
            count = MAX_ITERATIONS
            self.console.print(
                f"[bold yellow]⚠️  No count/duration specified. Limiting to {MAX_ITERATIONS} "
                f"reminders for safety.[/bold yellow]"
            )

        formatted_interval = self.format_duration(interval_seconds)

        if duration:
            total_seconds = self.parse_duration(duration)
            count = total_seconds // interval_seconds
            # SECURITY: Ensure count doesn't exceed maximum
            if count > MAX_ITERATIONS:
                count = MAX_ITERATIONS
                self.console.print(
                    f"[bold yellow]⚠️  Duration too long. Limiting to {MAX_ITERATIONS} "
                    f"reminders for safety.[/bold yellow]"
                )

            self.console.print(
                f"[bold blue]⏳ BreakBuddy will remind you every {formatted_interval} "
                f"for {self.format_duration(total_seconds)} ({count} reminders)...[/bold blue]"
            )
        elif count:
            # SECURITY: Ensure count doesn't exceed maximum
            if count > MAX_ITERATIONS:
                count = MAX_ITERATIONS
                self.console.print(
                    f"[bold yellow]⚠️  Count too high. Limiting to {MAX_ITERATIONS} "
                    f"reminders for safety.[/bold yellow]"
                )

            self.console.print(
                f"[bold blue]⏳ BreakBuddy will remind you every {formatted_interval} "
                f"({count} times)...[/bold blue]"
            )
        else:
            self.console.print(
                f"[bold blue]⏳ BreakBuddy will remind you every {formatted_interval} "
                f"(press Ctrl+C to stop)...[/bold blue]"
            )

        self._running = True
        reminder_count = 0

        try:
            while self._running:
                if count and reminder_count >= count:
                    break

                # SECURITY: Additional safety check to prevent runaway loops
                if reminder_count >= MAX_ITERATIONS:
                    self.console.print(
                        f"[bold red]⚠️  Safety limit reached ({MAX_ITERATIONS} reminders). Stopping.[/bold red]"
                    )
                    break

                time.sleep(interval_seconds)
                reminder_count += 1

                if self._running:  # Check again after sleep
                    self.show_reminder(message, category, fancy)

                    if count and reminder_count < count:
                        remaining = count - reminder_count
                        self.console.print(
                            f"[dim]📊 {remaining} reminder{'s' if remaining != 1 else ''} remaining[/dim]"
                        )

        except KeyboardInterrupt:
            self.console.print(
                "\n[bold yellow]BreakBuddy stopped. Take care! 👋[/bold yellow]"
            )
            sys.exit(0)

    def stop(self) -> None:
        """Stop the running reminder loop."""
        self._running = False
