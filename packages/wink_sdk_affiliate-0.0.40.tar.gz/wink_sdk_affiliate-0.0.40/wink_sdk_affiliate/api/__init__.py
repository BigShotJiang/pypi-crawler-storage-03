# flake8: noqa

# import apis into api package
from wink_sdk_affiliate.api.account_manager_api import AccountManagerApi
from wink_sdk_affiliate.api.affiliate_api import AffiliateApi

