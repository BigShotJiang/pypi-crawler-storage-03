===============================
glider_client
===============================

By: chiesa 
Date: October 29, 2024
Copyright Alpes Lasers SA, Neuchatel, Switzerland

Client library for Alpes Lasers external cavity system.

Usage
-----

See the "scripts" folder in the package.
