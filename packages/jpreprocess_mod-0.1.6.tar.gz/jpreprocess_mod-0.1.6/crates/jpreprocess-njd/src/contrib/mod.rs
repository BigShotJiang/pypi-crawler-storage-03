//! NJD modifiers added by jpreprocess

pub mod currency;
