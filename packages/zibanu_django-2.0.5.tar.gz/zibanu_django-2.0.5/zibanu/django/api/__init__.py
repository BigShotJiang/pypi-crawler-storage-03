# -*- coding: utf-8 -*-

# ****************************************************************
# IDE:          PyCharm
# Developed by: macercha
# Date:         7/07/23 7:30
# Project:      Zibanu - Django
# Module Name:  __init__.py
# Description:
# ****************************************************************
