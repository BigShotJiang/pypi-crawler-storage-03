"""Speedi – A typed, stateful, high-performance CLI framework for Python.

Public API:
- App: main application and command registry
- session: global Session instance
- parallel: simple concurrency primitive for running tasks in parallel
- validate_args: runtime validation stub (Satya-ready)
"""
from .app import App
from .session import session, Session
from .concurrency import parallel
from .validation import validate_args
from .output import echo, info, success, warning, error
from .shell import shell, shell_py, shell_rs, CmdResult

__all__ = [
    "App",
    "Session",
    "session",
    "parallel",
    "validate_args",
    "echo",
    "info",
    "success",
    "warning",
    "error",
    "shell",
    "shell_py",
    "shell_rs",
    "CmdResult",
]
