from __future__ import annotations

"""Optional Rust core bridge.

If the compiled extension `speedi_core` is available, import and expose minimal
bindings. Otherwise, provide pure-Python fallbacks.
"""

try:  # pragma: no cover - availability depends on build
    import speedi_core  # type: ignore
except Exception:  # noqa: BLE001
    speedi_core = None  # type: ignore


def has_rust_core() -> bool:
    return speedi_core is not None
