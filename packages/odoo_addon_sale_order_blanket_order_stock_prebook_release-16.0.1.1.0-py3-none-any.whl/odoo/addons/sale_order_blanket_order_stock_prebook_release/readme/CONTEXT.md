When a call-off order is confirmed for a product, the priority date used to compute the quantity available at promised date must be the start date of the blanket order.

This is required to ensure that the principle of first-come, first-served is respected. 
In the case of a product part of a blanket order the date to consider must be the start date of the blanket order and not the date of the call-off order.