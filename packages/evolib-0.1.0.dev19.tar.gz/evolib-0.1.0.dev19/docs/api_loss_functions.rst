Lossfunctions
===================

.. automodule:: evolib.utils.loss_functions
   :members:
   :undoc-members:
   :show-inheritance:
