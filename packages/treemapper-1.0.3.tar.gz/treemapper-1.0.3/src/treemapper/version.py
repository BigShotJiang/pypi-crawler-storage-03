__version__ = "1.0.3"  # This will be replaced during the build process
