# Example Integration Tests (Stub)

Integration tests for external boundaries (DB, HTTP, queues). Configure testcontainers/mocks when services exist.
