from enum import Enum
 
class ResponseStatusType(Enum):
    OK = 0
    HTTP = 1
    INTERNAL = 2
