from rest_framework import serializers
from ..models import Project, Organization
from django.contrib.auth import get_user_model

User = get_user_model()


class ProjectSerializer(serializers.ModelSerializer):
    organization = serializers.PrimaryKeyRelatedField(queryset=Organization.objects.all())
    users = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), many=True, required=False)

    class Meta:
        model = Project
        fields = ['id', 'name', 'description', 'organization', 'users', 'created', 'last_update']
        read_only_fields = ['id', 'created', 'last_update']
