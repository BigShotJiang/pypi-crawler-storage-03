from rest_framework import serializers
from ..models import User, Organization


class UserSerializer(serializers.ModelSerializer):
    organizations = serializers.PrimaryKeyRelatedField(queryset=Organization.objects.all(), many=True, required=False)

    class Meta:
        model = User
        fields = ['id', 'email', 'first_name', 'last_name', 'organizations', 'is_active', 'is_staff']
        read_only_fields = ['id', 'is_active', 'is_staff']
