from django.conf import settings
from django.contrib import admin
from django.utils.html import format_html
from django.utils.safestring import mark_safe
import csv
import json
from django.http import HttpResponse
from datetime import datetime
from .models import Organization, Project, User, ApplicationLog
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.contrib import messages


def redirect_to_password_change(modeladmin, request, queryset):
    if queryset.count() != 1:
        messages.warning(request, "Selecione apenas um usuário para trocar a senha.")
        return

    user = queryset.first()
    app_label = user._meta.app_label
    model_name = user._meta.model_name

    try:
        url = reverse(f'admin:{app_label}_{model_name}_password_change', args=[user.pk])
        return HttpResponseRedirect(url)
    except Exception as e:
        messages.error(request, f"Erro ao redirecionar para troca de senha: {e}")
        return


redirect_to_password_change.short_description = "Trocar senha do usuário selecionado"


# Registro do modelo Organization no admin
@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'created')  # Campos a serem exibidos na listagem
    search_fields = ('name', 'description')  # Campos para buscar no painel admin
    ordering = ('name',)  # Ordenação padrão
    list_filter = ('created',)  # Filtro no painel admin


# Registro do modelo Project no admin
@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    """
    Configuração do Django Admin para o modelo Project.
    Adiciona dinamicamente os campos definidos no settings.PROJECT_CUSTOM_FIELDS.
    """
    # Campos fixos a serem exibidos na listagem
    base_list_display = ['name', 'organization', 'created', 'last_update']

    # Adicionando dinamicamente os campos definidos no settings.py
    custom_fields = getattr(settings, "PROJECT_CUSTOM_FIELDS", [])
    dynamic_list_display = [field["name"] for field in custom_fields]

    list_display = base_list_display + dynamic_list_display
    search_fields = ('name', 'organization__name') + tuple(dynamic_list_display)
    list_filter = ('created', 'last_update', 'organization') + tuple(dynamic_list_display)

    # Configuração do formulário de edição
    base_fields = ('name', 'description', 'organization', 'users')
    fieldsets = [(None, {'fields': base_fields})]

    if custom_fields:
        dynamic_fields = [field["name"] for field in custom_fields]
        fieldsets.append(("Campos Personalizados", {'fields': dynamic_fields}))


# Registro do modelo User no admin
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('email', 'first_name', 'last_name', 'is_active', 'is_staff')  # Campos a serem exibidos na listagem
    search_fields = ('email', 'first_name', 'last_name')  # Campos para busca
    list_filter = ('is_active', 'is_staff', 'organizations')  # Filtros para facilitar a busca
    ordering = ('email',)  # Ordenação padrão
    actions = [redirect_to_password_change]


# Admin Model dos Logs

@admin.register(ApplicationLog)
class ApplicationLogAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'log_type_colored', 'source', 'user', 'ip_address', 'short_message', 'has_details')
    list_filter = ('log_type', 'source', 'timestamp', 'method')
    search_fields = ('message', 'user', 'ip_address', 'url_path', 'source')
    readonly_fields = (
        'id', 'timestamp', 'log_type', 'source', 'user',
        'ip_address', 'url_path', 'method', 'user_agent',
        'message', 'formatted_details'
    )
    date_hierarchy = 'timestamp'
    list_per_page = 50

    def get_queryset(self, request):
        return super().get_queryset(request).select_related()

    def has_add_permission(self, request):
        # Desabilita a adição manual de logs via admin
        return False

    def has_change_permission(self, request, obj=None):
        # Desabilita a edição de logs
        return False

    def short_message(self, obj):
        if len(obj.message) > 100:
            return f"{obj.message[:100]}..."
        return obj.message

    short_message.short_description = "Mensagem"

    def log_type_colored(self, obj):
        colors = {
            'INFO': '#28a745',  # Verde
            'WARNING': '#ffc107',  # Amarelo
            'ERROR': '#dc3545',  # Vermelho
            'CRITICAL': '#9c27b0',  # Roxo
            'DEBUG': '#17a2b8',  # Azul claro
            'ACCESS': '#007bff',  # Azul
        }

        color = colors.get(obj.log_type, '#6c757d')  # Cinza como padrão
        return format_html(
            '<span style="color: white; background-color: {}; padding: 3px 7px; border-radius: 3px;">{}</span>',
            color, obj.log_type
        )

    log_type_colored.short_description = "Tipo"

    def has_details(self, obj):
        return obj.details is not None and obj.details != {}

    has_details.boolean = True
    has_details.short_description = "Detalhes"

    def formatted_details(self, obj):
        if not obj.details:
            return "-"

        try:
            # Formata o JSON para exibição
            formatted_json = json.dumps(obj.details, indent=2, ensure_ascii=False)
            # Retorna como um elemento <pre> com estilo para melhor visualização
            return mark_safe(
                f'<pre style="background-color: #f8f9fa; padding: 10px; border-radius: 5px; max-height: 400px; '
                f'overflow: auto;">{formatted_json}</pre>')
        except:
            return str(obj.details)

    formatted_details.short_description = "Detalhes Formatados"

    fieldsets = (
        ('Informações Básicas', {
            'fields': ('id', 'timestamp', 'log_type', 'source', 'message')
        }),
        ('Usuário e Acesso', {
            'fields': ('user', 'ip_address', 'url_path', 'method', 'user_agent'),
            'classes': ('collapse',),
        }),
        ('Detalhes Adicionais', {
            'fields': ('formatted_details',),
            'classes': ('collapse',),
        }),
    )

    actions = ['export_as_csv']

    def export_as_csv(self, request, queryset):

        meta = self.model._meta
        field_names = [field.name for field in meta.fields if field.name != 'details']

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename=logs-{datetime.now().strftime("%Y%m%d-%H%M%S")}.csv'

        writer = csv.writer(response)
        writer.writerow(field_names)
        for obj in queryset:
            row = []
            for field in field_names:
                value = getattr(obj, field)
                row.append(str(value))
            writer.writerow(row)

        return response

    export_as_csv.short_description = "Exportar logs selecionados como CSV"

