import uuid
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils.translation import gettext_lazy as _


class CustomUserManager(BaseUserManager):
    """Manager customizado para o modelo de usuário."""

    def create_user(self, email, password=None, **extra_fields):
        """
        Cria e salva um usuário com o email e senha fornecidos.
        """
        if not email:
            raise ValueError(_("O campo Email deve ser definido"))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """
        Cria e salva um superusuário com o email e senha fornecidos.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if not extra_fields.get('is_staff'):
            raise ValueError(_('Superusuário deve ter is_staff=True.'))
        if not extra_fields.get('is_superuser'):
            raise ValueError(_('Superusuário deve ter is_superuser=True.'))

        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """
    Modelo de usuário customizado que usa email como identificador único.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )
    email = models.EmailField(
        _("endereço de email"),
        unique=True
    )
    first_name = models.CharField(
        _("primeiro nome"),
        max_length=150,
        blank=True
    )
    last_name = models.CharField(
        _("sobrenome"),
        max_length=150,
        blank=True
    )
    organizations = models.ManyToManyField(
        'Organization',
        verbose_name=_("organizações"),
        blank=True,
        related_name='users'
    )
    is_active = models.BooleanField(
        _("ativo"),
        default=True
    )
    is_staff = models.BooleanField(
        _("staff"),
        default=False
    )

    # Adicionando o related_name para evitar o conflito com o modelo auth.User
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_groups',  # Nome único para o grupo
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_permissions',  # Nome único para as permissões
        blank=True
    )

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    class Meta:
        verbose_name = _("usuário")
        verbose_name_plural = _("usuários")

    def __str__(self):
        return self.email
