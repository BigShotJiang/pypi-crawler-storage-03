from django.db import models
from django.utils import timezone
import uuid


class ApplicationLog(models.Model):
    """
    Modelo para armazenar logs de acesso e erros da aplicação
    """
    LOG_TYPES = (
        ('INFO', 'Informação'),
        ('WARNING', 'Aviso'),
        ('ERROR', 'Erro'),
        ('CRITICAL', 'Crítico'),
        ('DEBUG', 'Depuração'),
        ('ACCESS', 'Acesso'),
    )

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    timestamp = models.DateTimeField(default=timezone.now, db_index=True)
    log_type = models.CharField(max_length=10, choices=LOG_TYPES, db_index=True)
    source = models.CharField(max_length=255, blank=True, help_text="Módulo ou componente de origem")
    user = models.CharField(max_length=255, blank=True, null=True, help_text="Usuário relacionado ao evento")
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    url_path = models.CharField(max_length=500, blank=True, null=True)
    method = models.CharField(max_length=10, blank=True, null=True, help_text="GET, POST, etc.")
    user_agent = models.TextField(blank=True, null=True)
    message = models.TextField()
    details = models.JSONField(blank=True, null=True, help_text="Detalhes adicionais em formato JSON")

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['log_type', 'timestamp']),
            models.Index(fields=['source', 'timestamp']),
        ]
        verbose_name = "Log de Aplicação"
        verbose_name_plural = "Logs de Aplicação"

    def __str__(self):
        return f"{self.timestamp} - {self.log_type}: {self.message[:50]}"
