import uuid
from django.db import models
from django.utils.translation import gettext_lazy as _


class Organization(models.Model):
    """
    Modelo para representar uma organização.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )
    name = models.CharField(
        _("nome"),
        max_length=255
    )
    description = models.TextField(
        _("descrição"),
        blank=True,
        null=True
    )
    created = models.DateTimeField(
        _("data de criação"),
        auto_now_add=True
    )

    class Meta:
        verbose_name = _("organização")
        verbose_name_plural = _("organizações")
        ordering = ['name']

    def __str__(self):
        return self.name
