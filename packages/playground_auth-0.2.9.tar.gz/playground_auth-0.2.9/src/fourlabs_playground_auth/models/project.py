import uuid
from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _


class Project(models.Model):
    """
    Modelo para representar um projeto, permitindo campos de links dinâmicos definidos pelo usuário.
    """

    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )
    name = models.CharField(
        _("nome"),
        max_length=255
    )
    description = models.TextField(
        _("descrição"),
        blank=True,
        null=True
    )
    organization = models.ForeignKey(
        'Organization',
        verbose_name=_("organização"),
        on_delete=models.CASCADE,
        related_name='projects'
    )
    users = models.ManyToManyField(
        'User',
        verbose_name=_("usuários"),
        blank=True,
        related_name='projects'
    )
    created = models.DateTimeField(
        _("data de criação"),
        auto_now_add=True
    )
    last_update = models.DateTimeField(
        _("última atualização"),
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = _("projeto")
        verbose_name_plural = _("projetos")
        ordering = ['name']

    def __str__(self):
        return f"Projeto {self.name} | {self.organization.name}"

    # Adicionando os campos dinâmicos na classe
    @classmethod
    def _add_custom_fields(cls):
        """
        Adiciona dinamicamente os campos definidos em settings.PROJECT_CUSTOM_FIELDS.
        """
        custom_fields = getattr(settings, "PROJECT_CUSTOM_FIELDS", [])

        for field_config in custom_fields:
            field_name = field_config["name"]
            field_type = field_config.get("type", "CharField")
            verbose_name = field_config.get("verbose_name", field_name.replace("_", " ").title())
            params = field_config.get("params", {})  # Parâmetros adicionais do campo

            # Definição dos tipos de campos suportados
            field_mapping = {
                "CharField": models.CharField(_(verbose_name), max_length=params.get("max_length", 255), blank=True, null=True),
                "IntegerField": models.IntegerField(_(verbose_name), blank=True, null=True),
                "FloatField": models.FloatField(_(verbose_name), blank=True, null=True),
                "BooleanField": models.BooleanField(_(verbose_name), default=params.get("default", False)),
                "DateField": models.DateField(_(verbose_name), blank=True, null=True),
                "DateTimeField": models.DateTimeField(_(verbose_name), blank=True, null=True),
                "EmailField": models.EmailField(_(verbose_name), blank=True, null=True),
                "TextField": models.TextField(_(verbose_name), blank=True, null=True),
                "URLField": models.URLField(_(verbose_name), blank=True, null=True),
                "JSONField": models.JSONField(_(verbose_name), blank=True, null=True),
            }

            if field_type not in field_mapping:
                raise ValueError(f"Tipo de campo '{field_type}' não suportado!")

            field = field_mapping[field_type]
            field.contribute_to_class(cls, field_name)

# Executa a adição dos campos dinâmicos
Project._add_custom_fields()
