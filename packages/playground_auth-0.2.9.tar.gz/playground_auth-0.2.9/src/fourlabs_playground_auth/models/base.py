from django.db import models
from django.utils.translation import gettext_lazy as _


class TimeStampedModel(models.Model):
    """Modelo base com campos de timestamp."""

    created_at = models.DateTimeField(
        _("Data de criação"),
        auto_now_add=True,
        editable=False
    )
    updated_at = models.DateTimeField(
        _("Data de atualização"),
        auto_now=True,
        editable=False
    )

    class Meta:
        abstract = True
