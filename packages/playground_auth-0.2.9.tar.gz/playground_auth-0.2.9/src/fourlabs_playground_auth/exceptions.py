from typing import Optional
from rest_framework.exceptions import APIException


class PlaygroundAuthError(APIException):
    """Exceção base para erros de autenticação do Playground."""

    status_code = 400
    default_detail = "Ocorreu um erro durante a autenticação no Playground."
    default_code = "playground_auth_error"


class PlaygroundAPIError(PlaygroundAuthError):
    """Exceção lançada quando a API do Playground retorna um erro."""

    status_code = 502
    default_detail = "Erro ao comunicar com a API do Playground."
    default_code = "playground_api_error"

    def __init__(self, detail: Optional[str] = None, response=None):
        """
        Inicializa a exceção com detalhes opcionais e resposta da API.

        Args:
            detail: Mensagem de erro personalizada
            response: Objeto de resposta da API
        """
        super().__init__(detail=detail)
        self.response = response


class InvalidTokenError(PlaygroundAuthError):
    """Exceção lançada quando o token de acesso é inválido."""

    status_code = 401
    default_detail = "Token de acesso inválido ou expirado."
    default_code = "invalid_token"
