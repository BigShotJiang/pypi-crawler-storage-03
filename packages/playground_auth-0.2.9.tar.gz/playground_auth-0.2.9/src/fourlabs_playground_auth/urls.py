from django.urls import path
from .views.auth import LoginPlayground, LogoutPlayground

app_name = 'playground_auth'

urlpatterns = [
    path('login/', LoginPlayground.as_view(), name='login'),
    path('logout/', LogoutPlayground.as_view(), name='logout'),
]
