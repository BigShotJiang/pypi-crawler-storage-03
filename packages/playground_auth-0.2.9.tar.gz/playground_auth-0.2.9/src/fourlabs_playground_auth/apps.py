from django.apps import AppConfig


class DjangoPlaygroundAuthConfig(AppConfig):
    """Configuração do aplicativo Django Playground Auth."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fourlabs_playground_auth'
    verbose_name = 'Fourlabs Playground Authentication'
