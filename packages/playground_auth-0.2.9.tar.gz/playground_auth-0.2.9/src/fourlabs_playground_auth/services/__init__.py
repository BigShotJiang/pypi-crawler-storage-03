"""Módulo de serviços do Django Playground Auth."""

from .user_info import GetUserInfo

__all__ = ['GetUserInfo']