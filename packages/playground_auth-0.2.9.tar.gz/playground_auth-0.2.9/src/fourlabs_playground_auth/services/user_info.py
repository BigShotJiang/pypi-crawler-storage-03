import logging
from typing import Tuple, Optional
import requests
from django.conf import settings
from django.utils.crypto import get_random_string
from django.contrib.auth import get_user_model
from ..models import Organization
from ..models import Project
from ..exceptions import PlaygroundAPIError, InvalidTokenError

logger = logging.getLogger(__name__)
User = get_user_model()


class GetUserInfo:
    """Serviço para obter e processar informações do usuário do Playground."""

    def __init__(self, access_token: str):
        """
        Inicializa o serviço com o token de acesso.

        Args:
            access_token: Token de acesso para autenticação na API
        """
        self.access_token = access_token
        self.headers = {
            'Authorization': f'Bearer {access_token}',
            'Accept': 'application/json',
        }
        self.response = None

    def get_user_info(self) -> dict:
        """
        Obtém informações do usuário da API do Playground.

        Returns:
            dict: Dados do usuário retornados pela API

        Raises:
            PlaygroundAPIError: Se houver erro na comunicação com a API
            InvalidTokenError: Se o token for inválido
        """
        try:
            self.response = requests.get(
                f"{settings.PLAYGROUND_URI}/account/user-info/",
                params={'service': settings.SERVICE_ID},
                headers=self.headers,
                timeout=10
            )

            if self.response.status_code == 401:
                raise InvalidTokenError()

            if self.response.status_code != 200:
                raise PlaygroundAPIError(
                    detail=f"API retornou status {self.response.status_code}",
                    response=self.response
                )

            return self.response.json()

        except requests.RequestException as e:
            logger.error(f"Erro ao comunicar com API do Playground: {str(e)}")
            raise PlaygroundAPIError(detail=str(e))

    def save_user_info(self) -> Tuple[User, bool]:
        """
        Salva ou atualiza as informações do usuário no banco de dados.

        Returns:
            Tuple[User, bool]: Tupla contendo o objeto do usuário e um booleano
                              indicando se foi criado (True) ou atualizado (False)

        Raises:
            ValueError: Se os dados necessários não estiverem presentes na resposta
        """
        if not self.response:
            raise ValueError("É necessário chamar get_user_info() primeiro")

        data = self.response.json()

        # Validação dos dados obrigatórios
        required_fields = ['email', 'first_name', 'last_name']
        for field in required_fields:
            if not data.get(field):
                raise ValueError(f"Campo obrigatório ausente: {field}")

        # Criação ou atualização do usuário
        user, created = User.objects.get_or_create(
            email=data['email'],
            defaults={
                'first_name': data['first_name'],
                'last_name': data['last_name'],
            }
        )

        if created:
            user.set_password(get_random_string(length=16))
            user.save()
        else:
            # Atualiza informações do usuário existente
            user.first_name = data['first_name']
            user.last_name = data['last_name']
            if 'username' in data:
                user.username = data['username']
            user.save()

        # Processa organizações e projetos
        self._process_organizations_and_projects(user, data.get('tenants', []))

        return user, created

    def _process_organizations_and_projects(self, user: User, tenants: list) -> None:
        """
        Processa as organizações e projetos do usuário.

        Args:
            user: Objeto do usuário
            tenants: Lista de organizações do usuário
        """

        # Limpa associações existentes
        user.projects.clear()
        user.organizations.clear()

        for tenant in tenants:
            org, _ = Organization.objects.update_or_create(
                id=tenant['id'],
                defaults={'name': tenant['name']}
            )

            for project_data in tenant.get('projects', []):
                project, _ = Project.objects.update_or_create(
                    id=project_data['id'],
                    defaults={
                        'name': project_data.get('name', ''),
                        'description': project_data.get('description', ''),
                        'organization': org,
                    }
                )

                # Processa configurações do serviço
                for service in project_data.get('services', []):
                    if service.get('service', {}).get('id') == settings.SERVICE_ID:
                        config = service.get('configuration', {})
                        if isinstance(config, dict):
                            for key, value in config.items():
                                setattr(project, key, value)
                            project.save()

                project.users.add(user)

            user.organizations.add(org)
