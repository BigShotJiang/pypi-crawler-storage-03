"""Views do Django Playground Auth."""

from .auth import LoginPlayground, LogoutPlayground

__all__ = ['LoginPlayground', 'LogoutPlayground']