from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import traceback
from ..utils.log_manager import LogManager


class LoggedAPIView(APIView):
    """
    Classe base para APIViews com registro automático de logs.
    Registra logs de acesso e erros automaticamente para todos os métodos HTTP.
    """

    def dispatch(self, request, *args, **kwargs):
        """
        Sobrescreve o método dispatch para adicionar registro de logs
        e tratamento de exceções em todos os métodos HTTP.
        """
        # Obtém o método HTTP original (get, post, etc.)
        handler = getattr(self, request.method.lower(), self.http_method_not_allowed)

        # Se o método não for um método permitido, delega para o método original
        if handler == self.http_method_not_allowed:
            return super().dispatch(request, *args, **kwargs)

        # Registra o log de acesso
        self._log_access(request, handler.__name__, *args, **kwargs)

        try:
            # Executa o método original
            return handler(request, *args, **kwargs)
        except Exception as e:
            # Registra o erro
            return self._handle_exception(e, request, handler.__name__, *args, **kwargs)

    def _log_access(self, request, method_name, *args, **kwargs):
        """
        Registra um log de acesso para a solicitação atual.
        """
        # Pega o nome do método original da view (GET, POST, etc.)
        view_method = request.method

        # Obtém detalhes da solicitação
        query_params = dict(request.query_params) if hasattr(request, 'query_params') else {}
        url_path = request.path

        # Obtém o email do usuário, se autenticado
        user_email = None
        if hasattr(request, 'user') and request.user.is_authenticated:
            user_email = request.user.email if hasattr(request.user, 'email') else request.user.username

        # Registra o log de acesso
        LogManager.access(
            message=f"Acesso ao endpoint {self.__class__.__name__}.{view_method}",
            user=user_email,
            url_path=url_path,
            method=view_method,
            source=f"{self.__class__.__name__}.{method_name}",
            user_agent=request.META.get('HTTP_USER_AGENT', ''),
            details={
                "query_params": query_params,
                "kwargs": kwargs,
                # Se você quiser registrar também o corpo da requisição para métodos POST/PUT:
                # "request_data": request.data if hasattr(request, 'data') else {}
            }
        )

    def _handle_exception(self, exc, request, method_name, *args, **kwargs):
        """
        Trata e registra exceções que ocorrem durante o processamento da solicitação.
        """
        # Obtém o traceback completo da exceção
        tb = traceback.format_exc()

        # Obtém o nome do método original da view (GET, POST, etc.)
        view_method = request.method

        # Obtém o email do usuário, se autenticado
        user_email = None
        if hasattr(request, 'user') and request.user.is_authenticated:
            user_email = request.user.email if hasattr(request.user, 'email') else request.user.username

        # Determina o tipo de erro
        log_type = 'ERROR'
        if isinstance(exc, (KeyError, ValueError, TypeError)):
            log_type = 'WARNING'

        # Registra o erro
        LogManager.log(
            log_type=log_type,
            message=f"Erro ao processar solicitação {view_method}: {str(exc)}",
            user=user_email,
            url_path=request.path,
            method=view_method,
            source=f"{self.__class__.__name__}.{method_name}",
            details={
                "exception_type": exc.__class__.__name__,
                "exception_message": str(exc),
                "traceback": tb,
                "query_params": dict(request.query_params) if hasattr(request, 'query_params') else {},
                # Se você quiser registrar também o corpo da requisição para métodos POST/PUT:
                # "request_data": request.data if hasattr(request, 'data') else {}
            }
        )

        # Retorna uma resposta de erro padrão
        # Você pode personalizar esta resposta conforme necessário
        return Response(
            {"erro": "Ocorreu um erro ao processar sua solicitação"},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
