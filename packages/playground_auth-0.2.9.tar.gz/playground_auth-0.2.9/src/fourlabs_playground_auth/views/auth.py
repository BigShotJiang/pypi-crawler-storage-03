from typing import Any
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.utils.translation import gettext_lazy as _
from ..services import GetUserInfo
from ..exceptions import PlaygroundAuthError, InvalidTokenError
from ..utils.validators import validate_access_token


class LoginPlayground(APIView):
    """View para autenticação de usuários via Playground."""

    permission_classes = [AllowAny]

    @swagger_auto_schema(
        operation_summary=_("Autenticar usuário com token do Playground"),
        operation_description=_(
            "Autentica ou cria um usuário com base no token de acesso fornecido pelo Playground. "
            "Se o usuário não existir, ele será criado e associado a organizações relacionadas."
        ),
        manual_parameters=[
            openapi.Parameter(
                "access_token",
                openapi.IN_QUERY,
                description=_("Token de acesso do Playground"),
                type=openapi.TYPE_STRING,
                required=True,
            ),
        ],
        responses={
            200: openapi.Response(
                description=_("Usuário autenticado com sucesso"),
                schema=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'refresh': openapi.Schema(type=openapi.TYPE_STRING),
                        'access': openapi.Schema(type=openapi.TYPE_STRING),
                        'user': openapi.Schema(type=openapi.TYPE_OBJECT),
                        'user_created': openapi.Schema(type=openapi.TYPE_BOOLEAN),
                    }
                )
            ),
            400: "Requisição inválida",
            401: "Token inválido",
            502: "Erro ao comunicar com API do Playground",
        }
    )
    def get(self, request: Request) -> Response:
        """
        Processa a requisição de login.

        Args:
            request: Objeto de requisição do DRF

        Returns:
            Response: Resposta contendo tokens de autenticação e dados do usuário
        """
        access_token = request.query_params.get('access_token')

        try:
            validate_access_token(access_token)

            service = GetUserInfo(access_token)
            service.get_user_info()
            user, created = service.save_user_info()

            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'organizations': [
                        {'id': org.id, 'name': org.name}
                        for org in user.organizations.all()
                    ],
                },
                'user_created': created,
            })

        except (PlaygroundAuthError, InvalidTokenError) as e:
            return Response(
                {'error': str(e)},
                status=e.status_code
            )
        except Exception as e:
            return Response(
                {'error': _("Erro interno do servidor")},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class LogoutPlayground(APIView):
    """View para logout de usuários."""

    @swagger_auto_schema(
        operation_summary=_("Realizar logout do usuário"),
        operation_description=_("Invalida o token de refresh do usuário atual."),
        responses={
            200: "Logout realizado com sucesso",
            401: "Não autorizado",
        }
    )
    def post(self, request: Request) -> Response:
        """
        Processa a requisição de logout.

        Args:
            request: Objeto de requisição do DRF

        Returns:
            Response: Resposta indicando sucesso do logout
        """
        try:
            refresh_token = request.data.get('refresh')
            token = RefreshToken(refresh_token)
            token.blacklist()

            return Response({'detail': _("Logout realizado com sucesso")})

        except Exception:
            return Response(
                {'error': _("Token de refresh inválido")},
                status=status.HTTP_401_UNAUTHORIZED
            )
