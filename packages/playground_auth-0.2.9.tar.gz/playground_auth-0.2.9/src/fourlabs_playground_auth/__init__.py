"""Django Playground Authentication package."""
from django.conf import settings

__version__ = "0.1.0"

default_app_config = "django_playground_auth.apps.DjangoPlaygroundAuthConfig"

# Validação das configurações necessárias
required_settings = {
    'PLAYGROUND_URI': 'URL base da API do Playground',
    'SERVICE_ID': 'ID do serviço no Playground',
}

# Verifica se as configurações necessárias estão definidas
for setting, description in required_settings.items():
    if not hasattr(settings, setting):
        raise ValueError(f'A configuração {setting} é obrigatória: {description}')
