from django.conf import settings
import requests
import json
from requests.exceptions import RequestException


class TokenConsumer:
    """
    A class to handle token consumption through the API.

    This class provides a professional interface to interact with the
    token consumption endpoint, handling authentication and request management.

    Required Django Settings:
        PLAYGROUND_URI (str): Base URL for the API
        TOKEN_CONSUME_DEFAULT_TIMEOUT (int, optional): Default timeout for requests in seconds

    Attributes:
        consume_token (str): Token to be consumed
        project_id (str): Project identifier
        service_id (str): Service identifier
        base_url (str): Base URL for the API, retrieved from Django settings
    """

    def __init__(self, consume_token: str, service_id: str) -> None:
        """
        Initialize the TokenConsumer with required parameters.

        Args:
            consume_token (str): Token to be consumed
            project_id (str): Project identifier
            service_id (str): Service identifier

        Raises:
            ValueError: If any parameter is empty or invalid
            ImproperlyConfigured: If required Django settings are missing
        """
        self.project_id = None
        from django.core.exceptions import ImproperlyConfigured

        # Validate input parameters
        if not consume_token or not isinstance(consume_token, str):
            raise ValueError("consume_token must be a non-empty string")
        if not service_id or not isinstance(service_id, str):
            raise ValueError("service_id must be a non-empty string")

        # Get URL from Django settings with validation
        try:
            self.base_url = settings.PLAYGROUND_URI
        except AttributeError:
            raise ImproperlyConfigured(
                "PLAYGROUND_URI must be defined in Django settings"
            )

        # Get optional timeout setting
        self.timeout = getattr(settings, 'TOKEN_CONSUME_DEFAULT_TIMEOUT', 30)

        self.consume_token = consume_token
        self.service_id = service_id

    def consume(self, project_id) -> dict:
        """
        Consume a token by making a POST request to the API.

        Returns:
            dict: The response data from the API

        Raises:
            RequestException: If the request fails due to network issues
            ValueError: If the response is not in the expected format
            Exception: For any other unexpected errors
        """
        endpoint = f"{self.base_url}/tokens/consume-token/"
        self.project_id = project_id

        payload = {
            "consume_token": self.consume_token,
            "project_id": self.project_id,
            "service_id": self.service_id
        }

        headers = {
            "Content-Type": "application/json"
        }

        try:
            response = requests.post(
                url=endpoint,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.timeout
            )

            # Raise an exception for bad status codes
            response.raise_for_status()

            return response.json()

        except RequestException as e:
            raise RequestException(f"Failed to consume token: {str(e)}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse API response: {str(e)}")
        except Exception as e:
            raise Exception(f"An unexpected error occurred: {str(e)}")

    def __str__(self) -> str:
        """
        Return a string representation of the TokenConsumer instance.

        Returns:
            str: A string describing the TokenConsumer instance
        """
        return f"TokenConsumer(project_id={self.project_id}, service_id={self.service_id})"

    def __repr__(self) -> str:
        """
        Return a detailed string representation of the TokenConsumer instance.

        Returns:
            str: A detailed string representation of the TokenConsumer instance
        """
        return (
            f"TokenConsumer(consume_token='***', "
            f"project_id='{self.project_id}', "
            f"service_id='{self.service_id}')"
        )
    