import warnings
import requests
from packaging import version
import pkg_resources
from typing import Optional
import logging
import os

logger = logging.getLogger(__name__)


def check_version() -> None:
    """
    Check if there's a newer version of fourlabs-playground-auth available on Azure DevOps.
    Issues a warning if the installed version is outdated.
    """
    PACKAGE_NAME = "fourlabs-playground-auth"
    AZURE_ORG = "fourlabs-un2"
    AZURE_PROJECT = "Board Lab"
    AZURE_REPO = "fourlabs-playground-auth"

    def get_installed_version() -> Optional[str]:
        """Get the currently installed version of the package."""
        try:
            return pkg_resources.get_distribution(PACKAGE_NAME).version
        except pkg_resources.DistributionNotFound:
            logger.error(f"Could not determine installed version of {PACKAGE_NAME}")
            return None

    def get_latest_version() -> Optional[str]:
        """Get the latest version from Azure DevOps repository tags."""
        try:
            # Get personal access token from environment variable
            pat = os.getenv('AZURE_DEVOPS_PAT')
            if not pat:
                logger.debug("No Azure DevOps PAT found in environment variables")
                return None

            # Create authorization header
            auth = ('', pat)

            # Azure DevOps REST API URL for tags
            url = f"https://dev.azure.com/{AZURE_ORG}/{AZURE_PROJECT}/_apis/git/repositories/{AZURE_REPO}/refs?filter=tags/&api-version=6.0"

            response = requests.get(url, auth=auth, timeout=5)
            response.raise_for_status()

            # Get all tags and find the latest version
            tags = response.json().get('value', [])
            versions = []

            for tag in tags:
                tag_name = tag['name'].replace('refs/tags/', '')
                try:
                    # Verify if the tag is a valid version
                    version.parse(tag_name)
                    versions.append(tag_name)
                except version.InvalidVersion:
                    continue

            if versions:
                return str(max(version.parse(v) for v in versions))
            return None

        except Exception as e:
            logger.error(f"Failed to fetch latest version from Azure DevOps: {str(e)}")
            return None

    def warn_if_outdated(current: str, latest: str) -> None:
        """Issue a warning if the current version is behind the latest version."""
        if version.parse(current) < version.parse(latest):
            warning_message = f"""
                ⚠️  Your version of {PACKAGE_NAME} ({current}) is outdated.
                The latest version is {latest}. Please upgrade using:
                pip install --upgrade git+https://fourlabs-un2@dev.azure.com/fourlabs-un2/Board%20Lab/_git/fourlabs-playground-auth
                """
            warnings.warn(warning_message, UpdateWarning)

    class UpdateWarning(Warning):
        """Custom warning class for package update notifications."""
        pass

    # Only check once per Python session
    if not hasattr(check_version, '_has_run'):
        current_version = get_installed_version()
        if current_version:
            latest_version = get_latest_version()
            if latest_version:
                warn_if_outdated(current_version, latest_version)
        check_version._has_run = True
