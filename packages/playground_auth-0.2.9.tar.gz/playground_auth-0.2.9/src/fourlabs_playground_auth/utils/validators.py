import re
from typing import Optional
from django.core.exceptions import ValidationError


def validate_access_token(token: str):
    """
    Valida o formato do token de acesso.

    Args:
        token: Token de acesso a ser validado

    Raises:
        ValidationError: Se o token não estiver em um formato válido
    """
    if not token:
        raise ValidationError("Token de acesso é obrigatório")

    # Verifica o formato básico do token (pode ser ajustado conforme necessário)
    if not re.match(r'^[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*$', token):
        raise ValidationError("Formato de token inválido")


def validate_service_id(service_id: str):
    """
    Valida o ID do serviço.

    Args:
        service_id: ID do serviço a ser validado

    Raises:
        ValidationError: Se o ID do serviço não estiver em um formato válido
    """
    if not service_id:
        raise ValidationError("ID do serviço é obrigatório")

    if not re.match(r'^[a-zA-Z0-9-_]+$', service_id):
        raise ValidationError("Formato de ID de serviço inválido")
