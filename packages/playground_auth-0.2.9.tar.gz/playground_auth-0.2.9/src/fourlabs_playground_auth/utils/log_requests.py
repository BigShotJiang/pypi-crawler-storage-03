from rest_framework.response import Response
from rest_framework import status
from functools import wraps
from .log_manager import LogManager


def log_requests(func):
    """
    Decorator para registrar logs automaticamente antes e depois da execução do método.
    """

    @wraps(func)
    def wrapper(self, request, *args, **kwargs):
        user_email = request.user.email if request.user.is_authenticated else None
        method = request.method
        source = f"{self.__class__.__name__}.{method}"

        try:
            response = func(self, request, *args, **kwargs)

            LogManager.access(
                message=f"Requisição {method} processada com sucesso",
                user=user_email,
                method=method,
                source=source,
                details={
                    "query_params": dict(request.query_params),
                    "status_code": response.status_code,
                }
            )
            return response

        except Exception as e:
            LogManager.error(
                message=f"Erro ao processar solicitação {method}: {str(e)}",
                user=user_email,
                method=method,
                source=source,
                details={
                    "exception_type": e.__class__.__name__,
                    "query_params": dict(request.query_params),
                }
            )
            return Response(
                {"erro": "Ocorreu um erro ao processar sua solicitação"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    return wrapper
