from ..models import ApplicationLog


class LogManager:
    @staticmethod
    def log(log_type, message, source=None, user=None, ip_address=None,
            url_path=None, method=None, user_agent=None, details=None):
        """
        Cria uma entrada de log na base de dados
        """
        return ApplicationLog.objects.create(
            log_type=log_type,
            message=message,
            source=source,
            user=user,
            ip_address=ip_address,
            url_path=url_path,
            method=method,
            user_agent=user_agent,
            details=details
        )

    @staticmethod
    def info(message, **kwargs):
        return LogManager.log('INFO', message, **kwargs)

    @staticmethod
    def warning(message, **kwargs):
        return LogManager.log('WARNING', message, **kwargs)

    @staticmethod
    def error(message, **kwargs):
        return LogManager.log('ERROR', message, **kwargs)

    @staticmethod
    def critical(message, **kwargs):
        return LogManager.log('CRITICAL', message, **kwargs)

    @staticmethod
    def debug(message, **kwargs):
        return LogManager.log('DEBUG', message, **kwargs)

    @staticmethod
    def access(message, **kwargs):
        return LogManager.log('ACCESS', message, **kwargs)
