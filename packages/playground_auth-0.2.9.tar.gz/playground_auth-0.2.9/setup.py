from setuptools import setup, find_packages

setup(
    name='playground-auth',
    version='0.2.9',
    packages=find_packages(include=['fourlabs_playground_auth', 'fourlabs_playground_auth.*']),
    install_requires=[
        'Django>=5.1.6',
        'djangorestframework>=3.15.2',
        'requests>=2.32.3',
        'drf-yasg>=1.21.8',
    ],
    author='Fourlabs',
    author_email='fourlabs-showroom-un2@foursys.com.br',
    description='Django authentication app for Fourlabs Playground integration',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Framework :: Django',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
    ],
)
