# FourLabs Playground Auth

A **Django app** para integração de autenticação com o **Playground**.  
Este aplicativo fornece funcionalidades para autenticar usuários usando um **token de acesso Playground** e gerenciar **organizações e projetos** de forma eficiente.

---

## 🚀 **Instalação**

Clone e instale o pacote diretamente do repositório:

```bash
pip install playground-auth
```

## ⚙ Configuração
### 1️⃣ Adicione no INSTALLED_APPS
No arquivo settings.py, inclua a aplicação:

```python
INSTALLED_APPS = [
    ...
    'fourlabs_playground_auth',
]
```

Definir local para criar as migrações
```python
MIGRATION_MODULES = {
    'fourlabs_playground_auth': 'custom_migrations.fourlabs_playground_auth',
}
```

Criar local para criar as migrações
```bash
mkdir -p custom_migrations/fourlabs_playground_auth
touch custom_migrations/fourlabs_playground_auth/__init__.py
```

### 2️⃣ Configure as Credenciais Playground
Defina as configurações necessárias para autenticação no Playground:

```python
PLAYGROUND_URI = 'playground-uri'
SERVICE_ID = 'service-id'
```

### 3️⃣ Defina o Modelo de Usuário Padrão
Especifique o modelo de usuário personalizado para integração com o Playground:

```python
AUTH_USER_MODEL = 'fourlabs_playground_auth.User'
```

## 🛠 Personalização de Campos do Projeto
O usuário pode definir dinamicamente os campos do modelo Project através do settings.py.

Exemplo:

```python
PROJECT_CUSTOM_FIELDS = [
    {"name": "playstore_link", "type": "URLField", "verbose_name": "Link Play Store"},
    {"name": "appstore_link", "type": "URLField", "verbose_name": "Link App Store"},
    {"name": "twitter_link", "type": "URLField", "verbose_name": "Link Twitter"},
    {"name": "linkedin_link", "type": "URLField", "verbose_name": "Link LinkedIn"},
    {"name": "rating", "type": "FloatField", "verbose_name": "Avaliação"},
    {"name": "launch_date", "type": "DateField", "verbose_name": "Data de Lançamento"},
    {"name": "active", "type": "BooleanField", "verbose_name": "Está Ativo?", "params": {"default": True}},
    {"name": "support_email", "type": "EmailField", "verbose_name": "E-mail de Suporte"},
    {"name": "description", "type": "TextField", "verbose_name": "Descrição Completa"},
    {"name": "metadata", "type": "JSONField", "verbose_name": "Metadados Extras"},
]
```

Isso permitirá que o Django adicione esses campos automaticamente no modelo Project, sem necessidade de modificar o código-fonte.

## 🔄 Banco de Dados & Migrações
Após configurar o projeto, execute as migrações para refletir as alterações no banco de dados.

### 1️⃣ Criar as migrações
```bash
python manage.py makemigrations
```
### 2️⃣ Aplicar as migrações
```bash
python manage.py migrate
```
## 🌍 Uso
### 1️⃣ Adicione as URLs no urls.py
Para expor as rotas de autenticação, inclua no seu urls.py:

```python
from django.urls import path, include

urlpatterns = [
    ...
    path('auth/', include('fourlabs_playground_auth.urls')),
]

```
Isso garantirá que todas as funcionalidades de autenticação estejam acessíveis via /auth/.

### 📌 Recursos Principais
* ✅ Autenticação via token Playground 
* ✅ Gerenciamento de usuários, organizações e projetos 
* ✅ Campos personalizados para o modelo Project via settings.py 
* ✅ Integração simples e flexível com qualquer projeto Django

## 📝 Licença
Este projeto está licenciado sob a MIT License.


## Dicas para Atualizações

#### Aumente a versão em setup.py (version='0.1.1', por exemplo)

#### Apague a pasta dist/:

```bash
rm -rf dist/
```

#### Gere e envie novamente:

```bash
python setup.py sdist bdist_wheel
twine upload dist/*
```