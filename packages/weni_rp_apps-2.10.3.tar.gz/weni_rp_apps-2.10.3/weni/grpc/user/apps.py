from django.apps import AppConfig


class UserGrpcConfig(AppConfig):
    name = "weni.grpc.user"
