default_app_config = "weni.analytics_api.apps.AnalyticsApiConfig"
