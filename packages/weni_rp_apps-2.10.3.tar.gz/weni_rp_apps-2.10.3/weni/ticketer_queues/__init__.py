default_app_config = "weni.ticketer_queues.apps.TicketerQueuesConfig"
