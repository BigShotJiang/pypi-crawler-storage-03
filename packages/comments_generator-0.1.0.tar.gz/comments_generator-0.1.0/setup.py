from setuptools import setup, find_packages

setup(
    name="comments_generator",
    version="0.1.0",
    author="Yara Gafar",
    author_email="yara.gafar99@gmail.com",
    url="https://github.com/yaragafar99/comments_generator",
    description="A package for generating random comments based on category, language, and tone.",
    packages=find_packages(),
    include_package_data=True,
    package_data={"comments_generator": ["data/*.csv"]},
    install_requires=["pandas"],
    python_requires=">=3.7",
)
