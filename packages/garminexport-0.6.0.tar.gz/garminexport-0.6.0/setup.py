#!/usr/bin/env python
"""garminexport builder and installer."""
from setuptools import setup

if __name__ == '__main__':
    setup()
