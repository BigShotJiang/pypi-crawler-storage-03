* Akim Juillerat <akim.juillerat@camptocamp.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Jacques-Etienne Baudoux <je@bcim.be>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Fernando La Chica - GreenICe <fernandolachica@gmail.com>
* Denis Roussel <denis.roussel@acsone.eu>
