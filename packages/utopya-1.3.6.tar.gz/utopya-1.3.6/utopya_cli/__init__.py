"""The utopya CLI"""

import dantro.logging

from .cli import cli
