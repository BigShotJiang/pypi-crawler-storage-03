"""Tests in this submodule can be used to generate figures that can in turn be
used in the package documentation."""
