import importlib.metadata as metadata

__version__ = release = metadata.version("exonamd")
