DEFAULT_DAILY_REWARD = 100
SAVE_FILE_PATH = "~/.lineage_save.json"