# Sending an Automated Email

This example will go through a