adc-streaming documentation
============================

User's Guide
------------

.. toctree::
   :maxdepth: 2

   user/installation
   user/quickstart

API Reference
-------------

.. toctree::
   :maxdepth: 2

   api/api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
