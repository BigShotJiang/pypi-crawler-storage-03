from . import server


def main():
    server.main()
