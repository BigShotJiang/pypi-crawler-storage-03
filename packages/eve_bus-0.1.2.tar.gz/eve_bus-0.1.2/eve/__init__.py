"""Eve Event Bus

A lightweight event bus implementation using Redis.
"""

__version__ = "0.1.2"
__author__ = "Ray"
__email__ = "ray@rayainfo.cn"