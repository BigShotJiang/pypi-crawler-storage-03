"""Package para análise de ambiente."""
