<!-- Powered by JTECH™ Core -->

docOutputLocation: docs/brainstorming-session-results.md
template: '.jtech-core/templates/brainstorming-output-tmpl.yaml'

---

# Tarefa Facilitar Sessão de Brainstorming

Facilitar sessões interativas de brainstorming com usuários. Seja criativo e adaptável na aplicação de técnicas.

## Processo

### Passo 1: Configuração da Sessão

Faça 4 perguntas de contexto (não antecipe o que acontece depois):

1. Sobre o que estamos fazendo brainstorming?
2. Alguma restrição ou parâmetro?
3. Objetivo: exploração ampla ou ideação focada?
