<!-- Powered by JTECH™ Core -->

# Tarefa Interação Modo KB

## Propósito

Fornecer uma interface amigável à base de conhecimento JTech sem sobrecarregar usuários com informação antecipadamente.

## Instruções

Ao entrar no modo KB (\*kb-mode), siga estes passos:

### 1. Boas-vindas e Guia

Anuncie entrada no modo KB com uma introdução breve e amigável.

### 2. Apresentar Áreas de Tópicos

Ofereça uma lista concisa das principais áreas de tópicos que o usuário pode querer explorar:
