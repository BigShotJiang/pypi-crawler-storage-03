"""Package para sistema de rollback."""
