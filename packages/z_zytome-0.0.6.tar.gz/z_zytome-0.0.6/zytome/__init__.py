"""zytome"""

__version__ = "0.0.6"
__author__ = "Marko Zolo Gozano Untalan"
