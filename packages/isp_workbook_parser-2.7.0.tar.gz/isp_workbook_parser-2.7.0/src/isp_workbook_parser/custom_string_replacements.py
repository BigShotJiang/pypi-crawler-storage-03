typos_and_notes = {
    r"CCGT\d+": "CCGT",
    r"requirements_TAS\d+": "requirements_TAS",
    r"- Notes \d+,\d+&\d+": "",
    r"- Notes \d+&\d+": "",
    r"- Notes \d+": "",
    r"- \(Note \d+\)": "",
    r"\(Note \d+\)": "",
    r"\(Note \d+&\d+\)": "",
    r"\(Note \d+,d+&\d+\)": "",
    r"\(Note \d+ \+ Note \d+\)": "",
}
