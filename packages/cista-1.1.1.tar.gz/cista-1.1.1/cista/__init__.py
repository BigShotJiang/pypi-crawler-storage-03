from cista._version import __version__

__version__  # Public API
