Customizations related to ``fieldservice_equipment_stock`` module and ``product_warranty`` module.

This module allows managing warranties for equipment in the field service module.
It extends the functionality of the `fieldservice_equipment_stock` and `product_warranty` modules
to provide a link between equipment and product warranties.
