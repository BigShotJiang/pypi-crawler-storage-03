print("WhatBeatsRock")
