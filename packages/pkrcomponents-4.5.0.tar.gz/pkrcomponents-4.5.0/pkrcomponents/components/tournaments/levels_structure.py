""" This module contains the class LevelsStructure that represents the structure of the levels of a tournament."""


class LevelsStructure(list):
    # TODO: Implement this class that represents the structure of the levels of a tournament
    pass
