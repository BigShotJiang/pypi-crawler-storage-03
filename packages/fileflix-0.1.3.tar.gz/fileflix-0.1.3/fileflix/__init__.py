from .core import read_file, write_file

_all_ = ["read_file","write_file"]