"""``nbformat`` types."""

from __future__ import annotations

from .versions import current

Document = current.Document

__all__ = ["Document", "current"]
