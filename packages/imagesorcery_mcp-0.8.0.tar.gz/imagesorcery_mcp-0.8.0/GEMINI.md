# Gemini Workspace Instructions

On each new session, please re-read the `README.md` file to ensure you have the most up-to-date project context and instructions.

Adhere to all rules and guidelines outlined in the `README.md` file.
