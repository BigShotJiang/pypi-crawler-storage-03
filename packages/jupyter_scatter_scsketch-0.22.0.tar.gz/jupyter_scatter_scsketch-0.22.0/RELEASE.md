To release a new version of jscatter on PyPI and NPM:

1. Run `make bump-patch`, `make bump-minor`, or `make bump-major`
2. Run `make publish`
