from typing import Literal

PersistenceFormat = Literal['parquet', 'arrow_ipc']
