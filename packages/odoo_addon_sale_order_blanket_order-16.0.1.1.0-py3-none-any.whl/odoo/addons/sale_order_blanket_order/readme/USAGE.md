By default, the automatic creation of call-off orders from normal sale orders containing products
part of a blanket order is disabled. To enable this feature, you need to go into the sales settings
and enable the option "Create Call-Off from SO if possible".