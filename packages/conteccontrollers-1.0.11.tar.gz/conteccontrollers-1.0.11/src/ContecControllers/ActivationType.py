from enum import Enum

class ActivationType(Enum):
    OnOff = 0,
    Blind = 1,
    Pusher = 2