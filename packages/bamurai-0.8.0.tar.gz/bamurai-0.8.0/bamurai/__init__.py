from .core import *
from .stats import *
from .split import *
from .divide import *

from .version import get_version

__version__ = get_version()
