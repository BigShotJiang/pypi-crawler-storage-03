# Codewords Client

This is a client for the Codewords API.

## Installation

```bash
pip install codewords-client
```