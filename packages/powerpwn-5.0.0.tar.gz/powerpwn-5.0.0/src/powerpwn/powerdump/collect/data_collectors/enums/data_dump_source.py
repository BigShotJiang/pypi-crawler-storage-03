from enum import auto

from powerpwn.enums.str_enum import StrEnum


class DataDumpSource(StrEnum):
    connections = auto()
