from powerpwn.enums.str_enum import StrEnum


class FlowState(StrEnum):
    started = "Started"
    stopped = "Stopped"
