from dataclasses import dataclass
import os

try:  # pragma: no cover - optional convenience
    from dotenv import load_dotenv  # type: ignore
    load_dotenv()
except Exception:
    pass

@dataclass
class Settings:
    default_wpm: int = 200
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    llm_model: str | None = os.getenv("GRANULE_LLM_MODEL")
    llm_provider: str | None = os.getenv("GRANULE_LLM_PROVIDER")
    suppress_problem_questions: bool = bool(
        1
        if os.getenv("GRANULE_SUPPRESS_PROBLEM_QUESTIONS", "").strip().lower()
        in {"1", "true", "yes", "y", "on"}
        else 0
    )

    @property
    def llm_enabled(self) -> bool:
        return bool(self.openai_api_key)

settings = Settings()
