import json
from datetime import timedelta
import typer
from rich import print

# NOTE: Heavy / optional imports (LLM, OpenAI) are intentionally deferred until inside
# command functions to avoid slow startup or hangs when optional deps are problematic.
from .api import ingest as api_ingest, dissect as api_dissect, expand as api_expand, stream as api_stream
from .models.core import GranularitySpec
from .store_io import write_json

app = typer.Typer(add_completion=False)

@app.command()
def ingest(
    source: str,
    kind: str = "blog",
    output: str = typer.Option("doc.json", "--output", "-o", help="Output JSON path"),
):
    doc = api_ingest(source, kind)
    write_json(doc, output)
    print(f"[green]Wrote[/green] {output}")

@app.command()
def dissect(
    doc_path: str,
    max_tokens: int = 80,
    only: str = "",
    output: str = typer.Option("atoms.json", "--output", "-o", help="Output JSON path"),
):
    data = json.load(open(doc_path, "r", encoding="utf-8"))
    from .models.core import StructuredDoc
    doc = StructuredDoc(**data)
    kinds = [k.strip() for k in only.split(",") if k.strip()] or None
    spec = GranularitySpec(max_tokens_per_atom=max_tokens, atom_types=kinds)
    graph = api_dissect(doc, spec)
    write_json(graph, output)
    print(f"[green]Wrote[/green] {output}")

@app.command()
def expand(
    atoms_path: str,
    target: str = "55s",
    output: str = typer.Option("unit.json", "--output", "-o", help="Output JSON path"),
):
    data = json.load(open(atoms_path, "r", encoding="utf-8"))
    from .models.core import AtomGraph, GranularitySpec
    graph = AtomGraph(**data)
    td = parse_duration(target)
    spec = GranularitySpec(target_duration=td)
    unit = api_expand(graph, spec)
    write_json(unit, output)
    print(f"[green]Wrote[/green] {output}")

@app.command()
def stream(
    atoms_path: str,
    pace: str = "55s",
    until: str = "10m",
    output: str = typer.Option("session.jsonl", "--output", "-o", help="Output JSONL path"),
):
    data = json.load(open(atoms_path, "r", encoding="utf-8"))
    from .models.core import AtomGraph
    graph = AtomGraph(**data)
    pace_td = parse_duration(pace).total_seconds()
    until_td = parse_duration(until).total_seconds()
    with open(output, "w", encoding="utf-8") as f:
        for item in api_stream(graph, pace_td, until_td):
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    print(f"[green]Wrote[/green] {output}")

def parse_duration(s: str) -> timedelta:
    s = s.strip().lower()
    if s.endswith("s"): return timedelta(seconds=float(s[:-1]))
    if s.endswith("m"): return timedelta(minutes=float(s[:-1]))
    if s.endswith("h"): return timedelta(hours=float(s[:-1]))
    raise typer.BadParameter("Duration must end with s/m/h")

@app.command("simple-youtube")
def simple_youtube(url: str, output: str = typer.Option("simple.json", "--output", "-o")):
    """Run simplified pipeline: YouTube URL -> LLM summary."""
    from .api_simple import simple_youtube_summary  # lazy import
    result = simple_youtube_summary(url)
    write_json(result, output)
    print(f"[green]Wrote[/green] {output}")


@app.command("simple-card")
def simple_card(url: str, output: str = typer.Option("card.json", "--output", "-o")):
    """YouTube URL -> Transcript Insight Card JSON (LLM if enabled)."""
    from .api_simple import simple_youtube_card  # lazy import
    card = simple_youtube_card(url)
    write_json(card, output)
    print(f"[green]Wrote[/green] {output}")

@app.command("video-card")
def video_card(
    url: str,
    output: str = typer.Option("video_card.json", "--output", "-o"),
    title: str = typer.Option(None, "--title", help="Override video title (skip fetch)"),
):
    """YouTube URL -> VideoInsightCardPayload JSON (strict schema). Optionally override title."""
    from .api_simple import video_insight_card  # lazy import
    card = video_insight_card(url, title=title)
    from pydantic import BaseModel
    if isinstance(card, BaseModel):
        payload = card.model_dump(mode="python")
    else:  # pragma: no cover
        payload = card
    write_json(payload, output)
    print(f"[green]Wrote[/green] {output}")

@app.command("text-video-card")
def text_video_card(
    input_path: str = typer.Argument(..., help="Path to .txt file OR raw text snippet"),
    output: str = typer.Option("text_video_card.json", "--output", "-o"),
    title: str = typer.Option(None, "--title", help="Set title for the generated card"),
    assume_file: bool = typer.Option(False, "--file", help="Force treat input as path even if short"),
):
    """Raw transcript text (or a .txt file) -> VideoInsightCardPayload JSON.

    If input_path points to an existing file (or --file is set) the contents are read;
    otherwise the argument itself is treated as the transcript text.
    """
    import os
    if (assume_file or os.path.exists(input_path)) and os.path.isfile(input_path):
        text = open(input_path, 'r', encoding='utf-8').read()
    else:
        text = input_path
    from .api_simple import text_video_insight_card  # lazy import
    card = text_video_insight_card(text, title=title)
    from pydantic import BaseModel
    payload = card.model_dump(mode='python') if isinstance(card, BaseModel) else card
    write_json(payload, output)
    print(f"[green]Wrote[/green] {output}")

if __name__ == "__main__":  # moved to end so all commands are registered when run as a module
    app()
