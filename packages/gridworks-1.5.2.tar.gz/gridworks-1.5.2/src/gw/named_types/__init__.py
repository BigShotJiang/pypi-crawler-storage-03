from gw.named_types.gw_base import GwBase
from gw.named_types.gw_base_versionless import GwBaseVersionless

__all__ = ["GwBase", "GwBaseVersionless"]
