django-oauth2
======================

.. image:: https://travis-ci.org/stormsherpa/django-oauth2-provider.png?branch=master

*django-oauth2* is a Django application that provides
customizable OAuth2\-authentication for your Django projects.

`Documentation <https://new-django-oauth2.readthedocs.io/en/latest/>`_

License
=======

*django-oauth2* is a fork of *django-oauth2-provider* which is released under the MIT License. Please see the LICENSE file for details.


Packaging
=========

 $ python -m build

