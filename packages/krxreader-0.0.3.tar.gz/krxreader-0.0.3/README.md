# KRXReader

KRXReader is a Python library for scraping financial data from the KRX(Korea Exchange) Market Data System.
