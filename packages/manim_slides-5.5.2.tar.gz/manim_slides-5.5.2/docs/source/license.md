# License


```{include} ../../LICENSE.md
```
