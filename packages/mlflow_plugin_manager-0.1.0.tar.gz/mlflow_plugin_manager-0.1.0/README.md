# MLflow Plugin Manager

![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)

Welcome to the MLflow Plugin Manager, inspired by wbond's package manager for Sublime Text. This tool seamlessly integrates with MLflow, allowing you to install, update, and uninstall MLflow plugins directly from the MLflow web interface.

## Features
- 🛠 **Install** new MLflow plugins with ease.
- 🔄 **Update** existing plugins to their latest versions.
- 🗑 **Uninstall** plugins you no longer need.
- 🌐 Direct integration into the MLflow web interface.

Preview
![preview functionality](https://github.com/thijsdezoete/mlflow-plugin-manager/blob/master/media/mlflow-plugin.gif?raw=true)

## Installation

Clone this repository:
```bash
git clone git@github.com:thijsdezoete/mlflow-plugin-manager.git
```

Navigate to the cloned directory and install the package:

```bash
cd mlflow-plugin-manager
pip install -e .
```

# Usage

To run the MLflow server with the Plugin Manager, use the following command:

```bash
mlflow server --app-name plugin_manager
```

Once the server is running, navigate to the MLflow web interface. You'll find the Plugin Manager integrated and ready for use at:

http://localhost:5000/plugin-manager/

## Configuration

### Environment Variables

- `PLUGIN_SERVER_URL`: URL of the plugin metadata server
  - **Default**: `https://api.mlflowplugins.com` (production)
  - **Local Development**: Set to `http://localhost:5001` if running your own server
  
Example for local development:
```bash
export PLUGIN_SERVER_URL="http://localhost:5001"
mlflow server --app-name plugin_manager
```

## Architecture

The MLflow Plugin Manager consists of two components:

1. **MLflow Plugin** (this package): Integrates with MLflow's web interface and handles package installation locally via pip
2. **Metadata Server**: Provides plugin information (hosted at api.mlflowplugins.com)

**Important**: Package installation happens locally on your machine. The remote server only provides plugin metadata (available packages, versions, etc.).

## For Server Maintainers Only

If you're maintaining your own plugin metadata server:

```bash
cd server
python reindex_plugins.py  # Index packages from PyPI
python app.py              # Run metadata server on port 5001
```

End users don't need to run these commands - the default configuration uses api.mlflowplugins.com.

# License

This project is licensed under the MIT License. Refer to the LICENSE file for more details.


