"""__init__.py."""

import importlib.metadata

__version__ = importlib.metadata.version("strangeworks_core")
