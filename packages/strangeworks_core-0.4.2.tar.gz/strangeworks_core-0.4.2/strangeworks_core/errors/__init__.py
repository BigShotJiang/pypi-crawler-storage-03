"""__init__.py."""
from .error import StrangeworksError

__all__ = ["StrangeworksError"]
