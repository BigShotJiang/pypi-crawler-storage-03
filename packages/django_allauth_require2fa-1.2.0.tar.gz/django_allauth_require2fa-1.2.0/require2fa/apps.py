from django.apps import AppConfig


class Require2FaConfig(AppConfig):
    """Django app configuration for require2fa."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "require2fa"
