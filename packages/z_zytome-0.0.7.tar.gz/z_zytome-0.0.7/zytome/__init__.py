"""zytome"""

__version__ = "0.0.7"
__author__ = "Marko Zolo Gozano Untalan"
