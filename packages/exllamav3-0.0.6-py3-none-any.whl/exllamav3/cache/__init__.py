from .cache import Cache, CacheLayer
from .fp16 import CacheLayer_fp16
from .quant import CacheLayer_quant