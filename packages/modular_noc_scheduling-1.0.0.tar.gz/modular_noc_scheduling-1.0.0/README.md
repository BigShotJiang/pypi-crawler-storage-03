# NOC Scheduling Algorithm - Complete User Guide

## Table of Contents
1. [What is This Algorithm?](#what-is-this-algorithm)
2. [Who Should Use This Guide?](#who-should-use-this-guide)
3. [Key Features](#key-features)
4. [Understanding the Basics](#understanding-the-basics)
5. [How to Use the Algorithm](#how-to-use-the-algorithm)
6. [Understanding the Schedule Output](#understanding-the-schedule-output)
7. [Common Scenarios and Solutions](#common-scenarios-and-solutions)
8. [Troubleshooting](#troubleshooting)
9. [Technical Information](#technical-information)

---

## What is This Algorithm?

The **NOC Scheduling Algorithm** is an intelligent software tool designed to automatically create work schedules for Network Operations Center (NOC) teams. Think of it as a smart assistant that considers all your workplace rules, employee availability, holidays, and cultural requirements to generate fair and efficient work schedules.

### What Makes It Special?
- **Intelligent**: Uses advanced algorithms to solve complex scheduling puzzles
- **Fair**: Ensures equal distribution of workload among team members
- **Cultural-Aware**: Handles special requirements during Ramadan
- **Flexible**: Adapts to different team sizes and requirements
- **Reliable**: Guarantees all shifts are properly covered with qualified staff

---

## Who Should Use This Guide?

This guide is designed for:
- **Team Managers**: Who need to create monthly schedules
- **HR Personnel**: Responsible for workforce planning
- **Supervisors**: Who monitor shift coverage and fairness
- **Non-Technical Users**: Who want to understand how the algorithm works

**No programming knowledge required!** This guide explains everything in simple terms.

---

## Key Features

### 🕐 Multiple Shift Types
- **Morning Shifts (M)**: Regular daytime work
- **Evening Shifts (E)**: Afternoon/evening coverage
- **Night Shifts (N)**: Overnight operations
- **Ramadan Shifts**: Special shifts during the holy month with adjusted timings

### 🏖️ Holiday & Weekend Management
- Automatic holiday detection from your calendar
- Special holiday shifts with premium staffing
- Weekend coverage ensuring business continuity
- Regional calendar support (Hijri and Gregorian)

### 👥 Smart Team Management
- **Expert vs. Beginner** classification
- Automatic supervision pairing (beginners always work with experts)
- Fair workload distribution based on experience levels
- Vacation balance consideration for off-day allocation

### ⚖️ Fairness Guarantees
- Equal distribution of weekend and holiday work
- Balanced shift assignments over time
- Consideration of remaining vacation days
- Prevention of excessive consecutive shifts

### 🔧 Customizable Rules
- Enable/disable specific scheduling rules as needed
- Adapt to your organization's unique requirements
- Easy modification without technical expertise

---

## Understanding the Basics

### Employee Types
The algorithm recognizes two types of employees:

**Experts (E)**
- Experienced team members who can work independently
- Can supervise and guide beginners

**Beginners (B)**
- Newer team members requiring supervision
- Must always work alongside at least one expert

### Shift Categories

**Normal Days**
- **M (Morning)**: Standard day shift
- **E (Evening)**: Standard evening shift  
- **N (Night)**: Standard night shift

**Ramadan Days** (Special cultural/religious period)
- **MR (Morning Ramadan)**: Adjusted morning hours
- **E1R (Evening 1 Ramadan)**: First evening shift with special timing
- **E2R (Evening 2 Ramadan)**: Second evening shift with special timing
- **NR (Night Ramadan)**: Night shift with special considerations

**Holiday Variants**
- All shift types get an "H" prefix on holidays (e.g., HM, HE, HN)
- Holiday shifts may have different staffing requirements

**Special States**
- **OFF**: Scheduled day off
- **No Shift Assigned - Rest**: Mandatory rest day (cannot be changed)

### Calendar Integration
The algorithm automatically identifies:
- **Weekdays**: Sunday through Thursday (normal work days)
- **Weekends**: Friday and Saturday (require special coverage)
- **Holidays**: National and religious holidays from your calendar
- **Ramadan Period**: Automatically calculated based on Islamic calendar

---

## How to Use the Algorithm

### Installation

Before using the algorithm, you need to install the package and its dependencies.

#### Method 1: Install from Source (Recommended)

**Prerequisites:**
- Python 3.8 or higher
- pip (Python package installer)

**Installation Steps:**

1. **Navigate to the Package Directory**
   ```bash
   # Navigate to the scheduling_package directory
   cd c:\Projects\scheduling_package
   ```

2. **Install the Package**
   ```bash
   # Install in development mode (recommended for customization)
   pip install -e .
   
   # Or install normally
   pip install .
   ```

3. **Verify Installation**
   ```bash
   # Test the command-line interface
   modular-scheduling --help
   
   # Note: The web UI (scheduling-ui) requires additional setup
   # See Method 3 below for web interface setup
   ```

#### Method 2: Run Directly Without Package Installation

If you prefer to run the algorithm directly from source without installing the package:

```bash
# First, install only the required dependencies manually
pip install ortools>=9.0.0 hijri-converter>=2.2.4 streamlit>=1.28.0 pandas>=1.5.0 numpy>=1.21.0 typing-extensions>=4.0.0

# Then navigate to the package directory and run directly
cd c:\Projects\scheduling_package\modular_scheduling
python modular_scheduler.py --help
```

**Note**: When you use Method 1 (`pip install .` or `pip install -e .`), all dependencies are automatically installed from the package's `setup.py` configuration, so you don't need to install them manually.

#### Method 3: Web Interface Setup (Optional)

For the web-based interface, you need to copy the UI module from the main OR-Tools project:

```bash
# Copy the web UI module from the main project
copy "c:\Projects\OR-Tools\Real Projects\modular_scheduling\modular_ui.py" "c:\Projects\scheduling_package\modular_scheduling\"

# Then install the package with the UI
pip install -e .

# Now you can use the web interface
scheduling-ui
```

#### Development Installation (For Developers)

If you plan to modify or contribute to the algorithm:

```bash
pip install -e .
# Install with development dependencies
pip install -e ".[dev]"

# Install with documentation dependencies  
pip install -e ".[docs]"

# Install with all optional dependencies
pip install -e ".[dev,docs]"
```

**Windows Notes:**
- If you encounter issues with OR-Tools installation, you might need Microsoft Visual C++ 14.0 or greater
- Use PowerShell or Command Prompt as Administrator if you get permission errors
- On some Windows systems, you may need to use `python -m pip` instead of just `pip`

### Quick Start

Once installed, you can run the algorithm in several ways:

**Option 1: Command Line (Always Available)**
```bash
# Run the scheduling algorithm directly
modular-scheduling --help

# Or run directly from source
python c:\Projects\scheduling_package\modular_scheduling\modular_scheduler.py --help
```

**Option 2: Web Interface (If UI Module is Set Up)**
```bash
# Launch the web-based user interface (requires Method 3 installation above)
scheduling-ui
```
This will start a local web server and open the algorithm interface in your browser.

**Option 3: Direct Python Import**
```python
# For programmatic use in your own Python scripts
from modular_scheduling.modular_scheduler import main
# Your code here
```

**Getting Started Quickly:**

**Easiest Method (Automatic Dependencies):**
1. Navigate to package: `cd c:\Projects\scheduling_package`
2. Install with dependencies: `pip install -e .`
3. Run: `modular-scheduling --help`

**Manual Method (If you prefer not to install the package):**
1. Install dependencies manually: `pip install ortools hijri-converter streamlit pandas numpy typing-extensions`
2. Navigate to: `cd c:\Projects\scheduling_package\modular_scheduling`
3. Run: `python modular_scheduler.py --help`

---

### Method 1: Web Interface (Recommended for Most Users)

**Step 1: Launch the Algorithm**
1. Open your web browser
2. Navigate to the algorithm URL (provided by your IT team)
3. You'll see a user-friendly interface with clear sections

**Step 2: Enter Basic Information**
- **Year and Month**: Select the period you want to schedule
- **Team Size**: The algorithm will ask how many employees to schedule

**Step 3: Add Employee Information**
For each team member, provide:
- **Employee Type**: Expert or Beginner
- **Remaining Vacation Days**: How many vacation days they have left

**Step 4: Upload Holiday Calendar (Optional)**
- If you have a special holiday file, upload it

**Step 5: Configure Rules (Advanced)**
Most users can skip this section, but you can:
- Enable/disable specific scheduling rules
- Adjust minimum shift requirements
- Modify fairness settings

**Step 6: Generate Schedule**
- Click "Generate Schedule"
- Wait for the algorithm to process (maybe take afew seconds)
- Review the generated schedule

### Method 2: File-Based Input

If your organization prefers file-based processes:
1. Prepare an employee data file with required information
2. Ensure holiday calendar is in the correct format
3. Run the algorithm with these files as input

---

## Understanding the Schedule Output

### Reading the Schedule

The algorithm generates a calendar-style schedule showing:
- **Rows**: Each day of the month
- **Columns**: Each team member
- **Cells**: Assigned shift or status for each person each day

### Color Coding (Web Interface)
- **Blue**: Normal shifts (M, E, N)
- **Green**: Ramadan shifts (MR, E1R, E2R, NR)
- **Red**: Holiday shifts (HM, HE, HN, etc.)
- **Gray**: Off days
- **White**: Rest days (mandatory)

### Schedule Statistics
The algorithm provides helpful statistics:
- **Total shifts per employee**: Ensuring fairness
- **Weekend/Holiday distribution**: Showing equal sharing
- **Shift type distribution**: Balanced assignment patterns
- **Overtime indicators**: If someone exceeds normal limits

### Generated Files
The algorithm creates several detailed reports:

**1. Input Summary**
- All the parameters you entered
- Which rules were enabled/disabled
- Team composition details

**2. Schedule Solution**
- Complete day-by-day assignments
- Easy-to-read format for printing or sharing

**3. Off-Days Distribution**
- Calculation details for vacation day allocation
- Fairness metrics and explanations

**4. Calendar Information**
- Holiday and weekend identification
- Ramadan period calculations

---

## Common Scenarios and Solutions

### Scenario 1: "The Algorithm Says No Solution Found"
**What this means**: Your requirements cannot be met with the current team size or constraints.

**Solutions**:
- Add more team members
- Reduce minimum shift requirements
- Check if vacation day allocations are realistic

### Scenario 2: "Someone Has Too Many Shifts"
**What this means**: The workload distribution isn't perfectly even.

**Solutions**:
- Enable the "Fair Distribution" constraints
- Increase the solution search time
- Consider if the person has fewer vacation days (affecting their off-day allocation)

### Scenario 3: "Weekend Coverage Looks Uneven"
**What this means**: Some people work more weekends than others.

**Solutions**:
- Ensure "Fair Weekend Distribution" is enabled
- Check that you have enough team members for weekend coverage
- Consider the impact of vacation day differences

### Scenario 4: "Ramadan Shifts Aren't Working"
**What this means**: The algorithm can't properly assign special Ramadan shifts.

**Solutions**:
- Verify the Ramadan period is correctly calculated
- Ensure you have enough experts for supervision during Ramadan
- Check that Ramadan-specific constraints are enabled

### Scenario 5: "Holiday Coverage Is Missing"
**What this means**: Some holidays don't have proper shift coverage.

**Solutions**:
- Upload a complete holiday calendar file
- Enable holiday shift constraints
- Ensure minimum holiday staffing requirements are met

---

## Troubleshooting

### Common Issues and Quick Fixes

**Issue**: Algorithm is very slow
- **Solution**: Reduce the number of solutions requested, try with fewer constraints enabled

**Issue**: Schedule looks unfair
- **Solution**: Enable all fairness constraints

**Issue**: Beginners are working alone
- **Solution**: Ensure "Expert Supervision" constraint is enabled, check expert-to-beginner ratio

**Issue**: Too many consecutive work days
- **Solution**: Enable "Limit Contiguous Shifts" constraint, adjust maximum consecutive days

**Issue**: Off days don't match vacation entitlements
- **Solution**: Verify vacation day numbers are correct, enable vacation-based off-day constraints

### When to Contact Support
Contact your IT team if:
- The algorithm doesn't load or crashes
- You get error messages you don't understand
- The schedule results seem completely wrong
- You need to modify algorithm rules or constraints

---

## Technical Information

### Algorithm Architecture

**Core Components**
- **Scheduler Engine**: Uses Google OR-Tools constraint programming
- **Web Interface**: Built with Streamlit for easy use
- **Constraint Algorithm**: Modular rules that can be enabled/disabled
- **Calendar Integration**: Supports both Gregorian and Hijri calendars

**How It Works**
1. **Input Processing**: Algorithm converts your requirements into mathematical constraints
2. **Optimization**: Advanced algorithms find the best schedule that satisfies all rules
3. **Solution Generation**: Multiple valid schedules may be found
4. **Output Formatting**: Results are presented in user-friendly formats

### Constraint Categories

**Coverage Constraints**
- Ensure all shifts have adequate staffing
- Guarantee weekend and holiday coverage
- Maintain 24/7 operations continuity

**Fairness Constraints**
- Equal distribution of workload
- Balanced weekend/holiday assignments
- Fair vacation day consideration

**Safety Constraints**
- Expert supervision for beginners
- Mandatory rest after certain shift sequences
- Limits on consecutive working days

**Cultural Constraints**
- Special Ramadan shift patterns
- Regional holiday observances
- Cultural work week conventions

### File Formats

**Employee Data Input**
Employee information is entered through the web interface with the following parameters:
- **Employee Type**: `EXPERT` or `BEGINNER`
- **Vacation Days**: Integer value (0-21 for experts, 0-14 for beginners)

No separate employee data file is required - all input is handled through the interactive web interface.

**Holiday File Format**
Upload a text file (.txt) with holidays using this exact format:
```
day; month; description
1; 1; New Year's Day
15; 8; Independence Day
25; 12; Christmas Day
```

Format requirements:
- Each line contains: `day; month; description`
- Semicolon (`;`) separated values
- Day and month as integers (e.g., 1-31 for day, 1-12 for month)
- Description is optional but recommended for clarity
- Lines starting with "day" are treated as headers and ignored
- Empty lines are ignored
- File encoding: UTF-8

**Generated Output Files**
The algorithm automatically creates several output files with structured formats:

1. **Input Summary** (`input_summary_YYYY_MM_timestamp.txt`)
   - Contains all input parameters and constraint settings
   - Employee details and configuration used

2. **Solution File** (`solution_YYYY_MM_timestamp_sol1.txt`)
   - Complete day-by-day schedule assignments
   - Employee-day-shift mappings in readable format

3. **Off-Days Distribution** (`off_days_distribution_YYYY_MM_timestamp.txt`)
   - Detailed vacation day calculations and allocations
   - Fairness metrics and distribution analysis

4. **Calendar Information** (`month_calendar_info_YYYY_MM_timestamp.txt`)
   - Holiday identification and weekend classification
   - Ramadan period calculations and special day markings

### Dependencies and Requirements
- **OR-Tools**: Advanced optimization library by Google
- **Hijri-Converter**: Islamic calendar calculations
- **Streamlit**: Web interface framework
- **Pandas**: Data processing and display

### Performance Considerations
- **Small teams** (5-10 people): Solutions in seconds
- **Medium teams** (10-20 people): Solutions in 1-3 minutes
- **Large teams** (20+ people): May require 5-10 minutes
- **Complex constraints**: Increase processing time

### Data Privacy and Security
- No employee data is stored permanently
- All processing happens locally or on your secure servers
- Generated schedules can be exported and deleted from the algorithm
- No external data transmission required

### Customization Options

**Available Rule Modifications**
- Minimum number of people per shift
- Maximum consecutive working days
- Weekend/holiday distribution preferences
- Vacation day calculation methods
- Rest day requirements

**Advanced Configurations**
- Shift timing adjustments
- Employee skill level definitions
- Holiday calendar modifications
- Reporting format customizations

### Version Information
- **Current Version**: 1.0.0 (Modular Architecture)
- **Developer**: Innovation Team - Digital Transformation Directorate
- **License**: Proprietary software for organizational use

### Support and Maintenance
- Regular updates to improve performance and add features
- Technical support available through your IT department
- User training sessions can be arranged
- Documentation updates provided with new releases

---

*This guide covers the complete functionality of the NOC Scheduling Algorithm. For technical support or advanced customization requests, please contact your IT department or algorithm administrator.*
