"""
Setup configuration for the Modular NOC Scheduling Algorithm Package.

This package provides a comprehensive employee scheduling system using OR-Tools constraint
programming solver with a modular constraint architecture.
"""

from setuptools import setup, find_packages
import os

# Read the README file for the long description
def read_readme():
    """Read README.md for the long description."""
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return "A comprehensive employee scheduling system using OR-Tools constraint programming solver."

# Read version from __init__.py
def get_version():
    """Extract version from the package __init__.py file."""
    init_path = os.path.join(os.path.dirname(__file__), 'modular_scheduling', '__init__.py')
    with open(init_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.startswith('__version__'):
                return line.split('=')[1].strip().strip('"').strip("'")
    return "1.0.0"

setup(
    name="modular-noc-scheduling",
    version=get_version(),
    author="Innovation Team - Digital Transformation",
    description="Shift Scheduling Algorithm using OR-Tools with Modular Constraints",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Office/Business :: Scheduling",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Core dependencies - always required
        "ortools>=9.0.0",
        "hijri-converter>=2.2.4",
    ],
    extras_require={
        "ui": [
            # Web interface dependencies
            "streamlit>=1.28.0",
            "pandas>=1.5.0",
        ],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=1.0.0",
            "pre-commit>=2.20.0",
        ],
        "docs": [
            "sphinx>=5.0.0",
            "sphinx-rtd-theme>=1.0.0",
            "myst-parser>=0.18.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "modular-scheduling=modular_scheduling.modular_scheduler:main",
            # "scheduling-ui=modular_scheduling.modular_ui:main",  # Uncomment when UI module is added
        ],
    },
    package_data={
        "modular_scheduling": [
            "constraints/*.py",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords=[
        "scheduling",
        "optimization",
        "constraint-programming",
        "ortools",
        "employee-scheduling",
        "shift-scheduling",
        "noc-scheduling",
        "ramadan-scheduling",
        "holiday-scheduling",
        "workforce-management",
    ],
    project_urls={
        "Bug Reports": "",
        "Source": "",
        "Documentation": "",
    },
)