def hello() -> str:
    return "Hello from django-global-search!"
