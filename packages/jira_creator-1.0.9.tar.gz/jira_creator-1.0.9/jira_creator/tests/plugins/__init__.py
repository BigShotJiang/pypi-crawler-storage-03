#!/usr/bin/env python
"""Test suite for plugin infrastructure."""
