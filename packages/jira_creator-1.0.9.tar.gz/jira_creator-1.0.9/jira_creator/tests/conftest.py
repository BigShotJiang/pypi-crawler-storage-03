#!/usr/bin/env python
"""
Pytest configuration and fixtures for the plugin-based architecture.

This module provides basic pytest configuration.
"""
