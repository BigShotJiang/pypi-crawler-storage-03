# fastjsondiff

A fast JSON diff library written in Rust with Python bindings.

## Install

```bash
pip install maturin
maturin develop
```
