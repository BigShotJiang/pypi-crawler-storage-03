"""Deduplication methodologies."""

from matchbox.client.models.dedupers.naive import NaiveDeduper

__all__ = ("NaiveDeduper",)
