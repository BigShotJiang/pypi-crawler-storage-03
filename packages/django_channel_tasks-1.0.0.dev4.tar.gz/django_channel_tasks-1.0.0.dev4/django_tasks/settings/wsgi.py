from django_tasks.settings.base import *  # noqa


ROOT_URLCONF = 'django_tasks.wsgi_url_conf'

WSGI_APPLICATION = 'django_tasks.wsgi.application'
