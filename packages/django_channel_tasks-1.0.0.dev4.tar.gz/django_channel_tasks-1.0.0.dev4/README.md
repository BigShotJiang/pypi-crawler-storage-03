# PyPI distribution
[![PyPI version](https://badge.fury.io/py/django-channel-tasks.svg)](https://badge.fury.io/py/django-channel-tasks) [![PyPI downloads](https://img.shields.io/pypi/dm/django-channel-tasks.svg)](https://img.shields.io/pypi/dm/django-channel-tasks)

# Documentation
This project is documented with [Sphinx](https://www.sphinx-doc.org/), HTML documentation may be generated using [Tox](https://tox.wiki/) with `tox -e docs`.

# Maintenance
Are you testing or employing this project? Please, email the author explaining your case! New GitHub issues will also be wellcome.
