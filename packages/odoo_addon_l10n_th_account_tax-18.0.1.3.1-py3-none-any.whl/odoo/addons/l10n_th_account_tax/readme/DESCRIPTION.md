This module address 2 main tax requirement in Thailand

## 1. Tax Invoice (VAT)

Point of tax invoice can occur either on Invoice (VAT) or on Payment
(Undue VAT on invoice become VAT on payment)

## 2. Withholding Tax

This is the tax that is deducted during payment. There are 2 kinds of
withholding tax calculataion.

1.  Fixed rate of based amount, i.e., service 3%
2.  Progressive rate of accumulated amount, i.e., personal income tax
