from .cli import app

app(prog_name="ultrasphere")
