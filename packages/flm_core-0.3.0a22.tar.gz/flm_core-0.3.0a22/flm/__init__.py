

# Version is hard-coded here to avoid any other dependencies (no importlib
# magic, no pkg_resources, no other stuff like that), especially for possible
# future use with transcrypt.

__version__ = "0.3.0alpha000022"

# ALSO BUMP VERSION NUMBER IN pyproject.toml !!
