import sys  
sys.path.append('../')

from src import *

wsjt_all_ab()

