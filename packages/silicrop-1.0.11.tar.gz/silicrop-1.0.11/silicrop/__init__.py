"""
Silicrop - Package for Raman TMD data processing and visualization
"""

# Version
__version__ = "1.0.10"
