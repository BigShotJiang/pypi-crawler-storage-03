"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1bcity/person/v2/carbon.proto\x12\x0ecity.person.v2"\x9f\x01\n\rVehicleCarbon\x12\x0e\n\x02id\x18\x01 \x01(\x05R\x02id\x12\x0e\n\x02ds\x18\x02 \x01(\x01R\x02ds\x12\x0c\n\x01v\x18\x03 \x01(\x01R\x01v\x12\x0c\n\x01a\x18\x04 \x01(\x01R\x01a\x12\x13\n\x05u_acc\x18\x05 \x01(\x01R\x04uAcc\x12\x15\n\x06u_roll\x18\x06 \x01(\x01R\x05uRoll\x12\x15\n\x06u_aero\x18\x07 \x01(\x01R\x05uAero\x12\x0f\n\x03c_d\x18\x08 \x01(\x01R\x02cD""\n\x12EmissionStatistics\x12\x0c\n\x01u\x18\x01 \x01(\x01R\x01uB\xb4\x01\n\x12com.city.person.v2B\x0bCarbonProtoP\x01Z7git.fiblab.net/sim/protos/v2/go/city/person/v2;personv2\xa2\x02\x03CPX\xaa\x02\x0eCity.Person.V2\xca\x02\x0eCity\\Person\\V2\xe2\x02\x1aCity\\Person\\V2\\GPBMetadata\xea\x02\x10City::Person::V2b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'city.person.v2.carbon_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    _globals['DESCRIPTOR']._options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x12com.city.person.v2B\x0bCarbonProtoP\x01Z7git.fiblab.net/sim/protos/v2/go/city/person/v2;personv2\xa2\x02\x03CPX\xaa\x02\x0eCity.Person.V2\xca\x02\x0eCity\\Person\\V2\xe2\x02\x1aCity\\Person\\V2\\GPBMetadata\xea\x02\x10City::Person::V2'
    _globals['_VEHICLECARBON']._serialized_start = 48
    _globals['_VEHICLECARBON']._serialized_end = 207
    _globals['_EMISSIONSTATISTICS']._serialized_start = 209
    _globals['_EMISSIONSTATISTICS']._serialized_end = 243