"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1fcity/ping/v1/ping_service.proto\x12\x0ccity.ping.v1"\r\n\x0bPingRequest"\x0e\n\x0cPingResponse2L\n\x0bPingService\x12=\n\x04Ping\x12\x19.city.ping.v1.PingRequest\x1a\x1a.city.ping.v1.PingResponseB\xab\x01\n\x10com.city.ping.v1B\x10PingServiceProtoP\x01Z3git.fiblab.net/sim/protos/v2/go/city/ping/v1;pingv1\xa2\x02\x03CPX\xaa\x02\x0cCity.Ping.V1\xca\x02\x0cCity\\Ping\\V1\xe2\x02\x18City\\Ping\\V1\\GPBMetadata\xea\x02\x0eCity::Ping::V1b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'city.ping.v1.ping_service_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    _globals['DESCRIPTOR']._options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x10com.city.ping.v1B\x10PingServiceProtoP\x01Z3git.fiblab.net/sim/protos/v2/go/city/ping/v1;pingv1\xa2\x02\x03CPX\xaa\x02\x0cCity.Ping.V1\xca\x02\x0cCity\\Ping\\V1\xe2\x02\x18City\\Ping\\V1\\GPBMetadata\xea\x02\x0eCity::Ping::V1'
    _globals['_PINGREQUEST']._serialized_start = 49
    _globals['_PINGREQUEST']._serialized_end = 62
    _globals['_PINGRESPONSE']._serialized_start = 64
    _globals['_PINGRESPONSE']._serialized_end = 78
    _globals['_PINGSERVICE']._serialized_start = 80
    _globals['_PINGSERVICE']._serialized_end = 156