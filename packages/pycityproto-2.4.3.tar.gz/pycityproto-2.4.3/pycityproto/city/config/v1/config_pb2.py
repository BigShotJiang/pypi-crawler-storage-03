"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1bcity/config/v1/config.proto\x12\x0ecity.config.v1"-\n\tMongoPath\x12\x0e\n\x02db\x18\x01 \x01(\tR\x02db\x12\x10\n\x03col\x18\x02 \x01(\tR\x03col" \n\x0cOutputTarget\x12\x10\n\x03sql\x18\x01 \x01(\tR\x03sqlB\xb4\x01\n\x12com.city.config.v1B\x0bConfigProtoP\x01Z7git.fiblab.net/sim/protos/v2/go/city/config/v1;configv1\xa2\x02\x03CCX\xaa\x02\x0eCity.Config.V1\xca\x02\x0eCity\\Config\\V1\xe2\x02\x1aCity\\Config\\V1\\GPBMetadata\xea\x02\x10City::Config::V1b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'city.config.v1.config_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    _globals['DESCRIPTOR']._options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x12com.city.config.v1B\x0bConfigProtoP\x01Z7git.fiblab.net/sim/protos/v2/go/city/config/v1;configv1\xa2\x02\x03CCX\xaa\x02\x0eCity.Config.V1\xca\x02\x0eCity\\Config\\V1\xe2\x02\x1aCity\\Config\\V1\\GPBMetadata\xea\x02\x10City::Config::V1'
    _globals['_MONGOPATH']._serialized_start = 47
    _globals['_MONGOPATH']._serialized_end = 92
    _globals['_OUTPUTTARGET']._serialized_start = 94
    _globals['_OUTPUTTARGET']._serialized_end = 126