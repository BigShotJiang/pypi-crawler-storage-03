# cityproto

CityProto is a protobuf-based data exchange format for FIBLAB projects.
It is designed to be used in Golang, Python, and JavaScript/TypeScript projects.

Documentation: [https://cityproto.readthedocs.io/en/latest/](https://cityproto.readthedocs.io/en/latest/)
