# ml_eval_viz

A custom python package for Machine Learning model evaluation and visualization.

## Installation

```bash
$ pip install ml_eval_viz
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`ml_eval_viz` was created by Vaibhav Kiran Ghaisas. It is licensed under the terms of the MIT license.

## Credits

`ml_eval_viz` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
