from django.apps import AppConfig


class ApisHighlighterConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "apis_highlighter"

    def ready(self):
        from . import signals  # NOQA
