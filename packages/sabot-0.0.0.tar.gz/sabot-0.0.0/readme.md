# Sabot

**Sabot** is a command-line note-taking database, written in Python 3.13 by Stephen Malone.
