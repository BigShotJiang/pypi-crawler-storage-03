# Interactive API

::: dotevals.interactive.run
    options:
      show_root_heading: true
      show_source: true

::: dotevals.interactive.Results
    options:
      show_root_heading: true
      show_source: true
      members:
        - records
        - summary
