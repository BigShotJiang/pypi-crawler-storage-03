from lhammai_cli.main import main  # type: ignore
