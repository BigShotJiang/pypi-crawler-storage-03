# about.py

__version__ = "0.1.5"
__package__ = "manuscript_cover_letter"
__program_name__ = "manuscript-cover-letter"
__author__ = "Fernando Pujaico Rivera" 
__email__  = "fernando.pujaico.rivera@gmail.com"
__description__ = "Program to generate manuscript cover letters."
__url_source__  = "https://github.com/trucomanx/ManuscriptCoverLetter"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_bugs__    = "https://github.com/trucomanx/ManuscriptCoverLetter/issues"
