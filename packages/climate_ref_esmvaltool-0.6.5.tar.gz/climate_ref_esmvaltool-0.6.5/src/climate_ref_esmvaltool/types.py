from typing import Any

Recipe = dict[str, Any]

MetricBundleArgs = dict[str, Any]
OutputBundleArgs = dict[str, Any]
