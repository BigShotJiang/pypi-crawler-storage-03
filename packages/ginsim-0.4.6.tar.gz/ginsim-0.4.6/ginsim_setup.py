from colomoto.setup_helper import setup
setup({"pkg": "colomoto/ginsim",
        "check_progs": ["GINsim"]},
    {"pkg": "potassco/clingo",
        "check_progs": ["clingo"]})
