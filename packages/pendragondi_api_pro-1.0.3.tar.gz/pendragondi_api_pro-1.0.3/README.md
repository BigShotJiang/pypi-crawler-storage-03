# PendragonDI API Pro

Context-rich, in-app duplicate detection for Python — real-time, local, and secure.

## 🚀 Quickstart (Simple Mode)

```python
from pendragondi_api_pro import duplicate_guard

@duplicate_guard
def call_api(...):
    ...
```

## ⚡️ Advanced Usage

```python
from pendragondi_api_pro import duplicate_guard_pro

@duplicate_guard_pro(window_ms=3000, capture_args=False, rate_limit_per_minute=60)
def call_api(...):
    ...
```

## 📂 Examples

- [examples/guard_simple.py](examples/guard_simple.py)
- [examples/guard_advanced.py](examples/guard_advanced.py)

## 📦 Export Reports

```python
from pendragondi_api_pro import get_event_log, export_html

events = get_event_log().snapshot()
export_html(events, "report.html")
```

## 🖥 Optional CLI (Windows Caveat)

You can also use the tool via command line:

```bash
python -m pendragondi_api_pro export --output myreport.html --format html
```

> ℹ️ Note: The `pendragondi-api-pro` CLI script may not resolve correctly on some Windows setups due to Python packaging limitations. We recommend using `python -m pendragondi_api_pro` for consistent cross-platform behavior.

## 🛠 Configuration

- `window_ms`: Deduplication window (ms, default: 2000)
- `capture_args`: Whether to log/redact args (default: True)
- `stack_depth`: How many frames to capture (default: 6)
- `rate_limit_per_minute`: Bucket per-op deduplication (optional)

## 🔒 Privacy

No telemetry. Redaction for PII by default. See `redact.py` for implementation.

## 💬 Support/Contact

- Open an issue or email [pendragondi@pendragondi.dev](mailto:pendragondi@pendragondi.dev)

---

## 📜 License

[MIT License](LICENSE)

---

## 🧭 Why PendragonDI?

PendragonDI API Pro was built to solve the *next layer* of API waste and developer friction — giving you real-time, context-rich duplicate detection with privacy and speed at the core.

No agents. No data sales. No telemetry. Just the signal you need to debug smarter.

---

## 🤝 Contributing

Contributions are welcome! If you have suggestions for improvements or find a bug, please open an issue or submit a pull request.

When contributing:
- Fork the repository and create your branch from `main`
- Ensure any new code has appropriate type hints and docstrings
- Run the test suite and add tests for new functionality
- Submit a descriptive pull request so changes can be reviewed efficiently

---

## 💖 Support the Project

PendragonDI API Pro is open-source and free to use.  
If you’ve found it useful and would like to support ongoing development, you can sponsor us on GitHub:  
[![Sponsor on GitHub](https://img.shields.io/badge/Sponsor-💖-pink?style=flat)](https://github.com/sponsors/jinpendragon)
