__version__ = "1.0.6"

from .datau import autorun

__all__ = [
	"autorun",
	"__version__"
]
