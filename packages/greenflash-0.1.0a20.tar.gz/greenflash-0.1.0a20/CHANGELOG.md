# Changelog

## 0.1.0-alpha.20 (2025-08-26)

Full Changelog: [v0.1.0-alpha.19...v0.1.0-alpha.20](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.19...v0.1.0-alpha.20)

### Chores

* **internal:** change ci workflow machines ([2be4f09](https://github.com/greenflash-ai/python/commit/2be4f09577140eb0f2b9a4e27e7e0ff3d08d6021))
* update github action ([ad2e871](https://github.com/greenflash-ai/python/commit/ad2e871bbe5feaf7946f5abcb05ab4b5be440d1e))
* update SDK preview from latest OpenAPI spec ([835b699](https://github.com/greenflash-ai/python/commit/835b699c2d5d33a33096661fd8dc9b964ea0a071))

## 0.1.0-alpha.19 (2025-08-10)

Full Changelog: [v0.1.0-alpha.18...v0.1.0-alpha.19](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.18...v0.1.0-alpha.19)

### Chores

* **internal:** update comment in script ([057d62c](https://github.com/greenflash-ai/python/commit/057d62c099f5116d51c7a1d1de4101da66702864))
* update @stainless-api/prism-cli to v5.15.0 ([743f2a2](https://github.com/greenflash-ai/python/commit/743f2a2aa59d351b9dcac900604b9e849895d8b5))

## 0.1.0-alpha.18 (2025-08-06)

Full Changelog: [v0.1.0-alpha.17...v0.1.0-alpha.18](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.17...v0.1.0-alpha.18)

### Chores

* **internal:** fix ruff target version ([afac1f2](https://github.com/greenflash-ai/python/commit/afac1f2690faf9cb11bf470c3c0bd52ecc739486))

## 0.1.0-alpha.17 (2025-07-31)

Full Changelog: [v0.1.0-alpha.16...v0.1.0-alpha.17](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.16...v0.1.0-alpha.17)

### Features

* **client:** support file upload requests ([085ba90](https://github.com/greenflash-ai/python/commit/085ba90d92cf23b25d6e083afc1af1343d7e3565))

## 0.1.0-alpha.16 (2025-07-30)

Full Changelog: [v0.1.0-alpha.15...v0.1.0-alpha.16](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.15...v0.1.0-alpha.16)

### Features

* **api:** manual updates ([757505f](https://github.com/greenflash-ai/python/commit/757505f93ab46214f699ba52f8c6689846c112c2))

## 0.1.0-alpha.15 (2025-07-27)

Full Changelog: [v0.1.0-alpha.14...v0.1.0-alpha.15](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.14...v0.1.0-alpha.15)

### Features

* **api:** manual updates ([5f77c93](https://github.com/greenflash-ai/python/commit/5f77c9308e3560443e88c4026affdb7324f61746))

## 0.1.0-alpha.14 (2025-07-27)

Full Changelog: [v0.1.0-alpha.13...v0.1.0-alpha.14](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.13...v0.1.0-alpha.14)

### Features

* **api:** manual updates ([219e7c2](https://github.com/greenflash-ai/python/commit/219e7c233e96246bb41d68a9671c0f03de08fc08))


### Chores

* update SDK preview from latest OpenAPI spec ([fd4a512](https://github.com/greenflash-ai/python/commit/fd4a512fb2bd72770be95f14655af007bbcea992))

## 0.1.0-alpha.13 (2025-07-25)

Full Changelog: [v0.1.0-alpha.12...v0.1.0-alpha.13](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.12...v0.1.0-alpha.13)

### Chores

* **project:** add settings file for vscode ([ee68cef](https://github.com/greenflash-ai/python/commit/ee68cef4af865b09b76ee193c4123bee50ef7a78))

## 0.1.0-alpha.12 (2025-07-23)

Full Changelog: [v0.1.0-alpha.11...v0.1.0-alpha.12](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.11...v0.1.0-alpha.12)

### Bug Fixes

* **parsing:** parse extra field types ([d71ef29](https://github.com/greenflash-ai/python/commit/d71ef29551c3e051a0bd9441ac4e6539ce12aa0e))

## 0.1.0-alpha.11 (2025-07-22)

Full Changelog: [v0.1.0-alpha.10...v0.1.0-alpha.11](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.10...v0.1.0-alpha.11)

### Bug Fixes

* **parsing:** ignore empty metadata ([52ffaf5](https://github.com/greenflash-ai/python/commit/52ffaf52a8a9549ea31ab90258172f7dad29dff2))

## 0.1.0-alpha.10 (2025-07-16)

Full Changelog: [v0.1.0-alpha.9...v0.1.0-alpha.10](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.9...v0.1.0-alpha.10)

### Features

* **api:** manual updates ([3c2c8f0](https://github.com/greenflash-ai/python/commit/3c2c8f06e3857e66a7b69862408d8801657ce659))

## 0.1.0-alpha.9 (2025-07-16)

Full Changelog: [v0.1.0-alpha.8...v0.1.0-alpha.9](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.8...v0.1.0-alpha.9)

### Features

* **api:** manual updates ([e8c6148](https://github.com/greenflash-ai/python/commit/e8c61489e7d62904e3374ca758e2a0598f682702))
* **api:** manual updates ([b6c96d1](https://github.com/greenflash-ai/python/commit/b6c96d178ee487d96a3e7f7ac76618cc2a63241f))
* **api:** manual updates ([5191242](https://github.com/greenflash-ai/python/commit/5191242eec24b127b45c685dee713ac594ffc94c))
* **api:** manual updates ([106a53a](https://github.com/greenflash-ai/python/commit/106a53a65052605b46a881148e3e58180bc1b6cf))


### Chores

* update SDK settings ([6534280](https://github.com/greenflash-ai/python/commit/65342808d7b94310c586eaf03fbf95fcb519b62e))

## 0.1.0-alpha.8 (2025-07-15)

Full Changelog: [v0.1.0-alpha.7...v0.1.0-alpha.8](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.7...v0.1.0-alpha.8)

### Features

* clean up environment call outs ([26dae3f](https://github.com/greenflash-ai/python/commit/26dae3f89b18c9fd0e2a8cb67c06e41dac85b78d))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([0a99115](https://github.com/greenflash-ai/python/commit/0a9911546ece38d7291bacd6bfd2c20cd93f83fc))

## 0.1.0-alpha.7 (2025-07-11)

Full Changelog: [v0.1.0-alpha.6...v0.1.0-alpha.7](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.6...v0.1.0-alpha.7)

### Features

* **api:** update via SDK Studio ([0210ab0](https://github.com/greenflash-ai/python/commit/0210ab0278c2b3671ffda8739ca86fceca4329a0))
* **api:** update via SDK Studio ([836936c](https://github.com/greenflash-ai/python/commit/836936c7d4ba33e3b3d505825a109cdca3fca052))
* **api:** update via SDK Studio ([bd820b1](https://github.com/greenflash-ai/python/commit/bd820b145c606529e0c417941ca846e9f584582a))

## 0.1.0-alpha.6 (2025-07-11)

Full Changelog: [v0.1.0-alpha.5...v0.1.0-alpha.6](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.5...v0.1.0-alpha.6)

### Features

* **api:** update via SDK Studio ([69f3681](https://github.com/greenflash-ai/python/commit/69f368198a3db3c17ab739a565e6689f3f9e9e52))
* **api:** update via SDK Studio ([c658099](https://github.com/greenflash-ai/python/commit/c658099d8d4375b0aa82dd13c8fb510aad202dfe))
* **api:** update via SDK Studio ([0680595](https://github.com/greenflash-ai/python/commit/06805958d60a1c1466ca1e296191999470431a4e))


### Chores

* update SDK settings ([874a6e7](https://github.com/greenflash-ai/python/commit/874a6e71bdc746659737dac133fb01fe251074e7))

## 0.1.0-alpha.5 (2025-07-11)

Full Changelog: [v0.1.0-alpha.4...v0.1.0-alpha.5](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.4...v0.1.0-alpha.5)

### Chores

* **internal:** version bump ([ba385a4](https://github.com/greenflash-ai/python/commit/ba385a4c4f4f35c7f0c37eed452d1a606aed3758))

## 0.1.0-alpha.4 (2025-07-11)

Full Changelog: [v0.1.0-alpha.3...v0.1.0-alpha.4](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.3...v0.1.0-alpha.4)

### Chores

* **internal:** codegen related update ([084e7cf](https://github.com/greenflash-ai/python/commit/084e7cf7b896d1b965d4e78b9693c61bc277ab6b))
* **internal:** version bump ([851db65](https://github.com/greenflash-ai/python/commit/851db6588128dd72d9f6dfd284872df1daf9c5aa))
* **readme:** fix version rendering on pypi ([0c61810](https://github.com/greenflash-ai/python/commit/0c61810050e91daf95abfdf1c41dee883eddd0c3))

## 0.1.0-alpha.3 (2025-07-11)

Full Changelog: [v0.1.0-alpha.2...v0.1.0-alpha.3](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.2...v0.1.0-alpha.3)

### Features

* **api:** update via SDK Studio ([1f79f04](https://github.com/greenflash-ai/python/commit/1f79f0435f81adbb6dea933e848e494c87129b15))
* **api:** update via SDK Studio ([c713904](https://github.com/greenflash-ai/python/commit/c7139040e0ad0a006a9eef001400273b86e3f4ee))

## 0.1.0-alpha.2 (2025-07-11)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/greenflash-ai/python/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Features

* **api:** update via SDK Studio ([964401f](https://github.com/greenflash-ai/python/commit/964401fc840c7d188f5125ff1f6a12e787d85ad4))

## 0.1.0-alpha.1 (2025-07-09)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/greenflash-ai/python/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** update via SDK Studio ([6675f34](https://github.com/greenflash-ai/python/commit/6675f34410ea25b5251e3815114073b0a70de4ce))


### Chores

* update SDK settings ([0ed597f](https://github.com/greenflash-ai/python/commit/0ed597fa0c193b51228497dcb5c0cd732135e1f0))
* update SDK settings ([f67dad2](https://github.com/greenflash-ai/python/commit/f67dad26f22148bfe122e939b7bc6c4bf904a7d7))
