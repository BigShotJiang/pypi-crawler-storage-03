# unicrypto
Unified interface for some crypto algos
