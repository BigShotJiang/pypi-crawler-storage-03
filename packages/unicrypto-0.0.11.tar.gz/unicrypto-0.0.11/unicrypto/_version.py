__version__ = "0.0.11"
__banner__ = \
"""
# unicrypto %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__
