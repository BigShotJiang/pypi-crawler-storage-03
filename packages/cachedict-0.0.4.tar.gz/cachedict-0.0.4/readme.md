# Python cache dict.

## Installation

You can install via [pypi](https://pypi.org/project/cachedict/)

```console
pip install -U cachedict
```

## Usage

```python
from cachedict import FIFODict, LRUDict, LFUDict, TTLDict, TLRUDict
```
