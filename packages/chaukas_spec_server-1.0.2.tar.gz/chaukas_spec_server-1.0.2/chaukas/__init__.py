"""Chaukas Server SDK

Server-side Python framework for implementing the Chaukas agent audit and explainability platform.
"""

__version__ = "1.0.2"
__author__ = "Chaukas Team"
__license__ = "Apache-2.0"