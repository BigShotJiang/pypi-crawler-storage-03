# -*- coding: utf-8 -*-


class IllegalTransactionStateException(Exception):
    pass
