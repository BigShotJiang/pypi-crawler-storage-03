# -*- coding: utf-8 -*-


class Configuration:
    """
    配置项\n
    """
    pass


class Bean:
    """
    pojo\n
    """
    pass
