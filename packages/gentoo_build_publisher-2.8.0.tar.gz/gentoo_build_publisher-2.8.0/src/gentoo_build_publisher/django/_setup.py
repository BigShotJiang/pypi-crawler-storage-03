"""So we don't have to do import django; django.setup()"""

import django

django.setup()
