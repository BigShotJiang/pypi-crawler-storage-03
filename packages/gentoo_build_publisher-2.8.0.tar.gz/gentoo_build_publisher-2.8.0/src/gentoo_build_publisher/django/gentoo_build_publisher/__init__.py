"""The Gentoo Build Publisher Django App

This subpackage contains the INSTALLED_APP Django parts of Gentoo Build Publisher.
"""

# pylint: disable=invalid-name
default_app_config = "gentoo_build_publisher.apps.GentooBuildPublisherConfig"
