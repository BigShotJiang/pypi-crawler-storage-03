from sharetrace.st import install_exception_hook

__all__ = [
    'install_exception_hook',
]
