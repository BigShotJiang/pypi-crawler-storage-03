在您提交issue之前， 请先根据您的issue类型选取对应的问题集：

- 缺陷 | BUG
- 需求 | Feature Requests
- 问题 | Question

删除不属于您想要提交的issue类型，并且回答剩余的问题。