# SPDX-FileCopyrightText: 2025-present Walter Daems <walter.daems@uantwerpen.be>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.22"
