# Midas Commercial Data Simulator

The *comdata* module, provided by the *midas-comdata* package, provides a simulator for a commercial building reference data set.

Version: 2.1

## Usage

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

### Inside of midas

To use the store inside of midas, add `comdata` to your modules

```yaml
    my_scenario:
      modules:
        - comdata
        # - ...
```
and provide a *scope* and a configuration:

```yaml
    my_scenario:
      # ...
      comdata_params:
        my_grid_scope:
          interpolate: True
          randomize_data: True
          randomize_cos_phi: True
          mapping:
            22: [[Hospital, 0.002]] # industrial subgrid
            35: [[StripMall, 0.015]]
``` 

The number 22, 35 stands for the bus number, which depends on the grid.

### Any mosaik scenario

If you don't use midas, you can add the `comdata` manually to your [mosaik scenario](https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html) file.
First, the entry in the `sim_config`:

```python
  sim_config = {
      "CommercialDataSimulator": {
        "python": "midas_powerseries.simulator:PowerSeriesSimulator"
      },
      # ...
  }
```

Next, you need to start the simulator (assuming a `step_size` of 900):

```python
    comdata_sim = world.start(
        "CommercialDataSimulator",
        step_size=900,
        data_step_size=3600,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located/",
        filename="commercial_profiles.csv",  # this is default
    )
```

Then the models can be started:

```python
    hospital = comdata_sim.CalculatedQTimeSeries(name="Hospital", scaling=0.002)
    strip_mall = comdata_sim.CalculatedQTimeSeries(name="StripMall", scaling=0.015)
```

Finally, the modells need to be connected to other entities:

```python
    world.connect(hospital, other_entity, "p_mw", "q_mvar")
```

## License

The data set ist taken from the project [Oben Energy Data Initiative](https://data.openei.org/about).

