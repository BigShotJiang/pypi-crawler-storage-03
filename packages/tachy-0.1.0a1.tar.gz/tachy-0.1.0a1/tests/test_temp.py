def test_temp():
    assert isinstance("test", str)
