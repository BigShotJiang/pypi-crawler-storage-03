"""
Esta es la documentacion de player
"""


class Player:
    """
    Esta clase crea un reproductor de musica
    """

    def play(self, song):
        """
        Reproduce la cancion que recibio como parametro

        Parameters:
        song(str): Este es un String con el path de la cancion

        Returns:
        int: devuelve 1 si reprocuce con exito, en caso de fracaso devuelve con 0
        """
        print("Reproduciendo cancion")

    def stop(self):
        print("Stopping")
