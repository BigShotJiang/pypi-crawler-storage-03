For adding commissions on sales orders:

1.  Go to *Sales \> Orders \> Quotations*.
2.  Edit or create a new record.
3.  When you have selected a partner, each new quotation line you add
    will have the agents and commissions set at customer level.
4.  You can add, modify or delete these agents discretely clicking on
    the icon with several persons represented, next to the "Commission"
    field in the list. This icon will be available only if the line
    hasn't been invoiced yet.
5.  If you have configured your system for editing lines in a popup
    window, agents will appear also in this window.
6.  You have a button "Regenerate agents" on the bottom of the page
    "Order Lines" for forcing a recompute of all agents from the partner
    setup. This is needed for example when you have changed the partner
    on the quotation having already inserted lines.
