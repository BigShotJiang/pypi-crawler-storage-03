"""Test package for HooksMCP."""
