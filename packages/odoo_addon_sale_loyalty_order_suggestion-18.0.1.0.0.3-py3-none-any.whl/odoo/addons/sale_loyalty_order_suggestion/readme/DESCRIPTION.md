This module extends the functionality of the sale_loyalty wizard by
giving hints of available promotions and products needed to apply them
to the seller placing the sales order. A product added to the lines of a
sales order will be marked with a gift icon if there is a promotion
containing that product as part of its rules.
