
good_bullins = None
def lazy_import():
    global good_bullins
    from nextera_py import good_bullins
modules = None
def lazy_import():
    global modules
    from nextera_py import modules
__version__ = '0.0.1'
__author__ = 'jason'
__all__ = ['good_builtins', 'modules']