# SPDX-FileCopyrightText: 2025-present lingfish <jason@lucid.net.au>
#
# SPDX-License-Identifier: MIT
