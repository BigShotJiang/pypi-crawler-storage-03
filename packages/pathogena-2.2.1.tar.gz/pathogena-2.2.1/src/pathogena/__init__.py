"""The command line and Python client for EIT Pathogena."""

__version__ = "2.2.1"
