from hestia_earth.earth_engine import init_gee


init_gee()
