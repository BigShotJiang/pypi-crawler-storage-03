########
 inputs
########

.. automodule:: anemoi.inference.input
   :members:
   :no-undoc-members:
   :show-inheritance:

.. include:: ../_api/inference.inputs.rst
