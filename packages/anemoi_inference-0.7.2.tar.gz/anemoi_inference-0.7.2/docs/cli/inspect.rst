.. _inspect_command:

Inspect Command
===============

.. argparse::
    :module: anemoi.inference.__main__
    :func: create_parser
    :prog: anemoi-inference
    :path: inspect
