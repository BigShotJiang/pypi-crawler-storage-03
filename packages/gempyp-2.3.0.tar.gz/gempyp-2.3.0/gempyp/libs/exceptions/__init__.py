class ParseException(ValueError):
    pass

