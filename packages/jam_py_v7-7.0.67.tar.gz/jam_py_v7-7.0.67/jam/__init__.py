__version__ = (7, 0, 67)

def version():
    return '%s.%s.%s' % __version__

