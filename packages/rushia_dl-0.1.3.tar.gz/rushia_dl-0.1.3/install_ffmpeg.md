### for mac
brew postinstall libtasn1
brew install ffmpeg

### For windows
Download from https://ffmpeg.org/download.html#build-windows
Then install ffpmeg and configure the path in the environment variables.

### For Linux
sudo apt install ffmpeg


