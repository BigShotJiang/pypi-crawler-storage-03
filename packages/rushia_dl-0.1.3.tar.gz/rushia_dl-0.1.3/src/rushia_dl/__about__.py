# __about__.py

# SPDX-FileCopyrightText: 2023-present User-Name <sample@example.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0"
