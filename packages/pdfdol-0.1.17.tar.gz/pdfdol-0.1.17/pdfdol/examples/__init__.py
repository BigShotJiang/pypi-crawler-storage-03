"""Examples using pdfdol"""
