"""mitol.common"""

default_app_config = "mitol.common.apps.CommonApp"

__version__ = "2025.8.19"
__distributionname__ = "mitol-django-common"
