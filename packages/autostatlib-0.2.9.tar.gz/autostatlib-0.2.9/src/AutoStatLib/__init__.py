from AutoStatLib.AutoStatLib import StatisticalAnalysis
from AutoStatLib.StatPlots import *
from AutoStatLib._version import __version__
