#
# datadb - A quick library of database data fetching.
#

from .datafetch import DataFetch
