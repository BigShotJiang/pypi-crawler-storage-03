def test(a: int) -> None:
    pass
