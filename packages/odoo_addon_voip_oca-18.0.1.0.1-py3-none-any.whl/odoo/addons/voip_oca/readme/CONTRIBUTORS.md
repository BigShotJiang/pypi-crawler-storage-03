
- [Dixmit](https://www.dixmit.com):
  - Enric Alomar
  - Luis Rodríguez
- [Tecnativa](https://www.tecnativa.com):
  - Carlos Roca
