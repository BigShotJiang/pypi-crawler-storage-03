The following options are interesting but are not implemented right now:

- Allow to enable or disable the VOIP as a user (Login / Logout)
- Create a call system where the calls are done automatically according to tasks

Not contempled behavior
-----------------------

We are not supporting setting two configuration for user.
Not even a different configuration for company in the user.
