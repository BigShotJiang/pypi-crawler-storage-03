from . import res_partner
from . import voip_call
from . import mail_activity
from . import mail_activity_mixin
from . import res_users
from . import voip_pbx
from . import ir_http
