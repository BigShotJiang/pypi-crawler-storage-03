from typing import Dict, Any


ToolInput = Dict[str, Any]
ToolOutput = Dict[str, Any]