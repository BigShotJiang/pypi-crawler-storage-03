"""
Chat with real-time message preview.
"""

from .cli import cli

__all__ = [cli]
