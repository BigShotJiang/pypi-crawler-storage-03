"""
WebSocket server handling Y CRDT synchronization.
"""

from .cli import cli

__all__ = [cli]
