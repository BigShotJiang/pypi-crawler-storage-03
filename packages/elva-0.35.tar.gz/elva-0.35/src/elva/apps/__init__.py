"""
Directory containing terminal applications as namespace packages.
"""
