# Changelog

## 3.0.0-alpha.29 (2025-08-27)

Full Changelog: [v3.0.0-alpha.28...v3.0.0-alpha.29](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.28...v3.0.0-alpha.29)

### Features

* **api:** api update ([5c48767](https://github.com/supermemoryai/python-sdk/commit/5c48767f77b0daf362be422e6d2d8843c15692b3))
* **api:** api update ([8eb53ac](https://github.com/supermemoryai/python-sdk/commit/8eb53ac4b04fae2f656d82c2c36c01e6583a08e0))
* **api:** api update ([9194990](https://github.com/supermemoryai/python-sdk/commit/9194990dfbe4e8b9a3fe145095ae65c1cab1b342))
* **api:** api update ([be04a5c](https://github.com/supermemoryai/python-sdk/commit/be04a5cf50c9af30b04e43128a860a93305f401a))


### Bug Fixes

* avoid newer type syntax ([cd791b9](https://github.com/supermemoryai/python-sdk/commit/cd791b97c02fe5728e54482097c846557ab0d555))


### Chores

* **internal:** change ci workflow machines ([002a748](https://github.com/supermemoryai/python-sdk/commit/002a748ddf690fcaeab905c622fe598ddc0f6629))
* **internal:** update pyright exclude list ([41a59ff](https://github.com/supermemoryai/python-sdk/commit/41a59ff7fb26bd419f747265c00a99ad750833d0))

## 3.0.0-alpha.28 (2025-08-24)

Full Changelog: [v3.0.0-alpha.27...v3.0.0-alpha.28](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.27...v3.0.0-alpha.28)

### Features

* **api:** api update ([0745263](https://github.com/supermemoryai/python-sdk/commit/074526384ea43d5323feeb2101054e0515002169))

## 3.0.0-alpha.27 (2025-08-24)

Full Changelog: [v3.0.0-alpha.26...v3.0.0-alpha.27](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.26...v3.0.0-alpha.27)

### Features

* **api:** api update ([27dcd49](https://github.com/supermemoryai/python-sdk/commit/27dcd49c6bbf1c4c1bc11acc02c852a8849f158a))
* **api:** api update ([cf6d58b](https://github.com/supermemoryai/python-sdk/commit/cf6d58befc0f976222f875eb74594b64a4e36803))


### Chores

* update github action ([65d9e06](https://github.com/supermemoryai/python-sdk/commit/65d9e06acc7a7cbabefb2625c4404848681c0e03))

## 3.0.0-alpha.26 (2025-08-15)

Full Changelog: [v3.0.0-alpha.25...v3.0.0-alpha.26](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.25...v3.0.0-alpha.26)

### Features

* **api:** manual updates ([c2623b2](https://github.com/supermemoryai/python-sdk/commit/c2623b2b645eefd7e2cbb5027eb5a46cee7b62eb))
* **api:** manual updates ([9e373ef](https://github.com/supermemoryai/python-sdk/commit/9e373ef0b585eb15cb04b95a1bab46c8c102970c))
* **api:** manual updates ([fa75aff](https://github.com/supermemoryai/python-sdk/commit/fa75affffb701259be14445da95c77a1cdde512b))

## 3.0.0-alpha.25 (2025-08-15)

Full Changelog: [v3.0.0-alpha.24...v3.0.0-alpha.25](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.24...v3.0.0-alpha.25)

### Features

* **api:** api update ([9bfc023](https://github.com/supermemoryai/python-sdk/commit/9bfc023373df244fa4d45c12ad31fe5ca2bddc8b))


### Chores

* **internal:** codegen related update ([8df15a7](https://github.com/supermemoryai/python-sdk/commit/8df15a767ca5007ee34b4b7b1bc39e1961203c80))

## 3.0.0-alpha.24 (2025-08-10)

Full Changelog: [v3.0.0-alpha.23...v3.0.0-alpha.24](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.23...v3.0.0-alpha.24)

### Features

* **api:** api update ([4aacfa8](https://github.com/supermemoryai/python-sdk/commit/4aacfa8f2e35f50ab9ac01c4ae9b5086b8dc2230))
* **api:** api update ([9fe90d9](https://github.com/supermemoryai/python-sdk/commit/9fe90d99035348910c215cb196a27390b7c595d3))
* **api:** api update ([f9c7013](https://github.com/supermemoryai/python-sdk/commit/f9c70137f404d7638d6e77dbf360a276877a55a5))
* **api:** api update ([125afc9](https://github.com/supermemoryai/python-sdk/commit/125afc957cab83c2a0c75ba003479b09e5e0f63c))
* **api:** api update ([04b249d](https://github.com/supermemoryai/python-sdk/commit/04b249d0a09d2fcbd8aecd08bcfc6ff89673fb75))
* **client:** support file upload requests ([b6c42b1](https://github.com/supermemoryai/python-sdk/commit/b6c42b10e8412ccc5dbbed23d86c36598319df00))


### Bug Fixes

* **parsing:** ignore empty metadata ([a58758c](https://github.com/supermemoryai/python-sdk/commit/a58758ce1f1ae0c87d0fa3bea43367bb2d198891))
* **parsing:** parse extra field types ([5253128](https://github.com/supermemoryai/python-sdk/commit/5253128de66dc303f8c9e4d295f133f24f770d95))


### Chores

* **internal:** fix ruff target version ([25adc14](https://github.com/supermemoryai/python-sdk/commit/25adc1412380631fa8ce53034b519e819b45dec3))
* **internal:** update comment in script ([8fc31e8](https://github.com/supermemoryai/python-sdk/commit/8fc31e8cb2058d8bb4da67c5aebbac421474c3b8))
* **project:** add settings file for vscode ([2327687](https://github.com/supermemoryai/python-sdk/commit/232768766d49d14af45667f08ad66b890cc6a230))
* update @stainless-api/prism-cli to v5.15.0 ([7f4ff8b](https://github.com/supermemoryai/python-sdk/commit/7f4ff8b2712055be8a6100a2c132b514cf7e2e6d))

## 3.0.0-alpha.23 (2025-07-15)

Full Changelog: [v3.0.0-alpha.22...v3.0.0-alpha.23](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.22...v3.0.0-alpha.23)

### Features

* **api:** api update ([3f71f60](https://github.com/supermemoryai/python-sdk/commit/3f71f60954dedc0a91e1859df48c5c3ca0a47c88))
* **api:** api update ([b614732](https://github.com/supermemoryai/python-sdk/commit/b61473253183d434613b0aeb631376262d22cb0c))
* clean up environment call outs ([4aaccf1](https://github.com/supermemoryai/python-sdk/commit/4aaccf17ae31c04f3097fe04a6a081171fc725d1))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([80480dd](https://github.com/supermemoryai/python-sdk/commit/80480dd46271dc5136f39c5ff1315555b8d51e31))
* **parsing:** correctly handle nested discriminated unions ([812e982](https://github.com/supermemoryai/python-sdk/commit/812e982cbba93e197d4cd3cf8bdfa710e7830a78))


### Chores

* **internal:** bump pinned h11 dep ([9e822a1](https://github.com/supermemoryai/python-sdk/commit/9e822a16ce8cf30791abf6384e2e3205233eeaba))
* **package:** mark python 3.13 as supported ([2dc73dd](https://github.com/supermemoryai/python-sdk/commit/2dc73dd51ac30fa4d6b2d370b7411857518c1ddd))
* **readme:** fix version rendering on pypi ([a6d7d7a](https://github.com/supermemoryai/python-sdk/commit/a6d7d7a100680cfaa03138542f60b7b7407ad347))

## 3.0.0-alpha.22 (2025-07-03)

Full Changelog: [v3.0.0-alpha.21...v3.0.0-alpha.22](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.21...v3.0.0-alpha.22)

### Features

* **api:** manual updates ([2a863a1](https://github.com/supermemoryai/python-sdk/commit/2a863a166b5c39208ef910d84530a27898ed0c71))

## 3.0.0-alpha.21 (2025-07-03)

Full Changelog: [v3.0.0-alpha.20...v3.0.0-alpha.21](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.20...v3.0.0-alpha.21)

### Features

* **api:** api update ([8b94b9e](https://github.com/supermemoryai/python-sdk/commit/8b94b9e043564f8daf605289683270dba97ca323))
* **api:** api update ([7b7eda7](https://github.com/supermemoryai/python-sdk/commit/7b7eda703a9d3dcf9b235a5045829c69147240c6))
* **api:** manual updates ([e7bfa6e](https://github.com/supermemoryai/python-sdk/commit/e7bfa6ef5804b758d3da98206ee643f9ae44ce0a))


### Bug Fixes

* **ci:** correct conditional ([0b20719](https://github.com/supermemoryai/python-sdk/commit/0b20719ce022a872dd7334587317235b7a5562c3))


### Chores

* **ci:** change upload type ([38f5701](https://github.com/supermemoryai/python-sdk/commit/38f5701dff0cc09b4a42d1c86e6250ed4695783d))
* **ci:** only run for pushes and fork pull requests ([901a43c](https://github.com/supermemoryai/python-sdk/commit/901a43c0c06fb8ed2ee2cfc3c56d44002b108a06))
* **internal:** codegen related update ([9c82bc7](https://github.com/supermemoryai/python-sdk/commit/9c82bc7c2fff3e85ec8a8d3278b04741bedaf7d3))

## 3.0.0-alpha.20 (2025-06-27)

Full Changelog: [v3.0.0-alpha.19...v3.0.0-alpha.20](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.19...v3.0.0-alpha.20)

### Features

* **api:** api update ([3c35763](https://github.com/supermemoryai/python-sdk/commit/3c357637aab2e68e3a80e33b9f721c3a8182483a))
* **api:** api update ([08ffef9](https://github.com/supermemoryai/python-sdk/commit/08ffef95b8f7be8ce8a57ba2fe2761653cd42e5d))


### Bug Fixes

* **ci:** release-doctor — report correct token name ([dadfa9f](https://github.com/supermemoryai/python-sdk/commit/dadfa9f74851fc81e5af92e47c41115bee87aad7))


### Chores

* sync repo ([380252a](https://github.com/supermemoryai/python-sdk/commit/380252a9cb2d9c723b5c6b36a33573c462e48049))
* update SDK settings ([8c6f297](https://github.com/supermemoryai/python-sdk/commit/8c6f297fc2b8f7a6b600205a5c313767a99612cb))
