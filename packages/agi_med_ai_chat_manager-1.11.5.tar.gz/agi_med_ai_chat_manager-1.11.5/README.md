# agi-med-ai-chat-manager

Реализация подключения к разным ai чатам, таким как разным llm сервисам

## Ответственный разработчик

@shaposhnikov

## Общая информация

- Yandex_GPT
- Gigachat
- OpenRouter
- AiriServer

## Тесты

- `sudo docker compose up --build`
