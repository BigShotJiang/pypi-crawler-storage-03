## Cuvette

<div align="center">
  <img src="https://ecuvettes.com/wp-content/uploads/2021/04/1.jpg" alt="Cuvette" style="max-width: 200px;">
</div>

### setup

```sh
pip install cuvette
```
