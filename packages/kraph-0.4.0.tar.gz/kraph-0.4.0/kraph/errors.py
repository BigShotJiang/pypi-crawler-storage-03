class NoKraphFound(Exception):
    pass
