from .core import InitPyGame

__all__ = ["InitPyGame"]
