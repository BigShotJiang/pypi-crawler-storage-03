#!/usr/bin/env python3
# -*- coding: utf-8, vim: expandtab:ts=4 -*-

__version__ = '1.4.2'
