from __future__ import annotations

from ._internal import LazyString as LazyString
from ._internal import init_logs as init_logs
