# Changelog

We are currently working on porting this changelog to the specifications in
[Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Version 2.4.1] - Released 202x-xx-xx

### Fixed
* Seed random numbers in tests

## [Version 2.4.0] - Released 2024-04-18

### Added
* Python 3.12 support.

### Fixed:
* Removed codecov from test req


## [Version 2.3.0] - Released 2023-01-28

### Changed
* Added Python 3.11 support

## [Version 0.0.1] -

### Added
* Initial version
