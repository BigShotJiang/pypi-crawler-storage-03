def test_import():
    import pyflann_ibeis