#!/usr/bin/env bash
xdoctest pyflann_ibeis --style=google all "$@"