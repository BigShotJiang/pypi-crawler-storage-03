Planned backends
================
In addition to the currently existing backends, the following
additional backends may be supported in upcoming versions:

  - Redland librdf
  - Apache Jena Fuseki
  - Allegrograph
  - Wikidata
