# sparqlwrapper

::: tripper.backends.sparqlwrapper
