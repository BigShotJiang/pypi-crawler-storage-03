# triplestore_extend

::: tripper.triplestore_extend
