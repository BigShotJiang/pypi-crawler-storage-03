#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# standard python imports


class LicenseException(Exception):
    """Exception raised when trying an action on an unlicensed RegScale instance."""
