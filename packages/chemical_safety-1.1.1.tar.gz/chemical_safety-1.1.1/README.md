# chemical_safety
This package retrieves and displays SDS, GHS, and regulatory information for chemicals in an academic setting.

`pip install chemical-safety`


## dashboard
recommended for users who only want to view information

enter command prompt: `chemical-dashboard`

then access in your browser at http://localhost:5000

## chemical class
chemical_safety.chemical stores all GHS info

recommended for custom applications and development

