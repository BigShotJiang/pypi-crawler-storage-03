from setuptools import find_packages, setup

setup(
    name="pybase_library",
    version="0.1.6",    
    packages=find_packages(),
    install_requires=[],
    author="thinhnt3",
    description="Python based library",
    python_requires=">=3.11",
)
