//! Basic arithmetic pipelines

pub (crate) mod average;
pub (crate) mod sqrt;
pub (crate) mod real;