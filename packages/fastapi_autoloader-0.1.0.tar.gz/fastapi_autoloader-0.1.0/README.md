# fastapi-dynamic-router

A Python package for dynamic routing in FastAPI.
