"""FastAPI Dynamic Router modular autoload for faster development."""

from .dynamic_router import DynamicRouter  # noqa: F401
