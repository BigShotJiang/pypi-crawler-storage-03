"""
API Routes Module
"""

__all__ = ["documents", "search", "jobs", "health", "database"]