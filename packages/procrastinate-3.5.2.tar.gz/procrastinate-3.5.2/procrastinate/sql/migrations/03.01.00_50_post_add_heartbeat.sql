DROP FUNCTION IF EXISTS procrastinate_fetch_job_v1(character varying[]);
