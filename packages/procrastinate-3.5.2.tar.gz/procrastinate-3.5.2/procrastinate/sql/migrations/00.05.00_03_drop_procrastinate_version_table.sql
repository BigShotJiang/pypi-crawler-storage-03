-- drop the procrastinate_version table
DROP TABLE IF EXISTS procrastinate_version;
