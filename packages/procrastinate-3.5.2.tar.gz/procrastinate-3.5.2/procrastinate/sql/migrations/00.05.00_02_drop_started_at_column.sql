-- remove the started_at column from the procrastinate_jobs table
ALTER TABLE procrastinate_jobs DROP COLUMN started_at;
