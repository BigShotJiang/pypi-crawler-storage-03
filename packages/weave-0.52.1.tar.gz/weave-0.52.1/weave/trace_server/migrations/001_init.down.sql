DROP TABLE call_parts;
DROP TABLE calls_merged;
DROP VIEW calls_merged_view;

DROP TABLE object_versions;
DROP VIEW object_versions_deduped;

DROP TABLE tables;
DROP VIEW tables_deduped;

DROP TABLE table_rows;
DROP VIEW table_rows_deduped;

DROP TABLE files;
DROP VIEW files_deduped;
