# Expose script modules as importable utilities
# Each script keeps its own `main()` for CLI flows but can be imported as functions.