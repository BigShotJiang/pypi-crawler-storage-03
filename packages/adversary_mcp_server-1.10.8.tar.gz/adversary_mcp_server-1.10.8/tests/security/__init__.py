"""Security tests for Adversary MCP server."""
