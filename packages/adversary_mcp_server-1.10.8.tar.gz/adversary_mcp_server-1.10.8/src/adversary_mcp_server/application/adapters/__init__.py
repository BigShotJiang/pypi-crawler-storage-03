"""Application adapters for integrating domain interfaces with existing infrastructure."""
