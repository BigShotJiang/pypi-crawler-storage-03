"""Domain repository interfaces package.

Repository interfaces define the contracts for data persistence without
coupling the domain to specific storage implementations.
"""
