"""Domain entities package.

Entities are objects with identity that encapsulate business logic and behavior.
They represent core business concepts with rich behavior and domain rules.
"""
