# CoraLearn
A Simple AI library created from scratch using only numpy
