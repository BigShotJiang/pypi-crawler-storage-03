---
name: Empty Issue
about: A minimal template for ordinary issues or sub-tasks
---
