# ArrowRow

::: datachain.lib.file.ArrowRow
