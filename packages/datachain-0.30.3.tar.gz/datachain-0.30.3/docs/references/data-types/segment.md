# Segment

::: datachain.model.segment.Segment
