# Random Functions

Functions for generating random values and sampling.

::: datachain.func.random
