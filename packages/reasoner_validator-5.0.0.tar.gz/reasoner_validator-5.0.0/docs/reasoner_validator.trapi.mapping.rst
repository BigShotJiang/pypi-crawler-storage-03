TRAPI Result Mapping
====================

.. automodule:: reasoner_validator.trapi.mapping
   :members:
   :undoc-members:
   :show-inheritance:
