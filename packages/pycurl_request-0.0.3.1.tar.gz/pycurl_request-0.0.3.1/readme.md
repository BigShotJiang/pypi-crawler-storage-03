# pycurl request extension.

## Installation

You can install via [pypi](https://pypi.org/project/pycurl_request/)

```console
pip install -U pycurl_request
```

## Usage

```python
from pycurl_request import request
```
