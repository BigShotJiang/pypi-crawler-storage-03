# Quickstart

```{toctree}
:maxdepth: 1
quickstart/deployment.md
quickstart/bandpass.md
quickstart/sky_model.md
quickstart/selfcal.md
quickstart/polarisation.md
quickstart/spectral_line.md
```
