from __future__ import annotations

from ._version import version as __version__
from ._version import version_tuple as __version_tuple__

__all__ = [
    "__version__",
    "__version_tuple__",
]
