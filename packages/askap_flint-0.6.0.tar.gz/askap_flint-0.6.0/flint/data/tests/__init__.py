"""This folder is intended to hold data related to unit tests
that will run. It is not meant to otherwise hold datasets that
would be used in regular processing.
"""
