"""MCP Tools for generating role-based focus documents."""

import json
import asyncio
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from fastmcp import FastMCP

from .mcp_utils import (
    get_memory_bank_path,
    get_working_directory,
    paginate_content,
    format_error_response,
    load_template
)
from .increment_utils import (
    ensure_component_state,
    get_increment_details,
    get_full_increment_name
)


# Create MCP server instance for focus tools
mcp = FastMCP("Memory-Bank Focus")


@mcp.tool(name="get-pm-focus")
def get_pm_focus(release: str, component: str, page: int = 1) -> str:
    """Get PM focus for component level.
    
    Args:
        release: Release name
        component: Component name
        page: Page number for pagination
        
    Returns:
        JSON with PM focus content and pagination info
    """
    memory_bank_path = get_memory_bank_path()
    if not memory_bank_path:
        return format_error_response("Memory-Bank not bound to current project")
    
    try:
        # Ensure component state exists
        state_data = ensure_component_state(memory_bank_path, release, component)
        current_increment = state_data.get("current_increment", "01")
        
        # Get full increment name for path
        increment_name = get_full_increment_name(memory_bank_path, release, component, current_increment)
        
        # Check if focus file exists
        # PM focus is in increment folder alongside journal
        focus_file = memory_bank_path / "progress" / "releases" / release / "components" / component / "increments" / increment_name / "pm-focus.md"
        
        if focus_file.exists():
            # Return existing focus with pagination
            content = focus_file.read_text()
            result = paginate_content(content, page)
            result["role"] = "pm"
            result["component"] = component
            result["increment"] = current_increment
            return json.dumps(result)
        
        # Generate new focus
        focus_content = _generate_pm_focus(memory_bank_path, release, component, current_increment)
        
        if focus_content:
            # Save generated focus
            focus_file.parent.mkdir(parents=True, exist_ok=True)
            focus_file.write_text(focus_content)
            
            # Return with pagination
            result = paginate_content(focus_content, page)
            result["role"] = "pm"
            result["component"] = component
            result["increment"] = current_increment
            result["generated"] = True
            return json.dumps(result)
        
        return format_error_response("Failed to generate PM focus")
        
    except Exception as e:
        return format_error_response(f"Error getting PM focus: {e}")


@mcp.tool(name="get-dev-focus")
def get_dev_focus(release: str, component: str, page: int = 1) -> str:
    """Get dev focus for current increment.
    
    Args:
        release: Release name
        component: Component name
        page: Page number for pagination
        
    Returns:
        JSON with dev focus content and pagination info
    """
    memory_bank_path = get_memory_bank_path()
    if not memory_bank_path:
        return format_error_response("Memory-Bank not bound to current project")
    
    try:
        # Ensure component state exists
        state_data = ensure_component_state(memory_bank_path, release, component)
        current_increment = state_data.get("current_increment", "01")
        
        # Get full increment name for path
        increment_name = get_full_increment_name(memory_bank_path, release, component, current_increment)
        
        # Check if focus file exists
        # Dev focus is in increment folder alongside journal
        focus_file = memory_bank_path / "progress" / "releases" / release / "components" / component / "increments" / increment_name / "dev-focus.md"
        
        if focus_file.exists():
            # Return existing focus with pagination
            content = focus_file.read_text()
            result = paginate_content(content, page)
            result["role"] = "dev"
            result["component"] = component
            result["increment"] = current_increment
            return json.dumps(result)
        
        # Generate new focus
        focus_content = _generate_dev_focus(memory_bank_path, release, component, current_increment)
        
        if focus_content:
            # Save generated focus
            focus_file.parent.mkdir(parents=True, exist_ok=True)
            focus_file.write_text(focus_content)
            
            # Return with pagination
            result = paginate_content(focus_content, page)
            result["role"] = "dev"
            result["component"] = component
            result["increment"] = current_increment
            result["generated"] = True
            return json.dumps(result)
        
        return format_error_response("Failed to generate dev focus")
        
    except Exception as e:
        return format_error_response(f"Error getting dev focus: {e}")


@mcp.tool(name="get-tech-lead-focus")
def get_tech_lead_focus(release: str, component: str, page: int = 1) -> str:
    """Get tech-lead focus for current increment.
    
    Args:
        release: Release name
        component: Component name
        page: Page number for pagination
        
    Returns:
        JSON with tech-lead focus content and pagination info
    """
    memory_bank_path = get_memory_bank_path()
    if not memory_bank_path:
        return format_error_response("Memory-Bank not bound to current project")
    
    try:
        # Ensure component state exists
        state_data = ensure_component_state(memory_bank_path, release, component)
        current_increment = state_data.get("current_increment", "01")
        
        # Get full increment name for path
        increment_name = get_full_increment_name(memory_bank_path, release, component, current_increment)
        
        # Check if focus file exists
        # Tech-lead focus is in increment folder alongside journal
        focus_file = memory_bank_path / "progress" / "releases" / release / "components" / component / "increments" / increment_name / "tech-lead-focus.md"
        
        if focus_file.exists():
            # Return existing focus with pagination
            content = focus_file.read_text()
            result = paginate_content(content, page)
            result["role"] = "tech-lead"
            result["component"] = component
            result["increment"] = current_increment
            return json.dumps(result)
        
        # Generate new focus
        focus_content = _generate_tech_lead_focus(memory_bank_path, release, component, current_increment)
        
        if focus_content:
            # Save generated focus
            focus_file.parent.mkdir(parents=True, exist_ok=True)
            focus_file.write_text(focus_content)
            
            # Return with pagination
            result = paginate_content(focus_content, page)
            result["role"] = "tech-lead"
            result["component"] = component
            result["increment"] = current_increment
            result["generated"] = True
            return json.dumps(result)
        
        return format_error_response("Failed to generate tech-lead focus")
        
    except Exception as e:
        return format_error_response(f"Error getting tech-lead focus: {e}")


def _generate_pm_focus(memory_bank_path: Path, release: str, component: str, increment: str) -> Optional[str]:
    """Generate PM focus using formula and template.
    
    Formula: distilled_product + component + decomposition + state
    """
    try:
        # Get product context (vision + release)
        product_context = _get_product_context(memory_bank_path, release)
        
        # Load component content
        component_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "component.md"
        component_content = component_file.read_text() if component_file.exists() else "Component specification not found"
        
        # Load decomposition
        decomposition_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "decomposition.md"
        decomposition_content = decomposition_file.read_text() if decomposition_file.exists() else "Decomposition not found"
        
        # Load combined state
        state_content = _get_combined_state(memory_bank_path, release, component)
        
        # Load PM focus template
        template = load_template("progress/pm-focus.md", memory_bank_path)
        if not template:
            # Fallback template
            template = """---
datetime: "{datetime}"
increment: "{increment}"
component: "{component}"
release: "{release}"
---

## Product/Release Context

{product_context}

---

## Current Component

```md
{current_component_content}
```

## Decomposition

```md
{decomposition_content}
```

## State

```md
{current_component_state_content}
```

## Your Role

You are the Product Manager (PM) orchestrating the implementation of this component.
Your responsibilities:
- Coordinate between owner and development team
- Ensure increment objectives are met
- Manage workflow transitions between roles
- Track progress and report to owner
"""
        
        # Format template
        datetime_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        focus_content = template.format(
            datetime=datetime_str,
            increment=increment,
            component=component,
            release=release,
            destill_overview_of_product_and_current_release=product_context,  # Keep old name for compatibility
            current_component_content=component_content,
            decomposition_content=decomposition_content,
            current_component_state_content=state_content
        )
        
        return focus_content
        
    except Exception as e:
        print(f"Error generating PM focus: {e}")
        return None


def _generate_dev_focus(memory_bank_path: Path, release: str, component: str, increment: str) -> Optional[str]:
    """Generate dev focus using formula and template.
    
    Formula: distilled_product + component + increment + state
    """
    try:
        # Get product context (vision + release)
        product_context = _get_product_context(memory_bank_path, release)
        
        # Load component content
        component_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "component.md"
        component_content = component_file.read_text() if component_file.exists() else "Component specification not found"
        
        # Load current increment content
        increment_details = get_increment_details(memory_bank_path, release, component, increment)
        if increment_details and "filename" in increment_details:
            # Load actual increment file content
            increment_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "increments" / increment_details["filename"]
            try:
                increment_content = increment_file.read_text()
            except Exception:
                increment_content = "Increment file not found"
        else:
            increment_content = "Increment not found"
        
        # Load combined state
        state_content = _get_combined_state(memory_bank_path, release, component)
        
        # Load dev focus template
        template = load_template("progress/dev-focus.md", memory_bank_path)
        if not template:
            # Fallback template
            template = """---
datetime: "{datetime}"
increment: "{increment}"
component: "{component}"
release: "{release}"
---

## Your Role

You are the Developer implementing this increment.
Your responsibilities:
- Implement the increment requirements
- Write clean, maintainable code
- Follow project standards and conventions
- Document your implementation decisions in journal

## Product/Release Context

{destill_overview_of_product_and_release_by_increment_context}

---

## Component

```md
{component_content}
```

## Increment (Your current task)

```md
{increment_content}
```

## State

```md
{combined_initial_state_plus_progress_state}
```
"""
        
        # Format template
        datetime_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        focus_content = template.format(
            datetime=datetime_str,
            increment=increment,
            component=component,
            release=release,
            destill_overview_of_product_and_release_by_increment_context=product_context,  # Keep old name for compatibility
            component_content=component_content,
            increment_content=increment_content,
            combined_initial_state_plus_progress_state=state_content
        )
        
        return focus_content
        
    except Exception as e:
        print(f"Error generating dev focus: {e}")
        return None


def _generate_tech_lead_focus(memory_bank_path: Path, release: str, component: str, increment: str) -> Optional[str]:
    """Generate tech-lead focus using formula and template.
    
    Formula: distilled_product + component + increment + state
    """
    try:
        # Get product context (vision + release)
        product_context = _get_product_context(memory_bank_path, release)
        
        # Load component content
        component_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "component.md"
        component_content = component_file.read_text() if component_file.exists() else "Component specification not found"
        
        # Load current increment content
        increment_details = get_increment_details(memory_bank_path, release, component, increment)
        if increment_details and "filename" in increment_details:
            # Load actual increment file content
            increment_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "increments" / increment_details["filename"]
            try:
                increment_content = increment_file.read_text()
            except Exception:
                increment_content = "Increment file not found"
        else:
            increment_content = "Increment not found"
        
        # Load combined state
        state_content = _get_combined_state(memory_bank_path, release, component)
        
        # Load tech-lead focus template
        template = load_template("progress/tech-lead-focus.md", memory_bank_path)
        if not template:
            # Fallback template
            template = """---
datetime: "{datetime}"
increment: "{increment}"
component: "{component}"
release: "{release}"
---

## Your Role

You are the Tech Lead reviewing this increment implementation.
Your responsibilities:
- Validate implementation against requirements
- Ensure code quality and standards compliance
- Check for potential issues and edge cases
- Provide constructive feedback

## Product/Release Context

{product_context}

---

## Component

```md
{component_content}
```

## Increment (Implementation to review)

```md
{increment_content}
```

## State

```md
{combined_initial_state_plus_progress_state}
```
"""
        
        # Format template
        datetime_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        focus_content = template.format(
            datetime=datetime_str,
            increment=increment,
            component=component,
            release=release,
            destill_overview_of_product_and_release_by_increment_context=product_context,  # Keep old name for compatibility
            component_content=component_content,
            increment_content=increment_content,
            combined_initial_state_plus_progress_state=state_content
        )
        
        return focus_content
        
    except Exception as e:
        print(f"Error generating tech-lead focus: {e}")
        return None


def _get_combined_state(memory_bank_path: Path, release: str, component: str) -> str:
    """Get combined initial + progress state."""
    combined = ""
    
    # Load initial state
    initial_state_file = memory_bank_path / "implementation" / "releases" / release / "components" / component / "initial-state.md"
    if initial_state_file.exists():
        try:
            content = initial_state_file.read_text()
            # Remove YAML header if present
            if content.startswith('---\n'):
                yaml_end = content.find('\n---\n', 4)
                if yaml_end != -1:
                    content = content[yaml_end + 5:]
            combined += "### Initial State\n\n" + content + "\n\n"
        except Exception:
            combined += "### Initial State\n\n*Unable to load initial state*\n\n"
    
    # Load progress state
    progress_state_file = memory_bank_path / "progress" / "releases" / release / "components" / component / "progress-state.md"
    if progress_state_file.exists():
        try:
            content = progress_state_file.read_text()
            # Remove YAML header if present
            if content.startswith('---\n'):
                yaml_end = content.find('\n---\n', 4)
                if yaml_end != -1:
                    content = content[yaml_end + 5:]
            combined += "### Progress State\n\n" + content
        except Exception:
            combined += "### Progress State\n\n*Unable to load progress state*"
    else:
        combined += "### Progress State\n\n*No progress recorded yet*"
    
    return combined


def _get_product_context(memory_bank_path: Path, release: str) -> str:
    """Get product context by including vision and release files directly.
    
    No distillation - just direct file content insertion.
    """
    context_parts = []
    
    # 1. Product Vision (if exists)
    vision_file = memory_bank_path / "product" / "vision.md"
    if vision_file.exists():
        try:
            content = vision_file.read_text()
            # Remove YAML header if present
            if content.startswith('---\n'):
                yaml_end = content.find('\n---\n', 4)
                if yaml_end != -1:
                    content = content[yaml_end + 5:]
            context_parts.append("## Product Vision\n")
            context_parts.append(content.strip())
            context_parts.append("\n---\n")
        except Exception:
            pass
    
    # 2. Current Release (if exists)
    release_file = memory_bank_path / "product" / "releases" / f"{release}.md"
    if release_file.exists():
        try:
            content = release_file.read_text()
            # Remove YAML header if present
            if content.startswith('---\n'):
                yaml_end = content.find('\n---\n', 4)
                if yaml_end != -1:
                    content = content[yaml_end + 5:]
            context_parts.append(f"## Release: {release}\n")
            context_parts.append(content.strip())
            context_parts.append("\n---\n")
        except Exception:
            pass
    
    if not context_parts:
        return "## Product/Release Context\n\nNo product vision or release documentation found.\n"
    
    return "\n".join(context_parts)

