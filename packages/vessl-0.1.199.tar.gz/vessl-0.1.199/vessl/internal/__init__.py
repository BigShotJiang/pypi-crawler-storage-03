from vessl.internal.vessl_run import VesslRun

_run = VesslRun()

init = _run.init
api = _run.api
log = _run.log
progress = _run.progress
hyperparameters = _run.hyperparameters
finish = _run.finish
