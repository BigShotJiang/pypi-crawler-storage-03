from ..types import Theme

Unicode = Theme(
    vertical='│   ',
    branch='├── ',
    corner='└── ',
    tab='    '
)
