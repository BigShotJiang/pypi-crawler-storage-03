"""
Kapso SDK serialization module.
"""
