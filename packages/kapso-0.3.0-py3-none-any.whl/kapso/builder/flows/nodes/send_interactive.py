"""
SendInteractiveNode for sending interactive WhatsApp messages in flows.
"""

from typing import Union, Optional, Dict, Any, List
from dataclasses import dataclass, field

from .base import Node
from kapso.builder.ai.field import AIField


@dataclass
class InteractiveButton:
    """Button configuration for interactive messages."""
    id: str
    title: str


@dataclass  
class ListRow:
    """Row configuration for list messages."""
    id: str
    title: str
    description: Optional[str] = None


@dataclass
class ListSection:
    """Section configuration for list messages."""
    title: Optional[str] = None
    rows: List[ListRow] = field(default_factory=list)


class SendInteractiveNode(Node):
    """Node for sending interactive WhatsApp messages (buttons, lists, etc)."""
    
    def __init__(
        self,
        id: str,
        whatsapp_config_id: str,
        interactive_type: str,  # button, list, cta_url, flow, product, product_list, catalog_message
        body_text: Union[str, AIField],
        
        # Optional header configuration
        header_type: Optional[str] = None,  # none, text, image, video, document
        header_text: Optional[Union[str, AIField]] = None,  # For text headers
        header_media_url: Optional[str] = None,  # For media headers
        
        # Optional footer
        footer_text: Optional[Union[str, AIField]] = None,
        
        # Type-specific configurations
        buttons: Optional[List[Union[InteractiveButton, Dict[str, str]]]] = None,  # For button type
        list_button_text: Optional[str] = None,  # For list type
        list_sections: Optional[List[Union[ListSection, Dict]]] = None,  # For list type
        cta_display_text: Optional[str] = None,  # For cta_url type
        cta_url: Optional[str] = None,  # For cta_url type
        flow_id: Optional[str] = None,  # For flow type
        flow_cta: Optional[str] = None,  # For flow type
        
        provider_model_name: Optional[str] = None
    ):
        # Build main config with flattened structure (Rails expects fields at root level)
        config = {
            "whatsapp_config_id": whatsapp_config_id,
            "interactive_type": interactive_type,
            "body_text": body_text.to_dict() if isinstance(body_text, AIField) else body_text,
        }
        
        # Add header fields at root level
        if header_type and header_type != 'none':
            config["header_type"] = header_type
            if header_type == 'text' and header_text is not None:
                config["header_text"] = header_text.to_dict() if isinstance(header_text, AIField) else header_text
            elif header_type in ['image', 'video', 'document'] and header_media_url:
                config["header_media_url"] = header_media_url

        # Add footer text at root level  
        if footer_text is not None:
            config["footer_text"] = footer_text.to_dict() if isinstance(footer_text, AIField) else footer_text
        
        # Add action fields at root level based on interactive_type
        if interactive_type == 'button' and buttons:
            config['buttons'] = [
                {'id': button.id, 'title': button.title} if hasattr(button, 'id') else button
                for button in buttons
            ]
        elif interactive_type == 'list':
            config['list_button_text'] = list_button_text or 'View Options'
            if list_sections:
                config['list_sections'] = [
                    {
                        'title': section.title if hasattr(section, 'title') else section.get('title'),
                        'rows': [
                            {
                                'id': row.id if hasattr(row, 'id') else row['id'],
                                'title': row.title if hasattr(row, 'title') else row['title'],
                                'description': row.description if hasattr(row, 'description') else row.get('description')
                            } for row in (section.rows if hasattr(section, 'rows') else section.get('rows', []))
                        ]
                    }
                    for section in list_sections
                ]
            else:
                config['list_sections'] = []
        elif interactive_type == 'cta_url':
            if cta_display_text:
                config['cta_display_text'] = cta_display_text
            if cta_url:
                config['cta_url'] = cta_url
        elif interactive_type == 'flow':
            if flow_id:
                config['flow_id'] = flow_id
            if flow_cta:
                config['flow_cta'] = flow_cta
        
        # Build ai_field_config for all AI fields (following SendTextNode pattern)
        ai_config = {}
        has_ai_fields = False
        
        # Handle body_text AI field
        if isinstance(body_text, AIField):
            ai_config["body_text"] = body_text.to_config()
            has_ai_fields = True
        
        # Handle header_text AI field
        if isinstance(header_text, AIField):
            ai_config["header_text"] = header_text.to_config()
            has_ai_fields = True
            
        # Handle footer_text AI field
        if isinstance(footer_text, AIField):
            ai_config["footer_text"] = footer_text.to_config()
            has_ai_fields = True
        
        # Auto-generate ai_field_config if any AI fields are used
        if has_ai_fields:
            config["ai_field_config"] = ai_config
            if not provider_model_name:
                raise ValueError("provider_model_name required when using AIField")
            
        if provider_model_name:
            config["provider_model_name"] = provider_model_name
        
        # Store original values for property access
        self._body_text = body_text
        self._header_type = header_type
        self._header_text = header_text
        self._header_media_url = header_media_url
        self._footer_text = footer_text
        self._buttons = buttons
        self._list_button_text = list_button_text
        self._list_sections = list_sections
        self._cta_display_text = cta_display_text
        self._cta_url = cta_url
        self._flow_id = flow_id
        self._flow_cta = flow_cta
            
        super().__init__(
            id=id,
            node_type="send_interactive",
            config=config
        )
    
    @property
    def whatsapp_config_id(self) -> str:
        """Get the WhatsApp config ID."""
        return self.config["whatsapp_config_id"]
    
    @property
    def interactive_type(self) -> str:
        """Get the interactive type."""
        return self.config["interactive_type"]
    
    @property
    def body_text(self) -> Union[str, AIField]:
        """Get the body text."""
        return self._body_text
    
    @property
    def header_type(self) -> Optional[str]:
        """Get the header type."""
        return self._header_type
    
    @property
    def header_text(self) -> Optional[Union[str, AIField]]:
        """Get the header text."""
        return self._header_text
    
    @property
    def header_media_url(self) -> Optional[str]:
        """Get the header media URL."""
        return self._header_media_url
    
    @property
    def footer_text(self) -> Optional[Union[str, AIField]]:
        """Get the footer text."""
        return self._footer_text
    
    @property
    def provider_model_name(self) -> Optional[str]:
        """Get the provider model name."""
        return self.config.get("provider_model_name")
    
    @property
    def ai_field_config(self) -> Optional[Dict[str, Any]]:
        """Get the AI field configuration."""
        return self.config.get("ai_field_config")
    
    @property
    def buttons(self) -> Optional[List[Union[InteractiveButton, Dict[str, str]]]]:
        """Get the buttons configuration."""
        return self._buttons
    
    @property
    def list_button_text(self) -> Optional[str]:
        """Get the list button text."""
        return self._list_button_text
    
    @property
    def list_sections(self) -> Optional[List[Union[ListSection, Dict]]]:
        """Get the list sections configuration."""
        return self._list_sections
    
    @property
    def cta_display_text(self) -> Optional[str]:
        """Get the CTA display text."""
        return self._cta_display_text
    
    @property
    def cta_url(self) -> Optional[str]:
        """Get the CTA URL."""
        return self._cta_url
    
    @property
    def flow_id(self) -> Optional[str]:
        """Get the flow ID."""
        return self._flow_id
    
    @property
    def flow_cta(self) -> Optional[str]:
        """Get the flow CTA text."""
        return self._flow_cta