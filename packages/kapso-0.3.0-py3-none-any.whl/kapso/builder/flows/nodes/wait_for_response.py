"""
WaitForResponseNode for waiting for user responses in flows.
"""


from .base import Node


class WaitForResponseNode(Node):
    """Node for waiting for user responses."""
    
    def __init__(self, id: str):
        super().__init__(
            id=id,
            node_type="wait_for_response",
            config={}
        )