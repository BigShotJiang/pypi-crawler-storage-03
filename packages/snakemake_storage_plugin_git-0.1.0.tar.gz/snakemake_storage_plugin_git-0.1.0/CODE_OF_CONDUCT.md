# Code of Conduct

This project has adopted the [Snakemake Code of Conduct](https://github.com/snakemake/snakemake/blob/main/CODE_OF_CONDUCT.md)
