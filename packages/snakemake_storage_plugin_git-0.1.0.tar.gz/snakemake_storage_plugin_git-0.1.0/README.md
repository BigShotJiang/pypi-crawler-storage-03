# snakemake-storage-plugin-git

Snakemake storage plugin for downloading remote git repositories as input files.
