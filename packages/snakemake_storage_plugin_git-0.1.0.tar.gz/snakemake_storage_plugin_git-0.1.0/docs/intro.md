# Snakemake storage plugin: git

This plugin allows you to clone remote Git repositories via SSH and HTTPS.
