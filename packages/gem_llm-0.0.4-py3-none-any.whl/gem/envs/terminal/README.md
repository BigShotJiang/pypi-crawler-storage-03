References:
- [Terminal-Bench](https://github.com/laude-institute/terminal-bench)
- [Terminal-Bench-RL](https://github.com/Danau5tin/terminal-bench-rl)
