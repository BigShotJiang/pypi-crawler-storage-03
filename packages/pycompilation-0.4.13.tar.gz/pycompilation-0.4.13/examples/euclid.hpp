#ifndef _EUCLID_HPP_
#define _EUCLID_HPP_

#include <vector>

using std::vector;

vector<double> euclidean_norm(vector<vector<int> >);

#endif
