# ltrans: Jupyter Notebook AI Translator CLI

`ltrans` is a powerful command-line interface (CLI) tool designed to translate Jupyter Notebook (`.ipynb`) files from English to Chinese. It leverages advanced AI models (like Google Gemini) to provide accurate translations while preserving the original notebook structure, code, and only translating comments within code blocks.

## ✨ Features

*   **Intelligent Translation**: Translates Markdown cells and comments within code cells, leaving the code itself untouched.
*   **AI-Powered**: Utilizes leading AI models (e.g., Google Gemini, Qwen) for high-quality translation.
*   **CLI Interface**: Easy-to-use command-line tool for seamless integration into your workflow.
*   **Configurable**: Manage API keys and settings via a simple `config` command.
*   **Connectivity Check**: Verify your API credentials and service connectivity with the `check` command.
*   **Rich Output**: Beautiful and informative console output powered by `rich`.

## 🚀 Installation

You can install `ltrans` directly from PyPI (once published):

```bash
uv pip install ltrans
```

Alternatively, you can install from source:

```bash
git clone https://github.com/xyz-liu15/ltrans.git
cd ltrans
uv pip install -e .
```

## 🔑 Configuration

Before using the translation features, you need to configure your AI service API keys.

To set your Google Gemini API key:

```bash
ltrans config --google-key YOUR_GOOGLE_API_KEY
```

To set your Qwen API key and base URL:

```bash
ltrans config --qwen-key YOUR_QWEN_API_KEY --qwen-url YOUR_QWEN_BASE_URL
```

You can view your current configuration (excluding sensitive keys) by running:

```bash
ltrans config
```

## ✅ Check Connectivity

To verify that your configured API keys are working and services are reachable:

```bash
ltrans check
```

## 📖 Usage

Translate Jupyter Notebooks from a source directory to a target Markdown directory.

```bash
ltrans translate SOURCE_DIR [TARGET_DIR] [OPTIONS]
```

*   `SOURCE_DIR`: The directory containing your `.ipynb` files.
*   `TARGET_DIR`: (Optional) The directory where translated `.md` files will be saved. If not provided, it defaults to `<SOURCE_DIR>-translated`.

**Examples:**

Translate notebooks from `my_notebooks/` to `my_notebooks-translated/`:

```bash
ltrans translate my_notebooks/
```

Translate notebooks and save them to a specific directory:

```bash
ltrans translate my_notebooks/ translated_output/
```

Force re-translation of all files, even if they already exist in the target directory:

```bash
ltrans translate my_notebooks/ --force
```

Use a specific provider (e.g., Qwen) and concurrency level:

```bash
ltrans translate my_notebooks/ --provider qwen --concurrency 10
```

## 🤝 Contributing

Contributions are welcome! Please feel free to open issues or submit pull requests.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
