from django.apps import AppConfig


class MailCleanerConfig(AppConfig):
    name = "mail_cleaner"
