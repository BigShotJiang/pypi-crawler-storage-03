from sqlalchemy.orm import declarative_base

Model = declarative_base()
