# Metrics name will start with this prefix
DAGSTER_CLOUD_AGENT_METRIC_PREFIX = "dagster_cloud"
