# Thonny-OneLight

Atom OneLight theme for [Thonny](https://thonny.org) IDE