def say_hello():
    return "Welcome to FORKTEX!"
