from throttlebuster.cli import main

main()
