"""Main entry point to execute the llg3d module."""

from .main import main

if __name__ == "__main__":
    main()
