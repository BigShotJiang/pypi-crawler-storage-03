# TorchQUBO
CLI + 7 solvers.
