

# datasupplement


```
data file standard and parser meant to be clean, simple
and human readable, uses '.supp' file extension


```
