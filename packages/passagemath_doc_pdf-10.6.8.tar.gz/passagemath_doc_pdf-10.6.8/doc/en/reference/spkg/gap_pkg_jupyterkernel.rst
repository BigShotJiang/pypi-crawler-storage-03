.. _spkg_gap_pkg_jupyterkernel:

gap_pkg_jupyterkernel: Native Jupyter kernel for GAP
====================================================

Description
-----------

This GAP package implements the Jupyter protocol.

It is shipped together with some GAP packages that are dependencies
or additional functionality.

See also: ``sagemath_gap_pkg_jupyterkernel``


License
-------

BSD-3-Clause license


Upstream Contact
----------------

- https://github.com/gap-packages/JupyterKernel
- https://github.com/nathancarter/jupyterviz


Type
----

optional


Dependencies
------------

- :ref:`spkg_gap`
- :ref:`spkg_gap_packages`
- :ref:`spkg_zeromq`

Version Information
-------------------

package-version.txt::

    4.14.0.p0

Equivalent System Packages
--------------------------

(none known)
