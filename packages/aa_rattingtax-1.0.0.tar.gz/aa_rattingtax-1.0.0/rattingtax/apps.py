from django.apps import AppConfig

class RattingtaxConfig(AppConfig):
    name = "rattingtax"
    label = "rattingtax"
    verbose_name = "Ratting Tax"
    default_auto_field = "django.db.models.BigAutoField"
