# Changelog

---

## Changes in version 0.1.0 (2025/08/20)

- Add additional client metadata to ``collection`` objects consumed by ``langgraph-store-mongodb``.
- Improve testing.

## Changes in version 0.0.1 (2025/05/09)

- Initial release, added support for `MongoDBStore`.
