from cyfi.cli import app

app(prog_name="python -m cyfi")
