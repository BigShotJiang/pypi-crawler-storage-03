from cyfi.version import __version__

__version__
