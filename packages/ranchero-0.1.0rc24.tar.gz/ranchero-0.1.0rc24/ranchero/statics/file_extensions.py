# Used to extract filenames via ends_with()

fqs = [r"\.fq", r"\.fastq", r"\.fq\.gz", r"\.fastq\.gz"]

bams = [r"\.bam"]


all_extensions = fqs + bams