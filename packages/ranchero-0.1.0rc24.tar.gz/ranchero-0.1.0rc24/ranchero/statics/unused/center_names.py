# Ranchero doesn't support standardizing INDSC center names, but here's a start if you want to do it yourself.

{
	"Innstituto de Biomedicina de Valencia": "IBV_CSIC",
	"Instituto_de_Biomedicina_de_Valencia": "IBV_CSIC",
	"Swiss Tropical and Public Health Institute, Switzerland": "STPH",
	"NATIONAL SCIENCE AND TECHNOLOGY DEVELOPMENT AGENCY": "MAHIDOL UNIVERSITY",
	"WADSWORTH CENTER - NYS DOH": "WADSWORTH CENTER",
	"UNIVERSITY OF SAO P AULO": "UNIVERSIDADE DE SAO PAULO",
	"UNIVERSIDAD PERUANA CAYETANO HEREDIA, PERU": "UNIVERSIDAD PERUANA CAYETANO HEREDIA"
}
