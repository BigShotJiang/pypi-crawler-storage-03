from .component_manager import ComponentManagerWidget  # noqa
