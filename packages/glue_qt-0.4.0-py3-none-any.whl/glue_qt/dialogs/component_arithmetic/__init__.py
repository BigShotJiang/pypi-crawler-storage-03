from .component_arithmetic import ArithmeticEditorWidget  # noqa
