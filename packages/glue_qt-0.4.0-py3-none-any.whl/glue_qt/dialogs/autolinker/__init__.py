from glue_qt.dialogs.autolinker.autolinker import run_autolinker  # noqa
