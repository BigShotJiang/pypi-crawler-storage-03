def setup():
    from . import directory_importer  # noqa
