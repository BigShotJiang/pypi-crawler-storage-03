import warnings

from glue.viewers.common.tool import *  # noqa

warnings.warn('glue.viewers.common.tool is deprecated, use '
              'glue.viewers.common.tool instead', UserWarning)
