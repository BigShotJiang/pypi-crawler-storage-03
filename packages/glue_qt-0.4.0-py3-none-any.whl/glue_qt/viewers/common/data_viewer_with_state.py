from glue_qt.viewers.common.data_viewer import DataViewer

__all__ = ['DataViewerWithState']


class DataViewerWithState(DataViewer):
    pass
