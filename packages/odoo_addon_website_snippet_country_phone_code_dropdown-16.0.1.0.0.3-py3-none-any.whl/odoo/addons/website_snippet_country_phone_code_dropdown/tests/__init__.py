# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from . import test_snippet_country_phone_code_dropdown
