FeedGenerator
=============

[![Build Status](https://img.shields.io/github/actions/workflow/status/getpelican/feedgenerator/main.yml?branch=main)](https://github.com/getpelican/feedgenerator/actions)
[![PyPI Version](https://img.shields.io/pypi/v/feedgenerator)](https://pypi.org/project/feedgenerator/)
[![Downloads](https://img.shields.io/pypi/dm/feedgenerator)](https://pypi.org/project/feedgenerator/)
![License](https://img.shields.io/pypi/l/feedgenerator?color=blue)

FeedGenerator is a standalone version of Django’s
[feedgenerator](https://github.com/django/django/blob/master/django/utils/feedgenerator.py)
module. It has evolved over time and includes numerous enhancements.
