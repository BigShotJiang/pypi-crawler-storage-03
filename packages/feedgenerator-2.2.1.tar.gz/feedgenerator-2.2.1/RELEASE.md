Release type: patch

Restore missing `content` property to default item dictionary.
