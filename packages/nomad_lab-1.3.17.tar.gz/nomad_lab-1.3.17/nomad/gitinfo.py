log, ref, version, commit = (
    "e910d86b Merge branch 'v1.0.7' into 'master'",
    'tags/v1.0.7',
    'v1.0.7',
    'e910d86b',
)
