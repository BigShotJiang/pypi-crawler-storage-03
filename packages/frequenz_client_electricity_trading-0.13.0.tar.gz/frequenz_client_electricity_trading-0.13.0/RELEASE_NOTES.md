# Frequenz Electricity Trading API Client Release Notes

## Summary

<!-- Here goes a general summary of what this release is about -->

## Upgrading

* Widen the version range of api-common to also allow v0.8.x.
* Restrict entsoe client dependency version range up to v0.7.x.
* Listing gridpool orders that do not contain a price or quantity no longer raises an exception. Users must validate orders themselves.

## New Features

<!-- Here goes the main new features and examples or instructions on how to use them -->

## Bug Fixes

* Fixed typo in the trading CLI help text.
