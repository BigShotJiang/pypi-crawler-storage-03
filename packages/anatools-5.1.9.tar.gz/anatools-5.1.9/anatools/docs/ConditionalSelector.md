A logic node that selects an output based on a conditional statement
* "ConditionalA" - The first part of the condition statement
* "Operator" - The operator to use to compare the two values
* "ConditionalB" - The second part of the condition statement
* "True" - The value to pass if the condition is True
* "False" - The value to pass if the condition is False