"""
Primitives are stateless functions that perform work on torch.Tensor instances. E.g. activation functions, shape modifications, etc.
"""
