# -*- coding:utf-8 -*- 
# author = 'denishuang'
from __future__ import unicode_literals

default_app_config = 'xyz_unionauth.apps.Config'