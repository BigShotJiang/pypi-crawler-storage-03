::: xmllib.helpers
