def add_numbers(num1, num2):
    num1 + num2

def sub_numbers(num1, num2):
    num1 - num2

def mult_numbers(num1, num2):
    num1 * num2

def divi_numbers(num1, num2):
    num1 / num2