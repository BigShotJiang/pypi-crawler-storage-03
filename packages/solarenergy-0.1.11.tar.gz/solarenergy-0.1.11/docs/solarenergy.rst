solarenergy package
===================

Submodules
----------

.. toctree::

   solarenergy.solar_panels
   solarenergy.radiation

Module contents
---------------

.. automodule:: solarenergy
   :members:
   :undoc-members:
   :show-inheritance:
