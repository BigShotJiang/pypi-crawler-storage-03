[![PyPI - Version](https://img.shields.io/pypi/v/pigeon-transitions)](https://pypi.org/project/pigeon-transitions/)

# Pigeon Transitions

Pigeon transitions is a framework for creating event driven state machines using the Python [Transitions](https://github.com/pytransitions/transitions) library. This framework has the Pigeon message passing client built in.

## Documentation

An example is provided in the [example folder](https://github.com/AllenInstitute/pigeon-transitions/tree/master/example).