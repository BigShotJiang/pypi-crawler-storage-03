class MailboxException(Exception):
    pass


class NotCollectedError(Exception):
    pass
