# Safety classification - toxicity/NSFW flags
