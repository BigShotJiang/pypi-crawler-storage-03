# HTML utilities - readability-like extraction
