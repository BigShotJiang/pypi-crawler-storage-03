# Text processing utilities
