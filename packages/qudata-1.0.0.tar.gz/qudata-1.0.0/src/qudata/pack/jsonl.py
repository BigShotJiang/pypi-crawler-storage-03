# JSONL dataset builder - supervised jsonl schema
