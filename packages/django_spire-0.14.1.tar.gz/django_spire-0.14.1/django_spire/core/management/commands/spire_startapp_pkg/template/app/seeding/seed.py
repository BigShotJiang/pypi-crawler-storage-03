from module.seeding.seeder import SpireChildAppSeeder

SpireChildAppSeeder.seed_database(count=10)