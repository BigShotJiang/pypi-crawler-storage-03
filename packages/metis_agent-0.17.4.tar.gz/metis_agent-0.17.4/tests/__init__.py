"""
Tests for Metis Agent Framework.

This package contains comprehensive tests for all components including
security, tools, core functionality, and integration tests.
"""