"""
Core tools package for Metis Agent.

This package contains fundamental tools essential for basic operations.
"""
