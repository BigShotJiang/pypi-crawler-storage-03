"""
Advanced tools package for Metis Agent.

This package contains complex and specialized tools for advanced operations.
"""
