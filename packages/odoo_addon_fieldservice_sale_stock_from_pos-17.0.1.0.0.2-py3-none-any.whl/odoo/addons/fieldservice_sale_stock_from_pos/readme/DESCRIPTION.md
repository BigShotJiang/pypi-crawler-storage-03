This module adds compatibility between field_service_sale_stock and pos_order_to_sale_order, allowing the creation of FSM orders directly from the POS.
It also includes logic to handle refunds.
