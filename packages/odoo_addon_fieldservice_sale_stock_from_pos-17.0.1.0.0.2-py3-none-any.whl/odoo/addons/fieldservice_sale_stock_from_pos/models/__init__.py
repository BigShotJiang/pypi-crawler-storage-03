from . import sale_order
from . import stock_picking
from . import pos_config
from . import res_config_settings
