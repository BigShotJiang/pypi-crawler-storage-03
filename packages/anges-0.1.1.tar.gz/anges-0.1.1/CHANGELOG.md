# Changelog

All notable changes to the Anges project will be documented in this file.

## [Unreleased]

### Added
- **Notes Feature**:
  - Added notes from CLI and UI
  - Prompt tuning

## [0.1.0] - 2025-07-15

### Added
Anges is an open-source engineering agent system designed to be install-and-go, but also highly customizable and minimalist.
