<!-- Language switcher - place at top of every documentation file -->
**Languages**: [English](FILENAME.md) | [中文](FILENAME.zh.md)

---

# Document Title

[Brief description of the document]

## Table of Contents

- [Section 1](#section-1)
- [Section 2](#section-2)
- [Examples](#examples)

## Section 1

[Content here]

## Section 2

[Content here]

## Examples

```bash
# Code examples here
```

---

**Languages**: [English](FILENAME.md) | [中文](FILENAME.zh.md)