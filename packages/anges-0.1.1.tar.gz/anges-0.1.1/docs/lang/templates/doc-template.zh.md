<!-- Language switcher - place at top of every documentation file -->
**语言**: [English](FILENAME.md) | [中文](FILENAME.zh.md)

---

# 文档标题

[文档简要描述]

## 目录

- [第一节](#第一节)
- [第二节](#第二节)
- [示例](#示例)

## 第一节

[内容]

## 第二节

[内容]

## 示例

```bash
# 代码示例
```

---

**语言**: [English](FILENAME.md) | [中文](FILENAME.zh.md)