Scale (``ome_zarr.scale``)
==========================

.. automodule:: ome_zarr.scale
   :members:
