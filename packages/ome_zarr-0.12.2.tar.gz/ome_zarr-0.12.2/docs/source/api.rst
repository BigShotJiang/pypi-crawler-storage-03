Python API
==========

.. toctree::
    :maxdepth: 2

    api/cli
    api/csv
    api/data
    api/format
    api/io
    api/reader
    api/scale
    api/utils
    api/writer
