def read_video_last_image(proxy):
    return proxy.last_image, 1
