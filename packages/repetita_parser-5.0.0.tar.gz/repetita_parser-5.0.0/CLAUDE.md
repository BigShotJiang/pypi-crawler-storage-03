See @README.md for a brief project overview.
See @pyproject.toml for available tools and dependencies.

# Workflow/Tools
- Make sure to verify correctness of your changes by running tests using the Bash command `hatch run test`.
- Before finishing a change set, run `hatch fmt` to ensure the code is correctly formatted.
