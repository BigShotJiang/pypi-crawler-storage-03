# SPDX-FileCopyrightText: 2023-present Leon Richardt <git@leon.dev>
#
# SPDX-License-Identifier: MIT
