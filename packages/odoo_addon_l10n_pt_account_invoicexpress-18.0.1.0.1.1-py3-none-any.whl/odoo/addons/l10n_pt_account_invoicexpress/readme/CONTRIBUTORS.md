- Daniel Reis \<<dreis@opensourceintegrators.com>\>, [Open Source
  Integrators](https://www.opensourceintegrators.eu)
