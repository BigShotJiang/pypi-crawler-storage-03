from mcp_demo import create_server

mcp = create_server()