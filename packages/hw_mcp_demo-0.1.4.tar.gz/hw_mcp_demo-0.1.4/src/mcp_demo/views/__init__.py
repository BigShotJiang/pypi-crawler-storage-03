from mcp_demo.views.input_dialogue import dialogue

__all__ = [
    'dialogue'
]