"""Make the CLI runnable using python -m gumerov_expansion_coefficients."""

from .cli import app

app(prog_name="gumerov-expansion-coefficients")
