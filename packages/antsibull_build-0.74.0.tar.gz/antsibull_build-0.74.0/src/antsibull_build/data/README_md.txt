# Ansible Collection - community.ansible

The community.ansible collection is a meta collection.  It pulls in all of the
collections which used to be included in the ansible-2.9 tarball.
