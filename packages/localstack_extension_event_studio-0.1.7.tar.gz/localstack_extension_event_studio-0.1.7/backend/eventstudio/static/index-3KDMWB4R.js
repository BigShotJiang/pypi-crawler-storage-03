(() => {
  // html:/home/runner/work/localstack-extension-event-studio/localstack-extension-event-studio/frontend/src/index.html
  var src_default = "./index-UUISF6VF.html";
})();
//# sourceMappingURL=index-3KDMWB4R.js.map
