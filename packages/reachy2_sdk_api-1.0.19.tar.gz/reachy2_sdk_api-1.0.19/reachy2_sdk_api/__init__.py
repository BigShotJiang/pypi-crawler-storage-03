import sys

from pathlib import Path

sys.path.append(str(Path(__file__).parent))

__version__ = "1.0.19"
