from dice_ml.model_interfaces.base_model import BaseModel
import pandas as pd
import torch

class TimeSeriesModel(BaseModel):

    def __init__(self, model, model_path='', backend = None, func=None, kw_args=None):

        self.sequence_length = kw_args['sequence_length']
        self.num_features = kw_args['num_features']
        self.device = kw_args.get('device','cpu')

        super().__init__(model=model)
        self.model_type = 'regressor'
        self.model.to(self.device).eval()



    def predict(self, input_data):

        if isinstance(input_data, pd.DataFrame):
            input_data = input_data.values
        if input_data.ndim == 2 and input_data.shape[1] == self.sequence_length * self.num_features:
            input_data = input_data.reshape(-1, self.sequence_length, self.num_features)

        x = input_data.reshape(-1, self.sequence_length, self.num_features)
        x = torch.tensor(x, dtype=torch.float32, device=self.device)

        
        with torch.no_grad():
            preds = self.model(x).cpu().numpy().flatten()

        return preds