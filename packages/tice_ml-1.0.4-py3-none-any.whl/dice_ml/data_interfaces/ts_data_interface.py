from dice_ml.data_interfaces.public_data_interface import PublicData
import pandas as pd
import numpy as np

class TimeSeriesData(PublicData):

    def __init__(self, params):

        
        X = params['X']
        y = params['y']
        outcome_name = params['outcome_name']
        seq_len = params['sequence_length']
        num_features = params.get("num_features", X.shape[2])
        cont_feats = params.get('continuous_features',[])
        cat_features = params.get('categorical_features',[])



        

        # make column names like f0_t0, f1_t0, …, f3_t{T-1}
        if not cont_feats and not cat_features:
            base_names = [f"f{i}" for i in range(num_features)]
            cont_feats = base_names

        else:
            base_names = cont_feats + cat_features
            

        flat_feature_names = [
            f"{feat}_t{t}"
            for t in range(seq_len)
            for feat in base_names
        ]

        X_flat = X.reshape(X.shape[0], -1).astype(np.float32)   # (N, T*F)
        cont_flat = [f"{f}_t{t}" for t in range(seq_len) for f in cont_feats]
        cat_flat = [f"{f}_t{t}" for t in range (seq_len) for f in cat_features]

        df = pd.DataFrame(X_flat, columns=flat_feature_names)
        df[outcome_name] = y.astype(np.float32)


        #self.data_df = df

        features_dict = {
            col:[df[col].min(), df[col].max()]
            for col in cont_flat
        }

        #self.feature_names = flat_feature_names
        #self.features = features_dict

        # ---- 3. Call super().__init__ just like PrivateData does -------------
        public_params = {
            "dataframe": df,
            "continuous_features": cont_flat,
            "categorical_features": cat_flat,
            "outcome_name": outcome_name,
            "features": features_dict,
            "permitted_range": features_dict  
        }

        
        super().__init__(public_params)


 

      


        