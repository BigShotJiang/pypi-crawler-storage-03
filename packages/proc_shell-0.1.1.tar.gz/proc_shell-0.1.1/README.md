# proc_shell

Subshell with /proc-like temp file system.