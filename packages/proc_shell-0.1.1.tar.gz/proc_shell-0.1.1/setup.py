from setuptools import setup, find_packages

setup(
    name="proc_shell",
    version="0.1.0",
    packages=find_packages(),  # auto-finds packages under current dir
)