"""Version information for canns-ripser."""

__version__ = "0.2.0"