Add carrier agency concept A delivery carrier may have one or mutliple
agencies. The module does not add any logic around these agencies, it
will be done in dedicated carrier modules if necessary. For instance,
when generating label, sometimes, some information may depend on the
agency that will receive the package, which may depend on the warehouse
