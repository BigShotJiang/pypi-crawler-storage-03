BAD_QUESTION_TEXT = "This is a bad question and is not answerable as posed."
