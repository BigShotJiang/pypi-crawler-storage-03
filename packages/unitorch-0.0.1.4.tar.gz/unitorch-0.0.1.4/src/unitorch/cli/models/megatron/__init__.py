# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.

import unitorch.cli.models.megatron.modeling_gpt
