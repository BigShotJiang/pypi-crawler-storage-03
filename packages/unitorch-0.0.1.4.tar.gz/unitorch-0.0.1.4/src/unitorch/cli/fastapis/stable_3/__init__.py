# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.


import unitorch.cli.fastapis.stable_3.text2image
import unitorch.cli.fastapis.stable_3.image2image
import unitorch.cli.fastapis.stable_3.inpainting
