# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.

import unitorch.cli.fastapis.stable_xl.text2image
import unitorch.cli.fastapis.stable_xl.image2image
import unitorch.cli.fastapis.stable_xl.inpainting
