# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.

import unitorch.cli.fastapis.controlnet_3.text2image
