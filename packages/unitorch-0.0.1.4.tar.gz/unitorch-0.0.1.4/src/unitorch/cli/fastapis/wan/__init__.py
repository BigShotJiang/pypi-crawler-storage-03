# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.

import unitorch.cli.fastapis.wan.text2video
import unitorch.cli.fastapis.wan.image2video
