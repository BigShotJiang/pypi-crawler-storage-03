# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.

import unitorch.cli.fastapis.stable.text2image
import unitorch.cli.fastapis.stable.image2image
import unitorch.cli.fastapis.stable.inpainting
import unitorch.cli.fastapis.stable.resolution
import unitorch.cli.fastapis.stable.image2video
import unitorch.cli.fastapis.stable.interrogator
