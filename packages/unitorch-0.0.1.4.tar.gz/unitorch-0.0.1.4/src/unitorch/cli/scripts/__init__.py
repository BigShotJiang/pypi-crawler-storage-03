# Copyright (c) FULIUCANSHENG.
# Licensed under the MIT License.

import importlib
from functools import partial
from unitorch.cli import GenericScript, registered_script, register_script

# import script modules
