# unitorch scripts

> Pre/Post process with unitorch cli (unitorch-script)

```bash
unitorch-script path/to/script/config/ini --data_file ./data_file.tsv
```
