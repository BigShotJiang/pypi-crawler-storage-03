# unitorch services

> Start/Stop/Restart a service in daemon mode with unitorch cli (unitorch-service)

```bash
unitorch-service start/stop/restart path/to/service/config/ini --daemon_mode False --data_file ./data.tsv
```
