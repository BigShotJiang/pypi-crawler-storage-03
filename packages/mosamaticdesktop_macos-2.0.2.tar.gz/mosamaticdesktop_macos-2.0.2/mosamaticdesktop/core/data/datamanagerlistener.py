class DataManagerListener:
    def new_data(self, data):
        raise NotImplementedError()