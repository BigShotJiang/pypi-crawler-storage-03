"""Input/output operations for data files."""

from .data_handler import load_property_data

__all__ = [
    "load_property_data"
]
