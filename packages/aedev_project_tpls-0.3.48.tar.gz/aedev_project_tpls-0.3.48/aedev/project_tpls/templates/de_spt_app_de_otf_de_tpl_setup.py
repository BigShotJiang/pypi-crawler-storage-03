""" setup of {project_desc}. """
# noinspection PyUnresolvedReferences
import sys
print(f"SetUp {{__name__=}} {{sys.executable=}} {{sys.argv=}} {{sys.path=}}")

# noinspection PyUnresolvedReferences
import setuptools

# ReplaceWith#(setup_kwargs = {setup_kwargs_literal(setup_kwargs)})#

if __name__ == "__main__":
    # ReplaceWith#(setuptools.setup(**setup_kwargs))#
    pass
