.. alpm-conf documentation master file, created by
   sphinx-quickstart
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

alpm-conf
=========

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: Table of Contents

   README
   usage
   alpm-conf
   development
   history
   Repository <https://gitlab.com/xdegaye/alpm-conf>
