To use this module:

1.  Go to 'Purchase' and open a Purchase Order.
2.  If the vendor has defined some code for any purchase order line they
    will be displayed in the line under the column 'Product Supplier
    Code'.
