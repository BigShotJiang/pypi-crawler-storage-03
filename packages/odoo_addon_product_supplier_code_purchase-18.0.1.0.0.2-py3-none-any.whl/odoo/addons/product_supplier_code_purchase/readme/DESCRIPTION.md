This module adds to the purchase order line the supplier code defined in
the product.
