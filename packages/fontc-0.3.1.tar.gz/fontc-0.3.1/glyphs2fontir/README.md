# glyphs2fontir

This crate is a frontend for compilation of Glyphs app sources. It converts from .glyphs to the fontc
internal representation.

It should be referenced only by fontc.
