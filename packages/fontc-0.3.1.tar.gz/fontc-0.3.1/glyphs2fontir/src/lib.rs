//! Converts glyphs.app sources into IR for font compilation.
mod erase_open_corners;
pub mod source;
mod toir;
