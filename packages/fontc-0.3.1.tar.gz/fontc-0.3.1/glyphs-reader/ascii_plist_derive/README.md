# `ascii_plist_derive`

This crate provides a simple derive macro for parsing ASCII/NeXTSTEP/OpenStep
style [property lists]. It is designed for use by the [`glyphs-reader`]
crate and may not be suitable for other purposes.


[property lists]: https://en.wikipedia.org/wiki/Property_list
[`glyphs-reader`]: https://docs.rs/glyphs-reader
