# fontra2fontir

This crate is a frontend for compilation of [Fontra](https://fontra.xyz/) json sources. It converts from .fontra to the fontc
internal representation.

It should be referenced only by fontc.