"""
Bedrock models package.
Contains data structures, constants, and type definitions for Amazon Bedrock model management.
"""
