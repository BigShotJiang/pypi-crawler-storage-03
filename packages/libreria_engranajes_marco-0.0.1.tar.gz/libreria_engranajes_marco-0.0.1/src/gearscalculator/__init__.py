from .definiciones import num_diente
from .definiciones import altura_diente
from .definiciones import diametro_primitivo
from .definiciones import diametro_interior
from .definiciones import paso
from .definiciones import distancia_centros
from .definiciones import espesor
from .definiciones import distancia_centros

