
#include <eigenpy/version.hpp>

int main(int /*argc*/, char** /*argv*/) {
  eigenpy::checkVersionAtLeast(0, 0, 0);
  return 0;
}
