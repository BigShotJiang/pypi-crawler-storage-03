from deprecation_policy import (
    X,
    some_deprecated_function,
    some_future_deprecated_function,
)

some_deprecated_function()
some_future_deprecated_function()
X().deprecated_member_function()
