#! /bin/bash
# Clang activation script

export CC="clang"
export CXX="clang++"
