# Contributing

Standard matrix decomposion routines of Eigen such as the SVD and QR decompositions
can be readily added to **EigenPy** following the example of the Cholesky decomposition
that is already implemented.
Feel free to open a PR if you wrap them for your use case.

