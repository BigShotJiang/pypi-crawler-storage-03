Internal commands
*****************

.. setmode:: internal

.. cmakemodule:: ../../version.cmake
.. cmakemodule:: ../../pkg-config.cmake
.. cmakemodule:: ../../header.cmake
.. cmakemodule:: ../../cxx-standard.cmake

Doxygen related
===============
.. cmakemodule:: ../../doxygen.cmake
