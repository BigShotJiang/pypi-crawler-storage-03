## Iteration Helper Expressions

::: polars_ds.exprs.expr_iter