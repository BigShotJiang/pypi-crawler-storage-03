## Extension for String Manipulation and Metrics

::: polars_ds.exprs.string