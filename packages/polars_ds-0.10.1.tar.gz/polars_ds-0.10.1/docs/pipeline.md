## Polars Native Machine Learning Pipeline

::: polars_ds.modeling.pipeline