## Compatibility with Arrays

::: polars_ds.compat