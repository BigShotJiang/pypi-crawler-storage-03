"""
Test suite for DRF-API-Logger
"""