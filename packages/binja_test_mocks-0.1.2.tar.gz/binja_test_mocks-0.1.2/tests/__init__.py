"""Tests for binja-test-mocks."""
