from .springrank import SpringRank

__version__ = "0.0.9"
__authors__ = "Ben Aoki-Sherwood and Daniel Larremore"
