This directory contains diagrams used in the arch documents.

They can be embedded into those documents two ways:

* by the technique described here using the plantuml proxy service:
  https://stackoverflow.com/questions/32203610/how-to-integrate-uml-diagrams-into-gitlab-or-github
* By pasting them into https://www.planttext.com/ and then embedding the resulting SVG link

The first technique has the problem that the PR won't show changes, since it's always from master.
The second has the problem that you have to update it by hand. Pick your poison.
