# compshs

compshs is a library for **computational social science** in Python. 

It includes various text-focused tools to analyse and visualise information from document corpora.

## Quick start

Install compshs:
```
pip install compshs
```

## Project history

The project started in 2025 at Telecom Paris.