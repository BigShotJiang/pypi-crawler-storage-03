from .base import BaseModel

__all__ = ["BaseModel"]
