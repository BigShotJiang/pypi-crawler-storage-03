class UpdateCoordinator:
    pass