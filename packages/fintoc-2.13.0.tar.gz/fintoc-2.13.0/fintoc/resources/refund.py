"""Module to hold the Refund resource."""

from fintoc.mixins import ResourceMixin


class Refund(ResourceMixin):
    """Represents a Fintoc Refund."""
