"""Module to hold the TobaccoTaxes resource."""

from fintoc.mixins import ResourceMixin


class TobaccoTaxes(ResourceMixin):
    """Represents a Fintoc Tobacco Taxes."""
