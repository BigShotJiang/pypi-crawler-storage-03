"""Module to hold the Taxpayer resource."""

from fintoc.mixins import ResourceMixin


class Taxpayer(ResourceMixin):
    """Represents a Fintoc Taxpayer."""
