"""Module to hold the TransferAccount resource."""

from fintoc.mixins import ResourceMixin


class TransferAccount(ResourceMixin):
    """Represents a Fintoc Transfer Account."""
