"""Module to hold the version utilities."""

version_info = (2, 13, 0)
__version__ = ".".join([str(x) for x in version_info])
