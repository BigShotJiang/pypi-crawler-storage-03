"""
Init file for the Fintoc Python SDK.
"""

from fintoc.core import Fintoc
from fintoc.version import __version__
