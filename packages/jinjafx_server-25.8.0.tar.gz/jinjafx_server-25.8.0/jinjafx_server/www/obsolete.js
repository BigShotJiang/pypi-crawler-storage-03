if (!window.crypto) {
  window.location = 'obsolete.html' + window.location.search;
}
