# -*- coding: utf-8 -*-
"""Command-line interface modules."""

from .main_cli import main

__all__ = ["main"]
