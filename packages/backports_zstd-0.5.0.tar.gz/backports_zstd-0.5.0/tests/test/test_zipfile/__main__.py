import unittest

from . import load_tests  # noqa: F401


if __name__ == "__main__":
    unittest.main()
