DATA_SCHEMA = {
    "bank_balance": 0,
}