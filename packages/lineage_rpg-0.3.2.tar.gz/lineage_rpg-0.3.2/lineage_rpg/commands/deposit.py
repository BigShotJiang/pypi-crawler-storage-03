def execute(playerData, amount):
    try:
        amount = int(amount)
        if amount <= 0:
            print("Please enter a valid amount to deposit.")
            return
        if amount > playerData['bank_balance']:
            print(f"You cannot deposit more than your current balance of ${playerData['bank_balance']}.")
            return
        playerData['bank_balance'] += amount
        print(f"Successfully deposited ${amount}. New balance: ${playerData['bank_balance']}")
    except ValueError:
        print("Invalid amount. Please enter a numeric value.")