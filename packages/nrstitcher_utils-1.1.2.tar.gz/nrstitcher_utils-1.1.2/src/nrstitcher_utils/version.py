version = "1.1.2"
"""software version"""
