# nrstitcher_utils

The goal of this project is to ease usage of [NRSticher program](https://pi2-docs.readthedocs.io/en/latest/nr_stitcher.html) with esrf datasets

## how to access it from esrf infrascture

``` bash
module load nrstitcher
```

## documentation

Latest build documentation can be found [here](https://nrstitcher-utils-tomotools-7f52d4ab174ba161998ecb1bcc6adfcada61.gitlab-pages.esrf.fr/)