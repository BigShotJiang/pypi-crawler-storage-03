from django_bulk_hooks.handler import Hook as HookClass
from django_bulk_hooks.manager import BulkHookManager

__all__ = ["BulkHookManager", "HookClass"]
