import unittest


class TestMocker(unittest.TestCase):
    pass
