"""
Tools package for automagik-tools

This package contains all the MCP tools that can be loaded and used
with the automagik-tools framework.
"""

__all__ = []
