from tinyml4all.audio.capture import capture_serial
from tinyml4all.audio.synthetis import synthesize_speech
from tinyml4all.audio.classification.ClassificationAlbum import (
    ClassificationAlbum as Album,
)
