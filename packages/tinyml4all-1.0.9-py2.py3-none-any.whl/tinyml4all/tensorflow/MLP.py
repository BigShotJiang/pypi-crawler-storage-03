from tinyml4all.tensorflow.Sequential import Sequential


class MLP(Sequential):
    """
    Custom implementation for Multi-Layer Perceptron
    """

    pass
