from tinyml4all.tensorflow.Sequential import Sequential


class CNN1D(Sequential):
    """
    Custom implementation for 1D CNN
    """

    pass
