from tinyml4all.tabular.regression.RegressionTable import RegressionTable as Table
from tinyml4all.tabular.regression.RegressionChain import RegressionChain as Chain
