from tinyml4all.tabular.capture import capture_serial
