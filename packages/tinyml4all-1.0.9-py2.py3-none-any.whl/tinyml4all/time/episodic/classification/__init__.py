from tinyml4all.time.episodic.classification.EpisodicClassificationTimeSeries import (
    EpisodicClassificationTimeSeries as TimeSeries,
)
from tinyml4all.time.episodic.classification.Chain import Chain
