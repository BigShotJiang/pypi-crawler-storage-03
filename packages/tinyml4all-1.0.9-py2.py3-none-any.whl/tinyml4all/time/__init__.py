from tinyml4all.time.capture import capture_serial
