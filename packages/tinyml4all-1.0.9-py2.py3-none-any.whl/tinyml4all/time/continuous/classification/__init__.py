from tinyml4all.time.continuous.classification.ContinuousClassificationTimeSeries import (
    ContinuousClassificationTimeSeries as TimeSeries,
)
from tinyml4all.tabular.classification import Chain
