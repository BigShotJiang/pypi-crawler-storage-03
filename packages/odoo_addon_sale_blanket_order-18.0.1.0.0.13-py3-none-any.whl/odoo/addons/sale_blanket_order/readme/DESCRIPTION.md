A blanket order is a pre-agreement to sell a certain number of
quantities of products at a specific price. From a confirmed blanket
order, the users can create new sale orders at such price, until the
blanket order expires, either due to reaching the validity date or
exhausting all the quantities of products.
