from .analysers import *
from .datasources import *
from .runner import *

if(__name__ == "__main__"):
    get_args_and_run()

