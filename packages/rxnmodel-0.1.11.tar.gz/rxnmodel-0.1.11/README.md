This module defines reaction models for thermokinetic studies
