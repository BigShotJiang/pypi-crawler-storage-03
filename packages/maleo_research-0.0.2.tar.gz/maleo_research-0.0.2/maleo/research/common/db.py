from maleo.soma.managers.db import create_base


MaleoResearchBase = create_base()
