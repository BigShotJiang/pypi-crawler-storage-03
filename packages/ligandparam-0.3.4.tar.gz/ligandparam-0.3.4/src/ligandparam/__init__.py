# This file is intentionally left blank.
__version__ = "0.3.0"
__logging_name__ = "ligandparam"

