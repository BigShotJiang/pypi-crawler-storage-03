from pnb.mcl.test.model_api import load_suite
from pnb.mcl.metamodel import standard

load_tests = load_suite(standard)
