
from zopf._bindings import launch_cli

launch_cli()