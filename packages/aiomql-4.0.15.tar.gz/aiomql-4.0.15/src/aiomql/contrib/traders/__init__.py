from .simple_trader import SimpleTrader
from .scalp_trader import ScalpTrader
