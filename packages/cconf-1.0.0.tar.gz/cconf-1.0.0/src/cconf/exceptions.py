class ConfigError(Exception):
    pass


class ConfigWarning(UserWarning):
    pass


class PolicyError(Exception):
    pass
