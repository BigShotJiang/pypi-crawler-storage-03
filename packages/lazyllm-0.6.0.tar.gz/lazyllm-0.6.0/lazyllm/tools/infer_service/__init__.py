from .serve import InferServer, JobDescription
from .client import InferClient

__all__ = [
    'InferServer',
    'InferClient',
    "JobDescription"
]
