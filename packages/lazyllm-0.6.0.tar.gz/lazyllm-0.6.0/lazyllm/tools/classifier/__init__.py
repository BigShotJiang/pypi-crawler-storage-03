from .intent_classifier import IntentClassifier

__all__ = [
    'IntentClassifier'
]
