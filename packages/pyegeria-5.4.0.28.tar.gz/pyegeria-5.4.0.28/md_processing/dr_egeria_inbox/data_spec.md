
# Create Data Dictionary
## Name
Clinical Trial Data Dictionary

## Description
A data dictionary for clinical trial data elements 

## Qualified Name


___

# moo Create Data Spec

## Name

Data Specification for Teddy Bear Drop Foot Clinical Trial

## Description

Principle data requirements for this clinical trial. Meow

___


# moo Create Data Structure

## Name

Incoming Weekly Measurement Data

## Description

This describes  the weekly measurement data for each patient for the Teddy Bear drop foot clinical trial - meow

## In Data Spec

Data Specification for Teddy Bear Drop Foot Clinical Trial

___

# moo Create Data Field
## Name
PatientId
## Description
Unique identifier of the patient
## Data Type
String
## Position
0
## Min Cardinality
1
## Max Cardinality
1
## In Data Structure
> initially a data field must have at least one place it is part of and can update

Incoming Weekly Measurement Data
## Data Class (1)
## Glossary Term (1)
## Namespace
> forms part of qualified name
## Version

## In Data Dictionary
Clinical Trial Data Dictionary

## Qualified_Name

DataField::PatientId
___


_


