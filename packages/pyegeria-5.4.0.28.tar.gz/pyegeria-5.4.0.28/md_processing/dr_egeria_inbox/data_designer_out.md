

___

# View Data Dictionary
## Output Format
LIST

# View Data Specifications
## Output Format 
LIST


# View Data Specs
## Output Format
LIST
___

# View Data Specs
## Output Format
REPORT

___

# View Data Structures
## Output Format
LIST
___

# View Data Structures
## Output Format
REPORT
___

# View Data Fields
## Output Format
LIST
___

# View Data Fields
## Output Format
REPORT
## Search String
*
___
# View Data Class
## Output Format 
LIST

___
# View Data Class
## Output Format
REPORT

___


# View Data Class
## Output Format
DICT