from typing import Literal


PaginationOrder = Literal["asc", "desc"]
