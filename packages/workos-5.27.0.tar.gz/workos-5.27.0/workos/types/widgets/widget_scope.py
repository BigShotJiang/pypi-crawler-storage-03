from typing import Literal


WidgetScope = Literal["widgets:users-table:manage"]
