from typing import Literal

ScreenHintType = Literal["sign-up", "sign-in"]
