#ifndef ARNELIFY_ORM_MARIADB_H
#define ARNELIFY_ORM_MARIADB_H

//mariadb

#endif