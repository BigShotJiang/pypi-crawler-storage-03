from enum import Enum


class Language(Enum):
    ENGLISH = "en"
    SPANISH = "es"
