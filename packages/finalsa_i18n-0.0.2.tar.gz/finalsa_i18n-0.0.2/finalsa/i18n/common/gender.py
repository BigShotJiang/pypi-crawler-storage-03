from enum import Enum


class Gender(Enum):
    UNKNOWN = 0
    MALE = 1
    FEMALE = 2
    OTHER = 3
