# Safari UI protos

These protos are used for communication with the RoboticsUI framework.

> Note: Changes to these protos require recompilation of both the framework
> and the Unity portion of the RoboticsUI.
