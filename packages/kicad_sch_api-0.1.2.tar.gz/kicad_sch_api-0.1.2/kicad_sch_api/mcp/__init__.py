"""
KiCAD Schematic API - Model Context Protocol (MCP) Server

Basic MCP server implementation for AI-driven schematic manipulation.
"""

__version__ = "0.1.0"