from ai_infra_bench.version import __version__

__all__ = ["__version__"]
