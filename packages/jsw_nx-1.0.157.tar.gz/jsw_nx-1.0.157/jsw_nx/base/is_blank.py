def is_blank(s):
    if s == '':
        return True
    return s.isspace()
