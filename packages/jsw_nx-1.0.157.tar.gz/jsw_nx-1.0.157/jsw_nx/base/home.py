import os


def home():
    return os.getenv('HOME')
