def noop():
    pass


def noop_scrapy_parse(response):
    pass
