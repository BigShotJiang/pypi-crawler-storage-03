def to_a(obj):
    return list(obj)
