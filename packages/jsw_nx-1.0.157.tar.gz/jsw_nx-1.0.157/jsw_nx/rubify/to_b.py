def to_b(*args):
    return bool(args[0])
