def to_f(string):
    return float(string)
