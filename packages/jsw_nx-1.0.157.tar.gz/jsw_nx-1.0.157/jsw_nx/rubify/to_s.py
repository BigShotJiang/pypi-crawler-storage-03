def to_s(obj):
    return str(obj)
