def times(n, fn):
    for i in range(n):
        fn(i)
