def to_i(string):
    return int(string)
