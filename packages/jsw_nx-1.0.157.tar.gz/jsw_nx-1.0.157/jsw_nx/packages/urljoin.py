import urllib.parse


def urljoin(url1, url2):
    return urllib.parse.urljoin(url1, url2)
