import time


def sleep(sec):
    time.sleep(sec)
