def uniq(in_list):
    """
    Returns a list with unique elements of the input list.
    """
    return list(set(in_list))
