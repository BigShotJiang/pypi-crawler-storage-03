"""
Staphscope Typing Tool — MLST + spa + SCCmec typing for Staphylococcus aureus
"""

__version__ = "0.2.0"
__author__ = "Beckley Brown"
__email__ = "brownbeckley94@gmail.com"
