"""Project generation scripts for Sthali Core.

This package contains scripts to automate the creation of new projects using templates.
"""
