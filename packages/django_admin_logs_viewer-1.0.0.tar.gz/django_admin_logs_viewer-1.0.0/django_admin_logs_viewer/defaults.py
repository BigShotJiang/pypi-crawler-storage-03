DEFAULTS = {
    "LOGS_ROWS_PER_PAGE": 100,
    "LOGS_SHOW_ERRORS_SINCE_LAST_LOG_IN": False,
    "datetime_format": "%Y-%m-%d %H:%M:%S,%f",
}
