from .views.parser import LOGS_PREDEFINED_REGEXES
default_app_config = "django_admin_logs_viewer.apps.DjangoAdminLogsViewerConfig"
