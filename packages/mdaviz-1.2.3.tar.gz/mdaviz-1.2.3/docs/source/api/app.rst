====================================
Application starting point
====================================

.. automodule:: mdaviz.app
    :members:
    :private-members:
