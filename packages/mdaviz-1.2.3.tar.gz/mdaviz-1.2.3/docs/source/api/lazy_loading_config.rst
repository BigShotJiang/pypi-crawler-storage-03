====================================
Lazy Loading Configuration
====================================

.. automodule:: mdaviz.lazy_loading_config
    :members:
    :private-members:
