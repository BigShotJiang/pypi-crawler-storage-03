from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="cex-discord-bot",
    version="0.1.8",
    packages=find_packages(),
    install_requires=["requests"],
    entry_points={
        "console_scripts": ["cex-bot=cex_discord_bot.cex_info:main"],
    },
    author="Jose89fcb",
    description="Bot de línea de comandos para consultar cajas de CEX",
    long_description=long_description,
    long_description_content_type="text/markdown",  # Esto es clave
    python_requires=">=3.7",
)
