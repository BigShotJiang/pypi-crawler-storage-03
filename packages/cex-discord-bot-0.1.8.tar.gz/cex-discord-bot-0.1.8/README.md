# CEX Discord Bot

Bot de línea de comandos para consultar cajas de CEX.  
Permite obtener información como nombre, precio, cantidad en tienda, disponibilidad online, rating, fecha de actualización, link y la imagen de la caja.

---

## Código de ejemplo

```python
from cex_discord_bot.cex_info import listar_cajas

game_id = 711719417576
box = listar_cajas([game_id])[0]

print("Nombre:", box.nombre)
print("Precio:", box.precio)
print("Tienda:", box.tienda)
print("Online:", box.online)
print("Entrega:", box.entrega)
print("Rating:", box.rating)
print("Estrellas:", box.estrellas)
print("Última actualización:", box.last_update)
print("Link:", box.link)
print("Imagen:", box.imagen_grande)
print("-" * 50)


Instalación

Instala el paquete desde PyPI:
pip install cex-discord-bot

Uso

Después de instalarlo, puedes usarlo desde la línea de comandos con:
python -m cex_discord_bot.cex_info



Bot funcional: https://i.imgur.com/y0U3jyY.png



