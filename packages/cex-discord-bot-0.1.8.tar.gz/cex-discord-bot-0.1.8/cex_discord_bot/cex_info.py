# cex_info.py

from datetime import datetime
import requests

def obtener_box(game_id):
    """
    Devuelve un diccionario con la información de la caja desde la API de CEX.
    """
    url = f"https://wss2.cex.es.webuy.io/v3/boxes/{game_id}/detail"
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        box = data['response']['data']['boxDetails'][0]  # Primer resultado
        return box
    except Exception as e:
        print(f"Error al obtener box {game_id}: {e}")
        return None

# Clase para representar cada caja
class Box:
    def __init__(self, data, game_id):
        self.nombre = data.get('boxName', 'Desconocido')
        self.precio = data.get('sellPrice', 0)
        self.tienda = data.get('collectionQuantity', 0)
        self.online = data.get('ecomQuantityOnHand', 0)
        self.entrega = "✅ Disponible online" if data.get("webSellAllowed", 0) == 1 and self.online > 0 else "❌ No disponible online"
        self.rating = data.get("boxRating", 4.8)
        self.estrellas = "⭐" * round(self.rating)
        last = data.get("lastPriceUpdatedDate") or "Desconocida"
        try:
            last_dt = datetime.strptime(last, "%Y-%m-%d %H:%M:%S")
            self.last_update = last_dt.strftime("%d/%m/%Y %H:%M:%S")
        except:
            self.last_update = last
        self.link = f"https://es.webuy.com/product-detail?id={game_id}"
        # Imagen grande
        self.imagen_grande = data.get('imageUrls', {}).get('large', None)

    def __str__(self):
        return (
            f"{self.nombre} \n"
            f"Precio: {self.precio}€ \n"
            f"Tienda: {self.tienda} \n"
            f"Online: {self.online} \n"
            f"Entrega: {self.entrega} \n"
            f"Rating: {self.rating} {self.estrellas} \n"
            f"Última actualización: {self.last_update}\n"
            f"Link: {self.link} \n"
            f"Imagen: {self.imagen_grande}"
        )

# Función principal para listar cajas
def listar_cajas(game_ids):
    resultados = []
    for game_id in game_ids:
        box_data = obtener_box(game_id)
        if box_data:
            resultados.append(Box(box_data, game_id))
    return resultados

# Función main para línea de comandos
def main():
    ids = input("Introduce los IDs de las cajas separados por comas: ")
    game_ids = [i.strip() for i in ids.split(",") if i.strip()]

    cajas = listar_cajas(game_ids)

    print("\nResultados:\n" + "-" * 80)
    for box in cajas:
        print(box)
        print("-" * 80)

if __name__ == "__main__":
    main()
