def print_me():
    print("Hello from print_me!")