# FastAPI Custom Responses

Provides normalized response objects and error handling

