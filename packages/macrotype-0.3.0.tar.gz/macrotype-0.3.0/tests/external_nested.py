class ExternalOuter:
    class Inner:
        pass
