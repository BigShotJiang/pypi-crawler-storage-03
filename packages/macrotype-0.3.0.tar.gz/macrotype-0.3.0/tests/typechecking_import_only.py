from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from decimal import Decimal


def uses_decimal(x: "Decimal") -> None:
    pass
