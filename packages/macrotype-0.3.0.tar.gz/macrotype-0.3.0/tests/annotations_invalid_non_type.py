# Invalid non-type annotation to test error handling
BAD_NON_TYPE: 123
