class Namespace:
    @classmethod
    def make(cls) -> None: ...


namespace = Namespace.make
