import typing

if typing.TYPE_CHECKING:
    from decimal import Decimal as Dec


def takes(x: "Dec") -> None:
    pass
