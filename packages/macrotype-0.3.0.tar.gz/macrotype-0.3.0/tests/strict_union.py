from typing import Union

# Union variable used to exercise strict normalization
STRICT_UNION: Union[str, int]
