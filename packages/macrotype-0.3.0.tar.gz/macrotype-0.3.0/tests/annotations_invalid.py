from typing import Literal

# Invalid Literal value to test error handling
BAD_LITERAL: Literal[object()]
