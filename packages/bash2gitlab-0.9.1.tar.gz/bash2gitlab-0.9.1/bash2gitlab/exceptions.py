"""Exceptions shared across entire library"""


class Bash2GitlabError(Exception):
    """Base error for all errors defined in bash2gitlab"""
