pythonw -m pytest --cov=wxutils --cov-report=html
