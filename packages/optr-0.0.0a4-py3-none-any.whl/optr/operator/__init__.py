"""
Operator module for high-level automation
"""

from .base import Operator

__all__ = ["Operator"]
