"""
optr - Operator Framework for Desktop and Robot Automation
"""

__version__ = "0.0.0a1"
