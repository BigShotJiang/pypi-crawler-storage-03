"""Service layer for LinKCovery - separating business logic from CLI."""
