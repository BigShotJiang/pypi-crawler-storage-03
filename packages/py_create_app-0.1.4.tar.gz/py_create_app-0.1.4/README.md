# py-create-app

A Quick-style CLI to bootstrap Python projects:
- creates a virtualenv
- interactive checkbox to pick libraries (NumPy, Pandas, FastAPI, PyTorch, etc.)
- installs them
- sets up starter files

