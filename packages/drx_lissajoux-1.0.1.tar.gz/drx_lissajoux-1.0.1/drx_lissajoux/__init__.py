"""
Python library for interfacing with a DrX Lissajoux device.
"""
