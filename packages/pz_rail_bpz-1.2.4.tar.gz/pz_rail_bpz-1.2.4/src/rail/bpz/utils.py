""" Utility functions """

import os
from rail import bpz

RAIL_BPZ_DIR = os.path.abspath(os.path.join(os.path.dirname(bpz.__file__), '..', '..'))
