from setuptools import setup

setup(setup_requires=['setuptools_scm'])
