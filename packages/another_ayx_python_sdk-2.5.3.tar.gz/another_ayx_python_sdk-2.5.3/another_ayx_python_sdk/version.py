"""FILE GENERATED FROM SETUP.PY."""
short_version = "2.5.3"
version = "2.5.3"
full_version = "2.5.3"
release = True

if not release:
    version = full_version
