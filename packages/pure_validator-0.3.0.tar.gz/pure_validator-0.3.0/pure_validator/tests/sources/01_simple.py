def simple_pure(n: int) -> int:
    return n + 1


simple_pure.pure = True
