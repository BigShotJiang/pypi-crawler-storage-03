# Define constants to avoid string literals
FIELD_STORE_NAME = "store_name"
FIELD_STATUS = "status"
FIELD_NEXT_RUN_AT = "next_run_at"
FIELD_LOCKED_BY = "locked_by"
FIELD_PRIORITY = "priority"
FIELD_ID = "_id"
FIELD_EXPIRE_AT = "expire_at"
FIELD_WORKER_INFO = "worker_info"
