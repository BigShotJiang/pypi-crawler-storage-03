from mq.dashboard.router import init_mq_dashboard
from mq.dashboard.router import router as fastapi_router

__all__ = ["fastapi_router", "init_mq_dashboard"]
