# -*- mode: python -*-
"""Shared code for all scripts and modules"""
