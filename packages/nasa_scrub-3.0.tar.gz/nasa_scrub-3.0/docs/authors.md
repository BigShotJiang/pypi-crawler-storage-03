---
layout: default
title: Credits
nav_order: 14
---

# Credits

# Development Lead
* Lyle Barner: [lyle.barner@jpl.nasa.gov](mailto:lyle.barner@jpl.nasa.gov)

# Contributors
* Aaron Black: [aaron.black@jpl.nasa.gov](mailto:aaron.black@jpl.nasa.gov)
* Elizabeth Crisologo: [elizabeth.p.crisologo@jpl.nasa.gov](mailto:elizabeth.p.crisologo@jpl.nasa.gov)
* Michael Sanchez: [michaelds@berkeley.edu](mailto:michaelds@berkeley.edu)

# Legacy Developers
* Gerard Holzmann (Creator): [gerard.holzmann@gmail.com](mailto:gerard.holzmann@gmail.com)