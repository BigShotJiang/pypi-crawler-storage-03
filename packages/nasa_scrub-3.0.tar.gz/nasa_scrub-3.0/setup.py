#!/usr/bin/env python

"""The setup script."""

import setuptools

setuptools.setup()
