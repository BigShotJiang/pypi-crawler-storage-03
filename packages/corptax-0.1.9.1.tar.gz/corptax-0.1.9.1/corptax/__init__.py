"""Initialize the app"""

__version__ = "0.1.9.1"
__title__ = "corptax"
