# raymond's KMeans++

A Python utility library with helpful functions of Kmeans++ algorithm.
