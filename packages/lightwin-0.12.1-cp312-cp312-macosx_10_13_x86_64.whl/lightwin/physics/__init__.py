"""Gather generic physics functions."""
