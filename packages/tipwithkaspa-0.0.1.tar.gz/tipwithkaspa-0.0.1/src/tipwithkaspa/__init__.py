"""tipwithkaspa placeholder package."""
__all__ = []
