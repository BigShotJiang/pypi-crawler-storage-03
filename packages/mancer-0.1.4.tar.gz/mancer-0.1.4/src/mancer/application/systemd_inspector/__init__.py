"""
Moduł SystemdInspector do monitorowania i raportowania stanu jednostek systemd na zdalnych serwerach.
""" 