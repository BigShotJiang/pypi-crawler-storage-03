#!/usr/bin/env python3
"""
Punkt wejściowy dla modułu RemoteConfigManager.
Umożliwia uruchamianie jako: python -m mancer.application.remote_config_manager
"""

from .cli import main

if __name__ == "__main__":
    main() 