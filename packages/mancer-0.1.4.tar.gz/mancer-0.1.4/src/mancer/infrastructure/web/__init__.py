"""
Mancer Web Infrastructure

This module provides web service capabilities for Mancer applications.
"""

__all__ = ["flask_service"] 