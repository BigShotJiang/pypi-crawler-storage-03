"""
三竹簡訊 Python 函式庫測試套件
Mitake SMS Python Library Test Suite
"""