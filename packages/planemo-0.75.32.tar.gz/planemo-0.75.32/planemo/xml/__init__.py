import os

XML_DIRECTORY = os.path.dirname(__file__)
XSDS_PATH = os.path.join(XML_DIRECTORY, "xsd")

__all__ = ("XSDS_PATH",)
