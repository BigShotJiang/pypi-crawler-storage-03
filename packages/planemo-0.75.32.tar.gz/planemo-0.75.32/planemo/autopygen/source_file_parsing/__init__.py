"""
Subpackage containing functions used for parameter extraction from source files
"""
