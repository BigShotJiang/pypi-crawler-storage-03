# 基础组件

# 发布历史

```
0.0.1 初始版，测试发布功能
0.0.2
0.0.3.230817
0.0.6
    增加两个方法 find_files getWorkDirectory
0.0.7
    debug
0.0.8
    新增 TaskManage,Executing
0.0.9   正式 2024-09-10 降薪30%
    调整debug 输出格式
0.0.10 发布
    增加  read_stream, write_stream
    增加  limitThreadPoolExecutor
0.0.11
    新增 source.py 模块, Singleton
0.0.12
    win 模块
    gps dsm
0.0.13
    单例模式 装饰器
    增加  compile_source 方法
    增加类 EventLoop
0.0.14
    log 增加方法 create_logger
0.0.15
    util.__init__.py 优化
    安装时出现bug，使用下面版本
0.0.16
    修复安装Bug
0.0.17
    新增工具方法
0.0.18
    修复枚举枚举的已知BUG
    增加 modules 模块
0.0.19
    文件大小转换
0.0.20
    优化
0.0.21
    增加 ThreadTask 类
0.0.22
    增加 计时器类
0.0.23
    增加 ExpiringDict
0.0.24
    增加 choose 方法
    tryExcept 装饰器
0.0.25
    增加 setup 的相关函数及类
0.0.26
    get_classifiers
0.0.27
    增加network模块
0.0.28
    增加 timeout 方法
0.0.29
    优化
    importExcell
0.0.30
   timeout 优化
0.0.31
    线性/线性退避的超时时间
0.0.32
    增加 ping_host 方法
0.0.33
    优化 thread event_loop
0.0.34
    增加 pools 增加 run_async_tasks 方法
```

# 安装

pip install co6co==0.0.2
