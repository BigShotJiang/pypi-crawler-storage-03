# Copyright (c) 2025 Microsoft Corporation.

"""Tool handling package."""

from .base import LLMTool

__all__ = ["LLMTool"]
