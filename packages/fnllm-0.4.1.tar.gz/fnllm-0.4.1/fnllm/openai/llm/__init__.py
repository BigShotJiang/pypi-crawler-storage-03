# Copyright (c) 2025 Microsoft Corporation.


"""OpenAI LLM implementations."""
