# Copyright (c) 2025 Microsoft Corporation.

"""LLM base package."""

from .base_llm import BaseLLM

__all__ = ["BaseLLM"]
