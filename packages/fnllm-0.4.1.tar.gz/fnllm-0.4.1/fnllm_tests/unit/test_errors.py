# Copyright (c) 2025 Microsoft Corporation.


def test_can_import_errors():
    import fnllm.errors as e

    assert e is not None
