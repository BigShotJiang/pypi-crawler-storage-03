"""Process YAML include files and variable substitutions."""
__version__ = '0.6.7'
