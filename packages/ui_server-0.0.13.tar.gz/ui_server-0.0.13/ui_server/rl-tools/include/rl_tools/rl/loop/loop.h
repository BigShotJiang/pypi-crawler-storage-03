#include "../../version.h"
#if (defined(RL_TOOLS_DISABLE_INCLUDE_GUARDS) || !defined(RL_TOOLS_RL_LOOP_LOOP_H)) && (RL_TOOLS_USE_THIS_VERSION == 1)
#pragma once
#define RL_TOOLS_RL_LOOP_LOOP_H



RL_TOOLS_NAMESPACE_WRAPPER_START
namespace rl_tools::rl::loop{
    struct Config{};
}
RL_TOOLS_NAMESPACE_WRAPPER_END
#include "steps/steps.h"

#endif