```
cp experiments/2025-05-23_13-40-39/1c19b2c_zoo_environment_algorithm/l2f_sac/0001/ui.esm.js ui.js
```


Versions used:

```
foundation-policy        0.0.13
l2f                      2.0.10
```