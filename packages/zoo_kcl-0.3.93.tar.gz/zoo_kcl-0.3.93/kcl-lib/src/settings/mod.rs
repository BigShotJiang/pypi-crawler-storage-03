//! This module contains settings for kcl projects as well as the Design Studio.

pub mod types;

#[cfg(test)]
mod generate_settings_docs;
