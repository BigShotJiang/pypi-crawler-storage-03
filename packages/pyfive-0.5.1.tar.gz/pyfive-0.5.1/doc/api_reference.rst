API Reference
*************

.. autoclass:: pyfive.File
   :members:
   :noindex:
      
----

.. autoclass:: pyfive.Group
   :members:
   :noindex:

----

.. autoclass:: pyfive.Dataset
   :members:
   :noindex:

----

.. autoclass:: pyfive.Datatype
   :members:
   :noindex:
