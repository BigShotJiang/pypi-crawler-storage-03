from .rtree import RTree


# no modifications to plain RTree needed
class PointRTree(RTree):
    pass
