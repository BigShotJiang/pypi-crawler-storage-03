# ConLAi protobuf

## Build
```shell
protoc --python_out=. ./conl.proto
```
