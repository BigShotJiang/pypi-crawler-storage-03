from .classification import FedDatasetsClassification

__all__ = [
    "FedDatasetsClassification"
]
