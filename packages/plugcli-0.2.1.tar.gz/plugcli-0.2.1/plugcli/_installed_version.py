_installed_version = '0.2.1'
_installed_git_hash = '9309d7329956c4004050dc7278c3e72f3553c36a'
_version_setup_depth = 1
