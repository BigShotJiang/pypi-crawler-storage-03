Restricts blackout days for Scheduled Start (ETA) orders with the same date
