"""Configuration package for CLI-FSD.

This package contains configuration files and settings.
"""
