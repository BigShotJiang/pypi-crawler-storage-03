"""File Interaction MCP Server package."""
