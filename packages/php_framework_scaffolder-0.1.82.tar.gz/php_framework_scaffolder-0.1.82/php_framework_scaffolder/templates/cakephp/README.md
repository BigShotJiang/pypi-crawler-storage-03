## Docker Composer for {{ framework }}

Owner: {{ owner }}
Repo: {{ repo }}
Version: {{ tag }}@{{ commit }}
