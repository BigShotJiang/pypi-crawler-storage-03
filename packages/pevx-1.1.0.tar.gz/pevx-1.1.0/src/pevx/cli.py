#!/usr/bin/env python3
import click

from pevx.commands import uv as uv_commands

@click.group()
@click.version_option()
def cli():
    """Prudentia CLI - Development tools for Prudentia internal developers."""
    pass


cli.add_command(uv_commands.uv_proxy)

if __name__ == '__main__':
    cli() 