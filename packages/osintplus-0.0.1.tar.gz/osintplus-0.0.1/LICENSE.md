Licence MIT

Copyright (©) 2025 root10

Par la présente, la permission est accordée, gratuitement, 
à toute personne obtenant une copie de ce logiciel et des fichiers de documentation associés (le "Logiciel"), 
d'utiliser le Logiciel sans restriction, y compris sans limitation les droits d'utiliser, 
copier, modifier, fusionner, publier, distribuer, sous-licencier, et/ou vendre des copies du Logiciel, 
et de permettre aux personnes à qui le Logiciel est fourni de le faire, sous réserve des conditions suivantes :

La notice de copyright ci-dessus et la présente notice de permission doivent être incluses dans toutes les copies ou parties substantielles du Logiciel.

LE LOGICIEL EST FOURNI "EN L'ÉTAT", SANS GARANTIE D'AUCUNE SORTE, 
EXPRESSE OU IMPLICITE, Y COMPRIS MAIS SANS S'Y LIMITER LES GARANTIES DE QUALITÉ MARCHANDE, 
D'ADÉQUATION À UN USAGE PARTICULIER ET D'ABSENCE DE CONTREFAÇON. EN AUCUN CAS, 
LES AUTEURS OU LES DÉTENTEURS DU COPYRIGHT NE POURRONT ÊTRE TENUS RESPONSABLES DE TOUTE RÉCLAMATION, 
DOMMAGE OU AUTRE RESPONSABILITÉ, QUE CE SOIT DANS LE CADRE D’UN CONTRAT, D’UN DÉLIT OU AUTREMENT, 
DÉCOULANT DE, OU EN LIEN AVEC, 
LE LOGICIEL OU L’UTILISATION OU D’AUTRES RELATIONS AVEC LE LOGICIEL.
