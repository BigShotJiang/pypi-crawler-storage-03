.. _scripts:

====================================================
Scripts (`~magicctapipe.scripts`)
====================================================

.. currentmodule:: magicctapipe.scripts

Reference/API
=============

.. automodapi:: magicctapipe.scripts
    :no-inheritance-diagram:
