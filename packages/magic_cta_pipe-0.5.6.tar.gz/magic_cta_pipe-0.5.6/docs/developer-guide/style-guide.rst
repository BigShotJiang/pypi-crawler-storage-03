Style Guide
==================

``magic-cta-pipe`` follows the same style guide as ``ctapipe``. See the `ctapipe style guide <https://ctapipe.readthedocs.io/en/latest/developer-guide/style-guide.html>`_ for more information.
