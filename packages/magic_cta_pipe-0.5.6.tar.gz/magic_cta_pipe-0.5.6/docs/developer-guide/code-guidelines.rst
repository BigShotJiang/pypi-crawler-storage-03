.. _code_guidelines:

Code Guidelines
===============

Coding should follow the CTA coding guidelines from the **CTA Code
Standards** document. See the `ctapipe code guidelines <https://ctapipe.readthedocs.io/en/latest/developer-guide/code-guidelines.html>`_ for more information.