.. _user-guide:

User Guide
==========

.. toctree::
   :maxdepth: 2

   getting-started
   magic-lst-scripts
