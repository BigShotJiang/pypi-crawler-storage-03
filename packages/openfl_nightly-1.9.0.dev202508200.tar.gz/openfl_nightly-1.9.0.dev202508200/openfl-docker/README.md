# Using TEEs with OpenFL

OpenFL supports [Gramine-based](https://gramineproject.io/) SGX TEEs in containerized environments.

Refer to the dockerization step in the [TaskRunner Guide](https://openfl.readthedocs.io/en/latest/about/features_index/taskrunner.html) for more details.