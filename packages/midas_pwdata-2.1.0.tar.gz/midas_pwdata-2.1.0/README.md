# Midas PV and Wind Data Simulator

The *pwdata* module, provided by the *midas-pwdata* package, provides a simulator for PV and wind time series.

Version: 2.1

## Installation


This package will usually installed automatically together with `midas-mosaik`,
if you opt-in the `bh` extra. It is available on pypi, so you can install it
manually with

```bash
    pip install midas-pwdata
```

## Usage

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

### Inside of midas


To use the pwdata inside of midas, simply add `pwdata` to your modules

```yaml
    my_scenario:
      modules:
        - pwdata
        # - ...
```

and provide a *scope* and a configuration:

```yaml
    my_scenario:
      # ...
      pwdata_params:
        my_grid_scope:
          interpolate: True
          randomize_data: True
          randomize_cos_phi: True
          active_mapping:
            16: [[onshore_p_mw, 5]]
            17: [[solar_p_mw, 0.03]]
            20: [[solar_p_mw, 0.41]]
```

The mapping has to match to the grid that you're using.

### Any Mosaik Scenario

If you don't use midas, you can add the `pwdata` manually to your
`mosaik scenario`_ file. First, the entry in the `sim_config`:

```python
    sim_config = {
        "PVWindData": {"python": "midas_powerseries.simulator:PowerSeriesSimulator"},
        # ...
    }
```

Next, you need to start the simulator (assuming a `step_size` of 900):

```python
    pw_sim = world.start(
        "PVWindData",
        step_size=900,
        data_step_size=3600,
        is_load=False,
        is_sgen=True,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located/",
        filename="pvwind_profiles.csv",  # this is default
    )
```

Then the models can be started:

```python
    wind = pw_sim.CalculatedQTimeSeries(name="on_shore_p_mw", scaling=5)
    pv1 = pw_sim.CalculatedQTimeSeries(name="solar_p_mw", scaling=0.03)
    pv2 = pw_sim.CalculatedQTimeSeries(name="solar_p_mw", scaling=0.41)
```

Finally, the modells need to be connected to other entities:

```python
    world.connect(wind, other_entity, "p_mw", "q_mvar")
```

## License

The data set is taken from [50Hertz](https://www.50hertz.com/en/).
