# Generic scraper for hockey leagues
# This module provides functionality to scrape hockey league data from various sources.
