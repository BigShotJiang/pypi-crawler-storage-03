# # hockey_scraper/src/core/factory.py
# Factory class for creating scraper instances in the hockey scraper project
# This file contains the ScraperFactory class which provides methods to create different scraper instances.
