# hockey_scraper/src/core/output_handler.py
# Output handler for the hockey scraper project
# This file contains functions for handling output data, including saving to CSV and JSON formats.
