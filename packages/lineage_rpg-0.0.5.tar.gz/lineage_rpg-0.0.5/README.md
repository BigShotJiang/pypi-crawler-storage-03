git commit -am "Bump version to 0.2.0"
git tag v0.2.0
git push && git push --tags

rm -rf dist build *.egg-info && python -m build && twine upload dist/*

pip index versions lineage-rpg
pip install --upgrade lineage-rpg