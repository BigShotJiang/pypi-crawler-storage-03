   
.. mdinclude:: ../../README.md

Module Reference
================

.. automodule:: mvg
   :members:
   :undoc-members:
