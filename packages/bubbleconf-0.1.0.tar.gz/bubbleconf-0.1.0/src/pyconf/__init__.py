"""pyconf package (src layout)

Minimal package init for the project.
"""

__all__ = []
