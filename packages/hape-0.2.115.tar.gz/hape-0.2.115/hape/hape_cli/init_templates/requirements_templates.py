REQUIREMENTS_DEV = """
""".strip()

REQUIREMENTS_CLI = """
""".strip()