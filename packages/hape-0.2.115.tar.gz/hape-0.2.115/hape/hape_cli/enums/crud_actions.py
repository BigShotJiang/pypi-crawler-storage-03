import enum

class CrudActionsEnum(enum.Enum):
    GENERATE = "generate"
    DELETE = "delete"
