To set contacts to event, you need to:

1.  Go to *Events \> Events*.
2.  Edit or create one.
3.  You will see a new field under field *Organizer* named *Contacts*.

To set contacts for an event type, you need to:

1.  Go to *Events \> Configuration \> Event Templates*.
2.  Edit or create one.
3.  You will see a new field under field *Tags* named *Contacts*.
4.  After doing this, if you create an event and set it this type, the
    event will get appended these contacts automatically.
