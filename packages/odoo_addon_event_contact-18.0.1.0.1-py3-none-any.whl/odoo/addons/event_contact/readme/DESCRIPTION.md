This module adds the possibility to define contacts for the event.
Contacts are needed due to inform the people who should be contacted for
the event.
