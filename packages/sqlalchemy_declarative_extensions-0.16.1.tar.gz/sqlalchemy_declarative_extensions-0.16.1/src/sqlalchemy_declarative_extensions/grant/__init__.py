from sqlalchemy_declarative_extensions.grant.base import Grants

__all__ = [
    "Grants",
]
