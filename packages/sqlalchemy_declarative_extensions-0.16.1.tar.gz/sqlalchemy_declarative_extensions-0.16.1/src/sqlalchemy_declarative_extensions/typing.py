from typing import Protocol, runtime_checkable

__all__ = [
    "Protocol",
    "runtime_checkable",
]
