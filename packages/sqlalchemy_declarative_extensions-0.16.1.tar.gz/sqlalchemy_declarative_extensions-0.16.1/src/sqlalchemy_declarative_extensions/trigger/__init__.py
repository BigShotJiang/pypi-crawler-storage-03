from sqlalchemy_declarative_extensions.trigger.base import (
    Trigger,
    Triggers,
    register_trigger,
)

__all__ = [
    "Trigger",
    "Triggers",
    "register_trigger",
]
