from sqlalchemy_declarative_extensions.alembic.base import register_alembic_events

__all__ = [
    "register_alembic_events",
]
