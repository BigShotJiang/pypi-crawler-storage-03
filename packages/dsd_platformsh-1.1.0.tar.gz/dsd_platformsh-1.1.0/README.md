# dsd-platformsh

A plugin for deploying Django projects to Platform.sh, using django-simple-deploy.

For full documentation, see the documentation for [django-simple-deploy](https://django-simple-deploy.readthedocs.io/en/latest/).