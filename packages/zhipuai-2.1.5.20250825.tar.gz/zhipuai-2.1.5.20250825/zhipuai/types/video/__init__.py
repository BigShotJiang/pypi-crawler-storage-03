
from .video_object import (
    VideoObject,
    VideoResult
)

__all__ = ["VideoObject", "VideoResult"]
