from enum import Enum


class StiFrameworkType(Enum):

    DEFAULT = 'Default'
    FLASK = 'Flask'
    DJANGO = 'Django'
    TORNADO = 'Tornado'