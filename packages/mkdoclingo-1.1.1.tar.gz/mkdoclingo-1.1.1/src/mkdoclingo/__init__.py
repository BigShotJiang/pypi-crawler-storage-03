"""
The mkdoclingo project.
"""
