from .application import BSPumpApplication

app = BSPumpApplication()
app.run()
