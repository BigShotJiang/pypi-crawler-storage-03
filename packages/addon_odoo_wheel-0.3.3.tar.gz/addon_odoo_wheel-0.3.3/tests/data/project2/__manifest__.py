{
    "name": "Project1",
    "description": """Summary of Project1""",
    "author": "Mangono",
    "website": "https://mangono.fr",
    "category": "Technical",
    "version": "18.0.1.2.3",
    "license": "AGPL-3",
    "depends": ["base", "sale"],
    "installable": True,
    "application": False,
    "auto_install": False,
}
