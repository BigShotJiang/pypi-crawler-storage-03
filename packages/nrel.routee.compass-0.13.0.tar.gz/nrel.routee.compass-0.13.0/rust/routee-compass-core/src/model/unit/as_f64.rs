pub trait AsF64 {
    fn as_f64(&self) -> f64;
}
