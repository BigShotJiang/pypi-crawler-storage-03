"""
this package contains some optimized cython modules.
"""
