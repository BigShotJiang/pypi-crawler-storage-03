#!/usr/bin/env python

from .solution_space import solution_space  # noqa: F401
