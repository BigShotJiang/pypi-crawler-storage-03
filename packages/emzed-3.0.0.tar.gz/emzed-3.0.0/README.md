# emzed

`emzed` is a toolkit for analysing LCMS data.

For end-users please see the instructions at https://emzed.ethz.ch

## Develpoment setup

Please use Python 3.10 or newer:

```
$ python -m venv venv
$ pip install -e .[dev]
$ pre-commit install
```
