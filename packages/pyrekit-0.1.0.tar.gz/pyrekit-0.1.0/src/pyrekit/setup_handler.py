from pyrekit.file_handler import create_files, read_file
from pyrekit.server import Signal, pack_app, ServerProcess
from typing import Dict, Type
from json import loads, dumps
import time
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer
import importlib
import sys
from subprocess import run
from os import mkdir


class EventHandler(FileSystemEventHandler):
    def __init__(self, sig: Signal):
        super().__init__()
        self.sig: Signal = sig

    def on_modified(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return

        if self.sig.get_updated() is False:
            self.sig.flip_updated()

def open_observer(sig: Signal, path: str, recursive=True):
    event_handler = EventHandler(sig)
    observer = Observer()
    observer.schedule(event_handler, path, recursive=recursive)
    observer.start()
    return observer


def check_modifications(sig: Signal, path: str = "src/"):
    observer = open_observer(sig, path)

    print("Press CTRL + C to close.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nClosing...")
    finally:
        observer.stop()
        observer.join()


def get_package() -> Dict[str, str]:
    json_str = read_file("package.json")
    if len(json_str) != 0:
        return loads(json_str)
    else:
        print("package.json not found, maybe you did not setup the project!")
        exit(0)


def command(c: str, hide: bool = False):
    run(c.split(" "), capture_output=hide)


def setup(AppName: str = "PyReact"):
    try:
        mkdir("src")
        mkdir("build")
    except FileExistsError:
        print("src and build Folders already exists!")

    create_files(AppName)

    package = {
        "compilerOptions": {
            "target": "ES6",
            "module": "ESNext",
            "jsx": "react-jsx",
            "strict": True,
            "moduleResolution": "node",
            "esModuleInterop": True
        },
        "include": ["src"],
        "scripts": {
            "tailwindcss_dev": "npx @tailwindcss/cli -i ./src/input.css -o ./build/output.css",
            "tailwindcss": "npx @tailwindcss/cli -i ./src/input.css -o ./build/output.css -m",
            "esbuild_dev": "npx esbuild src/index.tsx --sourcemap --bundle --outfile=build/bundle.js --loader:.tsx=tsx",
            "esbuild": "npx esbuild src/index.tsx --minify --bundle --outfile=build/bundle.js --loader:.tsx=tsx",
            "build": "npm run tailwindcss && npm run esbuild",
            "run": "npm run tailwindcss_dev && npm run esbuild_dev"
        }
    }

    data = dumps(package)
    with open("package.json", "w") as fd:
        fd.write(data)
    command("npm install react react-dom esbuild tailwindcss @tailwindcss/cli")

def get_server_handle() -> Type:
    try:
        # rewrites the cached server module, so that hot-reload works
        if 'main' in sys.modules:
            importlib.reload(sys.modules['main'])

        from main import AppServer
        return AppServer
    except ImportError:
        raise ImportError("ERROR: You probably renamed the AppServer class in main.py, make sure it's still AppServer")

def open_server(signal: Signal, DEV = False) -> ServerProcess:
    AppServer = get_server_handle()
    app_server = AppServer()
    server = ServerProcess(app_server, DEV=DEV, signal=signal)
    return server


def handle_script(s: str):
    package = get_package()
    scripts = package["scripts"]
    if s not in scripts:
        print("This command does not exists!")
        return
    command(f"npm run {s}", hide=True)

    if s == "build":
        app_string = pack_app()

        server = ""
        with open("main.py", "r") as fd:
            server = fd.read()

        with open("app.py", "w", encoding="utf-8") as fd:
            fd.write(server.replace('pack_app(self.DEV)', f'r"""{app_string}"""'))

    elif s == "run":
        server = None
        signal = Signal()
        server_signal = Signal()
        server_observer = open_observer(server_signal, "./main.py", recursive=False)

        try:
            server = open_server(signal=signal, DEV=True)
        except ImportError as error:
            print(error)
            print("Closing...")
            return
        
        observer = open_observer(sig=signal, path="src")
        server.start()
        
        try:
            while True:
                if signal.get_updated():
                    print("Change detected in the frontend, recompiling...")
                    command(f"npm run {s}", hide=True)
                    signal.flip_updated()

                    if signal.get_reload() is False:
                        signal.flip_reload()
                    print("Recompiled...")

                if server_signal.get_updated():
                    print("Change detected in the backed main.py, reloading server...")
                    server.close()
                    server = open_server(signal=signal, DEV=True)
                    server.start()
                    server_signal.flip_updated()
                    print("Server reloaded successfully.")

        except KeyboardInterrupt:
            print("Closing...")

        except ImportError as error:
            print(error)

        finally:
            server.close()
            observer.stop()
            observer.join()
            server_observer.stop()
            server_observer.join()
            print("Cleanup complete. Exiting...")
            


def list_scripts():
    """
    Lists the scripts available in package.json
    """
    package = get_package()
    scripts = package["scripts"].keys()
    print("Found", len(scripts), "scripts:")
    for s in scripts:
        print("\b - ", s)
