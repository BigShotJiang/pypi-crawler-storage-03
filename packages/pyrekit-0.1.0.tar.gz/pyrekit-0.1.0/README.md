# Pyrekit - Python and react toolkit

A simple and powerful tool for building desktop applications using Python for the backend and React/TailwindCSS for the frontend, it includes pywebview to make desktop apps. Features include a development server with hot-reloading for both backend and frontend, and a simple build process.

## Prerequisites

Before you can use Pyrekit, you must have the following software installed:

- **Python 3.10+**
- **Node.js and npm**

You can verify the installations by running `python --version` and `npm --version`.

## Installation

To install Pyrekit, you can clone this repository and install it in editable mode:

```bash
git clone https://github.com/TuTheWeeb/pyrekit.git
pip install pyrekit/
```