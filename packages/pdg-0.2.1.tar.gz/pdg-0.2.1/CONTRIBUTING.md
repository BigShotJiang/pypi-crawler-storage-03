In case you are interested in contributing to Python package `pdg`,
please contact [api@pdg.lbl.gov](mailto:api@pdg.lbl.gov).

Please note that during the current development phase we are not able to accept
external pull requests unless agreed upon in advance.
