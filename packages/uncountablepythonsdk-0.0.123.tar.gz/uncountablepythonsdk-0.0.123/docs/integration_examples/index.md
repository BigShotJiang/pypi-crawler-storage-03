# Integration Examples

```{toctree}
create_ingredient
create_output
```
