from typing import Literal

ConvertEngineType = Literal["mineru", "docling", "identity"]