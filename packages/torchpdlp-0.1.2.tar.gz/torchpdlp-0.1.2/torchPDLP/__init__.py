from .solve import solve

__all__ = ["solve"]
