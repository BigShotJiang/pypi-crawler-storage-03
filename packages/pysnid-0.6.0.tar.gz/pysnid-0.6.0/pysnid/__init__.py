__version__ = "0.6.0"

from .snid import run_snid
