"""
Fremko main entry point
"""
from fremko.cli.main import cli

if __name__ == '__main__':
    cli()