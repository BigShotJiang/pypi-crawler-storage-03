import uuid

MOCK_UUID = uuid.UUID("12341234-1234-1234-1234-123412341234")
VIRTUAL_LAB_ID = uuid.UUID("ac9b42ed-22b9-4c9d-9dcb-cdd604c6ebf0")
PROJECT_ID = uuid.UUID("bf0c75df-7dea-43b2-9a11-fcf994f87ccd")
