====================================
MDA Folder Table View
====================================

.. automodule:: mdaviz.mda_folder_table_view
    :members:
    :private-members:
