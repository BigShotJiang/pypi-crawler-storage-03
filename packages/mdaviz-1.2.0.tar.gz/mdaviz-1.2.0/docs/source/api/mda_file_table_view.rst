====================================
MDA File Table View
====================================

.. automodule:: mdaviz.mda_file_table_view
    :members:
    :private-members:
