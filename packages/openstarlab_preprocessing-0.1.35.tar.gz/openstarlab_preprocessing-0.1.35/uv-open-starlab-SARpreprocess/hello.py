def main():
    print("Hello from uv-open-starlab-sarpreprocess!")


if __name__ == "__main__":
    main()
