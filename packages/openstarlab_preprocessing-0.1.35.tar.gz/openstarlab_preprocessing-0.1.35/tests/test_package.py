from preprocessing.sports.SAR_data.SAR_class import Soccer_SAR_data

# pytestを通すためだけの空のテスト
def test_import():
    Soccer_SAR_data.__name__()