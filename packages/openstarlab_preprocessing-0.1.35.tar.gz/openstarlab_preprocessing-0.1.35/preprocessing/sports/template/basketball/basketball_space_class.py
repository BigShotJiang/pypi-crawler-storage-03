import os
import pandas as pd
from tqdm import tqdm

class Basketball_space_data:
  def __init__(self,data_provider,data_path,...)
    self.data_provider = data_provider
    self.data_path = data_path
    ...
    
  def load_data(self):
    ...
