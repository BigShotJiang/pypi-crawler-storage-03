"""RapidAPI MCP Server - Marketplace discovery and assessment tools."""

__version__ = "2.1.0"