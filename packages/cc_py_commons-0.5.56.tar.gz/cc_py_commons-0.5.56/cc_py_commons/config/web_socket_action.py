class WebSocketAction:
	BROADCAST_TO_USER = 'broadcastActionToUser'
	BROADCAST_TO_ACCOUNT = 'broadcastActionToAccount'
