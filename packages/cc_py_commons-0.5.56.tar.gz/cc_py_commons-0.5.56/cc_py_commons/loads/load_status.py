import uuid

ACTIVE = uuid.UUID("9bcd4613-831e-4cb4-a76f-9166ce559fa6")
CANCELLED = uuid.UUID("c05e4437-c750-480f-9ab3-639202cdb8f4")
CONFIRMED = uuid.UUID("adc9769e-d2d7-4931-b373-f0221dcef6c2")
DELIVERED = uuid.UUID("5eca0c1b-1282-49cc-8dc4-8e8eb205e1a1")
DELETED = uuid.UUID("b3f28d9e-828e-459f-ae5a-5db91cabb3e2")
IN_TRANSIT = uuid.UUID("dc9c55e1-e6f8-464e-9a52-b8913ce92ca5")
EXPIRED = uuid.UUID("9f45913b-e4c9-4e0e-a9fb-157fb41e508f")
SELECTED = uuid.UUID("8fa3ae93-b79b-4059-8bfb-e868bc4f858b")