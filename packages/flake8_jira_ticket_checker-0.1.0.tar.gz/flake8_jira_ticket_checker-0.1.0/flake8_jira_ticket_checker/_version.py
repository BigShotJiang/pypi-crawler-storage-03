"""Version information for flake8-jira-ticket-checker."""

__version__ = "0.1.0"
