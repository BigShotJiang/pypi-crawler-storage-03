import logging

import pytest
import lazynwb


def test_import_package():
    pass

    
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    pytest.main([__file__])