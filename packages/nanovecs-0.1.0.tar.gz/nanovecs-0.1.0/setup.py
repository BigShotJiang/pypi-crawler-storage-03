from setuptools import setup, find_packages

setup(
    name="nanovecs",
    version="0.1.0",
    description="Mini biblioteca de vectores y tokenizador en Python puro",
    author="TuNombre",
    packages=find_packages(),
    python_requires=">=3.8",
)
