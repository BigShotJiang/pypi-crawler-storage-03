"""Entry point for running modelaudit as a module with python -m modelaudit."""

from .cli import main

if __name__ == "__main__":
    main()
