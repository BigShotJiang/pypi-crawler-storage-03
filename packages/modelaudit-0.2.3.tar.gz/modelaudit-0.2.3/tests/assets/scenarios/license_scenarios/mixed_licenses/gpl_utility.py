# GPL-3.0 License
# Copyright (C) 2024 GPL Utility Authors
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License.


def gpl_utility_function():
    return "This is GPL-3.0 licensed utility"
