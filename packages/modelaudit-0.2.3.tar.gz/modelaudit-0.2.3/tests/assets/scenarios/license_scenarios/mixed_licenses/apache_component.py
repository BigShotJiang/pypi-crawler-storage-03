# Apache License 2.0
# Copyright 2024 Apache Component Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.


def apache_licensed_function():
    return "This is Apache 2.0 licensed"
