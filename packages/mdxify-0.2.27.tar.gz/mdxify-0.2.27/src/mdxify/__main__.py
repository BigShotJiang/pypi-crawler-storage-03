"""Allow running mdxify as a module with python -m mdxify."""

from .cli import main

if __name__ == "__main__":
    main()