"""CLI package for dextrades.

Provides the `dextrades` console script entrypoint.
"""

__all__ = ["cli"]

