import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const browserWidget: JupyterFrontEndPlugin<void>;
export default browserWidget;
