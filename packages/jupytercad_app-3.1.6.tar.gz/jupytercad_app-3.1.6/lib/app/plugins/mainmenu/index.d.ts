import { JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * A service providing an interface to the main menu.
 */
declare const plugin: JupyterFrontEndPlugin<void>;
export default plugin;
