#!/bin/env python

class HDFStreamRequestError(Exception):
    pass
