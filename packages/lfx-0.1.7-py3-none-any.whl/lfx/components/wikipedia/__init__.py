from .wikidata import WikidataComponent
from .wikipedia import WikipediaComponent

__all__ = ["WikidataComponent", "WikipediaComponent"]
