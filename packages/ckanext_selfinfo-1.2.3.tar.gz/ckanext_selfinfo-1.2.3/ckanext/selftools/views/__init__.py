from __future__ import annotations

from .selftools_htmx import selftools_htmx

__all__: list[str] = [
    "selftools_htmx",
]
