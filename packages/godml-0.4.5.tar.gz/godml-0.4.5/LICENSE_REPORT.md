GODML Dependencies License Report
================================

✅ COMPATIBLE LICENSES:
- typer: MIT License
- pandas: BSD 3-Clause License
- scikit-learn: BSD 3-Clause License
- xgboost: Apache License 2.0
- lightgbm: MIT License
- tensorflow: Apache License 2.0
- mlflow: Apache License 2.0
- pydantic: MIT License
- pyyaml: MIT License
- rich: MIT License
- boto3: Apache License 2.0
- click: BSD 3-Clause License
- numpy: BSD 3-Clause License

🟢 STATUS: All dependencies are MIT/BSD/Apache licensed
🟢 COMMERCIAL USE: Permitted
🟢 DISTRIBUTION: Permitted
🟢 MODIFICATION: Permitted
