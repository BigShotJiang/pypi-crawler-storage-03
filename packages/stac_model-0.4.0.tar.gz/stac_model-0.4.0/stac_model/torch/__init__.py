# noqa: F401
from stac_model.torch.export import from_torch

__all__ = ["from_torch"]
