from .dispatch import (  # noqa
    Dispatcher,
)

from .functions import (  # noqa
    function,
)

from .methods import (  # noqa
    install_method,
    method,
)
