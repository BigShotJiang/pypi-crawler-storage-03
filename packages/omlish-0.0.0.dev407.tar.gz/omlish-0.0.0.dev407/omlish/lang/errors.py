class DuplicateKeyError(KeyError):
    pass
