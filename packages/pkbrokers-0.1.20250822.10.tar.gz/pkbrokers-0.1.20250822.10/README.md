A simple python library to connect to various brokers using standard user credentials, fetch the instruments (trading symbols), indices and their ticks during as well as off market hours.

[![codecov][codecov-badge]][codecov]

[codecov-badge]: https://codecov.io/gh/pkjmesra/PKBrokers/branch/main/graph/badge.svg
[codecov]: https://codecov.io/gh/pkjmesra/PKBrokers
