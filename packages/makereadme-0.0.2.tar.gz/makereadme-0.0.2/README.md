# mkreadme

**mkreadme** is a simple CLI tool to generate README.md files from Python scripts.

---
## Installation

```bash
pip install mkreadme
```
---

## Usage 
```bash
mkreadme your_script.py
```
---

## 📄 LICENSE (MIT - inglês)


---

## 📄 LICENSE-PT (tradução)



---

## 📄 tests/test_basic.py
```python
````
