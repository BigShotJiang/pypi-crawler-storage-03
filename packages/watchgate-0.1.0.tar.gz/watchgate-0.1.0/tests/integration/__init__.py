"""Integration tests for Watchgate MCP Gateway Server.

This package contains integration tests that verify the complete functionality
of Watchgate components working together.
"""
