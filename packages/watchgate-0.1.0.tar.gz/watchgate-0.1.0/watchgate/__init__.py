"""Watchgate MCP Gateway Server v0.1.0"""

__version__ = "0.1.0"
