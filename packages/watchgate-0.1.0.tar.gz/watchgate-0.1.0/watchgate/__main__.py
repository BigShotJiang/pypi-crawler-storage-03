"""Entry point for running watchgate as a module with python -m watchgate."""

from watchgate.main import main

if __name__ == "__main__":
    main()
