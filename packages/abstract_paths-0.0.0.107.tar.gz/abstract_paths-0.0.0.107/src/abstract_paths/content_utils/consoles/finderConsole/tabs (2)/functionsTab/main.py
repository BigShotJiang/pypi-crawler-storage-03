from .functionsTab import functionsTab
from .flowLayout import flowLayout
from abstract_gui.QT6.startConsole import  startConsole
def startFinderConsole():
    startConsole(finderConsole)

