from abstract_webtools import requestManager
input(requestManager("https://www.nature.com/articles/nature.2015.18787").source_code)
