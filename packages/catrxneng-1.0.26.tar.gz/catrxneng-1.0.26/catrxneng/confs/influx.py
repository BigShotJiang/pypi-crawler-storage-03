influx = {
    "url": "https://influx.br3z.com",
    "org": "myorg", 
    "token": "",
    "bucket": "mybucket"
}