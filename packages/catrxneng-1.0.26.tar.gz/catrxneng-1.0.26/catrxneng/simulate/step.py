
class Step:

    def __init__(self, step_name, step_num, start, end):
        self.step_name = step_name
        self.step_num = step_num
        self.start = start
        self.end = end