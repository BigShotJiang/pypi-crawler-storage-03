from trame_client.widgets.html import *  # noqa F403


def initialize(server):
    pass
