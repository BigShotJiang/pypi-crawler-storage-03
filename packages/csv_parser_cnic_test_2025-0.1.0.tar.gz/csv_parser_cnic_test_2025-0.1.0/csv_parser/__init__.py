print("csv_parser package initialized")
