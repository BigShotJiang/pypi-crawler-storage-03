# CSV Parser

This is a simple Python package that parses CSV files and converts them to Arrow format using PyArrow.

## Installation

You can install this package via `pip`:

```bash
pip install csv_parser

```
