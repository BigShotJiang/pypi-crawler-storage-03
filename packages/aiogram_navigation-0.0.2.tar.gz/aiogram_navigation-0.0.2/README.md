# Aiogram Navigation
This package was created to simplify creation of large menus in aiogram by providing easy to use navigation system.
