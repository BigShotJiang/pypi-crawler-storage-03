"""Jupyter server config."""

c.SimpleApp1.configA = "ConfigA from file"  # type:ignore[name-defined]
c.SimpleApp1.configB = "ConfigB from file"  # type:ignore[name-defined]
c.SimpleApp1.configC = "ConfigC from file"  # type:ignore[name-defined]
c.SimpleApp1.configD = "ConfigD from file"  # type:ignore[name-defined]
