.. highlight:: sh

.. include:: ../../../CONTRIBUTING.rst
