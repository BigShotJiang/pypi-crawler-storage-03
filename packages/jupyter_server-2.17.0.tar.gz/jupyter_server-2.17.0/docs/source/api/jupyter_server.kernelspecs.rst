jupyter\_server.kernelspecs package
===================================

Submodules
----------


.. automodule:: jupyter_server.kernelspecs.handlers
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: jupyter_server.kernelspecs
   :members:
   :show-inheritance:
   :undoc-members:
