jupyter\_server.services.kernelspecs package
============================================

Submodules
----------


.. automodule:: jupyter_server.services.kernelspecs.handlers
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: jupyter_server.services.kernelspecs
   :members:
   :show-inheritance:
   :undoc-members:
