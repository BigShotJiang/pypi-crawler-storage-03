PRESERVE_LEADING_WHITESPACE_MARKER = "<<approvaltests:preserve-leading-whitespace>>\n"
