AWS-Specific Documentation
==========================

.. note::

  **IMPORTANT**: The AWS provider is currently not finished and should not be used.


Boot disk types
---------------

- gp2
- gp3
- io1
- io2
- st1
- sc1
- standard
