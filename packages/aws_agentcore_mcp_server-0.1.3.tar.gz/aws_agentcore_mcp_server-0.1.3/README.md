<div align="center">
  <h1>AWS AgentCore MCP Server</h1>
  <h2>A comprehensive framework for building, securing, monitoring, and managing AI agents at scale</h2>

  <div align="center">
    <a href="https://github.com/aws/aws-agentcore-mcp-server/graphs/commit-activity"><img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/m/aws/aws-agentcore-mcp-server"/></a>
    <a href="https://github.com/aws/aws-agentcore-mcp-server/issues"><img alt="GitHub open issues" src="https://img.shields.io/github/issues/aws/aws-agentcore-mcp-server"/></a>
    <a href="https://github.com/aws/aws-agentcore-mcp-server/pulls"><img alt="GitHub open pull requests" src="https://img.shields.io/github/issues-pr/aws/aws-agentcore-mcp-server"/></a>
    <a href="https://github.com/aws/aws-agentcore-mcp-server/blob/main/LICENSE"><img alt="License" src="https://img.shields.io/github/license/aws/aws-agentcore-mcp-server"/></a>
    <a href="https://pypi.org/project/aws-agentcore-mcp-server/"><img alt="PyPI version" src="https://img.shields.io/pypi/v/aws-agentcore-mcp-server"/></a>
    <a href="https://python.org"><img alt="Python versions" src="https://img.shields.io/pypi/pyversions/aws-agentcore-mcp-server"/></a>
  </div>
  
  <p>
    <a href="https://docs.aws.amazon.com/bedrock-agentcore/">Documentation</a>
    ◆ <a href="https://github.com/aws-samples/sample-amazon-bedrock-agentcore-onboarding">Samples</a>
    ◆ <a href="https://aws.github.io/bedrock-agentcore-starter-toolkit/">Starter Toolkit</a>
    ◆ <a href="https://github.com/aws/aws-agentcore-mcp-server">MCP Server</a>
  </p>
</div>

This MCP server provides comprehensive documentation about AWS AgentCore to your GenAI tools, enabling you to build production-ready AI agents with enterprise-grade security, observability, and scalability.

## What is AWS AgentCore?

AWS AgentCore is a comprehensive framework for building, securing, monitoring, and managing AI agents at scale on Amazon Bedrock. It provides:

- **AgentCore Identity**: Centralized management of agent identities and credentials
- **AgentCore Gateway**: Universal integration layer for APIs and external services  
- **AgentCore Observability**: Advanced tracing, monitoring, and debugging capabilities
- **AgentCore Code Interpreter**: Secure code execution within sandboxed sessions
- **AgentCore Memory**: Short-term and long-term memory storage for context-aware agents

## Prerequisites

The usage methods below require [uv](https://github.com/astral-sh/uv) to be installed on your system. You can install it by following the [official installation instructions](https://github.com/astral-sh/uv#installation).

## Installation

You can use the AWS AgentCore MCP server with [40+ applications that support MCP servers](https://modelcontextprotocol.io/clients), including Amazon Q Developer CLI, Anthropic Claude Code, Cline, and Cursor.

### Q Developer CLI example

See the [Q Developer CLI documentation](https://docs.aws.amazon.com/amazonq/latest/qdeveloper-ug/command-line-mcp-configuration.html) for instructions on managing MCP configuration.

In `~/.aws/amazonq/mcp.json`:

```json
{
  "mcpServers": {
    "aws-agentcore": {
      "command": "uvx",
      "args": ["aws-agentcore-mcp-server"]
    }
  }
}
```

### Claude Code example

See the [Claude Code documentation](https://docs.anthropic.com/en/docs/claude-code/tutorials#configure-mcp-servers) for instructions on managing MCP servers.

```bash
claude mcp add aws-agentcore uvx aws-agentcore-mcp-server
```

### Cline example

See the [Cline documentation](https://docs.cline.bot/mcp-servers/configuring-mcp-servers#editing-mcp-settings-files) for instructions on managing MCP configuration.

Provide Cline with the following information:

```
I want to add the MCP server for AWS AgentCore.
Here's the GitHub link: @https://github.com/aws/aws-agentcore-mcp-server
Can you add it?
```

### Cursor example

See the [Cursor documentation](https://docs.cursor.com/context/model-context-protocol#configuring-mcp-servers) for instructions on managing MCP configuration.

In `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "aws-agentcore": {
      "command": "uvx",
      "args": ["aws-agentcore-mcp-server"]
    }
  }
}
```

## Available Tools

The MCP server provides the following documentation tools:

- `quickstart()` - Get started with AWS AgentCore SDK
- `agentcore_identity()` - Learn about secure agent authentication and authorization
- `agentcore_gateway()` - Integrate external APIs and services
- `agentcore_observability()` - Monitor and debug agents in production
- `agentcore_code_interpreter()` - Execute code securely in agents
- `agentcore_memory()` - Build context-aware agents with persistent memory
- `agentcore_tools()` - Integrate tools and extend agent capabilities

## Quick Testing

You can quickly test the MCP server using the MCP Inspector:

```bash
npx @modelcontextprotocol/inspector uvx aws-agentcore-mcp-server
```

Note: This requires [npx](https://docs.npmjs.com/cli/v11/commands/npx) to be installed on your system. It comes bundled with [Node.js](https://nodejs.org/). 

The Inspector is also useful for troubleshooting MCP server issues as it provides detailed connection and protocol information. For an in-depth guide, have a look at the [MCP Inspector documentation](https://modelcontextprotocol.io/docs/tools/inspector).

## Server Development

```bash
git clone https://github.com/aws/aws-agentcore-mcp-server.git
cd aws-agentcore-mcp-server
python3 -m venv venv
source venv/bin/activate
pip3 install -e .

npx @modelcontextprotocol/inspector python -m aws_agentcore_mcp_server
```

## Example Usage

Once installed, you can ask your AI assistant questions like:

- "How do I get started with AWS AgentCore?"
- "Show me how to set up AgentCore Identity for secure authentication"
- "How do I integrate external APIs using AgentCore Gateway?"
- "What observability features does AgentCore provide?"
- "How can I add code execution capabilities to my agent?"
- "How do I implement memory in my AgentCore agent?"
- "What tools can I integrate with my AgentCore agent?"

The MCP server will provide comprehensive documentation and code examples for each AgentCore component.

## Contributing ❤️

We welcome contributions! See our [Contributing Guide](CONTRIBUTING.md) for details on:
- Reporting bugs & features
- Development setup
- Contributing via Pull Requests
- Code of Conduct
- Reporting of security issues

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Security

See [CONTRIBUTING](CONTRIBUTING.md#security-issue-notifications) for more information.
