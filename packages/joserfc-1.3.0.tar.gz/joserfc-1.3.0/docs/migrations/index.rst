Migrations
==========

Here are some migration guides to help you transition from other libraries
to ``joserfc``:

.. toctree::

   authlib
   pyjwt
   python-jose
