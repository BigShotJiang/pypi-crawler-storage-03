from .._rfc7515.registry import JWSRegistry

__all__ = ["JWSRegistry"]
