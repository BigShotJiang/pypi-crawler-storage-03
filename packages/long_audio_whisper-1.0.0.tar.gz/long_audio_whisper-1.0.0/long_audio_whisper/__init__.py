from .processor import WhisperProcessor

__all__ = ["WhisperProcessor"]
