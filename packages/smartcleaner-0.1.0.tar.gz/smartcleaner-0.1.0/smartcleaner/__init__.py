from .core import SmartCleaner

__all__ = ["SmartCleaner"]
__version__ = "0.1.0"
