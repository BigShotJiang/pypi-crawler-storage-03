License
-------

.. literalinclude:: ../license.txt
