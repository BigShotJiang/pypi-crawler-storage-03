# Copyright (c) 2015 Nicolas JOUANIN
#
# See the file license.txt for copying permission.
from __future__ import annotations

QOS_0 = 0x00
QOS_1 = 0x01
QOS_2 = 0x02
