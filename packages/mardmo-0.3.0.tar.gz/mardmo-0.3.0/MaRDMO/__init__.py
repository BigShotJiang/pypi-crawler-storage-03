__title__ = 'MaRDMO'
__version__ = '0.3.0'
__author__ = 'Marco Reidelbach'
__email__ = 'reidelbach@zib.de'
__license__ = 'Apache-2.0'

VERSION = __version__
