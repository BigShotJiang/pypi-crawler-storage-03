# flake8: noqa

# import apis into api package
from wink_sdk_extranet_property_register.api.manage_leads_api import ManageLeadsApi
from wink_sdk_extranet_property_register.api.property_registration_api import PropertyRegistrationApi

