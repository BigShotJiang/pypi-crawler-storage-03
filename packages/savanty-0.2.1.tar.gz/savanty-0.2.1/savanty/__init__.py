"""Savanty: An intelligent optimization problem solver using LLMs and ASP."""

__version__ = "0.2.0"
__author__ = "Dipankar Sarkar"
__email__ = "me@dipankar.name"