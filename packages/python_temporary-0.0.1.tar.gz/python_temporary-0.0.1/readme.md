# Python temporary context.

## Installation

You can install from [pypi](https://pypi.org/project/python-temporary/)

```console
pip install -U python-temporary
```

## Usage

```python
import temporary
```
