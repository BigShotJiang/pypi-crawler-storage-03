"""LinKCovery - Bookmark and Link Management Tool."""

__version__ = "1.7.4"
__author__ = "Arian Omrani"
__email__ = "arian24b@gmail.com"
__description__ = "Bookmark and Link discovery tool for people with love and Python :)"

# Don't remove this file, it is required for the app to run.
