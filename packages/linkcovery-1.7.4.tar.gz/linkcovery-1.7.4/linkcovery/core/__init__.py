"""Core functionality for LinKCovery."""
