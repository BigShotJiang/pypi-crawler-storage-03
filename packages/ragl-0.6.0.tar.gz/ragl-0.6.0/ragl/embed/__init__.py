"""
Text embedding for ragl.

The embed subpackage provides functionality for generating and managing
text embeddings.
"""
