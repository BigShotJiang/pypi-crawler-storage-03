INACTIVITY_TIMEOUT_IN_MINUTES = 30
LOG_PATH = "mcpcat.log"  # Default log file path
SESSION_ID_PREFIX = "ses"
EVENT_ID_PREFIX = "evt"
MCPCAT_API_URL = "https://api.mcpcat.io"  # Default API URL for MCPCat events
