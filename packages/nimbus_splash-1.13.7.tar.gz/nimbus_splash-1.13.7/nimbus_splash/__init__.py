"""
nimbus_splash is a package for using Orca on Bath's Nimbus cloud HPC
"""
