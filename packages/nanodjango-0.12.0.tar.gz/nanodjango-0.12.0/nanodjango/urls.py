# Will be populated at runtime
from django.urls.resolvers import URLPattern, URLResolver


urlpatterns: list[URLPattern | URLResolver] = []
