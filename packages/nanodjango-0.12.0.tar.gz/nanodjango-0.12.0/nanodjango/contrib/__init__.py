from . import django_ninja  # noqa
