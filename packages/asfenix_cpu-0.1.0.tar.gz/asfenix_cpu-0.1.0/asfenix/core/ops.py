import numpy as np

def matmul(a, b):
    return a @ b

def relu(x):
    return np.maximum(0, x)
