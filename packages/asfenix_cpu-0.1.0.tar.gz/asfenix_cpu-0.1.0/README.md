# AsFenix

Framework de IA ligero y optimizado para CPU.
