from .app import PipeAgentApp

def main():
    app = PipeAgentApp()
    app.run()

if __name__ == "__main__":
    main()
