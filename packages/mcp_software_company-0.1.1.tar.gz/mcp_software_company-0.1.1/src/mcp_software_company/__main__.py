# __main__.py

from mcp_software_company import main

main()
