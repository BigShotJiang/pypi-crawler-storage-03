Sketch
======

.. currentmodule:: pyskani

.. autoclass:: pyskani.Sketch
   :special-members: __init__
   :inherited-members:
   :members: