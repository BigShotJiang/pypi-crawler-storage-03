Hit
===

.. currentmodule:: pyskani

.. autoclass:: pyskani.Hit
   :special-members: __init__
   :inherited-members:
   :members: