Database
========

.. currentmodule:: pyskani

.. autoclass:: pyskani.Database
   :special-members: __init__
   :inherited-members:
   :members: