Copyright Notice
================

Pyskani
-------

Pyskani is provided under the MIT License:

.. literalinclude:: ../../COPYING 


skani
-----

FastANI is wrapped and redistributed under the MIT License:

.. literalinclude:: ../../vendor/skani/LICENSE

