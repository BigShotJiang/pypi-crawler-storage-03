"""General logic for predicting annotations to the nova database

Author:
    Dominik Schiller <dominik.schiller@uni-a.de>
Date:
    06.09.2023

"""

def _main():
    raise NotImplementedError

if __name__ == '__main__':
    _main()