import pims
ImageIOReader = pims.ImageIOReader
