"""nova_utils.data.provider

Author:
    Dominik Schiller <dominik.schiller@uni-a.de>
Date:
    06th September 2023

The nova-utils data handler package implements different data provider to interact with multiple datastreams and annotations in a coherent way.
"""