"""
The Kodexa Command-Line Interface
"""

from .cli import cli
