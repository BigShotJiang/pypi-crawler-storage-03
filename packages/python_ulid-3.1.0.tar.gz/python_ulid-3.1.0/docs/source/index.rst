Python ULID
===========

Release v\ |release| (:ref:`What's new <changelog>`)


.. include:: ../../README.rst
   :start-after: teaser-begin
   :end-before: teaser-end

.. include:: ../../README.rst
   :start-after: installation-begin
   :end-before: installation-end

.. include:: ../../README.rst
   :start-after: usage-begin
   :end-before: usage-end

.. include:: ../../README.rst
   :start-after: pydantic-begin
   :end-before: pydantic-end

.. include:: ../../README.rst
   :start-after: cli-begin
   :end-before: cli-end

API documentation
-----------------

.. toctree::
   :maxdepth: 2

   api

.. toctree::
   :maxdepth: 1

   changelog

