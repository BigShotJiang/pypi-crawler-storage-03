# SPDX-FileCopyrightText: 2019 Nicholas Tollervey, written for Adafruit Industries
#
# SPDX-License-Identifier: MIT

"""A simple directory based Python module that's missing metadata."""


def hello():
    """A hello function"""
    return "Hello, World!"
