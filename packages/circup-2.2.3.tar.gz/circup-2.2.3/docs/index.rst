.. Circup documentation master file, created by
   sphinx-quickstart on Mon Sep  2 10:58:36 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../README.rst

.. include:: ../circup/wwshell/README.rst

.. include:: ../CONTRIBUTING.rst

API
===

.. automodule:: circup
    :members:


License
=======

.. include:: ../LICENSE
