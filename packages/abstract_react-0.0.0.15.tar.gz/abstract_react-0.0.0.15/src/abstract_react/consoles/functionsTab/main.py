from .functionsTab import functionsTab
from .flowLayout import flowLayout
from abstract_gui import  startConsole
def startFinderConsole():
    startConsole(finderConsole)

