"""
Core components for HTTP client, authentication, and retry logic
"""
