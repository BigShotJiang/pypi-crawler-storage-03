# Workflow
- Python dependencies install using uv (with --dev for development dependencies)
- Be sure to typecheck when you’re done making a series of code changes
- Prefer running single tests, and not the whole test suite, for performance