# -*- coding: utf-8 -*-
"""This module outputs contains modules for generation of the outputs"""
