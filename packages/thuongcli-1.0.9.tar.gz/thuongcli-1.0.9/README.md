# CLI Utility by Trần Đình Thương

This program provides command-line interface (CLI) commands for controlling your computer in a terminal environment.

## Usage
1. Open the Command Prompt (CMD).
2. Run the command `cli` and press Enter.
3. For help, use the command: `cli --help`.

## Author
- **Trần Đình Thương**
- Contact: [qbquangbinh@gmail.com](mailto:qbquangbinh@gmail.com)