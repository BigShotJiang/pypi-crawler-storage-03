# azcli-local
"azlocal" - Thin wrapper around "az" to use with Localstack

## Installation
```
pip install azlocal
```

## Usage
```
azlocal login
azlocal storage account list
```

## Help
```
azlocal -h
```
