from mirrai.core.screen_capture.base import ScreenCapture

__all__ = ["ScreenCapture"]
