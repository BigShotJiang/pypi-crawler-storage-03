# Backup-chan client connection configuration changelog

See what's changed between versions!

## 0.1.2

* Ensure that port is a number.

## 0.1.1

* Allow specifying custom config path

## 0.1.0

The first stable version.
