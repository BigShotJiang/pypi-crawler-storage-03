# -*- coding: utf-8 -*-

#  Developed by CQ Inversiones SAS. Copyright ©. 2019-2025. All rights reserved.
#  Desarrollado por CQ Inversiones SAS. Copyright ©. 2019-2025. Todos los derechos reservados.

# ****************************************************************
# IDE:          PyCharm
# Developed by: macercha
# Date:         11/12/22 6:06 PM
# Project:      Zibanu Django Project
# Module Name:  __init__.py
# Description:
# ****************************************************************
__version__ = "2.0.6"
