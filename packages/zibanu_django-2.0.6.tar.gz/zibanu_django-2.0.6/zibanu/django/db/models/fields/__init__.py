# -*- coding: utf-8 -*-

# ****************************************************************
# IDE:          PyCharm
# Developed by: macercha
# Date:         2/04/24
# Project:      Zibanu Django
# Module Name:  __init__.py
# Description:
# ****************************************************************
from .phone_field import PhoneField

__all__ = [
    "PhoneField"
]