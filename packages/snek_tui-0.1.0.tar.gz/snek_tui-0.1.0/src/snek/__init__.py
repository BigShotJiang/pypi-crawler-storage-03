"""Snek - A terminal-based Snake game built with Textual."""

__version__ = "0.1.0"