from .app import SnakeApp


def main():
    SnakeApp().run()
