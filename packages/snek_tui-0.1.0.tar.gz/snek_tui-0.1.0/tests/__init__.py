"""Test suite for the Snek game."""
