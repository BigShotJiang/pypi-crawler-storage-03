from .impl import my_function  # noqa: F401
