# noinspection SpellCheckingInspection
"""
* Kemono API version:
``1.0.0``

* current App commit hash:
``7ee4a7b18ee92a442c13950c05dc8236cfb14a60``
"""
from .base import *
