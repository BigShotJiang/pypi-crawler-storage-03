__title__ = "KToolBox"
# noinspection SpellCheckingInspection
__description__ = "A useful CLI tool for downloading posts in Kemono.cr / .su / .party"
__version__ = "v0.20.0"
