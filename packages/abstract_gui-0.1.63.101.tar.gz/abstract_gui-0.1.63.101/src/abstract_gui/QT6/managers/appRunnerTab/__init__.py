from .main import appRunnerTab
from ..startConsole import startConsole
def startAppRunnerConsole():
    startConsole(appRunnerTab)
