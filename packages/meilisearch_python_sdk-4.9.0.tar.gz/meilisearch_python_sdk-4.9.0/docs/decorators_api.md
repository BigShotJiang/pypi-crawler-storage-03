## Decorator Usage

Various decorators are provided that can be used to help with the Meilisearch interaction.

::: meilisearch_python_sdk.decorators
