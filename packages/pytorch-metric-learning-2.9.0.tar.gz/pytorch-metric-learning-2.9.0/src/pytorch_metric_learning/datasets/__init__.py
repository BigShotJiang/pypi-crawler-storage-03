from .base_dataset import BaseDataset
from .cars196 import Cars196
from .cub import CUB
from .inaturalist2018 import INaturalist2018
from .sop import StanfordOnlineProducts
