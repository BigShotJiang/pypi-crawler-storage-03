"""

PRC API raw response data types.

"""
