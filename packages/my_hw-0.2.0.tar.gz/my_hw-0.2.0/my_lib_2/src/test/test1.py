print(f"Path: {__file__}")
