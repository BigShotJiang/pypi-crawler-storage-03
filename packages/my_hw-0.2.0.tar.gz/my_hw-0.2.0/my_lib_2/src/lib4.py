# Content:
#   def lib4_func():


def lib4_func():
    """_summary_."""
    print("lib4_func")


def lib40_func():
    """_summary_."""
    print("lib40_func")
