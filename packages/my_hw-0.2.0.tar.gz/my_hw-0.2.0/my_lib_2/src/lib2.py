# Content:
#   def lib2_func():


def lib2_func():
    """_summary_."""
    print("lib2_func")


def lib20_func():
    """_summary_."""
    print("lib20_func")
