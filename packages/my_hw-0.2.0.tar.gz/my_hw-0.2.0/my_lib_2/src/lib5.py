# Content:
#   def lib5_func():


def lib5_func():
    """_summary_."""
    print("lib5_func")


def lib50_func():
    """_summary_."""
    print("lib50_func")
