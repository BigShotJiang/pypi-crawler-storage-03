# Content:
#   def lib3_func():


def lib3_func():
    """_summary_."""
    print("lib3_func")


def lib30_func():
    """_summary_."""
    print("lib30_func")
