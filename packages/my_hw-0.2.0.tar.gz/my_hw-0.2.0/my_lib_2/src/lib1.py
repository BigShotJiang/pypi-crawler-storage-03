# Content:
#   def lib1_func():


def lib1_func():
    """_summary_."""
    print("lib1_func")


def lib10_func():
    """_summary_."""
    print("lib10_func")


def lib100_func():
    """_summary_."""
    print("lib10_func")
