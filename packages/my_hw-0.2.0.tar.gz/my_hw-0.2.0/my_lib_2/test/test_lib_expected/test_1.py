import os


def test_1():
    assert os.path.exists("lib1.py")
