import os


def test_4():
    assert os.path.exists("lib4.py")
