import os


def test_5():
    assert os.path.exists("lib5.py")
