import os


def test_2():
    assert os.path.exists("lib2.py")
