import os


def test_0():
    assert os.path.exists("lib0.py")
