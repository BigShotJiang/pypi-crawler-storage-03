import os


def test_3():
    assert os.path.exists("lib3.py")
