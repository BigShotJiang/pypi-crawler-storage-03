import os


def test_6():
    assert os.path.exists("lib6.py")
