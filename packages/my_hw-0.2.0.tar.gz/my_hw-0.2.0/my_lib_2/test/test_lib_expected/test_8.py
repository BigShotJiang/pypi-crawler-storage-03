import os


def test_8():
    assert os.path.exists("lib8.txt")
