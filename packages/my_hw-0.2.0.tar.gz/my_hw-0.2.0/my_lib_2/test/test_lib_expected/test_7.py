import os


def test_7():
    assert os.path.exists("lib7.py")
