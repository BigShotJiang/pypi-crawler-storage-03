# Contributing to my_hm

Hi, thank you for taking the time to improve this Python or API!
