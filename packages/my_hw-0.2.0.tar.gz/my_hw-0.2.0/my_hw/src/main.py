def hello_world():
    """Print a hello world message from a python package."""
    print("¡Hello, world from a python package!")
