## Setting

---
**Prerequisites**

Before using `auto-go-home`, ensure the following:

- **Python**: `auto-go-home` requires Python 3.13. Check your Python version by running.

```shell
  python --version
```

**Installing libraries**
```shell
  pip install -r requirements.txt
```

## To run an application

---
```shell
  python main.py
```

## Contacts

---
Email: sonmingi135@gmail.com