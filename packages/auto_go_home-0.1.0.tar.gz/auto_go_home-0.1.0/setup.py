from setuptools import setup, find_packages

setup(
    name='auto-go-home',
    version='0.1.0',
    description='Automatic work out automation tool by handmk',
    author= 'handmk',
    author_email='sonmingi135@gmail.com',
    url='',
    install_requires=['DateTime', 'python-dotenv', 'schedule', 'webdriver-manager', 'selenium'],
    packages=find_packages(exclude=[]),
    keywords=['workout', 'auto'],
    python_requires='>=3.13',
    package_data={},
    zip_safe=False,
    classifiers=[]
)