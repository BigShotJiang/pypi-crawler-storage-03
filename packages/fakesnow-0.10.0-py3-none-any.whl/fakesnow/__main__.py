if __name__ == "__main__":
    import fakesnow.cli

    fakesnow.cli.main()
