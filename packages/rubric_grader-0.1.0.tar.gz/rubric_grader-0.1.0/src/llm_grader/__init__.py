"""
llm_grader package: grading code submissions with LLM-based rubrics and code evaluation.
"""

__version__ = "0.1.0"