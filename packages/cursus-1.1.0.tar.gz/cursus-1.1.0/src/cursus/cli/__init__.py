"""
Command-line interfaces for Cursus modules.
"""
