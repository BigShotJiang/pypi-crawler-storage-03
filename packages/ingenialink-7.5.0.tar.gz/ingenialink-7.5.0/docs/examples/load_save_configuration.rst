Load and Save configuration Examples
====================================

Load firmware through CANopen Example
----------------------------------------

.. literalinclude:: ../../examples/canopen/can_load_save_config.py

Load firmware through Ethernet Example
----------------------------------------

.. literalinclude:: ../../examples/ethernet/eth_load_save_config.py