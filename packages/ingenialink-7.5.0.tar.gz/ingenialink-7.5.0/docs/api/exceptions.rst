==========
Exceptions
==========

.. automodule:: ingenialink.exceptions
    :members:
    :member-order: groupwise
