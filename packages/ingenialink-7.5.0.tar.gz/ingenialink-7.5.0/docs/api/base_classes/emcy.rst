====
EMCY
====

.. automodule:: ingenialink.emcy
    :members:
    :member-order: groupwise
