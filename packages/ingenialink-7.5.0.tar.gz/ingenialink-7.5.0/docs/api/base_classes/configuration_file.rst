==================
Configuration File
==================

.. automodule:: ingenialink.configuration_file
    :members:
    :member-order: groupwise
