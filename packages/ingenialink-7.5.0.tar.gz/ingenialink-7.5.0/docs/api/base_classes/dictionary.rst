==========
Dictionary
==========

.. automodule:: ingenialink.dictionary
    :members:
    :member-order: groupwise
