=======
Network
=======

.. autoclass:: ingenialink.canopen.network.CanBaudrate
    :members:

.. autoclass:: ingenialink.canopen.network.CanDevice
    :members:

.. autoclass:: ingenialink.canopen.network.CanopenNetwork
    :members:
    :inherited-members:
    :member-order: groupwise

.. autoclass:: ingenialink.canopen.network.NetStatusListener
    :members:
    :member-order: groupwise
