==========
Dictionary
==========

.. automodule:: ingenialink.ethercat.dictionary
    :members:
    :inherited-members:
    :member-order: groupwise
