==========
Dictionary
==========

.. automodule:: ingenialink.ethernet.dictionary
    :members:
    :inherited-members:
    :member-order: groupwise
