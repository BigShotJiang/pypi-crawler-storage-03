=========
Registers
=========

.. automodule:: ingenialink.ethernet.register
    :members:
    :inherited-members:
    :member-order: groupwise
