from ingenialink.canopen.register import CanopenRegister


class EthercatRegister(CanopenRegister):
    """Class to represent an EtherCAT register."""
