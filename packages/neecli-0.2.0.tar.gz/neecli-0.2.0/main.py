from cli import cli

def main():
    """Main entry point for the NeeCLI package."""
    cli()

if __name__ == "__main__":
    main()
