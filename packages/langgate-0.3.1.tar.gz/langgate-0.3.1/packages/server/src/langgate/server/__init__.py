from langgate.server.main import app

__all__ = ["app"]
