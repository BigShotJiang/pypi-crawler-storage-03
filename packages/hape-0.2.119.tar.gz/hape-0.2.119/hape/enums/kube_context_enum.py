import enum

class KubeContextEnum(enum.Enum):
    dev = "dev"
    test = "test"
    prod = "prod"
