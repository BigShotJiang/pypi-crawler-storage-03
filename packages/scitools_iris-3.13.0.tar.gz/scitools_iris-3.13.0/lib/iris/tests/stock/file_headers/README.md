A directory of text files containing file header strings that include
placeholders - designed to be interpreted by 
[Python's string.Template](https://docs.python.org/3/library/string.html#string.Template).

* `.cdl` files: used by [`tests.stock.netcdf`](../netcdf.py) to create
synthetic NetCDF files of the required dimensions.
