def hello() -> str:
    return "Hello from pytest-gitscope!"
