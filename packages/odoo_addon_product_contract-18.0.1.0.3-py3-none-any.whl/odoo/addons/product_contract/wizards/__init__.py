from . import product_contract_configurator
