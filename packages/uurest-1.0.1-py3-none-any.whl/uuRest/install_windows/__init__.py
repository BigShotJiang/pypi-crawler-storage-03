from __future__ import absolute_import

from .install_windows import install_windows

__all__ = (
    "install_windows"
)


