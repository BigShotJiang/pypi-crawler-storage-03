"""Allow execution of obsidian-tmdb-cover as a module."""

from .cli import main

if __name__ == "__main__":
    main()
