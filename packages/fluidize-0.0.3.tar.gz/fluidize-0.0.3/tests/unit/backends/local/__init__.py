"""Local adapter unit tests."""
