"""Manager unit tests."""
