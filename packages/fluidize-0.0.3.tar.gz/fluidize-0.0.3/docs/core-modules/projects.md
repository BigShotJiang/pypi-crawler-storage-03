# Projects Module

## Registry
::: fluidize.managers.registry.RegistryManager
    options:
      show_source: false
      heading_level: 3
      show_root_heading: true

## Project
::: fluidize.managers.project.ProjectManager
    options:
      show_source: false
      heading_level: 3
      show_root_heading: true
