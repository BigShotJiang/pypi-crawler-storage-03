# Node Module

::: fluidize.managers.node.NodeManager
    options:
      show_source: false
      heading_level: 3
      show_root_heading: true
