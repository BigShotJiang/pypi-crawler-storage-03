"""Graph module for managing project graphs."""

from fluidize.core.modules.graph.processor import GraphProcessor

__all__ = ["GraphProcessor"]
