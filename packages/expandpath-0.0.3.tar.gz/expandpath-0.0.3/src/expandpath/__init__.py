from expandpath.core import *
from expandpath.tests import *

if __name__ == "__main__":
    main()
