This module provides online bank statements from GoCardless Bank Account
Data, which provides a free API for connecting and getting transactions
for bank accounts.
