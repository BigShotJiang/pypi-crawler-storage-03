On the product form view, go to the "General Information" tab, and put
the companies in which you want to use that product. If none is
selected, the product will be visible in all of them. The default value
is the current one.
