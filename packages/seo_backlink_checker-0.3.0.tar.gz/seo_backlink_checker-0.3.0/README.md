# SEO Backlink Checker

A simple Python package + CLI to check backlinks on web pages.

## Install (local)

```bash
pip install .
```

## Usage (Python)

```python
from seo_backlink_checker import check_backlink

result = check_backlink("https://example.com", "example.com")
print(result)
```

## Usage (CLI)

### Single URL

```bash
backlink-check example.com https://example.com
```

### Multiple URLs

```bash
backlink-check example.com https://site1.com https://site2.com
```

### From file

```bash
backlink-check example.com urls.txt --output results.json
```
