# Optional storage backends (SQLite, Sheets, etc.)
