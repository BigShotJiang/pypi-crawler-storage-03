from bacolonyzer.commands import entrypoint

entrypoint.run()
