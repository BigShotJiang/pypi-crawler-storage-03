"""Tests for session management components."""
