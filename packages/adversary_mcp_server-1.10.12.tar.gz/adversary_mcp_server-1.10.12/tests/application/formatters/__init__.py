"""Tests for application formatters."""
