from stac_processor_cli.app import app

if __name__ == "__main__":
    app()
