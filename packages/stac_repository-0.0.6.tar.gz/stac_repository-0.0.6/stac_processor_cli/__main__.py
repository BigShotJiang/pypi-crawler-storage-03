from stac_processor_cli.app import app

app()
