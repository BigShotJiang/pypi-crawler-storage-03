from stac_repository_cli.app import app

app()
