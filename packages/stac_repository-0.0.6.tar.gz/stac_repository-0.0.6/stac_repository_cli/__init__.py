from stac_repository_cli.app import app

if __name__ == "__main__":
    app()
