from .git_stac_repository import GitStacRepository as StacRepository

__version__ = "0.0.1"
