__version__ = "0.0.6"
__name_public__ = "stac-repository"
