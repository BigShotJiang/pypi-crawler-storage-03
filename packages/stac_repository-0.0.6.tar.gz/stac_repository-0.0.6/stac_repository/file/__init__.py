from .file_stac_repository import FileStacRepository as StacRepository

__version__ = "0.0.1"
