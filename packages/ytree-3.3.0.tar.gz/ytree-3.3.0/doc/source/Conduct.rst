.. _conduct:

Community Code of Conduct
=========================

ytree is a project by members of the `yt community
<http://yt-project.org/community.html>`_.  As such, we stand by the
`yt Community Code of Conduct
<http://yt-project.org/community.html#codeofconduct>`_.

Below is the ytree version of this code.

.. include:: ../../CODE_OF_CONDUCT.md