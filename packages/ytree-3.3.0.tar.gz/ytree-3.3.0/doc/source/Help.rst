Help
====

If you encounter problems, we want to help and there are lots
of places to get help. As an extension of `the yt project
<https://yt-project.org/>`_, we are members of the yt community.
There is a dedicated #ytree channel on the `yt project Slack
<https://yt-project.org/slack.html>`__ and questions can also
be posted to the `yt users mailing list
<https://mail.python.org/mailman3/lists/yt-users.python.org>`__.
Bugs and feature requests can also be posted on the `ytree issues
page <https://github.com/ytree-project/ytree/issues>`__.

Please note, issues or queries posted during the academic year
(roughly September to June) may take quite a bit longer to see a
response. Hang in there; we do care!

See you out there!
