# Configuration management module
