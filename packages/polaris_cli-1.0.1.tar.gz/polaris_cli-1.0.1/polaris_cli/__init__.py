"""
Polaris CLI - A beautiful cloud resource management command-line interface.
"""

__version__ = "1.0.1"
__author__ = "Polaris Team"
__email__ = "team@polaris.dev"
