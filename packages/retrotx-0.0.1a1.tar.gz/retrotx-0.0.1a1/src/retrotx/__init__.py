"""RetroTx - A Python package for RetroTx"""

__version__ = "0.0.1a1"
__author__ = "RetroTx Team"
__email__ = "retrotx@retrotx.org"


def hello():
    """A simple hello function"""
    return "Hello from RetroTx!"
