from .takmessage_pb2 import TakMessage
from .cotevent_pb2 import CotEvent
