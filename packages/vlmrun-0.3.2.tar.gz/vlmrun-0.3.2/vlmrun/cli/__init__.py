"""CLI package for vlmrun."""
