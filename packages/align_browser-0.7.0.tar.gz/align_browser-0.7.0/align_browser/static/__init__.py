# Static assets package for align-browser CLI tool
