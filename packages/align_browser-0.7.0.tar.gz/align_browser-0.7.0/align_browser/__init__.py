"""Align Browser - Static web application for visualizing align-system experiment results."""

__version__ = "0.7.0"
