"""Simple auto instrumentation for AI libraries."""

from .registry import auto_instrument

__all__ = ["auto_instrument"]
