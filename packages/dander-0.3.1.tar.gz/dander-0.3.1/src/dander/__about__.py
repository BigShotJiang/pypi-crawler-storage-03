# SPDX-FileCopyrightText: 2024-present Daniel Lawson <daniel.lawson@rmit.edu.au>
#
# SPDX-License-Identifier: MIT
__version__ = "0.3.1"
