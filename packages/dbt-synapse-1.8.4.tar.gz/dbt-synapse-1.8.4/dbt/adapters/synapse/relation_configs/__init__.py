from dbt.adapters.synapse.relation_configs.policies import (
    SynapseIncludePolicy,
    SynapseQuotePolicy,
    SynapseRelationType,
)
