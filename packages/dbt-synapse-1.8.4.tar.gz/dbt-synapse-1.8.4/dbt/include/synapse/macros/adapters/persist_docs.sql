{# Unfortunately adding docs via extended properties is not supported in Synapse only in SQLServer
  https://github.com/dbt-msft/dbt-sqlserver/issues/134
  https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-addextendedproperty-transact-sql?view=sql-server-ver16
 #}
