"""Cookbook for DOLs."""

from dol_cookbook.util import pkg_data_path, misc_files_path
