
# dol_cookbook
recipes for dol tools


To install:	```pip install dol_cookbook```
