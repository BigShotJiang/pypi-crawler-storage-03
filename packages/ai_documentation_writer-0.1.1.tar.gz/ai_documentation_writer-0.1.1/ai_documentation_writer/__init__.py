"""AI Documentation Writer - Automatically generate documentation for codebases."""

__version__ = "0.1.1"

__all__ = ["__version__"]
