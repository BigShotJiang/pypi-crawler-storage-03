artifact_manager_ui
===================

.. automodule:: fabrictestbed_extensions.ui.artifact_manager_ui
   :members:

.. autoclass:: fabrictestbed_extensions.ui.artifact_manager_ui.ArtifactManagerUI
   :members:
   :no-index:
   :special-members: __str__
