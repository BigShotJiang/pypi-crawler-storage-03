Welcome to xtgeoviz' documentation
==================================

.. toctree::
   :maxdepth: 2

   readme
   examples
   contributing
   apiref/modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
