// Author: Dylan Jones
// Date:   2025-05-01

fn main() {
    pyo3_build_config::use_pyo3_cfgs();
}
