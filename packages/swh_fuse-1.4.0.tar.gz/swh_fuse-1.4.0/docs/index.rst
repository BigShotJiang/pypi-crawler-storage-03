.. _swh-fuse:

.. include:: README.rst


.. toctree::
   :maxdepth: 1
   :caption: Overview

   Tutorial <tutorial>
   configuration
   parallelization
   Design notes <design>
   cli

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
