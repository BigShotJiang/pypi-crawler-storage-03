.. _swh-fuse-cli:

Command-line interface
======================

.. click:: swh.fuse.cli:fuse
  :prog: swh fs
  :nested: full
