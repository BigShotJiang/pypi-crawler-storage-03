"""
Wise Mise MCP Server

An intelligent MCP server for wise mise task management and organization.
"""

from .server import app

__version__ = "0.1.0"
__all__ = ["app"]
