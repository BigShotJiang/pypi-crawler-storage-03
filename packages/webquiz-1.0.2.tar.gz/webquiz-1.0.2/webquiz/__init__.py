"""AI Testing System - A modern web-based testing platform."""

__version__ = "1.0.1"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "A modern web-based testing system built with Python and aiohttp"