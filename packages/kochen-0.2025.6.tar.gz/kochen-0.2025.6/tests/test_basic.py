class TestMathUtils:

    def test_cubicinterp(self):

        pass