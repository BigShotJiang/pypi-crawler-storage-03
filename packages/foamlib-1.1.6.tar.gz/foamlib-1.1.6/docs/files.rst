File manipulation
=================

.. autoclass:: foamlib.FoamFile
   :members:
   :show-inheritance:

.. autoclass:: foamlib.FoamFieldFile
   :members:
   :show-inheritance:
