from .utils import Rubric


__all__ = ["Rubric"]
