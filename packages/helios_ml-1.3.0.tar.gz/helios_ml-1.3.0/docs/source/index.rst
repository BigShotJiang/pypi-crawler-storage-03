.. Helios documentation master file, created by
   sphinx-quickstart on Thu Jun  6 15:38:41 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Helios's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   getting-started
   tutorial
   quick-ref
   plugins


.. include:: ../../README.rst
   :start-after: .. what_is_helios
   :end-before: .. main_features

.. include:: ../../README.rst
   :start-after: .. main_features
   :end-before: .. installation
