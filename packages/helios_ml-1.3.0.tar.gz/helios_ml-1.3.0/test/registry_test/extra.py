def extra_func() -> str:
    return "extra_func"
