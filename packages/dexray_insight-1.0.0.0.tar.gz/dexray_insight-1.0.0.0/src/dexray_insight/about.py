#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = "Daniel Baier, Jan-Niclas Hilgert, Jannis Finn Borg-Olivier"
__version__ = "1.0.0.0"