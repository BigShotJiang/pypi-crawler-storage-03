# sage_setup: distribution = sagemath-maxima
# delvewheel: patch

from sage.all__sagemath_categories import *
