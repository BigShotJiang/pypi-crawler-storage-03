# Guia para usar mi libreria
## Existen 4 funciones 
## srmd
donde se encuentra la multipliacion division como suma y resta de dos numeros.
se requiere 2 numeros a,b que se multiplican, se dividen, se restan y se suman con md dividir 

## elt
libreria donde se asignando la instacion de motores primeramente la cantidad segido de de la potencia, numero de polos,
y los factores de la instalacion podesmos calcular la demanda de consumo de energia del sistema, para poder asi asignar
un transformador adecuado para todo el sistema, segido de ello podemos realizar el dimencionamiento de los cables de
alimentacion del transformador al tablero de control, segido de ellos seleecionar el cable de alimentacion de cada motor
