from .srmd import suma
from .srmd import resta
from .srmd import multiplicacion
from .srmd import division
from .elt import (
    demanda_motor, demanda_total, corriente_transformador, factor_temp_principal,
    factor_instalacion, corriente_corregida_principal, seleccionar_conductor_principal,
    corriente_motor, factor_temp_motor, corriente_corregida_motor, seleccionar_conductor_motor
)