# appsec-lab-alpha

This is a package owned by Schibsted Appication Security Team.

**Dependency Confusion Prevention.**