"""
SuperGemini Data Module
Static configuration and data files
"""