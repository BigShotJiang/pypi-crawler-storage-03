# syftr

Main syftr logic should go here