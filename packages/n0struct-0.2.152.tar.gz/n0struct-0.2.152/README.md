# n0struct
list/dict extensions allow to 
* work (find/get/set/update) with tree-like structures, generated for example by json.loads(..), using xpath approach 
* direct/wise compare lists/dictionaries/tree-like structures + exclude sub-nodes from comparison
* transform on the fly values in attributes during comparing
* .to_json(): convert tree-like structures into string buffer for saving into JSON file
* .to_xml(): convert tree-like structures into string buffer for saving into XML file
* .to_xpath: convert tree-like structures into string buffer for saving into XPATH file
