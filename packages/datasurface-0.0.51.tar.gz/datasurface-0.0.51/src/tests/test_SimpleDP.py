"""
// Copyright (c) William Newport
// SPDX-License-Identifier: BUSL-1.1
"""

import unittest


class TestSimpleDataPlatform(unittest.TestCase):
    def test_simple_data_platform(self):
        self.assertEqual(1, 1)

    def createEcosystem(self):
        pass
