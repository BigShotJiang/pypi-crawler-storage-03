# This file allows to run the app from windows command line

import songfinder

if __name__ == "__main__":
    songfinder.song_finder_main()
