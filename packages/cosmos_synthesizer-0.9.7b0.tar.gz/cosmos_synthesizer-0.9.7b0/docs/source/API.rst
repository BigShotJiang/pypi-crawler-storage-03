API Reference
=============

.. rubric:: Modules

.. :toctree: generated

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   synthesizer
