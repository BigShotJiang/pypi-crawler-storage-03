Author:

- `Christopher Lovell <https://github.com/christopherlovell>`_
- `Will Roper <https://github.com/WillJRoper>`_
- `Aswin Vijayan <https://github.com/aswinpvijayan>`_
- `Stephen Wilkins <https://github.com/stephenmwilkins/>`_

