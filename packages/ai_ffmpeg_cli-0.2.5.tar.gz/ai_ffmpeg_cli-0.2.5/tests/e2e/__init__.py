"""End-to-end tests for ai-ffmpeg-cli.

This package contains end-to-end tests that verify complete workflows.
E2E tests focus on testing the entire application from user input to output.
"""
