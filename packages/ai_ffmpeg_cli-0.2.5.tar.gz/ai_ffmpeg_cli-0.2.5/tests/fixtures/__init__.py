"""Test fixtures for ai-ffmpeg-cli.

This package contains shared test fixtures and utilities.
Fixtures provide reusable test data and setup for multiple test modules.
"""
