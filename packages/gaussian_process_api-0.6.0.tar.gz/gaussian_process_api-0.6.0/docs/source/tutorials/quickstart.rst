.. _quickstart:

Quickstart
==========

Before proceeding, you will want to install the package following the :ref:`install` guide.

.. todo:: add some very short code snippets
