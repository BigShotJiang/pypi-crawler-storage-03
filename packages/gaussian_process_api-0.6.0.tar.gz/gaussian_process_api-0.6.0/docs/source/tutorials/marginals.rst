Marginal distributions
======================

.. todo:: copy from marginals Jupyter notebook
