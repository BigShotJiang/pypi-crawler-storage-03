Getting Started
===============

Requirements
~~~~~~~~~~~~

.. include:: ../README.rst
    :start-after: start requirements
    :end-before: end requirements

Quickstart
~~~~~~~~~~

.. include:: ../README.rst
    :start-after: start quickstart
    :end-before: end quickstart
