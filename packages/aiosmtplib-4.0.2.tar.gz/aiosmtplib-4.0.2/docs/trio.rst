Trio Support
============

aiosmtplib does not support the (excellent) `Trio`_ library. For Trio support,
try the concrete implementation provided by the `smtpproto`_ library.

.. _Trio: https://github.com/python-trio/trio
.. _smtpproto: https://github.com/agronholm/smtpproto
