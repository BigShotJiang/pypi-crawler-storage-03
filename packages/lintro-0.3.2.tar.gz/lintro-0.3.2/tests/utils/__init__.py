"""Utility tests for lintro."""
