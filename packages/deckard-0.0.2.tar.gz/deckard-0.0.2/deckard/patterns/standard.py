EMAIL = r"(?P<email>\w+@\w+\.\w+)"
