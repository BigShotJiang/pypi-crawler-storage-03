algo_docs = algo_docs = (
    "https://github.com/kamangir/bluer-algo/blob/main/bluer_algo/docs"
)

assets = "https://github.com/kamangir/assets/raw/main"

assets2 = "https://github.com/kamangir/assets2/raw/main"

assets2_bluer_eagle = f"{assets2}/bluer-eagle"
assets2_bluer_fire = f"{assets2}/bluer-fire"
assets2_bluer_robin = f"{assets2}/bluer-robin"
assets2_bluer_swallow = f"{assets2}/bluer-swallow"
assets2_bluer_sparrow = f"{assets2}/bluer-sparrow"
