"""Invalid Command API exception.."""


class InvalidCommandException(Exception):
    """Raised if the supported command is invalid."""
