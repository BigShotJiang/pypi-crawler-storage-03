"""Invalid Update exception.."""


class UpdateException(Exception):
    """Raised if the requested update is invalid."""
