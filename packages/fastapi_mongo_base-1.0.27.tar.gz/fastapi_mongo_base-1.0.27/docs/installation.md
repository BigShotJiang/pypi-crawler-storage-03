# Installation

Instructions for installing fastapi-mongo-base.

```bash
pip install fastapi-mongo-base
```

For development:
```bash
git clone https://github.com/mahdikiani/fastapi-mongo-base-app.git
cd fastapi-mongo-base
pip install -e .
``` 