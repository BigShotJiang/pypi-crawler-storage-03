# Copyright 2023 Tecnativa - Pilar Vargas
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
{
    "name": "Loyalty Partner Applicability",
    "summary": "Enables the definition of a customer filter for promotion rules that will "
    "only be applied to customers who meet the specified conditions in the filter.",
    "version": "16.0.4.0.0",
    "category": "Sale",
    "website": "https://github.com/OCA/sale-promotion",
    "author": "Tecnativa,ACSONE SA/NV,Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "depends": ["loyalty"],
    "data": ["views/loyalty_program_view_form.xml"],
}
