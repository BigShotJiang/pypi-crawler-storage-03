# runners/converters/__init__.py
# Hier können mehrere Converter-Module liegen.
