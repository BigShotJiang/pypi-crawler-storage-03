metatensor-core
===============

This package contains the Python bindings to the core C API of metatensor. Most
users will want to use the ``metatensor`` meta package instead, which also
includes function to operate on the data.
