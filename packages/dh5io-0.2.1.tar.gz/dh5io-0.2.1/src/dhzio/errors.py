class DHZError(Exception):
    pass


class DHZWarning(Warning):
    pass
