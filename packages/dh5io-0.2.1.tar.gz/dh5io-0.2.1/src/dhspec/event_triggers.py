import numpy as np

EV_DATASET_NAME = "EV02"
EV_DATASET_DTYPE = np.dtype([("time", np.int64), ("event", np.int32)])
