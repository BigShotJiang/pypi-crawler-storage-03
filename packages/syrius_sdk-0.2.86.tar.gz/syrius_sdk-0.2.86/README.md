Syrius SDK for Python {version}
