"""
ImageScraper - A simple image scraper for Google, Bing, and Yahoo.
Made with ❤️ by MaviMods
"""

__version__ = "0.1.2"
