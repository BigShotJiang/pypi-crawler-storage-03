# SPDX-FileCopyrightText: 2025-present husheng <hs3434.work@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1004"
