"""An assortment of tests that can be run to check the health of the bioregistry."""
