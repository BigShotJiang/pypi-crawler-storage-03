2025-06-20 Version: 3.6.5
- Update API CreateTask: add request parameters body.transcription.languageHints.


2025-06-11 Version: 3.6.4
- Update API GetTaskResult: add response parameters Body.data.asrResult.$.roleName.


2025-05-27 Version: 3.6.3
- Update API CreateTask: add request parameters body.callBackUrl.


2025-05-06 Version: 3.6.2
- Update API CreateTask: add request parameters body.transcription.roleIdentification.


2025-04-16 Version: 3.6.1
- Generated python 2024-06-03 for ContactCenterAI.

2025-04-16 Version: 3.6.0
- Support API AnalyzeAudioSync.
- Update API AnalyzeConversation: add request parameters body.responseFormatType.
- Update API AnalyzeImage: add request parameters body.responseFormatType.
- Update API CreateTask: add request parameters body.responseFormatType.
- Update API RunCompletion: add request parameters body.responseFormatType.
- Update API RunCompletionMessage: add request parameters body.responseFormatType.


2025-04-01 Version: 3.5.2
- Update API CreateTask: add request parameters body.categoryTags.
- Update API CreateTask: add request parameters body.variables.
- Update API RunCompletion: add request parameters body.variables.


2025-03-26 Version: 3.5.1
- Generated python 2024-06-03 for ContactCenterAI.

2025-02-25 Version: 3.5.0
- Support API CreateVocab.
- Support API DeleteVocab.
- Support API GetVocab.
- Support API ListVocab.
- Support API UpdateVocab.
- Update API CreateTask: update param body.


2025-02-20 Version: 3.4.0
- Support API CreateVocab.
- Support API DeleteVocab.
- Support API GetVocab.
- Support API ListVocab.
- Support API UpdateVocab.
- Update API CreateTask: update param body.


2025-02-20 Version: 3.3.5
- Update API CreateTask: update param body.


2025-01-16 Version: 3.3.4
- Update API CreateTask: update param body.
- Update API GetTaskResult: update param requiredFieldList.
- Update API GetTaskResult: update response param.


2024-12-20 Version: 3.3.3
- Update API AnalyzeConversation: update param body.


2024-12-05 Version: 3.3.2
- Generated python 2024-06-03 for ContactCenterAI.

2024-12-05 Version: 3.3.1
- Update API AnalyzeConversation: update param body.
- Update API GetTaskResult: add param requiredFieldList.
- Update API GetTaskResult: update response param.


2024-11-26 Version: 3.3.0
- Support API AnalyzeImage.
- Update API AnalyzeConversation: update param body.
- Update API AnalyzeConversation: update response param.
- Update API RunCompletion: update response param.
- Update API RunCompletionMessage: update response param.


2024-10-11 Version: 3.2.0
- Support API CreateTask.


2024-09-24 Version: 3.1.1
- Update API AnalyzeConversation: update param body.


2024-09-06 Version: 3.1.0
- Support API CreateConversationAnalysisTask.
- Support API GetTaskResult.
- Update API AnalyzeConversation: update param regionId.
- Update API AnalyzeConversation: update param body.
- Update API RunCompletion: update param RegionId.
- Update API RunCompletion: update param body.
- Update API RunCompletionMessage: update param RegionId.
- Update API RunCompletionMessage: update param body.


2024-08-21 Version: 3.0.1
- Generated python 2024-06-03 for ContactCenterAI.

2024-08-19 Version: 3.0.0
- Update API AnalyzeConversation: update param body.


2024-08-16 Version: 2.1.0
- Support API AnalyzeConversation.


2024-07-02 Version: 2.0.0
- Update API RunCompletion: update param RegionId.
- Update API RunCompletion: update param body.
- Update API RunCompletionMessage: update param RegionId.
- Update API RunCompletionMessage: update param body.


2024-06-14 Version: 1.0.0
- Generated python 2024-06-03 for ContactCenterAI.

