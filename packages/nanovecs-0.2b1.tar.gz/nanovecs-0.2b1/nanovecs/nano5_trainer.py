import numpy as np
from tqdm import trange

class Trainer:
    def __init__(self, embeddings, vocab, lr=0.05, window=2):
        self.emb = embeddings
        self.vocab = vocab
        self.lr = lr
        self.window = window

    def train(self, tokens, epochs=10, batch_size=32):
        indices = [self.vocab.word2idx[t] for t in tokens if t in self.vocab.word2idx]
        for epoch in trange(epochs, desc="🧠 Entrenando embeddings"):
            total_loss = 0
            for i, center in enumerate(indices):
                context_ids = indices[max(0, i-self.window): i] + indices[i+1: i+self.window+1]
                for context in context_ids:
                    v_c, v_o = self.emb.vectors[center], self.emb.vectors[context]
                    grad = self.lr * (v_c - v_o)
                    self.emb.vectors[center] -= grad
                    self.emb.vectors[context] += grad
                    total_loss += np.sum(grad ** 2)
            if total_loss < 1e-6:
                break
