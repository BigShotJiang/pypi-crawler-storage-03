import os, json, csv
from tqdm import tqdm

class CorpusLoader:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def load_folder(self, folder):
        corpus = []
        files = [f for f in os.listdir(folder) if f.endswith(".txt")]
        for fname in tqdm(files, desc="📂 Cargando corpus"):
            with open(os.path.join(folder, fname), "r", encoding="utf-8") as f:
                corpus.extend(self.tokenizer.tokenize(f.read()))
        return corpus

    def load_csv(self, path, column=0):
        corpus = []
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in tqdm(reader, desc="📂 Leyendo CSV"):
                if row:
                    corpus.extend(self.tokenizer.tokenize(row[column]))
        return corpus

    def load_jsonl(self, path, key):
        corpus = []
        with open(path, "r", encoding="utf-8") as f:
            for line in tqdm(f, desc="📂 Leyendo JSONL"):
                data = json.loads(line)
                if key in data:
                    corpus.extend(self.tokenizer.tokenize(data[key]))
        return corpus
