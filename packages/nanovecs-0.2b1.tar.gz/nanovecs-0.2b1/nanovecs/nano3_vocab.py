class Vocab:
    def __init__(self, tokens):
        self.word2idx = {}
        self.idx2word = {}

        # Recorremos tokens en orden sin sets
        for token in tokens:
            if token not in self.word2idx:
                idx = len(self.word2idx)
                self.word2idx[token] = idx
                self.idx2word[idx] = token

    def __len__(self):
        return len(self.word2idx)

    def encode(self, token):
        return self.word2idx.get(token, None)

    def decode(self, idx):
        return self.idx2word.get(idx, None)
