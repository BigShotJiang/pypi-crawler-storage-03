import argparse
from .nano1_tokenizer import Tokenizer
from .nano2_corpus import CorpusLoader
from .nano3_vocab import Vocab
from .nano4_embeddings import Embeddings
from .nano5_trainer import Trainer
from .nano6_search import Search

def main():
    parser = argparse.ArgumentParser(description="nanovecs CLI")
    parser.add_argument("--corpus", type=str, default="examples/")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--dim", type=int, default=50)
    parser.add_argument("--topn", type=int, default=5)
    parser.add_argument("--query", type=str, default="gato")
    args = parser.parse_args()

    tok = Tokenizer()
    loader = CorpusLoader(tok)
    tokens = loader.load_folder(args.corpus)

    vocab = Vocab().build(tokens)
    emb = Embeddings(len(vocab.word2idx), dim=args.dim, normalize=True)

    trainer = Trainer(emb, vocab)
    trainer.train(tokens, epochs=args.epochs)

    search = Search(emb, vocab)
    results = search.most_similar(args.query, topn=args.topn)
    print(f"🔎 Palabras similares a '{args.query}':")
    for w, s in results:
        print(f"   {w} (sim={s:.3f})")

if __name__ == "__main__":
    main()
