import numpy as np

class Search:
    def __init__(self, embeddings, vocab):
        self.emb = embeddings
        self.vocab = vocab

    def most_similar(self, word, topn=5):
        if word not in self.vocab.word2idx:
            return []
        idx = self.vocab.word2idx[word]
        vec = self.emb.vectors[idx]
        sims = np.dot(self.emb.vectors, vec) / (
            np.linalg.norm(self.emb.vectors, axis=1) * np.linalg.norm(vec) + 1e-9
        )
        best = np.argsort(-sims)[:topn+1]
        return [(self.vocab.idx2word[i], float(sims[i])) for i in best if i != idx]
