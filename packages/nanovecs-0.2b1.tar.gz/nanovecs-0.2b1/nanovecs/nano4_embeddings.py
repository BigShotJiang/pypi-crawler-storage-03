import numpy as np

class Embeddings:
    def __init__(self, vocab_size, dim=50, normalize=False):
        self.vocab_size = vocab_size
        self.dim = dim
        self.vectors = np.random.uniform(-0.5, 0.5, (vocab_size, dim))
        if normalize:
            self.normalize()

    def normalize(self):
        norms = np.linalg.norm(self.vectors, axis=1, keepdims=True) + 1e-9
        self.vectors = self.vectors / norms

    def save(self, path):
        np.save(path, self.vectors)

    def load(self, path):
        self.vectors = np.load(path)
        self.vocab_size, self.dim = self.vectors.shape
        return self
