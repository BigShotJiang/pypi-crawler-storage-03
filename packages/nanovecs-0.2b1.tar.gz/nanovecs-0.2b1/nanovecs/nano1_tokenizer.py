import regex as re

class Tokenizer:
    def __init__(self, lowercase=True, stopwords=None):
        self.lowercase = lowercase
        self.stopwords = set(stopwords) if stopwords else set()

    def tokenize(self, text):
        if self.lowercase:
            text = text.lower()
        tokens = re.findall(r"\p{L}+", text)
        return [t for t in tokens if t not in self.stopwords]
