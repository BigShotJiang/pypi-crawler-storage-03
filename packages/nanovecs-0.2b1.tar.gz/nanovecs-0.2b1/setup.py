from setuptools import setup, find_packages

setup(
    name="nanovecs",
    version="0.2b1",
    description="Mini biblioteca de vectores y tokenizador en Python (beta estable, numpy+tqdm+regex)",
    author="TuNombre",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.21",
        "tqdm>=4.60",
        "regex>=2021.4.4"
    ],
    python_requires=">=3.8",
)
