from enum import Enum


class CacheKeyEnum(str, Enum):
    USER_PROFILE = "user_profile"
