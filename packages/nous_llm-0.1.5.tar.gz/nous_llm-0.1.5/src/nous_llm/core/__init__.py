"""Core functionality for the Universal LLM Wrapper."""
