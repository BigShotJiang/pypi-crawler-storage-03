# muxtools

A library for various muxing and automation tools for anything and everything fansubbing related

## How do I use this?

You might wanna check out the [guide/wiki](https://muxtools.vodes.pw/).

## Installation

Git is always the most updated one obviously but I can't guarantee that everything is in a working state.

You can also grab the latest stable ish versions from pip.

[![PyPI version](https://badge.fury.io/py/muxtools.svg)](https://badge.fury.io/py/muxtools)
