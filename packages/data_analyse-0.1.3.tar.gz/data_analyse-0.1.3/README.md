# MCP配置
```json
{
   "mcp-data-analyzer":{
       "command": "uvx",
      "args": ["mcp-data-analyzer"]
   }
}
```
