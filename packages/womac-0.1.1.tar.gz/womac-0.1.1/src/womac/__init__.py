try:
    from ._version import __version__
except Exception:
    __version__ = "0+unknown"


from .cli import main
from .config import (
    FeatureConfig,
    FeaturizeAs,
    FitMethod,
    MFSConfig,
    MFSMethod,
    MissingDataStrategy,
    ModelConfig,
    ModelResult,
    ReferencePoolConfig,
    Target,
    WomacConfig,
    WomacData,
    WomacResult,
)

# public API
from .womac import Womac

__all__ = [
    "FeatureConfig",
    "FeaturizeAs",
    "FitMethod",
    "main",
    "MFSConfig",
    "MFSMethod",
    "MissingDataStrategy",
    "ModelConfig",
    "ModelResult",
    "ReferencePoolConfig",
    "Target",
    "Womac",
    "WomacConfig",
    "WomacData",
    "WomacResult",
    "__version__",
]
