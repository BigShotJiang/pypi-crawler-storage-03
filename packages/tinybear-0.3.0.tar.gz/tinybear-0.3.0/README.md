# tinybear
Where you don't need pandas yet. Tools to work with TXT, CSV, Excel etc.

[![codecov](https://codecov.io/gh/lemontree210/tinybear/graph/badge.svg?token=S0XIMP99YU)](https://codecov.io/gh/lemontree210/tinybear)
