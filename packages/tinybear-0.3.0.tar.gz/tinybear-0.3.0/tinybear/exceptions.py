class ParsingError(Exception):
    """Base class for all parsing errors."""
