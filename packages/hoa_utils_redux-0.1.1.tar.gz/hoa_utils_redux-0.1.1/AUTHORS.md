# Credits

## Original `hoa-utils` maintainers

* [Marco Favorito](https://github.com/marcofavorito) <[marco.favorito@gmail.com](mailto:marco.favorito@gmail.com)>
* [Francesco Fuggitti](https://github.com/francescofuggitti) <[francesco.fuggitti@gmail.com](mailto:francesco.fuggitti@gmail.com)>

## Contributors

* [Luca Di Stefano](https://lucadistefano.eu)

[How to contribute](./contributing.md)
