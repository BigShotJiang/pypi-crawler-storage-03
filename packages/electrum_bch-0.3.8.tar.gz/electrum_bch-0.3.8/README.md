# electrum-bch

Packaged core under `elib.bitcoincashElectrum` for server-side usage.
