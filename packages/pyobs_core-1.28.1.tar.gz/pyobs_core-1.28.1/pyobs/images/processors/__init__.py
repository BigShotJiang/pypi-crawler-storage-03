"""
Image Processors (pyobs.images.processors)
------------------------------------------
"""
