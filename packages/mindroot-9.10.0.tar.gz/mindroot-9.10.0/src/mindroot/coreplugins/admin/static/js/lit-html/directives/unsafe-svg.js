import{directive as s}from"../directive.js";import{UnsafeHTMLDirective as e}from"./unsafe-html.js";
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class t extends e{}t.directiveName="unsafeSVG",t.resultType=2;const o=s(t);export{o as unsafeSVG};
//# sourceMappingURL=unsafe-svg.js.map
