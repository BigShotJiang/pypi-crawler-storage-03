# SPDX-FileCopyrightText: 2025-present Satya Ortiz-Gagne <satya.ortiz-gagne@mila.quebec>
#
# SPDX-License-Identifier: MIT

from pathlib import Path

CONFIG_FILE = Path(__file__).with_name("config.ini")
