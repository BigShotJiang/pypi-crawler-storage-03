# paperazzi

[![PyPI - Version](https://img.shields.io/pypi/v/paperazzi.svg)](https://pypi.org/project/paperazzi)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/paperazzi.svg)](https://pypi.org/project/paperazzi)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install paperazzi
```

## License

`paperazzi` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
