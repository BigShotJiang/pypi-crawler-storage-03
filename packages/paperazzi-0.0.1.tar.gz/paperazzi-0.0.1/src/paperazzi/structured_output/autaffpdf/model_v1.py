from paperazzi.structured_output.autaff.model_v1 import *

METADATA = Metadata(
    model_id=Path(__file__).parent.name, model_version=METADATA.model_version
)
del FIRST_MESSAGE
