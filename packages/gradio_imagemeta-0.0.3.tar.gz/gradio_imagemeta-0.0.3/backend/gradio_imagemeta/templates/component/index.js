var cd = Object.defineProperty;
var ol = (n) => {
  throw TypeError(n);
};
var fd = (n, e, t) => e in n ? cd(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t;
var _e = (n, e, t) => fd(n, typeof e != "symbol" ? e + "" : e, t), La = (n, e, t) => e.has(n) || ol("Cannot " + t);
var ti = (n, e, t) => (La(n, e, "read from private field"), t ? t.call(n) : e.get(n)), Ra = (n, e, t) => e.has(n) ? ol("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t), ll = (n, e, t, i) => (La(n, e, "write to private field"), i ? i.call(n, t) : e.set(n, t), t), dr = (n, e, t) => (La(n, e, "access private method"), t);
const hd = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ul = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
hd.reduce(
  (n, { color: e, primary: t, secondary: i }) => ({
    ...n,
    [e]: {
      primary: ul[e][t],
      secondary: ul[e][i]
    }
  }),
  {}
);
class Ur extends Error {
  constructor(e) {
    super(e), this.name = "ShareError";
  }
}
async function dd(n, e) {
  var l;
  if (window.__gradio_space__ == null)
    throw new Ur("Must be on Spaces to share.");
  let t, i, r;
  {
    let c;
    if (typeof n == "object" && n.url)
      c = n.url;
    else if (typeof n == "string")
      c = n;
    else
      throw new Error("Invalid data format for URL type");
    const u = await fetch(c);
    t = await u.blob(), i = u.headers.get("content-type") || "", r = u.headers.get("content-disposition") || "";
  }
  const a = new File([t], r, { type: i }), s = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: a,
    headers: {
      "Content-Type": a.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!s.ok) {
    if ((l = s.headers.get("content-type")) != null && l.includes("application/json")) {
      const c = await s.json();
      throw new Ur(`Upload failed: ${c.error}`);
    }
    throw new Ur("Upload failed.");
  }
  return await s.text();
}
const {
  SvelteComponent: _d,
  append_hydration: Is,
  assign: pd,
  attr: Ve,
  binding_callbacks: md,
  children: Hi,
  claim_element: Kc,
  claim_space: Qc,
  claim_svg_element: Ma,
  create_slot: gd,
  detach: jt,
  element: Jc,
  empty: cl,
  get_all_dirty_from_scope: bd,
  get_slot_changes: vd,
  get_spread_update: yd,
  init: wd,
  insert_hydration: Vi,
  listen: Dd,
  noop: Ed,
  safe_not_equal: Cd,
  set_dynamic_element_data: fl,
  set_style: ie,
  space: ef,
  svg_element: Na,
  toggle_class: Oe,
  transition_in: tf,
  transition_out: nf,
  update_slot_base: kd
} = window.__gradio__svelte__internal;
function hl(n) {
  let e, t, i, r, a;
  return {
    c() {
      e = Na("svg"), t = Na("line"), i = Na("line"), this.h();
    },
    l(s) {
      e = Ma(s, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = Hi(e);
      t = Ma(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Hi(t).forEach(jt), i = Ma(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Hi(i).forEach(jt), o.forEach(jt), this.h();
    },
    h() {
      Ve(t, "x1", "1"), Ve(t, "y1", "9"), Ve(t, "x2", "9"), Ve(t, "y2", "1"), Ve(t, "stroke", "gray"), Ve(t, "stroke-width", "0.5"), Ve(i, "x1", "5"), Ve(i, "y1", "9"), Ve(i, "x2", "9"), Ve(i, "y2", "5"), Ve(i, "stroke", "gray"), Ve(i, "stroke-width", "0.5"), Ve(e, "class", "resize-handle svelte-239wnu"), Ve(e, "xmlns", "http://www.w3.org/2000/svg"), Ve(e, "viewBox", "0 0 10 10");
    },
    m(s, o) {
      Vi(s, e, o), Is(e, t), Is(e, i), r || (a = Dd(
        e,
        "mousedown",
        /*resize*/
        n[27]
      ), r = !0);
    },
    p: Ed,
    d(s) {
      s && jt(e), r = !1, a();
    }
  };
}
function Sd(n) {
  var f;
  let e, t, i, r, a;
  const s = (
    /*#slots*/
    n[31].default
  ), o = gd(
    s,
    n,
    /*$$scope*/
    n[30],
    null
  );
  let l = (
    /*resizable*/
    n[19] && hl(n)
  ), c = [
    { "data-testid": (
      /*test_id*/
      n[11]
    ) },
    { id: (
      /*elem_id*/
      n[6]
    ) },
    {
      class: i = "block " + /*elem_classes*/
      (((f = n[7]) == null ? void 0 : f.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: r = /*rtl*/
      n[20] ? "rtl" : "ltr"
    }
  ], u = {};
  for (let h = 0; h < c.length; h += 1)
    u = pd(u, c[h]);
  return {
    c() {
      e = Jc(
        /*tag*/
        n[25]
      ), o && o.c(), t = ef(), l && l.c(), this.h();
    },
    l(h) {
      e = Kc(
        h,
        /*tag*/
        (n[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var d = Hi(e);
      o && o.l(d), t = Qc(d), l && l.l(d), d.forEach(jt), this.h();
    },
    h() {
      fl(
        /*tag*/
        n[25]
      )(e, u), Oe(
        e,
        "hidden",
        /*visible*/
        n[14] === !1
      ), Oe(
        e,
        "padded",
        /*padding*/
        n[10]
      ), Oe(
        e,
        "flex",
        /*flex*/
        n[1]
      ), Oe(
        e,
        "border_focus",
        /*border_mode*/
        n[9] === "focus"
      ), Oe(
        e,
        "border_contrast",
        /*border_mode*/
        n[9] === "contrast"
      ), Oe(e, "hide-container", !/*explicit_call*/
      n[12] && !/*container*/
      n[13]), Oe(
        e,
        "fullscreen",
        /*fullscreen*/
        n[0]
      ), Oe(
        e,
        "animating",
        /*fullscreen*/
        n[0] && /*preexpansionBoundingRect*/
        n[24] !== null
      ), Oe(
        e,
        "auto-margin",
        /*scale*/
        n[17] === null
      ), ie(
        e,
        "height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*height*/
            n[2]
          )
        )
      ), ie(
        e,
        "min-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*min_height*/
            n[3]
          )
        )
      ), ie(
        e,
        "max-height",
        /*fullscreen*/
        n[0] ? void 0 : (
          /*get_dimension*/
          n[26](
            /*max_height*/
            n[4]
          )
        )
      ), ie(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].top}px` : "0px"
      ), ie(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].left}px` : "0px"
      ), ie(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].width}px` : "0px"
      ), ie(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        n[24] ? `${/*preexpansionBoundingRect*/
        n[24].height}px` : "0px"
      ), ie(
        e,
        "width",
        /*fullscreen*/
        n[0] ? void 0 : typeof /*width*/
        n[5] == "number" ? `calc(min(${/*width*/
        n[5]}px, 100%))` : (
          /*get_dimension*/
          n[26](
            /*width*/
            n[5]
          )
        )
      ), ie(
        e,
        "border-style",
        /*variant*/
        n[8]
      ), ie(
        e,
        "overflow",
        /*allow_overflow*/
        n[15] ? (
          /*overflow_behavior*/
          n[16]
        ) : "hidden"
      ), ie(
        e,
        "flex-grow",
        /*scale*/
        n[17]
      ), ie(e, "min-width", `calc(min(${/*min_width*/
      n[18]}px, 100%))`), ie(e, "border-width", "var(--block-border-width)");
    },
    m(h, d) {
      Vi(h, e, d), o && o.m(e, null), Is(e, t), l && l.m(e, null), n[32](e), a = !0;
    },
    p(h, d) {
      var p;
      o && o.p && (!a || d[0] & /*$$scope*/
      1073741824) && kd(
        o,
        s,
        h,
        /*$$scope*/
        h[30],
        a ? vd(
          s,
          /*$$scope*/
          h[30],
          d,
          null
        ) : bd(
          /*$$scope*/
          h[30]
        ),
        null
      ), /*resizable*/
      h[19] ? l ? l.p(h, d) : (l = hl(h), l.c(), l.m(e, null)) : l && (l.d(1), l = null), fl(
        /*tag*/
        h[25]
      )(e, u = yd(c, [
        (!a || d[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          h[11]
        ) },
        (!a || d[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          h[6]
        ) },
        (!a || d[0] & /*elem_classes*/
        128 && i !== (i = "block " + /*elem_classes*/
        (((p = h[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu")) && { class: i },
        (!a || d[0] & /*rtl*/
        1048576 && r !== (r = /*rtl*/
        h[20] ? "rtl" : "ltr")) && { dir: r }
      ])), Oe(
        e,
        "hidden",
        /*visible*/
        h[14] === !1
      ), Oe(
        e,
        "padded",
        /*padding*/
        h[10]
      ), Oe(
        e,
        "flex",
        /*flex*/
        h[1]
      ), Oe(
        e,
        "border_focus",
        /*border_mode*/
        h[9] === "focus"
      ), Oe(
        e,
        "border_contrast",
        /*border_mode*/
        h[9] === "contrast"
      ), Oe(e, "hide-container", !/*explicit_call*/
      h[12] && !/*container*/
      h[13]), Oe(
        e,
        "fullscreen",
        /*fullscreen*/
        h[0]
      ), Oe(
        e,
        "animating",
        /*fullscreen*/
        h[0] && /*preexpansionBoundingRect*/
        h[24] !== null
      ), Oe(
        e,
        "auto-margin",
        /*scale*/
        h[17] === null
      ), d[0] & /*fullscreen, height*/
      5 && ie(
        e,
        "height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*height*/
            h[2]
          )
        )
      ), d[0] & /*fullscreen, min_height*/
      9 && ie(
        e,
        "min-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*min_height*/
            h[3]
          )
        )
      ), d[0] & /*fullscreen, max_height*/
      17 && ie(
        e,
        "max-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*max_height*/
            h[4]
          )
        )
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && ie(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].top}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && ie(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].left}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && ie(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].width}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && ie(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].height}px` : "0px"
      ), d[0] & /*fullscreen, width*/
      33 && ie(
        e,
        "width",
        /*fullscreen*/
        h[0] ? void 0 : typeof /*width*/
        h[5] == "number" ? `calc(min(${/*width*/
        h[5]}px, 100%))` : (
          /*get_dimension*/
          h[26](
            /*width*/
            h[5]
          )
        )
      ), d[0] & /*variant*/
      256 && ie(
        e,
        "border-style",
        /*variant*/
        h[8]
      ), d[0] & /*allow_overflow, overflow_behavior*/
      98304 && ie(
        e,
        "overflow",
        /*allow_overflow*/
        h[15] ? (
          /*overflow_behavior*/
          h[16]
        ) : "hidden"
      ), d[0] & /*scale*/
      131072 && ie(
        e,
        "flex-grow",
        /*scale*/
        h[17]
      ), d[0] & /*min_width*/
      262144 && ie(e, "min-width", `calc(min(${/*min_width*/
      h[18]}px, 100%))`);
    },
    i(h) {
      a || (tf(o, h), a = !0);
    },
    o(h) {
      nf(o, h), a = !1;
    },
    d(h) {
      h && jt(e), o && o.d(h), l && l.d(), n[32](null);
    }
  };
}
function dl(n) {
  let e;
  return {
    c() {
      e = Jc("div"), this.h();
    },
    l(t) {
      e = Kc(t, "DIV", { class: !0 }), Hi(e).forEach(jt), this.h();
    },
    h() {
      Ve(e, "class", "placeholder svelte-239wnu"), ie(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), ie(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    m(t, i) {
      Vi(t, e, i);
    },
    p(t, i) {
      i[0] & /*placeholder_height*/
      4194304 && ie(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), i[0] & /*placeholder_width*/
      8388608 && ie(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && jt(e);
    }
  };
}
function Ad(n) {
  let e, t, i, r = (
    /*tag*/
    n[25] && Sd(n)
  ), a = (
    /*fullscreen*/
    n[0] && dl(n)
  );
  return {
    c() {
      r && r.c(), e = ef(), a && a.c(), t = cl();
    },
    l(s) {
      r && r.l(s), e = Qc(s), a && a.l(s), t = cl();
    },
    m(s, o) {
      r && r.m(s, o), Vi(s, e, o), a && a.m(s, o), Vi(s, t, o), i = !0;
    },
    p(s, o) {
      /*tag*/
      s[25] && r.p(s, o), /*fullscreen*/
      s[0] ? a ? a.p(s, o) : (a = dl(s), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(s) {
      i || (tf(r, s), i = !0);
    },
    o(s) {
      nf(r, s), i = !1;
    },
    d(s) {
      s && (jt(e), jt(t)), r && r.d(s), a && a.d(s);
    }
  };
}
function Fd(n, e, t) {
  let { $$slots: i = {}, $$scope: r } = e, { height: a = void 0 } = e, { min_height: s = void 0 } = e, { max_height: o = void 0 } = e, { width: l = void 0 } = e, { elem_id: c = "" } = e, { elem_classes: u = [] } = e, { variant: f = "solid" } = e, { border_mode: h = "base" } = e, { padding: d = !0 } = e, { type: p = "normal" } = e, { test_id: v = void 0 } = e, { explicit_call: w = !1 } = e, { container: D = !0 } = e, { visible: m = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: b = null } = e, { min_width: E = 0 } = e, { flex: k = !1 } = e, { resizable: P = !1 } = e, { rtl: A = !1 } = e, { fullscreen: R = !1 } = e, B = R, L, de = p === "fieldset" ? "fieldset" : "div", z = 0, te = 0, Q = null;
  function oe(F) {
    R && F.key === "Escape" && t(0, R = !1);
  }
  const X = (F) => {
    if (F !== void 0) {
      if (typeof F == "number")
        return F + "px";
      if (typeof F == "string")
        return F;
    }
  }, ne = (F) => {
    let x = F.clientY;
    const H = (T) => {
      const ke = T.clientY - x;
      x = T.clientY, t(21, L.style.height = `${L.offsetHeight + ke}px`, L);
    }, J = () => {
      window.removeEventListener("mousemove", H), window.removeEventListener("mouseup", J);
    };
    window.addEventListener("mousemove", H), window.addEventListener("mouseup", J);
  };
  function De(F) {
    md[F ? "unshift" : "push"](() => {
      L = F, t(21, L);
    });
  }
  return n.$$set = (F) => {
    "height" in F && t(2, a = F.height), "min_height" in F && t(3, s = F.min_height), "max_height" in F && t(4, o = F.max_height), "width" in F && t(5, l = F.width), "elem_id" in F && t(6, c = F.elem_id), "elem_classes" in F && t(7, u = F.elem_classes), "variant" in F && t(8, f = F.variant), "border_mode" in F && t(9, h = F.border_mode), "padding" in F && t(10, d = F.padding), "type" in F && t(28, p = F.type), "test_id" in F && t(11, v = F.test_id), "explicit_call" in F && t(12, w = F.explicit_call), "container" in F && t(13, D = F.container), "visible" in F && t(14, m = F.visible), "allow_overflow" in F && t(15, _ = F.allow_overflow), "overflow_behavior" in F && t(16, g = F.overflow_behavior), "scale" in F && t(17, b = F.scale), "min_width" in F && t(18, E = F.min_width), "flex" in F && t(1, k = F.flex), "resizable" in F && t(19, P = F.resizable), "rtl" in F && t(20, A = F.rtl), "fullscreen" in F && t(0, R = F.fullscreen), "$$scope" in F && t(30, r = F.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && R !== B && (t(29, B = R), R ? (t(24, Q = L.getBoundingClientRect()), t(22, z = L.offsetHeight), t(23, te = L.offsetWidth), window.addEventListener("keydown", oe)) : (t(24, Q = null), window.removeEventListener("keydown", oe))), n.$$.dirty[0] & /*visible*/
    16384 && (m || t(1, k = !1));
  }, [
    R,
    k,
    a,
    s,
    o,
    l,
    c,
    u,
    f,
    h,
    d,
    v,
    w,
    D,
    m,
    _,
    g,
    b,
    E,
    P,
    A,
    L,
    z,
    te,
    Q,
    de,
    X,
    ne,
    p,
    B,
    r,
    i,
    De
  ];
}
class rf extends _d {
  constructor(e) {
    super(), wd(
      this,
      e,
      Fd,
      Ad,
      Cd,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function yo() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Xn = yo();
function af(n) {
  Xn = n;
}
const sf = /[&<>"']/, Td = new RegExp(sf.source, "g"), of = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Id = new RegExp(of.source, "g"), $d = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, _l = (n) => $d[n];
function ht(n, e) {
  if (e) {
    if (sf.test(n))
      return n.replace(Td, _l);
  } else if (of.test(n))
    return n.replace(Id, _l);
  return n;
}
const xd = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Pd(n) {
  return n.replace(xd, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Bd = /(^|[^\[])\^/g;
function se(n, e) {
  let t = typeof n == "string" ? n : n.source;
  e = e || "";
  const i = {
    replace: (r, a) => {
      let s = typeof a == "string" ? a : a.source;
      return s = s.replace(Bd, "$1"), t = t.replace(r, s), i;
    },
    getRegex: () => new RegExp(t, e)
  };
  return i;
}
function pl(n) {
  try {
    n = encodeURI(n).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return n;
}
const Gi = { exec: () => null };
function ml(n, e) {
  const t = n.replace(/\|/g, (a, s, o) => {
    let l = !1, c = s;
    for (; --c >= 0 && o[c] === "\\"; )
      l = !l;
    return l ? "|" : " |";
  }), i = t.split(/ \|/);
  let r = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i[i.length - 1].trim() && i.pop(), e)
    if (i.length > e)
      i.splice(e);
    else
      for (; i.length < e; )
        i.push("");
  for (; r < i.length; r++)
    i[r] = i[r].trim().replace(/\\\|/g, "|");
  return i;
}
function _r(n, e, t) {
  const i = n.length;
  if (i === 0)
    return "";
  let r = 0;
  for (; r < i && n.charAt(i - r - 1) === e; )
    r++;
  return n.slice(0, i - r);
}
function Od(n, e) {
  if (n.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let i = 0; i < n.length; i++)
    if (n[i] === "\\")
      i++;
    else if (n[i] === e[0])
      t++;
    else if (n[i] === e[1] && (t--, t < 0))
      return i;
  return -1;
}
function gl(n, e, t, i) {
  const r = e.href, a = e.title ? ht(e.title) : null, s = n[1].replace(/\\([\[\]])/g, "$1");
  if (n[0].charAt(0) !== "!") {
    i.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: r,
      title: a,
      text: s,
      tokens: i.inlineTokens(s)
    };
    return i.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: r,
    title: a,
    text: ht(s)
  };
}
function Ld(n, e) {
  const t = n.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const i = t[1];
  return e.split(`
`).map((r) => {
    const a = r.match(/^\s+/);
    if (a === null)
      return r;
    const [s] = a;
    return s.length >= i.length ? r.slice(i.length) : r;
  }).join(`
`);
}
class Xr {
  // set by the lexer
  constructor(e) {
    _e(this, "options");
    _e(this, "rules");
    // set by the lexer
    _e(this, "lexer");
    this.options = e || Xn;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const i = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? i : _r(i, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const i = t[0], r = Ld(i, t[3] || "");
      return {
        type: "code",
        raw: i,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: r
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let i = t[2].trim();
      if (/#$/.test(i)) {
        const r = _r(i, "#");
        (this.options.pedantic || !r || / $/.test(r)) && (i = r.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let i = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      i = _r(i.replace(/^ *>[ \t]?/gm, ""), `
`);
      const r = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(i);
      return this.lexer.state.top = r, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: i
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let i = t[1].trim();
      const r = i.length > 1, a = {
        type: "list",
        raw: "",
        ordered: r,
        start: r ? +i.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      i = r ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = r ? i : "[*+-]");
      const s = new RegExp(`^( {0,3}${i})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", l = "", c = !1;
      for (; e; ) {
        let u = !1;
        if (!(t = s.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, (D) => " ".repeat(3 * D.length)), h = e.split(`
`, 1)[0], d = 0;
        this.options.pedantic ? (d = 2, l = f.trimStart()) : (d = t[2].search(/[^ ]/), d = d > 4 ? 1 : d, l = f.slice(d), d += t[1].length);
        let p = !1;
        if (!f && /^ *$/.test(h) && (o += h + `
`, e = e.substring(h.length + 1), u = !0), !u) {
          const D = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, d - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, d - 1)}}#`);
          for (; e; ) {
            const b = e.split(`
`, 1)[0];
            if (h = b, this.options.pedantic && (h = h.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(h) || g.test(h) || D.test(h) || m.test(e))
              break;
            if (h.search(/[^ ]/) >= d || !h.trim())
              l += `
` + h.slice(d);
            else {
              if (p || f.search(/[^ ]/) >= 4 || _.test(f) || g.test(f) || m.test(f))
                break;
              l += `
` + h;
            }
            !p && !h.trim() && (p = !0), o += b + `
`, e = e.substring(b.length + 1), f = h.slice(d);
          }
        }
        a.loose || (c ? a.loose = !0 : /\n *\n *$/.test(o) && (c = !0));
        let v = null, w;
        this.options.gfm && (v = /^\[[ xX]\] /.exec(l), v && (w = v[0] !== "[ ] ", l = l.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: o,
          task: !!v,
          checked: w,
          loose: !1,
          text: l,
          tokens: []
        }), a.raw += o;
      }
      a.items[a.items.length - 1].raw = o.trimEnd(), a.items[a.items.length - 1].text = l.trimEnd(), a.raw = a.raw.trimEnd();
      for (let u = 0; u < a.items.length; u++)
        if (this.lexer.state.top = !1, a.items[u].tokens = this.lexer.blockTokens(a.items[u].text, []), !a.loose) {
          const f = a.items[u].tokens.filter((d) => d.type === "space"), h = f.length > 0 && f.some((d) => /\n.*\n/.test(d.raw));
          a.loose = h;
        }
      if (a.loose)
        for (let u = 0; u < a.items.length; u++)
          a.items[u].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const i = t[1].toLowerCase().replace(/\s+/g, " "), r = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: i,
        raw: t[0],
        href: r,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const i = ml(t[1]), r = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], s = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (i.length === r.length) {
      for (const o of r)
        /^ *-+: *$/.test(o) ? s.align.push("right") : /^ *:-+: *$/.test(o) ? s.align.push("center") : /^ *:-+ *$/.test(o) ? s.align.push("left") : s.align.push(null);
      for (const o of i)
        s.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of a)
        s.rows.push(ml(o, s.header.length).map((l) => ({
          text: l,
          tokens: this.lexer.inline(l)
        })));
      return s;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const i = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: ht(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const i = t[2].trim();
      if (!this.options.pedantic && /^</.test(i)) {
        if (!/>$/.test(i))
          return;
        const s = _r(i.slice(0, -1), "\\");
        if ((i.length - s.length) % 2 === 0)
          return;
      } else {
        const s = Od(t[2], "()");
        if (s > -1) {
          const l = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + s;
          t[2] = t[2].substring(0, s), t[0] = t[0].substring(0, l).trim(), t[3] = "";
        }
      }
      let r = t[2], a = "";
      if (this.options.pedantic) {
        const s = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);
        s && (r = s[1], a = s[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return r = r.trim(), /^</.test(r) && (this.options.pedantic && !/>$/.test(i) ? r = r.slice(1) : r = r.slice(1, -1)), gl(t, {
        href: r && r.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let i;
    if ((i = this.rules.inline.reflink.exec(e)) || (i = this.rules.inline.nolink.exec(e))) {
      const r = (i[2] || i[1]).replace(/\s+/g, " "), a = t[r.toLowerCase()];
      if (!a) {
        const s = i[0].charAt(0);
        return {
          type: "text",
          raw: s,
          text: s
        };
      }
      return gl(i, a, i[0], this.lexer);
    }
  }
  emStrong(e, t, i = "") {
    let r = this.rules.inline.emStrongLDelim.exec(e);
    if (!r || r[3] && i.match(/[\p{L}\p{N}]/u))
      return;
    if (!(r[1] || r[2] || "") || !i || this.rules.inline.punctuation.exec(i)) {
      const s = [...r[0]].length - 1;
      let o, l, c = s, u = 0;
      const f = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + s); (r = f.exec(t)) != null; ) {
        if (o = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !o)
          continue;
        if (l = [...o].length, r[3] || r[4]) {
          c += l;
          continue;
        } else if ((r[5] || r[6]) && s % 3 && !((s + l) % 3)) {
          u += l;
          continue;
        }
        if (c -= l, c > 0)
          continue;
        l = Math.min(l, l + c + u);
        const h = [...r[0]][0].length, d = e.slice(0, s + r.index + h + l);
        if (Math.min(s, l) % 2) {
          const v = d.slice(1, -1);
          return {
            type: "em",
            raw: d,
            text: v,
            tokens: this.lexer.inlineTokens(v)
          };
        }
        const p = d.slice(2, -2);
        return {
          type: "strong",
          raw: d,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let i = t[2].replace(/\n/g, " ");
      const r = /[^ ]/.test(i), a = /^ /.test(i) && / $/.test(i);
      return r && a && (i = i.substring(1, i.length - 1)), i = ht(i, !0), {
        type: "codespan",
        raw: t[0],
        text: i
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let i, r;
      return t[2] === "@" ? (i = ht(t[1]), r = "mailto:" + i) : (i = ht(t[1]), r = i), {
        type: "link",
        raw: t[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  url(e) {
    var i;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let r, a;
      if (t[2] === "@")
        r = ht(t[0]), a = "mailto:" + r;
      else {
        let s;
        do
          s = t[0], t[0] = ((i = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : i[0]) ?? "";
        while (s !== t[0]);
        r = ht(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: r,
        href: a,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let i;
      return this.lexer.state.inRawBlock ? i = t[0] : i = ht(t[0]), {
        type: "text",
        raw: t[0],
        text: i
      };
    }
  }
}
const Rd = /^(?: *(?:\n|$))+/, Md = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Nd = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, rr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Ud = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, lf = /(?:[*+-]|\d{1,9}[.)])/, uf = se(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, lf).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), wo = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Hd = /^[^\n]+/, Do = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Gd = se(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Do).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), zd = se(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, lf).getRegex(), ba = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Eo = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, qd = se("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Eo).replace("tag", ba).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), cf = se(wo).replace("hr", rr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ba).getRegex(), jd = se(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", cf).getRegex(), Co = {
  blockquote: jd,
  code: Md,
  def: Gd,
  fences: Nd,
  heading: Ud,
  hr: rr,
  html: qd,
  lheading: uf,
  list: zd,
  newline: Rd,
  paragraph: cf,
  table: Gi,
  text: Hd
}, bl = se("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", rr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ba).getRegex(), Vd = {
  ...Co,
  table: bl,
  paragraph: se(wo).replace("hr", rr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", bl).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ba).getRegex()
}, Wd = {
  ...Co,
  html: se(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Eo).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Gi,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: se(wo).replace("hr", rr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", uf).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, ff = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Xd = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, hf = /^( {2,}|\\)\n(?!\s*$)/, Zd = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, ar = "\\p{P}\\p{S}", Yd = se(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, ar).getRegex(), Kd = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Qd = se(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, ar).getRegex(), Jd = se("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, ar).getRegex(), e_ = se("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, ar).getRegex(), t_ = se(/\\([punct])/, "gu").replace(/punct/g, ar).getRegex(), n_ = se(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), i_ = se(Eo).replace("(?:-->|$)", "-->").getRegex(), r_ = se("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", i_).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Zr = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, a_ = se(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Zr).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), df = se(/^!?\[(label)\]\[(ref)\]/).replace("label", Zr).replace("ref", Do).getRegex(), _f = se(/^!?\[(ref)\](?:\[\])?/).replace("ref", Do).getRegex(), s_ = se("reflink|nolink(?!\\()", "g").replace("reflink", df).replace("nolink", _f).getRegex(), ko = {
  _backpedal: Gi,
  // only used for GFM url
  anyPunctuation: t_,
  autolink: n_,
  blockSkip: Kd,
  br: hf,
  code: Xd,
  del: Gi,
  emStrongLDelim: Qd,
  emStrongRDelimAst: Jd,
  emStrongRDelimUnd: e_,
  escape: ff,
  link: a_,
  nolink: _f,
  punctuation: Yd,
  reflink: df,
  reflinkSearch: s_,
  tag: r_,
  text: Zd,
  url: Gi
}, o_ = {
  ...ko,
  link: se(/^!?\[(label)\]\((.*?)\)/).replace("label", Zr).getRegex(),
  reflink: se(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Zr).getRegex()
}, $s = {
  ...ko,
  escape: se(ff).replace("])", "~|])").getRegex(),
  url: se(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, l_ = {
  ...$s,
  br: se(hf).replace("{2,}", "*").getRegex(),
  text: se($s.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, pr = {
  normal: Co,
  gfm: Vd,
  pedantic: Wd
}, Si = {
  normal: ko,
  gfm: $s,
  breaks: l_,
  pedantic: o_
};
class Vt {
  constructor(e) {
    _e(this, "tokens");
    _e(this, "options");
    _e(this, "state");
    _e(this, "tokenizer");
    _e(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Xn, this.options.tokenizer = this.options.tokenizer || new Xr(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: pr.normal,
      inline: Si.normal
    };
    this.options.pedantic ? (t.block = pr.pedantic, t.inline = Si.pedantic) : this.options.gfm && (t.block = pr.gfm, this.options.breaks ? t.inline = Si.breaks : t.inline = Si.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: pr,
      inline: Si
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Vt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Vt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const i = this.inlineQueue[t];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, l, c) => l + "    ".repeat(c.length));
    let i, r, a, s;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (i = o.call({ lexer: this }, e, t)) ? (e = e.substring(i.raw.length), t.push(i), !0) : !1))) {
        if (i = this.tokenizer.space(e)) {
          e = e.substring(i.raw.length), i.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(i);
          continue;
        }
        if (i = this.tokenizer.code(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : t.push(i);
          continue;
        }
        if (i = this.tokenizer.fences(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.heading(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.hr(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.blockquote(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.list(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.html(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.def(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.raw, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
            href: i.href,
            title: i.title
          });
          continue;
        }
        if (i = this.tokenizer.table(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.lheading(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const l = e.slice(1);
          let c;
          this.options.extensions.startBlock.forEach((u) => {
            c = u.call({ lexer: this }, l), typeof c == "number" && c >= 0 && (o = Math.min(o, c));
          }), o < 1 / 0 && o >= 0 && (a = e.substring(0, o + 1));
        }
        if (this.state.top && (i = this.tokenizer.paragraph(a))) {
          r = t[t.length - 1], s && r.type === "paragraph" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : t.push(i), s = a.length !== e.length, e = e.substring(i.raw.length);
          continue;
        }
        if (i = this.tokenizer.text(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && r.type === "text" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : t.push(i);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let i, r, a, s = e, o, l, c;
    if (this.tokens.links) {
      const u = Object.keys(this.tokens.links);
      if (u.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(s)) != null; )
          u.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (s = s.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + s.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(s)) != null; )
      s = s.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + s.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(s)) != null; )
      s = s.slice(0, o.index) + "++" + s.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (l || (c = ""), l = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((u) => (i = u.call({ lexer: this }, e, t)) ? (e = e.substring(i.raw.length), t.push(i), !0) : !1))) {
        if (i = this.tokenizer.escape(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.tag(e)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : t.push(i);
          continue;
        }
        if (i = this.tokenizer.link(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(i.raw.length), r = t[t.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : t.push(i);
          continue;
        }
        if (i = this.tokenizer.emStrong(e, s, c)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.codespan(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.br(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.del(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (i = this.tokenizer.autolink(e)) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (!this.state.inLink && (i = this.tokenizer.url(e))) {
          e = e.substring(i.raw.length), t.push(i);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let u = 1 / 0;
          const f = e.slice(1);
          let h;
          this.options.extensions.startInline.forEach((d) => {
            h = d.call({ lexer: this }, f), typeof h == "number" && h >= 0 && (u = Math.min(u, h));
          }), u < 1 / 0 && u >= 0 && (a = e.substring(0, u + 1));
        }
        if (i = this.tokenizer.inlineText(a)) {
          e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (c = i.raw.slice(-1)), l = !0, r = t[t.length - 1], r && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : t.push(i);
          continue;
        }
        if (e) {
          const u = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(u);
            break;
          } else
            throw new Error(u);
        }
      }
    return t;
  }
}
class Yr {
  constructor(e) {
    _e(this, "options");
    this.options = e || Xn;
  }
  code(e, t, i) {
    var a;
    const r = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, r ? '<pre><code class="language-' + ht(r) + '">' + (i ? e : ht(e, !0)) + `</code></pre>
` : "<pre><code>" + (i ? e : ht(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, i) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, i) {
    const r = t ? "ol" : "ul", a = t && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + r + a + `>
` + e + "</" + r + `>
`;
  }
  listitem(e, t, i) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const i = t.header ? "th" : "td";
    return (t.align ? `<${i} align="${t.align}">` : `<${i}>`) + e + `</${i}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, i) {
    const r = pl(e);
    if (r === null)
      return i;
    e = r;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + i + "</a>", a;
  }
  image(e, t, i) {
    const r = pl(e);
    if (r === null)
      return i;
    e = r;
    let a = `<img src="${e}" alt="${i}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class So {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, i) {
    return "" + i;
  }
  image(e, t, i) {
    return "" + i;
  }
  br() {
    return "";
  }
}
class Wt {
  constructor(e) {
    _e(this, "options");
    _e(this, "renderer");
    _e(this, "textRenderer");
    this.options = e || Xn, this.options.renderer = this.options.renderer || new Yr(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new So();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Wt(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Wt(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const s = a, o = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(s.type)) {
          i += o || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          i += this.renderer.hr();
          continue;
        }
        case "heading": {
          const s = a;
          i += this.renderer.heading(this.parseInline(s.tokens), s.depth, Pd(this.parseInline(s.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const s = a;
          i += this.renderer.code(s.text, s.lang, !!s.escaped);
          continue;
        }
        case "table": {
          const s = a;
          let o = "", l = "";
          for (let u = 0; u < s.header.length; u++)
            l += this.renderer.tablecell(this.parseInline(s.header[u].tokens), { header: !0, align: s.align[u] });
          o += this.renderer.tablerow(l);
          let c = "";
          for (let u = 0; u < s.rows.length; u++) {
            const f = s.rows[u];
            l = "";
            for (let h = 0; h < f.length; h++)
              l += this.renderer.tablecell(this.parseInline(f[h].tokens), { header: !1, align: s.align[h] });
            c += this.renderer.tablerow(l);
          }
          i += this.renderer.table(o, c);
          continue;
        }
        case "blockquote": {
          const s = a, o = this.parse(s.tokens);
          i += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const s = a, o = s.ordered, l = s.start, c = s.loose;
          let u = "";
          for (let f = 0; f < s.items.length; f++) {
            const h = s.items[f], d = h.checked, p = h.task;
            let v = "";
            if (h.task) {
              const w = this.renderer.checkbox(!!d);
              c ? h.tokens.length > 0 && h.tokens[0].type === "paragraph" ? (h.tokens[0].text = w + " " + h.tokens[0].text, h.tokens[0].tokens && h.tokens[0].tokens.length > 0 && h.tokens[0].tokens[0].type === "text" && (h.tokens[0].tokens[0].text = w + " " + h.tokens[0].tokens[0].text)) : h.tokens.unshift({
                type: "text",
                text: w + " "
              }) : v += w + " ";
            }
            v += this.parse(h.tokens, c), u += this.renderer.listitem(v, p, !!d);
          }
          i += this.renderer.list(u, o, l);
          continue;
        }
        case "html": {
          const s = a;
          i += this.renderer.html(s.text, s.block);
          continue;
        }
        case "paragraph": {
          const s = a;
          i += this.renderer.paragraph(this.parseInline(s.tokens));
          continue;
        }
        case "text": {
          let s = a, o = s.tokens ? this.parseInline(s.tokens) : s.text;
          for (; r + 1 < e.length && e[r + 1].type === "text"; )
            s = e[++r], o += `
` + (s.tokens ? this.parseInline(s.tokens) : s.text);
          i += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const s = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(s), "";
          throw new Error(s);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const s = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (s !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          i += s || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const s = a;
          i += t.text(s.text);
          break;
        }
        case "html": {
          const s = a;
          i += t.html(s.text);
          break;
        }
        case "link": {
          const s = a;
          i += t.link(s.href, s.title, this.parseInline(s.tokens, t));
          break;
        }
        case "image": {
          const s = a;
          i += t.image(s.href, s.title, s.text);
          break;
        }
        case "strong": {
          const s = a;
          i += t.strong(this.parseInline(s.tokens, t));
          break;
        }
        case "em": {
          const s = a;
          i += t.em(this.parseInline(s.tokens, t));
          break;
        }
        case "codespan": {
          const s = a;
          i += t.codespan(s.text);
          break;
        }
        case "br": {
          i += t.br();
          break;
        }
        case "del": {
          const s = a;
          i += t.del(this.parseInline(s.tokens, t));
          break;
        }
        case "text": {
          const s = a;
          i += t.text(s.text);
          break;
        }
        default: {
          const s = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(s), "";
          throw new Error(s);
        }
      }
    }
    return i;
  }
}
class zi {
  constructor(e) {
    _e(this, "options");
    this.options = e || Xn;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
_e(zi, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Wn, xs, pf;
class u_ {
  constructor(...e) {
    Ra(this, Wn);
    _e(this, "defaults", yo());
    _e(this, "options", this.setOptions);
    _e(this, "parse", dr(this, Wn, xs).call(this, Vt.lex, Wt.parse));
    _e(this, "parseInline", dr(this, Wn, xs).call(this, Vt.lexInline, Wt.parseInline));
    _e(this, "Parser", Wt);
    _e(this, "Renderer", Yr);
    _e(this, "TextRenderer", So);
    _e(this, "Lexer", Vt);
    _e(this, "Tokenizer", Xr);
    _e(this, "Hooks", zi);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var r, a;
    let i = [];
    for (const s of e)
      switch (i = i.concat(t.call(this, s)), s.type) {
        case "table": {
          const o = s;
          for (const l of o.header)
            i = i.concat(this.walkTokens(l.tokens, t));
          for (const l of o.rows)
            for (const c of l)
              i = i.concat(this.walkTokens(c.tokens, t));
          break;
        }
        case "list": {
          const o = s;
          i = i.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = s;
          (a = (r = this.defaults.extensions) == null ? void 0 : r.childTokens) != null && a[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((l) => {
            const c = o[l].flat(1 / 0);
            i = i.concat(this.walkTokens(c, t));
          }) : o.tokens && (i = i.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return i;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((i) => {
      const r = { ...i };
      if (r.async = this.defaults.async || r.async || !1, i.extensions && (i.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const s = t.renderers[a.name];
          s ? t.renderers[a.name] = function(...o) {
            let l = a.renderer.apply(this, o);
            return l === !1 && (l = s.apply(this, o)), l;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const s = t[a.level];
          s ? s.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), r.extensions = t), i.renderer) {
        const a = this.defaults.renderer || new Yr(this.defaults);
        for (const s in i.renderer) {
          if (!(s in a))
            throw new Error(`renderer '${s}' does not exist`);
          if (s === "options")
            continue;
          const o = s, l = i.renderer[o], c = a[o];
          a[o] = (...u) => {
            let f = l.apply(a, u);
            return f === !1 && (f = c.apply(a, u)), f || "";
          };
        }
        r.renderer = a;
      }
      if (i.tokenizer) {
        const a = this.defaults.tokenizer || new Xr(this.defaults);
        for (const s in i.tokenizer) {
          if (!(s in a))
            throw new Error(`tokenizer '${s}' does not exist`);
          if (["options", "rules", "lexer"].includes(s))
            continue;
          const o = s, l = i.tokenizer[o], c = a[o];
          a[o] = (...u) => {
            let f = l.apply(a, u);
            return f === !1 && (f = c.apply(a, u)), f;
          };
        }
        r.tokenizer = a;
      }
      if (i.hooks) {
        const a = this.defaults.hooks || new zi();
        for (const s in i.hooks) {
          if (!(s in a))
            throw new Error(`hook '${s}' does not exist`);
          if (s === "options")
            continue;
          const o = s, l = i.hooks[o], c = a[o];
          zi.passThroughHooks.has(s) ? a[o] = (u) => {
            if (this.defaults.async)
              return Promise.resolve(l.call(a, u)).then((h) => c.call(a, h));
            const f = l.call(a, u);
            return c.call(a, f);
          } : a[o] = (...u) => {
            let f = l.apply(a, u);
            return f === !1 && (f = c.apply(a, u)), f;
          };
        }
        r.hooks = a;
      }
      if (i.walkTokens) {
        const a = this.defaults.walkTokens, s = i.walkTokens;
        r.walkTokens = function(o) {
          let l = [];
          return l.push(s.call(this, o)), a && (l = l.concat(a.call(this, o))), l;
        };
      }
      this.defaults = { ...this.defaults, ...r };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Vt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Wt.parse(e, t ?? this.defaults);
  }
}
Wn = new WeakSet(), xs = function(e, t) {
  return (i, r) => {
    const a = { ...r }, s = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (s.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), s.async = !0);
    const o = dr(this, Wn, pf).call(this, !!s.silent, !!s.async);
    if (typeof i > "u" || i === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof i != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(i) + ", string expected"));
    if (s.hooks && (s.hooks.options = s), s.async)
      return Promise.resolve(s.hooks ? s.hooks.preprocess(i) : i).then((l) => e(l, s)).then((l) => s.hooks ? s.hooks.processAllTokens(l) : l).then((l) => s.walkTokens ? Promise.all(this.walkTokens(l, s.walkTokens)).then(() => l) : l).then((l) => t(l, s)).then((l) => s.hooks ? s.hooks.postprocess(l) : l).catch(o);
    try {
      s.hooks && (i = s.hooks.preprocess(i));
      let l = e(i, s);
      s.hooks && (l = s.hooks.processAllTokens(l)), s.walkTokens && this.walkTokens(l, s.walkTokens);
      let c = t(l, s);
      return s.hooks && (c = s.hooks.postprocess(c)), c;
    } catch (l) {
      return o(l);
    }
  };
}, pf = function(e, t) {
  return (i) => {
    if (i.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const r = "<p>An error occurred:</p><pre>" + ht(i.message + "", !0) + "</pre>";
      return t ? Promise.resolve(r) : r;
    }
    if (t)
      return Promise.reject(i);
    throw i;
  };
};
const Nn = new u_();
function ae(n, e) {
  return Nn.parse(n, e);
}
ae.options = ae.setOptions = function(n) {
  return Nn.setOptions(n), ae.defaults = Nn.defaults, af(ae.defaults), ae;
};
ae.getDefaults = yo;
ae.defaults = Xn;
ae.use = function(...n) {
  return Nn.use(...n), ae.defaults = Nn.defaults, af(ae.defaults), ae;
};
ae.walkTokens = function(n, e) {
  return Nn.walkTokens(n, e);
};
ae.parseInline = Nn.parseInline;
ae.Parser = Wt;
ae.parser = Wt.parse;
ae.Renderer = Yr;
ae.TextRenderer = So;
ae.Lexer = Vt;
ae.lexer = Vt.lex;
ae.Tokenizer = Xr;
ae.Hooks = zi;
ae.parse = ae;
ae.options;
ae.setOptions;
ae.use;
ae.walkTokens;
ae.parseInline;
Wt.parse;
Vt.lex;
const c_ = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, f_ = Object.hasOwnProperty;
class mf {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const i = this;
    let r = h_(e, t === !0);
    const a = r;
    for (; f_.call(i.occurrences, r); )
      i.occurrences[a]++, r = a + "-" + i.occurrences[a];
    return i.occurrences[r] = 0, r;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function h_(n, e) {
  return typeof n != "string" ? "" : (e || (n = n.toLowerCase()), n.replace(c_, "").replace(/ /g, "-"));
}
new mf();
var vl = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, d_ = { exports: {} };
(function(n) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(i) {
    var r = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, s = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(_) {
          return _ instanceof l ? new l(_.type, m(_.content), _.alias) : Array.isArray(_) ? _.map(m) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++a }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(_, g) {
          g = g || {};
          var b, E;
          switch (o.util.type(_)) {
            case "Object":
              if (E = o.util.objId(_), g[E])
                return g[E];
              b = /** @type {Record<string, any>} */
              {}, g[E] = b;
              for (var k in _)
                _.hasOwnProperty(k) && (b[k] = m(_[k], g));
              return (
                /** @type {any} */
                b
              );
            case "Array":
              return E = o.util.objId(_), g[E] ? g[E] : (b = [], g[E] = b, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(P, A) {
                b[A] = m(P, g);
              }), /** @type {any} */
              b);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var _ = r.exec(m.className);
            if (_)
              return _[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, _) {
          m.className = m.className.replace(RegExp(r, "gi"), ""), m.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (b) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(b.stack) || [])[1];
            if (m) {
              var _ = document.getElementsByTagName("script");
              for (var g in _)
                if (_[g].src == m)
                  return _[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, _, g) {
          for (var b = "no-" + _; m; ) {
            var E = m.classList;
            if (E.contains(_))
              return !0;
            if (E.contains(b))
              return !1;
            m = m.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: s,
        plaintext: s,
        text: s,
        txt: s,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, _) {
          var g = o.util.clone(o.languages[m]);
          for (var b in _)
            g[b] = _[b];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, _, g, b) {
          b = b || /** @type {any} */
          o.languages;
          var E = b[m], k = {};
          for (var P in E)
            if (E.hasOwnProperty(P)) {
              if (P == _)
                for (var A in g)
                  g.hasOwnProperty(A) && (k[A] = g[A]);
              g.hasOwnProperty(P) || (k[P] = E[P]);
            }
          var R = b[m];
          return b[m] = k, o.languages.DFS(o.languages, function(B, L) {
            L === R && B != m && (this[B] = k);
          }), k;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(_, g, b, E) {
          E = E || {};
          var k = o.util.objId;
          for (var P in _)
            if (_.hasOwnProperty(P)) {
              g.call(_, P, _[P], b || P);
              var A = _[P], R = o.util.type(A);
              R === "Object" && !E[k(A)] ? (E[k(A)] = !0, m(A, g, null, E)) : R === "Array" && !E[k(A)] && (E[k(A)] = !0, m(A, g, P, E));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, _) {
        o.highlightAllUnder(document, m, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, _, g) {
        var b = {
          callback: g,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", b), b.elements = Array.prototype.slice.apply(b.container.querySelectorAll(b.selector)), o.hooks.run("before-all-elements-highlight", b);
        for (var E = 0, k; k = b.elements[E++]; )
          o.highlightElement(k, _ === !0, b.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, _, g) {
        var b = o.util.getLanguage(m), E = o.languages[b];
        o.util.setLanguage(m, b);
        var k = m.parentElement;
        k && k.nodeName.toLowerCase() === "pre" && o.util.setLanguage(k, b);
        var P = m.textContent, A = {
          element: m,
          language: b,
          grammar: E,
          code: P
        };
        function R(L) {
          A.highlightedCode = L, o.hooks.run("before-insert", A), A.element.innerHTML = A.highlightedCode, o.hooks.run("after-highlight", A), o.hooks.run("complete", A), g && g.call(A.element);
        }
        if (o.hooks.run("before-sanity-check", A), k = A.element.parentElement, k && k.nodeName.toLowerCase() === "pre" && !k.hasAttribute("tabindex") && k.setAttribute("tabindex", "0"), !A.code) {
          o.hooks.run("complete", A), g && g.call(A.element);
          return;
        }
        if (o.hooks.run("before-highlight", A), !A.grammar) {
          R(o.util.encode(A.code));
          return;
        }
        if (_ && i.Worker) {
          var B = new Worker(o.filename);
          B.onmessage = function(L) {
            R(L.data);
          }, B.postMessage(JSON.stringify({
            language: A.language,
            code: A.code,
            immediateClose: !0
          }));
        } else
          R(o.highlight(A.code, A.grammar, A.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, _, g) {
        var b = {
          code: m,
          grammar: _,
          language: g
        };
        if (o.hooks.run("before-tokenize", b), !b.grammar)
          throw new Error('The language "' + b.language + '" has no grammar.');
        return b.tokens = o.tokenize(b.code, b.grammar), o.hooks.run("after-tokenize", b), l.stringify(o.util.encode(b.tokens), b.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, _) {
        var g = _.rest;
        if (g) {
          for (var b in g)
            _[b] = g[b];
          delete _.rest;
        }
        var E = new f();
        return h(E, E.head, m), u(m, E, _, E.head, 0), p(E);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, _) {
          var g = o.hooks.all;
          g[m] = g[m] || [], g[m].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, _) {
          var g = o.hooks.all[m];
          if (!(!g || !g.length))
            for (var b = 0, E; E = g[b++]; )
              E(_);
        }
      },
      Token: l
    };
    i.Prism = o;
    function l(m, _, g, b) {
      this.type = m, this.content = _, this.alias = g, this.length = (b || "").length | 0;
    }
    l.stringify = function m(_, g) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var b = "";
        return _.forEach(function(R) {
          b += m(R, g);
        }), b;
      }
      var E = {
        type: _.type,
        content: m(_.content, g),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: g
      }, k = _.alias;
      k && (Array.isArray(k) ? Array.prototype.push.apply(E.classes, k) : E.classes.push(k)), o.hooks.run("wrap", E);
      var P = "";
      for (var A in E.attributes)
        P += " " + A + '="' + (E.attributes[A] || "").replace(/"/g, "&quot;") + '"';
      return "<" + E.tag + ' class="' + E.classes.join(" ") + '"' + P + ">" + E.content + "</" + E.tag + ">";
    };
    function c(m, _, g, b) {
      m.lastIndex = _;
      var E = m.exec(g);
      if (E && b && E[1]) {
        var k = E[1].length;
        E.index += k, E[0] = E[0].slice(k);
      }
      return E;
    }
    function u(m, _, g, b, E, k) {
      for (var P in g)
        if (!(!g.hasOwnProperty(P) || !g[P])) {
          var A = g[P];
          A = Array.isArray(A) ? A : [A];
          for (var R = 0; R < A.length; ++R) {
            if (k && k.cause == P + "," + R)
              return;
            var B = A[R], L = B.inside, de = !!B.lookbehind, z = !!B.greedy, te = B.alias;
            if (z && !B.pattern.global) {
              var Q = B.pattern.toString().match(/[imsuy]*$/)[0];
              B.pattern = RegExp(B.pattern.source, Q + "g");
            }
            for (var oe = B.pattern || B, X = b.next, ne = E; X !== _.tail && !(k && ne >= k.reach); ne += X.value.length, X = X.next) {
              var De = X.value;
              if (_.length > m.length)
                return;
              if (!(De instanceof l)) {
                var F = 1, x;
                if (z) {
                  if (x = c(oe, ne, m, de), !x || x.index >= m.length)
                    break;
                  var ke = x.index, H = x.index + x[0].length, J = ne;
                  for (J += X.value.length; ke >= J; )
                    X = X.next, J += X.value.length;
                  if (J -= X.value.length, ne = J, X.value instanceof l)
                    continue;
                  for (var T = X; T !== _.tail && (J < H || typeof T.value == "string"); T = T.next)
                    F++, J += T.value.length;
                  F--, De = m.slice(ne, J), x.index -= ne;
                } else if (x = c(oe, 0, De, de), !x)
                  continue;
                var ke = x.index, Se = x[0], I = De.slice(0, ke), q = De.slice(ke + Se.length), j = ne + De.length;
                k && j > k.reach && (k.reach = j);
                var V = X.prev;
                I && (V = h(_, V, I), ne += I.length), d(_, V, F);
                var ce = new l(P, L ? o.tokenize(Se, L) : Se, te, Se);
                if (X = h(_, V, ce), q && h(_, X, q), F > 1) {
                  var Ee = {
                    cause: P + "," + R,
                    reach: j
                  };
                  u(m, _, g, X.prev, ne, Ee), k && Ee.reach > k.reach && (k.reach = Ee.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var m = { value: null, prev: null, next: null }, _ = { value: null, prev: m, next: null };
      m.next = _, this.head = m, this.tail = _, this.length = 0;
    }
    function h(m, _, g) {
      var b = _.next, E = { value: g, prev: _, next: b };
      return _.next = E, b.prev = E, m.length++, E;
    }
    function d(m, _, g) {
      for (var b = _.next, E = 0; E < g && b !== m.tail; E++)
        b = b.next;
      _.next = b, b.prev = _, m.length -= E;
    }
    function p(m) {
      for (var _ = [], g = m.head.next; g !== m.tail; )
        _.push(g.value), g = g.next;
      return _;
    }
    if (!i.document)
      return i.addEventListener && (o.disableWorkerMessageHandler || i.addEventListener("message", function(m) {
        var _ = JSON.parse(m.data), g = _.language, b = _.code, E = _.immediateClose;
        i.postMessage(o.highlight(b, o.languages[g], g)), E && i.close();
      }, !1)), o;
    var v = o.util.currentScript();
    v && (o.filename = v.src, v.hasAttribute("data-manual") && (o.manual = !0));
    function w() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var D = document.readyState;
      D === "loading" || D === "interactive" && v && v.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
    }
    return o;
  }(e);
  n.exports && (n.exports = t), typeof vl < "u" && (vl.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(r, a) {
      var s = {};
      s["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, s.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: s
        }
      };
      o["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var l = {};
      l[r] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return r;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", l);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, r) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [r, "language-" + r],
                inside: t.languages[r]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(i) {
    var r = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + r.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + r.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + r.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + r.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: r,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var a = i.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", r = function(v, w) {
      return "✖ Error " + v + " while fetching file: " + w;
    }, a = "✖ Error: File does not exist or is empty", s = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", l = "loading", c = "loaded", u = "failed", f = "pre[data-src]:not([" + o + '="' + c + '"]):not([' + o + '="' + l + '"])';
    function h(v, w, D) {
      var m = new XMLHttpRequest();
      m.open("GET", v, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? w(m.responseText) : m.status >= 400 ? D(r(m.status, m.statusText)) : D(a));
      }, m.send(null);
    }
    function d(v) {
      var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(v || "");
      if (w) {
        var D = Number(w[1]), m = w[2], _ = w[3];
        return m ? _ ? [D, Number(_)] : [D, void 0] : [D, D];
      }
    }
    t.hooks.add("before-highlightall", function(v) {
      v.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(v) {
      var w = (
        /** @type {HTMLPreElement} */
        v.element
      );
      if (w.matches(f)) {
        v.code = "", w.setAttribute(o, l);
        var D = w.appendChild(document.createElement("CODE"));
        D.textContent = i;
        var m = w.getAttribute("data-src"), _ = v.language;
        if (_ === "none") {
          var g = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          _ = s[g] || g;
        }
        t.util.setLanguage(D, _), t.util.setLanguage(w, _);
        var b = t.plugins.autoloader;
        b && b.loadLanguages(_), h(
          m,
          function(E) {
            w.setAttribute(o, c);
            var k = d(w.getAttribute("data-range"));
            if (k) {
              var P = E.split(/\r\n?|\n/g), A = k[0], R = k[1] == null ? P.length : k[1];
              A < 0 && (A += P.length), A = Math.max(0, Math.min(A - 1, P.length)), R < 0 && (R += P.length), R = Math.max(0, Math.min(R, P.length)), E = P.slice(A, R).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(A + 1));
            }
            D.textContent = E, t.highlightElement(D);
          },
          function(E) {
            w.setAttribute(o, u), D.textContent = E;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(w) {
        for (var D = (w || document).querySelectorAll(f), m = 0, _; _ = D[m++]; )
          t.highlightElement(_);
      }
    };
    var p = !1;
    t.fileHighlight = function() {
      p || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), p = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(d_);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(n) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  n.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, n.languages.tex = n.languages.latex, n.languages.context = n.languages.latex;
})(Prism);
(function(n) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, i = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  n.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: i.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: i.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = n.languages.bash;
  for (var r = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = i.variable[1].inside, s = 0; s < r.length; s++)
    a[r[s]] = n.languages.bash[r[s]];
  n.languages.sh = n.languages.bash, n.languages.shell = n.languages.bash;
})(Prism);
new mf();
const __ = (n) => {
  const e = {};
  for (let t = 0, i = n.length; t < i; t++) {
    const r = n[t];
    for (const a in r)
      e[a] ? e[a] = e[a].concat(r[a]) : e[a] = r[a];
  }
  return e;
}, p_ = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], m_ = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], g_ = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
__([
  Object.fromEntries(p_.map((n) => [n, ["*"]])),
  Object.fromEntries(m_.map((n) => [n, ["svg:*"]])),
  Object.fromEntries(g_.map((n) => [n, ["math:*"]]))
]);
const {
  HtmlTagHydration: Vv,
  SvelteComponent: Wv,
  attr: Xv,
  binding_callbacks: Zv,
  children: Yv,
  claim_element: Kv,
  claim_html_tag: Qv,
  detach: Jv,
  element: ey,
  init: ty,
  insert_hydration: ny,
  noop: iy,
  safe_not_equal: ry,
  toggle_class: ay
} = window.__gradio__svelte__internal, { afterUpdate: sy, tick: oy, onMount: ly } = window.__gradio__svelte__internal, {
  SvelteComponent: uy,
  attr: cy,
  children: fy,
  claim_component: hy,
  claim_element: dy,
  create_component: _y,
  destroy_component: py,
  detach: my,
  element: gy,
  init: by,
  insert_hydration: vy,
  mount_component: yy,
  safe_not_equal: wy,
  transition_in: Dy,
  transition_out: Ey
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cy,
  attr: ky,
  check_outros: Sy,
  children: Ay,
  claim_component: Fy,
  claim_element: Ty,
  claim_space: Iy,
  create_component: $y,
  create_slot: xy,
  destroy_component: Py,
  detach: By,
  element: Oy,
  empty: Ly,
  get_all_dirty_from_scope: Ry,
  get_slot_changes: My,
  group_outros: Ny,
  init: Uy,
  insert_hydration: Hy,
  mount_component: Gy,
  safe_not_equal: zy,
  space: qy,
  toggle_class: jy,
  transition_in: Vy,
  transition_out: Wy,
  update_slot_base: Xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: b_,
  append_hydration: Ua,
  attr: ni,
  children: yl,
  claim_component: v_,
  claim_element: wl,
  claim_space: y_,
  claim_text: w_,
  create_component: D_,
  destroy_component: E_,
  detach: Ha,
  element: Dl,
  init: C_,
  insert_hydration: k_,
  mount_component: S_,
  safe_not_equal: A_,
  set_data: F_,
  space: T_,
  text: I_,
  toggle_class: _n,
  transition_in: $_,
  transition_out: x_
} = window.__gradio__svelte__internal;
function P_(n) {
  let e, t, i, r, a, s, o;
  return i = new /*Icon*/
  n[1]({}), {
    c() {
      e = Dl("label"), t = Dl("span"), D_(i.$$.fragment), r = T_(), a = I_(
        /*label*/
        n[0]
      ), this.h();
    },
    l(l) {
      e = wl(l, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = yl(e);
      t = wl(c, "SPAN", { class: !0 });
      var u = yl(t);
      v_(i.$$.fragment, u), u.forEach(Ha), r = y_(c), a = w_(
        c,
        /*label*/
        n[0]
      ), c.forEach(Ha), this.h();
    },
    h() {
      ni(t, "class", "svelte-13ao5pu"), ni(e, "for", ""), ni(e, "data-testid", "block-label"), ni(e, "dir", s = /*rtl*/
      n[5] ? "rtl" : "ltr"), ni(e, "class", "svelte-13ao5pu"), _n(e, "hide", !/*show_label*/
      n[2]), _n(e, "sr-only", !/*show_label*/
      n[2]), _n(
        e,
        "float",
        /*float*/
        n[4]
      ), _n(
        e,
        "hide-label",
        /*disable*/
        n[3]
      );
    },
    m(l, c) {
      k_(l, e, c), Ua(e, t), S_(i, t, null), Ua(e, r), Ua(e, a), o = !0;
    },
    p(l, [c]) {
      (!o || c & /*label*/
      1) && F_(
        a,
        /*label*/
        l[0]
      ), (!o || c & /*rtl*/
      32 && s !== (s = /*rtl*/
      l[5] ? "rtl" : "ltr")) && ni(e, "dir", s), (!o || c & /*show_label*/
      4) && _n(e, "hide", !/*show_label*/
      l[2]), (!o || c & /*show_label*/
      4) && _n(e, "sr-only", !/*show_label*/
      l[2]), (!o || c & /*float*/
      16) && _n(
        e,
        "float",
        /*float*/
        l[4]
      ), (!o || c & /*disable*/
      8) && _n(
        e,
        "hide-label",
        /*disable*/
        l[3]
      );
    },
    i(l) {
      o || ($_(i.$$.fragment, l), o = !0);
    },
    o(l) {
      x_(i.$$.fragment, l), o = !1;
    },
    d(l) {
      l && Ha(e), E_(i);
    }
  };
}
function B_(n, e, t) {
  let { label: i = null } = e, { Icon: r } = e, { show_label: a = !0 } = e, { disable: s = !1 } = e, { float: o = !0 } = e, { rtl: l = !1 } = e;
  return n.$$set = (c) => {
    "label" in c && t(0, i = c.label), "Icon" in c && t(1, r = c.Icon), "show_label" in c && t(2, a = c.show_label), "disable" in c && t(3, s = c.disable), "float" in c && t(4, o = c.float), "rtl" in c && t(5, l = c.rtl);
  }, [i, r, a, s, o, l];
}
class gf extends b_ {
  constructor(e) {
    super(), C_(this, e, B_, P_, A_, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: O_,
  append_hydration: Hr,
  attr: ln,
  bubble: L_,
  check_outros: R_,
  children: Ps,
  claim_component: M_,
  claim_element: Bs,
  claim_space: El,
  claim_text: N_,
  construct_svelte_component: Cl,
  create_component: kl,
  create_slot: U_,
  destroy_component: Sl,
  detach: qi,
  element: Os,
  get_all_dirty_from_scope: H_,
  get_slot_changes: G_,
  group_outros: z_,
  init: q_,
  insert_hydration: bf,
  listen: j_,
  mount_component: Al,
  safe_not_equal: V_,
  set_data: W_,
  set_style: mr,
  space: Fl,
  text: X_,
  toggle_class: qe,
  transition_in: Ga,
  transition_out: za,
  update_slot_base: Z_
} = window.__gradio__svelte__internal;
function Tl(n) {
  let e, t;
  return {
    c() {
      e = Os("span"), t = X_(
        /*label*/
        n[1]
      ), this.h();
    },
    l(i) {
      e = Bs(i, "SPAN", { class: !0 });
      var r = Ps(e);
      t = N_(
        r,
        /*label*/
        n[1]
      ), r.forEach(qi), this.h();
    },
    h() {
      ln(e, "class", "svelte-qgco6m");
    },
    m(i, r) {
      bf(i, e, r), Hr(e, t);
    },
    p(i, r) {
      r & /*label*/
      2 && W_(
        t,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && qi(e);
    }
  };
}
function Y_(n) {
  let e, t, i, r, a, s, o, l, c = (
    /*show_label*/
    n[2] && Tl(n)
  );
  var u = (
    /*Icon*/
    n[0]
  );
  function f(p, v) {
    return {};
  }
  u && (r = Cl(u, f()));
  const h = (
    /*#slots*/
    n[14].default
  ), d = U_(
    h,
    n,
    /*$$scope*/
    n[13],
    null
  );
  return {
    c() {
      e = Os("button"), c && c.c(), t = Fl(), i = Os("div"), r && kl(r.$$.fragment), a = Fl(), d && d.c(), this.h();
    },
    l(p) {
      e = Bs(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var v = Ps(e);
      c && c.l(v), t = El(v), i = Bs(v, "DIV", { class: !0 });
      var w = Ps(i);
      r && M_(r.$$.fragment, w), a = El(w), d && d.l(w), w.forEach(qi), v.forEach(qi), this.h();
    },
    h() {
      ln(i, "class", "svelte-qgco6m"), qe(
        i,
        "x-small",
        /*size*/
        n[4] === "x-small"
      ), qe(
        i,
        "small",
        /*size*/
        n[4] === "small"
      ), qe(
        i,
        "large",
        /*size*/
        n[4] === "large"
      ), qe(
        i,
        "medium",
        /*size*/
        n[4] === "medium"
      ), e.disabled = /*disabled*/
      n[7], ln(
        e,
        "aria-label",
        /*label*/
        n[1]
      ), ln(
        e,
        "aria-haspopup",
        /*hasPopup*/
        n[8]
      ), ln(
        e,
        "title",
        /*label*/
        n[1]
      ), ln(e, "class", "svelte-qgco6m"), qe(
        e,
        "pending",
        /*pending*/
        n[3]
      ), qe(
        e,
        "padded",
        /*padded*/
        n[5]
      ), qe(
        e,
        "highlight",
        /*highlight*/
        n[6]
      ), qe(
        e,
        "transparent",
        /*transparent*/
        n[9]
      ), mr(e, "color", !/*disabled*/
      n[7] && /*_color*/
      n[11] ? (
        /*_color*/
        n[11]
      ) : "var(--block-label-text-color)"), mr(e, "--bg-color", /*disabled*/
      n[7] ? "auto" : (
        /*background*/
        n[10]
      ));
    },
    m(p, v) {
      bf(p, e, v), c && c.m(e, null), Hr(e, t), Hr(e, i), r && Al(r, i, null), Hr(i, a), d && d.m(i, null), s = !0, o || (l = j_(
        e,
        "click",
        /*click_handler*/
        n[15]
      ), o = !0);
    },
    p(p, [v]) {
      if (/*show_label*/
      p[2] ? c ? c.p(p, v) : (c = Tl(p), c.c(), c.m(e, t)) : c && (c.d(1), c = null), v & /*Icon*/
      1 && u !== (u = /*Icon*/
      p[0])) {
        if (r) {
          z_();
          const w = r;
          za(w.$$.fragment, 1, 0, () => {
            Sl(w, 1);
          }), R_();
        }
        u ? (r = Cl(u, f()), kl(r.$$.fragment), Ga(r.$$.fragment, 1), Al(r, i, a)) : r = null;
      }
      d && d.p && (!s || v & /*$$scope*/
      8192) && Z_(
        d,
        h,
        p,
        /*$$scope*/
        p[13],
        s ? G_(
          h,
          /*$$scope*/
          p[13],
          v,
          null
        ) : H_(
          /*$$scope*/
          p[13]
        ),
        null
      ), (!s || v & /*size*/
      16) && qe(
        i,
        "x-small",
        /*size*/
        p[4] === "x-small"
      ), (!s || v & /*size*/
      16) && qe(
        i,
        "small",
        /*size*/
        p[4] === "small"
      ), (!s || v & /*size*/
      16) && qe(
        i,
        "large",
        /*size*/
        p[4] === "large"
      ), (!s || v & /*size*/
      16) && qe(
        i,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!s || v & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!s || v & /*label*/
      2) && ln(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!s || v & /*hasPopup*/
      256) && ln(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!s || v & /*label*/
      2) && ln(
        e,
        "title",
        /*label*/
        p[1]
      ), (!s || v & /*pending*/
      8) && qe(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!s || v & /*padded*/
      32) && qe(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!s || v & /*highlight*/
      64) && qe(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!s || v & /*transparent*/
      512) && qe(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), v & /*disabled, _color*/
      2176 && mr(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), v & /*disabled, background*/
      1152 && mr(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      s || (r && Ga(r.$$.fragment, p), Ga(d, p), s = !0);
    },
    o(p) {
      r && za(r.$$.fragment, p), za(d, p), s = !1;
    },
    d(p) {
      p && qi(e), c && c.d(), r && Sl(r), d && d.d(p), o = !1, l();
    }
  };
}
function K_(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e, { Icon: s } = e, { label: o = "" } = e, { show_label: l = !1 } = e, { pending: c = !1 } = e, { size: u = "small" } = e, { padded: f = !0 } = e, { highlight: h = !1 } = e, { disabled: d = !1 } = e, { hasPopup: p = !1 } = e, { color: v = "var(--block-label-text-color)" } = e, { transparent: w = !1 } = e, { background: D = "var(--block-background-fill)" } = e;
  function m(_) {
    L_.call(this, n, _);
  }
  return n.$$set = (_) => {
    "Icon" in _ && t(0, s = _.Icon), "label" in _ && t(1, o = _.label), "show_label" in _ && t(2, l = _.show_label), "pending" in _ && t(3, c = _.pending), "size" in _ && t(4, u = _.size), "padded" in _ && t(5, f = _.padded), "highlight" in _ && t(6, h = _.highlight), "disabled" in _ && t(7, d = _.disabled), "hasPopup" in _ && t(8, p = _.hasPopup), "color" in _ && t(12, v = _.color), "transparent" in _ && t(9, w = _.transparent), "background" in _ && t(10, D = _.background), "$$scope" in _ && t(13, a = _.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*highlight, color*/
    4160 && t(11, i = h ? "var(--color-accent)" : v);
  }, [
    s,
    o,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    w,
    D,
    i,
    v,
    a,
    r,
    m
  ];
}
class Dn extends O_ {
  constructor(e) {
    super(), q_(this, e, K_, Y_, V_, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Q_,
  append_hydration: J_,
  attr: qa,
  binding_callbacks: ep,
  children: Il,
  claim_element: $l,
  create_slot: tp,
  detach: ja,
  element: xl,
  get_all_dirty_from_scope: np,
  get_slot_changes: ip,
  init: rp,
  insert_hydration: ap,
  safe_not_equal: sp,
  toggle_class: pn,
  transition_in: op,
  transition_out: lp,
  update_slot_base: up
} = window.__gradio__svelte__internal;
function cp(n) {
  let e, t, i;
  const r = (
    /*#slots*/
    n[5].default
  ), a = tp(
    r,
    n,
    /*$$scope*/
    n[4],
    null
  );
  return {
    c() {
      e = xl("div"), t = xl("div"), a && a.c(), this.h();
    },
    l(s) {
      e = $l(s, "DIV", { class: !0, "aria-label": !0 });
      var o = Il(e);
      t = $l(o, "DIV", { class: !0 });
      var l = Il(t);
      a && a.l(l), l.forEach(ja), o.forEach(ja), this.h();
    },
    h() {
      qa(t, "class", "icon svelte-3w3rth"), qa(e, "class", "empty svelte-3w3rth"), qa(e, "aria-label", "Empty value"), pn(
        e,
        "small",
        /*size*/
        n[0] === "small"
      ), pn(
        e,
        "large",
        /*size*/
        n[0] === "large"
      ), pn(
        e,
        "unpadded_box",
        /*unpadded_box*/
        n[1]
      ), pn(
        e,
        "small_parent",
        /*parent_height*/
        n[3]
      );
    },
    m(s, o) {
      ap(s, e, o), J_(e, t), a && a.m(t, null), n[6](e), i = !0;
    },
    p(s, [o]) {
      a && a.p && (!i || o & /*$$scope*/
      16) && up(
        a,
        r,
        s,
        /*$$scope*/
        s[4],
        i ? ip(
          r,
          /*$$scope*/
          s[4],
          o,
          null
        ) : np(
          /*$$scope*/
          s[4]
        ),
        null
      ), (!i || o & /*size*/
      1) && pn(
        e,
        "small",
        /*size*/
        s[0] === "small"
      ), (!i || o & /*size*/
      1) && pn(
        e,
        "large",
        /*size*/
        s[0] === "large"
      ), (!i || o & /*unpadded_box*/
      2) && pn(
        e,
        "unpadded_box",
        /*unpadded_box*/
        s[1]
      ), (!i || o & /*parent_height*/
      8) && pn(
        e,
        "small_parent",
        /*parent_height*/
        s[3]
      );
    },
    i(s) {
      i || (op(a, s), i = !0);
    },
    o(s) {
      lp(a, s), i = !1;
    },
    d(s) {
      s && ja(e), a && a.d(s), n[6](null);
    }
  };
}
function fp(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e, { size: s = "small" } = e, { unpadded_box: o = !1 } = e, l;
  function c(f) {
    var h;
    if (!f) return !1;
    const { height: d } = f.getBoundingClientRect(), { height: p } = ((h = f.parentElement) === null || h === void 0 ? void 0 : h.getBoundingClientRect()) || { height: d };
    return d > p + 2;
  }
  function u(f) {
    ep[f ? "unshift" : "push"](() => {
      l = f, t(2, l);
    });
  }
  return n.$$set = (f) => {
    "size" in f && t(0, s = f.size), "unpadded_box" in f && t(1, o = f.unpadded_box), "$$scope" in f && t(4, a = f.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty & /*el*/
    4 && t(3, i = c(l));
  }, [s, o, l, i, a, r, u];
}
class hp extends Q_ {
  constructor(e) {
    super(), rp(this, e, fp, cp, sp, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: Zy,
  append_hydration: Yy,
  attr: Ky,
  children: Qy,
  claim_svg_element: Jy,
  detach: ew,
  init: tw,
  insert_hydration: nw,
  noop: iw,
  safe_not_equal: rw,
  svg_element: aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: sw,
  append_hydration: ow,
  attr: lw,
  children: uw,
  claim_svg_element: cw,
  detach: fw,
  init: hw,
  insert_hydration: dw,
  noop: _w,
  safe_not_equal: pw,
  svg_element: mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: gw,
  append_hydration: bw,
  attr: vw,
  children: yw,
  claim_svg_element: ww,
  detach: Dw,
  init: Ew,
  insert_hydration: Cw,
  noop: kw,
  safe_not_equal: Sw,
  svg_element: Aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fw,
  append_hydration: Tw,
  attr: Iw,
  children: $w,
  claim_svg_element: xw,
  detach: Pw,
  init: Bw,
  insert_hydration: Ow,
  noop: Lw,
  safe_not_equal: Rw,
  svg_element: Mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nw,
  append_hydration: Uw,
  attr: Hw,
  children: Gw,
  claim_svg_element: zw,
  detach: qw,
  init: jw,
  insert_hydration: Vw,
  noop: Ww,
  safe_not_equal: Xw,
  svg_element: Zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yw,
  append_hydration: Kw,
  attr: Qw,
  children: Jw,
  claim_svg_element: eD,
  detach: tD,
  init: nD,
  insert_hydration: iD,
  noop: rD,
  safe_not_equal: aD,
  svg_element: sD
} = window.__gradio__svelte__internal, {
  SvelteComponent: oD,
  append_hydration: lD,
  attr: uD,
  children: cD,
  claim_svg_element: fD,
  detach: hD,
  init: dD,
  insert_hydration: _D,
  noop: pD,
  safe_not_equal: mD,
  svg_element: gD
} = window.__gradio__svelte__internal, {
  SvelteComponent: bD,
  append_hydration: vD,
  attr: yD,
  children: wD,
  claim_svg_element: DD,
  detach: ED,
  init: CD,
  insert_hydration: kD,
  noop: SD,
  safe_not_equal: AD,
  svg_element: FD
} = window.__gradio__svelte__internal, {
  SvelteComponent: TD,
  append_hydration: ID,
  attr: $D,
  children: xD,
  claim_svg_element: PD,
  detach: BD,
  init: OD,
  insert_hydration: LD,
  noop: RD,
  safe_not_equal: MD,
  svg_element: ND
} = window.__gradio__svelte__internal, {
  SvelteComponent: UD,
  append_hydration: HD,
  attr: GD,
  children: zD,
  claim_svg_element: qD,
  detach: jD,
  init: VD,
  insert_hydration: WD,
  noop: XD,
  safe_not_equal: ZD,
  svg_element: YD
} = window.__gradio__svelte__internal, {
  SvelteComponent: KD,
  append_hydration: QD,
  attr: JD,
  children: e3,
  claim_svg_element: t3,
  detach: n3,
  init: i3,
  insert_hydration: r3,
  noop: a3,
  safe_not_equal: s3,
  svg_element: o3
} = window.__gradio__svelte__internal, {
  SvelteComponent: l3,
  append_hydration: u3,
  attr: c3,
  children: f3,
  claim_svg_element: h3,
  detach: d3,
  init: _3,
  insert_hydration: p3,
  noop: m3,
  safe_not_equal: g3,
  svg_element: b3
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: Va,
  attr: kt,
  children: gr,
  claim_svg_element: br,
  detach: Ai,
  init: _p,
  insert_hydration: pp,
  noop: Wa,
  safe_not_equal: mp,
  set_style: zt,
  svg_element: vr
} = window.__gradio__svelte__internal;
function gp(n) {
  let e, t, i, r;
  return {
    c() {
      e = vr("svg"), t = vr("g"), i = vr("path"), r = vr("path"), this.h();
    },
    l(a) {
      e = br(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var s = gr(e);
      t = br(s, "g", { transform: !0 });
      var o = gr(t);
      i = br(o, "path", { d: !0, style: !0 }), gr(i).forEach(Ai), o.forEach(Ai), r = br(s, "path", { d: !0, style: !0 }), gr(r).forEach(Ai), s.forEach(Ai), this.h();
    },
    h() {
      kt(i, "d", "M18,6L6.087,17.913"), zt(i, "fill", "none"), zt(i, "fill-rule", "nonzero"), zt(i, "stroke-width", "2px"), kt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), kt(r, "d", "M4.364,4.364L19.636,19.636"), zt(r, "fill", "none"), zt(r, "fill-rule", "nonzero"), zt(r, "stroke-width", "2px"), kt(e, "width", "100%"), kt(e, "height", "100%"), kt(e, "viewBox", "0 0 24 24"), kt(e, "version", "1.1"), kt(e, "xmlns", "http://www.w3.org/2000/svg"), kt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), kt(e, "xml:space", "preserve"), kt(e, "stroke", "currentColor"), zt(e, "fill-rule", "evenodd"), zt(e, "clip-rule", "evenodd"), zt(e, "stroke-linecap", "round"), zt(e, "stroke-linejoin", "round");
    },
    m(a, s) {
      pp(a, e, s), Va(e, t), Va(t, i), Va(e, r);
    },
    p: Wa,
    i: Wa,
    o: Wa,
    d(a) {
      a && Ai(e);
    }
  };
}
class vf extends dp {
  constructor(e) {
    super(), _p(this, e, null, gp, mp, {});
  }
}
const {
  SvelteComponent: v3,
  append_hydration: y3,
  attr: w3,
  children: D3,
  claim_svg_element: E3,
  detach: C3,
  init: k3,
  insert_hydration: S3,
  noop: A3,
  safe_not_equal: F3,
  svg_element: T3
} = window.__gradio__svelte__internal, {
  SvelteComponent: I3,
  append_hydration: $3,
  attr: x3,
  children: P3,
  claim_svg_element: B3,
  detach: O3,
  init: L3,
  insert_hydration: R3,
  noop: M3,
  safe_not_equal: N3,
  svg_element: U3
} = window.__gradio__svelte__internal, {
  SvelteComponent: H3,
  append_hydration: G3,
  attr: z3,
  children: q3,
  claim_svg_element: j3,
  detach: V3,
  init: W3,
  insert_hydration: X3,
  noop: Z3,
  safe_not_equal: Y3,
  svg_element: K3
} = window.__gradio__svelte__internal, {
  SvelteComponent: bp,
  append_hydration: vp,
  attr: En,
  children: Pl,
  claim_svg_element: Bl,
  detach: Xa,
  init: yp,
  insert_hydration: wp,
  noop: Za,
  safe_not_equal: Dp,
  svg_element: Ol
} = window.__gradio__svelte__internal;
function Ep(n) {
  let e, t;
  return {
    c() {
      e = Ol("svg"), t = Ol("path"), this.h();
    },
    l(i) {
      e = Bl(i, "svg", {
        id: !0,
        xmlns: !0,
        viewBox: !0,
        width: !0,
        height: !0
      });
      var r = Pl(e);
      t = Bl(r, "path", { d: !0, fill: !0 }), Pl(t).forEach(Xa), r.forEach(Xa), this.h();
    },
    h() {
      En(t, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), En(t, "fill", "currentColor"), En(e, "id", "icon"), En(e, "xmlns", "http://www.w3.org/2000/svg"), En(e, "viewBox", "0 0 32 32"), En(e, "width", "100%"), En(e, "height", "100%");
    },
    m(i, r) {
      wp(i, e, r), vp(e, t);
    },
    p: Za,
    i: Za,
    o: Za,
    d(i) {
      i && Xa(e);
    }
  };
}
class Cp extends bp {
  constructor(e) {
    super(), yp(this, e, null, Ep, Dp, {});
  }
}
const {
  SvelteComponent: Q3,
  append_hydration: J3,
  attr: eE,
  children: tE,
  claim_svg_element: nE,
  detach: iE,
  init: rE,
  insert_hydration: aE,
  noop: sE,
  safe_not_equal: oE,
  svg_element: lE
} = window.__gradio__svelte__internal, {
  SvelteComponent: uE,
  append_hydration: cE,
  attr: fE,
  children: hE,
  claim_svg_element: dE,
  detach: _E,
  init: pE,
  insert_hydration: mE,
  noop: gE,
  safe_not_equal: bE,
  svg_element: vE
} = window.__gradio__svelte__internal, {
  SvelteComponent: kp,
  append_hydration: Sp,
  attr: ii,
  children: Ll,
  claim_svg_element: Rl,
  detach: Ya,
  init: Ap,
  insert_hydration: Fp,
  noop: Ka,
  safe_not_equal: Tp,
  svg_element: Ml
} = window.__gradio__svelte__internal;
function Ip(n) {
  let e, t;
  return {
    c() {
      e = Ml("svg"), t = Ml("path"), this.h();
    },
    l(i) {
      e = Rl(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var r = Ll(e);
      t = Rl(r, "path", { fill: !0, d: !0 }), Ll(t).forEach(Ya), r.forEach(Ya), this.h();
    },
    h() {
      ii(t, "fill", "currentColor"), ii(t, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), ii(e, "xmlns", "http://www.w3.org/2000/svg"), ii(e, "width", "100%"), ii(e, "height", "100%"), ii(e, "viewBox", "0 0 32 32");
    },
    m(i, r) {
      Fp(i, e, r), Sp(e, t);
    },
    p: Ka,
    i: Ka,
    o: Ka,
    d(i) {
      i && Ya(e);
    }
  };
}
class $p extends kp {
  constructor(e) {
    super(), Ap(this, e, null, Ip, Tp, {});
  }
}
const {
  SvelteComponent: yE,
  append_hydration: wE,
  attr: DE,
  children: EE,
  claim_svg_element: CE,
  detach: kE,
  init: SE,
  insert_hydration: AE,
  noop: FE,
  safe_not_equal: TE,
  svg_element: IE
} = window.__gradio__svelte__internal, {
  SvelteComponent: $E,
  append_hydration: xE,
  attr: PE,
  children: BE,
  claim_svg_element: OE,
  detach: LE,
  init: RE,
  insert_hydration: ME,
  noop: NE,
  safe_not_equal: UE,
  svg_element: HE
} = window.__gradio__svelte__internal, {
  SvelteComponent: GE,
  append_hydration: zE,
  attr: qE,
  children: jE,
  claim_svg_element: VE,
  detach: WE,
  init: XE,
  insert_hydration: ZE,
  noop: YE,
  safe_not_equal: KE,
  svg_element: QE
} = window.__gradio__svelte__internal, {
  SvelteComponent: JE,
  append_hydration: eC,
  attr: tC,
  children: nC,
  claim_svg_element: iC,
  detach: rC,
  init: aC,
  insert_hydration: sC,
  noop: oC,
  safe_not_equal: lC,
  svg_element: uC
} = window.__gradio__svelte__internal, {
  SvelteComponent: cC,
  append_hydration: fC,
  attr: hC,
  children: dC,
  claim_svg_element: _C,
  detach: pC,
  init: mC,
  insert_hydration: gC,
  noop: bC,
  safe_not_equal: vC,
  svg_element: yC
} = window.__gradio__svelte__internal, {
  SvelteComponent: wC,
  append_hydration: DC,
  attr: EC,
  children: CC,
  claim_svg_element: kC,
  detach: SC,
  init: AC,
  insert_hydration: FC,
  noop: TC,
  safe_not_equal: IC,
  svg_element: $C
} = window.__gradio__svelte__internal, {
  SvelteComponent: xp,
  append_hydration: Pp,
  attr: St,
  children: Nl,
  claim_svg_element: Ul,
  detach: Qa,
  init: Bp,
  insert_hydration: Op,
  noop: Ja,
  safe_not_equal: Lp,
  svg_element: Hl
} = window.__gradio__svelte__internal;
function Rp(n) {
  let e, t;
  return {
    c() {
      e = Hl("svg"), t = Hl("path"), this.h();
    },
    l(i) {
      e = Ul(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0,
        width: !0,
        height: !0
      });
      var r = Nl(e);
      t = Ul(r, "path", { d: !0 });
      var a = Nl(t);
      a.forEach(Qa), r.forEach(Qa), this.h();
    },
    h() {
      St(t, "d", "M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"), St(e, "xmlns", "http://www.w3.org/2000/svg"), St(e, "viewBox", "0 0 24 24"), St(e, "fill", "none"), St(e, "stroke", "currentColor"), St(e, "stroke-width", "2"), St(e, "stroke-linecap", "round"), St(e, "stroke-linejoin", "round"), St(e, "class", "feather feather-maximize"), St(e, "width", "100%"), St(e, "height", "100%");
    },
    m(i, r) {
      Op(i, e, r), Pp(e, t);
    },
    p: Ja,
    i: Ja,
    o: Ja,
    d(i) {
      i && Qa(e);
    }
  };
}
class Mp extends xp {
  constructor(e) {
    super(), Bp(this, e, null, Rp, Lp, {});
  }
}
const {
  SvelteComponent: xC,
  append_hydration: PC,
  attr: BC,
  children: OC,
  claim_svg_element: LC,
  detach: RC,
  init: MC,
  insert_hydration: NC,
  noop: UC,
  safe_not_equal: HC,
  svg_element: GC
} = window.__gradio__svelte__internal, {
  SvelteComponent: zC,
  append_hydration: qC,
  attr: jC,
  children: VC,
  claim_svg_element: WC,
  detach: XC,
  init: ZC,
  insert_hydration: YC,
  noop: KC,
  safe_not_equal: QC,
  svg_element: JC
} = window.__gradio__svelte__internal, {
  SvelteComponent: Np,
  append_hydration: Up,
  attr: ct,
  children: Gl,
  claim_svg_element: zl,
  detach: es,
  init: Hp,
  insert_hydration: Gp,
  noop: ts,
  safe_not_equal: zp,
  svg_element: ql
} = window.__gradio__svelte__internal;
function qp(n) {
  let e, t;
  return {
    c() {
      e = ql("svg"), t = ql("path"), this.h();
    },
    l(i) {
      e = zl(i, "svg", {
        fill: !0,
        stroke: !0,
        viewBox: !0,
        width: !0,
        height: !0,
        xmlns: !0,
        "aria-hidden": !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      });
      var r = Gl(e);
      t = zl(r, "path", {
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        d: !0
      }), Gl(t).forEach(es), r.forEach(es), this.h();
    },
    h() {
      ct(t, "stroke-linecap", "round"), ct(t, "stroke-linejoin", "round"), ct(t, "d", "M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"), ct(e, "fill", "none"), ct(e, "stroke", "currentColor"), ct(e, "viewBox", "0 0 24 24"), ct(e, "width", "100%"), ct(e, "height", "100%"), ct(e, "xmlns", "http://www.w3.org/2000/svg"), ct(e, "aria-hidden", "true"), ct(e, "stroke-width", "2"), ct(e, "stroke-linecap", "round"), ct(e, "stroke-linejoin", "round");
    },
    m(i, r) {
      Gp(i, e, r), Up(e, t);
    },
    p: ts,
    i: ts,
    o: ts,
    d(i) {
      i && es(e);
    }
  };
}
class yf extends Np {
  constructor(e) {
    super(), Hp(this, e, null, qp, zp, {});
  }
}
const {
  SvelteComponent: ek,
  append_hydration: tk,
  attr: nk,
  children: ik,
  claim_svg_element: rk,
  detach: ak,
  init: sk,
  insert_hydration: ok,
  noop: lk,
  safe_not_equal: uk,
  svg_element: ck
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: ns,
  attr: Te,
  children: yr,
  claim_svg_element: wr,
  detach: Fi,
  init: Vp,
  insert_hydration: Wp,
  noop: is,
  safe_not_equal: Xp,
  svg_element: Dr
} = window.__gradio__svelte__internal;
function Zp(n) {
  let e, t, i, r;
  return {
    c() {
      e = Dr("svg"), t = Dr("rect"), i = Dr("circle"), r = Dr("polyline"), this.h();
    },
    l(a) {
      e = wr(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var s = yr(e);
      t = wr(s, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), yr(t).forEach(Fi), i = wr(s, "circle", { cx: !0, cy: !0, r: !0 }), yr(i).forEach(Fi), r = wr(s, "polyline", { points: !0 }), yr(r).forEach(Fi), s.forEach(Fi), this.h();
    },
    h() {
      Te(t, "x", "3"), Te(t, "y", "3"), Te(t, "width", "18"), Te(t, "height", "18"), Te(t, "rx", "2"), Te(t, "ry", "2"), Te(i, "cx", "8.5"), Te(i, "cy", "8.5"), Te(i, "r", "1.5"), Te(r, "points", "21 15 16 10 5 21"), Te(e, "xmlns", "http://www.w3.org/2000/svg"), Te(e, "width", "100%"), Te(e, "height", "100%"), Te(e, "viewBox", "0 0 24 24"), Te(e, "fill", "none"), Te(e, "stroke", "currentColor"), Te(e, "stroke-width", "1.5"), Te(e, "stroke-linecap", "round"), Te(e, "stroke-linejoin", "round"), Te(e, "class", "feather feather-image");
    },
    m(a, s) {
      Wp(a, e, s), ns(e, t), ns(e, i), ns(e, r);
    },
    p: is,
    i: is,
    o: is,
    d(a) {
      a && Fi(e);
    }
  };
}
let Ao = class extends jp {
  constructor(e) {
    super(), Vp(this, e, null, Zp, Xp, {});
  }
};
const {
  SvelteComponent: Yp,
  append_hydration: Kp,
  attr: ri,
  children: jl,
  claim_svg_element: Vl,
  detach: rs,
  init: Qp,
  insert_hydration: Jp,
  noop: as,
  safe_not_equal: em,
  svg_element: Wl
} = window.__gradio__svelte__internal;
function tm(n) {
  let e, t;
  return {
    c() {
      e = Wl("svg"), t = Wl("path"), this.h();
    },
    l(i) {
      e = Vl(i, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var r = jl(e);
      t = Vl(r, "path", { fill: !0, d: !0 }), jl(t).forEach(rs), r.forEach(rs), this.h();
    },
    h() {
      ri(t, "fill", "currentColor"), ri(t, "d", "M200 32h-36.26a47.92 47.92 0 0 0-71.48 0H56a16 16 0 0 0-16 16v168a16 16 0 0 0 16 16h144a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16m-72 0a32 32 0 0 1 32 32H96a32 32 0 0 1 32-32m72 184H56V48h26.75A47.9 47.9 0 0 0 80 64v8a8 8 0 0 0 8 8h80a8 8 0 0 0 8-8v-8a47.9 47.9 0 0 0-2.75-16H200Z"), ri(e, "xmlns", "http://www.w3.org/2000/svg"), ri(e, "width", "100%"), ri(e, "height", "100%"), ri(e, "viewBox", "0 0 256 256");
    },
    m(i, r) {
      Jp(i, e, r), Kp(e, t);
    },
    p: as,
    i: as,
    o: as,
    d(i) {
      i && rs(e);
    }
  };
}
class nm extends Yp {
  constructor(e) {
    super(), Qp(this, e, null, tm, em, {});
  }
}
const {
  SvelteComponent: hk,
  append_hydration: dk,
  attr: _k,
  children: pk,
  claim_svg_element: mk,
  detach: gk,
  init: bk,
  insert_hydration: vk,
  noop: yk,
  safe_not_equal: wk,
  svg_element: Dk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ek,
  append_hydration: Ck,
  attr: kk,
  children: Sk,
  claim_svg_element: Ak,
  detach: Fk,
  init: Tk,
  insert_hydration: Ik,
  noop: $k,
  safe_not_equal: xk,
  svg_element: Pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bk,
  append_hydration: Ok,
  attr: Lk,
  children: Rk,
  claim_svg_element: Mk,
  detach: Nk,
  init: Uk,
  insert_hydration: Hk,
  noop: Gk,
  safe_not_equal: zk,
  svg_element: qk
} = window.__gradio__svelte__internal, {
  SvelteComponent: jk,
  append_hydration: Vk,
  attr: Wk,
  children: Xk,
  claim_svg_element: Zk,
  detach: Yk,
  init: Kk,
  insert_hydration: Qk,
  noop: Jk,
  safe_not_equal: eS,
  svg_element: tS
} = window.__gradio__svelte__internal, {
  SvelteComponent: nS,
  append_hydration: iS,
  attr: rS,
  children: aS,
  claim_svg_element: sS,
  detach: oS,
  init: lS,
  insert_hydration: uS,
  noop: cS,
  safe_not_equal: fS,
  svg_element: hS
} = window.__gradio__svelte__internal, {
  SvelteComponent: im,
  append_hydration: rm,
  attr: At,
  children: Xl,
  claim_svg_element: Zl,
  detach: ss,
  init: am,
  insert_hydration: sm,
  noop: os,
  safe_not_equal: om,
  svg_element: Yl
} = window.__gradio__svelte__internal;
function lm(n) {
  let e, t;
  return {
    c() {
      e = Yl("svg"), t = Yl("path"), this.h();
    },
    l(i) {
      e = Zl(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0,
        width: !0,
        height: !0
      });
      var r = Xl(e);
      t = Zl(r, "path", { d: !0 }), Xl(t).forEach(ss), r.forEach(ss), this.h();
    },
    h() {
      At(t, "d", "M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"), At(e, "xmlns", "http://www.w3.org/2000/svg"), At(e, "viewBox", "0 0 24 24"), At(e, "fill", "none"), At(e, "stroke", "currentColor"), At(e, "stroke-width", "2"), At(e, "stroke-linecap", "round"), At(e, "stroke-linejoin", "round"), At(e, "class", "feather feather-minimize"), At(e, "width", "100%"), At(e, "height", "100%");
    },
    m(i, r) {
      sm(i, e, r), rm(e, t);
    },
    p: os,
    i: os,
    o: os,
    d(i) {
      i && ss(e);
    }
  };
}
class um extends im {
  constructor(e) {
    super(), am(this, e, null, lm, om, {});
  }
}
const {
  SvelteComponent: dS,
  append_hydration: _S,
  attr: pS,
  children: mS,
  claim_svg_element: gS,
  detach: bS,
  init: vS,
  insert_hydration: yS,
  noop: wS,
  safe_not_equal: DS,
  svg_element: ES
} = window.__gradio__svelte__internal, {
  SvelteComponent: CS,
  append_hydration: kS,
  attr: SS,
  children: AS,
  claim_svg_element: FS,
  detach: TS,
  init: IS,
  insert_hydration: $S,
  noop: xS,
  safe_not_equal: PS,
  svg_element: BS
} = window.__gradio__svelte__internal, {
  SvelteComponent: OS,
  append_hydration: LS,
  attr: RS,
  children: MS,
  claim_svg_element: NS,
  detach: US,
  init: HS,
  insert_hydration: GS,
  noop: zS,
  safe_not_equal: qS,
  svg_element: jS
} = window.__gradio__svelte__internal, {
  SvelteComponent: VS,
  append_hydration: WS,
  attr: XS,
  children: ZS,
  claim_svg_element: YS,
  detach: KS,
  init: QS,
  insert_hydration: JS,
  noop: e4,
  safe_not_equal: t4,
  svg_element: n4
} = window.__gradio__svelte__internal, {
  SvelteComponent: i4,
  append_hydration: r4,
  attr: a4,
  children: s4,
  claim_svg_element: o4,
  detach: l4,
  init: u4,
  insert_hydration: c4,
  noop: f4,
  safe_not_equal: h4,
  svg_element: d4
} = window.__gradio__svelte__internal, {
  SvelteComponent: _4,
  append_hydration: p4,
  attr: m4,
  children: g4,
  claim_svg_element: b4,
  detach: v4,
  init: y4,
  insert_hydration: w4,
  noop: D4,
  safe_not_equal: E4,
  svg_element: C4
} = window.__gradio__svelte__internal, {
  SvelteComponent: k4,
  append_hydration: S4,
  attr: A4,
  children: F4,
  claim_svg_element: T4,
  detach: I4,
  init: $4,
  insert_hydration: x4,
  noop: P4,
  safe_not_equal: B4,
  svg_element: O4
} = window.__gradio__svelte__internal, {
  SvelteComponent: L4,
  append_hydration: R4,
  attr: M4,
  children: N4,
  claim_svg_element: U4,
  detach: H4,
  init: G4,
  insert_hydration: z4,
  noop: q4,
  safe_not_equal: j4,
  svg_element: V4
} = window.__gradio__svelte__internal, {
  SvelteComponent: W4,
  append_hydration: X4,
  attr: Z4,
  children: Y4,
  claim_svg_element: K4,
  detach: Q4,
  init: J4,
  insert_hydration: eA,
  noop: tA,
  safe_not_equal: nA,
  set_style: iA,
  svg_element: rA
} = window.__gradio__svelte__internal, {
  SvelteComponent: aA,
  append_hydration: sA,
  attr: oA,
  children: lA,
  claim_svg_element: uA,
  detach: cA,
  init: fA,
  insert_hydration: hA,
  noop: dA,
  safe_not_equal: _A,
  svg_element: pA
} = window.__gradio__svelte__internal, {
  SvelteComponent: mA,
  append_hydration: gA,
  attr: bA,
  children: vA,
  claim_svg_element: yA,
  detach: wA,
  init: DA,
  insert_hydration: EA,
  noop: CA,
  safe_not_equal: kA,
  svg_element: SA
} = window.__gradio__svelte__internal, {
  SvelteComponent: AA,
  append_hydration: FA,
  attr: TA,
  children: IA,
  claim_svg_element: $A,
  detach: xA,
  init: PA,
  insert_hydration: BA,
  noop: OA,
  safe_not_equal: LA,
  svg_element: RA
} = window.__gradio__svelte__internal, {
  SvelteComponent: MA,
  append_hydration: NA,
  attr: UA,
  children: HA,
  claim_svg_element: GA,
  detach: zA,
  init: qA,
  insert_hydration: jA,
  noop: VA,
  safe_not_equal: WA,
  svg_element: XA
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZA,
  append_hydration: YA,
  attr: KA,
  children: QA,
  claim_svg_element: JA,
  detach: eF,
  init: tF,
  insert_hydration: nF,
  noop: iF,
  safe_not_equal: rF,
  svg_element: aF
} = window.__gradio__svelte__internal, {
  SvelteComponent: sF,
  append_hydration: oF,
  attr: lF,
  children: uF,
  claim_svg_element: cF,
  detach: fF,
  init: hF,
  insert_hydration: dF,
  noop: _F,
  safe_not_equal: pF,
  svg_element: mF
} = window.__gradio__svelte__internal, {
  SvelteComponent: gF,
  append_hydration: bF,
  attr: vF,
  children: yF,
  claim_svg_element: wF,
  detach: DF,
  init: EF,
  insert_hydration: CF,
  noop: kF,
  safe_not_equal: SF,
  svg_element: AF
} = window.__gradio__svelte__internal, {
  SvelteComponent: FF,
  append_hydration: TF,
  attr: IF,
  children: $F,
  claim_svg_element: xF,
  detach: PF,
  init: BF,
  insert_hydration: OF,
  noop: LF,
  safe_not_equal: RF,
  svg_element: MF
} = window.__gradio__svelte__internal, {
  SvelteComponent: NF,
  append_hydration: UF,
  attr: HF,
  children: GF,
  claim_svg_element: zF,
  claim_text: qF,
  detach: jF,
  init: VF,
  insert_hydration: WF,
  noop: XF,
  safe_not_equal: ZF,
  svg_element: YF,
  text: KF
} = window.__gradio__svelte__internal, {
  SvelteComponent: QF,
  append_hydration: JF,
  attr: eT,
  children: tT,
  claim_svg_element: nT,
  detach: iT,
  init: rT,
  insert_hydration: aT,
  noop: sT,
  safe_not_equal: oT,
  svg_element: lT
} = window.__gradio__svelte__internal, {
  SvelteComponent: uT,
  append_hydration: cT,
  attr: fT,
  children: hT,
  claim_svg_element: dT,
  detach: _T,
  init: pT,
  insert_hydration: mT,
  noop: gT,
  safe_not_equal: bT,
  svg_element: vT
} = window.__gradio__svelte__internal, {
  SvelteComponent: yT,
  append_hydration: wT,
  attr: DT,
  children: ET,
  claim_svg_element: CT,
  detach: kT,
  init: ST,
  insert_hydration: AT,
  noop: FT,
  safe_not_equal: TT,
  svg_element: IT
} = window.__gradio__svelte__internal, {
  SvelteComponent: cm,
  append_hydration: ls,
  attr: je,
  children: Er,
  claim_svg_element: Cr,
  detach: Ti,
  init: fm,
  insert_hydration: hm,
  noop: us,
  safe_not_equal: dm,
  svg_element: kr
} = window.__gradio__svelte__internal;
function _m(n) {
  let e, t, i, r;
  return {
    c() {
      e = kr("svg"), t = kr("path"), i = kr("polyline"), r = kr("line"), this.h();
    },
    l(a) {
      e = Cr(a, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var s = Er(e);
      t = Cr(s, "path", { d: !0 }), Er(t).forEach(Ti), i = Cr(s, "polyline", { points: !0 }), Er(i).forEach(Ti), r = Cr(s, "line", { x1: !0, y1: !0, x2: !0, y2: !0 }), Er(r).forEach(Ti), s.forEach(Ti), this.h();
    },
    h() {
      je(t, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), je(i, "points", "17 8 12 3 7 8"), je(r, "x1", "12"), je(r, "y1", "3"), je(r, "x2", "12"), je(r, "y2", "15"), je(e, "xmlns", "http://www.w3.org/2000/svg"), je(e, "width", "90%"), je(e, "height", "90%"), je(e, "viewBox", "0 0 24 24"), je(e, "fill", "none"), je(e, "stroke", "currentColor"), je(e, "stroke-width", "2"), je(e, "stroke-linecap", "round"), je(e, "stroke-linejoin", "round"), je(e, "class", "feather feather-upload");
    },
    m(a, s) {
      hm(a, e, s), ls(e, t), ls(e, i), ls(e, r);
    },
    p: us,
    i: us,
    o: us,
    d(a) {
      a && Ti(e);
    }
  };
}
let pm = class extends cm {
  constructor(e) {
    super(), fm(this, e, null, _m, dm, {});
  }
};
const {
  SvelteComponent: xT,
  append_hydration: PT,
  attr: BT,
  children: OT,
  claim_svg_element: LT,
  detach: RT,
  init: MT,
  insert_hydration: NT,
  noop: UT,
  safe_not_equal: HT,
  svg_element: GT
} = window.__gradio__svelte__internal, {
  SvelteComponent: zT,
  append_hydration: qT,
  attr: jT,
  children: VT,
  claim_svg_element: WT,
  detach: XT,
  init: ZT,
  insert_hydration: YT,
  noop: KT,
  safe_not_equal: QT,
  svg_element: JT
} = window.__gradio__svelte__internal, {
  SvelteComponent: e5,
  append_hydration: t5,
  attr: n5,
  children: i5,
  claim_svg_element: r5,
  detach: a5,
  init: s5,
  insert_hydration: o5,
  noop: l5,
  safe_not_equal: u5,
  svg_element: c5
} = window.__gradio__svelte__internal, {
  SvelteComponent: f5,
  append_hydration: h5,
  attr: d5,
  children: _5,
  claim_svg_element: p5,
  claim_text: m5,
  detach: g5,
  init: b5,
  insert_hydration: v5,
  noop: y5,
  safe_not_equal: w5,
  svg_element: D5,
  text: E5
} = window.__gradio__svelte__internal, {
  SvelteComponent: C5,
  append_hydration: k5,
  attr: S5,
  children: A5,
  claim_svg_element: F5,
  claim_text: T5,
  detach: I5,
  init: $5,
  insert_hydration: x5,
  noop: P5,
  safe_not_equal: B5,
  svg_element: O5,
  text: L5
} = window.__gradio__svelte__internal, {
  SvelteComponent: R5,
  append_hydration: M5,
  attr: N5,
  children: U5,
  claim_svg_element: H5,
  claim_text: G5,
  detach: z5,
  init: q5,
  insert_hydration: j5,
  noop: V5,
  safe_not_equal: W5,
  svg_element: X5,
  text: Z5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y5,
  append_hydration: K5,
  attr: Q5,
  children: J5,
  claim_svg_element: e8,
  detach: t8,
  init: n8,
  insert_hydration: i8,
  noop: r8,
  safe_not_equal: a8,
  svg_element: s8
} = window.__gradio__svelte__internal, {
  SvelteComponent: o8,
  append_hydration: l8,
  attr: u8,
  children: c8,
  claim_svg_element: f8,
  detach: h8,
  init: d8,
  insert_hydration: _8,
  noop: p8,
  safe_not_equal: m8,
  svg_element: g8
} = window.__gradio__svelte__internal, {
  SvelteComponent: b8,
  append_hydration: v8,
  attr: y8,
  children: w8,
  claim_svg_element: D8,
  detach: E8,
  init: C8,
  insert_hydration: k8,
  noop: S8,
  safe_not_equal: A8,
  svg_element: F8
} = window.__gradio__svelte__internal, {
  SvelteComponent: T8,
  append_hydration: I8,
  attr: $8,
  children: x8,
  claim_svg_element: P8,
  detach: B8,
  init: O8,
  insert_hydration: L8,
  noop: R8,
  safe_not_equal: M8,
  svg_element: N8
} = window.__gradio__svelte__internal, {
  SvelteComponent: U8,
  append_hydration: H8,
  attr: G8,
  children: z8,
  claim_svg_element: q8,
  detach: j8,
  init: V8,
  insert_hydration: W8,
  noop: X8,
  safe_not_equal: Z8,
  svg_element: Y8
} = window.__gradio__svelte__internal, {
  SvelteComponent: K8,
  append_hydration: Q8,
  attr: J8,
  children: e7,
  claim_svg_element: t7,
  detach: n7,
  init: i7,
  insert_hydration: r7,
  noop: a7,
  safe_not_equal: s7,
  svg_element: o7
} = window.__gradio__svelte__internal, {
  SvelteComponent: l7,
  append_hydration: u7,
  attr: c7,
  children: f7,
  claim_svg_element: h7,
  detach: d7,
  init: _7,
  insert_hydration: p7,
  noop: m7,
  safe_not_equal: g7,
  svg_element: b7
} = window.__gradio__svelte__internal, {
  SvelteComponent: v7,
  append_hydration: y7,
  attr: w7,
  children: D7,
  claim_svg_element: E7,
  detach: C7,
  init: k7,
  insert_hydration: S7,
  noop: A7,
  safe_not_equal: F7,
  svg_element: T7
} = window.__gradio__svelte__internal, {
  SvelteComponent: mm,
  claim_component: gm,
  create_component: bm,
  destroy_component: vm,
  init: ym,
  mount_component: wm,
  safe_not_equal: Dm,
  transition_in: Em,
  transition_out: Cm
} = window.__gradio__svelte__internal, { createEventDispatcher: km } = window.__gradio__svelte__internal;
function Sm(n) {
  let e, t;
  return e = new Dn({
    props: {
      Icon: Cp,
      label: (
        /*i18n*/
        n[2]("common.share")
      ),
      pending: (
        /*pending*/
        n[3]
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[5]
  ), {
    c() {
      bm(e.$$.fragment);
    },
    l(i) {
      gm(e.$$.fragment, i);
    },
    m(i, r) {
      wm(e, i, r), t = !0;
    },
    p(i, [r]) {
      const a = {};
      r & /*i18n*/
      4 && (a.label = /*i18n*/
      i[2]("common.share")), r & /*pending*/
      8 && (a.pending = /*pending*/
      i[3]), e.$set(a);
    },
    i(i) {
      t || (Em(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Cm(e.$$.fragment, i), t = !1;
    },
    d(i) {
      vm(e, i);
    }
  };
}
function Am(n, e, t) {
  const i = km();
  let { formatter: r } = e, { value: a } = e, { i18n: s } = e, o = !1;
  const l = async () => {
    try {
      t(3, o = !0);
      const c = await r(a);
      i("share", { description: c });
    } catch (c) {
      console.error(c);
      let u = c instanceof Ur ? c.message : "Share failed.";
      i("error", u);
    } finally {
      t(3, o = !1);
    }
  };
  return n.$$set = (c) => {
    "formatter" in c && t(0, r = c.formatter), "value" in c && t(1, a = c.value), "i18n" in c && t(2, s = c.i18n);
  }, [r, a, s, o, i, l];
}
class Fm extends mm {
  constructor(e) {
    super(), ym(this, e, Am, Sm, Dm, { formatter: 0, value: 1, i18n: 2 });
  }
}
const Tm = /^(#\s*)(.+)$/m;
function Im(n) {
  const e = n.trim(), t = e.match(Tm);
  if (!t)
    return [!1, e || !1];
  const [i, , r] = t, a = r.trim();
  if (e === i)
    return [a, !1];
  const s = t.index !== void 0 ? t.index + i.length : 0, l = e.substring(s).trim() || !1;
  return [a, l];
}
const {
  SvelteComponent: $m,
  append_hydration: Pn,
  attr: Wi,
  check_outros: xm,
  children: Xi,
  claim_component: wf,
  claim_element: Zi,
  claim_space: va,
  claim_text: Fn,
  create_component: Df,
  destroy_component: Ef,
  detach: Xe,
  element: Yi,
  empty: Kr,
  group_outros: Pm,
  init: Bm,
  insert_hydration: Mt,
  mount_component: Cf,
  safe_not_equal: Om,
  set_data: Ki,
  space: ya,
  text: Tn,
  toggle_class: Kl,
  transition_in: Qr,
  transition_out: Jr
} = window.__gradio__svelte__internal;
function Lm(n) {
  let e, t;
  return e = new pm({}), {
    c() {
      Df(e.$$.fragment);
    },
    l(i) {
      wf(e.$$.fragment, i);
    },
    m(i, r) {
      Cf(e, i, r), t = !0;
    },
    i(i) {
      t || (Qr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Jr(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Ef(e, i);
    }
  };
}
function Rm(n) {
  let e, t;
  return e = new nm({}), {
    c() {
      Df(e.$$.fragment);
    },
    l(i) {
      wf(e.$$.fragment, i);
    },
    m(i, r) {
      Cf(e, i, r), t = !0;
    },
    i(i) {
      t || (Qr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Jr(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Ef(e, i);
    }
  };
}
function Mm(n) {
  let e = (
    /*i18n*/
    n[1](
      /*defs*/
      n[7][
        /*type*/
        n[0]
      ] || /*defs*/
      n[7].file
    ) + ""
  ), t, i, r, a = (
    /*mode*/
    n[3] !== "short" && Ql(n)
  );
  return {
    c() {
      t = Tn(e), i = ya(), a && a.c(), r = Kr();
    },
    l(s) {
      t = Fn(s, e), i = va(s), a && a.l(s), r = Kr();
    },
    m(s, o) {
      Mt(s, t, o), Mt(s, i, o), a && a.m(s, o), Mt(s, r, o);
    },
    p(s, o) {
      o & /*i18n, type*/
      3 && e !== (e = /*i18n*/
      s[1](
        /*defs*/
        s[7][
          /*type*/
          s[0]
        ] || /*defs*/
        s[7].file
      ) + "") && Ki(t, e), /*mode*/
      s[3] !== "short" ? a ? a.p(s, o) : (a = Ql(s), a.c(), a.m(r.parentNode, r)) : a && (a.d(1), a = null);
    },
    d(s) {
      s && (Xe(t), Xe(i), Xe(r)), a && a.d(s);
    }
  };
}
function Nm(n) {
  let e, t, i = (
    /*heading*/
    n[6] && Jl(n)
  ), r = (
    /*paragraph*/
    n[5] && eu(n)
  );
  return {
    c() {
      i && i.c(), e = ya(), r && r.c(), t = Kr();
    },
    l(a) {
      i && i.l(a), e = va(a), r && r.l(a), t = Kr();
    },
    m(a, s) {
      i && i.m(a, s), Mt(a, e, s), r && r.m(a, s), Mt(a, t, s);
    },
    p(a, s) {
      /*heading*/
      a[6] ? i ? i.p(a, s) : (i = Jl(a), i.c(), i.m(e.parentNode, e)) : i && (i.d(1), i = null), /*paragraph*/
      a[5] ? r ? r.p(a, s) : (r = eu(a), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null);
    },
    d(a) {
      a && (Xe(e), Xe(t)), i && i.d(a), r && r.d(a);
    }
  };
}
function Ql(n) {
  let e, t, i = (
    /*i18n*/
    n[1]("common.or") + ""
  ), r, a, s, o = (
    /*message*/
    (n[2] || /*i18n*/
    n[1]("upload_text.click_to_upload")) + ""
  ), l;
  return {
    c() {
      e = Yi("span"), t = Tn("- "), r = Tn(i), a = Tn(" -"), s = ya(), l = Tn(o), this.h();
    },
    l(c) {
      e = Zi(c, "SPAN", { class: !0 });
      var u = Xi(e);
      t = Fn(u, "- "), r = Fn(u, i), a = Fn(u, " -"), u.forEach(Xe), s = va(c), l = Fn(c, o), this.h();
    },
    h() {
      Wi(e, "class", "or svelte-1xg7h5n");
    },
    m(c, u) {
      Mt(c, e, u), Pn(e, t), Pn(e, r), Pn(e, a), Mt(c, s, u), Mt(c, l, u);
    },
    p(c, u) {
      u & /*i18n*/
      2 && i !== (i = /*i18n*/
      c[1]("common.or") + "") && Ki(r, i), u & /*message, i18n*/
      6 && o !== (o = /*message*/
      (c[2] || /*i18n*/
      c[1]("upload_text.click_to_upload")) + "") && Ki(l, o);
    },
    d(c) {
      c && (Xe(e), Xe(s), Xe(l));
    }
  };
}
function Jl(n) {
  let e, t;
  return {
    c() {
      e = Yi("h2"), t = Tn(
        /*heading*/
        n[6]
      ), this.h();
    },
    l(i) {
      e = Zi(i, "H2", { class: !0 });
      var r = Xi(e);
      t = Fn(
        r,
        /*heading*/
        n[6]
      ), r.forEach(Xe), this.h();
    },
    h() {
      Wi(e, "class", "svelte-1xg7h5n");
    },
    m(i, r) {
      Mt(i, e, r), Pn(e, t);
    },
    p(i, r) {
      r & /*heading*/
      64 && Ki(
        t,
        /*heading*/
        i[6]
      );
    },
    d(i) {
      i && Xe(e);
    }
  };
}
function eu(n) {
  let e, t;
  return {
    c() {
      e = Yi("p"), t = Tn(
        /*paragraph*/
        n[5]
      ), this.h();
    },
    l(i) {
      e = Zi(i, "P", { class: !0 });
      var r = Xi(e);
      t = Fn(
        r,
        /*paragraph*/
        n[5]
      ), r.forEach(Xe), this.h();
    },
    h() {
      Wi(e, "class", "svelte-1xg7h5n");
    },
    m(i, r) {
      Mt(i, e, r), Pn(e, t);
    },
    p(i, r) {
      r & /*paragraph*/
      32 && Ki(
        t,
        /*paragraph*/
        i[5]
      );
    },
    d(i) {
      i && Xe(e);
    }
  };
}
function Um(n) {
  let e, t, i, r, a, s;
  const o = [Rm, Lm], l = [];
  function c(d, p) {
    return (
      /*type*/
      d[0] === "clipboard" ? 0 : 1
    );
  }
  i = c(n), r = l[i] = o[i](n);
  function u(d, p) {
    return (
      /*heading*/
      d[6] || /*paragraph*/
      d[5] ? Nm : Mm
    );
  }
  let f = u(n), h = f(n);
  return {
    c() {
      e = Yi("div"), t = Yi("span"), r.c(), a = ya(), h.c(), this.h();
    },
    l(d) {
      e = Zi(d, "DIV", { class: !0 });
      var p = Xi(e);
      t = Zi(p, "SPAN", { class: !0 });
      var v = Xi(t);
      r.l(v), v.forEach(Xe), a = va(p), h.l(p), p.forEach(Xe), this.h();
    },
    h() {
      Wi(t, "class", "icon-wrap svelte-1xg7h5n"), Kl(
        t,
        "hovered",
        /*hovered*/
        n[4]
      ), Wi(e, "class", "wrap svelte-1xg7h5n");
    },
    m(d, p) {
      Mt(d, e, p), Pn(e, t), l[i].m(t, null), Pn(e, a), h.m(e, null), s = !0;
    },
    p(d, [p]) {
      let v = i;
      i = c(d), i !== v && (Pm(), Jr(l[v], 1, 1, () => {
        l[v] = null;
      }), xm(), r = l[i], r || (r = l[i] = o[i](d), r.c()), Qr(r, 1), r.m(t, null)), (!s || p & /*hovered*/
      16) && Kl(
        t,
        "hovered",
        /*hovered*/
        d[4]
      ), f === (f = u(d)) && h ? h.p(d, p) : (h.d(1), h = f(d), h && (h.c(), h.m(e, null)));
    },
    i(d) {
      s || (Qr(r), s = !0);
    },
    o(d) {
      Jr(r), s = !1;
    },
    d(d) {
      d && Xe(e), l[i].d(), h.d();
    }
  };
}
function Hm(n, e, t) {
  let i, r, { type: a = "file" } = e, { i18n: s } = e, { message: o = void 0 } = e, { mode: l = "full" } = e, { hovered: c = !1 } = e, { placeholder: u = void 0 } = e;
  const f = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return n.$$set = (h) => {
    "type" in h && t(0, a = h.type), "i18n" in h && t(1, s = h.i18n), "message" in h && t(2, o = h.message), "mode" in h && t(3, l = h.mode), "hovered" in h && t(4, c = h.hovered), "placeholder" in h && t(8, u = h.placeholder);
  }, n.$$.update = () => {
    n.$$.dirty & /*placeholder*/
    256 && t(6, [i, r] = u ? Im(u) : [!1, !1], i, (t(5, r), t(8, u)));
  }, [a, s, o, l, c, r, i, f, u];
}
class Gm extends $m {
  constructor(e) {
    super(), Bm(this, e, Hm, Um, Om, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4,
      placeholder: 8
    });
  }
}
const {
  SvelteComponent: I7,
  attr: $7,
  children: x7,
  claim_element: P7,
  create_slot: B7,
  detach: O7,
  element: L7,
  get_all_dirty_from_scope: R7,
  get_slot_changes: M7,
  init: N7,
  insert_hydration: U7,
  safe_not_equal: H7,
  toggle_class: G7,
  transition_in: z7,
  transition_out: q7,
  update_slot_base: j7
} = window.__gradio__svelte__internal, {
  SvelteComponent: V7,
  append_hydration: W7,
  attr: X7,
  check_outros: Z7,
  children: Y7,
  claim_component: K7,
  claim_element: Q7,
  claim_space: J7,
  create_component: e6,
  destroy_component: t6,
  detach: n6,
  element: i6,
  empty: r6,
  group_outros: a6,
  init: s6,
  insert_hydration: o6,
  listen: l6,
  mount_component: u6,
  safe_not_equal: c6,
  space: f6,
  toggle_class: h6,
  transition_in: d6,
  transition_out: _6
} = window.__gradio__svelte__internal, {
  SvelteComponent: zm,
  attr: tu,
  children: qm,
  claim_element: jm,
  create_slot: Vm,
  detach: nu,
  element: Wm,
  get_all_dirty_from_scope: Xm,
  get_slot_changes: Zm,
  init: Ym,
  insert_hydration: Km,
  null_to_empty: iu,
  safe_not_equal: Qm,
  transition_in: Jm,
  transition_out: eg,
  update_slot_base: tg
} = window.__gradio__svelte__internal;
function ng(n) {
  let e, t, i;
  const r = (
    /*#slots*/
    n[3].default
  ), a = Vm(
    r,
    n,
    /*$$scope*/
    n[2],
    null
  );
  return {
    c() {
      e = Wm("div"), a && a.c(), this.h();
    },
    l(s) {
      e = jm(s, "DIV", { class: !0 });
      var o = qm(e);
      a && a.l(o), o.forEach(nu), this.h();
    },
    h() {
      tu(e, "class", t = iu(`icon-button-wrapper ${/*top_panel*/
      n[0] ? "top-panel" : ""} ${/*display_top_corner*/
      n[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4");
    },
    m(s, o) {
      Km(s, e, o), a && a.m(e, null), i = !0;
    },
    p(s, [o]) {
      a && a.p && (!i || o & /*$$scope*/
      4) && tg(
        a,
        r,
        s,
        /*$$scope*/
        s[2],
        i ? Zm(
          r,
          /*$$scope*/
          s[2],
          o,
          null
        ) : Xm(
          /*$$scope*/
          s[2]
        ),
        null
      ), (!i || o & /*top_panel, display_top_corner*/
      3 && t !== (t = iu(`icon-button-wrapper ${/*top_panel*/
      s[0] ? "top-panel" : ""} ${/*display_top_corner*/
      s[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-109se4")) && tu(e, "class", t);
    },
    i(s) {
      i || (Jm(a, s), i = !0);
    },
    o(s) {
      eg(a, s), i = !1;
    },
    d(s) {
      s && nu(e), a && a.d(s);
    }
  };
}
function ig(n, e, t) {
  let { $$slots: i = {}, $$scope: r } = e, { top_panel: a = !0 } = e, { display_top_corner: s = !1 } = e;
  return n.$$set = (o) => {
    "top_panel" in o && t(0, a = o.top_panel), "display_top_corner" in o && t(1, s = o.display_top_corner), "$$scope" in o && t(2, r = o.$$scope);
  }, [a, s, r, i];
}
class kf extends zm {
  constructor(e) {
    super(), Ym(this, e, ig, ng, Qm, { top_panel: 0, display_top_corner: 1 });
  }
}
const {
  SvelteComponent: rg,
  check_outros: ag,
  claim_component: Sf,
  create_component: Af,
  destroy_component: Ff,
  detach: sg,
  empty: ru,
  group_outros: og,
  init: lg,
  insert_hydration: ug,
  mount_component: Tf,
  noop: If,
  safe_not_equal: cg,
  transition_in: ea,
  transition_out: ta
} = window.__gradio__svelte__internal, { createEventDispatcher: fg } = window.__gradio__svelte__internal;
function hg(n) {
  let e, t;
  return e = new Dn({
    props: { Icon: Mp, label: "Fullscreen" }
  }), e.$on(
    "click",
    /*click_handler_1*/
    n[3]
  ), {
    c() {
      Af(e.$$.fragment);
    },
    l(i) {
      Sf(e.$$.fragment, i);
    },
    m(i, r) {
      Tf(e, i, r), t = !0;
    },
    p: If,
    i(i) {
      t || (ea(e.$$.fragment, i), t = !0);
    },
    o(i) {
      ta(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Ff(e, i);
    }
  };
}
function dg(n) {
  let e, t;
  return e = new Dn({
    props: {
      Icon: um,
      label: "Exit fullscreen mode"
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[2]
  ), {
    c() {
      Af(e.$$.fragment);
    },
    l(i) {
      Sf(e.$$.fragment, i);
    },
    m(i, r) {
      Tf(e, i, r), t = !0;
    },
    p: If,
    i(i) {
      t || (ea(e.$$.fragment, i), t = !0);
    },
    o(i) {
      ta(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Ff(e, i);
    }
  };
}
function _g(n) {
  let e, t, i, r;
  const a = [dg, hg], s = [];
  function o(l, c) {
    return (
      /*fullscreen*/
      l[0] ? 0 : 1
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = ru();
    },
    l(l) {
      t.l(l), i = ru();
    },
    m(l, c) {
      s[e].m(l, c), ug(l, i, c), r = !0;
    },
    p(l, [c]) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (og(), ta(s[u], 1, 1, () => {
        s[u] = null;
      }), ag(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), ea(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (ea(t), r = !0);
    },
    o(l) {
      ta(t), r = !1;
    },
    d(l) {
      l && sg(i), s[e].d(l);
    }
  };
}
function pg(n, e, t) {
  const i = fg();
  let { fullscreen: r } = e;
  const a = () => i("fullscreen", !1), s = () => i("fullscreen", !0);
  return n.$$set = (o) => {
    "fullscreen" in o && t(0, r = o.fullscreen);
  }, [r, i, a, s];
}
class $f extends rg {
  constructor(e) {
    super(), lg(this, e, pg, _g, cg, { fullscreen: 0 });
  }
}
const xf = (n) => {
  let e;
  if (n.currentTarget instanceof Element)
    e = n.currentTarget.querySelector("img");
  else
    return [NaN, NaN];
  const t = e.getBoundingClientRect(), i = e.naturalWidth / t.width, r = e.naturalHeight / t.height;
  if (i > r) {
    const o = e.naturalHeight / i, l = (t.height - o) / 2;
    var a = Math.round((n.clientX - t.left) * i), s = Math.round((n.clientY - t.top - l) * i);
  } else {
    const o = e.naturalWidth / r, l = (t.width - o) / 2;
    var a = Math.round((n.clientX - t.left - l) * r), s = Math.round((n.clientY - t.top) * r);
  }
  return a < 0 || a >= e.naturalWidth || s < 0 || s >= e.naturalHeight ? null : [a, s];
}, { setContext: p6, getContext: mg } = window.__gradio__svelte__internal, gg = "WORKER_PROXY_CONTEXT_KEY";
function Pf() {
  return mg(gg);
}
const bg = "lite.local";
function vg(n) {
  return n.host === window.location.host || n.host === "localhost:7860" || n.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  n.host === bg;
}
function Bf(n, e) {
  const t = e.toLowerCase();
  for (const [i, r] of Object.entries(n))
    if (i.toLowerCase() === t)
      return r;
}
function Of(n) {
  const e = typeof window < "u";
  if (n == null || !e)
    return !1;
  const t = new URL(n, window.location.href);
  return !(!vg(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let Sr;
async function yg(n) {
  const e = typeof window < "u";
  if (n == null || !e || !Of(n))
    return n;
  if (Sr == null)
    try {
      Sr = Pf();
    } catch {
      return n;
    }
  if (Sr == null)
    return n;
  const i = new URL(n, window.location.href).pathname;
  return Sr.httpRequest({
    method: "GET",
    path: i,
    headers: {},
    query_string: ""
  }).then((r) => {
    if (r.status !== 200)
      throw new Error(`Failed to get file ${i} from the Wasm worker.`);
    const a = new Blob([r.body], {
      type: Bf(r.headers, "content-type")
    });
    return URL.createObjectURL(a);
  });
}
const {
  SvelteComponent: wg,
  assign: na,
  check_outros: Lf,
  children: Rf,
  claim_element: Mf,
  compute_rest_props: au,
  create_slot: Fo,
  detach: di,
  element: Nf,
  empty: ia,
  exclude_internal_props: Dg,
  get_all_dirty_from_scope: To,
  get_slot_changes: Io,
  get_spread_update: Uf,
  group_outros: Hf,
  init: Eg,
  insert_hydration: wa,
  listen: Gf,
  prevent_default: Cg,
  safe_not_equal: kg,
  set_attributes: ra,
  set_style: su,
  toggle_class: aa,
  transition_in: Un,
  transition_out: Hn,
  update_slot_base: $o
} = window.__gradio__svelte__internal, { createEventDispatcher: Sg, onMount: m6 } = window.__gradio__svelte__internal;
function Ag(n) {
  let e, t, i, r, a;
  const s = (
    /*#slots*/
    n[8].default
  ), o = Fo(
    s,
    n,
    /*$$scope*/
    n[7],
    null
  );
  let l = [
    { class: "download-link" },
    { href: (
      /*href*/
      n[0]
    ) },
    {
      target: t = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      n[1]
    ) },
    /*$$restProps*/
    n[6]
  ], c = {};
  for (let u = 0; u < l.length; u += 1)
    c = na(c, l[u]);
  return {
    c() {
      e = Nf("a"), o && o.c(), this.h();
    },
    l(u) {
      e = Mf(u, "A", {
        class: !0,
        href: !0,
        target: !0,
        rel: !0,
        download: !0
      });
      var f = Rf(e);
      o && o.l(f), f.forEach(di), this.h();
    },
    h() {
      ra(e, c), su(e, "position", "relative"), aa(e, "svelte-151nsdd", !0);
    },
    m(u, f) {
      wa(u, e, f), o && o.m(e, null), i = !0, r || (a = Gf(
        e,
        "click",
        /*dispatch*/
        n[3].bind(null, "click")
      ), r = !0);
    },
    p(u, f) {
      o && o.p && (!i || f & /*$$scope*/
      128) && $o(
        o,
        s,
        u,
        /*$$scope*/
        u[7],
        i ? Io(
          s,
          /*$$scope*/
          u[7],
          f,
          null
        ) : To(
          /*$$scope*/
          u[7]
        ),
        null
      ), ra(e, c = Uf(l, [
        { class: "download-link" },
        (!i || f & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) },
        { target: t },
        { rel: "noopener noreferrer" },
        (!i || f & /*download*/
        2) && { download: (
          /*download*/
          u[1]
        ) },
        f & /*$$restProps*/
        64 && /*$$restProps*/
        u[6]
      ])), su(e, "position", "relative"), aa(e, "svelte-151nsdd", !0);
    },
    i(u) {
      i || (Un(o, u), i = !0);
    },
    o(u) {
      Hn(o, u), i = !1;
    },
    d(u) {
      u && di(e), o && o.d(u), r = !1, a();
    }
  };
}
function Fg(n) {
  let e, t, i, r;
  const a = [Ig, Tg], s = [];
  function o(l, c) {
    return (
      /*is_downloading*/
      l[2] ? 0 : 1
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = ia();
    },
    l(l) {
      t.l(l), i = ia();
    },
    m(l, c) {
      s[e].m(l, c), wa(l, i, c), r = !0;
    },
    p(l, c) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (Hf(), Hn(s[u], 1, 1, () => {
        s[u] = null;
      }), Lf(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), Un(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (Un(t), r = !0);
    },
    o(l) {
      Hn(t), r = !1;
    },
    d(l) {
      l && di(i), s[e].d(l);
    }
  };
}
function Tg(n) {
  let e, t, i, r;
  const a = (
    /*#slots*/
    n[8].default
  ), s = Fo(
    a,
    n,
    /*$$scope*/
    n[7],
    null
  );
  let o = [
    /*$$restProps*/
    n[6],
    { href: (
      /*href*/
      n[0]
    ) }
  ], l = {};
  for (let c = 0; c < o.length; c += 1)
    l = na(l, o[c]);
  return {
    c() {
      e = Nf("a"), s && s.c(), this.h();
    },
    l(c) {
      e = Mf(c, "A", { href: !0 });
      var u = Rf(e);
      s && s.l(u), u.forEach(di), this.h();
    },
    h() {
      ra(e, l), aa(e, "svelte-151nsdd", !0);
    },
    m(c, u) {
      wa(c, e, u), s && s.m(e, null), t = !0, i || (r = Gf(e, "click", Cg(
        /*wasm_click_handler*/
        n[5]
      )), i = !0);
    },
    p(c, u) {
      s && s.p && (!t || u & /*$$scope*/
      128) && $o(
        s,
        a,
        c,
        /*$$scope*/
        c[7],
        t ? Io(
          a,
          /*$$scope*/
          c[7],
          u,
          null
        ) : To(
          /*$$scope*/
          c[7]
        ),
        null
      ), ra(e, l = Uf(o, [
        u & /*$$restProps*/
        64 && /*$$restProps*/
        c[6],
        (!t || u & /*href*/
        1) && { href: (
          /*href*/
          c[0]
        ) }
      ])), aa(e, "svelte-151nsdd", !0);
    },
    i(c) {
      t || (Un(s, c), t = !0);
    },
    o(c) {
      Hn(s, c), t = !1;
    },
    d(c) {
      c && di(e), s && s.d(c), i = !1, r();
    }
  };
}
function Ig(n) {
  let e;
  const t = (
    /*#slots*/
    n[8].default
  ), i = Fo(
    t,
    n,
    /*$$scope*/
    n[7],
    null
  );
  return {
    c() {
      i && i.c();
    },
    l(r) {
      i && i.l(r);
    },
    m(r, a) {
      i && i.m(r, a), e = !0;
    },
    p(r, a) {
      i && i.p && (!e || a & /*$$scope*/
      128) && $o(
        i,
        t,
        r,
        /*$$scope*/
        r[7],
        e ? Io(
          t,
          /*$$scope*/
          r[7],
          a,
          null
        ) : To(
          /*$$scope*/
          r[7]
        ),
        null
      );
    },
    i(r) {
      e || (Un(i, r), e = !0);
    },
    o(r) {
      Hn(i, r), e = !1;
    },
    d(r) {
      i && i.d(r);
    }
  };
}
function $g(n) {
  let e, t, i, r, a;
  const s = [Fg, Ag], o = [];
  function l(c, u) {
    return u & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (c[4] && Of(
      /*href*/
      c[0]
    ))), e ? 0 : 1;
  }
  return t = l(n, -1), i = o[t] = s[t](n), {
    c() {
      i.c(), r = ia();
    },
    l(c) {
      i.l(c), r = ia();
    },
    m(c, u) {
      o[t].m(c, u), wa(c, r, u), a = !0;
    },
    p(c, [u]) {
      let f = t;
      t = l(c, u), t === f ? o[t].p(c, u) : (Hf(), Hn(o[f], 1, 1, () => {
        o[f] = null;
      }), Lf(), i = o[t], i ? i.p(c, u) : (i = o[t] = s[t](c), i.c()), Un(i, 1), i.m(r.parentNode, r));
    },
    i(c) {
      a || (Un(i), a = !0);
    },
    o(c) {
      Hn(i), a = !1;
    },
    d(c) {
      c && di(r), o[t].d(c);
    }
  };
}
function xg(n, e, t) {
  const i = ["href", "download"];
  let r = au(e, i), { $$slots: a = {}, $$scope: s } = e;
  var o = this && this.__awaiter || function(p, v, w, D) {
    function m(_) {
      return _ instanceof w ? _ : new w(function(g) {
        g(_);
      });
    }
    return new (w || (w = Promise))(function(_, g) {
      function b(P) {
        try {
          k(D.next(P));
        } catch (A) {
          g(A);
        }
      }
      function E(P) {
        try {
          k(D.throw(P));
        } catch (A) {
          g(A);
        }
      }
      function k(P) {
        P.done ? _(P.value) : m(P.value).then(b, E);
      }
      k((D = D.apply(p, v || [])).next());
    });
  };
  let { href: l = void 0 } = e, { download: c } = e;
  const u = Sg();
  let f = !1;
  const h = Pf();
  function d() {
    return o(this, void 0, void 0, function* () {
      if (f)
        return;
      if (u("click"), l == null)
        throw new Error("href is not defined.");
      if (h == null)
        throw new Error("Wasm worker proxy is not available.");
      const v = new URL(l, window.location.href).pathname;
      t(2, f = !0), h.httpRequest({
        method: "GET",
        path: v,
        headers: {},
        query_string: ""
      }).then((w) => {
        if (w.status !== 200)
          throw new Error(`Failed to get file ${v} from the Wasm worker.`);
        const D = new Blob(
          [w.body],
          {
            type: Bf(w.headers, "content-type")
          }
        ), m = URL.createObjectURL(D), _ = document.createElement("a");
        _.href = m, _.download = c, _.click(), URL.revokeObjectURL(m);
      }).finally(() => {
        t(2, f = !1);
      });
    });
  }
  return n.$$set = (p) => {
    e = na(na({}, e), Dg(p)), t(6, r = au(e, i)), "href" in p && t(0, l = p.href), "download" in p && t(1, c = p.download), "$$scope" in p && t(7, s = p.$$scope);
  }, [
    l,
    c,
    f,
    u,
    h,
    d,
    r,
    s,
    a
  ];
}
class Pg extends wg {
  constructor(e) {
    super(), Eg(this, e, xg, $g, kg, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: Bg,
  assign: Ls,
  bubble: Og,
  claim_element: Lg,
  compute_rest_props: ou,
  detach: Rg,
  element: Mg,
  exclude_internal_props: Ng,
  get_spread_update: Ug,
  init: Hg,
  insert_hydration: Gg,
  listen: zg,
  noop: lu,
  safe_not_equal: qg,
  set_attributes: uu,
  src_url_equal: jg,
  toggle_class: cu
} = window.__gradio__svelte__internal;
function Vg(n) {
  let e, t, i, r, a = [
    {
      src: t = /*resolved_src*/
      n[0]
    },
    /*$$restProps*/
    n[1]
  ], s = {};
  for (let o = 0; o < a.length; o += 1)
    s = Ls(s, a[o]);
  return {
    c() {
      e = Mg("img"), this.h();
    },
    l(o) {
      e = Lg(o, "IMG", { src: !0 }), this.h();
    },
    h() {
      uu(e, s), cu(e, "svelte-kxeri3", !0);
    },
    m(o, l) {
      Gg(o, e, l), i || (r = zg(
        e,
        "load",
        /*load_handler*/
        n[4]
      ), i = !0);
    },
    p(o, [l]) {
      uu(e, s = Ug(a, [
        l & /*resolved_src*/
        1 && !jg(e.src, t = /*resolved_src*/
        o[0]) && { src: t },
        l & /*$$restProps*/
        2 && /*$$restProps*/
        o[1]
      ])), cu(e, "svelte-kxeri3", !0);
    },
    i: lu,
    o: lu,
    d(o) {
      o && Rg(e), i = !1, r();
    }
  };
}
function Wg(n, e, t) {
  const i = ["src"];
  let r = ou(e, i), { src: a = void 0 } = e, s, o;
  function l(c) {
    Og.call(this, n, c);
  }
  return n.$$set = (c) => {
    e = Ls(Ls({}, e), Ng(c)), t(1, r = ou(e, i)), "src" in c && t(2, a = c.src);
  }, n.$$.update = () => {
    if (n.$$.dirty & /*src, latest_src*/
    12) {
      t(0, s = a), t(3, o = a);
      const c = a;
      yg(c).then((u) => {
        o === c && t(0, s = u);
      });
    }
  }, [s, r, a, o, l];
}
class xo extends Bg {
  constructor(e) {
    super(), Hg(this, e, Wg, Vg, qg, { src: 2 });
  }
}
var Da = typeof self < "u" ? self : global;
const Qi = typeof navigator < "u", Xg = Qi && typeof HTMLImageElement > "u", sa = !(typeof global > "u" || typeof process > "u" || !process.versions || !process.versions.node), Po = Da.Buffer, Ar = Da.BigInt, Bo = !!Po, Zg = (n) => n;
function oa(n, e = Zg) {
  if (sa) try {
    return typeof require == "function" ? Promise.resolve(e(require(n))) : import(
      /* webpackIgnore: true */
      n
    ).then(e);
  } catch {
    console.warn(`Couldn't load ${n}`);
  }
}
let Oo = Da.fetch;
const Yg = (n) => Oo = n;
if (!Da.fetch) {
  const n = oa("http", (i) => i), e = oa("https", (i) => i), t = (i, { headers: r } = {}) => new Promise(async (a, s) => {
    let { port: o, hostname: l, pathname: c, protocol: u, search: f } = new URL(i);
    const h = { method: "GET", hostname: l, path: encodeURI(c) + f, headers: r };
    o !== "" && (h.port = Number(o));
    const d = (u === "https:" ? await e : await n).request(h, (p) => {
      if (p.statusCode === 301 || p.statusCode === 302) {
        let v = new URL(p.headers.location, i).toString();
        return t(v, { headers: r }).then(a).catch(s);
      }
      a({ status: p.statusCode, arrayBuffer: () => new Promise((v) => {
        let w = [];
        p.on("data", (D) => w.push(D)), p.on("end", () => v(Buffer.concat(w)));
      }) });
    });
    d.on("error", s), d.end();
  });
  Yg(t);
}
function U(n, e, t) {
  return e in n ? Object.defineProperty(n, e, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : n[e] = t, n;
}
const la = (n) => zf(n) ? void 0 : n, Kg = (n) => n !== void 0;
function zf(n) {
  return n === void 0 || (n instanceof Map ? n.size === 0 : Object.values(n).filter(Kg).length === 0);
}
function $e(n) {
  let e = new Error(n);
  throw delete e.stack, e;
}
function In(n) {
  return (n = function(e) {
    for (; e.endsWith("\0"); ) e = e.slice(0, -1);
    return e;
  }(n).trim()) === "" ? void 0 : n;
}
function Rs(n) {
  let e = function(t) {
    let i = 0;
    return t.ifd0.enabled && (i += 1024), t.exif.enabled && (i += 2048), t.makerNote && (i += 2048), t.userComment && (i += 1024), t.gps.enabled && (i += 512), t.interop.enabled && (i += 100), t.ifd1.enabled && (i += 1024), i + 2048;
  }(n);
  return n.jfif.enabled && (e += 50), n.xmp.enabled && (e += 2e4), n.iptc.enabled && (e += 14e3), n.icc.enabled && (e += 6e3), e;
}
const Ms = (n) => String.fromCharCode.apply(null, n), fu = typeof TextDecoder < "u" ? new TextDecoder("utf-8") : void 0;
function qf(n) {
  return fu ? fu.decode(n) : Bo ? Buffer.from(n).toString("utf8") : decodeURIComponent(escape(Ms(n)));
}
class lt {
  static from(e, t) {
    return e instanceof this && e.le === t ? e : new lt(e, void 0, void 0, t);
  }
  constructor(e, t = 0, i, r) {
    if (typeof r == "boolean" && (this.le = r), Array.isArray(e) && (e = new Uint8Array(e)), e === 0) this.byteOffset = 0, this.byteLength = 0;
    else if (e instanceof ArrayBuffer) {
      i === void 0 && (i = e.byteLength - t);
      let a = new DataView(e, t, i);
      this._swapDataView(a);
    } else if (e instanceof Uint8Array || e instanceof DataView || e instanceof lt) {
      i === void 0 && (i = e.byteLength - t), (t += e.byteOffset) + i > e.byteOffset + e.byteLength && $e("Creating view outside of available memory in ArrayBuffer");
      let a = new DataView(e.buffer, t, i);
      this._swapDataView(a);
    } else if (typeof e == "number") {
      let a = new DataView(new ArrayBuffer(e));
      this._swapDataView(a);
    } else $e("Invalid input argument for BufferView: " + e);
  }
  _swapArrayBuffer(e) {
    this._swapDataView(new DataView(e));
  }
  _swapBuffer(e) {
    this._swapDataView(new DataView(e.buffer, e.byteOffset, e.byteLength));
  }
  _swapDataView(e) {
    this.dataView = e, this.buffer = e.buffer, this.byteOffset = e.byteOffset, this.byteLength = e.byteLength;
  }
  _lengthToEnd(e) {
    return this.byteLength - e;
  }
  set(e, t, i = lt) {
    return e instanceof DataView || e instanceof lt ? e = new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : e instanceof ArrayBuffer && (e = new Uint8Array(e)), e instanceof Uint8Array || $e("BufferView.set(): Invalid data argument."), this.toUint8().set(e, t), new i(this, t, e.byteLength);
  }
  subarray(e, t) {
    return t = t || this._lengthToEnd(e), new lt(this, e, t);
  }
  toUint8() {
    return new Uint8Array(this.buffer, this.byteOffset, this.byteLength);
  }
  getUint8Array(e, t) {
    return new Uint8Array(this.buffer, this.byteOffset + e, t);
  }
  getString(e = 0, t = this.byteLength) {
    return qf(this.getUint8Array(e, t));
  }
  getLatin1String(e = 0, t = this.byteLength) {
    let i = this.getUint8Array(e, t);
    return Ms(i);
  }
  getUnicodeString(e = 0, t = this.byteLength) {
    const i = [];
    for (let r = 0; r < t && e + r < this.byteLength; r += 2) i.push(this.getUint16(e + r));
    return Ms(i);
  }
  getInt8(e) {
    return this.dataView.getInt8(e);
  }
  getUint8(e) {
    return this.dataView.getUint8(e);
  }
  getInt16(e, t = this.le) {
    return this.dataView.getInt16(e, t);
  }
  getInt32(e, t = this.le) {
    return this.dataView.getInt32(e, t);
  }
  getUint16(e, t = this.le) {
    return this.dataView.getUint16(e, t);
  }
  getUint32(e, t = this.le) {
    return this.dataView.getUint32(e, t);
  }
  getFloat32(e, t = this.le) {
    return this.dataView.getFloat32(e, t);
  }
  getFloat64(e, t = this.le) {
    return this.dataView.getFloat64(e, t);
  }
  getFloat(e, t = this.le) {
    return this.dataView.getFloat32(e, t);
  }
  getDouble(e, t = this.le) {
    return this.dataView.getFloat64(e, t);
  }
  getUintBytes(e, t, i) {
    switch (t) {
      case 1:
        return this.getUint8(e, i);
      case 2:
        return this.getUint16(e, i);
      case 4:
        return this.getUint32(e, i);
      case 8:
        return this.getUint64 && this.getUint64(e, i);
    }
  }
  getUint(e, t, i) {
    switch (t) {
      case 8:
        return this.getUint8(e, i);
      case 16:
        return this.getUint16(e, i);
      case 32:
        return this.getUint32(e, i);
      case 64:
        return this.getUint64 && this.getUint64(e, i);
    }
  }
  toString(e) {
    return this.dataView.toString(e, this.constructor.name);
  }
  ensureChunk() {
  }
}
function Ns(n, e) {
  $e(`${n} '${e}' was not loaded, try using full build of exifr.`);
}
class Lo extends Map {
  constructor(e) {
    super(), this.kind = e;
  }
  get(e, t) {
    return this.has(e) || Ns(this.kind, e), t && (e in t || function(i, r) {
      $e(`Unknown ${i} '${r}'.`);
    }(this.kind, e), t[e].enabled || Ns(this.kind, e)), super.get(e);
  }
  keyList() {
    return Array.from(this.keys());
  }
}
var _i = new Lo("file parser"), We = new Lo("segment parser"), wi = new Lo("file reader");
function Qg(n, e) {
  return typeof n == "string" ? hu(n, e) : Qi && !Xg && n instanceof HTMLImageElement ? hu(n.src, e) : n instanceof Uint8Array || n instanceof ArrayBuffer || n instanceof DataView ? new lt(n) : Qi && n instanceof Blob ? Us(n, e, "blob", zs) : void $e("Invalid input argument");
}
function hu(n, e) {
  return (t = n).startsWith("data:") || t.length > 1e4 ? Hs(n, e, "base64") : sa && n.includes("://") ? Us(n, e, "url", Gs) : sa ? Hs(n, e, "fs") : Qi ? Us(n, e, "url", Gs) : void $e("Invalid input argument");
  var t;
}
async function Us(n, e, t, i) {
  return wi.has(t) ? Hs(n, e, t) : i ? async function(r, a) {
    let s = await a(r);
    return new lt(s);
  }(n, i) : void $e(`Parser ${t} is not loaded`);
}
async function Hs(n, e, t) {
  let i = new (wi.get(t))(n, e);
  return await i.read(), i;
}
const Gs = (n) => Oo(n).then((e) => e.arrayBuffer()), zs = (n) => new Promise((e, t) => {
  let i = new FileReader();
  i.onloadend = () => e(i.result || new ArrayBuffer()), i.onerror = t, i.readAsArrayBuffer(n);
});
class Jg extends Map {
  get tagKeys() {
    return this.allKeys || (this.allKeys = Array.from(this.keys())), this.allKeys;
  }
  get tagValues() {
    return this.allValues || (this.allValues = Array.from(this.values())), this.allValues;
  }
}
function He(n, e, t) {
  let i = new Jg();
  for (let [r, a] of t) i.set(r, a);
  if (Array.isArray(e)) for (let r of e) n.set(r, i);
  else n.set(e, i);
  return i;
}
function qs(n, e, t) {
  let i, r = n.get(e);
  for (i of t) r.set(i[0], i[1]);
}
const ut = /* @__PURE__ */ new Map(), Zn = /* @__PURE__ */ new Map(), Gr = /* @__PURE__ */ new Map(), Fr = ["chunked", "firstChunkSize", "firstChunkSizeNode", "firstChunkSizeBrowser", "chunkSize", "chunkLimit"], jf = ["jfif", "xmp", "icc", "iptc", "ihdr"], js = ["tiff", ...jf], Le = ["ifd0", "ifd1", "exif", "gps", "interop"], Tr = [...js, ...Le], Ir = ["makerNote", "userComment"], Vf = ["translateKeys", "translateValues", "reviveValues", "multiSegment"], $r = [...Vf, "sanitize", "mergeOutput", "silentErrors"];
class Wf {
  get translate() {
    return this.translateKeys || this.translateValues || this.reviveValues;
  }
}
let Ii = class extends Wf {
  get needed() {
    return this.enabled || this.deps.size > 0;
  }
  constructor(e, t, i, r) {
    if (super(), U(this, "enabled", !1), U(this, "skip", /* @__PURE__ */ new Set()), U(this, "pick", /* @__PURE__ */ new Set()), U(this, "deps", /* @__PURE__ */ new Set()), U(this, "translateKeys", !1), U(this, "translateValues", !1), U(this, "reviveValues", !1), this.key = e, this.enabled = t, this.parse = this.enabled, this.applyInheritables(r), this.canBeFiltered = Le.includes(e), this.canBeFiltered && (this.dict = ut.get(e)), i !== void 0) if (Array.isArray(i)) this.parse = this.enabled = !0, this.canBeFiltered && i.length > 0 && this.translateTagSet(i, this.pick);
    else if (typeof i == "object") {
      if (this.enabled = !0, this.parse = i.parse !== !1, this.canBeFiltered) {
        let { pick: a, skip: s } = i;
        a && a.length > 0 && this.translateTagSet(a, this.pick), s && s.length > 0 && this.translateTagSet(s, this.skip);
      }
      this.applyInheritables(i);
    } else i === !0 || i === !1 ? this.parse = this.enabled = i : $e(`Invalid options argument: ${i}`);
  }
  applyInheritables(e) {
    let t, i;
    for (t of Vf) i = e[t], i !== void 0 && (this[t] = i);
  }
  translateTagSet(e, t) {
    if (this.dict) {
      let i, r, { tagKeys: a, tagValues: s } = this.dict;
      for (i of e) typeof i == "string" ? (r = s.indexOf(i), r === -1 && (r = a.indexOf(Number(i))), r !== -1 && t.add(Number(a[r]))) : t.add(i);
    } else for (let i of e) t.add(i);
  }
  finalizeFilters() {
    !this.enabled && this.deps.size > 0 ? (this.enabled = !0, ua(this.pick, this.deps)) : this.enabled && this.pick.size > 0 && ua(this.pick, this.deps);
  }
};
var Ke = { jfif: !1, tiff: !0, xmp: !1, icc: !1, iptc: !1, ifd0: !0, ifd1: !1, exif: !0, gps: !0, interop: !1, ihdr: void 0, makerNote: !1, userComment: !1, multiSegment: !1, skip: [], pick: [], translateKeys: !0, translateValues: !0, reviveValues: !0, sanitize: !0, mergeOutput: !0, silentErrors: !0, chunked: !0, firstChunkSize: void 0, firstChunkSizeNode: 512, firstChunkSizeBrowser: 65536, chunkSize: 65536, chunkLimit: 5 }, du = /* @__PURE__ */ new Map();
class Ro extends Wf {
  static useCached(e) {
    let t = du.get(e);
    return t !== void 0 || (t = new this(e), du.set(e, t)), t;
  }
  constructor(e) {
    super(), e === !0 ? this.setupFromTrue() : e === void 0 ? this.setupFromUndefined() : Array.isArray(e) ? this.setupFromArray(e) : typeof e == "object" ? this.setupFromObject(e) : $e(`Invalid options argument ${e}`), this.firstChunkSize === void 0 && (this.firstChunkSize = Qi ? this.firstChunkSizeBrowser : this.firstChunkSizeNode), this.mergeOutput && (this.ifd1.enabled = !1), this.filterNestedSegmentTags(), this.traverseTiffDependencyTree(), this.checkLoadedPlugins();
  }
  setupFromUndefined() {
    let e;
    for (e of Fr) this[e] = Ke[e];
    for (e of $r) this[e] = Ke[e];
    for (e of Ir) this[e] = Ke[e];
    for (e of Tr) this[e] = new Ii(e, Ke[e], void 0, this);
  }
  setupFromTrue() {
    let e;
    for (e of Fr) this[e] = Ke[e];
    for (e of $r) this[e] = Ke[e];
    for (e of Ir) this[e] = !0;
    for (e of Tr) this[e] = new Ii(e, !0, void 0, this);
  }
  setupFromArray(e) {
    let t;
    for (t of Fr) this[t] = Ke[t];
    for (t of $r) this[t] = Ke[t];
    for (t of Ir) this[t] = Ke[t];
    for (t of Tr) this[t] = new Ii(t, !1, void 0, this);
    this.setupGlobalFilters(e, void 0, Le);
  }
  setupFromObject(e) {
    let t;
    for (t of (Le.ifd0 = Le.ifd0 || Le.image, Le.ifd1 = Le.ifd1 || Le.thumbnail, Object.assign(this, e), Fr)) this[t] = cs(e[t], Ke[t]);
    for (t of $r) this[t] = cs(e[t], Ke[t]);
    for (t of Ir) this[t] = cs(e[t], Ke[t]);
    for (t of js) this[t] = new Ii(t, Ke[t], e[t], this);
    for (t of Le) this[t] = new Ii(t, Ke[t], e[t], this.tiff);
    this.setupGlobalFilters(e.pick, e.skip, Le, Tr), e.tiff === !0 ? this.batchEnableWithBool(Le, !0) : e.tiff === !1 ? this.batchEnableWithUserValue(Le, e) : Array.isArray(e.tiff) ? this.setupGlobalFilters(e.tiff, void 0, Le) : typeof e.tiff == "object" && this.setupGlobalFilters(e.tiff.pick, e.tiff.skip, Le);
  }
  batchEnableWithBool(e, t) {
    for (let i of e) this[i].enabled = t;
  }
  batchEnableWithUserValue(e, t) {
    for (let i of e) {
      let r = t[i];
      this[i].enabled = r !== !1 && r !== void 0;
    }
  }
  setupGlobalFilters(e, t, i, r = i) {
    if (e && e.length) {
      for (let s of r) this[s].enabled = !1;
      let a = _u(e, i);
      for (let [s, o] of a) ua(this[s].pick, o), this[s].enabled = !0;
    } else if (t && t.length) {
      let a = _u(t, i);
      for (let [s, o] of a) ua(this[s].skip, o);
    }
  }
  filterNestedSegmentTags() {
    let { ifd0: e, exif: t, xmp: i, iptc: r, icc: a } = this;
    this.makerNote ? t.deps.add(37500) : t.skip.add(37500), this.userComment ? t.deps.add(37510) : t.skip.add(37510), i.enabled || e.skip.add(700), r.enabled || e.skip.add(33723), a.enabled || e.skip.add(34675);
  }
  traverseTiffDependencyTree() {
    let { ifd0: e, exif: t, gps: i, interop: r } = this;
    r.needed && (t.deps.add(40965), e.deps.add(40965)), t.needed && e.deps.add(34665), i.needed && e.deps.add(34853), this.tiff.enabled = Le.some((a) => this[a].enabled === !0) || this.makerNote || this.userComment;
    for (let a of Le) this[a].finalizeFilters();
  }
  get onlyTiff() {
    return !jf.map((e) => this[e].enabled).some((e) => e === !0) && this.tiff.enabled;
  }
  checkLoadedPlugins() {
    for (let e of js) this[e].enabled && !We.has(e) && Ns("segment parser", e);
  }
}
function _u(n, e) {
  let t, i, r, a, s = [];
  for (r of e) {
    for (a of (t = ut.get(r), i = [], t)) (n.includes(a[0]) || n.includes(a[1])) && i.push(a[0]);
    i.length && s.push([r, i]);
  }
  return s;
}
function cs(n, e) {
  return n !== void 0 ? n : e !== void 0 ? e : void 0;
}
function ua(n, e) {
  for (let t of e) n.add(t);
}
U(Ro, "default", Ke);
class e0 {
  constructor(e) {
    U(this, "parsers", {}), U(this, "output", {}), U(this, "errors", []), U(this, "pushToErrors", (t) => this.errors.push(t)), this.options = Ro.useCached(e);
  }
  async read(e) {
    this.file = await Qg(e, this.options);
  }
  setup() {
    if (this.fileParser) return;
    let { file: e } = this, t = e.getUint16(0);
    for (let [i, r] of _i) if (r.canHandle(e, t)) return this.fileParser = new r(this.options, this.file, this.parsers), e[i] = !0;
    this.file.close && this.file.close(), $e("Unknown file format");
  }
  async parse() {
    let { output: e, errors: t } = this;
    return this.setup(), this.options.silentErrors ? (await this.executeParsers().catch(this.pushToErrors), t.push(...this.fileParser.errors)) : await this.executeParsers(), this.file.close && this.file.close(), this.options.silentErrors && t.length > 0 && (e.errors = t), la(e);
  }
  async executeParsers() {
    let { output: e } = this;
    await this.fileParser.parse();
    let t = Object.values(this.parsers).map(async (i) => {
      let r = await i.parse();
      i.assignToOutput(e, r);
    });
    this.options.silentErrors && (t = t.map((i) => i.catch(this.pushToErrors))), await Promise.all(t);
  }
  async extractThumbnail() {
    this.setup();
    let { options: e, file: t } = this, i = We.get("tiff", e);
    var r;
    if (t.tiff ? r = { start: 0, type: "tiff" } : t.jpeg && (r = await this.fileParser.getOrFindSegment("tiff")), r === void 0) return;
    let a = await this.fileParser.ensureSegmentChunk(r), s = this.parsers.tiff = new i(a, e, t), o = await s.extractThumbnail();
    return t.close && t.close(), o;
  }
}
async function Vs(n, e) {
  let t = new e0(e);
  return await t.read(n), t.parse();
}
class Ea {
  constructor(e, t, i) {
    U(this, "errors", []), U(this, "ensureSegmentChunk", async (r) => {
      let a = r.start, s = r.size || 65536;
      if (this.file.chunked) if (this.file.available(a, s)) r.chunk = this.file.subarray(a, s);
      else try {
        r.chunk = await this.file.readChunk(a, s);
      } catch (o) {
        $e(`Couldn't read segment: ${JSON.stringify(r)}. ${o.message}`);
      }
      else this.file.byteLength > a + s ? r.chunk = this.file.subarray(a, s) : r.size === void 0 ? r.chunk = this.file.subarray(a) : $e("Segment unreachable: " + JSON.stringify(r));
      return r.chunk;
    }), this.extendOptions && this.extendOptions(e), this.options = e, this.file = t, this.parsers = i;
  }
  injectSegment(e, t) {
    this.options[e].enabled && this.createParser(e, t);
  }
  createParser(e, t) {
    let i = new (We.get(e))(t, this.options, this.file);
    return this.parsers[e] = i;
  }
  createParsers(e) {
    for (let t of e) {
      let { type: i, chunk: r } = t, a = this.options[i];
      if (a && a.enabled) {
        let s = this.parsers[i];
        s && s.append || s || this.createParser(i, r);
      }
    }
  }
  async readSegments(e) {
    let t = e.map(this.ensureSegmentChunk);
    await Promise.all(t);
  }
}
let Bt = class {
  static findPosition(e, t) {
    let i = e.getUint16(t + 2) + 2, r = typeof this.headerLength == "function" ? this.headerLength(e, t, i) : this.headerLength, a = t + r, s = i - r;
    return { offset: t, length: i, headerLength: r, start: a, size: s, end: a + s };
  }
  static parse(e, t = {}) {
    return new this(e, new Ro({ [this.type]: t }), e).parse();
  }
  normalizeInput(e) {
    return e instanceof lt ? e : new lt(e);
  }
  constructor(e, t = {}, i) {
    U(this, "errors", []), U(this, "raw", /* @__PURE__ */ new Map()), U(this, "handleError", (r) => {
      if (!this.options.silentErrors) throw r;
      this.errors.push(r.message);
    }), this.chunk = this.normalizeInput(e), this.file = i, this.type = this.constructor.type, this.globalOptions = this.options = t, this.localOptions = t[this.type], this.canTranslate = this.localOptions && this.localOptions.translate;
  }
  translate() {
    this.canTranslate && (this.translated = this.translateBlock(this.raw, this.type));
  }
  get output() {
    return this.translated ? this.translated : this.raw ? Object.fromEntries(this.raw) : void 0;
  }
  translateBlock(e, t) {
    let i = Gr.get(t), r = Zn.get(t), a = ut.get(t), s = this.options[t], o = s.reviveValues && !!i, l = s.translateValues && !!r, c = s.translateKeys && !!a, u = {};
    for (let [f, h] of e) o && i.has(f) ? h = i.get(f)(h) : l && r.has(f) && (h = this.translateValue(h, r.get(f))), c && a.has(f) && (f = a.get(f) || f), u[f] = h;
    return u;
  }
  translateValue(e, t) {
    return t[e] || t.DEFAULT || e;
  }
  assignToOutput(e, t) {
    this.assignObjectToOutput(e, this.constructor.type, t);
  }
  assignObjectToOutput(e, t, i) {
    if (this.globalOptions.mergeOutput) return Object.assign(e, i);
    e[t] ? Object.assign(e[t], i) : e[t] = i;
  }
};
U(Bt, "headerLength", 4), U(Bt, "type", void 0), U(Bt, "multiSegment", !1), U(Bt, "canHandle", () => !1);
function t0(n) {
  return n === 192 || n === 194 || n === 196 || n === 219 || n === 221 || n === 218 || n === 254;
}
function n0(n) {
  return n >= 224 && n <= 239;
}
function i0(n, e, t) {
  for (let [i, r] of We) if (r.canHandle(n, e, t)) return i;
}
class pu extends Ea {
  constructor(...e) {
    super(...e), U(this, "appSegments", []), U(this, "jpegSegments", []), U(this, "unknownSegments", []);
  }
  static canHandle(e, t) {
    return t === 65496;
  }
  async parse() {
    await this.findAppSegments(), await this.readSegments(this.appSegments), this.mergeMultiSegments(), this.createParsers(this.mergedAppSegments || this.appSegments);
  }
  setupSegmentFinderArgs(e) {
    e === !0 ? (this.findAll = !0, this.wanted = new Set(We.keyList())) : (e = e === void 0 ? We.keyList().filter((t) => this.options[t].enabled) : e.filter((t) => this.options[t].enabled && We.has(t)), this.findAll = !1, this.remaining = new Set(e), this.wanted = new Set(e)), this.unfinishedMultiSegment = !1;
  }
  async findAppSegments(e = 0, t) {
    this.setupSegmentFinderArgs(t);
    let { file: i, findAll: r, wanted: a, remaining: s } = this;
    if (!r && this.file.chunked && (r = Array.from(a).some((o) => {
      let l = We.get(o), c = this.options[o];
      return l.multiSegment && c.multiSegment;
    }), r && await this.file.readWhole()), e = this.findAppSegmentsInRange(e, i.byteLength), !this.options.onlyTiff && i.chunked) {
      let o = !1;
      for (; s.size > 0 && !o && (i.canReadNextChunk || this.unfinishedMultiSegment); ) {
        let { nextChunkOffset: l } = i, c = this.appSegments.some((u) => !this.file.available(u.offset || u.start, u.length || u.size));
        if (o = e > l && !c ? !await i.readNextChunk(e) : !await i.readNextChunk(l), (e = this.findAppSegmentsInRange(e, i.byteLength)) === void 0) return;
      }
    }
  }
  findAppSegmentsInRange(e, t) {
    t -= 2;
    let i, r, a, s, o, l, { file: c, findAll: u, wanted: f, remaining: h, options: d } = this;
    for (; e < t; e++) if (c.getUint8(e) === 255) {
      if (i = c.getUint8(e + 1), n0(i)) {
        if (r = c.getUint16(e + 2), a = i0(c, e, r), a && f.has(a) && (s = We.get(a), o = s.findPosition(c, e), l = d[a], o.type = a, this.appSegments.push(o), !u && (s.multiSegment && l.multiSegment ? (this.unfinishedMultiSegment = o.chunkNumber < o.chunkCount, this.unfinishedMultiSegment || h.delete(a)) : h.delete(a), h.size === 0))) break;
        d.recordUnknownSegments && (o = Bt.findPosition(c, e), o.marker = i, this.unknownSegments.push(o)), e += r + 1;
      } else if (t0(i)) {
        if (r = c.getUint16(e + 2), i === 218 && d.stopAfterSos !== !1) return;
        d.recordJpegSegments && this.jpegSegments.push({ offset: e, length: r, marker: i }), e += r + 1;
      }
    }
    return e;
  }
  mergeMultiSegments() {
    if (!this.appSegments.some((t) => t.multiSegment)) return;
    let e = function(t, i) {
      let r, a, s, o = /* @__PURE__ */ new Map();
      for (let l = 0; l < t.length; l++) r = t[l], a = r[i], o.has(a) ? s = o.get(a) : o.set(a, s = []), s.push(r);
      return Array.from(o);
    }(this.appSegments, "type");
    this.mergedAppSegments = e.map(([t, i]) => {
      let r = We.get(t, this.options);
      return r.handleMultiSegments ? { type: t, chunk: r.handleMultiSegments(i) } : i[0];
    });
  }
  getSegment(e) {
    return this.appSegments.find((t) => t.type === e);
  }
  async getOrFindSegment(e) {
    let t = this.getSegment(e);
    return t === void 0 && (await this.findAppSegments(0, [e]), t = this.getSegment(e)), t;
  }
}
U(pu, "type", "jpeg"), _i.set("jpeg", pu);
const r0 = [void 0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 4];
class a0 extends Bt {
  parseHeader() {
    var e = this.chunk.getUint16();
    e === 18761 ? this.le = !0 : e === 19789 && (this.le = !1), this.chunk.le = this.le, this.headerParsed = !0;
  }
  parseTags(e, t, i = /* @__PURE__ */ new Map()) {
    let { pick: r, skip: a } = this.options[t];
    r = new Set(r);
    let s = r.size > 0, o = a.size === 0, l = this.chunk.getUint16(e);
    e += 2;
    for (let c = 0; c < l; c++) {
      let u = this.chunk.getUint16(e);
      if (s) {
        if (r.has(u) && (i.set(u, this.parseTag(e, u, t)), r.delete(u), r.size === 0)) break;
      } else !o && a.has(u) || i.set(u, this.parseTag(e, u, t));
      e += 12;
    }
    return i;
  }
  parseTag(e, t, i) {
    let { chunk: r } = this, a = r.getUint16(e + 2), s = r.getUint32(e + 4), o = r0[a];
    if (o * s <= 4 ? e += 8 : e = r.getUint32(e + 8), (a < 1 || a > 13) && $e(`Invalid TIFF value type. block: ${i.toUpperCase()}, tag: ${t.toString(16)}, type: ${a}, offset ${e}`), e > r.byteLength && $e(`Invalid TIFF value offset. block: ${i.toUpperCase()}, tag: ${t.toString(16)}, type: ${a}, offset ${e} is outside of chunk size ${r.byteLength}`), a === 1) return r.getUint8Array(e, s);
    if (a === 2) return In(r.getString(e, s));
    if (a === 7) return r.getUint8Array(e, s);
    if (s === 1) return this.parseTagValue(a, e);
    {
      let l = new (function(u) {
        switch (u) {
          case 1:
            return Uint8Array;
          case 3:
            return Uint16Array;
          case 4:
            return Uint32Array;
          case 5:
            return Array;
          case 6:
            return Int8Array;
          case 8:
            return Int16Array;
          case 9:
            return Int32Array;
          case 10:
            return Array;
          case 11:
            return Float32Array;
          case 12:
            return Float64Array;
          default:
            return Array;
        }
      }(a))(s), c = o;
      for (let u = 0; u < s; u++) l[u] = this.parseTagValue(a, e), e += c;
      return l;
    }
  }
  parseTagValue(e, t) {
    let { chunk: i } = this;
    switch (e) {
      case 1:
        return i.getUint8(t);
      case 3:
        return i.getUint16(t);
      case 4:
        return i.getUint32(t);
      case 5:
        return i.getUint32(t) / i.getUint32(t + 4);
      case 6:
        return i.getInt8(t);
      case 8:
        return i.getInt16(t);
      case 9:
        return i.getInt32(t);
      case 10:
        return i.getInt32(t) / i.getInt32(t + 4);
      case 11:
        return i.getFloat(t);
      case 12:
        return i.getDouble(t);
      case 13:
        return i.getUint32(t);
      default:
        $e(`Invalid tiff type ${e}`);
    }
  }
}
class fs extends a0 {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 225 && e.getUint32(t + 4) === 1165519206 && e.getUint16(t + 8) === 0;
  }
  async parse() {
    this.parseHeader();
    let { options: e } = this;
    return e.ifd0.enabled && await this.parseIfd0Block(), e.exif.enabled && await this.safeParse("parseExifBlock"), e.gps.enabled && await this.safeParse("parseGpsBlock"), e.interop.enabled && await this.safeParse("parseInteropBlock"), e.ifd1.enabled && await this.safeParse("parseThumbnailBlock"), this.createOutput();
  }
  safeParse(e) {
    let t = this[e]();
    return t.catch !== void 0 && (t = t.catch(this.handleError)), t;
  }
  findIfd0Offset() {
    this.ifd0Offset === void 0 && (this.ifd0Offset = this.chunk.getUint32(4));
  }
  findIfd1Offset() {
    if (this.ifd1Offset === void 0) {
      this.findIfd0Offset();
      let e = this.chunk.getUint16(this.ifd0Offset), t = this.ifd0Offset + 2 + 12 * e;
      this.ifd1Offset = this.chunk.getUint32(t);
    }
  }
  parseBlock(e, t) {
    let i = /* @__PURE__ */ new Map();
    return this[t] = i, this.parseTags(e, t, i), i;
  }
  async parseIfd0Block() {
    if (this.ifd0) return;
    let { file: e } = this;
    this.findIfd0Offset(), this.ifd0Offset < 8 && $e("Malformed EXIF data"), !e.chunked && this.ifd0Offset > e.byteLength && $e(`IFD0 offset points to outside of file.
this.ifd0Offset: ${this.ifd0Offset}, file.byteLength: ${e.byteLength}`), e.tiff && await e.ensureChunk(this.ifd0Offset, Rs(this.options));
    let t = this.parseBlock(this.ifd0Offset, "ifd0");
    return t.size !== 0 ? (this.exifOffset = t.get(34665), this.interopOffset = t.get(40965), this.gpsOffset = t.get(34853), this.xmp = t.get(700), this.iptc = t.get(33723), this.icc = t.get(34675), this.options.sanitize && (t.delete(34665), t.delete(40965), t.delete(34853), t.delete(700), t.delete(33723), t.delete(34675)), t) : void 0;
  }
  async parseExifBlock() {
    if (this.exif || (this.ifd0 || await this.parseIfd0Block(), this.exifOffset === void 0)) return;
    this.file.tiff && await this.file.ensureChunk(this.exifOffset, Rs(this.options));
    let e = this.parseBlock(this.exifOffset, "exif");
    return this.interopOffset || (this.interopOffset = e.get(40965)), this.makerNote = e.get(37500), this.userComment = e.get(37510), this.options.sanitize && (e.delete(40965), e.delete(37500), e.delete(37510)), this.unpack(e, 41728), this.unpack(e, 41729), e;
  }
  unpack(e, t) {
    let i = e.get(t);
    i && i.length === 1 && e.set(t, i[0]);
  }
  async parseGpsBlock() {
    if (this.gps || (this.ifd0 || await this.parseIfd0Block(), this.gpsOffset === void 0)) return;
    let e = this.parseBlock(this.gpsOffset, "gps");
    return e && e.has(2) && e.has(4) && (e.set("latitude", mu(...e.get(2), e.get(1))), e.set("longitude", mu(...e.get(4), e.get(3)))), e;
  }
  async parseInteropBlock() {
    if (!this.interop && (this.ifd0 || await this.parseIfd0Block(), this.interopOffset !== void 0 || this.exif || await this.parseExifBlock(), this.interopOffset !== void 0)) return this.parseBlock(this.interopOffset, "interop");
  }
  async parseThumbnailBlock(e = !1) {
    if (!this.ifd1 && !this.ifd1Parsed && (!this.options.mergeOutput || e)) return this.findIfd1Offset(), this.ifd1Offset > 0 && (this.parseBlock(this.ifd1Offset, "ifd1"), this.ifd1Parsed = !0), this.ifd1;
  }
  async extractThumbnail() {
    if (this.headerParsed || this.parseHeader(), this.ifd1Parsed || await this.parseThumbnailBlock(!0), this.ifd1 === void 0) return;
    let e = this.ifd1.get(513), t = this.ifd1.get(514);
    return this.chunk.getUint8Array(e, t);
  }
  get image() {
    return this.ifd0;
  }
  get thumbnail() {
    return this.ifd1;
  }
  createOutput() {
    let e, t, i, r = {};
    for (t of Le) if (e = this[t], !zf(e)) if (i = this.canTranslate ? this.translateBlock(e, t) : Object.fromEntries(e), this.options.mergeOutput) {
      if (t === "ifd1") continue;
      Object.assign(r, i);
    } else r[t] = i;
    return this.makerNote && (r.makerNote = this.makerNote), this.userComment && (r.userComment = this.userComment), r;
  }
  assignToOutput(e, t) {
    if (this.globalOptions.mergeOutput) Object.assign(e, t);
    else for (let [i, r] of Object.entries(t)) this.assignObjectToOutput(e, i, r);
  }
}
function mu(n, e, t, i) {
  var r = n + e / 60 + t / 3600;
  return i !== "S" && i !== "W" || (r *= -1), r;
}
U(fs, "type", "tiff"), U(fs, "headerLength", 10), We.set("tiff", fs);
const Mo = { ifd0: !1, ifd1: !1, exif: !1, gps: !1, interop: !1, sanitize: !1, reviveValues: !0, translateKeys: !1, translateValues: !1, mergeOutput: !1 };
Object.assign({}, Mo, { firstChunkSize: 4e4, gps: [1, 2, 3, 4] });
Object.assign({}, Mo, { tiff: !1, ifd1: !0, mergeOutput: !1 });
Object.assign({}, Mo, { firstChunkSize: 4e4, ifd0: [274] });
if (typeof navigator == "object") {
  let n = navigator.userAgent;
  if (n.includes("iPad") || n.includes("iPhone")) {
    let e = n.match(/OS (\d+)_(\d+)/);
    if (e) {
      let [, t, i] = e;
    }
  } else if (n.includes("OS X 10")) {
    let [, e] = n.match(/OS X 10[_.](\d+)/);
  }
  if (n.includes("Chrome/")) {
    let [, e] = n.match(/Chrome\/(\d+)/);
  } else if (n.includes("Firefox/")) {
    let [, e] = n.match(/Firefox\/(\d+)/);
  }
}
class s0 extends lt {
  constructor(...e) {
    super(...e), U(this, "ranges", new o0()), this.byteLength !== 0 && this.ranges.add(0, this.byteLength);
  }
  _tryExtend(e, t, i) {
    if (e === 0 && this.byteLength === 0 && i) {
      let r = new DataView(i.buffer || i, i.byteOffset, i.byteLength);
      this._swapDataView(r);
    } else {
      let r = e + t;
      if (r > this.byteLength) {
        let { dataView: a } = this._extend(r);
        this._swapDataView(a);
      }
    }
  }
  _extend(e) {
    let t;
    t = Bo ? Po.allocUnsafe(e) : new Uint8Array(e);
    let i = new DataView(t.buffer, t.byteOffset, t.byteLength);
    return t.set(new Uint8Array(this.buffer, this.byteOffset, this.byteLength), 0), { uintView: t, dataView: i };
  }
  subarray(e, t, i = !1) {
    return t = t || this._lengthToEnd(e), i && this._tryExtend(e, t), this.ranges.add(e, t), super.subarray(e, t);
  }
  set(e, t, i = !1) {
    i && this._tryExtend(t, e.byteLength, e);
    let r = super.set(e, t);
    return this.ranges.add(t, r.byteLength), r;
  }
  async ensureChunk(e, t) {
    this.chunked && (this.ranges.available(e, t) || await this.readChunk(e, t));
  }
  available(e, t) {
    return this.ranges.available(e, t);
  }
}
class o0 {
  constructor() {
    U(this, "list", []);
  }
  get length() {
    return this.list.length;
  }
  add(e, t, i = 0) {
    let r = e + t, a = this.list.filter((s) => gu(e, s.offset, r) || gu(e, s.end, r));
    if (a.length > 0) {
      e = Math.min(e, ...a.map((o) => o.offset)), r = Math.max(r, ...a.map((o) => o.end)), t = r - e;
      let s = a.shift();
      s.offset = e, s.length = t, s.end = r, this.list = this.list.filter((o) => !a.includes(o));
    } else this.list.push({ offset: e, length: t, end: r });
  }
  available(e, t) {
    let i = e + t;
    return this.list.some((r) => r.offset <= e && i <= r.end);
  }
}
function gu(n, e, t) {
  return n <= e && e <= t;
}
class Ca extends s0 {
  constructor(e, t) {
    super(0), U(this, "chunksRead", 0), this.input = e, this.options = t;
  }
  async readWhole() {
    this.chunked = !1, await this.readChunk(this.nextChunkOffset);
  }
  async readChunked() {
    this.chunked = !0, await this.readChunk(0, this.options.firstChunkSize);
  }
  async readNextChunk(e = this.nextChunkOffset) {
    if (this.fullyRead) return this.chunksRead++, !1;
    let t = this.options.chunkSize, i = await this.readChunk(e, t);
    return !!i && i.byteLength === t;
  }
  async readChunk(e, t) {
    if (this.chunksRead++, (t = this.safeWrapAddress(e, t)) !== 0) return this._readChunk(e, t);
  }
  safeWrapAddress(e, t) {
    return this.size !== void 0 && e + t > this.size ? Math.max(0, this.size - e) : t;
  }
  get nextChunkOffset() {
    if (this.ranges.list.length !== 0) return this.ranges.list[0].length;
  }
  get canReadNextChunk() {
    return this.chunksRead < this.options.chunkLimit;
  }
  get fullyRead() {
    return this.size !== void 0 && this.nextChunkOffset === this.size;
  }
  read() {
    return this.options.chunked ? this.readChunked() : this.readWhole();
  }
  close() {
  }
}
wi.set("blob", class extends Ca {
  async readWhole() {
    this.chunked = !1;
    let n = await zs(this.input);
    this._swapArrayBuffer(n);
  }
  readChunked() {
    return this.chunked = !0, this.size = this.input.size, super.readChunked();
  }
  async _readChunk(n, e) {
    let t = e ? n + e : void 0, i = this.input.slice(n, t), r = await zs(i);
    return this.set(r, n, !0);
  }
});
wi.set("url", class extends Ca {
  async readWhole() {
    this.chunked = !1;
    let n = await Gs(this.input);
    n instanceof ArrayBuffer ? this._swapArrayBuffer(n) : n instanceof Uint8Array && this._swapBuffer(n);
  }
  async _readChunk(n, e) {
    let t = e ? n + e - 1 : void 0, i = this.options.httpHeaders || {};
    (n || t) && (i.range = `bytes=${[n, t].join("-")}`);
    let r = await Oo(this.input, { headers: i }), a = await r.arrayBuffer(), s = a.byteLength;
    if (r.status !== 416) return s !== e && (this.size = n + s), this.set(a, n, !0);
  }
});
lt.prototype.getUint64 = function(n) {
  let e = this.getUint32(n), t = this.getUint32(n + 4);
  return e < 1048575 ? e << 32 | t : typeof Ar !== void 0 ? (console.warn("Using BigInt because of type 64uint but JS can only handle 53b numbers."), Ar(e) << Ar(32) | Ar(t)) : void $e("Trying to read 64b value but JS can only handle 53b numbers.");
};
class l0 extends Ea {
  parseBoxes(e = 0) {
    let t = [];
    for (; e < this.file.byteLength - 4; ) {
      let i = this.parseBoxHead(e);
      if (t.push(i), i.length === 0) break;
      e += i.length;
    }
    return t;
  }
  parseSubBoxes(e) {
    e.boxes = this.parseBoxes(e.start);
  }
  findBox(e, t) {
    return e.boxes === void 0 && this.parseSubBoxes(e), e.boxes.find((i) => i.kind === t);
  }
  parseBoxHead(e) {
    let t = this.file.getUint32(e), i = this.file.getString(e + 4, 4), r = e + 8;
    return t === 1 && (t = this.file.getUint64(e + 8), r += 8), { offset: e, length: t, kind: i, start: r };
  }
  parseBoxFullHead(e) {
    if (e.version !== void 0) return;
    let t = this.file.getUint32(e.start);
    e.version = t >> 24, e.start += 4;
  }
}
class Xf extends l0 {
  static canHandle(e, t) {
    if (t !== 0) return !1;
    let i = e.getUint16(2);
    if (i > 50) return !1;
    let r = 16, a = [];
    for (; r < i; ) a.push(e.getString(r, 4)), r += 4;
    return a.includes(this.type);
  }
  async parse() {
    let e = this.file.getUint32(0), t = this.parseBoxHead(e);
    for (; t.kind !== "meta"; ) e += t.length, await this.file.ensureChunk(e, 16), t = this.parseBoxHead(e);
    await this.file.ensureChunk(t.offset, t.length), this.parseBoxFullHead(t), this.parseSubBoxes(t), this.options.icc.enabled && await this.findIcc(t), this.options.tiff.enabled && await this.findExif(t);
  }
  async registerSegment(e, t, i) {
    await this.file.ensureChunk(t, i);
    let r = this.file.subarray(t, i);
    this.createParser(e, r);
  }
  async findIcc(e) {
    let t = this.findBox(e, "iprp");
    if (t === void 0) return;
    let i = this.findBox(t, "ipco");
    if (i === void 0) return;
    let r = this.findBox(i, "colr");
    r !== void 0 && await this.registerSegment("icc", r.offset + 12, r.length);
  }
  async findExif(e) {
    let t = this.findBox(e, "iinf");
    if (t === void 0) return;
    let i = this.findBox(e, "iloc");
    if (i === void 0) return;
    let r = this.findExifLocIdInIinf(t), a = this.findExtentInIloc(i, r);
    if (a === void 0) return;
    let [s, o] = a;
    await this.file.ensureChunk(s, o);
    let l = 4 + this.file.getUint32(s);
    s += l, o -= l, await this.registerSegment("tiff", s, o);
  }
  findExifLocIdInIinf(e) {
    this.parseBoxFullHead(e);
    let t, i, r, a, s = e.start, o = this.file.getUint16(s);
    for (s += 2; o--; ) {
      if (t = this.parseBoxHead(s), this.parseBoxFullHead(t), i = t.start, t.version >= 2 && (r = t.version === 3 ? 4 : 2, a = this.file.getString(i + r + 2, 4), a === "Exif")) return this.file.getUintBytes(i, r);
      s += t.length;
    }
  }
  get8bits(e) {
    let t = this.file.getUint8(e);
    return [t >> 4, 15 & t];
  }
  findExtentInIloc(e, t) {
    this.parseBoxFullHead(e);
    let i = e.start, [r, a] = this.get8bits(i++), [s, o] = this.get8bits(i++), l = e.version === 2 ? 4 : 2, c = e.version === 1 || e.version === 2 ? 2 : 0, u = o + r + a, f = e.version === 2 ? 4 : 2, h = this.file.getUintBytes(i, f);
    for (i += f; h--; ) {
      let d = this.file.getUintBytes(i, l);
      i += l + c + 2 + s;
      let p = this.file.getUint16(i);
      if (i += 2, d === t) return p > 1 && console.warn(`ILOC box has more than one extent but we're only processing one
Please create an issue at https://github.com/MikeKovarik/exifr with this file`), [this.file.getUintBytes(i + o, r), this.file.getUintBytes(i + o + r, a)];
      i += p * u;
    }
  }
}
class Zf extends Xf {
}
U(Zf, "type", "heic");
class bu extends Xf {
}
U(bu, "type", "avif"), _i.set("heic", Zf), _i.set("avif", bu), He(ut, ["ifd0", "ifd1"], [[256, "ImageWidth"], [257, "ImageHeight"], [258, "BitsPerSample"], [259, "Compression"], [262, "PhotometricInterpretation"], [270, "ImageDescription"], [271, "Make"], [272, "Model"], [273, "StripOffsets"], [274, "Orientation"], [277, "SamplesPerPixel"], [278, "RowsPerStrip"], [279, "StripByteCounts"], [282, "XResolution"], [283, "YResolution"], [284, "PlanarConfiguration"], [296, "ResolutionUnit"], [301, "TransferFunction"], [305, "Software"], [306, "ModifyDate"], [315, "Artist"], [316, "HostComputer"], [317, "Predictor"], [318, "WhitePoint"], [319, "PrimaryChromaticities"], [513, "ThumbnailOffset"], [514, "ThumbnailLength"], [529, "YCbCrCoefficients"], [530, "YCbCrSubSampling"], [531, "YCbCrPositioning"], [532, "ReferenceBlackWhite"], [700, "ApplicationNotes"], [33432, "Copyright"], [33723, "IPTC"], [34665, "ExifIFD"], [34675, "ICC"], [34853, "GpsIFD"], [330, "SubIFD"], [40965, "InteropIFD"], [40091, "XPTitle"], [40092, "XPComment"], [40093, "XPAuthor"], [40094, "XPKeywords"], [40095, "XPSubject"]]), He(ut, "exif", [[33434, "ExposureTime"], [33437, "FNumber"], [34850, "ExposureProgram"], [34852, "SpectralSensitivity"], [34855, "ISO"], [34858, "TimeZoneOffset"], [34859, "SelfTimerMode"], [34864, "SensitivityType"], [34865, "StandardOutputSensitivity"], [34866, "RecommendedExposureIndex"], [34867, "ISOSpeed"], [34868, "ISOSpeedLatitudeyyy"], [34869, "ISOSpeedLatitudezzz"], [36864, "ExifVersion"], [36867, "DateTimeOriginal"], [36868, "CreateDate"], [36873, "GooglePlusUploadCode"], [36880, "OffsetTime"], [36881, "OffsetTimeOriginal"], [36882, "OffsetTimeDigitized"], [37121, "ComponentsConfiguration"], [37122, "CompressedBitsPerPixel"], [37377, "ShutterSpeedValue"], [37378, "ApertureValue"], [37379, "BrightnessValue"], [37380, "ExposureCompensation"], [37381, "MaxApertureValue"], [37382, "SubjectDistance"], [37383, "MeteringMode"], [37384, "LightSource"], [37385, "Flash"], [37386, "FocalLength"], [37393, "ImageNumber"], [37394, "SecurityClassification"], [37395, "ImageHistory"], [37396, "SubjectArea"], [37500, "MakerNote"], [37510, "UserComment"], [37520, "SubSecTime"], [37521, "SubSecTimeOriginal"], [37522, "SubSecTimeDigitized"], [37888, "AmbientTemperature"], [37889, "Humidity"], [37890, "Pressure"], [37891, "WaterDepth"], [37892, "Acceleration"], [37893, "CameraElevationAngle"], [40960, "FlashpixVersion"], [40961, "ColorSpace"], [40962, "ExifImageWidth"], [40963, "ExifImageHeight"], [40964, "RelatedSoundFile"], [41483, "FlashEnergy"], [41486, "FocalPlaneXResolution"], [41487, "FocalPlaneYResolution"], [41488, "FocalPlaneResolutionUnit"], [41492, "SubjectLocation"], [41493, "ExposureIndex"], [41495, "SensingMethod"], [41728, "FileSource"], [41729, "SceneType"], [41730, "CFAPattern"], [41985, "CustomRendered"], [41986, "ExposureMode"], [41987, "WhiteBalance"], [41988, "DigitalZoomRatio"], [41989, "FocalLengthIn35mmFormat"], [41990, "SceneCaptureType"], [41991, "GainControl"], [41992, "Contrast"], [41993, "Saturation"], [41994, "Sharpness"], [41996, "SubjectDistanceRange"], [42016, "ImageUniqueID"], [42032, "OwnerName"], [42033, "SerialNumber"], [42034, "LensInfo"], [42035, "LensMake"], [42036, "LensModel"], [42037, "LensSerialNumber"], [42080, "CompositeImage"], [42081, "CompositeImageCount"], [42082, "CompositeImageExposureTimes"], [42240, "Gamma"], [59932, "Padding"], [59933, "OffsetSchema"], [65e3, "OwnerName"], [65001, "SerialNumber"], [65002, "Lens"], [65100, "RawFile"], [65101, "Converter"], [65102, "WhiteBalance"], [65105, "Exposure"], [65106, "Shadows"], [65107, "Brightness"], [65108, "Contrast"], [65109, "Saturation"], [65110, "Sharpness"], [65111, "Smoothness"], [65112, "MoireFilter"], [40965, "InteropIFD"]]), He(ut, "gps", [[0, "GPSVersionID"], [1, "GPSLatitudeRef"], [2, "GPSLatitude"], [3, "GPSLongitudeRef"], [4, "GPSLongitude"], [5, "GPSAltitudeRef"], [6, "GPSAltitude"], [7, "GPSTimeStamp"], [8, "GPSSatellites"], [9, "GPSStatus"], [10, "GPSMeasureMode"], [11, "GPSDOP"], [12, "GPSSpeedRef"], [13, "GPSSpeed"], [14, "GPSTrackRef"], [15, "GPSTrack"], [16, "GPSImgDirectionRef"], [17, "GPSImgDirection"], [18, "GPSMapDatum"], [19, "GPSDestLatitudeRef"], [20, "GPSDestLatitude"], [21, "GPSDestLongitudeRef"], [22, "GPSDestLongitude"], [23, "GPSDestBearingRef"], [24, "GPSDestBearing"], [25, "GPSDestDistanceRef"], [26, "GPSDestDistance"], [27, "GPSProcessingMethod"], [28, "GPSAreaInformation"], [29, "GPSDateStamp"], [30, "GPSDifferential"], [31, "GPSHPositioningError"]]), He(Zn, ["ifd0", "ifd1"], [[274, { 1: "Horizontal (normal)", 2: "Mirror horizontal", 3: "Rotate 180", 4: "Mirror vertical", 5: "Mirror horizontal and rotate 270 CW", 6: "Rotate 90 CW", 7: "Mirror horizontal and rotate 90 CW", 8: "Rotate 270 CW" }], [296, { 1: "None", 2: "inches", 3: "cm" }]]);
let ji = He(Zn, "exif", [[34850, { 0: "Not defined", 1: "Manual", 2: "Normal program", 3: "Aperture priority", 4: "Shutter priority", 5: "Creative program", 6: "Action program", 7: "Portrait mode", 8: "Landscape mode" }], [37121, { 0: "-", 1: "Y", 2: "Cb", 3: "Cr", 4: "R", 5: "G", 6: "B" }], [37383, { 0: "Unknown", 1: "Average", 2: "CenterWeightedAverage", 3: "Spot", 4: "MultiSpot", 5: "Pattern", 6: "Partial", 255: "Other" }], [37384, { 0: "Unknown", 1: "Daylight", 2: "Fluorescent", 3: "Tungsten (incandescent light)", 4: "Flash", 9: "Fine weather", 10: "Cloudy weather", 11: "Shade", 12: "Daylight fluorescent (D 5700 - 7100K)", 13: "Day white fluorescent (N 4600 - 5400K)", 14: "Cool white fluorescent (W 3900 - 4500K)", 15: "White fluorescent (WW 3200 - 3700K)", 17: "Standard light A", 18: "Standard light B", 19: "Standard light C", 20: "D55", 21: "D65", 22: "D75", 23: "D50", 24: "ISO studio tungsten", 255: "Other" }], [37385, { 0: "Flash did not fire", 1: "Flash fired", 5: "Strobe return light not detected", 7: "Strobe return light detected", 9: "Flash fired, compulsory flash mode", 13: "Flash fired, compulsory flash mode, return light not detected", 15: "Flash fired, compulsory flash mode, return light detected", 16: "Flash did not fire, compulsory flash mode", 24: "Flash did not fire, auto mode", 25: "Flash fired, auto mode", 29: "Flash fired, auto mode, return light not detected", 31: "Flash fired, auto mode, return light detected", 32: "No flash function", 65: "Flash fired, red-eye reduction mode", 69: "Flash fired, red-eye reduction mode, return light not detected", 71: "Flash fired, red-eye reduction mode, return light detected", 73: "Flash fired, compulsory flash mode, red-eye reduction mode", 77: "Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected", 79: "Flash fired, compulsory flash mode, red-eye reduction mode, return light detected", 89: "Flash fired, auto mode, red-eye reduction mode", 93: "Flash fired, auto mode, return light not detected, red-eye reduction mode", 95: "Flash fired, auto mode, return light detected, red-eye reduction mode" }], [41495, { 1: "Not defined", 2: "One-chip color area sensor", 3: "Two-chip color area sensor", 4: "Three-chip color area sensor", 5: "Color sequential area sensor", 7: "Trilinear sensor", 8: "Color sequential linear sensor" }], [41728, { 1: "Film Scanner", 2: "Reflection Print Scanner", 3: "Digital Camera" }], [41729, { 1: "Directly photographed" }], [41985, { 0: "Normal", 1: "Custom", 2: "HDR (no original saved)", 3: "HDR (original saved)", 4: "Original (for HDR)", 6: "Panorama", 7: "Portrait HDR", 8: "Portrait" }], [41986, { 0: "Auto", 1: "Manual", 2: "Auto bracket" }], [41987, { 0: "Auto", 1: "Manual" }], [41990, { 0: "Standard", 1: "Landscape", 2: "Portrait", 3: "Night", 4: "Other" }], [41991, { 0: "None", 1: "Low gain up", 2: "High gain up", 3: "Low gain down", 4: "High gain down" }], [41996, { 0: "Unknown", 1: "Macro", 2: "Close", 3: "Distant" }], [42080, { 0: "Unknown", 1: "Not a Composite Image", 2: "General Composite Image", 3: "Composite Image Captured While Shooting" }]]);
const vu = { 1: "No absolute unit of measurement", 2: "Inch", 3: "Centimeter" };
ji.set(37392, vu), ji.set(41488, vu);
const hs = { 0: "Normal", 1: "Low", 2: "High" };
function yu(n) {
  return typeof n == "object" && n.length !== void 0 ? n[0] : n;
}
function wu(n) {
  let e = Array.from(n).slice(1);
  return e[1] > 15 && (e = e.map((t) => String.fromCharCode(t))), e[2] !== "0" && e[2] !== 0 || e.pop(), e.join(".");
}
function ds(n) {
  if (typeof n == "string") {
    var [e, t, i, r, a, s] = n.trim().split(/[-: ]/g).map(Number), o = new Date(e, t - 1, i);
    return Number.isNaN(r) || Number.isNaN(a) || Number.isNaN(s) || (o.setHours(r), o.setMinutes(a), o.setSeconds(s)), Number.isNaN(+o) ? n : o;
  }
}
function $i(n) {
  if (typeof n == "string") return n;
  let e = [];
  if (n[1] === 0 && n[n.length - 1] === 0) for (let t = 0; t < n.length; t += 2) e.push(Du(n[t + 1], n[t]));
  else for (let t = 0; t < n.length; t += 2) e.push(Du(n[t], n[t + 1]));
  return In(String.fromCodePoint(...e));
}
function Du(n, e) {
  return n << 8 | e;
}
ji.set(41992, hs), ji.set(41993, hs), ji.set(41994, hs), He(Gr, ["ifd0", "ifd1"], [[50827, function(n) {
  return typeof n != "string" ? qf(n) : n;
}], [306, ds], [40091, $i], [40092, $i], [40093, $i], [40094, $i], [40095, $i]]), He(Gr, "exif", [[40960, wu], [36864, wu], [36867, ds], [36868, ds], [40962, yu], [40963, yu]]), He(Gr, "gps", [[0, (n) => Array.from(n).join(".")], [7, (n) => Array.from(n).join(":")]]);
class _s extends Bt {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 225 && e.getUint32(t + 4) === 1752462448 && e.getString(t + 4, 20) === "http://ns.adobe.com/";
  }
  static headerLength(e, t) {
    return e.getString(t + 4, 34) === "http://ns.adobe.com/xmp/extension/" ? 79 : 33;
  }
  static findPosition(e, t) {
    let i = super.findPosition(e, t);
    return i.multiSegment = i.extended = i.headerLength === 79, i.multiSegment ? (i.chunkCount = e.getUint8(t + 72), i.chunkNumber = e.getUint8(t + 76), e.getUint8(t + 77) !== 0 && i.chunkNumber++) : (i.chunkCount = 1 / 0, i.chunkNumber = -1), i;
  }
  static handleMultiSegments(e) {
    return e.map((t) => t.chunk.getString()).join("");
  }
  normalizeInput(e) {
    return typeof e == "string" ? e : lt.from(e).getString();
  }
  parse(e = this.chunk) {
    if (!this.localOptions.parse) return e;
    e = function(a) {
      let s = {}, o = {};
      for (let l of Jf) s[l] = [], o[l] = 0;
      return a.replace(h0, (l, c, u) => {
        if (c === "<") {
          let f = ++o[u];
          return s[u].push(f), `${l}#${f}`;
        }
        return `${l}#${s[u].pop()}`;
      });
    }(e);
    let t = fi.findAll(e, "rdf", "Description");
    t.length === 0 && t.push(new fi("rdf", "Description", void 0, e));
    let i, r = {};
    for (let a of t) for (let s of a.properties) i = f0(s.ns, r), Yf(s, i);
    return function(a) {
      let s;
      for (let o in a) s = a[o] = la(a[o]), s === void 0 && delete a[o];
      return la(a);
    }(r);
  }
  assignToOutput(e, t) {
    if (this.localOptions.parse) for (let [i, r] of Object.entries(t)) switch (i) {
      case "tiff":
        this.assignObjectToOutput(e, "ifd0", r);
        break;
      case "exif":
        this.assignObjectToOutput(e, "exif", r);
        break;
      case "xmlns":
        break;
      default:
        this.assignObjectToOutput(e, i, r);
    }
    else e.xmp = t;
  }
}
U(_s, "type", "xmp"), U(_s, "multiSegment", !0), We.set("xmp", _s);
class ca {
  static findAll(e) {
    return Kf(e, /([a-zA-Z0-9-]+):([a-zA-Z0-9-]+)=("[^"]*"|'[^']*')/gm).map(ca.unpackMatch);
  }
  static unpackMatch(e) {
    let t = e[1], i = e[2], r = e[3].slice(1, -1);
    return r = Qf(r), new ca(t, i, r);
  }
  constructor(e, t, i) {
    this.ns = e, this.name = t, this.value = i;
  }
  serialize() {
    return this.value;
  }
}
class fi {
  static findAll(e, t, i) {
    if (t !== void 0 || i !== void 0) {
      t = t || "[\\w\\d-]+", i = i || "[\\w\\d-]+";
      var r = new RegExp(`<(${t}):(${i})(#\\d+)?((\\s+?[\\w\\d-:]+=("[^"]*"|'[^']*'))*\\s*)(\\/>|>([\\s\\S]*?)<\\/\\1:\\2\\3>)`, "gm");
    } else r = /<([\w\d-]+):([\w\d-]+)(#\d+)?((\s+?[\w\d-:]+=("[^"]*"|'[^']*'))*\s*)(\/>|>([\s\S]*?)<\/\1:\2\3>)/gm;
    return Kf(e, r).map(fi.unpackMatch);
  }
  static unpackMatch(e) {
    let t = e[1], i = e[2], r = e[4], a = e[8];
    return new fi(t, i, r, a);
  }
  constructor(e, t, i, r) {
    this.ns = e, this.name = t, this.attrString = i, this.innerXml = r, this.attrs = ca.findAll(i), this.children = fi.findAll(r), this.value = this.children.length === 0 ? Qf(r) : void 0, this.properties = [...this.attrs, ...this.children];
  }
  get isPrimitive() {
    return this.value !== void 0 && this.attrs.length === 0 && this.children.length === 0;
  }
  get isListContainer() {
    return this.children.length === 1 && this.children[0].isList;
  }
  get isList() {
    let { ns: e, name: t } = this;
    return e === "rdf" && (t === "Seq" || t === "Bag" || t === "Alt");
  }
  get isListItem() {
    return this.ns === "rdf" && this.name === "li";
  }
  serialize() {
    if (this.properties.length === 0 && this.value === void 0) return;
    if (this.isPrimitive) return this.value;
    if (this.isListContainer) return this.children[0].serialize();
    if (this.isList) return c0(this.children.map(u0));
    if (this.isListItem && this.children.length === 1 && this.attrs.length === 0) return this.children[0].serialize();
    let e = {};
    for (let t of this.properties) Yf(t, e);
    return this.value !== void 0 && (e.value = this.value), la(e);
  }
}
function Yf(n, e) {
  let t = n.serialize();
  t !== void 0 && (e[n.name] = t);
}
var u0 = (n) => n.serialize(), c0 = (n) => n.length === 1 ? n[0] : n, f0 = (n, e) => e[n] ? e[n] : e[n] = {};
function Kf(n, e) {
  let t, i = [];
  if (!n) return i;
  for (; (t = e.exec(n)) !== null; ) i.push(t);
  return i;
}
function Qf(n) {
  if (function(i) {
    return i == null || i === "null" || i === "undefined" || i === "" || i.trim() === "";
  }(n)) return;
  let e = Number(n);
  if (!Number.isNaN(e)) return e;
  let t = n.toLowerCase();
  return t === "true" || t !== "false" && n.trim();
}
const Jf = ["rdf:li", "rdf:Seq", "rdf:Bag", "rdf:Alt", "rdf:Description"], h0 = new RegExp(`(<|\\/)(${Jf.join("|")})`, "g");
let Eu = oa("fs", (n) => n.promises);
wi.set("fs", class extends Ca {
  async readWhole() {
    this.chunked = !1, this.fs = await Eu;
    let n = await this.fs.readFile(this.input);
    this._swapBuffer(n);
  }
  async readChunked() {
    this.chunked = !0, this.fs = await Eu, await this.open(), await this.readChunk(0, this.options.firstChunkSize);
  }
  async open() {
    this.fh === void 0 && (this.fh = await this.fs.open(this.input, "r"), this.size = (await this.fh.stat(this.input)).size);
  }
  async _readChunk(n, e) {
    this.fh === void 0 && await this.open(), n + e > this.size && (e = this.size - n);
    var t = this.subarray(n, e, !0);
    return await this.fh.read(t.dataView, 0, e, n), t;
  }
  async close() {
    if (this.fh) {
      let n = this.fh;
      this.fh = void 0, await n.close();
    }
  }
});
wi.set("base64", class extends Ca {
  constructor(...n) {
    super(...n), this.input = this.input.replace(/^data:([^;]+);base64,/gim, ""), this.size = this.input.length / 4 * 3, this.input.endsWith("==") ? this.size -= 2 : this.input.endsWith("=") && (this.size -= 1);
  }
  async _readChunk(n, e) {
    let t, i, r = this.input;
    n === void 0 ? (n = 0, t = 0, i = 0) : (t = 4 * Math.floor(n / 3), i = n - t / 4 * 3), e === void 0 && (e = this.size);
    let a = n + e, s = t + 4 * Math.ceil(a / 3);
    r = r.slice(t, s);
    let o = Math.min(e, this.size - n);
    if (Bo) {
      let l = Po.from(r, "base64").slice(i, i + o);
      return this.set(l, n, !0);
    }
    {
      let l = this.subarray(n, o, !0), c = atob(r), u = l.toUint8();
      for (let f = 0; f < o; f++) u[f] = c.charCodeAt(i + f);
      return l;
    }
  }
});
let Cu = class extends Ea {
  static canHandle(e, t) {
    return t === 18761 || t === 19789;
  }
  extendOptions(e) {
    let { ifd0: t, xmp: i, iptc: r, icc: a } = e;
    i.enabled && t.deps.add(700), r.enabled && t.deps.add(33723), a.enabled && t.deps.add(34675), t.finalizeFilters();
  }
  async parse() {
    let { tiff: e, xmp: t, iptc: i, icc: r } = this.options;
    if (e.enabled || t.enabled || i.enabled || r.enabled) {
      let a = Math.max(Rs(this.options), this.options.chunkSize);
      await this.file.ensureChunk(0, a), this.createParser("tiff", this.file), this.parsers.tiff.parseHeader(), await this.parsers.tiff.parseIfd0Block(), this.adaptTiffPropAsSegment("xmp"), this.adaptTiffPropAsSegment("iptc"), this.adaptTiffPropAsSegment("icc");
    }
  }
  adaptTiffPropAsSegment(e) {
    if (this.parsers.tiff[e]) {
      let t = this.parsers.tiff[e];
      this.injectSegment(e, t);
    }
  }
};
U(Cu, "type", "tiff"), _i.set("tiff", Cu);
let d0 = oa("zlib");
const _0 = ["ihdr", "iccp", "text", "itxt", "exif"];
class ku extends Ea {
  constructor(...e) {
    super(...e), U(this, "catchError", (t) => this.errors.push(t)), U(this, "metaChunks", []), U(this, "unknownChunks", []);
  }
  static canHandle(e, t) {
    return t === 35152 && e.getUint32(0) === 2303741511 && e.getUint32(4) === 218765834;
  }
  async parse() {
    let { file: e } = this;
    await this.findPngChunksInRange(8, e.byteLength), await this.readSegments(this.metaChunks), this.findIhdr(), this.parseTextChunks(), await this.findExif().catch(this.catchError), await this.findXmp().catch(this.catchError), await this.findIcc().catch(this.catchError);
  }
  async findPngChunksInRange(e, t) {
    let { file: i } = this;
    for (; e < t; ) {
      let r = i.getUint32(e), a = i.getUint32(e + 4), s = i.getString(e + 4, 4).toLowerCase(), o = r + 4 + 4 + 4, l = { type: s, offset: e, length: o, start: e + 4 + 4, size: r, marker: a };
      _0.includes(s) ? this.metaChunks.push(l) : this.unknownChunks.push(l), e += o;
    }
  }
  parseTextChunks() {
    let e = this.metaChunks.filter((t) => t.type === "text");
    for (let t of e) {
      let [i, r] = this.file.getString(t.start, t.size).split("\0");
      this.injectKeyValToIhdr(i, r);
    }
  }
  injectKeyValToIhdr(e, t) {
    let i = this.parsers.ihdr;
    i && i.raw.set(e, t);
  }
  findIhdr() {
    let e = this.metaChunks.find((t) => t.type === "ihdr");
    e && this.options.ihdr.enabled !== !1 && this.createParser("ihdr", e.chunk);
  }
  async findExif() {
    let e = this.metaChunks.find((t) => t.type === "exif");
    e && this.injectSegment("tiff", e.chunk);
  }
  async findXmp() {
    let e = this.metaChunks.filter((t) => t.type === "itxt");
    for (let t of e)
      t.chunk.getString(0, 17) === "XML:com.adobe.xmp" && this.injectSegment("xmp", t.chunk);
  }
  async findIcc() {
    let e = this.metaChunks.find((o) => o.type === "iccp");
    if (!e) return;
    let { chunk: t } = e, i = t.getUint8Array(0, 81), r = 0;
    for (; r < 80 && i[r] !== 0; ) r++;
    let a = r + 2, s = t.getString(0, r);
    if (this.injectKeyValToIhdr("ProfileName", s), sa) {
      let o = await d0, l = t.getUint8Array(a);
      l = o.inflateSync(l), this.injectSegment("icc", l);
    }
  }
}
U(ku, "type", "png"), _i.set("png", ku), He(ut, "interop", [[1, "InteropIndex"], [2, "InteropVersion"], [4096, "RelatedImageFileFormat"], [4097, "RelatedImageWidth"], [4098, "RelatedImageHeight"]]), qs(ut, "ifd0", [[11, "ProcessingSoftware"], [254, "SubfileType"], [255, "OldSubfileType"], [263, "Thresholding"], [264, "CellWidth"], [265, "CellLength"], [266, "FillOrder"], [269, "DocumentName"], [280, "MinSampleValue"], [281, "MaxSampleValue"], [285, "PageName"], [286, "XPosition"], [287, "YPosition"], [290, "GrayResponseUnit"], [297, "PageNumber"], [321, "HalftoneHints"], [322, "TileWidth"], [323, "TileLength"], [332, "InkSet"], [337, "TargetPrinter"], [18246, "Rating"], [18249, "RatingPercent"], [33550, "PixelScale"], [34264, "ModelTransform"], [34377, "PhotoshopSettings"], [50706, "DNGVersion"], [50707, "DNGBackwardVersion"], [50708, "UniqueCameraModel"], [50709, "LocalizedCameraModel"], [50736, "DNGLensInfo"], [50739, "ShadowScale"], [50740, "DNGPrivateData"], [33920, "IntergraphMatrix"], [33922, "ModelTiePoint"], [34118, "SEMInfo"], [34735, "GeoTiffDirectory"], [34736, "GeoTiffDoubleParams"], [34737, "GeoTiffAsciiParams"], [50341, "PrintIM"], [50721, "ColorMatrix1"], [50722, "ColorMatrix2"], [50723, "CameraCalibration1"], [50724, "CameraCalibration2"], [50725, "ReductionMatrix1"], [50726, "ReductionMatrix2"], [50727, "AnalogBalance"], [50728, "AsShotNeutral"], [50729, "AsShotWhiteXY"], [50730, "BaselineExposure"], [50731, "BaselineNoise"], [50732, "BaselineSharpness"], [50734, "LinearResponseLimit"], [50735, "CameraSerialNumber"], [50741, "MakerNoteSafety"], [50778, "CalibrationIlluminant1"], [50779, "CalibrationIlluminant2"], [50781, "RawDataUniqueID"], [50827, "OriginalRawFileName"], [50828, "OriginalRawFileData"], [50831, "AsShotICCProfile"], [50832, "AsShotPreProfileMatrix"], [50833, "CurrentICCProfile"], [50834, "CurrentPreProfileMatrix"], [50879, "ColorimetricReference"], [50885, "SRawType"], [50898, "PanasonicTitle"], [50899, "PanasonicTitle2"], [50931, "CameraCalibrationSig"], [50932, "ProfileCalibrationSig"], [50933, "ProfileIFD"], [50934, "AsShotProfileName"], [50936, "ProfileName"], [50937, "ProfileHueSatMapDims"], [50938, "ProfileHueSatMapData1"], [50939, "ProfileHueSatMapData2"], [50940, "ProfileToneCurve"], [50941, "ProfileEmbedPolicy"], [50942, "ProfileCopyright"], [50964, "ForwardMatrix1"], [50965, "ForwardMatrix2"], [50966, "PreviewApplicationName"], [50967, "PreviewApplicationVersion"], [50968, "PreviewSettingsName"], [50969, "PreviewSettingsDigest"], [50970, "PreviewColorSpace"], [50971, "PreviewDateTime"], [50972, "RawImageDigest"], [50973, "OriginalRawFileDigest"], [50981, "ProfileLookTableDims"], [50982, "ProfileLookTableData"], [51043, "TimeCodes"], [51044, "FrameRate"], [51058, "TStop"], [51081, "ReelName"], [51089, "OriginalDefaultFinalSize"], [51090, "OriginalBestQualitySize"], [51091, "OriginalDefaultCropSize"], [51105, "CameraLabel"], [51107, "ProfileHueSatMapEncoding"], [51108, "ProfileLookTableEncoding"], [51109, "BaselineExposureOffset"], [51110, "DefaultBlackRender"], [51111, "NewRawImageDigest"], [51112, "RawToPreviewGain"]]);
let Su = [[273, "StripOffsets"], [279, "StripByteCounts"], [288, "FreeOffsets"], [289, "FreeByteCounts"], [291, "GrayResponseCurve"], [292, "T4Options"], [293, "T6Options"], [300, "ColorResponseUnit"], [320, "ColorMap"], [324, "TileOffsets"], [325, "TileByteCounts"], [326, "BadFaxLines"], [327, "CleanFaxData"], [328, "ConsecutiveBadFaxLines"], [330, "SubIFD"], [333, "InkNames"], [334, "NumberofInks"], [336, "DotRange"], [338, "ExtraSamples"], [339, "SampleFormat"], [340, "SMinSampleValue"], [341, "SMaxSampleValue"], [342, "TransferRange"], [343, "ClipPath"], [344, "XClipPathUnits"], [345, "YClipPathUnits"], [346, "Indexed"], [347, "JPEGTables"], [351, "OPIProxy"], [400, "GlobalParametersIFD"], [401, "ProfileType"], [402, "FaxProfile"], [403, "CodingMethods"], [404, "VersionYear"], [405, "ModeNumber"], [433, "Decode"], [434, "DefaultImageColor"], [435, "T82Options"], [437, "JPEGTables"], [512, "JPEGProc"], [515, "JPEGRestartInterval"], [517, "JPEGLosslessPredictors"], [518, "JPEGPointTransforms"], [519, "JPEGQTables"], [520, "JPEGDCTables"], [521, "JPEGACTables"], [559, "StripRowCounts"], [999, "USPTOMiscellaneous"], [18247, "XP_DIP_XML"], [18248, "StitchInfo"], [28672, "SonyRawFileType"], [28688, "SonyToneCurve"], [28721, "VignettingCorrection"], [28722, "VignettingCorrParams"], [28724, "ChromaticAberrationCorrection"], [28725, "ChromaticAberrationCorrParams"], [28726, "DistortionCorrection"], [28727, "DistortionCorrParams"], [29895, "SonyCropTopLeft"], [29896, "SonyCropSize"], [32781, "ImageID"], [32931, "WangTag1"], [32932, "WangAnnotation"], [32933, "WangTag3"], [32934, "WangTag4"], [32953, "ImageReferencePoints"], [32954, "RegionXformTackPoint"], [32955, "WarpQuadrilateral"], [32956, "AffineTransformMat"], [32995, "Matteing"], [32996, "DataType"], [32997, "ImageDepth"], [32998, "TileDepth"], [33300, "ImageFullWidth"], [33301, "ImageFullHeight"], [33302, "TextureFormat"], [33303, "WrapModes"], [33304, "FovCot"], [33305, "MatrixWorldToScreen"], [33306, "MatrixWorldToCamera"], [33405, "Model2"], [33421, "CFARepeatPatternDim"], [33422, "CFAPattern2"], [33423, "BatteryLevel"], [33424, "KodakIFD"], [33445, "MDFileTag"], [33446, "MDScalePixel"], [33447, "MDColorTable"], [33448, "MDLabName"], [33449, "MDSampleInfo"], [33450, "MDPrepDate"], [33451, "MDPrepTime"], [33452, "MDFileUnits"], [33589, "AdventScale"], [33590, "AdventRevision"], [33628, "UIC1Tag"], [33629, "UIC2Tag"], [33630, "UIC3Tag"], [33631, "UIC4Tag"], [33918, "IntergraphPacketData"], [33919, "IntergraphFlagRegisters"], [33921, "INGRReserved"], [34016, "Site"], [34017, "ColorSequence"], [34018, "IT8Header"], [34019, "RasterPadding"], [34020, "BitsPerRunLength"], [34021, "BitsPerExtendedRunLength"], [34022, "ColorTable"], [34023, "ImageColorIndicator"], [34024, "BackgroundColorIndicator"], [34025, "ImageColorValue"], [34026, "BackgroundColorValue"], [34027, "PixelIntensityRange"], [34028, "TransparencyIndicator"], [34029, "ColorCharacterization"], [34030, "HCUsage"], [34031, "TrapIndicator"], [34032, "CMYKEquivalent"], [34152, "AFCP_IPTC"], [34232, "PixelMagicJBIGOptions"], [34263, "JPLCartoIFD"], [34306, "WB_GRGBLevels"], [34310, "LeafData"], [34687, "TIFF_FXExtensions"], [34688, "MultiProfiles"], [34689, "SharedData"], [34690, "T88Options"], [34732, "ImageLayer"], [34750, "JBIGOptions"], [34856, "Opto-ElectricConvFactor"], [34857, "Interlace"], [34908, "FaxRecvParams"], [34909, "FaxSubAddress"], [34910, "FaxRecvTime"], [34929, "FedexEDR"], [34954, "LeafSubIFD"], [37387, "FlashEnergy"], [37388, "SpatialFrequencyResponse"], [37389, "Noise"], [37390, "FocalPlaneXResolution"], [37391, "FocalPlaneYResolution"], [37392, "FocalPlaneResolutionUnit"], [37397, "ExposureIndex"], [37398, "TIFF-EPStandardID"], [37399, "SensingMethod"], [37434, "CIP3DataFile"], [37435, "CIP3Sheet"], [37436, "CIP3Side"], [37439, "StoNits"], [37679, "MSDocumentText"], [37680, "MSPropertySetStorage"], [37681, "MSDocumentTextPosition"], [37724, "ImageSourceData"], [40965, "InteropIFD"], [40976, "SamsungRawPointersOffset"], [40977, "SamsungRawPointersLength"], [41217, "SamsungRawByteOrder"], [41218, "SamsungRawUnknown"], [41484, "SpatialFrequencyResponse"], [41485, "Noise"], [41489, "ImageNumber"], [41490, "SecurityClassification"], [41491, "ImageHistory"], [41494, "TIFF-EPStandardID"], [41995, "DeviceSettingDescription"], [42112, "GDALMetadata"], [42113, "GDALNoData"], [44992, "ExpandSoftware"], [44993, "ExpandLens"], [44994, "ExpandFilm"], [44995, "ExpandFilterLens"], [44996, "ExpandScanner"], [44997, "ExpandFlashLamp"], [46275, "HasselbladRawImage"], [48129, "PixelFormat"], [48130, "Transformation"], [48131, "Uncompressed"], [48132, "ImageType"], [48256, "ImageWidth"], [48257, "ImageHeight"], [48258, "WidthResolution"], [48259, "HeightResolution"], [48320, "ImageOffset"], [48321, "ImageByteCount"], [48322, "AlphaOffset"], [48323, "AlphaByteCount"], [48324, "ImageDataDiscard"], [48325, "AlphaDataDiscard"], [50215, "OceScanjobDesc"], [50216, "OceApplicationSelector"], [50217, "OceIDNumber"], [50218, "OceImageLogic"], [50255, "Annotations"], [50459, "HasselbladExif"], [50547, "OriginalFileName"], [50560, "USPTOOriginalContentType"], [50656, "CR2CFAPattern"], [50710, "CFAPlaneColor"], [50711, "CFALayout"], [50712, "LinearizationTable"], [50713, "BlackLevelRepeatDim"], [50714, "BlackLevel"], [50715, "BlackLevelDeltaH"], [50716, "BlackLevelDeltaV"], [50717, "WhiteLevel"], [50718, "DefaultScale"], [50719, "DefaultCropOrigin"], [50720, "DefaultCropSize"], [50733, "BayerGreenSplit"], [50737, "ChromaBlurRadius"], [50738, "AntiAliasStrength"], [50752, "RawImageSegmentation"], [50780, "BestQualityScale"], [50784, "AliasLayerMetadata"], [50829, "ActiveArea"], [50830, "MaskedAreas"], [50935, "NoiseReductionApplied"], [50974, "SubTileBlockSize"], [50975, "RowInterleaveFactor"], [51008, "OpcodeList1"], [51009, "OpcodeList2"], [51022, "OpcodeList3"], [51041, "NoiseProfile"], [51114, "CacheVersion"], [51125, "DefaultUserCrop"], [51157, "NikonNEFInfo"], [65024, "KdcIFD"]];
qs(ut, "ifd0", Su), qs(ut, "exif", Su), He(Zn, "gps", [[23, { M: "Magnetic North", T: "True North" }], [25, { K: "Kilometers", M: "Miles", N: "Nautical Miles" }]]);
class ps extends Bt {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 224 && e.getUint32(t + 4) === 1246120262 && e.getUint8(t + 8) === 0;
  }
  parse() {
    return this.parseTags(), this.translate(), this.output;
  }
  parseTags() {
    this.raw = /* @__PURE__ */ new Map([[0, this.chunk.getUint16(0)], [2, this.chunk.getUint8(2)], [3, this.chunk.getUint16(3)], [5, this.chunk.getUint16(5)], [7, this.chunk.getUint8(7)], [8, this.chunk.getUint8(8)]]);
  }
}
U(ps, "type", "jfif"), U(ps, "headerLength", 9), We.set("jfif", ps), He(ut, "jfif", [[0, "JFIFVersion"], [2, "ResolutionUnit"], [3, "XResolution"], [5, "YResolution"], [7, "ThumbnailWidth"], [8, "ThumbnailHeight"]]);
class Au extends Bt {
  parse() {
    return this.parseTags(), this.translate(), this.output;
  }
  parseTags() {
    this.raw = new Map([[0, this.chunk.getUint32(0)], [4, this.chunk.getUint32(4)], [8, this.chunk.getUint8(8)], [9, this.chunk.getUint8(9)], [10, this.chunk.getUint8(10)], [11, this.chunk.getUint8(11)], [12, this.chunk.getUint8(12)], ...Array.from(this.raw)]);
  }
}
U(Au, "type", "ihdr"), We.set("ihdr", Au), He(ut, "ihdr", [[0, "ImageWidth"], [4, "ImageHeight"], [8, "BitDepth"], [9, "ColorType"], [10, "Compression"], [11, "Filter"], [12, "Interlace"]]), He(Zn, "ihdr", [[9, { 0: "Grayscale", 2: "RGB", 3: "Palette", 4: "Grayscale with Alpha", 6: "RGB with Alpha", DEFAULT: "Unknown" }], [10, { 0: "Deflate/Inflate", DEFAULT: "Unknown" }], [11, { 0: "Adaptive", DEFAULT: "Unknown" }], [12, { 0: "Noninterlaced", 1: "Adam7 Interlace", DEFAULT: "Unknown" }]]);
class zr extends Bt {
  static canHandle(e, t) {
    return e.getUint8(t + 1) === 226 && e.getUint32(t + 4) === 1229144927;
  }
  static findPosition(e, t) {
    let i = super.findPosition(e, t);
    return i.chunkNumber = e.getUint8(t + 16), i.chunkCount = e.getUint8(t + 17), i.multiSegment = i.chunkCount > 1, i;
  }
  static handleMultiSegments(e) {
    return function(t) {
      let i = function(r) {
        let a = r[0].constructor, s = 0;
        for (let c of r) s += c.length;
        let o = new a(s), l = 0;
        for (let c of r) o.set(c, l), l += c.length;
        return o;
      }(t.map((r) => r.chunk.toUint8()));
      return new lt(i);
    }(e);
  }
  parse() {
    return this.raw = /* @__PURE__ */ new Map(), this.parseHeader(), this.parseTags(), this.translate(), this.output;
  }
  parseHeader() {
    let { raw: e } = this;
    this.chunk.byteLength < 84 && $e("ICC header is too short");
    for (let [t, i] of Object.entries(p0)) {
      t = parseInt(t, 10);
      let r = i(this.chunk, t);
      r !== "\0\0\0\0" && e.set(t, r);
    }
  }
  parseTags() {
    let e, t, i, r, a, { raw: s } = this, o = this.chunk.getUint32(128), l = 132, c = this.chunk.byteLength;
    for (; o--; ) {
      if (e = this.chunk.getString(l, 4), t = this.chunk.getUint32(l + 4), i = this.chunk.getUint32(l + 8), r = this.chunk.getString(t, 4), t + i > c) return void console.warn("reached the end of the first ICC chunk. Enable options.tiff.multiSegment to read all ICC segments.");
      a = this.parseTag(r, t, i), a !== void 0 && a !== "\0\0\0\0" && s.set(e, a), l += 12;
    }
  }
  parseTag(e, t, i) {
    switch (e) {
      case "desc":
        return this.parseDesc(t);
      case "mluc":
        return this.parseMluc(t);
      case "text":
        return this.parseText(t, i);
      case "sig ":
        return this.parseSig(t);
    }
    if (!(t + i > this.chunk.byteLength)) return this.chunk.getUint8Array(t, i);
  }
  parseDesc(e) {
    let t = this.chunk.getUint32(e + 8) - 1;
    return In(this.chunk.getString(e + 12, t));
  }
  parseText(e, t) {
    return In(this.chunk.getString(e + 8, t - 8));
  }
  parseSig(e) {
    return In(this.chunk.getString(e + 8, 4));
  }
  parseMluc(e) {
    let { chunk: t } = this, i = t.getUint32(e + 8), r = t.getUint32(e + 12), a = e + 16, s = [];
    for (let o = 0; o < i; o++) {
      let l = t.getString(a + 0, 2), c = t.getString(a + 2, 2), u = t.getUint32(a + 4), f = t.getUint32(a + 8) + e, h = In(t.getUnicodeString(f, u));
      s.push({ lang: l, country: c, text: h }), a += r;
    }
    return i === 1 ? s[0].text : s;
  }
  translateValue(e, t) {
    return typeof e == "string" ? t[e] || t[e.toLowerCase()] || e : t[e] || e;
  }
}
U(zr, "type", "icc"), U(zr, "multiSegment", !0), U(zr, "headerLength", 18);
const p0 = { 4: on, 8: function(n, e) {
  return [n.getUint8(e), n.getUint8(e + 1) >> 4, n.getUint8(e + 1) % 16].map((t) => t.toString(10)).join(".");
}, 12: on, 16: on, 20: on, 24: function(n, e) {
  const t = n.getUint16(e), i = n.getUint16(e + 2) - 1, r = n.getUint16(e + 4), a = n.getUint16(e + 6), s = n.getUint16(e + 8), o = n.getUint16(e + 10);
  return new Date(Date.UTC(t, i, r, a, s, o));
}, 36: on, 40: on, 48: on, 52: on, 64: (n, e) => n.getUint32(e), 80: on };
function on(n, e) {
  return In(n.getString(e, 4));
}
We.set("icc", zr), He(ut, "icc", [[4, "ProfileCMMType"], [8, "ProfileVersion"], [12, "ProfileClass"], [16, "ColorSpaceData"], [20, "ProfileConnectionSpace"], [24, "ProfileDateTime"], [36, "ProfileFileSignature"], [40, "PrimaryPlatform"], [44, "CMMFlags"], [48, "DeviceManufacturer"], [52, "DeviceModel"], [56, "DeviceAttributes"], [64, "RenderingIntent"], [68, "ConnectionSpaceIlluminant"], [80, "ProfileCreator"], [84, "ProfileID"], ["Header", "ProfileHeader"], ["MS00", "WCSProfiles"], ["bTRC", "BlueTRC"], ["bXYZ", "BlueMatrixColumn"], ["bfd", "UCRBG"], ["bkpt", "MediaBlackPoint"], ["calt", "CalibrationDateTime"], ["chad", "ChromaticAdaptation"], ["chrm", "Chromaticity"], ["ciis", "ColorimetricIntentImageState"], ["clot", "ColorantTableOut"], ["clro", "ColorantOrder"], ["clrt", "ColorantTable"], ["cprt", "ProfileCopyright"], ["crdi", "CRDInfo"], ["desc", "ProfileDescription"], ["devs", "DeviceSettings"], ["dmdd", "DeviceModelDesc"], ["dmnd", "DeviceMfgDesc"], ["dscm", "ProfileDescriptionML"], ["fpce", "FocalPlaneColorimetryEstimates"], ["gTRC", "GreenTRC"], ["gXYZ", "GreenMatrixColumn"], ["gamt", "Gamut"], ["kTRC", "GrayTRC"], ["lumi", "Luminance"], ["meas", "Measurement"], ["meta", "Metadata"], ["mmod", "MakeAndModel"], ["ncl2", "NamedColor2"], ["ncol", "NamedColor"], ["ndin", "NativeDisplayInfo"], ["pre0", "Preview0"], ["pre1", "Preview1"], ["pre2", "Preview2"], ["ps2i", "PS2RenderingIntent"], ["ps2s", "PostScript2CSA"], ["psd0", "PostScript2CRD0"], ["psd1", "PostScript2CRD1"], ["psd2", "PostScript2CRD2"], ["psd3", "PostScript2CRD3"], ["pseq", "ProfileSequenceDesc"], ["psid", "ProfileSequenceIdentifier"], ["psvm", "PS2CRDVMSize"], ["rTRC", "RedTRC"], ["rXYZ", "RedMatrixColumn"], ["resp", "OutputResponse"], ["rhoc", "ReflectionHardcopyOrigColorimetry"], ["rig0", "PerceptualRenderingIntentGamut"], ["rig2", "SaturationRenderingIntentGamut"], ["rpoc", "ReflectionPrintOutputColorimetry"], ["sape", "SceneAppearanceEstimates"], ["scoe", "SceneColorimetryEstimates"], ["scrd", "ScreeningDesc"], ["scrn", "Screening"], ["targ", "CharTarget"], ["tech", "Technology"], ["vcgt", "VideoCardGamma"], ["view", "ViewingConditions"], ["vued", "ViewingCondDesc"], ["wtpt", "MediaWhitePoint"]]);
const xr = { "4d2p": "Erdt Systems", AAMA: "Aamazing Technologies", ACER: "Acer", ACLT: "Acolyte Color Research", ACTI: "Actix Sytems", ADAR: "Adara Technology", ADBE: "Adobe", ADI: "ADI Systems", AGFA: "Agfa Graphics", ALMD: "Alps Electric", ALPS: "Alps Electric", ALWN: "Alwan Color Expertise", AMTI: "Amiable Technologies", AOC: "AOC International", APAG: "Apago", APPL: "Apple Computer", AST: "AST", "AT&T": "AT&T", BAEL: "BARBIERI electronic", BRCO: "Barco NV", BRKP: "Breakpoint", BROT: "Brother", BULL: "Bull", BUS: "Bus Computer Systems", "C-IT": "C-Itoh", CAMR: "Intel", CANO: "Canon", CARR: "Carroll Touch", CASI: "Casio", CBUS: "Colorbus PL", CEL: "Crossfield", CELx: "Crossfield", CGS: "CGS Publishing Technologies International", CHM: "Rochester Robotics", CIGL: "Colour Imaging Group, London", CITI: "Citizen", CL00: "Candela", CLIQ: "Color IQ", CMCO: "Chromaco", CMiX: "CHROMiX", COLO: "Colorgraphic Communications", COMP: "Compaq", COMp: "Compeq/Focus Technology", CONR: "Conrac Display Products", CORD: "Cordata Technologies", CPQ: "Compaq", CPRO: "ColorPro", CRN: "Cornerstone", CTX: "CTX International", CVIS: "ColorVision", CWC: "Fujitsu Laboratories", DARI: "Darius Technology", DATA: "Dataproducts", DCP: "Dry Creek Photo", DCRC: "Digital Contents Resource Center, Chung-Ang University", DELL: "Dell Computer", DIC: "Dainippon Ink and Chemicals", DICO: "Diconix", DIGI: "Digital", "DL&C": "Digital Light & Color", DPLG: "Doppelganger", DS: "Dainippon Screen", DSOL: "DOOSOL", DUPN: "DuPont", EPSO: "Epson", ESKO: "Esko-Graphics", ETRI: "Electronics and Telecommunications Research Institute", EVER: "Everex Systems", EXAC: "ExactCODE", Eizo: "Eizo", FALC: "Falco Data Products", FF: "Fuji Photo Film", FFEI: "FujiFilm Electronic Imaging", FNRD: "Fnord Software", FORA: "Fora", FORE: "Forefront Technology", FP: "Fujitsu", FPA: "WayTech Development", FUJI: "Fujitsu", FX: "Fuji Xerox", GCC: "GCC Technologies", GGSL: "Global Graphics Software", GMB: "Gretagmacbeth", GMG: "GMG", GOLD: "GoldStar Technology", GOOG: "Google", GPRT: "Giantprint", GTMB: "Gretagmacbeth", GVC: "WayTech Development", GW2K: "Sony", HCI: "HCI", HDM: "Heidelberger Druckmaschinen", HERM: "Hermes", HITA: "Hitachi America", HP: "Hewlett-Packard", HTC: "Hitachi", HiTi: "HiTi Digital", IBM: "IBM", IDNT: "Scitex", IEC: "Hewlett-Packard", IIYA: "Iiyama North America", IKEG: "Ikegami Electronics", IMAG: "Image Systems", IMI: "Ingram Micro", INTC: "Intel", INTL: "N/A (INTL)", INTR: "Intra Electronics", IOCO: "Iocomm International Technology", IPS: "InfoPrint Solutions Company", IRIS: "Scitex", ISL: "Ichikawa Soft Laboratory", ITNL: "N/A (ITNL)", IVM: "IVM", IWAT: "Iwatsu Electric", Idnt: "Scitex", Inca: "Inca Digital Printers", Iris: "Scitex", JPEG: "Joint Photographic Experts Group", JSFT: "Jetsoft Development", JVC: "JVC Information Products", KART: "Scitex", KFC: "KFC Computek Components", KLH: "KLH Computers", KMHD: "Konica Minolta", KNCA: "Konica", KODA: "Kodak", KYOC: "Kyocera", Kart: "Scitex", LCAG: "Leica", LCCD: "Leeds Colour", LDAK: "Left Dakota", LEAD: "Leading Technology", LEXM: "Lexmark International", LINK: "Link Computer", LINO: "Linotronic", LITE: "Lite-On", Leaf: "Leaf", Lino: "Linotronic", MAGC: "Mag Computronic", MAGI: "MAG Innovision", MANN: "Mannesmann", MICN: "Micron Technology", MICR: "Microtek", MICV: "Microvitec", MINO: "Minolta", MITS: "Mitsubishi Electronics America", MITs: "Mitsuba", MNLT: "Minolta", MODG: "Modgraph", MONI: "Monitronix", MONS: "Monaco Systems", MORS: "Morse Technology", MOTI: "Motive Systems", MSFT: "Microsoft", MUTO: "MUTOH INDUSTRIES", Mits: "Mitsubishi Electric", NANA: "NANAO", NEC: "NEC", NEXP: "NexPress Solutions", NISS: "Nissei Sangyo America", NKON: "Nikon", NONE: "none", OCE: "Oce Technologies", OCEC: "OceColor", OKI: "Oki", OKID: "Okidata", OKIP: "Okidata", OLIV: "Olivetti", OLYM: "Olympus", ONYX: "Onyx Graphics", OPTI: "Optiquest", PACK: "Packard Bell", PANA: "Matsushita Electric Industrial", PANT: "Pantone", PBN: "Packard Bell", PFU: "PFU", PHIL: "Philips Consumer Electronics", PNTX: "HOYA", POne: "Phase One A/S", PREM: "Premier Computer Innovations", PRIN: "Princeton Graphic Systems", PRIP: "Princeton Publishing Labs", QLUX: "Hong Kong", QMS: "QMS", QPCD: "QPcard AB", QUAD: "QuadLaser", QUME: "Qume", RADI: "Radius", RDDx: "Integrated Color Solutions", RDG: "Roland DG", REDM: "REDMS Group", RELI: "Relisys", RGMS: "Rolf Gierling Multitools", RICO: "Ricoh", RNLD: "Edmund Ronald", ROYA: "Royal", RPC: "Ricoh Printing Systems", RTL: "Royal Information Electronics", SAMP: "Sampo", SAMS: "Samsung", SANT: "Jaime Santana Pomares", SCIT: "Scitex", SCRN: "Dainippon Screen", SDP: "Scitex", SEC: "Samsung", SEIK: "Seiko Instruments", SEIk: "Seikosha", SGUY: "ScanGuy.com", SHAR: "Sharp Laboratories", SICC: "International Color Consortium", SONY: "Sony", SPCL: "SpectraCal", STAR: "Star", STC: "Sampo Technology", Scit: "Scitex", Sdp: "Scitex", Sony: "Sony", TALO: "Talon Technology", TAND: "Tandy", TATU: "Tatung", TAXA: "TAXAN America", TDS: "Tokyo Denshi Sekei", TECO: "TECO Information Systems", TEGR: "Tegra", TEKT: "Tektronix", TI: "Texas Instruments", TMKR: "TypeMaker", TOSB: "Toshiba", TOSH: "Toshiba", TOTK: "TOTOKU ELECTRIC", TRIU: "Triumph", TSBT: "Toshiba", TTX: "TTX Computer Products", TVM: "TVM Professional Monitor", TW: "TW Casper", ULSX: "Ulead Systems", UNIS: "Unisys", UTZF: "Utz Fehlau & Sohn", VARI: "Varityper", VIEW: "Viewsonic", VISL: "Visual communication", VIVO: "Vivo Mobile Communication", WANG: "Wang", WLBR: "Wilbur Imaging", WTG2: "Ware To Go", WYSE: "WYSE Technology", XERX: "Xerox", XRIT: "X-Rite", ZRAN: "Zoran", Zebr: "Zebra Technologies", appl: "Apple Computer", bICC: "basICColor", berg: "bergdesign", ceyd: "Integrated Color Solutions", clsp: "MacDermid ColorSpan", ds: "Dainippon Screen", dupn: "DuPont", ffei: "FujiFilm Electronic Imaging", flux: "FluxData", iris: "Scitex", kart: "Scitex", lcms: "Little CMS", lino: "Linotronic", none: "none", ob4d: "Erdt Systems", obic: "Medigraph", quby: "Qubyx Sarl", scit: "Scitex", scrn: "Dainippon Screen", sdp: "Scitex", siwi: "SIWI GRAFIKA", yxym: "YxyMaster" }, Fu = { scnr: "Scanner", mntr: "Monitor", prtr: "Printer", link: "Device Link", abst: "Abstract", spac: "Color Space Conversion Profile", nmcl: "Named Color", cenc: "ColorEncodingSpace profile", mid: "MultiplexIdentification profile", mlnk: "MultiplexLink profile", mvis: "MultiplexVisualization profile", nkpf: "Nikon Input Device Profile (NON-STANDARD!)" };
He(Zn, "icc", [[4, xr], [12, Fu], [40, Object.assign({}, xr, Fu)], [48, xr], [80, xr], [64, { 0: "Perceptual", 1: "Relative Colorimetric", 2: "Saturation", 3: "Absolute Colorimetric" }], ["tech", { amd: "Active Matrix Display", crt: "Cathode Ray Tube Display", kpcd: "Photo CD", pmd: "Passive Matrix Display", dcam: "Digital Camera", dcpj: "Digital Cinema Projector", dmpc: "Digital Motion Picture Camera", dsub: "Dye Sublimation Printer", epho: "Electrophotographic Printer", esta: "Electrostatic Printer", flex: "Flexography", fprn: "Film Writer", fscn: "Film Scanner", grav: "Gravure", ijet: "Ink Jet Printer", imgs: "Photo Image Setter", mpfr: "Motion Picture Film Recorder", mpfs: "Motion Picture Film Scanner", offs: "Offset Lithography", pjtv: "Projection Television", rpho: "Photographic Paper Printer", rscn: "Reflective Scanner", silk: "Silkscreen", twax: "Thermal Wax Printer", vidc: "Video Camera", vidm: "Video Monitor" }]]);
class Pr extends Bt {
  static canHandle(e, t, i) {
    return e.getUint8(t + 1) === 237 && e.getString(t + 4, 9) === "Photoshop" && this.containsIptc8bim(e, t, i) !== void 0;
  }
  static headerLength(e, t, i) {
    let r, a = this.containsIptc8bim(e, t, i);
    if (a !== void 0) return r = e.getUint8(t + a + 7), r % 2 != 0 && (r += 1), r === 0 && (r = 4), a + 8 + r;
  }
  static containsIptc8bim(e, t, i) {
    for (let r = 0; r < i; r++) if (this.isIptcSegmentHead(e, t + r)) return r;
  }
  static isIptcSegmentHead(e, t) {
    return e.getUint8(t) === 56 && e.getUint32(t) === 943868237 && e.getUint16(t + 4) === 1028;
  }
  parse() {
    let { raw: e } = this, t = this.chunk.byteLength - 1, i = !1;
    for (let r = 0; r < t; r++) if (this.chunk.getUint8(r) === 28 && this.chunk.getUint8(r + 1) === 2) {
      i = !0;
      let a = this.chunk.getUint16(r + 3), s = this.chunk.getUint8(r + 2), o = this.chunk.getLatin1String(r + 5, a);
      e.set(s, this.pluralizeValue(e.get(s), o)), r += 4 + a;
    } else if (i) break;
    return this.translate(), this.output;
  }
  pluralizeValue(e, t) {
    return e !== void 0 ? e instanceof Array ? (e.push(t), e) : [e, t] : t;
  }
}
U(Pr, "type", "iptc"), U(Pr, "translateValues", !1), U(Pr, "reviveValues", !1), We.set("iptc", Pr), He(ut, "iptc", [[0, "ApplicationRecordVersion"], [3, "ObjectTypeReference"], [4, "ObjectAttributeReference"], [5, "ObjectName"], [7, "EditStatus"], [8, "EditorialUpdate"], [10, "Urgency"], [12, "SubjectReference"], [15, "Category"], [20, "SupplementalCategories"], [22, "FixtureIdentifier"], [25, "Keywords"], [26, "ContentLocationCode"], [27, "ContentLocationName"], [30, "ReleaseDate"], [35, "ReleaseTime"], [37, "ExpirationDate"], [38, "ExpirationTime"], [40, "SpecialInstructions"], [42, "ActionAdvised"], [45, "ReferenceService"], [47, "ReferenceDate"], [50, "ReferenceNumber"], [55, "DateCreated"], [60, "TimeCreated"], [62, "DigitalCreationDate"], [63, "DigitalCreationTime"], [65, "OriginatingProgram"], [70, "ProgramVersion"], [75, "ObjectCycle"], [80, "Byline"], [85, "BylineTitle"], [90, "City"], [92, "Sublocation"], [95, "State"], [100, "CountryCode"], [101, "Country"], [103, "OriginalTransmissionReference"], [105, "Headline"], [110, "Credit"], [115, "Source"], [116, "CopyrightNotice"], [118, "Contact"], [120, "Caption"], [121, "LocalCaption"], [122, "Writer"], [125, "RasterizedCaption"], [130, "ImageType"], [131, "ImageOrientation"], [135, "LanguageIdentifier"], [150, "AudioType"], [151, "AudioSamplingRate"], [152, "AudioSamplingResolution"], [153, "AudioDuration"], [154, "AudioOutcue"], [184, "JobID"], [185, "MasterDocumentID"], [186, "ShortDocumentID"], [187, "UniqueDocumentID"], [188, "OwnerID"], [200, "ObjectPreviewFileFormat"], [201, "ObjectPreviewFileVersion"], [202, "ObjectPreviewData"], [221, "Prefs"], [225, "ClassifyState"], [228, "SimilarityIndex"], [230, "DocumentNotes"], [231, "DocumentHistory"], [232, "ExifCameraInfo"], [255, "CatalogSets"]]), He(Zn, "iptc", [[10, { 0: "0 (reserved)", 1: "1 (most urgent)", 2: "2", 3: "3", 4: "4", 5: "5 (normal urgency)", 6: "6", 7: "7", 8: "8 (least urgent)", 9: "9 (user-defined priority)" }], [75, { a: "Morning", b: "Both Morning and Evening", p: "Evening" }], [131, { L: "Landscape", P: "Portrait", S: "Square" }]]);
const {
  SvelteComponent: m0,
  append_hydration: Ne,
  attr: mt,
  binding_callbacks: g0,
  bubble: Br,
  check_outros: Mi,
  children: vt,
  claim_component: Qt,
  claim_element: Je,
  claim_space: Nt,
  claim_text: Ws,
  create_component: Jt,
  destroy_component: en,
  destroy_each: b0,
  detach: ue,
  element: et,
  empty: pi,
  ensure_array_like: Tu,
  get_svelte_dataset: Xs,
  group_outros: Ni,
  init: v0,
  insert_hydration: tt,
  listen: No,
  mount_component: tn,
  noop: y0,
  safe_not_equal: w0,
  set_data: Zs,
  set_style: gn,
  space: Ut,
  text: Ys,
  toggle_class: Iu,
  transition_in: ge,
  transition_out: Ie
} = window.__gradio__svelte__internal, { createEventDispatcher: D0, onMount: y6 } = window.__gradio__svelte__internal;
function $u(n, e, t) {
  const i = n.slice();
  return i[35] = e[t][0], i[36] = e[t][1], i;
}
function E0(n) {
  let e, t, i, r, a, s, o, l, c;
  return t = new kf({
    props: {
      display_top_corner: (
        /*display_icon_button_wrapper_top_corner*/
        n[8]
      ),
      $$slots: { default: [S0] },
      $$scope: { ctx: n }
    }
  }), s = new xo({
    props: {
      src: (
        /*value*/
        n[0].url
      ),
      alt: "",
      loading: "lazy"
    }
  }), s.$on(
    "load",
    /*load_handler*/
    n[29]
  ), {
    c() {
      e = et("div"), Jt(t.$$.fragment), i = Ut(), r = et("button"), a = et("div"), Jt(s.$$.fragment), this.h();
    },
    l(u) {
      e = Je(u, "DIV", { class: !0 });
      var f = vt(e);
      Qt(t.$$.fragment, f), i = Nt(f), r = Je(f, "BUTTON", { class: !0 });
      var h = vt(r);
      a = Je(h, "DIV", { class: !0 });
      var d = vt(a);
      Qt(s.$$.fragment, d), d.forEach(ue), h.forEach(ue), f.forEach(ue), this.h();
    },
    h() {
      mt(a, "class", "image-frame svelte-1glxd5l"), Iu(
        a,
        "selectable",
        /*selectable*/
        n[4]
      ), mt(r, "class", "svelte-1glxd5l"), mt(e, "class", "image-container svelte-1glxd5l"), gn(
        e,
        "height",
        /*height*/
        n[12]
      ), gn(
        e,
        "width",
        /*width*/
        n[13]
      );
    },
    m(u, f) {
      tt(u, e, f), tn(t, e, null), Ne(e, i), Ne(e, r), Ne(r, a), tn(s, a, null), n[30](e), o = !0, l || (c = No(
        r,
        "click",
        /*handle_click*/
        n[19]
      ), l = !0);
    },
    p(u, f) {
      const h = {};
      f[0] & /*display_icon_button_wrapper_top_corner*/
      256 && (h.display_top_corner = /*display_icon_button_wrapper_top_corner*/
      u[8]), f[0] & /*i18n, value, show_share_button, show_download_button, metadata, fullscreen, show_fullscreen_button*/
      17129 | f[1] & /*$$scope*/
      256 && (h.$$scope = { dirty: f, ctx: u }), t.$set(h);
      const d = {};
      f[0] & /*value*/
      1 && (d.src = /*value*/
      u[0].url), s.$set(d), (!o || f[0] & /*selectable*/
      16) && Iu(
        a,
        "selectable",
        /*selectable*/
        u[4]
      ), f[0] & /*height*/
      4096 && gn(
        e,
        "height",
        /*height*/
        u[12]
      ), f[0] & /*width*/
      8192 && gn(
        e,
        "width",
        /*width*/
        u[13]
      );
    },
    i(u) {
      o || (ge(t.$$.fragment, u), ge(s.$$.fragment, u), o = !0);
    },
    o(u) {
      Ie(t.$$.fragment, u), Ie(s.$$.fragment, u), o = !1;
    },
    d(u) {
      u && ue(e), en(t), en(s), n[30](null), l = !1, c();
    }
  };
}
function C0(n) {
  let e, t;
  return e = new hp({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [A0] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[1] & /*$$scope*/
      256 && (a.$$scope = { dirty: r, ctx: i }), e.$set(a);
    },
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function xu(n) {
  let e, t;
  return e = new $f({
    props: { fullscreen: (
      /*fullscreen*/
      n[9]
    ) }
  }), e.$on(
    "fullscreen",
    /*fullscreen_handler*/
    n[24]
  ), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*fullscreen*/
      512 && (a.fullscreen = /*fullscreen*/
      i[9]), e.$set(a);
    },
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function Pu(n) {
  let e, t;
  return e = new Dn({
    props: {
      Icon: yf,
      label: "View Metadata",
      "aria-label": "View and send image metadata"
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[25]
  ), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    p: y0,
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function Bu(n) {
  let e, t;
  return e = new Pg({
    props: {
      href: (
        /*value*/
        n[0].url
      ),
      download: (
        /*value*/
        n[0].orig_name || "image"
      ),
      $$slots: { default: [k0] },
      $$scope: { ctx: n }
    }
  }), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*value*/
      1 && (a.href = /*value*/
      i[0].url), r[0] & /*value*/
      1 && (a.download = /*value*/
      i[0].orig_name || "image"), r[0] & /*i18n*/
      64 | r[1] & /*$$scope*/
      256 && (a.$$scope = { dirty: r, ctx: i }), e.$set(a);
    },
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function k0(n) {
  let e, t;
  return e = new Dn({
    props: {
      Icon: $p,
      label: (
        /*i18n*/
        n[6]("common.download")
      )
    }
  }), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*i18n*/
      64 && (a.label = /*i18n*/
      i[6]("common.download")), e.$set(a);
    },
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function Ou(n) {
  let e, t;
  return e = new Fm({
    props: {
      i18n: (
        /*i18n*/
        n[6]
      ),
      formatter: (
        /*func*/
        n[26]
      ),
      value: (
        /*value*/
        n[0]
      )
    }
  }), e.$on(
    "share",
    /*share_handler*/
    n[27]
  ), e.$on(
    "error",
    /*error_handler*/
    n[28]
  ), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*i18n*/
      64 && (a.i18n = /*i18n*/
      i[6]), r[0] & /*value*/
      1 && (a.value = /*value*/
      i[0]), e.$set(a);
    },
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function S0(n) {
  let e, t, i, r, a, s = (
    /*show_fullscreen_button*/
    n[7] && xu(n)
  ), o = (
    /*metadata*/
    n[14] !== null && Pu(n)
  ), l = (
    /*show_download_button*/
    n[3] && Bu(n)
  ), c = (
    /*show_share_button*/
    n[5] && Ou(n)
  );
  return {
    c() {
      s && s.c(), e = Ut(), o && o.c(), t = Ut(), l && l.c(), i = Ut(), c && c.c(), r = pi();
    },
    l(u) {
      s && s.l(u), e = Nt(u), o && o.l(u), t = Nt(u), l && l.l(u), i = Nt(u), c && c.l(u), r = pi();
    },
    m(u, f) {
      s && s.m(u, f), tt(u, e, f), o && o.m(u, f), tt(u, t, f), l && l.m(u, f), tt(u, i, f), c && c.m(u, f), tt(u, r, f), a = !0;
    },
    p(u, f) {
      /*show_fullscreen_button*/
      u[7] ? s ? (s.p(u, f), f[0] & /*show_fullscreen_button*/
      128 && ge(s, 1)) : (s = xu(u), s.c(), ge(s, 1), s.m(e.parentNode, e)) : s && (Ni(), Ie(s, 1, 1, () => {
        s = null;
      }), Mi()), /*metadata*/
      u[14] !== null ? o ? (o.p(u, f), f[0] & /*metadata*/
      16384 && ge(o, 1)) : (o = Pu(u), o.c(), ge(o, 1), o.m(t.parentNode, t)) : o && (Ni(), Ie(o, 1, 1, () => {
        o = null;
      }), Mi()), /*show_download_button*/
      u[3] ? l ? (l.p(u, f), f[0] & /*show_download_button*/
      8 && ge(l, 1)) : (l = Bu(u), l.c(), ge(l, 1), l.m(i.parentNode, i)) : l && (Ni(), Ie(l, 1, 1, () => {
        l = null;
      }), Mi()), /*show_share_button*/
      u[5] ? c ? (c.p(u, f), f[0] & /*show_share_button*/
      32 && ge(c, 1)) : (c = Ou(u), c.c(), ge(c, 1), c.m(r.parentNode, r)) : c && (Ni(), Ie(c, 1, 1, () => {
        c = null;
      }), Mi());
    },
    i(u) {
      a || (ge(s), ge(o), ge(l), ge(c), a = !0);
    },
    o(u) {
      Ie(s), Ie(o), Ie(l), Ie(c), a = !1;
    },
    d(u) {
      u && (ue(e), ue(t), ue(i), ue(r)), s && s.d(u), o && o.d(u), l && l.d(u), c && c.d(u);
    }
  };
}
function A0(n) {
  let e, t;
  return e = new Ao({}), {
    c() {
      Jt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      tn(e, i, r), t = !0;
    },
    i(i) {
      t || (ge(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Ie(e.$$.fragment, i), t = !1;
    },
    d(i) {
      en(e, i);
    }
  };
}
function Lu(n) {
  let e, t, i, r = "X", a, s, o = "Image Metadata", l, c, u;
  function f(p, v) {
    return (
      /*filteredMetadata*/
      p[18].error ? T0 : F0
    );
  }
  let h = f(n), d = h(n);
  return {
    c() {
      e = et("div"), t = et("div"), i = et("button"), i.textContent = r, a = Ut(), s = et("h3"), s.textContent = o, l = Ut(), d.c(), this.h();
    },
    l(p) {
      e = Je(p, "DIV", { class: !0 });
      var v = vt(e);
      t = Je(v, "DIV", { class: !0 });
      var w = vt(t);
      i = Je(w, "BUTTON", { class: !0, "data-svelte-h": !0 }), Xs(i) !== "svelte-1irq3m4" && (i.textContent = r), a = Nt(w), s = Je(w, "H3", { class: !0, "data-svelte-h": !0 }), Xs(s) !== "svelte-1tc7pig" && (s.textContent = o), l = Nt(w), d.l(w), w.forEach(ue), v.forEach(ue), this.h();
    },
    h() {
      mt(i, "class", "close-button svelte-1glxd5l"), mt(s, "class", "popup-title svelte-1glxd5l"), mt(t, "class", "popup-content svelte-1glxd5l"), mt(e, "class", "metadata-popup svelte-1glxd5l"), gn(e, "width", typeof /*popup_metadata_width*/
      n[10] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        n[10],
        parseFloat(
          /*maxPopupWidth*/
          n[17]
        )
      )}px` : `min(${/*popup_metadata_width*/
      n[10]}, ${/*maxPopupWidth*/
      n[17]})`), gn(e, "height", typeof /*popup_metadata_height*/
      n[11] == "number" ? `${/*popup_metadata_height*/
      n[11]}px` : (
        /*popup_metadata_height*/
        n[11]
      ));
    },
    m(p, v) {
      tt(p, e, v), Ne(e, t), Ne(t, i), Ne(t, a), Ne(t, s), Ne(t, l), d.m(t, null), c || (u = No(
        i,
        "click",
        /*closePopup*/
        n[22]
      ), c = !0);
    },
    p(p, v) {
      h === (h = f(p)) && d ? d.p(p, v) : (d.d(1), d = h(p), d && (d.c(), d.m(t, null))), v[0] & /*popup_metadata_width, maxPopupWidth*/
      132096 && gn(e, "width", typeof /*popup_metadata_width*/
      p[10] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        p[10],
        parseFloat(
          /*maxPopupWidth*/
          p[17]
        )
      )}px` : `min(${/*popup_metadata_width*/
      p[10]}, ${/*maxPopupWidth*/
      p[17]})`), v[0] & /*popup_metadata_height*/
      2048 && gn(e, "height", typeof /*popup_metadata_height*/
      p[11] == "number" ? `${/*popup_metadata_height*/
      p[11]}px` : (
        /*popup_metadata_height*/
        p[11]
      ));
    },
    d(p) {
      p && ue(e), d.d(), c = !1, u();
    }
  };
}
function F0(n) {
  let e, t, i, r, a, s = "Load Metadata", o, l, c = Tu(Object.entries(
    /*filteredMetadata*/
    n[18]
  )), u = [];
  for (let f = 0; f < c.length; f += 1)
    u[f] = Mu($u(n, c, f));
  return {
    c() {
      e = et("div"), t = et("table"), i = et("tbody");
      for (let f = 0; f < u.length; f += 1)
        u[f].c();
      r = Ut(), a = et("button"), a.textContent = s, this.h();
    },
    l(f) {
      e = Je(f, "DIV", { class: !0 });
      var h = vt(e);
      t = Je(h, "TABLE", { class: !0 });
      var d = vt(t);
      i = Je(d, "TBODY", {});
      var p = vt(i);
      for (let v = 0; v < u.length; v += 1)
        u[v].l(p);
      p.forEach(ue), d.forEach(ue), h.forEach(ue), r = Nt(f), a = Je(f, "BUTTON", { class: !0, "data-svelte-h": !0 }), Xs(a) !== "svelte-1uwkq18" && (a.textContent = s), this.h();
    },
    h() {
      mt(t, "class", "metadata-table svelte-1glxd5l"), mt(e, "class", "metadata-table-container svelte-1glxd5l"), mt(a, "class", "load-metadata-button svelte-1glxd5l");
    },
    m(f, h) {
      tt(f, e, h), Ne(e, t), Ne(t, i);
      for (let d = 0; d < u.length; d += 1)
        u[d] && u[d].m(i, null);
      tt(f, r, h), tt(f, a, h), o || (l = No(
        a,
        "click",
        /*dispatchLoadMetadata*/
        n[21]
      ), o = !0);
    },
    p(f, h) {
      if (h[0] & /*filteredMetadata*/
      262144) {
        c = Tu(Object.entries(
          /*filteredMetadata*/
          f[18]
        ));
        let d;
        for (d = 0; d < c.length; d += 1) {
          const p = $u(f, c, d);
          u[d] ? u[d].p(p, h) : (u[d] = Mu(p), u[d].c(), u[d].m(i, null));
        }
        for (; d < u.length; d += 1)
          u[d].d(1);
        u.length = c.length;
      }
    },
    d(f) {
      f && (ue(e), ue(r), ue(a)), b0(u, f), o = !1, l();
    }
  };
}
function T0(n) {
  let e, t = (
    /*filteredMetadata*/
    n[18].error + ""
  ), i;
  return {
    c() {
      e = et("p"), i = Ys(t);
    },
    l(r) {
      e = Je(r, "P", {});
      var a = vt(e);
      i = Ws(a, t), a.forEach(ue);
    },
    m(r, a) {
      tt(r, e, a), Ne(e, i);
    },
    p(r, a) {
      a[0] & /*filteredMetadata*/
      262144 && t !== (t = /*filteredMetadata*/
      r[18].error + "") && Zs(i, t);
    },
    d(r) {
      r && ue(e);
    }
  };
}
function Ru(n) {
  let e, t, i = (
    /*key*/
    n[35] + ""
  ), r, a, s, o = (
    /*val*/
    n[36] + ""
  ), l, c;
  return {
    c() {
      e = et("tr"), t = et("td"), r = Ys(i), a = Ut(), s = et("td"), l = Ys(o), c = Ut(), this.h();
    },
    l(u) {
      e = Je(u, "TR", {});
      var f = vt(e);
      t = Je(f, "TD", { class: !0 });
      var h = vt(t);
      r = Ws(h, i), h.forEach(ue), a = Nt(f), s = Je(f, "TD", { class: !0 });
      var d = vt(s);
      l = Ws(d, o), d.forEach(ue), c = Nt(f), f.forEach(ue), this.h();
    },
    h() {
      mt(t, "class", "metadata-label svelte-1glxd5l"), mt(s, "class", "metadata-value svelte-1glxd5l");
    },
    m(u, f) {
      tt(u, e, f), Ne(e, t), Ne(t, r), Ne(e, a), Ne(e, s), Ne(s, l), Ne(e, c);
    },
    p(u, f) {
      f[0] & /*filteredMetadata*/
      262144 && i !== (i = /*key*/
      u[35] + "") && Zs(r, i), f[0] & /*filteredMetadata*/
      262144 && o !== (o = /*val*/
      u[36] + "") && Zs(l, o);
    },
    d(u) {
      u && ue(e);
    }
  };
}
function Mu(n) {
  let e, t = (
    /*val*/
    n[36] && Ru(n)
  );
  return {
    c() {
      t && t.c(), e = pi();
    },
    l(i) {
      t && t.l(i), e = pi();
    },
    m(i, r) {
      t && t.m(i, r), tt(i, e, r);
    },
    p(i, r) {
      /*val*/
      i[36] ? t ? t.p(i, r) : (t = Ru(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && ue(e), t && t.d(i);
    }
  };
}
function I0(n) {
  let e, t, i, r, a, s, o;
  e = new gf({
    props: {
      show_label: (
        /*show_label*/
        n[2]
      ),
      Icon: Ao,
      label: /*show_label*/ n[2] ? (
        /*label*/
        n[1] || /*i18n*/
        n[6]("image.image")
      ) : ""
    }
  });
  const l = [C0, E0], c = [];
  function u(h, d) {
    return (
      /*value*/
      h[0] === null || !/*value*/
      h[0].url ? 0 : 1
    );
  }
  i = u(n), r = c[i] = l[i](n);
  let f = (
    /*showMetadataPopup*/
    n[15] && /*filteredMetadata*/
    n[18] !== null && Lu(n)
  );
  return {
    c() {
      Jt(e.$$.fragment), t = Ut(), r.c(), a = Ut(), f && f.c(), s = pi();
    },
    l(h) {
      Qt(e.$$.fragment, h), t = Nt(h), r.l(h), a = Nt(h), f && f.l(h), s = pi();
    },
    m(h, d) {
      tn(e, h, d), tt(h, t, d), c[i].m(h, d), tt(h, a, d), f && f.m(h, d), tt(h, s, d), o = !0;
    },
    p(h, d) {
      const p = {};
      d[0] & /*show_label*/
      4 && (p.show_label = /*show_label*/
      h[2]), d[0] & /*show_label, label, i18n*/
      70 && (p.label = /*show_label*/
      h[2] ? (
        /*label*/
        h[1] || /*i18n*/
        h[6]("image.image")
      ) : ""), e.$set(p);
      let v = i;
      i = u(h), i === v ? c[i].p(h, d) : (Ni(), Ie(c[v], 1, 1, () => {
        c[v] = null;
      }), Mi(), r = c[i], r ? r.p(h, d) : (r = c[i] = l[i](h), r.c()), ge(r, 1), r.m(a.parentNode, a)), /*showMetadataPopup*/
      h[15] && /*filteredMetadata*/
      h[18] !== null ? f ? f.p(h, d) : (f = Lu(h), f.c(), f.m(s.parentNode, s)) : f && (f.d(1), f = null);
    },
    i(h) {
      o || (ge(e.$$.fragment, h), ge(r), o = !0);
    },
    o(h) {
      Ie(e.$$.fragment, h), Ie(r), o = !1;
    },
    d(h) {
      h && (ue(t), ue(a), ue(s)), en(e, h), c[i].d(h), f && f.d(h);
    }
  };
}
function $0(n, e, t) {
  let i, r;
  var a = this && this.__awaiter || function(x, H, J, T) {
    function ke(Se) {
      return Se instanceof J ? Se : new J(function(I) {
        I(Se);
      });
    }
    return new (J || (J = Promise))(function(Se, I) {
      function q(ce) {
        try {
          V(T.next(ce));
        } catch (Ee) {
          I(Ee);
        }
      }
      function j(ce) {
        try {
          V(T.throw(ce));
        } catch (Ee) {
          I(Ee);
        }
      }
      function V(ce) {
        ce.done ? Se(ce.value) : ke(ce.value).then(q, j);
      }
      V((T = T.apply(x, H || [])).next());
    });
  };
  let { value: s } = e, { label: o = void 0 } = e, { show_label: l } = e, { show_download_button: c = !0 } = e, { selectable: u = !1 } = e, { show_share_button: f = !1 } = e, { i18n: h } = e, { show_fullscreen_button: d = !0 } = e, { display_icon_button_wrapper_top_corner: p = !1 } = e, { fullscreen: v = !1 } = e, { only_custom_metadata: w = !0 } = e, { popup_metadata_width: D = 400 } = e, { popup_metadata_height: m = 300 } = e, { height: _ = void 0 } = e, { width: g = void 0 } = e, b = null, E = !1, k;
  const P = D0(), A = [
    "ImageWidth",
    "ImageHeight",
    "BitDepth",
    "ColorType",
    "Compression",
    "Filter",
    "Interlace"
  ];
  function R(x) {
    return a(this, void 0, void 0, function* () {
      if (!(x != null && x.url)) {
        t(14, b = null);
        return;
      }
      if (x.url.toLowerCase().endsWith(".svg"))
        t(14, b = null);
      else if (x.url.toLowerCase().endsWith(".png") || x.url.toLowerCase().endsWith(".jpg") || x.url.toLowerCase().endsWith(".jpeg"))
        try {
          const H = yield Vs(x.url, { exif: !0, iptc: !0, xmp: !0 });
          if (t(14, b = {}), H)
            for (const [J, T] of Object.entries(H))
              (typeof T == "string" || typeof T == "number" || typeof T == "boolean") && t(14, b[J] = T, b);
        } catch {
          t(14, b = {});
        }
      else
        t(14, b = {});
    });
  }
  function B(x) {
    let H = xf(x);
    H && P("select", { index: H, value: null });
  }
  function L() {
    b !== null && t(15, E = !E);
  }
  function de() {
    b !== null && (P("load_metadata"), z());
  }
  function z() {
    t(15, E = !1);
  }
  function te(x) {
    Br.call(this, n, x);
  }
  const Q = (x) => {
    L(), x.stopPropagation();
  }, oe = async (x) => x ? `<img src="${await dd(x)}" />` : "";
  function X(x) {
    Br.call(this, n, x);
  }
  function ne(x) {
    Br.call(this, n, x);
  }
  function De(x) {
    Br.call(this, n, x);
  }
  function F(x) {
    g0[x ? "unshift" : "push"](() => {
      k = x, t(16, k);
    });
  }
  return n.$$set = (x) => {
    "value" in x && t(0, s = x.value), "label" in x && t(1, o = x.label), "show_label" in x && t(2, l = x.show_label), "show_download_button" in x && t(3, c = x.show_download_button), "selectable" in x && t(4, u = x.selectable), "show_share_button" in x && t(5, f = x.show_share_button), "i18n" in x && t(6, h = x.i18n), "show_fullscreen_button" in x && t(7, d = x.show_fullscreen_button), "display_icon_button_wrapper_top_corner" in x && t(8, p = x.display_icon_button_wrapper_top_corner), "fullscreen" in x && t(9, v = x.fullscreen), "only_custom_metadata" in x && t(23, w = x.only_custom_metadata), "popup_metadata_width" in x && t(10, D = x.popup_metadata_width), "popup_metadata_height" in x && t(11, m = x.popup_metadata_height), "height" in x && t(12, _ = x.height), "width" in x && t(13, g = x.width);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*value*/
    1 && (s ? R(s) : t(14, b = null)), n.$$.dirty[0] & /*only_custom_metadata, metadata*/
    8404992 && t(18, i = w ? Object.fromEntries(Object.entries(b || {}).filter(([x]) => !A.includes(x))) : b), n.$$.dirty[0] & /*width*/
    8192 && t(17, r = typeof g == "number" ? g - 20 : typeof g == "string" ? `calc(${g} - 20px)` : "380px");
  }, [
    s,
    o,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    v,
    D,
    m,
    _,
    g,
    b,
    E,
    k,
    r,
    i,
    B,
    L,
    de,
    z,
    w,
    te,
    Q,
    oe,
    X,
    ne,
    De,
    F
  ];
}
class x0 extends m0 {
  constructor(e) {
    super(), v0(
      this,
      e,
      $0,
      I0,
      w0,
      {
        value: 0,
        label: 1,
        show_label: 2,
        show_download_button: 3,
        selectable: 4,
        show_share_button: 5,
        i18n: 6,
        show_fullscreen_button: 7,
        display_icon_button_wrapper_top_corner: 8,
        fullscreen: 9,
        only_custom_metadata: 23,
        popup_metadata_width: 10,
        popup_metadata_height: 11,
        height: 12,
        width: 13
      },
      null,
      [-1, -1]
    );
  }
}
new Intl.Collator(0, { numeric: 1 }).compare;
async function P0(n, e) {
  return n.map(
    (t) => new B0({
      path: t.name,
      orig_name: t.name,
      blob: t,
      size: t.size,
      mime_type: t.type,
      is_stream: e
    })
  );
}
class B0 {
  constructor({
    path: e,
    url: t,
    orig_name: i,
    size: r,
    blob: a,
    is_stream: s,
    mime_type: o,
    alt_text: l,
    b64: c
  }) {
    this.meta = { _type: "gradio.FileData" }, this.path = e, this.url = t, this.orig_name = i, this.size = r, this.blob = t ? void 0 : a, this.is_stream = s, this.mime_type = o, this.alt_text = l, this.b64 = c;
  }
}
typeof process < "u" && process.versions && process.versions.node;
var fn;
class w6 extends TransformStream {
  /** Constructs a new instance. */
  constructor(t = { allowCR: !1 }) {
    super({
      transform: (i, r) => {
        for (i = ti(this, fn) + i; ; ) {
          const a = i.indexOf(`
`), s = t.allowCR ? i.indexOf("\r") : -1;
          if (s !== -1 && s !== i.length - 1 && (a === -1 || a - 1 > s)) {
            r.enqueue(i.slice(0, s)), i = i.slice(s + 1);
            continue;
          }
          if (a === -1)
            break;
          const o = i[a - 1] === "\r" ? a - 1 : a;
          r.enqueue(i.slice(0, o)), i = i.slice(a + 1);
        }
        ll(this, fn, i);
      },
      flush: (i) => {
        if (ti(this, fn) === "")
          return;
        const r = t.allowCR && ti(this, fn).endsWith("\r") ? ti(this, fn).slice(0, -1) : ti(this, fn);
        i.enqueue(r);
      }
    });
    Ra(this, fn, "");
  }
}
fn = new WeakMap();
function Bn() {
}
function O0(n) {
  return n();
}
function L0(n) {
  return typeof n == "function";
}
function R0(n, ...e) {
  if (n == null) {
    for (const i of e) i(void 0);
    return Bn;
  }
  const t = n.subscribe(...e);
  return t.unsubscribe ? () => t.unsubscribe() : t;
}
const eh = typeof window < "u";
let Nu = eh ? () => window.performance.now() : () => Date.now(), th = eh ? (n) => requestAnimationFrame(n) : Bn;
const hi = /* @__PURE__ */ new Set();
function nh(n) {
  hi.forEach((e) => {
    e.c(n) || (hi.delete(e), e.f());
  }), hi.size !== 0 && th(nh);
}
function M0(n) {
  let e;
  return hi.size === 0 && th(nh), { promise: new Promise((t) => {
    hi.add(e = { c: n, f: t });
  }), abort() {
    hi.delete(e);
  } };
}
const ai = [];
function N0(n, e) {
  return { subscribe: sr(n, e).subscribe };
}
function sr(n, e = Bn) {
  let t;
  const i = /* @__PURE__ */ new Set();
  function r(s) {
    if (l = s, ((o = n) != o ? l == l : o !== l || o && typeof o == "object" || typeof o == "function") && (n = s, t)) {
      const c = !ai.length;
      for (const u of i) u[1](), ai.push(u, n);
      if (c) {
        for (let u = 0; u < ai.length; u += 2) ai[u][0](ai[u + 1]);
        ai.length = 0;
      }
    }
    var o, l;
  }
  function a(s) {
    r(s(n));
  }
  return { set: r, update: a, subscribe: function(s, o = Bn) {
    const l = [s, o];
    return i.add(l), i.size === 1 && (t = e(r, a) || Bn), s(n), () => {
      i.delete(l), i.size === 0 && t && (t(), t = null);
    };
  } };
}
function Di(n, e, t) {
  const i = !Array.isArray(n), r = i ? [n] : n;
  if (!r.every(Boolean)) throw new Error("derived() expects stores as input, got a falsy value");
  const a = e.length < 2;
  return N0(t, (s, o) => {
    let l = !1;
    const c = [];
    let u = 0, f = Bn;
    const h = () => {
      if (u) return;
      f();
      const p = e(i ? c[0] : c, s, o);
      a ? s(p) : f = L0(p) ? p : Bn;
    }, d = r.map((p, v) => R0(p, (w) => {
      c[v] = w, u &= ~(1 << v), l && h();
    }, () => {
      u |= 1 << v;
    }));
    return l = !0, h(), function() {
      d.forEach(O0), f(), l = !1;
    };
  });
}
function Uu(n) {
  return Object.prototype.toString.call(n) === "[object Date]";
}
function Ks(n, e, t, i) {
  if (typeof t == "number" || Uu(t)) {
    const r = i - t, a = (t - e) / (n.dt || 1 / 60), s = (a + (n.opts.stiffness * r - n.opts.damping * a) * n.inv_mass) * n.dt;
    return Math.abs(s) < n.opts.precision && Math.abs(r) < n.opts.precision ? i : (n.settled = !1, Uu(t) ? new Date(t.getTime() + s) : t + s);
  }
  if (Array.isArray(t)) return t.map((r, a) => Ks(n, e[a], t[a], i[a]));
  if (typeof t == "object") {
    const r = {};
    for (const a in t) r[a] = Ks(n, e[a], t[a], i[a]);
    return r;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function Hu(n, e = {}) {
  const t = sr(n), { stiffness: i = 0.15, damping: r = 0.8, precision: a = 0.01 } = e;
  let s, o, l, c = n, u = n, f = 1, h = 0, d = !1;
  function p(w, D = {}) {
    u = w;
    const m = l = {};
    return n == null || D.hard || v.stiffness >= 1 && v.damping >= 1 ? (d = !0, s = Nu(), c = w, t.set(n = u), Promise.resolve()) : (D.soft && (h = 1 / (60 * (D.soft === !0 ? 0.5 : +D.soft)), f = 0), o || (s = Nu(), d = !1, o = M0((_) => {
      if (d) return d = !1, o = null, !1;
      f = Math.min(f + h, 1);
      const g = { inv_mass: f, opts: v, settled: !0, dt: 60 * (_ - s) / 1e3 }, b = Ks(g, c, n, u);
      return s = _, c = n, t.set(n = b), g.settled && (o = null), !g.settled;
    })), new Promise((_) => {
      o.promise.then(() => {
        m === l && _();
      });
    }));
  }
  const v = { set: p, update: (w, D) => p(w(u, n), D), subscribe: t.subscribe, stiffness: i, damping: r, precision: a };
  return v;
}
function U0(n) {
  return H0(n) && !G0(n);
}
function H0(n) {
  return !!n && typeof n == "object";
}
function G0(n) {
  var e = Object.prototype.toString.call(n);
  return e === "[object RegExp]" || e === "[object Date]" || j0(n);
}
var z0 = typeof Symbol == "function" && Symbol.for, q0 = z0 ? Symbol.for("react.element") : 60103;
function j0(n) {
  return n.$$typeof === q0;
}
var V0 = U0;
function W0(n) {
  return Array.isArray(n) ? [] : {};
}
function Ji(n, e) {
  return e.clone !== !1 && e.isMergeableObject(n) ? mi(W0(n), n, e) : n;
}
function X0(n, e, t) {
  return n.concat(e).map(function(i) {
    return Ji(i, t);
  });
}
function Z0(n, e) {
  if (!e.customMerge)
    return mi;
  var t = e.customMerge(n);
  return typeof t == "function" ? t : mi;
}
function Y0(n) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(n).filter(function(e) {
    return Object.propertyIsEnumerable.call(n, e);
  }) : [];
}
function Gu(n) {
  return Object.keys(n).concat(Y0(n));
}
function ih(n, e) {
  try {
    return e in n;
  } catch {
    return !1;
  }
}
function K0(n, e) {
  return ih(n, e) && !(Object.hasOwnProperty.call(n, e) && Object.propertyIsEnumerable.call(n, e));
}
function Q0(n, e, t) {
  var i = {};
  return t.isMergeableObject(n) && Gu(n).forEach(function(r) {
    i[r] = Ji(n[r], t);
  }), Gu(e).forEach(function(r) {
    K0(n, r) || (ih(n, r) && t.isMergeableObject(e[r]) ? i[r] = Z0(r, t)(n[r], e[r], t) : i[r] = Ji(e[r], t));
  }), i;
}
function mi(n, e, t) {
  t = t || {}, t.arrayMerge = t.arrayMerge || X0, t.isMergeableObject = t.isMergeableObject || V0, t.cloneUnlessOtherwiseSpecified = Ji;
  var i = Array.isArray(e), r = Array.isArray(n), a = i === r;
  return a ? i ? t.arrayMerge(n, e, t) : Q0(n, e, t) : Ji(e, t);
}
mi.all = function(e, t) {
  if (!Array.isArray(e))
    throw new Error("first argument should be an array");
  return e.reduce(function(i, r) {
    return mi(i, r, t);
  }, {});
};
var Qs = function(n, e) {
  return Qs = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t, i) {
    t.__proto__ = i;
  } || function(t, i) {
    for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (t[r] = i[r]);
  }, Qs(n, e);
};
function ka(n, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Qs(n, e);
  function t() {
    this.constructor = n;
  }
  n.prototype = e === null ? Object.create(e) : (t.prototype = e.prototype, new t());
}
var ee = function() {
  return ee = Object.assign || function(e) {
    for (var t, i = 1, r = arguments.length; i < r; i++) {
      t = arguments[i];
      for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
  }, ee.apply(this, arguments);
};
function ms(n, e, t) {
  if (t || arguments.length === 2) for (var i = 0, r = e.length, a; i < r; i++)
    (a || !(i in e)) && (a || (a = Array.prototype.slice.call(e, 0, i)), a[i] = e[i]);
  return n.concat(a || Array.prototype.slice.call(e));
}
var Z;
(function(n) {
  n[n.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", n[n.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", n[n.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", n[n.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", n[n.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", n[n.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", n[n.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", n[n.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", n[n.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", n[n.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", n[n.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", n[n.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", n[n.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", n[n.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", n[n.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", n[n.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", n[n.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", n[n.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", n[n.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", n[n.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", n[n.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", n[n.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", n[n.INVALID_TAG = 23] = "INVALID_TAG", n[n.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", n[n.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", n[n.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(Z || (Z = {}));
var me;
(function(n) {
  n[n.literal = 0] = "literal", n[n.argument = 1] = "argument", n[n.number = 2] = "number", n[n.date = 3] = "date", n[n.time = 4] = "time", n[n.select = 5] = "select", n[n.plural = 6] = "plural", n[n.pound = 7] = "pound", n[n.tag = 8] = "tag";
})(me || (me = {}));
var gi;
(function(n) {
  n[n.number = 0] = "number", n[n.dateTime = 1] = "dateTime";
})(gi || (gi = {}));
function zu(n) {
  return n.type === me.literal;
}
function J0(n) {
  return n.type === me.argument;
}
function rh(n) {
  return n.type === me.number;
}
function ah(n) {
  return n.type === me.date;
}
function sh(n) {
  return n.type === me.time;
}
function oh(n) {
  return n.type === me.select;
}
function lh(n) {
  return n.type === me.plural;
}
function e1(n) {
  return n.type === me.pound;
}
function uh(n) {
  return n.type === me.tag;
}
function ch(n) {
  return !!(n && typeof n == "object" && n.type === gi.number);
}
function Js(n) {
  return !!(n && typeof n == "object" && n.type === gi.dateTime);
}
var fh = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, t1 = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function n1(n) {
  var e = {};
  return n.replace(t1, function(t) {
    var i = t.length;
    switch (t[0]) {
      case "G":
        e.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        e.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        e.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        e.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        e.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        e.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        e.hourCycle = "h12", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        e.hourCycle = "h23", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        e.hourCycle = "h11", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        e.hourCycle = "h24", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        e.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        e.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        e.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), e;
}
var i1 = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function r1(n) {
  if (n.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var e = n.split(i1).filter(function(h) {
    return h.length > 0;
  }), t = [], i = 0, r = e; i < r.length; i++) {
    var a = r[i], s = a.split("/");
    if (s.length === 0)
      throw new Error("Invalid number skeleton");
    for (var o = s[0], l = s.slice(1), c = 0, u = l; c < u.length; c++) {
      var f = u[c];
      if (f.length === 0)
        throw new Error("Invalid number skeleton");
    }
    t.push({ stem: o, options: l });
  }
  return t;
}
function a1(n) {
  return n.replace(/^(.*?)-/, "");
}
var qu = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, hh = /^(@+)?(\+|#+)?[rs]?$/g, s1 = /(\*)(0+)|(#+)(0+)|(0+)/g, dh = /^(0+)$/;
function ju(n) {
  var e = {};
  return n[n.length - 1] === "r" ? e.roundingPriority = "morePrecision" : n[n.length - 1] === "s" && (e.roundingPriority = "lessPrecision"), n.replace(hh, function(t, i, r) {
    return typeof r != "string" ? (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length) : r === "+" ? e.minimumSignificantDigits = i.length : i[0] === "#" ? e.maximumSignificantDigits = i.length : (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length + (typeof r == "string" ? r.length : 0)), "";
  }), e;
}
function _h(n) {
  switch (n) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function o1(n) {
  var e;
  if (n[0] === "E" && n[1] === "E" ? (e = {
    notation: "engineering"
  }, n = n.slice(2)) : n[0] === "E" && (e = {
    notation: "scientific"
  }, n = n.slice(1)), e) {
    var t = n.slice(0, 2);
    if (t === "+!" ? (e.signDisplay = "always", n = n.slice(2)) : t === "+?" && (e.signDisplay = "exceptZero", n = n.slice(2)), !dh.test(n))
      throw new Error("Malformed concise eng/scientific notation");
    e.minimumIntegerDigits = n.length;
  }
  return e;
}
function Vu(n) {
  var e = {}, t = _h(n);
  return t || e;
}
function l1(n) {
  for (var e = {}, t = 0, i = n; t < i.length; t++) {
    var r = i[t];
    switch (r.stem) {
      case "percent":
      case "%":
        e.style = "percent";
        continue;
      case "%x100":
        e.style = "percent", e.scale = 100;
        continue;
      case "currency":
        e.style = "currency", e.currency = r.options[0];
        continue;
      case "group-off":
      case ",_":
        e.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        e.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        e.style = "unit", e.unit = a1(r.options[0]);
        continue;
      case "compact-short":
      case "K":
        e.notation = "compact", e.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        e.notation = "compact", e.compactDisplay = "long";
        continue;
      case "scientific":
        e = ee(ee(ee({}, e), { notation: "scientific" }), r.options.reduce(function(l, c) {
          return ee(ee({}, l), Vu(c));
        }, {}));
        continue;
      case "engineering":
        e = ee(ee(ee({}, e), { notation: "engineering" }), r.options.reduce(function(l, c) {
          return ee(ee({}, l), Vu(c));
        }, {}));
        continue;
      case "notation-simple":
        e.notation = "standard";
        continue;
      case "unit-width-narrow":
        e.currencyDisplay = "narrowSymbol", e.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        e.currencyDisplay = "code", e.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        e.currencyDisplay = "name", e.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        e.currencyDisplay = "symbol";
        continue;
      case "scale":
        e.scale = parseFloat(r.options[0]);
        continue;
      case "integer-width":
        if (r.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        r.options[0].replace(s1, function(l, c, u, f, h, d) {
          if (c)
            e.minimumIntegerDigits = u.length;
          else {
            if (f && h)
              throw new Error("We currently do not support maximum integer digits");
            if (d)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (dh.test(r.stem)) {
      e.minimumIntegerDigits = r.stem.length;
      continue;
    }
    if (qu.test(r.stem)) {
      if (r.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      r.stem.replace(qu, function(l, c, u, f, h, d) {
        return u === "*" ? e.minimumFractionDigits = c.length : f && f[0] === "#" ? e.maximumFractionDigits = f.length : h && d ? (e.minimumFractionDigits = h.length, e.maximumFractionDigits = h.length + d.length) : (e.minimumFractionDigits = c.length, e.maximumFractionDigits = c.length), "";
      });
      var a = r.options[0];
      a === "w" ? e = ee(ee({}, e), { trailingZeroDisplay: "stripIfInteger" }) : a && (e = ee(ee({}, e), ju(a)));
      continue;
    }
    if (hh.test(r.stem)) {
      e = ee(ee({}, e), ju(r.stem));
      continue;
    }
    var s = _h(r.stem);
    s && (e = ee(ee({}, e), s));
    var o = o1(r.stem);
    o && (e = ee(ee({}, e), o));
  }
  return e;
}
var Or = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function u1(n, e) {
  for (var t = "", i = 0; i < n.length; i++) {
    var r = n.charAt(i);
    if (r === "j") {
      for (var a = 0; i + 1 < n.length && n.charAt(i + 1) === r; )
        a++, i++;
      var s = 1 + (a & 1), o = a < 2 ? 1 : 3 + (a >> 1), l = "a", c = c1(e);
      for ((c == "H" || c == "k") && (o = 0); o-- > 0; )
        t += l;
      for (; s-- > 0; )
        t = c + t;
    } else r === "J" ? t += "H" : t += r;
  }
  return t;
}
function c1(n) {
  var e = n.hourCycle;
  if (e === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  n.hourCycles && // @ts-ignore
  n.hourCycles.length && (e = n.hourCycles[0]), e)
    switch (e) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var t = n.language, i;
  t !== "root" && (i = n.maximize().region);
  var r = Or[i || ""] || Or[t || ""] || Or["".concat(t, "-001")] || Or["001"];
  return r[0];
}
var gs, f1 = new RegExp("^".concat(fh.source, "*")), h1 = new RegExp("".concat(fh.source, "*$"));
function Y(n, e) {
  return { start: n, end: e };
}
var d1 = !!String.prototype.startsWith, _1 = !!String.fromCodePoint, p1 = !!Object.fromEntries, m1 = !!String.prototype.codePointAt, g1 = !!String.prototype.trimStart, b1 = !!String.prototype.trimEnd, v1 = !!Number.isSafeInteger, y1 = v1 ? Number.isSafeInteger : function(n) {
  return typeof n == "number" && isFinite(n) && Math.floor(n) === n && Math.abs(n) <= 9007199254740991;
}, eo = !0;
try {
  var w1 = mh("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  eo = ((gs = w1.exec("a")) === null || gs === void 0 ? void 0 : gs[0]) === "a";
} catch {
  eo = !1;
}
var Wu = d1 ? (
  // Native
  function(e, t, i) {
    return e.startsWith(t, i);
  }
) : (
  // For IE11
  function(e, t, i) {
    return e.slice(i, i + t.length) === t;
  }
), to = _1 ? String.fromCodePoint : (
  // IE11
  function() {
    for (var e = [], t = 0; t < arguments.length; t++)
      e[t] = arguments[t];
    for (var i = "", r = e.length, a = 0, s; r > a; ) {
      if (s = e[a++], s > 1114111)
        throw RangeError(s + " is not a valid code point");
      i += s < 65536 ? String.fromCharCode(s) : String.fromCharCode(((s -= 65536) >> 10) + 55296, s % 1024 + 56320);
    }
    return i;
  }
), Xu = (
  // native
  p1 ? Object.fromEntries : (
    // Ponyfill
    function(e) {
      for (var t = {}, i = 0, r = e; i < r.length; i++) {
        var a = r[i], s = a[0], o = a[1];
        t[s] = o;
      }
      return t;
    }
  )
), ph = m1 ? (
  // Native
  function(e, t) {
    return e.codePointAt(t);
  }
) : (
  // IE 11
  function(e, t) {
    var i = e.length;
    if (!(t < 0 || t >= i)) {
      var r = e.charCodeAt(t), a;
      return r < 55296 || r > 56319 || t + 1 === i || (a = e.charCodeAt(t + 1)) < 56320 || a > 57343 ? r : (r - 55296 << 10) + (a - 56320) + 65536;
    }
  }
), D1 = g1 ? (
  // Native
  function(e) {
    return e.trimStart();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(f1, "");
  }
), E1 = b1 ? (
  // Native
  function(e) {
    return e.trimEnd();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(h1, "");
  }
);
function mh(n, e) {
  return new RegExp(n, e);
}
var no;
if (eo) {
  var Zu = mh("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  no = function(e, t) {
    var i;
    Zu.lastIndex = t;
    var r = Zu.exec(e);
    return (i = r[1]) !== null && i !== void 0 ? i : "";
  };
} else
  no = function(e, t) {
    for (var i = []; ; ) {
      var r = ph(e, t);
      if (r === void 0 || gh(r) || A1(r))
        break;
      i.push(r), t += r >= 65536 ? 2 : 1;
    }
    return to.apply(void 0, i);
  };
var C1 = (
  /** @class */
  function() {
    function n(e, t) {
      t === void 0 && (t = {}), this.message = e, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!t.ignoreTag, this.locale = t.locale, this.requiresOtherClause = !!t.requiresOtherClause, this.shouldParseSkeletons = !!t.shouldParseSkeletons;
    }
    return n.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, n.prototype.parseMessage = function(e, t, i) {
      for (var r = []; !this.isEOF(); ) {
        var a = this.char();
        if (a === 123) {
          var s = this.parseArgument(e, i);
          if (s.err)
            return s;
          r.push(s.val);
        } else {
          if (a === 125 && e > 0)
            break;
          if (a === 35 && (t === "plural" || t === "selectordinal")) {
            var o = this.clonePosition();
            this.bump(), r.push({
              type: me.pound,
              location: Y(o, this.clonePosition())
            });
          } else if (a === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(Z.UNMATCHED_CLOSING_TAG, Y(this.clonePosition(), this.clonePosition()));
          } else if (a === 60 && !this.ignoreTag && io(this.peek() || 0)) {
            var s = this.parseTag(e, t);
            if (s.err)
              return s;
            r.push(s.val);
          } else {
            var s = this.parseLiteral(e, t);
            if (s.err)
              return s;
            r.push(s.val);
          }
        }
      }
      return { val: r, err: null };
    }, n.prototype.parseTag = function(e, t) {
      var i = this.clonePosition();
      this.bump();
      var r = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: me.literal,
            value: "<".concat(r, "/>"),
            location: Y(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var a = this.parseMessage(e + 1, t, !0);
        if (a.err)
          return a;
        var s = a.val, o = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !io(this.char()))
            return this.error(Z.INVALID_TAG, Y(o, this.clonePosition()));
          var l = this.clonePosition(), c = this.parseTagName();
          return r !== c ? this.error(Z.UNMATCHED_CLOSING_TAG, Y(l, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: me.tag,
              value: r,
              children: s,
              location: Y(i, this.clonePosition())
            },
            err: null
          } : this.error(Z.INVALID_TAG, Y(o, this.clonePosition())));
        } else
          return this.error(Z.UNCLOSED_TAG, Y(i, this.clonePosition()));
      } else
        return this.error(Z.INVALID_TAG, Y(i, this.clonePosition()));
    }, n.prototype.parseTagName = function() {
      var e = this.offset();
      for (this.bump(); !this.isEOF() && S1(this.char()); )
        this.bump();
      return this.message.slice(e, this.offset());
    }, n.prototype.parseLiteral = function(e, t) {
      for (var i = this.clonePosition(), r = ""; ; ) {
        var a = this.tryParseQuote(t);
        if (a) {
          r += a;
          continue;
        }
        var s = this.tryParseUnquoted(e, t);
        if (s) {
          r += s;
          continue;
        }
        var o = this.tryParseLeftAngleBracket();
        if (o) {
          r += o;
          continue;
        }
        break;
      }
      var l = Y(i, this.clonePosition());
      return {
        val: { type: me.literal, value: r, location: l },
        err: null
      };
    }, n.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !k1(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, n.prototype.tryParseQuote = function(e) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (e === "plural" || e === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var t = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            t.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          t.push(i);
        this.bump();
      }
      return to.apply(void 0, t);
    }, n.prototype.tryParseUnquoted = function(e, t) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (t === "plural" || t === "selectordinal") || i === 125 && e > 0 ? null : (this.bump(), to(i));
    }, n.prototype.parseArgument = function(e, t) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(Z.EXPECT_ARGUMENT_CLOSING_BRACE, Y(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(Z.EMPTY_ARGUMENT, Y(i, this.clonePosition()));
      var r = this.parseIdentifierIfPossible().value;
      if (!r)
        return this.error(Z.MALFORMED_ARGUMENT, Y(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(Z.EXPECT_ARGUMENT_CLOSING_BRACE, Y(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: me.argument,
              // value does not include the opening and closing braces.
              value: r,
              location: Y(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(Z.EXPECT_ARGUMENT_CLOSING_BRACE, Y(i, this.clonePosition())) : this.parseArgumentOptions(e, t, r, i);
        default:
          return this.error(Z.MALFORMED_ARGUMENT, Y(i, this.clonePosition()));
      }
    }, n.prototype.parseIdentifierIfPossible = function() {
      var e = this.clonePosition(), t = this.offset(), i = no(this.message, t), r = t + i.length;
      this.bumpTo(r);
      var a = this.clonePosition(), s = Y(e, a);
      return { value: i, location: s };
    }, n.prototype.parseArgumentOptions = function(e, t, i, r) {
      var a, s = this.clonePosition(), o = this.parseIdentifierIfPossible().value, l = this.clonePosition();
      switch (o) {
        case "":
          return this.error(Z.EXPECT_ARGUMENT_TYPE, Y(s, l));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var c = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var u = this.clonePosition(), f = this.parseSimpleArgStyleIfPossible();
            if (f.err)
              return f;
            var h = E1(f.val);
            if (h.length === 0)
              return this.error(Z.EXPECT_ARGUMENT_STYLE, Y(this.clonePosition(), this.clonePosition()));
            var d = Y(u, this.clonePosition());
            c = { style: h, styleLocation: d };
          }
          var p = this.tryParseArgumentClose(r);
          if (p.err)
            return p;
          var v = Y(r, this.clonePosition());
          if (c && Wu(c == null ? void 0 : c.style, "::", 0)) {
            var w = D1(c.style.slice(2));
            if (o === "number") {
              var f = this.parseNumberSkeletonFromString(w, c.styleLocation);
              return f.err ? f : {
                val: { type: me.number, value: i, location: v, style: f.val },
                err: null
              };
            } else {
              if (w.length === 0)
                return this.error(Z.EXPECT_DATE_TIME_SKELETON, v);
              var D = w;
              this.locale && (D = u1(w, this.locale));
              var h = {
                type: gi.dateTime,
                pattern: D,
                location: c.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? n1(D) : {}
              }, m = o === "date" ? me.date : me.time;
              return {
                val: { type: m, value: i, location: v, style: h },
                err: null
              };
            }
          }
          return {
            val: {
              type: o === "number" ? me.number : o === "date" ? me.date : me.time,
              value: i,
              location: v,
              style: (a = c == null ? void 0 : c.style) !== null && a !== void 0 ? a : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var _ = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(Z.EXPECT_SELECT_ARGUMENT_OPTIONS, Y(_, ee({}, _)));
          this.bumpSpace();
          var g = this.parseIdentifierIfPossible(), b = 0;
          if (o !== "select" && g.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(Z.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, Y(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var f = this.tryParseDecimalInteger(Z.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, Z.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (f.err)
              return f;
            this.bumpSpace(), g = this.parseIdentifierIfPossible(), b = f.val;
          }
          var E = this.tryParsePluralOrSelectOptions(e, o, t, g);
          if (E.err)
            return E;
          var p = this.tryParseArgumentClose(r);
          if (p.err)
            return p;
          var k = Y(r, this.clonePosition());
          return o === "select" ? {
            val: {
              type: me.select,
              value: i,
              options: Xu(E.val),
              location: k
            },
            err: null
          } : {
            val: {
              type: me.plural,
              value: i,
              options: Xu(E.val),
              offset: b,
              pluralType: o === "plural" ? "cardinal" : "ordinal",
              location: k
            },
            err: null
          };
        }
        default:
          return this.error(Z.INVALID_ARGUMENT_TYPE, Y(s, l));
      }
    }, n.prototype.tryParseArgumentClose = function(e) {
      return this.isEOF() || this.char() !== 125 ? this.error(Z.EXPECT_ARGUMENT_CLOSING_BRACE, Y(e, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, n.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var e = 0, t = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var r = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(Z.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, Y(r, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            e += 1, this.bump();
            break;
          }
          case 125: {
            if (e > 0)
              e -= 1;
            else
              return {
                val: this.message.slice(t.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(t.offset, this.offset()),
        err: null
      };
    }, n.prototype.parseNumberSkeletonFromString = function(e, t) {
      var i = [];
      try {
        i = r1(e);
      } catch {
        return this.error(Z.INVALID_NUMBER_SKELETON, t);
      }
      return {
        val: {
          type: gi.number,
          tokens: i,
          location: t,
          parsedOptions: this.shouldParseSkeletons ? l1(i) : {}
        },
        err: null
      };
    }, n.prototype.tryParsePluralOrSelectOptions = function(e, t, i, r) {
      for (var a, s = !1, o = [], l = /* @__PURE__ */ new Set(), c = r.value, u = r.location; ; ) {
        if (c.length === 0) {
          var f = this.clonePosition();
          if (t !== "select" && this.bumpIf("=")) {
            var h = this.tryParseDecimalInteger(Z.EXPECT_PLURAL_ARGUMENT_SELECTOR, Z.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (h.err)
              return h;
            u = Y(f, this.clonePosition()), c = this.message.slice(f.offset, this.offset());
          } else
            break;
        }
        if (l.has(c))
          return this.error(t === "select" ? Z.DUPLICATE_SELECT_ARGUMENT_SELECTOR : Z.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, u);
        c === "other" && (s = !0), this.bumpSpace();
        var d = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(t === "select" ? Z.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : Z.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, Y(this.clonePosition(), this.clonePosition()));
        var p = this.parseMessage(e + 1, t, i);
        if (p.err)
          return p;
        var v = this.tryParseArgumentClose(d);
        if (v.err)
          return v;
        o.push([
          c,
          {
            value: p.val,
            location: Y(d, this.clonePosition())
          }
        ]), l.add(c), this.bumpSpace(), a = this.parseIdentifierIfPossible(), c = a.value, u = a.location;
      }
      return o.length === 0 ? this.error(t === "select" ? Z.EXPECT_SELECT_ARGUMENT_SELECTOR : Z.EXPECT_PLURAL_ARGUMENT_SELECTOR, Y(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !s ? this.error(Z.MISSING_OTHER_CLAUSE, Y(this.clonePosition(), this.clonePosition())) : { val: o, err: null };
    }, n.prototype.tryParseDecimalInteger = function(e, t) {
      var i = 1, r = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var a = !1, s = 0; !this.isEOF(); ) {
        var o = this.char();
        if (o >= 48 && o <= 57)
          a = !0, s = s * 10 + (o - 48), this.bump();
        else
          break;
      }
      var l = Y(r, this.clonePosition());
      return a ? (s *= i, y1(s) ? { val: s, err: null } : this.error(t, l)) : this.error(e, l);
    }, n.prototype.offset = function() {
      return this.position.offset;
    }, n.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, n.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, n.prototype.char = function() {
      var e = this.position.offset;
      if (e >= this.message.length)
        throw Error("out of bound");
      var t = ph(this.message, e);
      if (t === void 0)
        throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
      return t;
    }, n.prototype.error = function(e, t) {
      return {
        val: null,
        err: {
          kind: e,
          message: this.message,
          location: t
        }
      };
    }, n.prototype.bump = function() {
      if (!this.isEOF()) {
        var e = this.char();
        e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
      }
    }, n.prototype.bumpIf = function(e) {
      if (Wu(this.message, e, this.offset())) {
        for (var t = 0; t < e.length; t++)
          this.bump();
        return !0;
      }
      return !1;
    }, n.prototype.bumpUntil = function(e) {
      var t = this.offset(), i = this.message.indexOf(e, t);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, n.prototype.bumpTo = function(e) {
      if (this.offset() > e)
        throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (e = Math.min(e, this.message.length); ; ) {
        var t = this.offset();
        if (t === e)
          break;
        if (t > e)
          throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, n.prototype.bumpSpace = function() {
      for (; !this.isEOF() && gh(this.char()); )
        this.bump();
    }, n.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var e = this.char(), t = this.offset(), i = this.message.charCodeAt(t + (e >= 65536 ? 2 : 1));
      return i ?? null;
    }, n;
  }()
);
function io(n) {
  return n >= 97 && n <= 122 || n >= 65 && n <= 90;
}
function k1(n) {
  return io(n) || n === 47;
}
function S1(n) {
  return n === 45 || n === 46 || n >= 48 && n <= 57 || n === 95 || n >= 97 && n <= 122 || n >= 65 && n <= 90 || n == 183 || n >= 192 && n <= 214 || n >= 216 && n <= 246 || n >= 248 && n <= 893 || n >= 895 && n <= 8191 || n >= 8204 && n <= 8205 || n >= 8255 && n <= 8256 || n >= 8304 && n <= 8591 || n >= 11264 && n <= 12271 || n >= 12289 && n <= 55295 || n >= 63744 && n <= 64975 || n >= 65008 && n <= 65533 || n >= 65536 && n <= 983039;
}
function gh(n) {
  return n >= 9 && n <= 13 || n === 32 || n === 133 || n >= 8206 && n <= 8207 || n === 8232 || n === 8233;
}
function A1(n) {
  return n >= 33 && n <= 35 || n === 36 || n >= 37 && n <= 39 || n === 40 || n === 41 || n === 42 || n === 43 || n === 44 || n === 45 || n >= 46 && n <= 47 || n >= 58 && n <= 59 || n >= 60 && n <= 62 || n >= 63 && n <= 64 || n === 91 || n === 92 || n === 93 || n === 94 || n === 96 || n === 123 || n === 124 || n === 125 || n === 126 || n === 161 || n >= 162 && n <= 165 || n === 166 || n === 167 || n === 169 || n === 171 || n === 172 || n === 174 || n === 176 || n === 177 || n === 182 || n === 187 || n === 191 || n === 215 || n === 247 || n >= 8208 && n <= 8213 || n >= 8214 && n <= 8215 || n === 8216 || n === 8217 || n === 8218 || n >= 8219 && n <= 8220 || n === 8221 || n === 8222 || n === 8223 || n >= 8224 && n <= 8231 || n >= 8240 && n <= 8248 || n === 8249 || n === 8250 || n >= 8251 && n <= 8254 || n >= 8257 && n <= 8259 || n === 8260 || n === 8261 || n === 8262 || n >= 8263 && n <= 8273 || n === 8274 || n === 8275 || n >= 8277 && n <= 8286 || n >= 8592 && n <= 8596 || n >= 8597 && n <= 8601 || n >= 8602 && n <= 8603 || n >= 8604 && n <= 8607 || n === 8608 || n >= 8609 && n <= 8610 || n === 8611 || n >= 8612 && n <= 8613 || n === 8614 || n >= 8615 && n <= 8621 || n === 8622 || n >= 8623 && n <= 8653 || n >= 8654 && n <= 8655 || n >= 8656 && n <= 8657 || n === 8658 || n === 8659 || n === 8660 || n >= 8661 && n <= 8691 || n >= 8692 && n <= 8959 || n >= 8960 && n <= 8967 || n === 8968 || n === 8969 || n === 8970 || n === 8971 || n >= 8972 && n <= 8991 || n >= 8992 && n <= 8993 || n >= 8994 && n <= 9e3 || n === 9001 || n === 9002 || n >= 9003 && n <= 9083 || n === 9084 || n >= 9085 && n <= 9114 || n >= 9115 && n <= 9139 || n >= 9140 && n <= 9179 || n >= 9180 && n <= 9185 || n >= 9186 && n <= 9254 || n >= 9255 && n <= 9279 || n >= 9280 && n <= 9290 || n >= 9291 && n <= 9311 || n >= 9472 && n <= 9654 || n === 9655 || n >= 9656 && n <= 9664 || n === 9665 || n >= 9666 && n <= 9719 || n >= 9720 && n <= 9727 || n >= 9728 && n <= 9838 || n === 9839 || n >= 9840 && n <= 10087 || n === 10088 || n === 10089 || n === 10090 || n === 10091 || n === 10092 || n === 10093 || n === 10094 || n === 10095 || n === 10096 || n === 10097 || n === 10098 || n === 10099 || n === 10100 || n === 10101 || n >= 10132 && n <= 10175 || n >= 10176 && n <= 10180 || n === 10181 || n === 10182 || n >= 10183 && n <= 10213 || n === 10214 || n === 10215 || n === 10216 || n === 10217 || n === 10218 || n === 10219 || n === 10220 || n === 10221 || n === 10222 || n === 10223 || n >= 10224 && n <= 10239 || n >= 10240 && n <= 10495 || n >= 10496 && n <= 10626 || n === 10627 || n === 10628 || n === 10629 || n === 10630 || n === 10631 || n === 10632 || n === 10633 || n === 10634 || n === 10635 || n === 10636 || n === 10637 || n === 10638 || n === 10639 || n === 10640 || n === 10641 || n === 10642 || n === 10643 || n === 10644 || n === 10645 || n === 10646 || n === 10647 || n === 10648 || n >= 10649 && n <= 10711 || n === 10712 || n === 10713 || n === 10714 || n === 10715 || n >= 10716 && n <= 10747 || n === 10748 || n === 10749 || n >= 10750 && n <= 11007 || n >= 11008 && n <= 11055 || n >= 11056 && n <= 11076 || n >= 11077 && n <= 11078 || n >= 11079 && n <= 11084 || n >= 11085 && n <= 11123 || n >= 11124 && n <= 11125 || n >= 11126 && n <= 11157 || n === 11158 || n >= 11159 && n <= 11263 || n >= 11776 && n <= 11777 || n === 11778 || n === 11779 || n === 11780 || n === 11781 || n >= 11782 && n <= 11784 || n === 11785 || n === 11786 || n === 11787 || n === 11788 || n === 11789 || n >= 11790 && n <= 11798 || n === 11799 || n >= 11800 && n <= 11801 || n === 11802 || n === 11803 || n === 11804 || n === 11805 || n >= 11806 && n <= 11807 || n === 11808 || n === 11809 || n === 11810 || n === 11811 || n === 11812 || n === 11813 || n === 11814 || n === 11815 || n === 11816 || n === 11817 || n >= 11818 && n <= 11822 || n === 11823 || n >= 11824 && n <= 11833 || n >= 11834 && n <= 11835 || n >= 11836 && n <= 11839 || n === 11840 || n === 11841 || n === 11842 || n >= 11843 && n <= 11855 || n >= 11856 && n <= 11857 || n === 11858 || n >= 11859 && n <= 11903 || n >= 12289 && n <= 12291 || n === 12296 || n === 12297 || n === 12298 || n === 12299 || n === 12300 || n === 12301 || n === 12302 || n === 12303 || n === 12304 || n === 12305 || n >= 12306 && n <= 12307 || n === 12308 || n === 12309 || n === 12310 || n === 12311 || n === 12312 || n === 12313 || n === 12314 || n === 12315 || n === 12316 || n === 12317 || n >= 12318 && n <= 12319 || n === 12320 || n === 12336 || n === 64830 || n === 64831 || n >= 65093 && n <= 65094;
}
function ro(n) {
  n.forEach(function(e) {
    if (delete e.location, oh(e) || lh(e))
      for (var t in e.options)
        delete e.options[t].location, ro(e.options[t].value);
    else rh(e) && ch(e.style) || (ah(e) || sh(e)) && Js(e.style) ? delete e.style.location : uh(e) && ro(e.children);
  });
}
function F1(n, e) {
  e === void 0 && (e = {}), e = ee({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, e);
  var t = new C1(n, e).parse();
  if (t.err) {
    var i = SyntaxError(Z[t.err.kind]);
    throw i.location = t.err.location, i.originalMessage = t.err.message, i;
  }
  return e != null && e.captureLocation || ro(t.val), t.val;
}
function bs(n, e) {
  var t = e && e.cache ? e.cache : B1, i = e && e.serializer ? e.serializer : P1, r = e && e.strategy ? e.strategy : $1;
  return r(n, {
    cache: t,
    serializer: i
  });
}
function T1(n) {
  return n == null || typeof n == "number" || typeof n == "boolean";
}
function I1(n, e, t, i) {
  var r = T1(i) ? i : t(i), a = e.get(r);
  return typeof a > "u" && (a = n.call(this, i), e.set(r, a)), a;
}
function bh(n, e, t) {
  var i = Array.prototype.slice.call(arguments, 3), r = t(i), a = e.get(r);
  return typeof a > "u" && (a = n.apply(this, i), e.set(r, a)), a;
}
function vh(n, e, t, i, r) {
  return t.bind(e, n, i, r);
}
function $1(n, e) {
  var t = n.length === 1 ? I1 : bh;
  return vh(n, this, t, e.cache.create(), e.serializer);
}
function x1(n, e) {
  return vh(n, this, bh, e.cache.create(), e.serializer);
}
var P1 = function() {
  return JSON.stringify(arguments);
};
function Uo() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
Uo.prototype.get = function(n) {
  return this.cache[n];
};
Uo.prototype.set = function(n, e) {
  this.cache[n] = e;
};
var B1 = {
  create: function() {
    return new Uo();
  }
}, vs = {
  variadic: x1
}, bi;
(function(n) {
  n.MISSING_VALUE = "MISSING_VALUE", n.INVALID_VALUE = "INVALID_VALUE", n.MISSING_INTL_API = "MISSING_INTL_API";
})(bi || (bi = {}));
var Sa = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i, r) {
      var a = n.call(this, t) || this;
      return a.code = i, a.originalMessage = r, a;
    }
    return e.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, e;
  }(Error)
), Yu = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i, r, a) {
      return n.call(this, 'Invalid values for "'.concat(t, '": "').concat(i, '". Options are "').concat(Object.keys(r).join('", "'), '"'), bi.INVALID_VALUE, a) || this;
    }
    return e;
  }(Sa)
), O1 = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i, r) {
      return n.call(this, 'Value for "'.concat(t, '" must be of type ').concat(i), bi.INVALID_VALUE, r) || this;
    }
    return e;
  }(Sa)
), L1 = (
  /** @class */
  function(n) {
    ka(e, n);
    function e(t, i) {
      return n.call(this, 'The intl string context variable "'.concat(t, '" was not provided to the string "').concat(i, '"'), bi.MISSING_VALUE, i) || this;
    }
    return e;
  }(Sa)
), Qe;
(function(n) {
  n[n.literal = 0] = "literal", n[n.object = 1] = "object";
})(Qe || (Qe = {}));
function R1(n) {
  return n.length < 2 ? n : n.reduce(function(e, t) {
    var i = e[e.length - 1];
    return !i || i.type !== Qe.literal || t.type !== Qe.literal ? e.push(t) : i.value += t.value, e;
  }, []);
}
function M1(n) {
  return typeof n == "function";
}
function qr(n, e, t, i, r, a, s) {
  if (n.length === 1 && zu(n[0]))
    return [
      {
        type: Qe.literal,
        value: n[0].value
      }
    ];
  for (var o = [], l = 0, c = n; l < c.length; l++) {
    var u = c[l];
    if (zu(u)) {
      o.push({
        type: Qe.literal,
        value: u.value
      });
      continue;
    }
    if (e1(u)) {
      typeof a == "number" && o.push({
        type: Qe.literal,
        value: t.getNumberFormat(e).format(a)
      });
      continue;
    }
    var f = u.value;
    if (!(r && f in r))
      throw new L1(f, s);
    var h = r[f];
    if (J0(u)) {
      (!h || typeof h == "string" || typeof h == "number") && (h = typeof h == "string" || typeof h == "number" ? String(h) : ""), o.push({
        type: typeof h == "string" ? Qe.literal : Qe.object,
        value: h
      });
      continue;
    }
    if (ah(u)) {
      var d = typeof u.style == "string" ? i.date[u.style] : Js(u.style) ? u.style.parsedOptions : void 0;
      o.push({
        type: Qe.literal,
        value: t.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (sh(u)) {
      var d = typeof u.style == "string" ? i.time[u.style] : Js(u.style) ? u.style.parsedOptions : i.time.medium;
      o.push({
        type: Qe.literal,
        value: t.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (rh(u)) {
      var d = typeof u.style == "string" ? i.number[u.style] : ch(u.style) ? u.style.parsedOptions : void 0;
      d && d.scale && (h = h * (d.scale || 1)), o.push({
        type: Qe.literal,
        value: t.getNumberFormat(e, d).format(h)
      });
      continue;
    }
    if (uh(u)) {
      var p = u.children, v = u.value, w = r[v];
      if (!M1(w))
        throw new O1(v, "function", s);
      var D = qr(p, e, t, i, r, a), m = w(D.map(function(b) {
        return b.value;
      }));
      Array.isArray(m) || (m = [m]), o.push.apply(o, m.map(function(b) {
        return {
          type: typeof b == "string" ? Qe.literal : Qe.object,
          value: b
        };
      }));
    }
    if (oh(u)) {
      var _ = u.options[h] || u.options.other;
      if (!_)
        throw new Yu(u.value, h, Object.keys(u.options), s);
      o.push.apply(o, qr(_.value, e, t, i, r));
      continue;
    }
    if (lh(u)) {
      var _ = u.options["=".concat(h)];
      if (!_) {
        if (!Intl.PluralRules)
          throw new Sa(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, bi.MISSING_INTL_API, s);
        var g = t.getPluralRules(e, { type: u.pluralType }).select(h - (u.offset || 0));
        _ = u.options[g] || u.options.other;
      }
      if (!_)
        throw new Yu(u.value, h, Object.keys(u.options), s);
      o.push.apply(o, qr(_.value, e, t, i, r, h - (u.offset || 0)));
      continue;
    }
  }
  return R1(o);
}
function N1(n, e) {
  return e ? ee(ee(ee({}, n || {}), e || {}), Object.keys(n).reduce(function(t, i) {
    return t[i] = ee(ee({}, n[i]), e[i] || {}), t;
  }, {})) : n;
}
function U1(n, e) {
  return e ? Object.keys(n).reduce(function(t, i) {
    return t[i] = N1(n[i], e[i]), t;
  }, ee({}, n)) : n;
}
function ys(n) {
  return {
    create: function() {
      return {
        get: function(e) {
          return n[e];
        },
        set: function(e, t) {
          n[e] = t;
        }
      };
    }
  };
}
function H1(n) {
  return n === void 0 && (n = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: bs(function() {
      for (var e, t = [], i = 0; i < arguments.length; i++)
        t[i] = arguments[i];
      return new ((e = Intl.NumberFormat).bind.apply(e, ms([void 0], t, !1)))();
    }, {
      cache: ys(n.number),
      strategy: vs.variadic
    }),
    getDateTimeFormat: bs(function() {
      for (var e, t = [], i = 0; i < arguments.length; i++)
        t[i] = arguments[i];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, ms([void 0], t, !1)))();
    }, {
      cache: ys(n.dateTime),
      strategy: vs.variadic
    }),
    getPluralRules: bs(function() {
      for (var e, t = [], i = 0; i < arguments.length; i++)
        t[i] = arguments[i];
      return new ((e = Intl.PluralRules).bind.apply(e, ms([void 0], t, !1)))();
    }, {
      cache: ys(n.pluralRules),
      strategy: vs.variadic
    })
  };
}
var G1 = (
  /** @class */
  function() {
    function n(e, t, i, r) {
      var a = this;
      if (t === void 0 && (t = n.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(s) {
        var o = a.formatToParts(s);
        if (o.length === 1)
          return o[0].value;
        var l = o.reduce(function(c, u) {
          return !c.length || u.type !== Qe.literal || typeof c[c.length - 1] != "string" ? c.push(u.value) : c[c.length - 1] += u.value, c;
        }, []);
        return l.length <= 1 ? l[0] || "" : l;
      }, this.formatToParts = function(s) {
        return qr(a.ast, a.locales, a.formatters, a.formats, s, void 0, a.message);
      }, this.resolvedOptions = function() {
        return {
          locale: a.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return a.ast;
      }, this.locales = t, this.resolvedLocale = n.resolveLocale(t), typeof e == "string") {
        if (this.message = e, !n.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = n.__parse(e, {
          ignoreTag: r == null ? void 0 : r.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = e;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = U1(n.formats, i), this.formatters = r && r.formatters || H1(this.formatterCache);
    }
    return Object.defineProperty(n, "defaultLocale", {
      get: function() {
        return n.memoizedDefaultLocale || (n.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), n.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), n.memoizedDefaultLocale = null, n.resolveLocale = function(e) {
      var t = Intl.NumberFormat.supportedLocalesOf(e);
      return t.length > 0 ? new Intl.Locale(t[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
    }, n.__parse = F1, n.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, n;
  }()
);
function z1(n, e) {
  if (e == null)
    return;
  if (e in n)
    return n[e];
  const t = e.split(".");
  let i = n;
  for (let r = 0; r < t.length; r++)
    if (typeof i == "object") {
      if (r > 0) {
        const a = t.slice(r, t.length).join(".");
        if (a in i) {
          i = i[a];
          break;
        }
      }
      i = i[t[r]];
    } else
      i = void 0;
  return i;
}
const bn = {}, q1 = (n, e, t) => t && (e in bn || (bn[e] = {}), n in bn[e] || (bn[e][n] = t), t), yh = (n, e) => {
  if (e == null)
    return;
  if (e in bn && n in bn[e])
    return bn[e][n];
  const t = Aa(e);
  for (let i = 0; i < t.length; i++) {
    const r = t[i], a = V1(r, n);
    if (a)
      return q1(n, e, a);
  }
};
let Ho;
const or = sr({});
function j1(n) {
  return Ho[n] || null;
}
function wh(n) {
  return n in Ho;
}
function V1(n, e) {
  if (!wh(n))
    return null;
  const t = j1(n);
  return z1(t, e);
}
function W1(n) {
  if (n == null)
    return;
  const e = Aa(n);
  for (let t = 0; t < e.length; t++) {
    const i = e[t];
    if (wh(i))
      return i;
  }
}
function X1(n, ...e) {
  delete bn[n], or.update((t) => (t[n] = mi.all([t[n] || {}, ...e]), t));
}
Di(
  [or],
  ([n]) => Object.keys(n)
);
or.subscribe((n) => Ho = n);
const jr = {};
function Z1(n, e) {
  jr[n].delete(e), jr[n].size === 0 && delete jr[n];
}
function Dh(n) {
  return jr[n];
}
function Y1(n) {
  return Aa(n).map((e) => {
    const t = Dh(e);
    return [e, t ? [...t] : []];
  }).filter(([, e]) => e.length > 0);
}
function ao(n) {
  return n == null ? !1 : Aa(n).some(
    (e) => {
      var t;
      return (t = Dh(e)) == null ? void 0 : t.size;
    }
  );
}
function K1(n, e) {
  return Promise.all(
    e.map((i) => (Z1(n, i), i().then((r) => r.default || r)))
  ).then((i) => X1(n, ...i));
}
const xi = {};
function Eh(n) {
  if (!ao(n))
    return n in xi ? xi[n] : Promise.resolve();
  const e = Y1(n);
  return xi[n] = Promise.all(
    e.map(
      ([t, i]) => K1(t, i)
    )
  ).then(() => {
    if (ao(n))
      return Eh(n);
    delete xi[n];
  }), xi[n];
}
const Q1 = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, J1 = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: Q1,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, eb = J1;
function vi() {
  return eb;
}
const ws = sr(!1);
var tb = Object.defineProperty, nb = Object.defineProperties, ib = Object.getOwnPropertyDescriptors, Ku = Object.getOwnPropertySymbols, rb = Object.prototype.hasOwnProperty, ab = Object.prototype.propertyIsEnumerable, Qu = (n, e, t) => e in n ? tb(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t, sb = (n, e) => {
  for (var t in e || (e = {}))
    rb.call(e, t) && Qu(n, t, e[t]);
  if (Ku)
    for (var t of Ku(e))
      ab.call(e, t) && Qu(n, t, e[t]);
  return n;
}, ob = (n, e) => nb(n, ib(e));
let so;
const fa = sr(null);
function Ju(n) {
  return n.split("-").map((e, t, i) => i.slice(0, t + 1).join("-")).reverse();
}
function Aa(n, e = vi().fallbackLocale) {
  const t = Ju(n);
  return e ? [.../* @__PURE__ */ new Set([...t, ...Ju(e)])] : t;
}
function Yn() {
  return so ?? void 0;
}
fa.subscribe((n) => {
  so = n ?? void 0, typeof window < "u" && n != null && document.documentElement.setAttribute("lang", n);
});
const lb = (n) => {
  if (n && W1(n) && ao(n)) {
    const { loadingDelay: e } = vi();
    let t;
    return typeof window < "u" && Yn() != null && e ? t = window.setTimeout(
      () => ws.set(!0),
      e
    ) : ws.set(!0), Eh(n).then(() => {
      fa.set(n);
    }).finally(() => {
      clearTimeout(t), ws.set(!1);
    });
  }
  return fa.set(n);
}, lr = ob(sb({}, fa), {
  set: lb
}), Fa = (n) => {
  const e = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const r = JSON.stringify(i);
    return r in e ? e[r] : e[r] = n(i);
  };
};
var ub = Object.defineProperty, ha = Object.getOwnPropertySymbols, Ch = Object.prototype.hasOwnProperty, kh = Object.prototype.propertyIsEnumerable, ec = (n, e, t) => e in n ? ub(n, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : n[e] = t, Go = (n, e) => {
  for (var t in e || (e = {}))
    Ch.call(e, t) && ec(n, t, e[t]);
  if (ha)
    for (var t of ha(e))
      kh.call(e, t) && ec(n, t, e[t]);
  return n;
}, Ei = (n, e) => {
  var t = {};
  for (var i in n)
    Ch.call(n, i) && e.indexOf(i) < 0 && (t[i] = n[i]);
  if (n != null && ha)
    for (var i of ha(n))
      e.indexOf(i) < 0 && kh.call(n, i) && (t[i] = n[i]);
  return t;
};
const er = (n, e) => {
  const { formats: t } = vi();
  if (n in t && e in t[n])
    return t[n][e];
  throw new Error(`[svelte-i18n] Unknown "${e}" ${n} format.`);
}, cb = Fa(
  (n) => {
    var e = n, { locale: t, format: i } = e, r = Ei(e, ["locale", "format"]);
    if (t == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (r = er("number", i)), new Intl.NumberFormat(t, r);
  }
), fb = Fa(
  (n) => {
    var e = n, { locale: t, format: i } = e, r = Ei(e, ["locale", "format"]);
    if (t == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? r = er("date", i) : Object.keys(r).length === 0 && (r = er("date", "short")), new Intl.DateTimeFormat(t, r);
  }
), hb = Fa(
  (n) => {
    var e = n, { locale: t, format: i } = e, r = Ei(e, ["locale", "format"]);
    if (t == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? r = er("time", i) : Object.keys(r).length === 0 && (r = er("time", "short")), new Intl.DateTimeFormat(t, r);
  }
), db = (n = {}) => {
  var e = n, {
    locale: t = Yn()
  } = e, i = Ei(e, [
    "locale"
  ]);
  return cb(Go({ locale: t }, i));
}, _b = (n = {}) => {
  var e = n, {
    locale: t = Yn()
  } = e, i = Ei(e, [
    "locale"
  ]);
  return fb(Go({ locale: t }, i));
}, pb = (n = {}) => {
  var e = n, {
    locale: t = Yn()
  } = e, i = Ei(e, [
    "locale"
  ]);
  return hb(Go({ locale: t }, i));
}, mb = Fa(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (n, e = Yn()) => new G1(n, e, vi().formats, {
    ignoreTag: vi().ignoreTag
  })
), gb = (n, e = {}) => {
  var t, i, r, a;
  let s = e;
  typeof n == "object" && (s = n, n = s.id);
  const {
    values: o,
    locale: l = Yn(),
    default: c
  } = s;
  if (l == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let u = yh(n, l);
  if (!u)
    u = (a = (r = (i = (t = vi()).handleMissingMessage) == null ? void 0 : i.call(t, { locale: l, id: n, defaultValue: c })) != null ? r : c) != null ? a : n;
  else if (typeof u != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${n}" must be of type "string", found: "${typeof u}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), u;
  if (!o)
    return u;
  let f = u;
  try {
    f = mb(u, l).format(o);
  } catch (h) {
    h instanceof Error && console.warn(
      `[svelte-i18n] Message "${n}" has syntax error:`,
      h.message
    );
  }
  return f;
}, bb = (n, e) => pb(e).format(n), vb = (n, e) => _b(e).format(n), yb = (n, e) => db(e).format(n), wb = (n, e = Yn()) => yh(n, e);
Di([lr, or], () => gb);
Di([lr], () => bb);
Di([lr], () => vb);
Di([lr], () => yb);
Di([lr, or], () => wb);
const {
  SvelteComponent: Db,
  append_hydration: ot,
  attr: Cn,
  children: kn,
  claim_element: Sn,
  claim_space: oo,
  claim_text: si,
  detach: cn,
  element: An,
  init: Eb,
  insert_hydration: Sh,
  noop: tc,
  safe_not_equal: Cb,
  set_data: da,
  set_style: Ds,
  space: lo,
  text: oi,
  toggle_class: nc
} = window.__gradio__svelte__internal, { onMount: kb, createEventDispatcher: Sb, onDestroy: Ab } = window.__gradio__svelte__internal;
function ic(n) {
  let e, t, i, r, a = Ui(
    /*file_to_display*/
    n[2]
  ) + "", s, o, l, c, u = (
    /*file_to_display*/
    n[2].orig_name + ""
  ), f;
  return {
    c() {
      e = An("div"), t = An("span"), i = An("div"), r = An("progress"), s = oi(a), l = lo(), c = An("span"), f = oi(u), this.h();
    },
    l(h) {
      e = Sn(h, "DIV", { class: !0 });
      var d = kn(e);
      t = Sn(d, "SPAN", {});
      var p = kn(t);
      i = Sn(p, "DIV", { class: !0 });
      var v = kn(i);
      r = Sn(v, "PROGRESS", { style: !0, max: !0, class: !0 });
      var w = kn(r);
      s = si(w, a), w.forEach(cn), v.forEach(cn), p.forEach(cn), l = oo(d), c = Sn(d, "SPAN", { class: !0 });
      var D = kn(c);
      f = si(D, u), D.forEach(cn), d.forEach(cn), this.h();
    },
    h() {
      Ds(r, "visibility", "hidden"), Ds(r, "height", "0"), Ds(r, "width", "0"), r.value = o = Ui(
        /*file_to_display*/
        n[2]
      ), Cn(r, "max", "100"), Cn(r, "class", "svelte-cr2edf"), Cn(i, "class", "progress-bar svelte-cr2edf"), Cn(c, "class", "file-name svelte-cr2edf"), Cn(e, "class", "file svelte-cr2edf");
    },
    m(h, d) {
      Sh(h, e, d), ot(e, t), ot(t, i), ot(i, r), ot(r, s), ot(e, l), ot(e, c), ot(c, f);
    },
    p(h, d) {
      d & /*file_to_display*/
      4 && a !== (a = Ui(
        /*file_to_display*/
        h[2]
      ) + "") && da(s, a), d & /*file_to_display*/
      4 && o !== (o = Ui(
        /*file_to_display*/
        h[2]
      )) && (r.value = o), d & /*file_to_display*/
      4 && u !== (u = /*file_to_display*/
      h[2].orig_name + "") && da(f, u);
    },
    d(h) {
      h && cn(e);
    }
  };
}
function Fb(n) {
  let e, t, i, r = (
    /*files_with_progress*/
    n[0].length + ""
  ), a, s, o = (
    /*files_with_progress*/
    n[0].length > 1 ? "files" : "file"
  ), l, c, u, f = (
    /*file_to_display*/
    n[2] && ic(n)
  );
  return {
    c() {
      e = An("div"), t = An("span"), i = oi("Uploading "), a = oi(r), s = lo(), l = oi(o), c = oi("..."), u = lo(), f && f.c(), this.h();
    },
    l(h) {
      e = Sn(h, "DIV", { class: !0 });
      var d = kn(e);
      t = Sn(d, "SPAN", { class: !0 });
      var p = kn(t);
      i = si(p, "Uploading "), a = si(p, r), s = oo(p), l = si(p, o), c = si(p, "..."), p.forEach(cn), u = oo(d), f && f.l(d), d.forEach(cn), this.h();
    },
    h() {
      Cn(t, "class", "uploading svelte-cr2edf"), Cn(e, "class", "wrap svelte-cr2edf"), nc(
        e,
        "progress",
        /*progress*/
        n[1]
      );
    },
    m(h, d) {
      Sh(h, e, d), ot(e, t), ot(t, i), ot(t, a), ot(t, s), ot(t, l), ot(t, c), ot(e, u), f && f.m(e, null);
    },
    p(h, [d]) {
      d & /*files_with_progress*/
      1 && r !== (r = /*files_with_progress*/
      h[0].length + "") && da(a, r), d & /*files_with_progress*/
      1 && o !== (o = /*files_with_progress*/
      h[0].length > 1 ? "files" : "file") && da(l, o), /*file_to_display*/
      h[2] ? f ? f.p(h, d) : (f = ic(h), f.c(), f.m(e, null)) : f && (f.d(1), f = null), d & /*progress*/
      2 && nc(
        e,
        "progress",
        /*progress*/
        h[1]
      );
    },
    i: tc,
    o: tc,
    d(h) {
      h && cn(e), f && f.d();
    }
  };
}
function Ui(n) {
  return n.progress * 100 / (n.size || 0) || 0;
}
function Tb(n) {
  let e = 0;
  return n.forEach((t) => {
    e += Ui(t);
  }), document.documentElement.style.setProperty("--upload-progress-width", (e / n.length).toFixed(2) + "%"), e / n.length;
}
function Ib(n, e, t) {
  var i = this && this.__awaiter || function(v, w, D, m) {
    function _(g) {
      return g instanceof D ? g : new D(function(b) {
        b(g);
      });
    }
    return new (D || (D = Promise))(function(g, b) {
      function E(A) {
        try {
          P(m.next(A));
        } catch (R) {
          b(R);
        }
      }
      function k(A) {
        try {
          P(m.throw(A));
        } catch (R) {
          b(R);
        }
      }
      function P(A) {
        A.done ? g(A.value) : _(A.value).then(E, k);
      }
      P((m = m.apply(v, w || [])).next());
    });
  };
  let { upload_id: r } = e, { root: a } = e, { files: s } = e, { stream_handler: o } = e, l, c = !1, u, f, h = s.map((v) => Object.assign(Object.assign({}, v), { progress: 0 }));
  const d = Sb();
  function p(v, w) {
    t(0, h = h.map((D) => (D.orig_name === v && (D.progress += w), D)));
  }
  return kb(() => i(void 0, void 0, void 0, function* () {
    if (l = yield o(new URL(`${a}/gradio_api/upload_progress?upload_id=${r}`)), l == null)
      throw new Error("Event source is not defined");
    l.onmessage = function(v) {
      return i(this, void 0, void 0, function* () {
        const w = JSON.parse(v.data);
        c || t(1, c = !0), w.msg === "done" ? (l == null || l.close(), d("done")) : (t(7, u = w), p(w.orig_name, w.chunk_size));
      });
    };
  })), Ab(() => {
    (l != null || l != null) && l.close();
  }), n.$$set = (v) => {
    "upload_id" in v && t(3, r = v.upload_id), "root" in v && t(4, a = v.root), "files" in v && t(5, s = v.files), "stream_handler" in v && t(6, o = v.stream_handler);
  }, n.$$.update = () => {
    n.$$.dirty & /*files_with_progress*/
    1 && Tb(h), n.$$.dirty & /*current_file_upload, files_with_progress*/
    129 && t(2, f = u || h[0]);
  }, [
    h,
    c,
    f,
    r,
    a,
    s,
    o,
    u
  ];
}
class $b extends Db {
  constructor(e) {
    super(), Eb(this, e, Ib, Fb, Cb, {
      upload_id: 3,
      root: 4,
      files: 5,
      stream_handler: 6
    });
  }
}
function xb() {
  let n, e;
  return {
    drag(t, i = {}) {
      e = i;
      function r() {
        n = document.createElement("input"), n.type = "file", n.style.display = "none", n.setAttribute("aria-label", "File upload"), n.setAttribute("data-testid", "file-upload");
        const f = Array.isArray(e.accepted_types) ? e.accepted_types.join(",") : e.accepted_types || void 0;
        f && (n.accept = f), n.multiple = e.mode === "multiple" || !1, e.mode === "directory" && (n.webkitdirectory = !0, n.setAttribute("directory", ""), n.setAttribute("mozdirectory", "")), t.appendChild(n);
      }
      r();
      function a(f) {
        f.preventDefault(), f.stopPropagation();
      }
      function s(f) {
        var h;
        f.preventDefault(), f.stopPropagation(), (h = e.on_drag_change) == null || h.call(e, !0);
      }
      function o(f) {
        var h;
        f.preventDefault(), f.stopPropagation(), (h = e.on_drag_change) == null || h.call(e, !1);
      }
      function l(f) {
        var d, p, v;
        if (f.preventDefault(), f.stopPropagation(), (d = e.on_drag_change) == null || d.call(e, !1), !((p = f.dataTransfer) != null && p.files)) return;
        const h = Array.from(f.dataTransfer.files);
        h.length > 0 && ((v = e.on_files) == null || v.call(e, h));
      }
      function c() {
        e.disable_click || (n.value = "", n.click());
      }
      function u() {
        var f;
        if (n.files) {
          const h = Array.from(n.files);
          h.length > 0 && ((f = e.on_files) == null || f.call(e, h));
        }
      }
      return t.addEventListener("drag", a), t.addEventListener("dragstart", a), t.addEventListener("dragend", a), t.addEventListener("dragover", a), t.addEventListener("dragenter", s), t.addEventListener("dragleave", o), t.addEventListener("drop", l), t.addEventListener("click", c), n.addEventListener("change", u), {
        update(f) {
          e = f, n.remove(), r(), n.addEventListener("change", u);
        },
        destroy() {
          t.removeEventListener("drag", a), t.removeEventListener("dragstart", a), t.removeEventListener("dragend", a), t.removeEventListener("dragover", a), t.removeEventListener("dragenter", s), t.removeEventListener("dragleave", o), t.removeEventListener("drop", l), t.removeEventListener("click", c), n.removeEventListener("change", u), n.remove();
        }
      };
    },
    open_file_upload() {
      n && (n.value = "", n.click());
    }
  };
}
const {
  SvelteComponent: Pb,
  action_destroyer: Bb,
  attr: xt,
  check_outros: Ah,
  children: Fh,
  claim_component: Ob,
  claim_element: Th,
  create_component: Lb,
  create_slot: Ih,
  destroy_component: Rb,
  detach: yi,
  element: $h,
  empty: _a,
  get_all_dirty_from_scope: xh,
  get_slot_changes: Ph,
  group_outros: Bh,
  init: Mb,
  insert_hydration: Ta,
  is_function: Nb,
  listen: Ub,
  mount_component: Hb,
  safe_not_equal: Gb,
  set_style: pa,
  toggle_class: Ce,
  transition_in: yn,
  transition_out: Gn,
  update_slot_base: Oh
} = window.__gradio__svelte__internal, { createEventDispatcher: zb, tick: qb, getContext: D6 } = window.__gradio__svelte__internal;
function jb(n) {
  let e, t, i, r, a, s, o;
  const l = (
    /*#slots*/
    n[30].default
  ), c = Ih(
    l,
    n,
    /*$$scope*/
    n[29],
    null
  );
  return {
    c() {
      e = $h("button"), c && c.c(), this.h();
    },
    l(u) {
      e = Th(u, "BUTTON", {
        tabindex: !0,
        "aria-label": !0,
        "aria-dropeffect": !0,
        class: !0
      });
      var f = Fh(e);
      c && c.l(f), f.forEach(yi), this.h();
    },
    h() {
      xt(e, "tabindex", t = /*hidden*/
      n[9] ? -1 : 0), xt(e, "aria-label", i = /*aria_label*/
      n[14] || "Click to upload or drop files"), xt(e, "aria-dropeffect", "copy"), xt(e, "class", "svelte-1o7nwih"), Ce(
        e,
        "hidden",
        /*hidden*/
        n[9]
      ), Ce(
        e,
        "center",
        /*center*/
        n[4]
      ), Ce(
        e,
        "boundedheight",
        /*boundedheight*/
        n[3]
      ), Ce(
        e,
        "flex",
        /*flex*/
        n[5]
      ), Ce(
        e,
        "disable_click",
        /*disable_click*/
        n[7]
      ), Ce(
        e,
        "icon-mode",
        /*icon_upload*/
        n[12]
      ), pa(
        e,
        "height",
        /*icon_upload*/
        n[12] ? "" : (
          /*height*/
          n[13] ? typeof /*height*/
          n[13] == "number" ? (
            /*height*/
            n[13] + "px"
          ) : (
            /*height*/
            n[13]
          ) : "100%"
        )
      );
    },
    m(u, f) {
      Ta(u, e, f), c && c.m(e, null), a = !0, s || (o = Bb(r = /*drag*/
      n[19].call(null, e, {
        on_drag_change: ac,
        on_files: (
          /*drag_function_1*/
          n[31]
        ),
        accepted_types: (
          /*accept_file_types*/
          n[18]
        ),
        mode: (
          /*file_count*/
          n[6]
        ),
        disable_click: (
          /*disable_click*/
          n[7]
        )
      })), s = !0);
    },
    p(u, f) {
      c && c.p && (!a || f[0] & /*$$scope*/
      536870912) && Oh(
        c,
        l,
        u,
        /*$$scope*/
        u[29],
        a ? Ph(
          l,
          /*$$scope*/
          u[29],
          f,
          null
        ) : xh(
          /*$$scope*/
          u[29]
        ),
        null
      ), (!a || f[0] & /*hidden*/
      512 && t !== (t = /*hidden*/
      u[9] ? -1 : 0)) && xt(e, "tabindex", t), (!a || f[0] & /*aria_label*/
      16384 && i !== (i = /*aria_label*/
      u[14] || "Click to upload or drop files")) && xt(e, "aria-label", i), r && Nb(r.update) && f[0] & /*accept_file_types, file_count, disable_click*/
      262336 && r.update.call(null, {
        on_drag_change: ac,
        on_files: (
          /*drag_function_1*/
          u[31]
        ),
        accepted_types: (
          /*accept_file_types*/
          u[18]
        ),
        mode: (
          /*file_count*/
          u[6]
        ),
        disable_click: (
          /*disable_click*/
          u[7]
        )
      }), (!a || f[0] & /*hidden*/
      512) && Ce(
        e,
        "hidden",
        /*hidden*/
        u[9]
      ), (!a || f[0] & /*center*/
      16) && Ce(
        e,
        "center",
        /*center*/
        u[4]
      ), (!a || f[0] & /*boundedheight*/
      8) && Ce(
        e,
        "boundedheight",
        /*boundedheight*/
        u[3]
      ), (!a || f[0] & /*flex*/
      32) && Ce(
        e,
        "flex",
        /*flex*/
        u[5]
      ), (!a || f[0] & /*disable_click*/
      128) && Ce(
        e,
        "disable_click",
        /*disable_click*/
        u[7]
      ), (!a || f[0] & /*icon_upload*/
      4096) && Ce(
        e,
        "icon-mode",
        /*icon_upload*/
        u[12]
      ), f[0] & /*icon_upload, height*/
      12288 && pa(
        e,
        "height",
        /*icon_upload*/
        u[12] ? "" : (
          /*height*/
          u[13] ? typeof /*height*/
          u[13] == "number" ? (
            /*height*/
            u[13] + "px"
          ) : (
            /*height*/
            u[13]
          ) : "100%"
        )
      );
    },
    i(u) {
      a || (yn(c, u), a = !0);
    },
    o(u) {
      Gn(c, u), a = !1;
    },
    d(u) {
      u && yi(e), c && c.d(u), s = !1, o();
    }
  };
}
function Vb(n) {
  let e, t, i = !/*hidden*/
  n[9] && rc(n);
  return {
    c() {
      i && i.c(), e = _a();
    },
    l(r) {
      i && i.l(r), e = _a();
    },
    m(r, a) {
      i && i.m(r, a), Ta(r, e, a), t = !0;
    },
    p(r, a) {
      /*hidden*/
      r[9] ? i && (Bh(), Gn(i, 1, 1, () => {
        i = null;
      }), Ah()) : i ? (i.p(r, a), a[0] & /*hidden*/
      512 && yn(i, 1)) : (i = rc(r), i.c(), yn(i, 1), i.m(e.parentNode, e));
    },
    i(r) {
      t || (yn(i), t = !0);
    },
    o(r) {
      Gn(i), t = !1;
    },
    d(r) {
      r && yi(e), i && i.d(r);
    }
  };
}
function Wb(n) {
  let e, t, i, r, a, s;
  const o = (
    /*#slots*/
    n[30].default
  ), l = Ih(
    o,
    n,
    /*$$scope*/
    n[29],
    null
  );
  return {
    c() {
      e = $h("button"), l && l.c(), this.h();
    },
    l(c) {
      e = Th(c, "BUTTON", {
        tabindex: !0,
        "aria-label": !0,
        class: !0
      });
      var u = Fh(e);
      l && l.l(u), u.forEach(yi), this.h();
    },
    h() {
      xt(e, "tabindex", t = /*hidden*/
      n[9] ? -1 : 0), xt(e, "aria-label", i = /*aria_label*/
      n[14] || "Paste from clipboard"), xt(e, "class", "svelte-1o7nwih"), Ce(
        e,
        "hidden",
        /*hidden*/
        n[9]
      ), Ce(
        e,
        "center",
        /*center*/
        n[4]
      ), Ce(
        e,
        "boundedheight",
        /*boundedheight*/
        n[3]
      ), Ce(
        e,
        "flex",
        /*flex*/
        n[5]
      ), Ce(
        e,
        "icon-mode",
        /*icon_upload*/
        n[12]
      ), pa(
        e,
        "height",
        /*icon_upload*/
        n[12] ? "" : (
          /*height*/
          n[13] ? typeof /*height*/
          n[13] == "number" ? (
            /*height*/
            n[13] + "px"
          ) : (
            /*height*/
            n[13]
          ) : "100%"
        )
      );
    },
    m(c, u) {
      Ta(c, e, u), l && l.m(e, null), r = !0, a || (s = Ub(
        e,
        "click",
        /*paste_clipboard*/
        n[15]
      ), a = !0);
    },
    p(c, u) {
      l && l.p && (!r || u[0] & /*$$scope*/
      536870912) && Oh(
        l,
        o,
        c,
        /*$$scope*/
        c[29],
        r ? Ph(
          o,
          /*$$scope*/
          c[29],
          u,
          null
        ) : xh(
          /*$$scope*/
          c[29]
        ),
        null
      ), (!r || u[0] & /*hidden*/
      512 && t !== (t = /*hidden*/
      c[9] ? -1 : 0)) && xt(e, "tabindex", t), (!r || u[0] & /*aria_label*/
      16384 && i !== (i = /*aria_label*/
      c[14] || "Paste from clipboard")) && xt(e, "aria-label", i), (!r || u[0] & /*hidden*/
      512) && Ce(
        e,
        "hidden",
        /*hidden*/
        c[9]
      ), (!r || u[0] & /*center*/
      16) && Ce(
        e,
        "center",
        /*center*/
        c[4]
      ), (!r || u[0] & /*boundedheight*/
      8) && Ce(
        e,
        "boundedheight",
        /*boundedheight*/
        c[3]
      ), (!r || u[0] & /*flex*/
      32) && Ce(
        e,
        "flex",
        /*flex*/
        c[5]
      ), (!r || u[0] & /*icon_upload*/
      4096) && Ce(
        e,
        "icon-mode",
        /*icon_upload*/
        c[12]
      ), u[0] & /*icon_upload, height*/
      12288 && pa(
        e,
        "height",
        /*icon_upload*/
        c[12] ? "" : (
          /*height*/
          c[13] ? typeof /*height*/
          c[13] == "number" ? (
            /*height*/
            c[13] + "px"
          ) : (
            /*height*/
            c[13]
          ) : "100%"
        )
      );
    },
    i(c) {
      r || (yn(l, c), r = !0);
    },
    o(c) {
      Gn(l, c), r = !1;
    },
    d(c) {
      c && yi(e), l && l.d(c), a = !1, s();
    }
  };
}
function rc(n) {
  let e, t;
  return e = new $b({
    props: {
      root: (
        /*root*/
        n[8]
      ),
      upload_id: (
        /*upload_id*/
        n[16]
      ),
      files: (
        /*file_data*/
        n[17]
      ),
      stream_handler: (
        /*stream_handler*/
        n[11]
      )
    }
  }), {
    c() {
      Lb(e.$$.fragment);
    },
    l(i) {
      Ob(e.$$.fragment, i);
    },
    m(i, r) {
      Hb(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*root*/
      256 && (a.root = /*root*/
      i[8]), r[0] & /*upload_id*/
      65536 && (a.upload_id = /*upload_id*/
      i[16]), r[0] & /*file_data*/
      131072 && (a.files = /*file_data*/
      i[17]), r[0] & /*stream_handler*/
      2048 && (a.stream_handler = /*stream_handler*/
      i[11]), e.$set(a);
    },
    i(i) {
      t || (yn(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Gn(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Rb(e, i);
    }
  };
}
function Xb(n) {
  let e, t, i, r;
  const a = [Wb, Vb, jb], s = [];
  function o(l, c) {
    return (
      /*filetype*/
      l[0] === "clipboard" ? 0 : (
        /*uploading*/
        l[2] && /*show_progress*/
        l[10] ? 1 : 2
      )
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = _a();
    },
    l(l) {
      t.l(l), i = _a();
    },
    m(l, c) {
      s[e].m(l, c), Ta(l, i, c), r = !0;
    },
    p(l, c) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (Bh(), Gn(s[u], 1, 1, () => {
        s[u] = null;
      }), Ah(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), yn(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (yn(t), r = !0);
    },
    o(l) {
      Gn(t), r = !1;
    },
    d(l) {
      l && yi(i), s[e].d(l);
    }
  };
}
function Zb(n, e, t) {
  if (!n || n === "*" || n === "file/*" || Array.isArray(n) && n.some((r) => r === "*" || r === "file/*"))
    return !0;
  let i;
  if (typeof n == "string")
    i = n.split(",").map((r) => r.trim());
  else if (Array.isArray(n))
    i = n;
  else
    return !1;
  return i.includes(e) || i.some((r) => {
    const [a] = r.split("/").map((s) => s.trim());
    return r.endsWith("/*") && t.startsWith(a + "/");
  });
}
const ac = (n) => n = n;
function Yb(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e;
  var s = this && this.__awaiter || function(I, q, j, V) {
    function ce(Ee) {
      return Ee instanceof j ? Ee : new j(function(S) {
        S(Ee);
      });
    }
    return new (j || (j = Promise))(function(Ee, S) {
      function le(Ae) {
        try {
          fe(V.next(Ae));
        } catch (Fe) {
          S(Fe);
        }
      }
      function Pe(Ae) {
        try {
          fe(V.throw(Ae));
        } catch (Fe) {
          S(Fe);
        }
      }
      function fe(Ae) {
        Ae.done ? Ee(Ae.value) : ce(Ae.value).then(le, Pe);
      }
      fe((V = V.apply(I, q || [])).next());
    });
  };
  const { drag: o, open_file_upload: l } = xb();
  let { filetype: c = null } = e, { dragging: u = !1 } = e, { boundedheight: f = !0 } = e, { center: h = !0 } = e, { flex: d = !0 } = e, { file_count: p = "single" } = e, { disable_click: v = !1 } = e, { root: w } = e, { hidden: D = !1 } = e, { format: m = "file" } = e, { uploading: _ = !1 } = e, { show_progress: g = !0 } = e, { max_file_size: b = null } = e, { upload: E } = e, { stream_handler: k } = e, { icon_upload: P = !1 } = e, { height: A = void 0 } = e, { aria_label: R = void 0 } = e;
  function B() {
    l();
  }
  let L, de, z, te = null;
  const Q = () => {
    if (typeof navigator < "u") {
      const I = navigator.userAgent.toLowerCase();
      return I.indexOf("iphone") > -1 || I.indexOf("ipad") > -1;
    }
    return !1;
  }, oe = zb(), X = ["image", "video", "audio", "text", "file"], ne = (I) => i && I.startsWith(".") ? (te = !0, I) : i && I.includes("file/*") ? "*" : I.startsWith(".") || I.endsWith("/*") ? I : X.includes(I) ? I + "/*" : "." + I;
  function De() {
    navigator.clipboard.read().then((I) => s(this, void 0, void 0, function* () {
      for (let q = 0; q < I.length; q++) {
        const j = I[q].types.find((V) => V.startsWith("image/"));
        if (j) {
          I[q].getType(j).then((V) => s(this, void 0, void 0, function* () {
            const ce = new File([V], `clipboard.${j.replace("image/", "")}`);
            yield H([ce]);
          }));
          break;
        }
      }
    }));
  }
  function F() {
    l();
  }
  function x(I) {
    return s(this, void 0, void 0, function* () {
      yield qb(), t(16, L = Math.random().toString(36).substring(2, 15)), t(2, _ = !0);
      try {
        const q = yield E(I, w, L, b ?? 1 / 0);
        return oe("load", p === "single" ? q == null ? void 0 : q[0] : q), t(2, _ = !1), q || [];
      } catch (q) {
        return oe("error", q.message), t(2, _ = !1), [];
      }
    });
  }
  function H(I) {
    return s(this, void 0, void 0, function* () {
      if (!I.length)
        return;
      let q = I.map((j) => new File([j], j instanceof File ? j.name : "file", { type: j.type }));
      return i && te && (q = q.filter((j) => J(j) ? !0 : (oe("error", `Invalid file type: ${j.name}. Only ${c} allowed.`), !1)), q.length === 0) ? [] : (t(17, de = yield P0(q)), yield x(de));
    });
  }
  function J(I) {
    return c ? (Array.isArray(c) ? c : [c]).some((j) => {
      const V = ne(j);
      if (V.startsWith("."))
        return I.name.toLowerCase().endsWith(V.toLowerCase());
      if (V === "*")
        return !0;
      if (V.endsWith("/*")) {
        const [ce] = V.split("/");
        return I.type.startsWith(ce + "/");
      }
      return I.type === V;
    }) : !0;
  }
  function T(I) {
    return s(this, void 0, void 0, function* () {
      const q = I.filter((j) => {
        const V = "." + j.name.split(".").pop();
        return V && Zb(z, V, j.type) || (V && Array.isArray(c) ? c.includes(V) : V === c) ? !0 : (oe("error", `Invalid file type only ${c} allowed.`), !1);
      });
      if (m != "blob")
        yield H(q);
      else {
        if (p === "single") {
          oe("load", q[0]);
          return;
        }
        oe("load", q);
      }
    });
  }
  function ke(I) {
    return s(this, void 0, void 0, function* () {
      var q;
      if (t(1, u = !1), !(!((q = I.dataTransfer) === null || q === void 0) && q.files)) return;
      const j = Array.from(I.dataTransfer.files).filter(J);
      if (m != "blob")
        yield H(j);
      else {
        if (p === "single") {
          oe("load", j[0]);
          return;
        }
        oe("load", j);
      }
    });
  }
  const Se = (I) => T(I);
  return n.$$set = (I) => {
    "filetype" in I && t(0, c = I.filetype), "dragging" in I && t(1, u = I.dragging), "boundedheight" in I && t(3, f = I.boundedheight), "center" in I && t(4, h = I.center), "flex" in I && t(5, d = I.flex), "file_count" in I && t(6, p = I.file_count), "disable_click" in I && t(7, v = I.disable_click), "root" in I && t(8, w = I.root), "hidden" in I && t(9, D = I.hidden), "format" in I && t(21, m = I.format), "uploading" in I && t(2, _ = I.uploading), "show_progress" in I && t(10, g = I.show_progress), "max_file_size" in I && t(22, b = I.max_file_size), "upload" in I && t(23, E = I.upload), "stream_handler" in I && t(11, k = I.stream_handler), "icon_upload" in I && t(12, P = I.icon_upload), "height" in I && t(13, A = I.height), "aria_label" in I && t(14, R = I.aria_label), "$$scope" in I && t(29, a = I.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*filetype, ios*/
    268435457 && (c == null ? t(18, z = null) : typeof c == "string" ? t(18, z = ne(c)) : i && c.includes("file/*") ? t(18, z = "*") : (t(0, c = c.map(ne)), t(18, z = c.join(", "))));
  }, t(28, i = Q()), [
    c,
    u,
    _,
    f,
    h,
    d,
    p,
    v,
    w,
    D,
    g,
    k,
    P,
    A,
    R,
    De,
    L,
    de,
    z,
    o,
    T,
    m,
    b,
    E,
    B,
    F,
    H,
    ke,
    i,
    a,
    r,
    Se
  ];
}
class Kb extends Pb {
  constructor(e) {
    super(), Mb(
      this,
      e,
      Yb,
      Xb,
      Gb,
      {
        filetype: 0,
        dragging: 1,
        boundedheight: 3,
        center: 4,
        flex: 5,
        file_count: 6,
        disable_click: 7,
        root: 8,
        hidden: 9,
        format: 21,
        uploading: 2,
        show_progress: 10,
        max_file_size: 22,
        upload: 23,
        stream_handler: 11,
        icon_upload: 12,
        height: 13,
        aria_label: 14,
        open_upload: 24,
        paste_clipboard: 15,
        open_file_upload: 25,
        load_files: 26,
        load_files_from_drop: 27
      },
      null,
      [-1, -1]
    );
  }
  get open_upload() {
    return this.$$.ctx[24];
  }
  get paste_clipboard() {
    return this.$$.ctx[15];
  }
  get open_file_upload() {
    return this.$$.ctx[25];
  }
  get load_files() {
    return this.$$.ctx[26];
  }
  get load_files_from_drop() {
    return this.$$.ctx[27];
  }
}
const {
  SvelteComponent: E6,
  check_outros: C6,
  claim_component: k6,
  claim_space: S6,
  create_component: A6,
  create_slot: F6,
  destroy_component: T6,
  detach: I6,
  get_all_dirty_from_scope: $6,
  get_slot_changes: x6,
  group_outros: P6,
  init: B6,
  insert_hydration: O6,
  mount_component: L6,
  safe_not_equal: R6,
  space: M6,
  transition_in: N6,
  transition_out: U6,
  update_slot_base: H6
} = window.__gradio__svelte__internal, { createEventDispatcher: G6 } = window.__gradio__svelte__internal, {
  SvelteComponent: Qb,
  add_flush_callback: sc,
  append_hydration: Ue,
  attr: dt,
  bind: oc,
  binding_callbacks: ma,
  bubble: lc,
  check_outros: tr,
  children: yt,
  claim_component: On,
  claim_element: nt,
  claim_space: Ot,
  claim_text: uo,
  create_component: Ln,
  create_slot: Jb,
  destroy_component: Rn,
  destroy_each: e2,
  detach: re,
  element: it,
  empty: wn,
  ensure_array_like: uc,
  get_all_dirty_from_scope: t2,
  get_slot_changes: n2,
  get_svelte_dataset: co,
  group_outros: nr,
  init: i2,
  insert_hydration: Ze,
  listen: ir,
  mount_component: Mn,
  noop: r2,
  run_all: a2,
  safe_not_equal: s2,
  set_data: fo,
  set_style: qt,
  space: Lt,
  text: ho,
  toggle_class: cc,
  transition_in: ve,
  transition_out: Re,
  update_slot_base: o2
} = window.__gradio__svelte__internal, { createEventDispatcher: l2, tick: Es } = window.__gradio__svelte__internal;
function fc(n, e, t) {
  const i = n.slice();
  return i[47] = e[t][0], i[48] = e[t][1], i;
}
function hc(n) {
  let e, t, i, r, a = (
    /*show_fullscreen_button*/
    n[11] && dc(n)
  ), s = (
    /*metadata*/
    n[17] !== null && _c(n)
  );
  return i = new Dn({
    props: { Icon: vf, label: "Remove Image" }
  }), i.$on(
    "click",
    /*click_handler_1*/
    n[36]
  ), {
    c() {
      a && a.c(), e = Lt(), s && s.c(), t = Lt(), Ln(i.$$.fragment);
    },
    l(o) {
      a && a.l(o), e = Ot(o), s && s.l(o), t = Ot(o), On(i.$$.fragment, o);
    },
    m(o, l) {
      a && a.m(o, l), Ze(o, e, l), s && s.m(o, l), Ze(o, t, l), Mn(i, o, l), r = !0;
    },
    p(o, l) {
      /*show_fullscreen_button*/
      o[11] ? a ? (a.p(o, l), l[0] & /*show_fullscreen_button*/
      2048 && ve(a, 1)) : (a = dc(o), a.c(), ve(a, 1), a.m(e.parentNode, e)) : a && (nr(), Re(a, 1, 1, () => {
        a = null;
      }), tr()), /*metadata*/
      o[17] !== null ? s ? (s.p(o, l), l[0] & /*metadata*/
      131072 && ve(s, 1)) : (s = _c(o), s.c(), ve(s, 1), s.m(t.parentNode, t)) : s && (nr(), Re(s, 1, 1, () => {
        s = null;
      }), tr());
    },
    i(o) {
      r || (ve(a), ve(s), ve(i.$$.fragment, o), r = !0);
    },
    o(o) {
      Re(a), Re(s), Re(i.$$.fragment, o), r = !1;
    },
    d(o) {
      o && (re(e), re(t)), a && a.d(o), s && s.d(o), Rn(i, o);
    }
  };
}
function dc(n) {
  let e, t;
  return e = new $f({
    props: { fullscreen: (
      /*fullscreen*/
      n[16]
    ) }
  }), e.$on(
    "fullscreen",
    /*fullscreen_handler*/
    n[34]
  ), {
    c() {
      Ln(e.$$.fragment);
    },
    l(i) {
      On(e.$$.fragment, i);
    },
    m(i, r) {
      Mn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*fullscreen*/
      65536 && (a.fullscreen = /*fullscreen*/
      i[16]), e.$set(a);
    },
    i(i) {
      t || (ve(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Re(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Rn(e, i);
    }
  };
}
function _c(n) {
  let e, t;
  return e = new Dn({
    props: {
      Icon: yf,
      label: "View Metadata",
      "aria-label": "View and send image metadata"
    }
  }), e.$on(
    "click",
    /*click_handler*/
    n[35]
  ), {
    c() {
      Ln(e.$$.fragment);
    },
    l(i) {
      On(e.$$.fragment, i);
    },
    m(i, r) {
      Mn(e, i, r), t = !0;
    },
    p: r2,
    i(i) {
      t || (ve(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Re(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Rn(e, i);
    }
  };
}
function u2(n) {
  var r;
  let e, t, i = (
    /*value*/
    ((r = n[0]) == null ? void 0 : r.url) && hc(n)
  );
  return {
    c() {
      i && i.c(), e = wn();
    },
    l(a) {
      i && i.l(a), e = wn();
    },
    m(a, s) {
      i && i.m(a, s), Ze(a, e, s), t = !0;
    },
    p(a, s) {
      var o;
      /*value*/
      (o = a[0]) != null && o.url ? i ? (i.p(a, s), s[0] & /*value*/
      1 && ve(i, 1)) : (i = hc(a), i.c(), ve(i, 1), i.m(e.parentNode, e)) : i && (nr(), Re(i, 1, 1, () => {
        i = null;
      }), tr());
    },
    i(a) {
      t || (ve(i), t = !0);
    },
    o(a) {
      Re(i), t = !1;
    },
    d(a) {
      a && re(e), i && i.d(a);
    }
  };
}
function pc(n) {
  let e;
  const t = (
    /*#slots*/
    n[33].default
  ), i = Jb(
    t,
    n,
    /*$$scope*/
    n[42],
    null
  );
  return {
    c() {
      i && i.c();
    },
    l(r) {
      i && i.l(r);
    },
    m(r, a) {
      i && i.m(r, a), e = !0;
    },
    p(r, a) {
      i && i.p && (!e || a[1] & /*$$scope*/
      2048) && o2(
        i,
        t,
        r,
        /*$$scope*/
        r[42],
        e ? n2(
          t,
          /*$$scope*/
          r[42],
          a,
          null
        ) : t2(
          /*$$scope*/
          r[42]
        ),
        null
      );
    },
    i(r) {
      e || (ve(i, r), e = !0);
    },
    o(r) {
      Re(i, r), e = !1;
    },
    d(r) {
      i && i.d(r);
    }
  };
}
function c2(n) {
  let e, t, i = (
    /*value*/
    n[0] === null && pc(n)
  );
  return {
    c() {
      i && i.c(), e = wn();
    },
    l(r) {
      i && i.l(r), e = wn();
    },
    m(r, a) {
      i && i.m(r, a), Ze(r, e, a), t = !0;
    },
    p(r, a) {
      /*value*/
      r[0] === null ? i ? (i.p(r, a), a[0] & /*value*/
      1 && ve(i, 1)) : (i = pc(r), i.c(), ve(i, 1), i.m(e.parentNode, e)) : i && (nr(), Re(i, 1, 1, () => {
        i = null;
      }), tr());
    },
    i(r) {
      t || (ve(i), t = !0);
    },
    o(r) {
      Re(i), t = !1;
    },
    d(r) {
      r && re(e), i && i.d(r);
    }
  };
}
function mc(n) {
  let e, t, i, r, a;
  return t = new xo({
    props: {
      src: (
        /*value*/
        n[0].url
      ),
      alt: (
        /*value*/
        n[0].alt_text
      )
    }
  }), {
    c() {
      e = it("div"), Ln(t.$$.fragment), this.h();
    },
    l(s) {
      e = nt(s, "DIV", { class: !0 });
      var o = yt(e);
      On(t.$$.fragment, o), o.forEach(re), this.h();
    },
    h() {
      dt(e, "class", "image-frame svelte-3wfpo5"), cc(
        e,
        "selectable",
        /*selectable*/
        n[5]
      );
    },
    m(s, o) {
      Ze(s, e, o), Mn(t, e, null), i = !0, r || (a = ir(
        e,
        "click",
        /*handle_click*/
        n[25]
      ), r = !0);
    },
    p(s, o) {
      const l = {};
      o[0] & /*value*/
      1 && (l.src = /*value*/
      s[0].url), o[0] & /*value*/
      1 && (l.alt = /*value*/
      s[0].alt_text), t.$set(l), (!i || o[0] & /*selectable*/
      32) && cc(
        e,
        "selectable",
        /*selectable*/
        s[5]
      );
    },
    i(s) {
      i || (ve(t.$$.fragment, s), i = !0);
    },
    o(s) {
      Re(t.$$.fragment, s), i = !1;
    },
    d(s) {
      s && re(e), Rn(t), r = !1, a();
    }
  };
}
function gc(n) {
  let e, t, i, r = "X", a, s, o = "Image Metadata", l, c, u;
  function f(p, v) {
    return (
      /*filteredMetadata*/
      p[22].error ? h2 : f2
    );
  }
  let h = f(n), d = h(n);
  return {
    c() {
      e = it("div"), t = it("div"), i = it("button"), i.textContent = r, a = Lt(), s = it("h3"), s.textContent = o, l = Lt(), d.c(), this.h();
    },
    l(p) {
      e = nt(p, "DIV", { class: !0 });
      var v = yt(e);
      t = nt(v, "DIV", { class: !0 });
      var w = yt(t);
      i = nt(w, "BUTTON", { class: !0, "data-svelte-h": !0 }), co(i) !== "svelte-1irq3m4" && (i.textContent = r), a = Ot(w), s = nt(w, "H3", { class: !0, "data-svelte-h": !0 }), co(s) !== "svelte-1tc7pig" && (s.textContent = o), l = Ot(w), d.l(w), w.forEach(re), v.forEach(re), this.h();
    },
    h() {
      dt(i, "class", "close-button svelte-3wfpo5"), dt(s, "class", "popup-title svelte-3wfpo5"), dt(t, "class", "popup-content svelte-3wfpo5"), dt(e, "class", "metadata-popup svelte-3wfpo5"), qt(e, "width", typeof /*popup_metadata_width*/
      n[14] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        n[14],
        parseFloat(
          /*maxPopupWidth*/
          n[21]
        )
      )}px` : `min(${/*popup_metadata_width*/
      n[14]}, ${/*maxPopupWidth*/
      n[21]})`), qt(e, "height", typeof /*popup_metadata_height*/
      n[15] == "number" ? `${/*popup_metadata_height*/
      n[15]}px` : (
        /*popup_metadata_height*/
        n[15]
      ));
    },
    m(p, v) {
      Ze(p, e, v), Ue(e, t), Ue(t, i), Ue(t, a), Ue(t, s), Ue(t, l), d.m(t, null), c || (u = ir(
        i,
        "click",
        /*closePopup*/
        n[30]
      ), c = !0);
    },
    p(p, v) {
      h === (h = f(p)) && d ? d.p(p, v) : (d.d(1), d = h(p), d && (d.c(), d.m(t, null))), v[0] & /*popup_metadata_width, maxPopupWidth*/
      2113536 && qt(e, "width", typeof /*popup_metadata_width*/
      p[14] == "number" ? `${Math.min(
        /*popup_metadata_width*/
        p[14],
        parseFloat(
          /*maxPopupWidth*/
          p[21]
        )
      )}px` : `min(${/*popup_metadata_width*/
      p[14]}, ${/*maxPopupWidth*/
      p[21]})`), v[0] & /*popup_metadata_height*/
      32768 && qt(e, "height", typeof /*popup_metadata_height*/
      p[15] == "number" ? `${/*popup_metadata_height*/
      p[15]}px` : (
        /*popup_metadata_height*/
        p[15]
      ));
    },
    d(p) {
      p && re(e), d.d(), c = !1, u();
    }
  };
}
function f2(n) {
  let e, t, i, r, a, s = "Load Metadata", o, l, c = uc(Object.entries(
    /*filteredMetadata*/
    n[22]
  )), u = [];
  for (let f = 0; f < c.length; f += 1)
    u[f] = vc(fc(n, c, f));
  return {
    c() {
      e = it("div"), t = it("table"), i = it("tbody");
      for (let f = 0; f < u.length; f += 1)
        u[f].c();
      r = Lt(), a = it("button"), a.textContent = s, this.h();
    },
    l(f) {
      e = nt(f, "DIV", { class: !0 });
      var h = yt(e);
      t = nt(h, "TABLE", { class: !0 });
      var d = yt(t);
      i = nt(d, "TBODY", {});
      var p = yt(i);
      for (let v = 0; v < u.length; v += 1)
        u[v].l(p);
      p.forEach(re), d.forEach(re), h.forEach(re), r = Ot(f), a = nt(f, "BUTTON", { class: !0, "data-svelte-h": !0 }), co(a) !== "svelte-1uwkq18" && (a.textContent = s), this.h();
    },
    h() {
      dt(t, "class", "metadata-table svelte-3wfpo5"), dt(e, "class", "metadata-table-container svelte-3wfpo5"), dt(a, "class", "load-metadata-button svelte-3wfpo5");
    },
    m(f, h) {
      Ze(f, e, h), Ue(e, t), Ue(t, i);
      for (let d = 0; d < u.length; d += 1)
        u[d] && u[d].m(i, null);
      Ze(f, r, h), Ze(f, a, h), o || (l = ir(
        a,
        "click",
        /*dispatchLoadMetadata*/
        n[29]
      ), o = !0);
    },
    p(f, h) {
      if (h[0] & /*filteredMetadata*/
      4194304) {
        c = uc(Object.entries(
          /*filteredMetadata*/
          f[22]
        ));
        let d;
        for (d = 0; d < c.length; d += 1) {
          const p = fc(f, c, d);
          u[d] ? u[d].p(p, h) : (u[d] = vc(p), u[d].c(), u[d].m(i, null));
        }
        for (; d < u.length; d += 1)
          u[d].d(1);
        u.length = c.length;
      }
    },
    d(f) {
      f && (re(e), re(r), re(a)), e2(u, f), o = !1, l();
    }
  };
}
function h2(n) {
  let e, t = (
    /*filteredMetadata*/
    n[22].error + ""
  ), i;
  return {
    c() {
      e = it("p"), i = ho(t);
    },
    l(r) {
      e = nt(r, "P", {});
      var a = yt(e);
      i = uo(a, t), a.forEach(re);
    },
    m(r, a) {
      Ze(r, e, a), Ue(e, i);
    },
    p(r, a) {
      a[0] & /*filteredMetadata*/
      4194304 && t !== (t = /*filteredMetadata*/
      r[22].error + "") && fo(i, t);
    },
    d(r) {
      r && re(e);
    }
  };
}
function bc(n) {
  let e, t, i = (
    /*key*/
    n[47] + ""
  ), r, a, s, o = (
    /*val*/
    n[48] + ""
  ), l, c;
  return {
    c() {
      e = it("tr"), t = it("td"), r = ho(i), a = Lt(), s = it("td"), l = ho(o), c = Lt(), this.h();
    },
    l(u) {
      e = nt(u, "TR", {});
      var f = yt(e);
      t = nt(f, "TD", { class: !0 });
      var h = yt(t);
      r = uo(h, i), h.forEach(re), a = Ot(f), s = nt(f, "TD", { class: !0 });
      var d = yt(s);
      l = uo(d, o), d.forEach(re), c = Ot(f), f.forEach(re), this.h();
    },
    h() {
      dt(t, "class", "metadata-label svelte-3wfpo5"), dt(s, "class", "metadata-value svelte-3wfpo5");
    },
    m(u, f) {
      Ze(u, e, f), Ue(e, t), Ue(t, r), Ue(e, a), Ue(e, s), Ue(s, l), Ue(e, c);
    },
    p(u, f) {
      f[0] & /*filteredMetadata*/
      4194304 && i !== (i = /*key*/
      u[47] + "") && fo(r, i), f[0] & /*filteredMetadata*/
      4194304 && o !== (o = /*val*/
      u[48] + "") && fo(l, o);
    },
    d(u) {
      u && re(e);
    }
  };
}
function vc(n) {
  let e, t = (
    /*val*/
    n[48] && bc(n)
  );
  return {
    c() {
      t && t.c(), e = wn();
    },
    l(i) {
      t && t.l(i), e = wn();
    },
    m(i, r) {
      t && t.m(i, r), Ze(i, e, r);
    },
    p(i, r) {
      /*val*/
      i[48] ? t ? t.p(i, r) : (t = bc(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && re(e), t && t.d(i);
    }
  };
}
function d2(n) {
  let e, t, i, r, a, s, o, l, c, u, f, h, d, p, v;
  e = new gf({
    props: {
      show_label: (
        /*show_label*/
        n[4]
      ),
      Icon: Ao,
      label: (
        /*label*/
        n[3] || "Image"
      )
    }
  }), r = new kf({
    props: {
      $$slots: { default: [u2] },
      $$scope: { ctx: n }
    }
  });
  function w(b) {
    n[38](b);
  }
  function D(b) {
    n[39](b);
  }
  let m = {
    hidden: (
      /*value*/
      n[0] !== null
    ),
    filetype: "image/*",
    root: (
      /*root*/
      n[6]
    ),
    max_file_size: (
      /*max_file_size*/
      n[8]
    ),
    disable_click: (
      /*value*/
      n[0] !== null
    ),
    upload: (
      /*upload*/
      n[9]
    ),
    stream_handler: (
      /*stream_handler*/
      n[10]
    ),
    aria_label: (
      /*i18n*/
      n[7]("image.drop_to_upload")
    ),
    $$slots: { default: [c2] },
    $$scope: { ctx: n }
  };
  /*uploading*/
  n[2] !== void 0 && (m.uploading = /*uploading*/
  n[2]), /*dragging*/
  n[1] !== void 0 && (m.dragging = /*dragging*/
  n[1]), o = new Kb({ props: m }), n[37](o), ma.push(() => oc(o, "uploading", w)), ma.push(() => oc(o, "dragging", D)), o.$on(
    "load",
    /*handle_upload*/
    n[23]
  ), o.$on(
    "error",
    /*error_handler*/
    n[40]
  );
  let _ = (
    /*value*/
    n[0] !== null && mc(n)
  ), g = (
    /*showMetadataPopup*/
    n[19] && /*filteredMetadata*/
    n[22] !== null && gc(n)
  );
  return {
    c() {
      Ln(e.$$.fragment), t = Lt(), i = it("div"), Ln(r.$$.fragment), a = Lt(), s = it("div"), Ln(o.$$.fragment), u = Lt(), _ && _.c(), f = Lt(), g && g.c(), h = wn(), this.h();
    },
    l(b) {
      On(e.$$.fragment, b), t = Ot(b), i = nt(b, "DIV", { "data-testid": !0, class: !0 });
      var E = yt(i);
      On(r.$$.fragment, E), a = Ot(E), s = nt(E, "DIV", { class: !0 });
      var k = yt(s);
      On(o.$$.fragment, k), u = Ot(k), _ && _.l(k), k.forEach(re), E.forEach(re), f = Ot(b), g && g.l(b), h = wn(), this.h();
    },
    h() {
      dt(s, "class", "upload-container svelte-3wfpo5"), qt(
        s,
        "width",
        /*value*/
        n[0] ? "auto" : "100%"
      ), dt(i, "data-testid", "image"), dt(i, "class", "image-container svelte-3wfpo5"), qt(
        i,
        "height",
        /*height*/
        n[12]
      ), qt(
        i,
        "width",
        /*width*/
        n[13]
      );
    },
    m(b, E) {
      Mn(e, b, E), Ze(b, t, E), Ze(b, i, E), Mn(r, i, null), Ue(i, a), Ue(i, s), Mn(o, s, null), Ue(s, u), _ && _.m(s, null), n[41](i), Ze(b, f, E), g && g.m(b, E), Ze(b, h, E), d = !0, p || (v = [
        ir(
          s,
          "dragover",
          /*on_drag_over*/
          n[26]
        ),
        ir(
          s,
          "drop",
          /*on_drop*/
          n[27]
        )
      ], p = !0);
    },
    p(b, E) {
      const k = {};
      E[0] & /*show_label*/
      16 && (k.show_label = /*show_label*/
      b[4]), E[0] & /*label*/
      8 && (k.label = /*label*/
      b[3] || "Image"), e.$set(k);
      const P = {};
      E[0] & /*metadata, fullscreen, show_fullscreen_button, value*/
      198657 | E[1] & /*$$scope*/
      2048 && (P.$$scope = { dirty: E, ctx: b }), r.$set(P);
      const A = {};
      E[0] & /*value*/
      1 && (A.hidden = /*value*/
      b[0] !== null), E[0] & /*root*/
      64 && (A.root = /*root*/
      b[6]), E[0] & /*max_file_size*/
      256 && (A.max_file_size = /*max_file_size*/
      b[8]), E[0] & /*value*/
      1 && (A.disable_click = /*value*/
      b[0] !== null), E[0] & /*upload*/
      512 && (A.upload = /*upload*/
      b[9]), E[0] & /*stream_handler*/
      1024 && (A.stream_handler = /*stream_handler*/
      b[10]), E[0] & /*i18n*/
      128 && (A.aria_label = /*i18n*/
      b[7]("image.drop_to_upload")), E[0] & /*value*/
      1 | E[1] & /*$$scope*/
      2048 && (A.$$scope = { dirty: E, ctx: b }), !l && E[0] & /*uploading*/
      4 && (l = !0, A.uploading = /*uploading*/
      b[2], sc(() => l = !1)), !c && E[0] & /*dragging*/
      2 && (c = !0, A.dragging = /*dragging*/
      b[1], sc(() => c = !1)), o.$set(A), /*value*/
      b[0] !== null ? _ ? (_.p(b, E), E[0] & /*value*/
      1 && ve(_, 1)) : (_ = mc(b), _.c(), ve(_, 1), _.m(s, null)) : _ && (nr(), Re(_, 1, 1, () => {
        _ = null;
      }), tr()), E[0] & /*value*/
      1 && qt(
        s,
        "width",
        /*value*/
        b[0] ? "auto" : "100%"
      ), E[0] & /*height*/
      4096 && qt(
        i,
        "height",
        /*height*/
        b[12]
      ), E[0] & /*width*/
      8192 && qt(
        i,
        "width",
        /*width*/
        b[13]
      ), /*showMetadataPopup*/
      b[19] && /*filteredMetadata*/
      b[22] !== null ? g ? g.p(b, E) : (g = gc(b), g.c(), g.m(h.parentNode, h)) : g && (g.d(1), g = null);
    },
    i(b) {
      d || (ve(e.$$.fragment, b), ve(r.$$.fragment, b), ve(o.$$.fragment, b), ve(_), d = !0);
    },
    o(b) {
      Re(e.$$.fragment, b), Re(r.$$.fragment, b), Re(o.$$.fragment, b), Re(_), d = !1;
    },
    d(b) {
      b && (re(t), re(i), re(f), re(h)), Rn(e, b), Rn(r), n[37](null), Rn(o), _ && _.d(), n[41](null), g && g.d(b), p = !1, a2(v);
    }
  };
}
function _2(n, e, t) {
  let i, r, { $$slots: a = {}, $$scope: s } = e;
  var o = this && this.__awaiter || function(S, le, Pe, fe) {
    function Ae(Fe) {
      return Fe instanceof Pe ? Fe : new Pe(function(Me) {
        Me(Fe);
      });
    }
    return new (Pe || (Pe = Promise))(function(Fe, Me) {
      function Ct(be) {
        try {
          C(fe.next(be));
        } catch (Ht) {
          Me(Ht);
        }
      }
      function nn(be) {
        try {
          C(fe.throw(be));
        } catch (Ht) {
          Me(Ht);
        }
      }
      function C(be) {
        be.done ? Fe(be.value) : Ae(be.value).then(Ct, nn);
      }
      C((fe = fe.apply(S, le || [])).next());
    });
  };
  let { value: l = null } = e, { label: c = void 0 } = e, { show_label: u } = e, { selectable: f = !1 } = e, { root: h } = e, { i18n: d } = e, { max_file_size: p = null } = e, { upload: v } = e, { stream_handler: w } = e, { show_fullscreen_button: D = !0 } = e, { height: m = void 0 } = e, { width: _ = void 0 } = e, { only_custom_metadata: g = !0 } = e, { popup_metadata_width: b = 400 } = e, { popup_metadata_height: E = 300 } = e, k, { uploading: P = !1 } = e, { active_source: A = "upload" } = e, { fullscreen: R = !1 } = e, B = null, L = !1, de, { dragging: z = !1 } = e;
  const te = l2(), Q = [
    "ImageWidth",
    "ImageHeight",
    "BitDepth",
    "ColorType",
    "Compression",
    "Filter",
    "Interlace"
  ];
  function oe(S) {
    return o(this, void 0, void 0, function* () {
      if (!(S != null && S.url)) {
        t(17, B = null);
        return;
      }
      if (S.url.toLowerCase().endsWith(".svg"))
        t(17, B = null);
      else if (S.url.toLowerCase().endsWith(".png") || S.url.toLowerCase().endsWith(".jpg") || S.url.toLowerCase().endsWith(".jpeg"))
        try {
          const le = yield Vs(S.url, { exif: !0, iptc: !0, xmp: !0 });
          if (t(17, B = {}), le)
            for (const [Pe, fe] of Object.entries(le))
              (typeof fe == "string" || typeof fe == "number" || typeof fe == "boolean") && t(17, B[Pe] = fe, B);
        } catch {
          t(17, B = { error: "Failed to extract metadata" });
        }
      else
        t(17, B = { error: "Unsupported file type" });
    });
  }
  function X(S) {
    return o(this, arguments, void 0, function* ({ detail: le }) {
      var Pe, fe, Ae, Fe;
      let Me = null;
      if (!((Pe = le.path) === null || Pe === void 0) && Pe.toLowerCase().endsWith(".svg") && le.url) {
        const nn = yield (yield fetch(le.url)).text();
        t(0, l = Object.assign(Object.assign({}, le), {
          url: `data:image/svg+xml,${encodeURIComponent(nn)}`,
          metadata: null
        })), Me = null;
      } else if (le.url && (!((fe = le.path) === null || fe === void 0) && fe.toLowerCase().endsWith(".png") || !((Ae = le.path) === null || Ae === void 0) && Ae.toLowerCase().endsWith(".jpg") || !((Fe = le.path) === null || Fe === void 0) && Fe.toLowerCase().endsWith(".jpeg")))
        try {
          const Ct = yield Vs(le.url, { exif: !0, iptc: !0, xmp: !0 });
          if (Me = {}, Ct)
            for (const [nn, C] of Object.entries(Ct))
              (typeof C == "string" || typeof C == "number" || typeof C == "boolean") && (Me[nn] = C);
        } catch {
          Me = { error: "Failed to extract metadata" };
        }
      else
        Me = { error: "Unsupported file type" };
      t(0, l = Object.assign(Object.assign({}, le), { metadata: Me })), t(17, B = Me), yield Es(), te("upload"), te("change", l);
    });
  }
  function ne() {
    t(0, l = null), t(17, B = null), t(19, L = !1), te("clear"), te("change", null);
  }
  function De(S) {
    let le = xf(S);
    le && te("select", { index: le, value: null });
  }
  function F(S) {
    S.preventDefault(), S.stopPropagation(), S.dataTransfer && (S.dataTransfer.dropEffect = "copy"), t(1, z = !0);
  }
  function x(S) {
    return o(this, void 0, void 0, function* () {
      S.preventDefault(), S.stopPropagation(), t(1, z = !1), l && (ne(), yield Es()), t(31, A = "upload"), yield Es(), k.load_files_from_drop(S);
    });
  }
  function H() {
    B !== null && t(19, L = !L);
  }
  function J() {
    B !== null && (te("load_metadata"), T());
  }
  function T() {
    t(19, L = !1);
  }
  function ke(S) {
    lc.call(this, n, S);
  }
  const Se = (S) => {
    H(), S.stopPropagation();
  }, I = (S) => {
    ne(), S.stopPropagation();
  };
  function q(S) {
    ma[S ? "unshift" : "push"](() => {
      k = S, t(18, k);
    });
  }
  function j(S) {
    P = S, t(2, P);
  }
  function V(S) {
    z = S, t(1, z);
  }
  function ce(S) {
    lc.call(this, n, S);
  }
  function Ee(S) {
    ma[S ? "unshift" : "push"](() => {
      de = S, t(20, de);
    });
  }
  return n.$$set = (S) => {
    "value" in S && t(0, l = S.value), "label" in S && t(3, c = S.label), "show_label" in S && t(4, u = S.show_label), "selectable" in S && t(5, f = S.selectable), "root" in S && t(6, h = S.root), "i18n" in S && t(7, d = S.i18n), "max_file_size" in S && t(8, p = S.max_file_size), "upload" in S && t(9, v = S.upload), "stream_handler" in S && t(10, w = S.stream_handler), "show_fullscreen_button" in S && t(11, D = S.show_fullscreen_button), "height" in S && t(12, m = S.height), "width" in S && t(13, _ = S.width), "only_custom_metadata" in S && t(32, g = S.only_custom_metadata), "popup_metadata_width" in S && t(14, b = S.popup_metadata_width), "popup_metadata_height" in S && t(15, E = S.popup_metadata_height), "uploading" in S && t(2, P = S.uploading), "active_source" in S && t(31, A = S.active_source), "fullscreen" in S && t(16, R = S.fullscreen), "dragging" in S && t(1, z = S.dragging), "$$scope" in S && t(42, s = S.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*dragging*/
    2 && te("drag", z), n.$$.dirty[0] & /*value*/
    1 && (l ? l.metadata ? t(17, B = l.metadata) : oe(l) : t(17, B = null)), n.$$.dirty[0] & /*metadata*/
    131072 | n.$$.dirty[1] & /*only_custom_metadata*/
    2 && t(22, i = g ? Object.fromEntries(Object.entries(B || {}).filter(([S]) => !Q.includes(S))) : B), n.$$.dirty[0] & /*width*/
    8192 && t(21, r = typeof _ == "number" ? _ - 20 : typeof _ == "string" ? `calc(${_} - 20px)` : "380px");
  }, [
    l,
    z,
    P,
    c,
    u,
    f,
    h,
    d,
    p,
    v,
    w,
    D,
    m,
    _,
    b,
    E,
    R,
    B,
    k,
    L,
    de,
    r,
    i,
    X,
    ne,
    De,
    F,
    x,
    H,
    J,
    T,
    A,
    g,
    a,
    ke,
    Se,
    I,
    q,
    j,
    V,
    ce,
    Ee,
    s
  ];
}
class p2 extends Qb {
  constructor(e) {
    super(), i2(
      this,
      e,
      _2,
      d2,
      s2,
      {
        value: 0,
        label: 3,
        show_label: 4,
        selectable: 5,
        root: 6,
        i18n: 7,
        max_file_size: 8,
        upload: 9,
        stream_handler: 10,
        show_fullscreen_button: 11,
        height: 12,
        width: 13,
        only_custom_metadata: 32,
        popup_metadata_width: 14,
        popup_metadata_height: 15,
        uploading: 2,
        active_source: 31,
        fullscreen: 16,
        dragging: 1
      },
      null,
      [-1, -1]
    );
  }
}
function li(n) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; n > 1e3 && t < e.length - 1; )
    n /= 1e3, t++;
  let i = e[t];
  return (Number.isInteger(n) ? n : n.toFixed(1)) + i;
}
const {
  SvelteComponent: m2,
  append_hydration: Ft,
  attr: K,
  children: _t,
  claim_element: g2,
  claim_svg_element: Tt,
  component_subscribe: yc,
  detach: ft,
  element: b2,
  init: v2,
  insert_hydration: y2,
  noop: wc,
  safe_not_equal: w2,
  set_style: Lr,
  svg_element: It,
  toggle_class: Dc
} = window.__gradio__svelte__internal, { onMount: D2 } = window.__gradio__svelte__internal;
function E2(n) {
  let e, t, i, r, a, s, o, l, c, u, f, h;
  return {
    c() {
      e = b2("div"), t = It("svg"), i = It("g"), r = It("path"), a = It("path"), s = It("path"), o = It("path"), l = It("g"), c = It("path"), u = It("path"), f = It("path"), h = It("path"), this.h();
    },
    l(d) {
      e = g2(d, "DIV", { class: !0 });
      var p = _t(e);
      t = Tt(p, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var v = _t(t);
      i = Tt(v, "g", { style: !0 });
      var w = _t(i);
      r = Tt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(r).forEach(ft), a = Tt(w, "path", { d: !0, fill: !0, class: !0 }), _t(a).forEach(ft), s = Tt(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(s).forEach(ft), o = Tt(w, "path", { d: !0, fill: !0, class: !0 }), _t(o).forEach(ft), w.forEach(ft), l = Tt(v, "g", { style: !0 });
      var D = _t(l);
      c = Tt(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(c).forEach(ft), u = Tt(D, "path", { d: !0, fill: !0, class: !0 }), _t(u).forEach(ft), f = Tt(D, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), _t(f).forEach(ft), h = Tt(D, "path", { d: !0, fill: !0, class: !0 }), _t(h).forEach(ft), D.forEach(ft), v.forEach(ft), p.forEach(ft), this.h();
    },
    h() {
      K(r, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), K(r, "fill", "#FF7C00"), K(r, "fill-opacity", "0.4"), K(r, "class", "svelte-43sxxs"), K(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), K(a, "fill", "#FF7C00"), K(a, "class", "svelte-43sxxs"), K(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), K(s, "fill", "#FF7C00"), K(s, "fill-opacity", "0.4"), K(s, "class", "svelte-43sxxs"), K(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), K(o, "fill", "#FF7C00"), K(o, "class", "svelte-43sxxs"), Lr(i, "transform", "translate(" + /*$top*/
      n[1][0] + "px, " + /*$top*/
      n[1][1] + "px)"), K(c, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), K(c, "fill", "#FF7C00"), K(c, "fill-opacity", "0.4"), K(c, "class", "svelte-43sxxs"), K(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), K(u, "fill", "#FF7C00"), K(u, "class", "svelte-43sxxs"), K(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), K(f, "fill", "#FF7C00"), K(f, "fill-opacity", "0.4"), K(f, "class", "svelte-43sxxs"), K(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), K(h, "fill", "#FF7C00"), K(h, "class", "svelte-43sxxs"), Lr(l, "transform", "translate(" + /*$bottom*/
      n[2][0] + "px, " + /*$bottom*/
      n[2][1] + "px)"), K(t, "viewBox", "-1200 -1200 3000 3000"), K(t, "fill", "none"), K(t, "xmlns", "http://www.w3.org/2000/svg"), K(t, "class", "svelte-43sxxs"), K(e, "class", "svelte-43sxxs"), Dc(
        e,
        "margin",
        /*margin*/
        n[0]
      );
    },
    m(d, p) {
      y2(d, e, p), Ft(e, t), Ft(t, i), Ft(i, r), Ft(i, a), Ft(i, s), Ft(i, o), Ft(t, l), Ft(l, c), Ft(l, u), Ft(l, f), Ft(l, h);
    },
    p(d, [p]) {
      p & /*$top*/
      2 && Lr(i, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), p & /*$bottom*/
      4 && Lr(l, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), p & /*margin*/
      1 && Dc(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: wc,
    o: wc,
    d(d) {
      d && ft(e);
    }
  };
}
function C2(n, e, t) {
  let i, r;
  var a = this && this.__awaiter || function(d, p, v, w) {
    function D(m) {
      return m instanceof v ? m : new v(function(_) {
        _(m);
      });
    }
    return new (v || (v = Promise))(function(m, _) {
      function g(k) {
        try {
          E(w.next(k));
        } catch (P) {
          _(P);
        }
      }
      function b(k) {
        try {
          E(w.throw(k));
        } catch (P) {
          _(P);
        }
      }
      function E(k) {
        k.done ? m(k.value) : D(k.value).then(g, b);
      }
      E((w = w.apply(d, p || [])).next());
    });
  };
  let { margin: s = !0 } = e;
  const o = Hu([0, 0]);
  yc(n, o, (d) => t(1, i = d));
  const l = Hu([0, 0]);
  yc(n, l, (d) => t(2, r = d));
  let c;
  function u() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), l.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), l.set([125, -140])]), yield Promise.all([o.set([-125, 0]), l.set([125, -0])]), yield Promise.all([o.set([125, 0]), l.set([-125, 0])]);
    });
  }
  function f() {
    return a(this, void 0, void 0, function* () {
      yield u(), c || f();
    });
  }
  function h() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), l.set([-125, 0])]), f();
    });
  }
  return D2(() => (h(), () => c = !0)), n.$$set = (d) => {
    "margin" in d && t(0, s = d.margin);
  }, [s, i, r, o, l];
}
class k2 extends m2 {
  constructor(e) {
    super(), v2(this, e, C2, E2, w2, { margin: 0 });
  }
}
const {
  SvelteComponent: S2,
  append_hydration: $n,
  attr: Rt,
  binding_callbacks: Ec,
  check_outros: _o,
  children: Xt,
  claim_component: Lh,
  claim_element: Zt,
  claim_space: gt,
  claim_text: ye,
  create_component: Rh,
  create_slot: Mh,
  destroy_component: Nh,
  destroy_each: Uh,
  detach: N,
  element: Yt,
  empty: wt,
  ensure_array_like: ga,
  get_all_dirty_from_scope: Hh,
  get_slot_changes: Gh,
  group_outros: po,
  init: A2,
  insert_hydration: G,
  mount_component: zh,
  noop: mo,
  safe_not_equal: F2,
  set_data: Dt,
  set_style: vn,
  space: bt,
  text: we,
  toggle_class: pt,
  transition_in: Pt,
  transition_out: Kt,
  update_slot_base: qh
} = window.__gradio__svelte__internal, { tick: T2 } = window.__gradio__svelte__internal, { onDestroy: I2 } = window.__gradio__svelte__internal, { createEventDispatcher: $2 } = window.__gradio__svelte__internal, x2 = (n) => ({}), Cc = (n) => ({}), P2 = (n) => ({}), kc = (n) => ({});
function Sc(n, e, t) {
  const i = n.slice();
  return i[40] = e[t], i[42] = t, i;
}
function Ac(n, e, t) {
  const i = n.slice();
  return i[40] = e[t], i;
}
function B2(n) {
  let e, t, i, r, a = (
    /*i18n*/
    n[1]("common.error") + ""
  ), s, o, l;
  t = new Dn({
    props: {
      Icon: vf,
      label: (
        /*i18n*/
        n[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    n[32]
  );
  const c = (
    /*#slots*/
    n[30].error
  ), u = Mh(
    c,
    n,
    /*$$scope*/
    n[29],
    Cc
  );
  return {
    c() {
      e = Yt("div"), Rh(t.$$.fragment), i = bt(), r = Yt("span"), s = we(a), o = bt(), u && u.c(), this.h();
    },
    l(f) {
      e = Zt(f, "DIV", { class: !0 });
      var h = Xt(e);
      Lh(t.$$.fragment, h), h.forEach(N), i = gt(f), r = Zt(f, "SPAN", { class: !0 });
      var d = Xt(r);
      s = ye(d, a), d.forEach(N), o = gt(f), u && u.l(f), this.h();
    },
    h() {
      Rt(e, "class", "clear-status svelte-17v219f"), Rt(r, "class", "error svelte-17v219f");
    },
    m(f, h) {
      G(f, e, h), zh(t, e, null), G(f, i, h), G(f, r, h), $n(r, s), G(f, o, h), u && u.m(f, h), l = !0;
    },
    p(f, h) {
      const d = {};
      h[0] & /*i18n*/
      2 && (d.label = /*i18n*/
      f[1]("common.clear")), t.$set(d), (!l || h[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      f[1]("common.error") + "") && Dt(s, a), u && u.p && (!l || h[0] & /*$$scope*/
      536870912) && qh(
        u,
        c,
        f,
        /*$$scope*/
        f[29],
        l ? Gh(
          c,
          /*$$scope*/
          f[29],
          h,
          x2
        ) : Hh(
          /*$$scope*/
          f[29]
        ),
        Cc
      );
    },
    i(f) {
      l || (Pt(t.$$.fragment, f), Pt(u, f), l = !0);
    },
    o(f) {
      Kt(t.$$.fragment, f), Kt(u, f), l = !1;
    },
    d(f) {
      f && (N(e), N(i), N(r), N(o)), Nh(t), u && u.d(f);
    }
  };
}
function O2(n) {
  let e, t, i, r, a, s, o, l, c, u = (
    /*variant*/
    n[8] === "default" && /*show_eta_bar*/
    n[18] && /*show_progress*/
    n[6] === "full" && Fc(n)
  );
  function f(_, g) {
    if (
      /*progress*/
      _[7]
    ) return M2;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return R2;
    if (
      /*queue_position*/
      _[2] === 0
    ) return L2;
  }
  let h = f(n), d = h && h(n), p = (
    /*timer*/
    n[5] && $c(n)
  );
  const v = [G2, H2], w = [];
  function D(_, g) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = D(n)) && (s = w[a] = v[a](n));
  let m = !/*timer*/
  n[5] && Mc(n);
  return {
    c() {
      u && u.c(), e = bt(), t = Yt("div"), d && d.c(), i = bt(), p && p.c(), r = bt(), s && s.c(), o = bt(), m && m.c(), l = wt(), this.h();
    },
    l(_) {
      u && u.l(_), e = gt(_), t = Zt(_, "DIV", { class: !0 });
      var g = Xt(t);
      d && d.l(g), i = gt(g), p && p.l(g), g.forEach(N), r = gt(_), s && s.l(_), o = gt(_), m && m.l(_), l = wt(), this.h();
    },
    h() {
      Rt(t, "class", "progress-text svelte-17v219f"), pt(
        t,
        "meta-text-center",
        /*variant*/
        n[8] === "center"
      ), pt(
        t,
        "meta-text",
        /*variant*/
        n[8] === "default"
      );
    },
    m(_, g) {
      u && u.m(_, g), G(_, e, g), G(_, t, g), d && d.m(t, null), $n(t, i), p && p.m(t, null), G(_, r, g), ~a && w[a].m(_, g), G(_, o, g), m && m.m(_, g), G(_, l, g), c = !0;
    },
    p(_, g) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? u ? u.p(_, g) : (u = Fc(_), u.c(), u.m(e.parentNode, e)) : u && (u.d(1), u = null), h === (h = f(_)) && d ? d.p(_, g) : (d && d.d(1), d = h && h(_), d && (d.c(), d.m(t, i))), /*timer*/
      _[5] ? p ? p.p(_, g) : (p = $c(_), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!c || g[0] & /*variant*/
      256) && pt(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!c || g[0] & /*variant*/
      256) && pt(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let b = a;
      a = D(_), a === b ? ~a && w[a].p(_, g) : (s && (po(), Kt(w[b], 1, 1, () => {
        w[b] = null;
      }), _o()), ~a ? (s = w[a], s ? s.p(_, g) : (s = w[a] = v[a](_), s.c()), Pt(s, 1), s.m(o.parentNode, o)) : s = null), /*timer*/
      _[5] ? m && (po(), Kt(m, 1, 1, () => {
        m = null;
      }), _o()) : m ? (m.p(_, g), g[0] & /*timer*/
      32 && Pt(m, 1)) : (m = Mc(_), m.c(), Pt(m, 1), m.m(l.parentNode, l));
    },
    i(_) {
      c || (Pt(s), Pt(m), c = !0);
    },
    o(_) {
      Kt(s), Kt(m), c = !1;
    },
    d(_) {
      _ && (N(e), N(t), N(r), N(o), N(l)), u && u.d(_), d && d.d(), p && p.d(), ~a && w[a].d(_), m && m.d(_);
    }
  };
}
function Fc(n) {
  let e, t = `translateX(${/*eta_level*/
  (n[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Yt("div"), this.h();
    },
    l(i) {
      e = Zt(i, "DIV", { class: !0 }), Xt(e).forEach(N), this.h();
    },
    h() {
      Rt(e, "class", "eta-bar svelte-17v219f"), vn(e, "transform", t);
    },
    m(i, r) {
      G(i, e, r);
    },
    p(i, r) {
      r[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && vn(e, "transform", t);
    },
    d(i) {
      i && N(e);
    }
  };
}
function L2(n) {
  let e;
  return {
    c() {
      e = we("processing |");
    },
    l(t) {
      e = ye(t, "processing |");
    },
    m(t, i) {
      G(t, e, i);
    },
    p: mo,
    d(t) {
      t && N(e);
    }
  };
}
function R2(n) {
  let e, t = (
    /*queue_position*/
    n[2] + 1 + ""
  ), i, r, a, s;
  return {
    c() {
      e = we("queue: "), i = we(t), r = we("/"), a = we(
        /*queue_size*/
        n[3]
      ), s = we(" |");
    },
    l(o) {
      e = ye(o, "queue: "), i = ye(o, t), r = ye(o, "/"), a = ye(
        o,
        /*queue_size*/
        n[3]
      ), s = ye(o, " |");
    },
    m(o, l) {
      G(o, e, l), G(o, i, l), G(o, r, l), G(o, a, l), G(o, s, l);
    },
    p(o, l) {
      l[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && Dt(i, t), l[0] & /*queue_size*/
      8 && Dt(
        a,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (N(e), N(i), N(r), N(a), N(s));
    }
  };
}
function M2(n) {
  let e, t = ga(
    /*progress*/
    n[7]
  ), i = [];
  for (let r = 0; r < t.length; r += 1)
    i[r] = Ic(Ac(n, t, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = wt();
    },
    l(r) {
      for (let a = 0; a < i.length; a += 1)
        i[a].l(r);
      e = wt();
    },
    m(r, a) {
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(r, a);
      G(r, e, a);
    },
    p(r, a) {
      if (a[0] & /*progress*/
      128) {
        t = ga(
          /*progress*/
          r[7]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const o = Ac(r, t, s);
          i[s] ? i[s].p(o, a) : (i[s] = Ic(o), i[s].c(), i[s].m(e.parentNode, e));
        }
        for (; s < i.length; s += 1)
          i[s].d(1);
        i.length = t.length;
      }
    },
    d(r) {
      r && N(e), Uh(i, r);
    }
  };
}
function Tc(n) {
  let e, t = (
    /*p*/
    n[40].unit + ""
  ), i, r, a = " ", s;
  function o(u, f) {
    return (
      /*p*/
      u[40].length != null ? U2 : N2
    );
  }
  let l = o(n), c = l(n);
  return {
    c() {
      c.c(), e = bt(), i = we(t), r = we(" | "), s = we(a);
    },
    l(u) {
      c.l(u), e = gt(u), i = ye(u, t), r = ye(u, " | "), s = ye(u, a);
    },
    m(u, f) {
      c.m(u, f), G(u, e, f), G(u, i, f), G(u, r, f), G(u, s, f);
    },
    p(u, f) {
      l === (l = o(u)) && c ? c.p(u, f) : (c.d(1), c = l(u), c && (c.c(), c.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      u[40].unit + "") && Dt(i, t);
    },
    d(u) {
      u && (N(e), N(i), N(r), N(s)), c.d(u);
    }
  };
}
function N2(n) {
  let e = li(
    /*p*/
    n[40].index || 0
  ) + "", t;
  return {
    c() {
      t = we(e);
    },
    l(i) {
      t = ye(i, e);
    },
    m(i, r) {
      G(i, t, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = li(
        /*p*/
        i[40].index || 0
      ) + "") && Dt(t, e);
    },
    d(i) {
      i && N(t);
    }
  };
}
function U2(n) {
  let e = li(
    /*p*/
    n[40].index || 0
  ) + "", t, i, r = li(
    /*p*/
    n[40].length
  ) + "", a;
  return {
    c() {
      t = we(e), i = we("/"), a = we(r);
    },
    l(s) {
      t = ye(s, e), i = ye(s, "/"), a = ye(s, r);
    },
    m(s, o) {
      G(s, t, o), G(s, i, o), G(s, a, o);
    },
    p(s, o) {
      o[0] & /*progress*/
      128 && e !== (e = li(
        /*p*/
        s[40].index || 0
      ) + "") && Dt(t, e), o[0] & /*progress*/
      128 && r !== (r = li(
        /*p*/
        s[40].length
      ) + "") && Dt(a, r);
    },
    d(s) {
      s && (N(t), N(i), N(a));
    }
  };
}
function Ic(n) {
  let e, t = (
    /*p*/
    n[40].index != null && Tc(n)
  );
  return {
    c() {
      t && t.c(), e = wt();
    },
    l(i) {
      t && t.l(i), e = wt();
    },
    m(i, r) {
      t && t.m(i, r), G(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].index != null ? t ? t.p(i, r) : (t = Tc(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && N(e), t && t.d(i);
    }
  };
}
function $c(n) {
  let e, t = (
    /*eta*/
    n[0] ? `/${/*formatted_eta*/
    n[19]}` : ""
  ), i, r;
  return {
    c() {
      e = we(
        /*formatted_timer*/
        n[20]
      ), i = we(t), r = we("s");
    },
    l(a) {
      e = ye(
        a,
        /*formatted_timer*/
        n[20]
      ), i = ye(a, t), r = ye(a, "s");
    },
    m(a, s) {
      G(a, e, s), G(a, i, s), G(a, r, s);
    },
    p(a, s) {
      s[0] & /*formatted_timer*/
      1048576 && Dt(
        e,
        /*formatted_timer*/
        a[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && Dt(i, t);
    },
    d(a) {
      a && (N(e), N(i), N(r));
    }
  };
}
function H2(n) {
  let e, t;
  return e = new k2({
    props: { margin: (
      /*variant*/
      n[8] === "default"
    ) }
  }), {
    c() {
      Rh(e.$$.fragment);
    },
    l(i) {
      Lh(e.$$.fragment, i);
    },
    m(i, r) {
      zh(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*variant*/
      256 && (a.margin = /*variant*/
      i[8] === "default"), e.$set(a);
    },
    i(i) {
      t || (Pt(e.$$.fragment, i), t = !0);
    },
    o(i) {
      Kt(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Nh(e, i);
    }
  };
}
function G2(n) {
  let e, t, i, r, a, s = `${/*last_progress_level*/
  n[15] * 100}%`, o = (
    /*progress*/
    n[7] != null && xc(n)
  );
  return {
    c() {
      e = Yt("div"), t = Yt("div"), o && o.c(), i = bt(), r = Yt("div"), a = Yt("div"), this.h();
    },
    l(l) {
      e = Zt(l, "DIV", { class: !0 });
      var c = Xt(e);
      t = Zt(c, "DIV", { class: !0 });
      var u = Xt(t);
      o && o.l(u), u.forEach(N), i = gt(c), r = Zt(c, "DIV", { class: !0 });
      var f = Xt(r);
      a = Zt(f, "DIV", { class: !0 }), Xt(a).forEach(N), f.forEach(N), c.forEach(N), this.h();
    },
    h() {
      Rt(t, "class", "progress-level-inner svelte-17v219f"), Rt(a, "class", "progress-bar svelte-17v219f"), vn(a, "width", s), Rt(r, "class", "progress-bar-wrap svelte-17v219f"), Rt(e, "class", "progress-level svelte-17v219f");
    },
    m(l, c) {
      G(l, e, c), $n(e, t), o && o.m(t, null), $n(e, i), $n(e, r), $n(r, a), n[31](a);
    },
    p(l, c) {
      /*progress*/
      l[7] != null ? o ? o.p(l, c) : (o = xc(l), o.c(), o.m(t, null)) : o && (o.d(1), o = null), c[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      l[15] * 100}%`) && vn(a, "width", s);
    },
    i: mo,
    o: mo,
    d(l) {
      l && N(e), o && o.d(), n[31](null);
    }
  };
}
function xc(n) {
  let e, t = ga(
    /*progress*/
    n[7]
  ), i = [];
  for (let r = 0; r < t.length; r += 1)
    i[r] = Rc(Sc(n, t, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = wt();
    },
    l(r) {
      for (let a = 0; a < i.length; a += 1)
        i[a].l(r);
      e = wt();
    },
    m(r, a) {
      for (let s = 0; s < i.length; s += 1)
        i[s] && i[s].m(r, a);
      G(r, e, a);
    },
    p(r, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = ga(
          /*progress*/
          r[7]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const o = Sc(r, t, s);
          i[s] ? i[s].p(o, a) : (i[s] = Rc(o), i[s].c(), i[s].m(e.parentNode, e));
        }
        for (; s < i.length; s += 1)
          i[s].d(1);
        i.length = t.length;
      }
    },
    d(r) {
      r && N(e), Uh(i, r);
    }
  };
}
function Pc(n) {
  let e, t, i, r, a = (
    /*i*/
    n[42] !== 0 && z2()
  ), s = (
    /*p*/
    n[40].desc != null && Bc(n)
  ), o = (
    /*p*/
    n[40].desc != null && /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null && Oc()
  ), l = (
    /*progress_level*/
    n[14] != null && Lc(n)
  );
  return {
    c() {
      a && a.c(), e = bt(), s && s.c(), t = bt(), o && o.c(), i = bt(), l && l.c(), r = wt();
    },
    l(c) {
      a && a.l(c), e = gt(c), s && s.l(c), t = gt(c), o && o.l(c), i = gt(c), l && l.l(c), r = wt();
    },
    m(c, u) {
      a && a.m(c, u), G(c, e, u), s && s.m(c, u), G(c, t, u), o && o.m(c, u), G(c, i, u), l && l.m(c, u), G(c, r, u);
    },
    p(c, u) {
      /*p*/
      c[40].desc != null ? s ? s.p(c, u) : (s = Bc(c), s.c(), s.m(t.parentNode, t)) : s && (s.d(1), s = null), /*p*/
      c[40].desc != null && /*progress_level*/
      c[14] && /*progress_level*/
      c[14][
        /*i*/
        c[42]
      ] != null ? o || (o = Oc(), o.c(), o.m(i.parentNode, i)) : o && (o.d(1), o = null), /*progress_level*/
      c[14] != null ? l ? l.p(c, u) : (l = Lc(c), l.c(), l.m(r.parentNode, r)) : l && (l.d(1), l = null);
    },
    d(c) {
      c && (N(e), N(t), N(i), N(r)), a && a.d(c), s && s.d(c), o && o.d(c), l && l.d(c);
    }
  };
}
function z2(n) {
  let e;
  return {
    c() {
      e = we(" /");
    },
    l(t) {
      e = ye(t, " /");
    },
    m(t, i) {
      G(t, e, i);
    },
    d(t) {
      t && N(e);
    }
  };
}
function Bc(n) {
  let e = (
    /*p*/
    n[40].desc + ""
  ), t;
  return {
    c() {
      t = we(e);
    },
    l(i) {
      t = ye(i, e);
    },
    m(i, r) {
      G(i, t, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = /*p*/
      i[40].desc + "") && Dt(t, e);
    },
    d(i) {
      i && N(t);
    }
  };
}
function Oc(n) {
  let e;
  return {
    c() {
      e = we("-");
    },
    l(t) {
      e = ye(t, "-");
    },
    m(t, i) {
      G(t, e, i);
    },
    d(t) {
      t && N(e);
    }
  };
}
function Lc(n) {
  let e = (100 * /*progress_level*/
  (n[14][
    /*i*/
    n[42]
  ] || 0)).toFixed(1) + "", t, i;
  return {
    c() {
      t = we(e), i = we("%");
    },
    l(r) {
      t = ye(r, e), i = ye(r, "%");
    },
    m(r, a) {
      G(r, t, a), G(r, i, a);
    },
    p(r, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (r[14][
        /*i*/
        r[42]
      ] || 0)).toFixed(1) + "") && Dt(t, e);
    },
    d(r) {
      r && (N(t), N(i));
    }
  };
}
function Rc(n) {
  let e, t = (
    /*p*/
    (n[40].desc != null || /*progress_level*/
    n[14] && /*progress_level*/
    n[14][
      /*i*/
      n[42]
    ] != null) && Pc(n)
  );
  return {
    c() {
      t && t.c(), e = wt();
    },
    l(i) {
      t && t.l(i), e = wt();
    },
    m(i, r) {
      t && t.m(i, r), G(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[42]
      ] != null ? t ? t.p(i, r) : (t = Pc(i), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(i) {
      i && N(e), t && t.d(i);
    }
  };
}
function Mc(n) {
  let e, t, i, r;
  const a = (
    /*#slots*/
    n[30]["additional-loading-text"]
  ), s = Mh(
    a,
    n,
    /*$$scope*/
    n[29],
    kc
  );
  return {
    c() {
      e = Yt("p"), t = we(
        /*loading_text*/
        n[9]
      ), i = bt(), s && s.c(), this.h();
    },
    l(o) {
      e = Zt(o, "P", { class: !0 });
      var l = Xt(e);
      t = ye(
        l,
        /*loading_text*/
        n[9]
      ), l.forEach(N), i = gt(o), s && s.l(o), this.h();
    },
    h() {
      Rt(e, "class", "loading svelte-17v219f");
    },
    m(o, l) {
      G(o, e, l), $n(e, t), G(o, i, l), s && s.m(o, l), r = !0;
    },
    p(o, l) {
      (!r || l[0] & /*loading_text*/
      512) && Dt(
        t,
        /*loading_text*/
        o[9]
      ), s && s.p && (!r || l[0] & /*$$scope*/
      536870912) && qh(
        s,
        a,
        o,
        /*$$scope*/
        o[29],
        r ? Gh(
          a,
          /*$$scope*/
          o[29],
          l,
          P2
        ) : Hh(
          /*$$scope*/
          o[29]
        ),
        kc
      );
    },
    i(o) {
      r || (Pt(s, o), r = !0);
    },
    o(o) {
      Kt(s, o), r = !1;
    },
    d(o) {
      o && (N(e), N(i)), s && s.d(o);
    }
  };
}
function q2(n) {
  let e, t, i, r, a;
  const s = [O2, B2], o = [];
  function l(c, u) {
    return (
      /*status*/
      c[4] === "pending" ? 0 : (
        /*status*/
        c[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = l(n)) && (i = o[t] = s[t](n)), {
    c() {
      e = Yt("div"), i && i.c(), this.h();
    },
    l(c) {
      e = Zt(c, "DIV", { class: !0 });
      var u = Xt(e);
      i && i.l(u), u.forEach(N), this.h();
    },
    h() {
      Rt(e, "class", r = "wrap " + /*variant*/
      n[8] + " " + /*show_progress*/
      n[6] + " svelte-17v219f"), pt(e, "hide", !/*status*/
      n[4] || /*status*/
      n[4] === "complete" || /*show_progress*/
      n[6] === "hidden" || /*status*/
      n[4] == "streaming"), pt(
        e,
        "translucent",
        /*variant*/
        n[8] === "center" && /*status*/
        (n[4] === "pending" || /*status*/
        n[4] === "error") || /*translucent*/
        n[11] || /*show_progress*/
        n[6] === "minimal"
      ), pt(
        e,
        "generating",
        /*status*/
        n[4] === "generating" && /*show_progress*/
        n[6] === "full"
      ), pt(
        e,
        "border",
        /*border*/
        n[12]
      ), vn(
        e,
        "position",
        /*absolute*/
        n[10] ? "absolute" : "static"
      ), vn(
        e,
        "padding",
        /*absolute*/
        n[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(c, u) {
      G(c, e, u), ~t && o[t].m(e, null), n[33](e), a = !0;
    },
    p(c, u) {
      let f = t;
      t = l(c), t === f ? ~t && o[t].p(c, u) : (i && (po(), Kt(o[f], 1, 1, () => {
        o[f] = null;
      }), _o()), ~t ? (i = o[t], i ? i.p(c, u) : (i = o[t] = s[t](c), i.c()), Pt(i, 1), i.m(e, null)) : i = null), (!a || u[0] & /*variant, show_progress*/
      320 && r !== (r = "wrap " + /*variant*/
      c[8] + " " + /*show_progress*/
      c[6] + " svelte-17v219f")) && Rt(e, "class", r), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && pt(e, "hide", !/*status*/
      c[4] || /*status*/
      c[4] === "complete" || /*show_progress*/
      c[6] === "hidden" || /*status*/
      c[4] == "streaming"), (!a || u[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && pt(
        e,
        "translucent",
        /*variant*/
        c[8] === "center" && /*status*/
        (c[4] === "pending" || /*status*/
        c[4] === "error") || /*translucent*/
        c[11] || /*show_progress*/
        c[6] === "minimal"
      ), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && pt(
        e,
        "generating",
        /*status*/
        c[4] === "generating" && /*show_progress*/
        c[6] === "full"
      ), (!a || u[0] & /*variant, show_progress, border*/
      4416) && pt(
        e,
        "border",
        /*border*/
        c[12]
      ), u[0] & /*absolute*/
      1024 && vn(
        e,
        "position",
        /*absolute*/
        c[10] ? "absolute" : "static"
      ), u[0] & /*absolute*/
      1024 && vn(
        e,
        "padding",
        /*absolute*/
        c[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(c) {
      a || (Pt(i), a = !0);
    },
    o(c) {
      Kt(i), a = !1;
    },
    d(c) {
      c && N(e), ~t && o[t].d(), n[33](null);
    }
  };
}
var j2 = function(n, e, t, i) {
  function r(a) {
    return a instanceof t ? a : new t(function(s) {
      s(a);
    });
  }
  return new (t || (t = Promise))(function(a, s) {
    function o(u) {
      try {
        c(i.next(u));
      } catch (f) {
        s(f);
      }
    }
    function l(u) {
      try {
        c(i.throw(u));
      } catch (f) {
        s(f);
      }
    }
    function c(u) {
      u.done ? a(u.value) : r(u.value).then(o, l);
    }
    c((i = i.apply(n, e || [])).next());
  });
};
let Rr = [], Cs = !1;
const V2 = typeof window < "u", jh = V2 ? window.requestAnimationFrame : (n) => {
};
function W2(n) {
  return j2(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Rr.push(e), !Cs) Cs = !0;
      else return;
      yield T2(), jh(() => {
        let i = [0, 0];
        for (let r = 0; r < Rr.length; r++) {
          const s = Rr[r].getBoundingClientRect();
          (r === 0 || s.top + window.scrollY <= i[0]) && (i[0] = s.top + window.scrollY, i[1] = r);
        }
        window.scrollTo({ top: i[0] - 20, behavior: "smooth" }), Cs = !1, Rr = [];
      });
    }
  });
}
function X2(n, e, t) {
  let i, { $$slots: r = {}, $$scope: a } = e;
  const s = $2();
  let { i18n: o } = e, { eta: l = null } = e, { queue_position: c } = e, { queue_size: u } = e, { status: f } = e, { scroll_to_output: h = !1 } = e, { timer: d = !0 } = e, { show_progress: p = "full" } = e, { message: v = null } = e, { progress: w = null } = e, { variant: D = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: g = !1 } = e, { border: b = !1 } = e, { autoscroll: E } = e, k, P = !1, A = 0, R = 0, B = null, L = null, de = 0, z = null, te, Q = null, oe = !0;
  const X = () => {
    t(0, l = t(27, B = t(19, F = null))), t(25, A = performance.now()), t(26, R = 0), P = !0, ne();
  };
  function ne() {
    jh(() => {
      t(26, R = (performance.now() - A) / 1e3), P && ne();
    });
  }
  function De() {
    t(26, R = 0), t(0, l = t(27, B = t(19, F = null))), P && (P = !1);
  }
  I2(() => {
    P && De();
  });
  let F = null;
  function x(T) {
    Ec[T ? "unshift" : "push"](() => {
      Q = T, t(16, Q), t(7, w), t(14, z), t(15, te);
    });
  }
  const H = () => {
    s("clear_status");
  };
  function J(T) {
    Ec[T ? "unshift" : "push"](() => {
      k = T, t(13, k);
    });
  }
  return n.$$set = (T) => {
    "i18n" in T && t(1, o = T.i18n), "eta" in T && t(0, l = T.eta), "queue_position" in T && t(2, c = T.queue_position), "queue_size" in T && t(3, u = T.queue_size), "status" in T && t(4, f = T.status), "scroll_to_output" in T && t(22, h = T.scroll_to_output), "timer" in T && t(5, d = T.timer), "show_progress" in T && t(6, p = T.show_progress), "message" in T && t(23, v = T.message), "progress" in T && t(7, w = T.progress), "variant" in T && t(8, D = T.variant), "loading_text" in T && t(9, m = T.loading_text), "absolute" in T && t(10, _ = T.absolute), "translucent" in T && t(11, g = T.translucent), "border" in T && t(12, b = T.border), "autoscroll" in T && t(24, E = T.autoscroll), "$$scope" in T && t(29, a = T.$$scope);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (l === null && t(0, l = B), l != null && B !== l && (t(28, L = (performance.now() - A) / 1e3 + l), t(19, F = L.toFixed(1)), t(27, B = l))), n.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, de = L === null || L <= 0 || !R ? null : Math.min(R / L, 1)), n.$$.dirty[0] & /*progress*/
    128 && w != null && t(18, oe = !1), n.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (w != null ? t(14, z = w.map((T) => {
      if (T.index != null && T.length != null)
        return T.index / T.length;
      if (T.progress != null)
        return T.progress;
    })) : t(14, z = null), z ? (t(15, te = z[z.length - 1]), Q && (te === 0 ? t(16, Q.style.transition = "0", Q) : t(16, Q.style.transition = "150ms", Q))) : t(15, te = void 0)), n.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? X() : De()), n.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && k && h && (f === "pending" || f === "complete") && W2(k, E), n.$$.dirty[0] & /*status, message*/
    8388624, n.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, i = R.toFixed(1));
  }, [
    l,
    o,
    c,
    u,
    f,
    d,
    p,
    w,
    D,
    m,
    _,
    g,
    b,
    k,
    z,
    te,
    Q,
    de,
    oe,
    F,
    i,
    s,
    h,
    v,
    E,
    A,
    R,
    B,
    L,
    a,
    r,
    x,
    H,
    J
  ];
}
class Vh extends S2 {
  constructor(e) {
    super(), A2(
      this,
      e,
      X2,
      q2,
      F2,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Wh,
  setPrototypeOf: Nc,
  isFrozen: Z2,
  getPrototypeOf: Y2,
  getOwnPropertyDescriptor: K2
} = Object;
let {
  freeze: rt,
  seal: Et,
  create: Xh
} = Object, {
  apply: go,
  construct: bo
} = typeof Reflect < "u" && Reflect;
rt || (rt = function(e) {
  return e;
});
Et || (Et = function(e) {
  return e;
});
go || (go = function(e, t, i) {
  return e.apply(t, i);
});
bo || (bo = function(e, t) {
  return new e(...t);
});
const Mr = at(Array.prototype.forEach), Q2 = at(Array.prototype.lastIndexOf), Uc = at(Array.prototype.pop), Pi = at(Array.prototype.push), J2 = at(Array.prototype.splice), Vr = at(String.prototype.toLowerCase), ks = at(String.prototype.toString), Hc = at(String.prototype.match), Bi = at(String.prototype.replace), ev = at(String.prototype.indexOf), tv = at(String.prototype.trim), $t = at(Object.prototype.hasOwnProperty), Ye = at(RegExp.prototype.test), Oi = nv(TypeError);
function at(n) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++)
      i[r - 1] = arguments[r];
    return go(n, e, i);
  };
}
function nv(n) {
  return function() {
    for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
      t[i] = arguments[i];
    return bo(n, t);
  };
}
function W(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Vr;
  Nc && Nc(n, null);
  let i = e.length;
  for (; i--; ) {
    let r = e[i];
    if (typeof r == "string") {
      const a = t(r);
      a !== r && (Z2(e) || (e[i] = a), r = a);
    }
    n[r] = !0;
  }
  return n;
}
function iv(n) {
  for (let e = 0; e < n.length; e++)
    $t(n, e) || (n[e] = null);
  return n;
}
function un(n) {
  const e = Xh(null);
  for (const [t, i] of Wh(n))
    $t(n, t) && (Array.isArray(i) ? e[t] = iv(i) : i && typeof i == "object" && i.constructor === Object ? e[t] = un(i) : e[t] = i);
  return e;
}
function Li(n, e) {
  for (; n !== null; ) {
    const i = K2(n, e);
    if (i) {
      if (i.get)
        return at(i.get);
      if (typeof i.value == "function")
        return at(i.value);
    }
    n = Y2(n);
  }
  function t() {
    return null;
  }
  return t;
}
const Gc = rt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Ss = rt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), As = rt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), rv = rt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Fs = rt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), av = rt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), zc = rt(["#text"]), qc = rt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Ts = rt(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), jc = rt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Nr = rt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), sv = Et(/\{\{[\w\W]*|[\w\W]*\}\}/gm), ov = Et(/<%[\w\W]*|[\w\W]*%>/gm), lv = Et(/\$\{[\w\W]*/gm), uv = Et(/^data-[\-\w.\u00B7-\uFFFF]+$/), cv = Et(/^aria-[\-\w]+$/), Zh = Et(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), fv = Et(/^(?:\w+script|data):/i), hv = Et(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Yh = Et(/^html$/i), dv = Et(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Vc = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: cv,
  ATTR_WHITESPACE: hv,
  CUSTOM_ELEMENT: dv,
  DATA_ATTR: uv,
  DOCTYPE_NAME: Yh,
  ERB_EXPR: ov,
  IS_ALLOWED_URI: Zh,
  IS_SCRIPT_OR_DATA: fv,
  MUSTACHE_EXPR: sv,
  TMPLIT_EXPR: lv
});
const Ri = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, _v = function() {
  return typeof window > "u" ? null : window;
}, pv = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let i = null;
  const r = "data-tt-policy-suffix";
  t && t.hasAttribute(r) && (i = t.getAttribute(r));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return e.createPolicy(a, {
      createHTML(s) {
        return s;
      },
      createScriptURL(s) {
        return s;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Wc = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Kh() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : _v();
  const e = (M) => Kh(M);
  if (e.version = "3.2.6", e.removed = [], !n || !n.document || n.document.nodeType !== Ri.document || !n.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = n;
  const i = t, r = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: s,
    Node: o,
    Element: l,
    NodeFilter: c,
    NamedNodeMap: u = n.NamedNodeMap || n.MozNamedAttrMap,
    HTMLFormElement: f,
    DOMParser: h,
    trustedTypes: d
  } = n, p = l.prototype, v = Li(p, "cloneNode"), w = Li(p, "remove"), D = Li(p, "nextSibling"), m = Li(p, "childNodes"), _ = Li(p, "parentNode");
  if (typeof s == "function") {
    const M = t.createElement("template");
    M.content && M.content.ownerDocument && (t = M.content.ownerDocument);
  }
  let g, b = "";
  const {
    implementation: E,
    createNodeIterator: k,
    createDocumentFragment: P,
    getElementsByTagName: A
  } = t, {
    importNode: R
  } = i;
  let B = Wc();
  e.isSupported = typeof Wh == "function" && typeof _ == "function" && E && E.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: L,
    ERB_EXPR: de,
    TMPLIT_EXPR: z,
    DATA_ATTR: te,
    ARIA_ATTR: Q,
    IS_SCRIPT_OR_DATA: oe,
    ATTR_WHITESPACE: X,
    CUSTOM_ELEMENT: ne
  } = Vc;
  let {
    IS_ALLOWED_URI: De
  } = Vc, F = null;
  const x = W({}, [...Gc, ...Ss, ...As, ...Fs, ...zc]);
  let H = null;
  const J = W({}, [...qc, ...Ts, ...jc, ...Nr]);
  let T = Object.seal(Xh(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), ke = null, Se = null, I = !0, q = !0, j = !1, V = !0, ce = !1, Ee = !0, S = !1, le = !1, Pe = !1, fe = !1, Ae = !1, Fe = !1, Me = !0, Ct = !1;
  const nn = "user-content-";
  let C = !0, be = !1, Ht = {}, Kn = null;
  const jo = W({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Vo = null;
  const Wo = W({}, ["audio", "video", "img", "source", "image", "track"]);
  let Ia = null;
  const Xo = W({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), ur = "http://www.w3.org/1998/Math/MathML", cr = "http://www.w3.org/2000/svg", rn = "http://www.w3.org/1999/xhtml";
  let Qn = rn, $a = !1, xa = null;
  const id = W({}, [ur, cr, rn], ks);
  let fr = W({}, ["mi", "mo", "mn", "ms", "mtext"]), hr = W({}, ["annotation-xml"]);
  const rd = W({}, ["title", "style", "font", "a", "script"]);
  let Ci = null;
  const ad = ["application/xhtml+xml", "text/html"], sd = "text/html";
  let Be = null, Jn = null;
  const od = t.createElement("form"), Zo = function(y) {
    return y instanceof RegExp || y instanceof Function;
  }, Pa = function() {
    let y = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Jn && Jn === y)) {
      if ((!y || typeof y != "object") && (y = {}), y = un(y), Ci = // eslint-disable-next-line unicorn/prefer-includes
      ad.indexOf(y.PARSER_MEDIA_TYPE) === -1 ? sd : y.PARSER_MEDIA_TYPE, Be = Ci === "application/xhtml+xml" ? ks : Vr, F = $t(y, "ALLOWED_TAGS") ? W({}, y.ALLOWED_TAGS, Be) : x, H = $t(y, "ALLOWED_ATTR") ? W({}, y.ALLOWED_ATTR, Be) : J, xa = $t(y, "ALLOWED_NAMESPACES") ? W({}, y.ALLOWED_NAMESPACES, ks) : id, Ia = $t(y, "ADD_URI_SAFE_ATTR") ? W(un(Xo), y.ADD_URI_SAFE_ATTR, Be) : Xo, Vo = $t(y, "ADD_DATA_URI_TAGS") ? W(un(Wo), y.ADD_DATA_URI_TAGS, Be) : Wo, Kn = $t(y, "FORBID_CONTENTS") ? W({}, y.FORBID_CONTENTS, Be) : jo, ke = $t(y, "FORBID_TAGS") ? W({}, y.FORBID_TAGS, Be) : un({}), Se = $t(y, "FORBID_ATTR") ? W({}, y.FORBID_ATTR, Be) : un({}), Ht = $t(y, "USE_PROFILES") ? y.USE_PROFILES : !1, I = y.ALLOW_ARIA_ATTR !== !1, q = y.ALLOW_DATA_ATTR !== !1, j = y.ALLOW_UNKNOWN_PROTOCOLS || !1, V = y.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ce = y.SAFE_FOR_TEMPLATES || !1, Ee = y.SAFE_FOR_XML !== !1, S = y.WHOLE_DOCUMENT || !1, fe = y.RETURN_DOM || !1, Ae = y.RETURN_DOM_FRAGMENT || !1, Fe = y.RETURN_TRUSTED_TYPE || !1, Pe = y.FORCE_BODY || !1, Me = y.SANITIZE_DOM !== !1, Ct = y.SANITIZE_NAMED_PROPS || !1, C = y.KEEP_CONTENT !== !1, be = y.IN_PLACE || !1, De = y.ALLOWED_URI_REGEXP || Zh, Qn = y.NAMESPACE || rn, fr = y.MATHML_TEXT_INTEGRATION_POINTS || fr, hr = y.HTML_INTEGRATION_POINTS || hr, T = y.CUSTOM_ELEMENT_HANDLING || {}, y.CUSTOM_ELEMENT_HANDLING && Zo(y.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (T.tagNameCheck = y.CUSTOM_ELEMENT_HANDLING.tagNameCheck), y.CUSTOM_ELEMENT_HANDLING && Zo(y.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (T.attributeNameCheck = y.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), y.CUSTOM_ELEMENT_HANDLING && typeof y.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (T.allowCustomizedBuiltInElements = y.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ce && (q = !1), Ae && (fe = !0), Ht && (F = W({}, zc), H = [], Ht.html === !0 && (W(F, Gc), W(H, qc)), Ht.svg === !0 && (W(F, Ss), W(H, Ts), W(H, Nr)), Ht.svgFilters === !0 && (W(F, As), W(H, Ts), W(H, Nr)), Ht.mathMl === !0 && (W(F, Fs), W(H, jc), W(H, Nr))), y.ADD_TAGS && (F === x && (F = un(F)), W(F, y.ADD_TAGS, Be)), y.ADD_ATTR && (H === J && (H = un(H)), W(H, y.ADD_ATTR, Be)), y.ADD_URI_SAFE_ATTR && W(Ia, y.ADD_URI_SAFE_ATTR, Be), y.FORBID_CONTENTS && (Kn === jo && (Kn = un(Kn)), W(Kn, y.FORBID_CONTENTS, Be)), C && (F["#text"] = !0), S && W(F, ["html", "head", "body"]), F.table && (W(F, ["tbody"]), delete ke.tbody), y.TRUSTED_TYPES_POLICY) {
        if (typeof y.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Oi('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof y.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Oi('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        g = y.TRUSTED_TYPES_POLICY, b = g.createHTML("");
      } else
        g === void 0 && (g = pv(d, r)), g !== null && typeof b == "string" && (b = g.createHTML(""));
      rt && rt(y), Jn = y;
    }
  }, Yo = W({}, [...Ss, ...As, ...rv]), Ko = W({}, [...Fs, ...av]), ld = function(y) {
    let $ = _(y);
    (!$ || !$.tagName) && ($ = {
      namespaceURI: Qn,
      tagName: "template"
    });
    const O = Vr(y.tagName), pe = Vr($.tagName);
    return xa[y.namespaceURI] ? y.namespaceURI === cr ? $.namespaceURI === rn ? O === "svg" : $.namespaceURI === ur ? O === "svg" && (pe === "annotation-xml" || fr[pe]) : !!Yo[O] : y.namespaceURI === ur ? $.namespaceURI === rn ? O === "math" : $.namespaceURI === cr ? O === "math" && hr[pe] : !!Ko[O] : y.namespaceURI === rn ? $.namespaceURI === cr && !hr[pe] || $.namespaceURI === ur && !fr[pe] ? !1 : !Ko[O] && (rd[O] || !Yo[O]) : !!(Ci === "application/xhtml+xml" && xa[y.namespaceURI]) : !1;
  }, Gt = function(y) {
    Pi(e.removed, {
      element: y
    });
    try {
      _(y).removeChild(y);
    } catch {
      w(y);
    }
  }, ei = function(y, $) {
    try {
      Pi(e.removed, {
        attribute: $.getAttributeNode(y),
        from: $
      });
    } catch {
      Pi(e.removed, {
        attribute: null,
        from: $
      });
    }
    if ($.removeAttribute(y), y === "is")
      if (fe || Ae)
        try {
          Gt($);
        } catch {
        }
      else
        try {
          $.setAttribute(y, "");
        } catch {
        }
  }, Qo = function(y) {
    let $ = null, O = null;
    if (Pe)
      y = "<remove></remove>" + y;
    else {
      const xe = Hc(y, /^[\r\n\t ]+/);
      O = xe && xe[0];
    }
    Ci === "application/xhtml+xml" && Qn === rn && (y = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + y + "</body></html>");
    const pe = g ? g.createHTML(y) : y;
    if (Qn === rn)
      try {
        $ = new h().parseFromString(pe, Ci);
      } catch {
      }
    if (!$ || !$.documentElement) {
      $ = E.createDocument(Qn, "template", null);
      try {
        $.documentElement.innerHTML = $a ? b : pe;
      } catch {
      }
    }
    const Ge = $.body || $.documentElement;
    return y && O && Ge.insertBefore(t.createTextNode(O), Ge.childNodes[0] || null), Qn === rn ? A.call($, S ? "html" : "body")[0] : S ? $.documentElement : Ge;
  }, Jo = function(y) {
    return k.call(
      y.ownerDocument || y,
      y,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, Ba = function(y) {
    return y instanceof f && (typeof y.nodeName != "string" || typeof y.textContent != "string" || typeof y.removeChild != "function" || !(y.attributes instanceof u) || typeof y.removeAttribute != "function" || typeof y.setAttribute != "function" || typeof y.namespaceURI != "string" || typeof y.insertBefore != "function" || typeof y.hasChildNodes != "function");
  }, el = function(y) {
    return typeof o == "function" && y instanceof o;
  };
  function an(M, y, $) {
    Mr(M, (O) => {
      O.call(e, y, $, Jn);
    });
  }
  const tl = function(y) {
    let $ = null;
    if (an(B.beforeSanitizeElements, y, null), Ba(y))
      return Gt(y), !0;
    const O = Be(y.nodeName);
    if (an(B.uponSanitizeElement, y, {
      tagName: O,
      allowedTags: F
    }), Ee && y.hasChildNodes() && !el(y.firstElementChild) && Ye(/<[/\w!]/g, y.innerHTML) && Ye(/<[/\w!]/g, y.textContent) || y.nodeType === Ri.progressingInstruction || Ee && y.nodeType === Ri.comment && Ye(/<[/\w]/g, y.data))
      return Gt(y), !0;
    if (!F[O] || ke[O]) {
      if (!ke[O] && il(O) && (T.tagNameCheck instanceof RegExp && Ye(T.tagNameCheck, O) || T.tagNameCheck instanceof Function && T.tagNameCheck(O)))
        return !1;
      if (C && !Kn[O]) {
        const pe = _(y) || y.parentNode, Ge = m(y) || y.childNodes;
        if (Ge && pe) {
          const xe = Ge.length;
          for (let st = xe - 1; st >= 0; --st) {
            const sn = v(Ge[st], !0);
            sn.__removalCount = (y.__removalCount || 0) + 1, pe.insertBefore(sn, D(y));
          }
        }
      }
      return Gt(y), !0;
    }
    return y instanceof l && !ld(y) || (O === "noscript" || O === "noembed" || O === "noframes") && Ye(/<\/no(script|embed|frames)/i, y.innerHTML) ? (Gt(y), !0) : (ce && y.nodeType === Ri.text && ($ = y.textContent, Mr([L, de, z], (pe) => {
      $ = Bi($, pe, " ");
    }), y.textContent !== $ && (Pi(e.removed, {
      element: y.cloneNode()
    }), y.textContent = $)), an(B.afterSanitizeElements, y, null), !1);
  }, nl = function(y, $, O) {
    if (Me && ($ === "id" || $ === "name") && (O in t || O in od))
      return !1;
    if (!(q && !Se[$] && Ye(te, $))) {
      if (!(I && Ye(Q, $))) {
        if (!H[$] || Se[$]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(il(y) && (T.tagNameCheck instanceof RegExp && Ye(T.tagNameCheck, y) || T.tagNameCheck instanceof Function && T.tagNameCheck(y)) && (T.attributeNameCheck instanceof RegExp && Ye(T.attributeNameCheck, $) || T.attributeNameCheck instanceof Function && T.attributeNameCheck($)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            $ === "is" && T.allowCustomizedBuiltInElements && (T.tagNameCheck instanceof RegExp && Ye(T.tagNameCheck, O) || T.tagNameCheck instanceof Function && T.tagNameCheck(O)))
          ) return !1;
        } else if (!Ia[$]) {
          if (!Ye(De, Bi(O, X, ""))) {
            if (!(($ === "src" || $ === "xlink:href" || $ === "href") && y !== "script" && ev(O, "data:") === 0 && Vo[y])) {
              if (!(j && !Ye(oe, Bi(O, X, "")))) {
                if (O)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, il = function(y) {
    return y !== "annotation-xml" && Hc(y, ne);
  }, rl = function(y) {
    an(B.beforeSanitizeAttributes, y, null);
    const {
      attributes: $
    } = y;
    if (!$ || Ba(y))
      return;
    const O = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: H,
      forceKeepAttr: void 0
    };
    let pe = $.length;
    for (; pe--; ) {
      const Ge = $[pe], {
        name: xe,
        namespaceURI: st,
        value: sn
      } = Ge, ki = Be(xe), Oa = sn;
      let ze = xe === "value" ? Oa : tv(Oa);
      if (O.attrName = ki, O.attrValue = ze, O.keepAttr = !0, O.forceKeepAttr = void 0, an(B.uponSanitizeAttribute, y, O), ze = O.attrValue, Ct && (ki === "id" || ki === "name") && (ei(xe, y), ze = nn + ze), Ee && Ye(/((--!?|])>)|<\/(style|title)/i, ze)) {
        ei(xe, y);
        continue;
      }
      if (O.forceKeepAttr)
        continue;
      if (!O.keepAttr) {
        ei(xe, y);
        continue;
      }
      if (!V && Ye(/\/>/i, ze)) {
        ei(xe, y);
        continue;
      }
      ce && Mr([L, de, z], (sl) => {
        ze = Bi(ze, sl, " ");
      });
      const al = Be(y.nodeName);
      if (!nl(al, ki, ze)) {
        ei(xe, y);
        continue;
      }
      if (g && typeof d == "object" && typeof d.getAttributeType == "function" && !st)
        switch (d.getAttributeType(al, ki)) {
          case "TrustedHTML": {
            ze = g.createHTML(ze);
            break;
          }
          case "TrustedScriptURL": {
            ze = g.createScriptURL(ze);
            break;
          }
        }
      if (ze !== Oa)
        try {
          st ? y.setAttributeNS(st, xe, ze) : y.setAttribute(xe, ze), Ba(y) ? Gt(y) : Uc(e.removed);
        } catch {
          ei(xe, y);
        }
    }
    an(B.afterSanitizeAttributes, y, null);
  }, ud = function M(y) {
    let $ = null;
    const O = Jo(y);
    for (an(B.beforeSanitizeShadowDOM, y, null); $ = O.nextNode(); )
      an(B.uponSanitizeShadowNode, $, null), tl($), rl($), $.content instanceof a && M($.content);
    an(B.afterSanitizeShadowDOM, y, null);
  };
  return e.sanitize = function(M) {
    let y = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, $ = null, O = null, pe = null, Ge = null;
    if ($a = !M, $a && (M = "<!-->"), typeof M != "string" && !el(M))
      if (typeof M.toString == "function") {
        if (M = M.toString(), typeof M != "string")
          throw Oi("dirty is not a string, aborting");
      } else
        throw Oi("toString is not a function");
    if (!e.isSupported)
      return M;
    if (le || Pa(y), e.removed = [], typeof M == "string" && (be = !1), be) {
      if (M.nodeName) {
        const sn = Be(M.nodeName);
        if (!F[sn] || ke[sn])
          throw Oi("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (M instanceof o)
      $ = Qo("<!---->"), O = $.ownerDocument.importNode(M, !0), O.nodeType === Ri.element && O.nodeName === "BODY" || O.nodeName === "HTML" ? $ = O : $.appendChild(O);
    else {
      if (!fe && !ce && !S && // eslint-disable-next-line unicorn/prefer-includes
      M.indexOf("<") === -1)
        return g && Fe ? g.createHTML(M) : M;
      if ($ = Qo(M), !$)
        return fe ? null : Fe ? b : "";
    }
    $ && Pe && Gt($.firstChild);
    const xe = Jo(be ? M : $);
    for (; pe = xe.nextNode(); )
      tl(pe), rl(pe), pe.content instanceof a && ud(pe.content);
    if (be)
      return M;
    if (fe) {
      if (Ae)
        for (Ge = P.call($.ownerDocument); $.firstChild; )
          Ge.appendChild($.firstChild);
      else
        Ge = $;
      return (H.shadowroot || H.shadowrootmode) && (Ge = R.call(i, Ge, !0)), Ge;
    }
    let st = S ? $.outerHTML : $.innerHTML;
    return S && F["!doctype"] && $.ownerDocument && $.ownerDocument.doctype && $.ownerDocument.doctype.name && Ye(Yh, $.ownerDocument.doctype.name) && (st = "<!DOCTYPE " + $.ownerDocument.doctype.name + `>
` + st), ce && Mr([L, de, z], (sn) => {
      st = Bi(st, sn, " ");
    }), g && Fe ? g.createHTML(st) : st;
  }, e.setConfig = function() {
    let M = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Pa(M), le = !0;
  }, e.clearConfig = function() {
    Jn = null, le = !1;
  }, e.isValidAttribute = function(M, y, $) {
    Jn || Pa({});
    const O = Be(M), pe = Be(y);
    return nl(O, pe, $);
  }, e.addHook = function(M, y) {
    typeof y == "function" && Pi(B[M], y);
  }, e.removeHook = function(M, y) {
    if (y !== void 0) {
      const $ = Q2(B[M], y);
      return $ === -1 ? void 0 : J2(B[M], $, 1)[0];
    }
    return Uc(B[M]);
  }, e.removeHooks = function(M) {
    B[M] = [];
  }, e.removeAllHooks = function() {
    B = Wc();
  }, e;
}
Kh();
const {
  HtmlTagHydration: z6,
  SvelteComponent: q6,
  add_render_callback: j6,
  append_hydration: V6,
  attr: W6,
  bubble: X6,
  check_outros: Z6,
  children: Y6,
  claim_component: K6,
  claim_element: Q6,
  claim_html_tag: J6,
  claim_space: e9,
  claim_text: t9,
  create_component: n9,
  create_in_transition: i9,
  create_out_transition: r9,
  destroy_component: a9,
  detach: s9,
  element: o9,
  get_svelte_dataset: l9,
  group_outros: u9,
  init: c9,
  insert_hydration: f9,
  listen: h9,
  mount_component: d9,
  run_all: _9,
  safe_not_equal: p9,
  set_data: m9,
  space: g9,
  stop_propagation: b9,
  text: v9,
  toggle_class: y9,
  transition_in: w9,
  transition_out: D9
} = window.__gradio__svelte__internal, { createEventDispatcher: E9, onMount: C9 } = window.__gradio__svelte__internal, {
  SvelteComponent: k9,
  append_hydration: S9,
  attr: A9,
  bubble: F9,
  check_outros: T9,
  children: I9,
  claim_component: $9,
  claim_element: x9,
  claim_space: P9,
  create_animation: B9,
  create_component: O9,
  destroy_component: L9,
  detach: R9,
  element: M9,
  ensure_array_like: N9,
  fix_and_outro_and_destroy_block: U9,
  fix_position: H9,
  group_outros: G9,
  init: z9,
  insert_hydration: q9,
  mount_component: j9,
  noop: V9,
  safe_not_equal: W9,
  set_style: X9,
  space: Z9,
  transition_in: Y9,
  transition_out: K9,
  update_keyed_each: Q9
} = window.__gradio__svelte__internal, {
  SvelteComponent: J9,
  attr: eI,
  children: tI,
  claim_element: nI,
  detach: iI,
  element: rI,
  empty: aI,
  init: sI,
  insert_hydration: oI,
  noop: lI,
  safe_not_equal: uI,
  set_style: cI
} = window.__gradio__svelte__internal, {
  SvelteComponent: mv,
  attr: gv,
  check_outros: bv,
  children: vv,
  claim_component: yv,
  claim_element: wv,
  create_component: Dv,
  destroy_component: Ev,
  detach: Xc,
  element: Cv,
  group_outros: kv,
  init: Sv,
  insert_hydration: Av,
  mount_component: Fv,
  safe_not_equal: Tv,
  toggle_class: mn,
  transition_in: Wr,
  transition_out: vo
} = window.__gradio__svelte__internal;
function Zc(n) {
  let e, t;
  return e = new xo({
    props: { src: (
      /*value*/
      n[0].url
    ), alt: "" }
  }), {
    c() {
      Dv(e.$$.fragment);
    },
    l(i) {
      yv(e.$$.fragment, i);
    },
    m(i, r) {
      Fv(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r & /*value*/
      1 && (a.src = /*value*/
      i[0].url), e.$set(a);
    },
    i(i) {
      t || (Wr(e.$$.fragment, i), t = !0);
    },
    o(i) {
      vo(e.$$.fragment, i), t = !1;
    },
    d(i) {
      Ev(e, i);
    }
  };
}
function Iv(n) {
  let e, t, i = (
    /*value*/
    n[0] && Zc(n)
  );
  return {
    c() {
      e = Cv("div"), i && i.c(), this.h();
    },
    l(r) {
      e = wv(r, "DIV", { class: !0 });
      var a = vv(e);
      i && i.l(a), a.forEach(Xc), this.h();
    },
    h() {
      gv(e, "class", "container svelte-1sgcyba"), mn(
        e,
        "table",
        /*type*/
        n[1] === "table"
      ), mn(
        e,
        "gallery",
        /*type*/
        n[1] === "gallery"
      ), mn(
        e,
        "selected",
        /*selected*/
        n[2]
      ), mn(
        e,
        "border",
        /*value*/
        n[0]
      );
    },
    m(r, a) {
      Av(r, e, a), i && i.m(e, null), t = !0;
    },
    p(r, [a]) {
      /*value*/
      r[0] ? i ? (i.p(r, a), a & /*value*/
      1 && Wr(i, 1)) : (i = Zc(r), i.c(), Wr(i, 1), i.m(e, null)) : i && (kv(), vo(i, 1, 1, () => {
        i = null;
      }), bv()), (!t || a & /*type*/
      2) && mn(
        e,
        "table",
        /*type*/
        r[1] === "table"
      ), (!t || a & /*type*/
      2) && mn(
        e,
        "gallery",
        /*type*/
        r[1] === "gallery"
      ), (!t || a & /*selected*/
      4) && mn(
        e,
        "selected",
        /*selected*/
        r[2]
      ), (!t || a & /*value*/
      1) && mn(
        e,
        "border",
        /*value*/
        r[0]
      );
    },
    i(r) {
      t || (Wr(i), t = !0);
    },
    o(r) {
      vo(i), t = !1;
    },
    d(r) {
      r && Xc(e), i && i.d();
    }
  };
}
function $v(n, e, t) {
  let { value: i } = e, { type: r } = e, { selected: a = !1 } = e;
  return n.$$set = (s) => {
    "value" in s && t(0, i = s.value), "type" in s && t(1, r = s.type), "selected" in s && t(2, a = s.selected);
  }, [i, r, a];
}
class fI extends mv {
  constructor(e) {
    super(), Sv(this, e, $v, Iv, Tv, { value: 0, type: 1, selected: 2 });
  }
}
const {
  SvelteComponent: xv,
  add_flush_callback: ui,
  assign: Qh,
  bind: ci,
  binding_callbacks: xn,
  check_outros: Pv,
  claim_component: zn,
  claim_space: Jh,
  create_component: qn,
  destroy_component: jn,
  detach: zo,
  empty: Yc,
  flush: he,
  get_spread_object: ed,
  get_spread_update: td,
  group_outros: Bv,
  init: Ov,
  insert_hydration: qo,
  mount_component: Vn,
  safe_not_equal: Lv,
  space: nd,
  transition_in: hn,
  transition_out: dn
} = window.__gradio__svelte__internal, { afterUpdate: Rv } = window.__gradio__svelte__internal;
function Mv(n) {
  let e, t, i;
  function r(s) {
    n[55](s);
  }
  let a = {
    visible: (
      /*visible*/
      n[4]
    ),
    variant: (
      /*value*/
      n[0] === null ? "dashed" : "solid"
    ),
    border_mode: (
      /*dragging*/
      n[27] ? "focus" : "base"
    ),
    padding: !1,
    elem_id: (
      /*elem_id*/
      n[2]
    ),
    elem_classes: (
      /*elem_classes*/
      n[3]
    ),
    height: (
      /*height*/
      n[12] || void 0
    ),
    width: (
      /*width*/
      n[13]
    ),
    allow_overflow: !1,
    container: (
      /*container*/
      n[15]
    ),
    scale: (
      /*scale*/
      n[16]
    ),
    min_width: (
      /*min_width*/
      n[17]
    ),
    $$slots: { default: [Hv] },
    $$scope: { ctx: n }
  };
  return (
    /*fullscreen*/
    n[26] !== void 0 && (a.fullscreen = /*fullscreen*/
    n[26]), e = new rf({ props: a }), xn.push(() => ci(e, "fullscreen", r)), e.$on(
      "dragenter",
      /*handle_drag_event*/
      n[30]
    ), e.$on(
      "dragleave",
      /*handle_drag_event*/
      n[30]
    ), e.$on(
      "dragover",
      /*handle_drag_event*/
      n[30]
    ), e.$on(
      "drop",
      /*handle_drop*/
      n[31]
    ), {
      c() {
        qn(e.$$.fragment);
      },
      l(s) {
        zn(e.$$.fragment, s);
      },
      m(s, o) {
        Vn(e, s, o), i = !0;
      },
      p(s, o) {
        const l = {};
        o[0] & /*visible*/
        16 && (l.visible = /*visible*/
        s[4]), o[0] & /*value*/
        1 && (l.variant = /*value*/
        s[0] === null ? "dashed" : "solid"), o[0] & /*dragging*/
        134217728 && (l.border_mode = /*dragging*/
        s[27] ? "focus" : "base"), o[0] & /*elem_id*/
        4 && (l.elem_id = /*elem_id*/
        s[2]), o[0] & /*elem_classes*/
        8 && (l.elem_classes = /*elem_classes*/
        s[3]), o[0] & /*height*/
        4096 && (l.height = /*height*/
        s[12] || void 0), o[0] & /*width*/
        8192 && (l.width = /*width*/
        s[13]), o[0] & /*container*/
        32768 && (l.container = /*container*/
        s[15]), o[0] & /*scale*/
        65536 && (l.scale = /*scale*/
        s[16]), o[0] & /*min_width*/
        131072 && (l.min_width = /*min_width*/
        s[17]), o[0] & /*_selectable, root, sources, fullscreen, label, show_label, pending, show_fullscreen_button, gradio, height, width, only_custom_metadata, popup_metadata_width, popup_metadata_height, upload_component, uploading, active_source, value, dragging, loading_status, placeholder*/
        1072201571 | o[1] & /*$$scope*/
        67108864 && (l.$$scope = { dirty: o, ctx: s }), !t && o[0] & /*fullscreen*/
        67108864 && (t = !0, l.fullscreen = /*fullscreen*/
        s[26], ui(() => t = !1)), e.$set(l);
      },
      i(s) {
        i || (hn(e.$$.fragment, s), i = !0);
      },
      o(s) {
        dn(e.$$.fragment, s), i = !1;
      },
      d(s) {
        jn(e, s);
      }
    }
  );
}
function Nv(n) {
  let e, t, i;
  function r(s) {
    n[39](s);
  }
  let a = {
    visible: (
      /*visible*/
      n[4]
    ),
    variant: "solid",
    border_mode: (
      /*dragging*/
      n[27] ? "focus" : "base"
    ),
    padding: !1,
    elem_id: (
      /*elem_id*/
      n[2]
    ),
    elem_classes: (
      /*elem_classes*/
      n[3]
    ),
    height: (
      /*height*/
      n[12] || void 0
    ),
    width: (
      /*width*/
      n[13]
    ),
    allow_overflow: !1,
    container: (
      /*container*/
      n[15]
    ),
    scale: (
      /*scale*/
      n[16]
    ),
    min_width: (
      /*min_width*/
      n[17]
    ),
    $$slots: { default: [Gv] },
    $$scope: { ctx: n }
  };
  return (
    /*fullscreen*/
    n[26] !== void 0 && (a.fullscreen = /*fullscreen*/
    n[26]), e = new rf({ props: a }), xn.push(() => ci(e, "fullscreen", r)), {
      c() {
        qn(e.$$.fragment);
      },
      l(s) {
        zn(e.$$.fragment, s);
      },
      m(s, o) {
        Vn(e, s, o), i = !0;
      },
      p(s, o) {
        const l = {};
        o[0] & /*visible*/
        16 && (l.visible = /*visible*/
        s[4]), o[0] & /*dragging*/
        134217728 && (l.border_mode = /*dragging*/
        s[27] ? "focus" : "base"), o[0] & /*elem_id*/
        4 && (l.elem_id = /*elem_id*/
        s[2]), o[0] & /*elem_classes*/
        8 && (l.elem_classes = /*elem_classes*/
        s[3]), o[0] & /*height*/
        4096 && (l.height = /*height*/
        s[12] || void 0), o[0] & /*width*/
        8192 && (l.width = /*width*/
        s[13]), o[0] & /*container*/
        32768 && (l.container = /*container*/
        s[15]), o[0] & /*scale*/
        65536 && (l.scale = /*scale*/
        s[16]), o[0] & /*min_width*/
        131072 && (l.min_width = /*min_width*/
        s[17]), o[0] & /*fullscreen, value, label, show_label, show_download_button, _selectable, show_share_button, gradio, show_fullscreen_button, height, width, only_custom_metadata, popup_metadata_width, popup_metadata_height, loading_status*/
        92569315 | o[1] & /*$$scope*/
        67108864 && (l.$$scope = { dirty: o, ctx: s }), !t && o[0] & /*fullscreen*/
        67108864 && (t = !0, l.fullscreen = /*fullscreen*/
        s[26], ui(() => t = !1)), e.$set(l);
      },
      i(s) {
        i || (hn(e.$$.fragment, s), i = !0);
      },
      o(s) {
        dn(e.$$.fragment, s), i = !1;
      },
      d(s) {
        jn(e, s);
      }
    }
  );
}
function Uv(n) {
  let e, t;
  return e = new Gm({
    props: {
      i18n: (
        /*gradio*/
        n[24].i18n
      ),
      type: "image",
      placeholder: (
        /*placeholder*/
        n[22]
      )
    }
  }), {
    c() {
      qn(e.$$.fragment);
    },
    l(i) {
      zn(e.$$.fragment, i);
    },
    m(i, r) {
      Vn(e, i, r), t = !0;
    },
    p(i, r) {
      const a = {};
      r[0] & /*gradio*/
      16777216 && (a.i18n = /*gradio*/
      i[24].i18n), r[0] & /*placeholder*/
      4194304 && (a.placeholder = /*placeholder*/
      i[22]), e.$set(a);
    },
    i(i) {
      t || (hn(e.$$.fragment, i), t = !0);
    },
    o(i) {
      dn(e.$$.fragment, i), t = !1;
    },
    d(i) {
      jn(e, i);
    }
  };
}
function Hv(n) {
  var w;
  let e, t, i, r, a, s, o, l;
  const c = [
    {
      autoscroll: (
        /*gradio*/
        n[24].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      n[24].i18n
    ) },
    /*loading_status*/
    n[1]
  ];
  let u = {};
  for (let D = 0; D < c.length; D += 1)
    u = Qh(u, c[D]);
  e = new Vh({ props: u }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    n[40]
  );
  function f(D) {
    n[43](D);
  }
  function h(D) {
    n[44](D);
  }
  function d(D) {
    n[45](D);
  }
  function p(D) {
    n[46](D);
  }
  let v = {
    selectable: (
      /*_selectable*/
      n[14]
    ),
    root: (
      /*root*/
      n[8]
    ),
    sources: (
      /*sources*/
      n[19]
    ),
    fullscreen: (
      /*fullscreen*/
      n[26]
    ),
    label: (
      /*label*/
      n[5]
    ),
    show_label: (
      /*show_label*/
      n[6]
    ),
    pending: (
      /*pending*/
      n[21]
    ),
    show_fullscreen_button: (
      /*show_fullscreen_button*/
      n[23]
    ),
    max_file_size: (
      /*gradio*/
      n[24].max_file_size
    ),
    i18n: (
      /*gradio*/
      n[24].i18n
    ),
    upload: (
      /*func*/
      n[41]
    ),
    stream_handler: (
      /*gradio*/
      (w = n[24].client) == null ? void 0 : w.stream
    ),
    height: (
      /*height*/
      n[12] || void 0
    ),
    width: (
      /*width*/
      n[13]
    ),
    only_custom_metadata: (
      /*only_custom_metadata*/
      n[9]
    ),
    popup_metadata_width: (
      /*popup_metadata_width*/
      n[10]
    ),
    popup_metadata_height: (
      /*popup_metadata_height*/
      n[11]
    ),
    $$slots: { default: [Uv] },
    $$scope: { ctx: n }
  };
  return (
    /*uploading*/
    n[25] !== void 0 && (v.uploading = /*uploading*/
    n[25]), /*active_source*/
    n[28] !== void 0 && (v.active_source = /*active_source*/
    n[28]), /*value*/
    n[0] !== void 0 && (v.value = /*value*/
    n[0]), /*dragging*/
    n[27] !== void 0 && (v.dragging = /*dragging*/
    n[27]), i = new p2({ props: v }), n[42](i), xn.push(() => ci(i, "uploading", f)), xn.push(() => ci(i, "active_source", h)), xn.push(() => ci(i, "value", d)), xn.push(() => ci(i, "dragging", p)), i.$on(
      "edit",
      /*edit_handler*/
      n[47]
    ), i.$on(
      "clear",
      /*clear_handler*/
      n[48]
    ), i.$on(
      "drag",
      /*drag_handler*/
      n[49]
    ), i.$on(
      "upload",
      /*upload_handler*/
      n[50]
    ), i.$on(
      "select",
      /*select_handler_1*/
      n[51]
    ), i.$on(
      "share",
      /*share_handler_1*/
      n[52]
    ), i.$on(
      "load_metadata",
      /*handle_load_metadata*/
      n[32]
    ), i.$on(
      "error",
      /*error_handler_1*/
      n[53]
    ), i.$on(
      "fullscreen",
      /*fullscreen_handler_1*/
      n[54]
    ), {
      c() {
        qn(e.$$.fragment), t = nd(), qn(i.$$.fragment);
      },
      l(D) {
        zn(e.$$.fragment, D), t = Jh(D), zn(i.$$.fragment, D);
      },
      m(D, m) {
        Vn(e, D, m), qo(D, t, m), Vn(i, D, m), l = !0;
      },
      p(D, m) {
        var b;
        const _ = m[0] & /*gradio, loading_status*/
        16777218 ? td(c, [
          m[0] & /*gradio*/
          16777216 && {
            autoscroll: (
              /*gradio*/
              D[24].autoscroll
            )
          },
          m[0] & /*gradio*/
          16777216 && { i18n: (
            /*gradio*/
            D[24].i18n
          ) },
          m[0] & /*loading_status*/
          2 && ed(
            /*loading_status*/
            D[1]
          )
        ]) : {};
        e.$set(_);
        const g = {};
        m[0] & /*_selectable*/
        16384 && (g.selectable = /*_selectable*/
        D[14]), m[0] & /*root*/
        256 && (g.root = /*root*/
        D[8]), m[0] & /*sources*/
        524288 && (g.sources = /*sources*/
        D[19]), m[0] & /*fullscreen*/
        67108864 && (g.fullscreen = /*fullscreen*/
        D[26]), m[0] & /*label*/
        32 && (g.label = /*label*/
        D[5]), m[0] & /*show_label*/
        64 && (g.show_label = /*show_label*/
        D[6]), m[0] & /*pending*/
        2097152 && (g.pending = /*pending*/
        D[21]), m[0] & /*show_fullscreen_button*/
        8388608 && (g.show_fullscreen_button = /*show_fullscreen_button*/
        D[23]), m[0] & /*gradio*/
        16777216 && (g.max_file_size = /*gradio*/
        D[24].max_file_size), m[0] & /*gradio*/
        16777216 && (g.i18n = /*gradio*/
        D[24].i18n), m[0] & /*gradio*/
        16777216 && (g.upload = /*func*/
        D[41]), m[0] & /*gradio*/
        16777216 && (g.stream_handler = /*gradio*/
        (b = D[24].client) == null ? void 0 : b.stream), m[0] & /*height*/
        4096 && (g.height = /*height*/
        D[12] || void 0), m[0] & /*width*/
        8192 && (g.width = /*width*/
        D[13]), m[0] & /*only_custom_metadata*/
        512 && (g.only_custom_metadata = /*only_custom_metadata*/
        D[9]), m[0] & /*popup_metadata_width*/
        1024 && (g.popup_metadata_width = /*popup_metadata_width*/
        D[10]), m[0] & /*popup_metadata_height*/
        2048 && (g.popup_metadata_height = /*popup_metadata_height*/
        D[11]), m[0] & /*gradio, placeholder*/
        20971520 | m[1] & /*$$scope*/
        67108864 && (g.$$scope = { dirty: m, ctx: D }), !r && m[0] & /*uploading*/
        33554432 && (r = !0, g.uploading = /*uploading*/
        D[25], ui(() => r = !1)), !a && m[0] & /*active_source*/
        268435456 && (a = !0, g.active_source = /*active_source*/
        D[28], ui(() => a = !1)), !s && m[0] & /*value*/
        1 && (s = !0, g.value = /*value*/
        D[0], ui(() => s = !1)), !o && m[0] & /*dragging*/
        134217728 && (o = !0, g.dragging = /*dragging*/
        D[27], ui(() => o = !1)), i.$set(g);
      },
      i(D) {
        l || (hn(e.$$.fragment, D), hn(i.$$.fragment, D), l = !0);
      },
      o(D) {
        dn(e.$$.fragment, D), dn(i.$$.fragment, D), l = !1;
      },
      d(D) {
        D && zo(t), jn(e, D), n[42](null), jn(i, D);
      }
    }
  );
}
function Gv(n) {
  let e, t, i, r;
  const a = [
    {
      autoscroll: (
        /*gradio*/
        n[24].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      n[24].i18n
    ) },
    /*loading_status*/
    n[1]
  ];
  let s = {};
  for (let o = 0; o < a.length; o += 1)
    s = Qh(s, a[o]);
  return e = new Vh({ props: s }), i = new x0({
    props: {
      fullscreen: (
        /*fullscreen*/
        n[26]
      ),
      value: (
        /*value*/
        n[0]
      ),
      label: (
        /*label*/
        n[5]
      ),
      show_label: (
        /*show_label*/
        n[6]
      ),
      show_download_button: (
        /*show_download_button*/
        n[7]
      ),
      selectable: (
        /*_selectable*/
        n[14]
      ),
      show_share_button: (
        /*show_share_button*/
        n[18]
      ),
      i18n: (
        /*gradio*/
        n[24].i18n
      ),
      show_fullscreen_button: (
        /*show_fullscreen_button*/
        n[23]
      ),
      height: (
        /*height*/
        n[12] || void 0
      ),
      width: (
        /*width*/
        n[13]
      ),
      only_custom_metadata: (
        /*only_custom_metadata*/
        n[9]
      ),
      popup_metadata_width: (
        /*popup_metadata_width*/
        n[10]
      ),
      popup_metadata_height: (
        /*popup_metadata_height*/
        n[11]
      )
    }
  }), i.$on(
    "select",
    /*select_handler*/
    n[35]
  ), i.$on(
    "share",
    /*share_handler*/
    n[36]
  ), i.$on(
    "error",
    /*error_handler*/
    n[37]
  ), i.$on(
    "load_metadata",
    /*handle_load_metadata*/
    n[32]
  ), i.$on(
    "fullscreen",
    /*fullscreen_handler*/
    n[38]
  ), {
    c() {
      qn(e.$$.fragment), t = nd(), qn(i.$$.fragment);
    },
    l(o) {
      zn(e.$$.fragment, o), t = Jh(o), zn(i.$$.fragment, o);
    },
    m(o, l) {
      Vn(e, o, l), qo(o, t, l), Vn(i, o, l), r = !0;
    },
    p(o, l) {
      const c = l[0] & /*gradio, loading_status*/
      16777218 ? td(a, [
        l[0] & /*gradio*/
        16777216 && {
          autoscroll: (
            /*gradio*/
            o[24].autoscroll
          )
        },
        l[0] & /*gradio*/
        16777216 && { i18n: (
          /*gradio*/
          o[24].i18n
        ) },
        l[0] & /*loading_status*/
        2 && ed(
          /*loading_status*/
          o[1]
        )
      ]) : {};
      e.$set(c);
      const u = {};
      l[0] & /*fullscreen*/
      67108864 && (u.fullscreen = /*fullscreen*/
      o[26]), l[0] & /*value*/
      1 && (u.value = /*value*/
      o[0]), l[0] & /*label*/
      32 && (u.label = /*label*/
      o[5]), l[0] & /*show_label*/
      64 && (u.show_label = /*show_label*/
      o[6]), l[0] & /*show_download_button*/
      128 && (u.show_download_button = /*show_download_button*/
      o[7]), l[0] & /*_selectable*/
      16384 && (u.selectable = /*_selectable*/
      o[14]), l[0] & /*show_share_button*/
      262144 && (u.show_share_button = /*show_share_button*/
      o[18]), l[0] & /*gradio*/
      16777216 && (u.i18n = /*gradio*/
      o[24].i18n), l[0] & /*show_fullscreen_button*/
      8388608 && (u.show_fullscreen_button = /*show_fullscreen_button*/
      o[23]), l[0] & /*height*/
      4096 && (u.height = /*height*/
      o[12] || void 0), l[0] & /*width*/
      8192 && (u.width = /*width*/
      o[13]), l[0] & /*only_custom_metadata*/
      512 && (u.only_custom_metadata = /*only_custom_metadata*/
      o[9]), l[0] & /*popup_metadata_width*/
      1024 && (u.popup_metadata_width = /*popup_metadata_width*/
      o[10]), l[0] & /*popup_metadata_height*/
      2048 && (u.popup_metadata_height = /*popup_metadata_height*/
      o[11]), i.$set(u);
    },
    i(o) {
      r || (hn(e.$$.fragment, o), hn(i.$$.fragment, o), r = !0);
    },
    o(o) {
      dn(e.$$.fragment, o), dn(i.$$.fragment, o), r = !1;
    },
    d(o) {
      o && zo(t), jn(e, o), jn(i, o);
    }
  };
}
function zv(n) {
  let e, t, i, r;
  const a = [Nv, Mv], s = [];
  function o(l, c) {
    return (
      /*interactive*/
      l[20] ? 1 : 0
    );
  }
  return e = o(n), t = s[e] = a[e](n), {
    c() {
      t.c(), i = Yc();
    },
    l(l) {
      t.l(l), i = Yc();
    },
    m(l, c) {
      s[e].m(l, c), qo(l, i, c), r = !0;
    },
    p(l, c) {
      let u = e;
      e = o(l), e === u ? s[e].p(l, c) : (Bv(), dn(s[u], 1, 1, () => {
        s[u] = null;
      }), Pv(), t = s[e], t ? t.p(l, c) : (t = s[e] = a[e](l), t.c()), hn(t, 1), t.m(i.parentNode, i));
    },
    i(l) {
      r || (hn(t), r = !0);
    },
    o(l) {
      dn(t), r = !1;
    },
    d(l) {
      l && zo(i), s[e].d(l);
    }
  };
}
function qv(n, e, t) {
  let { value_is_output: i = !1 } = e, { elem_id: r = "" } = e, { elem_classes: a = [] } = e, { visible: s = !0 } = e, { value: o = null } = e, { label: l } = e, { show_label: c } = e, { show_download_button: u } = e, { root: f } = e, { only_custom_metadata: h = !0 } = e, { popup_metadata_width: d = 400 } = e, { popup_metadata_height: p = 300 } = e, { height: v } = e, { width: w } = e, { _selectable: D = !1 } = e, { container: m = !0 } = e, { scale: _ = null } = e, { min_width: g = void 0 } = e, { loading_status: b } = e, { show_share_button: E = !1 } = e, { sources: k = ["upload"] } = e, { interactive: P } = e, { pending: A } = e, { placeholder: R = void 0 } = e, { show_fullscreen_button: B } = e, { gradio: L } = e, de = null, z = !1, te = !1, Q, oe = "upload", X;
  Rv(() => {
    t(33, i = !1);
  });
  const ne = (C) => {
    const be = C;
    be.preventDefault(), be.stopPropagation(), be.type === "dragenter" || be.type === "dragover" ? t(27, Q = !0) : be.type === "dragleave" && t(27, Q = !1);
  }, De = (C) => {
    if (P) {
      const be = C;
      be.preventDefault(), be.stopPropagation(), t(27, Q = !1), X && X.loadFilesFromDrop(be);
    }
  };
  function F() {
    L.dispatch("load_metadata");
  }
  const x = ({ detail: C }) => L.dispatch("select", C), H = ({ detail: C }) => L.dispatch("share", C), J = ({ detail: C }) => L.dispatch("error", C), T = ({ detail: C }) => {
    t(26, z = C);
  };
  function ke(C) {
    z = C, t(26, z);
  }
  const Se = () => L.dispatch("clear_status", b), I = (...C) => L.client.upload(...C);
  function q(C) {
    xn[C ? "unshift" : "push"](() => {
      X = C, t(29, X);
    });
  }
  function j(C) {
    te = C, t(25, te);
  }
  function V(C) {
    oe = C, t(28, oe);
  }
  function ce(C) {
    o = C, t(0, o);
  }
  function Ee(C) {
    Q = C, t(27, Q);
  }
  const S = () => L.dispatch("edit"), le = () => {
    L.dispatch("clear");
  }, Pe = ({ detail: C }) => t(27, Q = C), fe = () => L.dispatch("upload"), Ae = ({ detail: C }) => L.dispatch("select", C), Fe = ({ detail: C }) => L.dispatch("share", C), Me = ({ detail: C }) => {
    t(1, b = b || {}), t(1, b.status = "error", b), L.dispatch("error", C);
  }, Ct = ({ detail: C }) => {
    t(26, z = C);
  };
  function nn(C) {
    z = C, t(26, z);
  }
  return n.$$set = (C) => {
    "value_is_output" in C && t(33, i = C.value_is_output), "elem_id" in C && t(2, r = C.elem_id), "elem_classes" in C && t(3, a = C.elem_classes), "visible" in C && t(4, s = C.visible), "value" in C && t(0, o = C.value), "label" in C && t(5, l = C.label), "show_label" in C && t(6, c = C.show_label), "show_download_button" in C && t(7, u = C.show_download_button), "root" in C && t(8, f = C.root), "only_custom_metadata" in C && t(9, h = C.only_custom_metadata), "popup_metadata_width" in C && t(10, d = C.popup_metadata_width), "popup_metadata_height" in C && t(11, p = C.popup_metadata_height), "height" in C && t(12, v = C.height), "width" in C && t(13, w = C.width), "_selectable" in C && t(14, D = C._selectable), "container" in C && t(15, m = C.container), "scale" in C && t(16, _ = C.scale), "min_width" in C && t(17, g = C.min_width), "loading_status" in C && t(1, b = C.loading_status), "show_share_button" in C && t(18, E = C.show_share_button), "sources" in C && t(19, k = C.sources), "interactive" in C && t(20, P = C.interactive), "pending" in C && t(21, A = C.pending), "placeholder" in C && t(22, R = C.placeholder), "show_fullscreen_button" in C && t(23, B = C.show_fullscreen_button), "gradio" in C && t(24, L = C.gradio);
  }, n.$$.update = () => {
    n.$$.dirty[0] & /*uploading*/
    33554432, n.$$.dirty[0] & /*value, gradio*/
    16777217 | n.$$.dirty[1] & /*old_value, value_is_output*/
    12 && JSON.stringify(o) !== JSON.stringify(de) && (t(34, de = o), L.dispatch("change"), i || L.dispatch("input"));
  }, [
    o,
    b,
    r,
    a,
    s,
    l,
    c,
    u,
    f,
    h,
    d,
    p,
    v,
    w,
    D,
    m,
    _,
    g,
    E,
    k,
    P,
    A,
    R,
    B,
    L,
    te,
    z,
    Q,
    oe,
    X,
    ne,
    De,
    F,
    i,
    de,
    x,
    H,
    J,
    T,
    ke,
    Se,
    I,
    q,
    j,
    V,
    ce,
    Ee,
    S,
    le,
    Pe,
    fe,
    Ae,
    Fe,
    Me,
    Ct,
    nn
  ];
}
class hI extends xv {
  constructor(e) {
    super(), Ov(
      this,
      e,
      qv,
      zv,
      Lv,
      {
        value_is_output: 33,
        elem_id: 2,
        elem_classes: 3,
        visible: 4,
        value: 0,
        label: 5,
        show_label: 6,
        show_download_button: 7,
        root: 8,
        only_custom_metadata: 9,
        popup_metadata_width: 10,
        popup_metadata_height: 11,
        height: 12,
        width: 13,
        _selectable: 14,
        container: 15,
        scale: 16,
        min_width: 17,
        loading_status: 1,
        show_share_button: 18,
        sources: 19,
        interactive: 20,
        pending: 21,
        placeholder: 22,
        show_fullscreen_button: 23,
        gradio: 24
      },
      null,
      [-1, -1]
    );
  }
  get value_is_output() {
    return this.$$.ctx[33];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), he();
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), he();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), he();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), he();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), he();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), he();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), he();
  }
  get show_download_button() {
    return this.$$.ctx[7];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), he();
  }
  get root() {
    return this.$$.ctx[8];
  }
  set root(e) {
    this.$$set({ root: e }), he();
  }
  get only_custom_metadata() {
    return this.$$.ctx[9];
  }
  set only_custom_metadata(e) {
    this.$$set({ only_custom_metadata: e }), he();
  }
  get popup_metadata_width() {
    return this.$$.ctx[10];
  }
  set popup_metadata_width(e) {
    this.$$set({ popup_metadata_width: e }), he();
  }
  get popup_metadata_height() {
    return this.$$.ctx[11];
  }
  set popup_metadata_height(e) {
    this.$$set({ popup_metadata_height: e }), he();
  }
  get height() {
    return this.$$.ctx[12];
  }
  set height(e) {
    this.$$set({ height: e }), he();
  }
  get width() {
    return this.$$.ctx[13];
  }
  set width(e) {
    this.$$set({ width: e }), he();
  }
  get _selectable() {
    return this.$$.ctx[14];
  }
  set _selectable(e) {
    this.$$set({ _selectable: e }), he();
  }
  get container() {
    return this.$$.ctx[15];
  }
  set container(e) {
    this.$$set({ container: e }), he();
  }
  get scale() {
    return this.$$.ctx[16];
  }
  set scale(e) {
    this.$$set({ scale: e }), he();
  }
  get min_width() {
    return this.$$.ctx[17];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), he();
  }
  get loading_status() {
    return this.$$.ctx[1];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), he();
  }
  get show_share_button() {
    return this.$$.ctx[18];
  }
  set show_share_button(e) {
    this.$$set({ show_share_button: e }), he();
  }
  get sources() {
    return this.$$.ctx[19];
  }
  set sources(e) {
    this.$$set({ sources: e }), he();
  }
  get interactive() {
    return this.$$.ctx[20];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), he();
  }
  get pending() {
    return this.$$.ctx[21];
  }
  set pending(e) {
    this.$$set({ pending: e }), he();
  }
  get placeholder() {
    return this.$$.ctx[22];
  }
  set placeholder(e) {
    this.$$set({ placeholder: e }), he();
  }
  get show_fullscreen_button() {
    return this.$$.ctx[23];
  }
  set show_fullscreen_button(e) {
    this.$$set({ show_fullscreen_button: e }), he();
  }
  get gradio() {
    return this.$$.ctx[24];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), he();
  }
}
export {
  fI as BaseExample,
  xo as BaseImage,
  p2 as BaseImageUploader,
  x0 as BaseStaticImage,
  hI as default
};
