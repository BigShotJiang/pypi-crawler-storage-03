"""A pluggable service for preparing Open edX credentials."""
