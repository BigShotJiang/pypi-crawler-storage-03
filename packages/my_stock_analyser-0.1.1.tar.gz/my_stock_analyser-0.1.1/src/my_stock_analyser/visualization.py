"""
Visualization Module

This module provides functions for visualizing stock data and technical indicators.
"""
import os
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import seaborn as sns

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('visualization.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Set style
plt.style.use('ggplot')  # Using ggplot style instead of seaborn
sns.set_theme(style="whitegrid")  # Using set_theme for newer seaborn versions

class StockVisualizer:
    """Class for creating visualizations of stock data and technical indicators."""
    
    def __init__(self, data: pd.DataFrame, symbol: str):
        """
        Initialize the StockVisualizer.
        
        Args:
            data: DataFrame containing stock data and indicators
            symbol: Stock symbol (e.g., 'RELIANCE.BO')
        """
        self.data = data.copy()
        self.symbol = symbol
        self.company_name = self._get_company_name(symbol)
        self.output_dir = Path('reports') / 'charts'
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_company_name(self, symbol: str) -> str:
        """Get company name from symbol."""
        # Simple mapping, can be expanded or fetched from an API
        company_map = {
            'RELIANCE.BO': 'Reliance Industries',
            'TCS.BO': 'Tata Consultancy Services',
            'HDFCBANK.BO': 'HDFC Bank',
            'INFY.BO': 'Infosys',
            'ICICIBANK.BO': 'ICICI Bank',
            'HINDUNILVR.BO': 'Hindustan Unilever',
            'ITC.BO': 'ITC Limited',
            'BHARTIARTL.BO': 'Bharti Airtel',
            'SBIN.BO': 'State Bank of India',
            'KOTAKBANK.BO': 'Kotak Mahindra Bank',
            'HCLTECH.BO': 'HCL Technologies',
            'BAJFINANCE.BO': 'Bajaj Finance',
            'LT.BO': 'Larsen & Toubro',
            'ASIANPAINT.BO': 'Asian Paints',
            'AXISBANK.BO': 'Axis Bank',
            'MARUTI.BO': 'Maruti Suzuki',
            'SUNPHARMA.BO': 'Sun Pharma',
            'TITAN.BO': 'Titan Company',
            'ULTRACEMCO.BO': 'UltraTech Cement',
            'NESTLEIND.BO': 'Nestle India'
        }
        return company_map.get(symbol, symbol.split('.')[0])
    
    def _save_plot(self, fig, filename: str, width: int = 1200, height: int = 800) -> str:
        """Save plot to file and return the file path."""
        # Generate a clean filename from the symbol
        clean_symbol = self.symbol.replace('.', '_').lower()
        filepath = self.output_dir / f"{clean_symbol}_{filename}.html"
        
        # Save as HTML for interactive visualization
        fig.write_html(
            filepath,
            full_html=False,
            include_plotlyjs='cdn',
            default_width=f"{width}px",
            default_height=f"{height}px"
        )
        
        logger.info(f"Saved plot to {filepath}")
        return str(filepath)
    
    def plot_candlestick(self, days: int = 90) -> str:
        """
        Create an interactive candlestick chart with volume.
        
        Args:
            days: Number of days to display (default: 90)
            
        Returns:
            Path to the saved HTML file
        """
        logger.info(f"Creating candlestick chart for {self.symbol}")
        
        # Get the most recent data
        df = self.data.tail(days).copy()
        
        # Create subplots with shared x-axis
        fig = make_subplots(
            rows=2, 
            cols=1, 
            shared_xaxes=True, 
            vertical_spacing=0.05,
            row_heights=[0.7, 0.3],
            subplot_titles=(
                f"{self.company_name} ({self.symbol}) - Price",
                "Volume"
            )
        )
        
        # Add candlestick
        fig.add_trace(
            go.Candlestick(
                x=df.index,
                open=df['open'],
                high=df['high'],
                low=df['low'],
                close=df['close'],
                name='Price',
                increasing_line_color='#26a69a',
                decreasing_line_color='#ef5350'
            ),
            row=1, col=1
        )
        
        # Add volume bars
        colors = ['#26a69a' if close >= open_ else '#ef5350' 
                 for close, open_ in zip(df['close'], df['open'])]
        
        fig.add_trace(
            go.Bar(
                x=df.index,
                y=df['volume'],
                name='Volume',
                marker_color=colors,
                opacity=0.7
            ),
            row=2, col=1
        )
        
        # Update layout
        fig.update_layout(
            title=f"{self.company_name} ({self.symbol}) - Last {days} Days",
            xaxis_title="Date",
            yaxis_title="Price",
            xaxis_rangeslider_visible=False,
            showlegend=False,
            template='plotly_white',
            hovermode='x unified',
            height=800,
            margin=dict(l=50, r=50, t=80, b=50),
            xaxis2_title="Date",
            yaxis2_title="Volume"
        )
        
        # Update y-axes
        fig.update_yaxes(title_text="Price", row=1, col=1)
        fig.update_yaxes(title_text="Volume", row=2, col=1)
        
        # Add moving averages if they exist
        for ma in ['ma_20', 'ma_50', 'ma_200']:
            if ma in df.columns:
                fig.add_trace(
                    go.Scatter(
                        x=df.index,
                        y=df[ma],
                        name=ma.upper(),
                        line=dict(width=1.5),
                        opacity=0.7
                    ),
                    row=1, col=1
                )
        
        # Save and return
        return self._save_plot(fig, f"candlestick_{days}d")
    
    def plot_technical_indicators(self, days: int = 180) -> str:
        """
        Create a dashboard of technical indicators.
        
        Args:
            days: Number of days to display (default: 180)
            
        Returns:
            Path to the saved HTML file
        """
        logger.info(f"Creating technical indicators dashboard for {self.symbol}")
        
        # Get the most recent data
        df = self.data.tail(days).copy()
        
        # Create subplots with shared x-axis
        fig = make_subplots(
            rows=4, 
            cols=1, 
            shared_xaxes=True,
            vertical_spacing=0.05,
            row_heights=[0.5, 0.2, 0.2, 0.2],
            subplot_titles=(
                f"{self.company_name} ({self.symbol}) - Price",
                "Relative Strength Index (RSI)",
                "Moving Average Convergence Divergence (MACD)",
                "Bollinger Bands %B"
            )
        )
        
        # 1. Price with Bollinger Bands
        fig.add_trace(
            go.Candlestick(
                x=df.index,
                open=df['open'],
                high=df['high'],
                low=df['low'],
                close=df['close'],
                name='Price',
                increasing_line_color='#26a69a',
                decreasing_line_color='#ef5350'
            ),
            row=1, col=1
        )
        
        # Add Bollinger Bands if available
        if all(col in df.columns for col in ['bb_upper', 'bb_middle', 'bb_lower']):
            # Upper band
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['bb_upper'],
                    name='BB Upper',
                    line=dict(color='rgba(200, 200, 200, 0.7)', width=1),
                    showlegend=False
                ),
                row=1, col=1
            )
            
            # Middle band
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['bb_middle'],
                    name='BB Middle',
                    line=dict(color='rgba(100, 100, 100, 0.7)', width=1, dash='dash'),
                    showlegend=False
                ),
                row=1, col=1
            )
            
            # Lower band
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['bb_lower'],
                    name='BB Lower',
                    line=dict(color='rgba(200, 200, 200, 0.7)', width=1),
                    fill='tonexty',
                    fillcolor='rgba(200, 200, 200, 0.1)',
                    showlegend=False
                ),
                row=1, col=1
            )
        
        # 2. RSI
        if 'rsi' in df.columns:
            # RSI line
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['rsi'],
                    name='RSI',
                    line=dict(color='#2196F3', width=2)
                ),
                row=2, col=1
            )
            
            # Overbought and oversold lines
            fig.add_hline(
                y=70, 
                line_dash='dash', 
                line_color='red', 
                opacity=0.5,
                row=2, col=1
            )
            
            fig.add_hline(
                y=30, 
                line_dash='dash', 
                line_color='green', 
                opacity=0.5,
                row=2, col=1
            )
            
            # Fill between RSI levels
            fig.add_hrect(
                y0=70, y1=100, 
                fillcolor='red', 
                opacity=0.1, 
                layer="below",
                row=2, col=1
            )
            
            fig.add_hrect(
                y0=0, y1=30, 
                fillcolor='green', 
                opacity=0.1, 
                layer="below",
                row=2, col=1
            )
        
        # 3. MACD
        if all(col in df.columns for col in ['macd_line', 'macd_signal']):
            # MACD line
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['macd_line'],
                    name='MACD',
                    line=dict(color='#2196F3', width=2)
                ),
                row=3, col=1
            )
            
            # Signal line
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['macd_signal'],
                    name='Signal',
                    line=dict(color='#FF9800', width=1.5)
                ),
                row=3, col=1
            )
            
            # Histogram
            colors = ['#26a69a' if val >= 0 else '#ef5350' 
                     for val in df['macd_hist']]
            
            fig.add_trace(
                go.Bar(
                    x=df.index,
                    y=df['macd_hist'],
                    name='Histogram',
                    marker_color=colors,
                    opacity=0.7
                ),
                row=3, col=1
            )
            
            # Zero line
            fig.add_hline(
                y=0, 
                line_color='black', 
                opacity=0.5,
                row=3, col=1
            )
        
        # 4. Bollinger Bands %B
        if 'bb_%b' in df.columns:
            # %B line
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df['bb_%b'],
                    name='%B',
                    line=dict(color='#9C27B0', width=2)
                ),
                row=4, col=1
            )
            
            # Overbought and oversold lines
            for level, color, y in [
                ('Upper', 'red', 100),
                ('Middle', 'black', 50),
                ('Lower', 'green', 0)
            ]:
                fig.add_hline(
                    y=y,
                    line_dash='dash',
                    line_color=color,
                    opacity=0.5,
                    row=4, col=1,
                    annotation_text=level if y != 50 else 'Middle',
                    annotation_position="right"
                )
        
        # Update layout
        fig.update_layout(
            title=f"{self.company_name} ({self.symbol}) - Technical Indicators",
            showlegend=False,
            template='plotly_white',
            height=1200,
            margin=dict(l=50, r=50, t=100, b=50),
            hovermode='x unified'
        )
        
        # Update y-axes
        fig.update_yaxes(title_text="Price", row=1, col=1)
        fig.update_yaxes(title_text="RSI", row=2, col=1)
        fig.update_yaxes(title_text="MACD", row=3, col=1)
        fig.update_yaxes(title_text="BB %B", row=4, col=1)
        
        # Update x-axes
        for i in range(1, 5):
            fig.update_xaxes(
                showgrid=True, 
                row=i, 
                col=1
            )
        
        # Save and return
        return self._save_plot(fig, "technical_indicators", height=1200)
    
    def plot_fundamentals(self, fundamentals: Dict) -> str:
        """
        Create a dashboard of fundamental metrics.
        
        Args:
            fundamentals: Dictionary of fundamental metrics
            
        Returns:
            Path to the saved HTML file
        """
        logger.info(f"Creating fundamentals dashboard for {self.symbol}")
        
        # Prepare data for visualization
        metrics = [
            ('Valuation', 'P/E Ratio', 'pe_ratio'),
            ('Valuation', 'Forward P/E', 'forward_pe'),
            ('Valuation', 'PEG Ratio', 'peg_ratio'),
            ('Valuation', 'Price/Book', 'price_to_book'),
            ('Valuation', 'Price/Sales', 'price_to_sales'),
            ('Valuation', 'Enterprise Value/Revenue', 'enterprise_to_revenue'),
            ('Valuation', 'Enterprise Value/EBITDA', 'enterprise_to_ebitda'),
            
            ('Profitability', 'Return on Equity', 'return_on_equity'),
            ('Profitability', 'Profit Margin', 'profit_margins'),
            ('Profitability', 'Operating Margin', 'operating_margins'),
            
            ('Financial Health', 'Debt/Equity', 'debt_to_equity'),
            ('Financial Health', 'Current Ratio', 'current_ratio'),
            ('Financial Health', 'Total Debt', 'total_debt'),
            ('Financial Health', 'Total Cash', 'total_cash'),
            
            ('Dividend', 'Dividend Yield', 'dividend_yield'),
            ('Dividend', 'Last Dividend Value', 'last_dividend_value'),
            
            ('Market', 'Beta', 'beta'),
            ('Market', '52-Week High', 'fifty_two_week_high'),
            ('Market', '52-Week Low', 'fifty_two_week_low'),
            ('Market', '50-Day MA', 'fifty_day_average'),
            ('Market', '200-Day MA', 'two_hundred_day_average'),
            ('Market', 'Market Cap (Cr)', 'market_cap'),
            ('Market', 'Enterprise Value (Cr)', 'enterprise_value')
        ]
        
        # Filter out metrics that don't have data
        data = []
        for category, name, key in metrics:
            value = fundamentals.get(key)
            if value is not None:
                # Convert market cap and enterprise value to Crores
                if key in ['market_cap', 'enterprise_value'] and value is not None:
                    value = value / 10**7  # Convert to Crores
                data.append({
                    'Category': category,
                    'Metric': name,
                    'Value': value
                })
        
        if not data:
            logger.warning("No fundamental data available for visualization")
            return ""
        
        # Create figure with subplots
        fig = make_subplots(
            rows=2, 
            cols=2,
            subplot_titles=(
                "Valuation Metrics",
                "Profitability & Growth",
                "Financial Health",
                "Dividend & Market Data"
            ),
            vertical_spacing=0.12,
            horizontal_spacing=0.1,
            specs=[
                [{"type": "bar"}, {"type": "bar"}],
                [{"type": "bar"}, {"type": "bar"}]
            ]
        )
        
        # Group data by category
        categories = {}
        for item in data:
            if item['Category'] not in categories:
                categories[item['Category']] = []
            categories[item['Category']].append(item)
        
        # Define subplot positions for each category
        category_positions = {
            'Valuation': (1, 1),
            'Profitability': (1, 2),
            'Financial Health': (2, 1),
            'Dividend': (2, 2),
            'Market': (2, 2)
        }
        
        # Add traces for each category
        for category, items in categories.items():
            row, col = category_positions.get(category, (1, 1))
            
            # Sort items by absolute value for better visualization
            items = sorted(items, key=lambda x: abs(x['Value']) if x['Value'] is not None else 0, reverse=True)
            
            # Prepare data for plotting
            x = [item['Metric'] for item in items]
            y = [item['Value'] for item in items]
            
            # Determine colors based on values (green for good, red for bad, blue for neutral)
            colors = []
            for item in items:
                metric = item['Metric'].lower()
                value = item['Value']
                
                if value is None:
                    colors.append('lightgray')
                elif 'ratio' in metric or 'margin' in metric or 'return' in metric:
                    # Higher is better (green for high values)
                    colors.append('rgba(76, 175, 80, 0.7)')
                elif 'debt' in metric or 'beta' in metric:
                    # Lower is better (red for high values)
                    colors.append('rgba(244, 67, 54, 0.7)' if (value or 0) > 0 else 'rgba(76, 175, 80, 0.7)')
                else:
                    # Neutral (blue)
                    colors.append('rgba(33, 150, 243, 0.7)')
            
            # Add bar trace
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=y,
                    name=category,
                    marker_color=colors,
                    text=[f"{v:.2f}" if isinstance(v, (int, float)) else str(v) for v in y],
                    textposition='auto',
                    hoverinfo='text',
                    hovertext=[f"{k}: {v:.2f}" if isinstance(v, (int, float)) else f"{k}: {v}" 
                              for k, v in zip(x, y)]
                ),
                row=row, col=col
            )
            
            # Add reference lines for important metrics
            if category == 'Valuation':
                # Add reference line at P/E = 20 (market average)
                fig.add_hline(
                    y=20,
                    line_dash='dash',
                    line_color='red',
                    opacity=0.5,
                    row=row, col=col,
                    annotation_text="Market Avg P/E=20",
                    annotation_position="top right"
                )
            
            if category == 'Financial Health':
                # Add reference line at D/E = 1
                fig.add_hline(
                    y=1,
                    line_dash='dash',
                    line_color='red',
                    opacity=0.5,
                    row=row, col=col,
                    annotation_text="D/E=1",
                    annotation_position="top right"
                )
        
        # Update layout
        fig.update_layout(
            title=f"{self.company_name} ({self.symbol}) - Fundamental Analysis",
            showlegend=False,
            template='plotly_white',
            height=1200,
            margin=dict(l=50, r=50, t=100, b=50),
            hovermode='closest'
        )
        
        # Update y-axes
        fig.update_yaxes(title_text="Value", row=1, col=1)
        fig.update_yaxes(title_text="Value", row=1, col=2)
        fig.update_yaxes(title_text="Value", row=2, col=1)
        fig.update_yaxes(title_text="Value", row=2, col=2)
        
        # Rotate x-axis labels
        fig.update_xaxes(tickangle=45)
        
        # Save and return
        return self._save_plot(fig, "fundamentals", height=1200)
    
    def plot_correlation_heatmap(self, symbols: List[str], data_dict: Dict[str, pd.DataFrame]) -> str:
        """
        Create a correlation heatmap for multiple stocks.
        
        Args:
            symbols: List of stock symbols
            data_dict: Dictionary mapping symbols to DataFrames with 'close' column
            
        Returns:
            Path to the saved HTML file
        """
        logger.info("Creating correlation heatmap")
        
        # Prepare data for correlation
        close_prices = pd.DataFrame()
        
        for symbol in symbols:
            if symbol in data_dict and 'close' in data_dict[symbol].columns:
                close_prices[symbol] = data_dict[symbol]['close']
        
        if close_prices.empty:
            logger.warning("No valid price data for correlation analysis")
            return ""
        
        # Calculate returns
        returns = close_prices.pct_change().dropna()
        
        # Calculate correlation matrix
        corr = returns.corr()
        
        # Create heatmap
        fig = go.Figure(data=go.Heatmap(
            z=corr.values,
            x=corr.columns,
            y=corr.index,
            colorscale='RdBu',
            zmin=-1,
            zmax=1,
            colorbar=dict(title='Correlation'),
            hoverongaps=False
        ))
        
        # Update layout
        fig.update_layout(
            title='Stock Returns Correlation Heatmap',
            xaxis_title='Stocks',
            yaxis_title='Stocks',
            template='plotly_white',
            height=800,
            margin=dict(l=100, r=50, t=100, b=100),
            xaxis=dict(tickangle=45)
        )
        
        # Add annotations
        for i, row in enumerate(corr.values):
            for j, value in enumerate(row):
                fig.add_annotation(
                    x=corr.columns[j],
                    y=corr.index[i],
                    text=f"{value:.2f}",
                    showarrow=False,
                    font=dict(
                        size=10,
                        color='black' if abs(value) < 0.7 else 'white'
                    )
                )
        
        # Save and return
        return self._save_plot(fig, "correlation_heatmap")
    
    def generate_all_visualizations(self, fundamentals: Optional[Dict] = None, sector_performance: Optional[List[Dict]] = None) -> Dict[str, str]:
        """
        Generate all available visualizations.
        
        Args:
            fundamentals: Optional dictionary of fundamental metrics
            sector_performance: Optional list of sector performance data
            
        Returns:
            Dictionary mapping visualization names to file paths
        """
        visualizations = {}
        
        try:
            # Generate candlestick chart
            visualizations['candlestick'] = self.plot_candlestick(days=90)
            
            # Generate technical indicators dashboard
            visualizations['technical_indicators'] = self.plot_technical_indicators(days=180)
            
            # Generate fundamentals dashboard if data is provided
            if fundamentals:
                visualizations['fundamentals'] = self.plot_fundamentals(fundamentals)
            
            # Generate sector performance chart if data is available and this is NIFTY 50
            if sector_performance and self.symbol == '^NSEI':
                sector_chart = self.create_sector_performance_chart(sector_performance)
                if sector_chart:
                    visualizations['sector_performance'] = sector_chart
            
            return visualizations
            
        except Exception as e:
            logger.error(f"Error generating visualizations: {e}")
            return visualizations
            
    def create_sector_performance_chart(self, sector_performance: List[Dict]) -> str:
        """
        Create a chart showing sector performance and weight in NIFTY 50.
        
        Args:
            sector_performance: List of dictionaries with sector performance data
            
        Returns:
            Path to the saved HTML file
        """
        try:
            # Convert to DataFrame for easier manipulation
            df = pd.DataFrame(sector_performance)
            
            # Create figure with secondary y-axis
            fig = make_subplots(specs=[[{"secondary_y": True}]])
            
            # Add bar chart for sector weights
            fig.add_trace(
                go.Bar(
                    x=df['sector'],
                    y=df['weight'],
                    name='Sector Weight (%)',
                    marker_color='#3498db',
                    opacity=0.7,
                    hovertemplate=
                        '<b>%{x}</b><br>' +
                        'Weight: %{y:.1f}%<br>' +
                        'Return: %{customdata[0]:.1f}%<br>' +
                        'Stocks Analyzed: %{customdata[1]}<extra></extra>',
                    customdata=df[['return', 'stocks_analyzed']],
                ),
                secondary_y=False,
            )
            
            # Add line chart for sector returns
            fig.add_trace(
                go.Scatter(
                    x=df['sector'],
                    y=df['return'],
                    name='1M Return (%)',
                    line=dict(color='#e74c3c', width=3),
                    mode='lines+markers',
                    yaxis='y2',
                    hovertemplate='%{y:.1f}%<extra></extra>',
                ),
                secondary_y=True,
            )
            
            # Create version-specific axis configurations
            import plotly
            
            # For yaxis (left)
            yaxis_config = {
                'title': 'Sector Weight (%)',
                'tickfont': {'color': '#3498db'},
                'range': [0, max(df['weight']) * 1.2],
            }
            
            # For yaxis2 (right)
            yaxis2_config = {
                'title': '1M Return (%)',
                'tickfont': {'color': '#e74c3c'},
                'overlaying': 'y',
                'side': 'right',
                'range': [min(df['return']) * 1.5, max(df['return']) * 1.5],
            }
            
            # Handle different Plotly versions
            if plotly.__version__ >= '5.0.0':
                yaxis_config['title_font'] = {'color': '#3498db'}
                yaxis2_config['title_font'] = {'color': '#e74c3c'}
            else:
                yaxis_config['titlefont'] = {'color': '#3498db'}
                yaxis2_config['titlefont'] = {'color': '#e74c3c'}
            
            # Update layout with version-specific configurations
            layout = {
                'title': {
                    'text': 'NIFTY 50 Sector Performance',
                    'x': 0.5,
                    'xanchor': 'center',
                    'font': {'size': 20}
                },
                'xaxis': {
                    'title': 'Sector',
                    'tickangle': 45,
                    'tickfont': {'size': 10},
                },
                'yaxis': yaxis_config,
                'yaxis2': yaxis2_config,
                'legend': {
                    'orientation': 'h',
                    'yanchor': 'bottom',
                    'y': 1.02,
                    'xanchor': 'right',
                    'x': 1
                },
                'plot_bgcolor': 'rgba(0,0,0,0)',
                'paper_bgcolor': 'rgba(0,0,0,0)',
                'margin': dict(l=50, r=50, t=80, b=100),
                'height': 600,
                'hovermode': 'x unified',
            }
            
            # Apply the layout with error handling
            try:
                fig.update_layout(**layout)
            except Exception as e:
                # Fallback to minimal configuration if there's an error
                logger.warning(f"Error updating layout: {e}")
                fig.update_layout(
                    title='NIFTY 50 Sector Performance',
                    xaxis_title='Sector',
                    yaxis_title='Sector Weight (%)',
                    yaxis2_title='1M Return (%)',
                    height=600
                )
            
            # Save the figure
            output_file = self.output_dir / f"{self.symbol.lower().replace('^', '').replace('.', '_')}_sector_performance.html"
            fig.write_html(
                output_file,
                full_html=False,
                include_plotlyjs='cdn',
                config={'displayModeBar': True}
            )
            
            logger.info(f"Saved sector performance chart to {output_file}")
            return str(output_file)
            
        except Exception as e:
            logger.error(f"Error creating sector performance chart: {e}")
            return ""

if __name__ == "__main__":
    # Example usage
    import yfinance as yf
    
    # Fetch sample data
    symbol = 'RELIANCE.BO'
    data = yf.download(symbol, period='1y')
    
    # Initialize visualizer
    visualizer = StockVisualizer(data, symbol)
    
    # Generate visualizations
    visualizations = visualizer.generate_all_visualizations()
    
    print("Generated visualizations:")
    for name, path in visualizations.items():
        print(f"- {name}: {path}")
