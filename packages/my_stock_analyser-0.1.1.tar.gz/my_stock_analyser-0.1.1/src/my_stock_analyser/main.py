"""
Stock Analysis Tool

A comprehensive tool for analyzing Indian stocks with technical and fundamental analysis.
"""
import json
import os
import sys
import logging
import argparse
import smtplib
import signal
import shutil
import time
import base64
from datetime import datetime, time as dt_time, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any

import pandas as pd
import numpy as np
from dotenv import load_dotenv

# Add the parent directory to the path
sys.path.append(str(Path(__file__).parent.parent))

# Import local modules
from src.data_fetcher import DataFetcher, get_top_bse_stocks, validate_stock_symbol
from src.technical_analysis import TechnicalAnalysis, calculate_fundamental_metrics
from src.visualization import StockVisualizer  # Absolute import from src package
from src.scheduler import schedule_analysis, AnalysisScheduler
from config.config import (
    EMAIL_CONFIG, 
    DEFAULT_PARAMS, 
    INDICATORS,
    TOP_BSE_STOCKS,
    REPORTS_DIR
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Ensure reports directory exists
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

class StockAnalyzer:
    """Main class for stock analysis application."""
    
    def __init__(self, symbols: List[str] = None, days: int = 365):
        """
        Initialize the StockAnalyzer.
        
        Args:
            symbols: List of stock symbols to analyze (default: top BSE stocks)
            days: Number of days of historical data to fetch (default: 365)
        """
        self.symbols = symbols or TOP_BSE_STOCKS
        self.days = days
        self.data_fetcher = DataFetcher()
        self.report_data = {}
        self.visualizations = {}
    
    def fetch_data(self) -> Dict[str, pd.DataFrame]:
        """
        Fetch data for all symbols.
        
        Returns:
            Dictionary mapping symbols to DataFrames with stock data
        """
        logger.info(f"Fetching data for {len(self.symbols)} stocks...")
        return self.data_fetcher.fetch_multiple_stocks(self.symbols, self.days)
    
    def analyze_stock(self, symbol: str, data: pd.DataFrame) -> Dict:
        """
        Perform technical and fundamental analysis on a stock.
        
        Args:
            symbol: Stock symbol
            data: DataFrame with stock data
            
        Returns:
            Dictionary with analysis results
        """
        logger.info(f"Analyzing {symbol}...")
        
        # Technical Analysis
        ta = TechnicalAnalysis(data)
        data_with_indicators = ta.calculate_all_indicators()
        
        # Fundamental Analysis
        fundamentals = calculate_fundamental_metrics(symbol)
        
        # Generate visualizations
        visualizer = StockVisualizer(data_with_indicators, symbol)
        charts = visualizer.generate_all_visualizations(fundamentals)
        
        # Store results
        self.visualizations[symbol] = charts
        
        # Prepare analysis summary
        latest = data_with_indicators.iloc[-1].to_dict()
        
        analysis = {
            'symbol': symbol,
            'latest_price': latest.get('close'),
            'change_pct': (latest.get('close', 0) / data_with_indicators['close'].iloc[-2] - 1) * 100 \
                          if len(data_with_indicators) > 1 else 0,
            'volume': latest.get('volume'),
            'rsi': latest.get('rsi'),
            'ma_20': latest.get('ma_20'),
            'ma_50': latest.get('ma_50'),
            'ma_200': latest.get('ma_200'),
            'bb_upper': latest.get('bb_upper'),
            'bb_middle': latest.get('bb_middle'),
            'bb_lower': latest.get('bb_lower'),
            'macd': latest.get('macd_line'),
            'macd_signal': latest.get('macd_signal'),
            'fundamentals': fundamentals,
            'charts': list(charts.values()) if charts else []
        }
        
        return analysis
    
    def generate_report(self, analysis_results: dict, for_email: bool = False, return_html: bool = False) -> tuple:
        """
        Generate an HTML report from the analysis results.
        
        Args:
            analysis_results: List of dictionaries containing analysis results
            for_email: Whether the report is being generated for email
            return_html: Whether to return the HTML content along with the file path
            
        Returns:
            tuple: (html_content, report_path) if return_html is True, else (None, report_path)
        """
        logger.info(f"Starting report generation with {len(analysis_results)} analysis results")
        
        # Create reports directory if it doesn't exist
        os.makedirs('reports', exist_ok=True)
        os.makedirs('reports/charts', exist_ok=True)
        
        # Generate timestamp for the report
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_path = f'reports/stock_analysis_report_{timestamp}.html'
        
        # Log the symbols being included in the report
        symbols = [r.get('symbol', 'unknown') for r in analysis_results]
        logger.info(f"Generating report for symbols: {', '.join(symbols) if symbols else 'None'}")
        
        # Log the structure of the first analysis result for debugging
        if analysis_results:
            sample_result = analysis_results[0]
            logger.debug(f"Sample analysis result structure for {sample_result.get('symbol', 'unknown')}:")
            for key, value in sample_result.items():
                if key != 'charts':
                    logger.debug(f"  {key}: {type(value)}")
                    if isinstance(value, dict):
                        logger.debug(f"    {value.keys()}")
                    elif isinstance(value, (list, tuple)) and value and isinstance(value[0], dict):
                        logger.debug(f"    List of dicts with keys: {value[0].keys() if value else 'empty'}")
                    elif isinstance(value, pd.DataFrame):
                        logger.debug(f"    DataFrame with columns: {value.columns.tolist()}")
                        logger.debug(f"    First few rows: {value.head().to_dict('records')}")
                    else:
                        logger.debug(f"    {value}")
        else:
            logger.warning("No analysis results provided to generate_report")
        
        # Store chart paths for email attachments
        chart_paths = []
        
        # Start building the HTML content
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Stock Analysis Report</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {{ 
                    font-family: Arial, sans-serif; 
                    line-height: 1.6; 
                    margin: 0; 
                    padding: 20px; 
                    color: #333; 
                    background-color: #f5f7fa;
                }}
                .container {{ 
                    max-width: 1200px; 
                    margin: 0 auto; 
                }}
                .report-header {{ 
                    text-align: center; 
                    margin-bottom: 30px; 
                    padding: 20px; 
                    background: #2a5298; 
                    color: white; 
                    border-radius: 8px;
                }}
                .stock-card {{ 
                    background: white; 
                    border-radius: 8px; 
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
                    margin-bottom: 30px; 
                    overflow: hidden;
                }}
                .stock-header {{ 
                    display: flex; 
                    justify-content: space-between; 
                    align-items: center; 
                    padding: 15px 20px;
                    background: linear-gradient(135deg, #1e3c72, #2a5298);
                    color: white;
                }}
                .stock-symbol {{ 
                    font-size: 24px; 
                    font-weight: 700; 
                    margin: 0;
                }}
                .stock-price {{ 
                    font-size: 22px; 
                    font-weight: 600;
                }}
                .positive {{ color: #28a745; }}
                .negative {{ color: #dc3545; }}
                .neutral {{ color: #6c757d; }}
                .metrics {{ 
                    padding: 15px 20px; 
                }}
                .metrics h3 {{
                    color: #2a5298;
                    margin-top: 0;
                    padding-bottom: 10px;
                    border-bottom: 2px solid #f0f4f8;
                }}
                .metrics-table {{
                    width: 100%;
                    border-collapse: collapse;
                    margin: 15px 0;
                }}
                .metrics-table th, .metrics-table td {{
                    padding: 12px 15px;
                    text-align: left;
                    border-bottom: 1px solid #eee;
                }}
                .metrics-table th {{
                    background-color: #f8fafd;
                    font-weight: 600;
                    color: #2a5298;
                }}
                .metrics-table tr:hover {{
                    background-color: #f8f9fa;
                }}
                .chart-container {{
                    margin: 20px 0;
                    padding: 20px;
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                }}
                .chart-title {{
                    font-size: 18px;
                    font-weight: 600;
                    color: #2a5298;
                    margin: 0 0 15px 0;
                }}
                .fundamentals {{
                    padding: 0 20px 20px;
                }}
                .fundamentals h3 {{
                    color: #2a5298;
                    margin: 25px 0 15px;
                    font-size: 1.3em;
                    border-bottom: 2px solid #f0f4f8;
                    padding-bottom: 8px;
                }}
                .fundamental-grid {{
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                    width: 100%;
                }}
                .fundamental-row {{
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    margin-bottom: 15px;
                }}
                .fundamental-section {{
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
                    overflow: hidden;
                    flex: 1;
                    min-width: calc(50% - 10px);
                    transition: transform 0.2s, box-shadow 0.2s;
                }}
                .fundamental-section:hover {{
                    transform: translateY(-2px);
                    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
                }}
                .fundamental-section h4 {{
                    margin: 0;
                    padding: 14px 18px;
                    background: linear-gradient(135deg, #f8fafd, #eef2f7);
                    color: #2a5298;
                    font-size: 15px;
                    font-weight: 600;
                    border-bottom: 1px solid #e1e8ed;
                    letter-spacing: 0.3px;
                }}
                .fundamental-table-container {{
                    padding: 5px 0;
                    max-height: 300px;
                    overflow-y: auto;
                }}
                .fundamental-table {{
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 14px;
                }}
                .fundamental-table th, 
                .fundamental-table td {{
                    padding: 10px 18px;
                    text-align: left;
                    border-bottom: 1px solid #f0f4f8;
                    line-height: 1.5;
                }}
                .fundamental-table th {{
                    font-weight: 600;
                    color: #4a5568;
                    background-color: transparent;
                    width: 55%;
                    white-space: nowrap;
                    padding-right: 10px;
                }}
                .fundamental-table td {{
                    color: #2d3748;
                    font-family: 'Courier New', monospace;
                    font-weight: 500;
                    text-align: right;
                    padding-right: 20px;
                }}
                .fundamental-table tr:last-child th,
                .fundamental-table tr:last-child td {{
                    border-bottom: none;
                }}
                .fundamental-table tr:hover {{
                    background-color: #f9fafc;
                }}
                /* Color coding for positive/negative values */
                .positive {{ color: #28a745; font-weight: 600; }}
                .negative {{ color: #dc3545; font-weight: 600; }}
                /* Scrollbar styling */
                .fundamental-table-container::-webkit-scrollbar {{
                    width: 6px;
                    height: 6px;
                }}
                .fundamental-table-container::-webkit-scrollbar-track {{
                    background: #f1f1f1;
                    border-radius: 3px;
                }}
                .fundamental-table-container::-webkit-scrollbar-thumb {{
                    background: #c1c1c1;
                    border-radius: 3px;
                }}
                .fundamental-table-container::-webkit-scrollbar-thumb:hover {{
                    background: #a8a8a8;
                }}
                .recommendation {{
                    padding: 15px 20px;
                    font-weight: 600;
                    text-align: center;
                    font-size: 18px;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                }}
                .recommendation.buy, .recommendation.strong-buy {{
                    background-color: #e6f7ee;
                    color: #28a745;
                    border-left: 5px solid #28a745;
                }}
                .recommendation.sell, .recommendation.strong-sell {{
                    background-color: #fce8e6;
                    color: #dc3545;
                    border-left: 5px solid #dc3545;
                }}
                .recommendation.hold {{
                    background-color: #fff8e1;
                    color: #ffc107;
                    border-left: 5px solid #ffc107;
                }}
                @media (max-width: 768px) {{
                    .stock-header {{
                        flex-direction: column;
                        text-align: center;
                    }}
                    .metrics-table th, .metrics-table td {{
                        padding: 10px 12px;
                        font-size: 14px;
                    }}
                    .fundamental-grid {{
                        grid-template-columns: 1fr;
                    }}
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="report-header">
                    <h1>Stock Analysis Report</h1>
                    <p>Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Analysis Period: {self.days} days</p>
                </div>
        """
        
        # Process each stock's analysis results
        for result in analysis_results:
            if not result:
                continue
                
            # Extract data from result
            symbol = result.get('symbol', '')
            price = result.get('latest_price', result.get('price', 0))
            change_pct = result.get('change_pct', 0)
            
            # Handle pandas Series/DataFrame by taking the last value if it's a Series
            def get_scalar_value(value):
                if hasattr(value, 'iloc') and len(value) > 0:
                    return value.iloc[-1]
                if hasattr(value, 'item'):  # For single-item Series/DataFrame
                    return value.item()
                return value if value is not None else 0
            
            # Convert all values to scalars
            price = get_scalar_value(price)
            change_pct = get_scalar_value(change_pct)
            
            # Now handle the comparison with proper None/Series handling
            if change_pct is None:
                change_icon = ''
                change_class = ''
            else:
                change_icon = '↑' if change_pct >= 0 else '↓'
                change_class = 'positive' if change_pct >= 0 else 'negative'
            
            # Generate recommendation
            recommendation, reasoning = self._generate_recommendation(result)
            
            # Technical indicators with proper None handling
            def safe_format(value, format_str='.2f', default='N/A'):
                if value is None:
                    return default
                try:
                    return f"{float(value):{format_str}}" if format_str else str(value)
                except (ValueError, TypeError):
                    return default
            
            # Get MACD values with proper None handling
            macd = result.get('macd')
            macd_signal = result.get('macd_signal')
            macd_value = safe_format(macd, '.2f')
            macd_class = 'positive' if macd and macd_signal and macd > macd_signal else 'negative' if macd and macd_signal and macd < macd_signal else 'neutral'
            
            # Prepare metrics
            metrics = [
                ('RSI (14)', safe_format(result.get('rsi'), '.2f'), self._get_rsi_class(result.get('rsi'))),
                ('50-Day MA', safe_format(result.get('ma_50'), '.2f'), 'neutral'),
                ('200-Day MA', safe_format(result.get('ma_200'), '.2f'), 'neutral'),
                ('52W High', safe_format(result.get('52w_high'), '.2f'), 'neutral'),
                ('52W Low', safe_format(result.get('52w_low'), '.2f'), 'neutral'),
                ('Volume', safe_format(result.get('volume'), ','), 'neutral'),
                ('MACD', macd_value, macd_class),
                ('MACD Signal', safe_format(result.get('macd_signal'), '.2f'), 'neutral')
            ]
            
            # Prepare charts HTML
            charts_html = ''
            if result.get('charts'):
                for chart_path in result['charts']:
                    if chart_path:
                        chart_filename = os.path.basename(chart_path)
                        chart_name = chart_filename.replace('.html', '').replace('_', ' ').title()
                        
                        if 'sector_performance' in chart_path:
                            chart_name = 'Sector Performance'
                        
                        chart_full_path = os.path.join('reports', 'charts', chart_filename)
                        if os.path.exists(chart_full_path):
                            if for_email:
                                # For email, we'll embed the chart as an image
                                try:
                                    # Add chart path for email attachments
                                    chart_paths.append(chart_full_path)
                                    
                                    # Generate a unique ID for the chart
                                    chart_id = f"chart_{symbol}_{chart_name.replace(' ', '_').lower()}"
                                    
                                    # Add a placeholder that will be replaced with the actual image in _convert_charts_to_images
                                    charts_html += f"""
                                    <div class="chart-container">
                                        <h3 class="chart-title">{chart_name}</h3>
                                        <div class="chart-placeholder" data-chart-path="{chart_full_path}" id="{chart_id}">
                                            Loading chart...
                                        </div>
                                    </div>
                                    """
                                except Exception as e:
                                    logger.error(f"Error preparing chart {chart_path} for email: {e}")
                                    charts_html += f"<p>Error loading chart: {chart_name}</p>"
                            else:
                                # For HTML report, use iframe
                                charts_html += f"""
                                <div class="chart-container">
                                    <h3 class="chart-title">{chart_name}</h3>
                                    <iframe src="charts/{chart_filename}" style="width:100%; height:500px; border:none;"></iframe>
                                </div>
                                """
            
            # Create stock card
            stock_card = f"""
            <div class="stock-card">
                <div class="stock-header">
                    <div class="stock-symbol">{symbol}</div>
                    <div class="stock-price">₹{price:,.2f} <span class='{change_class}'>({change_icon} {abs(change_pct):.2f}%)</span></div>
                </div>
                
                <div class="recommendation {recommendation.lower().replace(' ', '-')}">
                    <strong>{recommendation}:</strong>
                    <div class="analysis-section">
                        <p>{reasoning}</p>
                    </div>
                </div>
                
                <div class="metrics">
                    <h3>Key Metrics</h3>
                    <table class="metrics-table">
                        <thead>
                            <tr>
                                <th>Metric</th>
                                <th>Value</th>
                            </tr>
                        </thead>
                        <tbody>
            """.format(
                recommendation.lower().replace(' ', '-'),
                recommendation.upper(),
                reasoning
            )
            
            # Add metrics rows
            for label, value, css_class in metrics:
                stock_card += f"""
                            <tr>
                                <td>{label}</td>
                                <td class="{css_class}">{value}</td>
                            </tr>
                """
            
            # Close metrics table
            stock_card += """
                        </tbody>
                    </table>
                </div>
            """
            
            # Add fundamental analysis sections if available
            if result.get('fundamentals'):
                # Group metrics into categories
                metric_groups = {
                    'Valuation': ['pe_ratio', 'forward_pe', 'peg_ratio', 'price_to_book', 'price_to_sales', 'enterprise_value'],
                    'Financial Health': ['current_ratio', 'quick_ratio', 'debt_to_equity', 'interest_coverage', 'total_debt'],
                    'Profitability': ['gross_margin', 'operating_margin', 'net_margin', 'return_on_assets', 'return_on_equity', 'return_on_invested_capital'],
                    'Dividends': ['dividend_yield', 'payout_ratio', 'dividend_growth'],
                    'Growth': ['revenue_growth', 'earnings_growth', 'eps_growth', 'book_value_growth'],
                    'Efficiency': ['asset_turnover', 'inventory_turnover', 'receivables_turnover']
                }
                
                stock_card += """
                <div class="fundamentals">
                    <h3>Fundamental Analysis</h3>
                    <div class="fundamental-grid">
                """
                
                # Function to format metric values with appropriate formatting and coloring
                def format_metric_value(key, value):
                    if value is None:
                        return 'N/A', 'neutral'
                        
                    # Format the value based on its type
                    if isinstance(value, (int, float)):
                        # Determine formatting based on metric type
                        if any(term in key.lower() for term in ['ratio', 'yield', 'margin', 'return', 'growth', 'turnover']):
                            if '%' not in str(value):  # Avoid adding % multiple times
                                formatted = f"{float(value):.2f}%"
                            else:
                                formatted = f"{float(value.replace('%', '')):.2f}%"
                        else:
                            # Large numbers get comma separators
                            if abs(value) >= 1000:
                                formatted = f"{value:,.0f}"
                            else:
                                formatted = f"{value:,.2f}"
                        
                        # Add color coding for positive/negative values
                        if any(term in key.lower() for term in ['growth', 'return', 'yield', 'margin']):
                            value_class = 'positive' if float(str(value).replace('%', '')) >= 0 else 'negative'
                            return f"<span class='{value_class}'>{formatted}</span>", value_class
                        return formatted, 'neutral'
                    return str(value), 'neutral'
                
                # Create a card for each metric group
                for group_name, metric_keys in metric_groups.items():
                    # Filter metrics that exist in the fundamentals
                    group_metrics = {}
                    for key in metric_keys:
                        if key in result['fundamentals'] and result['fundamentals'][key] is not None:
                            group_metrics[key] = result['fundamentals'][key]
                    
                    # Skip empty groups
                    if not group_metrics:
                        continue
                    
                    # Add group header and card
                    stock_card += f"""
                    <div class="fundamental-card">
                        <div class="fundamental-card-header">
                            <h4>{group_name}</h4>
                        </div>
                        <div class="fundamental-card-body">
                            <table class="fundamental-table">
                    """
                    
                    # Add metrics for this group
                    for key, value in group_metrics.items():
                        formatted_value, value_class = format_metric_value(key, value)
                        display_key = ' '.join(word.capitalize() for word in key.split('_'))
                        
                        # Add icon based on metric type
                        icon = ''
                        if 'growth' in key.lower() or 'return' in key.lower() or 'yield' in key.lower():
                            if isinstance(value, (int, float)) and float(str(value).replace('%', '')) >= 0:
                                icon = '📈'
                            else:
                                icon = '📉'
                        elif 'ratio' in key.lower() or 'margin' in key.lower():
                            icon = '📊'
                        elif 'price' in key.lower() or 'value' in key.lower():
                            icon = '💰'
                        elif 'debt' in key.lower() or 'equity' in key.lower():
                            icon = '🏦'
                        
                        stock_card += f"""
                            <tr class="fundamental-row {value_class}">
                                <td class="fundamental-key">{icon} {display_key}</td>
                                <td class="fundamental-value">{formatted_value}</td>
                            </tr>
                        """
                    
                    stock_card += """
                            </table>
                        </div>
                    </div>
                    """
                
                stock_card += """
                    </div>
                </div>
                """
            
            # Add charts if available
            if charts_html:
                stock_card += f"""
                <div class="charts">
                    <h3>Technical Analysis</h3>
                    {charts_html}
                </div>
                """
            
            # Close stock card
            stock_card += """
            </div>
            """
            
            html_content += stock_card
        
        # Close HTML
        html_content += """
            </div>
        </body>
        </html>
        """
        
        # Write the report to a file
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
            
        logger.info(f"Report generated: {report_path}")
        
        # Handle different return cases
        if for_email:
            # For email, we need to process charts and return both HTML and paths
            try:
                # Convert chart placeholders to embedded images
                processed_html, attachments = self._convert_charts_to_images(html_content, for_email=True)
                chart_paths.extend(attachments)
                
                # Rewrite the file with embedded images
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(processed_html)
                
                logger.debug("Charts embedded in email report")
                return processed_html, report_path, chart_paths
                
            except Exception as e:
                logger.error(f"Error embedding charts in email report: {e}")
                # If there's an error, return the original HTML without embedded charts
                return html_content, report_path, chart_paths
                
        elif return_html:
            # For HTML return, just return the content and path
            return html_content, report_path
            
        # Default return is just the report path
        return report_path
        
    def _generate_recommendation(self, analysis: Dict) -> Tuple[str, str]:
        """
        Generate a recommendation based on technical and fundamental analysis.
        
        Args:
            analysis: Dictionary containing analysis results for a stock
            
        Returns:
            Tuple of (recommendation, reasoning)
        """
        # Get technical indicators
        rsi = analysis.get('rsi')
        macd = analysis.get('macd')
        macd_signal = analysis.get('macd_signal')
        ma_50 = analysis.get('ma_50')
        ma_200 = analysis.get('ma_200')
        price = analysis.get('price')
        
        # Initialize scores
        score = 0
        reasoning = []
        
        # RSI analysis
        if rsi is not None:
            if rsi < 30:
                score += 1
                reasoning.append("RSI indicates oversold conditions.")
            elif rsi > 70:
                score -= 1
                reasoning.append("RSI indicates overbought conditions.")
        
        # MACD analysis
        if macd is not None and macd_signal is not None:
            if macd > macd_signal:
                score += 1
                reasoning.append("Bullish MACD crossover detected.")
            else:
                score -= 1
                reasoning.append("Bearish MACD crossover detected.")
        
        # Moving averages analysis
        if ma_50 is not None and ma_200 is not None and price is not None:
            if ma_50 > ma_200 and price > ma_200:
                score += 1
                reasoning.append("Price above 200-day MA with golden cross.")
            elif ma_50 < ma_200 and price < ma_200:
                score -= 1
                reasoning.append("Price below 200-day MA with death cross.")
        
        # Generate recommendation based on score
        if score >= 2:
            return "Strong Buy", " ".join(reasoning)
        elif score >= 1:
            return "Buy", " ".join(reasoning)
        elif score <= -2:
            return "Strong Sell", " ".join(reasoning)
        elif score <= -1:
            return "Sell", " ".join(reasoning)
        else:
            return "Hold", "Neutral technical indicators suggest holding."
            
    def _process_stock_result(self, result: Dict) -> Dict:
        """
        Process a single stock result and prepare it for the report.
        
        Args:
            result: Dictionary containing stock analysis results
            
        Returns:
            Dictionary with processed stock data for the report
        """
        try:
            # Ensure we have a valid result
            if not result or 'symbol' not in result:
                logger.warning("Invalid or empty result provided to _process_stock_result")
                return {}
                
            # Extract basic stock info
            symbol = result['symbol']
            name = result.get('name', symbol)
            latest_price = result.get('latest_price', 0)
            change_pct = result.get('change_pct', 0)
            
            logger.debug(f"Processing {symbol} - {name}, Price: {latest_price}, Change: {change_pct}%")
            
            # Get technical indicators
            rsi = result.get('rsi')
            ma_20 = result.get('ma_20')
            ma_50 = result.get('ma_50')
            ma_200 = result.get('ma_200')
            bb_upper = result.get('bb_upper')
            bb_middle = result.get('bb_middle')
            bb_lower = result.get('bb_lower')
            macd = result.get('macd')
            macd_signal = result.get('macd_signal')
            volume = result.get('volume', 0)
            
            logger.debug(f"Technical indicators - RSI: {rsi}, MA20: {ma_20}, MA50: {ma_50}, MA200: {ma_200}")
            
            # Get fundamental metrics
            fundamentals = result.get('fundamentals', {})
            pe_ratio = result.get('pe_ratio', fundamentals.get('pe_ratio'))
            pb_ratio = result.get('pb_ratio', fundamentals.get('price_to_book'))
            roe = result.get('roe', fundamentals.get('return_on_equity'))
            
            logger.debug(f"Fundamentals - P/E: {pe_ratio}, P/B: {pb_ratio}, ROE: {roe}")
            logger.debug(f"Available fundamentals keys: {list(fundamentals.keys())}")
            
            # Process charts
            charts = result.get('charts', [])
            chart_paths = []
            
            logger.debug(f"Found {len(charts)} charts for {symbol}")
            
            # Copy chart files to reports/charts directory
            for chart_path in charts:
                if chart_path and os.path.exists(chart_path):
                    try:
                        chart_filename = f"{symbol}_{os.path.basename(chart_path)}"
                        dest_path = os.path.join('reports', 'charts', chart_filename)
                        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                        shutil.copy2(chart_path, dest_path)
                        chart_paths.append(dest_path)
                        logger.debug(f"Copied chart {chart_path} to {dest_path}")
                    except Exception as e:
                        logger.error(f"Error copying chart {chart_path}: {e}")
                else:
                    logger.warning(f"Chart path does not exist or is invalid: {chart_path}")
            
            # Prepare the processed result
            processed = {
                'symbol': symbol,
                'name': name,
                'latest_price': latest_price,
                'change_pct': change_pct,
                'rsi': rsi,
                'ma_20': ma_20,
                'ma_50': ma_50,
                'ma_200': ma_200,
                'bb_upper': bb_upper,
                'bb_middle': bb_middle,
                'bb_lower': bb_lower,
                'macd': macd,
                'macd_signal': macd_signal,
                'volume': volume,
                'pe_ratio': pe_ratio,
                'pb_ratio': pb_ratio,
                'roe': roe,
                'charts': chart_paths,
                'is_index': result.get('is_index', False)
            }
            
            # Add any additional fields from the original result
            additional_fields = {}
            for key, value in result.items():
                if key not in processed and not key.startswith('_'):
                    additional_fields[key] = value
            
            if additional_fields:
                logger.debug(f"Adding additional fields to {symbol}: {list(additional_fields.keys())}")
                processed.update(additional_fields)
            
            logger.debug(f"Successfully processed {symbol} with {len(chart_paths)} charts")
            return processed
            
        except Exception as e:
            logger.error(f"Error processing stock result for {result.get('symbol', 'unknown')}: {e}", exc_info=True)
            return {}
        
        # Get fundamental metrics
        fundamentals = result.get('fundamentals', {})
        pe_ratio = result.get('pe_ratio', fundamentals.get('pe_ratio'))
        pb_ratio = result.get('pb_ratio', fundamentals.get('price_to_book'))
        roe = result.get('roe', fundamentals.get('return_on_equity'))
        
        logger.debug(f"Fundamentals - P/E: {pe_ratio}, P/B: {pb_ratio}, ROE: {roe}")
        logger.debug(f"Available fundamentals keys: {list(fundamentals.keys())}")
        price = ensure_scalar(price, 0)
        week_high = ensure_scalar(result.get('52_week_high'))
        week_low = ensure_scalar(result.get('52_week_low'))
            
        # Prepare metrics - different for index vs stocks
        if is_index:
            metrics = [
                ('Price', f"₹{price:,.2f}"),
                ('Change', f"<span class='{change_class}'>{change_icon} {abs(change_pct):.2f}%</span>"),
                ('P/E', f"{result.get('pe_ratio', 'N/A')}"),
                ('52-Week High', f"₹{week_high:,.2f}" if week_high is not None else 'N/A'),
                ('52-Week Low', f"₹{week_low:,.2f}" if week_low is not None else 'N/A')
            ]
        else:
            # Stock metrics
            metrics = [
                ('Price', f"₹{price:,.2f}"),
                ('Change', f"<span class='{change_class}'>{change_icon} {abs(change_pct):.2f}%</span>"),
                ('RSI', f"<span class='{self._get_rsi_class(rsi) if rsi is not None else ''}'>{rsi:.2f}</span>" if rsi is not None else 'N/A'),
                ('MA(20)', f"₹{ma_20:,.2f}" if ma_20 else 'N/A'),
                ('MA(50)', f"₹{ma_50:,.2f}" if ma_50 else 'N/A')
            ]
            
            # Valuation metrics
            valuation_metrics = [
                ('P/E', f"{fundamentals.get('pe_ratio', 'N/A'):.2f}" if fundamentals.get('pe_ratio') is not None else 'N/A'),
                ('P/B', f"{fundamentals.get('price_to_book', 'N/A'):.2f}" if fundamentals.get('price_to_book') is not None else 'N/A'),
                ('PEG', f"{fundamentals.get('peg_ratio', 'N/A'):.2f}" if fundamentals.get('peg_ratio') is not None else 'N/A'),
                ('Dividend Yield', f"{fundamentals.get('dividend_yield', 'N/A'):.2f}%" if fundamentals.get('dividend_yield') is not None else 'N/A'),
                ('EPS', f"{fundamentals.get('eps', 'N/A'):.2f}" if fundamentals.get('eps') is not None else 'N/A')
            ]
            
            # Profitability metrics
            profitability_metrics = [
                ("Return on Equity", f"{fundamentals.get('return_on_equity', 'N/A'):.1f}%" if fundamentals.get('return_on_equity') is not None else 'N/A'),
                ("Return on Assets", f"{fundamentals.get('return_on_assets', 'N/A'):.1f}%" if fundamentals.get('return_on_assets') is not None else 'N/A'),
                ("Profit Margin", f"{fundamentals.get('profit_margin', 'N/A'):.1f}%" if fundamentals.get('profit_margin') is not None else 'N/A'),
                ("Quarterly Revenue Growth (YoY)", f"{fundamentals.get('revenue_growth', 'N/A'):.1f}%" if fundamentals.get('revenue_growth') is not None else 'N/A'),
                ("Quarterly Earnings Growth (YoY)", f"{fundamentals.get('earnings_growth', 'N/A'):.1f}%" if fundamentals.get('earnings_growth') is not None else 'N/A')
            ]
            
            # Financial Health metrics
            financial_health_metrics = [
                ("Current Ratio", f"{fundamentals.get('current_ratio', 'N/A'):.2f}" if fundamentals.get('current_ratio') is not None else 'N/A'),
                ("Debt/Equity", f"{fundamentals.get('debt_to_equity', 'N/A'):.2f}" if fundamentals.get('debt_to_equity') is not None else 'N/A'),
                ("Interest Coverage", f"{fundamentals.get('interest_coverage', 'N/A'):.1f}x" if fundamentals.get('interest_coverage') is not None else 'N/A'),
                ("Quick Ratio", f"{fundamentals.get('quick_ratio', 'N/A'):.2f}" if fundamentals.get('quick_ratio') is not None else 'N/A'),
                ("Operating Cash Flow", f"₹{fundamentals.get('operating_cash_flow', 'N/A'):,.0f}M" if fundamentals.get('operating_cash_flow') is not None else 'N/A')
            ]
            
            # Market Data metrics
            market_metrics = [
                ("Market Cap", f"₹{fundamentals.get('market_cap', 'N/A'):,.0f}M" if fundamentals.get('market_cap') is not None else 'N/A'),
                ("Beta", f"{fundamentals.get('beta', 'N/A'):.2f}" if fundamentals.get('beta') is not None else 'N/A'),
                ("52-Week High/Low", 
                 f"₹{fundamentals.get('fifty_two_week_high', 'N/A'):.2f} / ₹{fundamentals.get('fifty_two_week_low', 'N/A'):.2f}" 
                 if (fundamentals.get('fifty_two_week_high') is not None and 
                     fundamentals.get('fifty_two_week_low') is not None) 
                 else 'N/A'),
                ("Average Volume", f"{fundamentals.get('average_volume', 'N/A'):,.0f}" if fundamentals.get('average_volume') is not None else 'N/A'),
                ("Shares Outstanding", f"{fundamentals.get('shares_outstanding', 'N/A'):,.0f}" if fundamentals.get('shares_outstanding') is not None else 'N/A')
            ]
            
            # Create fundamental sections
            def create_fundamental_section(title, metrics):
                if not metrics:
                    return ''
                
                items = []
                for label, value in metrics:
                    items.append(f"""
                        <div class="fundamental-item">
                            <div class="fundamental-label">{label}</div>
                            <div class="fundamental-value">{value}</div>
                        </div>
                    """)
                
                return f"""
                    <div class="fundamental-section">
                        <h3>{title}</h3>
                        <div class="fundamental-grid">
                            {''.join(items)}
                        </div>
                    </div>
                """
            
            fundamental_sections = [
                create_fundamental_section("Valuation", valuation_metrics),
                create_fundamental_section("Profitability & Growth", profitability_metrics),
                create_fundamental_section("Financial Health", financial_health_metrics),
                create_fundamental_section("Market Data", market_metrics)
            ]
        
        # Prepare charts HTML - Using a more reliable approach
        charts_html = ''
        if result.get('charts'):
            for chart_path in result['charts']:
                if chart_path:
                    # Get the full path to the chart file
                    chart_full_path = os.path.join('reports', 'charts', os.path.basename(chart_path))
                    chart_name = os.path.basename(chart_path).replace('.html', '').replace('_', ' ').title()
                    
                    # Special handling for sector performance chart
                    if 'sector_performance' in chart_path.lower():
                        chart_name = 'Sector Performance'
                        
                        # Check if the chart file exists
                        if os.path.exists(chart_full_path):
                            # For email, we'll generate an image, for HTML we'll use iframe
                            if for_email:
                                # Generate a unique ID for the chart
                                chart_id = f"chart_{symbol}_{chart_name.replace(' ', '_').lower()}"
                                # The actual image will be embedded by _convert_charts_to_images
                                charts_html += f"""
                                <div class="chart-container">
                                    <div class="chart-title">{chart_name}</div>
                                    <div class="chart-placeholder" id="{chart_id}">
                                        Loading chart...
                                    </div>
                                </div>
                                """
                            else:
                                # For HTML report, use iframe
                                charts_html += f"""
                                <div class="chart-container">
                                    <div class="chart-title">{chart_name}</div>
                                    <iframe src="charts/{os.path.basename(chart_path)}" style="width:100%; height:500px; border:none;"></iframe>
                                </div>
                                """
                        else:
                            logger.warning(f"Chart file not found: {chart_full_path}")
                            charts_html += f"""
                            <div class="chart-container">
                                <div class="chart-title">{chart_name}</div>
                                <div class="chart-error">Chart not available: {os.path.basename(chart_path)}</div>
                            </div>
                            """
            
            # Create stock card with improved layout
            stock_card = f"""
            <div class="stock-card">
                <div class="stock-header">
                    <div class="stock-symbol">{symbol}</div>
                    <div class="stock-price">₹{price:,.2f} <span class='{change_class}'>({change_icon} {abs(change_pct):.2f}%)</span></div>
                </div>
                
                <div class="recommendation {recommendation.lower()}">
                    {recommendation.upper()}
                    <div class="analysis-section">
                        <h4>Analysis:</h4>
                        <p>{reasoning}</p>
                    </div>
                </div>
                
                <div class="metrics">
                    <h3>Key Metrics</h3>
                    <table class="metrics-table">
                        <thead>
                            <tr>
                                <th>Metric</th>
                                <th>Value</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            
            # Add metrics as table rows
            for label, value in metrics:
                # Determine if the value should be colored based on its content
                value_class = ""
                if isinstance(value, str):
                    if value.startswith(('+', '▲')):
                        value_class = "positive"
                    elif value.startswith(('-', '▼')):
                        value_class = "negative"
                
                stock_card += f"""
                            <tr>
                                <td><strong>{label}</strong></td>
                                <td class="metric-value {value_class}">{value}</td>
                            </tr>
                """
            
            stock_card += """
                        </tbody>
                    </table>
                </div>
                
                <div class="fundamentals">
                    <h3>Fundamental Analysis</h3>
            """
            
            # Add fundamental sections with improved layout
            if isinstance(fundamental_sections, list) and len(fundamental_sections) > 0:
                stock_card += """
                    </tbody>
                    </table>
                </div>
                
                <div class="fundamentals">
                    <h3>Fundamental Analysis</h3>
                """
                
                # Convert fundamental sections to a 2-column layout
                stock_card += """
                <div class="fundamental-grid">
                    <div class="fundamental-column">
                """
                
                # Add sections in two columns
                for i, section in enumerate(fundamental_sections):
                    if i > 0 and i % 2 == 0:
                        stock_card += """
                            </div>
                            <div class="fundamental-column">
                        """
                    stock_card += section
                
                stock_card += """
                    </div>
                </div>
                """
            
            # Add charts section if there are any charts
            if charts_html.strip():
                stock_card += """
                <div class="charts">
                    <h3>Technical Analysis</h3>
                    {}
                </div>
                """.format(charts_html)
            
            stock_card += """
                </div>
                
                <div class="charts">
                    <h3>Technical Analysis</h3>
                    {charts}
                </div>
            </div>
            """.format(charts=charts_html)
            
            stock_cards.append(stock_card)
        
        # Generate final HTML
        report_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        stock_count = len(analysis_results)
        
        # Create the final HTML content
        html_template = """
        <html>
        <head>
            <style>
                .buy {{ background-color: rgba(46, 204, 113, 0.2); border-left: 4px solid #2ecc71; }}
                .sell {{ background-color: rgba(231, 76, 60, 0.2); border-left: 4px solid #e74c3c; }}
                .hold {{ background-color: rgba(241, 196, 15, 0.2); border-left: 4px solid #f1c40f; }}
                .analysis-section {{ margin: 15px 0; }}
                .analysis-section h3 {{ margin-bottom: 10px; color: #2c3e50; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Stock Analysis Report</h1>
                <p>Generated on: {report_date}</p>
                <p>Stocks analyzed: {stock_count}</p>
                <hr>
                {stock_cards}
                <div class="footer">
                    <p>This report was automatically generated by the Stock Analysis Tool.</p>
                    <p>For educational purposes only. Not financial advice.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        report_html = html_template.format(
            report_date=report_date,
            stock_count=stock_count,
            stock_cards='\n'.join(stock_cards)
        )
        
        # Save report
        report_path = REPORTS_DIR / f"stock_analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_html)
        
        logger.info(f"Report generated: {report_path}")
        return str(report_path)
    
    def _get_rsi_class(self, rsi_value: float) -> str:
        """
        Get CSS class for RSI value styling.
        
        Args:
            rsi_value: RSI value
            
        Returns:
            CSS class name for styling
        """
        if rsi_value is None:
            return ""
        if rsi_value > 70:
            return "negative"  # Overbought
        elif rsi_value < 30:
            return "positive"  # Oversold
        return ""
        
    def _generate_recommendation(self, analysis: Dict) -> Tuple[str, str]:
        """
        Generate a recommendation based on technical and fundamental analysis.
        
        Args:
            analysis: Dictionary with analysis results
            
        Returns:
            Tuple of (recommendation, reasoning)
        """
        symbol = analysis['symbol']
        price = analysis['latest_price']
        rsi = analysis.get('rsi')
        ma_20 = analysis.get('ma_20')
        ma_50 = analysis.get('ma_50')
        ma_200 = analysis.get('ma_200')
        pe = analysis.get('fundamentals', {}).get('pe_ratio')
        roe = analysis.get('fundamentals', {}).get('return_on_equity')
        de = analysis.get('fundamentals', {}).get('debt_to_equity')
        
        reasons = []
        score = 0
        
        # RSI analysis
        if rsi:
            if rsi < 30:
                reasons.append("RSI indicates oversold conditions.")
                score += 1
            elif rsi > 70:
                reasons.append("RSI indicates overbought conditions.")
                score -= 1
        
        # Moving averages
        if ma_20 and ma_50 and ma_200:
            if ma_20 > ma_50 > ma_200 and price > ma_20:
                reasons.append("Bullish moving average crossover (20 > 50 > 200).")
                score += 1
            elif ma_20 < ma_50 < ma_200 and price < ma_20:
                reasons.append("Bearish moving average crossover (20 < 50 < 200).")
                score -= 1
        
        # P/E ratio
        if pe:
            if pe < 15:
                reasons.append("Low P/E ratio suggests the stock may be undervalued.")
                score += 1
            elif pe > 25:
                reasons.append("High P/E ratio suggests the stock may be overvalued.")
                score -= 1
        
        # ROE
        if roe:
            if roe > 15:
                reasons.append(f"Strong ROE of {roe:.1f}% indicates good profitability.")
                score += 1
            elif roe < 8:
                reasons.append(f"Low ROE of {roe:.1f}% may indicate profitability concerns.")
                score -= 1
        
        # Debt to Equity
        if de is not None:
            if de < 0.5:
                reasons.append("Low debt-to-equity ratio indicates strong financial health.")
                score += 1
            elif de > 2.0:
                reasons.append("High debt-to-equity ratio may indicate financial risk.")
                score -= 1
        
        # Generate recommendation based on score
        if score >= 2:
            recommendation = "BUY"
        elif score <= -2:
            recommendation = "SELL"
        else:
            recommendation = "HOLD"
        
        # If no specific reasons, provide a general analysis
        if not reasons:
            reasons = ["Neutral technical and fundamental indicators."]
        
        return recommendation, " ".join(reasons)
    
    def _embed_chart_image(self, chart_path: str, output_path: str = None) -> bool:
        """
        Convert a chart HTML to an image and save it to the specified path.
        
        Args:
            chart_path: Path to the chart HTML file
            output_path: Path to save the image to (if None, a temporary file will be used)
            
        Returns:
            bool: True if the image was successfully saved, False otherwise
        """
        import base64
        import time
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from webdriver_manager.chrome import ChromeDriverManager
        
        # Set up headless Chrome with additional options
        chrome_options = Options()
        chrome_options.add_argument('--headless=new')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--window-size=1200,1000')
        chrome_options.add_argument('--force-device-scale-factor=1')
        chrome_options.add_argument('--disable-extensions')
        chrome_options.add_argument('--disable-software-rasterizer')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        
        # Initialize WebDriver with error handling
        driver = None
        try:
            # Try with webdriver_manager first
            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=chrome_options)
            
            # Convert path to file URL
            abs_path = os.path.abspath(chart_path)
            if not os.path.exists(abs_path):
                logger.error(f"Chart file not found: {abs_path}")
                return False
                
            chart_url = f'file://{abs_path}'
            logger.debug(f"Loading chart URL: {chart_url}")
            
            # Load the page
            driver.get(chart_url)
            
            # Wait for the page to load completely
            WebDriverWait(driver, 20).until(
                lambda d: d.execute_script('return document.readyState') == 'complete'
            )
            
            # Wait for Plotly charts to render
            try:
                WebDriverWait(driver, 15).until(
                    EC.presence_of_element_located((By.CLASS_NAME, "plotly"))
                )
                # Additional wait for animations to complete
                time.sleep(3)
            except Exception as e:
                logger.warning(f"Timeout waiting for plotly chart: {e}")
            
            # Find the chart container
            chart_element = driver.find_element(By.CLASS_NAME, 'plotly')
            
            # If output_path is not provided, use a temporary file
            if not output_path:
                import tempfile
                _, output_path = tempfile.mkstemp(suffix='.png')
            
            # Save the screenshot to a file
            chart_element.screenshot(output_path)
            
            # Verify the file was created
            if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                logger.info(f"Successfully saved chart image to: {output_path}")
                return True
                
            logger.error(f"Failed to save chart image to: {output_path}")
            return False
            
        except Exception as e:
            logger.error(f"Error capturing chart screenshot: {str(e)}", exc_info=True)
            return False
            
        finally:
            try:
                if driver:
                    driver.quit()
            except Exception as e:
                logger.warning(f"Error quitting WebDriver: {e}")
            
    def _find_chrome_executable(self):
        """Find Chrome executable path based on the OS."""
        import platform
        import sys
        
        if sys.platform.startswith('win'):
            # Windows
            paths = [
                r'C:\Program Files\Google\Chrome\Application\chrome.exe',
                r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
            ]
        elif sys.platform == 'darwin':
            # macOS
            paths = [
                '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                '/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary',
                '/Applications/Chromium.app/Contents/MacOS/Chromium',
                '/usr/bin/google-chrome',
                '/usr/local/bin/chromium',
                '/usr/local/bin/chromium-browser'
            ]
        else:
            # Linux
            paths = [
                '/usr/bin/google-chrome',
                '/usr/local/bin/chrome',
                '/opt/google/chrome/chrome',
                '/usr/bin/chromium',
                '/usr/bin/chromium-browser'
            ]
        
        # Check each possible path
        for path in paths:
            if os.path.isfile(path):
                return path
        
        # If not found, try which
        try:
            import shutil
            return shutil.which('google-chrome') or shutil.which('chrome') or shutil.which('chromium')
        except:
            return None
    
    def _enhance_email_html(self, html_content: str) -> str:
        """
        Enhance the HTML content with better styling for email clients.
        
        Args:
            html_content: The original HTML content
        """
        # Define CSS for email compatibility
        css = """
        <style type="text/css">
            body { 
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333333;
                margin: 0;
                padding: 20px;
                background-color: #f5f7fa;
            }
            .container { 
                max-width: 100%;
                margin: 0 auto;
            }
            .stock-card { 
                background: white; 
                border-radius: 8px; 
                box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
                margin-bottom: 30px; 
                overflow: hidden;
            }
            .stock-header { 
                display: flex; 
                justify-content: space-between; 
                align-items: center; 
                padding: 15px 20px;
                background: linear-gradient(135deg, #1e3c72, #2a5298);
                color: white;
            }
            .positive { color: #28a745; font-weight: bold; }
            .negative { color: #dc3545; font-weight: bold; }
            
            @media (max-width: 768px) {
                .stock-header {
                    flex-direction: column;
                    text-align: center;
                    padding: 15px;
                }
                .stock-symbol, .stock-price {
                    margin: 5px 0;
                }
                .metrics-table th, 
                .metrics-table td,
                .fundamental-section th, 
                .fundamental-section td {
                    padding: 10px 12px;
                    font-size: 13px;
                }
                .fundamental-column {
                    flex: 100%;
                    margin-bottom: 15px;
                }
                .fundamental-section {
                    margin-bottom: 20px;
                }
            }
        </style>
        """
        
        # Insert CSS into the head of the HTML
        if '<head>' in html_content:
            if '<style type="text/css">' not in html_content:  # Avoid duplicate styles
                return html_content.replace('<head>', f'<head>{css}')
            return html_content
        else:
            return f'<html><head>{css}</head><body>{html_content}</body></html>'

    def _convert_charts_to_images(self, html_content: str, for_email: bool = False) -> tuple:
        """
        Convert chart placeholders to inline images in the HTML content.
        
        Args:
            html_content: The original HTML content
            for_email: Whether the HTML is for email (uses CIDs for images)
            
        Returns:
            tuple: (modified_html, attachments) where attachments is a list of (file_path, cid) tuples
        """
        from bs4 import BeautifulSoup
        import os
        import tempfile
        import uuid
        import shutil
        import base64
        
        soup = BeautifulSoup(html_content, 'html.parser')
        attachments = []
        
        # Create a more reliable temporary directory
        temp_dir = os.path.join(tempfile.gettempdir(), 'stock_analysis_charts')
        os.makedirs(temp_dir, exist_ok=True)
        logger.info(f"Using temporary directory for chart images: {temp_dir}")
        
        # Function to create error message
        def create_error_message(message):
            error_div = soup.new_tag('div', **{
                'class': 'chart-error',
                'style': 'padding: 10px; background-color: #ffebee; border-left: 4px solid #f44336; margin: 10px 0; color: #721c24;'
            })
            error_div.string = message
            return error_div
        
        # Function to create image container
        def create_image_container(img_path, alt_text, title, cid=None):
            container = soup.new_tag('div', **{
                'class': 'chart-image-container',
                'style': 'margin: 20px 0; padding: 10px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); text-align: center;'
            })
            
            # Add title if provided
            if title:
                title_tag = soup.new_tag('h4', **{
                    'style': 'margin: 0 0 10px 0; color: #2c3e50; font-size: 16px; font-weight: 600;'
                })
                title_tag.string = title
                container.append(title_tag)
            
            # Create image tag
            img_attrs = {
                'alt': alt_text or 'Chart',
                'title': title or 'Chart',
                'style': 'max-width: 100%; height: auto; border: 1px solid #e0e0e0; border-radius: 4px; display: block; margin: 0 auto;',
                'class': 'chart-img',
                'border': '0'
            }
            
            # For both email and HTML report, we'll use data URIs for embedded images
            if img_path and os.path.exists(img_path):
                try:
                    # Read the image file and convert to base64
                    with open(img_path, 'rb') as f:
                        img_data = f.read()
                        img_base64 = base64.b64encode(img_data).decode('utf-8')
                    
                    # Determine image type from file extension
                    img_ext = os.path.splitext(img_path)[1].lower().lstrip('.')
                    img_type = img_ext if img_ext in ['png', 'jpeg', 'jpg', 'gif'] else 'png'
                    
                    # Use data URI for the image source
                    img_attrs['src'] = f'data:image/{img_type};base64,{img_base64}'
                    
                    img_tag = soup.new_tag('img', **img_attrs)
                    container.append(img_tag)
                    return container
                    
                except Exception as e:
                    logger.error(f"Error reading image file {img_path}: {e}")
                    return create_error_message(f"Error loading chart: {str(e)}")
            else:
                logger.warning(f"Image file not found: {img_path}")
                return create_error_message("Chart image not found")
        
        # Process all chart placeholders
        for placeholder in soup.find_all('div', class_='chart-placeholder'):
            try:
                chart_path = placeholder.get('data-chart-path')
                if not chart_path:
                    logger.warning("Chart placeholder missing data-chart-path attribute")
                    placeholder.replace_with(create_error_message("Error: Missing chart path"))
                    continue
                
                # Get chart name from title or path
                chart_name = ""
                title_div = placeholder.find_previous_sibling('h3', class_='chart-title')
                if title_div:
                    chart_name = title_div.get_text(strip=True)
                else:
                    chart_name = os.path.basename(chart_path).replace('.html', '').replace('_', ' ').title()
                
                logger.info(f"Processing chart: {chart_name} at {chart_path}")
                
                # Check if the chart file exists
                if not os.path.exists(chart_path):
                    error_msg = f"Chart file not found: {os.path.abspath(chart_path)}"
                    logger.error(error_msg)
                    placeholder.replace_with(create_error_message(f"Error: {error_msg}"))
                    continue
                
                # Generate a unique filename for the chart image
                img_filename = f"chart_{uuid.uuid4().hex}.png"
                img_path = os.path.join(temp_dir, img_filename)
                
                # Ensure the directory exists
                os.makedirs(os.path.dirname(img_path), exist_ok=True)
                
                # Convert the chart HTML to an image and save to file
                success = self._embed_chart_image(chart_path, img_path)
                
                if success and os.path.exists(img_path):
                    # For email, we'll use the image as an attachment with CID
                    if for_email:
                        cid = f"chart_{uuid.uuid4().hex}"
                        attachments.append((img_path, cid))
                        logger.info(f"Prepared chart for email: {chart_name} (CID: {cid})")
                    
                    # Create the image container with appropriate source
                    img_container = create_image_container(
                        img_path, 
                        chart_name, 
                        chart_name, 
                        cid if for_email else None
                    )
                    
                    # Replace the placeholder with the image container
                    placeholder.replace_with(img_container)
                    logger.info(f"Successfully embedded chart: {chart_name}")
                else:
                    error_msg = f"Failed to generate chart image for {chart_name}"
                    logger.error(error_msg)
                    placeholder.replace_with(create_error_message(f"Error: {error_msg}"))
                
            except Exception as e:
                error_msg = f"Error processing chart: {str(e)}"
                logger.error(error_msg, exc_info=True)
                placeholder.replace_with(create_error_message(f"Error loading chart: {error_msg}"))
        
        # Handle iframes (backward compatibility)
        for iframe in soup.find_all('iframe'):
            try:
                src = iframe.get('src', '').strip()
                if not src:
                    logger.warning("Iframe missing src attribute")
                    iframe.replace_with(create_error_message("Error: Missing chart source"))
                    continue
                
                # Handle both relative and absolute paths
                if src.startswith(('http://', 'https://')):
                    # Skip remote URLs as we can't process them
                    logger.warning(f"Skipping remote URL in iframe: {src}")
                    continue
                
                # Handle relative paths
                chart_path = os.path.join('reports', src) if not os.path.isabs(src) else src
                chart_name = os.path.basename(chart_path).replace('.html', '').replace('_', ' ').title()
                
                # Special case for sector performance
                if 'sector_performance' in chart_path.lower():
                    chart_name = 'Sector Performance'
                
                logger.info(f"Processing iframe chart: {chart_name} at {chart_path}")
                
                # Check if the chart file exists
                if not os.path.exists(chart_path):
                    error_msg = f"Chart file not found: {os.path.abspath(chart_path)}"
                    logger.error(error_msg)
                    iframe.replace_with(create_error_message(f"Error: {error_msg}"))
                    continue
                
                # Generate a unique filename for the chart image
                img_filename = f"chart_{uuid.uuid4().hex}.png"
                img_path = os.path.join(temp_dir, img_filename)
                
                # Convert the chart HTML to an image and save to file
                success = self._embed_chart_image(chart_path, img_path)
                
                if success and os.path.exists(img_path):
                    if for_email:
                        # For email, use CID reference
                        cid = f"chart_{len(attachments) + 1}"
                        attachments.append((img_path, cid))
                        img_container = create_image_container(img_path, chart_name, chart_name, cid)
                        logger.info(f"Successfully embedded iframe chart in email: {chart_name} (CID: {cid})")
                    else:
                        # For local display, use file path
                        img_container = create_image_container(img_path, chart_name, chart_name)
                        logger.info(f"Successfully embedded iframe chart: {chart_name}")
                    
                    if iframe.parent:
                        if iframe.previous_sibling:
                            iframe.previous_sibling.insert_after(img_container)
                        else:
                            iframe.parent.insert(0, img_container)
                    iframe.decompose()
                else:
                    error_msg = f"Failed to generate chart image for {chart_name}"
                    logger.error(error_msg)
                    iframe.replace_with(create_error_message(f"Error: {error_msg}"))
                
            except Exception as e:
                error_msg = f"Error processing iframe chart: {str(e)}"
                logger.error(error_msg, exc_info=True)
                iframe.replace_with(create_error_message(f"Error loading chart: {error_msg}"))
        
        return str(soup), attachments
    
    def send_email(self, to_email: str, subject: str, html_content: str, attachments: list = None):
        """
        Send an email with HTML content and embedded chart images.
        
        Args:
            to_email: Recipient email address
            subject: Email subject
            html_content: HTML content of the email
            attachments: List of file paths to attach
        """
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from email.mime.image import MIMEImage
        from email.mime.base import MIMEBase
        from email import encoders
        import smtplib
        import os
        import tempfile
        import shutil
        import base64
        from bs4 import BeautifulSoup
        
        # Get email configuration
        sender_email = os.getenv('SENDER_EMAIL')
        sender_password = os.getenv('SENDER_PASSWORD')
        smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        smtp_port = int(os.getenv('SMTP_PORT', 587))
        
        if not sender_email or not sender_password:
            logger.error("Email credentials not found. Please set SENDER_EMAIL and SENDER_PASSWORD environment variables.")
            return False
            
        # Create a temporary directory for email attachments
        temp_dir = tempfile.mkdtemp(prefix='stock_analysis_email_')
        
        try:
            # Create the root message with 'related' type for inline images
            msg = MIMEMultipart('related')
            msg['Subject'] = subject
            msg['From'] = sender_email
            msg['To'] = to_email
            msg.preamble = 'This is a multi-part message in MIME format.'
            
            # Create the alternative part for HTML content
            msg_alternative = MIMEMultipart('alternative')
            msg.attach(msg_alternative)
            
            # Create a temporary HTML file to parse the content
            temp_html = os.path.join(temp_dir, 'temp.html')
            with open(temp_html, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            # Parse the HTML to find and process images
            with open(temp_html, 'r', encoding='utf-8') as f:
                soup = BeautifulSoup(f, 'html.parser')
            
            # Find all image tags
            img_tags = soup.find_all('img')
            
            # Process each image tag
            for i, img in enumerate(img_tags):
                src = img.get('src', '')
                
                # Handle base64 encoded images
                if src.startswith('data:image/'):
                    try:
                        # Extract image data from data URI
                        header, encoded = src.split(',', 1)
                        img_format = header.split(';')[0].split('/')[-1]
                        if img_format not in ['png', 'jpeg', 'jpg', 'gif']:
                            img_format = 'png'  # default to png
                        
                        # Generate a unique CID for this image
                        cid = f'chart_{i}_{os.urandom(4).hex()}@stockanalysis.com'
                        
                        # Save the image to a temporary file
                        img_filename = f'chart_{i}.{img_format}'
                        img_path = os.path.join(temp_dir, img_filename)
                        
                        # Decode and save the image
                        with open(img_path, 'wb') as f:
                            f.write(base64.b64decode(encoded))
                        
                        # Update the image source to use CID
                        img['src'] = f'cid:{cid}'
                        
                        # Create the image part
                        with open(img_path, 'rb') as f:
                            img_data = f.read()
                        
                        img_part = MIMEImage(img_data, _subtype=img_format)
                        img_part.add_header('Content-ID', f'<{cid}>')
                        img_part.add_header('Content-Disposition', 'inline', filename=img_filename)
                        
                        # Attach the image
                        msg.attach(img_part)
                        
                    except Exception as e:
                        logger.error(f"Error processing inline image: {e}")
                        # Remove the problematic image
                        img.decompose()
            
            # Convert the modified HTML back to string
            html_content = str(soup)
            
            # Attach the HTML content
            msg_html = MIMEText(html_content, 'html')
            msg_alternative.attach(msg_html)
            
            # Add regular attachments if any
            if attachments:
                for attachment in attachments:
                    try:
                        if os.path.exists(attachment):
                            with open(attachment, 'rb') as f:
                                part = MIMEBase('application', 'octet-stream')
                                part.set_payload(f.read())
                                encoders.encode_base64(part)
                                part.add_header('Content-Disposition', 
                                             f'attachment; filename="{os.path.basename(attachment)}"')  
                                msg.attach(part)
                    except Exception as e:
                        logger.error(f"Error attaching file {attachment}: {e}")
            
            # Send the email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(sender_email, sender_password)
                server.send_message(msg)
            
            logger.info(f"Email sent to {to_email}")
            return True
            
        except Exception as e:
            logger.error(f"Error sending email: {e}", exc_info=True)
            return False
            
        finally:
            # Clean up temporary directory
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception as e:
                logger.warning(f"Error cleaning up temporary directory: {e}")
    
    def run_analysis(self, send_email: bool = False, email: str = None):
        """
        Run the complete analysis pipeline.
        
        Args:
            send_email: Whether to send the report via email
            email: Recipient email address (required if send_email is True)
        """
        if send_email and not email:
            raise ValueError("Email address is required when send_email is True")
        
        # Step 1: Fetch NIFTY 50 data for comparison
        logger.info("Fetching NIFTY 50 data for market comparison...")
        nifty_data = self.data_fetcher.fetch_nifty50_data(days=self.days)
        
        # Step 2: Fetch stock data
        logger.info("Fetching stock data...")
        stock_data = self.fetch_data()
        
        if not stock_data:
            logger.error("No stock data available for analysis")
            return
        
        logger.info(f"Successfully fetched data for {len(stock_data)} stocks: {', '.join(stock_data.keys())}")
        
        # Step 3: Analyze each stock
        analysis_results = []
        for symbol, data in stock_data.items():
            try:
                logger.info(f"Analyzing {symbol}...")
                if data is None or data.empty:
                    logger.warning(f"No data available for {symbol}, skipping...")
                    continue
                    
                logger.debug(f"Data for {symbol}:\n{data.head()}")
                
                result = self.analyze_stock(symbol, data)
                
                if result:
                    logger.info(f"Analysis complete for {symbol}")
                    
                    # Add NIFTY 50 PE ratio for comparison
                    if nifty_data and 'pe_ratio' in nifty_data:
                        result['nifty_pe_ratio'] = nifty_data['pe_ratio']
                        # Calculate PE ratio difference if available
                        if 'pe_ratio' in result and result['pe_ratio'] is not None:
                            result['pe_ratio_diff'] = result['pe_ratio'] - nifty_data['pe_ratio']
                            result['pe_ratio_diff_pct'] = (result['pe_ratio'] / nifty_data['pe_ratio'] - 1) * 100
                    
                    logger.debug(f"Analysis result for {symbol}: {json.dumps({k: v for k, v in result.items() if k != 'charts'}, default=str)}")
                    analysis_results.append(result)
                else:
                    logger.warning(f"No analysis result returned for {symbol}")
                    
            except Exception as e:
                logger.error(f"Error analyzing {symbol}: {e}", exc_info=True)
        
        # Add NIFTY 50 to analysis results for the report
        try:
            # Skip if no NIFTY data
            if not nifty_data:
                logger.warning("No NIFTY 50 data available")
            else:
                # Get sector performance from nifty_data if available
                sector_performance = nifty_data.get('sector_performance')
                
                # Create a simplified analysis result for NIFTY 50
                nifty_result = {
                    'symbol': '^NSEI',
                    'name': 'NIFTY 50',
                    'latest_price': nifty_data.get('latest_price'),
                    'change_pct': nifty_data.get('change_pct'),
                    'pe_ratio': nifty_data.get('pe_ratio'),
                    'is_index': True,
                    '52_week_high': nifty_data.get('52_week_high'),
                    '52_week_low': nifty_data.get('52_week_low'),
                    'data': nifty_data.get('data', pd.DataFrame()),
                    'sector_performance': sector_performance,
                    'charts': []
                }
                
                # Generate sector performance chart if sector data is available
                if sector_performance:
                    try:
                        visualizer = StockVisualizer(nifty_data.get('data', pd.DataFrame()), '^NSEI')
                        sector_chart = visualizer.create_sector_performance_chart(sector_performance)
                        if sector_chart:
                            nifty_result['charts'].append(sector_chart)
                    except Exception as e:
                        logger.error(f"Error generating sector performance chart: {e}")
                
                analysis_results.insert(0, nifty_result)  # Add at the beginning
        except Exception as e:
            logger.error(f"Error adding NIFTY 50 to analysis results: {e}")
        
        # Step 4: Generate report with all analysis results
        if not analysis_results:
            logger.error("No analysis results to report")
            return None
            
        logger.info(f"Generating report with {len(analysis_results)} analysis results")
        logger.debug(f"Analysis results: {json.dumps([r.get('symbol') for r in analysis_results], default=str)}")
            
        # Generate the report and get both the HTML content and report path
        try:
            html_content, report_path = self.generate_report(analysis_results, return_html=True)
            logger.info(f"Report generated successfully at {report_path}")
        except Exception as e:
            logger.error(f"Error generating report: {e}", exc_info=True)
            return None
        
        # Send email if requested
        if send_email and email:
            logger.info(f"Sending email to {email}")
            email_subject = f"Stock Analysis Report - {datetime.now().strftime('%Y-%m-%d')}"
            
            # Save the report to a file if not already saved
            if not report_path:
                report_path = os.path.join('reports', f'stock_analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.html')
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(html_content)
                logger.info(f"Report saved to {os.path.abspath(report_path)}")
            
            # Send the email with the report
            try:
                # Ensure the report file is saved
                if not report_path or not os.path.exists(report_path):
                    report_path = os.path.join('reports', f'stock_analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.html')
                    with open(report_path, 'w', encoding='utf-8') as f:
                        f.write(html_content)
                    logger.info(f"Report saved to {os.path.abspath(report_path)}")
                
                # Generate a fresh HTML content for email with all stocks
                result = self.generate_report(analysis_results, for_email=True, return_html=True)
                
                # Handle the return value which could be (html_content, report_path) or (html_content, report_path, chart_paths)
                if len(result) == 3:
                    email_html_content, _, _ = result
                else:
                    email_html_content, _ = result
                
                # Send the email with the full report
                self.send_email(
                    to_email=email,
                    subject=email_subject,
                    html_content=email_html_content,
                    attachments=[report_path] if report_path else None
                )
                logger.info("Email sent successfully with all stocks included")
            except Exception as e:
                logger.error(f"Error sending email: {e}")
                logger.exception("Full error details:")
        
        return report_path


def list_scheduled_jobs():
    """List all scheduled jobs."""
    print("Scheduled jobs:")
    # In a real implementation, you might query a database or job store
    print("No persistent job storage configured. Use --schedule-time to create a new schedule.")


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Stock Analysis Tool')
    
    # Stock selection
    stock_group = parser.add_argument_group('Stock Selection')
    stock_group.add_argument(
        '--stocks', 
        nargs='+', 
        help='List of stock symbols to analyze (e.g., RELIANCE.BO TCS.BO)'
    )
    
    # Analysis parameters
    analysis_group = parser.add_argument_group('Analysis Parameters')
    analysis_group.add_argument(
        '--days', 
        type=int, 
        default=365,
        help='Number of days of historical data to fetch (default: 365)'
    )
    
    # Output options
    output_group = parser.add_argument_group('Output Options')
    output_group.add_argument(
        '--email',
        help='Email address to send the report to'
    )
    
    output_group.add_argument(
        '--report-dir',
        default='reports',
        help='Directory to save the report (default: reports)'
    )
    
    # Stock selection options
    selection_group = parser.add_argument_group('Stock Selection')
    selection_group.add_argument(
        '--top',
        type=int,
        help='Analyze top N BSE stocks by market cap (ignored if --stocks is provided)'
    )
    
    selection_group.add_argument(
        '--all',
        action='store_true',
        help='Analyze all top BSE stocks (ignored if --stocks or --top is provided)'
    )
    
    # Scheduling options
    schedule_group = parser.add_argument_group('Scheduling Options')
    schedule_group.add_argument(
        '--schedule',
        nargs='?',
        const='list',
        help='Run in scheduled mode. Use "list" to show scheduled jobs.'
    )
    
    schedule_group.add_argument(
        '--schedule-time',
        default='09:30',
        help='Time to run the analysis (24-hour format, e.g., 09:30). Default: 09:30 (market open)'
    )
    
    schedule_group.add_argument(
        '--include-weekends',
        action='store_true',
        help='Run analysis on weekends too (default: weekdays only)'
    )
    
    schedule_group.add_argument(
        '--no-run-on-start',
        action='store_true',
        help='Do not run analysis immediately when starting the scheduler'
    )
    
    return parser.parse_args()


def main():
    """Main function to run the stock analysis tool."""
    # Parse command line arguments
    args = parse_arguments()
    
    # Handle the schedule command
    if args.schedule and args.schedule.lower() in ['list', 'show']:
        list_scheduled_jobs()
        return
    
    # Determine which stocks to analyze
    if args.stocks:
        symbols = args.stocks
    elif args.top:
        symbols = TOP_BSE_STOCKS[:args.top]
    elif args.all:
        symbols = TOP_BSE_STOCKS
    else:
        # Default to top 10 stocks
        symbols = TOP_BSE_STOCKS[:10]
    
    # Validate stock symbols
    valid_symbols = []
    for symbol in symbols:
        if validate_stock_symbol(symbol):
            valid_symbols.append(symbol)
        else:
            logger.warning(f"Invalid stock symbol: {symbol}. Skipping...")
    
    if not valid_symbols:
        logger.error("No valid stock symbols provided. Exiting...")
        return
    
    # Create and run the analyzer
    analyzer = StockAnalyzer(symbols=valid_symbols, days=args.days)
    
    # Set report directory
    global REPORTS_DIR
    REPORTS_DIR = Path(args.report_dir)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    
    # Run analysis or schedule it
    if args.schedule:
        # Run in scheduled mode
        schedule_config = {
            'daily_time': args.schedule_time,
            'weekdays_only': not args.include_weekends,
            'run_on_start': not args.no_run_on_start
        }
        
        print(f"Scheduling analysis to run daily at {args.schedule_time}")
        if not args.include_weekends:
            print("Running on weekdays only")
        
        # Create a wrapper function that includes the analyzer and args
        def scheduled_analysis():
            report_path = analyzer.run_analysis(
                send_email=bool(args.email),
                email=args.email
            )
            if report_path:
                logger.info(f"Scheduled analysis complete. Report saved to: {report_path}")
                if args.email:
                    logger.info(f"Report sent to: {args.email}")
        
        # Start the scheduler
        scheduler = schedule_analysis(scheduled_analysis, schedule_config)
        
        # Handle graceful shutdown
        def signal_handler(sig, frame):
            print("\nShutting down scheduler...")
            scheduler.stop()
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        print("Scheduler is running. Press Ctrl+C to exit.")
        print(f"Next run at: {scheduler.get_next_run() or 'Not scheduled'}")
        
        # Keep the main thread alive
        while True:
            time.sleep(1)
    else:
        # Run analysis once
        report_path = analyzer.run_analysis(
            send_email=bool(args.email),
            email=args.email
        )
        
        if report_path:
            print(f"\nAnalysis complete! Report saved to: {report_path}")
            if args.email:
                print(f"Report has been sent to: {args.email}")
        else:
            print("\nAnalysis failed. Please check the logs for details.")


if __name__ == "__main__":
    main()
