#!/usr/bin/env python3
"""
Command Line Interface for My Stock Analyser
"""
import argparse
import logging
import os
import sys
from typing import List, Optional
from pathlib import Path

from dotenv import load_dotenv

from . import StockAnalyzer, __version__

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('stock_analysis.log')
    ]
)
logger = logging.getLogger(__name__)

def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='My Stock Analyser - A comprehensive stock analysis tool.'
    )
    
    # Main arguments
    parser.add_argument(
        '--version',
        action='version',
        version=f'My Stock Analyser v{__version__}'
    )
    
    # Stock selection
    stock_group = parser.add_argument_group('Stock Selection')
    stock_group.add_argument(
        '--stocks',
        nargs='+',
        help='List of stock symbols to analyze (e.g., RELIANCE.NS TCS.NS)'
    )
    stock_group.add_argument(
        '--top',
        type=int,
        help='Analyze top N stocks by market cap (default: 5)',
        metavar='N'
    )
    stock_group.add_argument(
        '--nifty50',
        action='store_true',
        help='Analyze NIFTY 50 index'
    )
    
    # Analysis options
    analysis_group = parser.add_argument_group('Analysis Options')
    analysis_group.add_argument(
        '--days',
        type=int,
        default=365,
        help='Number of days of historical data to analyze (default: 365)'
    )
    
    # Output options
    output_group = parser.add_argument_group('Output Options')
    output_group.add_argument(
        '--output',
        type=str,
        help='Output file path for the report (default: reports/stock_analysis_report_<timestamp>.html)'
    )
    output_group.add_argument(
        '--email',
        type=str,
        help='Email address to send the report to'
    )
    output_group.add_argument(
        '--no-browser',
        action='store_true',
        help='Do not open the report in a web browser'
    )
    
    return parser.parse_args()

def validate_arguments(args: argparse.Namespace) -> bool:
    """Validate the command line arguments."""
    if not any([args.stocks, args.top, args.nifty50]):
        logger.error("Please specify at least one stock symbol, --top N, or --nifty50")
        return False
    
    if args.top and (args.top < 1 or args.top > 50):
        logger.error("--top must be between 1 and 50")
        return False
    
    if args.days < 1:
        logger.error("--days must be a positive integer")
        return False
    
    if args.email and not is_valid_email(args.email):
        logger.error(f"Invalid email address: {args.email}")
        return False
    
    return True

def is_valid_email(email: str) -> bool:
    """Check if the email address is valid."""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def get_stock_symbols(args: argparse.Namespace) -> List[str]:
    """Get the list of stock symbols to analyze."""
    if args.nifty50:
        return ['^NSEI']
    
    if args.top:
        # In a real implementation, you might fetch top N stocks by market cap
        # For now, we'll use a predefined list of top Indian stocks
        top_stocks = [
            'RELIANCE.NS', 'TCS.NS', 'HDFCBANK.NS', 'INFY.NS', 'ICICIBANK.NS',
            'HINDUNILVR.NS', 'ITC.NS', 'BHARTIARTL.NS', 'SBIN.NS', 'KOTAKBANK.NS'
        ]
        return top_stocks[:args.top]
    
    return args.stocks or []

def main():
    """Main entry point for the CLI."""
    # Load environment variables from .env file
    load_dotenv()
    
    # Parse command line arguments
    args = parse_arguments()
    
    # Validate arguments
    if not validate_arguments(args):
        return 1
    
    try:
        # Get stock symbols to analyze
        symbols = get_stock_symbols(args)
        if not symbols:
            logger.error("No valid stock symbols provided")
            return 1
        
        logger.info(f"Analyzing {len(symbols)} stocks: {', '.join(symbols)}")
        
        # Initialize the stock analyzer
        analyzer = StockAnalyzer()
        
        # Run the analysis
        results = []
        for symbol in symbols:
            try:
                logger.info(f"Analyzing {symbol}...")
                result = analyzer.analyze_stock(symbol, days=args.days)
                if result:
                    results.append(result)
            except Exception as e:
                logger.error(f"Error analyzing {symbol}: {str(e)}")
        
        if not results:
            logger.error("No analysis results to report")
            return 1
        
        # Generate the report
        report_path = args.output or f"reports/stock_analysis_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.html"
        
        # Ensure the reports directory exists
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        
        # Generate the report
        html_content, report_path = analyzer.generate_report(
            results,
            output_path=report_path,
            return_html=True
        )
        
        logger.info(f"Report generated: {os.path.abspath(report_path)}")
        
        # Open the report in the default web browser
        if not args.no_browser:
            import webbrowser
            webbrowser.open(f'file://{os.path.abspath(report_path)}')
        
        # Send email if requested
        if args.email:
            try:
                analyzer.send_report(
                    to_email=args.email,
                    analysis_results=results,
                    subject=f"Stock Analysis Report - {pd.Timestamp.now().strftime('%Y-%m-%d')}"
                )
                logger.info(f"Report sent to {args.email}")
            except Exception as e:
                logger.error(f"Error sending email: {str(e)}")
                return 1
        
        return 0
        
    except Exception as e:
        logger.exception("An unexpected error occurred")
        return 1

if __name__ == "__main__":
    sys.exit(main())
