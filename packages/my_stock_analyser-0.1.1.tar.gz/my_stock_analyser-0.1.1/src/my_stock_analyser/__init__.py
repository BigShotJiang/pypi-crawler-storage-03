"""
My Stock Analyser - A comprehensive stock analysis tool.

This package provides tools for fetching stock data, performing technical 
and fundamental analysis, generating reports, and sending email notifications.
"""

__version__ = "0.1.0"

# Import main classes for easier access
from .data_fetcher import DataFetcher
from .analysis import StockAnalyzer
from .visualization import StockVisualizer
from .report_generator import ReportGenerator
from .email_sender import EmailSender

# Create aliases for commonly used functions
analyze_stock = StockAnalyzer.analyze_stock
generate_report = StockAnalyzer.generate_report

__all__ = [
    'DataFetcher',
    'StockAnalyzer',
    'StockVisualizer',
    'ReportGenerator',
    'EmailSender',
    'analyze_stock',
    'generate_report',
]
