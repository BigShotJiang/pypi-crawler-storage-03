::: xopt.generators.ga.cnsga.CNSGAGenerator
