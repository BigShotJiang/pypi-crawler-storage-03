__version__ = "1.0.1"
__author__ = "karta9821"
__author_email__ = "karwacki.bartosz.it@gmail.com"
__description__ = "Dual Momentum Investing Strategy Tool"
