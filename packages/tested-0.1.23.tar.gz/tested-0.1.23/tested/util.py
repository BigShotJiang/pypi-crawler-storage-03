"""Util functions"""
