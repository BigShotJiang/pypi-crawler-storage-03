## Contributing to pytmx
Thanks for your interest in contributing to pytmx!
Please follow these rules before contributing.
 - Lint your code `black . -l 88`
 - Create an issue or contact the maintainer on Discord before creating a pull request
