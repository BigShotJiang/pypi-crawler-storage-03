<?xml version="1.0" encoding="UTF-8"?>
<tileset name="16x16-overworld" tilewidth="16" tileheight="16">
 <image source="16x16-overworld.png" width="256" height="336"/>
 <tile id="17">
  <properties>
   <property name="name" value="grass"/>
  </properties>
 </tile>
 <tile id="275">
  <properties>
   <property name="name" value="castle-door"/>
  </properties>
 </tile>
</tileset>
