from typing import List


class WitWorld:
    def strings(self, a: str) -> str:
        return a

    def bytes(self, a: bytes) -> bytes:
        return a

    def ints(self, a: List[int]) -> List[int]:
        return a

    def string_list(self, a: List[str]) -> List[str]:
        return a
