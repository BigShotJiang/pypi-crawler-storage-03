class WitWorld:
    def foo(self, a):
        return a + 1
