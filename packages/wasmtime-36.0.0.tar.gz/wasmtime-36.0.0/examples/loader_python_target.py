# This is part of the `loader.py` example


def answer():
    return 42
