"""Version information for the Alter Python client."""

__title__ = "alter-py"
__version__ = "0.2.0"