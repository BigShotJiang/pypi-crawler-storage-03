## 上传步骤
在你的项目根目录（pyproject.toml 所在目录）执行：
```
python -m build
```
- 这个命令会生成一个 dist/ 文件夹。
- 文件通常是:
  - `yolo_convert-0.1.0-py3-none-any.whl`
  - `yolo_convert-0.1.0.tar.gz`

再上传包:
```
twine upload dist/*
```

## 本地开发
```
pip uninstall yolo-convert      # 卸载 PyPI 版本，避免冲突
pip install -e .                # 安装本地 editable 版本
yolo_convert -i yolov5s.pt
```
## 安装测试
```
pip install yolo-convert

导出Yolov5模型，一个输出（默认640x640分辨率）
yolo_convert -i yolov5.pt

导出Yolov5模型，一个输出
yolo_convert -i yolov5.pt --img 1024 1280

导出Yolov5模型，三个输出
yolo_convert -i yolov5.pt --hisi3559 --img 1024 1280

```
