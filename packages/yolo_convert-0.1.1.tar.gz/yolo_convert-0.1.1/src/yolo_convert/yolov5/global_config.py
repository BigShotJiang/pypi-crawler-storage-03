# 是否在 HiSilicon 3559 上运行
HISI3559 = False