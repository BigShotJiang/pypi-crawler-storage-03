"""
SVG to PPTX Converter Package
"""
from .converter import Converter

__all__ = ['Converter']
