# License: MIT
# Copyright © 2024 Frequenz Energy-as-a-Service GmbH

"""Helpful utilities for testing with the dispatch client."""
