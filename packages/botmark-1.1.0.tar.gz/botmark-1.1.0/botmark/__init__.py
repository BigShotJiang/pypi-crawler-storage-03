import importlib.metadata

__version__ = importlib.metadata.version("botmark")

from .core import BotManager, BotMarkAgent, FileSystemSource, BotmarkSource

__all__ = ["BotManager", "BotMarkAgent", "FileSystemSource", "BotmarkSource"]
