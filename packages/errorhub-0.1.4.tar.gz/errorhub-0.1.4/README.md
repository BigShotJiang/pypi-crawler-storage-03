# Error-Hub
Custom library publicly deployed through pip. One shot library to handle errors like a champ, with a decorator to wrap up api functions, avoid implemeting try catch again and again for every other api
