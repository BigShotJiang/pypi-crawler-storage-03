"""DEPRECATED: Please import tabpfn.architectures.base.encoders instead."""

from __future__ import annotations

from tabpfn.architectures.base.encoders import *  # noqa: F403
