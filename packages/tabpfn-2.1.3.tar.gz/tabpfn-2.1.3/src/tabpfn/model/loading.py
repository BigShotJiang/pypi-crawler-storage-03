"""DEPRECATED: Please import from `tabpfn.model_loading` instead."""

from __future__ import annotations

from tabpfn.model_loading import *  # noqa: F403
