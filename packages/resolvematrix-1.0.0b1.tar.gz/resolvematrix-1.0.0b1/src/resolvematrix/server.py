import ipaddress
import logging
import random
import typing
from enum import IntEnum

import dns.resolver
import httpx

from .cache import BaseCache, BasicResolutionCache
from .client import SERVER_NAME_REGEX, __version__, limited_read
from .err import ResolutionError

if typing.TYPE_CHECKING:
    ANY_ADDRESS = ipaddress.IPv6Address | ipaddress.IPv4Address


class DNSMode(IntEnum):
    IPV4_FIRST = 0
    IPV6_FIRST = 1
    IPV4_ONLY = 2
    IPV6_ONLY = 3


class ServerDestination:
    def __init__(self, hostname: str, sni: str | None = None):
        self.hostname = hostname
        self.host_header = hostname
        self.sni = sni

    @property
    def base_url(self) -> str:
        return f"https://{self.hostname}"

    def __repr__(self):
        return f"ServerDestination(hostname={self.hostname!r}, host_header={self.host_header!r}, sni={self.sni!r})"


class ServerResolver:
    def __init__(
        self,
        client: httpx.Client | None = None,
        dns_mode: DNSMode = DNSMode.IPV4_FIRST,
        dns_resolver: dns.resolver.Resolver | None = None,
        cache: BaseCache | None = None,
    ):
        self.client = client or httpx.Client(
            headers={"User-Agent": f"resolvematrix/{__version__}"},
            timeout=30.0,
        )
        self.dns_mode = dns_mode
        self.dns_resolver = dns_resolver or dns.resolver.get_default_resolver()
        self.log = logging.getLogger("resolvematrix.server")
        self.cache = cache or BasicResolutionCache()

    def _lookup_a(self, domain: str) -> list[ipaddress.IPv4Address]:
        """
        Resolves a domain name to a list of IPv4 addresses using DNS A records.

        :param domain: The domain name to resolve.
        :return: A list of IPv4Address objects. An empty list if no A records are found.
        """
        try:
            answers = self.dns_resolver.resolve(domain, "A")
            return [ipaddress.IPv4Address(rdata.to_text()) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []

    def _lookup_aaaa(self, domain: str) -> list[ipaddress.IPv6Address]:
        """
        Resolves a domain name to a list of IPv6 addresses using DNS AAAA records.

        :param domain: The domain name to resolve.
        :return: A list of IPv6Address objects. An empty list if no AAAA records are found.
        """
        try:
            answers = self.dns_resolver.resolve(domain, "AAAA")
            return [ipaddress.IPv6Address(rdata.to_text()) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []

    def lookup_domain(self, domain: str) -> "ANY_ADDRESS":
        """
        Resolves a domain name to an IP address using DNS A/AAAA records.

        :param domain: The domain name to resolve.
        :return: An IPv4Address or IPv6Address object. Chooses a random address if multiple are found.
        :raises ResolutionError: If no A or AAAA records are found.
        """
        if self.dns_mode == DNSMode.IPV4_ONLY:
            records = self._lookup_a(domain)
        elif self.dns_mode == DNSMode.IPV6_ONLY:
            records = self._lookup_aaaa(domain)
        elif self.dns_mode == DNSMode.IPV4_FIRST:
            records = self._lookup_a(domain)
            if not records:
                records = self._lookup_aaaa(domain)
        else:  # DNSMode.IPV6_FIRST
            records = self._lookup_aaaa(domain)
            if not records:
                records = self._lookup_a(domain)

        if not records:
            raise ResolutionError(f"No DNS records found for domain: {domain}")
        random.shuffle(records)
        return records[0]

    def _srv_lookup(self, record_name: str) -> tuple["ANY_ADDRESS", int] | None:
        """
        Performs an SRV lookup and additional A/AAAA lookups for the target hosts,
        returning an (IP address, port) tuple, or None if no valid records are found.
        """
        try:
            answers = self.dns_resolver.resolve(record_name, "SRV")
            records = [(rdata.target.to_text(omit_final_dot=True), rdata.port) for rdata in answers]
            if records:
                records.sort(key=lambda x: (x[0], -x[1]), reverse=True)

                for record in records:
                    # Return the first one that can be resolved
                    target, port = record
                    try:
                        ip = ipaddress.ip_address(target)
                        return ip, port
                    except ValueError:
                        pass

                    try:
                        self.lookup_domain(target)
                        return target, port
                    except ResolutionError:
                        continue

        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            pass
        return None

    def modern_srv_lookup(self, domain: str) -> tuple[str, int] | None:
        """
        Performs an SRV lookup for _matrix-fed._tcp.<domain> as per the modern Matrix server name resolution process.

        :param domain: The domain name to look up.
        :return: A tuple of (target, port) if an SRV record is found, otherwise None.
        """
        return self._srv_lookup(f"_matrix-fed._tcp.{domain}")

    def deprecated_srv_lookup(self, domain: str) -> tuple[str, int] | None:
        """
        Performs an SRV lookup for _matrix._tcp.<domain> as per the deprecated Matrix server name resolution process.

        :param domain: The domain name to look up.
        :return: A tuple of (target, port) if an SRV record is found, otherwise None.
        """
        return self._srv_lookup(f"_matrix._tcp.{domain}")

    def srv_lookup(self, domain: str, allow_deprecated: bool = True) -> tuple[str, int] | tuple[None, None]:
        """
        Performs an SRV lookup for the given domain, first trying the modern _matrix-fed._tcp.<domain> record,
        and falling back to the deprecated _matrix._tcp.<domain> record if allowed.

        :param domain: The domain name to look up.
        :param allow_deprecated: Whether to allow falling back to the deprecated SRV record.
        :return: A tuple of (target, port) if an SRV record is found, otherwise None.
        """
        result = self.modern_srv_lookup(domain)
        if allow_deprecated and result is None:
            result = self.deprecated_srv_lookup(domain)
        if result is None or result[0] is None:
            return None, None
        return result

    def resolve_well_known(self, destination: ServerDestination) -> ServerDestination:
        """
        Performs resolution steps 3 through 3.5 of the server name resolution process.

        :param destination: The server name to resolve.
        :return: A ServerDestination object with the resolved address and port set.
        :raises ResolutionError: If the well-known file cannot be fetched or parsed.
        """
        url = f"https://{destination.hostname}/.well-known/matrix/server"
        try:
            self.log.debug("requesting well-known for %r", destination.hostname)
            response = self.client.get(url, headers={"Host": destination.hostname}).raise_for_status()
            data = limited_read(response, 1024 * 64, 1024 * 8)
            assert "m.server" in data, "Invalid well-known response"
            delegated_location = data["m.server"]
            self.log.debug("%r is delegated to %r", destination.hostname, delegated_location)
            assert SERVER_NAME_REGEX.match(delegated_location) is not None, "Invalid m.server value in well-known"
        except (httpx.RequestError, httpx.HTTPStatusError, ValueError, AssertionError) as e:
            raise ResolutionError("Failed to fetch or parse well-known file", e) from e

        ipv6, ipv4, delegated_hostname, delegated_port = SERVER_NAME_REGEX.match(delegated_location).groups()

        # 3.1: If <delegated_hostname> is an IP literal, then that IP address should be used together with the
        # <delegated_port> or 8448 if no port is provided.
        if ipv4 or ipv6:
            ip = ipv4 or ipv6
            self.log.debug("delegated hostname %r for %r is an IP literal", delegated_hostname, destination.hostname)
            destination.hostname = f"{ip}:{delegated_port or 8448}"
            destination.host_header = ip
            destination.sni = ip
            return destination

        # 3.2: If <delegated_hostname> is not an IP literal, and <delegated_port> is present, an IP address is
        # discovered by looking up CNAME, AAAA or A records for <delegated_hostname>.
        # The resulting IP address is used, alongside the <delegated_port>.
        # Requests must be made with a Host header of <delegated_hostname>:<delegated_port>.
        # The target server must present a valid certificate for <delegated_hostname>.
        if delegated_port:
            self.log.debug(
                "delegated hostname %r for %r includes explicit port, skipping SRV lookup",
                delegated_hostname,
                destination.hostname,
            )
            self.lookup_domain(delegated_hostname)
            destination.hostname = f"{delegated_hostname}:{delegated_port}"
            destination.host_header = f"{delegated_hostname}:{delegated_port}"
            destination.sni = delegated_hostname
            return destination

        # 3.3+3.4: If <delegated_hostname> is not an IP literal and no <delegated_port> is present,
        # an SRV record is looked up...
        self.log.debug(
            "%r delegates to %r without explicit port, performing SRV lookups", destination.hostname, delegated_hostname
        )
        new_address, new_port = self.srv_lookup(delegated_hostname)
        if new_address and new_port:
            self.log.debug("found SRV record for %r: %r:%d", delegated_hostname, new_address, new_port)
            destination.hostname = f"{new_address}:{new_port}"
            destination.host_header = delegated_hostname
            destination.sni = delegated_hostname
            return destination

        # 3.5: If no SRV record is found, an IP address is resolved using CNAME, AAAA or A records.
        # Requests are then made to the resolved IP address and a port of 8448,
        # using a Host header of <delegated_hostname>.
        self.log.debug("no SRV record found for %r, falling back to A/AAAA lookup", delegated_hostname)
        self.lookup_domain(delegated_hostname)
        destination.hostname = f"{delegated_hostname}:8448"
        destination.host_header = delegated_hostname
        destination.sni = delegated_hostname
        return destination

    def resolve(self, server_name: str) -> ServerDestination:
        if not (match := SERVER_NAME_REGEX.match(server_name)):
            raise ValueError("Invalid server name")

        ipv6, ipv4, hostname, port_str = match.groups()
        port = int(port_str) if port_str else 8448
        destination = ServerDestination(hostname=hostname)
        success = True

        # 1: If the hostname is an IP literal, then that IP address should be used, together with the given port number,
        # or 8448 if no port is given.
        if ipv4 or ipv6:
            self.log.debug("server name %r is an IP literal, skipping well-known and SRV lookups", server_name)
            ip = ipv4 or ipv6
            destination.hostname = f"{ip}:{port}"
            destination.sni = ip
            destination.host_header = server_name
        else:
            if port_str:
                self.log.debug(
                    "server name %r includes explicit port, skipping well-known and SRV lookups", server_name
                )
                # 2: If the hostname is not an IP literal, and the server name includes an explicit port,
                # resolve the hostname to an IP address using CNAME, AAAA or A records
                self.lookup_domain(hostname)
                destination.hostname = f"{hostname}:{port}"
                destination.host_header = server_name
            else:
                # 3: well-known shenanigans
                try:
                    destination = self.resolve_well_known(destination)
                except ResolutionError:
                    self.log.debug("well-known lookup failed for %r, falling back to SRV and A/AAAA lookups", hostname)
                    # 4: If the /.well-known request resulted in an error response,
                    # a server is found by resolving an SRV record
                    new_address, new_port = self.srv_lookup(hostname)
                    if new_address and new_port:
                        self.log.debug("found SRV record for %r: %r:%d", hostname, new_address, new_port)
                        destination.hostname = f"{new_address}:{new_port}"
                        destination.host_header = hostname
                        destination.sni = hostname
                    else:
                        # 6: If the /.well-known request returned an error response, and no SRV records were found,
                        # an IP address is resolved using CNAME, AAAA and A records.
                        # Requests are made to the resolved IP address using port 8448
                        # and a Host header containing the <hostname>
                        success = False
                        self.log.debug("no SRV record found for %r, falling back to A/AAAA lookup", hostname)
                        self.lookup_domain(hostname)
                        destination.hostname = f"{hostname}:8448"
                        destination.host_header = hostname
                        destination.sni = hostname
        self.cache.add(server_name, destination)
        if not success:
            # Mark as offline so that we re-resolve sooner
            # We might not actually be offline, but generally servername:8448 indicates a lookup error,
            # since most servers will have a well-known or SRV record.
            self.cache.mark_offline(server_name)
        return destination
