Litestar integration comes with a plugin, you just need to add it to litestar app:
```python hl_lines="24"
--8<-- "docs/code/integrations/litestar_.py"
```
