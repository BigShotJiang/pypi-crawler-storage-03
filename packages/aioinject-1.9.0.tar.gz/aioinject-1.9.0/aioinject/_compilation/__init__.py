from aioinject._compilation.compile import CompilationParams, compile_fn


__all__ = ["CompilationParams", "compile_fn"]
