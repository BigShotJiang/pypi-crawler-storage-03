from .xoflib import *

__doc__ = xoflib.__doc__
if hasattr(xoflib, "__all__"):
    __all__ = xoflib.__all__