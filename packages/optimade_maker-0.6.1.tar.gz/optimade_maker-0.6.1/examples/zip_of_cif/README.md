This example entry consists of a zipped folder of CIFs describing structural data, with a csv file describing the properties.

The corresponding yaml file has to describe where to find the cifs and how to
map between structure and property, plus it has to list the csv column names to
serve.
