__version__ = "0.1.15"

from autostore.autostore import AutoStore, AutoPath