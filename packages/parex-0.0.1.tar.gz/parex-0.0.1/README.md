# parex

Placeholder package for SEL internal use. Prevents package squatting on PyPI.

This package is private and contains no functionality.
