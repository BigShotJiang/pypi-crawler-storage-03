__version__ = "0.5.0"

IMAGE_TAG = "0.5.0"
