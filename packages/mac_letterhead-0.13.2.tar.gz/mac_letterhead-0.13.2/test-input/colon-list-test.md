# Colon-List Test

## Problem Case - No Blank Line After Colon
Here are the items:
- Item 1
- Item 2
  - Sub item 1
  - Sub item 2

## Working Case - With Blank Line After Colon
Here are the items:

- Item 1
- Item 2
  - Sub item 1
  - Sub item 2

## Another Problem Case
The following options are available:
- Option A
- Option B
  - Sub-option B1
  - Sub-option B2

## Another Working Case
The following options are available:

- Option A
- Option B
  - Sub-option B1
  - Sub-option B2