"""Tests for probabilistic supervised regressors."""
