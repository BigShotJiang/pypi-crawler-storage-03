"""Adapters for probability distribution objects."""
# copyright: skpro developers, BSD-3-Clause License (see LICENSE file)
