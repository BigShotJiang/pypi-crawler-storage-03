"""Conversion auxiliary utilities."""
