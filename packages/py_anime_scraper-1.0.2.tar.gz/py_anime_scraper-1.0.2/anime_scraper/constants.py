STAPE_DOWNLOAD_URL = "https://streamtape.com/get_video"
YOURUPLOAD_DOWNLOAD_URL = "https://yourupload.com/embed"

YOURUPLOAD_TIMEOUT = 10000
SW_TIMEOUT = 10000
MEDIAFIRE_TIMEOUT = 10000
