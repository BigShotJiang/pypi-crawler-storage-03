

class CommandBase:
    def add_arguments(self, parser):
        pass

    def run(self, args, config):
        pass
    