from healpix_geo.healpix_geo import slices as slices_

Slice = slices_.Slice  # noqa: F401
ConcreteSlice = slices_.ConcreteSlice  # noqa: F401
