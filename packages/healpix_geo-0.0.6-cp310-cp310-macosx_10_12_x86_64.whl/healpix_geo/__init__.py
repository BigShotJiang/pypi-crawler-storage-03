from healpix_geo import nested, ring, slices

__all__ = ["nested", "ring", "slices"]
