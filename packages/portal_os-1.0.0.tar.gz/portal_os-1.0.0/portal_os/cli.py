#!/usr/bin/env python3
"""
Portal OS - Central Management Script
Unified CLI wrapper with shared configuration system for all Portal OS components
"""
import os
import sys
import json
import subprocess
from pathlib import Path
import click
from datetime import datetime

# Fix Unicode encoding for Windows
import locale
import codecs
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

# Import Portal OS configuration
from .config import get_config, get_component_config, apply_profile

__version__ = "1.0.0"

class PortalOSCLI:
    """Portal OS Central CLI Wrapper"""
    
    def __init__(self):
        self.config_manager = get_config()
        self._setup_components()
    
    def _setup_components(self):
        """Setup component paths and configurations"""
        self.components = {
            "ai_assistant": {
                "name": "🤖 AI Assistant",
                "description": "Conversational AI assistant with context awareness",
                "script": "scripts/ai_assistant.py"
            },
            "security_privacy": {
                "name": "🔒 Security & Privacy",
                "description": "Advanced security and privacy management",
                "script": "scripts/security_privacy_manager.py"
            },
            "performance_optimizer": {
                "name": "⚡ Performance Optimizer",
                "description": "System performance optimization and monitoring",
                "script": "scripts/performance_optimizer.py"
            },
            "voice_interaction": {
                "name": "🎤 Voice Interaction",
                "description": "Speech-to-text and text-to-speech capabilities",
                "script": "scripts/voice_interaction.py"
            },
            "advanced_ai": {
                "name": "🧠 Advanced AI",
                "description": "AI-powered workspace management and code intelligence",
                "script": "scripts/advanced_ai_features.py"
            },
            "search_assistant": {
                "name": "🔍 Search Assistant",
                "description": "Intelligent file and content search",
                "script": "scripts/search_assistant_setup.py"
            },
            "theme_manager": {
                "name": "🎨 Theme Manager",
                "description": "Visual theme and appearance management",
                "script": "scripts/theme_manager.py"
            },
            "plugin_manager": {
                "name": "🔌 Plugin Manager",
                "description": "Plugin system management and updates",
                "script": "scripts/plugin_manager.py"
            },
            "ui_ux_manager": {
                "name": "🖥️ UI/UX Manager",
                "description": "User interface and experience management",
                "script": "scripts/ui_ux_manager.py"
            }
        }
    
    def show_status(self):
        """Show complete system status"""
        print("🚀 Portal OS - Complete System Status")
        print("=" * 60)
        print(f"📋 Version: {__version__}")
        print(f"📁 Portal Directory: {self.config_manager.portal_dir}")
        print(f"📄 Config File: {self.config_manager.config_file}")
        print()
        
        print("🔧 Component Status:")
        print("-" * 40)
        
        for component_id, component in self.components.items():
            status = "✅ Active" if self._check_component_status(component_id) else "❌ Inactive"
            print(f"{status} {component['name']}")
            print(f"   {component['description']}")
            print()
    
    def _check_component_status(self, component_id: str) -> bool:
        """Check if a component is active"""
        try:
            # Check if component is enabled in config
            config = get_component_config(component_id)
            if not config.get("enabled", False):
                return False
            
            # Check if component script exists
            script_path = Path(component_id.replace("_", "-") + ".py")
            if not script_path.exists():
                return False
            
            return True
        except Exception:
            return False
    
    def run_component(self, component_id: str, args: list = None):
        """Run a specific component"""
        if component_id not in self.components:
            print(f"❌ Component '{component_id}' not found")
            return False
        
        component = self.components[component_id]
        script_path = Path(component["script"])
        
        if not script_path.exists():
            print(f"❌ Script not found: {script_path}")
            return False
        
        try:
            cmd = [sys.executable, str(script_path)] + (args or [])
            result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
            
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(result.stderr, file=sys.stderr)
            
            return result.returncode == 0
        except Exception as e:
            print(f"❌ Error running component: {e}")
            return False

# Create CLI instance
cli_instance = PortalOSCLI()

@click.group()
@click.version_option(version=__version__, prog_name="Portal OS")
def cli():
    """Portal OS - AI-Native Developer Operating System
    
    A revolutionary operating system that combines Ubuntu's stability 
    with AI-first design principles, inspired by the OS1 from "Her" 
    and the clean aesthetics of Cutefish OS.
    """
    pass

@cli.command()
def version():
    """Show Portal OS version"""
    print(f"🚀 Portal OS v{__version__}")
    print(f"📅 Built on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🐍 Python: {sys.version.split()[0]}")
    print(f"💻 Platform: {sys.platform}")

@cli.command()
def status():
    """Show complete system status"""
    cli_instance.show_status()

@cli.command()
def config():
    """Show current configuration"""
    config_data = cli_instance.config_manager.config
    print("⚙️ Portal OS System Configuration:")
    print("=" * 40)
    print(json.dumps(config_data, indent=2, ensure_ascii=False))

@cli.command()
def profiles():
    """List available profiles"""
    profiles = cli_instance.config_manager.config.get("profiles", {})
    current_profile = cli_instance.config_manager.get("portal_os.current_profile", "developer")
    
    print("📋 Available Portal OS Profiles:")
    print("=" * 40)
    
    for profile_name, profile_data in profiles.items():
        status = " (CURRENT)" if profile_name == current_profile else ""
        print(f"🎯 {profile_name}{status}")
        print(f"   Description: {profile_data.get('description', 'No description')}")
        print(f"   Components: {', '.join(profile_data.get('components', []))}")
        print()

@cli.command()
@click.argument('profile_name')
def apply_profile_cmd(profile_name):
    """Apply a specific profile"""
    try:
        apply_profile(profile_name)
        print(f"✅ Profile '{profile_name}' applied successfully")
    except ValueError as e:
        print(f"❌ {e}")
        sys.exit(1)

@cli.command()
@click.argument('component')
@click.argument('args', nargs=-1)
def run(component, args):
    """Run a specific component"""
    success = cli_instance.run_component(component, list(args))
    if not success:
        sys.exit(1)

@cli.command()
def backup():
    """Create a backup of current configuration"""
    backup_file = cli_instance.config_manager.backup_config()
    if backup_file:
        print(f"✅ Configuration backed up to: {backup_file}")
    else:
        print("❌ Failed to create backup")
        sys.exit(1)

@cli.command()
@click.argument('backup_file')
def restore(backup_file):
    """Restore configuration from backup"""
    success = cli_instance.config_manager.restore_config(backup_file)
    if success:
        print("✅ Configuration restored successfully")
    else:
        print("❌ Failed to restore configuration")
        sys.exit(1)

@cli.command()
def update():
    """Check for updates"""
    print("🔄 Checking for Portal OS updates...")
    print("📦 Current version:", __version__)
    print("ℹ️ Update functionality coming soon!")

@cli.command()
def doctor():
    """Run system diagnostics"""
    print("🔍 Portal OS System Diagnostics")
    print("=" * 40)
    
    # Check Python version
    print(f"🐍 Python Version: {sys.version.split()[0]} ✅")
    
    # Check configuration
    try:
        config = get_config()
        print(f"⚙️ Configuration: Loaded ✅")
        print(f"📁 Portal Directory: {config.portal_dir} ✅")
    except Exception as e:
        print(f"❌ Configuration Error: {e}")
    
    # Check components
    print("\n🔧 Component Status:")
    for component_id, component in cli_instance.components.items():
        status = "✅" if cli_instance._check_component_status(component_id) else "❌"
        print(f"   {status} {component['name']}")
    
    print("\n✅ Diagnostics complete!")

def main():
    """Main entry point"""
    cli()

if __name__ == "__main__":
    main()
