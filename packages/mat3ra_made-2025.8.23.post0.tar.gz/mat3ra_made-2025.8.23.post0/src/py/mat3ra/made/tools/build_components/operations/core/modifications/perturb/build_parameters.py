from mat3ra.made.tools.build_components.entities.reusable.base_builder import BaseBuilderParameters


class PerturbationBuildParameters(BaseBuilderParameters):
    center_material: bool = True
