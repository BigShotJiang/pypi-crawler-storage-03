// TODO: adjust the imports and remove the need for re-exporting
import { math } from "@mat3ra/code/dist/js/math";

export default {
    ...math,
};
