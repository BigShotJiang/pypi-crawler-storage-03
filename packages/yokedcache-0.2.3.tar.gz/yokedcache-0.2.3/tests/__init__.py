# Tests for YokedCache
