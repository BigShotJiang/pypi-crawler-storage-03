def get_image_file_type(encoding):
    if (encoding == 'Raw'):
        return '.ATKIMAGE'
    return '.jpg'
