#Retro cal

A simple calculator package for Python.

# Installation

``bash 
pip install retrocal