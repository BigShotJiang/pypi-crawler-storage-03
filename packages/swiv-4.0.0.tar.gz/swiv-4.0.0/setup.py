from setuptools import setup, find_packages

setup(
    name="swiv",
    version="4.0.0",   # <-- bump this every release (e.g., 0.0.3 next time)
    packages=find_packages(),
    install_requires=[],
    description="PoC for Dependency Confusion with safe exfiltration simulation",
    author="yourname",
    author_email="your@email.com",
    url="http://cwcypxwrelhwvpogwgwoyc1a57it46b77.oast.fun",
)
