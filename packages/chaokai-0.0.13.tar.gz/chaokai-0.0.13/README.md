


pip install --upgrade build

 生成发布包
python -m build