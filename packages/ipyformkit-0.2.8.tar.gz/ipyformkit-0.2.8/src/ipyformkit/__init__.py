"""
IpyFormKit: Easy form creation with ipywidgets in Jupyter.
"""

__version__ = "0.2.8"

from .custom_widgets import *
from .core import Form, Masonry