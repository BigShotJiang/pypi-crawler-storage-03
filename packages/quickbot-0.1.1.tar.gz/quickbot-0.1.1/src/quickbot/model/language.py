from .bot_enum import BotEnum, EnumMember


class LanguageBase(BotEnum):
    EN = EnumMember("en", {"en": "🇬🇧 english"})
