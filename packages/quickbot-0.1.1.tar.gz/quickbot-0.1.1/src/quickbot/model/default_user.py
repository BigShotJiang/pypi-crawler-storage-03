from .user import UserBase


class DefaultUser(UserBase): ...
