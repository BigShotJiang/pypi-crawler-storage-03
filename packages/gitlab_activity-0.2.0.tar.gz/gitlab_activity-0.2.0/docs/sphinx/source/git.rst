.. role:: hidden
    :class: hidden-section


gitlab_activity.git
========================================================
.. automodule:: gitlab_activity.git
   :members:
