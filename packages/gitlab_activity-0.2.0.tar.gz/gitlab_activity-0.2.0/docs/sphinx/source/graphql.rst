.. role:: hidden
    :class: hidden-section


gitlab_activity.graphql
========================================================
.. automodule:: gitlab_activity.graphql
   :members:
