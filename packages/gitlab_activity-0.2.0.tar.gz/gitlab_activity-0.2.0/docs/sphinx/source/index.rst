.. gitlab-activity documentation master file, created by
   sphinx-quickstart on Mon Oct 30 17:03:14 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to gitlab-activity's API documentation!
=================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   cli
   lib
   graphql
   git
   cache
   utils

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
