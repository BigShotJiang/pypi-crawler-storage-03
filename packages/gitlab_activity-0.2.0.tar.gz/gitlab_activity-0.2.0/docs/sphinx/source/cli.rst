.. role:: hidden
    :class: hidden-section


gitlab_activity.cli
========================================================
.. automodule:: gitlab_activity.cli
   :members:
