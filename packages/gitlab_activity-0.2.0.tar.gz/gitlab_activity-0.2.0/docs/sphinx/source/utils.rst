.. role:: hidden
    :class: hidden-section


gitlab_activity.utils
========================================================
.. automodule:: gitlab_activity.utils
   :members:
