# Build API documentation using Sphinx

This folder contains source files to create API documentation for `gitlab-activity`.

To make the documentation,

```
make html
```

This will build the documentation in `website/static/api` folder which will be served
by docusaurus.
