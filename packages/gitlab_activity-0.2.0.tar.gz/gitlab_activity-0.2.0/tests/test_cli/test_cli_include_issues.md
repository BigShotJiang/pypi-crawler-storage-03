

### New features added

- Label based feature issue [#2](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/issues/2) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

### Documentation improvements

- Docs feature that is closed by MR [#3](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/issues/3) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Opened Issues

### New features added

- FEAT:  Title based feature issue [#1](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/issues/1) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

### Maintenance and upkeep improvements

- Multi labelled issue [#6](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/issues/6) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))
- Maintenance related issue [#4](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/issues/4) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

### Unlabelled Opened Issues

- Other labelled issue [#5](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/issues/5) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))