# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->
<!-- <END NEW CHANGELOG ENTRY> -->

## v3.1.0 (2023-11-10)

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/a6bf475c8bd2a4539b0497107aa61c77a12c534e...8da3007ba86bdb292bafb7d87b4cbef54b27c8f5?from_project_id=51638705&straight=false))

### Enhancements made

- IMPROVE: Add hello notebook [!8](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/8) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

### Maintenance and upkeep improvements

- Update python helloworld [!11](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/11) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## v3.0.0

### foo

- foo1
- foo2

### bar

- bar1
- bar2

## v2.0.0

### foo

- foo1
- foo2

### bar

- bar1
- bar2