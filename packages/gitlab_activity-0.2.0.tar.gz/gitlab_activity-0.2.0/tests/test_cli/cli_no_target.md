# main@{2023-09-01}...main@{2023-10-28}

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity/-/compare/9a33c9d6803c8e13c3bccc6d070023cc65dcc481...d2834753b8000e0d64703d6799813750b7b66bff?from_project_id=51534402&straight=false))

## New features added

- Add source code [!1](https://gitlab.com/mahendrapaipuri/gitlab-activity/-/merge_requests/1) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Enhancements made

- Look for auth token from CI vars [!4](https://gitlab.com/mahendrapaipuri/gitlab-activity/-/merge_requests/4) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))
- Get created and also merged/closed activity [!3](https://gitlab.com/mahendrapaipuri/gitlab-activity/-/merge_requests/3) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))
- Improve API and grouping logic [!2](https://gitlab.com/mahendrapaipuri/gitlab-activity/-/merge_requests/2) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Maintenance and upkeep improvements

- Improve API and grouping logic [!2](https://gitlab.com/mahendrapaipuri/gitlab-activity/-/merge_requests/2) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))