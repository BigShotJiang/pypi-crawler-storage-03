
## v3.0.0 (2023-10-27)

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/2e9fc31c99210a3203138ad85f0f789be66bbede...a6bf475c8bd2a4539b0497107aa61c77a12c534e?from_project_id=51638705&straight=false))

### Bugs fixed

- Add bugfix to CI [!9](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/9) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## v2.1.0 (2023-10-27)


## v2.0.0 (2023-10-27)

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/c910fe9344d30afca9d7161f50683f2d26723dbb...59e8bd6f423515af80e58e2fe82a8ab2cab52c44?from_project_id=51638705&straight=false))

### Documentation improvements

- Add docs [!7](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/7) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

### Unlabelled Merged MRs

- Add bash hello world [!6](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/6) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## v1.0.0 (2023-10-27)

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/74a5ab6db729379f20f8c459322379f2d8f3e08e...c910fe9344d30afca9d7161f50683f2d26723dbb?from_project_id=51638705&straight=false))

### New features added

- Add Python hello world [!4](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/4) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## v0.2.0 (2023-10-27)

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/a0cb7ed07c74d7bdefe6fa133f6514e212d57cc0...74a5ab6db729379f20f8c459322379f2d8f3e08e?from_project_id=51638705&straight=false))

### Enhancements made

- Add CI job file [!3](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/3) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## v0.1.0 (2023-10-27)

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/dd9ca450921705b00d8d6a40ea0c8de957db7739...a0cb7ed07c74d7bdefe6fa133f6514e212d57cc0?from_project_id=51638705&straight=false))

### Maintenance and upkeep improvements

- Add gitignore file [!2](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/2) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

### Documentation improvements

- Update README [!1](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/1) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))
