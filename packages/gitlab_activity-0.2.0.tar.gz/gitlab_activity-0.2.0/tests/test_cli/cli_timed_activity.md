# main@{2023-10-20}...main@{2023-10-28}

([Full Changelog](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/compare/5c7bebd33d060f6ce954383443c6caff1af4ba10...a6bf475c8bd2a4539b0497107aa61c77a12c534e?from_project_id=51638705&straight=false))

## New features added

- Add Python hello world [!4](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/4) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Enhancements made

- IMPROVE: Add hello notebook [!8](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/8) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))
- Add CI job file [!3](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/3) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Bugs fixed

- Add bugfix to CI [!9](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/9) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Maintenance and upkeep improvements

- Add gitignore file [!2](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/2) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Documentation improvements

- Add docs [!7](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/7) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))
- Update README [!1](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/1) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))

## Unlabelled Merged MRs

- Add bash hello world [!6](https://gitlab.com/mahendrapaipuri/gitlab-activity-tests/-/merge_requests/6) ([@mahendrapaipuri](https://gitlab.com/mahendrapaipuri))