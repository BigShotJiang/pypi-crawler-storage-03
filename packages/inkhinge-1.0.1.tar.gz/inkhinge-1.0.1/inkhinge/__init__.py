"""inkhinge - 一个专为光谱分析设计的下一代深度学习工具集"""

__version__ = '1.0.1'
__author__ = 'Fenglong Li,Siyang Li,Kehan Li,Zhiqing Guo,Kailong Fan'
__email__ = '15340666394@163.com'
__license__ = 'MIT'
__url__ = 'https://github.com/1412universe/inkhinge'