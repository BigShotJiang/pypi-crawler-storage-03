"""Assistant service for ubo-app."""
