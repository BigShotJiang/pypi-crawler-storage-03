
from setuptools import setup, find_packages

setup(
    name="kittycolors",
    version="1.0.0",
    description="color lib dats kewlio",
    author="g4",
    author_email="defnotg4@gmail.com",
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.6',
)

