Security
========

If you think you have found a potential security vulnerability in ``joserfc``,
please email <me@lepture.com> directly.

.. warning:: Do not file a public issue.

Please do not disclose this to anyone else. We will retrieve a CVE identifier
if necessary and give you full credit under whatever name or alias you provide.
We will only request an identifier when we have a fix and can publish it in
a release.

The Process
-----------

Here is the process when we have received a security report:

1. we will reply to you in 24 hours
2. we will confirm it in 2 days, if we can't reproduce it, we will send emails
   to you for more information
3. we will fix the issue in 1 week after we confirm it. If we can't fix it for
   the moment, we will let you know.
4. we will push the source code to GitHub when it has been released in PyPI
   for 1 week.
5. if necessary, we will retrieve a CVE after releasing to PyPI.

Previous CVEs
-------------

- CVE-2024-37568: fixed in 0.11.0

CWE fixes
----------

- CWE-290: fixed in 1.1.0
