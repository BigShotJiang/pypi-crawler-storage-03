(models-cisco)=

# ciscoconfparse2.models_cisco

```{eval-rst}
.. autoclass:: ciscoconfparse2.models_cisco.TrackingInterface
   :members:
   :undoc-members:
   :inherited-members:
```

```{eval-rst}
.. autoclass:: ciscoconfparse2.models_cisco.HSRPInterfaceGroup
   :members:
   :undoc-members:
   :inherited-members:

```

```{eval-rst}
.. autoclass:: ciscoconfparse2.models_cisco.IOSCfgLine
   :members:
   :undoc-members:
   :inherited-members:
```

```{eval-rst}
.. autoclass:: ciscoconfparse2.models_cisco.IOSIntfLine
   :members:
   :undoc-members:
   :inherited-members:
```
