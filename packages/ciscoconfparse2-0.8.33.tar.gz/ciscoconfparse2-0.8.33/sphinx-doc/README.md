
Building the ccp documentation package comes down to this one wierd trick:

- `cd sphinx-doc/`
- `pip install ciscoconfparse`
- `make html`
