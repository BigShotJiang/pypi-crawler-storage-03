# -*- coding: utf-8 -*-
CHECKMARK = "✔"
CROSSMARK = "✘"
