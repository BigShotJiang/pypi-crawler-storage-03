### weighted_band_sum

Compute a weighted sum across all bands in a raster.

- Tool: `weighted_band_sum`

Parameters

- source (string)
- weights (array of numbers summing to 1)
- destination (string)

Returns

- destination; status, message
