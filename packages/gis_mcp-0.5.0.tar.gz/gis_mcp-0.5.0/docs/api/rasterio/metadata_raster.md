### metadata_raster

Open a raster (local path or HTTPS URL) and return core metadata.

- Tool: `metadata_raster`

Parameters

- path_or_url (string)

Returns

- metadata object including name, mode, driver, width, height, count, bounds, band_dtypes, no_data, crs, transform; status, message
