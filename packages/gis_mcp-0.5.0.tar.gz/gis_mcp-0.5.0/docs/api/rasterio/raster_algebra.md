### raster_algebra

Perform addition or subtraction on two rasters' bands; handles alignment.

- Tool: `raster_algebra`

Parameters

- raster1 (string)
- raster2 (string)
- band_index (integer, 1-based)
- operation (string: "add" | "subtract")
- destination (string)

Returns

- destination; status, message
