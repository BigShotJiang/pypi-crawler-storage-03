### get_raster_crs

Retrieve the CRS of a raster in PROJ dict and WKT string.

- Tool: `get_raster_crs`

Parameters

- path_or_url (string)

Returns

- proj4 (object), wkt (string); status, message
