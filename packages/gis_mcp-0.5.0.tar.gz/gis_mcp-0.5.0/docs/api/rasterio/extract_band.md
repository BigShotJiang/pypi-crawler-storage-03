### extract_band

Extract a single band from a multi-band raster and write it.

- Tool: `extract_band`

Parameters

- source (string)
- band_index (integer, 1-based)
- destination (string)

Returns

- destination; status, message
