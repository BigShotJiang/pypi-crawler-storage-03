### tile_raster

Split a raster into square tiles and write them to a directory.

- Tool: `tile_raster`

Parameters

- source (string)
- tile_size (integer)
- destination_dir (string)

Returns

- tiles_created (integer); status, message
