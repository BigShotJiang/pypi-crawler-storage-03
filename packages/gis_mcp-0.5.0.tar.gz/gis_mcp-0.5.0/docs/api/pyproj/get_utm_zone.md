### get_utm_zone

Return the UTM zone code for given lon/lat.

- Tool: `get_utm_zone`

Parameters

- coordinates (array [lon, lat])

Returns

- zone (string), status, message
