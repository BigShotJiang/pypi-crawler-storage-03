### get_utm_crs

Return a UTM CRS (WKT) for given lon/lat.

- Tool: `get_utm_crs`

Parameters

- coordinates (array [lon, lat])

Returns

- crs (string, WKT), status, message
