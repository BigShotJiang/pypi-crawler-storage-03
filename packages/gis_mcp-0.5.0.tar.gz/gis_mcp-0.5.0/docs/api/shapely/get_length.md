### get_length

Return the length of a geometry.

- Tool: `get_length`

Parameters

- geometry (string, WKT)

Returns

- length (number), status, message
