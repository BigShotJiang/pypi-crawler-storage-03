### envelope

Return the axis-aligned bounding box polygon of a geometry.

- Tool: `envelope`

Parameters

- geometry (string, WKT)

Returns

- geometry (string, WKT), status, message
