### is_valid

Check if a geometry is valid.

- Tool: `is_valid`

Parameters

- geometry (string, WKT)

Returns

- is_valid (boolean), status, message
