### get_coordinates

Return coordinates of a LineString or LinearRing.

- Tool: `get_coordinates`

Parameters

- geometry (string, WKT)

Returns

- coordinates (array of [x, y]), status, message
