### make_valid

Make a geometry valid.

- Tool: `make_valid`

Parameters

- geometry (string, WKT)

Returns

- geometry (string, WKT), status, message
