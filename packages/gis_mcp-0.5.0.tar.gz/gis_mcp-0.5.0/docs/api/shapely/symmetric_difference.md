### symmetric_difference

Find the symmetric difference of two geometries.

- Tool: `symmetric_difference`

Parameters

- geometry1 (string, WKT)
- geometry2 (string, WKT)

Returns

- geometry (string, WKT), status, message
