### simplify

Simplify a geometry with a tolerance.

- Tool: `simplify`

Parameters

- geometry (string, WKT)
- tolerance (number)
- preserve_topology (boolean, default true)

Returns

- geometry (string, WKT), status, message
