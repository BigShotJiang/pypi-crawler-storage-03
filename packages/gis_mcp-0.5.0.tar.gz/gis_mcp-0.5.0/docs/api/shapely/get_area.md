### get_area

Return the area of a geometry.

- Tool: `get_area`

Parameters

- geometry (string, WKT)

Returns

- area (number), status, message
