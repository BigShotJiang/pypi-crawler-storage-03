### Installations Overview

Pick the path that matches your setup:

- Smithery - see Smithery
- pip install with client configuration: see pip
- Development (editable) install with client configuration: see Developers
