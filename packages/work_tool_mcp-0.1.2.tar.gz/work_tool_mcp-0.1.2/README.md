
```json
{
  "mcpServers": {
    "work-tool-mcp": {
      "name": "work-tool-mcp",
      "command": "uvx",
      "args": [ "work-tool-mcp", "stdio" ]
    }
  }
}
```