"""Convenience functions and classes for common libraries."""
