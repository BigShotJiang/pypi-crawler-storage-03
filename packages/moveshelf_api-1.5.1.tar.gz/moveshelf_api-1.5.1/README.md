# Moveshelf Python API package

```sh
pip install moveshelf-api
```