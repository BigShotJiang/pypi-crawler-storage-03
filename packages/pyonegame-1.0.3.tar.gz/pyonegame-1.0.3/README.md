Installing
------
Enter in your __bash__:

    $ pip install pyonegame

Using
------
Enter in your __bash__:

    $ py -m pyonegame.run

