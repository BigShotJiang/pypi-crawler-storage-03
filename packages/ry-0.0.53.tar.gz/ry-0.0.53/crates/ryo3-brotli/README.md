# `ryo3-brotli`

ryo3-wrapper for `brotli` crate

[//]: # "<GENERATED>"

## Ref:

- docs.rs: [https://docs.rs/brotli](https://docs.rs/brotli)
- crates: [https://crates.io/crates/brotli](https://crates.io/crates/brotli)

[//]: # "</GENERATED>"
