from .far_fields import FarField
from .stokes import Stokes
from .spf import SPF
from .s1s2 import S1S2
from .near_field import NearField
from .footprint import Footprint
from .base import BaseRepresentation
