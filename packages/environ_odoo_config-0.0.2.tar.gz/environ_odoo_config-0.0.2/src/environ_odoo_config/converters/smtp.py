from typing import Any, Set

from ..api_converter import OdooConfigConverter, OnlyCli, RepeatableKey, SimpleKey


class ConfigConverterSmtp(OdooConfigConverter):
    """
    convert environment variable related the smtp configuration
    """

    _opt_group = "Smtp Configuration"
    load_language: Set[str] = RepeatableKey()
    overwrite_existing_translations: bool = SimpleKey(
        "I18N_OVERRIDE",
        cli=["--i18n-overwrite"],
        info="overwrites existing translation terms on updating a module or importing a CSV or a PO file.",
    )
    _cli_i18n: Any = OnlyCli("--load-language", "-l", "--language", "--i18n-export", "--i18n-import", "--modules")
