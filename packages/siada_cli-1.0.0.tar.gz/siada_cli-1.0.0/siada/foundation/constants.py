LLM_API_CONNECT_TIMEOUT = 30  # timeout for connecting to the API and sending the request (seconds)
LLM_API_READ_TIMEOUT = 600  # timeout for receiving the response (seconds)