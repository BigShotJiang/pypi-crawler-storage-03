"""
Siada Hub 命令行工具入口点
"""
