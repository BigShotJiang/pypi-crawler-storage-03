"""LangExtract provider plugin for Anthropic Claude."""

from langextract_anthropic.provider import AnthropicLanguageModel

__all__ = ['AnthropicLanguageModel']
__version__ = "0.2.1"
