class Integration:
    def __init__(self, integration_name: str, integration_version: str, dependency_name: str):
        self.integration_name = integration_name
        self.integration_version = integration_version
        self.dependency_name = dependency_name
