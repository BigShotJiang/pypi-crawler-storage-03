from ._utils import lru_cache

__all__ = ["lru_cache"]
