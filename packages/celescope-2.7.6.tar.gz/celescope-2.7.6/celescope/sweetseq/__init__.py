__ASSAY__ = "sweetseq"
STEPS = ["sample", "barcode", "mapping_tag", "count_tag", "analysis_tag"]
