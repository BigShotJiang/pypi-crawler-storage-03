STEPS = [
    "sample",
    "starsolo",
    "pathseq",
    "count_pathseq",
    "analysis_pathseq",
]
__ASSAY__ = "pathseq"
