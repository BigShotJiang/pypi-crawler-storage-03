STEPS = ["sample", "starsolo", "analysis", "conversion", "substitution", "replacement"]

__ASSAY__ = "dynaseq"

IMPORT_DICT = {
    "analysis": "celescope.rna",
}


# count
DYNA_MATRIX_DIR_SUFFIX = ["labeled", "unlabeled"]
