"""
This is a basic doctest demonstrating that the package and pydra can both be successfully
imported.

>>> import pydra.engine
>>> from pydra.tasks.fastsurfer.v1 import fastsurfer
"""
from ._version import __version__
