PACKAGE_VERSION = "v2.2"

from .v2_2 import Fastsurfer  # noqa
