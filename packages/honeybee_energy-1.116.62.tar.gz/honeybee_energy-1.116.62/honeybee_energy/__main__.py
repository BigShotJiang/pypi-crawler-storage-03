from honeybee_energy.cli import energy

if __name__ == '__main__':
    energy()
