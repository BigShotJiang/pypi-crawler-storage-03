# -*- coding: UTF-8 -*-
# Copyright 2016 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""
The `contacts` fixtures specific to :ref:`psico`.

.. autosummary::
   :toctree:

    std
    demo


"""
