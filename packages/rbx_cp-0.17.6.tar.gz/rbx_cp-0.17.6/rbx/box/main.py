# flake8: noqa
import nest_asyncio

nest_asyncio.apply()

from rbx.box.cli import app
