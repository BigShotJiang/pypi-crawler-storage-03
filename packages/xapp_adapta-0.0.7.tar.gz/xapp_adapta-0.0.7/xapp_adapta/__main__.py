# as -m switch option run
