=======
History
=======

0.2.1 (2024-01-11)
------------------

* First release featured on PyPI.
