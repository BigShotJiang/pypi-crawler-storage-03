"""Custom exceptions placeholder."""


class QQGJYXError(Exception):
    """Base exception for qqgjyx."""


__all__ = ["QQGJYXError"]


