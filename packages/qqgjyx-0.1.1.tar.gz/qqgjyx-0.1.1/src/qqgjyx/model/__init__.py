"""Models namespace (placeholder)."""

__all__ = []


