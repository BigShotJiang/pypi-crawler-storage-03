=======
kwparse
=======

Overview
--------

kwparse

Installation
------------

To install ``kwparse``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install kwparse

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/kwparse/#files>`_
* `Index <https://pypi.org/project/kwparse/>`_
* `Source <https://github.com/johannes-programming/kwparse/>`_

Credits
-------

* Author: Johannes
* Email: `johannes.programming@gmail.com <mailto:johannes.programming@gmail.com>`_

Thank you for using ``kwparse``!