from kwparse.core import *
from kwparse.tests import *

if __name__ == "__main__":
    main()
