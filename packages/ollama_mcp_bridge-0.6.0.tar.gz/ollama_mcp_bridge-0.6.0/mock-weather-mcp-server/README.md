# Mock Weather MCP Server

This is just a mock implementation of a weather MCP server for testing purposes.
