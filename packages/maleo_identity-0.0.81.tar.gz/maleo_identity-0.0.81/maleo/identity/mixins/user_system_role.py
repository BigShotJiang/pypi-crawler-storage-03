from maleo.soma.mixins.parameter import Expand as BaseExpand
from maleo.identity.enums.user_system_role import ExpandableField


class Expand(BaseExpand[ExpandableField]):
    pass
