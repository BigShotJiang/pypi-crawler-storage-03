
#to use the package as a module, if etlup becomes stable I will switch it or if we do more packages

# from etlup.src.etlup import data_models
