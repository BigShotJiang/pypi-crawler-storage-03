# Import all test classes from Tamalero modules
from .BaselineNoisewidth import BaselineNoisewidthV0
from .ModuleETROCStatus import ModuleETROCStatusV0
