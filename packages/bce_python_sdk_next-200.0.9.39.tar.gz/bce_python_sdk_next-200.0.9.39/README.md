# bce-python-sdk三方版

## 安装

- 本地安装

```
python setup.py install
```

- pip安装

```
pip install bce-python-sdk-next
```
