import sweatstack as ss


print("\n")
print(">>>>>>>>>> Sweat Stack Initialization <<<<<<<<<")
print("Initializing....")

ss.authenticate()