"""Mirrai: Multimodal AI agent for desktop automation via screenshots and tool use"""

__version__ = "0.1.0"
