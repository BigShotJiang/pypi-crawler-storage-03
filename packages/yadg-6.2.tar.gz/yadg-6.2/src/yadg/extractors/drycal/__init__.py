"""
Extractors for files from MesaLabs DryCal Pro software for Defender flow meters.

"""
