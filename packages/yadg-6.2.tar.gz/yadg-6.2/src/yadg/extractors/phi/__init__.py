"""
An extractor for data files from PHI X-ray photoelectron spectrometers.

"""
