"""
A basic tabulated file extractor.

"""
