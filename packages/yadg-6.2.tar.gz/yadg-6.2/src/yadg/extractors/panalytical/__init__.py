"""
Extractors for various exports of Panalytical X-ray diffractograms.

"""
