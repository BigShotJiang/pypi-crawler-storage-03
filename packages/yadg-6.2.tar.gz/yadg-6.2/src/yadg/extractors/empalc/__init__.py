"""
A custom extractor for processing liquid chromatography data exported from the Agilent
Online LC in the Materials for Energy Conversion lab at Empa.

"""
