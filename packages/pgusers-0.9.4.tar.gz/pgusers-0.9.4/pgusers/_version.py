
__version_info__ = (0, 9, 4)
__version__ = "{0}.{1}.{2}".format(*__version_info__)
