# Kubeflow SDK

[![Coverage Status](https://coveralls.io/repos/github/kubeflow/sdk/badge.svg?branch=main)](https://coveralls.io/github/kubeflow/sdk?branch=main)

## Overview

Kubeflow SDK streamlines user experience for data scientists and ML engineers to interact with
various Kubeflow projects.

Design doc: https://docs.google.com/document/d/1rX7ELAHRb_lvh0Y7BK1HBYAbA0zi9enB0F_358ZC58w/edit
