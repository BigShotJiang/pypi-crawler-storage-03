# setup.py
from setuptools import setup

# All configuration is managed in pyproject.toml.
# This file exists for backward compatibility.
setup()
