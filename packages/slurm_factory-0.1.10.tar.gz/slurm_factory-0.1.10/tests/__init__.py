"""Tests for slurm-factory package."""
