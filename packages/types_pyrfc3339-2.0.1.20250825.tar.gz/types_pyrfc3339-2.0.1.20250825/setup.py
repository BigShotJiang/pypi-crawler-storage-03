
from setuptools import setup

setup(package_data={'pyrfc3339-stubs': ['__init__.pyi', 'generator.pyi', 'parser.pyi', 'utils.pyi', 'METADATA.toml', 'py.typed']})
