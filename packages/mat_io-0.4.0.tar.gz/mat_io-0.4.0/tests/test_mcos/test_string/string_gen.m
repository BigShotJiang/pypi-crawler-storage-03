s1 = "Hello";
s2 = ["Apple", "Banana", "Cherry"; "Date", "Fig", "Grapes"];
s3 = "";

save('test_string_v7.mat', 's1', 's2', 's3', '-v7');
save('test_string_v73.mat', 's1', 's2', 's3', '-v7.3');
