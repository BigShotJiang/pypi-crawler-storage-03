classdef NoConstructor
    properties
        a;
        b;
        c;
    end
end
