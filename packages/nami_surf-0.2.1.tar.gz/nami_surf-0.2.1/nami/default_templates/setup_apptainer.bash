sudo add-apt-repository -y ppa:apptainer/ppa
sudo apt update
sudo apt install -y apptainer