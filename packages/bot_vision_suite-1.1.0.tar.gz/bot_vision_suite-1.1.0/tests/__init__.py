# Tests for bot-vision-suite package
