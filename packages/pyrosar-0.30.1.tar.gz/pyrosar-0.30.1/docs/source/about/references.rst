.. only:: html or text

    References
    ==========

.. bibliography::
    :style: plain
