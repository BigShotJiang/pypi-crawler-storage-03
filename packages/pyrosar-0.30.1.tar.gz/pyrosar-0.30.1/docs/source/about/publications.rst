############
Publications
############

.. bibliography::
    :style: plain
    :list: bullet
    :filter: author % "Truckenbrodt"