######################
Projects using pyroSAR
######################

pyroSAR is/was used in these projects:

- `BACI <http://www.baci-h2020.eu/index.php/Main/HomePage>`_
- `CCI Biomass <https://climate.esa.int/en/projects/biomass/>`_
- `COPA <https://sentinel.esa.int/web/sentinel/sentinel-1-ard-normalised-radar-backscatter-nrb-product>`_
- `EMSAfrica <https://www.emsafrica.org/>`_
- `GlobBiomass <https://globbiomass.org/>`_
- `SALDi <https://www.saldi.uni-jena.de/>`_
- `SenThIS <https://eos-jena.com/en/projects/>`_
- `Sentinel4REDD <https://www.dlr.de/rd/en/Portaldata/28/Resources/dokumente/re/Projektblatt_Sentinel4REDD_engl.pdf>`_
- `SWOS <https://www.swos-service.eu/>`_
- `BONDS <https://www.biodiversa.org/1418>`_

You know of other projects? We'd be happy to know.
