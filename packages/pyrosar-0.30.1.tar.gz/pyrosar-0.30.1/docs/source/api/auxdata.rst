Auxiliary Data Tools
====================

.. automodule:: pyroSAR.auxdata
    :members: dem_autoload, dem_create, get_egm_lookup, getasse30_hdr, get_dem_options, DEMHandler
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        dem_autoload
        dem_create
        get_egm_lookup
        getasse30_hdr
        get_dem_options
        DEMHandler
