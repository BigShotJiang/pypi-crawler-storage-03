workflow files were created with the yED Graph Editor (https://www.yworks.com/products/yed)

setting the vector bridge style:
Preferences -> Display -> Bridge Style
