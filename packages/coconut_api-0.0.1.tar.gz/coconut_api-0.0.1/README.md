# :coconut: Coconut: A python backend framework

## Description

A middleware rich python framework for building backend web applications. Just like an coconut has shells, this framework is built around stackable middlewares that let you compose functionality in a clean and modular way.

## Status

:gear: Early development stage
