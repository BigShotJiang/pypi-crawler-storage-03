class Coconut:
    def __init__(self):
        print("Testing Coconut v0.0.1")
        pass
