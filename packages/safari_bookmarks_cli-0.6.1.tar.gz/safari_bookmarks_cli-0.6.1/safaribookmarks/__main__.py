from .main import main
import sys

main()
