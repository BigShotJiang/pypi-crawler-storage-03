from .safaribookmarks import SafariBookmarks, SafariBookmarkItem

open = SafariBookmarks.open

__all__ = ["SafariBookmarks", "SafariBookmarkItem", "open"]
