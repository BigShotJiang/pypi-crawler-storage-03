from django.apps import AppConfig


class Config(AppConfig):
    name = "example.book"
