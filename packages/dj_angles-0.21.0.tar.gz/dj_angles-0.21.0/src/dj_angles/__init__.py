from dj_angles.tags import Tag
from dj_angles.template_loader import Loader

__all__ = [
    "Loader",
    "Tag",
]
