from dj_angles.caseconverter.kebab import kebabify

__all__ = [
    "kebabify",
]
