import os

QT_VERSION = os.environ.get("EDIFICE_QT_VERSION", "PySide6")
