if __name__ == "__main__":
    from .runner import runner

    runner()
