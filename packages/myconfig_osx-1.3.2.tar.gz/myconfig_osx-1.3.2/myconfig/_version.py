"""Version information"""

VERSION = "1.3.2"
__version__ = VERSION
