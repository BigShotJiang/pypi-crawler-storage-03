This module extends `fieldservice_kanban_info` to show the route information in the kanban view of the field service orders.
