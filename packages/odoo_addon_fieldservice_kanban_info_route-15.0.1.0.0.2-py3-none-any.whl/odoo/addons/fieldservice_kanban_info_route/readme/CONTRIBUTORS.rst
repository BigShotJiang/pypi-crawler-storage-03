* `APSL-Nagarro <https://www.apsl.tech>`_:
  * Patryk Pyczko <ppyczko@apsl.net>
