* Navigate to Field Service.
* Create or edit a Field Service Order. Assign a route to the order's location.
* Go to the Kanban view.
* The route information will be displayed in the kanban card.
