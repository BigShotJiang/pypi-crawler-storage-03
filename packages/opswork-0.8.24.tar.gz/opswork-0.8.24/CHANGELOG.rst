=========
Changelog
=========

Version 0.8.1
=============

- Fix error from undefined class.


Version 0.8.0
=============

- Remove AI command.


Version 0.7.3
=============

- Fix issue.


Version 0.7.2
=============

- Fix issue.


Version 0.7.1
=============

- Fix a bug in recipe clone.


Version 0.7.0
=============

- Support AI with Google PaLM.


Version 0.6.0
=============

- Support remote recipes.


Version 0.5.1
=============

- Fix secret listing


Version 0.5.0
=============

- Encrypt credentials


Version 0.4.0
=============

- Support secrets.


Version 0.3.0
=============

- Support vars override


Version 0.2.0
=============

- Add random password command


Version 0.1.0
=============

- Initial Release.
