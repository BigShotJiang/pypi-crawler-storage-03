from .core import dustmaps3d

__version__ = '2.2.11'
__all__ = ['dustmaps3d']
