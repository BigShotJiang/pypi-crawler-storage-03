from typing import Any

MongoStep = dict[str, Any]
