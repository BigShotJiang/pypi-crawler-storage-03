from typing import Any

ColumnName = str
# Pipeline = List[dict]
TemplatedVariable = Any
