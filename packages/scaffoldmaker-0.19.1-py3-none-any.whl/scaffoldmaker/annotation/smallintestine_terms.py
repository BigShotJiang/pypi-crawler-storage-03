"""
Common resource for small intestine annotation terms.
"""

# convention: preferred name, preferred id, followed by any other ids and alternative names
smallintestine_terms = [
    ("circular-longitudinal muscle interface of first segment of the duodenum along the gastric-omentum attachment", "ILX:0793090"),
    ("circular muscle layer of ileum", "ILX:0776561"),
    ("circular muscle layer of small intestine", "ILX:0772669"),
    ("duodenum", "UBERON:0002114", "ILX:0726125", "FMA:7206"),
    ("ileocecal junction", "UBERON:0001073", "ILX:0730012", "FMA:11338"),
    ("ileum", "UBERON:0002116", "ILX:0728151", "FMA:7208"),
    ("jejunum", "UBERON:0002115", "ILX:0724224", "FMA:7207"),
    ("longitudinal muscle layer of ileum", "ILX:0770304"),
    ("longitudinal muscle layer of small intestine", "ILX:0772125"),
    ("luminal surface of duodenum", "ILX:0793121"),
    ("mucosa of ileum", "ILX:0770578"),
    ("mucosa of small intestine", "UBERON:0001204", "ILX:0770578", "FMA:14933"),
    ("serosa of duodenum", "UBERON:0003336", "ILX:0732373", "FMA:14948"),
    ("serosa of ileum", "ILX:0774472"),
    ("serosa of small intestine", "UBERON:0001206", "ILX:0727465", "FMA:14938"),
    ("small intestine", "UBERON:0002108", "ILX:0726770", "FMA:7200"),
    ("submucosa of ileum", "UBERON:0004946", "ILX:0734297", "FMA:14957"),
    ("submucosa of small intestine", "UBERON:0001205", "ILX:0735609", "FMA:14934")
    ]


def get_smallintestine_term(name: str):
    """
    Find term by matching name to any identifier held for a term.
    Raise exception if name not found.
    :return ( preferred name, preferred id )
    """
    for term in smallintestine_terms:
        if name in term:
            return (term[0], term[1])
    raise NameError("Small intestine annotation term '" + name + "' not found.")
