#!/usr/bin/env python3
"""
md_to_word_mcp package
"""

__version__ = "0.1.0"
