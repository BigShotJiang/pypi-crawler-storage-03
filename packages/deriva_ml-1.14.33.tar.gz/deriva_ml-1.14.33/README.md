# DerivaML
Deriva-ML is a python library to simplify the process of creating and executing reproducible machine learning workflows
using a deriva catalog.


## Installing the GitHub CLI

The script release.sh will create a new release tag in GitHub.  This script requires the 
GitHUB CLI be installed. 

See [https://cli.github.com](https://cli.github.com) for instructions on how to install and configure the CLI.

