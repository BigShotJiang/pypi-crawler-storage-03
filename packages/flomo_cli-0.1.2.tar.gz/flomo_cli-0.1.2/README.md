# Flomo-cli: save your memos in terminal

## Usage

```shell
pip install flomo-cli
# first use
flomo-cli --url <your-flomo-api>
# next
flomo-cli
```

## ScreenShot



![Next use](images/next-use.png)