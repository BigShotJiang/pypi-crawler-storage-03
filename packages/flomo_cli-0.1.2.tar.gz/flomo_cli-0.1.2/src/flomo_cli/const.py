CONFIG_FILENAME = ".flomo.cli.toml"
CONFIG_SECTION = "flomo_cli"
CONFIG_KEY_URL = "url"