from opentelemetry.exporter.prometheus import PrometheusMetricReader

reader = PrometheusMetricReader()
