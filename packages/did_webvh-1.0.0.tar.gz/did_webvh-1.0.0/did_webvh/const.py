"""Constant values."""

ASKAR_STORE_FILENAME = "keys.sqlite"
DOCUMENT_FILENAME = "did.json"
HISTORY_FILENAME = "did.jsonl"
METHOD_NAME = "webvh"
METHOD_VERSION = "1.0"
SCID_PLACEHOLDER = "{SCID}"
WITNESS_FILENAME = "did-witness.json"
