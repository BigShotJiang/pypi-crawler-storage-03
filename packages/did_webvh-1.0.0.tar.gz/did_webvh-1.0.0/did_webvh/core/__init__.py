"""DID log handling for did:webvh."""
