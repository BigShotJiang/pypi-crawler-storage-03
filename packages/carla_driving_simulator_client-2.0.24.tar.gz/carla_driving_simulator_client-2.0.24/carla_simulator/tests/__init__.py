"""
Tests for carla_simulator package.
"""
