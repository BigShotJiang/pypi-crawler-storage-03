# Trueflagger

Biblioteca Python para iniciantes que permite criar, ler, atualizar e remover *flags* simples usando arquivos.

## Instalação

```bash
pip install Trueflagger
