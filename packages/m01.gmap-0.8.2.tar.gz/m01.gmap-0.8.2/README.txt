This package provides a m01.mongo and z3c.form based google map widget for Zope3.
