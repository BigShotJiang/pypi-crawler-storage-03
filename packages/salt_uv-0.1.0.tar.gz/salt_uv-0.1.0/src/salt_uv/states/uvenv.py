import os

__salt__ = {}
__opts__ = {}


def managed(name, user=None, requirements=None, python=None, uv_bin="uv", **kwargs):
    ret = {"name": name, "result": False, "comment": "Venv", "changes": {}}
    venv_py = os.path.join(name, "bin", "python")
    if not os.path.exists(venv_py):
        if __opts__["test"]:
            ret["result"] = None
            ret["comment"] = f"Would install Venv to {name}"
            return ret
        venv_args = [uv_bin, "venv", "--allow-existing", name]
        if python:
            venv_args.append("-p")
            venv_args.append(python)
        result = __salt__["cmd.run"](venv_args, runas=user)

    if requirements:
        if __opts__["test"]:
            ret["result"] = None
            ret["comment"] = f"Would install {requirements}"
            return ret

        pip_args = [uv_bin, "pip", "install", "-r", requirements]
        result = __salt__["cmd.run"](pip_args, runas=user, cwd=name)
        changes = {}
        for line in result.split("\n"):
            if line.startswith(" +"):
                pkg, version = line.split("==")
                changes[pkg] = version
        ret["changes"] = changes
        ret["comment"] = result
        ret["result"] = True
        return ret

    ret["comment"] = "No changes required"
    ret["result"] = True
    return ret


def sync(name, user=None, uv_bin="uv"):
    ret = {"name": name, "result": False, "comment": "Venv", "changes": {}}
    if __opts__["test"]:
        command = [uv_bin, "sync", "--dry-run"]
        result = __salt__["cmd.run"](command, runas=user, cwd=name)
        ret["result"] = None
        ret["comment"] = f"Would install Venv to {name}"
        ret["comment"] = result
        return ret
    else:
        command = [uv_bin, "sync"]
        result = __salt__["cmd.run"](command, runas=user, cwd=name)
        ret["result"] = True
        ret["comment"] = f"Would install Venv to {name}"
        ret["comment"] = result
        return ret
