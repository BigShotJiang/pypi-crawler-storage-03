# Copyright 2025 Cardiff University
# SPDX-License-Identifier: MIT

"""Command-line tools for IGWN Robot Auth."""

__author__ = "Duncan Macleod <duncan.macleod@ligo.org>"
