# Copyright (c) 2025 Cardiff University
# SPDX-License-Identifier: MIT

"""Tests for `igwn_robot_auth`."""

__author__ = "Duncan Macleod <duncan.macleod@ligo.org>"
