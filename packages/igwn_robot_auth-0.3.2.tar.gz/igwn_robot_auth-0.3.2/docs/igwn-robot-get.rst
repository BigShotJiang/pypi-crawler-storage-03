##################
``igwn-robot-get``
##################

.. argparse::
    :ref: igwn_robot_auth.tools.get.create_parser
    :prog: igwn-robot-get
