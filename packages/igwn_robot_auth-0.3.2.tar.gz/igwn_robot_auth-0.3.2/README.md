# igwn-robot-auth

This project provides utilities for managing IGWN authorisation credentials
associated with Robot identities (shared accounts, automated processes, etc).

For full documentation, please see

<https://rtd.igwn.org/projects/igwn-robot-auth/>
