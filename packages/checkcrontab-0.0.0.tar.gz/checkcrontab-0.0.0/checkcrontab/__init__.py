#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__version__ = "0.0.0"
__author__ = 'Aleksandr Pimenov'
__email__ = 'wachawo@gmail.com'
__description__ = "A Python3 script for checking syntax and correctness of crontab files"

from .main import main

__all__ = ["main"]
