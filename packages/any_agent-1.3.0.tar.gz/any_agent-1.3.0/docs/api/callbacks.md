# Callbacks

::: any_agent.callbacks.base.Callback

::: any_agent.callbacks.context.Context

::: any_agent.callbacks.span_cost.AddCostInfo

::: any_agent.callbacks.span_print.ConsolePrintSpan

::: any_agent.callbacks.get_default_callbacks
