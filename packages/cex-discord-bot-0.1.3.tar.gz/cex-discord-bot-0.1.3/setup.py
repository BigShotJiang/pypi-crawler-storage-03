from setuptools import setup, find_packages

setup(
    name="cex-discord-bot",
    version="0.1.3",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "cex-bot=cex_discord_bot.cex_info:main",
        ],
    },
    author="Jose89fcb",
    description="Bot de línea de comandos para consultar cajas de CEX",
    python_requires=">=3.7",
)