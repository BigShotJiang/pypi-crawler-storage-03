from django.apps import AppConfig


class ExampleConfig(AppConfig):
    name = "example"
    verbose_name = "Example"
