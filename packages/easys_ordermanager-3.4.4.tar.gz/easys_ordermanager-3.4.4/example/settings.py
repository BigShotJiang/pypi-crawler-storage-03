SECRET_KEY = "&kxa67(_phgs@5&8=!x(ix(l%w1nmkh&n#1%^5pm&wm^ij)4(6"  # noqa: S105
DEBUG = True

INSTALLED_APPS = [
    "example.apps.ExampleConfig",
]

TIME_ZONE = "Europe/Berlin"
USE_I18N = True
USE_L10N = True
USE_TZ = True
