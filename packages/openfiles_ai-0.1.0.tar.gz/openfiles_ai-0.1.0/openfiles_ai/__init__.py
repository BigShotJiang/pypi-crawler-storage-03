"""
OpenFiles Python SDK

AI-native file storage platform with S3-style operations
"""

__version__ = "0.1.0"

# Re-export from submodules for convenience
from .core import OpenFilesClient
from .openai import OpenAI
from .tools import OpenFilesTools

__all__ = ["OpenFilesClient", "OpenFilesTools", "OpenAI"]
