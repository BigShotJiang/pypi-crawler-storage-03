import pandas as pd
import numpy as np
from tabulate import tabulate

def rg(
    df,
    periodo='anio',
    periodo_actual=None,
    periodo_base=None,
    variables=None
):
    """
    Calcula la tasa de crecimiento de variables entre dos periodos.

    Parámetros:
    - df: DataFrame con 'fecha_evento' y variables como total_fallecidos, peaton_fallecidos, etc.
    - periodo: 'anio', 'trimestre' o 'mes'
    - periodo_actual: str o int, ej. '2025Q1', 2025, '2025-03'
    - periodo_base: str o int
    - variables: lista de columnas a comparar, ej. ['total_fallecidos', 'peaton_fallecidos']

    Retorna:
    - DataFrame con variable, valor_base, valor_actual, tasa_crecimiento (%)
    """

    # Convertir fecha
    df['fecha'] = pd.to_datetime(df['fecha_evento'])

    # Crear columna de agrupación
    if periodo == 'anio':
        df['grupo'] = df['fecha'].dt.year.astype(str)
    elif periodo == 'trimestre':
        df['grupo'] = df['fecha'].dt.to_period('Q').astype(str)
    elif periodo == 'mes':
        df['grupo'] = df['fecha'].dt.to_period('M').astype(str)
    else:
        raise ValueError("El periodo debe ser 'anio', 'trimestre' o 'mes'.")

    # Verificar variables
    if variables is None:
        variables = [col for col in df.select_dtypes(include='number').columns if col not in ['fecha']]

    faltantes = [v for v in variables if v not in df.columns]
    if faltantes:
        raise ValueError(f"Las siguientes columnas no existen en el DataFrame: {faltantes}")

    # Agrupar
    resumen = df.groupby('grupo')[variables].sum()

    periodos_disponibles = resumen.index.tolist()

    # Mostrar sugerencia si faltan periodos
    if periodo_base is None or periodo_actual is None:
        print("ℹ️  Periodos disponibles para comparación:")
        for p in periodos_disponibles:
            print(f"  - {p}")
        raise ValueError("Debes especificar 'periodo_base' y 'periodo_actual' entre los disponibles.")

    if periodo_base not in resumen.index or periodo_actual not in resumen.index:
        raise ValueError(
            f"❌ Uno o ambos periodos no están en los datos.\n"
            f"Periodo base: {periodo_base} {'✅' if periodo_base in periodos_disponibles else '❌'}\n"
            f"Periodo actual: {periodo_actual} {'✅' if periodo_actual in periodos_disponibles else '❌'}\n"
            f"✔️  Disponibles: {periodos_disponibles}"
        )

    # Valores base y actual
    base = resumen.loc[periodo_base]
    actual = resumen.loc[periodo_actual]

    # Calcular tasa
    with np.errstate(divide='ignore', invalid='ignore'):
        tasa = np.where(
            base != 0,
            (actual - base) / base * 100,
            np.nan
        )

     # Convertir a string los nombres de periodo
    nombre_base = str(periodo_base)
    nombre_actual = str(periodo_actual)

    resultado = pd.DataFrame({
    'variable': variables,
    nombre_base: base.values,
    nombre_actual: actual.values,
    'tasa_crecimiento (%)': np.round(tasa, 2)
})
   


    return print(tabulate(resultado, headers='keys', tablefmt='github', showindex=False))
