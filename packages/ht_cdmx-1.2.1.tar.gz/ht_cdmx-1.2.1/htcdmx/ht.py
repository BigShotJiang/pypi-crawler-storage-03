from tabulate import tabulate

def hts(df, periodo="trimestre", mostrar_tabla=True):
    if 'anio' not in df.columns or (periodo == 'trimestre' and 'trimestre' not in df.columns):
        raise ValueError("El DataFrame debe contener las columnas 'anio' y 'trimestre' para el análisis por trimestre.")
    print('Hechos de transito')
    if periodo == "anio":
        
        conteo = df.groupby(['anio']).size().reset_index(name="hechos de transito")
        
    elif periodo == "trimestre":
        conteo = df.pivot_table(index='trimestre',
                                columns='anio',
                                values='ID',
                                aggfunc='count',
                                fill_value=0)
    elif periodo == "mes":
        conteo = df.pivot_table(index='mes',
                                columns='anio',
                                values='ID',
                                aggfunc='count',
                                fill_value=0)

    else:
        raise ValueError("Periodo no reconocido. Usa 'anio' o 'trimestre'.")

    if mostrar_tabla:
        print(tabulate(conteo, headers='keys', tablefmt='grid'))

    return conteo


def hechos_transito_fall(df, periodo="trimestre",mostrar_tabla=True):
    if 'anio' not in df.columns or (periodo == 'trimestre' and 'trimestre' not in df.columns):
        raise ValueError("El DataFrame debe contener las columnas 'anio' y 'trimestre' para el análisis por trimestre.")
    print('Hechos de transito con fallecidos')
    if periodo == "anio":
        
        conteo = df[df['total_fallecidos']>=1].groupby(['anio']).size().reset_index(name="hechos de transito")
        
    elif periodo == "trimestre":
        conteo = df[df['total_fallecidos']>=1].pivot_table(index='trimestre',
                                columns='anio',
                                values='ID',
                                aggfunc='count',
                                fill_value=0)
    elif periodo == "mes":
        conteo = df[df['total_fallecidos']>=1].pivot_table(index='mes',
                                columns='anio',
                                values='ID',
                                aggfunc='count',
                                fill_value=0)

    else:
        raise ValueError("Periodo no reconocido. Usa 'anio' o 'trimestre'.")

    if mostrar_tabla:
        print(tabulate(conteo, headers='keys', tablefmt='grid'))

    return conteo

def hechos_transito_les(df, periodo="trimestre", mostrar_tabla=True):

    if 'anio' not in df.columns or (periodo == 'trimestre' and 'trimestre' not in df.columns):
        raise ValueError("El DataFrame debe contener las columnas 'anio' y 'trimestre' para el análisis por trimestre.")
    print('Hechos de transito con lesionados')
    if periodo == "anio":
        
        conteo = df[(df['total_fallecidos'] == 0) & (df['total_lesionados'] >= 1)].groupby(['anio']).size().reset_index(name="hechos de transito")
        
    elif periodo == "trimestre":
        conteo = df[(df['total_fallecidos'] == 0) & (df['total_lesionados'] >= 1)].pivot_table(index='trimestre',
                                columns='anio',
                                values='ID',
                                aggfunc='count',
                                fill_value=0)
    elif periodo == "mes":
        conteo = df[(df['total_fallecidos'] == 0) & (df['total_lesionados'] >= 1)].pivot_table(index='mes',
                                columns='anio',
                                values='ID',
                                aggfunc='count',
                                fill_value=0)

    else:
        raise ValueError("Periodo no reconocido. Usa 'anio' o 'trimestre'.")

    if mostrar_tabla:
        print(tabulate(conteo, headers='keys', tablefmt='grid'))

    return conteo
