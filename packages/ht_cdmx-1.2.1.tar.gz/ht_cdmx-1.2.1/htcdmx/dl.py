import pandas as pd

def dld():
    """
    Carga un archivo CSV desde una URL fija y lo devuelve como un DataFrame.
    Además imprime el periodo de los datos según la columna 'fecha_evento'.

    Retorna:
        pd.DataFrame: DataFrame con los datos cargados.
    """
    url = "https://seguridadvial.semovi.cdmx.gob.mx/wp-content/themes/semovi-seguridad-vial/data/dataset.csv"
    try:
        df = pd.read_csv(url)
        print("✅ Archivo cargado correctamente.")

        # Si existe la columna fecha_evento
        if "fecha_evento" in df.columns:
            df["fecha_evento"] = pd.to_datetime(df["fecha_evento"], errors="coerce")

            min_fecha = df["fecha_evento"].min()
            max_fecha = df["fecha_evento"].max()

            if pd.notna(min_fecha) and pd.notna(max_fecha):
                print(f"📅 El periodo de los datos abarca del {min_fecha.date()} al {max_fecha.date()}")
            else:
                print("⚠️ No se pudieron determinar las fechas (valores nulos o inválidos).")
        else:
            print("⚠️ La columna 'fecha_evento' no existe en el dataset.")

        return df

    except Exception as e:
        print(f"❌ Error al cargar el archivo: {e}")
        return None


