import pandas as pd
from tabulate import tabulate

def gf(df, sexo='fallecidos_femeninos', periodo='año'):
    """
    Suma los fallecidos por tipo de sexo y por periodo de tiempo.

    Parámetros:
    - df: DataFrame con columnas de sexo por tipo y una columna llamada 'fecha'.
    - usuario: columna a sumar (por ejemplo: 'fallecidos_femeninos', 'fallecidos_masculinos', 'fallecidos_se_desconoce'.).
    - frecuencia: 'año', 'trimestre' o 'mes'.

    Retorna:
    - DataFrame con la suma de fallecidos por tipo de sexo y el periodo especificado.
    """
    columna_fecha = 'fecha_evento'  # Columna fija dentro de la función

    if columna_fecha not in df.columns:
        raise ValueError(f"La columna de fecha '{columna_fecha}' no existe en el DataFrame.")
    if sexo not in df.columns:
        raise ValueError(f"La columna de usuario '{sexo}' no existe en el DataFrame.")
    
    # Asegurar que la columna de fecha sea de tipo datetime
    df[columna_fecha] = pd.to_datetime(df[columna_fecha], errors='coerce')

    # Crear columna de agrupación según frecuencia
    if periodo == 'año':
        resultado = df.groupby('anio')[sexo].sum().reset_index()
        #df['grupo'] = df[columna_fecha].dt.year
    elif periodo == 'trimestre':
        print(f'{sexo}')
        resultado =df.pivot_table(index='trimestre',
                                  columns='anio',
                                  values=sexo,
                                  aggfunc='sum',
                                  fill_value=0).reset_index()
        #df['grupo'] = df[columna_fecha].dt.to_period('Q').astype(str)
    elif periodo == 'mes':
        print(f'{sexo}')
        resultado =df.pivot_table(index='mes',
                                  columns='anio',
                                  values=sexo,
                                  aggfunc='sum',
                                  fill_value=0).reset_index()
        #df['grupo'] = df[columna_fecha].dt.to_period('M').astype(str)
    else:
        raise ValueError("La frecuencia debe ser 'año', 'trimestre' o 'mes'.")

    #resultado = df.groupby('grupo')[usuario].sum().reset_index()
   
    #resultado.columns = [frecuencia, f'{usuario}']
    print(tabulate(resultado, headers='keys', tablefmt='grid'))
    return resultado
