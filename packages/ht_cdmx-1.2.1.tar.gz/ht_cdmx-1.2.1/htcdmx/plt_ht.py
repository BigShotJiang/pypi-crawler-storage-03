import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import seaborn as sns

def plt_ht(
    df, 
    periodo='anio', 
    tipo='lineas', 
    etiquetas=True,
    anios=None, 
    trimestres=None, 
    meses=None
):
    """
    Grafica hechos de tránsito con posibilidad de filtrar por año, trimestre o mes.

    Parámetros:
    - df: DataFrame con 'fecha_evento', 'total_fallecidos', 'total_lesionados'
    - periodo: 'anio', 'trimestre' o 'mes'
    - tipo: 'lineas' o 'barras'
    - etiquetas: bool para mostrar etiquetas en gráfico
    - anios: lista opcional de años [2022, 2023]
    - trimestres: lista opcional de trimestres [1, 2, 3, 4]
    - meses: lista opcional de meses [1, 2, ..., 12]
    """

    # Validaciones
    if periodo not in ['anio', 'trimestre', 'mes']:
        raise ValueError("Periodo debe ser 'anio', 'trimestre' o 'mes'")
    if tipo not in ['lineas', 'barras']:
        raise ValueError("Tipo debe ser 'lineas' o 'barras'")

    # Preparar fechas
    df['fecha'] = pd.to_datetime(df['fecha_evento'])
    df['anio'] = df['fecha'].dt.year
    df['mes'] = df['fecha'].dt.month
    df['trimestre_num'] = df['fecha'].dt.quarter

    # Aplicar filtros
    if anios:
        df = df[df['anio'].isin(anios)]
    if trimestres:
        df = df[df['trimestre_num'].isin(trimestres)]
    if meses:
        df = df[df['mes'].isin(meses)]

    # Crear columna de agrupación
    if periodo == 'anio':
        df['grupo'] = df['anio'].astype(str)
    elif periodo == 'trimestre':
        df['grupo'] = df['fecha'].dt.to_period('Q').astype(str)  # '2022Q1'
    elif periodo == 'mes':
        df['grupo'] = df['fecha'].dt.to_period('M').astype(str)  # '2022-04'

    # Categorías
    total_df = df.copy()
    con_fallecidos_df = df[df['total_fallecidos'] >= 1]
    con_lesionados_df = df[(df['total_fallecidos'] == 0) & (df['total_lesionados'] >= 1)]

    categorias = {
        "Totales": total_df,
        "Con fallecidos": con_fallecidos_df,
        "Con lesionados": con_lesionados_df
    }

    # Estilo y formato
    format_miles = mtick.FuncFormatter(lambda x, _: f'{int(x):,}' if x >= 1 else f'{x:.0f}')
    sns.set(style="whitegrid")

    for nombre, datos in categorias.items():
        resumen = datos.groupby('grupo').size().reset_index(name='cantidad')
        resumen = resumen.sort_values('grupo')

        plt.figure(figsize=(12, 5))
        ax = plt.gca()
        ax.yaxis.set_major_formatter(format_miles)

        if tipo == 'lineas':
            sns.lineplot(data=resumen, x='grupo', y='cantidad', marker='o')
            if etiquetas:
                for x, y in zip(resumen['grupo'], resumen['cantidad']):
                    plt.text(x, y + y * 0.02, f'{int(y):,}', ha='center', va='bottom', fontsize=9)
        else:
            ax = sns.barplot(data=resumen, x='grupo', y='cantidad', color='steelblue')
            if etiquetas:
                for bar in ax.patches:
                    height = bar.get_height()
                    ax.text(
                        bar.get_x() + bar.get_width() / 2,
                        height + height * 0.01,
                        f'{int(height):,}',
                        ha='center',
                        va='bottom',
                        fontsize=9
                    )

        plt.title(f"Hechos de tránsito - {nombre} por {periodo}")
        plt.xlabel(periodo.capitalize())
        plt.ylabel("Número de hechos")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()
