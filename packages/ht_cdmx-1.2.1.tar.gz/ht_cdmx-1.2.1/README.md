# Librería de Datos de Hechos de Tránsito CDMX

Esta librería de Python permite cargar, procesar y visualizar datos de hechos de tránsito en la Ciudad de México (CDMX), utilizados en el micrositio de hechos de tránsito de SEMOVI.

---

## Instalación

Puedes instalar la librería usando `pip` desde PyPI o TestPyPI:

```bash
pip install ht-CDMX==1.2.1
```

Si estás usando TestPyPI:

```bash
pip install -i https://test.pypi.org/simple/ ht-CDMX
```

---

## Uso

A continuación se describen los módulos disponibles y su funcionalidad:

### `dl.py`
Carga los datos de hechos de tránsito de la CDMX, los cuales se usan en el micrositio de hechos de tránsito de SEMOVI.

### `ht.py`
Muestra los hechos de tránsito ocurridos en la CDMX:  
- Hechos de tránsito totales.  
- Hechos de tránsito con fallecidos.  
- Hechos de tránsito con lesionados.  
- El periodo puede ser **mensual, trimestral o anual**.

### `tf.py`
Muestra las personas **fallecidas** por hechos de tránsito:  
- Totales o por tipo de usuario de la vía.  
- El periodo puede ser **mensual, trimestral o anual**.

### `tl.py`
Muestra las personas **lesionadas** por hechos de tránsito:  
- Totales o por tipo de usuario de la vía.  
- El periodo puede ser **mensual, trimestral o anual**.

### `gf.py`
Muestra las personas **fallecidas** por hechos de tránsito **totales por sexo**:  
- El periodo puede ser **mensual, trimestral o anual**.

### `gl.py`
Muestra las personas **lesionadas** por hechos de tránsito **totales por sexo**:  
- El periodo puede ser **mensual, trimestral o anual**.

### `plt_ht.py`
Permite **graficar** los datos de los módulos anteriores.

---

### `rg.py`
Permite **calcular las tasas de crecimiento** de los datos de los módulos anteriores.

---

## Ejemplo de uso

```python
import htcdmx 

# Cargar datos
df = htcdmx.dld()

# Mostrar hechos de tránsito totales trimestrales
htcdmx.hts(df, periodo="trimestre", mostrar_tabla=True)

# Mostrar fallecidos por tipo de usuario
htcdmx.tf(df, usuario='total_fallecidos', periodo='año')

# Mostrar lesionados por tipo de usuario
htcdmx.tl(df, usuario='total_lesionados', periodo='año')

# Mostrar fallecidos por sexo
htcdmx.gf(df, sexo='fallecidos_femeninos', periodo='año')

# Mostrar lesionados por sexo
htcdmx.gl(df, sexo='fallecidos_femeninos', periodo='año'):

# Graficar los resultados
htcdmx.plt_ht(df, periodo='anio', tipo='lineas', etiquetas=True,anios=None, trimestres=None, meses=None)
```

---

## Notas
- Asegúrate de tener instaladas todas las dependencias (`pandas`, `matplotlib`, etc.).  
- Los periodos disponibles son: `mensual`, `trimestral` y `anual`.  
- Los datos se obtienen directamente de la fuente oficial de SEMOVI CDMX https://seguridadvial.semovi.cdmx.gob.mx/hechos-de-transito/