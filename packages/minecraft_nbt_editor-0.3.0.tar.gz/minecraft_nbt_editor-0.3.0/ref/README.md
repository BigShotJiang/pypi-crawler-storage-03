# NBT Viewer
VSCode extension to view Minecraft NBT files. For structure files, this shows a 3D block view.

![](https://user-images.githubusercontent.com/17352009/104337363-b4aeb000-54f5-11eb-93a2-47ce2e3e4fea.png)

## Credits

* [AmberW](https://github.com/AmberWat) for the NBT icons
* [SPGoding](https://github.com/SPGoding) for the downloading and caching logic from [Spyglass](https://github.com/SpyglassMC/Spyglass)

## Disclaimer
While this extension has been tested, it can technically corrupt your files. Always be careful and backup important files.
