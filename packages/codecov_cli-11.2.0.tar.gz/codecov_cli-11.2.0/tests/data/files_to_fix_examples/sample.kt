{
    first line on kotlin file
}

secnod line

{
    previous line should be fixed
}


{ // afsdpfjasd fjasdpfj apsdjf
    should fix previous
}

data class Key(
    val key: String? = null
)

    /*


    some stuff here

*/




// fasdpofjaspdf


// fapsjdf
