UV_LOCK = "uv.lock"
