/**
 * @author Szincsak Andras
 */
$.paramquery.pqGrid.regional ['hu'] = { 
    strLoading: "Terhelés", 
    strAdd: "�j", 
    strEdit: "Szerkeszt", 
    strDelete: "T�r�l", 
    strSearch: "Keres�s", 
    strNothingFound: "Nincs tal�lat", 
    strSelectedmatches: "{1} tal�latb�l {0} kiv�lasztva", 
    strPrevResult: "korábbi eredmény", 
    strNextResult: "következő eredmény",
    strNoRows: "Nincs megjelenítendő sorok"     
}; 
$.paramquery.pqPager.regional ['hu'] = { 
    strPage: "Oldal: {0} / {1}", 
    strFirstPage: "Első oldal", 
    strPrevPage: "Előző oldal", 
    strNextPage: "Következő oldal", 
    strLastPage: "Utolsó oldal", 
    strRefresh: "Felfrissít", 
    strRpp: "Találat oldalanként: {0}", 
    strDisplay: "Megjelenítése {0} az {1} {2} elemek." 
};