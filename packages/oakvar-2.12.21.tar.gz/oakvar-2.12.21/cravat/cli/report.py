from oakvar.cli.report import *
from oakvar.lib.base.reporter import BaseReporter

CravatReport = BaseReporter
