from oakvar.cli.module.install_defs import *
