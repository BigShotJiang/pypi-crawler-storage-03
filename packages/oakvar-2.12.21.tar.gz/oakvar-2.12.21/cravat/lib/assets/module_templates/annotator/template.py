from oakvar.lib.assets.module_templates.annotator.template import *
