# finecode_extension_api

Package with FineCode API for extensions.
