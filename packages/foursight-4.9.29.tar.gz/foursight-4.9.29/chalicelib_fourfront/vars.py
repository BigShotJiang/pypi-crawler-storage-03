from os.path import dirname, join
from foursight_core.app_utils import AppUtilsCore

FOURSIGHT_PREFIX = 'foursight'
DEV_ENV = 'mastertest'
HOST = 'https://search-foursight-fourfront-ylxn33a5qytswm63z52uytgkm4.us-east-1.es.amazonaws.com'
CHECK_SETUP_FILE = join(dirname(__file__), AppUtilsCore.CHECK_SETUP_FILE_NAME)
