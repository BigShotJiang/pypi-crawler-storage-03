Just
====


.. currentmodule:: cg_maybe._just

.. autoclass:: Just
   :members: