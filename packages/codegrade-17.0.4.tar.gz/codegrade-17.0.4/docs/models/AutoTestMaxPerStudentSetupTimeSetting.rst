AutoTestMaxPerStudentSetupTimeSetting
=====================================

.. currentmodule:: codegrade.models.auto_test_max_per_student_setup_time_setting

.. autoclass:: AutoTestMaxPerStudentSetupTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
