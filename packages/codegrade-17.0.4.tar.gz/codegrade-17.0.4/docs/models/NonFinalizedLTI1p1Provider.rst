NonFinalizedLTI1p1Provider
==========================

.. currentmodule:: codegrade.models.non_finalized_lti1p1_provider

.. autoclass:: NonFinalizedLTI1p1Provider
   :members: finalized, netloc, edit_secret, lms_consumer_key, lms_consumer_secret
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
