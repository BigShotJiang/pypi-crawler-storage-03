Patch1P3ProviderLTIData
=======================

.. currentmodule:: codegrade.models.patch1_p3_provider_lti_data

.. autoclass:: Patch1P3ProviderLTIData
   :members: iss, client_id, auth_token_url, auth_login_url, key_set_url, auth_audience, finalize
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
