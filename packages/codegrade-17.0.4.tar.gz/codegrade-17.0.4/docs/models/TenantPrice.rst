TenantPrice
===========

.. currentmodule:: codegrade.models.tenant_price

.. autoclass:: TenantPrice
   :members: tenant
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
