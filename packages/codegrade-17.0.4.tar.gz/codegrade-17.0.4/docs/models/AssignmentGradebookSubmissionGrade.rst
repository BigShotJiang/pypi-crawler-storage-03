AssignmentGradebookSubmissionGrade
==================================

.. currentmodule:: codegrade.models.assignment_gradebook_submission_grade

.. autoclass:: AssignmentGradebookSubmissionGrade
   :members: submission_id, grade
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
