TenantCouponWithoutCode
=======================

.. currentmodule:: codegrade.models.tenant_coupon_without_code

.. autoclass:: TenantCouponWithoutCode
   :members: type
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
