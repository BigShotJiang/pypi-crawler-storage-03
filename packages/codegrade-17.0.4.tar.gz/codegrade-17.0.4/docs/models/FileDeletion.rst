FileDeletion
============

.. currentmodule:: codegrade.models.file_deletion

.. autoclass:: FileDeletion
   :members: fullname, reason, deletion_type, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
