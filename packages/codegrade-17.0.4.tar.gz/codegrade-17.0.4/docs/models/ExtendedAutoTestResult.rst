ExtendedAutoTestResult
======================

.. currentmodule:: codegrade.models.extended_auto_test_result

.. autoclass:: ExtendedAutoTestResult
   :members: global_setup_stdout, global_setup_stderr, global_setup_output, setup_stdout, setup_stderr, step_results, approx_waiting_before, final_result, suite_files, quality_comments, possible_runners
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
