Group
=====

.. currentmodule:: codegrade.models.group

.. autoclass:: Group
   :members: id, members, name, group_set_id, created_at
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
