MaxDynamoFileSizeSetting
========================

.. currentmodule:: codegrade.models.max_dynamo_file_size_setting

.. autoclass:: MaxDynamoFileSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
