PlagiarismState
===============

.. currentmodule:: codegrade.models.plagiarism_state

.. class:: PlagiarismState

**Options**

* ``starting``
* ``done``
* ``crashed``
* ``started``
* ``parsing``
* ``running``
* ``finalizing``
* ``comparing``
