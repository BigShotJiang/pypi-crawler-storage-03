PatchRubricCategoryTypeAssignmentData
=====================================

.. currentmodule:: codegrade.models.patch_rubric_category_type_assignment_data

.. autoclass:: PatchRubricCategoryTypeAssignmentData
   :members: new_type, row
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
