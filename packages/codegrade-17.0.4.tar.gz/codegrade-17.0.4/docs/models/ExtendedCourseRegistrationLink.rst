ExtendedCourseRegistrationLink
==============================

.. currentmodule:: codegrade.models.extended_course_registration_link

.. autoclass:: ExtendedCourseRegistrationLink
   :members: course
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
