BaseFile
========

.. currentmodule:: codegrade.models.base_file

.. autoclass:: BaseFile
   :members: type, id, name, size, hash
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
