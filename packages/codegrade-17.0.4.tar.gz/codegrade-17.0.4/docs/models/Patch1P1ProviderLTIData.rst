Patch1P1ProviderLTIData
=======================

.. currentmodule:: codegrade.models.patch1_p1_provider_lti_data

.. autoclass:: Patch1P1ProviderLTIData
   :members: finalize
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
