NonDeletedCommentReply
======================

.. currentmodule:: codegrade.models.non_deleted_comment_reply

.. autoclass:: NonDeletedCommentReply
   :members: comment, author_id, deleted
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
