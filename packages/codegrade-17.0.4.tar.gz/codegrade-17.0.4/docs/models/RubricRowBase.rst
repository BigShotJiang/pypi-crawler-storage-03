RubricRowBase
=============

.. currentmodule:: codegrade.models.rubric_row_base

.. autoclass:: RubricRowBase
   :members: id, header, description, description_type, items, locked, type
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
