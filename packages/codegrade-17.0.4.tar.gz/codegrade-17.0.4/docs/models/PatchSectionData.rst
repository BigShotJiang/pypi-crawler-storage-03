PatchSectionData
================

.. currentmodule:: codegrade.models.patch_section_data

.. autoclass:: PatchSectionData
   :members: name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
