FirstDayOfWeekFromLocaleSetting
===============================

.. currentmodule:: codegrade.models.first_day_of_week_from_locale_setting

.. autoclass:: FirstDayOfWeekFromLocaleSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
