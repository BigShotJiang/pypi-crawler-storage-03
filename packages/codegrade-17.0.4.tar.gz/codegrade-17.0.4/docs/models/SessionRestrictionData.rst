SessionRestrictionData
======================

.. currentmodule:: codegrade.models.session_restriction_data

.. autoclass:: SessionRestrictionData
   :members: for_context, removed_permissions
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
