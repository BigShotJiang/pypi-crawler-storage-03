CreateSectionCourseData
=======================

.. currentmodule:: codegrade.models.create_section_course_data

.. autoclass:: CreateSectionCourseData
   :members: name, user_ids
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
