PayWithCouponCoursePriceData
============================

.. currentmodule:: codegrade.models.pay_with_coupon_course_price_data

.. autoclass:: PayWithCouponCoursePriceData
   :members: code
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
