StartPaymentCoursePriceCloseTabData
===================================

.. currentmodule:: codegrade.models.start_payment_course_price_close_tab_data

.. autoclass:: StartPaymentCoursePriceCloseTabData
   :members: mode
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
