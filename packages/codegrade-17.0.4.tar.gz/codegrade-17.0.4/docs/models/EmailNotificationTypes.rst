EmailNotificationTypes
======================

.. currentmodule:: codegrade.models.email_notification_types

.. class:: EmailNotificationTypes

**Options**

* ``direct``
* ``daily``
* ``weekly``
* ``off``
