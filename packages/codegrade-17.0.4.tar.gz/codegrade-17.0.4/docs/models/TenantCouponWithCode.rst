TenantCouponWithCode
====================

.. currentmodule:: codegrade.models.tenant_coupon_with_code

.. autoclass:: TenantCouponWithCode
   :members: type, code
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
