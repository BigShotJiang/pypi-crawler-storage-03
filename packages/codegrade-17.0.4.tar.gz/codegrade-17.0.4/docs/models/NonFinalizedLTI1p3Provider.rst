NonFinalizedLTI1p3Provider
==========================

.. currentmodule:: codegrade.models.non_finalized_lti1p3_provider

.. autoclass:: NonFinalizedLTI1p3Provider
   :members: finalized, netloc, auth_login_url, auth_token_url, client_id, key_set_url, auth_audience, custom_fields, public_jwk, public_key, edit_secret
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
