NewAutoTestBuildMaxCommandTimeSetting
=====================================

.. currentmodule:: codegrade.models.new_auto_test_build_max_command_time_setting

.. autoclass:: NewAutoTestBuildMaxCommandTimeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
