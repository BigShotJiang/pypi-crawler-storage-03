LTIDeepLinkResponse
===================

.. currentmodule:: codegrade.models.lti_deep_link_response

.. autoclass:: LTIDeepLinkResponse
   :members: url, jwt
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
