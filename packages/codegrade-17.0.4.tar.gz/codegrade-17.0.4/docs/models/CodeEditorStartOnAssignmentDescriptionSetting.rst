CodeEditorStartOnAssignmentDescriptionSetting
=============================================

.. currentmodule:: codegrade.models.code_editor_start_on_assignment_description_setting

.. autoclass:: CodeEditorStartOnAssignmentDescriptionSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
