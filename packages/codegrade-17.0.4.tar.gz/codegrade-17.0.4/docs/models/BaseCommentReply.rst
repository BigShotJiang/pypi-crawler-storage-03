BaseCommentReply
================

.. currentmodule:: codegrade.models.base_comment_reply

.. autoclass:: BaseCommentReply
   :members: id, in_reply_to_id, last_edit, created_at, reply_type, comment_type, approved, comment_base_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
