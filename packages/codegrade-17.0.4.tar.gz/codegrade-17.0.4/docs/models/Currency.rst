Currency
========

.. currentmodule:: codegrade.models.currency

.. class:: Currency

**Options**

* ``eur``
* ``usd``
* ``gbp``
* ``cad``
