Saml2Provider
=============

.. currentmodule:: codegrade.models.saml2_provider

.. autoclass:: Saml2Provider
   :members: id, metadata_url, ui_info
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
