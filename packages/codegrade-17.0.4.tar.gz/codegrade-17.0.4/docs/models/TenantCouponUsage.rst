TenantCouponUsage
=================

.. currentmodule:: codegrade.models.tenant_coupon_usage

.. autoclass:: TenantCouponUsage
   :members: scope, id, created_at, coupon, user_id, course
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
