FileRule
========

.. currentmodule:: codegrade.models.file_rule

.. autoclass:: FileRule
   :members: file_type, name, rule_type
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
