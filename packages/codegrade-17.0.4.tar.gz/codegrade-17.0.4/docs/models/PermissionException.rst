PermissionException
===================

.. currentmodule:: codegrade.models.permission_exception

.. autoclass:: PermissionException
   :members: missing_permissions, user_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
