PaymentPendingStatus
====================

.. currentmodule:: codegrade.models.payment_pending_status

.. autoclass:: PaymentPendingStatus
   :members: tag, price
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
