TenantStatistics
================

.. currentmodule:: codegrade.models.tenant_statistics

.. autoclass:: TenantStatistics
   :members: student_amounts, submission_amounts, amount_submissions_last_week, course_amounts
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
