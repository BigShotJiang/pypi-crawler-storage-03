BaseLTIProvider
===============

.. currentmodule:: codegrade.models.base_lti_provider

.. autoclass:: BaseLTIProvider
   :members: id, created_at, intended_use, tenant_id, label
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
