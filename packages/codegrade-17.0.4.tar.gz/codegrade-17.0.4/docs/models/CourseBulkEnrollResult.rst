CourseBulkEnrollResult
======================

.. currentmodule:: codegrade.models.course_bulk_enroll_result

.. autoclass:: CourseBulkEnrollResult
   :members: enrolled_users, sso_incompatible_users
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
