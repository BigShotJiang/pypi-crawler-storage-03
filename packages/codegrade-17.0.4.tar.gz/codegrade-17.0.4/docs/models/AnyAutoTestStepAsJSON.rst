AnyAutoTestStepAsJSON
=====================

.. currentmodule:: codegrade.models.any_auto_test_step_as_json

.. autoclass:: AnyAutoTestStepAsJSON
   :members: id, description
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
