LTILaunchResult
===============

.. currentmodule:: codegrade.models.lti_launch_result

.. autoclass:: LTILaunchResult
   :members: data, version
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
