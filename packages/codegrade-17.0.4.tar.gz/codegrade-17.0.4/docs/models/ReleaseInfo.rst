ReleaseInfo
===========

.. currentmodule:: codegrade.models.release_info

.. autoclass:: ReleaseInfo
   :members: date, version, message, ui_preference
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
