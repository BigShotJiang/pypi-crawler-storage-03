RubricEnabledForTeacherOnSubmissionsPageSetting
===============================================

.. currentmodule:: codegrade.models.rubric_enabled_for_teacher_on_submissions_page_setting

.. autoclass:: RubricEnabledForTeacherOnSubmissionsPageSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
