CourseSection
=============

.. currentmodule:: codegrade.models.course_section

.. autoclass:: CourseSection
   :members: id, name, course_id, member_count, member_ids
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
