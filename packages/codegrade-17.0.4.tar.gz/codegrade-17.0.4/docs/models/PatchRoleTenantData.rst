PatchRoleTenantData
===================

.. currentmodule:: codegrade.models.patch_role_tenant_data

.. autoclass:: PatchRoleTenantData
   :members: permission, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
