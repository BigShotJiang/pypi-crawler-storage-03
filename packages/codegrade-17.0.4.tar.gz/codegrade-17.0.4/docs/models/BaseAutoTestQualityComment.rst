BaseAutoTestQualityComment
==========================

.. currentmodule:: codegrade.models.base_auto_test_quality_comment

.. autoclass:: BaseAutoTestQualityComment
   :members: severity, code, origin, msg, line, column
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
