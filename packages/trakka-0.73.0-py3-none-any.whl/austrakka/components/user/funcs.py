from typing import List, Dict, Any

from loguru import logger

from austrakka.utils.api import api_patch, api_get
from austrakka.utils.api import api_post
from austrakka.utils.api import api_put
from austrakka.utils.helpers.output import call_get_and_print
from austrakka.utils.misc import logger_wraps
from austrakka.utils.paths import USER_PATH


@logger_wraps()
def list_users(show_disabled: bool, out_format: str):
    call_get_and_print(f'{USER_PATH}/?includeall={show_disabled}', out_format)


# pylint: disable=duplicate-code
@logger_wraps()
def add_user(
        user_id: str,
        org: str,
        owner_group_roles: List[str],
        is_process: bool,
        server_username: str,
        no_download_quota: bool,
        download_quota: int,
):
    if no_download_quota and download_quota is not None:
        logger.info(f"User configured with no download quota: "
                    f"Quota of {download_quota} will be ignored")
        
    user = {
        "objectId": user_id,
        "organisation": {
            "abbreviation": org
        },
        "ownerGroupRoles": list(owner_group_roles),
        "isAusTrakkaProcess": is_process,
        "analysisServerUsername": server_username,
        "monthlyBytesQuota": download_quota,
        "noDownloadQuota": no_download_quota,
    }
    
    api_post(
        path=USER_PATH,
        data=user
    )


def update_user(
        object_id: str,
        name: str = None,
        email: str = None,
        org: str = None,
        server_username: str = None,
        is_active: bool = None,
        no_download_quota: bool = None,
        download_quota: int = None,
):
    user_resp = api_get(f'{USER_PATH}/userId/{object_id}')
    user_full = user_resp['data']
    user: Dict[str, Any] = {
        "displayName": user_full['displayName'],
        "contactEmail": user_full['contactEmail'],
        "orgAbbrev": user_full['orgAbbrev'],
        "isActive": user_full['isActive'],
        "analysisServerUsername": user_full['analysisServerUsername'],
        "noDownloadQuota": user_full['noDownloadQuota'],
        "monthlyBytesQuota": user_full['monthlyBytesQuota'],
    }

    if no_download_quota and download_quota is not None:
        logger.info(f"User configured with no download quota: "
                    f"Quota of {download_quota} will be ignored")

    if name is not None:
        user['displayName'] = name
    if email is not None:
        user['contactEmail'] = email
    if org is not None:
        user['orgAbbrev'] = org
    if is_active is not None:
        user['isActive'] = is_active
    if server_username is not None:
        user['analysisServerUsername'] = server_username
    if no_download_quota is not None:
        user['noDownloadQuota'] = no_download_quota
    if download_quota is not None:
        user['monthlyBytesQuota'] = download_quota

    api_put(
        path=f'{USER_PATH}/{object_id}',
        data=user
    )


@logger_wraps()
def enable_user(user_id: str):
    api_patch(path=f'{USER_PATH}/enable/{user_id}')


@logger_wraps()
def disable_user(user_id: str):
    api_patch(path=f'{USER_PATH}/disable/{user_id}')
