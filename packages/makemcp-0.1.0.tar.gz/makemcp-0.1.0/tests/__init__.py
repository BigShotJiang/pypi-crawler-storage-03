"""
QuickMCP Test Suite
"""