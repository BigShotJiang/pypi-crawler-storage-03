from quad_torch.quad import QUAD

__all__ = ["QUAD"]