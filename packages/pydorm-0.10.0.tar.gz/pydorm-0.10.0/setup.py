import setuptools

setuptools.setup(
    name="pydorm",
    version="0.10.0",
    description="A dynamic and lightweight Python orm framework",
    author="melon",
    packages=setuptools.find_packages(),
)
