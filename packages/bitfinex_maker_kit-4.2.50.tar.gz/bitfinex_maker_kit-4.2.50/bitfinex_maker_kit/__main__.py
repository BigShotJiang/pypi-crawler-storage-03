"""
Entry point for the maker_kit package when run as a module.
"""

from .cli import main

if __name__ == "__main__":
    main()
