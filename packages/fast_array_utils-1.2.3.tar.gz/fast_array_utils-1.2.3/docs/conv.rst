``fast_array_utils.conv``
=========================

.. automodule:: fast_array_utils.conv
   :members:

``fast_array_utils.conv.scipy``
-------------------------------

.. automodule:: fast_array_utils.conv.scipy
   :members:
