# TODOAUTH:
# put in mock_plugin a custom auth_handler
# test if it works