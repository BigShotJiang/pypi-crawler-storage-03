

def test_execute_form_agent(main_agent, stray):
    assert True  # TODO: this is going to be a mess
