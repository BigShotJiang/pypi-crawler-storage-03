
def test_execute_procedures_agent(main_agent, stray):
    assert True  # TODO: this is going to be a mess

# TODO: test tool prompt
