To use this module, you need to:

- Go to a purchase order.
- Click on "Pay Purchase Advance".
- Select the Journal and specify the amount of the advanced payment.
- "Make Advance Payment".

When generating the invoice, the system displays the advanced payments,
select those you want to add to the invoice.
