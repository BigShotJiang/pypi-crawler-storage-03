============
transpolibre
============
``transpolibre`` is a Python program to automate translation of ``gettext``
PO files using LibreTranslate, Ollama, or local models.

.. toctree::
   about
   install
   usage
   libretranslate
   source
   languages
   todo
   see
   license
   :maxdepth: 2
   :caption: Contents:
