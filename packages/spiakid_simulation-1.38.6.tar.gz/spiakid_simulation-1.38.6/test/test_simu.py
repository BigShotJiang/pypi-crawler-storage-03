import unittest

class TestSum(unittest.TestCase):
    def test_simple(self):
        self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()
