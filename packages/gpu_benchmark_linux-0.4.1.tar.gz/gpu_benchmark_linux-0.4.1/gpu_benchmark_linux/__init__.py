"""
GPU基准测试工具 - 用于评估NVIDIA GPU性能的综合工具包
"""

__version__ = "0.4.1"