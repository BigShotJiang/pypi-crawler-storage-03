def hello_world():
    """A simple hello world function."""
    return "Hello, World!"


if __name__ == "__main__":
    # Test the function
    message = hello_world()
    print(message)