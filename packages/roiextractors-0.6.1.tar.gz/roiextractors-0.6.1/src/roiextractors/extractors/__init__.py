"""All specialized ImagingExtractors and SegmentationExtractors are defined here."""
