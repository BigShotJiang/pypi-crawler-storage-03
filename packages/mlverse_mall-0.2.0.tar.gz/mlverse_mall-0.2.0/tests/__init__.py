"Unit tests for mall"
