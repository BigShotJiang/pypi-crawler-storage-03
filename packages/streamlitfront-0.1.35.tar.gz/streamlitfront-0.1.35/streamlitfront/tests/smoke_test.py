"""
Really quick tests, just to make sure the basics work.

Importing examples to make sure that the elements they use still exist
(i.e. doesn't raise SyntaxError, ImportError or ModuleNotFound, etc.)
>>> from streamlitfront.examples import (
...     mk_app,
...     custom_output,
...     dag_app,
...     simple_real_audio_ml,
...     crude,
...     data_binding
... )
"""
