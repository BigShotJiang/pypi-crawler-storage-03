# # visual regression testing
# from seleniumbase import BaseCase
# from streamlit import cli as stcli
# import sys
# import streamlit as st
# import time


# class ComponentsTest(BaseCase):
#     def test_basic(self):
#         self.post_message("Check ")
#         self.open("http://localhost:8501")
#         self.check_window(name="first_test)", level=3)
#         time.sleep(3)
