from front.examples.simple_ml_1 import *
