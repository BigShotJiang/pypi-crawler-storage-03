"""Core formatting functionality."""

from .formatter import MakefileFormatter

__all__ = ["MakefileFormatter"]
