# Task: {Task Name}

## Component
→ `/architecture/releases/{release}/components/{component}.md#{section}`

## What to Do
{Атомарная задача - одна конкретная вещь}

## Implementation
**Location:** {конкретный путь к файлу/модулю}
**Type:** new

### Changes
- {Конкретное изменение с деталями}
- {Конкретное изменение с деталями}

## Input/Output
**Input:** {конкретный формат входных данных}
**Output:** {конкретный формат результата}

## Notes
{Технические детали реализации}
{Ссылки на паттерны если применимо}