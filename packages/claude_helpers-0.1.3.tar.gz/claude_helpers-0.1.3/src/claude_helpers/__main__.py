"""Entry point for python -m claude_helpers."""

from .cli import cli

if __name__ == "__main__":
    cli()