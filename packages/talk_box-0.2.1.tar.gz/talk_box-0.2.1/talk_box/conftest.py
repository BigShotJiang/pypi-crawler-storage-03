# This conftest.py file prevents pytest from collecting tests from the talk_box package directory
# Tests should only be collected from the tests/ directory
