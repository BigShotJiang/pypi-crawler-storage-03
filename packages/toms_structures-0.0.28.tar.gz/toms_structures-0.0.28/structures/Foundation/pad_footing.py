

class PadFooting:
    M:float = 0
    N:float = 0
    N_eccentricity_x: float = 0
    N_eccentricity_y: float = 0
    depth:float = 0
    length:float = 0
    width:float = 0
    fuc:float = 20

    def max_allowable_bearing(self):
        
        return 

