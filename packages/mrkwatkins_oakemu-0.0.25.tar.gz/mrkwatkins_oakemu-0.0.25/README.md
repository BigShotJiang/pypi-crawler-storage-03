# OakEmu-Python

[![Build Status](https://github.com/MrKWatkins/OakEmu-Python/actions/workflows/build.yml/badge.svg)](https://github.com/MrKWatkins/OakEmu-Python/actions/workflows/build.yml)
[![PyPI - Version](https://img.shields.io/pypi/v/mrkwatkins-oakemu)](https://pypi.org/project/mrkwatkins-oakemu/)
[![PyPI - Downloads](https://img.shields.io/pypi/dm/mrkwatkins-oakemu)](https://pypi.org/project/mrkwatkins-oakemu/)

> Python wrappers for the [OakEmu](https://github.com/MrKWatkins/OakEmu) project.