from enum import IntEnum


class ZXColour(IntEnum):
    BLACK = 0
    BLUE = 1
    RED = 2
    MAGENTA = 3
    GREEN = 4
    CYAN = 5
    YELLOW = 6
    WHITE = 7
