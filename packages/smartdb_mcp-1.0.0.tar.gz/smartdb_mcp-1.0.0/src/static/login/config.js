// 外部配置文件 - 可在打包后修改
window.APP_CONFIG = {
  client_id: 'smart_db_client_id',
  client_secret: 'smart_db_client_secret'
};
