class SQLPermissionError(Exception):
    """SQL 权限错误"""
    pass

class SQLExecutionError(Exception):
    """SQL 执行错误"""
    pass