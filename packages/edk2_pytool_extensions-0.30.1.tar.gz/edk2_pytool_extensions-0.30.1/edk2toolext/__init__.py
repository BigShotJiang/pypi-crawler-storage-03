##
# Copyright (c) Microsoft Corporation
#
# SPDX-License-Identifier: BSD-2-Clause-Patent
##
"""This file exists to satisfy pythons packaging requirements.

Read more: https://docs.python.org/3/reference/import.html#regular-packages
"""
