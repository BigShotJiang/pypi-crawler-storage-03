from .deprecation import deprecated

__all__ = ["deprecated"]
