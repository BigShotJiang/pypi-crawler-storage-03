# Quantify-core Design

This is the place to specify planned features and design guides for Quantify-core.

```{toctree}
:maxdepth: 1

dataset/index
```
