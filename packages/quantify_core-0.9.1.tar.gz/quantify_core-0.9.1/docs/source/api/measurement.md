# `quantify_core.measurement`

```{eval-rst}
.. automodule:: quantify_core.measurement
    :members:
```

## `types`

```{eval-rst}
.. automodule:: quantify_core.measurement.types
    :members:
```

## `control`

```{eval-rst}
.. automodule:: quantify_core.measurement.control
    :members:
```

