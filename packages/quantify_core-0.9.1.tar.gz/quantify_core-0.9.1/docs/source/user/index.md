(user-guide)=
# User guide

```{toctree}
:caption: Getting started
:maxdepth: 1

about
installation
```

```{toctree}
:caption: Basic concepts
:maxdepth: 1

concepts
```

```{toctree}
:caption: Extras
:maxdepth: 1

bibliography
authors
changelog
release_notes
```
