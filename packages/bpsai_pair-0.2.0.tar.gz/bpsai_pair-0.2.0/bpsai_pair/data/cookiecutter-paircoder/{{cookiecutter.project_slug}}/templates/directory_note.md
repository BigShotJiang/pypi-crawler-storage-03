
# Directory Note — <dir>

**Purpose:** <why this directory exists>
**Entry Points:** <files/modules used externally>
**Invariants:** <constraints, contracts, side effects>
**Dependencies:** <allowed deps, forbidden deps>

## Do / Don’t
- Do: <guideline>
- Don’t: <pitfall>

## Gotchas
- <common issues>

## Glossary
- <term>: <definition>
