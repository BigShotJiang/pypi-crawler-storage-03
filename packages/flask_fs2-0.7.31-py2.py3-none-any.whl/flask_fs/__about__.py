__description__ = "Simple and easy file storages for Flask"
