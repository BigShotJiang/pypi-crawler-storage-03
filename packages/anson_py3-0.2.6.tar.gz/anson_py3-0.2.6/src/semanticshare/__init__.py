"""
anson.py3/src/semanticshare/__init__.py
Namespace: semanticshare
@since 0.2.6
"""