# risk-kit
An open source python model for build Expert Driven Credit Risk Scorecards
