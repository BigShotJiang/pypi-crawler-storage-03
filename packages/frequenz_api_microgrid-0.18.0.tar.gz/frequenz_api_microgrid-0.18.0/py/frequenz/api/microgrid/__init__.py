# License: MIT
# Copyright © 2022 Frequenz Energy-as-a-Service GmbH

"""Frequenz gRPC API for monitoring and control of microgrids."""
