from dataclasses import dataclass

@dataclass
class RecordDiarize():
    speaker:str
    text:str