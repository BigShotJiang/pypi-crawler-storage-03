## Introduction

...

## Setup

This library is available on [PyPi](https://pypi.python.org/pypi/exeplot/) and can be simply installed using Pip:

```sh
pip install exeplot
```

