# hexora: Static analysis of malicous Python scripts.
# Copyright (c) 2025, Artem Golubin

from ._hexora import audit_path, audit_file
