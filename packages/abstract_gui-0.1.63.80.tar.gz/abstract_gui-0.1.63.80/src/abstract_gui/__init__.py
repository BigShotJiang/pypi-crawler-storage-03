from .initFuncsCall import getInitForAllTabs
from .QT6.startConsole import *
