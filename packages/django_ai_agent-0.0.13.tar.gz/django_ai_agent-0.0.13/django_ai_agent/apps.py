from django.apps import AppConfig


class DjangoAIAgentConfig(AppConfig):
    name = "django_ai_agent"
    verbose_name = "Django AI agent App"
