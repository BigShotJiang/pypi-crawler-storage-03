from .document import DocumentAdmin
from .document_chunk import DocumentChunkAdmin
