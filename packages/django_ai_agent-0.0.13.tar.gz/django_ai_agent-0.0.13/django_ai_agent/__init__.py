default_app_config = "django_ai_agent.apps.DjangoAIAgentConfig"
