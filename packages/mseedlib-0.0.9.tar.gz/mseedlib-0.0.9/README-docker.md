> [!CAUTION]
> This package is retired, but lives on in https://pypi.org/project/pymseed/

Replaced by [pymseed](https://pypi.org/project/pymseed/)

RIP mseedlib
```
                                               .'.'`'.
                                               /     |
                                              |      |
                                              |      | .--.
                                              |      |/   |
                                              |      ||   |
                                              |      | \  |
                                              |      |  `'
                                            .'|      |
              ________________             /  |      |
             /                \           |   `'--.  |
            |                  |          |      /   |
            |     R. I. P.     |           `'--'`    |
            |                  |              |      |
            |                  |              |      |
            |__________________|              |      |
           /                  /|              |      |
          /__________________/ |          ,',"|      |",',
__________|__________________|/_________ ~"~"`"~"~"`"~"~`"~
```
