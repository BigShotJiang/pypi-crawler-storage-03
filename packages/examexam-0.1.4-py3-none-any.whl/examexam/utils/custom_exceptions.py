class ExamExamValueError(ValueError):
    """ExamExam does not like that value"""


class ExamExamTypeError(TypeError):
    """ExamExam does not like that"""
