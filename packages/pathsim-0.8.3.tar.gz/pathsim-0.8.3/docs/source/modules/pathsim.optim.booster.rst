pathsim.optim.booster module
============================

.. automodule:: pathsim.optim.booster
   :members:
   :show-inheritance:
   :undoc-members:
