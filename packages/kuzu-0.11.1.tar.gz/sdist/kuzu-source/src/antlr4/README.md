Neither `Cypher.g4` nor `keywords.txt` can be individually used to generate Kuzu's grammar. Rather, the files are combined to generate `scripts/antlr4/Cypher.g4`, which is immediately digestible.
