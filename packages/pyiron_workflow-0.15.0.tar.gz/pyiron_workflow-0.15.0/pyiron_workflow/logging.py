from pyiron_snippets.logger import logger as logger

# For now, we use the snippets logger with absolutely zero changes
