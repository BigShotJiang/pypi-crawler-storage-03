"""CLI components for lu77U-MobileSec"""
