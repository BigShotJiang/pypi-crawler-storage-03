"""
Configuration settings for lu77U-MobileSec
"""

APP_NAME = "lu77U-MobileSec"
APP_VERSION = "0.0.1"
APP_DESCRIPTION = "The Only Mobile Security Tool Which You Need"
APP_AUTHOR = "Sam MG Harish"
APP_EMAIL = "sammgharish@gmail.com"

SOCIAL_LINKS = {
    "GitHub Repository": "https://github.com/sam-mg/lu77U-MobileSec"
}