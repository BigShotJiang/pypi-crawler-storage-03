from enum import Enum

class StatusEnum(Enum):
    On = 0
    Off = 1