from enum import Enum

class ListenerType(str, Enum):
    HTTP_CALLBACK = "http-callback"
