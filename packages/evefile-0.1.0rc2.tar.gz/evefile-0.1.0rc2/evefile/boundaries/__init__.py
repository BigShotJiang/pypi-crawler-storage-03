"""Interfaces of the evefile package: facades and resources."""
