To install this module, you need:

- crm
- base_location located in OCA/partner-contact repo
