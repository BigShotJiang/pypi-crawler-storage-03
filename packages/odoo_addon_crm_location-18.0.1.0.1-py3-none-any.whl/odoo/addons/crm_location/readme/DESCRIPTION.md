This module introduces a better zip.

It enables zip, city, state and country auto-completion on lead.
