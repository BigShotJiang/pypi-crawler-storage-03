"""Evaluation definition management.

This module handles loading and parsing of evaluation YAML files.
"""
