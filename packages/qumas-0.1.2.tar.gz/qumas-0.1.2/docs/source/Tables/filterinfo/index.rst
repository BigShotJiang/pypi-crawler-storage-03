Filterinfo
==========

.. include:: ../../../../qumas/Tables/filterinfo/README.md
   :parser: myst_parser.sphinx_

.. toctree::
   :maxdepth: 1

   filter_unique
