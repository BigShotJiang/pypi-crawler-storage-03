qumas.Tools.linear\_fit module
=============================

.. automodule:: qumas.Tools.linear_fit
   :members:
   :show-inheritance:
   :undoc-members:
