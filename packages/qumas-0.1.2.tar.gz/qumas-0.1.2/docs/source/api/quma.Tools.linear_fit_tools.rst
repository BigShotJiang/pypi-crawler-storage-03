qumas.Tools.linear\_fit\_tools module
====================================

.. automodule:: qumas.Tools.linear_fit_tools
   :members:
   :show-inheritance:
   :undoc-members:
