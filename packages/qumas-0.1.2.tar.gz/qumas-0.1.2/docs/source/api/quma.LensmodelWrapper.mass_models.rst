qumas.LensmodelWrapper.mass\_models module
=========================================

.. automodule:: qumas.LensmodelWrapper.mass_models
   :members:
   :show-inheritance:
   :undoc-members:
