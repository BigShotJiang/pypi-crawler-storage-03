"""smartlife device sharing sdk version."""

VERSION = "0.2.2"