"""Module to support aiohomematic testing with a local client."""
