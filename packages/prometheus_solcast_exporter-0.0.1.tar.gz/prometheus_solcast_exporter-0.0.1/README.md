`prometheus_solcast_exporter`
=============================

A very quick and dirty unofficial Prometheus exporter for [Solcast's free home
solar forecast API](https://solcast.com/free-rooftop-solar-forecasting). (So
dirty it doesn't even have any tests!)


Usage
-----

    $ prometheus_solcast_exporter RESOURCE_ID --api-key=API_KEY

> [!TIP]
>
> The `RESOURCE_ID` is the ID used to identify a particular array and usually
> has the form `XXXX-XXXX-XXXX-XXXX`.

By default will run an Prometheus exporter on port 9534. See `--help` for
further options.


Metrics
-------

Produces two sets of metrics:

* `solcast_up{resource_id="..."}`: 1 when the most recent Solcast API request
  succeeded, 0 otherwise.
* `solcast_forecast_watts{resource_id="...", time_offset="NNN",
  centile="..."}`: The forecast solar power in Watts. The `time_offset` label
  gives the number of minutes into the future the forecast is for. The
  `centile` label is either empty (for the main estimate), 10 (for the 10th
  percentile estimate) or 90 (for the 90th percentile estimate).

Forecast data is fetched at an interval configured by the `--max-age` argument,
defaulting to 180 minutes to avoid hitting the 10 requests per day API rate
limit. The most recently fetched data (appropriately time shifted) is returned
between requests.

Historic estimated values are not captured.
