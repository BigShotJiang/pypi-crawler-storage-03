## Django Simple Ordering

A package for adding simple integer-based ordering to your Django models.
