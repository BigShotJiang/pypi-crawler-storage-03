"""PAR CLI TTS - Command line text-to-speech tool."""

__version__ = "0.2.0"
