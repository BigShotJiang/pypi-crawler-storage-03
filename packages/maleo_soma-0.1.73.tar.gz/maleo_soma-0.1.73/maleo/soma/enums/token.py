from enum import StrEnum


class TokenType(StrEnum):
    REFRESH = "refresh"
    ACCESS = "access"
