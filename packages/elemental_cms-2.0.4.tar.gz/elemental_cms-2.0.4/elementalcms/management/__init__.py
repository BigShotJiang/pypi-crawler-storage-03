from .globaldeps import GlobalDeps
from .media import Media
from .pages import Pages
from .snippets import Snippets
from .static import Static
from .cli import cli
