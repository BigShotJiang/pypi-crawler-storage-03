## Command

`async-kernel` is installed at the command prompt. You can use it to:

- Launch a kernel manually
- Define a new kernel spec
- Remove an existing kernel spec

:::async_kernel.command
