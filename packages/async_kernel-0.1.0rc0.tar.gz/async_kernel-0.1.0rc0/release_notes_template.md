If this is a PR for the new release.

1. Merge the PR
    a. Update these release notes and keep a copy handy to use in the release.
    b. Merge the release.
1. Create a release
    a. Go to Code -> tags -> create a release
    b. In the new release use the version in the release notes as a tag.
    c. Use the release notes that were copied.
