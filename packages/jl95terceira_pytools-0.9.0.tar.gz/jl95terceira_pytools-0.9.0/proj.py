import os.path

PATH      = os.path.split(__file__)[0]
TOOLS_DIR = 'jl95terceira-pytools'