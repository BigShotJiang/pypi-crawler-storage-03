"""
Package for parsing data from various sources.
"""
