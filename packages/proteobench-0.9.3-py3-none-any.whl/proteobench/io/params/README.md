# Params

Parsing of parameter files of data analysis software.
