import OpenHowNet
OpenHowNet.download()
