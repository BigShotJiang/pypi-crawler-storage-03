.. _spkg_database_odlyzko_zeta:

database_odlyzko_zeta: Table of zeros of the Riemann zeta function
==================================================================

Description
-----------

Table of zeros of the Riemann zeta function by Andrew Odlyzko.

This package contains the file 'zeros6' with the first 2,001,052 zeros
of the Riemann zeta function, accurate to within 4*10^(-9).


Type
----

optional


Dependencies
------------

- :ref:`spkg_sagemath_environment`
- :ref:`spkg_sagemath_objects`

Version Information
-------------------

package-version.txt::

    20061209

Equivalent System Packages
--------------------------

# See https://repology.org/project/sage-data-odlyzko-zeta/versions

However, these system packages will not be used for building Sage
because ``spkg-configure.m4`` has not been written for this package;
see :issue:`27330` for more information.
