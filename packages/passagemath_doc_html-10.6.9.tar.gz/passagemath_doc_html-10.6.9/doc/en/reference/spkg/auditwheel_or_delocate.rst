.. _spkg_auditwheel_or_delocate:

auditwheel_or_delocate: Repair wheels on Linux or macOS
=======================================================

Description
-----------

This package represents ``auditwheel`` on Linux and ``delocate`` on macOS.

(Actually, we install ``delocate`` also on Linux because our script
``make -j list-broken-packages`` uses a small subroutine of ``delocate``
even on Linux.)

License
-------

MIT

BSD 2-clause

Upstream Contact
----------------

https://pypi.org/project/auditwheel/

https://pypi.org/project/delocate/


Type
----

optional


Dependencies
------------

- $(PYTHON)
- $(PYTHON_TOOLCHAIN)

Version Information
-------------------

requirements.txt::

    delocate
    auditwheel; sys_platform != 'darwin'

Equivalent System Packages
--------------------------

(none known)
