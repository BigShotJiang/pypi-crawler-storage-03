def main():
    print("Hello from anyrfc!")


if __name__ == "__main__":
    main()
