"""Core framework unit tests."""
