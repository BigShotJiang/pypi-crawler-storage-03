"""WebSocket unit tests."""
