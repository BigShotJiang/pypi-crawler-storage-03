"""WebSocket (RFC 6455) test suite."""
