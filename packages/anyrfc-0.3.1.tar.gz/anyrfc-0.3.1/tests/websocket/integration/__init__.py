"""WebSocket integration tests."""
