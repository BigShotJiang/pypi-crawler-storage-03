"""WebSocket RFC 6455 compliance tests."""
