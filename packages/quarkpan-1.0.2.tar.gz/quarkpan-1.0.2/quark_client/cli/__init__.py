"""
QuarkPan CLI 模块
"""

from .main import app

__all__ = ['app']
