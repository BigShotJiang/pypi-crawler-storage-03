# tablex/__init__.py

__version__ = "0.1.0"
__author__ = "Samartha M J"
__license__ = "MIT"

from .converter import TableX

__all__ = ["TableX"]
