# HarmonyMIDIToken

- HarmonyMIDIToken 은 AI Agent DIVA 의 Melody Generate Tool 의 Tokenizer 이름이며, pitch 에 따른Instrument 구분이 완료된 Future Bounce Midi 파일을 음향학적으로 나타낼 수 있다.