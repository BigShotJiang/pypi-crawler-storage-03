__version__ = "0.2.39"

from .convert import convert_urdf_to_mjcf as run
