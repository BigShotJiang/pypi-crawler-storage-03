"""
Main entry point for synclub_mcp server when run as a module.
"""

from synclub_mcp.server import main

if __name__ == "__main__":
    main() 