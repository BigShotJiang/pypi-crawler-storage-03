__all__ = [
    "__author__",
    "__copyright__",
    "__version__",
]

__version__ = "0.1.0"
__author__ = "Kamal Fasya"
__copyright__ = f"Copyright 2025 {__author__}"
