# Filing System based Composite

This example shows how to locally render a filing system based
Composite. First run function-pythonic using the run-pythonic.sh
script in this directory in one shell session. Then run the
render.sh script in another shell session.
