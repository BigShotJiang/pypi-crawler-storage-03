# sage_setup: distribution = sagemath-fricas
