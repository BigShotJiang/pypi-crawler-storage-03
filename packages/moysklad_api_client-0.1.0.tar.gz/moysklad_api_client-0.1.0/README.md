# moysklad-api-client

Лёгкий асинхронный клиент для работы с MoySklad API на базе httpx.
При ответе 429,503 происходит ретрай с exponential backoff.
## Установка
pip
```bash
pip install moysklad-api-client
```
poetry
```bash
poetry add moysklad-api-client
```
## Пример
Работа через контекстный менеджер
```python
import asyncio
from moysklad_api_client import APIClient, Entity

async def main():
    async with APIClient() as client:
        response = await client.get(Entity.PRODUCT, api_key="your_token")
        print(response.status_code, response.json())

asyncio.run(main())
```
Работа через экземпляр класса
```python
async def main():
    client = APIClient()
    response = await client.get(
        entity_name='customerorder',
        api_key='api_key',
        params={'limit': 1, 'offset': 100}

    )
    return response.json() 

asyncio.run(main())
```