class BadResponse(Exception):
    def __init__(self, message: str, error_code: int):
        super().__init__(message)
        self.error_code = error_code
        
    
    def __str__(self):
        return f"{self.args[0]} - {self.error_code}"
    
    
class AttemptLimit(Exception):
    def __init__(self, message: str, limit: int):
        super().__init__(message)
        self.limit = limit
        

    def __str__(self):
        return f"{self.args[0]} - {self.limit} attempts"
    
class ServerError(Exception):
    def __init__(self, message: str):
        super().__init__(message)
    
    def __str__(self):
        return f"{self.args[0]}"
    
