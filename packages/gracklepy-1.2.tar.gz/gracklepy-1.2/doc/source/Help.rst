Help
----

Mailing List
~~~~~~~~~~~~

If you have any questions, please join the `Grackle Users Google Group
<https://groups.google.com/forum/#!forum/grackle-cooling-users>`_.  Feel
free to post any questions or ideas for development.

Slack Channel
~~~~~~~~~~~~~

We also use `Slack <https://slack.com/>`__ for lower latency discussions.
If you'd like help in real time, this is the place.
Click `here
<https://join.slack.com/t/grackle-project/shared_invite/enQtODc3MDA1NjQ0MTY3LTI5OTQ4ZjU4YTk0OTM0YzBiOTE4OGJmNDQyMTA4MmU1ZjMxOTMyN2FjNGM1OTkxOGE2NzM0Yzc1YWUzMDhiODY>`__
for an invitation to our Slack channel.

GitHub Issues
~~~~~~~~~~~~~

Alternatively you can describe issues or get help or post ideas for development by openning a  `GitHub Issue <https://github.com/grackle-project/grackle/issues>`__
