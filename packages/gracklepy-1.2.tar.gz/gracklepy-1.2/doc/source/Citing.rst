.. _citing:

.. include:: ../../CITATION.rst
