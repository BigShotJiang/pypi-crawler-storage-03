class IllegalArgumentException(Exception):
    ...


class IllegalStateException(Exception):
    ...


class ConfigurationMissingException(Exception):
    ...
