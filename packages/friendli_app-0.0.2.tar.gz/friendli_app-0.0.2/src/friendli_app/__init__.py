"""Friendli App - AI agent framework with CLI and SDK."""

__version__ = "0.1.0"

# SDK is available as friendli_app.sdk
# CLI is available via the fa or friendli-app commands


__all__ = ["__version__"]
