# Copyright (c) 2025-present, FriendliAI Inc. All rights reserved.

"""Friendli Client schemas."""

from __future__ import annotations

from friendli_app.cli.schema.user import WhoamiResponse as WhoamiResponse
