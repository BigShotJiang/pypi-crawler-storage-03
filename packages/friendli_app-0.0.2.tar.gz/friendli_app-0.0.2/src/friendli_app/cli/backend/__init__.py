# Copyright (c) 2025-present, FriendliAI Inc. All rights reserved.

"""CLI application backends.

- auth backend
- settings backend

"""
