# Copyright (c) 2025-present, FriendliAI Inc. All rights reserved.

"""CLI command actions.

While commands define the interfaces shown to the user, actions define the
implementation of those interfaces.
"""
