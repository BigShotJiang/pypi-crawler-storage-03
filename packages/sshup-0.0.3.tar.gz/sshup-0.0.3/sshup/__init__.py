"""sshup"""

######################################################################
# Main app information.
__author__     = "Wael Ramadan"
__copyright__  = "Copyright 2025, Wael Ramadan"
__credits__    = [ "Wael Ramadan" ]
__maintainer__ = "Wael Ramadan"
__email__      = "wamramadan@gmail.com"
__version__    = "0.0.3"
__licence__    = "MIT"
