class Detector():
    def __init__(self):
        pass
    
    def detect(self, image):
        pass