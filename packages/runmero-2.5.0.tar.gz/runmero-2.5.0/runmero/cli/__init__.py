# حقوق الطبع والنشر محفوظة © 2025 mero - من مدينة عكا الصامدة فلسطين

from .main import main, cli

__all__ = ['main', 'cli']
