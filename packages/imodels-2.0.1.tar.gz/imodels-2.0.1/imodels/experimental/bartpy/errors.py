
class NoSplittableVariableException(Exception):
    pass


class NoPrunableNodeException(Exception):
    pass
