

# Update Solution Component
## Display Name
First Component
## Description
My first component
## Solution Component Type
Test Jig
## In Solution Blueprints
SolutionBlueprint::Automated Manufacturing Control::0.5.9.1
## In Supply Chains
InformationSupplyChain::puddys_supply_chain
Main Supply Chain
## Merge Update
False
___

# Update Solution Component
## Display Name
Second Component
## Description
My second component
## Solution Component Type
Test Jig
## In Solution Blueprint
Master Plan
___

# Update Solution Component
## Display Name
Sub-Component 1
## Description
A first sub-component
## In Solution Component
First Component
___

# Update Solution Component
## Display Name
Sub-Component 2
## Description
A second sub-component
## In Solution Component
First Component

___

# Link Solution Components
## Component1
First Component
## Component2
Second Component
## Wire Label
A linking label
## Description
So they can hang out together.