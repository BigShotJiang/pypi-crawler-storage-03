from issue_solver.cli.cudu_cli import CuduCLI


def run_main() -> None:
    CuduCLI.run()


if __name__ == "__main__":
    run_main()
