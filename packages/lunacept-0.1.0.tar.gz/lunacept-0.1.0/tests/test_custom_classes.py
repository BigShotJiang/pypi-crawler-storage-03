#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自定义类测试
测试XTrace对自定义类实例的变量显示能力
"""

# TODO: 实现自定义类测试
# - 类方法中的异常
# - 实例属性访问错误
# - 类继承中的异常
# - 特殊方法(__repr__, __str__等)的显示

pass
