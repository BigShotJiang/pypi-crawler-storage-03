from iccore import logging_utils


def test_dedefault_logger():

    logging_utils.setup_default_logger()
