from setuptools import setup, find_packages

setup(
    name='colorme',
    version='0.1.0',
    packages=find_packages(),
    description='Print hex-colored text in your terminal from Python',
    author='TS-DEV-JAVA',
    url='https://github.com/ts-dev-java/colorme',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: GNU General Public License v2 (GPLv2)',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)