# colorme-v2

Print hex-colored text in your terminal from Python.

## Features

- Color text using hex codes
- Support for bold and underline styles
- Easy to use API
- Super light-weight

## Installation

```bash
pip install colorme-v2
```

## Usage
```python
from colorme import color_text, bold, underline

# Prints hello world in PURE red

print(color_text("Hello in red!", "#ff0000"))
# Prints Blue backround

print(color_text("Background blue", "#0000ff", background=True))

# Prints Bold green text
print(bold(color_text("Bold green", "#00ff00")))

# Prints Orange Underlined Text
print(underline(color_text("Underlined orange", "#ffa500")))
```

# License

this project is licensed under:

GPL-2.0 License