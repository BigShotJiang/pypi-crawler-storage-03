from .color import color_text
from .styles import bold, underline

__all__ = ['color_text', 'bold', 'underline']
