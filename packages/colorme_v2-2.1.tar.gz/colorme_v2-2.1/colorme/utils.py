def hex_to_rgb(hex_color: str) -> tuple:
    """Convert hex color (e.g. '#ff5733') to RGB tuple."""
    hex_color = hex_color.strip().lstrip('#')
    if len(hex_color) != 6:
        raise ValueError(f"Invalid hex color: '{hex_color}'")
    r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    return r, g, b
