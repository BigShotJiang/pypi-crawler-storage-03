# 🎨 ASCII-Me

Convierte imágenes y GIFs en arte ASCII a color directamente en tu terminal.  
Compatible con **Linux, macOS y Windows**.

---

## 🚀 Instalación

Clona el repositorio e instala con `pip`:

```bash
git clone https://github.com/WetZap/Ascii-Me.git
cd Ascii-Me
pip install .
