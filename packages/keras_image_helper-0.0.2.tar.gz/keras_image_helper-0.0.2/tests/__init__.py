# Tests package for keras-image-helper
