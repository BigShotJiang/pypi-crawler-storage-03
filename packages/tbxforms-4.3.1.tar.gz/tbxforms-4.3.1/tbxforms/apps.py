from django.apps import AppConfig


class TbxFormsConfig(AppConfig):
    name = "tbxforms"
