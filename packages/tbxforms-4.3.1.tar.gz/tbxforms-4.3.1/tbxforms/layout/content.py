from crispy_forms import layout as crispy_forms_layout


class HTML(crispy_forms_layout.HTML):
    pass
