from PIL import Image
import os
import sys

def resize_image():
    """
    CLI command to resize images.
    Usage:
      resizer input.png output.png 0.5
      resizer input_folder output_folder 0.5
    """
    if len(sys.argv) < 4:
        print("Usage:")
        print("  Single file: resizer input.png output.png 0.5")
        print("  Whole folder: resizer input_folder output_folder 0.5")
        return

    input_path = sys.argv[1]
    output_path = sys.argv[2]
    scale_factor = float(sys.argv[3])

    def resize_single(input_path, output_path, scale_factor):
        try:
            img = Image.open(input_path)
            new_size = (int(img.width * scale_factor), int(img.height * scale_factor))
            resized_img = img.resize(new_size, Image.LANCZOS)
            resized_img.save(output_path, format=img.format)
            print(f"✅ Resized {input_path} → {output_path} ({new_size})")
        except Exception as e:
            print(f"❌ Error resizing {input_path}: {e}")

    def resize_folder(input_folder, output_folder, scale_factor):
        os.makedirs(output_folder, exist_ok=True)
        supported_ext = (".png", ".jpg", ".jpeg", ".webp")
        for filename in os.listdir(input_folder):
            if filename.lower().endswith(supported_ext):
                resize_single(
                    os.path.join(input_folder, filename),
                    os.path.join(output_folder, filename),
                    scale_factor,
                )

    if os.path.isdir(input_path):
        resize_folder(input_path, output_path, scale_factor)
    elif os.path.isfile(input_path):
        resize_single(input_path, output_path, scale_factor)
    else:
        print(f"Error: {input_path} not found.")
