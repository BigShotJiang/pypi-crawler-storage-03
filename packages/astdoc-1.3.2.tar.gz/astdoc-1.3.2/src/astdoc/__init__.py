"""Parse abstract syntax trees (AST) and extracting docstring information."""
