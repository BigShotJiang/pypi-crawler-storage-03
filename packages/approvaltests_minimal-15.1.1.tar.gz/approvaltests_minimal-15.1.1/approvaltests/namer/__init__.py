"""Approvaltests.namer module."""

from .default_namer_factory import *
from .stack_frame_namer import *
