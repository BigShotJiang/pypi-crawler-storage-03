WEEK = 7  # Days in a week
MONTH = 30.44  # Average days in a month
YEAR = 365.25  # Average days in a year
