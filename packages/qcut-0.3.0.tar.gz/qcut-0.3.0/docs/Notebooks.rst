Notebooks
======================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   Basic Usage <examples/QCutBasicUsage.ipynb>
   Subsequent Wires <examples/QCutCutSubsequentWires.ipynb>
   Cut to Three parts <examples/QCutCutToThreeParts.ipynb>
   Multiple cuts on a single wire <examples/QCutMultipleCutsOnSingleWire.ipynb>