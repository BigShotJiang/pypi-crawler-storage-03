Examples on using QCut
======================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   Multiple_cuts
   OtherObservables