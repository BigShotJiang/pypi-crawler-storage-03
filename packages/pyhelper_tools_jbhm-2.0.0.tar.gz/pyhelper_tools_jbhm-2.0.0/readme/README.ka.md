# დამხმარე ბიბლიოთეკა

[!  
[!  

## ხელმისაწვდომი ენები

[! [en] (https://img.shields.io/badge/lang-en-red.svg)] (readme.md)  
[!  
[! [fr] (https://img.shields.io/badge/lang-fr-blue.svg)] (readme.fr.md)  
[! [de] (https://img.shields.io/badge/lang-de-creen.svg)] (readme.de.md)  
[! [ru] (https://img.shields.io/badge/lang-ru-purple.svg)] (readme.ru.md)  
[! [Tr] (https://img.shields.io/badge/lang-tr-orange.svg)] (readme.tr.md)  
[! [ZH] (https://img.shields.io/badge/lang-zh-black.svg)] (readme.zh.md)  
[!  
[!  
[!  
[!  
[! [ar] (https://img.shields.io/badge/lang-ar-brown.svg)] (readme.ar.md)  
[! [AF] (https://img.shields.io/badge/lang-af-orange.svg)] (readme.af.md)  
[!  
[!  
[!  
[! [as] (https://img.shields.io/badge/lang-as-purple.svg)] (readme.as.md)  
[!  
[!  
[! [BM] (https://img.shields.io/badge/lang-bm-darkgreen.svg)] (readme.bm.md)  
[! [Eu] (https://img.shields.io/badge/lang-eu-pink.svg)] (readme.eu.md)  
[!  
[! [Bn] (https://img.shields.io/badge/lang-bn-teal.svg)] (readme.bn.md)  
[!  
[!  
[! [BG] (https://img.shields.io/badge/lang-bg-green.svg)] (readme.bg.md)  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[! [DV] (https://img.shields.io/badge/lang-dv-orange.svg)] (readme.dv.md)  
[! [doi] (https://img.shields.io/badge/lang-doi-brown.svg)] (readme.doi.md)  
[! [NL] (https://img.shields.io/badge/lang-nl-orange.svg)] (readme.nl.md)  
[! [eo] (https://img.shields.io/badge/lang-eo-creen.svg)] (readme.eo.md)  
[! [et] (https://img.shields.io/badge/lang-et-blue.svg)] (readme.et.md)  
[!  
[!  
[!  
[!  
[! [gl] (https://img.shields.io/badge/lang-gl-green.svg)] (readme.gl.md)  
[!  
[! [El] (https://img.shields.io/badge/lang-el-blue.svg)] (readme.el.md)  
[!  
[! [Gu] (https://img.shields.io/badge/lang-gu-orange.svg)] (readme.gu.md)  
[!  
[! [HA] (https://img.shields.io/badge/lang-ha-blue.svg)] (readme.ha.md)  
[!  
[!  
[!  
[!  
[!  
[! [is] (https://img.shields.io/badge/lang-is-red.svg)] (readme.is.md)  
[!  
[!  
[! [id] (https://img.shields.io/badge/lang-id-creen.svg)] (readme.id.md)  
[!  
[! [JW] (https://img.shields.io/badge/lang-jw-red.svg)] (readme.jw.md)  
[!  
[!

[! [კმ] (https://img.shields.io/badge/lang-km-green.svg)] (readme.km.md)  
[! [RW] (https://img.shields.io/badge/lang-rw-blue.svg)] (readme.rw.md)  
[!  
[!  
[!  
[! [ku] (https://img.shields.io/badge/lang-ku-green.svg)] (readme.ku.md)  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[! [MK] (https://img.shields.io/badge/lang-mk-green.svg)] (readme.mk.md)  
[! [MAI] (https://img.shields.io/badge/lang-mai-blue.svg)] (readme.mai.md)  
[! [MG] (https://img.shields.io/badge/lang-mg-red.svg)] (readme.mg.md)  
[! [MS] (https://img.shields.io/badge/lang-m-purple.svg)] (readme.ms.md)  
[! [ML] (https://img.shields.io/badge/lang-ml-orange.svg)] (readme.ml.md)  
[! [MT] (https://img.shields.io/badge/lang-mt-creen.svg)] (readme.mt.md)  
[!  
[!  
[!  
[! [Mn] (https://img.shields.io/badge/lang-mn-orange.svg)] (readme.mn.md)  
[!  
[! [ne] (https://img.shields.io/badge/lang-ne-blue.svg)] (readme.ne.md)  
[! [არა] (https://img.shields.io/badge/lang-no-red.svg)] (readme.no.md)  
[! [ან] (https://img.shields.io/badge/lang-or-purple.svg)] (readme.or.md)  
[! [om] (https://img.shields.io/badge/lang-om-orange.svg)] (readme.om.md)  
[! [PS] (https://img.shields.io/badge/lang-ps-green.svg)] (readme.ps.md)  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[! [St] (https://img.shields.io/badge/lang-st-purple.svg)] (readme.st.md)  
[! [SN] (https://img.shields.io/badge/lang-sn-orange.svg)] (readme.sn.md)  
[!  
[!  
[! [SK] (https://img.shields.io/badge/lang-sk-red.svg)] (readme.sk.md)  
[! [SL] (https://img.shields.io/badge/lang-sl-purple.svg)] (readme.sl.md)  
[!  
[!  
[! [SW] (https://img.shields.io/badge/lang-sw-blue.svg)] (readme.sw.md)  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[!  
[! [AK] (https://img.shields.io/badge/lang-ak-creen.svg)] (readme.ak.md)  
[! [UK] (https://img.shields.io/badge/lang-uk-blue.svg)] (readme.uk.md)  
[!  
[! [ug] (https://img.shields.io/badge/lang-ug-purple.svg)] (readme.ug.md)  
[!  
[! [vi] (https://img.shields.io/badge/lang-vi-green.svg)] (readme.vi.md)  
[! [Cy] (https://img.shields.io/badge/lang-cy-blue.svg)] (readme.cy.md)

[! [XH] (https://img.shields.io/badge/lang-xh-red.svg)] (readme.xh.md)  
[!  
[! [yo] (https://img.shields.io/badge/lang-yo-orange.svg)]]  
[! [zu] (https://img.shields.io/badge/lang-zu-green.svg)] (readme.zu.md)

---

## 📖 Overview

**PyHelper** is a versatile Python toolkit designed to simplify **data analysis, visualization, statistical operations, and utility workflows**.  
It integrates seamlessly into academic, research, and professional projects, allowing you to focus on insights rather than boilerplate code.

Key advantages:
- 🧮 Built-in **statistics and math utilities**
- 📊 Easy-to-use **data visualization wrappers**
- 🗂 Handy **file handling and searching**
- 🔍 **Syntax validation** for Python files
- 🌍 **Multi-language support** with ready-to-use translations
- 🚀 Optimized for **fast prototyping** and **educational purposes**

---

## ✨ Features

### 📊 Data Visualization
- Horizontal & vertical bar charts (`hbar`, `vbar`)
- Pie charts (`pie`)
- Box plots (`boxplot`)
- Histograms (`histo`)
- Heatmaps (`heatmap`)
- Data tables (`table`)
- Advanced visualizations (scatter, violin, KDE, pairplot, etc.)

### 📈 Statistical Analysis
- Measures of central tendency:  
  `get_media`, `get_median`, `get_moda`
- Measures of dispersion:  
  `get_rank`, `get_var`, `get_desv`, `disp`
- Data normalization (`normalize`)
- Outlier detection (IQR & Z-score methods)
- Conditional data transformations (`conditional`)

### 🛠 Utilities
- File discovery and loading (`call`)
- Enhanced **Switch / AsyncSwitch** system
- Syntax checking & analysis (`PythonFileChecker`, `check_syntax`)
- Error reporting with context
- Integrated help system (`help`, previews, docs)

### 🌍 Multi-language Support
- Built-in translations for **12 languages**
- Extendable with `load_user_translations()`
- Dynamic selection with `set_language(lang_code)`
- Default fallback to English

---

## 🚀 Installation

Install from PyPI:

```bash
pip install pyhelper-tools-jbhm
```

---

## 🔧 Usage Examples

### Set language
```python
from helper import set_language

set_language("en")  # English
set_language("es")  # Spanish
set_language("fr")  # French
set_language("de")  # German
set_language("ru")  # Russian
set_language("tr")  # Turkish
set_language("zh")  # Chinese
set_language("it")  # Italian
set_language("pt")  # Portuguese
set_language("sv")  # Swedish
set_language("ja")  # Japanese
set_language("ar")  # Arabic
# ... support for 100+ languages
```

### Basic statistics
```python
import helper as hp

data = [1, 2, 2, 3, 4, 5]

print(hp.get_media(data))   # Mean
print(hp.get_median(data))  # Median
print(hp.get_moda(data))    # Mode
```

### Visualization
```python
import helper as hp
from helper.submodules import graph as gr

df = hp.pd.DataFrame({"values": [5, 3, 7, 2, 9]})
gr.histo(df, "values", bins=5, title="Sample Histogram")
```

### File handling
```python
from helper import call

data = call("my_data", type="csv")  # Finds and loads a CSV file automatically
```

### Custom translations
```python
from helper import load_user_translations

# Load custom translations from lang.json
load_user_translations("custom/lang.json")
```

---

## 📂 Project Structure

```
helper/
 ├── core.py              # Main functions
 ├── lang/                # Translation files (JSON)
 ├── submodules/
 │   ├── graph.py         # Visualization functions
 │   ├── statics.py       # Statistical functions
 │   ├── utils.py         # Utility helpers
 └── __init__.py
```

---

## 🤝 Contributing

Contributions are welcome!  
Please open issues, suggest improvements, or submit pull requests on the [GitHub repository](https://github.com/jbhmdev/pyhelper-tools).

---

## 📜 License

This project is licensed under the **MIT License**.  
See the [LICENSE](LICENSE) file for details.

---

⚡ Ready to supercharge your Python workflows with **PyHelper**? Start exploring today!