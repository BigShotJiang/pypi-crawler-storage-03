# Biblioteca Helper

[! [Licenza: MIT] (https://img.shields.io/badge/license-mit-yglent] (licenza)  
[! Pypi] (https://img.sieldspiels.io/pypihelper-tools-jbhm?style=Thegge&label=Typypi..org/Project/pyhelper-tools-jbhm/)  

## 🌍 lingue dispunibili

[! [en] (https://img.shield.sio/badge/lang-en-red.svg)] (readme.md)  
[! [Es] (https://img.shield.sio/badge/lang-es-yvg)] (readme.md)  
[! [FR] (https://img.shield.sides/lang-blue.svg)] (LEADME.MD)  
[! [de] (https://img.shield.sio/badge/lang-de-green.svg)] (readme.md)  
[! [ru] (https://img.siho/badge/lang-ru-puplex.svg)] (ligame.ru.md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md ).md)  
[! [tr] (https://img.shield.sio/badge/lang-tr-tr-tr-vg)] (readme.t.tm)  
[! [ZH] (https://img.shield.sio/badge/lang-zh-black.svg)] (LEATME.MD.MD)  
[! [it] (https://img.shield.sio/badge/lang-it-itgrey.svg)] (readme.it..md)  
[! [Pt] (https://img.shield.sio/badge/lang-pt.pt-pt.t) (readme.pt.md)  
[! [SV] (https://img.shield.sio/badge/lang-sv-blue.svg)] (radme.sv.md)  
[! [JA] (https://img.shield.sio/badge/lang-ja.svg)] (LEADME.JOM)  
[! [AR] (https://img.shield.sio/badge/lang-ar-bown.svg)] (README.A.AR.UD)  
[! [AF] (https://img.shield.io/badge/lang-Af-Onge.svg)] (Readme.af.md)  
[! [Sq] (https://img.shield.sio/badge/lang-sq-blue.svg)] (LEATME.MD.MD)  
[! [AM] (https://img.shield.sio/badge/lang-am-am-mreen] (readme.md)  
[! [HY] (https://img.shield.sio/badge/lang-Red.HYVG)] (README.MY.MD)  
[! [cum'è] (https://img.shield.sio/badge/lang-as-purple.svg)] (Rela..MD)  
[! [AI] (https://img.shield.sio/badge/lang-ay-bg.svg)] (Readme.yay.md)  
[! [AZ] (https://img.shield.sio/badge/lang-az-AzBeue.svg)] (Readme.m.md)  
[! [BM] (https://img.shield.sio/badge/lang-bm-bm-bm-] (readme.mm.md)  
[! [UE] (https://img.shield.sields.io/badge/lang-eu-pink.svg)] (readme.eu.eu.md)  
[! [Be] (https://img.shield.sio/badge/lang-be-DarkBlue.svg)] (Readme.Md)  
[! [Bn] (https://img.shield.sio/badge/lang-bn-teal.svg)] (radme.bn.md)  
[! [BHO] (https://img.shield.io/badge/lang-bho-orange)] (readme.bho.md)  
[! [BS] (https://img.shield.sio/badge/lang-bs-bs-vg)] (readme.mm.md)  
[! [BG] (https://img.shield.sio/badge/lang-bg-Green] (readme.bg.md)  
[! [CA] (https://img.shield.sio/badge/lang-Chow] (readme.ca.md)  
[! [CEB] (https://img.shield.sio/badge/lang-ceb-blue.svg)] (REATME.MM.MD)  
[! [NY] (https://img.shield.sio/badge/lang.yvg)] (Readme.md)  
[! [CO] (https://img.shield.sields/lang-co-green)] (readme.co)  
[! [hr] (https://img.shield.sio/badge/lang-hrue.svg)] (readme.hr)  
[! [CS] (https://img.shields.io/badge/lang-cs-red.svg)] (readme.ms.md)  
[! [da] (https://img.shield.sio/badge/lang-da-purple.svg)] (readme.do.md)  
[! [DV] (https://img.shield.sields.io/badge/lang-dv-orge.svg)] (readme.dv.md)  
[! [DOi] (https://img.shield.sio/badge/lang-doi-bg.svg)] (readme.doi.md)  
[! [NL] (https://img.shield.sields.Ilang-ngl.stl-orgg)] (readme.nl.md)  
[! [EO] (https://img.shield.sio/badge/lang-eo-green)] (readme.eo.eo.eo.md)  
[! [ET] (https://img.shield.sio/badge/lang-et-blue.svg)] (readme.et.md)  
[! [EE] (https://img.shield.sio/badge/lang-Eee.EVG)] (LEATME.EE.MD)  
[! [tl] (https://img.shield.sio/badge/lang-tl-purple.svg)] (readme.md)  
[! [Fi] (https://img.shield.sio/badge/lang-fi-fue.svg)] (LEADME.FI.MD)  
[! [FY] (https://img.shield.io/badge/lang-fy- -vg)] (readme.fy.md)  
[! [gl] (https://img.shield.sio/badge/lang-gl-green)] (readme.ml.md)  
[! [ka] (https://img.shield.sio/badge/lang-ka-VG)] (LEADME.KE.KO.MD)  
[! [El] (https://img.shield.sio/badge/lang-el-bg)] (readme.el.md)  
[! [Gn] (https://img.shield.sio/badge/lang-gn-purple.svg)] (LEATME.MMD)  
[! [GU] (https://img.sield.sio/badge/lang-gu-gu-] (readme.bu.md)  
[! [HT] (https://img.shield.sio/badge/lang-ht-ht-ht)] (readme.ht.ht)  
[! [ha] (https://img.shield.sio/badge/lang-HA-VG)] (README.MD.MD)  
[! [Haw] (https://img.shield.sio/badge/lang-haw-red.svg)] (LEADME.ME.MD)  
[! [IW] (https://img.shield.sio/badge/lang-iw-psu.VG)] (Readme..iw.md)  
[! [Hola] (https://img.shield.sio/badge/lang-hi- -orge.svg)] (Readme.hi..MD)  
[! [HMN] (https://img.shield.sio/badge/lang-hmn-green] (radme.hmn.md)  
[! [hu] (https://img.shields.io/badge/lang-hu-blue.svg)] (LEADME.HU.MD)  
[! [hè] (https://img.shield.sides/lang-is-red.svg)] (REATME.MD)  
[! [ig] (https://img.shield.sio/badge/lang-ig-purple.svg)] (readme.ig.md)  
[! [Ilo] (https://img.shield.sio/badge/lang-ilo-il-il.vg)] (readme.ilo.md)  
[! [ID] (https://img.sides/lang-id-green.svg)] (LEADME.ID.MD)  
[! [GA] (https://img.shield.sio/badge/lang-GE.VG)] (LEADME.GNO.GO)  
[! [JW] (https://img.shield.sields/lang-jw-red.svg)] (readme.jw.md)  
[! [KN] (https://img.shield.sio/badge/lang-KNY.SVG)] (LEATME.KN.KN.DN)  
[! [kk] (https://img.shield.sio/badge/lang-kk-vg)] (readme.kk.md)

[! [km] (https://img.shield.sio/badge/lang-km-green.svg)] (readme.km.md)  
[! [RW] (https://img.shield.sio/badge/lang-rw-blue.svg)] (radme.md)  
[! [Gom] (https://img.shield.sio/badge/lang-gom-red.svg)] (Readme.mom.md)  
[! [ko] (https://img.shield.sio/badge/lang-ko-vo.vg)] (LEADME.KO.KO.KO)  
[! [KRI] (https://img.shield.sio/badge/lang-kri-kri-VG)] (README.KRI.MD)  
[! [ku] (https://img.shield.sio/badge/lang-ku-green] (readme.ku.md)  
[! [CKB] (https://img.shield.sio/badge/lang-ckb-blue.svg)] (Readme.ckeb.md)  
[! [KY] (https://img.shield.sio/badge/lang-ky-Red.svg)] (Readme.ky.md)  
[! [lo] (https://img.shield.sio/badge/lang-lo-purple.svg)] (Readme.o....md)  
[! [la] (https://img.shield.sio/badge/lang-la-Lange.svg)] (Readme.la.MD)  
[! [LV] (https://img.shield.sields/lang-lv-green.itvg)] (Readme.m..md)  
[! [ln] (https://img.shield.sio/badge/lang-brae.svg)] (readme.ln.md)  
[! [LT] (https://img.shield.sides/lang-lt-lt-lt-Lt.lt.lt.lt.MD)  
[! [lg] (https://img.shield.sio/badge/lang-lg-lg.svg)] (readme.lg.md)  
[! [LB] (https://img.shield.sio/badge/lang-lb-lan.svg)] (readme.lm.md)  
[! [MK] (https://img.shield.sio/badge/lang-mk-green] (readme.mk.mm)  
[! [MAI] (https://img.shield.sio/badge/lang-bai-Bie.svg)] (readme.m.mai.md)  
[! [mg] (https://img.shield.sio/badge/lang-mg-red.svg)] (readme.mg.md)  
[! [MS] (https://img.shield.sio/badge/lang-ms-msu.svg)] (readme.ms.ms.md)  
[! [ml] (https://img.shield.sio/madge/lang-ml-ml-.vg)] (LEATME.MM.MD)  
[! [mt] (https://img.shield.sio/badge/lang-mt-green)] (readme.mt.md)  
[! [MI] (https://img.shield.sio/badge/lang-mi-blue.svg)] (readme.mi.mmd)  
[! [Signore] (https://img.shield.sio/badge/lang-mr-MR.) (readme.mr.md)  
[! [lus] (https://img.shield.sio/badge/lang-lus-lus.svg)] (Readme.lus.md)  
[! [mn] (https://img.shield.sio/badge/lang-mn-VN.VG)] (LEATME.MN.MD)  
[! [u mio] (https://img.shield.sio/badge/lang-my-green.svg)] (LEATME.MD)  
[! [VI] (https://img.shield.sio/badge/lang-ne-BRUE.SVG)] (Readme.ne.md)  
[! [No] (https://img.shield.sio/badge/lang-no-Red.svg)] (REATME.MD)  
[! [o] (https://img.shield.sio/badge/lang-or-purple.svg)] (Rela..O.O.O  
[! [Om] (https://img.shield.sio/badge/lang-om-Onge.svg)] (readme.m.md)  
[! [PS] (https://img.shield.sio/badge/lang-ps-green.svg)] (LEADME.MD)  
[! [Fa] (https://img.shield.sio/badge/lang-fue-blue.svg)] (LEADMEFA.MD)  
[! [Qu] https://img.shield.sio/badge/lang-qu-vg)] (Rela..MD)  
[! [RO] (https://img.shield.sio/badge/lang-ro-ru.tvg)] (Readme.ro.ro)  
[! [SM] (https://img.shield.sides/lang-sm-Sm-Svg)] (LEATME.SM.MD)  
[! [SA] (https://img.shield.sio/badge/lang-sa-green.svg)] (LEADME.SA.MD)  
[! [GD] (https://img.shield.sio/badge/lang-bd-blue.svg)] (readme.md.md)  
[! [NSO] (https://img.sides/lang-nsoS-red.svg)] (readme.mm)  
[! [ST] (https://img.shield.sio/badge/lang-st-vente.svg)] (readme.st.md)  
[! [sn] (https://img.shield.sio/badge/lang-Snange.svg)] (LEATME.MD.MD)  
[! [SD] (https://img.shield.sio/badge/lang-sd-green.svg)] (LEABME.SD.MD)  
[! [SI] (https://img.shield.sio/badge/lang-si-Blue.svg)] (REATME.MD)  
[! [SK] (https://img.shields.io/badge/lang-sk-red.svg)] (LEADME.SK.MD)  
[! [Sl] (https://img.shield.sio/badge/lang-Sl-purple.svg)] (LEATME.SL.MD)  
[! [Dunque] (https://img.shield.sio/badge/lang-ssu-Svg)] (LEADME..MD)  
[! [Su] (https://img.shield.sio/badge/lang-su-green.svg)] (REATME.MD)  
[! [SW] (https://img.shield.sio/badge/lang-sw-blue.svg)] (LEABME.SW.MD)  
[! [TG] (https://img.shield.sio/badge/lang-tg-red.svg)] (readme..tg.md)  
[! [TA] (https://img.shield.sio/badge/lang-ta-purple.svg)] (ReteMme..MD)  
[! [TT] (https://img.shields.io/badge/lang-tt-orge.svg)] (readme.tt.t..md)  
[! [te] (https://img.shield.sio/badge/lang-green.svg)] (LEATME..MD)  
[! [th] (https://img.shields.io/badge/lang-th-Blue.svg)] (LEADME.MD)  
[! [ti] (https://img.shield.sio/badge/lang-ti-ti-tix)] (readme.ti.ti)  
[! [Ts] (https://img.shield.sio/badge/lang-TSVE.TVG)] (LEATME.TS.MD)  
[! [TK] (https://img.shield.sio/badge/lang-tk-stg-)] (readme.md.md)  
[! [Ak] (https://img.shield.sio/badge/lang-ak-Green)] (readme.ak)  
[! [UK] (https://img.shields.io/badge/lang-uk-blue.svg)] (Readme.uk.md)  
[! [UR] (https://img.shield.sides/lang-ur-Red.svg)] (Rela..ur.md)  
[! [U UG] (https://img.shield.sio/badge/lang-ug-purple.svg)] (readme.ug.md)  
[! [Uz] (https://img.shield.sides/lang-uz-Urange.svg)] (readme.uz.md)  
[! [VI] (https://img.shield.sio/badge/lang-vi-vi-vi) (readme.vi.vi)  
[! [CY] (https://img.shield.sio/badge/lang-Cy-Blue.svg)] (Readme.md)

[! [XH] (https://img.shield.sio/badge/lang-xh-red.svg)] (readme.xm)  
[! [Yi] (https://img.shield.sio/badge/lang-yi-purple.svg)] (readme.yi.md)  
[! [YO] (https://img.shield.sio/badge/lang-yvo.yvg)] (LEADME.YO.YO.MD)  
[! [Zu] (https://img.shield.side/lang-zu-gu-Green] (LEABME.ZU.MD)

---

## 📖 Panoramica

** Pyhelper ** hè un toolkit pitone versatile per simplificà ** analisi di dati, visualizazione, e operazioni statistiche, è di travagliu di utilità **.  
Integrava senza cascà in a ricerca accademica, di ricerca è prughjetti prufessiunali, chì permettica di scopi nantu à l'insoli piuttostu cà di codice di calverali.

Vantaghji chjave:
- 🧮 Statistiche di e Custruita **
- 📊 E facili à usu ** I Wrappers Visualizazione di Dati **
- 🗂 Handy ** File Handling è Ricerca **
- 🔍 ** Sytax Validazione ** per i fugliali Python
- 🌍 ** Supportu multi-lingua ** cù traduzzioni pronta à uss
- 🚀 ottimizatu per ** Prototifazione Fast ** è ** scopi educativi **

---

## ✨ caratteristiche

### 📊 Visualizazione di dati
- Grafici di barri orizontali è verticali (`hbar`,` vbar`)
- Grafici di Pie (`pie`)
- Porte di scatula (`boxplot`)
- Histograms (`histo`)
- Heatmaps (`hootmap`)
- Tavuli di dati (`Table`)
- Viritamenti avanzati (Scatter, Viulinu, KDE, un parolo, etc.)

### 📈 analisi statìtica
- misure di tendenza cintrali:  
  `Get_Media`,` Get_Medeic`, `Get_Moda`
- misure di dispersione:  
  `Get_Rank`,` Get_var`, `Get_Desv`,` Spedite`
- Normalizazione di dati (`normalizà`)
- Deteczione Outlier (iQr & Z-Score)
- trasfurmazioni di dati cundiziunali (`cundiziunali`)

### 🛠 Utilità
- File di scuperta è carica (`Call`)
- Aumentata ** switch / asyncswitch ** sistema
- Sintetta di cuntrollu & analisi (`pythonfilechecker`, 'check_syntax`)
- ERROR RAPPORTI CON CONTEXT
- Sistema d'aiutu integratu (`Aiutu`, Anteprima, Docs)

### 🌍 supportu multi-lingua
- Traduzioni di custruitu * ** 12 lingue ** **
- estendabile cù `caric_user_translazioni ()`
- Selezzione dinamica cun "Set_language (Lang_code)`
- Predefinitu Fallback à l'inglese

---

## 🚀 installazione

Installa da PyPI:

`` `bash
PIP installate Piehelper-Tools-Jbhm
`` ``

---

## 🔧 esempi di usu

### Set Lingua
`` `python
Da l'importazione di l'aiutu Set_language

set_language ("en") # inglese
set_language ("es") #
set_language ("fr") # francese
Set_language ("de") # Tedescu
Set_language ("ru") # russu
Set_language ("tr") # turcu
Set_language ("ZH") # Cinese
set_language ("it") # italiano
set_language ("PT") # portoghese
set_language ("sv") # Svedese
Set_language ("JA") # Giapponese
Set_language ("AR") # Arabic
# ... Supportu per 100+ Lingue
`` ``

### statistiche basiche
`` `python
Import Helper cum'è HP

dati = [1, 2, 2, 2, 3, 4, 5]

Stampa (HP.Get_Media (dati)) # mean
Stampa (HP.GET_MEDIAN (DATI)) # medianu
Stampa (HP.Get_Moda (Dati)) # Modu
`` ``

### visualizazione
`` `python
Import Helper cum'è HP
da Helper.Submodule Import Gra Graph cum'è Gr

df = hp.pd.dataframe ({"values": [5, 3, 7, 2, 9]})
Gr.Histo (DF, "valori", bins = 5, titulu = "histogram" di mostra ")
`` ``

### File Handling
`` `python
Da a chjama d'importazione di l'aiutu

Dati = Chjamate ("My_data", Type = "CSV") # trova è carichi un file csv automaticamente
`` ``

### Traduzioni di persunalità
`` `python
Da Welper Import Shoge_user_Translazioni

# Caricate e traduzzioni personali da lang.json
Caricamentu_user_Translazioni ("Custom / lang.json")
`` ``

---

## 📂 struttura di u prugettu

`` ``
Hegper /
 ├── core.py # funzioni principali
 ├── Lang / # fickes di traduzzione (JSON)
 ├── Sottunies /
 │ ├── Graph.py # funziona di visualizazione
 │ ├── Statisty.py # funziona statìstiche
 │ ├── Utily.Py # Aiutatori di utilità
 └── __init__.Py
`` ``

---

## 🤝 cuntribuisce

Contribuzioni sò Benvenuti!  
Per piacè apre i prublemi, suggerite di migliurà, o sottumette richieste di tirata nantu à u repositariu di u [Github?] (Https://github.com/jbhmdev/pyvelyhelper-dools).

---

## 📜 licenza

Stu prugettu hè licenziatu sottu à u licenza ** mit **.  
Vede u [Licenza] (Licenza) File per i dettagli.

---

⚡ pronta à supercarga u vostru travagliu Python Worklows cù ** pyhelper **? Cumincià à esplurà oghje!