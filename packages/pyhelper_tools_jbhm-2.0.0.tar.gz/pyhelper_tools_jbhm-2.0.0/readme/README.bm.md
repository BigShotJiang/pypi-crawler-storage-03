# Dɛmɛbaga ka gafemarayɔrɔ .

[![License: MIT](https://img.shields.io/badge/license-mit-yellow.svg)](lise)  
[![Pypi](https://img.shields.io/pypi/v/pyhelper-tools-jbhm?style=for-the-badge&label=pypi&color=blue)](https://pypi.org/project/pyhelper-jbhm/)  

## 🌍 Kanw bɛ sɔrɔ .

[![en](https://img.shields.io/badge/lang-en-red.svg)](kalansen.md)  
[![es](https://img.shields.io/badge/lang-es-yellow.svg)](readme.es.md)  
[![fr](https://img.shields.io/badge/lang-fr-blue.svg)](kalansen.fr.md)  
[![de](https://img.shields.io/badge/lang-de-green.svg)](kalansen.de.md)  
[![ru](https://img.shields.io/badge/lang-ru-purple.svg)](kalansen.ru.md)  
[![tr](https://img.shields.io/badge/lang-tr-orange.svg)](kalan.tr.md)  
[![Zh](https://img.shields.io/badge/lang-zh-black.svg)](kalansen.zh.md)  
[![It](https://img.shields.io/badge/lang-it-lightgrey.svg)](kalan.it.md)  
[![Pt](https://img.shields.io/badge/lang-pt-brightgreen.svg)](readme.pt.md)  
[![sv](https://img.shields.io/badge/lang-sv-blue.svg)](kalansen.sv.md)  
[![ja](https://img.shields.io/badge/lang-ja-red.svg)](readme.ja.md)  
[![ar](https://img.shields.io/badge/lang-ar-brown.svg)](kalan.ar.md)  
[![af](https://img.shields.io/badge/lang-af-orange.svg)](kalansen.af.md)  
[![sq](https://img.shields.io/badge/lang-sq-blue.svg)](readme.sq.md)  
[![am](https://img.shields.io/badge/lang-am-green.svg)](kalansen.am.md)  
[![Hy](https://img.shields.io/badge/lang-hy-red.svg)](kalan.HY.MD)  
[![as](https://img.shields.io/badge/lang-as-purple.svg)](readme.as.md)  
[![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme.ay.md)  
[![az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme.az.md)  
[![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](kalansenme.bm.md)  
[![EU](https://img.shields.io/badge/lang-eu-pink.svg)](kalansenme.eu.md)  
[![be](https://img.shields.io/badge/lang-be-darkblue.svg)](kalansen.be.md)  
[![bn](https://img.shields.io/badge/lang-bn-teal.svg)](kalansen.bn.md)  
[![bho](https://img.shields.io/badge/lang-bho-orange.svg)](Readme.bho.md)  
[![BS](https://img.shields.io/badge/lang-bs-purple.svg)](kalansen.bm.md)  
[![bg](https://img.shields.io/badge/lang-bg-green.svg)](kalansenme.bg.md)  
[![ca](https://img.shields.io/badge/lang-ca-yellow.svg)](kalansen.ca.md)  
[![CEB](https://img.shields.io/badge/lang-ceb-blue.svg)](readme.ceb.md)  
[![NY](https://img.shields.io/badge/lang-ny-red.svg)](kalan.ny.md)  
[![co](https://img.shields.io/badge/lang-co-green.svg)](kalan.co.md)  
[![hr](https://img.shields.io/badge/lang-hr-blue.svg)](kalansen.hr.md)  
[![cs](https://img.shields.io/badge/lang-cs-red.svg)](readme.cs.md)  
[![da](https://img.shields.io/badge/lang-da-purple.svg)](kalansen.da.md)  
[![dv](https://img.shields.io/badge/lang-dv-orange.svg)](kalansen.dv.md)  
[![doi](https://img.shields.io/badge/lang-doi-brown.svg)](readme.doi.md)  
[![nl](https://img.shields.io/badge/lang-nl-orange.svg)](kalansen.nl.md)  
[![EO](https://img.shields.io/badge/lang-eo-green.svg)](kalansenme.eo.md)  
[![et](https://img.shields.io/badge/lang-et-blue.svg)](kalansen.et.md)  
[![EE](https://img.shields.io/badge/lang-ee-red.svg)](kalansen.ee.md)  
[![tl](https://img.shields.io/badge/lang-tl-purple.svg)](readme.tl.md)  
[![fi](https://img.shields.io/badge/lang-fi-blue.svg)](kalansen.fi.md)  
[![FY](https://img.shields.io/badge/lang-fy-orange.svg)](kalansen.fy.md)  
[![gl](https://img.shields.io/badge/lang-gl-green.svg)](readme.gl.md)  
[![ka](https://img.shields.io/badge/lang-ka-red.svg)](kalansen.ka.md)  
[![el](https://img.shields.io/badge/lang-el-blue.svg)](kalansen.el.md)  
[![gn](https://img.shields.io/badge/lang-gn-purple.svg)](kalansen.gn.md)  
[![Gu](https://img.shields.io/badge/lang-gu-orange.svg)](kalansen.gu.md)  
[![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme.ht.md)  
[![ha](https://img.shields.io/badge/lang-ha-blue.svg)](kalansen.ha.md)  
[![Haw](https://img.shields.io/badge/lang-haw-red.svg)](kalansen.haw.md)  
[![iw](https://img.shields.io/badge/lang-iw-purple.svg)](kalansen.iw.md)  
[![Hi](https://img.shields.io/badge/lang-hi-orange.svg)](kalansen.hi.md)  
[![hmn](https://img.shields.io/badge/lang-hmn-green.svg)](readme.hmn.md)  
[![HU](https://img.shields.io/badge/lang-hu-blue.svg)](readme.hu.md)  
[![is](https://img.shields.io/badge/lang-is-red.svg)](readme.is.md)  
[![Ig](https://img.shields.io/badge/lang-ig-purple.svg)](readme.ig.md)  
[![ilo](https://img.shields.io/badge/lang-ilo-orange.svg)](readme.ilo.md)  
[![id](https://img.shields.io/badge/lang-id-green.svg)](readme.id.md)  
[![GA](https://img.shields.io/badge/lang-ga-blue.svg)](kalansen.ga.md)  
[![jw](https://img.shields.io/badge/lang-jw-red.svg)](kalansenme.jw.md)  
[![kn](https://img.shields.io/badge/lang-kn-purple.svg)](kalansen.kn.md)  
[![kk](https://img.shields.io/badge/lang-kk-orange.svg)](kalansen.kk.md)

[![km](https://img.shields.io/badge/lang-km-green.svg)](kalansen.km.md)  
[![rw](https://img.shields.io/badge/lang-rw-blue.svg)](kalansen.rw.md)  
[![gom](https://img.shields.io/badge/lang-gom-red.svg)](kalansen.gom.md)  
[![ko](https://img.shields.io/badge/lang-ko-purple.svg)](readme.ko.md)  
[![Kri](https://img.shields.io/badge/lang-kri-orange.svg)](kalansen.kri.md)  
[![Ku](https://img.shields.io/badge/lang-ku-green.svg)](kalan.ku.md)  
[![CKB](https://img.shields.io/badge/lang-ckb-blue.svg)](readme.ckb.md)  
[![Ky](https://img.shields.io/badge/lang-ky-red.svg)](kalan.Ky.ky.md)  
[![Lo](https://img.shields.io/badge/lang-lo-purple.svg)](kalan.lo.md)  
[![La](https://img.shields.io/badge/lang-la-orange.svg)](kalansen.la.md)  
[![lv](https://img.shields.io/badge/lang-lv-green.svg)](kalansen.lv.md)  
[![ln](https://img.shields.io/badge/lang-ln-blue.svg)](readme.ln.md)  
[![lt](https://img.shields.io/badge/lang-lt-red.svg)](readme.lt.md)  
[![lg](https://img.shields.io/badge/lang-lg-purple.svg)](kalansen.lg.md)  
[![lb](https://img.shields.io/badge/lang-lb-orange.svg)](kalan.lb.md)  
[![mk](https://img.shields.io/badge/lang-mk-green.svg)](kalansen.mk.md)  
[![mai](https://img.shields.io/badge/lang-mai-blue.svg)](kalansen.mai.md)  
[![mg](https://img.shields.io/badge/lang-mg-red.svg)](kalansen.mg.md)  
[![Ms](https://img.shields.io/badge/lang-ms-purple.svg.svg)](readme.ms.md)  
[![ml](https://img.shields.io/badge/lang-ml-orange.svg)](kalansen.ml.md)  
[![mt](https://img.shields.io/badge/lang-mt-green.svg)](readme.mt.md)  
[![mi](https://img.shields.io/badge/lang-mi-blue.svg)](kalansen.mi.md)  
[![Mr](https://img.shields.io/badge/lang-mr-red.svg)](kalansen.mr.md)  
[![lus](https://img.shields.io/badge/lang-lus-purple.svg)](readme.lus.md)  
[![mn](https://img.shields.io/badge/lang-mn-orange.svg)](kalansen.mn.md)  
[![ne](https://img.shields.io/badge/lang-my-green.svg)](kalan.My.md)  
[![ne](https://img.shields.io/badge/lang-ne-blue.svg)](readme.ne.md)  
[![ayi](https://img.shields.io/badge/lang-no-red.svg)](kalan.no.md)  
[![Wari](https://img.shields.io/badge/lang-or-purple.svg)](readme.or.md)  
[![OM](https://img.shields.io/badge/lang-om-orange.svg)](readme.om.md)  
[![PS](https://img.shields.io/badge/lang-ps-green.svg)](kalansen.ps.md)  
[![fa](https://img.shields.io/badge/lang-fa-blue.svg)](kalansen.fa.md)  
[![Qu](https://img.shields.io/badge/lang-qu-red.svg)](kalansen.qu.md)  
[![ro](https://img.shields.io/badge/lang-ro-purple.svg.svg)](readme.ro.md)  
[![sm](https://img.shields.io/badge/lang-sm-orange.svg)](readme.sm.md)  
[![sa](https://img.shields.io/badge/lang-sa-green.svg)](kalan.sa.md)  
[![GD](https://img.shields.io/badge/lang-gd-blue.svg)](kalansen.gd.md)  
[![NSO](https://img.shields.io/badge/lang-nso-red.svg)](kalansen.nso.md)  
[![St](https://img.shields.io/badge/lang-st-purple.svg)](kalansen.st.md)  
[![sn](https://img.shields.io/badge/lang-sn-orange.svg)](readme.sn.md)  
[![SD](https://img.shields.io/badge/lang-sd-green.svg)](readme.sd.md)  
[![Si](https://img.shields.io/badge/lang-si-blue.svg)](readme.si.md)  
[![SK](https://img.shields.io/badge/lang-sk-red.svg)](kalansen.sk.md)  
[![sl](https://img.shields.io/badge/lang-sl-purple.svg.svg)](readme.sl.md)  
[![So](https://img.shields.io/badge/lang-so-orange.svg)](kalan.so.md)  
[![Su](https://img.shields.io/badge/lang-su-green.svg)](readme.su.md)  
[![sw](https://img.shields.io/badge/lang-sw-blue.svg)](readme.sw.md)  
[![tg](https://img.shields.io/badge/lang-tg-red.svg)](kalansen.tg.md)  
[![Ta](https://img.shields.io/badge/lang-ta-purple.svg)](readme.ta.md)  
[![TT](https://img.shields.io/badge/lang-tt-orange.svg)](readme.tt.md)  
[![Te](https://img.shields.io/badge/lang-te-green.svg)](readme.te.md)  
[![th](https://img.shields.io/badge/lang-th-blue.svg)](kalan.th.md)  
[![ti](https://img.shields.io/badge/lang-ti-red.svg)](kalan.ti.md)  
[![Ts](https://img.shields.io/badge/lang-ts-purple.svg)](readme.ts.md)  
[![tk](https://img.shields.io/badge/lang-tk-orange.svg)](readme.tk.md)  
[![ak](https://img.shields.io/badge/lang-ak-green.svg)](kalansen.ak.md)  
[![uk](https://img.shields.io/badge/lang-uk-blue.svg)](readme.uk.md)  
[![ur](https://img.shields.io/badge/lang-ur-red.svg)](readme.ur.md)  
[![ug](https://img.shields.io/badge/lang-ug-purple.svg)](kalansen.ug.md)  
[![uz](https://img.shields.io/badge/lang-uz-orange.svg)](Readme.uz.md)  
[![vi](https://img.shields.io/badge/lang-vi-green.svg)](readme.vi.md)  
[![Cy](https://img.shields.io/badge/lang-cy-blue.svg)](readme.cy.md)

[![xh](https://img.shields.io/badge/lang-xh-red.svg)](kalansen.xh.md)  
[![Yi](https://img.shields.io/badge/lang-yi-purple.svg)](readme.yi.md)  
[![Yo](https://img.shields.io/badge/lang-yo-orange.svg)](kalan.Yo.md)  
[![zu](https://img.shields.io/badge/lang-zu-green.svg)](kalansenme.zu.md)

---

## 📖 Lajɛba .

**PyHelper** ye Python baarakɛminɛnw ye minnu bɛ se ka kɛ fɛn caman ye, minnu dilannen don walasa ka **Data sɛgɛsɛgɛli, ɲɛjirali, jateminɛ baarakɛcogo, ani nafama baarakɛcogo nɔgɔya**.  
A bɛ don kalanko, ɲinini, ani baarakɛlaw ka porozɛw la cogo la min tɛ ɲɔgɔn ta, o b’a to i bɛ se ka i sinsin hakilinaw kan sanni ka i sinsin kode boilerplate kan.

Nafa jɔnjɔnw:
- 🧮 A bɛ don a kɔnɔ **Jatew ni jatebɔ nafama**
- 📊 A ka nɔgɔn ka baara kɛ ni **Data Visualization Wrappers ye**
- 🗂 Handy **dosiyɛri baarakɛcogo ani ɲinini**
- 🔍 **Syntax validation** ka ɲɛsin Python filew ma .
- 🌍 **Kan caman dɛmɛni** ni baarakɛcogo labɛnnenw ye .
- 🚀 Optimized for **Fast prototyping** ani **kalan kuntilenna**

---

## ✨ Fɛn minnu bɛ kɛ .

## 📊 Data Visualization .
- bar charts horizontales & vertical (`hbar`, `vbar`) .
- Pie charts (`pie`) .
- Box plots (`boxplot`) .
- Histogrammes (`histo`) .
- Heatmaps (`Sheatmap`) .
- Donanw ka tabali (`Taabolo`) .
- Visualizations avancés (scatter, violon, kde, pairplot, wdfl)

## 📈 Jateminɛw .
- Cɛmancɛla ŋaniya sumanikɛlanw :  
  `get_media`, `get_median`, `get_moda`
- jɛnsɛnni fɛɛrɛw : .  
  `Get_rank`, `get_var`, `Get_Desv`, `Disp`
- Data normalisation (`Normalize`) .
- Outlier detection (IQR & Z-Score fɛɛrɛw) .
- Data changements conditionnels (`conditionnel`) .

## 🛠 utilities .
- File sɔrɔli ani doni (`weleli`) .
- Enhanced **switch / asyncswitch** système .
- Sinsinnanw sɛgɛsɛgɛli & sɛgɛsɛgɛli (`Pythonfilechecker`, `check_syntax`)
- filiw lakali ni kɔnɔkow ye .
- Dɛmɛn sira jɛlen (`dɛmɛ`, ɲɛjiraliw, docs) .

## 🌍 Kan caman dɛmɛni .
- Bamanankan na, bamanankan na, o ye **12 kanw ye**
- A bɛ se ka janya ni `load_user_translations()` ye.
- Sugandili fangama ni `set_language(lang_code)`
- Fallback default ka Angilɛkan .

---

## 🚀 Installation .

Aw bɛ a sigi ka bɔ PYPI la:

```Bash .
Pip installation pyhelper-tools-jbhm .
```

---

## 🔧 Baarakɛcogo misaliw .

### Set kan .
```Python .
ka bɔ dɛmɛbagaw doncogo la set_language .

set_language("en") # Bamanankan
set_language("es") # español .
set_language("fr") # faransikan .
set_language("de") # Alemaɲi .
set_language("ru") # Risila .
set_language("tr") # Turkikan .
set_language("zh") # chinois .
set_language("it") # Italien .
set_language("pt") # portuguese .
set_language("sv") # Suwɛdikan .
set_language("ja") # Japonkan
set_language("ar") # Arabukan .
# ... Dɛmɛ don kan 100+ ma .
```

### Jateminɛ jɔnjɔnw .
```Python .
Aw bɛ dɛmɛ don dɛmɛnan na i n’a fɔ HP .

Donanw = [1, 2, 2, 3, 4, 5].

print(hp.get_media(data)) # kɔrɔ ye .
print(hp.get_median(data)) # median .
print(hp.get_moda(data)) # Mode .
```

### Visualization .
```Python .
Aw bɛ dɛmɛ don dɛmɛnan na i n’a fɔ HP .
ka bɔ dɛmɛbaga.subModules import graphique as gr .

df = hp.pd.dataframe({"nafaw": [5, 3, 7, 2, 9]})
gr.histo(df, "nafaw", bins=5, title="Sample Histogram")
```

### File baarakɛcogo .
```Python .
ka bɔ dɛmɛbagaw ka donko weleli la .

data = call("my_data", type="CSV") # A bɛ CSV file dɔ sɔrɔ ani k'a doni a yɛrɛma .
```

### Bamanankan ni dɔnko bamanankan na .
```Python .
ka bɔ dɛmɛbagaw donli la load_user_translations .

# load ladamu bamanankan na ka bɔ lang.json .
load_user_translations("Lafasali/lang.json")
```

---

## 📂 Porozɛ sigicogo .

```
Dɛmɛbaga/
 ├── core.py # Baarakɛcogo kunbabaw .
 ├── lang/ # Bamanankan bamanankan na (JSON) .
 ├── Submodules/ .
 │ ├── graph.py # yecogo baarakɛcogo .
 │ ├── statics.py # Jateminɛ baarakɛcogo .
 │ ├── utils.py # utilité dɛmɛbagaw .
 └── __init__.py .
```

---

## 🤝 ka dɛmɛ don .

Bolomafaraw bɛ sɔn!  
Aw ye kow da wuli, ka fɛɛrɛw jira, walima ka sama ɲininiw bila [GitHub Repository] kan(https://github.com/jbhmdev/pyhelper-tools).

---

## 📜 License .

Nin poroze in ye lase sɔrɔ **MIT ka lase** kɔnɔ.  
Aw ye [license](license) file lajɛ walasa ka kunnafoni wɛrɛw sɔrɔ.

---

⚡ Labɛn ka supercharge i ka python baarakɛcogo la ni **PyHelper** ye? A daminɛ ka sɛgɛsɛgɛli kɛ bi!