# مكتبة المساعدة

[! [ترخيص: معهد ماساتشوستس للتكنولوجيا] (https://img.shields.io/badge/license-mit-hellow.svg)] (ترخيص)  
[!  

## 🌍 اللغات المتاحة

[!  
[!  
[!  
[! [de] (https://img.shields.io/badge/lang-de-green.svg)]  
[!  
[! [tr] (https://img.shields.io/badge/lang-  
[!  
[!  
[!  
[! [SV] (https://img.shields.io/badge/lang-sv-lue.svg)]  
[!  
[! [AR] (https://img.shields.io/badge/lang-ar-brown.svg)]  
[! [AF] (https://img.shields.io/badge/lang-af-orange.svg)]  
[!  
[! [AM] (https://img.shields.io/badge/lang-am-green.svg)]  
[!  
[! [AS] (https://img.shields.io/badge/lang-as-purple.svg)]  
[! [AY] (https://img.shields.io/badge/lang-ay-brown.svg)]  
[! [AZ] (https://img.shields.io/badge/lang-az-lightblue.svg)]  
[! [BM] (https://img.shields.io/badge/lang-bm-darkgreen.svg)]  
[! [EU] (https://img.shields.io/badge/lang-eu-pink.svg)]  
[!  
[! [bn] (https://img.shields.io/badge/lang-bn-teal.svg)]  
[! [BHO] (https://img.shields.io/badge/lang-bho-orange.svg)]  
[!  
[! [BG] (https://img.shields.io/badge/lang-bg-green.svg)]  
[! [CA] (https://img.shields.io/badge/lang-ca-hellow.svg)]  
[!  
[!  
[! [CO] (https://img.shields.io/badge/lang-co-green.svg)]  
[!  
[! [CS] (https://img.shields.io/badge/lang-cs-dred.svg)]  
[! [DA] (https://img.shields.io/badge/lang-da-purple.svg)]  
[! [DV] (https://img.shields.io/badge/lang-dv-orange.svg)]  
[! [doi] (https://img.shields.io/badge/lang-doi-brown.svg)]  
[! [NL] (https://img.shields.io/badge/lang-nl-orange.svg)]  
[!  
[!  
[!  
[! [TL] (https://img.shields.io/badge/lang-tl-purple.svg)]  
[!  
[! [FY] (https://img.shields.io/badge/lang-fy-orange.svg)]  
[! [GL] (https://img.shields.io/badge/lang-gl-green.svg)]  
[!  
[!  
[! [GN] (https://img.shields.io/badge/lang-gn-purple.svg)]  
[! [GU] (https://img.shields.io/badge/lang-gu-orange.svg)]  
[! [ht] (https://img.shields.io/badge/lang-ht-green.svg)]  
[!  
[!  
[! [iw] (https://img.shields.io/badge/lang-iw-purple.svg)]  
[! [مرحبًا] (https://img.shields.io/badge/lang-hi-orange.svg)] (readme.hi.md)  
[! [HMN] (https://img.shields.io/badge/lang-hmn-green.svg)]  
[!  
[! [IS] (https://img.shields.io/badge/lang-is-dred.svg)]  
[! [IG] (https://img.shields.io/badge/lang-ig-purple.svg)]  
[! [ILO] (https://img.shields.io/badge/lang-ilo-orange.svg)]  
[! [id] (https://img.shields.io/badge/lang-id-green.svg)]  
[!  
[!  
[! [KN] (https://img.shields.io/badge/lang-kn-purple.svg)]  
[! [KK] (https://img.shields.io/badge/lang-kk-orange.svg)]

[! [KM] (https://img.shields.io/badge/lang-km-green.svg)] (readme.km.md)  
[!  
[!  
[! [KO] (https://img.shields.io/badge/lang-ko-purple.svg)]  
[!  
[! [KU] (https://img.shields.io/badge/lang-ku-green.svg)]  
[!  
[! [KY] (https://img.shields.io/badge/lang-ky-dred.svg)] (readme.ky.md)  
[! [lo] (https://img.shields.io/badge/lang-lo-purple.svg)]  
[! [la] (https://img.shields.io/badge/lang-la-orange.svg)]  
[! [LV] (https://img.shields.io/badge/lang-lv-green.svg)]  
[!  
[!  
[! [LG] (https://img.shields.io/badge/lang-lg-purple.svg)]  
[! [lb] (https://img.shields.io/badge/lang-lb-orange.svg)]  
[! [MK] (https://img.shields.io/badge/lang-mk-green.svg)]  
[!  
[!  
[! [MS] (https://img.shields.io/badge/lang-ms-purple.svg)]  
[! [ML] (https://img.shields.io/badge/lang-ml-orange.svg)]  
[! [MT] (https://img.shields.io/badge/lang-mt-green.svg)]  
[! [MI] (https://img.shields.io/badge/lang-mi-blue.svg)]  
[!  
[! [lus] (https://img.shields.io/badge/lang-lus-purple.svg)]  
[! [mn] (https://img.shields.io/badge/lang-mn-orange.svg)]  
[! [my] (https://img.shields.io/badge/lang-my-green.svg)]  
[!  
[!  
[! [أو] (https://img.shields.io/badge/lang-or-purple.svg)]  
[! [om] (https://img.shields.io/badge/lang-om-orange.svg)]  
[! [PS] (https://img.shields.io/badge/lang-ps-green.svg)]  
[!  
[!  
[!  
[! [SM] (https://img.shields.io/badge/lang-sm-orange.svg)]  
[! [SA] (https://img.shields.io/badge/lang-sa-green.svg)]  
[!  
[!  
[! [ST] (https://img.shields.io/badge/lang-st-purple.svg)]  
[! [SN] (https://img.shields.io/badge/lang-sn-orange.svg)]  
[! [SD] (https://img.shields.io/badge/lang-sd-green.svg)]  
[!  
[!  
[! [SL] (https://img.shields.io/badge/lang-sl-purple.svg)]  
[! [SO] (https://img.shields.io/badge/lang-s-orange.svg)]  
[! [su] (https://img.shields.io/badge/lang-su-green.svg)]  
[!  
[!  
[! [TA] (https://img.shields.io/badge/lang-ta-purple.svg)]  
[! [TT] (https://img.shields.io/badge/lang-tt-orange.svg)]  
[! [TE] (https://img.shields.io/badge/lang-te-green.svg)]  
[!  
[!  
[! [TS] (https://img.shields.io/badge/lang-ts-purple.svg)]  
[! [TK] (https://img.shields.io/badge/lang-tk-orange.svg)]  
[! [AK] (https://img.shields.io/badge/lang-ak-green.svg)]  
[! [المملكة المتحدة] (https://img.shields.io/badge/lang-uk-blue.svg)] (readme.uk.md)  
[!  
[! [UG] (https://img.shields.io/badge/lang-ug-purple.svg)]  
[! [UZ] (https://img.shields.io/badge/lang-uz-orange.svg)]  
[! [vi] (https://img.shields.io/badge/lang-vi-green.svg)]  
[!

[!  
[! [yi] (https://img.shields.io/badge/lang-yi-purple.svg)]  
[! [yo] (https://img.shields.io/badge/lang-yo-orange.svg)]  
[! [Zu] (https://img.shields.io/badge/lang-zu-green.svg)]

---

## 📖 نظرة عامة

** Pyhelper ** عبارة عن مجموعة أدوات Python متعددة الاستخدامات مصممة لتبسيط ** تحليل البيانات ، والتصور ، والعمليات الإحصائية ، وسير عمل الأداة المساعدة **.  
إنه يدمج بسلاسة في المشاريع الأكاديمية والبحثية والمهنية ، مما يتيح لك التركيز على الرؤى بدلاً من رمز الغلاية.

المزايا الرئيسية:
- 🧮 مدمجة ** الإحصاءات ومرافق الرياضيات ** **
-📊 سهلة الاستخدام ** مغلفة تصور البيانات **
- 🗂 مفيد ** معالجة الملفات والبحث ** **
- 🔍 ** التحقق من صحة بناء الجملة ** لملفات بيثون
-🌍 ** دعم متعدد اللغات ** مع ترجمات جاهزة للاستخدام
- 🚀 محسن لـ ** النماذج الأولية السريعة ** و ** التعليمية ** **

---

## ✨ الميزات

### 📊 تصور البيانات
- مخططات شريط أفقية ورأسية (`hbar` ،` vbar`)
- مخططات فطيرة ("فطيرة)
- مخططات مربع (`boxplot`)
- الرسوم البيانية (`histo`)
- خرائط الحرارة ("خريطة الحرارة")
- جداول البيانات ("الجدول")
- تصورات متقدمة (مبعثر ، كمان ، KDE ، Pairplot ، إلخ)

### 📈 التحليل الإحصائي
- تدابير الميل المركزي:  
  `get_media` ،` get_median` ، `get_moda`
- تدابير التشتت:  
  `get_rank` ،` get_var` ، `get_desv` ،` disp `
- تطبيع البيانات ("تطبيع")
- الكشف الخارجي (أساليب IQR & Z-Score)
- تحويلات البيانات الشرطية ("مشروطة")

### 🛠 المرافق
- اكتشاف الملفات وتحميلها ("الاتصال")
- نظام التبديل / asyncswitch **
- فحص بناء الجملة وتحليله (`pythonfileChecker` ،` check_syntax`)
- خطأ في الإبلاغ عن السياق
- نظام المساعدة المتكامل ("المساعدة" ، معاينات ، مستندات)

### 🌍 دعم متعدد اللغات
- ترجمات مدمجة لـ ** 12 لغة **
- قابلة للتمديد مع `load_user_translations ()`
- الاختيار الديناميكي مع `set_language (lang_code)`
- الاحتياط الافتراضي للغة الإنجليزية

---

## 🚀 التثبيت

التثبيت من PYPI:

"باش
PIP تثبيت Pyhelper-Tools-JBHM
`` `

---

## 🔧 أمثلة الاستخدام

### تعيين اللغة
"بيثون
من Helper Import Set_language

set_language ("en") # اللغة الإنجليزية
set_language ("ES") # الإسبانية
set_language ("FR") # French
set_language ("DE") # الألمانية
set_language ("RU") # الروسية
set_language ("tr") # التركية
set_language ("ZH") # الصينية
set_language ("it") # الإيطالية
set_language ("Pt") # البرتغالية
set_language ("SV") # السويدية
set_language ("JA") # اليابانية
set_language ("ar") # العربية
# ... دعم أكثر من 100 لغة
`` `

### الإحصاءات الأساسية
"بيثون
مساعد المساعد كـ HP

البيانات = [1 ، 2 ، 2 ، 3 ، 4 ، 5]

طباعة (hp.get_media (البيانات)) # يعني
طباعة (hp.get_median (البيانات)) # الوسيط
طباعة (hp.get_moda (بيانات)) # الوضع
`` `

### التصور
"بيثون
مساعد المساعد كـ HP
من Helper.SubModules استيراد الرسم البياني كـ GR

df = hp.pd.dataframe ({"القيم": [5 ، 3 ، 7 ، 2 ، 9]})
gr.histo (df ، "القيم" ، bins = 5 ، title = "sample the -themrogram")
`` `

### معالجة الملفات
"بيثون
من مكالمة استيراد المساعد

data = call ("my_data" ، type = "csv") # يجد وتحميل ملف CSV تلقائيًا
`` `

### ترجمات مخصصة
"بيثون
من المساعد استيراد load_user_translations

# تحميل ترجمات مخصصة من lang.json
load_user_translations ("custom/lang.json")
`` `

---

## 📂 هيكل المشروع

`` `
المساعد/
 ├ core.py # الوظائف الرئيسية
 ملفات ترجمة Lang/ # Lang (JSON)
 ├ النسيجية الفرعية/
 │ ├ graph.py # وظائف التصور
 │ ├ statics.py # الوظائف الإحصائية
 │ ├ utils.py # مساعدون الأداة المساعدة
 └ __init__.py
`` `

---

## 🤝 المساهمة

المساهمات مرحب بها!  
يرجى فتح المشكلات ، أو اقتراح تحسينات ، أو إرسال طلبات سحب على [github ropository] (https://github.com/jbhmdev/pyhelper-tools).

---

## 📜 الترخيص

هذا المشروع مرخص بموجب ترخيص ** MIT **.  
راجع ملف [الترخيص] (الترخيص) للحصول على التفاصيل.

---

⚡ جاهز لتكريم سير عمل Python الخاص بك مع ** Pyhelper **؟ ابدأ في الاستكشاف اليوم!