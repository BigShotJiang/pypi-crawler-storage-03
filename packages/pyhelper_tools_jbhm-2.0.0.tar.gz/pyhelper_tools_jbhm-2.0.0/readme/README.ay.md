# Yanaptʼir biblioteca .

[![licencia: mit](https://img.shields.io/badge/license-mit-yellow.svg)](licencia) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![pypi](https://img.shields.io/pypi/v/pyhelper-tools-jbhm?style=por-the-Badge&label=pypi&color=azul)](https://pypi.org/Proyecto/Pyhelper-Tools-JBHM/)  

## 🌍 Uñt'at arunaka .

[![en](https://img.shields.io/badge/lang-en-red.svg)](readme.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![es](https://img.shields.io/badge/lang-es-yellow.svg)](readme.es.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![fr](https://img.shields.io/badge/lang-fr-blue.svg)](readme.fr.md) ukax mä jach’a uñacht’äwiwa.  
[![de](https://img.shields.io/badge/lang-de-green.svg)](readme.de.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![Ru](https://img.shields.io/badge/lang-ru-purple.svg)](readme.ru.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![tr](https://img.shields.io/badge/lang-tr-orange.svg)](readme.tr.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![zh](https://img.shields.io/badge/lang-zh-black.svg)](readme.zh.md) ukax mä jach’a uñacht’äwiwa.  
[![ukax](https://img.shields.io/badge/lang-it-lightgrey.svg)](readme.it.md)  
[![PT](https://img.shields.io/badge/lang-pt-brightgreen.svg)](readme.pt.md) ukax mä jach’a uñacht’äwiwa.  
[![sv](https://img.shields.io/badge/lang-sv-blue.svg)](readme.sv.md) ukax mä jach’a uñacht’äwiwa.  
[![JA](https://img.shields.io/badge/lang-ja-red.svg)](readme.ja.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![AR](https://img.shields.io/badge/lang-ar-brown.svg)](readme.ar.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![AF](https://img.shields.io/badge/lang-af-orange.svg)](readme.af.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![sq](https://img.shields.io/badge/lang-sq-blue.svg)](readme.sq.md) ukax mä jach’a uñacht’äwiwa.  
[![am](https://img.shields.io/badge/lang-am-green.svg)](readme.am.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![hy](https://img.shields.io/badge/lang-hy-red.svg)](readme.hy.md) ukax mä jach’a uñacht’äwiwa.  
[![As](https://img.shields.io/badge/lang-as-purple.svg)](readme.as.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![ay](https://img.shields.io/badge/lang-ay-brown.svg)](readme.ay.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![Az](https://img.shields.io/badge/lang-az-lightblue.svg)](readme.az.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![bm](https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme.bm.md) ukax mä jach’a uñacht’äwiwa.  
[![eu](https://img.shields.io/badge/lang-eu-pink.svg)](readme.eu.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![Be](https://img.shields.io/badge/lang-be-darkblue.svg)](readme.be.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![bn](https://img.shields.io/badge/lang-bn-teal.svg)](readme.bn.md) ukax mä jach’a uñacht’äwiwa.  
[![bho](https://img.shields.io/badge/lang-bho-aranja.svg)](readme.bho.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![BS](https://img.shields.io/badge/lang-bs-purple.svg)](readme.bm.md) ukax mä jach’a uñacht’äwiwa.  
[![bg](https://img.shields.io/badge/lang-bg-green.svg)](readme.bg.md) ukax mä jach’a uñacht’äwiwa.  
[![CA](https://img.shields.io/badge/lang-ca-yellow.svg)](readme.ca.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![CEB](https://img.shields.io/badge/lang-ceb-blue.svg)](readme.ceb.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![NY](https://img.shields.io/badge/lang-ny-red.svg)](readme.ny.md) ukax mä jach’a uñacht’äwiwa.  
[![co](https://img.shields.io/badge/lang-co-green.svg)](readme.co.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![hr](https://img.shields.io/badge/lang-hr-blue.svg)](Readme.hr.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![CS](https://img.shields.io/badge/lang-cs-red.svg)](readme.cs.md) ukax mä jach’a uñacht’äwiwa.  
[![DA](https://img.shields.io/badge/lang-da-purple.svg)](readme.da.md) ukax mä jach’a uñacht’äwiwa.  
[![dv](https://img.shields.io/badge/lang-dv-aranja.svg)](readme.dv.md) ukax mä jach’a uñacht’äwiwa.  
[![DOI](https://img.shields.io/badge/lang-doi-brown.svg)](readme.doi.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![nl](https://img.shields.io/badge/lang-nl-aranja.svg)](readme.nl.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![EO](https://img.shields.io/badge/lang-eo-green.svg)](readme.eo.md) ukax mä jach’a uñacht’äwiwa.  
[![et](https://img.shields.io/badge/lang-et-blue.svg)](readme.et.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![ee](https://img.shields.io/badge/lang-ee-red.svg)](readme.ee.e.  
[![tl](https://img.shields.io/badge/lang-tl-purple.svg)](readme.tl.md) ukax mä jach’a uñacht’äwiwa.  
[![Fi](https://img.shields.io/badge/lang-fi-blue.svg)](readme.fi.md) ukax mä jach’a uñacht’äwiwa.  
[![FY](https://img.shields.io/badge/lang-fy-naranja.svg)](readme.fy.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![gl](https://img.shields.io/badge/lang-gl-green.svg)](readme.gl.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![KA](https://img.shields.io/badge/lang-ka-red.svg)](readme.ka.md) ukax mä jach’a uñacht’äwiwa.  
[![el](https://img.shields.io/badge/lang-el-blue.svg)](readme.el.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![gn](https://img.shields.io/badge/lang-gn-purple.svg)](readme.gn.md) ukax mä jach’a uñacht’äwiwa.  
[![GU](https://img.shields.io/badge/lang-gu-orange.svg)](readme.gu.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![ht](https://img.shields.io/badge/lang-ht-green.svg)](readme.ht.md) ukax mä jach’a uñacht’äwiwa.  
[![ha](https://img.shields.io/badge/lang-ha-blue.svg)](readme.ha.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![haw](https://img.shields.io/badge/lang-haw-red.svg)](readme.haw.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![iw](https://img.shields.io/badge/lang-iw-purple.svg)](readme.iw.md) ukax mä jach’a uñacht’äwiwa.  
[![HI](https://img.shields.io/badge/lang-hi-orange.svg)](readme.hi.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![hmn](https://img.shields.io/badge/lang-hmn-green.svg)](readme.hmn.md) ukax mä jach’a uñacht’äwiwa.  
[![hu](https://img.shields.io/badge/lang-hu-blue.svg)](readme.hu.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![is](https://img.shields.io/badge/lang-is-red.svg)](readme.md) ukax mä jach’a uñacht’äwiwa.  
[![IG](https://img.shields.io/badge/lang-ig-purple.svg)](readme.ig.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![ilo](https://img.shields.io/badge/lang-ilo-naranja.svg)](readme.ilo.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![id](https://img.shields.io/badge/lang-id-green.svg)](readme.id.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![GA](https://img.shields.io/badge/lang-ga-blue.svg)](readme.ga.md) ukax mä jach’a uñacht’äwiwa.  
[![jw](https://img.shields.io/badge/lang-jw-red.svg)](readme.jw.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![kn](https://img.shields.io/badge/lang-kn-purple.svg)](readme.kn.md) ukax mä jach’a uñacht’äwiwa.  
[![kk](https://img.shields.io/badge/lang-kk-aranja.svg)](readme.kk.md) ukax mä jach'a uñacht'äwiwa.

[![km](https://img.shields.io/badge/lang-km-green.svg)](readme.km.md) ukax mä jach’a uñacht’äwiwa.  
[![RW](https://img.shields.io/badge/lang-rw-blue.svg)](readme.rw.md) ukax mä jach’a uñacht’äwiwa.  
[![gom](https://img.shields.io/badge/lang-gom-red.svg)](readme.gom.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![KO](https://img.shields.io/badge/lang-ko-purple.svg)](readme.ko.md) ukax mä jach’a uñacht’äwiwa.  
[![kri](https://img.shields.io/badge/lang-kri-aranja.svg)](readme.kri.md) ukax mä jach'a uñacht'äwiwa.  
[![KU](https://img.shields.io/badge/lang-ku-green.svg)](readme.ku.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![CKB](https://img.shields.io/badge/lang-ckb-blue.svg)](readme.ckb.md) ukax mä jach’a uñacht’äwiwa.  
[![KY](https://img.shields.io/badge/lang-ky-red.svg)](readme.ky.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![Lo](https://img.shields.io/badge/lang-lo-purple.svg)](readme.lo.md) ukax mä jach’a uñacht’äwiwa.  
[![La](https://img.shields.io/badge/lang-la-naranja.svg)](readme.la.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![lv](https://img.shields.io/badge/lang-lv-green.svg)](readme.lv.md) ukax mä jach’a uñacht’äwiwa.  
[![ln](https://img.shields.io/badge/lang-ln-blue.svg)](readme.ln.md) ukax mä jach’a uñacht’äwiwa.  
[![lt](https://img.shields.io/badge/lang-lg-red.svg)](readme.lt.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![lg](https://img.shields.io/badge/lang-lg-purple.svg)](readme.lg.md) ukax mä jach’a uñacht’äwiwa.  
[![LB](https://img.shields.io/badge/lang-lang-aranja.svg)](readme.lb.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![mk](https://img.shields.io/badge/lang-mk-green.svg)](readme.mk.md) ukax mä jach’a uñacht’äwiwa.  
[![mai](https://img.shields.io/badge/lang-mai-blue.svg)](readme.mai.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![mg](https://img.shields.io/badge/lang-mg-red.svg)](readme.mg.md) ukax mä jach’a uñacht’äwiwa.  
[![ms](https://img.shields.io/badge/lang-ms-purple.svg)](readme.ms.md) ukax mä jach’a uñacht’äwiwa.  
[![ml](https://img.shields.io/badge/lang-ml-aranja.svg)](readme.ml.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![mt](https://img.shields.io/badge/lang-mt-green.svg)](readme.mt.md) ukax mä jach’a uñacht’äwiwa.  
[![mi](https://img.shields.io/badge/lang-mi-blue.svg)](readme.mi.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![mr](https://img.shields.io/badge/lang-mr-red.svg)](readme.mr.md) ukax mä jach’a uñacht’äwiwa.  
[![LUS](https://img.shields.io/badge/lang-lus-purple.svg)](readme.lus.md) ukax mä jach’a uñacht’äwiwa.  
[![mn](https://img.shields.io/badge/lang-mn-orange.svg)](readme.mn.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![my](https://img.shields.io/badge/lang-my-green.svg)](readme.my.md) ukax mä jach’a uñacht’äwiwa.  
[![Ne](https://img.shields.io/badge/lang-ne-blue.svg)](readme.ne.md) ukax mä jach’a uñacht’äwiwa.  
[![janiwa](https://img.shields.io/badge/lang-no-red.svg)](readme.no.md) ukaxa mä juk’a pachanakwa lurasi.  
[![jan ukax](https://img.shields.io/badge/lang-or-purple.svg)](readme.or.md)  
[![om](https://img.shields.io/badge/lang-om-aranja.svg)](readme.om.md) ukax mä jach'a uñacht'äwiwa.  
[![PS](https://img.shields.io/badge/lang-ps-green.svg)](readme.ps.md) ukax mä jach’a uñacht’äwiwa.  
[![FA](https://img.shields.io/badge/lang-fa-blue.svg)](readme.fa.md) ukax mä jach’a uñacht’äwiwa.  
[![QU](https://img.shields.io/badge/lang-qu-red.svg)](readme.qu.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![ro](https://img.shields.io/badge/lang-ro-purple.svg)](readme.ro.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![sm](https://img.shields.io/badge/lang-sm-aranja.svg)](readme.sm.md) ukax mä jach’a uñacht’äwiwa.  
[![sa](https://img.shields.io/badge/lang-sa-green.svg)](readme.sa.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![GD](https://img.shields.io/badge/lang-gd-blue.svg)](readme.gd.md) ukax mä jach’a uñacht’äwiwa.  
[![nso](https://img.shields.io/badge/lang-nso-red.svg)](readme.nso.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![st](https://img.shields.io/badge/lang-st-purple.svg)](readme.st.md) ukax mä jach’a uñacht’äwiwa.  
[![sn](https://img.shields.io/badge/lang-sn-aranja.svg)](readme.sn.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![sd](https://img.shields.io/badge/lang-sd-green.svg)](readme.sd.md) ukax mä jach’a uñacht’äwiwa.  
[![Si](https://img.shields.io/badge/lang-si-blue.svg)](readme.si.md) ukax mä jach’a uñacht’äwiwa.  
[![SK](https://img.shields.io/badge/lang-sk-red.svg)](readme.sk.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![sl](https://img.shields.io/badge/lang-sl-purple.svg)](readme.sl.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![SO](https://img.shields.io/badge/lang-so-aranja.svg)](readme.so.md) ukax mä jach'a uñacht'äwiwa.  
[![su](https://img.shields.io/badge/lang-su-green.svg)](readme.su.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![sw](https://img.shields.io/badge/lang-sw-blue.svg)](readme.sw.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![tg](https://img.shields.io/badge/lang-tg-red.svg)](readme.tg.md) ukax mä jach’a uñacht’äwiwa.  
[![TA](https://img.shields.io/badge/lang-ta-purple.svg)](readme.ta.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![tt](https://img.shields.io/badge/lang-tt-orange.svg)](readme.tt.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![te](https://img.shields.io/badge/lang-te-green.svg)](readme.te.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![th](https://img.shields.io/badge/lang-th-blue.svg)](readme.th.md) ukax mä jach’a uñacht’äwiwa.  
[![ti](https://img.shields.io/badge/lang-ti-red.svg)](readme.ti.md) ukax mä jach’a uñacht’äwiwa.  
[![TS](https://img.shields.io/badge/lang-ts-purple.svg)](readme.ts.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![tk](https://img.shields.io/badge/lang-tk-orange.svg)](readme.tk.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![ak](https://img.shields.io/badge/lang-ak-green.svg)](readme.ak.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![UK](https://img.shields.io/badge/lang-uk-blue.svg)](readme.uk.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![ur](https://img.shields.io/badge/lang-ur-red.svg)](readme.ur.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![UG](https://img.shields.io/badge/lang-ug-purple.svg)](readme.g.md) ukax mä jach'a uñacht'äwiwa.  
[![Uz](https://img.shields.io/badge/lang-uz-aranja.svg)](readme.uz.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.  
[![vi](https://img.shields.io/badge/lang-vi-green.svg)](readme.vi.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![cy](https://img.shields.io/badge/lang-cy-blue.svg)](readme.cy.md) ukax mä jach’a uñacht’äwiwa.

[![xh](https://img.shields.io/badge/lang-xh-red.svg)](readme.xh.md) ukax mä jach’a uñacht’äwiwa.  
[![yi](https://img.shields.io/badge/lang-yi-purple.svg)](readme.yi.md) ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.  
[![Yo](https://img.shields.io/badge/lang-yo-orange.svg)](readme.yo.md) ukax mä jach’a uñacht’äwiwa.  
[![Zu](https://img.shields.io/badge/lang-zu-green.svg)](readme.zu.md) ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.

--- .

## 📖 Jisk'a t'aqa

**Pyhelper** ukax mä versatil Python Toolkit ukawa, ukax **Data Análisis, Visualización, Operaciones Estadísticas ukat Flujos de Trabajo de Utilidad** ukanakar simplificañatakiw lurata.  
Ukax proyectos académicos, investigaciones ukat profesionales ukanakaruw jan kuna jan walt’awimp mayacht’i, ukax código de calderato ukar uñtasit amuyunakaruw uñt’ayi.

Jach’a ventaja: 1.1.
- 🧮 Incorporado **Estadísticas ukat utilidades de matemáticas**
- 📊 Jasaki apnaqañataki **Data Visualización envolturas**
- 🗂 Handy **Archivo apnaqaña ukat thaqhaña**
- 🔍 **SyNTAX Validation** ukax Python ukan qillqatanakapawa.
- 🌍 **Multi-lenguage yanapt’awi** Jaqukipäwinak wakicht’at jaqukipäwinakampi
- 🚀 optimizado para **FAST prototipos** ukat **educativo uka amtanaka***

--- .

## ✨ Uñacht'äwinaka .

### 📊 Datos ukan uñacht'äwipa .
- Horizontal & vertical barra chartanaka (`hbar`, `vbar`) .
- Uka ch’akhanakaxa (`pie`) .
- Uka chimpuxa (`Boxplot`) .
- Histogramas (`histo`) ukaxa mä juk’a pachanakwa lurasi.
- Hotras (`Mapa de calor`) ukaxa mä juk’a pachanakwa lurasi.
- Datos tablas (`Tabla`) ukaxa 1.1.
- Avanzado visualizaciones (escador, violín, kde, parplot, ukat juk’ampinaka)

### 📈 Análisis estadístico ukax 1.1.
- Medidas de tendencia central ukaxa: 1.1.  
  `get_media`, `get_median`, `get_moda`
- Medidas de dispersión ukaxa: 1.1.  
  `get_rank`, `get_var`, `get_desv`, `disp`
- Normalización de datos (`normaliza`) ukaxa mä juk’a pachanakwa lurasi.
- Outlier uñt’aña (IQR & Z-puntuación uñakipaña) .
- Transformaciones de datos condicionales (`Condicional`) ukaxa mä juk’a pachanakwa lurasi.

### 🛠 Utilidades ukax 1.1.
- Archivo jikxataña ukat carga (`Call`) .
- Enhanced **Switch / Asyncswitch** Sistema ukaxa mä juk’a pachanakwa lurasi.
- Sintaxis uñakipaña & uñakipaña (`PythonFilechecker`, `check_syntax`)
- Pantjasiwi yatiyawixa contexto ukampiwa .
- Sistema integrado de ayuda (`yanapt’awi`, nayrïr uñtawi, docs)

### 🌍 Walja arunakan yanapt'awinakapa .
- **12 arunaka** uka arunakax akham sañ muni.
- Extendible ukaxa `Load_user_translations()` ukampi luratawa.
- Dinámico ajlliwixa `set_lenguage(lang_código)` ukampi luratawa.
- Default fallback ukax inglés arut uñt’atawa.

--- .

## 🚀 Instalación ukax mä jach'a uñacht'äwiwa.

PYPI ukan uñt’ayata:

```Bash .
Pip Instalación Pyhelper-tools-jbhm ukaxa mä juk’a pachanakwa lurasi.
```.

--- .

## 🔧 Uñacht'äwinaka .

### set aru .
```Python ukax 1.0.
Yanapt’iri importado set_lenguage .

set_lenguage("en") # Inglés Ukax mä jach'a uñacht'äwiwa.
set_lenguage("es") # español ukax mä jach'a uñacht'äwiwa.
set_lenguage("fr") # Francés ukax mä jach'a uñacht'äwiwa.
set_lenguage("de") # alemán ukax mä jach'a uñacht'äwiwa.
set_lenguage("ru") # ruso ukax mä jach'a uñacht'äwiwa.
set_lenguage("tr") # turco ukax mä jach'a uñacht'äwiwa.
set_lenguage("zh") # chino ukax mä jach'a uñacht'äwiwa.
set_lenguage("it") # italiano ukax mä jach'a uñacht'äwiwa.
set_lenguage("pt") # portugués ukax mä jach'a uñacht'äwiwa.
set_lenguage("sv") # sueco ukax mä jach'a uñacht'äwiwa.
set_lenguage("ja") # japonés ukax mä jach'a uñacht'äwiwa.
set_lenguage("AR") # árabe .
# ... 100+ arunakar yanapt'aña .
```.

### Estadísticas básicas ukax 1.1.
```Python ukax 1.0.
Importar Yanapt’iri ukhama HP .

Datos = [1, 2, 2, 3, 4, 5] ukat juk’ampinaka.

imprimir(hp.get_media(datos)) # ukax sañ muniwa.
Imprimir(hp.get_mediana(datos)) # Ukax mä jach’a uñacht’äwiwa.
Imprimir(hp.get_moda(datos)) # ukax mä modalidad ukhamawa.
```.

### Visualización ukax mä jach'a uñacht'äwiwa.
```Python ukax 1.0.
Importar Yanapt’iri ukhama HP .
From Helper.Submódulos Importación gráfico como GR .

df = hp.pd.dataframe({"valors": [5, 3, 7, 2, 9]}) Ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa, ukax mä jach’a uñacht’äwiwa.
Gr.Histo(DF, "valores", bins=5, título="sample histogram") ukax mä jach'a uñacht'äwiwa, ukax mä jach'a uñacht'äwiwa.
```.

### archiw apnaqaña .
```Python ukax 1.0.
Yanapt’iri Importación jawsaña .

Datos = jawsaña("my_data", type="csv") # Mä CSV qillqata jikxataña ukat apkataña.
```.

### costumbre jaqukipäwinaka .
```Python ukax 1.0.
Yanapt’iri importar carga_user_translations .

# Lang.json ukan qillqt'at jaqukipäwinakat qillqt'aña.
load_user_translations("Custom/Lang.json") ukax mä jach'a uñacht'äwiwa.
```.

--- .

## 📂 Proyecto ukan estructurapa .

```.
Yanapt’iri/ .
 ├── Core.py # Jilïr lurawi .
 ├── Lang/ # Jaqukipaña archivonaka (JSON)
 ├── Submódulos/ .
 │ ├── gráfico.py # Uñacht’ayaña lurawi .
 │ ├── statics.py # funciones estadísticas ukaxa 1.1.
 │ ├── Utils.py # Utilidad Yanapt'irinaka
 └── __init__.py ukax mä jach'a uñacht'äwiwa.
```.

--- .

## 🤝 ukax yanapt'iwa.

¡Aportaciones ukax wali askiwa!  
Jisk’a jan walt’awinak jist’arañamawa, askichawinak amuyt’ayañamawa, jan ukax [Github Repository](https://github.com/jbhmdev/pyhelper-tools) ukan mayiwinakap uñt’ayañamawa.

--- .

## 📜 licencia .

Aka proyectox **MIT Licencia** ukan licenciat uñt’ayatawa.  
Uñakipt’añatakix [licencia](licencia) qillqataw uñakipt’añama.

--- .

⚡ ¿Python ukan irnaqañanakax **Pyhelper** ukamp supercarga ukar wakicht’atäpachati? ¡Jichhüruw yatxatañ qalltañama!