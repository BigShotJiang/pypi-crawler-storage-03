# हेल्पर लाइब्रेरी के बा।

[![लाइसेंस: एमआईटी] (https://img.shields.io/badge/license-mit-yellow.svg)] (लाइसेंस)  
[![pypi] (https://img.shields.io/pypi/v/pyhelper-tools-jbhm?style=for-the-badge&label=pypi&coler=blue)] (https://pypi.org/ppylypl-tools-jbhm/)  

## 🌍 उपलब्ध भाषा के बारे में जानकारी दिहल गइल बा।

[![en](https://img.shields.io/badge/lang-en-red.svg)](readme.md)  
[![es] (https://img.shields.io/badge/lang-es-yellow.svg)](readme.es.md)  
[![fr] (https://img.shields.io/badge/lang-fr-blue.svg)](readme.fr.md)  
[![de](https://img.shields.io/badge/lang-de-green.svg)](readme.de.md)  
[![RU] (https://img.shields.io/badge/lang-ru-purple.svg)](readme.ru.md)  
[![TR] (https://img.shields.io/badge/lang-tr-orange.svg)](readme.tr.md)  
[![ZH] (https://img.shields.io/badge/lang-zh-black.svg)](readme.zh.md)  
[![इट] (https://img.shields.io/badge/lang-it-lightsgre.svg)](readme.it.md)  
[![pt] (https://img.shields.io/badge/lang-pt-brightgreen.svg)](readme.pt.md)  
[![SV] (https://img.shields.io/badge/lang-sv-blue.svg)](readme.sv.md)  
[![ja] (https://img.shields.io/badge/lang-ja-red.svg)](readme.ja.md)  
[![एआर] (https://img.shields.io/badge/lang-ar-brown.svg)](readme.ar.md)  
[![af] (https://img.shields.io/badge/lang-af-orange.svg)](readme.af.md)  
[![sq] (https://img.shields.io/badge/lang-sq-blue.svg)](readme.sq.md)  
[![am](https://img.shields.io/badge/lang-am-green.svg)](readme.am.md)  
[![HI] (https://img.shields.io/badge/lang-hy-red.svg)](readme.hy.md)  
[![As](https://img.shields.io/badge/lang-as-purple.svg)](readme.as.md)  
[![अय](https://img.shields.io/badge/lang-ay-brown.svg)] (रीडम.एय.एमडी)  
[![az] (https://img.shields.io/badge/lang-az-lighblue.svg)](readme.az.md)  
[![BM] (https://img.shields.io/badge/lang-bm-darkgreen.svg)](readme.bm.md)  
[![EU] (https://img.shields.io/badge/lang-eu-pink.svg)] (readme.eu.md)  
[![be] (https://img.shields.io/badge/lang-be-darkblue.svg)](readme.be.md)  
[![bn] (https://img.shields.io/badge/lang-bn-teal.svg)](readme.bn.md)  
[![भो] (https://img.shields.io/badge/lang-bho-orange.svg)](readme.bho.md)  
[![BS] (https://img.shields.io/badge/lang-bs-purple.svg)](readme.bm.md)  
[![BG] (https://img.shields.io/badge/lang-bg-green.svg)] (रीडम.बीजी.एमडी)  
[![CA] (https://img.shields.io/badge/lang-ca-yellow.svg)](readme.ca.md)  
[![CEB] (https://img.shields.io/badge/lang-ceb-blue.svg)](readme.ceb.md)  
[![NY] (https://img.shields.io/badge/lang-ny-red.svg)](readme.ny.md)  
[![को] (https://img.shields.io/badge/lang-co-green.svg)](readme.co.md)  
[![hr] (https://img.shields.io/badge/lang-hr-blue.svg)] (रीडम.एचआर.एमडी)  
[![CS] (https://img.shields.io/badge/lang-cs-red.svg)](readme.cs.md)  
[![दा] (https://img.shields.io/badge/lang-da-purple.svg)](readme.da.md)  
[![DV] (https://img.shields.io/badge/lang-dv-orange.svg)](readme.dv.md)  
[![DOI] (https://img.shields.io/badge/lang-doi-brown.svg)](readme.doi.md)  
[![nl] (https://img.shields.io/badge/lang-nl-orange.svg)](readme.nl.md)  
[![EO] (https://img.shields.io/badge/lang-eo-green.svg)](readme.eo.md)  
[![ET] (https://img.shields.io/badge/lang-et-blue.svg)](readme.et.md)  
[![ईई] (https://img.shields.io/badge/lang-ee-red.svg)](readme.ee.md)  
[![TL] (https://img.shields.io/badge/lang-tl-purple.svg)](readme.tl.md)  
[![fi] (https://img.shields.io/badge/lang-fi-blue.svg)](readme.fi.md)  
[![fy] (https://img.shields.io/badge/lang-fy-orange.svg)] (रीडम.fy.md)  
[![GL] (https://img.shields.io/badge/lang-gl-green.svg)] (readme.gl.md)  
[![ka] (https://img.shields.io/badge/lang-ka-red.svg)](readme.ka.md)  
[![el] (https://img.shields.io/badge/lang-el-blue.svg)](readme.el.md)  
[![GN] (https://img.shields.io/badge/lang-gn-purple.svg)](readme.gn.md)  
[![गु] (https://img.shields.io/badge/lang-gu-orange.svg)](readme.gu.md)  
[![ht] (https://img.shields.io/badge/lang-ht-green.svg)](readme.ht.md)  
[![हा](https://img.shields.io/badge/lang-ha-blue.svg)](readme.ha.md)  
[![HAW](https://img.shields.io/badge/lang-how-red.svg)](readme.how.md)  
[![IW] (https://img.shields.io/badge/lang-iw-purple.svg)](readme.iw.md)  
[![HI] (https://img.shields.io/badge/lang-hi-orange.svg)](readme.hi.md)  
[![हमएन] (https://img.shields.io/badge/lang-hmn-green.svg)](readme.hmn.md)  
[![HU](https://img.shields.io/badge/lang-hu-blue.svg)](readme.hu.md)  
[![Is](https://img.shields.io/badge/lang-is-red.svg)](readme.is.md)  
[![IG] (https://img.shields.io/badge/lang-ig-purple.svg)](readme.ig.md)  
[![ILO] (https://img.shields.io/badge/lang-ilo-orange.svg)](readme.ilo.md)  
[![ID] (https://img.shields.io/badge/lang-id-green.svg)](readme.id.md)  
[![GA] (https://img.shields.io/badge/lang-ga-blue.svg)](readme.ga.md)  
[![JW] (https://img.shields.io/badge/lang-jw-red.svg)](readme.jw.md)  
[![kn] (https://img.shields.io/badge/lang-kn-purple.svg)](readme.kn.md)  
[![kk] (https://img.shields.io/badge/lang-kk-orange.svg)](readme.kk.md)

[![km] (https://img.shields.io/badge/lang-km-green.svg)](readme.km.md)  
[![RW] (https://img.shields.io/badge/lang-rw-blue.svg)](readme.rw.md)  
[![गोम] (https://img.shields.io/badge/lang-gom-red.svg)](readme.gom.md)  
[![को] (https://img.shields.io/badge/lang-ko-purple.svg)](readme.ko.md)  
[![KRI] (https://img.shields.io/badge/lang-kri-orange.svg)](readme.kri.md)  
[![कु] (https://img.shields.io/badge/lang-ku-green.svg)](readme.ku.md)  
[![CKB] (https://img.shields.io/badge/lang-ckb-blue.svg)] (readme.ckb.md)  
[![ky] (https://img.shields.io/badge/lang-ky-red.svg)](readme.ky.md)  
[![LO] (https://img.shields.io/badge/lang-lo-purple.svg)](readme.lo.md)  
[![ला](https://img.shields.io/badge/lang-la-orange.svg)](readme.la.md)  
[![lv] (https://img.shields.io/badge/lang-lv-green.svg)](readme.lv.md)  
[![ln] (https://img.shields.io/badge/lang-ln-blue.svg)](readme.ln.md)  
[![lt] (https://img.shields.io/badge/lang-lt-red.svg)](readme.lt.md)  
[![lg] (https://img.shields.io/badge/lang-lg-purple.svg)](readme.lg.md)  
[![lb] (https://img.shields.io/badge/lang-lb-orange.svg)] (रीडम.एलबी.एमडी)  
[![MK] (https://img.shields.io/badge/lang-mk-green.svg)](readme.mk.md)  
[![mai] (https://img.shields.io/badge/lang-mai-blue.svg)](readme.mai.md)  
[![mg] (https://img.shields.io/badge/lang-mg-red.svg)] (readme.mg.md)  
[![ms] (https://img.shields.io/badge/lang-ms-purple.svg)](readme.ms.md)  
[![ml] (https://img.shields.io/badge/lang-ml-orange.svg)] (readme.ml.md)  
[![mt] (https://img.shields.io/badge/lang-mt-green.svg)](readme.mt.md)  
[![MI](https://img.shields.io/badge/lang-mi-blue.svg)](readme.mi.md)  
[![MR] (https://img.shields.io/badge/lang-mr-red.svg)] (रीडम.एमआर.एमडी)  
[![लस] (https://img.shields.io/badge/lang-lus-purple.svg)](readme.lus.md)  
[![mn] (https://img.shields.io/badge/lang-mn-orange.svg)] (readme.mn.md)  
[![हमार](https://img.shields.io/badge/lang-my-green.svg)](readme.my.md)  
[![NE](https://img.shields.io/badge/lang-ne-blue.svg)](readme.ne.md)  
[![ना] (https://img.shields.io/badge/lang-no-red.svg)](readme.no.md)  
[![या] (https://img.shields.io/badge/lang-or-purple.svg)](readme.or.md)  
[![OM](https://img.shields.io/badge/lang-om-orange.svg)] (रीडम.ओएम.एमडी)  
[![PS] (https://img.shields.io/badge/lang-ps-green.svg)](readme.ps.md)  
[![FA] (https://img.shields.io/badge/lang-fa-blue.svg)](readme.fa.md)  
[![qu] (https://img.shields.io/badge/lang-qu-red.svg)](readme.qu.md)  
[![रो] (https://img.shields.io/badge/lang-ro-purple.svg)](readme.ro.md)  
[![SM] (https://img.shields.io/badge/lang-sm-orange.svg)](readme.sm.md)  
[![Sa] (https://img.shields.io/badge/lang-sa-green.svg)](readme.sa.md)  
[![GD] (https://img.shields.io/badge/lang-gd-blue.svg)](readme.gd.md)  
[![NSO] (https://img.shields.io/badge/lang-nso-red.svg)](readme.nso.md)  
[![st] (https://img.shields.io/badge/lang-st-purple.svg)] (readme.st.md)  
[![SN] (https://img.shields.io/badge/lang-sn-orange.svg)](readme.sn.md)  
[![SD] (https://img.shields.io/badge/lang-sd-green.svg)](readme.sd.md)  
[![SI] (https://img.shields.io/badge/lang-si-blue.svg)](readme.si.md)  
[![SK] (https://img.shields.io/badge/lang-sk-red.svg)](readme.sk.md)  
[![SL] (https://img.shields.io/badge/lang-sl-purple.svg)](readme.sl.md)  
[![so](https://img.shields.io/badge/lang-so-orange.svg)] (रीडम.सो.एमडी)  
[![SU] (https://img.shields.io/badge/lang-su-green.svg)] (रीडम.सु.एमडी)  
[![SW] (https://img.shields.io/badge/lang-sw-blue.svg)](readme.sw.md)  
[![tg] (https://img.shields.io/badge/lang-tg-red.svg)](readme.tg.md)  
[![TA] (https://img.shields.io/badge/lang-ta-purple.svg)](readme.ta.md)  
[![TT] (https://img.shields.io/badge/lang-tt-orange.svg)](readme.tt.md)  
[![te] (https://img.shields.io/badge/lang-te-green.svg)] (readme.te.md)  
[![Th] (https://img.shields.io/badge/lang-th-blue.svg)](readme.th.md)  
[![ti] (https://img.shields.io/badge/lang-ti-red.svg)](readme.ti.md)  
[![TS] (https://img.shields.io/badge/lang-ts-purple.svg)](readme.ts.md)  
[![tk] (https://img.shields.io/badge/lang-tk-orange.svg)](readme.tk.md)  
[![AK] (https://img.shields.io/badge/lang-ak-green.svg)] (readme.ak.md)  
[![यूके] (https://img.shields.io/badge/lang-uk-blue.svg)] (readme.uk.md)  
[![ur](https://img.shields.io/badge/lang-ur-red.svg)](readme.ur.md)  
[![UG](https://img.shields.io/badge/lang-ug-purple.svg)](readme.ug.md)  
[![उज] (https://img.shields.io/badge/lang-uz-orange.svg)](readme.uz.md)  
[![vi] (https://img.shields.io/badge/lang-vi-green.svg)](readme.vi.md)  
[![cy] (https://img.shields.io/badge/lang-cy-blue.svg)] (रीडम.सी.

[![xh] (https://img.shields.io/badge/lang-xh-red.svg)](readme.xh.md)  
[![yi](https://img.shields.io/badge/lang-yi-purple.svg)](readme.yi.md)  
[![yo] (https://img.shields.io/badge/lang-yo-orange.svg)](readme.yo.md)  
[![zu] (https://img.shields.io/badge/lang-zu-green.svg)](readme.zu.md)

--- 1999 के बा।

## 📖 के बारे में जानकारी दिहल गइल बा।

**पाइहेल्पर** एगो बहुमुखी पायथन टूलकिट ह जवन **डेटा विश्लेषण, विजुअलाइजेशन, सांख्यिकीय संचालन, आ उपयोगिता कार्यप्रवाह** के सरल बनावे खातिर बनावल गइल बा.  
ई अकादमिक, शोध, आ प्रोफेशनल प्रोजेक्ट सभ में सहजता से एकीकरण करे ला, जेह से रउआँ के बॉयलरप्लेट कोड के बजाय अंतर्दृष्टि पर फोकस कइल जा सके ला।

प्रमुख फायदा बा:
- 🧮 बिल्ट-इन **आँकड़े और गणित उपयोगिता**
- 📊 के उपयोग में आसान **डेटा विजुअलाइजेशन रैपर**
- 🗂 सुलभ **फाइल हैंडलिंग अउर खोज**
- 🔍 **सिंटैक्स वैलिडेशन** पायथन फाइल खातिर
- 🌍 **मल्टी-लैंग्वेज सपोर्ट** रेडी-टू-यूज अनुवाद के साथ
- 🚀 **फास्ट प्रोटोटाइपिंग** आ **शिक्षा के उद्देश्य से अनुकूलित**

--- 1999 के बा।

## ✨ फीचर बा .

### 📊 डेटा विजुअलाइजेशन के बारे में जानकारी दिहल गइल बा।
- क्षैतिज अउर ऊर्ध्वाधर बार चार्ट (`HBAR`, `vbar`)
- पाई चार्ट (`पाई`) के बा।
- बॉक्स प्लॉट (`बॉक्सप्लॉट`) के बा।
- हिस्टोग्राम (`हिस्टो`) के बा।
- हीटमैप (`हीटमैप`) के बा।
- डेटा टेबल (`टेबल`) के बा।
- उन्नत विजुअलाइजेशन (बिखरल, वायलिन, केडीई, जोड़ीप्लॉट, आदि)

### 📈 सांख्यिकीय विश्लेषण के बा
- केंद्रीय प्रवृत्ति के मापदंड: 1।  
  `get_media`, `get_मीडियन`, `get_moda`
- फैलाव के मापदंड: 1।  
  `get_rank`, `get_var`, `get_desv`, `डिस्प`
- डेटा सामान्यीकरण (`सामान्य`)
- आउटलइयर डिटेक्शन (आईक्यूआर एंड जेड-स्कोर विधि)
- सशर्त डेटा रूपांतरण (`सशर्त`) के बा।

### 🛠 उपयोगिता के बारे में जानकारी दिहल गइल बा।
- फाइल के खोज आ लोड हो रहल बा (`कॉल`)
- बढ़ावल **स्विच / एसिंकस्विच** सिस्टम
- वाक्य रचना के जांच आ विश्लेषण (`पाइथॉनफाइलचेकर`, `चेक_सिंटैक्स`)
- संदर्भ के साथ त्रुटि रिपोर्टिंग के बा
- एकीकृत मदद प्रणाली (`मदद`, पूर्वावलोकन, डॉक्स)

### 🌍 बहु-भाषा के समर्थन बा
- **12 भाषा के लिए बिल्ट-इन अनुवाद**
- `load_user_translations()` के साथ विस्तारित बा।
- `set_language (लैंग_कोड)` के साथ गतिशील चयन बा।
- अंग्रेजी में डिफ़ॉल्ट फॉलबैक बा

--- 1999 के बा।

## 🚀 इंस्टॉलेशन के बा

PYPI से इंस्टॉल करीं:

```बैश 1999 के बा।
पिप इंस्टॉल करीं पाइहेलर-टूल्स-जेबीएचएम
``` के बा .

--- 1999 के बा।

## 🔧 प्रयोग के उदाहरण बा

### भाषा सेट करे के बा .
```पाइथन के बा .
से हेल्पर आयात set_language

set_language("en") # भोजपुरी
set_language("es") # स्पेनिश के बा।
set_language("fr") # फ्रेंच 2019 के बा।
set_language("de") # जर्मन के बा।
set_language("ru") # रूसी के बा।
set_language("tr") # तुर्की के बा।
set_language("zh") # चीनी बा।
set_language("it") # इटैलियन
set_language("pt") # पुर्तगाली 1999 के बा।
set_language("sv") # स्वीडिश के बा।
set_language("ja") # जापानी बा।
set_language("ar") # अरबी के बा।
# ... 100+ भाषा के समर्थन
``` के बा .

### मूलभूत आँकड़ा बा .
```पाइथन के बा .
एचपी के रूप में इम्पोर्ट हेल्पर के बा

डेटा = [1, 2, 2, 3, 4, 5] के बा।

print(hp.get_media (डेटा)) # के मतलब बा।
print(hp.get_मीडियन (डेटा)) # मीडियन बा।
प्रिंट (एचपी.गेट_मोडा (डेटा)) # मोड बा।
``` के बा .

### विजुअलाइजेशन के बारे में बतावल गइल बा।
```पाइथन के बा .
एचपी के रूप में इम्पोर्ट हेल्पर के बा
helper.submodules से ग्राफ के जीआर के रूप में आयात करीं

df = hp.pd.dataframe ({"मान": [5, 3, 7, 2, 9]})
gr.histo(df, "मूल्य", bins=5, title="नमूना हिस्टोग्राम")
``` के बा .

### फाइल हैंडलिंग के बा
```पाइथन के बा .
से हेल्पर आयात कॉल 2019 के बा।

data = call("my_data", type="csv") # एगो CSV फाइल के स्वचालित रूप से खोज के लोड करे ला
``` के बा .

### # कस्टम अनुवाद के बारे में जानकारी दिहल गइल बा।
```पाइथन के बा .
हेल्पर से load_user_translations के आयात करीं

# lang.json से कस्टम अनुवाद लोड करीं
load_user_translations("कस्टम/लैंग.जेसन") के बा।
``` के बा .

--- 1999 के बा।

## 📂 परियोजना के संरचना के बारे में जानकारी दिहल गइल बा।

``` के बा .
सहायक/ के बा।
 ├── core.py # मुख्य कार्य बा।
 ├── लैंग/ # अनुवाद फाइल (json)
 ├── सबमॉड्यूल/ के बा।
 │ ├── ग्राफ.पीवाई # विजुअलाइजेशन फंक्शन बा।
 │ ├── statics.py # सांख्यिकीय कार्य
 │ ├── Utils.py # उपयोगिता सहायक
 └── __init__.py के बा।
``` के बा .

--- 1999 के बा।

## 🤝 योगदान देवे वाला बा

योगदान के स्वागत बा!  
कृपया मुद्दा खोलीं, सुधार के सुझाव दीं, भा [गिथब रिपोजिटरी](https://github.com/jbhmdev/pyhelper-tools) पर पुल अनुरोध जमा करीं।

--- 1999 के बा।

## 📜 लाइसेंस बा

ई प्रोजेक्ट **एमआईटी लाइसेंस** के तहत लाइसेंस प्राप्त बा।  
विस्तार से जाने खातिर [लाइसेंस](लाइसेंस) फाइल देखल जाव।

--- 1999 के बा।

⚡ **पाइहेलर** के साथ आपन पायथन वर्कफ़्लो के सुपरचार्ज करे खातिर तैयार बा? आज ही खोजल शुरू करीं!