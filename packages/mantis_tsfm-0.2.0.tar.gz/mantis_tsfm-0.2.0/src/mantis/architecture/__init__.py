"""Init file for architecture.""" 

from .architecture import Mantis8M


__all__ = ['Mantis8M']
