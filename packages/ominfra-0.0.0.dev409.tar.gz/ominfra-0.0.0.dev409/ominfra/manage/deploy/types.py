import typing as ta


##


DeployHome = ta.NewType('DeployHome', str)

DeployRev = ta.NewType('DeployRev', str)
