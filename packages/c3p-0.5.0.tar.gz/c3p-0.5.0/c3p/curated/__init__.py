from pathlib import Path

CURATED_PATH = Path(__file__).parent