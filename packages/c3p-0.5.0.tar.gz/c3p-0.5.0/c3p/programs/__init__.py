from pathlib import Path

PROGRAM_DIR = Path(__file__).parent