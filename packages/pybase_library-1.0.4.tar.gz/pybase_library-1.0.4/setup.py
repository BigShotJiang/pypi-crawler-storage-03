from setuptools import find_packages, setup

setup(
    name="pybase_library",
    version="1.0.4",    
    packages=find_packages(),
    install_requires=[],
    author="thinhnt3",
    description="Python based library",
    python_requires=">=3.11",
)
