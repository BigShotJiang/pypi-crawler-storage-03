# This file is part of Jaxley, a differentiable neuroscience simulator. Jaxley is
# licensed under the Apache License Version 2.0, see <https://www.apache.org/licenses/>

# This folder checks whether the new version of the code produces **exactly** the same
# simulation results as previous versions.
