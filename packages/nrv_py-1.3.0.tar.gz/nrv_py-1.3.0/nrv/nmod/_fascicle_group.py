from ..utils.geom._popshape import PopShape


class fascicle_group(PopShape):
    """
    Instance of an axon population.

    """

    def __init__(self):
        super().__init__()
        raise NotImplementedError("fascicle_group is not yet implemented")
