"""ctenv - Run programs in containers as current user"""

from .version import __version__

__all__ = ["__version__"]
