from .xgboost import XGBoostPruningCallback


__all__ = [
    "XGBoostPruningCallback",
]
