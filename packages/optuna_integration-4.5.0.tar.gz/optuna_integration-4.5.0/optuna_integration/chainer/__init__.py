from .chainer import ChainerPruningExtension


__all__ = [
    "ChainerPruningExtension",
]
