from .catboost import CatBoostPruningCallback


__all__ = [
    "CatBoostPruningCallback",
]
