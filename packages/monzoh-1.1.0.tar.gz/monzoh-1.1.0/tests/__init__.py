"""Tests for monzoh library."""
