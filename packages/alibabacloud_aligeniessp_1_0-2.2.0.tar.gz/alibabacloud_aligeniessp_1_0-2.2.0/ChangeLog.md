2023-08-23 Version: 2.1.0
- Generated python ssp_1.0 for AliGenie.

2023-06-08 Version: 2.0.1
- Add ScanCodeBind api.

2023-06-02 Version: 2.0.0
- 修改ScgSearch返回结果类型.

2022-10-17 Version: 1.0.14
- Add ScanCodeBind api.

2022-10-08 Version: 1.0.13
- Add EcologyAuthenticate api.

2022-09-08 Version: 1.0.12
- Add scgsearch api.

2022-09-01 Version: 1.0.11
- Add scgsearch api.

2022-08-25 Version: 1.0.10
- Add scgsearch api.

2022-08-22 Version: 1.0.9
- Add scgsearch api.

2022-07-29 Version: 1.0.8
- Add net access api.

2022-04-11 Version: 1.0.7
- List methods result changed.

2021-12-09 Version: 1.0.6
- Init for new api.

2021-11-26 Version: 1.0.5
- Init for new api.

2021-11-24 Version: 1.0.3
- Init for new api.

2021-11-24 Version: 1.0.2
- Init for new api.

2021-09-17 Version: 0.0.2
- Init for new api.

2021-09-16 Version: 0.0.1
- Init for new api.

