:html_theme.sidebar_secondary.remove:

==========
User Guide
==========

In this user guide, you will find tutorials describing and detailing the main components of the `LSAPy` package,
and explaining how they operate together to perform Land Suitability Analysis (LSA).


.. toctree::
   :maxdepth: 2

   functions
   criteria
   lsa
