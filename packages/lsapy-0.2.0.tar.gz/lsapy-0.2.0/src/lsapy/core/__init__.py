"""Core Module."""
