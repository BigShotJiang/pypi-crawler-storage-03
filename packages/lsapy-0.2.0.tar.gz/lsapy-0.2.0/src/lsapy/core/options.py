"""LSAPy Options."""

from __future__ import annotations

OPTIONS = {
    "display_width": 80,
    "display_max_rows": 12,
}

# class set_options:
#     # TODO: Implement context manager for setting options
#     ...
