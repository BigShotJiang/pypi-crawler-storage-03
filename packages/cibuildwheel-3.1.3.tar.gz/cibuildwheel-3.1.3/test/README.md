This folder contains integration tests for cibuildwheel.
