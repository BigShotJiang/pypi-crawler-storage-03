"""
LSTM Estimator for Long-Range Dependence Analysis

This module provides a PyTorch LSTM-based estimator for Hurst parameter estimation.
It integrates with the BaseMLEstimator interface but overrides training and
estimation to support sequence models (train once, apply many).
"""

from typing import Any, Dict, Tuple, Optional
import numpy as np
from .base_ml_estimator import BaseMLEstimator

# Optional torch import to avoid import errors if not installed
try:
    import torch
    from torch import nn
    from torch.utils.data import Dataset, DataLoader
    TORCH_AVAILABLE = True
except Exception:
    TORCH_AVAILABLE = False


if TORCH_AVAILABLE:
    class _SequenceDataset(Dataset):
        def __init__(self, X: np.ndarray, y: np.ndarray):
            # X: (n_samples, seq_len, 1)
            self.X = torch.from_numpy(X.astype(np.float32))
            self.y = torch.from_numpy(y.astype(np.float32)).view(-1, 1)

        def __len__(self) -> int:
            return self.X.shape[0]

        def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
            return self.X[idx], self.y[idx]


if TORCH_AVAILABLE:
    class _LSTMRegressor(nn.Module):
        def __init__(self, input_size: int, hidden_size: int, num_layers: int,
                     dropout: float = 0.0, bidirectional: bool = False):
            super().__init__()
            self.lstm = nn.LSTM(
                input_size=input_size,
                hidden_size=hidden_size,
                num_layers=num_layers,
                dropout=dropout if num_layers > 1 else 0.0,
                batch_first=True,
                bidirectional=bidirectional,
            )
            direction_multiplier = 2 if bidirectional else 1
            self.head = nn.Sequential(
                nn.Linear(hidden_size * direction_multiplier, hidden_size),
                nn.ReLU(),
                nn.Linear(hidden_size, 1),
            )

        def forward(self, x: torch.Tensor) -> torch.Tensor:
            # x: (batch, seq_len, input_size)
            out, (hn, cn) = self.lstm(x)
            # Use last time step output
            last = out[:, -1, :]
            return self.head(last)


# Close the TORCH_AVAILABLE if statement


class LSTMEstimator(BaseMLEstimator):
    """
    LSTM estimator for Hurst parameter estimation using PyTorch.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if not TORCH_AVAILABLE:
            raise ImportError("PyTorch is required for LSTMEstimator. Install with: pip install torch")
        # Defaults
        self.hidden_size = self.parameters.get('hidden_size', 64)
        self.num_layers = self.parameters.get('num_layers', 2)
        self.dropout = self.parameters.get('dropout', 0.1)
        self.bidirectional = self.parameters.get('bidirectional', False)
        self.learning_rate = self.parameters.get('learning_rate', 1e-3)
        self.epochs = self.parameters.get('epochs', 30)
        self.batch_size = self.parameters.get('batch_size', 32)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Internal torch model placeholder (created in train)
        self._torch_model: Optional[nn.Module] = None

    def _validate_parameters(self) -> None:
        # Minimal validation
        if self.parameters.get('feature_extraction_method') not in (None, 'raw', 'statistical', 'spectral', 'wavelet'):
            raise ValueError("Invalid feature_extraction_method")

    def _create_model(self) -> Any:
        # Not used by Base training; sequence model created in train
        return None

    def _prepare_sequences(self, X: np.ndarray, fit_scaler: bool) -> np.ndarray:
        # Ensure shape (n_samples, seq_len)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        # Fit/transform with StandardScaler across sequence positions
        if fit_scaler:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = self.scaler.transform(X)
        # Add channel dim -> (n, seq_len, 1)
        return X_scaled.reshape(X_scaled.shape[0], X_scaled.shape[1], 1)

    def train(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        if not TORCH_AVAILABLE:
            raise ImportError("PyTorch is required for LSTMEstimator. Install with: pip install torch")

        # Use raw sequence; ignore Base feature extraction
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
        import time as _time

        # Prepare sequences and split
        X_seq = self._prepare_sequences(X, fit_scaler=True)
        X_train, X_val, y_train, y_val = train_test_split(
            X_seq, y, test_size=self.test_size, random_state=self.random_state
        )

        # Build dataset and loaders
        train_ds = _SequenceDataset(X_train, y_train)
        val_ds = _SequenceDataset(X_val, y_val)
        train_loader = DataLoader(train_ds, batch_size=self.batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=self.batch_size, shuffle=False)

        # Create model
        input_size = 1
        model = _LSTMRegressor(
            input_size=input_size,
            hidden_size=self.hidden_size,
            num_layers=self.num_layers,
            dropout=self.dropout,
            bidirectional=self.bidirectional,
        ).to(self.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=self.learning_rate)
        criterion = nn.MSELoss()

        start = _time.time()
        model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for xb, yb in train_loader:
                xb = xb.to(self.device)
                yb = yb.to(self.device)
                optimizer.zero_grad()
                preds = model(xb)
                loss = criterion(preds, yb)
                loss.backward()
                optimizer.step()
                epoch_loss += float(loss.item()) * xb.size(0)
            # Optional: simple val pass (not early stopping for brevity)
            _ = epoch_loss / len(train_ds)

        # Evaluate on train/val
        model.eval()
        def _predict(loader):
            outs, gts = [], []
            with torch.no_grad():
                for xb, yb in loader:
                    xb = xb.to(self.device)
                    preds = model(xb).cpu().numpy().reshape(-1)
                    outs.append(preds)
                    gts.append(yb.numpy().reshape(-1))
            return np.concatenate(outs), np.concatenate(gts)

        train_pred, train_gt = _predict(train_loader)
        val_pred, val_gt = _predict(val_loader)

        train_mse = mean_squared_error(train_gt, train_pred)
        test_mse = mean_squared_error(val_gt, val_pred)
        train_mae = mean_absolute_error(train_gt, train_pred)
        test_mae = mean_absolute_error(val_gt, val_pred)
        train_r2 = r2_score(train_gt, train_pred)
        test_r2 = r2_score(val_gt, val_pred)

        # Store
        self._torch_model = model
        self.model = model  # for compatibility with Base
        self.results = {
            'train_mse': train_mse,
            'test_mse': test_mse,
            'train_mae': train_mae,
            'test_mae': test_mae,
            'train_r2': train_r2,
            'test_r2': test_r2,
            'n_features': X_seq.shape[1],
            'n_samples': X_seq.shape[0]
        }
        self.is_trained = True
        return self.results

    def estimate(self, data: np.ndarray) -> Dict[str, Any]:
        if not self.is_trained or self._torch_model is None:
            raise ValueError("Model must be trained before estimation")

        # Prepare single sequence using fitted scaler
        if data.ndim == 1:
            X_seq = self._prepare_sequences(data.reshape(1, -1), fit_scaler=False)
        else:
            X_seq = self._prepare_sequences(data, fit_scaler=False)

        x = torch.from_numpy(X_seq.astype(np.float32)).to(self.device)
        self._torch_model.eval()
        with torch.no_grad():
            pred = self._torch_model(x).cpu().numpy().reshape(-1)
        hurst_estimate = float(pred[0])

        self.results.update({
            'hurst_parameter': hurst_estimate,
            'estimation_method': self.__class__.__name__,
            'feature_extraction_method': 'raw'
        })
        return self.results

    # Override save/load to handle torch state dict alongside metadata
    def save_model(self, filepath: str) -> None:
        if not self.is_trained or self._torch_model is None:
            raise ValueError("Model must be trained before saving")
        import os, joblib, torch
        meta = {
            'scaler': self.scaler,
            'parameters': self.parameters,
            'results': self.results,
            'model_meta': {
                'hidden_size': self.hidden_size,
                'num_layers': self.num_layers,
                'dropout': self.dropout,
                'bidirectional': self.bidirectional,
            }
        }
        joblib.dump(meta, filepath)
        torch.save(self._torch_model.state_dict(), filepath + '.pt')

    def load_model(self, filepath: str) -> None:
        import os, joblib, torch
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
        meta = joblib.load(filepath)
        self.scaler = meta['scaler']
        self.parameters = meta['parameters']
        self.results = meta['results']
        self.hidden_size = meta['model_meta']['hidden_size']
        self.num_layers = meta['model_meta']['num_layers']
        self.dropout = meta['model_meta']['dropout']
        self.bidirectional = meta['model_meta']['bidirectional']

        # Recreate model and load weights
        self._torch_model = _LSTMRegressor(
            input_size=1,
            hidden_size=self.hidden_size,
            num_layers=self.num_layers,
            dropout=self.dropout,
            bidirectional=self.bidirectional,
        )
        state_path = filepath + '.pt'
        if not os.path.exists(state_path):
            raise FileNotFoundError(f"Model weights not found: {state_path}")
        self._torch_model.load_state_dict(torch.load(state_path, map_location='cpu'))
        self.model = self._torch_model
        self.is_trained = True
