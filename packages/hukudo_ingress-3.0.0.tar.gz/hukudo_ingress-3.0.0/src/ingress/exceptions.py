class CaddyError(Exception):
    pass
