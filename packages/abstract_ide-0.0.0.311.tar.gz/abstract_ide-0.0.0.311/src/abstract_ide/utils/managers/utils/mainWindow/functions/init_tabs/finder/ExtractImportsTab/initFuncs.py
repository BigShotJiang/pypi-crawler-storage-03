from .functions import *
def initFuncs(self):
    self.browse_dir = browse_dir
    self.make_params = make_params
    self.start_extract = start_extract
    self.append_log = append_log
    self.display_imports = display_imports
    return self
