# TBD: Optional helper functions: matrix formatting, validation, etc.
def is_square(matrix):
    return matrix.shape[0] == matrix.shape[1]
