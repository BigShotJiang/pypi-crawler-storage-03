## License

`denvr` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

```
--8<-- "LICENSE.txt"
```
