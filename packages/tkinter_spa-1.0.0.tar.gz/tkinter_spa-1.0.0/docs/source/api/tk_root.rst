TkinterApp
==========

.. currentmodule:: tkinter_spa.tk_root

.. autoclass:: TkinterApp()
    :members: