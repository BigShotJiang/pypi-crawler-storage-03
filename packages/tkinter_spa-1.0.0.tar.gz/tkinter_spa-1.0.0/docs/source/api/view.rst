View
====

.. currentmodule:: tkinter_spa.view

.. autoclass:: CallableClass(ABCMeta)

.. autoclass:: View(ABC, metaclass = CallableClass)
    :members: