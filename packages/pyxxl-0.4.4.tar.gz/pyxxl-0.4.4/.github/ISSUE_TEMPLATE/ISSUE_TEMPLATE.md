---
name: New Issue
about: Create a issue to help us improve
title: ''
labels: ''
assignees: ''

---

**Problem description**

详细描述你的问题

**Steps to reproduce the problem**

```python
最好可以附上代码
```


**Specifications like the version of the project, operating system, or hardware**

* XXL-JOB 版本:
* pyxxl 版本:
* python 版本:
* other more:
