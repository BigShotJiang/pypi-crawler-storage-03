import logging

setting_logger = logging.getLogger("pyxxl.setting")
executor_logger = logging.getLogger("pyxxl.executor")
xxl_client_logger = logging.getLogger("pyxxl.xxl_client")
