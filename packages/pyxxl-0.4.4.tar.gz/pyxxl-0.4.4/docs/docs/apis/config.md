# ExecutorConfig

::: pyxxl.ExecutorConfig
