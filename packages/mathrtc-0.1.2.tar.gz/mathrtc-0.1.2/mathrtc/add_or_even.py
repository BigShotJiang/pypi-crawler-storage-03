def addoreven():
  n = int(input("Enter a number: "))
  print("Even" if n % 2 == 0 else "Odd")