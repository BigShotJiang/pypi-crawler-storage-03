from .fact import fact
from .cal import cal
from .main import fib
from .add_or_even import add_or_even