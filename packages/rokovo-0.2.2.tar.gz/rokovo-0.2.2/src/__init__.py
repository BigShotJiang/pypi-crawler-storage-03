__all__ = ["__version__"]

# see: https://semver.org
__version__ = "0.2.2"
