# Projex -  Elegant solution for easy development

---
### With projex you can handle:
- Environment Variable spaces (testing/production/development/etc.)
- Resources (Ram Usage/CPU Usage)
- Run actions (run commands)
- Auto ssh development and sync
- Auto git integration auto commits and auto versioning
- Auto CI/CD integration

#### All just with simple bash commands ;)
