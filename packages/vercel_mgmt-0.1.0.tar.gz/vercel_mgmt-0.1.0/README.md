# vercel-mgmt
Cancel multiple builds right from the terminal
