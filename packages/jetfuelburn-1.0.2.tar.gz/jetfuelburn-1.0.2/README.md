# JetFuelBurn

A Python package for calculating fuel burn of commercial aircraft.