# -*- coding: utf-8 -*-
# @version        : 1.0
# @Update Time    : 2023/8/18 9:00
# @File           : database.py
# @IDE            : PyCharm
# @desc           : SQLAlchemy 部分

from typing import AsyncGenerator, Generator
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker, AsyncAttrs
from sqlalchemy.orm import DeclarativeBase, declared_attr, Session, sessionmaker
from config.environments import get_settings
from fastapi import Request
from core.exception import CustomException
from core.logger import logger
from sqlalchemy import create_engine

# 获取环境配置
env_settings = get_settings()

# 官方文档：https://docs.sqlalchemy.org/en/20/orm/extensions/asyncio.html#sqlalchemy.ext.asyncio.create_async_engine

# database_url  dialect+driver://username:password@host:port/database

# echo：如果为True，引擎将记录所有语句以及它们的参数列表的repr()到默认的日志处理程序，该处理程序默认为sys.stdout。如果设置为字符串"debug"，
# 结果行也将打印到标准输出。Engine的echo属性可以随时修改以打开和关闭日志记录；也可以使用标准的Python logging模块来直接控制日志记录。

# echo_pool=False：如果为True，连接池将记录信息性输出，如何时使连接失效以及何时将连接回收到默认的日志处理程序，该处理程序默认为sys.stdout。
# 如果设置为字符串"debug"，记录将包括池的检出和检入。也可以使用标准的Python logging模块来直接控制日志记录。

# pool_pre_ping：布尔值，如果为True，将启用连接池的"pre-ping"功能，该功能在每次检出时测试连接的活动性。

# pool_recycle=-1：此设置导致池在给定的秒数后重新使用连接。默认为-1，即没有超时。例如，将其设置为3600意味着在一小时后重新使用连接。
# 请注意，特别是MySQL会在检测到连接8小时内没有活动时自动断开连接（尽管可以通过MySQLDB连接自身和服务器配置进行配置）。

# pool_size=5：在连接池内保持打开的连接数。与QueuePool以及SingletonThreadPool一起使用。
# 对于QueuePool，pool_size设置为0表示没有限制；要禁用连接池，请将poolclass设置为NullPool。

# pool_timeout=30：在从池中获取连接之前等待的秒数。仅在QueuePool中使用。这可以是一个浮点数，但受Python时间函数的限制，可能在几十毫秒内不可靠

# max_overflow 参数用于配置连接池中允许的连接 "溢出" 数量。这个参数用于在高负载情况下处理连接请求的峰值。
# 当连接池的所有连接都在使用中时，如果有新的连接请求到达，连接池可以创建额外的连接来满足这些请求，最多创建的数量由 max_overflow 参数决定。
# 新增同步数据库连接
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建同步引擎
sync_engine = create_engine(
    env_settings.SQLALCHEMY_SYNC_URL,  # 使用同步数据库URL
    pool_pre_ping=True,
    pool_recycle=1800,   # 半小时，定期回收连接,防止长时间未使用的连接出现问题
    pool_size=20,        # 初始连接池大小，可以根据实际情况调整
    max_overflow=30,     # 允许额外30个溢出连接，总连接数最多为50
    pool_timeout=60      # 设置超时时间为60秒
)

# 创建同步会话工厂
SyncSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=sync_engine,
    expire_on_commit=False  # 保持对象状态
)

def sync_db_getter() -> Generator[Session, None, None]:
    """同步获取数据库会话"""
    db = SyncSessionLocal()
    try:
        yield db
    except Exception as e:
        db.rollback()
        logger.error(f"Database error: {str(e)}")
        raise
    finally:
        db.close()

# 创建异步引擎
async_engine = create_async_engine(
    env_settings.SQLALCHEMY_ASYNC_URL,
    echo=False,
    echo_pool=False,
    pool_pre_ping=True,
    pool_recycle=3600,
    pool_size=5,
    max_overflow=5,
    connect_args={}
)

# 创建异步会话工厂
session_factory = async_sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=async_engine,
    expire_on_commit=False,
    class_=AsyncSession
)

class Base(AsyncAttrs, DeclarativeBase):
    """ORM模型基类"""
    
    @declared_attr.directive
    def __tablename__(cls) -> str:
        """自动生成表名"""
        table_name = cls.__tablename__
        if not table_name:
            model_name = cls.__name__
            ls = []
            for index, char in enumerate(model_name):
                if char.isupper() and index != 0:
                    ls.append("_")
                ls.append(char)
            table_name = "".join(ls).lower()
        return table_name

async def db_getter() -> AsyncGenerator[AsyncSession, None]:
    """异步获取数据库会话"""
    async with session_factory() as session:
        async with session.begin():
            yield session

# def redis_getter(request: Request) -> Redis:
#     """获取 redis 数据库对象"""
#     if not env_settings.REDIS_DB_ENABLE:
#         raise CustomException("请先配置Redis数据库链接并启用！",
#                             desc="请启用 application/settings.py: REDIS_DB_ENABLE")
#     return request.app.state.redis
#
# def mongo_getter(request: Request) -> AsyncIOMotorDatabase:
#     """获取 mongo 数据库对象"""
#     if not env_settings.MONGO_DB_ENABLE:
#         raise CustomException(
#             "请先配置MongoDB数据库链接并启用！",
#             desc="请启用 application/settings.py: MONGO_DB_ENABLE"
#         )
#     return request.app.state.mongo
