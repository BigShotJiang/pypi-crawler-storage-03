import uuid
from contextvars import ContextVar
from typing import Dict, Any

from fastapi import Request, Response, FastAPI

# 创建请求上下文变量
request_context: ContextVar[Dict[str, Any]] = ContextVar('request_context', default={})


def register_trace_context_middleware(app: FastAPI):
    """
    追踪上下文中间件
    用于从请求头中获取追踪信息并设置到上下文中
    """

    @app.middleware("http")
    async def trace_context_middleware(request: Request, call_next):
        # 从请求头中获取追踪信息
        trace_info = {
            'x_request_id': request.headers.get('x-request-id', str(uuid.uuid4())),
            'x_trace_id': request.headers.get('x-trace-id', str(uuid.uuid4())),
            'x_span_id': request.headers.get('x-span-id', str(uuid.uuid4())),
            'x_pspan_id': request.headers.get('x-pspan-id', '-1'),
            'x_tenant_id': request.headers.get('x-tenant-id', '-1'),
            'x_user_id': request.headers.get('x-user-id', '-1')
        }

        # 设置请求上下文
        token = request_context.set(trace_info)

        try:
            response = await call_next(request)
            return response
        finally:
            # 清理上下文
            request_context.reset(token)
