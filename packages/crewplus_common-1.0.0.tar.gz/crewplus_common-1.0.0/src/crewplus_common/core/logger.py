# -*- coding: utf-8 -*-
# @version    : 1.0
# @create     : 2024/03/14 10:00
# @update     : 2024/03/14 10:00
# @desc       : Logger configuration using loguru
"""
Logger Configuration Module

This module provides a wrapper around loguru to offer a simplified and standardized logging interface.
It supports:
- Four logging levels (debug, info, warning, error)
- File and console output with different configurations
- Standard library logging interception
- Context binding for structured logging
- Global context attributes for distributed tracing

Example:
    Basic usage:
        >>> from core.logger import logger
        >>> logger.info("Application started")
        >>> logger.error("An error occurred", exc_info=True)

    With context binding:
        >>> request_logger = logger.bind(request_id="123", user_id="456")
        >>> request_logger.info("Processing request")

    Intercepting standard library logging:
        >>> import logging
        >>> logger.intercept(logging)
        >>> logging.info("This will be handled by loguru")

    Setting global trace attributes:
        >>> from core.logger import LogConfig
        >>> LogConfig.BIND_ATTRS = {"trace_id": "abc-123", "service": "api"}
"""

import sys
from pathlib import Path
from datetime import datetime
import time
import uuid
from typing import Dict

from loguru import logger as _logger
import logging
from pygelf import GelfTcpHandler

# 导入请求上下文变量
from core.middleware_context import request_context

class GelfHandler(logging.Handler):
    """
    Custom handler that formats logs in GELF format and sends to Vector
    """

    def __init__(self, host, port):
        super().__init__()
        print(f"Initializing GelfHandler with host={host}, port={port}")  # 添加连接信息日志

        # 初始化时创建连接
        self._initialize_connection(host, port)
        self._settings = None
        self._hostname = self._get_hostname()

    def _initialize_connection(self, host, port):
        """初始化并建立与 Vector 的连接"""
        """
        host=host,
        port=port,
        include_extra_fields=True,
        debug=True,
        retry=True,
        retry_delay=2,
        max_retries=3,
        keep_connection=True  # 保持连接
        """
        try:
            self.gelf_handler = GelfTcpHandler(
                host=host,
                port=port,
                include_extra_fields=True
            )

            # 验证连接是否成功建立
            # if not self._verify_connection():
            #     raise ConnectionError("Failed to establish connection with Vector")

        except Exception as e:
            print(f"Error initializing Vector connection: {str(e)}")
            raise

    def _verify_connection(self):
        """验证连接是否有效"""
        try:
            # 尝试发送一个测试消息
            test_record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg="Test connection",
                args=(),
                exc_info=None
            )

            # 确保 LogRecord 的所有标准属性都不为 None
            for attr in dir(test_record):
                if not attr.startswith('__') and getattr(test_record, attr) is None:
                    if attr in ['args', 'exc_info', 'exc_text']:
                        # 这些特殊字段保持原样
                        continue
                    if isinstance(getattr(test_record.__class__, attr, None), property):
                        # 跳过属性装饰器
                        continue
                    setattr(test_record, attr, "")

            self.gelf_handler.emit(test_record)
            return True
        except Exception as e:
            print(f"Connection verification failed: {str(e)}")
            return False

    def _reconnect_if_needed(self):
        """检查并在需要时重新连接"""
        try:
            if not hasattr(self.gelf_handler, 'socket') or not self.gelf_handler.socket:
                self._initialize_connection(self.gelf_handler.host, self.gelf_handler.port)
        except Exception as e:
            print(f"Reconnection failed: {str(e)}")

    def _get_hostname(self):
        """获取主机名，如果获取失败则返回默认值"""
        try:
            import socket
            return socket.gethostname()
        except Exception:
            return "unknown-host"

    def _get_settings(self):
        if self._settings is None:
            try:
                from config.environments import get_settings
                self._settings = get_settings()
            except ImportError:
                return None
        return self._settings

    def _convert_to_log_record(self, record):
        """将 loguru 记录转换为标准日志记录格式"""
        if isinstance(record, dict):
            # 如果是字典格式（loguru 记录），转换为 LogRecord
            import logging

            # 获取日志级别和名称
            level_dict = record.get("level", {})
            if hasattr(level_dict, "no") and hasattr(level_dict, "name"):
                # 处理 RecordLevel 类型
                level = level_dict.no
                level_name = level_dict.name
            else:
                level = logging.INFO
                level_name = "INFO"

            log_record = logging.LogRecord(
                name=record.get("name", "loguru"),
                level=level,
                pathname=record.get("file", {}).name if isinstance(record.get("file"), dict) else "",
                lineno=record.get("line", 0),
                msg=record.get("message", ""),
                args=(),
                exc_info=record.get("exception", None)
            )

            # 设置 level_name 字段
            setattr(log_record, 'level_name', level_name)

            # 添加额外属性
            for key, value in record.items():
                if not hasattr(log_record, key):
                    setattr(log_record, key, value)

            # 确保 LogRecord 的所有标准属性都不为 None
            for attr in dir(log_record):
                if not attr.startswith('__') and getattr(log_record, attr) is None:
                    if attr in ['args', 'exc_info', 'exc_text']:
                        # 这些特殊字段保持原样
                        continue
                    if isinstance(getattr(log_record.__class__, attr, None), property):
                        # 跳过属性装饰器
                        continue
                    setattr(log_record, attr, "")

            # 如果 extra 字段存在，删除它
            if hasattr(log_record, 'extra'):
                delattr(log_record, 'extra')

            return log_record
        return record

    def _get_trace_info(self) -> Dict[str, str]:
        """从请求上下文中获取追踪信息"""
        try:
            context = request_context.get()
            return {
                'x_request_id': context.get('x_request_id', ''),
                'x_trace_id': context.get('x_trace_id', ''),
                'x_span_id': context.get('x_span_id', ''),
                'x_pspan_id': context.get('x_pspan_id', '-1'),
                'x_tenant_id': context.get('x_tenant_id', '-1'),
                'x_user_id': context.get('x_user_id', '-1')
            }
        except LookupError:
            # 如果上下文中没有信息，返回默认值
            return {
                'x_request_id': str(uuid.uuid4()),
                'x_trace_id': str(uuid.uuid4()),
                'x_span_id': str(uuid.uuid4()),
                'x_pspan_id': '-1',
                'x_tenant_id': '-1',
                'x_user_id': '-1'
            }

    def emit(self, record):
        try:
            # 检查 Vector 是否启用
            settings = self._get_settings()
            if not getattr(settings, "VECTOR_ENABLE", False):
                return

            # 确保连接有效
            self._reconnect_if_needed()

            # 获取时间戳
            timestamp = datetime.utcnow().isoformat() + 'Z'
            _timestamp = int(time.time() * 1_000_000_000)  # 纳秒级时间戳

            # 从请求上下文中获取追踪信息
            trace_info = self._get_trace_info()

            if settings is None:
                print("Warning: Settings not available, skipping Vector log")
                return

            # 转换记录为标准日志记录格式
            log_record = self._convert_to_log_record(record)

            # 从record中提取额外信息
            # extra = getattr(log_record, 'extra', {})
            #             service_name = os.getenv('APP', 'undefined')
            #             environment = os.getenv('NAMESPACE', 'undefined')
            #             host_name = getattr(settings, "HOST_NAME", self._hostname)
            # 安全地获取设置值
            service_name = getattr(settings, "SERVICE_NAME", "unknown-service")
            environment = getattr(settings, "APP_ENVIRONMENT", "unknown-env")
            host_name = getattr(settings, "HOST_NAME", self._hostname)

            # 设置额外的日志记录属性
            # 基本字段
            setattr(log_record, 'timestamp', timestamp)
            setattr(log_record, '_timestamp', _timestamp)
            setattr(log_record, 'message', log_record.getMessage())

            # 应用信息
            setattr(log_record, 'app', service_name)
            setattr(log_record, 'host', host_name)
            setattr(log_record, 'namespace', environment)

            # 追踪字段（从请求上下文中获取）
            setattr(log_record, 'x_request_id', trace_info['x_request_id'])
            setattr(log_record, 'x_trace_id', trace_info['x_trace_id'])
            setattr(log_record, 'x_span_id', trace_info['x_span_id'])
            setattr(log_record, 'x_pspan_id', trace_info['x_pspan_id'])
            setattr(log_record, 'x_tenant_id', trace_info['x_tenant_id'])
            setattr(log_record, 'x_user_id', trace_info['x_user_id'])

            # 添加额外字段
            # for key, value in extra.items():
            #     setattr(log_record, key, value)



            # 发送到 Vector
            try:
                self.gelf_handler.emit(log_record)
            except Exception as e:
                print(f"Failed to send log to Vector: {str(e)}")
                # 尝试重新连接并重试一次
                self._reconnect_if_needed()
                self.gelf_handler.emit(log_record)
                print(f"Successfully sent log to Vector after reconnection")

        except Exception as e:
            print(f"Error in emit: {str(e)}", file=sys.stderr)
            import traceback
            print(f"Detailed error: {traceback.format_exc()}", file=sys.stderr)

    def close(self):
        """确保正确关闭连接"""
        try:
            if hasattr(self.gelf_handler, 'socket') and self.gelf_handler.socket:
                self.gelf_handler.socket.close()
        except Exception as e:
            print(f"Error closing Vector connection: {str(e)}")
        finally:
            super().close()


class Intercepter(logging.Handler):
    """
    A handler class which redirects standard library logging to loguru.

    This allows unified logging format and handling when using third-party
    libraries that use the standard logging module.
    """

    def emit(self, record):
        # 保持原有的日志格式
        _logger.opt(exception=record.exc_info).log(
            record.levelname,
            record.getMessage(),
            name=record.name
        )


class LogConfig:
    """
    Logging configuration class that defines all logging related settings.

    Attributes:
        LOG_PATH: Directory where log files will be stored
        LOG_FORMAT: Standard format for all log messages
        BIND_ATTRS: Global context attributes for all log messages (e.g., trace_id)
        FILE_CONFIG: Configuration for file logging
        CONSOLE_CONFIG: Configuration for console logging
    """
    LOG_PATH = Path(__file__).resolve().parent.parent / "logs"
    LOG_FORMAT = "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | PID:{process} | TID:{thread} | {name}:{function}:{line} - {message}"

    # Global context attributes for distributed tracing
    BIND_ATTRS = {}

    FILE_CONFIG = {
        "sink": str(LOG_PATH / f'app_{"{time:YYYY-MM-DD}"}.log'),
        "format": LOG_FORMAT,
        "rotation": "00:00",  # Rotate at midnight
        "retention": "7 days",  # Keep logs for 7 days
        "enqueue": True,  # Thread-safe logging
        "encoding": "UTF-8",
        "level": "INFO"
    }

    CONSOLE_CONFIG = {
        "sink": sys.stdout,
        "format": LOG_FORMAT,
        "level": "INFO",
        "colorize": True,  # Colorize output
        "enqueue": True  # Thread-safe logging
    }


class Logger:
    """
    A wrapper class around loguru logger that provides a simplified interface.

    This class restricts logging to four levels (debug, info, warning, error)
    and adds support for context binding and standard library logging interception.

    Example:
        >>> logger = Logger(_logger)
        >>> logger.info("Hello, world!")
        >>> request_logger = logger.bind(request_id="123")
        >>> request_logger.info("Processing request")
    """
    """
        A wrapper class around loguru logger that provides a simplified interface.
        """
    _gelf_handler = None  # 添加类变量声明

    def __init__(self, logger_instance):
        self._logger = logger_instance
        # 在初始化时就尝试设置 GELF handler
        self._initialize_gelf_handler()
        for level in ["debug", "info", "warning", "error"]:
            setattr(self, level, getattr(logger_instance, level))

    @classmethod
    def _initialize_gelf_handler(cls):
        if cls._gelf_handler is None:
            try:
                from config.environments import get_settings
                settings = get_settings()

                # 检查是否启用 Vector 日志
                if not getattr(settings, "VECTOR_ENABLE", False):
                    print("Vector logging is disabled by configuration")
                    return

                vector_config = {
                    "host": settings.VECTOR_HOST,
                    "port": settings.VECTOR_PORT,
                    "level": "INFO"
                }

                print(f"Initializing GELF handler with config: {vector_config}")  # 打印配置信息

                gelf_handler = GelfHandler(
                    host=vector_config["host"],
                    port=vector_config["port"]
                )
                gelf_handler.setLevel(vector_config["level"])

                cls._gelf_handler = gelf_handler

                def sink(message):
                    try:
                        # 检查 Vector 是否启用
                        if not getattr(settings, "VECTOR_ENABLE", False):
                            return
                        # 直接传递 loguru 的 message 对象
                        gelf_handler.emit(message.record)
                    except Exception as e:
                        print(f"Error in loguru sink: {str(e)}", file=sys.stderr)

                _logger.add(
                    sink,
                    format="{message}",
                    level=vector_config["level"],
                    filter=lambda record: True
                )
                print("GELF handler initialized successfully")
            except ImportError as e:
                print(f"Failed to initialize GELF handler: {str(e)}")
            except Exception as e:
                print(f"Unexpected error initializing GELF handler: {str(e)}")

    def __getattr__(self, name):
        # 延迟初始化GELF handler
        if name in ["debug", "info", "warning", "error"]:
            self._initialize_gelf_handler()
        return getattr(self._logger, name)

    def intercept(self, module) -> None:
        """
        Intercept standard library logging and redirect to loguru.

        Args:
            module: The logging module to intercept (usually the standard logging module)

        Example:
            >>> import logging
            >>> logger.intercept(logging)
            >>> logging.info("This will be handled by loguru")
        """
        module.basicConfig(handlers=[Intercepter()], level=0, force=True)
        module.getLogger().handlers = []

    def bind(self, **kwargs) -> "Logger":
        """
        Create a new logger instance with bound context variables.

        Args:
            **kwargs: Arbitrary keyword arguments to be bound to the logger

        Returns:
            A new Logger instance with the bound context

        Example:
            >>> request_logger = logger.bind(request_id="123", user_id="456")
            >>> request_logger.info("Request processed")  # Will include bound context
        """
        bound_logger = self._logger.bind(**kwargs)
        return Logger(bound_logger)


# Initialize logging configuration
LogConfig.LOG_PATH.mkdir(exist_ok=True)
_logger.remove()

# Apply global context attributes if any
if LogConfig.BIND_ATTRS:
    _logger = _logger.bind(**LogConfig.BIND_ATTRS)

# Configure handlers
_logger.configure(handlers=[LogConfig.FILE_CONFIG, LogConfig.CONSOLE_CONFIG])

# Create and export logger instance
logger = Logger(_logger)
__all__ = ["logger"]
