import os
from importlib import import_module
from config.base_settings import Settings


# 获取环境名称
ENV = os.getenv("ENV", "dev").lower()

# 全局配置实例
_settings_instance = None

try:
    # 加载指定环境的配置
    module = import_module(f"config.environments.env_{ENV}")
    settings_class = getattr(module, ENV.title() + 'Settings')
    SETTINGS = settings_class
    print(f"Environment config loaded: {ENV}")
except Exception as e:
    print(f"Environment config load failed: {ENV}")
    raise


def get_settings() -> Settings:
    """Get settings instance"""
    global _settings_instance
    if _settings_instance is None:
        _settings_instance = SETTINGS()
    return _settings_instance