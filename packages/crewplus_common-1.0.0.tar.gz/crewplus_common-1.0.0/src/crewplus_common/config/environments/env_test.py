# -*- coding: utf-8 -*-
# @version    : 1.0
# @create     : 2021/10/19 15:47
# @update     : 2024/03/14 10:00
# @desc       : Test environment configuration

from config.base_settings import Settings
import os


class TestSettings(Settings):

    # 调试模式
    DEBUG: bool = False

    # MySQL数据库配置
    SQLALCHEMY_ASYNC_URL: str = "mysql+asyncmy://agent:r85qFQcN5b@mysql:3306/opsmateai_agent"
    SQLALCHEMY_SYNC_URL: str = "mysql+pymysql://agent:r85qFQcN5b@mysql:3306/opsmateai_agent"
    OFFICE_PORT: int = int(os.getenv("OFFICE_PORT", 9001))

    VECTOR_HOST: str = os.getenv("TCP_LOG_HOST", "localhost")
    VECTOR_PORT: int = int(os.getenv("TCP_LOG_PORT", 12201))
    VECTOR_ENABLE: bool = os.getenv("TCP_LOG_ENABLE", True)
    SERVICE_NAME: str = os.getenv('APP', 'apsmateai-docforge')
    APP_ENVIRONMENT: str = os.getenv('ENV', 'test')
    # 存储服务配置
    STORAGE_PROVIDER: str = "azure" # local azure
    LOCAL_STORAGE_BASE_DIR: str = "/tmp/opsmate_test_storage"
    AZURE_STORAGE_CONNECTION_STRING: str = "DefaultEndpointsProtocol=https;AccountName=opsmateai;AccountKey=32eWuL1bDO8phQPCS7nQ7K5qiZH/baHE354KKdi86uMyJUcXtxL3i8ZcuFPF050iYRTZEU7fMXkm+AStgrk9vg==;EndpointSuffix=core.windows.net"
    AZURE_STORAGE_CONTAINER_NAME: str = "celery-test"
    #Celery配置
    CELERY_BROKER_URL: str = "redis://redis:6379/1"
    CELERY_BACKEND_URL: str = "redis://redis:6379/1"
    CELERY_QUEUES: str = os.getenv("CELERY_QUEUES", "default")
    CELERY_CONCURRENCY: int = int(os.getenv("CELERY_CONCURRENCY", "8"))
    CELERY_WORKER_MAX_TASKS_PER_CHILD: int = int(os.getenv("CELERY_WORKER_MAX_TASKS_PER_CHILD", "50"))
    CELERY_WORKER_MAX_MEMORY_PER_CHILD: int = int(os.getenv("CELERY_WORKER_MAX_MEMORY_PER_CHILD", "4194304"))
    CELERY_BATCH_SIZE: int = int(os.getenv("CELERY_BATCH_SIZE", "20"))
    CELERY_POOL: str = os.getenv("CELERY_POOL", "threads")
    CELERY_ENABLE_SCHEDULE: str = os.getenv("CELERY_ENABLE_SCHEDULE", "false")
    CELERY_SCHEDULE_MINUTES: int = int(os.getenv("CELERY_SCHEDULE_MINUTES", "60"))
# 创建测试环境配置实例
settings = TestSettings() 