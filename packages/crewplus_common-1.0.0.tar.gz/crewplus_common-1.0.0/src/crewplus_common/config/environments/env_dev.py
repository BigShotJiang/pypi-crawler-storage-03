# -*- coding: utf-8 -*-
# @version    : 1.0
# @create     : 2021/10/19 15:47
# @update     : 2024/03/14 10:00
# @desc       : Development environment configuration

from config.base_settings import Settings
import os


class DevSettings(Settings):

    # 调试模式
    DEBUG: bool = True

    # MySQL数据库配置
    SQLALCHEMY_ASYNC_URL: str = "mysql+asyncmy://root:Sjtu403B!ertw@crewplus-mysql:3306/crewplus"
    SQLALCHEMY_SYNC_URL: str = "mysql+pymysql://root:Sjtu403B!ertw@crewplus-mysql:3306/crewplus"

    # Vector GELF 配置
    VECTOR_HOST: str = os.getenv("TCP_LOG_HOST", "localhost")
    VECTOR_PORT: int = int(os.getenv("TCP_LOG_PORT", 12201))
    VECTOR_ENABLE: bool = os.getenv("TCP_LOG_ENABLE", False)
    SERVICE_NAME: str = os.getenv('APP', 'apsmateai-docforge')
    APP_ENVIRONMENT: str = os.getenv('ENV', 'dev')
    # 存储服务配置
    STORAGE_PROVIDER: str = "azure" # local azure
    LOCAL_STORAGE_BASE_DIR: str = "/tmp/opsmate_test_storage"
    AZURE_STORAGE_CONNECTION_STRING: str = "DefaultEndpointsProtocol=https;AccountName=opsmateai;AccountKey=32eWuL1bDO8phQPCS7nQ7K5qiZH/baHE354KKdi86uMyJUcXtxL3i8ZcuFPF050iYRTZEU7fMXkm+AStgrk9vg==;EndpointSuffix=core.windows.net"

# 创建开发环境配置实例
settings = DevSettings() 
