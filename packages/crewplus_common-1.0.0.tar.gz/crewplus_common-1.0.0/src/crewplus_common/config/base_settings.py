from typing import List, Optional, Union, Callable, ClassVar
from pydantic_settings import BaseSettings
import os
from pathlib import Path
from fastapi.security import OAuth2PasswordBearer


class Settings(BaseSettings):
    # 版本信息
    VERSION: str = "1.0.0"
    
    # 基础目录配置
    BASE_DIR: str = str(Path(__file__).resolve().parent.parent)

    IP_PARSE_ENABLE: bool = False
    IP_PARSE_TOKEN: str = "IP_PARSE_TOKEN"
    
    # 认证设置
    OAUTH_ENABLE: bool = True
    oauth2_scheme: ClassVar[Union[OAuth2PasswordBearer, Callable]] = OAuth2PasswordBearer(tokenUrl="/auth/api/login", auto_error=False) if OAUTH_ENABLE else lambda: ""
    
    # JWT设置
    SECRET_KEY: str = 'vgb0tnl9d58+6n-6h-ea&u^1#s0ccp!794=kbvqacjq75vzps$'
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440  # 24小时
    REFRESH_TOKEN_EXPIRE_MINUTES: int = 1440 * 2  # 48小时
    ACCESS_TOKEN_CACHE_MINUTES: int = 30
    
    # 文件系统设置
    TEMP_DIR: str = os.path.join(BASE_DIR, "temp")
    STATIC_ENABLE: bool = True
    STATIC_URL: str = "/media"
    STATIC_DIR: str = "static"
    STATIC_ROOT: str = os.path.join(BASE_DIR, STATIC_DIR)
    
    # CORS设置
    CORS_ORIGIN_ENABLE: bool = True
    ALLOW_ORIGINS: List[str] = ["*"]
    ALLOW_CREDENTIALS: bool = True
    ALLOW_METHODS: List[str] = ["*"]
    ALLOW_HEADERS: List[str] = ["*"]
    
    # 演示模式设置
    DEMO: bool = False
    DEMO_WHITE_LIST_PATH: List[str] = [
        "/auth/login",
        "/auth/token/refresh",
    ]
    DEMO_BLACK_LIST_PATH: List[str] = [
        "/auth/api/login"
    ]
    
    # 系统默认值
    DEFAULT_PASSWORD: str = "0"  # 默认密码，"0"表示Email
    DEFAULT_AVATAR: str = "https://crewplus-useast-demo.s3.amazonaws.com/data/image/2024/07/11/55886_6tvc_1821.png"
    DEFAULT_AUTH_ERROR_MAX_NUMBER: int = 5  # 最大登录尝试次数
    
    # 日志设置
    LOG_LEVEL: str = "INFO"  # 默认日志级别
    LOGIN_LOG_RECORD: bool = True
    REQUEST_LOG_RECORD: bool = True
    OPERATION_LOG_RECORD: bool = False
    OPERATION_RECORD_METHOD: List[str] = ["POST", "PUT", "DELETE"]
    IGNORE_OPERATION_FUNCTION: List[str] = ["post_dicts_details"]
    
    # 中间件配置
    MIDDLEWARES: List[Optional[str]] = [
        "core.middleware.register_request_log_middleware" if REQUEST_LOG_RECORD else None,
        "core.middleware.register_demo_env_middleware" if DEMO else None,
        "core.middleware.register_jwt_refresh_middleware"
    ]
    
    # 事件处理器
    EVENTS: List[str] = [
        "core.event.connect_redis",
    ]
    
    # 任务队列设置
    SUBSCRIBE: str = 'crewplus_queue'  # 任务发布/订阅通道

    # V V V V V  在这里添加 Celery 配置声明  V V V V V
    # 这样做可以告诉 Pydantic "蓝图"上存在这些字段，请从环境中加载它们
    CELERY_BROKER_URL: Optional[str] = None
    CELERY_BACKEND_URL: Optional[str] = None
    CELERY_QUEUES: str = "default"
    CELERY_CONCURRENCY: int = 8
    CELERY_WORKER_MAX_TASKS_PER_CHILD: int = 50
    CELERY_WORKER_MAX_MEMORY_PER_CHILD: int = 4194304
    CELERY_POOL: str = "prefork"
    CELERY_ENABLE_SCHEDULE: str = "false"
    CELERY_SCHEDULE_MINUTES: int = 60
    # ^ ^ ^ ^ ^  添加结束  ^ ^ ^ ^ ^

    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "allow"  # 允许额外的字段
