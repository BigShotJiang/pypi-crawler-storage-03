# Edge case tests for memg_core
