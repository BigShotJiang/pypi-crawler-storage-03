from enum import Enum


class Options(Enum):
    A = "A"
    B = "B"
