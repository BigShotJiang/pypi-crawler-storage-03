#!/bin/bash

rm 1.1.*
rm 1.2.*
rm 1.3.*
rm 1.4.*

rm 2.1.*
rm 2.2.*
rm 2.3.*
rm 2.4.*
rm 2.5.*

rm 3.1.*
rm 3.2.*
rm 3.3.*

rm 4.1.*
rm 4.2.*
rm 4.3.*

rm slurm*
rm log*
rm Times*
rm CONS*
rm NN*
rm -rf regular_shp