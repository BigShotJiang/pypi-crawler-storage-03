=======
Authors
=======

* Carles Tena (`ctwebpage`_)
* Alba Vilanova Cortezón (`avcwebpage`_)

.. _ctwebpage: https://www.bsc.es/tena-carles
.. _avcwebpage: https://www.bsc.es/vilanova-cortezon-alba
