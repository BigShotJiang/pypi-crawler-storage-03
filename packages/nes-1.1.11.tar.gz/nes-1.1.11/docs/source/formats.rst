Formats
========================

CAMS RA format
----------------------------------------

.. automodule:: nes.nes_formats.cams_ra_format
   :members:
   :undoc-members:
   :show-inheritance:

CMAQ format
------------------------------------

.. automodule:: nes.nes_formats.cmaq_format
   :members:
   :undoc-members:
   :show-inheritance:

MONARCH format
---------------------------------------

.. automodule:: nes.nes_formats.monarch_format
   :members:
   :undoc-members:
   :show-inheritance:

WRF CHEM format
-----------------------------------------

.. automodule:: nes.nes_formats.wrf_chem_format
   :members:
   :undoc-members:
   :show-inheritance: