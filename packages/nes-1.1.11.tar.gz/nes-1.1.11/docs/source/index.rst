========
Contents
========

.. toctree::
   :maxdepth: 2

   readme
   object
   methods
   formats
   projections
   contributing
   changelog
   authors