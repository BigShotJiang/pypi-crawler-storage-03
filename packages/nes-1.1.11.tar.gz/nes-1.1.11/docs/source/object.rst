The NES object
==============

Creating a NES object
----------------------

.. automodule:: nes.create_nes
   :members:
   :undoc-members:
   :show-inheritance:

Loading a NES object
--------------------

.. automodule:: nes.load_nes
   :members:
   :undoc-members:
   :show-inheritance:
