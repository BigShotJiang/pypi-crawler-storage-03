"""API for devices."""

import uuid

OTHER_DEVICE: uuid.UUID = uuid.UUID("9c0e0865-f3b0-488f-8d3f-b3b0cdda5de7")
