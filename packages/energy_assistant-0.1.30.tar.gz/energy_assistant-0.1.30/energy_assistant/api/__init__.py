"""REST api for energy assistant."""
