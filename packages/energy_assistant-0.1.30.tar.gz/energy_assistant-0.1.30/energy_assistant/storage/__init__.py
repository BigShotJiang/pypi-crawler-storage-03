"""Storage for energy assistant."""
