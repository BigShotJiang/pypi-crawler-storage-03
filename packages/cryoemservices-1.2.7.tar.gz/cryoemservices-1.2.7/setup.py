#!/usr/bin/env python

from __future__ import annotations

import setuptools

if __name__ == "__main__":
    # Do not add any parameters here. Edit setup.cfg instead.
    setuptools.setup()
