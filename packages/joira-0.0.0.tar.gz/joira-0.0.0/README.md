# joira (Python)

Minimal placeholder package to claim the `joira` name on PyPI.

Usage:

```
python -m joira
```

Or via console script after install:

```
joira
```
