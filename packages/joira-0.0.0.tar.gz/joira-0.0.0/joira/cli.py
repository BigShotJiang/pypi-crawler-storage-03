def main() -> None:
    print("joira: hello world (python)")


if __name__ == "__main__":
    main()
