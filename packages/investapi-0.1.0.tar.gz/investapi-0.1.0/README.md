# InvestAPI
API for gathering Stock, ETFs, Crypto and Steam item prices
