"""SQLSaber CLI - Agentic SQL assistant like Claude Code but for SQL."""
