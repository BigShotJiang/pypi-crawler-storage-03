"""CLI module for SQLSaber."""

from .commands import main

__all__ = [
    "main",
]
