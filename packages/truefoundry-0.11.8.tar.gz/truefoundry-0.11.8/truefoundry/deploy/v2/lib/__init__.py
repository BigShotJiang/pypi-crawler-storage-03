# NOTE: Later all of these can be under a `models` or some other module
# I am not entirely sure about the structure of `lib` module yet
# This can go through another round of refactoring
