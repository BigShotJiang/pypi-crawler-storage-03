# JAX Code Assistant
Finetuning LLMs on JAX to better aid in code assistance.

## Setup
Make sure to set the environment variables before running the scripts. You'd need:

- [ ] Github Token
- [ ] Google API key
