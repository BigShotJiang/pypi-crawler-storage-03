qumas.MicrolensingAnalysis.WindowAnalysis module
===============================================

.. automodule:: qumas.MicrolensingAnalysis.WindowAnalysis
   :members:
   :show-inheritance:
   :undoc-members:
