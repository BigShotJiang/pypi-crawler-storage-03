qumas.MicrolensingAnalysis.windows module
========================================

.. automodule:: qumas.MicrolensingAnalysis.windows
   :members:
   :show-inheritance:
   :undoc-members:
