qumas.cli module
===============

.. automodule:: qumas.cli
   :members:
   :show-inheritance:
   :undoc-members:
