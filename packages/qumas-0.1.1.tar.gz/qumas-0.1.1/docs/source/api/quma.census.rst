qumas.census module
==================

.. automodule:: qumas.census
   :members:
   :show-inheritance:
   :undoc-members:
