def test_import_module():
    import qumas

    assert qumas is not None
