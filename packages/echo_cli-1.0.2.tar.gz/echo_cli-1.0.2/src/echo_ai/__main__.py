"""Entry point for running Echo AI as a module with `python -m echo_ai`."""

from .cli import main

if __name__ == "__main__":
    main()
