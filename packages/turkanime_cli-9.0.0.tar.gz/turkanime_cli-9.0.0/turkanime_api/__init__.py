""" TurkAnimu API """
from .objects import Anime,Bolum,Video
from .bypass import session