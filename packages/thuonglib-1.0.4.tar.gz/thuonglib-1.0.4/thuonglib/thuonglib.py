def main():
    print("Utility by Tran Dinh Thuong")

if __name__ == "__main__":
    main()