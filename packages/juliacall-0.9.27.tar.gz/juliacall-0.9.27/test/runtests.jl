using TestItemRunner

@run_package_tests
