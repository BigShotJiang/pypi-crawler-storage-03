Shape = tuple[int, ...]
