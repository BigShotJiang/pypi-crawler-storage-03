# VideoSDK HumeAI Plugin

Agent Framework plugin for TTS services from HumeAI.

```bash
pip install videosdk-plugins-humeai
```

