korpy
======
korpy is a toolkit for korean texts

- TMI: i was trying to do krpy, but that was taken.
- TMI: it is a short of Python-Korean.