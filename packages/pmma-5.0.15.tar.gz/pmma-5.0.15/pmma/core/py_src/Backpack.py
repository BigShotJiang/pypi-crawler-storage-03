class Backpack:
    application_running = True
    application_start_time = None
    language = None