from .nearest_neighbors import KNNClassifier

__all__ = [
    "KNNClassifier",
]