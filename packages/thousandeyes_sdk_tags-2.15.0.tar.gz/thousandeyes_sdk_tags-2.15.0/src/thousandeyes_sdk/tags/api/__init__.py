# flake8: noqa

# import apis into api package
from thousandeyes_sdk.tags.api.tag_assignment_api import TagAssignmentApi
from thousandeyes_sdk.tags.api.tags_api import TagsApi

