"""Contain widgets used in the web viewer."""
