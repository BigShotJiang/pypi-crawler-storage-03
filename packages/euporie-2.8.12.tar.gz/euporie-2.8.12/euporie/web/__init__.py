"""A euporie web viewer component."""
