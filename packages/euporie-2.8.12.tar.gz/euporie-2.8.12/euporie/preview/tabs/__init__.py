"""Notebook tab for use in preview app."""
