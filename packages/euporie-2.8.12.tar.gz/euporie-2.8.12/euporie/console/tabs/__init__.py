"""Contain various application tab implementations."""
