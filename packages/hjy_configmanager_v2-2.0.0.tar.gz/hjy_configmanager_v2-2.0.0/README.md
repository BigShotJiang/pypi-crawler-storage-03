# hjy-configmanager-v2

Hjy configmanager package version 2.0.0.

## Installation

```bash
pip install hjy-configmanager-v2
```

## Usage

```python
import hjy_configmanager_v2
print(hjy_configmanager_v2.__version__)
```
