# Roadmap

!!! NOTE
    The roadmap represents the general direction of the project, and is subject
    to change based on priority and bandwidth.

## The road to 1.0

The primary focus of pre-1.0 releases is completing the base functionality and
ensuring stability.

**Planned features**

* Debug toolbar panel
* Database experiment backend
* Django admin support
