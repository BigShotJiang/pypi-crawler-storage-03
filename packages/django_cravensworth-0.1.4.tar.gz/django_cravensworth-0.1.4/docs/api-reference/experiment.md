# Experiment

::: cravensworth.core.experiment
    options:
      members:
      - Context
      - ContextProvider
      - DjangoRequestContextProvider
      - Allocation
      - Audience
      - Experiment
      - CravensworthState
      - is_variant
      - is_on
      - is_off
