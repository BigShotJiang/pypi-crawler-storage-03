"""
MLGame 3D Framework

A framework for playing Unity games with Python agents using ML-Agents.
"""

__version__ = "0.7.1"
