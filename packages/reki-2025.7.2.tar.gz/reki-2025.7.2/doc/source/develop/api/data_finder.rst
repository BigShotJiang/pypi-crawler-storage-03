数据查找
==================================

.. py:currentmodule:: reki.data_finder

.. autofunction:: find_local_file


内部函数
----------

.. autofunction:: reki.data_finder._util.find_file


.. autofunction:: reki.data_finder._config.find_config