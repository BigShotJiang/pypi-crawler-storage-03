1.  Go to `Purchase > Configuration > Settings`.
2.  Check the "Create variants on confirm" option if you want to delay
    the creation of them until the order confirmation.
