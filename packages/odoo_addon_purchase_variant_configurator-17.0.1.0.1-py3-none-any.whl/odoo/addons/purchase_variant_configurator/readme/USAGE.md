1.  Go to a purchase order or create a new one.
2.  Create a new line
3.  Set in Product Template some product with attributes and variants.
4.  All product attributes will be displayed in table mode just below.
5.  Set a value for all attributes.
6.  A product variant (with the selected options) will be auto-set.

Only if the "Create variants on confirm" option in the configuration is
set.

1.  Go to `Purchase > Products > Product` and create a new one.
2.  Go to the "Attributes & Variants" tab.
3.  Set in "Variant creation" the option "Do not create them
    automatically".
4.  Set some attribute and value(s)
5.  Go to a purchase order or create a new one.
6.  Create a new line
7.  Set in Product Template the one created before and select values for
    attributes.
8.  Confirm orden.
9.  A product variant (with the selected options) will have been created
    for the Product Template.
