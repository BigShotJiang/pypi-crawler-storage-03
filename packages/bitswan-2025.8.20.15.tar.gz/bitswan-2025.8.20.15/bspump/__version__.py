# THIS-FILE-WILL-BE-REPLACED !!! DO NOT CHANGE OR MODIFY THIS FILE !!!

# During the GitHub release workflow, this file is overwritten with the CalVer version
# For development, this defaults to "devel"

# PEP 440 -- Version Identification and Dependency Specification
# https://www.python.org/dev/peps/pep-0440/

__version__ = "2025.08.20.15"
__build__ = "0.0.0.dev"
