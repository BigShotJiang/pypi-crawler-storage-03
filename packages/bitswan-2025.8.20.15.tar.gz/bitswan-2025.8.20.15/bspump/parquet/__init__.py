from .sink import ParquetSink

__all__ = ("ParquetSink",)
