itertools-len
=============

.. currentmodule:: itertools_len
.. automodule:: itertools_len

.. raw:: html

   <script>
   window.setTimeout(() => {
     const link = $('.local-toc>ul>li:not(.current)>a').first()
     SphinxRtdTheme.Navigation.toggleCurrent(link)
   }, 100)
   </script>
