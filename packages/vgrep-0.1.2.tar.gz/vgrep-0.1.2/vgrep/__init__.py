"""vgrep package."""

__all__: list[str] = []

# Package version
__version__ = "0.1.2"
