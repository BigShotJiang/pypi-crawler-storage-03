from .window import PermissionConfigurator
__all__ = ["PermissionConfigurator"]
