To use the module act as follows while you process an incoming shipment.

1.  In the detailed operations list view click on the optional columns
    and select the information that is relevant for you.
2.  Fill the lot/serial number name.
3.  Fill whatever other extra field is relevant for you.
4.  Fill the rest of information as usual.
5.  Validate the operation.

Your lots will include now all the information you added during the
reception.
