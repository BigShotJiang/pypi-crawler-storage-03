<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU" sourcelanguage="_US">
<context>
    <name>FileDialogSource</name>
    <message>
        <location filename="../file_dialog_source.py" line="26"/>
        <source>All supported</source>
        <comment>file type</comment>
        <translation type="obsolete">Все поддерживаемые</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="36"/>
        <source>All files</source>
        <comment>file type</comment>
        <translation type="obsolete">Все файлы</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="41"/>
        <source>Compressed JSON</source>
        <comment>file type</comment>
        <translation type="obsolete">JSON со сжатием</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="42"/>
        <location filename="../file_dialog_source.py" line="63"/>
        <source>JSON</source>
        <comment>file type</comment>
        <translation type="obsolete">JSON</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="49"/>
        <source>Load Catalog</source>
        <translation type="obsolete">Загрузить каталог</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="57"/>
        <source>JSON with GZip compression</source>
        <comment>file type</comment>
        <translation type="obsolete">JSON со сжатием GZip</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="58"/>
        <source>JSON with Bzip2 compression</source>
        <comment>file type</comment>
        <translation type="obsolete">JSON со сжатием Bzip2</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="62"/>
        <source>JSON with LZMA2 compression</source>
        <comment>file type</comment>
        <translation type="obsolete">JSON со сжатием LZMA2</translation>
    </message>
    <message>
        <location filename="../file_dialog_source.py" line="70"/>
        <source>Save As…</source>
        <translation type="obsolete">Сохранить как…</translation>
    </message>
</context>
<context>
    <name>SubstanceInfo</name>
    <message>
        <location filename="../substance_info.py" line="160"/>
        <source>HUMAN_READABLE[key]</source>
        <translation type="obsolete">HUMAN_READABLE[key]</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="141"/>
        <source>Substance Info</source>
        <translation>Информация о веществе</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="168"/>
        <source></source>
        <comment>HUMAN_READABLE[key]</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="170"/>
        <source>Number of spectral lines</source>
        <translation>Число спектральных линий</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="177"/>
        <source>Catalog</source>
        <translation>Каталог</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="178"/>
        <source>Lines</source>
        <translation>Линии</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="179"/>
        <source>Frequency</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="180"/>
        <source>Intensity</source>
        <translation>Интенсивность</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="181"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="182"/>
        <source>Molecule</source>
        <translation>Молекула</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="183"/>
        <source>Structural formula</source>
        <translation>Структурная формула</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="184"/>
        <source>Stoichiometric formula</source>
        <translation>Стехиометрическая формула</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="185"/>
        <source>Molecule symbol</source>
        <translation>Молекулярный символ</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="186"/>
        <source>Species tag</source>
        <translation>Номер вещества</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="187"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="188"/>
        <source>Trivial name</source>
        <translation>Обыденное название</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="189"/>
        <source>Isotopolog</source>
        <translation>Изотополог</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="190"/>
        <source>State (TeX)</source>
        <translation>Состояние (TeX)</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="191"/>
        <source>State (HTML)</source>
        <translation>Состояние (HTML)</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="192"/>
        <source>InChI key</source>
        <translation>Хэш InChI</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="193"/>
        <source>Contributor</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="194"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="195"/>
        <source>Date of entry</source>
        <translation>Дата внесения</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="196"/>
        <source>Degrees of freedom</source>
        <translation>Число степеней свободы</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="197"/>
        <source>Lower state energy</source>
        <translation>Энергия нижнего уровня</translation>
    </message>
</context>
<context>
    <name>UI</name>
    <message>
        <location filename="../ui.py" line="135"/>
        <source>PyCatSearch (version {0})</source>
        <translation>PyCatSearch (версия {0})</translation>
    </message>
    <message>
        <location filename="../ui.py" line="137"/>
        <source>PyCatSearch</source>
        <translation>PyCatSearch</translation>
    </message>
    <message>
        <location filename="../ui.py" line="182"/>
        <source>Limit shown spectral lines</source>
        <translation>Ограничить показанные спектральные линии</translation>
    </message>
    <message>
        <location filename="../ui.py" line="183"/>
        <source>Minimal Intensity:</source>
        <translation>Мин. интенсивность:</translation>
    </message>
    <message>
        <location filename="../ui.py" line="193"/>
        <source>Temperature to calculate intensity</source>
        <translation>Температура, при которой считать интенсивность</translation>
    </message>
    <message>
        <location filename="../ui.py" line="194"/>
        <source>&#xa0;K</source>
        <translation>&#xa0;К</translation>
    </message>
    <message>
        <location filename="../ui.py" line="195"/>
        <source>Temperature:</source>
        <translation>Температура:</translation>
    </message>
    <message>
        <location filename="../ui.py" line="198"/>
        <source>Show</source>
        <translation>Показать</translation>
    </message>
    <message>
        <location filename="../ui.py" line="281"/>
        <location filename="../ui.py" line="590"/>
        <location filename="../ui.py" line="597"/>
        <location filename="../ui.py" line="601"/>
        <location filename="../ui.py" line="614"/>
        <source>Release Info</source>
        <translation>Информация о выпуске</translation>
    </message>
    <message>
        <location filename="../ui.py" line="282"/>
        <location filename="../ui.py" line="602"/>
        <source>Version {release.version} published {release.pub_date} is available. Would you like to get the update? The app will try to restart.</source>
        <translation>Доступна версия {release.version}, опубликованная {release.pub_date}. Загрузить обновление? Программа попробует перезапуститься.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="312"/>
        <source>Loading catalogs:</source>
        <translation>Загрузка каталогов:</translation>
    </message>
    <message>
        <location filename="../ui.py" line="318"/>
        <source>Loading a catalog from&lt;br&gt;{}</source>
        <translation>Загрузка каталога из&lt;br&gt;{}</translation>
    </message>
    <message>
        <location filename="../ui.py" line="329"/>
        <source>Loading has been cancelled.</source>
        <translation>Загрузка каталога отменена.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="331"/>
        <source>Failed to load a catalog.</source>
        <translation>Не удалось загрузить каталог.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="333"/>
        <source>Catalogs loaded.</source>
        <translation>Каталоги загружены.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="366"/>
        <source>Select a catalog file to load.</source>
        <translation>Выберите файл каталога для загрузки.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="370"/>
        <location filename="../ui.py" line="378"/>
        <source>Loading…</source>
        <translation>Загрузка…</translation>
    </message>
    <message>
        <location filename="../ui.py" line="403"/>
        <source>Unable to save the catalog</source>
        <translation>Не удаётся сохранить каталог</translation>
    </message>
    <message>
        <location filename="../ui.py" line="404"/>
        <source>Error {exception} occurred while saving {filename}. Try another location.</source>
        <translation>При сохранении {filename} произошла ошибка {exception}. Попробуйте другое местоположение.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="432"/>
        <source>{value} {unit}</source>
        <comment>format value in html</comment>
        <translation>{value} {unit}</translation>
    </message>
    <message>
        <location filename="../ui.py" line="434"/>
        <source>{value}</source>
        <comment>format value in html</comment>
        <translation>{value}</translation>
    </message>
    <message>
        <location filename="../ui.py" line="591"/>
        <source>You are using the final version for Python&#xa0;3.8.
There will be no more updates.</source>
        <translation>Вы используете последнюю версию под Python&#xa0;3.8.
Больше обновлений не будет.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="597"/>
        <source>Update check failed.</source>
        <translation>Ошибка при проверке наличия обновлений.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="614"/>
        <source>You are using the latest version.</source>
        <translation>Вы используете новейшую версию.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="623"/>
        <source>Catalog Info</source>
        <translation>Информация о каталоге</translation>
    </message>
    <message>
        <location filename="../ui.py" line="623"/>
        <source>No catalogs loaded</source>
        <translation>Нет загруженных каталогов</translation>
    </message>
    <message>
        <location filename="../ui.py" line="628"/>
        <source>CatSearch is a means of searching through spectroscopy lines catalogs. It&apos;s an offline application.</source>
        <translation>CatSearch&#xa0;— это средство поиска по каталогам спектральных линий. Это приложение не требует доступа в Интернет для работы.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="631"/>
        <source>It relies on the data stored in JSON files.</source>
        <translation>Оно полагается на данные, хранящиеся в файлах JSON.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="632"/>
        <source>One can use their own catalogs as well as download data from &lt;a href=&quot;https://spec.jpl.nasa.gov/&quot;&gt;JPL&lt;/a&gt; and &lt;a href=&quot;https://cdms.astro.uni-koeln.de/&quot;&gt;CDMS&lt;/a&gt; spectroscopy databases available on the Internet.</source>
        <translation>Можно использовать свои каталоги или загрузить данные из баз спектральных линий &lt;a href=&quot;https://spec.jpl.nasa.gov/&quot;&gt;JPL&lt;/a&gt; и &lt;a href=&quot;https://astro.uni-koeln.de/&quot;&gt;CDMS&lt;/a&gt;, доступных в Интернете.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="638"/>
        <source>Both plain text JSON and GZip/BZip2/LZMA-compressed JSON are supported.</source>
        <translation>Поддерживаются файлы JSON и файлы JSON, сжатые GZip, BZip2 или LZMA.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="639"/>
        <source>See {readme_link} for more info.</source>
        <translation>Больше информации&#xa0;— в {readme_link}.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="641"/>
        <source>readme</source>
        <translation>описании</translation>
    </message>
    <message>
        <location filename="../ui.py" line="644"/>
        <source>CatSearch is licensed under the {license_link}.</source>
        <translation>CatSearch поставляется под лицензией {license_link}.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="645"/>
        <source>GNU LGPL version 3</source>
        <translation>GNU LGPL версии 3</translation>
    </message>
    <message>
        <location filename="../ui.py" line="647"/>
        <source>The source code is available on {repo_link}.</source>
        <translation>Исходный код доступен на {repo_link}.</translation>
    </message>
    <message>
        <location filename="../ui.py" line="653"/>
        <source>About CatSearch</source>
        <translation>О CatSearch</translation>
    </message>
    <message>
        <location filename="../ui.py" line="777"/>
        <source>Searching…</source>
        <translation>Поиск…</translation>
    </message>
    <message>
        <location filename="../ui.py" line="785"/>
        <source>Ready.</source>
        <translation>Готово.</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../settings.py" line="98"/>
        <source>Line Feed (\n)</source>
        <translation>подача строки (\n)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="99"/>
        <source>Carriage Return (\r)</source>
        <translation>возврат каретки (\r)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="100"/>
        <source>CR+LF (\r\n)</source>
        <translation>ВК+ПС (\r\n)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="101"/>
        <source>LF+CR (\n\r)</source>
        <translation>ПС+ВК (\n\r)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="104"/>
        <source>comma (,)</source>
        <translation>запятая (,)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="105"/>
        <source>tab (\t)</source>
        <translation>табуляция (\t)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="106"/>
        <source>semicolon (;)</source>
        <translation>точка с запятой (;)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="107"/>
        <source>space ( )</source>
        <translation>пробел ( )</translation>
    </message>
    <message>
        <location filename="../settings.py" line="109"/>
        <source>MHz</source>
        <translation>МГц</translation>
    </message>
    <message>
        <location filename="../settings.py" line="109"/>
        <source>GHz</source>
        <translation>ГГц</translation>
    </message>
    <message>
        <location filename="../settings.py" line="109"/>
        <location filename="../settings.py" line="116"/>
        <source>cm⁻¹</source>
        <translation>см⁻¹</translation>
    </message>
    <message>
        <location filename="../settings.py" line="109"/>
        <source>nm</source>
        <translation>нм</translation>
    </message>
    <message>
        <location filename="../settings.py" line="111"/>
        <source>lg(nm² × MHz)</source>
        <translation>lg(нм² · МГц)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="112"/>
        <source>nm² × MHz</source>
        <translation>нм² · МГц</translation>
    </message>
    <message>
        <location filename="../settings.py" line="113"/>
        <source>lg(cm / molecule)</source>
        <translation>lg(см / молекула)</translation>
    </message>
    <message>
        <location filename="../settings.py" line="114"/>
        <source>cm / molecule</source>
        <translation>см / молекула</translation>
    </message>
    <message>
        <location filename="../settings.py" line="116"/>
        <source>meV</source>
        <translation>мэВ</translation>
    </message>
    <message>
        <location filename="../settings.py" line="116"/>
        <source>J</source>
        <translation>Дж</translation>
    </message>
    <message>
        <location filename="../settings.py" line="117"/>
        <source>K</source>
        <translation>К</translation>
    </message>
    <message>
        <location filename="../settings.py" line="117"/>
        <source>°C</source>
        <translation>°C</translation>
    </message>
    <message>
        <location filename="../settings.py" line="127"/>
        <source>When the program starts</source>
        <translation>При запуске приложения</translation>
    </message>
    <message>
        <location filename="../settings.py" line="137"/>
        <source>Display</source>
        <translation>Отображение</translation>
    </message>
    <message>
        <location filename="../settings.py" line="142"/>
        <source>Units</source>
        <translation>Единицы измерения</translation>
    </message>
    <message>
        <location filename="../settings.py" line="154"/>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../settings.py" line="162"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../settings.py" line="129"/>
        <location filename="../settings.py" line="133"/>
        <source>Load catalogs</source>
        <translation>Загружать каталоги</translation>
    </message>
    <message>
        <location filename="../settings.py" line="134"/>
        <source>Check for update</source>
        <translation>Проверять обновления</translation>
    </message>
    <message>
        <location filename="../settings.py" line="138"/>
        <source>Allow rich text in formulas</source>
        <translation>Разрешить форматирование в формулах</translation>
    </message>
    <message>
        <location filename="../settings.py" line="143"/>
        <source>Frequency:</source>
        <translation>Частота:</translation>
    </message>
    <message>
        <location filename="../settings.py" line="146"/>
        <source>Intensity:</source>
        <translation>Интенсивность:</translation>
    </message>
    <message>
        <location filename="../settings.py" line="149"/>
        <source>Energy:</source>
        <translation>Энергия:</translation>
    </message>
    <message>
        <location filename="../settings.py" line="150"/>
        <source>Temperature:</source>
        <translation>Температура:</translation>
    </message>
    <message>
        <location filename="../settings.py" line="155"/>
        <source>With units</source>
        <translation>С единицами измерения</translation>
    </message>
    <message>
        <location filename="../settings.py" line="156"/>
        <source>Line ending:</source>
        <translation>Окончание строки:</translation>
    </message>
    <message>
        <location filename="../settings.py" line="157"/>
        <source>CSV separator:</source>
        <translation>Разделитель в CSV:</translation>
    </message>
    <message>
        <location filename="../settings.py" line="166"/>
        <source>InChI key search URL:</source>
        <translation>Адрес для поиска по ключу InChI:</translation>
    </message>
</context>
<context>
    <name>FoundLinesModel</name>
    <message>
        <location filename="../found_lines_model.py" line="106"/>
        <location filename="../found_lines_model.py" line="115"/>
        <source>{value} [{unit}]</source>
        <comment>unit format</comment>
        <translation>{value}, {unit}</translation>
    </message>
    <message>
        <location filename="../found_lines_model.py" line="108"/>
        <source>Substance</source>
        <translation>Вещество</translation>
    </message>
    <message>
        <location filename="../found_lines_model.py" line="109"/>
        <location filename="../found_lines_model.py" line="117"/>
        <source>Frequency</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../found_lines_model.py" line="110"/>
        <location filename="../found_lines_model.py" line="121"/>
        <source>Intensity</source>
        <translation>Интенсивность</translation>
    </message>
    <message>
        <location filename="../found_lines_model.py" line="111"/>
        <location filename="../found_lines_model.py" line="125"/>
        <source>Lower state energy</source>
        <translation>Энергия нижнего уровня</translation>
    </message>
</context>
<context>
    <name>AboutBox</name>
    <message>
        <location filename="../about_dialog.py" line="55"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../about_dialog.py" line="79"/>
        <source>The app uses the following third-party modules:</source>
        <translation>Приложение использует следующие сторонние компоненты:</translation>
    </message>
    <message>
        <location filename="../about_dialog.py" line="84"/>
        <source>Package Name</source>
        <translation>Название пакета</translation>
    </message>
    <message>
        <location filename="../about_dialog.py" line="84"/>
        <source>Package Version</source>
        <translation>Версия пакета</translation>
    </message>
</context>
<context>
    <name>SubstanceBox</name>
    <message>
        <location filename="../substances_box.py" line="59"/>
        <source>Search Only For…</source>
        <translation>Искать только…</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="61"/>
        <source>Filter</source>
        <translation>Фильтр</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="72"/>
        <source>Keep substances list selection through filter changes</source>
        <translation>Сохранять выбранные вещества при изменении фильтра</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="73"/>
        <source>Persistent Selection</source>
        <translation>Сохранять выбор</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="75"/>
        <source>Clear substances list selection</source>
        <translation>Очистить список выбранных веществ</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="76"/>
        <source>Select None</source>
        <translation>Очистить выбранное</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="102"/>
        <source>Substance &amp;Info</source>
        <translation>&amp;Информация о веществе</translation>
    </message>
    <message>
        <location filename="../substances_box.py" line="102"/>
        <source>&amp;Select Substance</source>
        <translation>&amp;Выбор вещества</translation>
    </message>
</context>
<context>
    <name>WaitingScreen</name>
    <message>
        <location filename="../waiting_screen.py" line="84"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Отмена</translation>
    </message>
</context>
<context>
    <name>OpenFileDialog</name>
    <message>
        <location filename="../file_dialog.py" line="178"/>
        <source>All supported</source>
        <translation>Все поддерживаемые</translation>
    </message>
</context>
<context>
    <name>UpdateDialog</name>
    <message>
        <location filename="../update_dialog.py" line="31"/>
        <source>Update Catalog</source>
        <translation>Обновить каталог</translation>
    </message>
</context>
<context>
    <name>SubstanceInfoSelector</name>
    <message>
        <location filename="../substance_info.py" line="53"/>
        <source>Select Substance</source>
        <translation>Выбор вещества</translation>
    </message>
    <message>
        <location filename="../substance_info.py" line="86"/>
        <source>Substance &amp;Info</source>
        <translation>&amp;Информация о веществе</translation>
    </message>
</context>
<context>
    <name>ProgressPage</name>
    <message>
        <location filename="../catalog_wizard/progress_page.py" line="22"/>
        <source>Downloading catalog</source>
        <translation>Скачивание каталога</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/progress_page.py" line="33"/>
        <source>%p% (%v out of %m)</source>
        <comment>%p = the percentage. %v = the current value. %m = the total number of steps.</comment>
        <translation>%p% (%v из %m)</translation>
    </message>
</context>
<context>
    <name>SummaryPage</name>
    <message>
        <location filename="../catalog_wizard/summary_page.py" line="21"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/summary_page.py" line="22"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/summary_page.py" line="24"/>
        <source>Click {button_text} to save the catalog for {min_frequency} to {max_frequency}&#xa0;MHz.</source>
        <translation>Нажмите {button_text}, чтобы сохранить каталог для диапазона от {min_frequency} до {max_frequency}&#xa0;МГц.</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/summary_page.py" line="31"/>
        <source>Failure</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/summary_page.py" line="32"/>
        <source>For the specified frequency range, nothing has been loaded.</source>
        <translation>Для указанного диапазона частот ничего не скачано.</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../catalog_wizard/settings_page.py" line="12"/>
        <source>New catalog</source>
        <translation>Новый каталог</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/settings_page.py" line="22"/>
        <location filename="../catalog_wizard/settings_page.py" line="23"/>
        <source></source>
        <comment>spin prefix</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../catalog_wizard/settings_page.py" line="24"/>
        <location filename="../catalog_wizard/settings_page.py" line="25"/>
        <source>&#xa0;MHz</source>
        <comment>spin suffix</comment>
        <translation>&#xa0;МГц</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/settings_page.py" line="26"/>
        <source>Minimal frequency:</source>
        <translation>Частота от:</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/settings_page.py" line="27"/>
        <source>Maximal frequency:</source>
        <translation>Частота до:</translation>
    </message>
</context>
<context>
    <name>SaveCatalogWizard</name>
    <message>
        <location filename="../catalog_wizard/__init__.py" line="56"/>
        <location filename="../catalog_wizard/__init__.py" line="81"/>
        <source>Unable to save the catalog</source>
        <translation>Не удаётся сохранить каталог</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/__init__.py" line="57"/>
        <location filename="../catalog_wizard/__init__.py" line="82"/>
        <source>Error {exception} occurred while saving {filename}. Try another location.</source>
        <translation>При сохранении {filename} произошла ошибка {exception}. Попробуйте другое местоположение.</translation>
    </message>
</context>
<context>
    <name>DownloadConfirmationPage</name>
    <message>
        <location filename="../catalog_wizard/download_confirmation_page.py" line="11"/>
        <source>Downloading catalog</source>
        <translation>Скачивание каталога</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/download_confirmation_page.py" line="20"/>
        <source>&amp;Start</source>
        <translation>&amp;Начать</translation>
    </message>
    <message>
        <location filename="../catalog_wizard/download_confirmation_page.py" line="22"/>
        <source>Click {button_text} to start the download data for {min_frequency} to {max_frequency}&#xa0;MHz.</source>
        <translation>Нажмите {button_text}, чтобы начать скачивание данных для диапазона от {min_frequency} до {max_frequency}&#xa0;МГц.</translation>
    </message>
</context>
<context>
    <name>file type</name>
    <message>
        <location filename="../catalog_file_dialog.py" line="16"/>
        <source>JSON with GZip compression</source>
        <translation>JSON со сжатием GZip</translation>
    </message>
    <message>
        <location filename="../catalog_file_dialog.py" line="21"/>
        <source>JSON with Bzip2 compression</source>
        <translation>JSON со сжатием Bzip2</translation>
    </message>
    <message>
        <location filename="../catalog_file_dialog.py" line="26"/>
        <source>JSON with LZMA2 compression</source>
        <translation>JSON со сжатием LZMA2</translation>
    </message>
    <message>
        <location filename="../catalog_file_dialog.py" line="31"/>
        <source>Tar archive with GZip compression</source>
        <translation>Архив tar со сжатием GZip</translation>
    </message>
    <message>
        <location filename="../catalog_file_dialog.py" line="36"/>
        <source>Tar archive with Bzip2 compression</source>
        <translation>Архив tar со сжатием Bzip2</translation>
    </message>
    <message>
        <location filename="../catalog_file_dialog.py" line="41"/>
        <source>Tar archive with LZMA2 compression</source>
        <translation>Архив tar со сжатием LZMA2</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../preferences.py" line="253"/>
        <source>Preferences</source>
        <translation>Настройки</translation>
    </message>
</context>
<context>
    <name>FrequencySpinBox</name>
    <message>
        <location filename="../frequency_box.py" line="22"/>
        <source>&#xa0;MHz</source>
        <translation>&#xa0;МГц</translation>
    </message>
</context>
<context>
    <name>FrequencyBox</name>
    <message>
        <location filename="../frequency_box.py" line="53"/>
        <source>From:</source>
        <translation>От:</translation>
    </message>
    <message>
        <location filename="../frequency_box.py" line="55"/>
        <source>To:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../frequency_box.py" line="56"/>
        <source>Range</source>
        <translation>Диапазон</translation>
    </message>
    <message>
        <location filename="../frequency_box.py" line="59"/>
        <source>Center:</source>
        <translation>Центр:</translation>
    </message>
    <message>
        <location filename="../frequency_box.py" line="63"/>
        <source>Deviation:</source>
        <translation>Отклонение:</translation>
    </message>
    <message>
        <location filename="../frequency_box.py" line="64"/>
        <source>Center</source>
        <translation>Центр</translation>
    </message>
</context>
<context>
    <name>SourcesList</name>
    <message>
        <location filename="../catalog_info.py" line="48"/>
        <source>Filename</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../catalog_info.py" line="48"/>
        <source>Build Time</source>
        <translation>Дата создания</translation>
    </message>
    <message>
        <location filename="../catalog_info.py" line="60"/>
        <source>Open File &amp;Location</source>
        <translation>&amp;Расположение файла</translation>
    </message>
    <message>
        <location filename="../catalog_info.py" line="65"/>
        <source>&amp;Update Catalog</source>
        <translation>&amp;Обновить каталог</translation>
    </message>
</context>
<context>
    <name>CatalogInfo</name>
    <message>
        <location filename="../catalog_info.py" line="150"/>
        <source>Catalog Info</source>
        <translation>Информация о каталоге</translation>
    </message>
    <message>
        <location filename="../catalog_info.py" line="161"/>
        <source>Frequency limits:</source>
        <translation>Частота:</translation>
    </message>
    <message>
        <location filename="../catalog_info.py" line="166"/>
        <source>{min_frequency} to {max_frequency}&#xa0;MHz</source>
        <translation>от {min_frequency} до {max_frequency}&#xa0;МГц</translation>
    </message>
    <message>
        <location filename="../catalog_info.py" line="175"/>
        <source>Total number of substances:</source>
        <translation>Всего веществ:</translation>
    </message>
</context>
<context>
    <name>SaveCatalogWaitingScreen</name>
    <message>
        <location filename="../save_catalog_waiting_screen.py" line="24"/>
        <location filename="../save_catalog_waiting_screen.py" line="24"/>
        <source>Please wait…</source>
        <translation>Пожалуйста, подождите…</translation>
    </message>
</context>
<context>
    <name>OpenFilePathEntry</name>
    <message>
        <location filename="../open_file_path_entry.py" line="31"/>
        <source>&amp;Browse…</source>
        <translation>&amp;Обзор…</translation>
    </message>
    <message>
        <location filename="../open_file_path_entry.py" line="39"/>
        <source>Translations</source>
        <translation>Файлы перевода</translation>
    </message>
</context>
<context>
    <name>DownloadDialog</name>
    <message>
        <location filename="../download_dialog.py" line="26"/>
        <source>Download Catalog</source>
        <translation>Скачать каталог</translation>
    </message>
</context>
<context>
    <name>MenuBar</name>
    <message>
        <location filename="../menu_bar.py" line="13"/>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="16"/>
        <source>&amp;Load Catalog…</source>
        <translation>&amp;Загрузить каталог…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="21"/>
        <source>&amp;Reload Catalogs</source>
        <translation>&amp;Перезагрузить каталоги</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="28"/>
        <source>&amp;Save Catalog As…</source>
        <translation>&amp;Сохранить каталог как…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="33"/>
        <source>&amp;Download Catalog…</source>
        <translation>&amp;Скачать каталог…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="38"/>
        <source>&amp;Preferences…</source>
        <translation>&amp;Настройки…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="44"/>
        <source>&amp;Quit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="48"/>
        <source>&amp;Edit</source>
        <translation>&amp;Правка</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="51"/>
        <source>Clea&amp;r Results</source>
        <translation>О&amp;чистить результаты</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="54"/>
        <source>Copy &amp;Only</source>
        <translation>Копировать &amp;только</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="55"/>
        <source>Active &amp;Cell</source>
        <translation>Текущую &amp;ячейку</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="57"/>
        <source>&amp;Substance Name</source>
        <translation>&amp;Название вещества</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="58"/>
        <location filename="../menu_bar.py" line="84"/>
        <source>&amp;Frequency</source>
        <translation>&amp;Частоту</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="59"/>
        <location filename="../menu_bar.py" line="85"/>
        <source>&amp;Intensity</source>
        <translation>&amp;Интенсивность</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="61"/>
        <location filename="../menu_bar.py" line="86"/>
        <source>&amp;Lower State Energy</source>
        <translation>&amp;Энергию нижнего уровня</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="64"/>
        <source>&amp;Copy Selection</source>
        <translation>&amp;Копировать выделенное</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="68"/>
        <source>Select &amp;All</source>
        <translation>&amp;Выделить всё</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="78"/>
        <source>Substance &amp;Info</source>
        <translation>&amp;Информация о веществе</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="82"/>
        <source>&amp;Columns</source>
        <translation>&amp;Отображать</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="83"/>
        <source>&amp;Substance</source>
        <translation>&amp;Вещество</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="88"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="90"/>
        <source>Check for &amp;Updates…</source>
        <translation>Проверить наличие об&amp;новлений…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="94"/>
        <source>About &amp;Catalogs…</source>
        <translation>О &amp;каталогах…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="98"/>
        <source>&amp;About…</source>
        <translation>&amp;О программе…</translation>
    </message>
    <message>
        <location filename="../menu_bar.py" line="102"/>
        <source>About &amp;Qt…</source>
        <translation>О &amp;Qt…</translation>
    </message>
</context>
</TS>
