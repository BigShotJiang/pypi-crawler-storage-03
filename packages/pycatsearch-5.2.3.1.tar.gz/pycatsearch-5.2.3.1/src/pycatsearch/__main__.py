#!/usr/bin/env python3

if __name__ == "__main__":
    from . import main_gui as main

    exit(main())
