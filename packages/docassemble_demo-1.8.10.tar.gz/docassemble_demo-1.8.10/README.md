See the [docassemble web site] for a description of **docassemble**
and installation instructions.

To get help with using **docassemble**, join the [docassemble Slack
group].

[docassemble web site]: https://docassemble.org
[docassemble Slack group]: https://docassemble.org/docs/support.html
