#!/usr/bin/env python3
"""Entry point for jupyter-mcp when run as a module or via pipx"""

from mcp_jupyter_server_fast import main

if __name__ == "__main__":
    main()