"""Top-level package for ASSET Lab Resource Adequacy Model."""
# use date of release for versioning
__version__ = "2025.08.20"
