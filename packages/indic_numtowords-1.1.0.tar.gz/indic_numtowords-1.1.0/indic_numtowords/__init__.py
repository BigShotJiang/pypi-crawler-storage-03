__version__ = "1.0.0"
__author__ = 'Mohammed Safi Ur Rahman Khan <safikhan2000@gmail.com>'
__credits__ = 'AI4Bharat'

from .numtowords import num2words, supported_langs