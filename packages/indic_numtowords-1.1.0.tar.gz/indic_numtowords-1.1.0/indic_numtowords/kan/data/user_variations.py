variations = {
    101 : ['ನೂರಾ ಒಂದು']
}