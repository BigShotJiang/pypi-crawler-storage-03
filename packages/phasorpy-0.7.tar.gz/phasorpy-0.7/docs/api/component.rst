phasorpy.component
------------------

.. automodule:: phasorpy.component
    :members:
