phasorpy.lifetime
-----------------

.. automodule:: phasorpy.lifetime
    :members:
