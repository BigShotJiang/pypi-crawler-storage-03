phasorpy.cursor
---------------

.. automodule:: phasorpy.cursor
    :members:
