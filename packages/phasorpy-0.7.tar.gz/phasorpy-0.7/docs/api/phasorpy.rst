phasorpy
--------

.. automodule:: phasorpy
    :members:
    :special-members: __version__
