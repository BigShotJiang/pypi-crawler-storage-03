phasorpy._utils
---------------

.. note::
    This module and its functions are not part of the public interface.
    They are intended to facilitate the development of the PhasorPy library.

.. automodule:: phasorpy._utils
    :members:
