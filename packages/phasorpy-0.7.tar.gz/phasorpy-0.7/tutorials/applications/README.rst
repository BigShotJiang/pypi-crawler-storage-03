Applications
------------

Problem-oriented how-to guides for advanced applications:
