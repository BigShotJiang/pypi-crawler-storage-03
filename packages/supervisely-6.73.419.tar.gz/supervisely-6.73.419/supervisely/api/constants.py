# coding: utf-8

DOWNLOAD_BATCH_SIZE = None

# for Video Labeling Toolbox
PLAYBACK_RATE_POSSIBLE_VALUES = [
    0.1,
    0.3,
    0.5,
    0.6,
    0.7,
    0.8,
    0.9,
    1,
    1.1,
    1.2,
    1.3,
    1.5,
    2,
    4,
    8,
    16,
    32,
]
