"""Web application for OnPrem"""

from . import utils
from . import pages
from .OnPrem import read_config, write_default_yaml
