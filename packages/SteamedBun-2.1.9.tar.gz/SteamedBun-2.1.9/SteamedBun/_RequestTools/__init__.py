"""
@Author: 馒头 (chocolate)
@Email: neihanshenshou@163.com
@File: __init__.py
@Time: 2023/12/9 18:00
"""
from .HttpRequest import delete
from .HttpRequest import get
from .HttpRequest import head
from .HttpRequest import options
from .HttpRequest import patch
from .HttpRequest import post
from .HttpRequest import put
from .HttpRequest import request
