"""
Initialisiert das `tests`-Paket, damit absolute Importe wie
`from tests.chaos...` während der Testausführung funktionieren.
"""
