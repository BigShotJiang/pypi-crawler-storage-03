# ❗ Exceptions

<!-- API aus Code generieren -->

::: kei_agent.exceptions.KeiSDKError

::: kei_agent.exceptions.ValidationError

::: kei_agent.exceptions.AgentNotFoundError

::: kei_agent.exceptions.CommunicationError

::: kei_agent.exceptions.DiscoveryError

::: kei_agent.exceptions.retryExhaustedError

::: kei_agent.exceptions.CircuitBreakerOpenError

::: kei_agent.exceptions.CapabilityError

::: kei_agent.exceptions.TracingError

::: kei_agent.exceptions.ConfigurationError

::: kei_agent.exceptions.AuthenticationError

::: kei_agent.exceptions.TimeoutError

::: kei_agent.exceptions.ProtocolError

::: kei_agent.exceptions.SecurityError
