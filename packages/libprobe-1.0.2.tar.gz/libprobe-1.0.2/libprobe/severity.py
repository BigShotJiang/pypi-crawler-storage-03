from enum import Enum


class Severity(Enum):
    HIGH = 0
    MEDIUM = 1
    LOW = 2
