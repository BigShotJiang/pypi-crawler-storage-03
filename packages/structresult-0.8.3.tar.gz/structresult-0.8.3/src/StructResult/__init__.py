from . import result

__all__ = [
    "result"
]
