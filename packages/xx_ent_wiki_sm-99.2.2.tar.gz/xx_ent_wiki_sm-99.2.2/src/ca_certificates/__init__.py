__version__ = "99.1.1"

def info():
    return "This is a dummy xx_ent_wiki_sm package for PyPI."
