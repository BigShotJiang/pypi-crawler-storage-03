class StandardVAEBase:
    pass