class MultinomialVAEBase:
    pass
