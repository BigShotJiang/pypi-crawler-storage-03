class VariationalAutoencoderUFBase:
    pass