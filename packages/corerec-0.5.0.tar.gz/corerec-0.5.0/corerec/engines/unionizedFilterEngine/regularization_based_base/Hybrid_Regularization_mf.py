class HybridRegularizationMF :
    pass