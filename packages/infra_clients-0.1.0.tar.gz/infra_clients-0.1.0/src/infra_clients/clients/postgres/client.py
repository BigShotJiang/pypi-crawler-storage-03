from contextlib import asynccontextmanager

from sqlalchemy import URL
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine


class Postgres:
    __instance = None
    __initialized = False

    def __new__(cls, *args, **kwargs):
        if cls.__instance:
            return cls.__instance
        else:
            cls.__instance = super().__new__(cls)
            return cls.__instance

    def __init__(
        self, host: str, username: str, password: str, database: str, port: int
    ):
        if not self.__initialized:
            url = URL.create(
                drivername="postgresql+asyncpg",
                host=host,
                username=username,
                password=password,
                database=database,
                port=port,
            )
            self.engine = create_async_engine(url=url)
            self.session_maker = async_sessionmaker(bind=self.engine)
            self.__initialized = True

    @asynccontextmanager
    async def get_session(self):
        session = self.session_maker()
        try:
            yield session
        finally:
            await session.close()
