def main() -> None:
    print("Hello from infra-clients!")
