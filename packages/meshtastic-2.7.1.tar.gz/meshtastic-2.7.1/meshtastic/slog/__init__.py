"""Structured logging framework (see dev docs for more info)."""

from .slog import LogSet, root_dir
