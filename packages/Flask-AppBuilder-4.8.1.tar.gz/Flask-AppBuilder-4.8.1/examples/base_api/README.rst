Base Api example
----------------

Simple example showing how to use *BaseApi* class

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask run

For Swagger view go to: http://localhost:5000/swagger/v1
