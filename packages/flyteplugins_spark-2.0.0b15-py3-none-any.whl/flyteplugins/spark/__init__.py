__all__ = ["Spark"]

from flyteplugins.spark.task import Spark
