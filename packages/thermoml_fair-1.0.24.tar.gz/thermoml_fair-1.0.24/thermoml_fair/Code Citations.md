# Code Citations

## License: unknown
https://github.com/pmoracho/padrondl/blob/8861c3de577e57e85507c30077b0d4680aa2d437/tabulate.py

```
(),
    tablefmt
```


## License: unknown
https://github.com/irmu/moria/blob/a9d455085a50620ac94311061b635a543b2a9b5d/repo/script.module.tabulate/lib/tabulate/__init__.py

```
(),
    tablefmt
```


## License: unknown
https://github.com/pmoracho/padrondl/blob/8861c3de577e57e85507c30077b0d4680aa2d437/tabulate.py

```
(),
    tablefmt="simple",
    floatfmt=_DEFAULT_FLOATFMT,
    intfmt=_DEFAULT_INTFMT,
    numalign=_DEFAULT_ALIGN,
    stralign=_DEFAULT_ALIGN,
    missingval=_DEFAULT_MISSINGVAL,
    showindex="default",
    disable
```


## License: unknown
https://github.com/irmu/moria/blob/a9d455085a50620ac94311061b635a543b2a9b5d/repo/script.module.tabulate/lib/tabulate/__init__.py

```
(),
    tablefmt="simple",
    floatfmt=_DEFAULT_FLOATFMT,
    intfmt=_DEFAULT_INTFMT,
    numalign=_DEFAULT_ALIGN,
    stralign=_DEFAULT_ALIGN,
    missingval=_DEFAULT_MISSINGVAL,
    showindex="default",
    disable
```


## License: unknown
https://github.com/pmoracho/padrondl/blob/8861c3de577e57e85507c30077b0d4680aa2d437/tabulate.py

```
(),
    tablefmt="simple",
    floatfmt=_DEFAULT_FLOATFMT,
    intfmt=_DEFAULT_INTFMT,
    numalign=_DEFAULT_ALIGN,
    stralign=_DEFAULT_ALIGN,
    missingval=_DEFAULT_MISSINGVAL,
    showindex="default",
    disable_numparse=False,
    colalign=None,
    maxcolwidths=None,
    rowalign=None,
    maxheadercolwidths=None,
):
    """Format
```


## License: unknown
https://github.com/irmu/moria/blob/a9d455085a50620ac94311061b635a543b2a9b5d/repo/script.module.tabulate/lib/tabulate/__init__.py

```
(),
    tablefmt="simple",
    floatfmt=_DEFAULT_FLOATFMT,
    intfmt=_DEFAULT_INTFMT,
    numalign=_DEFAULT_ALIGN,
    stralign=_DEFAULT_ALIGN,
    missingval=_DEFAULT_MISSINGVAL,
    showindex="default",
    disable_numparse=False,
    colalign=None,
    maxcolwidths=None,
    rowalign=None,
    maxheadercolwidths=None,
):
    """Format
```

