"""Task support for the ETL workflow"""

from .base import EntryIterator, EtlTask, OutputTable
from .nlp_task import BaseNlpTask, BaseOpenAiTask, BaseOpenAiTaskWithSpans
