_code_components:

Geometries Module
-----------------

.. automodule:: FiberFusing.geometries
    :members:
    :inherited-members:
    :member-order: bysource

