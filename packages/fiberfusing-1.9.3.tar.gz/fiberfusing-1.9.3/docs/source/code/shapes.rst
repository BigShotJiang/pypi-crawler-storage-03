.. _code_buffer:

Shape Module
------------

.. automodule:: FiberFusing.shapes
    :members:
    :inherited-members:
    :member-order: bysource
