"""
Generalized Propensity Score (GPS) method for continuous treatments.
""" 