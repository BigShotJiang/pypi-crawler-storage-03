class LoginException(Exception):
    pass


class UploadException(Exception):
    pass
