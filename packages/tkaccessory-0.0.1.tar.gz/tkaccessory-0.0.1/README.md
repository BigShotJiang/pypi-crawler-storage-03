# TkAccessory

To download ,and use this package : `pip install TkAccessory`

Use TkAccessory tools to make your client interface more better

TkAccessory provides you the best modules to customize your gui

![Progress bars](https://github.com/SingleStar2023/TkAccessory/blob/progress-samples/TkToolsProgress.gif?raw=true)

![Loading styles](https://github.com/SingleStar2023/TkAccessory/blob/loading-samples/TkToolsLoading.gif?raw=true)

### Single Star
### Seyed Moied Seyedi 