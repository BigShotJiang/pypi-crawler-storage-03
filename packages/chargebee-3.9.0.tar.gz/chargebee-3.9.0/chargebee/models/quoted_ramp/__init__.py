from .operations import QuotedRamp
from .responses import QuotedRampResponse
