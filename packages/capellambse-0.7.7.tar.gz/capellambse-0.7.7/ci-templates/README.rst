..
   SPDX-FileCopyrightText: Copyright DB InfraGO AG
   SPDX-License-Identifier: Apache-2.0

Supported instances
===================

- Gitlab CI/CD (`More information <./gitlab/README.rst>`_)
- Github Actions (`More information <./github/README.rst>`_)
