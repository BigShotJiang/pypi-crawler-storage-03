"""Builder.io Unofficial Python SDK"""

__all__ = ["make_greeting"]

from ._builder_io import make_greeting
