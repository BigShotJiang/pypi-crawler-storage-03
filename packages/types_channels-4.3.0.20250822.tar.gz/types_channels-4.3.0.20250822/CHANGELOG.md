## 4.3.0.20250822 (2025-08-22)

Add missing defaults to third-party stubs ([#14617](https://github.com/python/typeshed/pull/14617))

## 4.3.0.20250730 (2025-07-30)

[channels] Bump to `4.3.*` (#14490)

## 4.2.0.20250712 (2025-07-12)

Django channels stubs (#13939)

