__version_info__ = (2025, 8, 23)
__version__ = ".".join(str(e) for e in __version_info__)
