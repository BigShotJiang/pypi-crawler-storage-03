# !!! WiP !!! Android idle bypass script by (pussious) cfati

import sys


def simulate(verbose=False):
    print("Platform not supported!")
    sys.exit(-1)


if __name__ == "__main__":
    print("This script is not meant to be run directly.\n")
    sys.exit(-1)
