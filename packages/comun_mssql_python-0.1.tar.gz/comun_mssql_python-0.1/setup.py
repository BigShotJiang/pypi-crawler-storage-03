from setuptools import setup

setup(name='comun_mssql_python',
      version='0.1',
      py_modules=['comun_mssql_python'],
      install_requires=['mssql_python'])
