from sigexport import utils


def test_source_location():
    utils.source_location()
