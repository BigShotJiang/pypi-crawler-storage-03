from sigexport.main import cli

cli()
