class UtcpSerializerValidationError(Exception):
    """Exception raised when a serializer validation fails."""
