For define the secondary units, you should active *Manage multiples
units of measure* on the user that will be responsable of this function.
