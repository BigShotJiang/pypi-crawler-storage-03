This module extends the functionality of saleorder_secondary_unit module
to allow sell products in online store in secondary units defined.
