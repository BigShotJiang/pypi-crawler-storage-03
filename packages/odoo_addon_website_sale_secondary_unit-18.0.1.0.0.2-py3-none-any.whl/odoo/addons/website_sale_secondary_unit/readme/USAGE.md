To use this module you need to:

- Go to *'Website \> Products \> Products'*.
- Select a template.
- Set the secondary units that you need.
- Go to Website Shop and buy this product, you will see a selectable
  option with all secondary units defined in the product and visible in
  website.
- If you do not want to sell in a base product unit and only allow sell
  in a secondary unit you can disable the option *'Allow to sell in unit
  of measure'* in a product sale tab.
