#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#

azure_storage_account_name_key_name = "storage_account_name"
azure_storage_access_key_key_name = "storage_access_key"
azure_storage_endpoint_suffix_key_name = "storage_endpoint_suffix"
results_per_page = 999
table_name_regex = "^[a-z0-9](?!.*--)[a-z0-9-]{1,61}[a-z0-9]$"
