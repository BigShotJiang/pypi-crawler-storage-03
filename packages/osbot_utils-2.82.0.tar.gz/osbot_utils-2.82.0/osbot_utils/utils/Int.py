def int_is_even(number):
    return number % 2 == 0

def int_is_odd(number):
    return int_is_even(number) is False