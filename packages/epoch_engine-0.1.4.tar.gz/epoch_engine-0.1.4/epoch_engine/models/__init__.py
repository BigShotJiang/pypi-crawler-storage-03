# Author: Sergey Polivin <s.polivin@gmail.com>
# License: MIT License

# ruff: noqa: F401

from .architectures import BasicBlock, EDNet, ResNet
