# Author: Sergey Polivin <s.polivin@gmail.com>
# License: MIT License

# ruff: noqa: F401

from .trainer import Trainer
