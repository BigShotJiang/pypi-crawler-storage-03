# pylint: disable=missing-module-docstring, missing-final-newline
VERSION = "4.0.340"