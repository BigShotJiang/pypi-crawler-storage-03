

"""
Doopal AI Governance Python SDK

A Python client library that wraps LLM API calls and routes them through Doopal
for governance, redaction, and policy enforcement.
"""

import asyncio
import json
import logging
from enum import Enum
from typing import Any, AsyncGenerator, Dict, List, Optional, Union

import httpx
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class LLMProvider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    AZURE_OPENAI = "azure_openai"
    COHERE = "cohere"
    HUGGINGFACE = "huggingface"


class ChatMessage(BaseModel):
    role: str
    content: str


class DoopalRequest(BaseModel):
    provider: LLMProvider
    model: str
    messages: List[ChatMessage]
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    stream: bool = False
    metadata: Optional[Dict[str, Any]] = None


class DoopalResponse(BaseModel):
    response: Optional[str] = None
    provider: str
    model: str
    usage: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None
    redacted_content: Optional[List[str]] = None
    embeddings: Optional[List[List[float]]] = None


class DoopalError(Exception):
    """Base exception for Doopal SDK errors"""

    pass


class PolicyViolationError(DoopalError):
    """Raised when a request violates governance policies"""

    pass


class RedactionError(DoopalError):
    """Raised when content is blocked due to redaction rules"""

    pass


class DoopalClient:
    """
    Doopal AI Governance Python Client

    This client wraps LLM API calls and routes them through Doopal for
    governance, redaction, and policy enforcement.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.doopal.com",
        timeout: int = 30,
        max_retries: int = 3,
        organization_id: Optional[str] = None,
    ):
        """
        Initialize Doopal client

        Args:
            api_key: Your Doopal API key
            base_url: Doopal gateway base URL
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            organization_id: Optional organization ID for multi-tenant setups
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.organization_id = organization_id

        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout), headers=self._get_default_headers()
        )

    def _get_default_headers(self) -> Dict[str, str]:
        """Get default headers for requests"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "doopal-python-sdk/1.1.0",
        }

        if self.organization_id:
            headers["X-Organization-ID"] = self.organization_id

        return headers

    async def openai_chat_completions(
        self,
        model: str,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/v1/chat/completions"
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        try:
            resp = await self.client.post(url, json=payload, headers=self._get_default_headers())
            if resp.status_code != 200:
                raise DoopalError(f"OpenAI-compat error: {resp.status_code} - {resp.text}")
            return resp.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Request failed: {e}")
    async def openai_list_models(self) -> Dict[str, Any]:
        url = f"{self.base_url}/v1/models"
        try:
            resp = await self.client.get(url, headers=self._get_default_headers())
            if resp.status_code != 200:
                raise DoopalError(f"OpenAI-compat error: {resp.status_code} - {resp.text}")
            return resp.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Request failed: {e}")


    async def openai_embeddings(
        self,
        model: str,
        input_texts: List[str],
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/v1/embeddings"
        payload = {
            "model": model,
            "input": input_texts,
        }
        try:
            resp = await self.client.post(url, json=payload, headers=self._get_default_headers())
            if resp.status_code != 200:
                raise DoopalError(f"OpenAI-compat error: {resp.status_code} - {resp.text}")
            return resp.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Request failed: {e}")

    async def chat_completion(
        self,
        provider: Union[str, LLMProvider],
        model: str,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs,
    ) -> Union[DoopalResponse, AsyncGenerator[str, None]]:
        """
        Create a chat completion through Doopal governance

        Args:
            provider: LLM provider (openai, anthropic, etc.)
            model: Model name (e.g., gpt-3.5-turbo, claude-3-sonnet)
            messages: List of chat messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the response
            **kwargs: Additional parameters

        Returns:
            DoopalResponse or async generator for streaming

        Raises:
            PolicyViolationError: If request violates policies
            RedactionError: If content is blocked by redaction
            DoopalError: For other API errors
        """
        chat_messages = [
            ChatMessage(role=msg["role"], content=msg["content"]) for msg in messages
        ]
 
        request = DoopalRequest(
            provider=LLMProvider(provider) if isinstance(provider, str) else provider,
            model=model,
            messages=chat_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            metadata=kwargs.get("metadata", {}),
        )

        if stream:
            return self._stream_chat_completion(request)
        else:
            return await self._chat_completion(request)

    async def _chat_completion(self, request: DoopalRequest) -> DoopalResponse:
        """Internal method for non-streaming chat completion"""
        url = f"{self.base_url}/gateway/chat"

        try:
            response = await self.client.post(
                url, json=request.model_dump(), headers=self._get_default_headers()
            )

            if response.status_code == 403:
                error_detail = response.json().get("detail", "Policy violation")
                raise PolicyViolationError(error_detail)
            elif response.status_code == 400:
                error_detail = response.json().get("detail", "Bad request")
                if "blocked due to sensitive content" in error_detail:
                    raise RedactionError(error_detail)
                raise DoopalError(error_detail)
            elif response.status_code != 200:
                raise DoopalError(
                    f"API error: {response.status_code} - {response.text}"
                )

            response_data = response.json()
            return DoopalResponse(**response_data)

        except httpx.RequestError as e:
            raise DoopalError(f"Request failed: {e}")
        except json.JSONDecodeError as e:
            raise DoopalError(f"Invalid JSON response: {e}")

    async def _stream_chat_completion(
        self, request: DoopalRequest
    ) -> AsyncGenerator[str, None]:
        """Internal method for streaming chat completion"""
        url = f"{self.base_url}/gateway/chat"

        try:
            async with self.client.stream(
                "POST",
                url,
                json=request.model_dump(),
                headers=self._get_default_headers(),
            ) as response:

                if response.status_code == 403:
                    error_detail = (await response.aread()).decode()
                    raise PolicyViolationError(error_detail)
                elif response.status_code == 400:
                    error_detail = (await response.aread()).decode()
                    if "blocked due to sensitive content" in error_detail:
                        raise RedactionError(error_detail)
                    raise DoopalError(error_detail)
                elif response.status_code != 200:
                    error_detail = (await response.aread()).decode()
                    raise DoopalError(
                        f"API error: {response.status_code} - {error_detail}"
                    )

                async for chunk in response.aiter_text():
                    if chunk.strip():
                        yield chunk

        except httpx.RequestError as e:
            raise DoopalError(f"Streaming request failed: {e}")

    async def completion(
        self,
        provider: Union[str, LLMProvider],
        model: str,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> DoopalResponse:
        """
        Create a text completion through Doopal governance

        Args:
            provider: LLM provider
            model: Model name
            prompt: Input prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters

        Returns:
            DoopalResponse
        """
        messages = [{"role": "user", "content": prompt}]
        return await self.chat_completion(
            provider=provider,
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )

    async def embeddings(
        self,
        provider: Union[str, LLMProvider],
        model: str,
        input_text: Union[str, List[str]],
        **kwargs,
    ) -> DoopalResponse:
        """
        Create embeddings through Doopal governance

        Args:
            provider: LLM provider
            model: Model name
            input_text: Text or list of texts to embed
            **kwargs: Additional parameters

        Returns:
            DoopalResponse with embeddings
        """
        url = f"{self.base_url}/gateway/embeddings"

        request_data = {
            "provider": provider,
            "model": model,
            "input": input_text,
            "metadata": kwargs.get("metadata", {}),
        }

        try:
            response = await self.client.post(
                url, json=request_data, headers=self._get_default_headers()
            )

            if response.status_code == 403:
                error_detail = response.json().get("detail", "Policy violation")
                raise PolicyViolationError(error_detail)
            elif response.status_code != 200:
                raise DoopalError(
                    f"API error: {response.status_code} - {response.text}"
                )

            response_data = response.json()
            return DoopalResponse(**response_data)

        except httpx.RequestError as e:
            raise DoopalError(f"Request failed: {e}")

    async def get_usage_stats(self) -> Dict[str, Any]:
        """Get usage statistics for the current API key"""
        url = f"{self.base_url}/gateway/stats"

        try:
            response = await self.client.get(url, headers=self._get_default_headers())

            if response.status_code != 200:
                raise DoopalError(
                    f"API error: {response.status_code} - {response.text}"
                )

            return response.json()

        except httpx.RequestError as e:
            raise DoopalError(f"Request failed: {e}")

    async def health_check(self) -> Dict[str, Any]:
        """Check Doopal gateway health"""
        url = f"{self.base_url}/gateway/health"

        try:
            response = await self.client.get(url)

            if response.status_code != 200:
                raise DoopalError(f"Health check failed: {response.status_code}")

            return response.json()

        except httpx.RequestError as e:
            raise DoopalError(f"Health check failed: {e}")
    
    async def get_detailed_health(self) -> Dict[str, Any]:
        """Get comprehensive system health status"""
        url = f"{self.base_url}/health/detailed"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Detailed health check failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Detailed health check failed: {e}")
    
    async def get_readiness_status(self) -> Dict[str, Any]:
        """Check service readiness for Kubernetes probes"""
        url = f"{self.base_url}/health/ready"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Readiness check failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Readiness check failed: {e}")
    
    async def get_liveness_status(self) -> Dict[str, Any]:
        """Check service liveness for Kubernetes probes"""
        url = f"{self.base_url}/health/live"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Liveness check failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Liveness check failed: {e}")
    
    # ENTERPRISE FEATURES
    
    async def get_organization(self) -> Dict[str, Any]:
        """Get organization information"""
        url = f"{self.base_url}/enterprise/organizations/current"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get organization failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get organization failed: {e}")
    
    async def update_organization(self, settings: Dict[str, Any]) -> Dict[str, Any]:
        """Update organization settings"""
        url = f"{self.base_url}/enterprise/organizations/current"
        try:
            response = await self.client.patch(url, json=settings, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Update organization failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Update organization failed: {e}")
    
    async def get_user_roles(self) -> Dict[str, Any]:
        """Get user roles and permissions"""
        url = f"{self.base_url}/enterprise/roles/user"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get user roles failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get user roles failed: {e}")
    
    async def get_organization_members(self) -> List[Dict[str, Any]]:
        """Get organization members and their roles"""
        url = f"{self.base_url}/enterprise/organizations/members"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get organization members failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get organization members failed: {e}")
    
    async def invite_user(self, invitation: Dict[str, Any]) -> Dict[str, Any]:
        """Invite user to organization"""
        url = f"{self.base_url}/enterprise/organizations/invite"
        try:
            response = await self.client.post(url, json=invitation, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Invite user failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Invite user failed: {e}")
    
    async def configure_sso(self, sso_config: Dict[str, Any]) -> Dict[str, Any]:
        """Configure SSO settings"""
        url = f"{self.base_url}/enterprise/sso/configure"
        try:
            response = await self.client.post(url, json=sso_config, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Configure SSO failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Configure SSO failed: {e}")
    
    async def get_audit_logs(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get audit logs for the organization"""
        url = f"{self.base_url}/enterprise/audit/logs"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get audit logs failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get audit logs failed: {e}")
    
    # ADVANCED ANALYTICS
    
    async def get_compliance_analytics(self, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get advanced compliance analytics"""
        url = f"{self.base_url}/api/analytics/advanced/compliance"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get compliance analytics failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get compliance analytics failed: {e}")
    
    async def get_threat_analytics(self, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get threat detection analytics"""
        url = f"{self.base_url}/api/analytics/advanced/threats"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get threat analytics failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get threat analytics failed: {e}")
    
    async def get_performance_analytics(self, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get performance analytics"""
        url = f"{self.base_url}/api/analytics/advanced/performance"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get performance analytics failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get performance analytics failed: {e}")
    
    async def get_cost_analytics(self, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get cost analytics"""
        url = f"{self.base_url}/api/analytics/advanced/costs"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get cost analytics failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get cost analytics failed: {e}")
    
    # COMPLIANCE REPORTING
    
    async def get_compliance_status(self, framework: str = "all") -> Dict[str, Any]:
        """Get compliance status report"""
        url = f"{self.base_url}/api/compliance/status/{framework}"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get compliance status failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get compliance status failed: {e}")
    
    async def generate_compliance_report(self, report_config: Dict[str, Any]) -> Dict[str, Any]:
        """Generate compliance report"""
        url = f"{self.base_url}/api/compliance/reports/generate"
        try:
            response = await self.client.post(url, json=report_config, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Generate compliance report failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Generate compliance report failed: {e}")
    
    async def get_compliance_violations(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get compliance violations"""
        url = f"{self.base_url}/api/compliance/violations"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get compliance violations failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get compliance violations failed: {e}")
    
    # POLICY MANAGEMENT
    
    async def get_policies(self) -> List[Dict[str, Any]]:
        """Get all policies"""
        url = f"{self.base_url}/api/policies"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get policies failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get policies failed: {e}")
    
    async def create_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new policy"""
        url = f"{self.base_url}/api/policies"
        try:
            response = await self.client.post(url, json=policy, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Create policy failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Create policy failed: {e}")
    
    async def update_policy(self, policy_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing policy"""
        url = f"{self.base_url}/api/policies/{policy_id}"
        try:
            response = await self.client.patch(url, json=updates, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Update policy failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Update policy failed: {e}")
    
    async def delete_policy(self, policy_id: str) -> Dict[str, Any]:
        """Delete a policy"""
        url = f"{self.base_url}/api/policies/{policy_id}"
        try:
            response = await self.client.delete(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Delete policy failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Delete policy failed: {e}")
    
    async def test_policy(self, test_config: Dict[str, Any]) -> Dict[str, Any]:
        """Test a policy against input"""
        url = f"{self.base_url}/api/policies/test"
        try:
            response = await self.client.post(url, json=test_config, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Test policy failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Test policy failed: {e}")
    
    # PROVIDER MANAGEMENT
    
    async def get_providers(self) -> List[Dict[str, Any]]:
        """Get available AI providers"""
        url = f"{self.base_url}/api/providers"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get providers failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get providers failed: {e}")
    
    async def add_provider(self, provider: Dict[str, Any]) -> Dict[str, Any]:
        """Add new AI provider"""
        url = f"{self.base_url}/api/providers"
        try:
            response = await self.client.post(url, json=provider, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Add provider failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Add provider failed: {e}")
    
    async def update_provider(self, provider_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update AI provider configuration"""
        url = f"{self.base_url}/api/providers/{provider_id}"
        try:
            response = await self.client.patch(url, json=updates, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Update provider failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Update provider failed: {e}")
    
    # SECURITY & MONITORING
    
    async def get_security_threats(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get security threats detection data"""
        url = f"{self.base_url}/api/security/threats"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get security threats failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get security threats failed: {e}")
    
    async def get_observability_metrics(self, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get observability metrics"""
        url = f"{self.base_url}/api/observability/metrics"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get observability metrics failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get observability metrics failed: {e}")
    
    async def get_alerts(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get system alerts"""
        url = f"{self.base_url}/api/observability/alerts"
        if filters:
            params = "&".join([f"{k}={v}" for k, v in filters.items()])
            url = f"{url}?{params}"
        
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get alerts failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get alerts failed: {e}")
    
    # INTEGRATIONS
    
    async def get_integrations(self) -> List[Dict[str, Any]]:
        """Get available integrations"""
        url = f"{self.base_url}/api/integrations"
        try:
            response = await self.client.get(url, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Get integrations failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Get integrations failed: {e}")
    
    async def configure_integration(self, integration: Dict[str, Any]) -> Dict[str, Any]:
        """Configure integration"""
        url = f"{self.base_url}/api/integrations/configure"
        try:
            response = await self.client.post(url, json=integration, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Configure integration failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Configure integration failed: {e}")
    
    # STRUCTURED DATA VALIDATION
    
    async def validate_structured_data(self, validation_config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate structured data output"""
        url = f"{self.base_url}/api/validators/structured-data"
        try:
            response = await self.client.post(url, json=validation_config, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Validate structured data failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Validate structured data failed: {e}")
    
    async def validate_pii(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Validate PII detection"""
        url = f"{self.base_url}/api/validators/pii"
        try:
            response = await self.client.post(url, json=content, headers=self._get_default_headers())
            if response.status_code != 200:
                raise DoopalError(f"Validate PII failed: {response.status_code}")
            return response.json()
        except httpx.RequestError as e:
            raise DoopalError(f"Validate PII failed: {e}")

    async def close(self):
        """Close the HTTP client"""
        await self.client.aclose()

    async def __aenter__(self):
        """Async context manager entry"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()


class DoopalSyncClient:
    """Synchronous wrapper for DoopalClient"""

    def __init__(self, *args, **kwargs):
        self._async_client = DoopalClient(*args, **kwargs)

    def chat_completion(self, *args, **kwargs):
        """Synchronous chat completion"""
        return asyncio.run(self._async_client.chat_completion(*args, **kwargs))

    def completion(self, *args, **kwargs):
        """Synchronous completion"""
        return asyncio.run(self._async_client.completion(*args, **kwargs))

    def embeddings(self, *args, **kwargs):
        """Synchronous embeddings"""
        return asyncio.run(self._async_client.embeddings(*args, **kwargs))

    def get_usage_stats(self):
        """Synchronous usage stats"""
        return asyncio.run(self._async_client.get_usage_stats())

    def health_check(self):
        """Synchronous health check"""
        return asyncio.run(self._async_client.health_check())
    
    def get_detailed_health(self):
        """Synchronous detailed health check"""
        return asyncio.run(self._async_client.get_detailed_health())
    
    def get_readiness_status(self):
        """Synchronous readiness check"""
        return asyncio.run(self._async_client.get_readiness_status())
    
    def get_liveness_status(self):
        """Synchronous liveness check"""
        return asyncio.run(self._async_client.get_liveness_status())
    
    # Enterprise features sync wrappers
    def get_organization(self):
        return asyncio.run(self._async_client.get_organization())
    
    def update_organization(self, settings):
        return asyncio.run(self._async_client.update_organization(settings))
    
    def get_user_roles(self):
        return asyncio.run(self._async_client.get_user_roles())
    
    def get_organization_members(self):
        return asyncio.run(self._async_client.get_organization_members())
    
    def invite_user(self, invitation):
        return asyncio.run(self._async_client.invite_user(invitation))
    
    def configure_sso(self, sso_config):
        return asyncio.run(self._async_client.configure_sso(sso_config))
    
    def get_audit_logs(self, filters=None):
        return asyncio.run(self._async_client.get_audit_logs(filters))
    
    # Analytics sync wrappers
    def get_compliance_analytics(self, filters=None):
        return asyncio.run(self._async_client.get_compliance_analytics(filters))
    
    def get_threat_analytics(self, filters=None):
        return asyncio.run(self._async_client.get_threat_analytics(filters))
    
    def get_performance_analytics(self, filters=None):
        return asyncio.run(self._async_client.get_performance_analytics(filters))
    
    def get_cost_analytics(self, filters=None):
        return asyncio.run(self._async_client.get_cost_analytics(filters))
    
    # Compliance sync wrappers
    def get_compliance_status(self, framework="all"):
        return asyncio.run(self._async_client.get_compliance_status(framework))
    
    def generate_compliance_report(self, report_config):
        return asyncio.run(self._async_client.generate_compliance_report(report_config))
    
    def get_compliance_violations(self, filters=None):
        return asyncio.run(self._async_client.get_compliance_violations(filters))
    
    # Policy management sync wrappers
    def get_policies(self):
        return asyncio.run(self._async_client.get_policies())
    
    def create_policy(self, policy):
        return asyncio.run(self._async_client.create_policy(policy))
    
    def update_policy(self, policy_id, updates):
        return asyncio.run(self._async_client.update_policy(policy_id, updates))
    
    def delete_policy(self, policy_id):
        return asyncio.run(self._async_client.delete_policy(policy_id))
    
    def test_policy(self, test_config):
        return asyncio.run(self._async_client.test_policy(test_config))
    
    # Provider management sync wrappers
    def get_providers(self):
        return asyncio.run(self._async_client.get_providers())
    
    def add_provider(self, provider):
        return asyncio.run(self._async_client.add_provider(provider))
    
    def update_provider(self, provider_id, updates):
        return asyncio.run(self._async_client.update_provider(provider_id, updates))
    
    # Security sync wrappers
    def get_security_threats(self, filters=None):
        return asyncio.run(self._async_client.get_security_threats(filters))
    
    def get_observability_metrics(self, filters=None):
        return asyncio.run(self._async_client.get_observability_metrics(filters))
    
    def get_alerts(self, filters=None):
        return asyncio.run(self._async_client.get_alerts(filters))
    
    # Integration sync wrappers
    def get_integrations(self):
        return asyncio.run(self._async_client.get_integrations())
    
    def configure_integration(self, integration):
        return asyncio.run(self._async_client.configure_integration(integration))
    
    # Validation sync wrappers
    def validate_structured_data(self, validation_config):
        return asyncio.run(self._async_client.validate_structured_data(validation_config))
    
    def validate_pii(self, content):
        return asyncio.run(self._async_client.validate_pii(content))

    def close(self):
        """Close the client"""
        asyncio.run(self._async_client.close())


async def example_usage():
    """Example usage of the Doopal Python SDK"""
    async with DoopalClient(api_key="your-api-key") as client:
        response = await client.chat_completion(
            provider="openai",
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Hello, how are you?"}],
            temperature=0.7,
            max_tokens=100,
        )

        print(f"Response: {response.response}")
        print(f"Redacted content: {response.redacted_content}")

        async for chunk in await client.chat_completion(
            provider="openai",
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Tell me a story"}],
            stream=True,
        ):
            print(chunk, end="")

        stats = await client.get_usage_stats()
        print(f"Usage stats: {stats}")


def main():
    """CLI entry point for Doopal SDK"""
    print("Doopal Python SDK v1.1.2")
    print("Usage: Import this SDK in your Python code")
    print("Example:")
    print("""
from doopal import DoopalClient

async def example():
    async with DoopalClient(api_key="your-api-key") as client:
        response = await client.chat_completion(
            provider="openai",
            model="gpt-3.5-turbo", 
            messages=[{"role": "user", "content": "Hello!"}]
        )
        print(response.response)
""")
    print("For full documentation, visit: https://docs.doopal.com")


if __name__ == "__main__":
    asyncio.run(example_usage())
