from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="doopal",
    version="1.1.2",
    author="Doopal Team",
    author_email="info@doopal.com",
    description="Python SDK for Doopal AI Governance Platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/doopal-ai/doopal-governance",
    packages=["doopal"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.24.0",
        "pydantic>=2.0.0",
        "asyncio",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "doopal=doopal:main",
        ],
    },
    keywords="ai governance llm security redaction policy enterprise compliance analytics monitoring rbac sso audit",
    project_urls={
        "Bug Reports": "https://github.com/doopal-ai/doopal-governance/issues",
        "Source": "https://github.com/doopal-ai/doopal-governance",
        "Documentation": "https://docs.doopal.com",
    },
)
