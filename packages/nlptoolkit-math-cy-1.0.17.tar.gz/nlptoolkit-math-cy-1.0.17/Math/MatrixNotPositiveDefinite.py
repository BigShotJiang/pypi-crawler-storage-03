class MatrixNotPositiveDefinite:

    def __init__(self):
        self.message = "Matrix should be positive definite."
