class DeterminantZero(Exception):

    def __init__(self):
        self.message = "Determinant of matrix is zero."
