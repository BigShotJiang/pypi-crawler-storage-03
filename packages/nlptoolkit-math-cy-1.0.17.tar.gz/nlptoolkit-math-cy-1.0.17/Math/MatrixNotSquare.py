class MatrixNotSquare(Exception):

    def __init__(self):
        self.message = "Matrix should be square."
