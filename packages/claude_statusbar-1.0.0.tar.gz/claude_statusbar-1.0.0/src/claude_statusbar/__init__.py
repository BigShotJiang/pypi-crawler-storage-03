"""Claude Status Bar Monitor - Lightweight token usage monitor"""

__version__ = "1.0.0"

from .core import main

__all__ = ["main"]