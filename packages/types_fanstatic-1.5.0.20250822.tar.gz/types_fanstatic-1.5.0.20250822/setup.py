
from setuptools import setup

setup(package_data={'fanstatic-stubs': ['__init__.pyi', 'checksum.pyi', 'compiler.pyi', 'config.pyi', 'core.pyi', 'inclusion.pyi', 'injector.pyi', 'publisher.pyi', 'registry.pyi', 'wsgi.pyi', 'METADATA.toml', 'py.typed']})
