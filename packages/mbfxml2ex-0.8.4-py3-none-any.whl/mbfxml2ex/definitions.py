
INFOSET_RANK_MAP = {
    'color': ('field', 1),
    'resolution': ('field', 2),
    'rootclass': ('group', 1),
    'class': ('group', 2),
    'type': ('group', 3),
    'Set': ('group', 4),
    'TraceAssociation': ('group', 5),
    'leaf': ('metadata', 1),
    'TreeOrder': ('metadata', 2),
}
