class MBFXMLException(Exception):
    pass


class MBFXMLFormat(Exception):
    pass


class MBFXMLFile(Exception):
    pass


class MBFDataException(Exception):
    pass


class MBFImagesException(Exception):
    pass


class MissingImplementationException(Exception):
    pass
