import logging

logger = logging.getLogger("arangoasync")
