Define a member product, and select 'Variable periods' in the field
*Membership type*. You will be able to select them the period for the
membership in quantity and interval.
