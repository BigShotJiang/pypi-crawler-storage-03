# -*- coding: utf-8 -*-
# Redis RPC implementation
