def main() -> None:
    print("Hello from aci-python-sdk!")


if __name__ == "__main__":
    main()
