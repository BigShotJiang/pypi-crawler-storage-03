MOCK_API_KEY = "test_api_key"
MOCK_LINKED_ACCOUNT_OWNER_ID = "test_linked_account_owner_id"
MOCK_BASE_URL = "https://api.aci.dev/v1/"
