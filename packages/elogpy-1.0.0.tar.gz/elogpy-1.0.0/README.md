## Introduction
This is a lightweight Python wrapper for accessing ELOG (https://elog.psi.ch/elog) instances

## Installation
Simply using PIP


