from setuptools import setup,Extension,find_packages

setup(
    name="second-module",
    version="0.5",
    packages=find_packages(),
    description="My second module for practice",
)