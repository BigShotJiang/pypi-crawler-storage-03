class second:
    def second_module(self):
        print("Hello from second module")


