"""Top-level package for risclog.batou."""
