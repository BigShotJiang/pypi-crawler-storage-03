=============
risclog.batou
=============

.. image:: https://github.com/risclog-solution/risclog.batou/workflows/Test/badge.svg?branch=master
     :target: https://github.com/risclog-solution/risclog.batou/actions?workflow=Test
     :alt: CI Status

batou extensions used by risclog


Features
========

Run tests::

    $ ./pytest


Credits
=======

This package was created with Cookiecutter_ and the `risclog-solution/risclog-cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`risclog-solution/risclog-cookiecutter-pypackage`: https://github.com/risclog-solution/risclog-cookiecutter-pypackage


This package uses AppEnv_ for running tests inside this package.

.. _AppEnv: https://github.com/flyingcircusio/appenv
