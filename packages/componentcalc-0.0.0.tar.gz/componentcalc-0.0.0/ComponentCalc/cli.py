def ComponentCalc():
    print("Placeholder Command.")
