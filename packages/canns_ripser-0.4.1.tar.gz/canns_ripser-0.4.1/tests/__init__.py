import matplotlib
matplotlib.use('agg')