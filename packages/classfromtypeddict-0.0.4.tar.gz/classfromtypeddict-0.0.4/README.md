The Class ClassFromTypedDict allows converting a dict following a TypedDict schema into a class automatically.
    The dict will be used as a basis to set the parameters.
    If the TypedDict is nested, the associated ClassFromTypedDict is automatically created and nested to the root ClassFromTypedDict