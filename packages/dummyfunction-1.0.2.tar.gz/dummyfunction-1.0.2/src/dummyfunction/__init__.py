from dummyfunction.core import *
from dummyfunction.tests import *
