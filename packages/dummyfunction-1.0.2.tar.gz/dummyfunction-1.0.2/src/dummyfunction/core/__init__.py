from typing import *

__all__ = ["dummyfunction"]


def dummyfunction(*args: Any, **kwargs: Any) -> None:
    "This function does nothing."
    pass
