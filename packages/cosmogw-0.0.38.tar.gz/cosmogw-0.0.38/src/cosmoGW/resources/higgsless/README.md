
parameters_fit_sims includes the parameters found from the fits of the provided template
to the results of the simulations in the results of Higgsless simulations to study GW
production from phase transitions with alpha of 0.0046, 0.05 and 0.5

The results correspond to those presented in

[Caprini:2024gyk]: Gravitational waves from decaying sources in strong
phase transitions, A. Roper Pol, I. Stomberg, C. Caprini, R. Jinno, T. Konstandin,
H. Rubira, J. High Energy Phys., arXiv:2409.03651.
