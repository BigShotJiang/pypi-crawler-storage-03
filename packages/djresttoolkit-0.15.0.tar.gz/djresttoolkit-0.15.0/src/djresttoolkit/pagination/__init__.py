from ._page_number_pagination import PageNumberPagination

__all__ = ["PageNumberPagination"]
