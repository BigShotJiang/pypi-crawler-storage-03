
> [!Warning]  
> 由于绿色包内部执行已更改为 `uv tool`，`v2.4.0`之前旧版绿色包需删掉后使用新版本，无论win还是mac；  
> 使用内置更新升级失败的话查看 [更新失败指引](https://jasoneri.github.io/ComicGUISpider/faq/#%E6%9B%B4%E6%96%B0%E5%A4%B1%E8%B4%A5%E5%90%8E%E7%A8%8B%E5%BA%8F%E6%97%A0%E6%B3%95%E6%89%93%E5%BC%80)  

## 🎁 Feat

✅ 已打包上传至 pypi ，可使用 uv tool 管理/运行 CGS [查看细则](https://jasoneri.github.io/ComicGUISpider/deploy/quick-start)  
✅ 支持日夜模式切换，已做字体颜色优化  
✅ ✨新增支持 kemono的 discord 资源下载  

## 🐞 Fix

✅ kemono 域名更换  
✅ 修复 domainTool 的 jm 域名检测  
✅ ✨修复 kemomo 的 api 变更相关
