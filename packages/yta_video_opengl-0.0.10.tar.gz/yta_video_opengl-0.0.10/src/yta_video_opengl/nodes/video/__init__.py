"""
Working with video frames has to be done
with nodes that use OpenGL because this
way, by using the GPU, is the best way.
"""