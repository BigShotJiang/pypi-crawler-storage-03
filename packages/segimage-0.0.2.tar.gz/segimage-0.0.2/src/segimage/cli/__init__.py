"""
CLI package for segimage.
"""

from .main import main

__all__ = ["main"]


