# datacontract_helper

howto:

build and publish:

```
manualy increase version in pyproject.toml and remove old version

uv build

uv publish --token pypi-fdgdgdfbjlfdkb
```