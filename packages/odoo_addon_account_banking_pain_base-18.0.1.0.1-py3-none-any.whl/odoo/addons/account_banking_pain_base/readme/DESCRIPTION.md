This module contains fields and functions that are used by the module
for SEPA Credit Transfer (account_banking_sepa_credit_transfer) and SEPA
Direct Debit (account_banking_sepa_direct_debit). This module doesn't
provide any functionality by itself.

This module was started during the Akretion-Noviat code sprint of
November 21st 2013 in Epiais les Louvres (France).
