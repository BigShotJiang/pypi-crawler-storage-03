# Core quick tests
