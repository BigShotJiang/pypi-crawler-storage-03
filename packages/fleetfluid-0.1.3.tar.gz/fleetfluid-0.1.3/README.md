# FleetFluid

**AI Agent Functions for Data Processing**

FleetFluid is a Python library that simplifies data transformation by letting you use AI-powered functions without writing them from scratch. Instead of building functions, you invoke ready-made, agent-based functions that handle tasks like text cleaning, information extraction, translation, labeling, anonymization, and more—just by specifying what you need in natural language.

Powered by PydanticAI, FleetFluid offers a streamlined interface for embedding intelligent data processing into your ETL workflows, without the overhead of managing complex AI infrastructure.

## Installation

```bash
pip install fleetfluid
```

## Quick Start

```python
import fleetfluid

# Initialize with your preferred model
fleetfluid.init(
    model="anthropic:claude-sonnet-4-20250514",
    temperature=0.7,
    max_tokens=1000
)

# AI Transformation
sample_text = "The data processing pipeline needs optimization for better performance."
result = fleetfluid.ai("Rewrite this in a more technical tone", sample_text)
print(result)  # "The data processing pipeline requires optimization for enhanced performance."

# Multi-label Classification
text = "The database query is running slowly and consuming too much memory"
labels = ["Performance Issue", "Feature Request", "Bug Report"]
result = fleetfluid.label(text, labels, multiple=True)
print(result.labels)  # ["Performance Issue", "Bug Report"]
print(result.confidence_scores)  # {"Performance Issue": 0.9, "Bug Report": 0.8}

# Single-label Classification
result = fleetfluid.label(text, labels, multiple=False)
print(result.label)  # "Performance Issue"
print(result.confidence)  # 0.9

# Text Anonymization
personal_text = "Hi, my name is John Smith. Email: john@email.com. Phone: 555-123-4567"
anonymized = fleetfluid.anonymize(personal_text)
print(anonymized)  # "Hi, my name is [NAME]. Email: [EMAIL]. Phone: [PHONE]"

# Feature Description Generation
product_features = {
    "material": "leather",
    "color": "black", 
    "type": "wallet"
}
description = fleetfluid.describe(product_features, style="marketing")
print(description)  # "A sophisticated black leather wallet that combines style and functionality."

# Information Extraction
job_description = """Senior Data Engineer with 5+ years experience 
in Python, SQL, AWS, and machine learning pipelines."""
skills = fleetfluid.extract("skills", job_description)
print(skills)  # ["Python", "SQL", "AWS", "machine learning"]

## Configuration

```python
import fleetfluid

# Basic initialization
fleetfluid.init(model="openai:gpt-4")

# With additional PydanticAI configuration
fleetfluid.init(
    model="anthropic:claude-sonnet-4-20250514",
    temperature=0.7,
    max_tokens=1000
)
```

## API Reference

### `fleetfluid.init(model, **kwargs)`

Initialize FleetFluid with model configuration.

- **model** (str): Model identifier (e.g., "openai:gpt-4")
- **kwargs**: Additional configuration passed to PydanticAI agents

### `fleetfluid.ai(prompt, data)`

Apply AI transformation to data using the given prompt.

- **prompt** (str): Instruction for the AI
- **data** (str): Input data to transform
- **Returns** (str): Transformed data

### `fleetfluid.label(text, labels, multiple=False)`

Label text using AI agent with structured output.

- **text** (str): Input text to label
- **labels** (list[str]): List of possible labels to choose from
- **multiple** (bool): If True, select multiple labels; if False, select single best label (default: False)
- **Returns**: 
  - `SingleLabelResult` (when `multiple=False`): Contains `label`, `confidence`, and `reasoning`
  - `MultipleLabelResult` (when `multiple=True`): Contains `labels`, `confidence_scores`, and `reasoning`

### `fleetfluid.anonymize(text)`

Anonymize personal information in text using AI.

- **text** (str): Input text containing personal information to anonymize
- **Returns** (str): Anonymized text with personal information replaced by placeholders

### `fleetfluid.describe(features, style="natural")`

Generate a meaningful text description from a dictionary of features.

- **features** (dict): Dictionary of product/object features
- **style** (str): Description style ("natural", "marketing", "technical", "casual")
- **Returns** (str): Natural language description of the features

### `fleetfluid.extract(extraction_type, text)`

Extract specific types of information from text using AI.

- **extraction_type** (str): Type of information to extract (e.g., "skills", "countries", "companies", "technologies")
- **text** (str): Input text to extract information from
- **Returns** (list): List of extracted items

## Use Cases

### Data Cleaning & Standardization
```python
# Fix inconsistent formatting
clean_data = fleetfluid.ai("standardize this address format", "123 main st apt 4b")

# Normalize names
normalized = fleetfluid.ai("convert to proper case", "JOHN SMITH")
```

### Text Processing
```python
# Summarize content
summary = fleetfluid.ai("summarize in 2 sentences", long_text)

# Extract entities
entities = fleetfluid.ai("extract all company names as a list", business_text)
```

### Data Enrichment
```python
# Categorize data
category = fleetfluid.ai("categorize this product: electronics, clothing, books", product_name)

# Generate missing data
description = fleetfluid.ai("write a product description", product_title)

# Structured labeling
text = "Customer complaint about delayed delivery"
labels = ["positive", "negative", "neutral", "urgent"]
result = fleetfluid.label(text, labels)
print(f"Sentiment: {result.label} (confidence: {result.confidence})")

# Multi-label classification
text = "Product review: Great quality but expensive"
result = fleetfluid.label(text, ["positive", "negative", "price", "quality"], multiple=True)
print(f"Labels: {result.labels}")
```

### Data Privacy & Compliance
```python
# Anonymize customer data
customer_text = "Customer: Jane Doe, Email: jane@email.com, Phone: 555-123-4567"
anonymized = fleetfluid.anonymize(customer_text)
print(anonymized)  # "Customer: [NAME], Email: [EMAIL], Phone: [PHONE]"
```

### Product & Content Generation
```python
# Generate product descriptions from features
product_features = {"material": "cotton", "color": "blue", "style": "casual"}
description = fleetfluid.describe(product_features, style="marketing")
print(description)  # "A comfortable blue cotton casual shirt perfect for everyday wear."

# Create content in different styles
tech_specs = {"processor": "Intel i7", "ram": "16GB", "storage": "512GB SSD"}
tech_description = fleetfluid.describe(tech_specs, style="technical")
print(tech_description)  # "Intel i7 processor with 16GB RAM and 512GB SSD storage."
```

### Information Extraction & Mining
```python
# Extract skills from job descriptions
job_text = "Looking for Python developer with AWS and Docker experience"
skills = fleetfluid.extract("skills", job_text)
print(skills)  # ["Python", "AWS", "Docker"]

# Extract countries from travel content
travel_text = "I visited Paris, France and Tokyo, Japan last year"
countries = fleetfluid.extract("countries", travel_text)
print(countries)  # ["France", "Japan"]

# Extract companies from business articles
business_text = "Apple, Microsoft, and Google are leading tech companies"
companies = fleetfluid.extract("companies", business_text)
print(companies)  # ["Apple", "Microsoft", "Google"]
```

## Error Handling

```python
try:
    result = fleetfluid.ai("translate to French", text)
except RuntimeError as e:
    print(f"AI processing failed: {e}")
```

## API Token Configuration

FleetFluid uses PydanticAI for AI model interactions and relies on standard environment variables for API authentication. You need to set up API tokens for your chosen model provider before using FleetFluid.

### Setting Up API Tokens

#### OpenAI Models
For OpenAI models like `"openai:gpt-4"` or `"openai:gpt-3.5-turbo"`:

```bash
export OPENAI_API_KEY="your-openai-api-key-here"
```

#### Anthropic Models
For Anthropic models like `"anthropic:claude-sonnet-4-20250514"`:

```bash
export ANTHROPIC_API_KEY="your-anthropic-api-key-here"
```

#### Google Models
For Google models like `"gemini-2.5-pro"`:

```bash
export GOOGLE_API_KEY="your-google-api-key-here"
```

#### Groq Models
For Groq models like `"groq:llama-70b"`:

```bash
export GROQ_API_KEY="your-groq-api-key-here"
```

#### Google VertexAI Models
For Google VertexAI models like `"vertexai:gemini-2.5-pro"`:

```bash
# Set Google Cloud credentials
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/your/service-account-key.json"

# Or set project ID and use Application Default Credentials
export GOOGLE_CLOUD_PROJECT="your-project-id"
```

### Environment Variable Setup

You can set environment variables in several ways:

#### 1. Terminal/Shell
```bash
# For current session
export OPENAI_API_KEY="sk-your-key-here"

# For permanent setup (add to ~/.bashrc, ~/.zshrc, etc.)
echo 'export OPENAI_API_KEY="sk-your-key-here"' >> ~/.bashrc
source ~/.bashrc
```

#### 2. Python Environment
```python
import os
os.environ["OPENAI_API_KEY"] = "sk-your-key-here"

import fleetfluid
fleetfluid.init(model="openai:gpt-4")
```

#### 3. .env File (if supported by your setup)
Create a `.env` file in your project root:
```
OPENAI_API_KEY=sk-your-key-here
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

## Requirements

- Python 3.8+
- PydanticAI
- An API key for your chosen model provider (see API Token Configuration above)

## Version

Current version: 0.1.3

## License

MIT License. See LICENSE file for details.