# ZTProxy

A proxy tool for ZeroTrusted AI.

## Installation

```bash
pip install .
```

## Usage

```bash
ztproxy
```