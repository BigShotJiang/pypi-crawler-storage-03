1.  Go to *Sale \> Quotations*.
2.  Create a sales order.
3.  Add a new line.
4.  Select an elaboration in the line. If the product has an elaboration
    profile selected, you will just be able to select the elaborations set
    on the profile.
5.  Confirm the sales order.
6.  Go to the picking created by this sales order and validate it.
7.  Print Delivery Slip and Picking Operations.
8.  Go back to the sales order. A new line is created with the product
    linked to the elaboration.
