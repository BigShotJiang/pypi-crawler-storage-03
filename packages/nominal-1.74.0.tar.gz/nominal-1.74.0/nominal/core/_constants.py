DEFAULT_API_BASE_URL = "https://api.gov.nominal.io/api"
