import setuptools

setuptools.setup(
    package_data={
        "pyairtable": ["py.typed"],
    },
)
