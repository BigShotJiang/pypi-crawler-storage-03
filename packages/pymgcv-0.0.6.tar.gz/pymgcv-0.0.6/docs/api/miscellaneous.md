# Miscellaneous API

Various functionality not part of the main API, but we want to be exposed/searchable.

::: pymgcv.qq
    options:
      members:
        - "QQResult"
        - "qq_cdf"
        - "qq_simulate"
