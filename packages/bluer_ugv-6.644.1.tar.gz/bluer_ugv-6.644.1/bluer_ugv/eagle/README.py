from bluer_objects.README.items import ImageItems

assets2 = "https://github.com/kamangir/assets2/blob/main/bluer-eagle"

items = ImageItems(
    {
        f"{assets2}/file_0000000007986246b45343b0c06325dd.png": "",
        f"{assets2}/20250727_182113.jpg": "",
        f"{assets2}/20250726_171953.jpg": "",
    }
)
