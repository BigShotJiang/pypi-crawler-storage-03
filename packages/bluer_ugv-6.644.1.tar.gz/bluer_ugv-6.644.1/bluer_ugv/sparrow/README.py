from bluer_objects.README.items import ImageItems

assets2 = "https://github.com/kamangir/assets2/blob/main/bluer-sparrow"

items = ImageItems(
    {
        f"{assets2}/20250722_174115-2.jpg": "",
        f"{assets2}/20250729_234927.jpg": "",
    }
)
