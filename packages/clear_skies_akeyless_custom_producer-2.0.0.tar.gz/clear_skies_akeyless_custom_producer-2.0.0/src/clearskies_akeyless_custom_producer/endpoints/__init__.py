from clearskies_akeyless_custom_producer.endpoints.no_input import NoInput

__all__ = ["NoInput"]
