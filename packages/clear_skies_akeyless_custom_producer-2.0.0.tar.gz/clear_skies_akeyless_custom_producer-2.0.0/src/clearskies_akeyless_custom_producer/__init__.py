from clearskies_akeyless_custom_producer import endpoints

__all__ = ["endpoints"]
