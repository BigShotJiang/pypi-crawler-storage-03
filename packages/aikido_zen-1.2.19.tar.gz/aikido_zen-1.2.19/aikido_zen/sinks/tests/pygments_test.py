import pytest
import aikido_zen


def test_pygments_dynamic_import_works():
    from pygments.formatters import HtmlFormatter
