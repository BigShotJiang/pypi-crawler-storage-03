"""Lambda init.py file"""


def protect(handler):
    """Aikido protect function for the lambda"""
    return handler
