"""Contains package versions"""

PKG_VERSION = "1.2.19"
