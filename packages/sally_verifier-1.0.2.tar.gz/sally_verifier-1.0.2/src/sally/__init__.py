# -*- encoding: utf-8 -*-

"""
SALLY
sally package

"""

__version__ = '1.0.2'  # also change in setup.py
