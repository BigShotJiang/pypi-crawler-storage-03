__all__ = ["version", "version_info"]


version = "3.0.0"
version_info = (3, 0, 0, "final", 0)
