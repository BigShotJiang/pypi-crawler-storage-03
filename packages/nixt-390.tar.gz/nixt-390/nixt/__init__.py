# This file is placed in the Public Domain.


__doc__ = __name__.upper()
