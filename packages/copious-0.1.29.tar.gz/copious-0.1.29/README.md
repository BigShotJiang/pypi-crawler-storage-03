# Copious

A handy tool that make your day to day programming much easier. 

The name comes from the latin word cornucopia.
