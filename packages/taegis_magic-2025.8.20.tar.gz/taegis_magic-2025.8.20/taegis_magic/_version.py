"""Version identifier."""

__version__ = "2025.8.20"
