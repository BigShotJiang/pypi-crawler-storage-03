"""Extra tools for supporting RAG."""
