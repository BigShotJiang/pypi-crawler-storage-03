"""Streamlit components used by the companion app.

* Docker image: https://hub.docker.com/r/rsundqvist/time-split/
* Repo: https://github.com/rsundqvist/time-split-app/
"""

__version__ = "1.0.3"
