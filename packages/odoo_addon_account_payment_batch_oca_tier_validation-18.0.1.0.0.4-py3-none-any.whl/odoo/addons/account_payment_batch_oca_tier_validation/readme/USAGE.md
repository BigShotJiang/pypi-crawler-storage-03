To use this module, you need to:

1.  Create a Payment Order triggering at least one *Tier Definition*.
2.  Click on *Request Validation* button.
3.  Under the tab *Reviews* have a look to pending reviews and their
    statuses.
4.  Once all reviews are validated, click on the button *Confirm Payments*.

Additional features:

- You can filter the Payment/Debit Orders requesting your review through the
  filter *Needs my Review*.
- User with rights to confirm the Payment/Debit Order (validate all tiers that
  would be generated) can directly do the operation i.e. there is
  no need for her/him to request a validation.
