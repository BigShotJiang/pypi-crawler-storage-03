# About mdalib

Python support library for EPICS synApps MDA-format data files.

Copied from the Python wheel at [synApps mdaPythonUtils](https://github.com/EPICS-synApps/support/tree/master/utils/mdaPythonUtils).

## Caution

Per this [commit message](https://github.com/EPICS-synApps/support/commit/f49b4b9ab7844b24060d3b3163d59eb76a3c5c7e):

> Don't use f_xdrlib. It doesn't work for large numbers of data points.
