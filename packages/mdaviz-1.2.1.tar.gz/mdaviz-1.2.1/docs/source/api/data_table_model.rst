====================================
Data Table Model
====================================

.. automodule:: mdaviz.data_table_model
    :members:
    :private-members:
