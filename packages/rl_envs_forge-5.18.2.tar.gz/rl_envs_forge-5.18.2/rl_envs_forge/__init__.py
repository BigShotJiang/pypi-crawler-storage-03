from importlib.metadata import version

__version__ = version("rl-envs-forge")