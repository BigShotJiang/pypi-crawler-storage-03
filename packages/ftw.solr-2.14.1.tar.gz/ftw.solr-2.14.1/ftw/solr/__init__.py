def initialize(context):
    from ftw.solr import patches  # noqa
