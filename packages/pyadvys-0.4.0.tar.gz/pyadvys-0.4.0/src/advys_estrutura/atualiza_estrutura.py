

def main():
    from advys_estrutura import atualiza_caminhos, atualiza_imagens

    atualiza_caminhos.executa_atualizacao()
    atualiza_imagens.executa_atualizacao()


    print("Estrutura Atualizada")