def main():
    from advys_configuracoes.config_ini import cria_pyadvys_ini

    cria_pyadvys_ini()
    print("Arquivo de configuração criado com sucesso!")