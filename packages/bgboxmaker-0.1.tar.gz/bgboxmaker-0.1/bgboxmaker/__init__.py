def main():
    print("This is BG Boxmaker")
    return