from setuptools import setup

setup(name='bgboxmaker',
    version='0.1',
    description='Board Game Tuck Box Generator',
    url='https://github.com/thetalorian/bgboxmake',
    author='Samuel Plum',
    author_email='splum@taloria.com',
    license='MIT',
    packages=['bgboxmaker'],
    zip_safe=False)
