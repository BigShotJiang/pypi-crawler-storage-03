# makepkg

<div>

[![PyPI Latest Release](https://img.shields.io/pypi/v/makepkg?style=flat&logo=pypi)](https://pypi.org/project/makepkg/)
[![PyPI pyversions](https://img.shields.io/pypi/pyversions/makepkg.svg?logo=python&style=flat)](https://pypi.python.org/pypi/makepkg/)
[![license](https://img.shields.io/pypi/l/makepkg?style=flat&logo=opensourceinitiative)](https://opensource.org/license/mit/)

</div>

Build and share your Python projects without the complexity.


**Project currently under development**
