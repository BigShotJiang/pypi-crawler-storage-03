# Test package initialization for agemcp module tests
