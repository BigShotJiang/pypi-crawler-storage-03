import os
from dotenv import load_dotenv

load_dotenv()

# -------- Prompts Vars --------
PROMPT_TEMPLATE_FORMAT = os.getenv("PROMPT_TEMPLATE_FORMAT")
MIN_SYSTEM_PROMPT_LENGTH = os.getenv("MIN_SYSTEM_PROMPT_LENGTH")
MIN_USER_PROMPT_LENGTH = os.getenv("MIN_USER_PROMPT_LENGTH")

# -------- LLM Vars --------
MAX_BUCKET_SIZE = os.getenv("MAX_BUCKET_SIZE", 10)
CHECK_EVERY_N_SECONDS = os.getenv("CHECK_EVERY_N_SECONDS", 0.1)
RAISE_ON_SAMPLE_ERROR = os.getenv(
    "RAISE_ON_SAMPLE_ERROR", 0)
TIMEOUT_SECONDS = os.getenv("TIMEOUT_SECONDS", 120)
RETRY_ATTEMPTS = os.getenv("RETRY_ATTEMPTS", 2)
REQUESTS_PER_SECOND = os.getenv("REQUESTS_PER_SECOND", 10)
