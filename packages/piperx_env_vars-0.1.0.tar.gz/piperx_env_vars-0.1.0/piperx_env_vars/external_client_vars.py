import os
from dotenv import load_dotenv

load_dotenv()

# On Demand Connection
MAX_EXTERNAL_CLIENT_SQL_CONNECTION = int(
    os.getenv("MAX_EXTERNAL_CLIENT_SQL_CONNECTION", "5"))
