import os
from dotenv import load_dotenv

load_dotenv()

# Internal PostgreSQL database connection environment variables
PG_USER_NAME = os.getenv("PG_USER_NAME")
PG_PASSWORD = os.getenv("PG_PASSWORD")
PG_HOST = os.getenv("PG_HOST")
PG_DB_NAME = os.getenv("PG_DB_NAME")
PG_POOL_COUNT = int(os.getenv("PG_POOL_COUNT", "20"))
PG_PROTOCOL = "postgresql+asyncpg"
ASYNC_PG_CONNECTION_STRING = (
    f"{PG_PROTOCOL}://{PG_USER_NAME}:{PG_PASSWORD}@{PG_HOST}/{PG_DB_NAME}"
)


# TODO: To deprecate later (Client will provide their own blob credentials)
# Azure File Manager
MAX_FILE_MANAGER_CLIENT_COUNT = int(
    os.getenv("MAX_FILE_MANAGER_CLIENT_COUNT", "5"))
AZURE_BLOB_ACCOUNT_URL = os.getenv("AZURE_BLOB_ACCOUNT_URL")
AZURE_ACCOUNT_KEY = os.getenv("AZURE_ACCOUNT_KEY")


# Azure Key Vault
AZURE_KEY_VAULT_URL = os.getenv("AZURE_KEY_VAULT_URL")
AZURE_KEY_VAULT_TENANT_ID = os.getenv("AZURE_KEY_VAULT_TENANT_ID")
AZURE_KEY_VAULT_CLIENT_ID = os.getenv("AZURE_KEY_VAULT_CLIENT_ID")
AZURE_KEY_VAULT_CLIENT_SECRET = os.getenv("AZURE_KEY_VAULT_CLIENT_SECRET")


# DB Trigger Functions
PG_TRIGGER_LOG_FN = "notify_new_log"
PG_TRIGGER_LOG_FN_TRIGGER = "notify_new_log_trigger"
PG_TRIGGER_CHANNEL = "new_block_log"
PG_WORK_FLOW_FN = "new_workflow_function"
PG_WORK_FLOW_TRIGGER_CHANNEL = "new_workflow_run_channel"
PG_WORK_FLOW_TRIGGER = "new_workflow_run_trigger"
