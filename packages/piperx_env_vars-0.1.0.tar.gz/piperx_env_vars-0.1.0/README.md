# piperx-env-vars

A Python package for managing environment variables for the PiperX platform. This package centralizes configuration for services, storage, external clients, server settings, and block prompts using environment variables and `.env` files.

## Features

- Loads environment variables for different PiperX components.
- Supports configuration for authentication, storage, external clients, and more.
- Uses [`python-dotenv`](https://pypi.org/project/python-dotenv/) for `.env` file support.

## Directory Structure

- **blocks_vars.py**: Prompt and LLM configuration variables.
- **external_client_vars.py**: External client connection settings.
- **internal_storage_vars.py**: Internal storage and database configuration.
- **server_vars.py**: Server-level environment variables.
- **services_vars.py**: Service integrations and API keys.

## Usage

Install dependencies (requires Python 3.13+):

```sh
uv sync

from piperx_env_vars import APP_NAME, PG_USER_NAME, OPENAI_API_KEY