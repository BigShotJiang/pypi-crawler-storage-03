# speciesot

A software package for cross-species transcriptome analysis using GWOT.
