﻿groggy.get\_current\_backend
============================

.. currentmodule:: groggy

.. autofunction:: get_current_backend