﻿groggy.get\_available\_backends
===============================

.. currentmodule:: groggy

.. autofunction:: get_available_backends