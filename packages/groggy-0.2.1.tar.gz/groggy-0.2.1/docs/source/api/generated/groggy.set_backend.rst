﻿groggy.set\_backend
===================

.. currentmodule:: groggy

.. autofunction:: set_backend