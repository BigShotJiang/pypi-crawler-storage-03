class HuiBiaoException(Exception):
    pass
