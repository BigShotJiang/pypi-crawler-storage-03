import solara


@solara.component
def Page():
    return solara.Markdown("Click an example on the left")
