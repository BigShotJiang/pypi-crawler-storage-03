"""
aiida_skeaf

AiiDA plugin for the Supercell K-space Extremal Area Finder (SKEAF) code
"""

__version__ = "0.1.0"
