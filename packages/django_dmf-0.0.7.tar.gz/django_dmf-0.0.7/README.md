# django_dmf
A Version Controlled Fully Managed Data Migration Framework For Django that kicks in post Django's Inbuilt Schema Migration. This helps to keep Schema Migration and Data Migration isolated from each other so that if one changes, it doesn't impact the other and both migrations can be independently managed.
