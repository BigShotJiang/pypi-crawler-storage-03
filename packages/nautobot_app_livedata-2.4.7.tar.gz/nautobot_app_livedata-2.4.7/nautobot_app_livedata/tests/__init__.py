"""Unit tests for nautobot_app_livedata app."""
