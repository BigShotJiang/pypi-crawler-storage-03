"""Nornir plays for Nautobot App Livedata."""

# filepath: nautobot_app_livedata/nornir_plays/__init__.py
