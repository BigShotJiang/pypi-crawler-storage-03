# Ce fichier sert à créer des metamodels pour ne renvoyer que l'entités  avec une partie ou sans ses relations
# from pydantic import BaseModel, Field

# class EntityBaseModel(BaseModel):
#     pass


# class MetaEntityModel(BaseModel):
#     pass
