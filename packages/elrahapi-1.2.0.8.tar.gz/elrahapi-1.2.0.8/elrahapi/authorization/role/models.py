from elrahapi.authorization.base_meta_model import (
    MetaAuthorization,
)




class RoleModel(MetaAuthorization):
    pass


