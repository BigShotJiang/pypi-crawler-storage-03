:py:mod:`jsonschema.validators`
===============================

.. automodule:: jsonschema.validators
   :members:
   :undoc-members:
   :private-members: _RefResolver
