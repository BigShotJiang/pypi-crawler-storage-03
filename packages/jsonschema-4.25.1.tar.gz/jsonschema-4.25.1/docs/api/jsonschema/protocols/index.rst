:py:mod:`jsonschema.protocols`
==============================

.. automodule:: jsonschema.protocols
   :members:
   :undoc-members:
