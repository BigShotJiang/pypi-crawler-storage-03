:py:mod:`jsonschema.exceptions`
===============================

.. automodule:: jsonschema.exceptions
   :members:
   :undoc-members:
