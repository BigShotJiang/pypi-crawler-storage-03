def test():
    from ajprax.prelude import Iter, RequirementException, Sentinel, identity, log, print
