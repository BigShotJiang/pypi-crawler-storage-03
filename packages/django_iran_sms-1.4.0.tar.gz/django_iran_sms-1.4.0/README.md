
# اطلاعیه

این پکیج تنها برای **هدایت** به پکیج اصلی ساخته شده است و به صورت خودکار پکیج زیر را نصب می‌کند:  

👉 [django-chelseru](https://pypi.org/project/django-chelseru/)

خواهشمند است برای استفاده مستقیم، همین پکیج اصلی را نصب کنید:  

```bash
pip install django-chelseru
---
