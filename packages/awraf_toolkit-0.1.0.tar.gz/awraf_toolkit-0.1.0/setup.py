from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='awraf-toolkit',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'numpy>=1.19.0',
        'matplotlib>=3.3.0',
        'pandas>=1.1.0',
        'seaborn>=0.11.0',
        'scipy>=1.5.0',
        'tabulate>=0.8.0',
    ],
    author='Kushagra Agrawal, Ferheen Ayaz, Polat Goktas',
    author_email='kush4409@gmail.com',  
    description='Adaptive Weight-Based Resource Allocation Framework for 6G IoT with THz Links and Intelligent Surfaces',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/afrilab/awraf',  
    project_urls={
        'Bug Reports': 'https://github.com/afrilab/awraf/issues',
        'Source': 'https://github.com/afrilab/awraf',
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Scientific/Engineering :: Information Analysis',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
        'Natural Language :: English',
        'Framework :: Jupyter',
    ],
    keywords=[
        'iot', '6g', 'resource-allocation', 'edge-computing', 'thz', 'irs',
        'machine-learning', 'reinforcement-learning', 'optimization',
        'simulation', 'wireless-networks', 'federated-learning'
    ],
    python_requires='>=3.7',
    include_package_data=True,
    zip_safe=False,
    entry_points={
        'console_scripts': [
            'awraf-sim=awraf.cli:main',
        ],
    },
)
