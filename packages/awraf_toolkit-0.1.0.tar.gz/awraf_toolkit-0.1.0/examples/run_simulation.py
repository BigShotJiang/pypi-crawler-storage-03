import numpy as np
import random

from awraf.simulator import AWRAFSimulator
from awraf.enums import ScenarioType, AlgorithmType
from awraf.utils import run_statistical_analysis, analyze_and_plot, print_summary_table

def main():
    # Set random seeds for reproducibility
    np.random.seed(42)
    random.seed(42)

    # Define scenarios and algorithms to run
    SCENARIOS_TO_RUN = [
        (ScenarioType.SMART_HEALTHCARE, 50, 10),
        (ScenarioType.SMART_TRANSPORTATION, 60, 12),
        (ScenarioType.BASELINE_IOT, 40, 10)
    ]

    ALGORITHMS_TO_RUN = [
        AlgorithmType.AWRAF_DYNAMIC,
        AlgorithmType.AWRAF_STATIC,
        AlgorithmType.GREEDY,
        AlgorithmType.RL_BASED
    ]

    # Run the full statistical and scalability analysis
    statistical_df = run_statistical_analysis(SCENARIOS_TO_RUN, ALGORITHMS_TO_RUN, num_trials=30)

    # Plot and get aggregated results
    aggregated_results = analyze_and_plot(statistical_df, SCENARIOS_TO_RUN)

    # Print the final summary table
    print_summary_table(aggregated_results, statistical_df)

    print("\nANALYSIS COMPLETE - 6G IoT SCENARIOS SUCCESSFULLY EVALUATED WITH BASELINES AND STATISTICAL VALIDATION.\n")

if __name__ == "__main__":
    main()
