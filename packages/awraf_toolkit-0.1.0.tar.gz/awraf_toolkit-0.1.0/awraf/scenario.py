import numpy as np
import random
from typing import List
from awraf.models import IoTDevice, EdgeServer
from awraf.enums import ScenarioType

class ScenarioGenerator:
    def __init__(self, num_devices: int, num_servers: int, scenario_type: ScenarioType):
        self.num_devices = num_devices
        self.num_servers = num_servers
        self.scenario_type = scenario_type
        self.devices: List[IoTDevice] = []
        self.servers: List[EdgeServer] = []

    def generate_scenario(self):
        if self.scenario_type == ScenarioType.SMART_HEALTHCARE:
            self._generate_healthcare_scenario()
        elif self.scenario_type == ScenarioType.SMART_TRANSPORTATION:
            self._generate_transportation_scenario()
        else:
            self._generate_baseline_scenario()
        return self.devices, self.servers

    def _generate_healthcare_scenario(self):
        for i in range(self.num_devices):
            task_size = np.random.uniform(0.1, 5.0)
            self.devices.append(IoTDevice(i, task_size, np.random.uniform(1, 50), np.random.uniform(50, 200),
                                          "wearable_sensor", self.scenario_type, np.random.uniform(0, 2), True, 275.0,
                                          data_to_upload=task_size * 0.2, model_size_downlink=10.0))
        for j in range(self.num_servers):
            self.servers.append(EdgeServer(j, np.random.uniform(100, 300), np.random.uniform(5000, 10000), np.random.uniform(2000, 5000),
                                           "healthcare_edge", np.random.randint(128, 513), 10000.0, True))

    def _generate_transportation_scenario(self):
        for i in range(self.num_devices):
            task_size = np.random.uniform(5, 50)
            self.devices.append(IoTDevice(i, task_size, np.random.uniform(5, 100), np.random.uniform(500, 2000),
                                          "vehicle", self.scenario_type, np.random.uniform(20, 35), True, 275.0,
                                          data_to_upload=task_size * 0.5, model_size_downlink=20.0))
        for j in range(self.num_servers):
            self.servers.append(EdgeServer(j, np.random.uniform(200, 450), np.random.uniform(3000, 8000), np.random.uniform(3000, 6000),
                                           "roadside_unit", np.random.randint(64, 257), 8000.0, True))

    def _generate_baseline_scenario(self):
        for i in range(self.num_devices):
            self.devices.append(IoTDevice(i, np.random.uniform(1, 50), np.random.uniform(10, 1000), np.random.uniform(100, 1000),
                                          "generic", self.scenario_type, data_to_upload=np.random.uniform(1, 5)))
        for j in range(self.num_servers):
            self.servers.append(EdgeServer(j, np.random.uniform(250, 500), np.random.uniform(500, 1000), np.random.uniform(1000, 2000), "generic"))
