import numpy as np
import random
from typing import Dict, List, Tuple

from awraf.enums import ScenarioType, AlgorithmType
from awraf.models import IoTDevice, EdgeServer
from awraf.algorithm import RLAgent
from awraf.scenario import ScenarioGenerator

class AWRAFSimulator:
    """Adaptive Weight-Based Resource Allocation Framework Simulator."""
    def __init__(self, scenario_type: ScenarioType, algorithm: AlgorithmType, num_devices: int, num_servers: int):
        self.scenario_type = scenario_type
        self.algorithm = algorithm
        self.num_devices = num_devices
        self.num_servers = num_servers
        self.devices: List[IoTDevice] = []
        self.servers: List[EdgeServer] = []
        self.rl_agent = None

        self.scenario_map = {
            ScenarioType.SMART_HEALTHCARE: 0,
            ScenarioType.SMART_TRANSPORTATION: 1,
            ScenarioType.BASELINE_IOT: 2
        }
        self._initialize_scenario()

    def _get_state_for_rl(self, device):
        """Discretize device state for the Q-table."""
        task_bin = int(min(4, device.task_size // 10))
        latency_bin = int(min(4, device.latency_tolerance // 200))
        scenario_idx = self.scenario_map[device.scenario]
        return scenario_idx * 25 + task_bin * 5 + latency_bin

    def _initialize_scenario(self):
        scenario_gen = ScenarioGenerator(self.num_devices, self.num_servers, self.scenario_type)
        self.devices, self.servers = scenario_gen.generate_scenario()

        if self.algorithm == AlgorithmType.RL_BASED:
            state_space_size = 3 * 5 * 5  # 3 scenarios, 5 bins for task size, 5 for latency
            action_space_size = self.num_servers
            self.rl_agent = RLAgent(state_space_size, action_space_size)

    def _calculate_latency(self, device: IoTDevice, server: EdgeServer) -> Tuple[float, float]:
        """Calculate latency and communication delay."""
        # Convert bandwidth from Mbps to MBps
        bw_mbps = server.bandwidth / 8

        # Communication delay (ms) for uplink and downlink
        comm_delay = ((device.data_to_upload + device.model_size_downlink) / bw_mbps) * 1000

        # Simplified computation delay (ms)
        comp_delay = (device.task_size / (server.computational_capacity * 0.05)) # Simplified processing rate

        total_latency = comm_delay + comp_delay

        # 6G-specific factors
        if server.irs_elements > 0:
            total_latency *= (1 - (server.irs_elements / 1500)) # IRS improvement
        if device.mobility_speed > 0:
            total_latency *= (1 + (device.mobility_speed / 100)) # Mobility penalty

        return total_latency, comm_delay

    def _calculate_energy(self, device: IoTDevice, server: EdgeServer) -> float:
        energy = device.task_size * 2.5
        if device.federated_learning_capable: energy *= 1.2
        if server.irs_elements > 0: energy *= (1 - (server.irs_elements / 2500))
        energy *= (1 + (device.thz_frequency / 500))
        return energy

    def _calculate_security(self, device: IoTDevice, server: EdgeServer) -> float:
        security = np.random.uniform(0.7, 1.0)
        if self.scenario_type == ScenarioType.SMART_HEALTHCARE: security = np.random.uniform(0.85, 1.0)
        if device.federated_learning_capable and server.supports_federated_learning: security = min(1.0, security + 0.1)
        if server.irs_elements > 256: security = min(1.0, security + 0.05)
        return security

    def _calculate_utility(self, device: IoTDevice, server: EdgeServer, weights: Tuple[float, float, float]) -> float:
        w_latency, w_energy, w_security = weights
        latency, _ = self._calculate_latency(device, server)
        energy = self._calculate_energy(device, server)
        security = self._calculate_security(device, server)

        lat_util = max(0, 1 - (latency / device.latency_tolerance)) if device.latency_tolerance > 0 else 0
        eng_util = max(0, 1 - (energy / device.energy_constraint)) if device.energy_constraint > 0 else 0

        return (w_latency * lat_util + w_energy * eng_util + w_security * security)

    def _update_weights(self, iteration: int) -> Tuple[float, float, float]:
        if self.algorithm == AlgorithmType.AWRAF_STATIC:
            return (0.4, 0.3, 0.3)

        k = iteration
        if self.scenario_type == ScenarioType.SMART_HEALTHCARE:
            w_l, w_e = 0.6 - 0.1 * np.sin(k/10), 0.2 + 0.05 * np.cos(k/10)
        elif self.scenario_type == ScenarioType.SMART_TRANSPORTATION:
            w_l, w_e = 0.5 - 0.15 * np.sin(k/10), 0.4 + 0.1 * np.cos(k/10)
        else:
            w_l, w_e = 0.5 - 0.1 * np.sin(k/10), 0.4 + 0.1 * np.cos(k/10)
        w_s = 1.0 - w_l - w_e
        return (w_l, w_e, w_s)

    def run_simulation(self, max_iterations=100) -> Dict:
        """Main resource allocation loop."""
        history = {
            'device_utility': [], 'server_load': [], 'allocation_success_rate': [],
            'communication_delay': [], 'uplink_downlink_bw': []
        }

        # RL Training (if applicable)
        if self.algorithm == AlgorithmType.RL_BASED:
            for _ in range(500): # Training episodes
                device = random.choice(self.devices)
                state = self._get_state_for_rl(device)
                action = self.rl_agent.choose_action(state)
                server = self.servers[action]

                reward = self._calculate_utility(device, server, (0.4, 0.3, 0.3))
                if server.current_load + device.task_size > server.computational_capacity:
                    reward = -1 # Penalty for overloading

                next_state = self._get_state_for_rl(random.choice(self.devices))
                self.rl_agent.update_q_table(state, action, reward, next_state)

        for iteration in range(max_iterations):
            for server in self.servers:
                server.current_load = 0.0
                server.allocated_devices = []

            weights = self._update_weights(iteration)
            successful_allocations, total_utility, total_comm_delay, total_bw = 0, 0, 0, 0

            for device in self.devices:
                best_server, best_utility = None, -1

                if self.algorithm == AlgorithmType.RL_BASED:
                    state = self._get_state_for_rl(device)
                    action = self.rl_agent.choose_action(state)
                    server = self.servers[action]
                    if server.current_load + device.task_size <= server.computational_capacity:
                        best_server = server
                        best_utility = self._calculate_utility(device, server, weights)
                elif self.algorithm == AlgorithmType.GREEDY:
                    best_latency = float('inf')
                    for server in self.servers:
                        if server.current_load + device.task_size <= server.computational_capacity:
                            latency, _ = self._calculate_latency(device, server)
                            if latency < best_latency:
                                best_latency, best_server = latency, server
                    if best_server:
                        best_utility = self._calculate_utility(device, best_server, weights)
                else: # AWRAF (Static or Dynamic)
                    for server in self.servers:
                        if server.current_load + device.task_size <= server.computational_capacity:
                            utility = self._calculate_utility(device, server, weights)
                            if utility > best_utility:
                                best_utility, best_server = utility, server

                if best_server:
                    best_server.current_load += device.task_size
                    best_server.allocated_devices.append(device.device_id)
                    total_utility += best_utility
                    successful_allocations += 1
                    _, comm_delay = self._calculate_latency(device, best_server)
                    total_comm_delay += comm_delay
                    total_bw += device.data_to_upload + device.model_size_downlink

            history['device_utility'].append(total_utility / len(self.devices) if self.devices else 0)
            history['server_load'].append(np.mean([s.current_load / s.computational_capacity for s in self.servers]))
            history['allocation_success_rate'].append(successful_allocations / len(self.devices) if self.devices else 0)
            history['communication_delay'].append(total_comm_delay / successful_allocations if successful_allocations > 0 else 0)
            history['uplink_downlink_bw'].append(total_bw)

        return history
