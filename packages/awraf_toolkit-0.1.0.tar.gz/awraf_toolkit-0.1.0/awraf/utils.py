import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import random
from scipy import stats
from tabulate import tabulate
from typing import Dict, List, Tuple

from awraf.enums import ScenarioType, AlgorithmType

# Set default font sizes and figure size for better readability
plt.rcParams.update({'font.size': 14, 'figure.figsize': (18, 16), 'axes.titlesize': 16, 'axes.labelsize': 14})

def run_statistical_analysis(scenarios, algorithms, num_trials=30):
    """Runs simulations multiple times for statistical validation."""
    all_results = []
    print(f"\nRunning Statistical Validation ({num_trials} trials)...\n")

    for trial in range(num_trials):
        print(f"  Trial {trial + 1}/{num_trials}...")
        np.random.seed(trial) # Use trial number as seed for reproducibility
        random.seed(trial)
        for scenario_type, n_dev, n_serv in scenarios:
            for algo in algorithms:
                # Import here to avoid circular dependency and allow flexible import
                from awraf.simulator import AWRAFSimulator
                sim = AWRAFSimulator(scenario_type, algo, n_dev, n_serv)
                history = sim.run_simulation(max_iterations=50)

                res = {
                    'Trial': trial, 'Scenario': scenario_type.value, 'Algorithm': algo.value,
                    'Device_Utility': np.mean(history['device_utility']),
                    'Server_Load': np.mean(history['server_load']),
                    'Allocation_Success': history['allocation_success_rate'][-1],
                    'Communication_Delay': np.mean(history['communication_delay']),
                    'Total_Bandwidth': np.mean(history['uplink_downlink_bw'])
                }
                all_results.append(res)

    return pd.DataFrame(all_results)

def analyze_and_plot(df_stats: pd.DataFrame, scenarios_config: List[Tuple[ScenarioType, int, int]]):
    """Analyzes statistical results and creates improved plots."""
    agg_results = df_stats.groupby(['Scenario', 'Algorithm']).agg(
        Mean_Utility=('Device_Utility', 'mean'),
        CI_Utility=('Device_Utility', lambda x: 1.96 * x.std() / np.sqrt(len(x))),
        Mean_Load=('Server_Load', 'mean'),
        CI_Load=('Server_Load', lambda x: 1.96 * x.std() / np.sqrt(len(x))),
        Mean_Success_Rate=('Allocation_Success', 'mean')
    ).reset_index()

    print("\n--- T-Test Results (p-value for Device Utility) ---")
    for scenario in df_stats['Scenario'].unique():
        print(f"\nScenario: {scenario}")
        awraf_data = df_stats[(df_stats['Scenario'] == scenario) & (df_stats['Algorithm'] == AlgorithmType.AWRAF_DYNAMIC.value)]['Device_Utility']
        for algo in [AlgorithmType.AWRAF_STATIC, AlgorithmType.GREEDY, AlgorithmType.RL_BASED]:
            baseline_data = df_stats[(df_stats['Scenario'] == scenario) & (df_stats['Algorithm'] == algo.value)]['Device_Utility']
            if not baseline_data.empty:
                t_stat, p_value = stats.ttest_ind(awraf_data, baseline_data, equal_var=False) # Welch's t-test
                print(f"  vs {algo.value.split('(')[0].strip()}: p-value = {p_value:.4f} {'(Significant Improvement)' if p_value < 0.05 else ''}")

    sns.set_palette("viridis")
    fig, axes = plt.subplots(2, 2, figsize=(20, 16))
    fig.suptitle('AWRAF: Comprehensive Performance and Scalability Analysis', fontsize=22, weight='bold')

    # Plot 1: Device Utility
    ax1 = axes[0, 0]
    sns.barplot(data=agg_results, x='Scenario', y='Mean_Utility', hue='Algorithm', ax=ax1)
    
    # Add error bars only for algorithms that exist in results
    offset = -0.3
    for algo in [AlgorithmType.AWRAF_DYNAMIC, AlgorithmType.AWRAF_STATIC, AlgorithmType.GREEDY, AlgorithmType.RL_BASED]:
        algo_data = agg_results[agg_results['Algorithm'] == algo.value]
        if not algo_data.empty:
            ax1.errorbar(x=np.arange(len(scenarios_config)) + offset, 
                        y=algo_data['Mean_Utility'], 
                        yerr=algo_data['CI_Utility'], 
                        fmt='none', c='black', capsize=5)
        offset += 0.2

    ax1.set_title('Average Device Utility (with 95% CI)', fontsize=16)
    ax1.set_ylabel('Device Utility (Normalized)', fontsize=14)
    ax1.set_xticklabels([s[0].value.split('(')[0] for s in scenarios_config], rotation=10, ha="right")
    ax1.legend(title='Algorithm', bbox_to_anchor=(1.02, 1), loc='upper left')

    # Plot 2: Server Load
    ax2 = axes[0, 1]
    sns.barplot(data=agg_results, x='Scenario', y='Mean_Load', hue='Algorithm', ax=ax2)
    
    # Add error bars only for algorithms that exist in results
    offset = -0.3
    for algo in [AlgorithmType.AWRAF_DYNAMIC, AlgorithmType.AWRAF_STATIC, AlgorithmType.GREEDY, AlgorithmType.RL_BASED]:
        algo_data = agg_results[agg_results['Algorithm'] == algo.value]
        if not algo_data.empty:
            ax2.errorbar(x=np.arange(len(scenarios_config)) + offset, 
                        y=algo_data['Mean_Load'], 
                        yerr=algo_data['CI_Load'], 
                        fmt='none', c='black', capsize=5)
        offset += 0.2

    ax2.set_title('Average Server Load Ratio (with 95% CI)', fontsize=16)
    ax2.set_ylabel('Server Load Ratio', fontsize=14)
    ax2.set_xticklabels([s[0].value.split('(')[0] for s in scenarios_config], rotation=10, ha="right")
    ax2.legend(title='Algorithm').set_visible(False)

    # Plot 3: Communication Overhead
    comm_df = df_stats.groupby(['Scenario', 'Algorithm']).agg(
        Mean_Delay=('Communication_Delay', 'mean'),
        Mean_BW=('Total_Bandwidth', 'mean')
    ).reset_index()
    sns.barplot(data=comm_df, x='Scenario', y='Mean_Delay', hue='Algorithm', ax=axes[1, 0])
    axes[1, 0].set_title('Average Communication Delay per Task', fontsize=16)
    axes[1, 0].set_ylabel('Communication Delay (ms)', fontsize=14)
    axes[1, 0].set_xticklabels([s[0].value.split('(')[0] for s in scenarios_config], rotation=10, ha="right")
    axes[1, 0].legend(title='Algorithm').set_visible(False)

    # Plot 4: Scalability
    print("\nRunning Scalability Analysis...")
    device_counts = [50, 100, 200, 300, 400, 500]
    scalability_results = []
    for n_dev in device_counts:
        n_serv = int(n_dev / 5)
        for algo in AlgorithmType:
            from awraf.simulator import AWRAFSimulator
            sim = AWRAFSimulator(ScenarioType.SMART_TRANSPORTATION, algo, n_dev, n_serv)
            history = sim.run_simulation(max_iterations=20)
            scalability_results.append({'Devices': n_dev, 'Algorithm': algo.value, 'Utility': np.mean(history['device_utility'])})
    scalability_df = pd.DataFrame(scalability_results)

    sns.lineplot(data=scalability_df, x='Devices', y='Utility', hue='Algorithm', style='Algorithm', markers=True, dashes=False, ax=axes[1, 1], linewidth=2.5)
    axes[1, 1].set_title('Scalability: Utility vs. Number of Devices', fontsize=16)
    axes[1, 1].set_xlabel('Number of Devices', fontsize=14)
    axes[1, 1].set_ylabel('Device Utility (Normalized)', fontsize=14)
    axes[1, 1].legend(title='Algorithm')

    for ax in axes.flat: ax.grid(True, which='both', linestyle='--', linewidth=0.5)

    plt.tight_layout(rect=[0, 0.03, 0.9, 0.95])
    plt.show()

    return agg_results

def print_summary_table(df_agg: pd.DataFrame, df_stats: pd.DataFrame):
    """Prints the final comprehensive summary table."""
    print("\n" + "="*140)
    print("AWRAF COMPREHENSIVE PERFORMANCE COMPARISON SUMMARY")
    print("="*140)

    df_agg['Device Utility (μ ± CI)'] = df_agg.apply(lambda r: f"{r['Mean_Utility']:.3f} ± {r['CI_Utility']:.3f}", axis=1)
    df_agg['Server Load (μ ± CI)'] = df_agg.apply(lambda r: f"{r['Mean_Load']:.3f} ± {r['CI_Load']:.3f}", axis=1)
    df_agg['Success Rate (%)'] = df_agg['Mean_Success_Rate'].apply(lambda x: f"{x*100:.1f}%")

    comm_delay_agg = df_stats.groupby(['Scenario', 'Algorithm']).agg(
        Mean_Delay=('Communication_Delay', 'mean'),
        CI_Delay=('Communication_Delay', lambda x: 1.96 * x.std() / np.sqrt(len(x)))
    ).reset_index()
    comm_delay_agg['Comm. Delay (ms)'] = comm_delay_agg.apply(lambda r: f"{r['Mean_Delay']:.2f} ± {r['CI_Delay']:.2f}", axis=1)

    summary = df_agg.merge(comm_delay_agg[['Scenario', 'Algorithm', 'Comm. Delay (ms)']], on=['Scenario', 'Algorithm'])

    summary_pivot = summary.pivot(index='Scenario', columns='Algorithm', values=['Device Utility (μ ± CI)', 'Server Load (μ ± CI)', 'Success Rate (%)', 'Comm. Delay (ms)'])

    print(tabulate(summary_pivot, headers='keys', tablefmt='grid'))
    print("="*140)
