import numpy as np
from dataclasses import dataclass, field
from typing import List
from awraf.enums import ScenarioType

@dataclass
class IoTDevice:
    """Represents an IoT device with realistic 6G characteristics."""
    device_id: int
    task_size: float
    latency_tolerance: float
    energy_constraint: float
    device_type: str
    scenario: ScenarioType
    mobility_speed: float = 0.0
    federated_learning_capable: bool = False
    thz_frequency: float = 275.0
    data_to_upload: float = 0.0  # MB, for communication overhead
    model_size_downlink: float = 0.0 # MB, for FL model updates

@dataclass
class EdgeServer:
    """Represents an edge server with 6G capabilities."""
    server_id: int
    computational_capacity: float
    bandwidth: float
    energy_capacity: float
    server_type: str
    irs_elements: int = 0
    thz_bandwidth: float = 10000.0
    supports_federated_learning: bool = False
    current_load: float = 0.0
    allocated_devices: List[int] = field(default_factory=list)
