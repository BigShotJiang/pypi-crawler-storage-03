#!/usr/bin/env python3
"""
Command-line interface for the AWRAF Toolkit.
"""

import argparse
import sys
import numpy as np
import random
from typing import List, Tuple

from awraf.simulator import AWRAFSimulator
from awraf.enums import ScenarioType, AlgorithmType
from awraf.utils import run_statistical_analysis, analyze_and_plot, print_summary_table


def parse_scenarios(scenario_str: str) -> List[Tuple[ScenarioType, int, int]]:
    """Parse scenario string into list of tuples."""
    scenarios = []
    for scenario in scenario_str.split(','):
        parts = scenario.strip().split(':')
        if len(parts) != 3:
            print(f"Invalid scenario format: {scenario}. Use 'scenario:devices:servers'")
            sys.exit(1)
        
        scenario_name, devices, servers = parts
        try:
            scenario_type = ScenarioType[scenario_name.upper()]
            devices = int(devices)
            servers = int(servers)
            scenarios.append((scenario_type, devices, servers))
        except (KeyError, ValueError) as e:
            print(f"Invalid scenario: {e}")
            sys.exit(1)
    
    return scenarios


def parse_algorithms(algorithm_str: str) -> List[AlgorithmType]:
    """Parse algorithm string into list of AlgorithmType."""
    algorithms = []
    for algo in algorithm_str.split(','):
        try:
            algorithm = AlgorithmType[algo.strip().upper()]
            algorithms.append(algorithm)
        except KeyError:
            print(f"Invalid algorithm: {algo}. Available: {[a.name for a in AlgorithmType]}")
            sys.exit(1)
    
    return algorithms


def main():
    """Main CLI function."""
    parser = argparse.ArgumentParser(
        description="AWRAF Toolkit: Adaptive Weight-Based Resource Allocation Framework for 6G IoT",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run basic simulation
  awraf-sim --scenarios "SMART_HEALTHCARE:50:10" --algorithms "AWRAF_DYNAMIC"
  
  # Run comprehensive analysis
  awraf-sim --scenarios "SMART_HEALTHCARE:50:10,SMART_TRANSPORTATION:60:12" --algorithms "AWRAF_DYNAMIC,GREEDY" --trials 50
  
  # Quick demo
  awraf-sim --demo
        """
    )
    
    parser.add_argument(
        '--scenarios',
        type=str,
        help='Comma-separated scenarios in format "scenario:devices:servers" (e.g., "SMART_HEALTHCARE:50:10")'
    )
    
    parser.add_argument(
        '--algorithms',
        type=str,
        help='Comma-separated algorithms (e.g., "AWRAF_DYNAMIC,GREEDY")'
    )
    
    parser.add_argument(
        '--trials',
        type=int,
        default=30,
        help='Number of simulation trials (default: 30)'
    )
    
    parser.add_argument(
        '--demo',
        action='store_true',
        help='Run demo with default scenarios and algorithms'
    )
    
    parser.add_argument(
        '--seed',
        type=int,
        help='Random seed for reproducibility'
    )
    
    args = parser.parse_args()
    
    # Set random seed if provided
    if args.seed is not None:
        np.random.seed(args.seed)
        random.seed(args.seed)
        print(f"Using random seed: {args.seed}")
    
    # Demo mode
    if args.demo:
        print("🚀 Running AWRAF Toolkit Demo...")
        scenarios = [
            (ScenarioType.SMART_HEALTHCARE, 30, 6),
            (ScenarioType.SMART_TRANSPORTATION, 40, 8),
            (ScenarioType.BASELINE_IOT, 25, 5)
        ]
        algorithms = [
            AlgorithmType.AWRAF_DYNAMIC,
            AlgorithmType.GREEDY
        ]
        trials = 10
    else:
        # Parse command line arguments
        if not args.scenarios or not args.algorithms:
            parser.error("--scenarios and --algorithms are required (or use --demo)")
        
        scenarios = parse_scenarios(args.scenarios)
        algorithms = parse_algorithms(args.algorithms)
        trials = args.trials
    
    # Print configuration
    print(f"📊 Scenarios: {[f'{s[0].name}({s[1]} devices, {s[2]} servers)' for s in scenarios]}")
    print(f"🔧 Algorithms: {[a.name for a in algorithms]}")
    print(f"🔄 Trials: {trials}")
    print()
    
    try:
        # Run simulation
        print("⏳ Running statistical analysis...")
        results = run_statistical_analysis(scenarios, algorithms, num_trials=trials)
        
        print("📈 Generating plots and analysis...")
        aggregated = analyze_and_plot(results, scenarios)
        
        print("📋 Printing summary table...")
        print_summary_table(aggregated, results)
        
        print("\n✅ Analysis complete!")
        
    except Exception as e:
        print(f"❌ Error during simulation: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
