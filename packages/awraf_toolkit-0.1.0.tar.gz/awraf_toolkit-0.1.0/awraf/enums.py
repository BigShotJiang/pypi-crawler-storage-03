from enum import Enum

class ScenarioType(Enum):
    SMART_HEALTHCARE = "Smart Healthcare (IRS-THz)"
    SMART_TRANSPORTATION = "Smart Transportation (V2X-THz)"
    BASELINE_IOT = "Baseline IoT"

class AlgorithmType(Enum):
    AWRAF_DYNAMIC = "AWRAF (Dynamic Weights)"
    AWRAF_STATIC = "AWRAF (Static Weights)"
    GREEDY = "Greedy Allocation"
    RL_BASED = "Reinforcement Learning"
