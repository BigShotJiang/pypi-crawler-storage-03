# Unit tests for the scenario module

import unittest
import numpy as np
from awraf.scenario import ScenarioGenerator
from awraf.enums import ScenarioType

class TestScenarioGenerator(unittest.TestCase):

    def test_healthcare_scenario_generation(self):
        gen = ScenarioGenerator(num_devices=5, num_servers=2, scenario_type=ScenarioType.SMART_HEALTHCARE)
        devices, servers = gen.generate_scenario()
        self.assertEqual(len(devices), 5)
        self.assertEqual(len(servers), 2)
        self.assertTrue(all(d.device_type == "wearable_sensor" for d in devices))
        self.assertTrue(all(s.server_type == "healthcare_edge" for s in servers))

    def test_transportation_scenario_generation(self):
        gen = ScenarioGenerator(num_devices=5, num_servers=2, scenario_type=ScenarioType.SMART_TRANSPORTATION)
        devices, servers = gen.generate_scenario()
        self.assertEqual(len(devices), 5)
        self.assertEqual(len(servers), 2)
        self.assertTrue(all(d.device_type == "vehicle" for d in devices))
        self.assertTrue(all(s.server_type == "roadside_unit" for s in servers))

    def test_baseline_scenario_generation(self):
        gen = ScenarioGenerator(num_devices=5, num_servers=2, scenario_type=ScenarioType.BASELINE_IOT)
        devices, servers = gen.generate_scenario()
        self.assertEqual(len(devices), 5)
        self.assertEqual(len(servers), 2)
        self.assertTrue(all(d.device_type == "generic" for d in devices))
        self.assertTrue(all(s.server_type == "generic" for s in servers))

if __name__ == '__main__':
    unittest.main()
