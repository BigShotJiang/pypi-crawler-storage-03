# Unit tests for the simulator module

import unittest
import numpy as np
from awraf.simulator import AWRAFSimulator
from awraf.enums import ScenarioType, AlgorithmType

class TestAWRAFSimulator(unittest.TestCase):

    def setUp(self):
        # Common setup for tests
        self.num_devices = 10
        self.num_servers = 2
        np.random.seed(42)
        import random
        random.seed(42)

    def test_initialization(self):
        sim = AWRAFSimulator(ScenarioType.BASELINE_IOT, AlgorithmType.AWRAF_DYNAMIC, self.num_devices, self.num_servers)
        self.assertEqual(len(sim.devices), self.num_devices)
        self.assertEqual(len(sim.servers), self.num_servers)
        self.assertEqual(sim.scenario_type, ScenarioType.BASELINE_IOT)
        self.assertEqual(sim.algorithm, AlgorithmType.AWRAF_DYNAMIC)

    def test_run_simulation_dynamic_awraf(self):
        sim = AWRAFSimulator(ScenarioType.BASELINE_IOT, AlgorithmType.AWRAF_DYNAMIC, self.num_devices, self.num_servers)
        history = sim.run_simulation(max_iterations=5)
        self.assertIn('device_utility', history)
        self.assertIn('server_load', history)
        self.assertEqual(len(history['device_utility']), 5)

    def test_run_simulation_greedy(self):
        sim = AWRAFSimulator(ScenarioType.BASELINE_IOT, AlgorithmType.GREEDY, self.num_devices, self.num_servers)
        history = sim.run_simulation(max_iterations=5)
        self.assertIn('device_utility', history)

    def test_run_simulation_rl_based(self):
        sim = AWRAFSimulator(ScenarioType.BASELINE_IOT, AlgorithmType.RL_BASED, self.num_devices, self.num_servers)
        history = sim.run_simulation(max_iterations=5)
        self.assertIn('device_utility', history)

    # Add more specific tests for calculations, constraints, etc.

if __name__ == '__main__':
    unittest.main()
