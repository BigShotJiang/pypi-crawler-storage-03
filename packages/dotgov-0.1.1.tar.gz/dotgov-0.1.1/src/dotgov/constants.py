## Locations

COLOMBIA = "www.datos.gov.co"

SEATTLE = "data.seattle.gov"

CHICAGO = "data.cityofchicago.org"


## Datasets

COLOMBIA_PROCUREMENT = "p6dx-8zbt"

SEATTLE_911 = "kzjm-xkqj"

CHICAGO_CRIMES = "ijzp-q8t2"
