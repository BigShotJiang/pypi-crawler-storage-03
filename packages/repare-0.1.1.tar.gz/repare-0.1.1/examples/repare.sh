#!/bin/bash

repare -n "nodes.csv" -r "relations.csv" -o "outputs"
