"""
@Author: kang.yang
@Date: 2024/1/25 11:22
"""


class App:
    did = None
    pkg = None
    ability = None
    wda_project_path = None
    sib_path = None
    sonic_host = None
    sonic_user = None
    sonic_pwd = None

