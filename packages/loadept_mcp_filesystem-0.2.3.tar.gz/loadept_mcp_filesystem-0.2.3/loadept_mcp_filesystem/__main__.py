from loadept_mcp_filesystem import main

main()
