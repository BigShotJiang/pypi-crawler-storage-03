from keywordsai_sdk.keywordsai_types.base_types import KeywordsAIBaseModel

class ConditionParams(KeywordsAIBaseModel):
    condition_slug: str