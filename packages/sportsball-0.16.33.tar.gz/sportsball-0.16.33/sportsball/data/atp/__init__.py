"""The ATP data sportsball module."""

from .combined.atp_combined_league_model import \
    ATPCombinedLeagueModel as ATPLeagueModel

__all__ = ("ATPLeagueModel",)
