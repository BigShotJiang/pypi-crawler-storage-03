"""
WaveYo-API CLI Tool
Command line interface for WaveYo-API project management.
"""

__version__ = "0.1.0"
__author__ = "WaveYo Team"
__email__ = "contact@waveyo.com"
__license__ = "MIT"
