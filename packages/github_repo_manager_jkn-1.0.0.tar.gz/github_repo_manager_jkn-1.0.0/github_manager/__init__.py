"""
GitHub Manager Pro - Un outil professionnel pour gérer les dépôts GitHub
"""

__version__ = "1.0.0"
__author__ = "Jonathan K-N"
__email__ = "your.email@example.com"

from .main import main

__all__ = ["main"]