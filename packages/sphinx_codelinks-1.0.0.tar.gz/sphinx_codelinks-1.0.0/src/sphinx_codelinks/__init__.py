"""CodeLinks source code analyser"""

from sphinx_codelinks.sphinx_extension.source_tracing import setup

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "setup",
]
