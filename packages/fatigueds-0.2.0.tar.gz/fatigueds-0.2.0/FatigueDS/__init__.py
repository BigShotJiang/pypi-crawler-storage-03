"""
A project template for the sdPy effort..
"""

__version__ = "0.2.0"
from .spec_dev import SpecificationDevelopment
from . import tools
from . import signals