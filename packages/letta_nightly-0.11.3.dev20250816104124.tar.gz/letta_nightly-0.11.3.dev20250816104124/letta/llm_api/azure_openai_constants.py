AZURE_MODEL_TO_CONTEXT_LENGTH = {
    "babbage-002": 16384,
    "davinci-002": 16384,
    "gpt-35-turbo-0613": 4096,
    "gpt-35-turbo-1106": 16385,
    "gpt-35-turbo-0125": 16385,
    "gpt-4-0613": 8192,
    "gpt-4o-mini-2024-07-18": 128000,
    "gpt-4o-mini": 128000,
    "gpt-4o": 128000,
}
