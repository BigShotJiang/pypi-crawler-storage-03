# Kafka Topics

This package defines centralized Kafka topic constants used across various Pack Bridge services.