import sys
import types
import importlib

import pytest


@pytest.fixture(autouse=True)
def stub_hardware_modules(monkeypatch):
    fake_board = types.SimpleNamespace()
    fake_board.SPI = lambda: object()
    fake_board.D5 = object()
    sys.modules.setdefault("board", fake_board)

    class _DigitalInOut:
        def __init__(self, *_, **__):
            pass

    fake_digitalio = types.SimpleNamespace(DigitalInOut=_DigitalInOut)
    sys.modules.setdefault("digitalio", fake_digitalio)

    fake_max31865_mod = types.ModuleType("temperature_expansion_kit_plugin.max31865")

    class _FakeMAX31865:
        def __init__(self, *_, **__):
            self._t = 30.0

        @property
        def temperature(self):
            return self._t

    fake_max31865_mod.MAX31865 = _FakeMAX31865
    sys.modules.setdefault("temperature_expansion_kit_plugin.max31865", fake_max31865_mod)

    import os
    core_path = os.path.expanduser("~/code/pioreactor/core")
    if core_path not in sys.path:
        sys.path.insert(0, core_path)
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

    # smbus deps used by pioreactor's ADC layer on Linux; stub for tests.
    sys.modules.setdefault("smbus2", types.SimpleNamespace(SMBus=object))
    sys.modules.setdefault("smbus", types.SimpleNamespace(SMBus=object))

    monkeypatch.setenv("PIOREACTOR_TESTING", "1")
    import pioreactor.hardware as hw
    import pioreactor.whoami as whoami

    monkeypatch.setattr(hw, "is_heating_pcb_present", lambda: True, raising=False)
    monkeypatch.setattr(whoami, "is_testing_env", lambda: True, raising=False)
    monkeypatch.setattr(whoami, "is_active", lambda unit: True, raising=False)

    class _FakeClient:
        def is_connected(self):
            return True

        def will_set(self, *args, **kwargs):
            pass
        def publish(self, *args, **kwargs):
            class _Msg:
                def wait_for_publish(self, timeout=None):
                    return True

            return _Msg()

        def loop_stop(self):
            pass

        def disconnect(self):
            pass

        def message_callback_add(self, *args, **kwargs):
            pass

        def subscribe(self, *args, **kwargs):
            class _Res:
                rc = 0
            return _Res(), 0

    import pioreactor.utils.pwm as pwm_mod
    monkeypatch.setattr(pwm_mod, "create_client", lambda *a, **k: _FakeClient(), raising=False)

    # prevent file logging attempts and MQTT in create_logger
    import logging as pylog
    from logging import handlers as std_handlers
    monkeypatch.setattr(std_handlers, "WatchedFileHandler", lambda *a, **k: pylog.StreamHandler(), raising=False)

    import pioreactor.pubsub as pubsub_mod
    monkeypatch.setattr(pubsub_mod, "create_client", lambda *a, **k: _FakeClient(), raising=False)

    # stub JobManager to avoid sqlite writes
    import pioreactor.utils as utils_mod

    class _MemCache:
        _store = {}

        def __init__(self, name):
            self.name = name

        def __enter__(self):
            return self._store.setdefault(self.name, {})

        def __exit__(self, *args):
            return False

    monkeypatch.setattr(utils_mod, "local_intermittent_storage", lambda name: _MemCache(name), raising=False)
    monkeypatch.setattr(pwm_mod, "local_intermittent_storage", lambda name: _MemCache(name), raising=False)

    class _FakeJobManager:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def register_and_set_running(self, *args, **kwargs):
            return 1

        def set_job_to_disconnected(self, *args, **kwargs):
            pass

        def set_job_to_lost(self, *args, **kwargs):
            pass

        def set_job_to_failed(self, *args, **kwargs):
            pass

        def set_job_to_finished(self, *args, **kwargs):
            pass

        def update_pid(self, *args, **kwargs):
            pass

        def is_job_running(self, *args, **kwargs):
            return False

        def upsert_setting(self, *args, **kwargs):
            pass

        def set_not_running(self, *args, **kwargs):
            pass

    monkeypatch.setattr(utils_mod, "JobManager", _FakeJobManager, raising=False)

    try:
        import temperature_expansion_kit_plugin as plugin
        importlib.reload(plugin)
    except Exception:
        pass


def make_thermostat(**kwargs):
    import temperature_expansion_kit_plugin as plugin

    return plugin.Thermostat(
        unit=kwargs.get("unit", "unit-test"),
        experiment=kwargs.get("experiment", "exp-test"),
        target_temperature=kwargs.get("target_temperature", 35),
    )


def test_thermostat_target_temperature_clamping():
    import temperature_expansion_kit_plugin as plugin

    with make_thermostat(target_temperature=40) as t:
        t.set_target_temperature(85)
        assert t.target_temperature == plugin.Thermostat.MAX_TARGET_TEMP
        t.set_target_temperature(35)
        assert t.target_temperature == 35


def test_child_cant_update_heater_when_locked():
    import temperature_expansion_kit_plugin as plugin

    with make_thermostat(target_temperature=30) as t:
        assert t.update_heater(50)
        with t.pwm.lock_temporarily():
            assert not t.update_heater(50)
            assert not t.update_heater(60)
        assert t.update_heater(25)


def test_heating_is_reduced_when_set_temp_is_exceeded():
    with make_thermostat(target_temperature=25) as t:
        setattr(
            t.heating_pcb_tmp_driver,
            "get_temperature",
            lambda *args: t.MAX_TEMP_TO_REDUCE_HEATING + 0.1,
        )
        t._update_heater(50)
        assert t.heater_duty_cycle == 50
        t.read_external_temperature()
        assert 0 < t.heater_duty_cycle < 50


def test_heating_stops_when_max_temp_is_exceeded():
    with make_thermostat(target_temperature=25) as t:
        setattr(
            t.heating_pcb_tmp_driver,
            "get_temperature",
            lambda *args: t.MAX_TEMP_TO_DISABLE_HEATING + 0.1,
        )
        t._update_heater(50)
        assert t.heater_duty_cycle == 50
        t.read_external_temperature()
        assert t.heater_duty_cycle == 0


def test_sleeping_turns_off_heater():
    with make_thermostat(target_temperature=30) as t:
        t.update_heater(40)
        assert t.heater_duty_cycle > 0
        t.on_sleeping()
        assert t.heater_duty_cycle == 0
