"""
Extension module.
"""

from ams.extension import eva  # NOQA
