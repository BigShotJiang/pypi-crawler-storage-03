.. role:: raw-html(raw)
    :format: html

*******
License
*******

GNU Public License v3
*********************
| Copyright :raw-html:`&copy;` 2023-2025 Jinning Wang.

AMS is free software; you can redistribute it and/or modify it under the terms
of the `GNU General Public License <http://www.gnu.org/licenses/gpl-3.0.html>`_
as published by the Free Software Foundation; either version 3 of the License,
or (at your option) any later version.

AMS is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the `GNU General Public License
<http://www.gnu.org/licenses/gpl-3.0.html>`_ for more details.