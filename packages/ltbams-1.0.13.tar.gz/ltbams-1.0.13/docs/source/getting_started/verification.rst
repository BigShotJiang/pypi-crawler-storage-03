.. _verification:

============
Verification
============

This section presents the verification of AMS by comparing the DCOPF results
with other tools.

.. toctree::
   :maxdepth: 2

   ../_examples/verification/ams_dcopf_verification.ipynb
