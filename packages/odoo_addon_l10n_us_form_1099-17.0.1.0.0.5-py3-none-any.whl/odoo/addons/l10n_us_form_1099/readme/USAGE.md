To use this module, you need to:

1.  Go to Contacts
2.  Create or select a partner
3.  Go to the Sales & Purchases tab
4.  Check the "Is a 1099" box
5.  Select their 1099 type
6.  If their type is 1099-MISC, you can select their box
7.  Go to Invoicing \> Vendors \> Bills (or Payments)
8.  Create vendor bills and payments for those 1099 vendors
9.  Go to Invoicing \> Reporting \> 1099 Report
