1.  Go to Contacts \> Configuration \> 1099 Types
2.  Review the existing types and update them if necessary
3.  Go to Contacts \> Configuration \> 1099-MISC Boxes
4.  Review the existing boxes and update them if necessary
