(changelog)=

# Change Log

## Aug-20-2025: v0.1.0a0

- Release of the first alpha version of **jQMC**.
