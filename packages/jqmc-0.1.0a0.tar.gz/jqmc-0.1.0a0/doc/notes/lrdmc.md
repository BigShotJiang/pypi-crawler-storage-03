# Lattice Regularized Diffusion Monte Carlo (LRDMC)

(lrdmc_tags)=

## Green's Function Monte Carlo (GFMC)

Work in progress.
