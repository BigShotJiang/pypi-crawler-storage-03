# Technical notes

Technical notes of **jQMC**.

```{toctree}
:hidden:
ao
vmc
vmcopt
lrdmc
atomic-forces
jax
trexio
```
