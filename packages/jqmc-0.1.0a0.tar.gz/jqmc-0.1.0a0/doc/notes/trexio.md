# Interfaces with TREX-IO

(trexio_tags)=

## Conventions employed in jQMC and TREX-IO

Work in progress.
