# How to cite jQMC

(citation_of_jQMC)=

## Citation of jQMC

If you used jQMC in your reseach project, please cite the following articles.
This indeed helps the jQMC project to continue:

- "jQMC: JAX-based ab initio Quantum Monte Carlo package",

  Kosuke Nakano, and Michele Casula, in preparation (2025)

  ```
  @article{nakano-jqmc,
    author  = {Nakano, Kosuke and Casula, Michele},
    title   = {jQMC: JAX-based ab initio Quantum Monte Carlo package},
    journal = {in preparation},
    %volume  = {},
    %number  = {},
    %pages   = {},
    year    = {2025},
    %doi     = {}
  }
  ```
