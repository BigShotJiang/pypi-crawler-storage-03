# iPilot [![CI](https://github.com/luketainton/pypilot/actions/workflows/ci.yml/badge.svg)](https://github.com/luketainton/pypilot/actions/workflows/ci.yml) [![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=luketainton_pypilot&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=luketainton_pypilot)

## Description
IP Information Lookup Tool

## How to install
`pip install ipilot`

## How to use
`ipilot --help`
