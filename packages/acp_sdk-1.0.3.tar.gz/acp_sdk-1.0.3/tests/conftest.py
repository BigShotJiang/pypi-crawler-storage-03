# Copyright 2025 © BeeAI a Series of LF Projects, LLC
# SPDX-License-Identifier: Apache-2.0

pytest_plugins = [
    "e2e.fixtures.client",
    "e2e.fixtures.server",
]
