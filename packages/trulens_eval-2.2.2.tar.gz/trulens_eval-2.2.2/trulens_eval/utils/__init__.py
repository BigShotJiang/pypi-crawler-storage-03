# ruff: noqa: E402
"""
!!! warning
    This module is deprecated and will be removed. Use `trulens.core.utils`
    instead.
"""

from trulens.core.utils import deprecation as deprecation_utils

deprecation_utils.packages_dep_warn()
