"""Common dialogs"""

from doorstop_edit.dialogs.confirm_dialog import ConfirmDialog  # noqa
from doorstop_edit.dialogs.diff_dialog import DiffDialog  # noqa
from doorstop_edit.dialogs.info_dialog import InfoDialog  # noqa
from doorstop_edit.dialogs.setting_dialog import SettingDialog  # noqa
