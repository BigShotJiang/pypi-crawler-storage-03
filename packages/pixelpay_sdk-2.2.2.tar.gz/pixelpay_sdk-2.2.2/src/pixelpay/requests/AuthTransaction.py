from .PaymentTransaction import PaymentTransaction


class AuthTransaction(PaymentTransaction):
    pass
