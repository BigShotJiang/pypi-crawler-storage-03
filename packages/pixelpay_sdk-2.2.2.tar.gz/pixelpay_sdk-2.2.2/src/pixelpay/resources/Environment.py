class Environment:
    LIVE: str = "live"
    TEST: str = "test"
    SANDBOX: str = "sandbox"
    STAGING: str = "staging"
    ENV: str = "prod" # test | prod
