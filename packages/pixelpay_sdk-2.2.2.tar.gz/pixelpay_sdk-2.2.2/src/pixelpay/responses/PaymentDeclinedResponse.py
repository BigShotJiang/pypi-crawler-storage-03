from ..base import Response


class PaymentDeclinedResponse(Response):
    pass
