from ..base import Response


class InputErrorResponse(Response):
    pass
