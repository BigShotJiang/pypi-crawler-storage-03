from ..base import Response


class PreconditionalResponse(Response):
    pass
