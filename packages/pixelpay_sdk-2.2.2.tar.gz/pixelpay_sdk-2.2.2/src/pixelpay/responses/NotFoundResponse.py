from ..base import Response


class NotFoundResponse(Response):
    pass
