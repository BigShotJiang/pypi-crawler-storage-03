from ..base import Response


class NetworkFailureResponse(Response):
    pass
