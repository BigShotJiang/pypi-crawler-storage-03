from ..base import Response


class FailureResponse(Response):
    pass
