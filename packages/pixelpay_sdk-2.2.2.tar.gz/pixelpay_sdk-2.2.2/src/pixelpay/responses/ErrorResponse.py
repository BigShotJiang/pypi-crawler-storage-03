from ..base import Response


class ErrorResponse(Response):
    pass
