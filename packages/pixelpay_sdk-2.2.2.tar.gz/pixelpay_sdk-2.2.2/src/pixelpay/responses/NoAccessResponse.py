from ..base import Response


class NoAccessResponse(Response):
    pass
