from ..base import Response


class SuccessResponse(Response):
    pass
