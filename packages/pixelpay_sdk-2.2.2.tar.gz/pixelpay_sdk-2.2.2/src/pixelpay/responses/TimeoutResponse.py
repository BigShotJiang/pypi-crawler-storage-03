from ..base import Response


class TimeoutResponse(Response):
    pass
