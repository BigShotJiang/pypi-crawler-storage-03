from ..base import Response


class PayloadResponse(Response):
    pass
