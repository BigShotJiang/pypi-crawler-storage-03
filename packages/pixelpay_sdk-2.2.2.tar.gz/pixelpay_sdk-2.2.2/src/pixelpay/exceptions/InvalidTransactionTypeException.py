class InvalidTransactionTypeException(Exception):
    pass
