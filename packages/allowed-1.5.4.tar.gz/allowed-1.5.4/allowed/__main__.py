from .allowed import main

main()