__version__ = "2.0.0"
from .image_labeler import ImageLabeler