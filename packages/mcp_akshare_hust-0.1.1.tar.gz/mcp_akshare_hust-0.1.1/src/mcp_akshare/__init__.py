"""MCP AKShare - A Model Context Protocol server for AKShare stock data."""

__version__ = "0.1.1"

from .main import main

__all__ = ["main"]