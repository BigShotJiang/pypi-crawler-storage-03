#!/usr/bin/env python

import os
import json
from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass
import time
from datetime import datetime, timedelta
from enum import Enum

import dotenv
import requests
from fastmcp import FastMCP
from prometheus_mcp_server.logging_config import get_logger

dotenv.load_dotenv()
mcp = FastMCP("Prometheus MCP")

# Get logger instance
logger = get_logger()

def validate_limit_parameter(limit: Optional[Union[int, str]]) -> Optional[int]:
    """Validate and convert limit parameter to integer if needed.
    
    Args:
        limit: Optional limit parameter that can be int, str, or None
        
    Returns:
        Optional[int]: Validated integer limit or None
        
    Raises:
        ValueError: If string limit cannot be converted to valid integer
    """
    if limit is None:
        return None
    if isinstance(limit, str):
        try:
            return int(limit)
        except ValueError:
            raise ValueError(f"Invalid limit value '{limit}': must be a valid integer")
    return limit

class TransportType(str, Enum):
    """Supported MCP server transport types."""

    STDIO = "stdio"
    HTTP = "http"
    SSE = "sse"

    @classmethod
    def values(cls) -> list[str]:
        """Get all valid transport values."""
        return [transport.value for transport in cls]

@dataclass
class MCPServerConfig:
    """Global Configuration for MCP."""
    mcp_server_transport: TransportType = None
    mcp_bind_host: str = None
    mcp_bind_port: int = None

    def __post_init__(self):
        """Validate mcp configuration."""
        if not self.mcp_server_transport:
            raise ValueError("MCP SERVER TRANSPORT is required")
        if not self.mcp_bind_host:
            raise ValueError(f"MCP BIND HOST is required")
        if not self.mcp_bind_port:
            raise ValueError(f"MCP BIND PORT is required")

@dataclass
class PrometheusConfig:
    url: str
    # Optional credentials
    username: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None
    # Optional Org ID for multi-tenant setups
    org_id: Optional[str] = None
    # Optional Custom MCP Server Configuration
    mcp_server_config: Optional[MCPServerConfig] = None

config = PrometheusConfig(
    url=os.environ.get("PROMETHEUS_URL", ""),
    username=os.environ.get("PROMETHEUS_USERNAME", ""),
    password=os.environ.get("PROMETHEUS_PASSWORD", ""),
    token=os.environ.get("PROMETHEUS_TOKEN", ""),
    org_id=os.environ.get("ORG_ID", ""),
    mcp_server_config=MCPServerConfig(
        mcp_server_transport=os.environ.get("PROMETHEUS_MCP_SERVER_TRANSPORT", "stdio").lower(),
        mcp_bind_host=os.environ.get("PROMETHEUS_MCP_BIND_HOST", "127.0.0.1"),
        mcp_bind_port=int(os.environ.get("PROMETHEUS_MCP_BIND_PORT", "8080"))
    )
)

def get_prometheus_auth():
    """Get authentication for Prometheus based on provided credentials."""
    if config.token:
        return {"Authorization": f"Bearer {config.token}"}
    elif config.username and config.password:
        return requests.auth.HTTPBasicAuth(config.username, config.password)
    return None

def make_prometheus_request(endpoint, params=None):
    """Make a request to the Prometheus API with proper authentication and headers."""
    if not config.url:
        logger.error("Prometheus configuration missing", error="PROMETHEUS_URL not set")
        raise ValueError("Prometheus configuration is missing. Please set PROMETHEUS_URL environment variable.")

    url = f"{config.url.rstrip('/')}/api/v1/{endpoint}"
    auth = get_prometheus_auth()
    headers = {}

    if isinstance(auth, dict):  # Token auth is passed via headers
        headers.update(auth)
        auth = None  # Clear auth for requests.get if it's already in headers
    
    # Add OrgID header if specified
    if config.org_id:
        headers["X-Scope-OrgID"] = config.org_id

    try:
        logger.debug("Making Prometheus API request", endpoint=endpoint, url=url, params=params)
        
        # Make the request with appropriate headers and auth
        response = requests.get(url, params=params, auth=auth, headers=headers)
        
        response.raise_for_status()
        result = response.json()
        
        if result["status"] != "success":
            error_msg = result.get('error', 'Unknown error')
            logger.error("Prometheus API returned error", endpoint=endpoint, error=error_msg, status=result["status"])
            raise ValueError(f"Prometheus API error: {error_msg}")
        
        data_field = result.get("data", {})
        if isinstance(data_field, dict):
            result_type = data_field.get("resultType")
        else:
            result_type = "list"
        logger.debug("Prometheus API request successful", endpoint=endpoint, result_type=result_type)
        return result["data"]
    
    except requests.exceptions.RequestException as e:
        logger.error("HTTP request to Prometheus failed", endpoint=endpoint, url=url, error=str(e), error_type=type(e).__name__)
        raise
    except json.JSONDecodeError as e:
        logger.error("Failed to parse Prometheus response as JSON", endpoint=endpoint, url=url, error=str(e))
        raise ValueError(f"Invalid JSON response from Prometheus: {str(e)}")
    except Exception as e:
        logger.error("Unexpected error during Prometheus request", endpoint=endpoint, url=url, error=str(e), error_type=type(e).__name__)
        raise

@mcp.tool(description="Execute a PromQL instant query against Prometheus")
async def execute_query(query: str, time: Optional[str] = None) -> Dict[str, Any]:
    """Execute an instant query against Prometheus.
    
    Args:
        query: PromQL query string
        time: Optional RFC3339 or Unix timestamp (default: current time)
        
    Returns:
        Query result with type (vector, matrix, scalar, string) and values
    """
    params = {"query": query}
    if time:
        params["time"] = time
    
    logger.info("Executing instant query", query=query, time=time)
    data = make_prometheus_request("query", params=params)
    
    result = {
        "resultType": data["resultType"],
        "result": data["result"]
    }
    
    logger.info("Instant query completed", 
                query=query, 
                result_type=data["resultType"], 
                result_count=len(data["result"]) if isinstance(data["result"], list) else 1)
    
    return result

@mcp.tool(description="Execute a PromQL range query with start time, end time, and step interval")
async def execute_range_query(query: str, start: str, end: str, step: str) -> Dict[str, Any]:
    """Execute a range query against Prometheus.
    
    Args:
        query: PromQL query string
        start: Start time as RFC3339 or Unix timestamp
        end: End time as RFC3339 or Unix timestamp
        step: Query resolution step width (e.g., '15s', '1m', '1h')
        
    Returns:
        Range query result with type (usually matrix) and values over time
    """
    params = {
        "query": query,
        "start": start,
        "end": end,
        "step": step
    }
    
    logger.info("Executing range query", query=query, start=start, end=end, step=step)
    data = make_prometheus_request("query_range", params=params)
    
    result = {
        "resultType": data["resultType"],
        "result": data["result"]
    }
    
    logger.info("Range query completed", 
                query=query, 
                result_type=data["resultType"], 
                result_count=len(data["result"]) if isinstance(data["result"], list) else 1)
    
    return result

@mcp.tool(description="List all available metrics in Prometheus")
async def list_metrics(limit: Optional[Union[int, str]] = None) -> List[str]:
    """Retrieve a list of all metric names available in Prometheus.
    
    Args:
        limit: Optional maximum number of metrics to return (can be int or string)
    
    Returns:
        List of metric names as strings
    """
    params = {}
    limit = validate_limit_parameter(limit)
    if limit is not None:
        params["limit"] = limit
    
    logger.info("Listing available metrics", limit=limit)
    data = make_prometheus_request("label/__name__/values", params=params if params else None)
    logger.info("Metrics list retrieved", metric_count=len(data), limit=limit)
    return data

@mcp.tool(description="Get metadata for a specific metric")
async def get_metric_metadata(metric: str, limit: Optional[Union[int, str]] = None) -> List[Dict[str, Any]]:
    """Get metadata about a specific metric.
    
    Args:
        metric: The name of the metric to retrieve metadata for
        limit: Optional maximum number of metadata entries to return (can be int or string)
        
    Returns:
        List of metadata entries for the metric
    """
    params = {"metric": metric}
    limit = validate_limit_parameter(limit)
    if limit is not None:
        params["limit"] = limit
        
    logger.info("Retrieving metric metadata", metric=metric, limit=limit)
    data = make_prometheus_request("metadata", params=params)
    logger.info("Metric metadata retrieved", metric=metric, metadata_count=len(data["metadata"]), limit=limit)
    return data["metadata"]

@mcp.tool(description="Get information about all scrape targets")
async def get_targets() -> Dict[str, List[Dict[str, Any]]]:
    """Get information about all Prometheus scrape targets.
    
    Returns:
        Dictionary with active and dropped targets information
    """
    logger.info("Retrieving scrape targets information")
    data = make_prometheus_request("targets")
    
    result = {
        "activeTargets": data["activeTargets"],
        "droppedTargets": data["droppedTargets"]
    }
    
    logger.info("Scrape targets retrieved", 
                active_targets=len(data["activeTargets"]), 
                dropped_targets=len(data["droppedTargets"]))
    
    return result

@mcp.tool(description="List all available label names in Prometheus")
async def list_labels(limit: Optional[Union[int, str]] = None) -> List[str]:
    """Retrieve a list of all label names available in Prometheus.
    
    Args:
        limit: Optional maximum number of label names to return (can be int or string)
    
    Returns:
        List of label names as strings
    """
    params = {}
    limit = validate_limit_parameter(limit)
    if limit is not None:
        params["limit"] = limit
    
    logger.info("Listing available labels", limit=limit)
    data = make_prometheus_request("labels", params=params if params else None)
    logger.info("Labels list retrieved", label_count=len(data), limit=limit)
    return data

@mcp.tool(description="Get all values for a specific label")
async def get_label_values(label_name: str, limit: Optional[Union[int, str]] = None) -> List[str]:
    """Get all possible values for a specific label.
    
    Args:
        label_name: The name of the label to retrieve values for
        limit: Optional maximum number of label values to return (can be int or string)
        
    Returns:
        List of label values as strings
    """
    params = {}
    limit = validate_limit_parameter(limit)
    if limit is not None:
        params["limit"] = limit
    
    logger.info("Retrieving label values", label_name=label_name, limit=limit)
    data = make_prometheus_request(f"label/{label_name}/values", params=params if params else None)
    logger.info("Label values retrieved", label_name=label_name, values_count=len(data), limit=limit)
    return data

@mcp.tool(description="Find time series by label matchers")
async def find_series(match: List[str], limit: Optional[Union[int, str]] = None, start: Optional[str] = None, end: Optional[str] = None) -> List[Dict[str, str]]:
    """Find time series by label matchers.
    
    Args:
        match: List of series selector expressions (e.g., ['up', 'process_start_time_seconds{job="prometheus"}'])
        limit: Optional maximum number of series to return (can be int or string)
        start: Optional start time as RFC3339 or Unix timestamp
        end: Optional end time as RFC3339 or Unix timestamp
        
    Returns:
        List of label sets representing the series
    """
    params = {}
    # Add match parameters - requests library handles list values for 'match[]' automatically
    if match:
        params['match[]'] = match
    
    limit = validate_limit_parameter(limit)
    if limit is not None:
        params["limit"] = limit
    if start is not None:
        params["start"] = start
    if end is not None:
        params["end"] = end
    
    logger.info("Finding series", match=match, limit=limit, start=start, end=end)
    data = make_prometheus_request("series", params=params)
    logger.info("Series found", series_count=len(data), limit=limit)
    return data

if __name__ == "__main__":
    logger.info("Starting Prometheus MCP Server", mode="direct")
    mcp.run()
