"""
ClickMouse命令行工具
"""

import argparse
from . import click_mouse

# 常量
__version__ = '0.1.0'

def main():
    """
    ClickMouse命令行工具的函数
    """
    print('ClickMouse命令行工具未实现，敬请期待')

if __name__ == '__main__':
    main()