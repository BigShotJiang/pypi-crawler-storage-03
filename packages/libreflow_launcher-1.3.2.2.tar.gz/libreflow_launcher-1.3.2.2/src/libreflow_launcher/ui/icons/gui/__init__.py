import libreflow_launcher.resources as resources

resources.add_folder('icons.gui', __file__)
