"""LLM client tests."""
