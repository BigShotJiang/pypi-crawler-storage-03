"""MCP Trello Extension - A Model Context Protocol extension for Trello integration."""

__version__ = "0.2.0"

from .client import TrelloClient

__all__ = ["TrelloClient"]
