# -*- coding: utf-8 -*-
VERSION = '3.0-beta'
