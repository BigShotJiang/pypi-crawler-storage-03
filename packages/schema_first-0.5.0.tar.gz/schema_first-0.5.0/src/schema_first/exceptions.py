class SchemaFirstException(Exception):
    """Common exception."""
