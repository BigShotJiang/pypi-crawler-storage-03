self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "30f34b9f1f88266ca895d00cace57057",
    "url": "/static/dist2/index.html"
  },
  {
    "revision": "e27646e504dece7852e8",
    "url": "/static/dist2/static/css/2.7cafca44.chunk.css"
  },
  {
    "revision": "28e686e085d5cf0fdb80",
    "url": "/static/dist2/static/css/main.ff3ce63a.chunk.css"
  },
  {
    "revision": "e27646e504dece7852e8",
    "url": "/static/dist2/static/js/2.e78fdbab.chunk.js"
  },
  {
    "revision": "1aea4192c69f3efa45ca8d60d4c9b77a",
    "url": "/static/dist2/static/js/2.e78fdbab.chunk.js.LICENSE.txt"
  },
  {
    "revision": "28e686e085d5cf0fdb80",
    "url": "/static/dist2/static/js/main.c276df28.chunk.js"
  },
  {
    "revision": "0317add2a7aae2dc6c79",
    "url": "/static/dist2/static/js/runtime-main.30a1ae39.js"
  }
]);