export const PENDING_STATUS = 0
export const COMPLETED_STATUS = 1
export const DECLINED_STATUS = 2
