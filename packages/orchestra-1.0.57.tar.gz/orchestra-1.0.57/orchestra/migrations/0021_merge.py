# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations
from django.db import models


class Migration(migrations.Migration):

    dependencies = [
        ('orchestra', '0020_auto_20151028_1559'),
        ('orchestra', '0020_auto_20151022_1553'),
    ]

    operations = [
    ]
