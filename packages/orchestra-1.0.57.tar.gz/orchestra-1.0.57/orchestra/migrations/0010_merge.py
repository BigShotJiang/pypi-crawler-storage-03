# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations
from django.db import models


class Migration(migrations.Migration):

    dependencies = [
        ('orchestra', '0009_auto_20150529_1413'),
        ('orchestra', '0009_auto_20150528_1910'),
    ]

    operations = [
    ]
