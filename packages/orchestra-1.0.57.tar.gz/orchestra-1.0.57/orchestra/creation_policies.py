def always_create(prerequisite_data, project_data, **kwargs):
    """
    Default creation policy; always create the task.
    """
    return True
