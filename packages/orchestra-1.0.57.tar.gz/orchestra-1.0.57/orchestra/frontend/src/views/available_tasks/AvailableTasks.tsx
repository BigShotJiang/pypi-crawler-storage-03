import React from 'react'

const Task = () => {
  return (
        <div>
          Available tasks table
        </div>
    )
}

export default Task;
