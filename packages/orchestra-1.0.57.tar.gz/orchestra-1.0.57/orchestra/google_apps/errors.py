class FailedRequest(Exception):
    pass


class InvalidUrlError(Exception):
    pass


class GoogleDriveError(Exception):
    pass
