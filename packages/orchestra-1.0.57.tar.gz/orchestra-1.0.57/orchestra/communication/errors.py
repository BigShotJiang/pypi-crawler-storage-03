from slacker import Error


class SlackFormatError(Exception):
    pass


SlackError = Error
