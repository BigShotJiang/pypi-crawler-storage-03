def load(workflow_version):
    """ Dummy loading function. """
    pass
