def machine_function(project_data, prerequisites):
    """ Dummy test func. """
    return {'version': 'test_v2'}
