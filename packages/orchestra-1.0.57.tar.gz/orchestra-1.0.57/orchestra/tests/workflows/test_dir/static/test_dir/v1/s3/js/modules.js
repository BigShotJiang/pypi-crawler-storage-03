(function() {
  'use strict';

  angular.module('test_dir.v1.s3', []);

})();
