(function() {
  'use strict';

  angular.module('test_dir.v2.s2', []);

})();
