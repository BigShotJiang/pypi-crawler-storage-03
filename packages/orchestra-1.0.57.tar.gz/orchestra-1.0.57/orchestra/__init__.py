# The current Orchestra version.
__version__ = '1.0.57'

default_app_config = 'orchestra.apps.OrchestraAppConfig'
