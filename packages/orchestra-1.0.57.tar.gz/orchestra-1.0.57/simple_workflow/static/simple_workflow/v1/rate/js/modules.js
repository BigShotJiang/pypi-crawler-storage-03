(function() {
  'use strict';

  angular.module('simple_workflow.v1.rate', []);

})();
