(function() {
  'use strict';

  angular.module('journalism_workflow.v1.editor', []);

})();
