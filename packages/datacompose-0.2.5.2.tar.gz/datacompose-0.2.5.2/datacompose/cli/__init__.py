"""
Datacompose CLI - Command-line interface for generating data cleaning UDFs.
"""

__version__ = "0.2.4"
