from ziplime.assets.models.asset_model import AssetModel


class CommodityModel(AssetModel):
    __tablename__ = "commodities"
