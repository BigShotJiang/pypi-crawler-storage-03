"""
Main module for the `posted` package.
"""

from .base import MsgBrokerBase, NoMsg
