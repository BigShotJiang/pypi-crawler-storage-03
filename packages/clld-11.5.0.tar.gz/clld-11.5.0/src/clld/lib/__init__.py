"""
clld library modules.

.. note:: Modules in this package must not have clld dependencies outside the lib package.
"""
