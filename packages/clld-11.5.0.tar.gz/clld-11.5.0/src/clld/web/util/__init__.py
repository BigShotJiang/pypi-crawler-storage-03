"""Functionality to create HTML from clld objects."""
