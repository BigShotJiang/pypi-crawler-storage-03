# flake8: noqa
from clld.web.datatables.language import Languages
from clld.web.datatables.value import Values
from clld.web.datatables.valueset import Valuesets
from clld.web.datatables.parameter import Parameters
from clld.web.datatables.unitparameter import Unitparameters
from clld.web.datatables.contribution import Contributions
from clld.web.datatables.contributor import Contributors
from clld.web.datatables.unit import Units
from clld.web.datatables.source import Sources
from clld.web.datatables.sentence import Sentences
from clld.web.datatables.unitvalue import Unitvalues
