from clld.db import fts


def test_fts():
    assert fts
