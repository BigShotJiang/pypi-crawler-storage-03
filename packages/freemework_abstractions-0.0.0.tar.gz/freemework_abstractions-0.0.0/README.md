# freemework_abstractions

Minimal example Python library managed with PDM.