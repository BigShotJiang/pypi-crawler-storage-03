from abc import ABC

class FException(ABC):
    pass