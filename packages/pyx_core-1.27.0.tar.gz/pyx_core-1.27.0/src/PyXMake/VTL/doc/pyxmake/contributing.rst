:sd_hide_title:
.. grid:: 1

    .. grid-item-card:: Contributing

        Information about user contributions and focal point
------------
Contributing
------------
.. include:: ../../../CONTRIBUTING.md
	:parser: myst_parser.docutils_
.. toctree::
   :hidden:
   
   self