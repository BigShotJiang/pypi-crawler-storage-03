---
sd_hide_title: true
---

# Getting started

```{eval-rst}
.. include:: core.rst
```

```{toctree}
:hidden:
:caption: Getting started
Downloading & Installation <self>
```

```{toctree}
:hidden:
:includehidden:
:caption: CI/CD Catalog

general
python
docker
```