-------------------------------
Delete deprecated pipeline data
-------------------------------

.. literalinclude:: ../../../templates/project-housekeeping/template.yml
   :language: yaml