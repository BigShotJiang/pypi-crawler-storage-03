This addon allows configuring an exporter for endpoints to be used in
code snippets.
