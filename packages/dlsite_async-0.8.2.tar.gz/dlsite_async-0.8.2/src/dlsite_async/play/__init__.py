"""DLsite Play module."""
