# -*- coding: utf-8 -*-

"""Top-level package for pydeck-overlays."""

__author__ = """Oceanum Developers"""
__email__ = "developers@oceanum.science"
__version__ = "0.9.1"

from .labels import LabelLayer
