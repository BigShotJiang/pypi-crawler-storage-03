"""A tracked and `hatch` managed version."""

__version__ = "0.0.0a9"
