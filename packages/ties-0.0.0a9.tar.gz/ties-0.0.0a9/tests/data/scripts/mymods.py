"""Test transform functions."""


def join_with_dash(*args: str) -> str:
    """Join files with dashes."""
    return "-".join(args)
