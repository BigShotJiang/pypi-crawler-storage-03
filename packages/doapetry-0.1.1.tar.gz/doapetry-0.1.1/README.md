# doapetry

Create a DOAP based on the pyproject.toml

