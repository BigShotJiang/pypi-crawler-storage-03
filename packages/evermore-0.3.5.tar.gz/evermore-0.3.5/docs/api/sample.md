# Sampling Parameters

```{eval-rst}
.. automodule:: evermore.parameters.sample
    :show-inheritance:
    :members:
```
