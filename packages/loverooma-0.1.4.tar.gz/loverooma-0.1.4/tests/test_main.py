from loverooma.connect_kb import work

wk = work()

wk.update('hello3sdf32vv',id='2cffg344')

wk.create_collection(vector_dimension=2560)

wk.reload()

wk.search('hellocc')

wk.update('hello332vv',id='ddcccd')

wk.index.delete(doc_id = "222333")