.. cool_styles documentation master file, created by
   sphinx-quickstart on Wed Aug 13 22:57:26 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

cool_styles documentation
=========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

