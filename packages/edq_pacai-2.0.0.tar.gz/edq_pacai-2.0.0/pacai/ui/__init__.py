"""
The `pacai.ui` package houses all the standard UIs for the pacai project.
"""
