"""
The `pacai.resources` package provides no actual code,
but instead provides various non-code resources for the project.
"""
