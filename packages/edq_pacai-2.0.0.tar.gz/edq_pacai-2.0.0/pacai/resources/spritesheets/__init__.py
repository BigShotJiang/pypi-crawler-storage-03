"""
The `pacai.resources.spritesheets` provides default sprite sheets that can be used for this project.
"""
