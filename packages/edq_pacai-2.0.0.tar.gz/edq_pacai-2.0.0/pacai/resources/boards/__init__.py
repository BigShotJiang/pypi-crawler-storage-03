"""
The `pacai.resources.boards` provides default game boards that can be used for this project.
"""
