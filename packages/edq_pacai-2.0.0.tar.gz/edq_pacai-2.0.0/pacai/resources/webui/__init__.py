"""
The `pacai.resources.webui` provides static resources for the web UI.
"""
