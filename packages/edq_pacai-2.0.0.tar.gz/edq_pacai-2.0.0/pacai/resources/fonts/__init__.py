"""
The `pacai.resources.fonts` provides default fonts that can be used for this project.
"""
