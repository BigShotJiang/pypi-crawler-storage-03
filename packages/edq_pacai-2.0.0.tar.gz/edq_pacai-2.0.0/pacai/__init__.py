"""
The pacai package is the top-level package for the Pacman AI project maintained by EduLinq, Eriq Augustine, and the LINQS lab at UCSC.
"""

__version__ = '2.0.0'
