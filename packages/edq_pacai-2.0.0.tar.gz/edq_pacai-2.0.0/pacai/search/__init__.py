"""
The `pacai.search` package contains search problems and tools provided by the pacai project.
Where the `pacai.core.search` module provides the infrastructure for search tools and problems,
this package provides instantiated tools and problems.
"""
