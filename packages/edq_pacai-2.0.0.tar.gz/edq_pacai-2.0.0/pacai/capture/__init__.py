"""
The `pacai.capture` package provides code for running the caputre game.
"""
