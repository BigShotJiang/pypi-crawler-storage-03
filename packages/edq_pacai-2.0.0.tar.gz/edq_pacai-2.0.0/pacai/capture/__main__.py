"""
A shortcut for the main capture executable: `pacai.capture.bin`.
"""

import pacai.capture.bin

if (__name__ == '__main__'):
    pacai.capture.bin.main()
