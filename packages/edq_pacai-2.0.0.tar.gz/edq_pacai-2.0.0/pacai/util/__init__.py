"""
The `pacai.util` package provides utilities for use in the pacai project.
"""
