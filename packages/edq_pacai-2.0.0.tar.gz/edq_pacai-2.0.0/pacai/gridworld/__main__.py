"""
A shortcut for the main GridWorld executable: `pacai.gridworld.bin`.
"""

import pacai.gridworld.bin

if (__name__ == '__main__'):
    pacai.gridworld.bin.main()
