"""
The `pacai.pacman` package provides code for running Pac-Man-like games.
This includes a classic game of Pac-Man as well as more specialized games used as learning exercises.
"""
