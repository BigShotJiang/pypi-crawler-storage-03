"""
A shortcut for the main Pac-Man executable: `pacai.pacman.bin`.
"""

import pacai.pacman.bin

if (__name__ == '__main__'):
    pacai.pacman.bin.main()
