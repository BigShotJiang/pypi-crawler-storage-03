"""
A shortcut for the main 8 Puzzle executable: `pacai.eightpuzzle.bin`.
"""

import pacai.eightpuzzle.bin

if (__name__ == '__main__'):
    pacai.eightpuzzle.bin.main()
