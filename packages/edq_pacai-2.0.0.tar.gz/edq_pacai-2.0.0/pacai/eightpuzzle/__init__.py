"""
The `pacai.eightpuzzle` package provides code for an 8 Puzzle game.
8 Puzzle is a smaller varint of the [15 Puzzle game](https://en.wikipedia.org/wiki/15_puzzle).
"""
