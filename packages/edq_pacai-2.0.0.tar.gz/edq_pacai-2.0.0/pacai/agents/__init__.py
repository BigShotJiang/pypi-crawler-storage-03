"""
The `pacai.agents` package houses all the provided agents for the pacai project.
Some agents will be fully implemented, while some will be abstract classes meant to be extended by students.
"""
