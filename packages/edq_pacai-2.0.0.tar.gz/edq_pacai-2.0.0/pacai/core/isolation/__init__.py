"""
The `pacai.core.isolation` package provides the mechanisms for isolating agent code from the core game engine.
"""
