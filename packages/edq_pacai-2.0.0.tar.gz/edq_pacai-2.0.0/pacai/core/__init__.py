"""
The `pacai.core` package provides the core game engine, infrastructure, and abstractions for creating games.
This package contains no actual game logic or resources, just the infrastructure for running them.
"""
