#  License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import res_partner
from . import res_users
from . import sale
from . import sale_order_line
