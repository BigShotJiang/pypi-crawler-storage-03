After agent user is configured, try to login as agent user and open contacts.
You will see only contacts created by this user and contacts,
to which he assigned as agent.

Agent user can see only sale orders, quotation created by him or where he present as agent.

Agent can create Sale Orders and Contacts (if has Create Contacts right).

Agent can see only own commission lines.

Agent can see only own commission lines total (My Commission) in the Sale Order.

Agent can't open commission line form.

Agent can't recompute agents commissions.

Agent can't edit commission lines.
