* Create new user.
* Open related to user partner.
* Tick Agent checkbox.
* Go back to user.
* Select desired access groups related to agent.
* Grant to agent user one group from Sales category. Recommended to use Own Records Only.
