* `Ooops404 <https://www.ooops404.com>`__:

  * Ilyas <irazor147@gmail.com>

* `PyTech SRL <https://www.pytech.it>`__:

  * Alessandro Uffreduzzi <alessandro.uffreduzzi@pytech.it>
* `Aion Tech <https://aiontech.company/>`_:

  * Simone Rubino <simone.rubino@aion-tech.it>
