This module provides access groups and rules to restrict access of agent user
to contacts and sales.

If installing with demo data, the module also provides a user to ease testing
from the point of view of the agent. You can log in using username `agent`
and password `agent`.
