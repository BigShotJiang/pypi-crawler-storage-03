"""An MCP (Model-Context-Protocol) Server for Deep Academic Research"""

__version__ = "0.1.3"

