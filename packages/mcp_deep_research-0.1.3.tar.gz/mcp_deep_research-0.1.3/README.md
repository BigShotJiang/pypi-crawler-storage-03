# mcp-deep-research
An mcp server designed for local-deployed deep research.
