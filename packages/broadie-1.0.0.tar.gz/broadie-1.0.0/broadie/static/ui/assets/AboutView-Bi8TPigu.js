import{c as e,d as t,e as n,f as r}from"./index-IX1lih9x.js";const i={name:`AboutView`},a={class:`container`};function o(e,i,o,s,c,l){return r(),t(`div`,a,[...i[0]||=[n(`<div class="card" style="margin-bottom:16px;" data-v-4c3e1e0f><div class="card-header" data-v-4c3e1e0f>About Broadie</div><div class="card-body" data-v-4c3e1e0f><p data-v-4c3e1e0f> Broadie is a batteries-included multi-agent framework with REST and WebSocket APIs, persistent memory, and a flexible tool system. This UI lets you chat with your agent, view conversations, and stream responses. </p></div></div><div class="card" style="margin-bottom:16px;" data-v-4c3e1e0f><div class="card-header" data-v-4c3e1e0f>Quick Start — Create and Run an Agent</div><div class="card-body" data-v-4c3e1e0f><ol class="small" style="line-height:1.7;" data-v-4c3e1e0f><li data-v-4c3e1e0f> Install Broadie (from PyPI): <pre class="mono" data-v-4c3e1e0f><code data-v-4c3e1e0f>pip install broadie</code></pre></li><li data-v-4c3e1e0f> Create a minimal agent config file <strong data-v-4c3e1e0f>main.json</strong>: <pre class="mono" data-v-4c3e1e0f><code data-v-4c3e1e0f>{
  &quot;name&quot;: &quot;my_agent&quot;,
  &quot;description&quot;: &quot;A helpful assistant&quot;,
  &quot;instruction&quot;: &quot;You are a helpful AI assistant.&quot;,
  &quot;model&quot;: {&quot;provider&quot;: &quot;google&quot;, &quot;name&quot;: &quot;gemini-2.0-flash&quot;}
}</code></pre></li><li data-v-4c3e1e0f> Run the agent directly (CLI): <pre class="mono" data-v-4c3e1e0f><code data-v-4c3e1e0f>broadie run main.json</code></pre></li><li data-v-4c3e1e0f> Or serve the API + UI: <pre class="mono" data-v-4c3e1e0f><code data-v-4c3e1e0f>broadie serve main.json</code></pre> Then open the UI at: <pre class="mono" data-v-4c3e1e0f><code data-v-4c3e1e0f>http://localhost:8000/ui</code></pre></li></ol><p class="small muted" data-v-4c3e1e0f> Tip: copy .env.example to .env and configure your model keys (e.g., GOOGLE_API_KEY). </p></div></div><div class="card" data-v-4c3e1e0f><div class="card-header" data-v-4c3e1e0f>Programmatic Agent (Optional)</div><div class="card-body" data-v-4c3e1e0f><p class="small" data-v-4c3e1e0f>Define your agent in Python and serve it:</p><pre class="mono" data-v-4c3e1e0f><code data-v-4c3e1e0f>from broadie import Agent, tool

@tool(name=&quot;echo&quot;, description=&quot;Echo input&quot;)
def echo(text: str) -&gt; str:
    return text

class EchoAgent(Agent):
    def build_config(self):
        return {&quot;name&quot;: &quot;echo_agent&quot;, &quot;instruction&quot;: &quot;Echoer&quot;}

# Serve from code
# broadie serve module.path:EchoAgent
</code></pre></div></div>`,3)]])}var s=e(i,[[`render`,o],[`__scopeId`,`data-v-4c3e1e0f`]]);export{s as default};