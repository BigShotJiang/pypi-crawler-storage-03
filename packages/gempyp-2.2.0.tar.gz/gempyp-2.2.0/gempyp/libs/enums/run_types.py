import enum
 
class RunTypes(enum.Enum):
    CI_CD_CT = "CI-CD-CT"
    ON_DEMAND = "ON-DEMAND"
    SCHEDULED = "SCHEDULED"

