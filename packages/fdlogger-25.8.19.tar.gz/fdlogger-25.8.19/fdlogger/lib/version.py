"""It's the version"""
__version__ = "25.8.19"
