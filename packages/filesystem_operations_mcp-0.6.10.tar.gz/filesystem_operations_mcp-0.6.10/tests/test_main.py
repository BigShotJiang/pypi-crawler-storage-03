from filesystem_operations_mcp.main import cli


def test_main_imports():
    assert cli is not None
