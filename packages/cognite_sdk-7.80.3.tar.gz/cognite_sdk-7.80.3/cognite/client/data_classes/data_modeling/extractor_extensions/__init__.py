from __future__ import annotations

from cognite.client.utils._experimental import FeaturePreviewWarning

FeaturePreviewWarning("General Availability", "alpha", "Extractor Extension Model").warn()
