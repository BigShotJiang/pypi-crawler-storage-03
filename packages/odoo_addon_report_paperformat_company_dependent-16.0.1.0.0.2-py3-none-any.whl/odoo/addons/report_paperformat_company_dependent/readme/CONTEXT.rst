Odoo's standard behavior allows only a single paper format per report across all companies.
In a multi-company setup, this means it's not possible by default to use different paper
formats for each company.
This module addresses that limitation by enabling company-specific paper format
configuration.
