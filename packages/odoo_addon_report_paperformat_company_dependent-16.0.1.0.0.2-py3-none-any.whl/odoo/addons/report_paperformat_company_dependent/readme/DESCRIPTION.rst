This module allows configuring different paper formats for reports in a multi-company environment.

When a user creates a new company after this module is installed, the paper format for
reports will not be assigned automatically.
Users must manually assign the appropriate paper format for each report in the new company as 
necessary.
