"""
Version of platform_services
"""

__version__ = '0.68.2'
