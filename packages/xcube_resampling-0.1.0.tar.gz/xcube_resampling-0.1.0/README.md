# xcube-resampling

A Python package providing low-level, dask-aware spatial resampling algorithms 
for xcube and everyone.
