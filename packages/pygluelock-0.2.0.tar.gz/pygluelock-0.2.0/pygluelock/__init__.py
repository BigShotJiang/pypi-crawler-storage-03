"""Top-level package for python glue lock wrapper."""

__author__ = """Adnan Hossain"""
__email__ = 'fadnanhossain@hotmail.com'
