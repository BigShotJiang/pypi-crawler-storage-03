# Usage

To use python glue lock wrapper in a project:

```python
import pygluelock
```
