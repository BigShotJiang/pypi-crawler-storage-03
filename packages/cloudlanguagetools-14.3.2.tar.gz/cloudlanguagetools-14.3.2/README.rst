# cloud-language-tools
Interface with various cloud APIs for translation, text to speech

## service keys
see utils/service_keys.py

## building releases
see package.sh
