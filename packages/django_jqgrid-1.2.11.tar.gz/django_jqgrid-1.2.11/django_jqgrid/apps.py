from django.apps import AppConfig


class DjangoJqgridConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_jqgrid'
    verbose_name = 'Django jqGrid'
