> [!CAUTION]
> This project is in active development and not ready for production use. It has not been publicly announced yet.

# Microsoft Teams API Client

Core API client functionality with models and clients for Microsoft Teams integration.
Provides HTTP abstraction, authentication, and typed models for Teams Bot Framework APIs.