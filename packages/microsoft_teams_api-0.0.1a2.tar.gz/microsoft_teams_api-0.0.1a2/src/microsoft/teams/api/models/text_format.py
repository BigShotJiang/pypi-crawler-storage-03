"""
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the MIT License.
"""

from typing import Literal

TextFormat = Literal["markdown", "plain", "xml"]
