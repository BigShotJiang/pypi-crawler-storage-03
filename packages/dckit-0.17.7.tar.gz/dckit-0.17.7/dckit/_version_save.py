#!/usr/bin/env python
# This file was created automatically
longversion = '0.17.7'
