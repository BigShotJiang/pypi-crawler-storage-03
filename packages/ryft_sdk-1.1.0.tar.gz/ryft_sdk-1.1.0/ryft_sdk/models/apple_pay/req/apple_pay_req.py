from typing_extensions import TypedDict


class CreateApplePayWebSessionReq(TypedDict):
    displayName: str
    domainName: str
