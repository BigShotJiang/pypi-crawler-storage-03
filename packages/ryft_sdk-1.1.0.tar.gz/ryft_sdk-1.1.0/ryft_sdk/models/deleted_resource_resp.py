from typing import TypedDict


class DeletedResourceResp(TypedDict):
    id: str
