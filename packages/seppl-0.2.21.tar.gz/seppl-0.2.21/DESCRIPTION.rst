Simple Entry Point PipeLines (seppl). Python library for parsing pipeline components with their own options. 

**seppl** takes a very light-weight approach to avoid encroaching too much on
your code. If you want to, you can add some compatibility checks between the
pipeline components with some additional mixins.
However, the execution of the pipeline (and potentially moving data between
components) is left to you and your code.

Usage and examples can be found here:

`https://github.com/waikato-datamining/seppl <https://github.com/waikato-datamining/seppl>`__

