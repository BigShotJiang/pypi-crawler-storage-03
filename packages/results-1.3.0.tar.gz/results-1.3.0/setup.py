import setuptools

setuptools.setup()
