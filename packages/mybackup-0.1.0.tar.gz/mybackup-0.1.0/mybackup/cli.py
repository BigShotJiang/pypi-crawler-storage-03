from .ui import main_ui

def run():
    main_ui()

if __name__ == "__main__":
    run()
