""".. include:: ./doc.md"""  # noqa: D415

from .utils import calculate_cer, calculate_mer, calculate_wer, calculate_wil, calculate_wip  # noqa: F401
