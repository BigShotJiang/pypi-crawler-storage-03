""".. include:: ./doc.md"""  # noqa: D415

from .api import transcribe_audios  # noqa: F401
