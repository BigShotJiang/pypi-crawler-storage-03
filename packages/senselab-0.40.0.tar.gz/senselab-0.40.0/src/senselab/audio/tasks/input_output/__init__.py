"""This module provides some utilities for audio input and output."""

from .utils import read_audios, save_audios  # noqa: F401
