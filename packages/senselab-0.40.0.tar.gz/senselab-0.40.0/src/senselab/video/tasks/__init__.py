"""Tasks for video processing."""
