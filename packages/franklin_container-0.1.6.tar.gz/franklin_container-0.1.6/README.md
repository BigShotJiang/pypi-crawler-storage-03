# Educator franklin package for installation in container
