"""WOT-PDF Utilities"""
