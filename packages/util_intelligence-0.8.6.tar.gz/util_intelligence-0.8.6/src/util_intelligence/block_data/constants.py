import os

RESOURCE_ROOT_PATH = os.environ.get('RESOURCE_ROOT', '/resource')
SIMSUN_FONT_FILE_PATH = os.path.join(RESOURCE_ROOT_PATH, 'fonts', 'simsun.ttc')
