# query-collection

This should be an interface and implementation of a collection that holds SPARQL
1.1 queries.

