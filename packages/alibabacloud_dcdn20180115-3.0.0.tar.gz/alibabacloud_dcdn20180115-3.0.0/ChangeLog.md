2024-11-06 Version: 2.5.0
- Support API GetDcdnKvDetail.
- Update API PreloadDcdnObjectCaches: add param QueryHashkey.


2024-08-21 Version: 2.4.2
- Update API DescribeDcdnKvAccount: update response param.


2024-08-20 Version: 2.4.1
- Update API BatchDeleteDcdnKvWithHighCapacity: update param Url.
- Update API BatchPutDcdnKv: update param KvList.
- Update API BatchPutDcdnKvWithHighCapacity: update param Url.
- Update API DescribeDcdnKvAccount: update response param.
- Update API DescribeDcdnKvNamespace: update response param.
- Update API DescribeDcdnUserDomains: update param DomainName.


2024-04-11 Version: 2.4.0
- Support API RefreshDcdnObjectCacheByCacheTag.


2024-04-08 Version: 2.3.0
- Support API BatchDeleteDcdnKv.
- Support API BatchDeleteDcdnKvWithHighCapacity.
- Support API BatchPutDcdnKvWithHighCapacity.
- Support API PutDcdnKvWithHighCapacity.
- Update API BatchPutDcdnKv: update param KvList.
- Update API DescribeDcdnDomainConfigs: update param FunctionNames.
- Update API DescribeDcdnWafGroups: update response param.
- Update API PutDcdnKvNamespace: update param Description.


2024-03-21 Version: 2.2.1
- Update API DescribeDcdnKvNamespace: update response param.
- Update API PutDcdnKvNamespace: update response param.


2024-01-08 Version: 2.2.0
- Generated python 2018-01-15 for dcdn.

2023-12-27 Version: 2.1.0
- Generated python 2018-01-15 for dcdn.

2023-12-08 Version: 2.0.0
- Generated python 2018-01-15 for dcdn.

2023-11-23 Version: 1.10.0
- Generated python 2018-01-15 for dcdn.

2023-11-22 Version: 1.9.0
- Generated python 2018-01-15 for dcdn.

2023-11-07 Version: 1.8.1
- Generated python 2018-01-15 for dcdn.

2023-10-23 Version: 1.8.0
- Generated python 2018-01-15 for dcdn.

2023-10-18 Version: 1.7.0
- Generated python 2018-01-15 for dcdn.

2023-10-17 Version: 1.6.0
- Generated python 2018-01-15 for dcdn.

2023-10-17 Version: 1.5.2
- Generated python 2018-01-15 for dcdn.

2023-10-16 Version: 1.5.1
- Generated python 2018-01-15 for dcdn.

2023-10-10 Version: 1.5.0
- Generated python 2018-01-15 for dcdn.

2023-09-14 Version: 1.4.0
- Generated python 2018-01-15 for dcdn.

2023-09-04 Version: 1.3.1
- Generated python 2018-01-15 for dcdn.

2023-08-30 Version: 1.3.0
- Generated python 2018-01-15 for dcdn.

2023-08-29 Version: 1.2.0
- Generated python 2018-01-15 for dcdn.

2023-08-29 Version: 1.2.0
- Generated python 2018-01-15 for dcdn.

2023-08-23 Version: 1.1.19
- Generated python 2018-01-15 for dcdn.

2023-08-09 Version: 1.1.18
- Generated python 2018-01-15 for dcdn.

2023-08-02 Version: 1.1.17
- Update DescribeDcdnUserDomains.

2023-07-28 Version: 1.1.16
- Add DescribeDcdnKvNamespace.

2023-07-25 Version: 1.1.15
- Add DescribeDcdnL2Ips.

2023-07-24 Version: 1.1.14
- Add SetDcdnDomainCertificate.

2023-07-17 Version: 1.1.13
- Add SetDcdnDomainSSLCertificate.

2023-06-28 Version: 1.1.12
- Add DescribeDdosBpsMax.

2023-06-20 Version: 1.1.11
- Add DescribeDdosEventMax.

2023-06-08 Version: 1.1.10
- Update DeleteDcdnSpecificStagingConfig.

2023-05-26 Version: 1.1.9
- Add DescribeDcdnFullDomainsBlockIPConfig.

2023-05-22 Version: 1.1.8
- Add DescribeDcdnFullDomainsBlockIPHistory.

2023-05-19 Version: 1.1.7
- Add DescribeDcdnDomainMd5Info.

2023-04-25 Version: 1.1.6
- Add CheckDcdnDomainExist.

2023-03-24 Version: 1.1.5
- Add GetDcdnKv.

2023-03-04 Version: 1.1.4
- Update DescribeDcdnUserTags.

2023-02-25 Version: 1.1.3
- Update DescribeDcdnDomainUsageData.

2023-01-17 Version: 1.1.2
- Add DeleteDcdnKv.

2023-01-10 Version: 1.1.1
- Update DescribeDcdnWafLogs.

2022-12-27 Version: 1.1.0
- Add DescribeDcdnWafLogs.

2022-12-09 Version: 1.0.28
- Add DescribeDdosAllEventList.

2022-11-29 Version: 1.0.27
- Update DescribeDcdnDeletedDomains.

2022-11-17 Version: 1.0.26
- Update DescribeRDDomainConfig.

2022-11-17 Version: 1.0.25
- Add DescribeRDDomainConfig.

2022-10-27 Version: 1.0.24
- Update BatchAddDcdnDomain,add error code.

2022-10-13 Version: 1.0.23
- Update DeleteRoutineConfEnvs.

2022-09-28 Version: 1.0.22
- Update AddDcdnDomain.

2022-09-16 Version: 1.0.21
- Update DescribeDcdnReport.

2022-09-13 Version: 1.0.20
- Update DescribeDcdnL2Vips.

2022-09-01 Version: 1.0.19
- Add DescribeDcdnL2Vips.

2022-08-31 Version: 1.0.18
- Support STS.

2022-08-24 Version: 1.0.17
- AMP version.

2022-07-28 Version: 1.0.16
 - Delete SetDcdnConfigOfVersion.

2022-07-05 Version: 1.0.15
 - Add DescribeDcdnIpaDomainMultiUsageData.

2022-06-09 Version: 1.0.14
 - Update DescribeDcdnSLSRealtimeLogDelivery.

2022-05-26 Version: 1.0.13
 - Add SetDcdnFullDomainsBlockIP.

2022-04-28 Version: 1.0.12
- Add DescribeDcdnWafDomains.

2022-04-07 Version: 1.0.11
- Add DescribeDcdnWafService.

2022-03-31 Version: 1.0.10
- Add waf api.

2022-03-31 Version: 1.0.9
- AMP version.

2022-03-28 Version: 1.0.8
- AMP version.

2022-03-22 Version: 1.0.7
- Update PreloadDcdnObjectCaches.

2022-01-06 Version: 1.0.6
- Update ErrorCode.

2021-12-31 Version: 1.0.5
- Update ErrorCode.

2021-12-29 Version: 1.0.4
- AMP version.

2021-12-16 Version: 1.0.3
- AMP version.

2021-06-08 Version: 1.0.2
- Generated python 2018-01-15 for dcdn.

2021-03-31 Version: 1.0.1
- Generated python 2018-01-15 for dcdn.

2021-01-28 Version: 1.0.0
- AMP Version Change.

