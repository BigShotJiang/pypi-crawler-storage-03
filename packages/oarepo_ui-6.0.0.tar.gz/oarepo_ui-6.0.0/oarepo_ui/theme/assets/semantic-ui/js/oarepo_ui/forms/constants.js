export const overridableComponentIds = [
  "Errors.container",
  "FormActions.container",
  "FormApp.layout",
  "FormFields.container",
  "CustomFields.container",
];

export const DEFAULT_SUGGESTION_SIZE = 20;
