import * as React from 'react';

export const Disabled = () => null;

export default Disabled;
