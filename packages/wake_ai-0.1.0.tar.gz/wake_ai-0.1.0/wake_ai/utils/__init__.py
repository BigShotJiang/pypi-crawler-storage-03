"""Utility modules for Wake AI framework."""

from .logging import get_logger
