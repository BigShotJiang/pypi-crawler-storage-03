# Reference

::: imxInsights.compare.imxContainerCompare

::: imxInsights.compare.changedImxObject

::: imxInsights.compare.changes

::: imxInsights.compare.changeStatusEnum

::: imxInsights.compare.geometryChange
