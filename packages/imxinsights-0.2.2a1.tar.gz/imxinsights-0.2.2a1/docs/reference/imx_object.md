# Reference

::: imxInsights.domain.imxObject

::: imxInsights.domain.imxGeographicLocation
