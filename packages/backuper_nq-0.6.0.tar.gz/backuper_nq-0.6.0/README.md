# Backuper
Personal backup script

TBA

## Development
### Install
```
pip install poetry==1.8.3
poetry install
pre-commit install
```

### Run
```
backuper config.yml
echo "<config>" | backuper -
```
