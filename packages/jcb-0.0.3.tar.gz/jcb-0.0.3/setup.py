import setuptools

with open("VERSION") as version_file:
    version = version_file.read().strip()

setuptools.setup(
    name="jcb",
    version=version,
)
