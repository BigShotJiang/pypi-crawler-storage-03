OPENAI_REASONING_MODELS = [
    "o1",
    "o1-mini",
    "o3",
    "o3-mini",
    "o1-pro",
    "o4-mini",
    "gpt-5",
    "gpt-5-mini",
    "gpt-5-nano",
]
