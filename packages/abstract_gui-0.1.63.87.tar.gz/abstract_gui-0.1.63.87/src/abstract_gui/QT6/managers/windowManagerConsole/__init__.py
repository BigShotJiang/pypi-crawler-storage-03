from .main import windowManagerConsole
from ..startConsole import startConsole
def startWindowManagerConsole():
    startConsole(windowManagerConsole)
 
