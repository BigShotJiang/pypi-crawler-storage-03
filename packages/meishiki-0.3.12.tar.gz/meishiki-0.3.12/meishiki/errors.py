class ConvertWarekiException(Exception):
    """和暦計算におけるユーザー定義例外クラス"""

    pass


class MeishikiException(Exception):
    """命式計算におけるユーザー定義例外クラス"""

    pass


class UnseiException(Exception):
    """運命計算におけるユーザー定義例外クラス"""

    pass
