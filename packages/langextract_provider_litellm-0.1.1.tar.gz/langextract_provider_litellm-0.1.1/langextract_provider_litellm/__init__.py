"""LangExtract provider plugin for LiteLLM."""

from langextract_provider_litellm.provider import LiteLLMLanguageModel

__all__ = ["LiteLLMLanguageModel"]
__version__ = "0.1.1"
