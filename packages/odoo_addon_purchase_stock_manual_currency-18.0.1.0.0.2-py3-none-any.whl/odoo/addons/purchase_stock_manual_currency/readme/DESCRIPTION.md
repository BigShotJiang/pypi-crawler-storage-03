This module integrates purchase_manual_currency with purchase stock
management, ensuring that manually set currency rates on purchase orders
are applied to stock moves, stock valuation layers, and product costs.
