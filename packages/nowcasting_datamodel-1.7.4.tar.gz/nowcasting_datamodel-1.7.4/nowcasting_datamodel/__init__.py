"""Init file"""

__version__ = "1.7.4"

N_GSP = 342
