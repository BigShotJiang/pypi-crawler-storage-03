"""Base files for SQL sqlalchemy"""

from sqlalchemy.orm import declarative_base

Base_Forecast = declarative_base()  # noqa
Base_PV = declarative_base()  # noqa
