"""init for save functions"""
