# OTEL Tracing experimental feature code

The folder structure from here is meant to correspond to trulens folder
structure and when the experimental feature were to be adopted, the contents of
these folders will be merged into their corresponding locations in trulens
namespace.
