Constants
=========

.. currentmodule:: terminusgps.wialon.constants

.. autoclass:: WialonProfileField
    :members:

.. autoclass:: WialonMeasurementUnit
    :members:

.. autoclass:: WialonItemsType
    :members:

.. autoclass:: WialonItemProperty
    :members:

.. autodata:: ACCESSMASK_RESOURCE_BASIC
.. autodata:: ACCESSMASK_UNIT_BASIC
.. autodata:: ACCESSMASK_UNIT_MIGRATION
