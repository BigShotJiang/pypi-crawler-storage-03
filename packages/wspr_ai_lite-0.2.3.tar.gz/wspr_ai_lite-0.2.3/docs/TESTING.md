# Testing

## With pytest
```bash
pytest -q
```

## With Makefile (optional)
```bash
make test
```

### What gets tested?
- `month_range` correctness
- Band mapping from frequency
- CSV parsing of required columns
