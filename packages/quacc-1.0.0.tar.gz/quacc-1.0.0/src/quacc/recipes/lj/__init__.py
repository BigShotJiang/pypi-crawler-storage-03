"""Recipes for Lennard-Jones."""
