"""Recipes for Gaussian."""
