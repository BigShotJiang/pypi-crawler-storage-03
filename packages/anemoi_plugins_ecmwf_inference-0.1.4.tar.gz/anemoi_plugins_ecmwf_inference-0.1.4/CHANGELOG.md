# Changelog

## [0.1.4](https://github.com/ecmwf/anemoi-plugins-ecmwf/compare/inference-0.1.3...inference-0.1.4) (2025-08-26)


### Features

* Add preprocessors to test dynamics  ([#25](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/25)) ([0e98f93](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/0e98f939b3d1c5a8b94d2082ef529062113c1e9f))

## [0.1.3](https://github.com/ecmwf/anemoi-plugins-ecmwf/compare/inference-0.1.2...inference-0.1.3) (2025-08-14)


### Bug Fixes

* mir grid handling due to anemoi-inference ([#23](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/23)) ([a65ffa4](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/a65ffa49b6f4785bf46b6ae763ac369878e3ec1b))

## [0.1.2](https://github.com/ecmwf/anemoi-plugins-ecmwf/compare/inference-0.1.1...inference-0.1.2) (2025-08-13)


### Bug Fixes

* updates from anemoi-inference ([#18](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/18)) ([91194fb](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/91194fbb30ea9279d255e1f17cfab7b4e31533c7))

## [0.1.1](https://github.com/ecmwf/anemoi-plugins-ecmwf/compare/inference-0.1.0...inference-0.1.1) (2025-08-05)


### Features

* **inference opendata:** Add opendata input ([#15](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/15)) ([990fa3d](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/990fa3ddd60b058005f6cb33c2d53eea289c632d))
* **inference regrid:** Add regrid preprocessor ([#16](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/16)) ([af00ffe](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/af00ffe5d57f3e5b8b65bbcba7791fa00070d1ba))


### Bug Fixes

* **inference mir:** ensure grid is str ([6397681](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/63976811396341e83b0c421c03fd572f78d28b53))
* **opendata:** Add default to pop ([5e4ef50](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/5e4ef504c11bfb04e820a5cf46d62add965772ba))

## 0.1.0 (2025-07-28)


### Bug Fixes

* Reorganise repo ([#13](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/13)) ([8b47509](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/8b47509110db13f106f11397cbb2f89d80e82952))
