"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to read algorithmic parameters from different sources.
"""
from mlrl.testbed.experiments.input.parameters.reader import ParameterReader
