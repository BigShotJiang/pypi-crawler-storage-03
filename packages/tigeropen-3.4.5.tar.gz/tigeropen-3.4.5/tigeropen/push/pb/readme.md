# generate proto
```
cd openapi-python-sdk
protoc  --proto_path=.  --python_out=.  --pyi_out=. tigeropen/push/pb/*.proto
```
