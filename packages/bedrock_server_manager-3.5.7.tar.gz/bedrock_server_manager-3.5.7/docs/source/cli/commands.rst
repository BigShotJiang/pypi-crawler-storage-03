.. click:: bedrock_server_manager.__main__:cli
   :prog: bedrock-server-manager
   :nested: full