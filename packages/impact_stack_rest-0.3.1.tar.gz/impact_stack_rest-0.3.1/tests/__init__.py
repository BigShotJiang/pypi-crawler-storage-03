"""Tests for impact-stack-requests."""
