### Impact Stack REST

This library implements utilities for making inter services requests between Impact Stack
microservices.

All the requests are authenticated using JWTs that are previously fetched from the auth-service.
