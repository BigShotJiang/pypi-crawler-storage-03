# CxGParser
CxG Induction Parser.

## License
MIT License, Copyright (c) 2025 CxGrammar.
