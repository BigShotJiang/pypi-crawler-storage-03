import numpy as np
import matplotlib.pyplot as plt

x = np.arange(5)
plt.plot(x)
plt.show()