Python Quickstart
=================

This document explains how to use pyxsccd process a time series. 
Some advanced topics are glossed over to be covered in more detail
elsewhere in pyxsccd documentation. Only the CSV format is used here,
but the examples do apply to raster-based time series formats. It is 
presumed that Rasterio has been :doc:`installed <installation>`.