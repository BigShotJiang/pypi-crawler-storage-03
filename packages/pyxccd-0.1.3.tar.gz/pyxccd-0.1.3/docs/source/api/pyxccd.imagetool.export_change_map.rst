pyxccd.imagetool.export\_change\_map module
===========================================

.. automodule:: pyxccd.imagetool.export_change_map
   :members:
   :undoc-members:
   :show-inheritance:
