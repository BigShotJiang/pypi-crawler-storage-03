BASE_URL = "https://animeflv.net"
SEARCH_URL = "https://animeflv.net/browse"
ANIME_VIDEO_URL = "https://animeflv.net/ver"
ANIME_URL = "https://animeflv.net/anime"
BASE_EPISODE_IMG_URL = "https://cdn.animeflv.net/screenshots"

SW_DOWNLOAD_URL = "https://hgplaycdn.com/f"
