from anime_scraper.scrapers.jkanime.scraper import JKAnimeScraper
