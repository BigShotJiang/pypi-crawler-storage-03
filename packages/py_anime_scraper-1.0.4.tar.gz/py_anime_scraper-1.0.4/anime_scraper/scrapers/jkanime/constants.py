BASE_URL = "https://jkanime.net"
SEARCH_URL = "https://jkanime.net/buscar"
BASE_EPISODE_IMG_URL = (
    "https://cdn.jkdesu.com/assets/images/animes/video/image_thumb"
)

SW_DOWNLOAD_URL = "https://flaswish.com/f"

IMPERSONATE = "chrome"
