

.. _scenedetect-video_splitter:

---------------------------------------------------------------
Video Splitting
---------------------------------------------------------------

.. automodule:: scenedetect.video_splitter
   :members:
