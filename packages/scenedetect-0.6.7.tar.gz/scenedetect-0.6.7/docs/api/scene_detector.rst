
.. _scenedetect-scene_detector:

-------------------------------------------------
SceneDetector
-------------------------------------------------

.. automodule:: scenedetect.scene_detector
   :members:
