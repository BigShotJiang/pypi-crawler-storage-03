
.. _scenedetect-scene_manager:

-----------------------------------------------------------------------
SceneManager
-----------------------------------------------------------------------

.. automodule:: scenedetect.scene_manager
   :members:
