
.. _scenedetect-frame_timecode:

---------------------------------------------------------------
FrameTimecode
---------------------------------------------------------------

.. automodule:: scenedetect.frame_timecode
   :members:
