
.. _scenedetect-video_stream:

---------------------------------------------------------------
VideoStream
---------------------------------------------------------------

.. automodule:: scenedetect.video_stream
   :members:
