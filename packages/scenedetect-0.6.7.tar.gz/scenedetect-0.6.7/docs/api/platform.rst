
.. _scenedetect-platform:

---------------------------------------------------------------
Platform & Logging
---------------------------------------------------------------

.. automodule:: scenedetect.platform
    :members:
