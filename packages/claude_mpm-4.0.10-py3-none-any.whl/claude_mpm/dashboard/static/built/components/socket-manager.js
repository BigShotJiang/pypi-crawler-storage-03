import{S as a,S as e}from"../socket-client.js";export{a as SocketManager,e as default};
//# sourceMappingURL=socket-manager.js.map
