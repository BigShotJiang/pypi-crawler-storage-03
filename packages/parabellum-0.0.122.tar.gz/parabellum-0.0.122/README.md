# Parabellum

TODO: switch to red and blue team semantics (not enemy and ally)
