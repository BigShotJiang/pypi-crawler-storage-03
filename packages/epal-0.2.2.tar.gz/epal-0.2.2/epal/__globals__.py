VERSION = "0.2.2"
VERSION_NAME = "cherrywood"

__application__ = None
__window__ = None
