# GCSOPT

Library based on [CVXPY](https://www.cvxpy.org) to solve optimization problems in Graphs of Convex Sets (GCS).
For a detailed description of the algorithms implemented implemented in this library see the PhD thesis [Graphs of Convex Sets with Applications to Optimal Control and Motion Planning
](https://groups.csail.mit.edu/robotics-center/public_papers/Marcucci24a.pdf).

**Warning:** The library is still under development and not thoroughly tested yet.
