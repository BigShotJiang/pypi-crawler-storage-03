from .watcher import RabbitWatcher, new_watcher
