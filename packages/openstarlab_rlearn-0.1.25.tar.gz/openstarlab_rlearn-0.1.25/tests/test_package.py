from rlearn.sports.main_class import RLearn_Model

# pytestを通すためだけの空のテスト
def test_import():
    RLearn_Model.__name__()