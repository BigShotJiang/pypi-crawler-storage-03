"""CSO Doctor - Diagnose and check prerequisites."""

import subprocess
import shutil
import platform
from typing import Dict, Any
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()
app = typer.Typer(help="Diagnose CSO environment and prerequisites")


def check_command(cmd: str) -> Dict[str, Any]:
    """Check if a command exists and get its version."""
    path = shutil.which(cmd)
    if not path:
        return {"installed": False, "path": None, "version": None}

    # Try to get version
    version = None
    try:
        # Different commands have different version flags
        version_flags = {
            "terraform": ["version", "-json"],
            "gcloud": ["version", "--format=json"],
            "kubectl": ["version", "--client", "--short"],
            "helm": ["version", "--short"],
            "docker": ["--version"],
            "git": ["--version"],
        }

        flag = version_flags.get(cmd, ["--version"])
        result = subprocess.run([cmd] + flag, capture_output=True, text=True, timeout=5)

        if result.returncode == 0:
            version = result.stdout.strip().split("\n")[0]
    except Exception:
        pass

    return {"installed": True, "path": path, "version": version}


def check_gcp_auth() -> Dict[str, Any]:
    """Check GCP authentication status."""
    try:
        result = subprocess.run(
            ["gcloud", "auth", "list", "--format=json"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            import json

            accounts = json.loads(result.stdout)
            if accounts:
                active = next(
                    (a for a in accounts if a.get("status") == "ACTIVE"), None
                )
                return {
                    "authenticated": True,
                    "account": active.get("account") if active else None,
                    "accounts": len(accounts),
                }
    except Exception:
        pass

    return {"authenticated": False, "account": None}


def check_aws_auth() -> Dict[str, Any]:
    """Check AWS authentication status."""
    try:
        result = subprocess.run(
            ["aws", "sts", "get-caller-identity"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            import json

            identity = json.loads(result.stdout)
            return {
                "authenticated": True,
                "account": identity.get("Account"),
                "user": identity.get("Arn", "").split("/")[-1],
            }
    except Exception:
        pass

    return {"authenticated": False, "account": None}


def check_kubernetes() -> Dict[str, Any]:
    """Check Kubernetes cluster connection."""
    try:
        # Get current context
        context_result = subprocess.run(
            ["kubectl", "config", "current-context"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        current_context = (
            context_result.stdout.strip() if context_result.returncode == 0 else None
        )

        # Check cluster info
        cluster_result = subprocess.run(
            ["kubectl", "cluster-info"], capture_output=True, text=True, timeout=5
        )

        connected = cluster_result.returncode == 0

        return {
            "connected": connected,
            "context": current_context,
            "cluster_info": cluster_result.stdout.strip() if connected else None,
        }
    except Exception:
        pass

    return {"connected": False, "context": None}


def check_docker() -> Dict[str, Any]:
    """Check Docker status."""
    try:
        result = subprocess.run(
            ["docker", "info", "--format", "json"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            import json

            info = json.loads(result.stdout)
            return {
                "running": True,
                "version": info.get("ServerVersion"),
                "os": info.get("OperatingSystem"),
                "kubernetes": "kubernetes" in info.get("Name", "").lower()
                or "desktop" in info.get("OperatingSystem", "").lower(),
            }
    except Exception:
        pass

    return {"running": False}


@app.command()
def check(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show detailed information"
    ),
    fix: bool = typer.Option(False, "--fix", help="Show how to fix issues"),
):
    """Check all CSO prerequisites and environment."""

    console.print(
        Panel.fit(
            "[bold cyan]CSO Doctor[/bold cyan]\n"
            "Checking your environment for CloudStack Orchestrator",
            border_style="cyan",
        )
    )

    # System Information
    console.print("\n[bold yellow]System Information[/bold yellow]")
    sys_table = Table(show_header=False, box=None)
    sys_table.add_row("OS:", platform.system())
    sys_table.add_row("Version:", platform.version())
    sys_table.add_row("Python:", platform.python_version())
    sys_table.add_row("Architecture:", platform.machine())
    console.print(sys_table)

    # Required Tools
    console.print("\n[bold yellow]Required Tools[/bold yellow]")
    tools = {
        "kubectl": {"required": True, "purpose": "Kubernetes management"},
        "helm": {"required": True, "purpose": "Package management"},
        "git": {"required": True, "purpose": "Version control"},
        "docker": {"required": False, "purpose": "Container runtime (for local)"},
        "terraform": {"required": False, "purpose": "Infrastructure provisioning"},
        "gcloud": {"required": False, "purpose": "GCP management"},
        "aws": {"required": False, "purpose": "AWS management"},
    }

    tools_table = Table(show_header=True)
    tools_table.add_column("Tool", style="cyan")
    tools_table.add_column("Status", style="green")
    tools_table.add_column("Version")
    tools_table.add_column("Purpose", style="dim")

    missing_required = []
    missing_optional = []

    for tool, info in tools.items():
        status = check_command(tool)

        if status["installed"]:
            status_icon = "✅"
            status_text = "Installed"
            version = status["version"] or "Unknown"
        else:
            if info["required"]:
                status_icon = "❌"
                status_text = "Missing"
                missing_required.append(tool)
            else:
                status_icon = "⚠️"
                status_text = "Not found"
                missing_optional.append(tool)
            version = "-"

        tools_table.add_row(
            f"{status_icon} {tool}",
            status_text,
            version[:40] if version != "-" else version,
            info["purpose"],
        )

    console.print(tools_table)

    # Kubernetes Status
    console.print("\n[bold yellow]Kubernetes Status[/bold yellow]")
    k8s_status = check_kubernetes()

    if k8s_status["connected"]:
        console.print(
            f"✅ Connected to cluster: [green]{k8s_status['context']}[/green]"
        )
        if verbose and k8s_status["cluster_info"]:
            console.print(f"   {k8s_status['cluster_info'][:100]}")
    else:
        console.print("❌ Not connected to any Kubernetes cluster")

    # Docker Status (for local development)
    console.print("\n[bold yellow]Docker Status[/bold yellow]")
    docker_status = check_docker()

    if docker_status["running"]:
        console.print("✅ Docker is running")
        if docker_status.get("kubernetes"):
            console.print("   [green]Kubernetes support detected[/green]")
    else:
        console.print("⚠️ Docker not running or not installed")

    # Cloud Provider Authentication
    console.print("\n[bold yellow]Cloud Provider Authentication[/bold yellow]")

    # GCP
    if check_command("gcloud")["installed"]:
        gcp_auth = check_gcp_auth()
        if gcp_auth["authenticated"]:
            console.print(
                f"✅ GCP: Authenticated as [green]{gcp_auth['account']}[/green]"
            )
        else:
            console.print("⚠️ GCP: Not authenticated (run: gcloud auth login)")
    else:
        console.print("⚠️ GCP: gcloud not installed")

    # AWS
    if check_command("aws")["installed"]:
        aws_auth = check_aws_auth()
        if aws_auth["authenticated"]:
            console.print(f"✅ AWS: Authenticated as [green]{aws_auth['user']}[/green]")
        else:
            console.print("⚠️ AWS: Not authenticated (configure with: aws configure)")
    else:
        console.print("⚠️ AWS: AWS CLI not installed")

    # CSO Configuration
    console.print("\n[bold yellow]CSO Configuration[/bold yellow]")
    cso_dir = Path.home() / ".cso"

    if cso_dir.exists():
        console.print(f"✅ CSO directory exists: {cso_dir}")

        # Check for terraform state
        tf_state = cso_dir / "terraform" / "terraform.tfstate"
        if tf_state.exists():
            console.print("   📦 Terraform state found")

        # Check for bootstrap config
        bootstrap_json = cso_dir / "bootstrap.json"
        if bootstrap_json.exists():
            console.print("   📋 Bootstrap configuration found")
    else:
        console.print(f"⚠️ CSO directory not found: {cso_dir}")

    # Summary and Recommendations
    console.print("\n" + "=" * 50)

    if not missing_required and not missing_optional:
        console.print("\n[green]✅ All prerequisites satisfied![/green]")
        console.print("You're ready to use CSO!")
    else:
        if missing_required:
            console.print(
                f"\n[red]❌ Missing required tools: {', '.join(missing_required)}[/red]"
            )

        if missing_optional:
            console.print(
                f"\n[yellow]⚠️ Missing optional tools: {', '.join(missing_optional)}[/yellow]"
            )

        if fix:
            console.print("\n[cyan]📝 How to fix:[/cyan]")

            fixes = {
                "kubectl": {
                    "Windows": "choco install kubernetes-cli",
                    "Darwin": "brew install kubectl",
                    "Linux": "curl -LO https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl",
                },
                "helm": {
                    "Windows": "choco install kubernetes-helm",
                    "Darwin": "brew install helm",
                    "Linux": "curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash",
                },
                "terraform": {
                    "Windows": "choco install terraform",
                    "Darwin": "brew install terraform",
                    "Linux": "wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg",
                },
                "gcloud": {
                    "Windows": "Download from: https://cloud.google.com/sdk/docs/install",
                    "Darwin": "brew install google-cloud-sdk",
                    "Linux": "curl https://sdk.cloud.google.com | bash",
                },
                "docker": {
                    "Windows": "Download Docker Desktop: https://www.docker.com/products/docker-desktop",
                    "Darwin": "brew install --cask docker",
                    "Linux": "curl -fsSL https://get.docker.com | sh",
                },
                "aws": {
                    "Windows": "choco install awscli",
                    "Darwin": "brew install awscli",
                    "Linux": "pip install awscli",
                },
            }

            current_os = platform.system()

            for tool in missing_required + missing_optional:
                if tool in fixes and current_os in fixes[tool]:
                    console.print(f"\n{tool}:")
                    console.print(f"  {fixes[tool][current_os]}")

    # Quick start
    console.print("\n[bold cyan]Quick Start Commands:[/bold cyan]")
    console.print("1. Local development:  [yellow]cso setup --provider local[/yellow]")
    console.print(
        "2. GCP with infra:     [yellow]cso setup --provider gcp --provision-infrastructure --gcp-project-id PROJECT[/yellow]"
    )
    console.print("3. Check status:       [yellow]cso status[/yellow]")


if __name__ == "__main__":
    app()
