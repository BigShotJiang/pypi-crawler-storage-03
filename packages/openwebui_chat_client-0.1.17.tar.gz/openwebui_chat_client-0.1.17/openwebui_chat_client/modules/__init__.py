# Modules for OpenWebUI Chat Client

from .prompts_manager import PromptsManager

__all__ = ['PromptsManager']