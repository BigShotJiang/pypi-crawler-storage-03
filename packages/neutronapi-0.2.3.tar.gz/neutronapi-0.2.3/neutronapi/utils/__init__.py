"""Utility helpers for neutronapi (IDs, etc.)."""

