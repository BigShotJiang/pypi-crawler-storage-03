from abc import ABC


class BaseLengthEncoding(ABC):
    pass
