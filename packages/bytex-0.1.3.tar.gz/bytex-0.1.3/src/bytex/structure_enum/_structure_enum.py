from enum import Enum

STRUCTURE_ENUM_CODEC_KEY: str = "_codec_"


class _StructureEnum(Enum):
    pass
