from bytex.structure_enum._structure_enum import (
    STRUCTURE_ENUM_CODEC_KEY,
    _StructureEnum,
)
from bytex.structure_enum.structure_enum import StructureEnum

__all__ = ["_StructureEnum", "STRUCTURE_ENUM_CODEC_KEY", "StructureEnum"]
