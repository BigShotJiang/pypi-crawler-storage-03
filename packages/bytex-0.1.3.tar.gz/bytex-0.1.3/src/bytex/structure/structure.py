from bytex.structure.structure_meta import StructureMeta
from bytex.structure._structure import _Structure


class Structure(_Structure, metaclass=StructureMeta):
    pass
