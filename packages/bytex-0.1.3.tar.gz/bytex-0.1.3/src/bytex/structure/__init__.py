from bytex.structure.structure import Structure

__all__ = ["Structure"]
