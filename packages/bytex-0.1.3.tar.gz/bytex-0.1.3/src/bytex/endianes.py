from enum import Enum


class Endianes(Enum):
    BIG = "Big"
    LITTLE = "Little"
