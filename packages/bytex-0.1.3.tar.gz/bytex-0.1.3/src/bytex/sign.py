from enum import Enum


class Sign(str, Enum):
    SIGNED = "I"
    UNSIGNED = "U"
