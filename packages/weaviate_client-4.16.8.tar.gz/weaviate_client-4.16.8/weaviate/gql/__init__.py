"""GraphQL module used to create `get` and/or `aggregate`  GraphQL requests from Weaviate."""
