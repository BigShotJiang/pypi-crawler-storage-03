weaviate.collections.data
=========================

.. automodule:: weaviate.collections.data
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

.. weaviate.collections.data.data
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.data.data
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:

.. weaviate.collections.data.sync
.. ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. .. automodule:: weaviate.collections.data.sync
..    :members:
..    :undoc-members:
..    :show-inheritance:
..    :private-members:
