###########
 processor
###########

.. automodule:: anemoi.inference.processor
   :members:
   :no-undoc-members:
   :show-inheritance:

.. include:: ../_api/inference.pre_processors.rst

.. include:: ../_api/inference.post_processors.rst
