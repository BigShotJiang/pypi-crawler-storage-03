########
 runner
########

.. automodule:: anemoi.inference.runner
   :members:
   :no-undoc-members:
   :show-inheritance:

.. include:: ../_api/inference.runners.rst
