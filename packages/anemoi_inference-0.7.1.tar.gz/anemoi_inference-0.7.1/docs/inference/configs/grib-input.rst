.. _grib-input:

############
 GRIB input
############

.. note::

   This is placeholder documentation. This will explain how to use the
   GRIB input's behaviour can be configured.

Use the ``namer`` parameter to specify how to rename fields to match the
names in the checkpoints.

.. literalinclude:: yaml/grib-input_1.yaml
