#!/bin/sh
# SPDX-FileCopyrightText: <year> <company>
#
# SPDX-License-Identifier: GPL-3.0-or-later
