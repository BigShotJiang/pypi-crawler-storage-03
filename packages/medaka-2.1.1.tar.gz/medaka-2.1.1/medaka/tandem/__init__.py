"""This module expose the main function for the tandem package."""

from .tandem import main

__all__ = ["main"]
