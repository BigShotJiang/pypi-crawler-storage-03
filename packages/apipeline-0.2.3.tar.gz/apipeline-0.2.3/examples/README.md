
## examples

- `python -m examples.sentence_aggregator`