# coding: utf-8

"""
Mux Python - Copyright 2019 Mux Inc.

NOTE: This class is auto generated. Do not edit the class manually.
"""


from __future__ import absolute_import

import unittest

import mux_python
from mux_python.models.create_track_request import CreateTrackRequest  # noqa: E501
from mux_python.rest import ApiException


class TestCreateTrackRequest(unittest.TestCase):
    """CreateTrackRequest unit test stubs"""

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testCreateTrackRequest(self):
        """Test CreateTrackRequest"""
        # FIXME: construct object with mandatory attributes with example values
        # model = mux_python.models.create_track_request.CreateTrackRequest()  # noqa: E501
        pass


if __name__ == '__main__':
    unittest.main()
