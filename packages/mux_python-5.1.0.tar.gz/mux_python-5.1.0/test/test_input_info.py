# coding: utf-8

"""
Mux Python - Copyright 2019 Mux Inc.

NOTE: This class is auto generated. Do not edit the class manually.
"""


from __future__ import absolute_import

import unittest

import mux_python
from mux_python.models.input_info import InputInfo  # noqa: E501
from mux_python.rest import ApiException


class TestInputInfo(unittest.TestCase):
    """InputInfo unit test stubs"""

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testInputInfo(self):
        """Test InputInfo"""
        # FIXME: construct object with mandatory attributes with example values
        # model = mux_python.models.input_info.InputInfo()  # noqa: E501
        pass


if __name__ == '__main__':
    unittest.main()
