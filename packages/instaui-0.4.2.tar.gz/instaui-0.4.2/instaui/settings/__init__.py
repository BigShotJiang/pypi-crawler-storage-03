from .__settings import use_tailwind


__all__ = ["use_tailwind"]
