"""Conftest for replay+reset mode tests."""
