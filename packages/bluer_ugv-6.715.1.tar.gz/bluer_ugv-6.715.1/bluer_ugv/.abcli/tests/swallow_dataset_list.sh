#! /usr/bin/env bash

function test_bluer_ugv_swallow_dataset_list() {
    local options=$1

    bluer_ugv_swallow_dataset_list
}
