# -*- coding: utf-8 -*-

__title__ = "gapipy"

__version__ = "2.39.0"

from .client import Client  # noqa
