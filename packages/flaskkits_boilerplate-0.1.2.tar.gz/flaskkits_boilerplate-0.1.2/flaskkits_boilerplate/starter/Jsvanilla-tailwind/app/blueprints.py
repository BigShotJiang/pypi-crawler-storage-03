from flask import Blueprint

main = Blueprint('main', __name__)
