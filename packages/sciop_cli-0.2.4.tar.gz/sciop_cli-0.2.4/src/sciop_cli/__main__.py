from sciop_cli.cli.main import cli

cli()
