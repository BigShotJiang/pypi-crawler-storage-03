"""Generated models from OpenAPI spec."""
