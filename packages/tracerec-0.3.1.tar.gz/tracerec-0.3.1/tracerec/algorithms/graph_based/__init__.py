# Algoritmos basados en conocimiento
from tracerec.algorithms.embedder import Embedder
