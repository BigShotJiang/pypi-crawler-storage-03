"""
MTV API
"""

from .tracker import MtvTracker
