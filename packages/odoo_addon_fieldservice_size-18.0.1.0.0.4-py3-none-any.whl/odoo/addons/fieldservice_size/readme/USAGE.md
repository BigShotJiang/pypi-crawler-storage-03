\## Enter sizes for field service locations. Go to Master Data \>
Locations

1.  Select or create a location.
2.  Go to the Sizes tab.
3.  Select a Size. Enter the value for the size.

\## Use Order Sizes

1.  Select or create a field service order.
2.  Set a location on the order.
3.  Set a type on the order.
4.  The size value will update to the location's size value of the order
    type's default size.
