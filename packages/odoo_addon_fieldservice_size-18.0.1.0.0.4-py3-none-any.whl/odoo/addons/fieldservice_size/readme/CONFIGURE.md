To configure field service sizes, go to Configuration \> Sizes.

Set the size name, type of orders to which the size will apply, and unit
of measure for the size. If this size is the default size to be used for
orders of the designated type, select the option for 'Is Order Size'.
