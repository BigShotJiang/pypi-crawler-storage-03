## v0.0.4 (2025-08-19)

### Fix

- **uv-loop**: fixes windows compatibility

## v0.0.3 (2025-08-14)

### Fix

- **tiles**: fixes bug on tiles not being generated properly
- update cog2tiles version to 0.0.2 and add commitizen to dev dependencies
- **publish**: remove unnecessary --no-group dev flag from uv sync

## v0.0.2 (2025-08-14)

### Fix

- **cz**: adds cz version
- **ci**: adds ci to publish the package
