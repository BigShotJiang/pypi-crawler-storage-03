def main():
    print("Hello from cogtiler!")


if __name__ == "__main__":
    main()
