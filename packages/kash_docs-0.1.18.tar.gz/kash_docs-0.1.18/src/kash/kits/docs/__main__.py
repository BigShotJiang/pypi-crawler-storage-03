from kash.shell import shell_main

if __name__ == "__main__":
    shell_main.main()
