#!/usr/bin/env python3
"""
Test script to validate usage tracking with port-forwarded manager API.

Prerequisites:
1. Port-forward the manager service: kubectl port-forward -n api-services svc/manager 8080:8080
2. Set environment variables in .env:
   - MANAGER_URL=http://localhost:8080
   - SERVICE_NAME=your-service-name
   - TEST_LLM_URL and TEST_LLM_APIKEY for model API calls
3. Ensure LOCAL_CONFIGS=False to use production UsageTracker
"""

import asyncio
import sys
import os
from datetime import datetime
from pydantic import BaseModel

# Add the current directory to Python path for imports
sys.path.insert(0, '.')

from confidentialmind_core.model_client import ModelClient
from confidentialmind_core.usage_tracker import get_usage_tracker, UsageTracker, UsageRecord, UsageType
from confidentialmind_core.config_manager import load_environment, ConfigManager
from confidentialmind_core import config

# initialize the configuration manager

class DummyConfig(BaseModel):
    dummy_field: str = "dummy_value"

cm = ConfigManager()
cm.init_manager(config_model=DummyConfig())


def validate_environment():
    """Validate that required environment variables are set for manager API testing"""
    print("=== Validating Environment for Manager API Testing ===")
    
    required_vars = {
        'MANAGER_URL': 'Manager API URL (should be http://localhost:8080 for port-forward)',
        'SERVICE_NAME': 'Your service name for stack identification',
        'TEST_LLM_URL': 'Model API URL for testing',
        'TEST_LLM_APIKEY': 'Model API key for testing'
    }
    
    # Optional vars for testing modes
    optional_vars = {
        'USAGE_TRACKER_DEBUG': 'Set to "true" to use debug tracker instead of manager API',
        'CONFIDENTIAL_MIND_LOCAL_CONFIG': 'Set to "False" for production-like config manager'
    }
    
    missing_vars = []
    for var, description in required_vars.items():
        value = os.environ.get(var)
        if value:
            # Mask API keys for security
            display_value = value if 'APIKEY' not in var else f"{value[:10]}...{value[-4:]}"
            print(f"✓ {var} = {display_value}")
        else:
            print(f"✗ {var} is missing ({description})")
            missing_vars.append(var)
    
    # Show optional configuration
    print("\nConfiguration:")
    for var, description in optional_vars.items():
        value = os.environ.get(var, "not set")
        print(f"  {var} = {value}")
    
    print(f"\nLocal development mode: {config.LOCAL_DEV}")
    print(f"Local configs mode: {config.LOCAL_CONFIGS}")
    
    # Check debug mode - explicit setting takes precedence
    debug_env = os.environ.get("USAGE_TRACKER_DEBUG", "").lower()
    
    if debug_env in ("true", "1", "yes"):
        print("📝 DEBUG MODE: USAGE_TRACKER_DEBUG=true - using DebugUsageTracker")
        print("   (logs only, no manager API calls)")
    elif debug_env in ("false", "0", "no"):
        print("🔗 PRODUCTION MODE: USAGE_TRACKER_DEBUG=false - using real UsageTracker")
        print("   (will make actual manager API calls)")
    elif config.LOCAL_DEV and config.LOCAL_CONFIGS:
        print("📝 AUTO DEBUG MODE: LOCAL_DEV=True + LOCAL_CONFIGS=True - using DebugUsageTracker")
        print("   Set USAGE_TRACKER_DEBUG=false to override and use real manager API")
    else:
        print("🔗 PRODUCTION MODE: Will use real UsageTracker with manager API")
    
    if missing_vars:
        print(f"\n❌ Missing required environment variables: {', '.join(missing_vars)}")
        print("\nTo set up port-forwarding and test:")
        print("1. kubectl port-forward -n api-services svc/manager 8080:8080")
        print("2. Add to your .env file:")
        print("   MANAGER_URL=http://localhost:8080")
        print("   SERVICE_NAME=your-service-name")
        print("   CONFIDENTIAL_MIND_LOCAL_CONFIG=False")
        print("3. Choose testing mode:")
        print("   For debug mode (safe, logs only): USAGE_TRACKER_DEBUG=true")
        print("   For real manager API (requires proper config): leave USAGE_TRACKER_DEBUG unset")
        return False
    
    return True


async def test_manager_api_connection():
    """Test that we can connect to and use the manager API"""
    print("\n=== Testing Manager API Connection ===")
    
    # Get the usage tracker (should be production UsageTracker, not debug)
    tracker = get_usage_tracker()
    print(f"Using tracker: {type(tracker).__name__}")
    
    if not isinstance(tracker, UsageTracker):
        print("⚠ Using DebugUsageTracker - set CONFIDENTIAL_MIND_LOCAL_CONFIG=False to test real API")
        return True  # Still continue with the test
    
    # Test direct usage reporting
    print("\nTesting direct usage reporting...")
    
    # Create a usage record manually for testing
    usage_record = UsageRecord(
        originId="test-origin",
        targetId="test-target",
        timestamp=int(datetime.now().timestamp()),
        apiKey=None,
        traceId="manager-api-test-trace",
        type=UsageType.INPUT_TOKENS.value,
        value=100
    )
    
    success = await tracker.report_usage(
        usage_records=[usage_record],
    )
    
    if success:
        print("✓ Direct usage reporting successful")
    else:
        print("✗ Direct usage reporting failed")
        return False
    
    return True


async def test_model_client_with_manager():
    """Test ModelClient with real manager API reporting"""
    print("\n=== Testing ModelClient with Manager API ===")
    
    try:
        # Create client with usage tracking enabled
        client = ModelClient(config_id="TEST_LLM", auto_track_usage=True)
        print("✓ ModelClient created with auto usage tracking")
        
        # Make a model API call
        print("\nMaking model API call...")
        response = await client.completions_with_usage(
            model="cm-llm",
            messages=[{"role": "user", "content": "Say 'Manager API test successful!'"}],
            max_tokens=10,
            temperature=0,
            trace_id="manager-integration-test"
        )
        
        if hasattr(response, 'choices') and len(response.choices) > 0:
            content = response.choices[0].message.content
            print(f"✓ Model response: '{content.strip()}'")
            
            if hasattr(response, 'usage'):
                usage = response.usage
                print(f"✓ Token usage: {usage.prompt_tokens} + {usage.completion_tokens} = {usage.total_tokens}")
                print("✓ Usage data should now be reported to manager API")
            else:
                print("⚠ No usage data in response")
        
        # Test streaming with manager API
        print("\nTesting streaming with manager API...")
        response_stream = await client.completions_with_usage(
            model="cm-llm",
            messages=[{"role": "user", "content": "Count 1, 2, 3"}],
            max_tokens=15,
            temperature=0,
            stream=True,
            trace_id="manager-streaming-test"
        )
        
        chunks_received = 0
        async for chunk in response_stream:
            chunks_received += 1
        
        print(f"✓ Streaming completed: {chunks_received} chunks")
        print("✓ Usage data from streaming should be reported to manager API")
        
        return True
        
    except Exception as e:
        print(f"✗ Model client test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """Run manager API validation tests"""
    print("🔗 Testing ConfidentialMind Core with Manager API")
    print("=" * 60)
    
    # Load environment
    load_environment()
    
    # Validate environment setup
    if not validate_environment():
        return False
    
    print("\n" + "=" * 60)
    
    # Test manager API connection
    api_success = await test_manager_api_connection()
    
    # Test model client integration
    client_success = await test_model_client_with_manager()
    
    print("\n" + "=" * 60)
    
    if api_success and client_success:
        print("✅ All manager API tests passed!")
        print("\n🎉 Your usage tracking system is working with the real manager API!")
        print("\nUsage data should now be visible in:")
        print("- Manager API logs")
        print("- Usage database")
        print("- Monitoring dashboards")
        
        print("\nNext steps:")
        print("1. Check manager API logs for usage records")
        print("2. Verify data appears in the usage database")
        print("3. Deploy to production environment")
    else:
        print("❌ Some manager API tests failed")
        print("\nTroubleshooting:")
        print("1. Ensure port-forwarding is active: kubectl port-forward -n api-services svc/manager 8080:8080")
        print("2. Check manager API is responding: curl http://localhost:8080/health")
        print("3. Verify SERVICE_NAME matches a real service in the stack")
        print("4. Check manager API logs for error messages")
    
    return api_success and client_success


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)