LOCAL_DEV = False
LOCAL_CONFIGS = False

# Service URLs
MANAGER_SERVICE_URL = "http://manager.api-services.svc.cluster.local:8080"
REALTIME_SERVICE_URL = "ws://realtime.api-services.svc.cluster.local:8080"
