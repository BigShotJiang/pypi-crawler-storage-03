from setuptools import setup

setup(
    name="dew_gwdata",
    use_scm_version={"version_scheme": "post-release"},
    setup_requires=["setuptools_scm"],
    description="Python module for accessing groundwater data internally at DEW",
    long_description=open("README.md", "r").read(),
    long_description_content_type="text/markdown",
    url="http://github.com/dew-waterscience/dew_gwdata",
    author="Kent Inverarity",
    author_email="kent.inverarity@sa.gov.au",
    packages=["dew_gwdata"],
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "logger20 = dew_gwdata.logger20_dosbox:logger20",
            "dew_gwdata.webapp = dew_gwdata.webapp.main:run_webapp"
        ]
    },
    install_requires=[
        "loguru",
        "numpy",
        "matplotlib",
        "networkx",
        "pillow",
        "pandas",
        "ipython",
        "geopandas",
        "rasterio",
        "shapely",
        "toml",
        "requests",
        "appdirs",
        "lasio",
        "python-sa-gwdata>=0.14",
        "sageodata_db>=0.43",
        "ausweather>=0.9",
        "aquarius_webportal",
        "click",
        "pyodbc",
        "sqlparse",
        "sqlalchemy",
        "fastapi",
        "pydantic",
        "pypdf",
        "uvicorn",
    ],
)
