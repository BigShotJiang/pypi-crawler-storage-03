# pyciv7
Python bindings for the Sid Meier’s Civilization VII Software Development Kit (SDK)
