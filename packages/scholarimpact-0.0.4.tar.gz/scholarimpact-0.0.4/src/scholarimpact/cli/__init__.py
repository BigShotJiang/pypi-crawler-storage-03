"""CLI module for ScholarImpact."""

from .main import cli

__all__ = ["cli"]
