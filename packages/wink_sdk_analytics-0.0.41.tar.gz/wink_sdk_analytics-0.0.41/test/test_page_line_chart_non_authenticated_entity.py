# coding: utf-8

"""
    Wink API

     # Introduction  Welcome to the Wink API - A programmer-friendly way to manage, sell and book travel inventory on the Wink platform. The API gives you all the tools you need to ready your properties and inventory for sale across 1000s of our native sales channels.  Integrators, affiliates, travel agents and content creators have the ability search for your travel inventory and promote / sell it in a wide variety of ways.   # Integrations  We have already integrated with the most well-known channel managers so you don't have to. To see our current integrations, please go to https://extranet.wink.travel and scroll to Connectivity section. Once your properties are set up, you can finish the setup by mapping your property to Wink using your channel manager partner portal. If your properties don't have a channel manager, you can easily manage rates and availability with this API.   # Intended Audience  Programmers are [most likely] a requirement to start integrating with Wink. Companies and organizations that would most benefit from integrating with us are new and existing travel companies that have relationships with suppliers and that need an advanced system from which to manage their travel inventory and get that same inventory out to as many eyeballs as possible at the lowest price possible.  - Hotel chains  - Hotel brands  - Travel tech companies  - Destination sites  - Integrators  - Aggregators  - Destination management companies  - Travel agencies  - OTAs   ## APIs  Not every integrator needs every API. For that reason, we have separated APIs into context.  ### Test API   - [Ping](/ping): The Ping API is a quick test endpoint to verify that your credentials work Wink.  ### Common APIs  - [Notifications](/notifications): The Notifications API is a way for us to stay in touch with your user, property or affiliate account. - [User Settings](/user-settings): The User Settings API exposes endpoints to allow 3rd party integrators to communicate with Wink.  ### Consume APIs Consume endpoints are for developers who want to find existing travel inventory and either book it or use it to advertise through one of their Wink affiliate accounts.   - [Configuration](/engine-client): A single endpoint to retrieve whitelabel + customization information for the booking engine.  - [Lookup](/lookup): All APIs related to locating inventory by region, locale and property flags.  - [Inventory](/inventory): All APIs related to retrieve known travel inventory as it was found using the Lookup API..  - [Booking](/booking): All APIs related to creating bookings on the platform.  - [Travel Agent](/travel-agent): The Travel Agent API exposes endpoints to manage agent-facilitated bookings.   ### Produce APIs  Produce endpoints are for developers who want to create and manage travel inventory.   #### Property  - [Property registration](/extranet/property/register): As a producer, this is, oftentimes, where you start your journey. These endpoints let you create properties on Wink.  - [Property](/extranet/property): This collection of property endpoints are mostly management endpoints that let you display, change status and similar for your existing properties.  - [Facilities](/extranet/facilities): This collection of endpoints let you manage facilities; such as room types.  - [Experiences](/extranet/experiences): This collection of endpoints let you manage experiences, such as activities.  - [Monetize](/extranet/monetize): The Monetize API exposes endpoints for managing cancellation polies, rate plans, promotions and more on Wink.  - [Distribution](/extranet/distribution): The Distribution API exposes endpoints for sales channels, connecting with affiliates, managing rates and inventory calendars and more on Wink.  - [Property Booking](/extranet/booking): The Property Booking API exposes endpoints for managing bookings and reviews at the property-level.   #### Affiliate  - [Affiliate](/affiliate): This collection of affiliate endpoints are mostly management endpoints that let you display, change status and similar for your existing accounts.  - [Browse](/affiliate/browse): The Browse API exposes endpoints for affiliates to find suppliers and inventory to sell.  - [Inventory](/affiliate/inventory): The Inventory API exposes endpoints for affiliates to manage the inventory they want to sell and how they want to sell it.  - [Sales Channel](/affiliate/sales-channel): The Sales Channel API exposes endpoints for affiliates to manage existing sales channels as well as find new ones.  - [WinkLinks](/affiliate/winklinks): The WinkLinks API exposes endpoints for affiliates to manage their WinkLinks page.   #### Rate provider  - [Channel manager](/channel-manager): The Channel Manager API enables external channel manager partners to map, exchange rate / availability information with us as well as be informed of bookings that occur on the Wink platform for one of their properties.   ### Taxonomy APIs  Taxonomy endpoints are for developers who want to consume and produce travel inventory and need taxonomies of standard and non-standard codes for inventory types, classes, statuses etc.   - [Reference](/reference): All APIs related to retrieving platform-supported taxonomies.   ### Insight APIs  Insight endpoints do exactly what the name implies - They offer platform-level insight into the activities of producers and consumers.   - [Analytics](/analytics): All APIs related to tracking metrics across a wide variety of data source segments including, more entertaining, leaderboard metrics.   ### Payment APIs  Payment endpoints are for developers who want to purchase travel inventory. This can be done via the API as a registered Travel Agent or using our API in conjunction with our PCI compliant payment widget for all other entities.   - [TripPay](/payment): All APIs related to TripPay account management, booking, mapping and integration features.   ## SDKs  We are actively working on supporting the most used languages out there. If you don't see your language here, reach out to us with a request to officially add your language. In the meantime, if you want to roll your own SDK, you can do so by downloading the OpenAPI spec and using one of the many available OpenAPI generators available: [https://openapi-generator.tech/docs/generators](https://openapi-generator.tech/docs/generators).   - Java SDK [https://github.com/wink-travel/wink-sdk-java](https://github.com/wink-travel/wink-sdk-java)   ## Usage  These features are made available to you via a [REST API](https://en.wikipedia.org/wiki/Representational_state_transfer). This API is language agnostic.   ## Versioning  We chose to version our endpoints in a way that we hope affects your integration minimally. You request the version of our API you wish to work with via the `Wink-Version` header. When it's time for you to upgrade, you only have to change the version number to get access to our updated endpoints.   ## Release history  - Follow updates on Github: https://github.com/wink-travel/wink-sdk-java/blob/master/CHANGELOG.md   # Analytics API Welcome to the Affiliate API - A programmer-friendly way to get insight into platform-level activities and bookings.  

    The version of the OpenAPI document: 30.5.19
    Contact: bjorn@wink.travel
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


import unittest

from wink_sdk_analytics.models.page_line_chart_non_authenticated_entity import PageLineChartNonAuthenticatedEntity

class TestPageLineChartNonAuthenticatedEntity(unittest.TestCase):
    """PageLineChartNonAuthenticatedEntity unit test stubs"""

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def make_instance(self, include_optional) -> PageLineChartNonAuthenticatedEntity:
        """Test PageLineChartNonAuthenticatedEntity
            include_optional is a boolean, when False only required
            params are included, when True both required and
            optional params are included """
        # uncomment below to create an instance of `PageLineChartNonAuthenticatedEntity`
        """
        model = PageLineChartNonAuthenticatedEntity()
        if include_optional:
            return PageLineChartNonAuthenticatedEntity(
                total_elements = 56,
                total_pages = 56,
                size = 56,
                content = [
                    wink_sdk_analytics.models.line_chart_non_authenticated_entity.LineChart_Non_Authenticated_Entity(
                        identifier = '', 
                        title = wink_sdk_analytics.models.chart_title_non_authenticated_entity.ChartTitle_Non_Authenticated_Entity(
                            text = '', ), 
                        legend = wink_sdk_analytics.models.chart_legend_non_authenticated_entity.ChartLegend_Non_Authenticated_Entity(
                            position = '', ), 
                        series_defaults = wink_sdk_analytics.models.chart_series_defaults_non_authenticated_entity.ChartSeriesDefaults_Non_Authenticated_Entity(
                            type = '', ), 
                        series = [
                            wink_sdk_analytics.models.chart_series_non_authenticated_entity.ChartSeries_Non_Authenticated_Entity(
                                name = '', 
                                data = [
                                    1.337
                                    ], )
                            ], 
                        value_axis = wink_sdk_analytics.models.value_axis.Value axis(
                            labels = wink_sdk_analytics.models.chart_value_axis_labels_non_authenticated_entity.ChartValueAxisLabels_Non_Authenticated_Entity(
                                format = '', ), 
                            line = wink_sdk_analytics.models.chart_value_axis_line_non_authenticated_entity.ChartValueAxisLine_Non_Authenticated_Entity(
                                visible = True, ), 
                            axis_crossing_value = 56, 
                            major_unit = 1.337, ), 
                        category_axis = wink_sdk_analytics.models.category_axis.Category axis(
                            auto_base_unit_steps = wink_sdk_analytics.models.auto_base_unit_steps_non_authenticated_entity.AutoBaseUnitSteps_Non_Authenticated_Entity(
                                milliseconds = 1.337, 
                                seconds = 1.337, 
                                minutes = 1.337, 
                                hours = 1.337, 
                                days = 1.337, 
                                weeks = 1.337, 
                                months = 1.337, 
                                years = 1.337, ), 
                            axis_crossing_value = [
                                None
                                ], 
                            background = '', 
                            base_unit = 'milliseconds', 
                            base_unit_step = 1.337, 
                            categories = [
                                ''
                                ], 
                            color = '', 
                            justified = True, 
                            major_grid_lines = wink_sdk_analytics.models.major_grid_lines.Major grid lines(
                                visible = True, ), 
                            major_ticks = wink_sdk_analytics.models.minor_ticks.Minor ticks(
                                color = '', 
                                size = 1.337, 
                                step = 1.337, 
                                skip = 1.337, 
                                visible = True, 
                                width = 1.337, ), 
                            max = datetime.datetime.strptime('2013-10-20 19:20:30.00', '%Y-%m-%d %H:%M:%S.%f'), 
                            max_date_groups = 1.337, 
                            max_divisions = 1.337, 
                            min = datetime.datetime.strptime('2013-10-20 19:20:30.00', '%Y-%m-%d %H:%M:%S.%f'), 
                            minor_grid_lines = wink_sdk_analytics.models.minor_grid_lines.Minor grid lines(
                                color = '', 
                                dash_type = 'dash', 
                                skip = 1.337, 
                                step = 1.337, 
                                visible = True, 
                                width = 1.337, ), 
                            minor_ticks = wink_sdk_analytics.models.minor_ticks.Minor ticks(
                                color = '', 
                                size = 1.337, 
                                step = 1.337, 
                                skip = 1.337, 
                                visible = True, 
                                width = 1.337, ), 
                            name = '', 
                            pane = '', 
                            plot_bands = [
                                wink_sdk_analytics.models.plot_bands.Plot bands(
                                    color = '', 
                                    from = '', 
                                    opacity = 1.337, 
                                    to = '', )
                                ], 
                            reverse = True, 
                            round_to_base_unit = True, 
                            start_angle = 1.337, 
                            type = 'category', 
                            week_start_day = 'Sunday', 
                            crosshair = wink_sdk_analytics.models.crosshair.Crosshair(
                                color = '', 
                                dash_type = 'dash', 
                                opacity = 1.337, 
                                visible = True, 
                                width = 1.337, 
                                tooltip = wink_sdk_analytics.models.category_axis_crosshair_tooltip_non_authenticated_entity.CategoryAxisCrosshairTooltip_Non_Authenticated_Entity(
                                    background = '', 
                                    border = wink_sdk_analytics.models.border_non_authenticated_entity.Border_Non_Authenticated_Entity(
                                        color = '', 
                                        dash_type = 'dash', 
                                        width = 1.337, ), 
                                    color = '', 
                                    font = '', 
                                    format = '', 
                                    padding = wink_sdk_analytics.models.padding_non_authenticated_entity.Padding_Non_Authenticated_Entity(
                                        top = 1.337, 
                                        right = 1.337, 
                                        bottom = 1.337, 
                                        left = 1.337, ), 
                                    visible = True, ), ), 
                            notes = wink_sdk_analytics.models.notes.Notes(
                                position = 'top', 
                                icon = wink_sdk_analytics.models.category_axis_notes_icon_non_authenticated_entity.CategoryAxisNotesIcon_Non_Authenticated_Entity(
                                    background = '', 
                                    size = 1.337, 
                                    type = 'square', 
                                    visible = True, ), 
                                label = wink_sdk_analytics.models.category_axis_notes_label_non_authenticated_entity.CategoryAxisNotesLabel_Non_Authenticated_Entity(
                                    background = '', 
                                    color = '', 
                                    font = '', 
                                    format = '', 
                                    position = 'inside', 
                                    rotation = 1.337, 
                                    visible = True, ), ), 
                            select = wink_sdk_analytics.models.select.Select(
                                from = wink_sdk_analytics.models.from.from(), 
                                max = wink_sdk_analytics.models.max.max(), 
                                min = wink_sdk_analytics.models.min.min(), 
                                mousewheel = wink_sdk_analytics.models.mousewheel.mousewheel(), 
                                to = wink_sdk_analytics.models.to.to(), ), 
                            visible = True, ), 
                        tooltip = wink_sdk_analytics.models.tool_tip.Tool tip(
                            visible = True, 
                            format = '', ), 
                        render_as = '', 
                        transitions = True, )
                    ],
                number = 56,
                sort = [
                    wink_sdk_analytics.models.sort_object.SortObject(
                        direction = '', 
                        null_handling = '', 
                        ascending = True, 
                        property = '', 
                        ignore_case = True, )
                    ],
                number_of_elements = 56,
                pageable = wink_sdk_analytics.models.pageable_object_non_authenticated_entity.PageableObject_Non_Authenticated_Entity(
                    offset = 56, 
                    sort = [
                        wink_sdk_analytics.models.sort_object.SortObject(
                            direction = '', 
                            null_handling = '', 
                            ascending = True, 
                            property = '', 
                            ignore_case = True, )
                        ], 
                    unpaged = True, 
                    page_number = 56, 
                    page_size = 56, 
                    paged = True, ),
                first = True,
                last = True,
                empty = True
            )
        else:
            return PageLineChartNonAuthenticatedEntity(
        )
        """

    def testPageLineChartNonAuthenticatedEntity(self):
        """Test PageLineChartNonAuthenticatedEntity"""
        # inst_req_only = self.make_instance(include_optional=False)
        # inst_req_and_optional = self.make_instance(include_optional=True)

if __name__ == '__main__':
    unittest.main()
