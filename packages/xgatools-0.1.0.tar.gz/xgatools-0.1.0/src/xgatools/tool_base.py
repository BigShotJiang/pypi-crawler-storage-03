from daytona_sdk import DaytonaConfig

from daytona_sdk import AsyncSandbox

class XGATool:
    pass

class XGASandBoxTool(XGATool):
    def __init__(self, sandbox: AsyncSandbox):
        pass