"""Exception module for clickpy."""


class ClickStrategyNotFound(Exception):
    """Click Strategy Not Found Exception."""
