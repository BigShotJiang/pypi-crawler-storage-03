"""Clickpy, Automated mouse clicking script."""  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    from clickpy import cli  # pragma: no cover

    cli()  # pragma: no cover
