# Changelog 0.1.x

## 0.1.1

### Enhancements
- Adding `--version` option to the main command.

### Bug fixes


### Documentation

## 0.1.2

### Enhancements
- Adding `--raw` option to the `get` command to fetch the raw data of PRs.
- Making time delta at start date to be seven days by default.

### Bug fixes
- Added docstrings to the core functions
- Improved header definition for HTTP requests

### Documentation
