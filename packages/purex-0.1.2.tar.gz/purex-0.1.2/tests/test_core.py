def test_pilot():
    assert 2 + 2 == 4




