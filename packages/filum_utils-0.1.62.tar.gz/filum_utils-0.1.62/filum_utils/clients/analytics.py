from filum_analytics import Client


class AnalyticsClient(Client):
    pass
