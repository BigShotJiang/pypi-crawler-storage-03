from tenacity import retry

from filum_utils.clients.contact_center.common import _RETRY_PARAMS, ContactCenterClient
from filum_utils.clients.contact_center.types import (
    KBDocumentType,
    UpdateDocumentEmbeddingType,
)


class DocumentClient(ContactCenterClient):
    @retry(**_RETRY_PARAMS)
    def get_kb_document(self, organization_id: str, document_id: str) -> KBDocumentType:
        return self._request(
            endpoint=f"/internal/documents/{document_id}",
            method="GET",
            params={"organizationId": organization_id},
        )

    @retry(**_RETRY_PARAMS)
    def update_document_embedding(
        self,
        document_id: str,
        document_embedding: UpdateDocumentEmbeddingType,
    ):
        self._request(
            endpoint=f"/internal/documents/{document_id}/embedding",
            method="PUT",
            data=document_embedding,
        )
