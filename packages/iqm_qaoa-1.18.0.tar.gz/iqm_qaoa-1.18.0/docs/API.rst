API Reference
=============

.. autosummary::
   :toctree: api
   :template: autosummary-module-template.rst
   :recursive:

   iqm.applications
   iqm.qaoa
