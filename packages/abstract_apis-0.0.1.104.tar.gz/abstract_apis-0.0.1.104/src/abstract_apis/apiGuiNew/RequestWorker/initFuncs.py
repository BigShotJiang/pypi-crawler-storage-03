from .functions import *
def initFuncs(self):
    self.run = run
    return self
