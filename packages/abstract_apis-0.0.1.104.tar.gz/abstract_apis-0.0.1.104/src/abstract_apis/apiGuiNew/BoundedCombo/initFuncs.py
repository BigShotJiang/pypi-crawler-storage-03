from .functions import *
def initFuncs(self):
    self.showPopup = showPopup
    return self
