from __future__ import annotations

from .plugin import aggregate_step  # re-export for convenience

__all__ = ["aggregate_step"]
