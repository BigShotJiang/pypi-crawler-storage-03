Library Reference
=================

Here, you will find documentation to use HADDOCK3 as a library.

.. toctree::
   :maxdepth: 1

   core/haddock.core
   libs/haddock.libs
   gear/haddock.gear
