.. include:: ../CITING.md
   :parser: myst_parser.sphinx_
