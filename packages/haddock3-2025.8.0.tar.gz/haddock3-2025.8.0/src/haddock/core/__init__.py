"""
Core haddock3 functionalities.
"""
