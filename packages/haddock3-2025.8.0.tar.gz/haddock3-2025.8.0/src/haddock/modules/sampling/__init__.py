"""HADDOCK3 modules for sampling."""
