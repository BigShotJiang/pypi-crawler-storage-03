It is possible to list specific resource types we want to return.

We can pick any from the following and need to return a list of all the resource types to select:
- metric
- semantic_model
- saved_query
- source
- analysis
- model
- test
- unit_test
- exposure
- snapshot
- seed
- default
- all