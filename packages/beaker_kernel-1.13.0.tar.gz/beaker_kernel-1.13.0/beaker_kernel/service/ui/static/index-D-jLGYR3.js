const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["static/NotebookInterface-BDviEYox.js","static/DebugPanel.vue_vue_type_style_index_0_lang-PW_f_WLw.js","static/primevue-1TEWPnDt.js","static/xlsx-Ck9ILNdx.js","static/jupyterlab-C2EV-Dpr.js","static/_plugin-vue_export-helper-DlAUqK2U.js","static/codemirror-C5EHd1r4.js","static/DebugPanel-BrLfw-dN.css","static/BeakerQueryCell.vue_vue_type_style_index_0_lang-Dt4dB8m3.js","static/BeakerRawCell.vue_vue_type_style_index_0_lang-DHQ28atJ.js","static/BeakerRawCell-C4ZSMvXS.css","static/BeakerQueryCell-Dg7h5BeK.css","static/MediaPanel.vue_vue_type_style_index_0_lang-BO_XdLt2.js","static/MediaPanel-NTE3VWLY.css","static/IntegrationPanel.vue_vue_type_style_index_0_lang-Dl0CwqlQ.js","static/pdfjs-4lX-eNFD.js","static/IntegrationPanel-GXUxQBXZ.css","static/NotebookInterface-GIpFFiWa.css","static/ChatInterface-DJ-tWjtz.js","static/NotebookSvg-DhCzyRVi.js","static/ChatInterface-DtYgH3Y3.css","static/IntegrationsInterface-DtpeHKTq.js","static/IntegrationsInterface-MKHT9xLN.css","static/DevInterface-Cfhv43bV.js","static/DevInterface-D1b-rrZT.css","static/BeakerAdmin-DWysRvrn.js","static/BeakerAdmin-CmINXWMq.css","static/PlaygroundInterface-DuhU8nir.js","static/PlaygroundInterface-Cm4O1Ahs.css"])))=>i.map(i=>d[i]);
import { e as Or, r as xo, m as _r, w as Ir, a as Dr, b as ar, s as Wr, d as Bo, u as X, c as Tr, i as Y, f as T, h as cr, p as go, g as Lr, n as Ar, j as Hr, o as Mr, t as Fr, k as jr, l as Nr, q as w, v as Vr, P as Xr, T as Yr, C as Gr, D as qr, x as Kr, F as Ur } from "./primevue-1TEWPnDt.js";
import { _ as N, l as ir } from "./jupyterlab-C2EV-Dpr.js";
let tn, Kf, qf, Xf, Yf, Vf, Gf, Uf;
let __tla = (async ()=>{
    (function() {
        const r = document.createElement("link").relList;
        if (r && r.supports && r.supports("modulepreload")) return;
        for (const t of document.querySelectorAll('link[rel="modulepreload"]'))n(t);
        new MutationObserver((t)=>{
            for (const a of t)if (a.type === "childList") for (const s of a.addedNodes)s.tagName === "LINK" && s.rel === "modulepreload" && n(s);
        }).observe(document, {
            childList: !0,
            subtree: !0
        });
        function e(t) {
            const a = {};
            return t.integrity && (a.integrity = t.integrity), t.referrerPolicy && (a.referrerPolicy = t.referrerPolicy), t.crossOrigin === "use-credentials" ? a.credentials = "include" : t.crossOrigin === "anonymous" ? a.credentials = "omit" : a.credentials = "same-origin", a;
        }
        function n(t) {
            if (t.ep) return;
            t.ep = !0;
            const a = e(t);
            fetch(t.href, a);
        }
    })();
    const Qr = Symbol();
    var Wo;
    (function(o) {
        o.direct = "direct", o.patchObject = "patch object", o.patchFunction = "patch function";
    })(Wo || (Wo = {}));
    function Jr() {
        const o = Or(!0), r = o.run(()=>xo({}));
        let e = [], n = [];
        const t = _r({
            install (a) {
                t._a = a, a.provide(Qr, t), a.config.globalProperties.$pinia = t, n.forEach((s)=>e.push(s)), n = [];
            },
            use (a) {
                return this._a ? e.push(a) : n.push(a), this;
            },
            _p: e,
            _a: null,
            _e: o,
            _s: new Map,
            state: r
        });
        return t;
    }
    const po = Symbol("_v_keybinding"), To = [
        "passive",
        "once",
        "capture"
    ], Zr = (o)=>{
        let r = o.target;
        const e = o.target.ownerDocument.documentElement, n = [
            "INPUT",
            "TEXTAREA",
            "SELECT"
        ], t = [
            "textbox",
            "searchbox"
        ];
        for(; r !== null && r !== e;){
            if (n.includes(r.tagName)) return !0;
            const a = r.getAttribute("contenteditable");
            if (a?.toLowerCase() === "true" || a === "") return !0;
            if (r.hasAttribute("tabindex") && r.hasAttribute("role")) {
                const s = r.getAttribute("role");
                if (s && t.includes(s)) return !0;
            }
            r = r.parentElement;
        }
        return !1;
    }, dr = (o)=>o.classList.contains("beaker-cell"), oe = (o)=>{
        let r = o.target;
        const e = o.target.ownerDocument.documentElement;
        for(; r !== null && r !== e;){
            if (dr(r)) return !0;
            r = r.parentElement;
        }
        return !1;
    }, re = (o)=>{
        let r = o.target;
        const e = o.target.ownerDocument.documentElement;
        for(; r !== null && r !== e;){
            if (dr(r) && r.classList.contains("selected")) return !0;
            r = r.parentElement;
        }
        return !1;
    }, lr = {
        "in-editor": Zr,
        "in-cell": oe,
        selected: re
    };
    function ee(o, r) {
        return (e, ...n)=>{
            for (let t of r){
                let a = !1;
                t.startsWith("!") && (a = !0, t = t.slice(1));
                const s = lr[t];
                if (s === void 0) continue;
                const f = s(e);
                if (a ? f : !f) return;
            }
            return o(e);
        };
    }
    const sr = {
        parseEventDefinitions (o) {
            return Object.entries(o.value).map(([e, n])=>{
                const [t, a, ...s] = e.toLowerCase().split("."), f = s.filter((i)=>Object.keys(lr).some((u)=>RegExp(`!?${u}`, "i").test(i))), c = s.filter((i)=>!To.includes(i)), g = s.filter((i)=>To.includes(i));
                (t === void 0 || a === void 0 || t === "" || a === "") && console.warn(`Keybinding definition '${e}' cannot be parsed. Please ensure it is in the format of '{eventtype}.{key}(.{modifier})*'`);
                let p = n;
                c.length && (p = Ir(p, c)), p = Dr(p, [
                    a
                ]), f.length && (p = ee(p, f));
                const l = g.reduce((i, u)=>(i[u] = !0, i), {});
                return {
                    eventType: t,
                    eventOptions: l,
                    callback: p
                };
            });
        },
        beforeMount (o, r, e) {
            const n = sr.parseEventDefinitions(r), t = r.modifiers.top === !0 ? window : o;
            o[po] = {
                targetEl: t,
                eventListeners: n
            }, n.forEach((a)=>{
                const { eventType: s, eventOptions: f, callback: c } = a;
                t.addEventListener(s, c, f);
            });
        },
        unmounted (o, r, e) {
            const { targetEl: n, eventListeners: t } = o[po];
            t.forEach((a)=>{
                const { eventType: s, eventOptions: f, callback: c } = a;
                n.removeEventListener(s, c, f);
            }), delete o[po];
        }
    }, Lo = (o)=>o.scrollTop + o.clientHeight >= o.scrollHeight || o.scrollTop == 0 && o.clientHeight >= o.scrollHeight, to = Symbol("_v_autoscroll"), ne = {
        mounted (o) {
            o[to] = {
                observer: null,
                scrollHandler: null,
                wasFlush: !0
            };
            const r = o[to], e = ()=>{
                const a = Lo(o);
                r.wasFlush = a;
            };
            o.addEventListener("scroll", e);
            const n = ()=>{
                r.wasFlush && !Lo(o) && o.scrollTo({
                    left: 0,
                    top: o.scrollHeight,
                    behavior: "instant"
                });
            }, t = new MutationObserver(n);
            t.observe(o, {
                attributes: !0,
                childList: !0,
                subtree: !0
            }), r.observer = t, r.scrollHandler = e;
        },
        unmounted (o) {
            const r = o[to];
            r.observer.disconnect(), o.removeEventListener("scroll", r.scrollHandler), delete r.observer, delete o[to];
        }
    }, mo = {
        name: "beaker-default",
        defaultMode: "light",
        saveTheme: !1
    }, te = {
        install (o, r) {
            r === void 0 ? r = mo : r = {
                ...mo,
                ...r
            };
            const e = localStorage.getItem("theme");
            if (e !== null) try {
                const f = JSON.parse(e);
                r = {
                    ...r,
                    ...f
                };
            } catch (f) {
                console.error("Error when trying to parse saved them json string.", f), r = {
                    ...mo
                }, localStorage.setItem("theme", JSON.stringify(r));
            }
            r.mode = localStorage.getItem("theme-lightmode") || r.defaultMode || "light", r = ar(r);
            const n = ()=>{
                const f = document.documentElement;
                r.mode === "light" || r.mode === "default" ? f.classList.remove("beaker-dark") : f.classList.add("beaker-dark");
            }, t = ()=>{
                r.mode = r.mode === "light" ? "dark" : "light", r.saveTheme && localStorage.setItem("theme", JSON.stringify(r)), localStorage.setItem("theme-lightmode", r.mode), n();
            }, a = (f, c)=>{
                r.name = f, r.mode = c, r.saveTheme && localStorage.setItem("theme", JSON.stringify(r)), localStorage.setItem("theme-lightmode", r.mode), n();
            }, s = (f)=>{
                r.mode = f || r.defaultMode, r.saveTheme && localStorage.setItem("theme", JSON.stringify(r)), localStorage.setItem("theme-lightmode", r.mode), n();
            };
            o.config.globalProperties.$beakerTheme = {
                theme: r,
                setTheme: a,
                toggleDarkMode: t,
                setDarkMode: s
            }, o.provide("theme", o.config.globalProperties.$beakerTheme), n();
        }
    };
    function ae(o) {
        return o?.charAt(0).toUpperCase() + o.slice(1) || o;
    }
    Vf = function() {
        const o = new Date, r = o.getTimezoneOffset() * 60 * 1e3, e = Number(o) - r;
        let t = new Date(e).toISOString();
        return t = t.split(".")[0], t = t.replace(/[:T]/g, "_"), t;
    };
    Xf = function(o, r, e) {
        const n = new Blob([
            o
        ], {
            type: e
        }), t = window.navigator;
        if (t.msSaveOrOpenBlob) t.msSaveBlob(n, r);
        else {
            const a = window.document.createElement("a");
            a.href = window.URL.createObjectURL(n), a.download = r, document.body.appendChild(a), a.click(), document.body.removeChild(a);
        }
    };
    const ce = (o)=>{
        if (typeof o.getAttribute("tabindex") == "string") return !0;
    };
    Yf = function(o) {
        for(; o != null && o !== document.body;){
            if (ce(o)) return o;
            o = o.parentElement;
        }
    };
    Gf = function(o) {
        return Object.hasOwn(o, "ename") && Object.hasOwn(o, "evalue");
    };
    function ur(o) {
        return Object.hasOwn(o, "view") && Object.hasOwn(o.view, "viewState") ? o.view : o && o.$el ? o.$el : o;
    }
    function fr(o) {
        return Object.hasOwn(o, "viewState") && Object.hasOwn(o, "dom") && Object.hasOwn(o, "docView");
    }
    function gr(o) {
        return o && o.type === "textarea";
    }
    qf = function(o) {
        const r = ur(o);
        return fr(r) ? r.state.selection.main.to === 0 : gr(r) ? r.selectionEnd === 0 : !1;
    };
    Kf = function(o) {
        const r = ur(o);
        return fr(r) ? r.state.selection.main.from === r.state.doc.length : gr(r) ? r.selectionStart === r.textLength : !1;
    };
    const ie = {
        install (o, r) {
            r || (r = globalThis.beaker_app || {});
            const e = r.templateStrings || {}, n = r.assets || {}, t = xo(null), a = (i, u)=>{
                if (t.value) {
                    const R = r.pages?.[t.value]?.template_strings?.[i];
                    if (R) return R;
                }
                return i in e ? e[i] : u || "";
            };
            function s(i) {
                return i in e;
            }
            function f(i) {
                return i in n;
            }
            function c(i) {
                if (i in n) return n[i];
            }
            o.config.globalProperties.$tmpl = {
                _: a,
                getAsset: c,
                hasAsset: f,
                hasTemplateValue: s
            };
            const g = (i)=>{
                t.value = i, l(i);
                const u = r?.stylesheet, v = r?.pages?.[i]?.stylesheet;
                u && p(u, "beakerapp-global"), v && p(v, "beakerapp-page");
            }, p = (i, u)=>{
                if (typeof i == "string") {
                    const v = document.getElementById(u) || document.createElement("link");
                    v.setAttribute("href", i), v.setAttribute("rel", "stylesheet"), v.setAttribute("id", u), document.head.appendChild(v);
                }
            }, l = (i)=>{
                const u = r?.pages?.[i];
                u?.title ? document.title = u.title : document.title === "" && (document.title = `Beaker ${ae(i)}`);
            };
            o.config.globalProperties.$beakerAppConfig = {
                config: r,
                setPageTitle: l,
                setPage: g,
                currentPage: t
            }, o.provide("beakerAppConfig", o.config.globalProperties.$beakerAppConfig);
        }
    };
    const V = typeof document < "u";
    function pr(o) {
        return typeof o == "object" || "displayName" in o || "props" in o || "__vccOpts" in o;
    }
    function de(o) {
        return o.__esModule || o[Symbol.toStringTag] === "Module" || o.default && pr(o.default);
    }
    const x = Object.assign;
    function bo(o, r) {
        const e = {};
        for(const n in r){
            const t = r[n];
            e[n] = W(t) ? t.map(o) : o(t);
        }
        return e;
    }
    const J = ()=>{}, W = Array.isArray, mr = /#/g, le = /&/g, se = /\//g, ue = /=/g, fe = /\?/g, br = /\+/g, ge = /%5B/g, pe = /%5D/g, hr = /%5E/g, me = /%60/g, vr = /%7B/g, be = /%7C/g, kr = /%7D/g, he = /%20/g;
    function $o(o) {
        return encodeURI("" + o).replace(be, "|").replace(ge, "[").replace(pe, "]");
    }
    function ve(o) {
        return $o(o).replace(vr, "{").replace(kr, "}").replace(hr, "^");
    }
    function ko(o) {
        return $o(o).replace(br, "%2B").replace(he, "+").replace(mr, "%23").replace(le, "%26").replace(me, "`").replace(vr, "{").replace(kr, "}").replace(hr, "^");
    }
    function ke(o) {
        return ko(o).replace(ue, "%3D");
    }
    function ye(o) {
        return $o(o).replace(mr, "%23").replace(fe, "%3F");
    }
    function Ce(o) {
        return o == null ? "" : ye(o).replace(se, "%2F");
    }
    function oo(o) {
        try {
            return decodeURIComponent("" + o);
        } catch  {}
        return "" + o;
    }
    const we = /\/$/, xe = (o)=>o.replace(we, "");
    function ho(o, r, e = "/") {
        let n, t = {}, a = "", s = "";
        const f = r.indexOf("#");
        let c = r.indexOf("?");
        return f < c && f >= 0 && (c = -1), c > -1 && (n = r.slice(0, c), a = r.slice(c + 1, f > -1 ? f : r.length), t = o(a)), f > -1 && (n = n || r.slice(0, f), s = r.slice(f, r.length)), n = Se(n ?? r, e), {
            fullPath: n + (a && "?") + a + s,
            path: n,
            query: t,
            hash: oo(s)
        };
    }
    function Be(o, r) {
        const e = r.query ? o(r.query) : "";
        return r.path + (e && "?") + e + (r.hash || "");
    }
    function Ao(o, r) {
        return !r || !o.toLowerCase().startsWith(r.toLowerCase()) ? o : o.slice(r.length) || "/";
    }
    function $e(o, r, e) {
        const n = r.matched.length - 1, t = e.matched.length - 1;
        return n > -1 && n === t && G(r.matched[n], e.matched[t]) && yr(r.params, e.params) && o(r.query) === o(e.query) && r.hash === e.hash;
    }
    function G(o, r) {
        return (o.aliasOf || o) === (r.aliasOf || r);
    }
    function yr(o, r) {
        if (Object.keys(o).length !== Object.keys(r).length) return !1;
        for(const e in o)if (!Re(o[e], r[e])) return !1;
        return !0;
    }
    function Re(o, r) {
        return W(o) ? Ho(o, r) : W(r) ? Ho(r, o) : o === r;
    }
    function Ho(o, r) {
        return W(r) ? o.length === r.length && o.every((e, n)=>e === r[n]) : o.length === 1 && o[0] === r;
    }
    function Se(o, r) {
        if (o.startsWith("/")) return o;
        if (!o) return r;
        const e = r.split("/"), n = o.split("/"), t = n[n.length - 1];
        (t === ".." || t === ".") && n.push("");
        let a = e.length - 1, s, f;
        for(s = 0; s < n.length; s++)if (f = n[s], f !== ".") if (f === "..") a > 1 && a--;
        else break;
        return e.slice(0, a).join("/") + "/" + n.slice(s).join("/");
    }
    const H = {
        path: "/",
        name: void 0,
        params: {},
        query: {},
        hash: "",
        fullPath: "/",
        matched: [],
        meta: {},
        redirectedFrom: void 0
    };
    var ro;
    (function(o) {
        o.pop = "pop", o.push = "push";
    })(ro || (ro = {}));
    var Z;
    (function(o) {
        o.back = "back", o.forward = "forward", o.unknown = "";
    })(Z || (Z = {}));
    function ze(o) {
        if (!o) if (V) {
            const r = document.querySelector("base");
            o = r && r.getAttribute("href") || "/", o = o.replace(/^\w+:\/\/[^\/]+/, "");
        } else o = "/";
        return o[0] !== "/" && o[0] !== "#" && (o = "/" + o), xe(o);
    }
    const Ee = /^[^#]+#/;
    function Pe(o, r) {
        return o.replace(Ee, "#") + r;
    }
    function Oe(o, r) {
        const e = document.documentElement.getBoundingClientRect(), n = o.getBoundingClientRect();
        return {
            behavior: r.behavior,
            left: n.left - e.left - (r.left || 0),
            top: n.top - e.top - (r.top || 0)
        };
    }
    const ao = ()=>({
            left: window.scrollX,
            top: window.scrollY
        });
    function _e(o) {
        let r;
        if ("el" in o) {
            const e = o.el, n = typeof e == "string" && e.startsWith("#"), t = typeof e == "string" ? n ? document.getElementById(e.slice(1)) : document.querySelector(e) : e;
            if (!t) return;
            r = Oe(t, o);
        } else r = o;
        "scrollBehavior" in document.documentElement.style ? window.scrollTo(r) : window.scrollTo(r.left != null ? r.left : window.scrollX, r.top != null ? r.top : window.scrollY);
    }
    function Mo(o, r) {
        return (history.state ? history.state.position - r : -1) + o;
    }
    const yo = new Map;
    function Ie(o, r) {
        yo.set(o, r);
    }
    function De(o) {
        const r = yo.get(o);
        return yo.delete(o), r;
    }
    let We = ()=>location.protocol + "//" + location.host;
    function Cr(o, r) {
        const { pathname: e, search: n, hash: t } = r, a = o.indexOf("#");
        if (a > -1) {
            let f = t.includes(o.slice(a)) ? o.slice(a).length : 1, c = t.slice(f);
            return c[0] !== "/" && (c = "/" + c), Ao(c, "");
        }
        return Ao(e, o) + n + t;
    }
    function Te(o, r, e, n) {
        let t = [], a = [], s = null;
        const f = ({ state: i })=>{
            const u = Cr(o, location), v = e.value, B = r.value;
            let R = 0;
            if (i) {
                if (e.value = u, r.value = i, s && s === v) {
                    s = null;
                    return;
                }
                R = B ? i.position - B.position : 0;
            } else n(u);
            t.forEach((z)=>{
                z(e.value, v, {
                    delta: R,
                    type: ro.pop,
                    direction: R ? R > 0 ? Z.forward : Z.back : Z.unknown
                });
            });
        };
        function c() {
            s = e.value;
        }
        function g(i) {
            t.push(i);
            const u = ()=>{
                const v = t.indexOf(i);
                v > -1 && t.splice(v, 1);
            };
            return a.push(u), u;
        }
        function p() {
            const { history: i } = window;
            i.state && i.replaceState(x({}, i.state, {
                scroll: ao()
            }), "");
        }
        function l() {
            for (const i of a)i();
            a = [], window.removeEventListener("popstate", f), window.removeEventListener("beforeunload", p);
        }
        return window.addEventListener("popstate", f), window.addEventListener("beforeunload", p, {
            passive: !0
        }), {
            pauseListeners: c,
            listen: g,
            destroy: l
        };
    }
    function Fo(o, r, e, n = !1, t = !1) {
        return {
            back: o,
            current: r,
            forward: e,
            replaced: n,
            position: window.history.length,
            scroll: t ? ao() : null
        };
    }
    function Le(o) {
        const { history: r, location: e } = window, n = {
            value: Cr(o, e)
        }, t = {
            value: r.state
        };
        t.value || a(n.value, {
            back: null,
            current: n.value,
            forward: null,
            position: r.length - 1,
            replaced: !0,
            scroll: null
        }, !0);
        function a(c, g, p) {
            const l = o.indexOf("#"), i = l > -1 ? (e.host && document.querySelector("base") ? o : o.slice(l)) + c : We() + o + c;
            try {
                r[p ? "replaceState" : "pushState"](g, "", i), t.value = g;
            } catch (u) {
                console.error(u), e[p ? "replace" : "assign"](i);
            }
        }
        function s(c, g) {
            const p = x({}, r.state, Fo(t.value.back, c, t.value.forward, !0), g, {
                position: t.value.position
            });
            a(c, p, !0), n.value = c;
        }
        function f(c, g) {
            const p = x({}, t.value, r.state, {
                forward: c,
                scroll: ao()
            });
            a(p.current, p, !0);
            const l = x({}, Fo(n.value, c, null), {
                position: p.position + 1
            }, g);
            a(c, l, !1), n.value = c;
        }
        return {
            location: n,
            state: t,
            push: f,
            replace: s
        };
    }
    function Ae(o) {
        o = ze(o);
        const r = Le(o), e = Te(o, r.state, r.location, r.replace);
        function n(a, s = !0) {
            s || e.pauseListeners(), history.go(a);
        }
        const t = x({
            location: "",
            base: o,
            go: n,
            createHref: Pe.bind(null, o)
        }, r, e);
        return Object.defineProperty(t, "location", {
            enumerable: !0,
            get: ()=>r.location.value
        }), Object.defineProperty(t, "state", {
            enumerable: !0,
            get: ()=>r.state.value
        }), t;
    }
    function He(o) {
        return typeof o == "string" || o && typeof o == "object";
    }
    function wr(o) {
        return typeof o == "string" || typeof o == "symbol";
    }
    const xr = Symbol("");
    var jo;
    (function(o) {
        o[o.aborted = 4] = "aborted", o[o.cancelled = 8] = "cancelled", o[o.duplicated = 16] = "duplicated";
    })(jo || (jo = {}));
    function q(o, r) {
        return x(new Error, {
            type: o,
            [xr]: !0
        }, r);
    }
    function L(o, r) {
        return o instanceof Error && xr in o && (r == null || !!(o.type & r));
    }
    const No = "[^/]+?", Me = {
        sensitive: !1,
        strict: !1,
        start: !0,
        end: !0
    }, Fe = /[.+*?^${}()[\]/\\]/g;
    function je(o, r) {
        const e = x({}, Me, r), n = [];
        let t = e.start ? "^" : "";
        const a = [];
        for (const g of o){
            const p = g.length ? [] : [
                90
            ];
            e.strict && !g.length && (t += "/");
            for(let l = 0; l < g.length; l++){
                const i = g[l];
                let u = 40 + (e.sensitive ? .25 : 0);
                if (i.type === 0) l || (t += "/"), t += i.value.replace(Fe, "\\$&"), u += 40;
                else if (i.type === 1) {
                    const { value: v, repeatable: B, optional: R, regexp: z } = i;
                    a.push({
                        name: v,
                        repeatable: B,
                        optional: R
                    });
                    const C = z || No;
                    if (C !== No) {
                        u += 10;
                        try {
                            new RegExp(`(${C})`);
                        } catch (D) {
                            throw new Error(`Invalid custom RegExp for param "${v}" (${C}): ` + D.message);
                        }
                    }
                    let $ = B ? `((?:${C})(?:/(?:${C}))*)` : `(${C})`;
                    l || ($ = R && g.length < 2 ? `(?:/${$})` : "/" + $), R && ($ += "?"), t += $, u += 20, R && (u += -8), B && (u += -20), C === ".*" && (u += -50);
                }
                p.push(u);
            }
            n.push(p);
        }
        if (e.strict && e.end) {
            const g = n.length - 1;
            n[g][n[g].length - 1] += .7000000000000001;
        }
        e.strict || (t += "/?"), e.end ? t += "$" : e.strict && !t.endsWith("/") && (t += "(?:/|$)");
        const s = new RegExp(t, e.sensitive ? "" : "i");
        function f(g) {
            const p = g.match(s), l = {};
            if (!p) return null;
            for(let i = 1; i < p.length; i++){
                const u = p[i] || "", v = a[i - 1];
                l[v.name] = u && v.repeatable ? u.split("/") : u;
            }
            return l;
        }
        function c(g) {
            let p = "", l = !1;
            for (const i of o){
                (!l || !p.endsWith("/")) && (p += "/"), l = !1;
                for (const u of i)if (u.type === 0) p += u.value;
                else if (u.type === 1) {
                    const { value: v, repeatable: B, optional: R } = u, z = v in g ? g[v] : "";
                    if (W(z) && !B) throw new Error(`Provided param "${v}" is an array but it is not repeatable (* or + modifiers)`);
                    const C = W(z) ? z.join("/") : z;
                    if (!C) if (R) i.length < 2 && (p.endsWith("/") ? p = p.slice(0, -1) : l = !0);
                    else throw new Error(`Missing required param "${v}"`);
                    p += C;
                }
            }
            return p || "/";
        }
        return {
            re: s,
            score: n,
            keys: a,
            parse: f,
            stringify: c
        };
    }
    function Ne(o, r) {
        let e = 0;
        for(; e < o.length && e < r.length;){
            const n = r[e] - o[e];
            if (n) return n;
            e++;
        }
        return o.length < r.length ? o.length === 1 && o[0] === 80 ? -1 : 1 : o.length > r.length ? r.length === 1 && r[0] === 80 ? 1 : -1 : 0;
    }
    function Br(o, r) {
        let e = 0;
        const n = o.score, t = r.score;
        for(; e < n.length && e < t.length;){
            const a = Ne(n[e], t[e]);
            if (a) return a;
            e++;
        }
        if (Math.abs(t.length - n.length) === 1) {
            if (Vo(n)) return 1;
            if (Vo(t)) return -1;
        }
        return t.length - n.length;
    }
    function Vo(o) {
        const r = o[o.length - 1];
        return o.length > 0 && r[r.length - 1] < 0;
    }
    const Ve = {
        type: 0,
        value: ""
    }, Xe = /[a-zA-Z0-9_]/;
    function Ye(o) {
        if (!o) return [
            []
        ];
        if (o === "/") return [
            [
                Ve
            ]
        ];
        if (!o.startsWith("/")) throw new Error(`Invalid path "${o}"`);
        function r(u) {
            throw new Error(`ERR (${e})/"${g}": ${u}`);
        }
        let e = 0, n = e;
        const t = [];
        let a;
        function s() {
            a && t.push(a), a = [];
        }
        let f = 0, c, g = "", p = "";
        function l() {
            g && (e === 0 ? a.push({
                type: 0,
                value: g
            }) : e === 1 || e === 2 || e === 3 ? (a.length > 1 && (c === "*" || c === "+") && r(`A repeatable param (${g}) must be alone in its segment. eg: '/:ids+.`), a.push({
                type: 1,
                value: g,
                regexp: p,
                repeatable: c === "*" || c === "+",
                optional: c === "*" || c === "?"
            })) : r("Invalid state to consume buffer"), g = "");
        }
        function i() {
            g += c;
        }
        for(; f < o.length;){
            if (c = o[f++], c === "\\" && e !== 2) {
                n = e, e = 4;
                continue;
            }
            switch(e){
                case 0:
                    c === "/" ? (g && l(), s()) : c === ":" ? (l(), e = 1) : i();
                    break;
                case 4:
                    i(), e = n;
                    break;
                case 1:
                    c === "(" ? e = 2 : Xe.test(c) ? i() : (l(), e = 0, c !== "*" && c !== "?" && c !== "+" && f--);
                    break;
                case 2:
                    c === ")" ? p[p.length - 1] == "\\" ? p = p.slice(0, -1) + c : e = 3 : p += c;
                    break;
                case 3:
                    l(), e = 0, c !== "*" && c !== "?" && c !== "+" && f--, p = "";
                    break;
                default:
                    r("Unknown state");
                    break;
            }
        }
        return e === 2 && r(`Unfinished custom RegExp for param "${g}"`), l(), s(), t;
    }
    function Ge(o, r, e) {
        const n = je(Ye(o.path), e), t = x(n, {
            record: o,
            parent: r,
            children: [],
            alias: []
        });
        return r && !t.record.aliasOf == !r.record.aliasOf && r.children.push(t), t;
    }
    function qe(o, r) {
        const e = [], n = new Map;
        r = qo({
            strict: !1,
            end: !0,
            sensitive: !1
        }, r);
        function t(l) {
            return n.get(l);
        }
        function a(l, i, u) {
            const v = !u, B = Yo(l);
            B.aliasOf = u && u.record;
            const R = qo(r, l), z = [
                B
            ];
            if ("alias" in l) {
                const D = typeof l.alias == "string" ? [
                    l.alias
                ] : l.alias;
                for (const F of D)z.push(Yo(x({}, B, {
                    components: u ? u.record.components : B.components,
                    path: F,
                    aliasOf: u ? u.record : B
                })));
            }
            let C, $;
            for (const D of z){
                const { path: F } = D;
                if (i && F[0] !== "/") {
                    const A = i.record.path, I = A[A.length - 1] === "/" ? "" : "/";
                    D.path = i.record.path + (F && I + F);
                }
                if (C = Ge(D, i, R), u ? u.alias.push(C) : ($ = $ || C, $ !== C && $.alias.push(C), v && l.name && !Go(C) && s(l.name)), $r(C) && c(C), B.children) {
                    const A = B.children;
                    for(let I = 0; I < A.length; I++)a(A[I], C, u && u.children[I]);
                }
                u = u || C;
            }
            return $ ? ()=>{
                s($);
            } : J;
        }
        function s(l) {
            if (wr(l)) {
                const i = n.get(l);
                i && (n.delete(l), e.splice(e.indexOf(i), 1), i.children.forEach(s), i.alias.forEach(s));
            } else {
                const i = e.indexOf(l);
                i > -1 && (e.splice(i, 1), l.record.name && n.delete(l.record.name), l.children.forEach(s), l.alias.forEach(s));
            }
        }
        function f() {
            return e;
        }
        function c(l) {
            const i = Qe(l, e);
            e.splice(i, 0, l), l.record.name && !Go(l) && n.set(l.record.name, l);
        }
        function g(l, i) {
            let u, v = {}, B, R;
            if ("name" in l && l.name) {
                if (u = n.get(l.name), !u) throw q(1, {
                    location: l
                });
                R = u.record.name, v = x(Xo(i.params, u.keys.filter(($)=>!$.optional).concat(u.parent ? u.parent.keys.filter(($)=>$.optional) : []).map(($)=>$.name)), l.params && Xo(l.params, u.keys.map(($)=>$.name))), B = u.stringify(v);
            } else if (l.path != null) B = l.path, u = e.find(($)=>$.re.test(B)), u && (v = u.parse(B), R = u.record.name);
            else {
                if (u = i.name ? n.get(i.name) : e.find(($)=>$.re.test(i.path)), !u) throw q(1, {
                    location: l,
                    currentLocation: i
                });
                R = u.record.name, v = x({}, i.params, l.params), B = u.stringify(v);
            }
            const z = [];
            let C = u;
            for(; C;)z.unshift(C.record), C = C.parent;
            return {
                name: R,
                path: B,
                params: v,
                matched: z,
                meta: Ue(z)
            };
        }
        o.forEach((l)=>a(l));
        function p() {
            e.length = 0, n.clear();
        }
        return {
            addRoute: a,
            resolve: g,
            removeRoute: s,
            clearRoutes: p,
            getRoutes: f,
            getRecordMatcher: t
        };
    }
    function Xo(o, r) {
        const e = {};
        for (const n of r)n in o && (e[n] = o[n]);
        return e;
    }
    function Yo(o) {
        const r = {
            path: o.path,
            redirect: o.redirect,
            name: o.name,
            meta: o.meta || {},
            aliasOf: o.aliasOf,
            beforeEnter: o.beforeEnter,
            props: Ke(o),
            children: o.children || [],
            instances: {},
            leaveGuards: new Set,
            updateGuards: new Set,
            enterCallbacks: {},
            components: "components" in o ? o.components || null : o.component && {
                default: o.component
            }
        };
        return Object.defineProperty(r, "mods", {
            value: {}
        }), r;
    }
    function Ke(o) {
        const r = {}, e = o.props || !1;
        if ("component" in o) r.default = e;
        else for(const n in o.components)r[n] = typeof e == "object" ? e[n] : e;
        return r;
    }
    function Go(o) {
        for(; o;){
            if (o.record.aliasOf) return !0;
            o = o.parent;
        }
        return !1;
    }
    function Ue(o) {
        return o.reduce((r, e)=>x(r, e.meta), {});
    }
    function qo(o, r) {
        const e = {};
        for(const n in o)e[n] = n in r ? r[n] : o[n];
        return e;
    }
    function Qe(o, r) {
        let e = 0, n = r.length;
        for(; e !== n;){
            const a = e + n >> 1;
            Br(o, r[a]) < 0 ? n = a : e = a + 1;
        }
        const t = Je(o);
        return t && (n = r.lastIndexOf(t, n - 1)), n;
    }
    function Je(o) {
        let r = o;
        for(; r = r.parent;)if ($r(r) && Br(o, r) === 0) return r;
    }
    function $r({ record: o }) {
        return !!(o.name || o.components && Object.keys(o.components).length || o.redirect);
    }
    function Ze(o) {
        const r = {};
        if (o === "" || o === "?") return r;
        const n = (o[0] === "?" ? o.slice(1) : o).split("&");
        for(let t = 0; t < n.length; ++t){
            const a = n[t].replace(br, " "), s = a.indexOf("="), f = oo(s < 0 ? a : a.slice(0, s)), c = s < 0 ? null : oo(a.slice(s + 1));
            if (f in r) {
                let g = r[f];
                W(g) || (g = r[f] = [
                    g
                ]), g.push(c);
            } else r[f] = c;
        }
        return r;
    }
    function Ko(o) {
        let r = "";
        for(let e in o){
            const n = o[e];
            if (e = ke(e), n == null) {
                n !== void 0 && (r += (r.length ? "&" : "") + e);
                continue;
            }
            (W(n) ? n.map((a)=>a && ko(a)) : [
                n && ko(n)
            ]).forEach((a)=>{
                a !== void 0 && (r += (r.length ? "&" : "") + e, a != null && (r += "=" + a));
            });
        }
        return r;
    }
    function on(o) {
        const r = {};
        for(const e in o){
            const n = o[e];
            n !== void 0 && (r[e] = W(n) ? n.map((t)=>t == null ? null : "" + t) : n == null ? n : "" + n);
        }
        return r;
    }
    const rn = Symbol(""), Uo = Symbol(""), Ro = Symbol(""), So = Symbol(""), Co = Symbol("");
    function Q() {
        let o = [];
        function r(n) {
            return o.push(n), ()=>{
                const t = o.indexOf(n);
                t > -1 && o.splice(t, 1);
            };
        }
        function e() {
            o = [];
        }
        return {
            add: r,
            list: ()=>o.slice(),
            reset: e
        };
    }
    function M(o, r, e, n, t, a = (s)=>s()) {
        const s = n && (n.enterCallbacks[t] = n.enterCallbacks[t] || []);
        return ()=>new Promise((f, c)=>{
                const g = (i)=>{
                    i === !1 ? c(q(4, {
                        from: e,
                        to: r
                    })) : i instanceof Error ? c(i) : He(i) ? c(q(2, {
                        from: r,
                        to: i
                    })) : (s && n.enterCallbacks[t] === s && typeof i == "function" && s.push(i), f());
                }, p = a(()=>o.call(n && n.instances[t], r, e, g));
                let l = Promise.resolve(p);
                o.length < 3 && (l = l.then(g)), l.catch((i)=>c(i));
            });
    }
    function vo(o, r, e, n, t = (a)=>a()) {
        const a = [];
        for (const s of o)for(const f in s.components){
            let c = s.components[f];
            if (!(r !== "beforeRouteEnter" && !s.instances[f])) if (pr(c)) {
                const p = (c.__vccOpts || c)[r];
                p && a.push(M(p, e, n, s, f, t));
            } else {
                let g = c();
                a.push(()=>g.then((p)=>{
                        if (!p) throw new Error(`Couldn't resolve component "${f}" at "${s.path}"`);
                        const l = de(p) ? p.default : p;
                        s.mods[f] = p, s.components[f] = l;
                        const u = (l.__vccOpts || l)[r];
                        return u && M(u, e, n, s, f, t)();
                    }));
            }
        }
        return a;
    }
    function Qo(o) {
        const r = Y(Ro), e = Y(So), n = T(()=>{
            const c = X(o.to);
            return r.resolve(c);
        }), t = T(()=>{
            const { matched: c } = n.value, { length: g } = c, p = c[g - 1], l = e.matched;
            if (!p || !l.length) return -1;
            const i = l.findIndex(G.bind(null, p));
            if (i > -1) return i;
            const u = Jo(c[g - 2]);
            return g > 1 && Jo(p) === u && l[l.length - 1].path !== u ? l.findIndex(G.bind(null, c[g - 2])) : i;
        }), a = T(()=>t.value > -1 && cn(e.params, n.value.params)), s = T(()=>t.value > -1 && t.value === e.matched.length - 1 && yr(e.params, n.value.params));
        function f(c = {}) {
            if (an(c)) {
                const g = r[X(o.replace) ? "replace" : "push"](X(o.to)).catch(J);
                return o.viewTransition && typeof document < "u" && "startViewTransition" in document && document.startViewTransition(()=>g), g;
            }
            return Promise.resolve();
        }
        return {
            route: n,
            href: T(()=>n.value.href),
            isActive: a,
            isExactActive: s,
            navigate: f
        };
    }
    function en(o) {
        return o.length === 1 ? o[0] : o;
    }
    let nn;
    nn = Bo({
        name: "RouterLink",
        compatConfig: {
            MODE: 3
        },
        props: {
            to: {
                type: [
                    String,
                    Object
                ],
                required: !0
            },
            replace: Boolean,
            activeClass: String,
            exactActiveClass: String,
            custom: Boolean,
            ariaCurrentValue: {
                type: String,
                default: "page"
            },
            viewTransition: Boolean
        },
        useLink: Qo,
        setup (o, { slots: r }) {
            const e = ar(Qo(o)), { options: n } = Y(Ro), t = T(()=>({
                    [Zo(o.activeClass, n.linkActiveClass, "router-link-active")]: e.isActive,
                    [Zo(o.exactActiveClass, n.linkExactActiveClass, "router-link-exact-active")]: e.isExactActive
                }));
            return ()=>{
                const a = r.default && en(r.default(e));
                return o.custom ? a : cr("a", {
                    "aria-current": e.isExactActive ? o.ariaCurrentValue : null,
                    href: e.href,
                    onClick: e.navigate,
                    class: t.value
                }, a);
            };
        }
    });
    tn = nn;
    function an(o) {
        if (!(o.metaKey || o.altKey || o.ctrlKey || o.shiftKey) && !o.defaultPrevented && !(o.button !== void 0 && o.button !== 0)) {
            if (o.currentTarget && o.currentTarget.getAttribute) {
                const r = o.currentTarget.getAttribute("target");
                if (/\b_blank\b/i.test(r)) return;
            }
            return o.preventDefault && o.preventDefault(), !0;
        }
    }
    function cn(o, r) {
        for(const e in r){
            const n = r[e], t = o[e];
            if (typeof n == "string") {
                if (n !== t) return !1;
            } else if (!W(t) || t.length !== n.length || n.some((a, s)=>a !== t[s])) return !1;
        }
        return !0;
    }
    function Jo(o) {
        return o ? o.aliasOf ? o.aliasOf.path : o.path : "";
    }
    const Zo = (o, r, e)=>o ?? r ?? e, dn = Bo({
        name: "RouterView",
        inheritAttrs: !1,
        props: {
            name: {
                type: String,
                default: "default"
            },
            route: Object
        },
        compatConfig: {
            MODE: 3
        },
        setup (o, { attrs: r, slots: e }) {
            const n = Y(Co), t = T(()=>o.route || n.value), a = Y(Uo, 0), s = T(()=>{
                let g = X(a);
                const { matched: p } = t.value;
                let l;
                for(; (l = p[g]) && !l.components;)g++;
                return g;
            }), f = T(()=>t.value.matched[s.value]);
            go(Uo, T(()=>s.value + 1)), go(rn, f), go(Co, t);
            const c = xo();
            return Lr(()=>[
                    c.value,
                    f.value,
                    o.name
                ], ([g, p, l], [i, u, v])=>{
                p && (p.instances[l] = g, u && u !== p && g && g === i && (p.leaveGuards.size || (p.leaveGuards = u.leaveGuards), p.updateGuards.size || (p.updateGuards = u.updateGuards))), g && p && (!u || !G(p, u) || !i) && (p.enterCallbacks[l] || []).forEach((B)=>B(g));
            }, {
                flush: "post"
            }), ()=>{
                const g = t.value, p = o.name, l = f.value, i = l && l.components[p];
                if (!i) return or(e.default, {
                    Component: i,
                    route: g
                });
                const u = l.props[p], v = u ? u === !0 ? g.params : typeof u == "function" ? u(g) : u : null, R = cr(i, x({}, v, r, {
                    onVnodeUnmounted: (z)=>{
                        z.component.isUnmounted && (l.instances[p] = null);
                    },
                    ref: c
                }));
                return or(e.default, {
                    Component: R,
                    route: g
                }) || R;
            };
        }
    });
    function or(o, r) {
        if (!o) return null;
        const e = o(r);
        return e.length === 1 ? e[0] : e;
    }
    const Rr = dn;
    function ln(o) {
        const r = qe(o.routes, o), e = o.parseQuery || Ze, n = o.stringifyQuery || Ko, t = o.history, a = Q(), s = Q(), f = Q(), c = Wr(H);
        let g = H;
        V && o.scrollBehavior && "scrollRestoration" in history && (history.scrollRestoration = "manual");
        const p = bo.bind(null, (d)=>"" + d), l = bo.bind(null, Ce), i = bo.bind(null, oo);
        function u(d, b) {
            let m, h;
            return wr(d) ? (m = r.getRecordMatcher(d), h = b) : h = d, r.addRoute(h, m);
        }
        function v(d) {
            const b = r.getRecordMatcher(d);
            b && r.removeRoute(b);
        }
        function B() {
            return r.getRoutes().map((d)=>d.record);
        }
        function R(d) {
            return !!r.getRecordMatcher(d);
        }
        function z(d, b) {
            if (b = x({}, b || c.value), typeof d == "string") {
                const k = ho(e, d, b.path), P = r.resolve({
                    path: k.path
                }, b), U = t.createHref(k.fullPath);
                return x(k, P, {
                    params: i(P.params),
                    hash: oo(k.hash),
                    redirectedFrom: void 0,
                    href: U
                });
            }
            let m;
            if (d.path != null) m = x({}, d, {
                path: ho(e, d.path, b.path).path
            });
            else {
                const k = x({}, d.params);
                for(const P in k)k[P] == null && delete k[P];
                m = x({}, d, {
                    params: l(k)
                }), b.params = l(b.params);
            }
            const h = r.resolve(m, b), S = d.hash || "";
            h.params = p(i(h.params));
            const E = Be(n, x({}, d, {
                hash: ve(S),
                path: h.path
            })), y = t.createHref(E);
            return x({
                fullPath: E,
                hash: S,
                query: n === Ko ? on(d.query) : d.query || {}
            }, h, {
                redirectedFrom: void 0,
                href: y
            });
        }
        function C(d) {
            return typeof d == "string" ? ho(e, d, c.value.path) : x({}, d);
        }
        function $(d, b) {
            if (g !== d) return q(8, {
                from: b,
                to: d
            });
        }
        function D(d) {
            return I(d);
        }
        function F(d) {
            return D(x(C(d), {
                replace: !0
            }));
        }
        function A(d) {
            const b = d.matched[d.matched.length - 1];
            if (b && b.redirect) {
                const { redirect: m } = b;
                let h = typeof m == "function" ? m(d) : m;
                return typeof h == "string" && (h = h.includes("?") || h.includes("#") ? h = C(h) : {
                    path: h
                }, h.params = {}), x({
                    query: d.query,
                    hash: d.hash,
                    params: h.path != null ? {} : d.params
                }, h);
            }
        }
        function I(d, b) {
            const m = g = z(d), h = c.value, S = d.state, E = d.force, y = d.replace === !0, k = A(m);
            if (k) return I(x(C(k), {
                state: typeof k == "object" ? x({}, S, k.state) : S,
                force: E,
                replace: y
            }), b || m);
            const P = m;
            P.redirectedFrom = b;
            let U;
            return !E && $e(n, h, m) && (U = q(16, {
                to: P,
                from: h
            }), Io(h, h, !0, !1)), (U ? Promise.resolve(U) : Eo(P, h)).catch((O)=>L(O) ? L(O, 2) ? O : so(O) : lo(O, P, h)).then((O)=>{
                if (O) {
                    if (L(O, 2)) return I(x({
                        replace: y
                    }, C(O.to), {
                        state: typeof O.to == "object" ? x({}, S, O.to.state) : S,
                        force: E
                    }), b || P);
                } else O = Oo(P, h, !0, y, S);
                return Po(P, h, O), O;
            });
        }
        function zr(d, b) {
            const m = $(d, b);
            return m ? Promise.reject(m) : Promise.resolve();
        }
        function co(d) {
            const b = no.values().next().value;
            return b && typeof b.runWithContext == "function" ? b.runWithContext(d) : d();
        }
        function Eo(d, b) {
            let m;
            const [h, S, E] = sn(d, b);
            m = vo(h.reverse(), "beforeRouteLeave", d, b);
            for (const k of h)k.leaveGuards.forEach((P)=>{
                m.push(M(P, d, b));
            });
            const y = zr.bind(null, d, b);
            return m.push(y), j(m).then(()=>{
                m = [];
                for (const k of a.list())m.push(M(k, d, b));
                return m.push(y), j(m);
            }).then(()=>{
                m = vo(S, "beforeRouteUpdate", d, b);
                for (const k of S)k.updateGuards.forEach((P)=>{
                    m.push(M(P, d, b));
                });
                return m.push(y), j(m);
            }).then(()=>{
                m = [];
                for (const k of E)if (k.beforeEnter) if (W(k.beforeEnter)) for (const P of k.beforeEnter)m.push(M(P, d, b));
                else m.push(M(k.beforeEnter, d, b));
                return m.push(y), j(m);
            }).then(()=>(d.matched.forEach((k)=>k.enterCallbacks = {}), m = vo(E, "beforeRouteEnter", d, b, co), m.push(y), j(m))).then(()=>{
                m = [];
                for (const k of s.list())m.push(M(k, d, b));
                return m.push(y), j(m);
            }).catch((k)=>L(k, 8) ? k : Promise.reject(k));
        }
        function Po(d, b, m) {
            f.list().forEach((h)=>co(()=>h(d, b, m)));
        }
        function Oo(d, b, m, h, S) {
            const E = $(d, b);
            if (E) return E;
            const y = b === H, k = V ? history.state : {};
            m && (h || y ? t.replace(d.fullPath, x({
                scroll: y && k && k.scroll
            }, S)) : t.push(d.fullPath, S)), c.value = d, Io(d, b, m, y), so();
        }
        let K;
        function Er() {
            K || (K = t.listen((d, b, m)=>{
                if (!Do.listening) return;
                const h = z(d), S = A(h);
                if (S) {
                    I(x(S, {
                        replace: !0,
                        force: !0
                    }), h).catch(J);
                    return;
                }
                g = h;
                const E = c.value;
                V && Ie(Mo(E.fullPath, m.delta), ao()), Eo(h, E).catch((y)=>L(y, 12) ? y : L(y, 2) ? (I(x(C(y.to), {
                        force: !0
                    }), h).then((k)=>{
                        L(k, 20) && !m.delta && m.type === ro.pop && t.go(-1, !1);
                    }).catch(J), Promise.reject()) : (m.delta && t.go(-m.delta, !1), lo(y, h, E))).then((y)=>{
                    y = y || Oo(h, E, !1), y && (m.delta && !L(y, 8) ? t.go(-m.delta, !1) : m.type === ro.pop && L(y, 20) && t.go(-1, !1)), Po(h, E, y);
                }).catch(J);
            }));
        }
        let io = Q(), _o = Q(), eo;
        function lo(d, b, m) {
            so(d);
            const h = _o.list();
            return h.length ? h.forEach((S)=>S(d, b, m)) : console.error(d), Promise.reject(d);
        }
        function Pr() {
            return eo && c.value !== H ? Promise.resolve() : new Promise((d, b)=>{
                io.add([
                    d,
                    b
                ]);
            });
        }
        function so(d) {
            return eo || (eo = !d, Er(), io.list().forEach(([b, m])=>d ? m(d) : b()), io.reset()), d;
        }
        function Io(d, b, m, h) {
            const { scrollBehavior: S } = o;
            if (!V || !S) return Promise.resolve();
            const E = !m && De(Mo(d.fullPath, 0)) || (h || !m) && history.state && history.state.scroll || null;
            return Ar().then(()=>S(d, b, E)).then((y)=>y && _e(y)).catch((y)=>lo(y, d, b));
        }
        const uo = (d)=>t.go(d);
        let fo;
        const no = new Set, Do = {
            currentRoute: c,
            listening: !0,
            addRoute: u,
            removeRoute: v,
            clearRoutes: r.clearRoutes,
            hasRoute: R,
            getRoutes: B,
            resolve: z,
            options: o,
            push: D,
            replace: F,
            go: uo,
            back: ()=>uo(-1),
            forward: ()=>uo(1),
            beforeEach: a.add,
            beforeResolve: s.add,
            afterEach: f.add,
            onError: _o.add,
            isReady: Pr,
            install (d) {
                const b = this;
                d.component("RouterLink", tn), d.component("RouterView", Rr), d.config.globalProperties.$router = b, Object.defineProperty(d.config.globalProperties, "$route", {
                    enumerable: !0,
                    get: ()=>X(c)
                }), V && !fo && c.value === H && (fo = !0, D(t.location).catch((S)=>{}));
                const m = {};
                for(const S in H)Object.defineProperty(m, S, {
                    get: ()=>c.value[S],
                    enumerable: !0
                });
                d.provide(Ro, b), d.provide(So, Tr(m)), d.provide(Co, c);
                const h = d.unmount;
                no.add(d), d.unmount = function() {
                    no.delete(d), no.size < 1 && (g = H, K && K(), K = null, c.value = H, fo = !1, eo = !1), h();
                };
            }
        };
        function j(d) {
            return d.reduce((b, m)=>b.then(()=>co(m)), Promise.resolve());
        }
        return Do;
    }
    function sn(o, r) {
        const e = [], n = [], t = [], a = Math.max(r.matched.length, o.matched.length);
        for(let s = 0; s < a; s++){
            const f = r.matched[s];
            f && (o.matched.find((g)=>G(g, f)) ? n.push(f) : e.push(f));
            const c = o.matched[s];
            c && (r.matched.find((g)=>G(g, c)) || t.push(c));
        }
        return [
            e,
            n,
            t
        ];
    }
    Uf = function(o) {
        return Y(So);
    };
    const un = Bo({
        __name: "App",
        props: [
            "config"
        ],
        setup (o) {
            return (r, e)=>(Mr(), Hr(X(Rr), {
                    config: o.config
                }, null, 8, [
                    "config"
                ]));
        }
    }), wo = {
        notebook: {
            path: "/notebook",
            component: ()=>N(()=>import("./NotebookInterface-BDviEYox.js").then(async (m)=>{
                        await m.__tla;
                        return m;
                    }), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17])),
            role: "home"
        },
        chat: {
            path: "/chat",
            component: ()=>N(()=>import("./ChatInterface-DJ-tWjtz.js").then(async (m)=>{
                        await m.__tla;
                        return m;
                    }), __vite__mapDeps([18,2,1,3,4,5,6,7,9,10,12,13,19,14,15,16,20])),
            role: "alt"
        },
        integrations: {
            path: "/integrations",
            component: ()=>N(()=>import("./IntegrationsInterface-DtpeHKTq.js").then(async (m)=>{
                        await m.__tla;
                        return m;
                    }), __vite__mapDeps([21,1,2,3,4,5,6,7,14,15,16,19,22]))
        },
        dev: {
            path: "/dev",
            component: ()=>N(()=>import("./DevInterface-Cfhv43bV.js").then(async (m)=>{
                        await m.__tla;
                        return m;
                    }), __vite__mapDeps([23,1,2,3,4,5,6,7,8,9,10,11,24]))
        },
        admin: {
            path: "/admin",
            component: ()=>N(()=>import("./BeakerAdmin-DWysRvrn.js"), __vite__mapDeps([25,4,2,26]))
        },
        playground: {
            path: "/playground",
            component: ()=>N(()=>import("./PlaygroundInterface-DuhU8nir.js"), __vite__mapDeps([27,2,5,28]))
        }
    }, fn = (o)=>{
        const r = Object.hasOwn(o, "/");
        return Object.entries(o).map(([e, n])=>{
            const t = {
                path: n.path,
                name: e,
                component: n.component,
                meta: {
                    componentPath: n.componentPath,
                    role: n.role
                }
            };
            return !r && n.role === "home" && (t.alias = "/"), t;
        });
    }, gn = (o)=>{
        let r = {};
        return Object.values(o).map((e)=>{
            if (Object.hasOwn(wo, e.slug)) {
                const n = {
                    ...wo[e.slug]
                };
                n.role && (n.role = e.default ? "home" : "alt"), r[e.slug] = n;
            }
        }), r;
    }, pn = (o)=>{
        let r = o?.appConfig?.pages ? gn(o.appConfig.pages) : {
            ...wo
        };
        delete r.playground;
        const e = fn(r);
        return ln({
            history: Ae("/"),
            routes: e
        });
    };
    var mn = {
        transitionDuration: "{transition.duration}"
    }, bn = {
        borderWidth: "0 0 1px 0",
        borderColor: "{content.border.color}"
    }, hn = {
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        activeColor: "{text.color}",
        padding: "1.125rem",
        fontWeight: "600",
        borderRadius: "0",
        borderWidth: "0",
        borderColor: "{content.border.color}",
        background: "{content.background}",
        hoverBackground: "{content.background}",
        activeBackground: "{content.background}",
        activeHoverBackground: "{content.background}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        },
        toggleIcon: {
            color: "{text.muted.color}",
            hoverColor: "{text.color}",
            activeColor: "{text.color}",
            activeHoverColor: "{text.color}"
        },
        first: {
            topBorderRadius: "{content.border.radius}",
            borderWidth: "0"
        },
        last: {
            bottomBorderRadius: "{content.border.radius}",
            activeBottomBorderRadius: "0"
        }
    }, vn = {
        borderWidth: "0",
        borderColor: "{content.border.color}",
        background: "{content.background}",
        color: "{text.color}",
        padding: "0 1.125rem 1.125rem 1.125rem"
    }, kn = {
        root: mn,
        panel: bn,
        header: hn,
        content: vn
    }, yn = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}"
    }, Cn = {
        background: "{overlay.select.background}",
        borderColor: "{overlay.select.border.color}",
        borderRadius: "{overlay.select.border.radius}",
        color: "{overlay.select.color}",
        shadow: "{overlay.select.shadow}"
    }, wn = {
        padding: "{list.padding}",
        gap: "{list.gap}"
    }, xn = {
        focusBackground: "{list.option.focus.background}",
        selectedBackground: "{list.option.selected.background}",
        selectedFocusBackground: "{list.option.selected.focus.background}",
        color: "{list.option.color}",
        focusColor: "{list.option.focus.color}",
        selectedColor: "{list.option.selected.color}",
        selectedFocusColor: "{list.option.selected.focus.color}",
        padding: "{list.option.padding}",
        borderRadius: "{list.option.border.radius}"
    }, Bn = {
        background: "{list.option.group.background}",
        color: "{list.option.group.color}",
        fontWeight: "{list.option.group.font.weight}",
        padding: "{list.option.group.padding}"
    }, $n = {
        width: "2.5rem",
        sm: {
            width: "2rem"
        },
        lg: {
            width: "3rem"
        },
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.border.color}",
        activeBorderColor: "{form.field.border.color}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Rn = {
        borderRadius: "{border.radius.sm}"
    }, Sn = {
        padding: "{list.option.padding}"
    }, zn = {
        light: {
            chip: {
                focusBackground: "{surface.200}",
                focusColor: "{surface.800}"
            },
            dropdown: {
                background: "{surface.100}",
                hoverBackground: "{surface.200}",
                activeBackground: "{surface.300}",
                color: "{surface.600}",
                hoverColor: "{surface.700}",
                activeColor: "{surface.800}"
            }
        },
        dark: {
            chip: {
                focusBackground: "{surface.700}",
                focusColor: "{surface.0}"
            },
            dropdown: {
                background: "{surface.800}",
                hoverBackground: "{surface.700}",
                activeBackground: "{surface.600}",
                color: "{surface.300}",
                hoverColor: "{surface.200}",
                activeColor: "{surface.100}"
            }
        }
    }, En = {
        root: yn,
        overlay: Cn,
        list: wn,
        option: xn,
        optionGroup: Bn,
        dropdown: $n,
        chip: Rn,
        emptyMessage: Sn,
        colorScheme: zn
    }, Pn = {
        width: "2rem",
        height: "2rem",
        fontSize: "1rem",
        background: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}"
    }, On = {
        size: "1rem"
    }, _n = {
        borderColor: "{content.background}",
        offset: "-0.75rem"
    }, In = {
        width: "3rem",
        height: "3rem",
        fontSize: "1.5rem",
        icon: {
            size: "1.5rem"
        },
        group: {
            offset: "-1rem"
        }
    }, Dn = {
        width: "4rem",
        height: "4rem",
        fontSize: "2rem",
        icon: {
            size: "2rem"
        },
        group: {
            offset: "-1.5rem"
        }
    }, Wn = {
        root: Pn,
        icon: On,
        group: _n,
        lg: In,
        xl: Dn
    }, Tn = {
        borderRadius: "{border.radius.md}",
        padding: "0 0.5rem",
        fontSize: "0.75rem",
        fontWeight: "700",
        minWidth: "1.5rem",
        height: "1.5rem"
    }, Ln = {
        size: "0.5rem"
    }, An = {
        fontSize: "0.625rem",
        minWidth: "1.25rem",
        height: "1.25rem"
    }, Hn = {
        fontSize: "0.875rem",
        minWidth: "1.75rem",
        height: "1.75rem"
    }, Mn = {
        fontSize: "1rem",
        minWidth: "2rem",
        height: "2rem"
    }, Fn = {
        light: {
            primary: {
                background: "{primary.color}",
                color: "{primary.contrast.color}"
            },
            secondary: {
                background: "{surface.100}",
                color: "{surface.600}"
            },
            success: {
                background: "{green.500}",
                color: "{surface.0}"
            },
            info: {
                background: "{sky.500}",
                color: "{surface.0}"
            },
            warn: {
                background: "{orange.500}",
                color: "{surface.0}"
            },
            danger: {
                background: "{red.500}",
                color: "{surface.0}"
            },
            contrast: {
                background: "{surface.950}",
                color: "{surface.0}"
            }
        },
        dark: {
            primary: {
                background: "{primary.color}",
                color: "{primary.contrast.color}"
            },
            secondary: {
                background: "{surface.800}",
                color: "{surface.300}"
            },
            success: {
                background: "{green.400}",
                color: "{green.950}"
            },
            info: {
                background: "{sky.400}",
                color: "{sky.950}"
            },
            warn: {
                background: "{orange.400}",
                color: "{orange.950}"
            },
            danger: {
                background: "{red.400}",
                color: "{red.950}"
            },
            contrast: {
                background: "{surface.0}",
                color: "{surface.950}"
            }
        }
    }, jn = {
        root: Tn,
        dot: Ln,
        sm: An,
        lg: Hn,
        xl: Mn,
        colorScheme: Fn
    }, Nn = {
        borderRadius: {
            none: "0",
            xs: "2px",
            sm: "4px",
            md: "6px",
            lg: "8px",
            xl: "12px"
        },
        emerald: {
            50: "#ecfdf5",
            100: "#d1fae5",
            200: "#a7f3d0",
            300: "#6ee7b7",
            400: "#34d399",
            500: "#10b981",
            600: "#059669",
            700: "#047857",
            800: "#065f46",
            900: "#064e3b",
            950: "#022c22"
        },
        green: {
            50: "#f0fdf4",
            100: "#dcfce7",
            200: "#bbf7d0",
            300: "#86efac",
            400: "#4ade80",
            500: "#22c55e",
            600: "#16a34a",
            700: "#15803d",
            800: "#166534",
            900: "#14532d",
            950: "#052e16"
        },
        lime: {
            50: "#f7fee7",
            100: "#ecfccb",
            200: "#d9f99d",
            300: "#bef264",
            400: "#a3e635",
            500: "#84cc16",
            600: "#65a30d",
            700: "#4d7c0f",
            800: "#3f6212",
            900: "#365314",
            950: "#1a2e05"
        },
        red: {
            50: "#fef2f2",
            100: "#fee2e2",
            200: "#fecaca",
            300: "#fca5a5",
            400: "#f87171",
            500: "#ef4444",
            600: "#dc2626",
            700: "#b91c1c",
            800: "#991b1b",
            900: "#7f1d1d",
            950: "#450a0a"
        },
        orange: {
            50: "#fff7ed",
            100: "#ffedd5",
            200: "#fed7aa",
            300: "#fdba74",
            400: "#fb923c",
            500: "#f97316",
            600: "#ea580c",
            700: "#c2410c",
            800: "#9a3412",
            900: "#7c2d12",
            950: "#431407"
        },
        amber: {
            50: "#fffbeb",
            100: "#fef3c7",
            200: "#fde68a",
            300: "#fcd34d",
            400: "#fbbf24",
            500: "#f59e0b",
            600: "#d97706",
            700: "#b45309",
            800: "#92400e",
            900: "#78350f",
            950: "#451a03"
        },
        yellow: {
            50: "#fefce8",
            100: "#fef9c3",
            200: "#fef08a",
            300: "#fde047",
            400: "#facc15",
            500: "#eab308",
            600: "#ca8a04",
            700: "#a16207",
            800: "#854d0e",
            900: "#713f12",
            950: "#422006"
        },
        teal: {
            50: "#f0fdfa",
            100: "#ccfbf1",
            200: "#99f6e4",
            300: "#5eead4",
            400: "#2dd4bf",
            500: "#14b8a6",
            600: "#0d9488",
            700: "#0f766e",
            800: "#115e59",
            900: "#134e4a",
            950: "#042f2e"
        },
        cyan: {
            50: "#ecfeff",
            100: "#cffafe",
            200: "#a5f3fc",
            300: "#67e8f9",
            400: "#22d3ee",
            500: "#06b6d4",
            600: "#0891b2",
            700: "#0e7490",
            800: "#155e75",
            900: "#164e63",
            950: "#083344"
        },
        sky: {
            50: "#f0f9ff",
            100: "#e0f2fe",
            200: "#bae6fd",
            300: "#7dd3fc",
            400: "#38bdf8",
            500: "#0ea5e9",
            600: "#0284c7",
            700: "#0369a1",
            800: "#075985",
            900: "#0c4a6e",
            950: "#082f49"
        },
        blue: {
            50: "#eff6ff",
            100: "#dbeafe",
            200: "#bfdbfe",
            300: "#93c5fd",
            400: "#60a5fa",
            500: "#3b82f6",
            600: "#2563eb",
            700: "#1d4ed8",
            800: "#1e40af",
            900: "#1e3a8a",
            950: "#172554"
        },
        indigo: {
            50: "#eef2ff",
            100: "#e0e7ff",
            200: "#c7d2fe",
            300: "#a5b4fc",
            400: "#818cf8",
            500: "#6366f1",
            600: "#4f46e5",
            700: "#4338ca",
            800: "#3730a3",
            900: "#312e81",
            950: "#1e1b4b"
        },
        violet: {
            50: "#f5f3ff",
            100: "#ede9fe",
            200: "#ddd6fe",
            300: "#c4b5fd",
            400: "#a78bfa",
            500: "#8b5cf6",
            600: "#7c3aed",
            700: "#6d28d9",
            800: "#5b21b6",
            900: "#4c1d95",
            950: "#2e1065"
        },
        purple: {
            50: "#faf5ff",
            100: "#f3e8ff",
            200: "#e9d5ff",
            300: "#d8b4fe",
            400: "#c084fc",
            500: "#a855f7",
            600: "#9333ea",
            700: "#7e22ce",
            800: "#6b21a8",
            900: "#581c87",
            950: "#3b0764"
        },
        fuchsia: {
            50: "#fdf4ff",
            100: "#fae8ff",
            200: "#f5d0fe",
            300: "#f0abfc",
            400: "#e879f9",
            500: "#d946ef",
            600: "#c026d3",
            700: "#a21caf",
            800: "#86198f",
            900: "#701a75",
            950: "#4a044e"
        },
        pink: {
            50: "#fdf2f8",
            100: "#fce7f3",
            200: "#fbcfe8",
            300: "#f9a8d4",
            400: "#f472b6",
            500: "#ec4899",
            600: "#db2777",
            700: "#be185d",
            800: "#9d174d",
            900: "#831843",
            950: "#500724"
        },
        rose: {
            50: "#fff1f2",
            100: "#ffe4e6",
            200: "#fecdd3",
            300: "#fda4af",
            400: "#fb7185",
            500: "#f43f5e",
            600: "#e11d48",
            700: "#be123c",
            800: "#9f1239",
            900: "#881337",
            950: "#4c0519"
        },
        slate: {
            50: "#f8fafc",
            100: "#f1f5f9",
            200: "#e2e8f0",
            300: "#cbd5e1",
            400: "#94a3b8",
            500: "#64748b",
            600: "#475569",
            700: "#334155",
            800: "#1e293b",
            900: "#0f172a",
            950: "#020617"
        },
        gray: {
            50: "#f9fafb",
            100: "#f3f4f6",
            200: "#e5e7eb",
            300: "#d1d5db",
            400: "#9ca3af",
            500: "#6b7280",
            600: "#4b5563",
            700: "#374151",
            800: "#1f2937",
            900: "#111827",
            950: "#030712"
        },
        zinc: {
            50: "#fafafa",
            100: "#f4f4f5",
            200: "#e4e4e7",
            300: "#d4d4d8",
            400: "#a1a1aa",
            500: "#71717a",
            600: "#52525b",
            700: "#3f3f46",
            800: "#27272a",
            900: "#18181b",
            950: "#09090b"
        },
        neutral: {
            50: "#fafafa",
            100: "#f5f5f5",
            200: "#e5e5e5",
            300: "#d4d4d4",
            400: "#a3a3a3",
            500: "#737373",
            600: "#525252",
            700: "#404040",
            800: "#262626",
            900: "#171717",
            950: "#0a0a0a"
        },
        stone: {
            50: "#fafaf9",
            100: "#f5f5f4",
            200: "#e7e5e4",
            300: "#d6d3d1",
            400: "#a8a29e",
            500: "#78716c",
            600: "#57534e",
            700: "#44403c",
            800: "#292524",
            900: "#1c1917",
            950: "#0c0a09"
        }
    }, Vn = {
        transitionDuration: "0.2s",
        focusRing: {
            width: "1px",
            style: "solid",
            color: "{primary.color}",
            offset: "2px",
            shadow: "none"
        },
        disabledOpacity: "0.6",
        iconSize: "1rem",
        anchorGutter: "2px",
        primary: {
            50: "{emerald.50}",
            100: "{emerald.100}",
            200: "{emerald.200}",
            300: "{emerald.300}",
            400: "{emerald.400}",
            500: "{emerald.500}",
            600: "{emerald.600}",
            700: "{emerald.700}",
            800: "{emerald.800}",
            900: "{emerald.900}",
            950: "{emerald.950}"
        },
        formField: {
            paddingX: "0.75rem",
            paddingY: "0.5rem",
            sm: {
                fontSize: "0.875rem",
                paddingX: "0.625rem",
                paddingY: "0.375rem"
            },
            lg: {
                fontSize: "1.125rem",
                paddingX: "0.875rem",
                paddingY: "0.625rem"
            },
            borderRadius: "{border.radius.md}",
            focusRing: {
                width: "0",
                style: "none",
                color: "transparent",
                offset: "0",
                shadow: "none"
            },
            transitionDuration: "{transition.duration}"
        },
        list: {
            padding: "0.25rem 0.25rem",
            gap: "2px",
            header: {
                padding: "0.5rem 1rem 0.25rem 1rem"
            },
            option: {
                padding: "0.5rem 0.75rem",
                borderRadius: "{border.radius.sm}"
            },
            optionGroup: {
                padding: "0.5rem 0.75rem",
                fontWeight: "600"
            }
        },
        content: {
            borderRadius: "{border.radius.md}"
        },
        mask: {
            transitionDuration: "0.15s"
        },
        navigation: {
            list: {
                padding: "0.25rem 0.25rem",
                gap: "2px"
            },
            item: {
                padding: "0.5rem 0.75rem",
                borderRadius: "{border.radius.sm}",
                gap: "0.5rem"
            },
            submenuLabel: {
                padding: "0.5rem 0.75rem",
                fontWeight: "600"
            },
            submenuIcon: {
                size: "0.875rem"
            }
        },
        overlay: {
            select: {
                borderRadius: "{border.radius.md}",
                shadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
            },
            popover: {
                borderRadius: "{border.radius.md}",
                padding: "0.75rem",
                shadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
            },
            modal: {
                borderRadius: "{border.radius.xl}",
                padding: "1.25rem",
                shadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)"
            },
            navigation: {
                shadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
            }
        },
        colorScheme: {
            light: {
                surface: {
                    0: "#ffffff",
                    50: "{slate.50}",
                    100: "{slate.100}",
                    200: "{slate.200}",
                    300: "{slate.300}",
                    400: "{slate.400}",
                    500: "{slate.500}",
                    600: "{slate.600}",
                    700: "{slate.700}",
                    800: "{slate.800}",
                    900: "{slate.900}",
                    950: "{slate.950}"
                },
                primary: {
                    color: "{primary.500}",
                    contrastColor: "#ffffff",
                    hoverColor: "{primary.600}",
                    activeColor: "{primary.700}"
                },
                highlight: {
                    background: "{primary.50}",
                    focusBackground: "{primary.100}",
                    color: "{primary.700}",
                    focusColor: "{primary.800}"
                },
                mask: {
                    background: "rgba(0,0,0,0.4)",
                    color: "{surface.200}"
                },
                formField: {
                    background: "{surface.0}",
                    disabledBackground: "{surface.200}",
                    filledBackground: "{surface.50}",
                    filledHoverBackground: "{surface.50}",
                    filledFocusBackground: "{surface.50}",
                    borderColor: "{surface.300}",
                    hoverBorderColor: "{surface.400}",
                    focusBorderColor: "{primary.color}",
                    invalidBorderColor: "{red.400}",
                    color: "{surface.700}",
                    disabledColor: "{surface.500}",
                    placeholderColor: "{surface.500}",
                    invalidPlaceholderColor: "{red.600}",
                    floatLabelColor: "{surface.500}",
                    floatLabelFocusColor: "{primary.600}",
                    floatLabelActiveColor: "{surface.500}",
                    floatLabelInvalidColor: "{form.field.invalid.placeholder.color}",
                    iconColor: "{surface.400}",
                    shadow: "0 0 #0000, 0 0 #0000, 0 1px 2px 0 rgba(18, 18, 23, 0.05)"
                },
                text: {
                    color: "{surface.700}",
                    hoverColor: "{surface.800}",
                    mutedColor: "{surface.500}",
                    hoverMutedColor: "{surface.600}"
                },
                content: {
                    background: "{surface.0}",
                    hoverBackground: "{surface.100}",
                    borderColor: "{surface.200}",
                    color: "{text.color}",
                    hoverColor: "{text.hover.color}"
                },
                overlay: {
                    select: {
                        background: "{surface.0}",
                        borderColor: "{surface.200}",
                        color: "{text.color}"
                    },
                    popover: {
                        background: "{surface.0}",
                        borderColor: "{surface.200}",
                        color: "{text.color}"
                    },
                    modal: {
                        background: "{surface.0}",
                        borderColor: "{surface.200}",
                        color: "{text.color}"
                    }
                },
                list: {
                    option: {
                        focusBackground: "{surface.100}",
                        selectedBackground: "{highlight.background}",
                        selectedFocusBackground: "{highlight.focus.background}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        selectedColor: "{highlight.color}",
                        selectedFocusColor: "{highlight.focus.color}",
                        icon: {
                            color: "{surface.400}",
                            focusColor: "{surface.500}"
                        }
                    },
                    optionGroup: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    }
                },
                navigation: {
                    item: {
                        focusBackground: "{surface.100}",
                        activeBackground: "{surface.100}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        activeColor: "{text.hover.color}",
                        icon: {
                            color: "{surface.400}",
                            focusColor: "{surface.500}",
                            activeColor: "{surface.500}"
                        }
                    },
                    submenuLabel: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    },
                    submenuIcon: {
                        color: "{surface.400}",
                        focusColor: "{surface.500}",
                        activeColor: "{surface.500}"
                    }
                }
            },
            dark: {
                surface: {
                    0: "#ffffff",
                    50: "{zinc.50}",
                    100: "{zinc.100}",
                    200: "{zinc.200}",
                    300: "{zinc.300}",
                    400: "{zinc.400}",
                    500: "{zinc.500}",
                    600: "{zinc.600}",
                    700: "{zinc.700}",
                    800: "{zinc.800}",
                    900: "{zinc.900}",
                    950: "{zinc.950}"
                },
                primary: {
                    color: "{primary.400}",
                    contrastColor: "{surface.900}",
                    hoverColor: "{primary.300}",
                    activeColor: "{primary.200}"
                },
                highlight: {
                    background: "color-mix(in srgb, {primary.400}, transparent 84%)",
                    focusBackground: "color-mix(in srgb, {primary.400}, transparent 76%)",
                    color: "rgba(255,255,255,.87)",
                    focusColor: "rgba(255,255,255,.87)"
                },
                mask: {
                    background: "rgba(0,0,0,0.6)",
                    color: "{surface.200}"
                },
                formField: {
                    background: "{surface.950}",
                    disabledBackground: "{surface.700}",
                    filledBackground: "{surface.800}",
                    filledHoverBackground: "{surface.800}",
                    filledFocusBackground: "{surface.800}",
                    borderColor: "{surface.600}",
                    hoverBorderColor: "{surface.500}",
                    focusBorderColor: "{primary.color}",
                    invalidBorderColor: "{red.300}",
                    color: "{surface.0}",
                    disabledColor: "{surface.400}",
                    placeholderColor: "{surface.400}",
                    invalidPlaceholderColor: "{red.400}",
                    floatLabelColor: "{surface.400}",
                    floatLabelFocusColor: "{primary.color}",
                    floatLabelActiveColor: "{surface.400}",
                    floatLabelInvalidColor: "{form.field.invalid.placeholder.color}",
                    iconColor: "{surface.400}",
                    shadow: "0 0 #0000, 0 0 #0000, 0 1px 2px 0 rgba(18, 18, 23, 0.05)"
                },
                text: {
                    color: "{surface.0}",
                    hoverColor: "{surface.0}",
                    mutedColor: "{surface.400}",
                    hoverMutedColor: "{surface.300}"
                },
                content: {
                    background: "{surface.900}",
                    hoverBackground: "{surface.800}",
                    borderColor: "{surface.700}",
                    color: "{text.color}",
                    hoverColor: "{text.hover.color}"
                },
                overlay: {
                    select: {
                        background: "{surface.900}",
                        borderColor: "{surface.700}",
                        color: "{text.color}"
                    },
                    popover: {
                        background: "{surface.900}",
                        borderColor: "{surface.700}",
                        color: "{text.color}"
                    },
                    modal: {
                        background: "{surface.900}",
                        borderColor: "{surface.700}",
                        color: "{text.color}"
                    }
                },
                list: {
                    option: {
                        focusBackground: "{surface.800}",
                        selectedBackground: "{highlight.background}",
                        selectedFocusBackground: "{highlight.focus.background}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        selectedColor: "{highlight.color}",
                        selectedFocusColor: "{highlight.focus.color}",
                        icon: {
                            color: "{surface.500}",
                            focusColor: "{surface.400}"
                        }
                    },
                    optionGroup: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    }
                },
                navigation: {
                    item: {
                        focusBackground: "{surface.800}",
                        activeBackground: "{surface.800}",
                        color: "{text.color}",
                        focusColor: "{text.hover.color}",
                        activeColor: "{text.hover.color}",
                        icon: {
                            color: "{surface.500}",
                            focusColor: "{surface.400}",
                            activeColor: "{surface.400}"
                        }
                    },
                    submenuLabel: {
                        background: "transparent",
                        color: "{text.muted.color}"
                    },
                    submenuIcon: {
                        color: "{surface.500}",
                        focusColor: "{surface.400}",
                        activeColor: "{surface.400}"
                    }
                }
            }
        }
    }, Xn = {
        primitive: Nn,
        semantic: Vn
    }, Yn = {
        borderRadius: "{content.border.radius}"
    }, Gn = {
        root: Yn
    }, qn = {
        padding: "1rem",
        background: "{content.background}",
        gap: "0.5rem",
        transitionDuration: "{transition.duration}"
    }, Kn = {
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        borderRadius: "{content.border.radius}",
        gap: "{navigation.item.gap}",
        icon: {
            color: "{navigation.item.icon.color}",
            hoverColor: "{navigation.item.icon.focus.color}"
        },
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Un = {
        color: "{navigation.item.icon.color}"
    }, Qn = {
        root: qn,
        item: Kn,
        separator: Un
    }, Jn = {
        borderRadius: "{form.field.border.radius}",
        roundedBorderRadius: "2rem",
        gap: "0.5rem",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        iconOnlyWidth: "2.5rem",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}",
            iconOnlyWidth: "2rem"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}",
            iconOnlyWidth: "3rem"
        },
        label: {
            fontWeight: "500"
        },
        raisedShadow: "0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12)",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            offset: "{focus.ring.offset}"
        },
        badgeSize: "1rem",
        transitionDuration: "{form.field.transition.duration}"
    }, Zn = {
        light: {
            root: {
                primary: {
                    background: "{primary.color}",
                    hoverBackground: "{primary.hover.color}",
                    activeBackground: "{primary.active.color}",
                    borderColor: "{primary.color}",
                    hoverBorderColor: "{primary.hover.color}",
                    activeBorderColor: "{primary.active.color}",
                    color: "{primary.contrast.color}",
                    hoverColor: "{primary.contrast.color}",
                    activeColor: "{primary.contrast.color}",
                    focusRing: {
                        color: "{primary.color}",
                        shadow: "none"
                    }
                },
                secondary: {
                    background: "{surface.100}",
                    hoverBackground: "{surface.200}",
                    activeBackground: "{surface.300}",
                    borderColor: "{surface.100}",
                    hoverBorderColor: "{surface.200}",
                    activeBorderColor: "{surface.300}",
                    color: "{surface.600}",
                    hoverColor: "{surface.700}",
                    activeColor: "{surface.800}",
                    focusRing: {
                        color: "{surface.600}",
                        shadow: "none"
                    }
                },
                info: {
                    background: "{sky.500}",
                    hoverBackground: "{sky.600}",
                    activeBackground: "{sky.700}",
                    borderColor: "{sky.500}",
                    hoverBorderColor: "{sky.600}",
                    activeBorderColor: "{sky.700}",
                    color: "#ffffff",
                    hoverColor: "#ffffff",
                    activeColor: "#ffffff",
                    focusRing: {
                        color: "{sky.500}",
                        shadow: "none"
                    }
                },
                success: {
                    background: "{green.500}",
                    hoverBackground: "{green.600}",
                    activeBackground: "{green.700}",
                    borderColor: "{green.500}",
                    hoverBorderColor: "{green.600}",
                    activeBorderColor: "{green.700}",
                    color: "#ffffff",
                    hoverColor: "#ffffff",
                    activeColor: "#ffffff",
                    focusRing: {
                        color: "{green.500}",
                        shadow: "none"
                    }
                },
                warn: {
                    background: "{orange.500}",
                    hoverBackground: "{orange.600}",
                    activeBackground: "{orange.700}",
                    borderColor: "{orange.500}",
                    hoverBorderColor: "{orange.600}",
                    activeBorderColor: "{orange.700}",
                    color: "#ffffff",
                    hoverColor: "#ffffff",
                    activeColor: "#ffffff",
                    focusRing: {
                        color: "{orange.500}",
                        shadow: "none"
                    }
                },
                help: {
                    background: "{purple.500}",
                    hoverBackground: "{purple.600}",
                    activeBackground: "{purple.700}",
                    borderColor: "{purple.500}",
                    hoverBorderColor: "{purple.600}",
                    activeBorderColor: "{purple.700}",
                    color: "#ffffff",
                    hoverColor: "#ffffff",
                    activeColor: "#ffffff",
                    focusRing: {
                        color: "{purple.500}",
                        shadow: "none"
                    }
                },
                danger: {
                    background: "{red.500}",
                    hoverBackground: "{red.600}",
                    activeBackground: "{red.700}",
                    borderColor: "{red.500}",
                    hoverBorderColor: "{red.600}",
                    activeBorderColor: "{red.700}",
                    color: "#ffffff",
                    hoverColor: "#ffffff",
                    activeColor: "#ffffff",
                    focusRing: {
                        color: "{red.500}",
                        shadow: "none"
                    }
                },
                contrast: {
                    background: "{surface.950}",
                    hoverBackground: "{surface.900}",
                    activeBackground: "{surface.800}",
                    borderColor: "{surface.950}",
                    hoverBorderColor: "{surface.900}",
                    activeBorderColor: "{surface.800}",
                    color: "{surface.0}",
                    hoverColor: "{surface.0}",
                    activeColor: "{surface.0}",
                    focusRing: {
                        color: "{surface.950}",
                        shadow: "none"
                    }
                }
            },
            outlined: {
                primary: {
                    hoverBackground: "{primary.50}",
                    activeBackground: "{primary.100}",
                    borderColor: "{primary.200}",
                    color: "{primary.color}"
                },
                secondary: {
                    hoverBackground: "{surface.50}",
                    activeBackground: "{surface.100}",
                    borderColor: "{surface.200}",
                    color: "{surface.500}"
                },
                success: {
                    hoverBackground: "{green.50}",
                    activeBackground: "{green.100}",
                    borderColor: "{green.200}",
                    color: "{green.500}"
                },
                info: {
                    hoverBackground: "{sky.50}",
                    activeBackground: "{sky.100}",
                    borderColor: "{sky.200}",
                    color: "{sky.500}"
                },
                warn: {
                    hoverBackground: "{orange.50}",
                    activeBackground: "{orange.100}",
                    borderColor: "{orange.200}",
                    color: "{orange.500}"
                },
                help: {
                    hoverBackground: "{purple.50}",
                    activeBackground: "{purple.100}",
                    borderColor: "{purple.200}",
                    color: "{purple.500}"
                },
                danger: {
                    hoverBackground: "{red.50}",
                    activeBackground: "{red.100}",
                    borderColor: "{red.200}",
                    color: "{red.500}"
                },
                contrast: {
                    hoverBackground: "{surface.50}",
                    activeBackground: "{surface.100}",
                    borderColor: "{surface.700}",
                    color: "{surface.950}"
                },
                plain: {
                    hoverBackground: "{surface.50}",
                    activeBackground: "{surface.100}",
                    borderColor: "{surface.200}",
                    color: "{surface.700}"
                }
            },
            text: {
                primary: {
                    hoverBackground: "{primary.50}",
                    activeBackground: "{primary.100}",
                    color: "{primary.color}"
                },
                secondary: {
                    hoverBackground: "{surface.50}",
                    activeBackground: "{surface.100}",
                    color: "{surface.500}"
                },
                success: {
                    hoverBackground: "{green.50}",
                    activeBackground: "{green.100}",
                    color: "{green.500}"
                },
                info: {
                    hoverBackground: "{sky.50}",
                    activeBackground: "{sky.100}",
                    color: "{sky.500}"
                },
                warn: {
                    hoverBackground: "{orange.50}",
                    activeBackground: "{orange.100}",
                    color: "{orange.500}"
                },
                help: {
                    hoverBackground: "{purple.50}",
                    activeBackground: "{purple.100}",
                    color: "{purple.500}"
                },
                danger: {
                    hoverBackground: "{red.50}",
                    activeBackground: "{red.100}",
                    color: "{red.500}"
                },
                contrast: {
                    hoverBackground: "{surface.50}",
                    activeBackground: "{surface.100}",
                    color: "{surface.950}"
                },
                plain: {
                    hoverBackground: "{surface.50}",
                    activeBackground: "{surface.100}",
                    color: "{surface.700}"
                }
            },
            link: {
                color: "{primary.color}",
                hoverColor: "{primary.color}",
                activeColor: "{primary.color}"
            }
        },
        dark: {
            root: {
                primary: {
                    background: "{primary.color}",
                    hoverBackground: "{primary.hover.color}",
                    activeBackground: "{primary.active.color}",
                    borderColor: "{primary.color}",
                    hoverBorderColor: "{primary.hover.color}",
                    activeBorderColor: "{primary.active.color}",
                    color: "{primary.contrast.color}",
                    hoverColor: "{primary.contrast.color}",
                    activeColor: "{primary.contrast.color}",
                    focusRing: {
                        color: "{primary.color}",
                        shadow: "none"
                    }
                },
                secondary: {
                    background: "{surface.800}",
                    hoverBackground: "{surface.700}",
                    activeBackground: "{surface.600}",
                    borderColor: "{surface.800}",
                    hoverBorderColor: "{surface.700}",
                    activeBorderColor: "{surface.600}",
                    color: "{surface.300}",
                    hoverColor: "{surface.200}",
                    activeColor: "{surface.100}",
                    focusRing: {
                        color: "{surface.300}",
                        shadow: "none"
                    }
                },
                info: {
                    background: "{sky.400}",
                    hoverBackground: "{sky.300}",
                    activeBackground: "{sky.200}",
                    borderColor: "{sky.400}",
                    hoverBorderColor: "{sky.300}",
                    activeBorderColor: "{sky.200}",
                    color: "{sky.950}",
                    hoverColor: "{sky.950}",
                    activeColor: "{sky.950}",
                    focusRing: {
                        color: "{sky.400}",
                        shadow: "none"
                    }
                },
                success: {
                    background: "{green.400}",
                    hoverBackground: "{green.300}",
                    activeBackground: "{green.200}",
                    borderColor: "{green.400}",
                    hoverBorderColor: "{green.300}",
                    activeBorderColor: "{green.200}",
                    color: "{green.950}",
                    hoverColor: "{green.950}",
                    activeColor: "{green.950}",
                    focusRing: {
                        color: "{green.400}",
                        shadow: "none"
                    }
                },
                warn: {
                    background: "{orange.400}",
                    hoverBackground: "{orange.300}",
                    activeBackground: "{orange.200}",
                    borderColor: "{orange.400}",
                    hoverBorderColor: "{orange.300}",
                    activeBorderColor: "{orange.200}",
                    color: "{orange.950}",
                    hoverColor: "{orange.950}",
                    activeColor: "{orange.950}",
                    focusRing: {
                        color: "{orange.400}",
                        shadow: "none"
                    }
                },
                help: {
                    background: "{purple.400}",
                    hoverBackground: "{purple.300}",
                    activeBackground: "{purple.200}",
                    borderColor: "{purple.400}",
                    hoverBorderColor: "{purple.300}",
                    activeBorderColor: "{purple.200}",
                    color: "{purple.950}",
                    hoverColor: "{purple.950}",
                    activeColor: "{purple.950}",
                    focusRing: {
                        color: "{purple.400}",
                        shadow: "none"
                    }
                },
                danger: {
                    background: "{red.400}",
                    hoverBackground: "{red.300}",
                    activeBackground: "{red.200}",
                    borderColor: "{red.400}",
                    hoverBorderColor: "{red.300}",
                    activeBorderColor: "{red.200}",
                    color: "{red.950}",
                    hoverColor: "{red.950}",
                    activeColor: "{red.950}",
                    focusRing: {
                        color: "{red.400}",
                        shadow: "none"
                    }
                },
                contrast: {
                    background: "{surface.0}",
                    hoverBackground: "{surface.100}",
                    activeBackground: "{surface.200}",
                    borderColor: "{surface.0}",
                    hoverBorderColor: "{surface.100}",
                    activeBorderColor: "{surface.200}",
                    color: "{surface.950}",
                    hoverColor: "{surface.950}",
                    activeColor: "{surface.950}",
                    focusRing: {
                        color: "{surface.0}",
                        shadow: "none"
                    }
                }
            },
            outlined: {
                primary: {
                    hoverBackground: "color-mix(in srgb, {primary.color}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {primary.color}, transparent 84%)",
                    borderColor: "{primary.700}",
                    color: "{primary.color}"
                },
                secondary: {
                    hoverBackground: "rgba(255,255,255,0.04)",
                    activeBackground: "rgba(255,255,255,0.16)",
                    borderColor: "{surface.700}",
                    color: "{surface.400}"
                },
                success: {
                    hoverBackground: "color-mix(in srgb, {green.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {green.400}, transparent 84%)",
                    borderColor: "{green.700}",
                    color: "{green.400}"
                },
                info: {
                    hoverBackground: "color-mix(in srgb, {sky.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {sky.400}, transparent 84%)",
                    borderColor: "{sky.700}",
                    color: "{sky.400}"
                },
                warn: {
                    hoverBackground: "color-mix(in srgb, {orange.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {orange.400}, transparent 84%)",
                    borderColor: "{orange.700}",
                    color: "{orange.400}"
                },
                help: {
                    hoverBackground: "color-mix(in srgb, {purple.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {purple.400}, transparent 84%)",
                    borderColor: "{purple.700}",
                    color: "{purple.400}"
                },
                danger: {
                    hoverBackground: "color-mix(in srgb, {red.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {red.400}, transparent 84%)",
                    borderColor: "{red.700}",
                    color: "{red.400}"
                },
                contrast: {
                    hoverBackground: "{surface.800}",
                    activeBackground: "{surface.700}",
                    borderColor: "{surface.500}",
                    color: "{surface.0}"
                },
                plain: {
                    hoverBackground: "{surface.800}",
                    activeBackground: "{surface.700}",
                    borderColor: "{surface.600}",
                    color: "{surface.0}"
                }
            },
            text: {
                primary: {
                    hoverBackground: "color-mix(in srgb, {primary.color}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {primary.color}, transparent 84%)",
                    color: "{primary.color}"
                },
                secondary: {
                    hoverBackground: "{surface.800}",
                    activeBackground: "{surface.700}",
                    color: "{surface.400}"
                },
                success: {
                    hoverBackground: "color-mix(in srgb, {green.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {green.400}, transparent 84%)",
                    color: "{green.400}"
                },
                info: {
                    hoverBackground: "color-mix(in srgb, {sky.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {sky.400}, transparent 84%)",
                    color: "{sky.400}"
                },
                warn: {
                    hoverBackground: "color-mix(in srgb, {orange.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {orange.400}, transparent 84%)",
                    color: "{orange.400}"
                },
                help: {
                    hoverBackground: "color-mix(in srgb, {purple.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {purple.400}, transparent 84%)",
                    color: "{purple.400}"
                },
                danger: {
                    hoverBackground: "color-mix(in srgb, {red.400}, transparent 96%)",
                    activeBackground: "color-mix(in srgb, {red.400}, transparent 84%)",
                    color: "{red.400}"
                },
                contrast: {
                    hoverBackground: "{surface.800}",
                    activeBackground: "{surface.700}",
                    color: "{surface.0}"
                },
                plain: {
                    hoverBackground: "{surface.800}",
                    activeBackground: "{surface.700}",
                    color: "{surface.0}"
                }
            },
            link: {
                color: "{primary.color}",
                hoverColor: "{primary.color}",
                activeColor: "{primary.color}"
            }
        }
    }, ot = {
        root: Jn,
        colorScheme: Zn
    }, rt = {
        background: "{content.background}",
        borderRadius: "{border.radius.xl}",
        color: "{content.color}",
        shadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)"
    }, et = {
        padding: "1.25rem",
        gap: "0.5rem"
    }, nt = {
        gap: "0.5rem"
    }, tt = {
        fontSize: "1.25rem",
        fontWeight: "500"
    }, at = {
        color: "{text.muted.color}"
    }, ct = {
        root: rt,
        body: et,
        caption: nt,
        title: tt,
        subtitle: at
    }, it = {
        transitionDuration: "{transition.duration}"
    }, dt = {
        gap: "0.25rem"
    }, lt = {
        padding: "1rem",
        gap: "0.5rem"
    }, st = {
        width: "2rem",
        height: "0.5rem",
        borderRadius: "{content.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, ut = {
        light: {
            indicator: {
                background: "{surface.200}",
                hoverBackground: "{surface.300}",
                activeBackground: "{primary.color}"
            }
        },
        dark: {
            indicator: {
                background: "{surface.700}",
                hoverBackground: "{surface.600}",
                activeBackground: "{primary.color}"
            }
        }
    }, ft = {
        root: it,
        content: dt,
        indicatorList: lt,
        indicator: st,
        colorScheme: ut
    }, gt = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}"
        }
    }, pt = {
        width: "2.5rem",
        color: "{form.field.icon.color}"
    }, mt = {
        background: "{overlay.select.background}",
        borderColor: "{overlay.select.border.color}",
        borderRadius: "{overlay.select.border.radius}",
        color: "{overlay.select.color}",
        shadow: "{overlay.select.shadow}"
    }, bt = {
        padding: "{list.padding}",
        gap: "{list.gap}",
        mobileIndent: "1rem"
    }, ht = {
        focusBackground: "{list.option.focus.background}",
        selectedBackground: "{list.option.selected.background}",
        selectedFocusBackground: "{list.option.selected.focus.background}",
        color: "{list.option.color}",
        focusColor: "{list.option.focus.color}",
        selectedColor: "{list.option.selected.color}",
        selectedFocusColor: "{list.option.selected.focus.color}",
        padding: "{list.option.padding}",
        borderRadius: "{list.option.border.radius}",
        icon: {
            color: "{list.option.icon.color}",
            focusColor: "{list.option.icon.focus.color}",
            size: "0.875rem"
        }
    }, vt = {
        color: "{form.field.icon.color}"
    }, kt = {
        root: gt,
        dropdown: pt,
        overlay: mt,
        list: bt,
        option: ht,
        clearIcon: vt
    }, yt = {
        borderRadius: "{border.radius.sm}",
        width: "1.25rem",
        height: "1.25rem",
        background: "{form.field.background}",
        checkedBackground: "{primary.color}",
        checkedHoverBackground: "{primary.hover.color}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.border.color}",
        checkedBorderColor: "{primary.color}",
        checkedHoverBorderColor: "{primary.hover.color}",
        checkedFocusBorderColor: "{primary.color}",
        checkedDisabledBorderColor: "{form.field.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        shadow: "{form.field.shadow}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            width: "1rem",
            height: "1rem"
        },
        lg: {
            width: "1.5rem",
            height: "1.5rem"
        }
    }, Ct = {
        size: "0.875rem",
        color: "{form.field.color}",
        checkedColor: "{primary.contrast.color}",
        checkedHoverColor: "{primary.contrast.color}",
        disabledColor: "{form.field.disabled.color}",
        sm: {
            size: "0.75rem"
        },
        lg: {
            size: "1rem"
        }
    }, wt = {
        root: yt,
        icon: Ct
    }, xt = {
        borderRadius: "16px",
        paddingX: "0.75rem",
        paddingY: "0.5rem",
        gap: "0.5rem",
        transitionDuration: "{transition.duration}"
    }, Bt = {
        width: "2rem",
        height: "2rem"
    }, $t = {
        size: "1rem"
    }, Rt = {
        size: "1rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        }
    }, St = {
        light: {
            root: {
                background: "{surface.100}",
                color: "{surface.800}"
            },
            icon: {
                color: "{surface.800}"
            },
            removeIcon: {
                color: "{surface.800}"
            }
        },
        dark: {
            root: {
                background: "{surface.800}",
                color: "{surface.0}"
            },
            icon: {
                color: "{surface.0}"
            },
            removeIcon: {
                color: "{surface.0}"
            }
        }
    }, zt = {
        root: xt,
        image: Bt,
        icon: $t,
        removeIcon: Rt,
        colorScheme: St
    }, Et = {
        transitionDuration: "{transition.duration}"
    }, Pt = {
        width: "1.5rem",
        height: "1.5rem",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Ot = {
        shadow: "{overlay.popover.shadow}",
        borderRadius: "{overlay.popover.borderRadius}"
    }, _t = {
        light: {
            panel: {
                background: "{surface.800}",
                borderColor: "{surface.900}"
            },
            handle: {
                color: "{surface.0}"
            }
        },
        dark: {
            panel: {
                background: "{surface.900}",
                borderColor: "{surface.700}"
            },
            handle: {
                color: "{surface.0}"
            }
        }
    }, It = {
        root: Et,
        preview: Pt,
        panel: Ot,
        colorScheme: _t
    }, Dt = {
        size: "2rem",
        color: "{overlay.modal.color}"
    }, Wt = {
        gap: "1rem"
    }, Tt = {
        icon: Dt,
        content: Wt
    }, Lt = {
        background: "{overlay.popover.background}",
        borderColor: "{overlay.popover.border.color}",
        color: "{overlay.popover.color}",
        borderRadius: "{overlay.popover.border.radius}",
        shadow: "{overlay.popover.shadow}",
        gutter: "10px",
        arrowOffset: "1.25rem"
    }, At = {
        padding: "{overlay.popover.padding}",
        gap: "1rem"
    }, Ht = {
        size: "1.5rem",
        color: "{overlay.popover.color}"
    }, Mt = {
        gap: "0.5rem",
        padding: "0 {overlay.popover.padding} {overlay.popover.padding} {overlay.popover.padding}"
    }, Ft = {
        root: Lt,
        content: At,
        icon: Ht,
        footer: Mt
    }, jt = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}",
        shadow: "{overlay.navigation.shadow}",
        transitionDuration: "{transition.duration}"
    }, Nt = {
        padding: "{navigation.list.padding}",
        gap: "{navigation.list.gap}"
    }, Vt = {
        focusBackground: "{navigation.item.focus.background}",
        activeBackground: "{navigation.item.active.background}",
        color: "{navigation.item.color}",
        focusColor: "{navigation.item.focus.color}",
        activeColor: "{navigation.item.active.color}",
        padding: "{navigation.item.padding}",
        borderRadius: "{navigation.item.border.radius}",
        gap: "{navigation.item.gap}",
        icon: {
            color: "{navigation.item.icon.color}",
            focusColor: "{navigation.item.icon.focus.color}",
            activeColor: "{navigation.item.icon.active.color}"
        }
    }, Xt = {
        mobileIndent: "1rem"
    }, Yt = {
        size: "{navigation.submenu.icon.size}",
        color: "{navigation.submenu.icon.color}",
        focusColor: "{navigation.submenu.icon.focus.color}",
        activeColor: "{navigation.submenu.icon.active.color}"
    }, Gt = {
        borderColor: "{content.border.color}"
    }, qt = {
        root: jt,
        list: Nt,
        item: Vt,
        submenu: Xt,
        submenuIcon: Yt,
        separator: Gt
    }, Kt = {
        transitionDuration: "{transition.duration}"
    }, Ut = {
        background: "{content.background}",
        borderColor: "{datatable.border.color}",
        color: "{content.color}",
        borderWidth: "0 0 1px 0",
        padding: "0.75rem 1rem",
        sm: {
            padding: "0.375rem 0.5rem"
        },
        lg: {
            padding: "1rem 1.25rem"
        }
    }, Qt = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        borderColor: "{datatable.border.color}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        selectedColor: "{highlight.color}",
        gap: "0.5rem",
        padding: "0.75rem 1rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        },
        sm: {
            padding: "0.375rem 0.5rem"
        },
        lg: {
            padding: "1rem 1.25rem"
        }
    }, Jt = {
        fontWeight: "600"
    }, Zt = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        selectedColor: "{highlight.color}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        }
    }, oa = {
        borderColor: "{datatable.border.color}",
        padding: "0.75rem 1rem",
        sm: {
            padding: "0.375rem 0.5rem"
        },
        lg: {
            padding: "1rem 1.25rem"
        }
    }, ra = {
        background: "{content.background}",
        borderColor: "{datatable.border.color}",
        color: "{content.color}",
        padding: "0.75rem 1rem",
        sm: {
            padding: "0.375rem 0.5rem"
        },
        lg: {
            padding: "1rem 1.25rem"
        }
    }, ea = {
        fontWeight: "600"
    }, na = {
        background: "{content.background}",
        borderColor: "{datatable.border.color}",
        color: "{content.color}",
        borderWidth: "0 0 1px 0",
        padding: "0.75rem 1rem",
        sm: {
            padding: "0.375rem 0.5rem"
        },
        lg: {
            padding: "1rem 1.25rem"
        }
    }, ta = {
        color: "{primary.color}"
    }, aa = {
        width: "0.5rem"
    }, ca = {
        width: "1px",
        color: "{primary.color}"
    }, ia = {
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        size: "0.875rem"
    }, da = {
        size: "2rem"
    }, la = {
        hoverBackground: "{content.hover.background}",
        selectedHoverBackground: "{content.background}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        selectedHoverColor: "{primary.color}",
        size: "1.75rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, sa = {
        inlineGap: "0.5rem",
        overlaySelect: {
            background: "{overlay.select.background}",
            borderColor: "{overlay.select.border.color}",
            borderRadius: "{overlay.select.border.radius}",
            color: "{overlay.select.color}",
            shadow: "{overlay.select.shadow}"
        },
        overlayPopover: {
            background: "{overlay.popover.background}",
            borderColor: "{overlay.popover.border.color}",
            borderRadius: "{overlay.popover.border.radius}",
            color: "{overlay.popover.color}",
            shadow: "{overlay.popover.shadow}",
            padding: "{overlay.popover.padding}",
            gap: "0.5rem"
        },
        rule: {
            borderColor: "{content.border.color}"
        },
        constraintList: {
            padding: "{list.padding}",
            gap: "{list.gap}"
        },
        constraint: {
            focusBackground: "{list.option.focus.background}",
            selectedBackground: "{list.option.selected.background}",
            selectedFocusBackground: "{list.option.selected.focus.background}",
            color: "{list.option.color}",
            focusColor: "{list.option.focus.color}",
            selectedColor: "{list.option.selected.color}",
            selectedFocusColor: "{list.option.selected.focus.color}",
            separator: {
                borderColor: "{content.border.color}"
            },
            padding: "{list.option.padding}",
            borderRadius: "{list.option.border.radius}"
        }
    }, ua = {
        borderColor: "{datatable.border.color}",
        borderWidth: "0 0 1px 0"
    }, fa = {
        borderColor: "{datatable.border.color}",
        borderWidth: "0 0 1px 0"
    }, ga = {
        light: {
            root: {
                borderColor: "{content.border.color}"
            },
            row: {
                stripedBackground: "{surface.50}"
            },
            bodyCell: {
                selectedBorderColor: "{primary.100}"
            }
        },
        dark: {
            root: {
                borderColor: "{surface.800}"
            },
            row: {
                stripedBackground: "{surface.950}"
            },
            bodyCell: {
                selectedBorderColor: "{primary.900}"
            }
        }
    }, pa = {
        root: Kt,
        header: Ut,
        headerCell: Qt,
        columnTitle: Jt,
        row: Zt,
        bodyCell: oa,
        footerCell: ra,
        columnFooter: ea,
        footer: na,
        dropPoint: ta,
        columnResizer: aa,
        resizeIndicator: ca,
        sortIcon: ia,
        loadingIcon: da,
        rowToggleButton: la,
        filter: sa,
        paginatorTop: ua,
        paginatorBottom: fa,
        colorScheme: ga
    }, ma = {
        borderColor: "transparent",
        borderWidth: "0",
        borderRadius: "0",
        padding: "0"
    }, ba = {
        background: "{content.background}",
        color: "{content.color}",
        borderColor: "{content.border.color}",
        borderWidth: "0 0 1px 0",
        padding: "0.75rem 1rem",
        borderRadius: "0"
    }, ha = {
        background: "{content.background}",
        color: "{content.color}",
        borderColor: "transparent",
        borderWidth: "0",
        padding: "0",
        borderRadius: "0"
    }, va = {
        background: "{content.background}",
        color: "{content.color}",
        borderColor: "{content.border.color}",
        borderWidth: "1px 0 0 0",
        padding: "0.75rem 1rem",
        borderRadius: "0"
    }, ka = {
        borderColor: "{content.border.color}",
        borderWidth: "0 0 1px 0"
    }, ya = {
        borderColor: "{content.border.color}",
        borderWidth: "1px 0 0 0"
    }, Ca = {
        root: ma,
        header: ba,
        content: ha,
        footer: va,
        paginatorTop: ka,
        paginatorBottom: ya
    }, wa = {
        transitionDuration: "{transition.duration}"
    }, xa = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}",
        shadow: "{overlay.popover.shadow}",
        padding: "{overlay.popover.padding}"
    }, Ba = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        padding: "0 0 0.5rem 0"
    }, $a = {
        gap: "0.5rem",
        fontWeight: "500"
    }, Ra = {
        width: "2.5rem",
        sm: {
            width: "2rem"
        },
        lg: {
            width: "3rem"
        },
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.border.color}",
        activeBorderColor: "{form.field.border.color}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Sa = {
        color: "{form.field.icon.color}"
    }, za = {
        hoverBackground: "{content.hover.background}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        padding: "0.25rem 0.5rem",
        borderRadius: "{content.border.radius}"
    }, Ea = {
        hoverBackground: "{content.hover.background}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        padding: "0.25rem 0.5rem",
        borderRadius: "{content.border.radius}"
    }, Pa = {
        borderColor: "{content.border.color}",
        gap: "{overlay.popover.padding}"
    }, Oa = {
        margin: "0.5rem 0 0 0"
    }, _a = {
        padding: "0.25rem",
        fontWeight: "500",
        color: "{content.color}"
    }, Ia = {
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{primary.color}",
        rangeSelectedBackground: "{highlight.background}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        selectedColor: "{primary.contrast.color}",
        rangeSelectedColor: "{highlight.color}",
        width: "2rem",
        height: "2rem",
        borderRadius: "50%",
        padding: "0.25rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Da = {
        margin: "0.5rem 0 0 0"
    }, Wa = {
        padding: "0.375rem",
        borderRadius: "{content.border.radius}"
    }, Ta = {
        margin: "0.5rem 0 0 0"
    }, La = {
        padding: "0.375rem",
        borderRadius: "{content.border.radius}"
    }, Aa = {
        padding: "0.5rem 0 0 0",
        borderColor: "{content.border.color}"
    }, Ha = {
        padding: "0.5rem 0 0 0",
        borderColor: "{content.border.color}",
        gap: "0.5rem",
        buttonGap: "0.25rem"
    }, Ma = {
        light: {
            dropdown: {
                background: "{surface.100}",
                hoverBackground: "{surface.200}",
                activeBackground: "{surface.300}",
                color: "{surface.600}",
                hoverColor: "{surface.700}",
                activeColor: "{surface.800}"
            },
            today: {
                background: "{surface.200}",
                color: "{surface.900}"
            }
        },
        dark: {
            dropdown: {
                background: "{surface.800}",
                hoverBackground: "{surface.700}",
                activeBackground: "{surface.600}",
                color: "{surface.300}",
                hoverColor: "{surface.200}",
                activeColor: "{surface.100}"
            },
            today: {
                background: "{surface.700}",
                color: "{surface.0}"
            }
        }
    }, Fa = {
        root: wa,
        panel: xa,
        header: Ba,
        title: $a,
        dropdown: Ra,
        inputIcon: Sa,
        selectMonth: za,
        selectYear: Ea,
        group: Pa,
        dayView: Oa,
        weekDay: _a,
        date: Ia,
        monthView: Da,
        month: Wa,
        yearView: Ta,
        year: La,
        buttonbar: Aa,
        timePicker: Ha,
        colorScheme: Ma
    }, ja = {
        background: "{overlay.modal.background}",
        borderColor: "{overlay.modal.border.color}",
        color: "{overlay.modal.color}",
        borderRadius: "{overlay.modal.border.radius}",
        shadow: "{overlay.modal.shadow}"
    }, Na = {
        padding: "{overlay.modal.padding}",
        gap: "0.5rem"
    }, Va = {
        fontSize: "1.25rem",
        fontWeight: "600"
    }, Xa = {
        padding: "0 {overlay.modal.padding} {overlay.modal.padding} {overlay.modal.padding}"
    }, Ya = {
        padding: "0 {overlay.modal.padding} {overlay.modal.padding} {overlay.modal.padding}",
        gap: "0.5rem"
    }, Ga = {
        root: ja,
        header: Na,
        title: Va,
        content: Xa,
        footer: Ya
    }, qa = {
        borderColor: "{content.border.color}"
    }, Ka = {
        background: "{content.background}",
        color: "{text.color}"
    }, Ua = {
        margin: "1rem 0",
        padding: "0 1rem",
        content: {
            padding: "0 0.5rem"
        }
    }, Qa = {
        margin: "0 1rem",
        padding: "0.5rem 0",
        content: {
            padding: "0.5rem 0"
        }
    }, Ja = {
        root: qa,
        content: Ka,
        horizontal: Ua,
        vertical: Qa
    }, Za = {
        background: "rgba(255, 255, 255, 0.1)",
        borderColor: "rgba(255, 255, 255, 0.2)",
        padding: "0.5rem",
        borderRadius: "{border.radius.xl}"
    }, oc = {
        borderRadius: "{content.border.radius}",
        padding: "0.5rem",
        size: "3rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, rc = {
        root: Za,
        item: oc
    }, ec = {
        background: "{overlay.modal.background}",
        borderColor: "{overlay.modal.border.color}",
        color: "{overlay.modal.color}",
        shadow: "{overlay.modal.shadow}"
    }, nc = {
        padding: "{overlay.modal.padding}"
    }, tc = {
        fontSize: "1.5rem",
        fontWeight: "600"
    }, ac = {
        padding: "0 {overlay.modal.padding} {overlay.modal.padding} {overlay.modal.padding}"
    }, cc = {
        padding: "{overlay.modal.padding}"
    }, ic = {
        root: ec,
        header: nc,
        title: tc,
        content: ac,
        footer: cc
    }, dc = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}"
    }, lc = {
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        activeColor: "{primary.color}"
    }, sc = {
        background: "{overlay.select.background}",
        borderColor: "{overlay.select.border.color}",
        borderRadius: "{overlay.select.border.radius}",
        color: "{overlay.select.color}",
        shadow: "{overlay.select.shadow}",
        padding: "{list.padding}"
    }, uc = {
        focusBackground: "{list.option.focus.background}",
        color: "{list.option.color}",
        focusColor: "{list.option.focus.color}",
        padding: "{list.option.padding}",
        borderRadius: "{list.option.border.radius}"
    }, fc = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}"
    }, gc = {
        toolbar: dc,
        toolbarItem: lc,
        overlay: sc,
        overlayOption: uc,
        content: fc
    }, pc = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        color: "{content.color}",
        padding: "0 1.125rem 1.125rem 1.125rem",
        transitionDuration: "{transition.duration}"
    }, mc = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        borderRadius: "{content.border.radius}",
        borderWidth: "1px",
        borderColor: "transparent",
        padding: "0.5rem 0.75rem",
        gap: "0.5rem",
        fontWeight: "600",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, bc = {
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}"
    }, hc = {
        padding: "0"
    }, vc = {
        root: pc,
        legend: mc,
        toggleIcon: bc,
        content: hc
    }, kc = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}",
        transitionDuration: "{transition.duration}"
    }, yc = {
        background: "transparent",
        color: "{text.color}",
        padding: "1.125rem",
        borderColor: "unset",
        borderWidth: "0",
        borderRadius: "0",
        gap: "0.5rem"
    }, Cc = {
        highlightBorderColor: "{primary.color}",
        padding: "0 1.125rem 1.125rem 1.125rem",
        gap: "1rem"
    }, wc = {
        padding: "1rem",
        gap: "1rem",
        borderColor: "{content.border.color}",
        info: {
            gap: "0.5rem"
        }
    }, xc = {
        gap: "0.5rem"
    }, Bc = {
        height: "0.25rem"
    }, $c = {
        gap: "0.5rem"
    }, Rc = {
        root: kc,
        header: yc,
        content: Cc,
        file: wc,
        fileList: xc,
        progressbar: Bc,
        basic: $c
    }, Sc = {
        color: "{form.field.float.label.color}",
        focusColor: "{form.field.float.label.focus.color}",
        activeColor: "{form.field.float.label.active.color}",
        invalidColor: "{form.field.float.label.invalid.color}",
        transitionDuration: "0.2s",
        positionX: "{form.field.padding.x}",
        positionY: "{form.field.padding.y}",
        fontWeight: "500",
        active: {
            fontSize: "0.75rem",
            fontWeight: "400"
        }
    }, zc = {
        active: {
            top: "-1.25rem"
        }
    }, Ec = {
        input: {
            paddingTop: "1.5rem",
            paddingBottom: "{form.field.padding.y}"
        },
        active: {
            top: "{form.field.padding.y}"
        }
    }, Pc = {
        borderRadius: "{border.radius.xs}",
        active: {
            background: "{form.field.background}",
            padding: "0 0.125rem"
        }
    }, Oc = {
        root: Sc,
        over: zc,
        in: Ec,
        on: Pc
    }, _c = {
        borderWidth: "1px",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        transitionDuration: "{transition.duration}"
    }, Ic = {
        background: "rgba(255, 255, 255, 0.1)",
        hoverBackground: "rgba(255, 255, 255, 0.2)",
        color: "{surface.100}",
        hoverColor: "{surface.0}",
        size: "3rem",
        gutter: "0.5rem",
        prev: {
            borderRadius: "50%"
        },
        next: {
            borderRadius: "50%"
        },
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Dc = {
        size: "1.5rem"
    }, Wc = {
        background: "{content.background}",
        padding: "1rem 0.25rem"
    }, Tc = {
        size: "2rem",
        borderRadius: "{content.border.radius}",
        gutter: "0.5rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Lc = {
        size: "1rem"
    }, Ac = {
        background: "rgba(0, 0, 0, 0.5)",
        color: "{surface.100}",
        padding: "1rem"
    }, Hc = {
        gap: "0.5rem",
        padding: "1rem"
    }, Mc = {
        width: "1rem",
        height: "1rem",
        activeBackground: "{primary.color}",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Fc = {
        background: "rgba(0, 0, 0, 0.5)"
    }, jc = {
        background: "rgba(255, 255, 255, 0.4)",
        hoverBackground: "rgba(255, 255, 255, 0.6)",
        activeBackground: "rgba(255, 255, 255, 0.9)"
    }, Nc = {
        size: "3rem",
        gutter: "0.5rem",
        background: "rgba(255, 255, 255, 0.1)",
        hoverBackground: "rgba(255, 255, 255, 0.2)",
        color: "{surface.50}",
        hoverColor: "{surface.0}",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Vc = {
        size: "1.5rem"
    }, Xc = {
        light: {
            thumbnailNavButton: {
                hoverBackground: "{surface.100}",
                color: "{surface.600}",
                hoverColor: "{surface.700}"
            },
            indicatorButton: {
                background: "{surface.200}",
                hoverBackground: "{surface.300}"
            }
        },
        dark: {
            thumbnailNavButton: {
                hoverBackground: "{surface.700}",
                color: "{surface.400}",
                hoverColor: "{surface.0}"
            },
            indicatorButton: {
                background: "{surface.700}",
                hoverBackground: "{surface.600}"
            }
        }
    }, Yc = {
        root: _c,
        navButton: Ic,
        navIcon: Dc,
        thumbnailsContent: Wc,
        thumbnailNavButton: Tc,
        thumbnailNavButtonIcon: Lc,
        caption: Ac,
        indicatorList: Hc,
        indicatorButton: Mc,
        insetIndicatorList: Fc,
        insetIndicatorButton: jc,
        closeButton: Nc,
        closeButtonIcon: Vc,
        colorScheme: Xc
    }, Gc = {
        color: "{form.field.icon.color}"
    }, qc = {
        icon: Gc
    }, Kc = {
        color: "{form.field.float.label.color}",
        focusColor: "{form.field.float.label.focus.color}",
        invalidColor: "{form.field.float.label.invalid.color}",
        transitionDuration: "0.2s",
        positionX: "{form.field.padding.x}",
        top: "{form.field.padding.y}",
        fontSize: "0.75rem",
        fontWeight: "400"
    }, Uc = {
        paddingTop: "1.5rem",
        paddingBottom: "{form.field.padding.y}"
    }, Qc = {
        root: Kc,
        input: Uc
    }, Jc = {
        transitionDuration: "{transition.duration}"
    }, Zc = {
        icon: {
            size: "1.5rem"
        },
        mask: {
            background: "{mask.background}",
            color: "{mask.color}"
        }
    }, oi = {
        position: {
            left: "auto",
            right: "1rem",
            top: "1rem",
            bottom: "auto"
        },
        blur: "8px",
        background: "rgba(255,255,255,0.1)",
        borderColor: "rgba(255,255,255,0.2)",
        borderWidth: "1px",
        borderRadius: "30px",
        padding: ".5rem",
        gap: "0.5rem"
    }, ri = {
        hoverBackground: "rgba(255,255,255,0.1)",
        color: "{surface.50}",
        hoverColor: "{surface.0}",
        size: "3rem",
        iconSize: "1.5rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, ei = {
        root: Jc,
        preview: Zc,
        toolbar: oi,
        action: ri
    }, ni = {
        size: "15px",
        hoverSize: "30px",
        background: "rgba(255,255,255,0.3)",
        hoverBackground: "rgba(255,255,255,0.3)",
        borderColor: "unset",
        hoverBorderColor: "unset",
        borderWidth: "0",
        borderRadius: "50%",
        transitionDuration: "{transition.duration}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "rgba(255,255,255,0.3)",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, ti = {
        handle: ni
    }, ai = {
        padding: "{form.field.padding.y} {form.field.padding.x}",
        borderRadius: "{content.border.radius}",
        gap: "0.5rem"
    }, ci = {
        fontWeight: "500"
    }, ii = {
        size: "1rem"
    }, di = {
        light: {
            info: {
                background: "color-mix(in srgb, {blue.50}, transparent 5%)",
                borderColor: "{blue.200}",
                color: "{blue.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)"
            },
            success: {
                background: "color-mix(in srgb, {green.50}, transparent 5%)",
                borderColor: "{green.200}",
                color: "{green.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)"
            },
            warn: {
                background: "color-mix(in srgb,{yellow.50}, transparent 5%)",
                borderColor: "{yellow.200}",
                color: "{yellow.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)"
            },
            error: {
                background: "color-mix(in srgb, {red.50}, transparent 5%)",
                borderColor: "{red.200}",
                color: "{red.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)"
            },
            secondary: {
                background: "{surface.100}",
                borderColor: "{surface.200}",
                color: "{surface.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)"
            },
            contrast: {
                background: "{surface.900}",
                borderColor: "{surface.950}",
                color: "{surface.50}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)"
            }
        },
        dark: {
            info: {
                background: "color-mix(in srgb, {blue.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {blue.700}, transparent 64%)",
                color: "{blue.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)"
            },
            success: {
                background: "color-mix(in srgb, {green.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {green.700}, transparent 64%)",
                color: "{green.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)"
            },
            warn: {
                background: "color-mix(in srgb, {yellow.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {yellow.700}, transparent 64%)",
                color: "{yellow.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)"
            },
            error: {
                background: "color-mix(in srgb, {red.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {red.700}, transparent 64%)",
                color: "{red.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)"
            },
            secondary: {
                background: "{surface.800}",
                borderColor: "{surface.700}",
                color: "{surface.300}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)"
            },
            contrast: {
                background: "{surface.0}",
                borderColor: "{surface.100}",
                color: "{surface.950}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)"
            }
        }
    }, li = {
        root: ai,
        text: ci,
        icon: ii,
        colorScheme: di
    }, si = {
        padding: "{form.field.padding.y} {form.field.padding.x}",
        borderRadius: "{content.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        transitionDuration: "{transition.duration}"
    }, ui = {
        hoverBackground: "{content.hover.background}",
        hoverColor: "{content.hover.color}"
    }, fi = {
        root: si,
        display: ui
    }, gi = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}"
    }, pi = {
        borderRadius: "{border.radius.sm}"
    }, mi = {
        light: {
            chip: {
                focusBackground: "{surface.200}",
                color: "{surface.800}"
            }
        },
        dark: {
            chip: {
                focusBackground: "{surface.700}",
                color: "{surface.0}"
            }
        }
    }, bi = {
        root: gi,
        chip: pi,
        colorScheme: mi
    }, hi = {
        background: "{form.field.background}",
        borderColor: "{form.field.border.color}",
        color: "{form.field.icon.color}",
        borderRadius: "{form.field.border.radius}",
        padding: "0.5rem",
        minWidth: "2.5rem"
    }, vi = {
        addon: hi
    }, ki = {
        transitionDuration: "{transition.duration}"
    }, yi = {
        width: "2.5rem",
        borderRadius: "{form.field.border.radius}",
        verticalPadding: "{form.field.padding.y}"
    }, Ci = {
        light: {
            button: {
                background: "transparent",
                hoverBackground: "{surface.100}",
                activeBackground: "{surface.200}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.border.color}",
                activeBorderColor: "{form.field.border.color}",
                color: "{surface.400}",
                hoverColor: "{surface.500}",
                activeColor: "{surface.600}"
            }
        },
        dark: {
            button: {
                background: "transparent",
                hoverBackground: "{surface.800}",
                activeBackground: "{surface.700}",
                borderColor: "{form.field.border.color}",
                hoverBorderColor: "{form.field.border.color}",
                activeBorderColor: "{form.field.border.color}",
                color: "{surface.400}",
                hoverColor: "{surface.300}",
                activeColor: "{surface.200}"
            }
        }
    }, wi = {
        root: ki,
        button: yi,
        colorScheme: Ci
    }, xi = {
        gap: "0.5rem"
    }, Bi = {
        width: "2.5rem",
        sm: {
            width: "2rem"
        },
        lg: {
            width: "3rem"
        }
    }, $i = {
        root: xi,
        input: Bi
    }, Ri = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}"
        }
    }, Si = {
        root: Ri
    }, zi = {
        transitionDuration: "{transition.duration}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Ei = {
        background: "{primary.color}"
    }, Pi = {
        background: "{content.border.color}"
    }, Oi = {
        color: "{text.muted.color}"
    }, _i = {
        root: zi,
        value: Ei,
        range: Pi,
        text: Oi
    }, Ii = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        borderColor: "{form.field.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        shadow: "{form.field.shadow}",
        borderRadius: "{form.field.border.radius}",
        transitionDuration: "{form.field.transition.duration}"
    }, Di = {
        padding: "{list.padding}",
        gap: "{list.gap}",
        header: {
            padding: "{list.header.padding}"
        }
    }, Wi = {
        focusBackground: "{list.option.focus.background}",
        selectedBackground: "{list.option.selected.background}",
        selectedFocusBackground: "{list.option.selected.focus.background}",
        color: "{list.option.color}",
        focusColor: "{list.option.focus.color}",
        selectedColor: "{list.option.selected.color}",
        selectedFocusColor: "{list.option.selected.focus.color}",
        padding: "{list.option.padding}",
        borderRadius: "{list.option.border.radius}"
    }, Ti = {
        background: "{list.option.group.background}",
        color: "{list.option.group.color}",
        fontWeight: "{list.option.group.font.weight}",
        padding: "{list.option.group.padding}"
    }, Li = {
        color: "{list.option.color}",
        gutterStart: "-0.375rem",
        gutterEnd: "0.375rem"
    }, Ai = {
        padding: "{list.option.padding}"
    }, Hi = {
        light: {
            option: {
                stripedBackground: "{surface.50}"
            }
        },
        dark: {
            option: {
                stripedBackground: "{surface.900}"
            }
        }
    }, Mi = {
        root: Ii,
        list: Di,
        option: Wi,
        optionGroup: Ti,
        checkmark: Li,
        emptyMessage: Ai,
        colorScheme: Hi
    }, Fi = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        color: "{content.color}",
        gap: "0.5rem",
        verticalOrientation: {
            padding: "{navigation.list.padding}",
            gap: "{navigation.list.gap}"
        },
        horizontalOrientation: {
            padding: "0.5rem 0.75rem",
            gap: "0.5rem"
        },
        transitionDuration: "{transition.duration}"
    }, ji = {
        borderRadius: "{content.border.radius}",
        padding: "{navigation.item.padding}"
    }, Ni = {
        focusBackground: "{navigation.item.focus.background}",
        activeBackground: "{navigation.item.active.background}",
        color: "{navigation.item.color}",
        focusColor: "{navigation.item.focus.color}",
        activeColor: "{navigation.item.active.color}",
        padding: "{navigation.item.padding}",
        borderRadius: "{navigation.item.border.radius}",
        gap: "{navigation.item.gap}",
        icon: {
            color: "{navigation.item.icon.color}",
            focusColor: "{navigation.item.icon.focus.color}",
            activeColor: "{navigation.item.icon.active.color}"
        }
    }, Vi = {
        padding: "0",
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        color: "{content.color}",
        shadow: "{overlay.navigation.shadow}",
        gap: "0.5rem"
    }, Xi = {
        padding: "{navigation.list.padding}",
        gap: "{navigation.list.gap}"
    }, Yi = {
        padding: "{navigation.submenu.label.padding}",
        fontWeight: "{navigation.submenu.label.font.weight}",
        background: "{navigation.submenu.label.background.}",
        color: "{navigation.submenu.label.color}"
    }, Gi = {
        size: "{navigation.submenu.icon.size}",
        color: "{navigation.submenu.icon.color}",
        focusColor: "{navigation.submenu.icon.focus.color}",
        activeColor: "{navigation.submenu.icon.active.color}"
    }, qi = {
        borderColor: "{content.border.color}"
    }, Ki = {
        borderRadius: "50%",
        size: "1.75rem",
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        hoverBackground: "{content.hover.background}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Ui = {
        root: Fi,
        baseItem: ji,
        item: Ni,
        overlay: Vi,
        submenu: Xi,
        submenuLabel: Yi,
        submenuIcon: Gi,
        separator: qi,
        mobileButton: Ki
    }, Qi = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}",
        shadow: "{overlay.navigation.shadow}",
        transitionDuration: "{transition.duration}"
    }, Ji = {
        padding: "{navigation.list.padding}",
        gap: "{navigation.list.gap}"
    }, Zi = {
        focusBackground: "{navigation.item.focus.background}",
        color: "{navigation.item.color}",
        focusColor: "{navigation.item.focus.color}",
        padding: "{navigation.item.padding}",
        borderRadius: "{navigation.item.border.radius}",
        gap: "{navigation.item.gap}",
        icon: {
            color: "{navigation.item.icon.color}",
            focusColor: "{navigation.item.icon.focus.color}"
        }
    }, od = {
        padding: "{navigation.submenu.label.padding}",
        fontWeight: "{navigation.submenu.label.font.weight}",
        background: "{navigation.submenu.label.background}",
        color: "{navigation.submenu.label.color}"
    }, rd = {
        borderColor: "{content.border.color}"
    }, ed = {
        root: Qi,
        list: Ji,
        item: Zi,
        submenuLabel: od,
        separator: rd
    }, nd = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        color: "{content.color}",
        gap: "0.5rem",
        padding: "0.5rem 0.75rem",
        transitionDuration: "{transition.duration}"
    }, td = {
        borderRadius: "{content.border.radius}",
        padding: "{navigation.item.padding}"
    }, ad = {
        focusBackground: "{navigation.item.focus.background}",
        activeBackground: "{navigation.item.active.background}",
        color: "{navigation.item.color}",
        focusColor: "{navigation.item.focus.color}",
        activeColor: "{navigation.item.active.color}",
        padding: "{navigation.item.padding}",
        borderRadius: "{navigation.item.border.radius}",
        gap: "{navigation.item.gap}",
        icon: {
            color: "{navigation.item.icon.color}",
            focusColor: "{navigation.item.icon.focus.color}",
            activeColor: "{navigation.item.icon.active.color}"
        }
    }, cd = {
        padding: "{navigation.list.padding}",
        gap: "{navigation.list.gap}",
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        shadow: "{overlay.navigation.shadow}",
        mobileIndent: "1rem",
        icon: {
            size: "{navigation.submenu.icon.size}",
            color: "{navigation.submenu.icon.color}",
            focusColor: "{navigation.submenu.icon.focus.color}",
            activeColor: "{navigation.submenu.icon.active.color}"
        }
    }, id = {
        borderColor: "{content.border.color}"
    }, dd = {
        borderRadius: "50%",
        size: "1.75rem",
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        hoverBackground: "{content.hover.background}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, ld = {
        root: nd,
        baseItem: td,
        item: ad,
        submenu: cd,
        separator: id,
        mobileButton: dd
    }, sd = {
        borderRadius: "{content.border.radius}",
        borderWidth: "1px",
        transitionDuration: "{transition.duration}"
    }, ud = {
        padding: "0.5rem 0.75rem",
        gap: "0.5rem",
        sm: {
            padding: "0.375rem 0.625rem"
        },
        lg: {
            padding: "0.625rem 0.875rem"
        }
    }, fd = {
        fontSize: "1rem",
        fontWeight: "500",
        sm: {
            fontSize: "0.875rem"
        },
        lg: {
            fontSize: "1.125rem"
        }
    }, gd = {
        size: "1.125rem",
        sm: {
            size: "1rem"
        },
        lg: {
            size: "1.25rem"
        }
    }, pd = {
        width: "1.75rem",
        height: "1.75rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            offset: "{focus.ring.offset}"
        }
    }, md = {
        size: "1rem",
        sm: {
            size: "0.875rem"
        },
        lg: {
            size: "1.125rem"
        }
    }, bd = {
        root: {
            borderWidth: "1px"
        }
    }, hd = {
        content: {
            padding: "0"
        }
    }, vd = {
        light: {
            info: {
                background: "color-mix(in srgb, {blue.50}, transparent 5%)",
                borderColor: "{blue.200}",
                color: "{blue.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{blue.100}",
                    focusRing: {
                        color: "{blue.600}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{blue.600}",
                    borderColor: "{blue.600}"
                },
                simple: {
                    color: "{blue.600}"
                }
            },
            success: {
                background: "color-mix(in srgb, {green.50}, transparent 5%)",
                borderColor: "{green.200}",
                color: "{green.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{green.100}",
                    focusRing: {
                        color: "{green.600}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{green.600}",
                    borderColor: "{green.600}"
                },
                simple: {
                    color: "{green.600}"
                }
            },
            warn: {
                background: "color-mix(in srgb,{yellow.50}, transparent 5%)",
                borderColor: "{yellow.200}",
                color: "{yellow.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{yellow.100}",
                    focusRing: {
                        color: "{yellow.600}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{yellow.600}",
                    borderColor: "{yellow.600}"
                },
                simple: {
                    color: "{yellow.600}"
                }
            },
            error: {
                background: "color-mix(in srgb, {red.50}, transparent 5%)",
                borderColor: "{red.200}",
                color: "{red.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{red.100}",
                    focusRing: {
                        color: "{red.600}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{red.600}",
                    borderColor: "{red.600}"
                },
                simple: {
                    color: "{red.600}"
                }
            },
            secondary: {
                background: "{surface.100}",
                borderColor: "{surface.200}",
                color: "{surface.600}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.200}",
                    focusRing: {
                        color: "{surface.600}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{surface.500}",
                    borderColor: "{surface.500}"
                },
                simple: {
                    color: "{surface.500}"
                }
            },
            contrast: {
                background: "{surface.900}",
                borderColor: "{surface.950}",
                color: "{surface.50}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.800}",
                    focusRing: {
                        color: "{surface.50}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{surface.950}",
                    borderColor: "{surface.950}"
                },
                simple: {
                    color: "{surface.950}"
                }
            }
        },
        dark: {
            info: {
                background: "color-mix(in srgb, {blue.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {blue.700}, transparent 64%)",
                color: "{blue.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{blue.500}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{blue.500}",
                    borderColor: "{blue.500}"
                },
                simple: {
                    color: "{blue.500}"
                }
            },
            success: {
                background: "color-mix(in srgb, {green.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {green.700}, transparent 64%)",
                color: "{green.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{green.500}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{green.500}",
                    borderColor: "{green.500}"
                },
                simple: {
                    color: "{green.500}"
                }
            },
            warn: {
                background: "color-mix(in srgb, {yellow.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {yellow.700}, transparent 64%)",
                color: "{yellow.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{yellow.500}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{yellow.500}",
                    borderColor: "{yellow.500}"
                },
                simple: {
                    color: "{yellow.500}"
                }
            },
            error: {
                background: "color-mix(in srgb, {red.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {red.700}, transparent 64%)",
                color: "{red.500}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{red.500}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{red.500}",
                    borderColor: "{red.500}"
                },
                simple: {
                    color: "{red.500}"
                }
            },
            secondary: {
                background: "{surface.800}",
                borderColor: "{surface.700}",
                color: "{surface.300}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.700}",
                    focusRing: {
                        color: "{surface.300}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{surface.400}",
                    borderColor: "{surface.400}"
                },
                simple: {
                    color: "{surface.400}"
                }
            },
            contrast: {
                background: "{surface.0}",
                borderColor: "{surface.100}",
                color: "{surface.950}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.100}",
                    focusRing: {
                        color: "{surface.950}",
                        shadow: "none"
                    }
                },
                outlined: {
                    color: "{surface.0}",
                    borderColor: "{surface.0}"
                },
                simple: {
                    color: "{surface.0}"
                }
            }
        }
    }, kd = {
        root: sd,
        content: ud,
        text: fd,
        icon: gd,
        closeButton: pd,
        closeIcon: md,
        outlined: bd,
        simple: hd,
        colorScheme: vd
    }, yd = {
        borderRadius: "{content.border.radius}",
        gap: "1rem"
    }, Cd = {
        background: "{content.border.color}",
        size: "0.5rem"
    }, wd = {
        gap: "0.5rem"
    }, xd = {
        size: "0.5rem"
    }, Bd = {
        size: "1rem"
    }, $d = {
        verticalGap: "0.5rem",
        horizontalGap: "1rem"
    }, Rd = {
        root: yd,
        meters: Cd,
        label: wd,
        labelMarker: xd,
        labelIcon: Bd,
        labelList: $d
    }, Sd = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}"
        }
    }, zd = {
        width: "2.5rem",
        color: "{form.field.icon.color}"
    }, Ed = {
        background: "{overlay.select.background}",
        borderColor: "{overlay.select.border.color}",
        borderRadius: "{overlay.select.border.radius}",
        color: "{overlay.select.color}",
        shadow: "{overlay.select.shadow}"
    }, Pd = {
        padding: "{list.padding}",
        gap: "{list.gap}",
        header: {
            padding: "{list.header.padding}"
        }
    }, Od = {
        focusBackground: "{list.option.focus.background}",
        selectedBackground: "{list.option.selected.background}",
        selectedFocusBackground: "{list.option.selected.focus.background}",
        color: "{list.option.color}",
        focusColor: "{list.option.focus.color}",
        selectedColor: "{list.option.selected.color}",
        selectedFocusColor: "{list.option.selected.focus.color}",
        padding: "{list.option.padding}",
        borderRadius: "{list.option.border.radius}",
        gap: "0.5rem"
    }, _d = {
        background: "{list.option.group.background}",
        color: "{list.option.group.color}",
        fontWeight: "{list.option.group.font.weight}",
        padding: "{list.option.group.padding}"
    }, Id = {
        color: "{form.field.icon.color}"
    }, Dd = {
        borderRadius: "{border.radius.sm}"
    }, Wd = {
        padding: "{list.option.padding}"
    }, Td = {
        root: Sd,
        dropdown: zd,
        overlay: Ed,
        list: Pd,
        option: Od,
        optionGroup: _d,
        chip: Dd,
        clearIcon: Id,
        emptyMessage: Wd
    }, Ld = {
        gap: "1.125rem"
    }, Ad = {
        gap: "0.5rem"
    }, Hd = {
        root: Ld,
        controls: Ad
    }, Md = {
        gutter: "0.75rem",
        transitionDuration: "{transition.duration}"
    }, Fd = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        selectedColor: "{highlight.color}",
        hoverColor: "{content.hover.color}",
        padding: "0.75rem 1rem",
        toggleablePadding: "0.75rem 1rem 1.25rem 1rem",
        borderRadius: "{content.border.radius}"
    }, jd = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        borderColor: "{content.border.color}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        size: "1.5rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Nd = {
        color: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        height: "24px"
    }, Vd = {
        root: Md,
        node: Fd,
        nodeToggleButton: jd,
        connector: Nd
    }, Xd = {
        outline: {
            width: "2px",
            color: "{content.background}"
        }
    }, Yd = {
        root: Xd
    }, Gd = {
        padding: "0.5rem 1rem",
        gap: "0.25rem",
        borderRadius: "{content.border.radius}",
        background: "{content.background}",
        color: "{content.color}",
        transitionDuration: "{transition.duration}"
    }, qd = {
        background: "transparent",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        selectedColor: "{highlight.color}",
        width: "2.5rem",
        height: "2.5rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Kd = {
        color: "{text.muted.color}"
    }, Ud = {
        maxWidth: "2.5rem"
    }, Qd = {
        root: Gd,
        navButton: qd,
        currentPageReport: Kd,
        jumpToPageInput: Ud
    }, Jd = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}"
    }, Zd = {
        background: "transparent",
        color: "{text.color}",
        padding: "1.125rem",
        borderColor: "{content.border.color}",
        borderWidth: "0",
        borderRadius: "0"
    }, ol = {
        padding: "0.375rem 1.125rem"
    }, rl = {
        fontWeight: "600"
    }, el = {
        padding: "0 1.125rem 1.125rem 1.125rem"
    }, nl = {
        padding: "0 1.125rem 1.125rem 1.125rem"
    }, tl = {
        root: Jd,
        header: Zd,
        toggleableHeader: ol,
        title: rl,
        content: el,
        footer: nl
    }, al = {
        gap: "0.5rem",
        transitionDuration: "{transition.duration}"
    }, cl = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderWidth: "1px",
        color: "{content.color}",
        padding: "0.25rem 0.25rem",
        borderRadius: "{content.border.radius}",
        first: {
            borderWidth: "1px",
            topBorderRadius: "{content.border.radius}"
        },
        last: {
            borderWidth: "1px",
            bottomBorderRadius: "{content.border.radius}"
        }
    }, il = {
        focusBackground: "{navigation.item.focus.background}",
        color: "{navigation.item.color}",
        focusColor: "{navigation.item.focus.color}",
        gap: "0.5rem",
        padding: "{navigation.item.padding}",
        borderRadius: "{content.border.radius}",
        icon: {
            color: "{navigation.item.icon.color}",
            focusColor: "{navigation.item.icon.focus.color}"
        }
    }, dl = {
        indent: "1rem"
    }, ll = {
        color: "{navigation.submenu.icon.color}",
        focusColor: "{navigation.submenu.icon.focus.color}"
    }, sl = {
        root: al,
        panel: cl,
        item: il,
        submenu: dl,
        submenuIcon: ll
    }, ul = {
        background: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        height: ".75rem"
    }, fl = {
        color: "{form.field.icon.color}"
    }, gl = {
        background: "{overlay.popover.background}",
        borderColor: "{overlay.popover.border.color}",
        borderRadius: "{overlay.popover.border.radius}",
        color: "{overlay.popover.color}",
        padding: "{overlay.popover.padding}",
        shadow: "{overlay.popover.shadow}"
    }, pl = {
        gap: "0.5rem"
    }, ml = {
        light: {
            strength: {
                weakBackground: "{red.500}",
                mediumBackground: "{amber.500}",
                strongBackground: "{green.500}"
            }
        },
        dark: {
            strength: {
                weakBackground: "{red.400}",
                mediumBackground: "{amber.400}",
                strongBackground: "{green.400}"
            }
        }
    }, bl = {
        meter: ul,
        icon: fl,
        overlay: gl,
        content: pl,
        colorScheme: ml
    }, hl = {
        gap: "1.125rem"
    }, vl = {
        gap: "0.5rem"
    }, kl = {
        root: hl,
        controls: vl
    }, yl = {
        background: "{overlay.popover.background}",
        borderColor: "{overlay.popover.border.color}",
        color: "{overlay.popover.color}",
        borderRadius: "{overlay.popover.border.radius}",
        shadow: "{overlay.popover.shadow}",
        gutter: "10px",
        arrowOffset: "1.25rem"
    }, Cl = {
        padding: "{overlay.popover.padding}"
    }, wl = {
        root: yl,
        content: Cl
    }, xl = {
        background: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        height: "1.25rem"
    }, Bl = {
        background: "{primary.color}"
    }, $l = {
        color: "{primary.contrast.color}",
        fontSize: "0.75rem",
        fontWeight: "600"
    }, Rl = {
        root: xl,
        value: Bl,
        label: $l
    }, Sl = {
        light: {
            root: {
                colorOne: "{red.500}",
                colorTwo: "{blue.500}",
                colorThree: "{green.500}",
                colorFour: "{yellow.500}"
            }
        },
        dark: {
            root: {
                colorOne: "{red.400}",
                colorTwo: "{blue.400}",
                colorThree: "{green.400}",
                colorFour: "{yellow.400}"
            }
        }
    }, zl = {
        colorScheme: Sl
    }, El = {
        width: "1.25rem",
        height: "1.25rem",
        background: "{form.field.background}",
        checkedBackground: "{primary.color}",
        checkedHoverBackground: "{primary.hover.color}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.border.color}",
        checkedBorderColor: "{primary.color}",
        checkedHoverBorderColor: "{primary.hover.color}",
        checkedFocusBorderColor: "{primary.color}",
        checkedDisabledBorderColor: "{form.field.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        shadow: "{form.field.shadow}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            width: "1rem",
            height: "1rem"
        },
        lg: {
            width: "1.5rem",
            height: "1.5rem"
        }
    }, Pl = {
        size: "0.75rem",
        checkedColor: "{primary.contrast.color}",
        checkedHoverColor: "{primary.contrast.color}",
        disabledColor: "{form.field.disabled.color}",
        sm: {
            size: "0.5rem"
        },
        lg: {
            size: "1rem"
        }
    }, Ol = {
        root: El,
        icon: Pl
    }, _l = {
        gap: "0.25rem",
        transitionDuration: "{transition.duration}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Il = {
        size: "1rem",
        color: "{text.muted.color}",
        hoverColor: "{primary.color}",
        activeColor: "{primary.color}"
    }, Dl = {
        root: _l,
        icon: Il
    }, Wl = {
        light: {
            root: {
                background: "rgba(0,0,0,0.1)"
            }
        },
        dark: {
            root: {
                background: "rgba(255,255,255,0.3)"
            }
        }
    }, Tl = {
        colorScheme: Wl
    }, Ll = {
        transitionDuration: "{transition.duration}"
    }, Al = {
        size: "9px",
        borderRadius: "{border.radius.sm}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Hl = {
        light: {
            bar: {
                background: "{surface.100}"
            }
        },
        dark: {
            bar: {
                background: "{surface.800}"
            }
        }
    }, Ml = {
        root: Ll,
        bar: Al,
        colorScheme: Hl
    }, Fl = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}"
        }
    }, jl = {
        width: "2.5rem",
        color: "{form.field.icon.color}"
    }, Nl = {
        background: "{overlay.select.background}",
        borderColor: "{overlay.select.border.color}",
        borderRadius: "{overlay.select.border.radius}",
        color: "{overlay.select.color}",
        shadow: "{overlay.select.shadow}"
    }, Vl = {
        padding: "{list.padding}",
        gap: "{list.gap}",
        header: {
            padding: "{list.header.padding}"
        }
    }, Xl = {
        focusBackground: "{list.option.focus.background}",
        selectedBackground: "{list.option.selected.background}",
        selectedFocusBackground: "{list.option.selected.focus.background}",
        color: "{list.option.color}",
        focusColor: "{list.option.focus.color}",
        selectedColor: "{list.option.selected.color}",
        selectedFocusColor: "{list.option.selected.focus.color}",
        padding: "{list.option.padding}",
        borderRadius: "{list.option.border.radius}"
    }, Yl = {
        background: "{list.option.group.background}",
        color: "{list.option.group.color}",
        fontWeight: "{list.option.group.font.weight}",
        padding: "{list.option.group.padding}"
    }, Gl = {
        color: "{form.field.icon.color}"
    }, ql = {
        color: "{list.option.color}",
        gutterStart: "-0.375rem",
        gutterEnd: "0.375rem"
    }, Kl = {
        padding: "{list.option.padding}"
    }, Ul = {
        root: Fl,
        dropdown: jl,
        overlay: Nl,
        list: Vl,
        option: Xl,
        optionGroup: Yl,
        clearIcon: Gl,
        checkmark: ql,
        emptyMessage: Kl
    }, Ql = {
        borderRadius: "{form.field.border.radius}"
    }, Jl = {
        light: {
            root: {
                invalidBorderColor: "{form.field.invalid.border.color}"
            }
        },
        dark: {
            root: {
                invalidBorderColor: "{form.field.invalid.border.color}"
            }
        }
    }, Zl = {
        root: Ql,
        colorScheme: Jl
    }, os = {
        borderRadius: "{content.border.radius}"
    }, rs = {
        light: {
            root: {
                background: "{surface.200}",
                animationBackground: "rgba(255,255,255,0.4)"
            }
        },
        dark: {
            root: {
                background: "rgba(255, 255, 255, 0.06)",
                animationBackground: "rgba(255, 255, 255, 0.04)"
            }
        }
    }, es = {
        root: os,
        colorScheme: rs
    }, ns = {
        transitionDuration: "{transition.duration}"
    }, ts = {
        background: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        size: "3px"
    }, as = {
        background: "{primary.color}"
    }, cs = {
        width: "20px",
        height: "20px",
        borderRadius: "50%",
        background: "{content.border.color}",
        hoverBackground: "{content.border.color}",
        content: {
            borderRadius: "50%",
            hoverBackground: "{content.background}",
            width: "16px",
            height: "16px",
            shadow: "0px 0.5px 0px 0px rgba(0, 0, 0, 0.08), 0px 1px 1px 0px rgba(0, 0, 0, 0.14)"
        },
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, is = {
        light: {
            handle: {
                content: {
                    background: "{surface.0}"
                }
            }
        },
        dark: {
            handle: {
                content: {
                    background: "{surface.950}"
                }
            }
        }
    }, ds = {
        root: ns,
        track: ts,
        range: as,
        handle: cs,
        colorScheme: is
    }, ls = {
        gap: "0.5rem",
        transitionDuration: "{transition.duration}"
    }, ss = {
        root: ls
    }, us = {
        borderRadius: "{form.field.border.radius}",
        roundedBorderRadius: "2rem",
        raisedShadow: "0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 1px 5px 0 rgba(0, 0, 0, 0.12)"
    }, fs = {
        root: us
    }, gs = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        transitionDuration: "{transition.duration}"
    }, ps = {
        background: "{content.border.color}"
    }, ms = {
        size: "24px",
        background: "transparent",
        borderRadius: "{content.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, bs = {
        root: gs,
        gutter: ps,
        handle: ms
    }, hs = {
        transitionDuration: "{transition.duration}"
    }, vs = {
        background: "{content.border.color}",
        activeBackground: "{primary.color}",
        margin: "0 0 0 1.625rem",
        size: "2px"
    }, ks = {
        padding: "0.5rem",
        gap: "1rem"
    }, ys = {
        padding: "0",
        borderRadius: "{content.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        gap: "0.5rem"
    }, Cs = {
        color: "{text.muted.color}",
        activeColor: "{primary.color}",
        fontWeight: "500"
    }, ws = {
        background: "{content.background}",
        activeBackground: "{content.background}",
        borderColor: "{content.border.color}",
        activeBorderColor: "{content.border.color}",
        color: "{text.muted.color}",
        activeColor: "{primary.color}",
        size: "2rem",
        fontSize: "1.143rem",
        fontWeight: "500",
        borderRadius: "50%",
        shadow: "0px 0.5px 0px 0px rgba(0, 0, 0, 0.06), 0px 1px 1px 0px rgba(0, 0, 0, 0.12)"
    }, xs = {
        padding: "0.875rem 0.5rem 1.125rem 0.5rem"
    }, Bs = {
        background: "{content.background}",
        color: "{content.color}",
        padding: "0",
        indent: "1rem"
    }, $s = {
        root: hs,
        separator: vs,
        step: ks,
        stepHeader: ys,
        stepTitle: Cs,
        stepNumber: ws,
        steppanels: xs,
        steppanel: Bs
    }, Rs = {
        transitionDuration: "{transition.duration}"
    }, Ss = {
        background: "{content.border.color}"
    }, zs = {
        borderRadius: "{content.border.radius}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        gap: "0.5rem"
    }, Es = {
        color: "{text.muted.color}",
        activeColor: "{primary.color}",
        fontWeight: "500"
    }, Ps = {
        background: "{content.background}",
        activeBackground: "{content.background}",
        borderColor: "{content.border.color}",
        activeBorderColor: "{content.border.color}",
        color: "{text.muted.color}",
        activeColor: "{primary.color}",
        size: "2rem",
        fontSize: "1.143rem",
        fontWeight: "500",
        borderRadius: "50%",
        shadow: "0px 0.5px 0px 0px rgba(0, 0, 0, 0.06), 0px 1px 1px 0px rgba(0, 0, 0, 0.12)"
    }, Os = {
        root: Rs,
        separator: Ss,
        itemLink: zs,
        itemLabel: Es,
        itemNumber: Ps
    }, _s = {
        transitionDuration: "{transition.duration}"
    }, Is = {
        borderWidth: "0 0 1px 0",
        background: "{content.background}",
        borderColor: "{content.border.color}"
    }, Ds = {
        background: "transparent",
        hoverBackground: "transparent",
        activeBackground: "transparent",
        borderWidth: "0 0 1px 0",
        borderColor: "{content.border.color}",
        hoverBorderColor: "{content.border.color}",
        activeBorderColor: "{primary.color}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        activeColor: "{primary.color}",
        padding: "1rem 1.125rem",
        fontWeight: "600",
        margin: "0 0 -1px 0",
        gap: "0.5rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Ws = {
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        activeColor: "{primary.color}"
    }, Ts = {
        height: "1px",
        bottom: "-1px",
        background: "{primary.color}"
    }, Ls = {
        root: _s,
        tablist: Is,
        item: Ds,
        itemIcon: Ws,
        activeBar: Ts
    }, As = {
        transitionDuration: "{transition.duration}"
    }, Hs = {
        borderWidth: "0 0 1px 0",
        background: "{content.background}",
        borderColor: "{content.border.color}"
    }, Ms = {
        background: "transparent",
        hoverBackground: "transparent",
        activeBackground: "transparent",
        borderWidth: "0 0 1px 0",
        borderColor: "{content.border.color}",
        hoverBorderColor: "{content.border.color}",
        activeBorderColor: "{primary.color}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        activeColor: "{primary.color}",
        padding: "1rem 1.125rem",
        fontWeight: "600",
        margin: "0 0 -1px 0",
        gap: "0.5rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        }
    }, Fs = {
        background: "{content.background}",
        color: "{content.color}",
        padding: "0.875rem 1.125rem 1.125rem 1.125rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "inset {focus.ring.shadow}"
        }
    }, js = {
        background: "{content.background}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        width: "2.5rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        }
    }, Ns = {
        height: "1px",
        bottom: "-1px",
        background: "{primary.color}"
    }, Vs = {
        light: {
            navButton: {
                shadow: "0px 0px 10px 50px rgba(255, 255, 255, 0.6)"
            }
        },
        dark: {
            navButton: {
                shadow: "0px 0px 10px 50px color-mix(in srgb, {content.background}, transparent 50%)"
            }
        }
    }, Xs = {
        root: As,
        tablist: Hs,
        tab: Ms,
        tabpanel: Fs,
        navButton: js,
        activeBar: Ns,
        colorScheme: Vs
    }, Ys = {
        transitionDuration: "{transition.duration}"
    }, Gs = {
        background: "{content.background}",
        borderColor: "{content.border.color}"
    }, qs = {
        borderColor: "{content.border.color}",
        activeBorderColor: "{primary.color}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        activeColor: "{primary.color}"
    }, Ks = {
        background: "{content.background}",
        color: "{content.color}"
    }, Us = {
        background: "{content.background}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}"
    }, Qs = {
        light: {
            navButton: {
                shadow: "0px 0px 10px 50px rgba(255, 255, 255, 0.6)"
            }
        },
        dark: {
            navButton: {
                shadow: "0px 0px 10px 50px color-mix(in srgb, {content.background}, transparent 50%)"
            }
        }
    }, Js = {
        root: Ys,
        tabList: Gs,
        tab: qs,
        tabPanel: Ks,
        navButton: Us,
        colorScheme: Qs
    }, Zs = {
        fontSize: "0.875rem",
        fontWeight: "700",
        padding: "0.25rem 0.5rem",
        gap: "0.25rem",
        borderRadius: "{content.border.radius}",
        roundedBorderRadius: "{border.radius.xl}"
    }, ou = {
        size: "0.75rem"
    }, ru = {
        light: {
            primary: {
                background: "{primary.100}",
                color: "{primary.700}"
            },
            secondary: {
                background: "{surface.100}",
                color: "{surface.600}"
            },
            success: {
                background: "{green.100}",
                color: "{green.700}"
            },
            info: {
                background: "{sky.100}",
                color: "{sky.700}"
            },
            warn: {
                background: "{orange.100}",
                color: "{orange.700}"
            },
            danger: {
                background: "{red.100}",
                color: "{red.700}"
            },
            contrast: {
                background: "{surface.950}",
                color: "{surface.0}"
            }
        },
        dark: {
            primary: {
                background: "color-mix(in srgb, {primary.500}, transparent 84%)",
                color: "{primary.300}"
            },
            secondary: {
                background: "{surface.800}",
                color: "{surface.300}"
            },
            success: {
                background: "color-mix(in srgb, {green.500}, transparent 84%)",
                color: "{green.300}"
            },
            info: {
                background: "color-mix(in srgb, {sky.500}, transparent 84%)",
                color: "{sky.300}"
            },
            warn: {
                background: "color-mix(in srgb, {orange.500}, transparent 84%)",
                color: "{orange.300}"
            },
            danger: {
                background: "color-mix(in srgb, {red.500}, transparent 84%)",
                color: "{red.300}"
            },
            contrast: {
                background: "{surface.0}",
                color: "{surface.950}"
            }
        }
    }, eu = {
        root: Zs,
        icon: ou,
        colorScheme: ru
    }, nu = {
        background: "{form.field.background}",
        borderColor: "{form.field.border.color}",
        color: "{form.field.color}",
        height: "18rem",
        padding: "{form.field.padding.y} {form.field.padding.x}",
        borderRadius: "{form.field.border.radius}"
    }, tu = {
        gap: "0.25rem"
    }, au = {
        margin: "2px 0"
    }, cu = {
        root: nu,
        prompt: tu,
        commandResponse: au
    }, iu = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}"
        }
    }, du = {
        root: iu
    }, lu = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        color: "{content.color}",
        borderRadius: "{content.border.radius}",
        shadow: "{overlay.navigation.shadow}",
        transitionDuration: "{transition.duration}"
    }, su = {
        padding: "{navigation.list.padding}",
        gap: "{navigation.list.gap}"
    }, uu = {
        focusBackground: "{navigation.item.focus.background}",
        activeBackground: "{navigation.item.active.background}",
        color: "{navigation.item.color}",
        focusColor: "{navigation.item.focus.color}",
        activeColor: "{navigation.item.active.color}",
        padding: "{navigation.item.padding}",
        borderRadius: "{navigation.item.border.radius}",
        gap: "{navigation.item.gap}",
        icon: {
            color: "{navigation.item.icon.color}",
            focusColor: "{navigation.item.icon.focus.color}",
            activeColor: "{navigation.item.icon.active.color}"
        }
    }, fu = {
        mobileIndent: "1rem"
    }, gu = {
        size: "{navigation.submenu.icon.size}",
        color: "{navigation.submenu.icon.color}",
        focusColor: "{navigation.submenu.icon.focus.color}",
        activeColor: "{navigation.submenu.icon.active.color}"
    }, pu = {
        borderColor: "{content.border.color}"
    }, mu = {
        root: lu,
        list: su,
        item: uu,
        submenu: fu,
        submenuIcon: gu,
        separator: pu
    }, bu = {
        minHeight: "5rem"
    }, hu = {
        eventContent: {
            padding: "1rem 0"
        }
    }, vu = {
        eventContent: {
            padding: "0 1rem"
        }
    }, ku = {
        size: "1.125rem",
        borderRadius: "50%",
        borderWidth: "2px",
        background: "{content.background}",
        borderColor: "{content.border.color}",
        content: {
            borderRadius: "50%",
            size: "0.375rem",
            background: "{primary.color}",
            insetShadow: "0px 0.5px 0px 0px rgba(0, 0, 0, 0.06), 0px 1px 1px 0px rgba(0, 0, 0, 0.12)"
        }
    }, yu = {
        color: "{content.border.color}",
        size: "2px"
    }, Cu = {
        event: bu,
        horizontal: hu,
        vertical: vu,
        eventMarker: ku,
        eventConnector: yu
    }, wu = {
        width: "25rem",
        borderRadius: "{content.border.radius}",
        borderWidth: "1px",
        transitionDuration: "{transition.duration}"
    }, xu = {
        size: "1.125rem"
    }, Bu = {
        padding: "{overlay.popover.padding}",
        gap: "0.5rem"
    }, $u = {
        gap: "0.5rem"
    }, Ru = {
        fontWeight: "500",
        fontSize: "1rem"
    }, Su = {
        fontWeight: "500",
        fontSize: "0.875rem"
    }, zu = {
        width: "1.75rem",
        height: "1.75rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            offset: "{focus.ring.offset}"
        }
    }, Eu = {
        size: "1rem"
    }, Pu = {
        light: {
            root: {
                blur: "1.5px"
            },
            info: {
                background: "color-mix(in srgb, {blue.50}, transparent 5%)",
                borderColor: "{blue.200}",
                color: "{blue.600}",
                detailColor: "{surface.700}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{blue.100}",
                    focusRing: {
                        color: "{blue.600}",
                        shadow: "none"
                    }
                }
            },
            success: {
                background: "color-mix(in srgb, {green.50}, transparent 5%)",
                borderColor: "{green.200}",
                color: "{green.600}",
                detailColor: "{surface.700}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{green.100}",
                    focusRing: {
                        color: "{green.600}",
                        shadow: "none"
                    }
                }
            },
            warn: {
                background: "color-mix(in srgb,{yellow.50}, transparent 5%)",
                borderColor: "{yellow.200}",
                color: "{yellow.600}",
                detailColor: "{surface.700}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{yellow.100}",
                    focusRing: {
                        color: "{yellow.600}",
                        shadow: "none"
                    }
                }
            },
            error: {
                background: "color-mix(in srgb, {red.50}, transparent 5%)",
                borderColor: "{red.200}",
                color: "{red.600}",
                detailColor: "{surface.700}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{red.100}",
                    focusRing: {
                        color: "{red.600}",
                        shadow: "none"
                    }
                }
            },
            secondary: {
                background: "{surface.100}",
                borderColor: "{surface.200}",
                color: "{surface.600}",
                detailColor: "{surface.700}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.200}",
                    focusRing: {
                        color: "{surface.600}",
                        shadow: "none"
                    }
                }
            },
            contrast: {
                background: "{surface.900}",
                borderColor: "{surface.950}",
                color: "{surface.50}",
                detailColor: "{surface.0}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.800}",
                    focusRing: {
                        color: "{surface.50}",
                        shadow: "none"
                    }
                }
            }
        },
        dark: {
            root: {
                blur: "10px"
            },
            info: {
                background: "color-mix(in srgb, {blue.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {blue.700}, transparent 64%)",
                color: "{blue.500}",
                detailColor: "{surface.0}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {blue.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{blue.500}",
                        shadow: "none"
                    }
                }
            },
            success: {
                background: "color-mix(in srgb, {green.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {green.700}, transparent 64%)",
                color: "{green.500}",
                detailColor: "{surface.0}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {green.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{green.500}",
                        shadow: "none"
                    }
                }
            },
            warn: {
                background: "color-mix(in srgb, {yellow.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {yellow.700}, transparent 64%)",
                color: "{yellow.500}",
                detailColor: "{surface.0}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {yellow.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{yellow.500}",
                        shadow: "none"
                    }
                }
            },
            error: {
                background: "color-mix(in srgb, {red.500}, transparent 84%)",
                borderColor: "color-mix(in srgb, {red.700}, transparent 64%)",
                color: "{red.500}",
                detailColor: "{surface.0}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {red.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "rgba(255, 255, 255, 0.05)",
                    focusRing: {
                        color: "{red.500}",
                        shadow: "none"
                    }
                }
            },
            secondary: {
                background: "{surface.800}",
                borderColor: "{surface.700}",
                color: "{surface.300}",
                detailColor: "{surface.0}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.500}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.700}",
                    focusRing: {
                        color: "{surface.300}",
                        shadow: "none"
                    }
                }
            },
            contrast: {
                background: "{surface.0}",
                borderColor: "{surface.100}",
                color: "{surface.950}",
                detailColor: "{surface.950}",
                shadow: "0px 4px 8px 0px color-mix(in srgb, {surface.950}, transparent 96%)",
                closeButton: {
                    hoverBackground: "{surface.100}",
                    focusRing: {
                        color: "{surface.950}",
                        shadow: "none"
                    }
                }
            }
        }
    }, Ou = {
        root: wu,
        icon: xu,
        content: Bu,
        text: $u,
        summary: Ru,
        detail: Su,
        closeButton: zu,
        closeIcon: Eu,
        colorScheme: Pu
    }, _u = {
        padding: "0.25rem",
        borderRadius: "{content.border.radius}",
        gap: "0.5rem",
        fontWeight: "500",
        disabledBackground: "{form.field.disabled.background}",
        disabledBorderColor: "{form.field.disabled.background}",
        disabledColor: "{form.field.disabled.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            padding: "0.25rem"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            padding: "0.25rem"
        }
    }, Iu = {
        disabledColor: "{form.field.disabled.color}"
    }, Du = {
        padding: "0.25rem 0.75rem",
        borderRadius: "{content.border.radius}",
        checkedShadow: "0px 1px 2px 0px rgba(0, 0, 0, 0.02), 0px 1px 2px 0px rgba(0, 0, 0, 0.04)",
        sm: {
            padding: "0.25rem 0.75rem"
        },
        lg: {
            padding: "0.25rem 0.75rem"
        }
    }, Wu = {
        light: {
            root: {
                background: "{surface.100}",
                checkedBackground: "{surface.100}",
                hoverBackground: "{surface.100}",
                borderColor: "{surface.100}",
                color: "{surface.500}",
                hoverColor: "{surface.700}",
                checkedColor: "{surface.900}",
                checkedBorderColor: "{surface.100}"
            },
            content: {
                checkedBackground: "{surface.0}"
            },
            icon: {
                color: "{surface.500}",
                hoverColor: "{surface.700}",
                checkedColor: "{surface.900}"
            }
        },
        dark: {
            root: {
                background: "{surface.950}",
                checkedBackground: "{surface.950}",
                hoverBackground: "{surface.950}",
                borderColor: "{surface.950}",
                color: "{surface.400}",
                hoverColor: "{surface.300}",
                checkedColor: "{surface.0}",
                checkedBorderColor: "{surface.950}"
            },
            content: {
                checkedBackground: "{surface.800}"
            },
            icon: {
                color: "{surface.400}",
                hoverColor: "{surface.300}",
                checkedColor: "{surface.0}"
            }
        }
    }, Tu = {
        root: _u,
        icon: Iu,
        content: Du,
        colorScheme: Wu
    }, Lu = {
        width: "2.5rem",
        height: "1.5rem",
        borderRadius: "30px",
        gap: "0.25rem",
        shadow: "{form.field.shadow}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        },
        borderWidth: "1px",
        borderColor: "transparent",
        hoverBorderColor: "transparent",
        checkedBorderColor: "transparent",
        checkedHoverBorderColor: "transparent",
        invalidBorderColor: "{form.field.invalid.border.color}",
        transitionDuration: "{form.field.transition.duration}",
        slideDuration: "0.2s"
    }, Au = {
        borderRadius: "50%",
        size: "1rem"
    }, Hu = {
        light: {
            root: {
                background: "{surface.300}",
                disabledBackground: "{form.field.disabled.background}",
                hoverBackground: "{surface.400}",
                checkedBackground: "{primary.color}",
                checkedHoverBackground: "{primary.hover.color}"
            },
            handle: {
                background: "{surface.0}",
                disabledBackground: "{form.field.disabled.color}",
                hoverBackground: "{surface.0}",
                checkedBackground: "{surface.0}",
                checkedHoverBackground: "{surface.0}",
                color: "{text.muted.color}",
                hoverColor: "{text.color}",
                checkedColor: "{primary.color}",
                checkedHoverColor: "{primary.hover.color}"
            }
        },
        dark: {
            root: {
                background: "{surface.700}",
                disabledBackground: "{surface.600}",
                hoverBackground: "{surface.600}",
                checkedBackground: "{primary.color}",
                checkedHoverBackground: "{primary.hover.color}"
            },
            handle: {
                background: "{surface.400}",
                disabledBackground: "{surface.900}",
                hoverBackground: "{surface.300}",
                checkedBackground: "{surface.900}",
                checkedHoverBackground: "{surface.900}",
                color: "{surface.900}",
                hoverColor: "{surface.800}",
                checkedColor: "{primary.color}",
                checkedHoverColor: "{primary.hover.color}"
            }
        }
    }, Mu = {
        root: Lu,
        handle: Au,
        colorScheme: Hu
    }, Fu = {
        background: "{content.background}",
        borderColor: "{content.border.color}",
        borderRadius: "{content.border.radius}",
        color: "{content.color}",
        gap: "0.5rem",
        padding: "0.75rem"
    }, ju = {
        root: Fu
    }, Nu = {
        maxWidth: "12.5rem",
        gutter: "0.25rem",
        shadow: "{overlay.popover.shadow}",
        padding: "0.5rem 0.75rem",
        borderRadius: "{overlay.popover.border.radius}"
    }, Vu = {
        light: {
            root: {
                background: "{surface.700}",
                color: "{surface.0}"
            }
        },
        dark: {
            root: {
                background: "{surface.700}",
                color: "{surface.0}"
            }
        }
    }, Xu = {
        root: Nu,
        colorScheme: Vu
    }, Yu = {
        background: "{content.background}",
        color: "{content.color}",
        padding: "1rem",
        gap: "2px",
        indent: "1rem",
        transitionDuration: "{transition.duration}"
    }, Gu = {
        padding: "0.25rem 0.5rem",
        borderRadius: "{content.border.radius}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        color: "{text.color}",
        hoverColor: "{text.hover.color}",
        selectedColor: "{highlight.color}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        },
        gap: "0.25rem"
    }, qu = {
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        selectedColor: "{highlight.color}"
    }, Ku = {
        borderRadius: "50%",
        size: "1.75rem",
        hoverBackground: "{content.hover.background}",
        selectedHoverBackground: "{content.background}",
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        selectedHoverColor: "{primary.color}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, Uu = {
        size: "2rem"
    }, Qu = {
        margin: "0 0 0.5rem 0"
    }, Ju = {
        root: Yu,
        node: Gu,
        nodeIcon: qu,
        nodeToggleButton: Ku,
        loadingIcon: Uu,
        filter: Qu
    }, Zu = {
        background: "{form.field.background}",
        disabledBackground: "{form.field.disabled.background}",
        filledBackground: "{form.field.filled.background}",
        filledHoverBackground: "{form.field.filled.hover.background}",
        filledFocusBackground: "{form.field.filled.focus.background}",
        borderColor: "{form.field.border.color}",
        hoverBorderColor: "{form.field.hover.border.color}",
        focusBorderColor: "{form.field.focus.border.color}",
        invalidBorderColor: "{form.field.invalid.border.color}",
        color: "{form.field.color}",
        disabledColor: "{form.field.disabled.color}",
        placeholderColor: "{form.field.placeholder.color}",
        invalidPlaceholderColor: "{form.field.invalid.placeholder.color}",
        shadow: "{form.field.shadow}",
        paddingX: "{form.field.padding.x}",
        paddingY: "{form.field.padding.y}",
        borderRadius: "{form.field.border.radius}",
        focusRing: {
            width: "{form.field.focus.ring.width}",
            style: "{form.field.focus.ring.style}",
            color: "{form.field.focus.ring.color}",
            offset: "{form.field.focus.ring.offset}",
            shadow: "{form.field.focus.ring.shadow}"
        },
        transitionDuration: "{form.field.transition.duration}",
        sm: {
            fontSize: "{form.field.sm.font.size}",
            paddingX: "{form.field.sm.padding.x}",
            paddingY: "{form.field.sm.padding.y}"
        },
        lg: {
            fontSize: "{form.field.lg.font.size}",
            paddingX: "{form.field.lg.padding.x}",
            paddingY: "{form.field.lg.padding.y}"
        }
    }, of = {
        width: "2.5rem",
        color: "{form.field.icon.color}"
    }, rf = {
        background: "{overlay.select.background}",
        borderColor: "{overlay.select.border.color}",
        borderRadius: "{overlay.select.border.radius}",
        color: "{overlay.select.color}",
        shadow: "{overlay.select.shadow}"
    }, ef = {
        padding: "{list.padding}"
    }, nf = {
        padding: "{list.option.padding}"
    }, tf = {
        borderRadius: "{border.radius.sm}"
    }, af = {
        color: "{form.field.icon.color}"
    }, cf = {
        root: Zu,
        dropdown: of,
        overlay: rf,
        tree: ef,
        emptyMessage: nf,
        chip: tf,
        clearIcon: af
    }, df = {
        transitionDuration: "{transition.duration}"
    }, lf = {
        background: "{content.background}",
        borderColor: "{treetable.border.color}",
        color: "{content.color}",
        borderWidth: "0 0 1px 0",
        padding: "0.75rem 1rem"
    }, sf = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        borderColor: "{treetable.border.color}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        selectedColor: "{highlight.color}",
        gap: "0.5rem",
        padding: "0.75rem 1rem",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        }
    }, uf = {
        fontWeight: "600"
    }, ff = {
        background: "{content.background}",
        hoverBackground: "{content.hover.background}",
        selectedBackground: "{highlight.background}",
        color: "{content.color}",
        hoverColor: "{content.hover.color}",
        selectedColor: "{highlight.color}",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "-1px",
            shadow: "{focus.ring.shadow}"
        }
    }, gf = {
        borderColor: "{treetable.border.color}",
        padding: "0.75rem 1rem",
        gap: "0.5rem"
    }, pf = {
        background: "{content.background}",
        borderColor: "{treetable.border.color}",
        color: "{content.color}",
        padding: "0.75rem 1rem"
    }, mf = {
        fontWeight: "600"
    }, bf = {
        background: "{content.background}",
        borderColor: "{treetable.border.color}",
        color: "{content.color}",
        borderWidth: "0 0 1px 0",
        padding: "0.75rem 1rem"
    }, hf = {
        width: "0.5rem"
    }, vf = {
        width: "1px",
        color: "{primary.color}"
    }, kf = {
        color: "{text.muted.color}",
        hoverColor: "{text.hover.muted.color}",
        size: "0.875rem"
    }, yf = {
        size: "2rem"
    }, Cf = {
        hoverBackground: "{content.hover.background}",
        selectedHoverBackground: "{content.background}",
        color: "{text.muted.color}",
        hoverColor: "{text.color}",
        selectedHoverColor: "{primary.color}",
        size: "1.75rem",
        borderRadius: "50%",
        focusRing: {
            width: "{focus.ring.width}",
            style: "{focus.ring.style}",
            color: "{focus.ring.color}",
            offset: "{focus.ring.offset}",
            shadow: "{focus.ring.shadow}"
        }
    }, wf = {
        borderColor: "{content.border.color}",
        borderWidth: "0 0 1px 0"
    }, xf = {
        borderColor: "{content.border.color}",
        borderWidth: "0 0 1px 0"
    }, Bf = {
        light: {
            root: {
                borderColor: "{content.border.color}"
            },
            bodyCell: {
                selectedBorderColor: "{primary.100}"
            }
        },
        dark: {
            root: {
                borderColor: "{surface.800}"
            },
            bodyCell: {
                selectedBorderColor: "{primary.900}"
            }
        }
    }, $f = {
        root: df,
        header: lf,
        headerCell: sf,
        columnTitle: uf,
        row: ff,
        bodyCell: gf,
        footerCell: pf,
        columnFooter: mf,
        footer: bf,
        columnResizer: hf,
        resizeIndicator: vf,
        sortIcon: kf,
        loadingIcon: yf,
        nodeToggleButton: Cf,
        paginatorTop: wf,
        paginatorBottom: xf,
        colorScheme: Bf
    }, Rf = {
        mask: {
            background: "{content.background}",
            color: "{text.muted.color}"
        },
        icon: {
            size: "2rem"
        }
    }, Sf = {
        loader: Rf
    }, zf = Object.defineProperty, Ef = Object.defineProperties, Pf = Object.getOwnPropertyDescriptors, rr = Object.getOwnPropertySymbols, Of = Object.prototype.hasOwnProperty, _f = Object.prototype.propertyIsEnumerable, er = (o, r, e)=>r in o ? zf(o, r, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: e
        }) : o[r] = e, nr, If = (nr = ((o, r)=>{
        for(var e in r || (r = {}))Of.call(r, e) && er(o, e, r[e]);
        if (rr) for (var e of rr(r))_f.call(r, e) && er(o, e, r[e]);
        return o;
    })({}, Xn), Ef(nr, Pf({
        components: {
            accordion: kn,
            autocomplete: En,
            avatar: Wn,
            badge: jn,
            blockui: Gn,
            breadcrumb: Qn,
            button: ot,
            card: ct,
            carousel: ft,
            cascadeselect: kt,
            checkbox: wt,
            chip: zt,
            colorpicker: It,
            confirmdialog: Tt,
            confirmpopup: Ft,
            contextmenu: qt,
            datatable: pa,
            dataview: Ca,
            datepicker: Fa,
            dialog: Ga,
            divider: Ja,
            dock: rc,
            drawer: ic,
            editor: gc,
            fieldset: vc,
            fileupload: Rc,
            floatlabel: Oc,
            galleria: Yc,
            iconfield: qc,
            iftalabel: Qc,
            image: ei,
            imagecompare: ti,
            inlinemessage: li,
            inplace: fi,
            inputchips: bi,
            inputgroup: vi,
            inputnumber: wi,
            inputotp: $i,
            inputtext: Si,
            knob: _i,
            listbox: Mi,
            megamenu: Ui,
            menu: ed,
            menubar: ld,
            message: kd,
            metergroup: Rd,
            multiselect: Td,
            orderlist: Hd,
            organizationchart: Vd,
            overlaybadge: Yd,
            paginator: Qd,
            panel: tl,
            panelmenu: sl,
            password: bl,
            picklist: kl,
            popover: wl,
            progressbar: Rl,
            progressspinner: zl,
            radiobutton: Ol,
            rating: Dl,
            ripple: Tl,
            scrollpanel: Ml,
            select: Ul,
            selectbutton: Zl,
            skeleton: es,
            slider: ds,
            speeddial: ss,
            splitbutton: fs,
            splitter: bs,
            stepper: $s,
            steps: Os,
            tabmenu: Ls,
            tabs: Xs,
            tabview: Js,
            tag: eu,
            terminal: cu,
            textarea: du,
            tieredmenu: mu,
            timeline: Cu,
            toast: Ou,
            togglebutton: Tu,
            toggleswitch: Mu,
            toolbar: ju,
            tooltip: Xu,
            tree: Ju,
            treeselect: cf,
            treetable: $f,
            virtualscroller: Sf
        }
    })));
    const Df = [
        0,
        50,
        100,
        200,
        300,
        400,
        500,
        600,
        700,
        800,
        900,
        950
    ], Sr = (o, r = 0, e = 100)=>Object.fromEntries(Df.map((n)=>{
            var t, a;
            const s = (500 - n) / 500, f = (e - r) * s, c = f < 0 ? f - r : f + r;
            c >= 0 ? (t = Fr, a = c) : (t = jr, a = -c);
            const g = t(o, a);
            return [
                n,
                g
            ];
        })), Wf = "#708da9", tr = Sr(Wf, 7, 95), Tf = Sr("#7254f3"), Lf = Nr(If, {
        semantic: {
            primary: Tf,
            colorScheme: {
                light: {
                    surface: {
                        ...tr,
                        border: w("surface.200"),
                        a: w("surface.0"),
                        b: w("surface.50"),
                        c: w("surface.100"),
                        d: w("surface.200"),
                        e: w("surface.300"),
                        f: w("surface.400"),
                        g: w("surface.500"),
                        h: w("surface.600"),
                        i: w("surface.700"),
                        j: w("surface.800"),
                        k: w("surface.900"),
                        l: w("surface.950")
                    }
                },
                dark: {
                    surface: {
                        ...tr,
                        border: w("surface.800"),
                        a: w("surface.950"),
                        b: w("surface.900"),
                        c: w("surface.800"),
                        d: w("surface.700"),
                        e: w("surface.600"),
                        f: w("surface.500"),
                        g: w("surface.400"),
                        h: w("surface.300"),
                        i: w("surface.200"),
                        j: w("surface.100"),
                        k: w("surface.50"),
                        l: w("surface.0")
                    }
                }
            }
        },
        components: {
            panel: {
                header: {
                    borderRadius: `${w("panel.root.borderRadius")} ${w("panel.root.borderRadius")} 0 0`
                },
                extend: {
                    contentBorderRadius: `0 0 ${w("panel.root.borderRadius")} ${w("panel.root.borderRadius")}`
                }
            },
            dialog: {
                extend: {
                    headerImage: "linear-gradient(45deg, var(--p-surface-a), var(--p-surface-a), var(--p-surface-a), var(--p-surface-b), var(--p-surface-b), var(--p-surface-b));"
                }
            },
            toolbar: {
                root: {
                    background: "var(--p-surface-b)"
                }
            },
            menubar: {
                root: {
                    background: "var(--p-surface-b)"
                }
            },
            datatable: {
                headerCell: {
                    background: "var(--p-surface-b)"
                }
            }
        },
        extend: {
            surface: {
                borderRadius: "6px"
            },
            tree: {
                borderColor: `solid 1px ${w("content.border.color")}`
            }
        },
        css: ({ dt: o })=>`
.p-panel-content {
    border-radius: ${o("panel.contentBorderRadius")};
}

.p-dialog-header {
    background-image: ${o("dialog.headerImage")};
    border-top-left-radius: inherit;
    border-top-right-radius: inherit;
}

.p-dialog-footer {
    border-bottom-left-radius: inherit;
    border-bottom-right-radius: inherit;
}
        `
    }), Af = ir.PageConfig.getBaseUrl(), Hf = ir.URLExt.join(Af, "/config") + `?q=${Date.now().toString()}`, Mf = await fetch(Hf), zo = await Mf.json(), _ = Vr(un, {
        config: zo
    }), Ff = pn(zo);
    _.use(Jr());
    _.use(Ff);
    _.use(Xr, {
        theme: {
            preset: Lf,
            options: {
                darkModeSelector: ".beaker-dark",
                cssLayer: {
                    name: "primevue",
                    order: "primevue, beaker"
                }
            }
        }
    });
    _.use(Yr);
    _.use(Gr);
    _.use(qr);
    _.use(ie, zo.appConfig);
    _.use(te);
    _.directive("tooltip", Kr);
    _.directive("focustrap", Ur);
    _.directive("keybindings", sr);
    _.directive("autoscroll", ne);
    _.mount("#app");
})();
export { tn as R, Kf as a, qf as b, Xf as d, Yf as f, Vf as g, Gf as i, Uf as u, __tla };
