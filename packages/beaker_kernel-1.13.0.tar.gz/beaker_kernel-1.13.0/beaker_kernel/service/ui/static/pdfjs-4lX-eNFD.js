let Pt, St, O, D, Rt, rs, Tt, X, pt, ye, tt, st, te, me, Oe, ot, be, Et, Qs, Os, Z, ui, di, Vt, qe, Ae, Gt, Be, rt, Ee, P, we, Zs, Ln, Ms, ie, _n, Ei, Ci, Fs, xi, Se, Xe, xn, gt, vi, Mt, N, Y, Ls, Mn;
let __tla = (async ()=>{
    let at, Ne, Pe, ct, ci, it, Bt, he;
    at = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser");
    Ne = [
        .001,
        0,
        0,
        .001,
        0,
        0
    ];
    Pe = 1.35;
    ct = {
        ANY: 1,
        DISPLAY: 2,
        PRINT: 4,
        ANNOTATIONS_FORMS: 16,
        ANNOTATIONS_STORAGE: 32,
        ANNOTATIONS_DISABLE: 64,
        IS_EDITING: 128,
        OPLIST: 256
    };
    Tt = {
        DISABLE: 0,
        ENABLE: 1,
        ENABLE_FORMS: 2,
        ENABLE_STORAGE: 3
    };
    ci = "pdfjs_internal_editor_";
    D = {
        DISABLE: -1,
        NONE: 0,
        FREETEXT: 3,
        HIGHLIGHT: 9,
        STAMP: 13,
        INK: 15,
        SIGNATURE: 101
    };
    O = {
        RESIZE: 1,
        CREATE: 2,
        FREETEXT_SIZE: 11,
        FREETEXT_COLOR: 12,
        FREETEXT_OPACITY: 13,
        INK_COLOR: 21,
        INK_THICKNESS: 22,
        INK_OPACITY: 23,
        HIGHLIGHT_COLOR: 31,
        HIGHLIGHT_DEFAULT_COLOR: 32,
        HIGHLIGHT_THICKNESS: 33,
        HIGHLIGHT_FREE: 34,
        HIGHLIGHT_SHOW_ALL: 35,
        DRAW_STEP: 41
    };
    di = {
        PRINT: 4,
        MODIFY_CONTENTS: 8,
        COPY: 16,
        MODIFY_ANNOTATIONS: 32,
        FILL_INTERACTIVE_FORMS: 256,
        COPY_FOR_ACCESSIBILITY: 512,
        ASSEMBLE: 1024,
        PRINT_HIGH_QUALITY: 2048
    };
    it = {
        FILL: 0,
        STROKE: 1,
        FILL_STROKE: 2,
        INVISIBLE: 3,
        FILL_STROKE_MASK: 3,
        ADD_TO_PATH_FLAG: 4
    };
    me = {
        GRAYSCALE_1BPP: 1,
        RGB_24BPP: 2,
        RGBA_32BPP: 3
    };
    X = {
        TEXT: 1,
        LINK: 2,
        FREETEXT: 3,
        LINE: 4,
        SQUARE: 5,
        CIRCLE: 6,
        POLYGON: 7,
        POLYLINE: 8,
        HIGHLIGHT: 9,
        UNDERLINE: 10,
        SQUIGGLY: 11,
        STRIKEOUT: 12,
        STAMP: 13,
        CARET: 14,
        INK: 15,
        POPUP: 16,
        FILEATTACHMENT: 17,
        SOUND: 18,
        MOVIE: 19,
        WIDGET: 20,
        SCREEN: 21,
        PRINTERMARK: 22,
        TRAPNET: 23,
        WATERMARK: 24,
        THREED: 25,
        REDACT: 26
    };
    Bt = {
        SOLID: 1,
        DASHED: 2,
        BEVELED: 3,
        INSET: 4,
        UNDERLINE: 5
    };
    we = {
        ERRORS: 0,
        WARNINGS: 1,
        INFOS: 5
    };
    be = {
        dependency: 1,
        setLineWidth: 2,
        setLineCap: 3,
        setLineJoin: 4,
        setMiterLimit: 5,
        setDash: 6,
        setRenderingIntent: 7,
        setFlatness: 8,
        setGState: 9,
        save: 10,
        restore: 11,
        transform: 12,
        moveTo: 13,
        lineTo: 14,
        curveTo: 15,
        curveTo2: 16,
        curveTo3: 17,
        closePath: 18,
        rectangle: 19,
        stroke: 20,
        closeStroke: 21,
        fill: 22,
        eoFill: 23,
        fillStroke: 24,
        eoFillStroke: 25,
        closeFillStroke: 26,
        closeEOFillStroke: 27,
        endPath: 28,
        clip: 29,
        eoClip: 30,
        beginText: 31,
        endText: 32,
        setCharSpacing: 33,
        setWordSpacing: 34,
        setHScale: 35,
        setLeading: 36,
        setFont: 37,
        setTextRenderingMode: 38,
        setTextRise: 39,
        moveText: 40,
        setLeadingMoveText: 41,
        setTextMatrix: 42,
        nextLine: 43,
        showText: 44,
        showSpacedText: 45,
        nextLineShowText: 46,
        nextLineSetSpacingShowText: 47,
        setCharWidth: 48,
        setCharWidthAndBounds: 49,
        setStrokeColorSpace: 50,
        setFillColorSpace: 51,
        setStrokeColor: 52,
        setStrokeColorN: 53,
        setFillColor: 54,
        setFillColorN: 55,
        setStrokeGray: 56,
        setFillGray: 57,
        setStrokeRGBColor: 58,
        setFillRGBColor: 59,
        setStrokeCMYKColor: 60,
        setFillCMYKColor: 61,
        shadingFill: 62,
        beginInlineImage: 63,
        beginImageData: 64,
        endInlineImage: 65,
        paintXObject: 66,
        markPoint: 67,
        markPointProps: 68,
        beginMarkedContent: 69,
        beginMarkedContentProps: 70,
        endMarkedContent: 71,
        beginCompat: 72,
        endCompat: 73,
        paintFormXObjectBegin: 74,
        paintFormXObjectEnd: 75,
        beginGroup: 76,
        endGroup: 77,
        beginAnnotation: 80,
        endAnnotation: 81,
        paintImageMaskXObject: 83,
        paintImageMaskXObjectGroup: 84,
        paintImageXObject: 85,
        paintInlineImageXObject: 86,
        paintInlineImageXObjectGroup: 87,
        paintImageXObjectRepeat: 88,
        paintImageMaskXObjectRepeat: 89,
        paintSolidColorImageMask: 90,
        constructPath: 91,
        setStrokeTransparent: 92,
        setFillTransparent: 93,
        rawFillPath: 94
    };
    he = {
        moveTo: 0,
        lineTo: 1,
        curveTo: 2,
        closePath: 3
    };
    ui = {
        NEED_PASSWORD: 1,
        INCORRECT_PASSWORD: 2
    };
    let ve = we.WARNINGS;
    function fi(c) {
        Number.isInteger(c) && (ve = c);
    }
    function pi() {
        return ve;
    }
    function _e(c) {
        ve >= we.INFOS && console.log(`Info: ${c}`);
    }
    function F(c) {
        ve >= we.WARNINGS && console.log(`Warning: ${c}`);
    }
    function $(c) {
        throw new Error(c);
    }
    function K(c, t) {
        c || $(t);
    }
    function gi(c) {
        switch(c?.protocol){
            case "http:":
            case "https:":
            case "ftp:":
            case "mailto:":
            case "tel:":
                return !0;
            default:
                return !1;
        }
    }
    Ms = function(c, t = null, e = null) {
        if (!c) return null;
        if (e && typeof c == "string" && (e.addDefaultProtocol && c.startsWith("www.") && c.match(/\./g)?.length >= 2 && (c = `http://${c}`), e.tryConvertEncoding)) try {
            c = wi(c);
        } catch  {}
        const s = t ? URL.parse(c, t) : URL.parse(c);
        return gi(s) ? s : null;
    };
    Ls = function(c, t, e = !1) {
        const s = URL.parse(c);
        return s ? (s.hash = t, s.href) : e && Ms(c, "http://example.com") ? c.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
    };
    N = function(c, t, e, s = !1) {
        return Object.defineProperty(c, t, {
            value: e,
            enumerable: !s,
            configurable: !0,
            writable: !1
        }), e;
    };
    const Dt = function() {
        function t(e, s) {
            this.message = e, this.name = s;
        }
        return t.prototype = new Error, t.constructor = t, t;
    }();
    class cs extends Dt {
        constructor(t, e){
            super(t, "PasswordException"), this.code = e;
        }
    }
    class Re extends Dt {
        constructor(t, e){
            super(t, "UnknownErrorException"), this.details = e;
        }
    }
    Oe = class extends Dt {
        constructor(t){
            super(t, "InvalidPDFException");
        }
    };
    Ae = class extends Dt {
        constructor(t, e, s){
            super(t, "ResponseException"), this.status = e, this.missing = s;
        }
    };
    class mi extends Dt {
        constructor(t){
            super(t, "FormatError");
        }
    }
    Pt = class extends Dt {
        constructor(t){
            super(t, "AbortException");
        }
    };
    function Ds(c) {
        (typeof c != "object" || c?.length === void 0) && $("Invalid argument for bytesToString");
        const t = c.length, e = 8192;
        if (t < e) return String.fromCharCode.apply(null, c);
        const s = [];
        for(let i = 0; i < t; i += e){
            const n = Math.min(i + e, t), r = c.subarray(i, n);
            s.push(String.fromCharCode.apply(null, r));
        }
        return s.join("");
    }
    function se(c) {
        typeof c != "string" && $("Invalid argument for stringToBytes");
        const t = c.length, e = new Uint8Array(t);
        for(let s = 0; s < t; ++s)e[s] = c.charCodeAt(s) & 255;
        return e;
    }
    function bi(c) {
        return String.fromCharCode(c >> 24 & 255, c >> 16 & 255, c >> 8 & 255, c & 255);
    }
    function Ai() {
        const c = new Uint8Array(4);
        return c[0] = 1, new Uint32Array(c.buffer, 0, 1)[0] === 1;
    }
    function yi() {
        try {
            return new Function(""), !0;
        } catch  {
            return !1;
        }
    }
    st = class {
        static get isLittleEndian() {
            return N(this, "isLittleEndian", Ai());
        }
        static get isEvalSupported() {
            return N(this, "isEvalSupported", yi());
        }
        static get isOffscreenCanvasSupported() {
            return N(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
        }
        static get isImageDecoderSupported() {
            return N(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
        }
        static get platform() {
            if (typeof navigator < "u" && typeof navigator?.platform == "string" && typeof navigator?.userAgent == "string") {
                const { platform: t, userAgent: e } = navigator;
                return N(this, "platform", {
                    isAndroid: e.includes("Android"),
                    isLinux: t.includes("Linux"),
                    isMac: t.includes("Mac"),
                    isWindows: t.includes("Win"),
                    isFirefox: e.includes("Firefox")
                });
            }
            return N(this, "platform", {
                isAndroid: !1,
                isLinux: !1,
                isMac: !1,
                isWindows: !1,
                isFirefox: !1
            });
        }
        static get isCSSRoundSupported() {
            return N(this, "isCSSRoundSupported", globalThis.CSS?.supports?.("width: round(1.5px, 1px)"));
        }
    };
    const Ie = Array.from(Array(256).keys(), (c)=>c.toString(16).padStart(2, "0"));
    P = class {
        static makeHexColor(t, e, s) {
            return `#${Ie[t]}${Ie[e]}${Ie[s]}`;
        }
        static scaleMinMax(t, e) {
            let s;
            t[0] ? (t[0] < 0 && (s = e[0], e[0] = e[2], e[2] = s), e[0] *= t[0], e[2] *= t[0], t[3] < 0 && (s = e[1], e[1] = e[3], e[3] = s), e[1] *= t[3], e[3] *= t[3]) : (s = e[0], e[0] = e[1], e[1] = s, s = e[2], e[2] = e[3], e[3] = s, t[1] < 0 && (s = e[1], e[1] = e[3], e[3] = s), e[1] *= t[1], e[3] *= t[1], t[2] < 0 && (s = e[0], e[0] = e[2], e[2] = s), e[0] *= t[2], e[2] *= t[2]), e[0] += t[4], e[1] += t[5], e[2] += t[4], e[3] += t[5];
        }
        static transform(t, e) {
            return [
                t[0] * e[0] + t[2] * e[1],
                t[1] * e[0] + t[3] * e[1],
                t[0] * e[2] + t[2] * e[3],
                t[1] * e[2] + t[3] * e[3],
                t[0] * e[4] + t[2] * e[5] + t[4],
                t[1] * e[4] + t[3] * e[5] + t[5]
            ];
        }
        static applyTransform(t, e, s = 0) {
            const i = t[s], n = t[s + 1];
            t[s] = i * e[0] + n * e[2] + e[4], t[s + 1] = i * e[1] + n * e[3] + e[5];
        }
        static applyTransformToBezier(t, e, s = 0) {
            const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5];
            for(let h = 0; h < 6; h += 2){
                const d = t[s + h], u = t[s + h + 1];
                t[s + h] = d * i + u * r + o, t[s + h + 1] = d * n + u * a + l;
            }
        }
        static applyInverseTransform(t, e) {
            const s = t[0], i = t[1], n = e[0] * e[3] - e[1] * e[2];
            t[0] = (s * e[3] - i * e[2] + e[2] * e[5] - e[4] * e[3]) / n, t[1] = (-s * e[1] + i * e[0] + e[4] * e[1] - e[5] * e[0]) / n;
        }
        static axialAlignedBoundingBox(t, e, s) {
            const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5], h = t[0], d = t[1], u = t[2], f = t[3];
            let g = i * h + o, p = g, m = i * u + o, b = m, y = a * d + l, A = y, v = a * f + l, w = v;
            if (n !== 0 || r !== 0) {
                const _ = n * h, S = n * u, E = r * d, C = r * f;
                g += E, b += E, m += C, p += C, y += _, w += _, v += S, A += S;
            }
            s[0] = Math.min(s[0], g, m, p, b), s[1] = Math.min(s[1], y, v, A, w), s[2] = Math.max(s[2], g, m, p, b), s[3] = Math.max(s[3], y, v, A, w);
        }
        static inverseTransform(t) {
            const e = t[0] * t[3] - t[1] * t[2];
            return [
                t[3] / e,
                -t[1] / e,
                -t[2] / e,
                t[0] / e,
                (t[2] * t[5] - t[4] * t[3]) / e,
                (t[4] * t[1] - t[5] * t[0]) / e
            ];
        }
        static singularValueDecompose2dScale(t, e) {
            const s = t[0], i = t[1], n = t[2], r = t[3], a = s ** 2 + i ** 2, o = s * n + i * r, l = n ** 2 + r ** 2, h = (a + l) / 2, d = Math.sqrt(h ** 2 - (a * l - o ** 2));
            e[0] = Math.sqrt(h + d || 1), e[1] = Math.sqrt(h - d || 1);
        }
        static normalizeRect(t) {
            const e = t.slice(0);
            return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
        }
        static intersect(t, e) {
            const s = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), i = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
            if (s > i) return null;
            const n = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), r = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
            return n > r ? null : [
                s,
                n,
                i,
                r
            ];
        }
        static pointBoundingBox(t, e, s) {
            s[0] = Math.min(s[0], t), s[1] = Math.min(s[1], e), s[2] = Math.max(s[2], t), s[3] = Math.max(s[3], e);
        }
        static rectBoundingBox(t, e, s, i, n) {
            n[0] = Math.min(n[0], t, s), n[1] = Math.min(n[1], e, i), n[2] = Math.max(n[2], t, s), n[3] = Math.max(n[3], e, i);
        }
        static #t(t, e, s, i, n, r, a, o, l, h) {
            if (l <= 0 || l >= 1) return;
            const d = 1 - l, u = l * l, f = u * l, g = d * (d * (d * t + 3 * l * e) + 3 * u * s) + f * i, p = d * (d * (d * n + 3 * l * r) + 3 * u * a) + f * o;
            h[0] = Math.min(h[0], g), h[1] = Math.min(h[1], p), h[2] = Math.max(h[2], g), h[3] = Math.max(h[3], p);
        }
        static #e(t, e, s, i, n, r, a, o, l, h, d, u) {
            if (Math.abs(l) < 1e-12) {
                Math.abs(h) >= 1e-12 && this.#t(t, e, s, i, n, r, a, o, -d / h, u);
                return;
            }
            const f = h ** 2 - 4 * d * l;
            if (f < 0) return;
            const g = Math.sqrt(f), p = 2 * l;
            this.#t(t, e, s, i, n, r, a, o, (-h + g) / p, u), this.#t(t, e, s, i, n, r, a, o, (-h - g) / p, u);
        }
        static bezierBoundingBox(t, e, s, i, n, r, a, o, l) {
            l[0] = Math.min(l[0], t, a), l[1] = Math.min(l[1], e, o), l[2] = Math.max(l[2], t, a), l[3] = Math.max(l[3], e, o), this.#e(t, s, n, a, e, i, r, o, 3 * (-t + 3 * (s - n) + a), 6 * (t - 2 * s + n), 3 * (s - t), l), this.#e(t, s, n, a, e, i, r, o, 3 * (-e + 3 * (i - r) + o), 6 * (e - 2 * i + r), 3 * (i - e), l);
        }
    };
    function wi(c) {
        return decodeURIComponent(escape(c));
    }
    let ke = null, ds = null;
    vi = function(c) {
        return ke || (ke = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, ds = new Map([
            [
                "ﬅ",
                "ſt"
            ]
        ])), c.replaceAll(ke, (t, e, s)=>e ? e.normalize("NFKC") : ds.get(s));
    };
    Fs = function() {
        if (typeof crypto.randomUUID == "function") return crypto.randomUUID();
        const c = new Uint8Array(32);
        return crypto.getRandomValues(c), Ds(c);
    };
    const We = "pdfjs_internal_id_";
    function _i(c, t, e) {
        if (!Array.isArray(e) || e.length < 2) return !1;
        const [s, i, ...n] = e;
        if (!c(s) && !Number.isInteger(s) || !t(i)) return !1;
        const r = n.length;
        let a = !0;
        switch(i.name){
            case "XYZ":
                if (r < 2 || r > 3) return !1;
                break;
            case "Fit":
            case "FitB":
                return r === 0;
            case "FitH":
            case "FitBH":
            case "FitV":
            case "FitBV":
                if (r > 1) return !1;
                break;
            case "FitR":
                if (r !== 4) return !1;
                a = !1;
                break;
            default:
                return !1;
        }
        for (const o of n)if (!(typeof o == "number" || a && o === null)) return !1;
        return !0;
    }
    ot = function(c, t, e) {
        return Math.min(Math.max(c, t), e);
    };
    function Ns(c) {
        return Uint8Array.prototype.toBase64 ? c.toBase64() : btoa(Ds(c));
    }
    function Si(c) {
        return Uint8Array.fromBase64 ? Uint8Array.fromBase64(c) : se(atob(c));
    }
    typeof Promise.try != "function" && (Promise.try = function(c, ...t) {
        return new Promise((e)=>{
            e(c(...t));
        });
    });
    typeof Math.sumPrecise != "function" && (Math.sumPrecise = function(c) {
        return c.reduce((t, e)=>t + e, 0);
    });
    const _t = "http://www.w3.org/2000/svg";
    Vt = class {
        static CSS = 96;
        static PDF = 72;
        static PDF_TO_CSS_UNITS = this.CSS / this.PDF;
    };
    ie = async function(c, t = "text") {
        if (Ht(c, document.baseURI)) {
            const e = await fetch(c);
            if (!e.ok) throw new Error(e.statusText);
            switch(t){
                case "arraybuffer":
                    return e.arrayBuffer();
                case "blob":
                    return e.blob();
                case "json":
                    return e.json();
            }
            return e.text();
        }
        return new Promise((e, s)=>{
            const i = new XMLHttpRequest;
            i.open("GET", c, !0), i.responseType = t, i.onreadystatechange = ()=>{
                if (i.readyState === XMLHttpRequest.DONE) {
                    if (i.status === 200 || i.status === 0) {
                        switch(t){
                            case "arraybuffer":
                            case "blob":
                            case "json":
                                e(i.response);
                                return;
                        }
                        e(i.responseText);
                        return;
                    }
                    s(new Error(i.statusText));
                }
            }, i.send(null);
        });
    };
    class ne {
        constructor({ viewBox: t, userUnit: e, scale: s, rotation: i, offsetX: n = 0, offsetY: r = 0, dontFlip: a = !1 }){
            this.viewBox = t, this.userUnit = e, this.scale = s, this.rotation = i, this.offsetX = n, this.offsetY = r, s *= e;
            const o = (t[2] + t[0]) / 2, l = (t[3] + t[1]) / 2;
            let h, d, u, f;
            switch(i %= 360, i < 0 && (i += 360), i){
                case 180:
                    h = -1, d = 0, u = 0, f = 1;
                    break;
                case 90:
                    h = 0, d = 1, u = 1, f = 0;
                    break;
                case 270:
                    h = 0, d = -1, u = -1, f = 0;
                    break;
                case 0:
                    h = 1, d = 0, u = 0, f = -1;
                    break;
                default:
                    throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
            }
            a && (u = -u, f = -f);
            let g, p, m, b;
            h === 0 ? (g = Math.abs(l - t[1]) * s + n, p = Math.abs(o - t[0]) * s + r, m = (t[3] - t[1]) * s, b = (t[2] - t[0]) * s) : (g = Math.abs(o - t[0]) * s + n, p = Math.abs(l - t[1]) * s + r, m = (t[2] - t[0]) * s, b = (t[3] - t[1]) * s), this.transform = [
                h * s,
                d * s,
                u * s,
                f * s,
                g - h * s * o - u * s * l,
                p - d * s * o - f * s * l
            ], this.width = m, this.height = b;
        }
        get rawDims() {
            const t = this.viewBox;
            return N(this, "rawDims", {
                pageWidth: t[2] - t[0],
                pageHeight: t[3] - t[1],
                pageX: t[0],
                pageY: t[1]
            });
        }
        clone({ scale: t = this.scale, rotation: e = this.rotation, offsetX: s = this.offsetX, offsetY: i = this.offsetY, dontFlip: n = !1 } = {}) {
            return new ne({
                viewBox: this.viewBox.slice(),
                userUnit: this.userUnit,
                scale: t,
                rotation: e,
                offsetX: s,
                offsetY: i,
                dontFlip: n
            });
        }
        convertToViewportPoint(t, e) {
            const s = [
                t,
                e
            ];
            return P.applyTransform(s, this.transform), s;
        }
        convertToViewportRectangle(t) {
            const e = [
                t[0],
                t[1]
            ];
            P.applyTransform(e, this.transform);
            const s = [
                t[2],
                t[3]
            ];
            return P.applyTransform(s, this.transform), [
                e[0],
                e[1],
                s[0],
                s[1]
            ];
        }
        convertToPdfPoint(t, e) {
            const s = [
                t,
                e
            ];
            return P.applyInverseTransform(s, this.transform), s;
        }
    }
    qe = class extends Dt {
        constructor(t, e = 0){
            super(t, "RenderingCancelledException"), this.extraDelay = e;
        }
    };
    Se = function(c) {
        const t = c.length;
        let e = 0;
        for(; e < t && c[e].trim() === "";)e++;
        return c.substring(e, e + 5).toLowerCase() === "data:";
    };
    Xe = function(c) {
        return typeof c == "string" && /\.pdf$/i.test(c);
    };
    Ei = function(c) {
        return [c] = c.split(/[#?]/, 1), c.substring(c.lastIndexOf("/") + 1);
    };
    Ci = function(c, t = "document.pdf") {
        if (typeof c != "string") return t;
        if (Se(c)) return F('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
        const e = /^(?:(?:[^:]+:)?\/\/[^/]+)?([^?#]*)(\?[^#]*)?(#.*)?$/, s = /[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i, i = e.exec(c);
        let n = s.exec(i[1]) || s.exec(i[2]) || s.exec(i[3]);
        if (n && (n = n[0], n.includes("%"))) try {
            n = s.exec(decodeURIComponent(n))[0];
        } catch  {}
        return n || t;
    };
    class us {
        started = Object.create(null);
        times = [];
        time(t) {
            t in this.started && F(`Timer is already running for ${t}`), this.started[t] = Date.now();
        }
        timeEnd(t) {
            t in this.started || F(`Timer has not been started for ${t}`), this.times.push({
                name: t,
                start: this.started[t],
                end: Date.now()
            }), delete this.started[t];
        }
        toString() {
            const t = [];
            let e = 0;
            for (const { name: s } of this.times)e = Math.max(s.length, e);
            for (const { name: s, start: i, end: n } of this.times)t.push(`${s.padEnd(e)} ${n - i}ms
`);
            return t.join("");
        }
    }
    function Ht(c, t) {
        const e = t ? URL.parse(c, t) : URL.parse(c);
        return e?.protocol === "http:" || e?.protocol === "https:";
    }
    gt = function(c) {
        c.preventDefault();
    };
    Y = function(c) {
        c.preventDefault(), c.stopPropagation();
    };
    Os = class {
        static #t;
        static toDateObject(t) {
            if (!t || typeof t != "string") return null;
            this.#t ||= new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?");
            const e = this.#t.exec(t);
            if (!e) return null;
            const s = parseInt(e[1], 10);
            let i = parseInt(e[2], 10);
            i = i >= 1 && i <= 12 ? i - 1 : 0;
            let n = parseInt(e[3], 10);
            n = n >= 1 && n <= 31 ? n : 1;
            let r = parseInt(e[4], 10);
            r = r >= 0 && r <= 23 ? r : 0;
            let a = parseInt(e[5], 10);
            a = a >= 0 && a <= 59 ? a : 0;
            let o = parseInt(e[6], 10);
            o = o >= 0 && o <= 59 ? o : 0;
            const l = e[7] || "Z";
            let h = parseInt(e[8], 10);
            h = h >= 0 && h <= 23 ? h : 0;
            let d = parseInt(e[9], 10) || 0;
            return d = d >= 0 && d <= 59 ? d : 0, l === "-" ? (r += h, a += d) : l === "+" && (r -= h, a -= d), new Date(Date.UTC(s, i, n, r, a, o));
        }
    };
    xi = function(c, { scale: t = 1, rotation: e = 0 }) {
        const { width: s, height: i } = c.attributes.style, n = [
            0,
            0,
            parseInt(s),
            parseInt(i)
        ];
        return new ne({
            viewBox: n,
            userUnit: 1,
            scale: t,
            rotation: e
        });
    };
    function Ye(c) {
        if (c.startsWith("#")) {
            const t = parseInt(c.slice(1), 16);
            return [
                (t & 16711680) >> 16,
                (t & 65280) >> 8,
                t & 255
            ];
        }
        return c.startsWith("rgb(") ? c.slice(4, -1).split(",").map((t)=>parseInt(t)) : c.startsWith("rgba(") ? c.slice(5, -1).split(",").map((t)=>parseInt(t)).slice(0, 3) : (F(`Not a valid color format: "${c}"`), [
            0,
            0,
            0
        ]);
    }
    function Ti(c) {
        const t = document.createElement("span");
        t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
        for (const e of c.keys()){
            t.style.color = e;
            const s = window.getComputedStyle(t).color;
            c.set(e, Ye(s));
        }
        t.remove();
    }
    function z(c) {
        const { a: t, b: e, c: s, d: i, e: n, f: r } = c.getTransform();
        return [
            t,
            e,
            s,
            i,
            n,
            r
        ];
    }
    function mt(c) {
        const { a: t, b: e, c: s, d: i, e: n, f: r } = c.getTransform().invertSelf();
        return [
            t,
            e,
            s,
            i,
            n,
            r
        ];
    }
    Mt = function(c, t, e = !1, s = !0) {
        if (t instanceof ne) {
            const { pageWidth: i, pageHeight: n } = t.rawDims, { style: r } = c, a = st.isCSSRoundSupported, o = `var(--total-scale-factor) * ${i}px`, l = `var(--total-scale-factor) * ${n}px`, h = a ? `round(down, ${o}, var(--scale-round-x))` : `calc(${o})`, d = a ? `round(down, ${l}, var(--scale-round-y))` : `calc(${l})`;
            !e || t.rotation % 180 === 0 ? (r.width = h, r.height = d) : (r.width = d, r.height = h);
        }
        s && c.setAttribute("data-main-rotation", t.rotation);
    };
    Et = class {
        constructor(){
            const { pixelRatio: t } = Et;
            this.sx = t, this.sy = t;
        }
        get scaled() {
            return this.sx !== 1 || this.sy !== 1;
        }
        get symmetric() {
            return this.sx === this.sy;
        }
        limitCanvas(t, e, s, i) {
            let n = 1 / 0, r = 1 / 0, a = 1 / 0;
            s > 0 && (n = Math.sqrt(s / (t * e))), i !== -1 && (r = i / t, a = i / e);
            const o = Math.min(n, r, a);
            return this.sx > o || this.sy > o ? (this.sx = o, this.sy = o, !0) : !1;
        }
        static get pixelRatio() {
            return globalThis.devicePixelRatio || 1;
        }
    };
    Be = [
        "image/apng",
        "image/avif",
        "image/bmp",
        "image/gif",
        "image/jpeg",
        "image/png",
        "image/svg+xml",
        "image/webp",
        "image/x-icon"
    ];
    class Zt {
        #t = null;
        #e = null;
        #s;
        #i = null;
        #r = null;
        #n = null;
        static #l = null;
        constructor(t){
            this.#s = t, Zt.#l ||= Object.freeze({
                freetext: "pdfjs-editor-remove-freetext-button",
                highlight: "pdfjs-editor-remove-highlight-button",
                ink: "pdfjs-editor-remove-ink-button",
                stamp: "pdfjs-editor-remove-stamp-button",
                signature: "pdfjs-editor-remove-signature-button"
            });
        }
        render() {
            const t = this.#t = document.createElement("div");
            t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
            const e = this.#s._uiManager._signal;
            t.addEventListener("contextmenu", gt, {
                signal: e
            }), t.addEventListener("pointerdown", Zt.#o, {
                signal: e
            });
            const s = this.#i = document.createElement("div");
            s.className = "buttons", t.append(s);
            const i = this.#s.toolbarPosition;
            if (i) {
                const { style: n } = t, r = this.#s._uiManager.direction === "ltr" ? 1 - i[0] : i[0];
                n.insetInlineEnd = `${100 * r}%`, n.top = `calc(${100 * i[1]}% + var(--editor-toolbar-vert-offset))`;
            }
            return this.#c(), t;
        }
        get div() {
            return this.#t;
        }
        static #o(t) {
            t.stopPropagation();
        }
        #d(t) {
            this.#s._focusEventsAllowed = !1, Y(t);
        }
        #h(t) {
            this.#s._focusEventsAllowed = !0, Y(t);
        }
        #u(t) {
            const e = this.#s._uiManager._signal;
            t.addEventListener("focusin", this.#d.bind(this), {
                capture: !0,
                signal: e
            }), t.addEventListener("focusout", this.#h.bind(this), {
                capture: !0,
                signal: e
            }), t.addEventListener("contextmenu", gt, {
                signal: e
            });
        }
        hide() {
            this.#t.classList.add("hidden"), this.#e?.hideDropdown();
        }
        show() {
            this.#t.classList.remove("hidden"), this.#r?.shown();
        }
        #c() {
            const { editorType: t, _uiManager: e } = this.#s, s = document.createElement("button");
            s.className = "delete", s.tabIndex = 0, s.setAttribute("data-l10n-id", Zt.#l[t]), this.#u(s), s.addEventListener("click", (i)=>{
                e.delete();
            }, {
                signal: e._signal
            }), this.#i.append(s);
        }
        get #f() {
            const t = document.createElement("div");
            return t.className = "divider", t;
        }
        async addAltText(t) {
            const e = await t.render();
            this.#u(e), this.#i.prepend(e, this.#f), this.#r = t;
        }
        addColorPicker(t) {
            this.#e = t;
            const e = t.renderButton();
            this.#u(e), this.#i.prepend(e, this.#f);
        }
        async addEditSignatureButton(t) {
            const e = this.#n = await t.renderEditButton(this.#s);
            this.#u(e), this.#i.prepend(e, this.#f);
        }
        updateEditSignatureButton(t) {
            this.#n && (this.#n.title = t);
        }
        remove() {
            this.#t.remove(), this.#e?.destroy(), this.#e = null;
        }
    }
    class Pi {
        #t = null;
        #e = null;
        #s;
        constructor(t){
            this.#s = t;
        }
        #i() {
            const t = this.#e = document.createElement("div");
            t.className = "editToolbar", t.setAttribute("role", "toolbar"), t.addEventListener("contextmenu", gt, {
                signal: this.#s._signal
            });
            const e = this.#t = document.createElement("div");
            return e.className = "buttons", t.append(e), this.#n(), t;
        }
        #r(t, e) {
            let s = 0, i = 0;
            for (const n of t){
                const r = n.y + n.height;
                if (r < s) continue;
                const a = n.x + (e ? n.width : 0);
                if (r > s) {
                    i = a, s = r;
                    continue;
                }
                e ? a > i && (i = a) : a < i && (i = a);
            }
            return [
                e ? 1 - i : i,
                s
            ];
        }
        show(t, e, s) {
            const [i, n] = this.#r(e, s), { style: r } = this.#e ||= this.#i();
            t.append(this.#e), r.insetInlineEnd = `${100 * i}%`, r.top = `calc(${100 * n}% + var(--editor-toolbar-vert-offset))`;
        }
        hide() {
            this.#e.remove();
        }
        #n() {
            const t = document.createElement("button");
            t.className = "highlightButton", t.tabIndex = 0, t.setAttribute("data-l10n-id", "pdfjs-highlight-floating-button1");
            const e = document.createElement("span");
            t.append(e), e.className = "visuallyHidden", e.setAttribute("data-l10n-id", "pdfjs-highlight-floating-button-label");
            const s = this.#s._signal;
            t.addEventListener("contextmenu", gt, {
                signal: s
            }), t.addEventListener("click", ()=>{
                this.#s.highlightSelection("floating_button");
            }, {
                signal: s
            }), this.#t.append(t);
        }
    }
    function Ke(c, t, e) {
        for (const s of e)t.addEventListener(s, c[s].bind(c));
    }
    class Ri {
        #t = 0;
        get id() {
            return `${ci}${this.#t++}`;
        }
    }
    class Qe {
        #t = Fs();
        #e = 0;
        #s = null;
        static get _isSVGFittingCanvas() {
            const t = 'data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>', s = new OffscreenCanvas(1, 3).getContext("2d", {
                willReadFrequently: !0
            }), i = new Image;
            i.src = t;
            const n = i.decode().then(()=>(s.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(s.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
            return N(this, "_isSVGFittingCanvas", n);
        }
        async #i(t, e) {
            this.#s ||= new Map;
            let s = this.#s.get(t);
            if (s === null) return null;
            if (s?.bitmap) return s.refCounter += 1, s;
            try {
                s ||= {
                    bitmap: null,
                    id: `image_${this.#t}_${this.#e++}`,
                    refCounter: 0,
                    isSvg: !1
                };
                let i;
                if (typeof e == "string" ? (s.url = e, i = await ie(e, "blob")) : e instanceof File ? i = s.file = e : e instanceof Blob && (i = e), i.type === "image/svg+xml") {
                    const n = Qe._isSVGFittingCanvas, r = new FileReader, a = new Image, o = new Promise((l, h)=>{
                        a.onload = ()=>{
                            s.bitmap = a, s.isSvg = !0, l();
                        }, r.onload = async ()=>{
                            const d = s.svgUrl = r.result;
                            a.src = await n ? `${d}#svgView(preserveAspectRatio(none))` : d;
                        }, a.onerror = r.onerror = h;
                    });
                    r.readAsDataURL(i), await o;
                } else s.bitmap = await createImageBitmap(i);
                s.refCounter = 1;
            } catch (i) {
                F(i), s = null;
            }
            return this.#s.set(t, s), s && this.#s.set(s.id, s), s;
        }
        async getFromFile(t) {
            const { lastModified: e, name: s, size: i, type: n } = t;
            return this.#i(`${e}_${s}_${i}_${n}`, t);
        }
        async getFromUrl(t) {
            return this.#i(t, t);
        }
        async getFromBlob(t, e) {
            const s = await e;
            return this.#i(t, s);
        }
        async getFromId(t) {
            this.#s ||= new Map;
            const e = this.#s.get(t);
            if (!e) return null;
            if (e.bitmap) return e.refCounter += 1, e;
            if (e.file) return this.getFromFile(e.file);
            if (e.blobPromise) {
                const { blobPromise: s } = e;
                return delete e.blobPromise, this.getFromBlob(e.id, s);
            }
            return this.getFromUrl(e.url);
        }
        getFromCanvas(t, e) {
            this.#s ||= new Map;
            let s = this.#s.get(t);
            if (s?.bitmap) return s.refCounter += 1, s;
            const i = new OffscreenCanvas(e.width, e.height);
            return i.getContext("2d").drawImage(e, 0, 0), s = {
                bitmap: i.transferToImageBitmap(),
                id: `image_${this.#t}_${this.#e++}`,
                refCounter: 1,
                isSvg: !1
            }, this.#s.set(t, s), this.#s.set(s.id, s), s;
        }
        getSvgUrl(t) {
            const e = this.#s.get(t);
            return e?.isSvg ? e.svgUrl : null;
        }
        deleteId(t) {
            this.#s ||= new Map;
            const e = this.#s.get(t);
            if (!e || (e.refCounter -= 1, e.refCounter !== 0)) return;
            const { bitmap: s } = e;
            if (!e.url && !e.file) {
                const i = new OffscreenCanvas(s.width, s.height);
                i.getContext("bitmaprenderer").transferFromImageBitmap(s), e.blobPromise = i.convertToBlob();
            }
            s.close?.(), e.bitmap = null;
        }
        isValidId(t) {
            return t.startsWith(`image_${this.#t}_`);
        }
    }
    class Ii {
        #t = [];
        #e = !1;
        #s;
        #i = -1;
        constructor(t = 128){
            this.#s = t;
        }
        add({ cmd: t, undo: e, post: s, mustExec: i, type: n = NaN, overwriteIfSameType: r = !1, keepUndo: a = !1 }) {
            if (i && t(), this.#e) return;
            const o = {
                cmd: t,
                undo: e,
                post: s,
                type: n
            };
            if (this.#i === -1) {
                this.#t.length > 0 && (this.#t.length = 0), this.#i = 0, this.#t.push(o);
                return;
            }
            if (r && this.#t[this.#i].type === n) {
                a && (o.undo = this.#t[this.#i].undo), this.#t[this.#i] = o;
                return;
            }
            const l = this.#i + 1;
            l === this.#s ? this.#t.splice(0, 1) : (this.#i = l, l < this.#t.length && this.#t.splice(l)), this.#t.push(o);
        }
        undo() {
            if (this.#i === -1) return;
            this.#e = !0;
            const { undo: t, post: e } = this.#t[this.#i];
            t(), e?.(), this.#e = !1, this.#i -= 1;
        }
        redo() {
            if (this.#i < this.#t.length - 1) {
                this.#i += 1, this.#e = !0;
                const { cmd: t, post: e } = this.#t[this.#i];
                t(), e?.(), this.#e = !1;
            }
        }
        hasSomethingToUndo() {
            return this.#i !== -1;
        }
        hasSomethingToRedo() {
            return this.#i < this.#t.length - 1;
        }
        cleanType(t) {
            if (this.#i !== -1) {
                for(let e = this.#i; e >= 0; e--)if (this.#t[e].type !== t) {
                    this.#t.splice(e + 1, this.#i - e), this.#i = e;
                    return;
                }
                this.#t.length = 0, this.#i = -1;
            }
        }
        destroy() {
            this.#t = null;
        }
    }
    class re {
        constructor(t){
            this.buffer = [], this.callbacks = new Map, this.allKeys = new Set;
            const { isMac: e } = st.platform;
            for (const [s, i, n = {}] of t)for (const r of s){
                const a = r.startsWith("mac+");
                e && a ? (this.callbacks.set(r.slice(4), {
                    callback: i,
                    options: n
                }), this.allKeys.add(r.split("+").at(-1))) : !e && !a && (this.callbacks.set(r, {
                    callback: i,
                    options: n
                }), this.allKeys.add(r.split("+").at(-1)));
            }
        }
        #t(t) {
            t.altKey && this.buffer.push("alt"), t.ctrlKey && this.buffer.push("ctrl"), t.metaKey && this.buffer.push("meta"), t.shiftKey && this.buffer.push("shift"), this.buffer.push(t.key);
            const e = this.buffer.join("+");
            return this.buffer.length = 0, e;
        }
        exec(t, e) {
            if (!this.allKeys.has(e.key)) return;
            const s = this.callbacks.get(this.#t(e));
            if (!s) return;
            const { callback: i, options: { bubbles: n = !1, args: r = [], checker: a = null } } = s;
            a && !a(t, e) || (i.bind(t, ...r, e)(), n || Y(e));
        }
    }
    class Je {
        static _colorsMapping = new Map([
            [
                "CanvasText",
                [
                    0,
                    0,
                    0
                ]
            ],
            [
                "Canvas",
                [
                    255,
                    255,
                    255
                ]
            ]
        ]);
        get _colors() {
            const t = new Map([
                [
                    "CanvasText",
                    null
                ],
                [
                    "Canvas",
                    null
                ]
            ]);
            return Ti(t), N(this, "_colors", t);
        }
        convert(t) {
            const e = Ye(t);
            if (!window.matchMedia("(forced-colors: active)").matches) return e;
            for (const [s, i] of this._colors)if (i.every((n, r)=>n === e[r])) return Je._colorsMapping.get(s);
            return e;
        }
        getHexCode(t) {
            const e = this._colors.get(t);
            return e ? P.makeHexColor(...e) : t;
        }
    }
    Rt = class {
        #t = new AbortController;
        #e = null;
        #s = new Map;
        #i = new Map;
        #r = null;
        #n = null;
        #l = null;
        #o = new Ii;
        #d = null;
        #h = null;
        #u = 0;
        #c = new Set;
        #f = null;
        #a = null;
        #p = new Set;
        _editorUndoBar = null;
        #m = !1;
        #g = !1;
        #b = !1;
        #A = null;
        #y = null;
        #v = null;
        #S = null;
        #C = !1;
        #T = null;
        #R = new Ri;
        #_ = !1;
        #P = !1;
        #x = null;
        #k = null;
        #M = null;
        #L = null;
        #$ = null;
        #E = D.NONE;
        #w = new Set;
        #O = null;
        #B = null;
        #U = null;
        #j = null;
        #V = {
            isEditing: !1,
            isEmpty: !0,
            hasSomethingToUndo: !1,
            hasSomethingToRedo: !1,
            hasSelectedEditor: !1,
            hasSelectedText: !1
        };
        #G = [
            0,
            0
        ];
        #D = null;
        #F = null;
        #z = null;
        #N = null;
        static TRANSLATE_SMALL = 1;
        static TRANSLATE_BIG = 10;
        static get _keyboardManager() {
            const t = Rt.prototype, e = (r)=>r.#F.contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && r.hasSomethingToControl(), s = (r, { target: a })=>{
                if (a instanceof HTMLInputElement) {
                    const { type: o } = a;
                    return o !== "text" && o !== "number";
                }
                return !0;
            }, i = this.TRANSLATE_SMALL, n = this.TRANSLATE_BIG;
            return N(this, "_keyboardManager", new re([
                [
                    [
                        "ctrl+a",
                        "mac+meta+a"
                    ],
                    t.selectAll,
                    {
                        checker: s
                    }
                ],
                [
                    [
                        "ctrl+z",
                        "mac+meta+z"
                    ],
                    t.undo,
                    {
                        checker: s
                    }
                ],
                [
                    [
                        "ctrl+y",
                        "ctrl+shift+z",
                        "mac+meta+shift+z",
                        "ctrl+shift+Z",
                        "mac+meta+shift+Z"
                    ],
                    t.redo,
                    {
                        checker: s
                    }
                ],
                [
                    [
                        "Backspace",
                        "alt+Backspace",
                        "ctrl+Backspace",
                        "shift+Backspace",
                        "mac+Backspace",
                        "mac+alt+Backspace",
                        "mac+ctrl+Backspace",
                        "Delete",
                        "ctrl+Delete",
                        "shift+Delete",
                        "mac+Delete"
                    ],
                    t.delete,
                    {
                        checker: s
                    }
                ],
                [
                    [
                        "Enter",
                        "mac+Enter"
                    ],
                    t.addNewEditorFromKeyboard,
                    {
                        checker: (r, { target: a })=>!(a instanceof HTMLButtonElement) && r.#F.contains(a) && !r.isEnterHandled
                    }
                ],
                [
                    [
                        " ",
                        "mac+ "
                    ],
                    t.addNewEditorFromKeyboard,
                    {
                        checker: (r, { target: a })=>!(a instanceof HTMLButtonElement) && r.#F.contains(document.activeElement)
                    }
                ],
                [
                    [
                        "Escape",
                        "mac+Escape"
                    ],
                    t.unselectAll
                ],
                [
                    [
                        "ArrowLeft",
                        "mac+ArrowLeft"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            -i,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowLeft",
                        "mac+shift+ArrowLeft"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            -n,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ArrowRight",
                        "mac+ArrowRight"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            i,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowRight",
                        "mac+shift+ArrowRight"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            n,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ArrowUp",
                        "mac+ArrowUp"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            0,
                            -i
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowUp",
                        "mac+shift+ArrowUp"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            0,
                            -n
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ArrowDown",
                        "mac+ArrowDown"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            0,
                            i
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowDown",
                        "mac+shift+ArrowDown"
                    ],
                    t.translateSelectedEditors,
                    {
                        args: [
                            0,
                            n
                        ],
                        checker: e
                    }
                ]
            ]));
        }
        constructor(t, e, s, i, n, r, a, o, l, h, d, u, f, g){
            const p = this._signal = this.#t.signal;
            this.#F = t, this.#z = e, this.#r = s, this.#B = i, this._eventBus = n, n._on("editingaction", this.onEditingAction.bind(this), {
                signal: p
            }), n._on("pagechanging", this.onPageChanging.bind(this), {
                signal: p
            }), n._on("scalechanging", this.onScaleChanging.bind(this), {
                signal: p
            }), n._on("rotationchanging", this.onRotationChanging.bind(this), {
                signal: p
            }), n._on("setpreference", this.onSetPreference.bind(this), {
                signal: p
            }), n._on("switchannotationeditorparams", (m)=>this.updateParams(m.type, m.value), {
                signal: p
            }), this.#it(), this.#ot(), this.#K(), this.#n = r.annotationStorage, this.#A = r.filterFactory, this.#U = a, this.#S = o || null, this.#m = l, this.#g = h, this.#b = d, this.#$ = u || null, this.viewParameters = {
                realScale: Vt.PDF_TO_CSS_UNITS,
                rotation: 0
            }, this.isShiftKeyDown = !1, this._editorUndoBar = f || null, this._supportsPinchToZoom = g !== !1;
        }
        destroy() {
            this.#N?.resolve(), this.#N = null, this.#t?.abort(), this.#t = null, this._signal = null;
            for (const t of this.#i.values())t.destroy();
            this.#i.clear(), this.#s.clear(), this.#p.clear(), this.#L?.clear(), this.#e = null, this.#w.clear(), this.#o.destroy(), this.#r?.destroy(), this.#B?.destroy(), this.#T?.hide(), this.#T = null, this.#M?.destroy(), this.#M = null, this.#y && (clearTimeout(this.#y), this.#y = null), this.#D && (clearTimeout(this.#D), this.#D = null), this._editorUndoBar?.destroy();
        }
        combinedSignal(t) {
            return AbortSignal.any([
                this._signal,
                t.signal
            ]);
        }
        get mlManager() {
            return this.#$;
        }
        get useNewAltTextFlow() {
            return this.#g;
        }
        get useNewAltTextWhenAddingImage() {
            return this.#b;
        }
        get hcmFilter() {
            return N(this, "hcmFilter", this.#U ? this.#A.addHCMFilter(this.#U.foreground, this.#U.background) : "none");
        }
        get direction() {
            return N(this, "direction", getComputedStyle(this.#F).direction);
        }
        get highlightColors() {
            return N(this, "highlightColors", this.#S ? new Map(this.#S.split(",").map((t)=>t.split("=").map((e)=>e.trim()))) : null);
        }
        get highlightColorNames() {
            return N(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t)=>t.reverse())) : null);
        }
        setCurrentDrawingSession(t) {
            t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), this.#h = t;
        }
        setMainHighlightColorPicker(t) {
            this.#M = t;
        }
        editAltText(t, e = !1) {
            this.#r?.editAltText(this, t, e);
        }
        getSignature(t) {
            this.#B?.getSignature({
                uiManager: this,
                editor: t
            });
        }
        get signatureManager() {
            return this.#B;
        }
        switchToMode(t, e) {
            this._eventBus.on("annotationeditormodechanged", e, {
                once: !0,
                signal: this._signal
            }), this._eventBus.dispatch("showannotationeditorui", {
                source: this,
                mode: t
            });
        }
        setPreference(t, e) {
            this._eventBus.dispatch("setpreference", {
                source: this,
                name: t,
                value: e
            });
        }
        onSetPreference({ name: t, value: e }) {
            switch(t){
                case "enableNewAltTextWhenAddingImage":
                    this.#b = e;
                    break;
            }
        }
        onPageChanging({ pageNumber: t }) {
            this.#u = t - 1;
        }
        focusMainContainer() {
            this.#F.focus();
        }
        findParent(t, e) {
            for (const s of this.#i.values()){
                const { x: i, y: n, width: r, height: a } = s.div.getBoundingClientRect();
                if (t >= i && t <= i + r && e >= n && e <= n + a) return s;
            }
            return null;
        }
        disableUserSelect(t = !1) {
            this.#z.classList.toggle("noUserSelect", t);
        }
        addShouldRescale(t) {
            this.#p.add(t);
        }
        removeShouldRescale(t) {
            this.#p.delete(t);
        }
        onScaleChanging({ scale: t }) {
            this.commitOrRemove(), this.viewParameters.realScale = t * Vt.PDF_TO_CSS_UNITS;
            for (const e of this.#p)e.onScaleChanging();
            this.#h?.onScaleChanging();
        }
        onRotationChanging({ pagesRotation: t }) {
            this.commitOrRemove(), this.viewParameters.rotation = t;
        }
        #q({ anchorNode: t }) {
            return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
        }
        #Y(t) {
            const { currentLayer: e } = this;
            if (e.hasTextLayer(t)) return e;
            for (const s of this.#i.values())if (s.hasTextLayer(t)) return s;
            return null;
        }
        highlightSelection(t = "") {
            const e = document.getSelection();
            if (!e || e.isCollapsed) return;
            const { anchorNode: s, anchorOffset: i, focusNode: n, focusOffset: r } = e, a = e.toString(), l = this.#q(e).closest(".textLayer"), h = this.getSelectionBoxes(l);
            if (!h) return;
            e.empty();
            const d = this.#Y(l), u = this.#E === D.NONE, f = ()=>{
                d?.createAndAddNewEditor({
                    x: 0,
                    y: 0
                }, !1, {
                    methodOfCreation: t,
                    boxes: h,
                    anchorNode: s,
                    anchorOffset: i,
                    focusNode: n,
                    focusOffset: r,
                    text: a
                }), u && this.showAllEditors("highlight", !0, !0);
            };
            if (u) {
                this.switchToMode(D.HIGHLIGHT, f);
                return;
            }
            f();
        }
        #et() {
            const t = document.getSelection();
            if (!t || t.isCollapsed) return;
            const s = this.#q(t).closest(".textLayer"), i = this.getSelectionBoxes(s);
            i && (this.#T ||= new Pi(this), this.#T.show(s, i, this.direction === "ltr"));
        }
        addToAnnotationStorage(t) {
            !t.isEmpty() && this.#n && !this.#n.has(t.id) && this.#n.setValue(t.id, t);
        }
        #st() {
            const t = document.getSelection();
            if (!t || t.isCollapsed) {
                this.#O && (this.#T?.hide(), this.#O = null, this.#I({
                    hasSelectedText: !1
                }));
                return;
            }
            const { anchorNode: e } = t;
            if (e === this.#O) return;
            const i = this.#q(t).closest(".textLayer");
            if (!i) {
                this.#O && (this.#T?.hide(), this.#O = null, this.#I({
                    hasSelectedText: !1
                }));
                return;
            }
            if (this.#T?.hide(), this.#O = e, this.#I({
                hasSelectedText: !0
            }), !(this.#E !== D.HIGHLIGHT && this.#E !== D.NONE) && (this.#E === D.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), this.#C = this.isShiftKeyDown, !this.isShiftKeyDown)) {
                const n = this.#E === D.HIGHLIGHT ? this.#Y(i) : null;
                n?.toggleDrawing();
                const r = new AbortController, a = this.combinedSignal(r), o = (l)=>{
                    l.type === "pointerup" && l.button !== 0 || (r.abort(), n?.toggleDrawing(!0), l.type === "pointerup" && this.#X("main_toolbar"));
                };
                window.addEventListener("pointerup", o, {
                    signal: a
                }), window.addEventListener("blur", o, {
                    signal: a
                });
            }
        }
        #X(t = "") {
            this.#E === D.HIGHLIGHT ? this.highlightSelection(t) : this.#m && this.#et();
        }
        #it() {
            document.addEventListener("selectionchange", this.#st.bind(this), {
                signal: this._signal
            });
        }
        #nt() {
            if (this.#v) return;
            this.#v = new AbortController;
            const t = this.combinedSignal(this.#v);
            window.addEventListener("focus", this.focus.bind(this), {
                signal: t
            }), window.addEventListener("blur", this.blur.bind(this), {
                signal: t
            });
        }
        #rt() {
            this.#v?.abort(), this.#v = null;
        }
        blur() {
            if (this.isShiftKeyDown = !1, this.#C && (this.#C = !1, this.#X("main_toolbar")), !this.hasSelection) return;
            const { activeElement: t } = document;
            for (const e of this.#w)if (e.div.contains(t)) {
                this.#k = [
                    e,
                    t
                ], e._focusEventsAllowed = !1;
                break;
            }
        }
        focus() {
            if (!this.#k) return;
            const [t, e] = this.#k;
            this.#k = null, e.addEventListener("focusin", ()=>{
                t._focusEventsAllowed = !0;
            }, {
                once: !0,
                signal: this._signal
            }), e.focus();
        }
        #K() {
            if (this.#x) return;
            this.#x = new AbortController;
            const t = this.combinedSignal(this.#x);
            window.addEventListener("keydown", this.keydown.bind(this), {
                signal: t
            }), window.addEventListener("keyup", this.keyup.bind(this), {
                signal: t
            });
        }
        #at() {
            this.#x?.abort(), this.#x = null;
        }
        #Q() {
            if (this.#d) return;
            this.#d = new AbortController;
            const t = this.combinedSignal(this.#d);
            document.addEventListener("copy", this.copy.bind(this), {
                signal: t
            }), document.addEventListener("cut", this.cut.bind(this), {
                signal: t
            }), document.addEventListener("paste", this.paste.bind(this), {
                signal: t
            });
        }
        #J() {
            this.#d?.abort(), this.#d = null;
        }
        #ot() {
            const t = this._signal;
            document.addEventListener("dragover", this.dragOver.bind(this), {
                signal: t
            }), document.addEventListener("drop", this.drop.bind(this), {
                signal: t
            });
        }
        addEditListeners() {
            this.#K(), this.#Q();
        }
        removeEditListeners() {
            this.#at(), this.#J();
        }
        dragOver(t) {
            for (const { type: e } of t.dataTransfer.items)for (const s of this.#a)if (s.isHandlingMimeForPasting(e)) {
                t.dataTransfer.dropEffect = "copy", t.preventDefault();
                return;
            }
        }
        drop(t) {
            for (const e of t.dataTransfer.items)for (const s of this.#a)if (s.isHandlingMimeForPasting(e.type)) {
                s.paste(e, this.currentLayer), t.preventDefault();
                return;
            }
        }
        copy(t) {
            if (t.preventDefault(), this.#e?.commitOrRemove(), !this.hasSelection) return;
            const e = [];
            for (const s of this.#w){
                const i = s.serialize(!0);
                i && e.push(i);
            }
            e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
        }
        cut(t) {
            this.copy(t), this.delete();
        }
        async paste(t) {
            t.preventDefault();
            const { clipboardData: e } = t;
            for (const n of e.items)for (const r of this.#a)if (r.isHandlingMimeForPasting(n.type)) {
                r.paste(n, this.currentLayer);
                return;
            }
            let s = e.getData("application/pdfjs");
            if (!s) return;
            try {
                s = JSON.parse(s);
            } catch (n) {
                F(`paste: "${n.message}".`);
                return;
            }
            if (!Array.isArray(s)) return;
            this.unselectAll();
            const i = this.currentLayer;
            try {
                const n = [];
                for (const o of s){
                    const l = await i.deserialize(o);
                    if (!l) return;
                    n.push(l);
                }
                const r = ()=>{
                    for (const o of n)this.#Z(o);
                    this.#tt(n);
                }, a = ()=>{
                    for (const o of n)o.remove();
                };
                this.addCommands({
                    cmd: r,
                    undo: a,
                    mustExec: !0
                });
            } catch (n) {
                F(`paste: "${n.message}".`);
            }
        }
        keydown(t) {
            !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), this.#E !== D.NONE && !this.isEditorHandlingKeyboard && Rt._keyboardManager.exec(this, t);
        }
        keyup(t) {
            this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, this.#C && (this.#C = !1, this.#X("main_toolbar")));
        }
        onEditingAction({ name: t }) {
            switch(t){
                case "undo":
                case "redo":
                case "delete":
                case "selectAll":
                    this[t]();
                    break;
                case "highlightSelection":
                    this.highlightSelection("context_menu");
                    break;
            }
        }
        #I(t) {
            Object.entries(t).some(([s, i])=>this.#V[s] !== i) && (this._eventBus.dispatch("annotationeditorstateschanged", {
                source: this,
                details: Object.assign(this.#V, t)
            }), this.#E === D.HIGHLIGHT && t.hasSelectedEditor === !1 && this.#H([
                [
                    O.HIGHLIGHT_FREE,
                    !0
                ]
            ]));
        }
        #H(t) {
            this._eventBus.dispatch("annotationeditorparamschanged", {
                source: this,
                details: t
            });
        }
        setEditingState(t) {
            t ? (this.#nt(), this.#Q(), this.#I({
                isEditing: this.#E !== D.NONE,
                isEmpty: this.#W(),
                hasSomethingToUndo: this.#o.hasSomethingToUndo(),
                hasSomethingToRedo: this.#o.hasSomethingToRedo(),
                hasSelectedEditor: !1
            })) : (this.#rt(), this.#J(), this.#I({
                isEditing: !1
            }), this.disableUserSelect(!1));
        }
        registerEditorTypes(t) {
            if (!this.#a) {
                this.#a = t;
                for (const e of this.#a)this.#H(e.defaultPropertiesToUpdate);
            }
        }
        getId() {
            return this.#R.id;
        }
        get currentLayer() {
            return this.#i.get(this.#u);
        }
        getLayer(t) {
            return this.#i.get(t);
        }
        get currentPageIndex() {
            return this.#u;
        }
        addLayer(t) {
            this.#i.set(t.pageIndex, t), this.#_ ? t.enable() : t.disable();
        }
        removeLayer(t) {
            this.#i.delete(t.pageIndex);
        }
        async updateMode(t, e = null, s = !1) {
            if (this.#E !== t && !(this.#N && (await this.#N.promise, !this.#N))) {
                if (this.#N = Promise.withResolvers(), this.#h?.commitOrRemove(), this.#E = t, t === D.NONE) {
                    this.setEditingState(!1), this.#ht(), this._editorUndoBar?.hide(), this.#N.resolve();
                    return;
                }
                t === D.SIGNATURE && await this.#B?.loadSignatures(), this.setEditingState(!0), await this.#lt(), this.unselectAll();
                for (const i of this.#i.values())i.updateMode(t);
                if (!e) {
                    s && this.addNewEditorFromKeyboard(), this.#N.resolve();
                    return;
                }
                for (const i of this.#s.values())i.annotationElementId === e ? (this.setSelected(i), i.enterInEditMode()) : i.unselect();
                this.#N.resolve();
            }
        }
        addNewEditorFromKeyboard() {
            this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
        }
        updateToolbar(t) {
            t !== this.#E && this._eventBus.dispatch("switchannotationeditormode", {
                source: this,
                mode: t
            });
        }
        updateParams(t, e) {
            if (this.#a) {
                switch(t){
                    case O.CREATE:
                        this.currentLayer.addNewEditor(e);
                        return;
                    case O.HIGHLIGHT_DEFAULT_COLOR:
                        this.#M?.updateColor(e);
                        break;
                    case O.HIGHLIGHT_SHOW_ALL:
                        this._eventBus.dispatch("reporttelemetry", {
                            source: this,
                            details: {
                                type: "editing",
                                data: {
                                    type: "highlight",
                                    action: "toggle_visibility"
                                }
                            }
                        }), (this.#j ||= new Map).set(t, e), this.showAllEditors("highlight", e);
                        break;
                }
                for (const s of this.#w)s.updateParams(t, e);
                for (const s of this.#a)s.updateDefaultParams(t, e);
            }
        }
        showAllEditors(t, e, s = !1) {
            for (const n of this.#s.values())n.editorType === t && n.show(e);
            (this.#j?.get(O.HIGHLIGHT_SHOW_ALL) ?? !0) !== e && this.#H([
                [
                    O.HIGHLIGHT_SHOW_ALL,
                    e
                ]
            ]);
        }
        enableWaiting(t = !1) {
            if (this.#P !== t) {
                this.#P = t;
                for (const e of this.#i.values())t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
            }
        }
        async #lt() {
            if (!this.#_) {
                this.#_ = !0;
                const t = [];
                for (const e of this.#i.values())t.push(e.enable());
                await Promise.all(t);
                for (const e of this.#s.values())e.enable();
            }
        }
        #ht() {
            if (this.unselectAll(), this.#_) {
                this.#_ = !1;
                for (const t of this.#i.values())t.disable();
                for (const t of this.#s.values())t.disable();
            }
        }
        getEditors(t) {
            const e = [];
            for (const s of this.#s.values())s.pageIndex === t && e.push(s);
            return e;
        }
        getEditor(t) {
            return this.#s.get(t);
        }
        addEditor(t) {
            this.#s.set(t.id, t);
        }
        removeEditor(t) {
            t.div.contains(document.activeElement) && (this.#y && clearTimeout(this.#y), this.#y = setTimeout(()=>{
                this.focusMainContainer(), this.#y = null;
            }, 0)), this.#s.delete(t.id), t.annotationElementId && this.#L?.delete(t.annotationElementId), this.unselect(t), (!t.annotationElementId || !this.#c.has(t.annotationElementId)) && this.#n?.remove(t.id);
        }
        addDeletedAnnotationElement(t) {
            this.#c.add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
        }
        isDeletedAnnotationElement(t) {
            return this.#c.has(t);
        }
        removeDeletedAnnotationElement(t) {
            this.#c.delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
        }
        #Z(t) {
            const e = this.#i.get(t.pageIndex);
            e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
        }
        setActiveEditor(t) {
            this.#e !== t && (this.#e = t, t && this.#H(t.propertiesToUpdate));
        }
        get #ct() {
            let t = null;
            for (t of this.#w);
            return t;
        }
        updateUI(t) {
            this.#ct === t && this.#H(t.propertiesToUpdate);
        }
        updateUIForDefaultProperties(t) {
            this.#H(t.defaultPropertiesToUpdate);
        }
        toggleSelected(t) {
            if (this.#w.has(t)) {
                this.#w.delete(t), t.unselect(), this.#I({
                    hasSelectedEditor: this.hasSelection
                });
                return;
            }
            this.#w.add(t), t.select(), this.#H(t.propertiesToUpdate), this.#I({
                hasSelectedEditor: !0
            });
        }
        setSelected(t) {
            this.#h?.commitOrRemove();
            for (const e of this.#w)e !== t && e.unselect();
            this.#w.clear(), this.#w.add(t), t.select(), this.#H(t.propertiesToUpdate), this.#I({
                hasSelectedEditor: !0
            });
        }
        isSelected(t) {
            return this.#w.has(t);
        }
        get firstSelectedEditor() {
            return this.#w.values().next().value;
        }
        unselect(t) {
            t.unselect(), this.#w.delete(t), this.#I({
                hasSelectedEditor: this.hasSelection
            });
        }
        get hasSelection() {
            return this.#w.size !== 0;
        }
        get isEnterHandled() {
            return this.#w.size === 1 && this.firstSelectedEditor.isEnterHandled;
        }
        undo() {
            this.#o.undo(), this.#I({
                hasSomethingToUndo: this.#o.hasSomethingToUndo(),
                hasSomethingToRedo: !0,
                isEmpty: this.#W()
            }), this._editorUndoBar?.hide();
        }
        redo() {
            this.#o.redo(), this.#I({
                hasSomethingToUndo: !0,
                hasSomethingToRedo: this.#o.hasSomethingToRedo(),
                isEmpty: this.#W()
            });
        }
        addCommands(t) {
            this.#o.add(t), this.#I({
                hasSomethingToUndo: !0,
                hasSomethingToRedo: !1,
                isEmpty: this.#W()
            });
        }
        cleanUndoStack(t) {
            this.#o.cleanType(t);
        }
        #W() {
            if (this.#s.size === 0) return !0;
            if (this.#s.size === 1) for (const t of this.#s.values())return t.isEmpty();
            return !1;
        }
        delete() {
            this.commitOrRemove();
            const t = this.currentLayer?.endDrawingSession(!0);
            if (!this.hasSelection && !t) return;
            const e = t ? [
                t
            ] : [
                ...this.#w
            ], s = ()=>{
                this._editorUndoBar?.show(i, e.length === 1 ? e[0].editorType : e.length);
                for (const n of e)n.remove();
            }, i = ()=>{
                for (const n of e)this.#Z(n);
            };
            this.addCommands({
                cmd: s,
                undo: i,
                mustExec: !0
            });
        }
        commitOrRemove() {
            this.#e?.commitOrRemove();
        }
        hasSomethingToControl() {
            return this.#e || this.hasSelection;
        }
        #tt(t) {
            for (const e of this.#w)e.unselect();
            this.#w.clear();
            for (const e of t)e.isEmpty() || (this.#w.add(e), e.select());
            this.#I({
                hasSelectedEditor: this.hasSelection
            });
        }
        selectAll() {
            for (const t of this.#w)t.commit();
            this.#tt(this.#s.values());
        }
        unselectAll() {
            if (!(this.#e && (this.#e.commitOrRemove(), this.#E !== D.NONE)) && !this.#h?.commitOrRemove() && this.hasSelection) {
                for (const t of this.#w)t.unselect();
                this.#w.clear(), this.#I({
                    hasSelectedEditor: !1
                });
            }
        }
        translateSelectedEditors(t, e, s = !1) {
            if (s || this.commitOrRemove(), !this.hasSelection) return;
            this.#G[0] += t, this.#G[1] += e;
            const [i, n] = this.#G, r = [
                ...this.#w
            ], a = 1e3;
            this.#D && clearTimeout(this.#D), this.#D = setTimeout(()=>{
                this.#D = null, this.#G[0] = this.#G[1] = 0, this.addCommands({
                    cmd: ()=>{
                        for (const o of r)this.#s.has(o.id) && (o.translateInPage(i, n), o.translationDone());
                    },
                    undo: ()=>{
                        for (const o of r)this.#s.has(o.id) && (o.translateInPage(-i, -n), o.translationDone());
                    },
                    mustExec: !1
                });
            }, a);
            for (const o of r)o.translateInPage(t, e), o.translationDone();
        }
        setUpDragSession() {
            if (this.hasSelection) {
                this.disableUserSelect(!0), this.#f = new Map;
                for (const t of this.#w)this.#f.set(t, {
                    savedX: t.x,
                    savedY: t.y,
                    savedPageIndex: t.pageIndex,
                    newX: 0,
                    newY: 0,
                    newPageIndex: -1
                });
            }
        }
        endDragSession() {
            if (!this.#f) return !1;
            this.disableUserSelect(!1);
            const t = this.#f;
            this.#f = null;
            let e = !1;
            for (const [{ x: i, y: n, pageIndex: r }, a] of t)a.newX = i, a.newY = n, a.newPageIndex = r, e ||= i !== a.savedX || n !== a.savedY || r !== a.savedPageIndex;
            if (!e) return !1;
            const s = (i, n, r, a)=>{
                if (this.#s.has(i.id)) {
                    const o = this.#i.get(a);
                    o ? i._setParentAndPosition(o, n, r) : (i.pageIndex = a, i.x = n, i.y = r);
                }
            };
            return this.addCommands({
                cmd: ()=>{
                    for (const [i, { newX: n, newY: r, newPageIndex: a }] of t)s(i, n, r, a);
                },
                undo: ()=>{
                    for (const [i, { savedX: n, savedY: r, savedPageIndex: a }] of t)s(i, n, r, a);
                },
                mustExec: !0
            }), !0;
        }
        dragSelectedEditors(t, e) {
            if (this.#f) for (const s of this.#f.keys())s.drag(t, e);
        }
        rebuild(t) {
            if (t.parent === null) {
                const e = this.getLayer(t.pageIndex);
                e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
            } else t.parent.addOrRebuild(t);
        }
        get isEditorHandlingKeyboard() {
            return this.getActive()?.shouldGetKeyboardEvents() || this.#w.size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
        }
        isActive(t) {
            return this.#e === t;
        }
        getActive() {
            return this.#e;
        }
        getMode() {
            return this.#E;
        }
        get imageManager() {
            return N(this, "imageManager", new Qe);
        }
        getSelectionBoxes(t) {
            if (!t) return null;
            const e = document.getSelection();
            for(let l = 0, h = e.rangeCount; l < h; l++)if (!t.contains(e.getRangeAt(l).commonAncestorContainer)) return null;
            const { x: s, y: i, width: n, height: r } = t.getBoundingClientRect();
            let a;
            switch(t.getAttribute("data-main-rotation")){
                case "90":
                    a = (l, h, d, u)=>({
                            x: (h - i) / r,
                            y: 1 - (l + d - s) / n,
                            width: u / r,
                            height: d / n
                        });
                    break;
                case "180":
                    a = (l, h, d, u)=>({
                            x: 1 - (l + d - s) / n,
                            y: 1 - (h + u - i) / r,
                            width: d / n,
                            height: u / r
                        });
                    break;
                case "270":
                    a = (l, h, d, u)=>({
                            x: 1 - (h + u - i) / r,
                            y: (l - s) / n,
                            width: u / r,
                            height: d / n
                        });
                    break;
                default:
                    a = (l, h, d, u)=>({
                            x: (l - s) / n,
                            y: (h - i) / r,
                            width: d / n,
                            height: u / r
                        });
                    break;
            }
            const o = [];
            for(let l = 0, h = e.rangeCount; l < h; l++){
                const d = e.getRangeAt(l);
                if (!d.collapsed) for (const { x: u, y: f, width: g, height: p } of d.getClientRects())g === 0 || p === 0 || o.push(a(u, f, g, p));
            }
            return o.length === 0 ? null : o;
        }
        addChangedExistingAnnotation({ annotationElementId: t, id: e }) {
            (this.#l ||= new Map).set(t, e);
        }
        removeChangedExistingAnnotation({ annotationElementId: t }) {
            this.#l?.delete(t);
        }
        renderAnnotationElement(t) {
            const e = this.#l?.get(t.data.id);
            if (!e) return;
            const s = this.#n.getRawValue(e);
            s && (this.#E === D.NONE && !s.hasBeenModified || s.renderAnnotationElement(t));
        }
        setMissingCanvas(t, e, s) {
            const i = this.#L?.get(t);
            i && (i.setCanvas(e, s), this.#L.delete(t));
        }
        addMissingCanvas(t, e) {
            (this.#L ||= new Map).set(t, e);
        }
    };
    class yt {
        #t = null;
        #e = !1;
        #s = null;
        #i = null;
        #r = null;
        #n = null;
        #l = !1;
        #o = null;
        #d = null;
        #h = null;
        #u = null;
        #c = !1;
        static #f = null;
        static _l10n = null;
        constructor(t){
            this.#d = t, this.#c = t._uiManager.useNewAltTextFlow, yt.#f ||= Object.freeze({
                added: "pdfjs-editor-new-alt-text-added-button",
                "added-label": "pdfjs-editor-new-alt-text-added-button-label",
                missing: "pdfjs-editor-new-alt-text-missing-button",
                "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
                review: "pdfjs-editor-new-alt-text-to-review-button",
                "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
            });
        }
        static initialize(t) {
            yt._l10n ??= t;
        }
        async render() {
            const t = this.#s = document.createElement("button");
            t.className = "altText", t.tabIndex = "0";
            const e = this.#i = document.createElement("span");
            t.append(e), this.#c ? (t.classList.add("new"), t.setAttribute("data-l10n-id", yt.#f.missing), e.setAttribute("data-l10n-id", yt.#f["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
            const s = this.#d._uiManager._signal;
            t.addEventListener("contextmenu", gt, {
                signal: s
            }), t.addEventListener("pointerdown", (n)=>n.stopPropagation(), {
                signal: s
            });
            const i = (n)=>{
                n.preventDefault(), this.#d._uiManager.editAltText(this.#d), this.#c && this.#d._reportTelemetry({
                    action: "pdfjs.image.alt_text.image_status_label_clicked",
                    data: {
                        label: this.#a
                    }
                });
            };
            return t.addEventListener("click", i, {
                capture: !0,
                signal: s
            }), t.addEventListener("keydown", (n)=>{
                n.target === t && n.key === "Enter" && (this.#l = !0, i(n));
            }, {
                signal: s
            }), await this.#p(), t;
        }
        get #a() {
            return this.#t && "added" || this.#t === null && this.guessedText && "review" || "missing";
        }
        finish() {
            this.#s && (this.#s.focus({
                focusVisible: this.#l
            }), this.#l = !1);
        }
        isEmpty() {
            return this.#c ? this.#t === null : !this.#t && !this.#e;
        }
        hasData() {
            return this.#c ? this.#t !== null || !!this.#h : this.isEmpty();
        }
        get guessedText() {
            return this.#h;
        }
        async setGuessedText(t) {
            this.#t === null && (this.#h = t, this.#u = await yt._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
                generatedAltText: t
            }), this.#p());
        }
        toggleAltTextBadge(t = !1) {
            if (!this.#c || this.#t) {
                this.#o?.remove(), this.#o = null;
                return;
            }
            if (!this.#o) {
                const e = this.#o = document.createElement("div");
                e.className = "noAltTextBadge", this.#d.div.append(e);
            }
            this.#o.classList.toggle("hidden", !t);
        }
        serialize(t) {
            let e = this.#t;
            return !t && this.#h === e && (e = this.#u), {
                altText: e,
                decorative: this.#e,
                guessedText: this.#h,
                textWithDisclaimer: this.#u
            };
        }
        get data() {
            return {
                altText: this.#t,
                decorative: this.#e
            };
        }
        set data({ altText: t, decorative: e, guessedText: s, textWithDisclaimer: i, cancel: n = !1 }) {
            s && (this.#h = s, this.#u = i), !(this.#t === t && this.#e === e) && (n || (this.#t = t, this.#e = e), this.#p());
        }
        toggle(t = !1) {
            this.#s && (!t && this.#n && (clearTimeout(this.#n), this.#n = null), this.#s.disabled = !t);
        }
        shown() {
            this.#d._reportTelemetry({
                action: "pdfjs.image.alt_text.image_status_label_displayed",
                data: {
                    label: this.#a
                }
            });
        }
        destroy() {
            this.#s?.remove(), this.#s = null, this.#i = null, this.#r = null, this.#o?.remove(), this.#o = null;
        }
        async #p() {
            const t = this.#s;
            if (!t) return;
            if (this.#c) {
                if (t.classList.toggle("done", !!this.#t), t.setAttribute("data-l10n-id", yt.#f[this.#a]), this.#i?.setAttribute("data-l10n-id", yt.#f[`${this.#a}-label`]), !this.#t) {
                    this.#r?.remove();
                    return;
                }
            } else {
                if (!this.#t && !this.#e) {
                    t.classList.remove("done"), this.#r?.remove();
                    return;
                }
                t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
            }
            let e = this.#r;
            if (!e) {
                this.#r = e = document.createElement("span"), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${this.#d.id}`;
                const i = 100, n = this.#d._uiManager._signal;
                n.addEventListener("abort", ()=>{
                    clearTimeout(this.#n), this.#n = null;
                }, {
                    once: !0
                }), t.addEventListener("mouseenter", ()=>{
                    this.#n = setTimeout(()=>{
                        this.#n = null, this.#r.classList.add("show"), this.#d._reportTelemetry({
                            action: "alt_text_tooltip"
                        });
                    }, i);
                }, {
                    signal: n
                }), t.addEventListener("mouseleave", ()=>{
                    this.#n && (clearTimeout(this.#n), this.#n = null), this.#r?.classList.remove("show");
                }, {
                    signal: n
                });
            }
            this.#e ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = this.#t), e.parentNode || t.append(e), this.#d.getElementForAltText()?.setAttribute("aria-describedby", e.id);
        }
    }
    Ee = class {
        #t;
        #e = !1;
        #s = null;
        #i;
        #r;
        #n;
        #l;
        #o = null;
        #d;
        #h = null;
        #u;
        #c = null;
        constructor({ container: t, isPinchingDisabled: e = null, isPinchingStopped: s = null, onPinchStart: i = null, onPinching: n = null, onPinchEnd: r = null, signal: a }){
            this.#t = t, this.#s = s, this.#i = e, this.#r = i, this.#n = n, this.#l = r, this.#u = new AbortController, this.#d = AbortSignal.any([
                a,
                this.#u.signal
            ]), t.addEventListener("touchstart", this.#f.bind(this), {
                passive: !1,
                signal: this.#d
            });
        }
        get MIN_TOUCH_DISTANCE_TO_PINCH() {
            return 35 / Et.pixelRatio;
        }
        #f(t) {
            if (this.#i?.()) return;
            if (t.touches.length === 1) {
                if (this.#o) return;
                const i = this.#o = new AbortController, n = AbortSignal.any([
                    this.#d,
                    i.signal
                ]), r = this.#t, a = {
                    capture: !0,
                    signal: n,
                    passive: !1
                }, o = (l)=>{
                    l.pointerType === "touch" && (this.#o?.abort(), this.#o = null);
                };
                r.addEventListener("pointerdown", (l)=>{
                    l.pointerType === "touch" && (Y(l), o(l));
                }, a), r.addEventListener("pointerup", o, a), r.addEventListener("pointercancel", o, a);
                return;
            }
            if (!this.#c) {
                this.#c = new AbortController;
                const i = AbortSignal.any([
                    this.#d,
                    this.#c.signal
                ]), n = this.#t, r = {
                    signal: i,
                    capture: !1,
                    passive: !1
                };
                n.addEventListener("touchmove", this.#a.bind(this), r);
                const a = this.#p.bind(this);
                n.addEventListener("touchend", a, r), n.addEventListener("touchcancel", a, r), r.capture = !0, n.addEventListener("pointerdown", Y, r), n.addEventListener("pointermove", Y, r), n.addEventListener("pointercancel", Y, r), n.addEventListener("pointerup", Y, r), this.#r?.();
            }
            if (Y(t), t.touches.length !== 2 || this.#s?.()) {
                this.#h = null;
                return;
            }
            let [e, s] = t.touches;
            e.identifier > s.identifier && ([e, s] = [
                s,
                e
            ]), this.#h = {
                touch0X: e.screenX,
                touch0Y: e.screenY,
                touch1X: s.screenX,
                touch1Y: s.screenY
            };
        }
        #a(t) {
            if (!this.#h || t.touches.length !== 2) return;
            Y(t);
            let [e, s] = t.touches;
            e.identifier > s.identifier && ([e, s] = [
                s,
                e
            ]);
            const { screenX: i, screenY: n } = e, { screenX: r, screenY: a } = s, o = this.#h, { touch0X: l, touch0Y: h, touch1X: d, touch1Y: u } = o, f = d - l, g = u - h, p = r - i, m = a - n, b = Math.hypot(p, m) || 1, y = Math.hypot(f, g) || 1;
            if (!this.#e && Math.abs(y - b) <= Ee.MIN_TOUCH_DISTANCE_TO_PINCH) return;
            if (o.touch0X = i, o.touch0Y = n, o.touch1X = r, o.touch1Y = a, !this.#e) {
                this.#e = !0;
                return;
            }
            const A = [
                (i + r) / 2,
                (n + a) / 2
            ];
            this.#n?.(A, y, b);
        }
        #p(t) {
            t.touches.length >= 2 || (this.#c && (this.#c.abort(), this.#c = null, this.#l?.()), this.#h && (Y(t), this.#h = null, this.#e = !1));
        }
        destroy() {
            this.#u?.abort(), this.#u = null, this.#o?.abort(), this.#o = null;
        }
    };
    class k {
        #t = null;
        #e = null;
        #s = null;
        #i = !1;
        #r = null;
        #n = "";
        #l = !1;
        #o = null;
        #d = null;
        #h = null;
        #u = null;
        #c = "";
        #f = !1;
        #a = null;
        #p = !1;
        #m = !1;
        #g = !1;
        #b = null;
        #A = 0;
        #y = 0;
        #v = null;
        #S = null;
        _isCopy = !1;
        _editToolbar = null;
        _initialOptions = Object.create(null);
        _initialData = null;
        _isVisible = !0;
        _uiManager = null;
        _focusEventsAllowed = !0;
        static _l10n = null;
        static _l10nResizer = null;
        #C = !1;
        #T = k._zIndex++;
        static _borderLineWidth = -1;
        static _colorManager = new Je;
        static _zIndex = 1;
        static _telemetryTimeout = 1e3;
        static get _resizerKeyboardManager() {
            const t = k.prototype._resizeWithKeyboard, e = Rt.TRANSLATE_SMALL, s = Rt.TRANSLATE_BIG;
            return N(this, "_resizerKeyboardManager", new re([
                [
                    [
                        "ArrowLeft",
                        "mac+ArrowLeft"
                    ],
                    t,
                    {
                        args: [
                            -e,
                            0
                        ]
                    }
                ],
                [
                    [
                        "ctrl+ArrowLeft",
                        "mac+shift+ArrowLeft"
                    ],
                    t,
                    {
                        args: [
                            -s,
                            0
                        ]
                    }
                ],
                [
                    [
                        "ArrowRight",
                        "mac+ArrowRight"
                    ],
                    t,
                    {
                        args: [
                            e,
                            0
                        ]
                    }
                ],
                [
                    [
                        "ctrl+ArrowRight",
                        "mac+shift+ArrowRight"
                    ],
                    t,
                    {
                        args: [
                            s,
                            0
                        ]
                    }
                ],
                [
                    [
                        "ArrowUp",
                        "mac+ArrowUp"
                    ],
                    t,
                    {
                        args: [
                            0,
                            -e
                        ]
                    }
                ],
                [
                    [
                        "ctrl+ArrowUp",
                        "mac+shift+ArrowUp"
                    ],
                    t,
                    {
                        args: [
                            0,
                            -s
                        ]
                    }
                ],
                [
                    [
                        "ArrowDown",
                        "mac+ArrowDown"
                    ],
                    t,
                    {
                        args: [
                            0,
                            e
                        ]
                    }
                ],
                [
                    [
                        "ctrl+ArrowDown",
                        "mac+shift+ArrowDown"
                    ],
                    t,
                    {
                        args: [
                            0,
                            s
                        ]
                    }
                ],
                [
                    [
                        "Escape",
                        "mac+Escape"
                    ],
                    k.prototype._stopResizingWithKeyboard
                ]
            ]));
        }
        constructor(t){
            this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null;
            const { rotation: e, rawDims: { pageWidth: s, pageHeight: i, pageX: n, pageY: r } } = this.parent.viewport;
            this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [
                s,
                i
            ], this.pageTranslation = [
                n,
                r
            ];
            const [a, o] = this.parentDimensions;
            this.x = t.x / a, this.y = t.y / o, this.isAttachedToDOM = !1, this.deleted = !1;
        }
        get editorType() {
            return Object.getPrototypeOf(this).constructor._type;
        }
        static get isDrawer() {
            return !1;
        }
        static get _defaultLineColor() {
            return N(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
        }
        static deleteAnnotationElement(t) {
            const e = new ki({
                id: t.parent.getNextId(),
                parent: t.parent,
                uiManager: t._uiManager
            });
            e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
        }
        static initialize(t, e) {
            if (k._l10n ??= t, k._l10nResizer ||= Object.freeze({
                topLeft: "pdfjs-editor-resizer-top-left",
                topMiddle: "pdfjs-editor-resizer-top-middle",
                topRight: "pdfjs-editor-resizer-top-right",
                middleRight: "pdfjs-editor-resizer-middle-right",
                bottomRight: "pdfjs-editor-resizer-bottom-right",
                bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
                bottomLeft: "pdfjs-editor-resizer-bottom-left",
                middleLeft: "pdfjs-editor-resizer-middle-left"
            }), k._borderLineWidth !== -1) return;
            const s = getComputedStyle(document.documentElement);
            k._borderLineWidth = parseFloat(s.getPropertyValue("--outline-width")) || 0;
        }
        static updateDefaultParams(t, e) {}
        static get defaultPropertiesToUpdate() {
            return [];
        }
        static isHandlingMimeForPasting(t) {
            return !1;
        }
        static paste(t, e) {
            $("Not implemented");
        }
        get propertiesToUpdate() {
            return [];
        }
        get _isDraggable() {
            return this.#C;
        }
        set _isDraggable(t) {
            this.#C = t, this.div?.classList.toggle("draggable", t);
        }
        get isEnterHandled() {
            return !0;
        }
        center() {
            const [t, e] = this.pageDimensions;
            switch(this.parentRotation){
                case 90:
                    this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
                    break;
                case 180:
                    this.x += this.width / 2, this.y += this.height / 2;
                    break;
                case 270:
                    this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
                    break;
                default:
                    this.x -= this.width / 2, this.y -= this.height / 2;
                    break;
            }
            this.fixAndSetPosition();
        }
        addCommands(t) {
            this._uiManager.addCommands(t);
        }
        get currentLayer() {
            return this._uiManager.currentLayer;
        }
        setInBackground() {
            this.div.style.zIndex = 0;
        }
        setInForeground() {
            this.div.style.zIndex = this.#T;
        }
        setParent(t) {
            t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : this.#z(), this.parent = t;
        }
        focusin(t) {
            this._focusEventsAllowed && (this.#f ? this.#f = !1 : this.parent.setSelected(this));
        }
        focusout(t) {
            !this._focusEventsAllowed || !this.isAttachedToDOM || t.relatedTarget?.closest(`#${this.id}`) || (t.preventDefault(), this.parent?.isMultipleSelection || this.commitOrRemove());
        }
        commitOrRemove() {
            this.isEmpty() ? this.remove() : this.commit();
        }
        commit() {
            this.addToAnnotationStorage();
        }
        addToAnnotationStorage() {
            this._uiManager.addToAnnotationStorage(this);
        }
        setAt(t, e, s, i) {
            const [n, r] = this.parentDimensions;
            [s, i] = this.screenToPageTranslation(s, i), this.x = (t + s) / n, this.y = (e + i) / r, this.fixAndSetPosition();
        }
        _moveAfterPaste(t, e) {
            const [s, i] = this.parentDimensions;
            this.setAt(t * s, e * i, this.width * s, this.height * i), this._onTranslated();
        }
        #R([t, e], s, i) {
            [s, i] = this.screenToPageTranslation(s, i), this.x += s / t, this.y += i / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
        }
        translate(t, e) {
            this.#R(this.parentDimensions, t, e);
        }
        translateInPage(t, e) {
            this.#a ||= [
                this.x,
                this.y,
                this.width,
                this.height
            ], this.#R(this.pageDimensions, t, e), this.div.scrollIntoView({
                block: "nearest"
            });
        }
        translationDone() {
            this._onTranslated(this.x, this.y);
        }
        drag(t, e) {
            this.#a ||= [
                this.x,
                this.y,
                this.width,
                this.height
            ];
            const { div: s, parentDimensions: [i, n] } = this;
            if (this.x += t / i, this.y += e / n, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
                const { x: d, y: u } = this.div.getBoundingClientRect();
                this.parent.findNewParent(this, d, u) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
            }
            let { x: r, y: a } = this;
            const [o, l] = this.getBaseTranslation();
            r += o, a += l;
            const { style: h } = s;
            h.left = `${(100 * r).toFixed(2)}%`, h.top = `${(100 * a).toFixed(2)}%`, this._onTranslating(r, a), s.scrollIntoView({
                block: "nearest"
            });
        }
        _onTranslating(t, e) {}
        _onTranslated(t, e) {}
        get _hasBeenMoved() {
            return !!this.#a && (this.#a[0] !== this.x || this.#a[1] !== this.y);
        }
        get _hasBeenResized() {
            return !!this.#a && (this.#a[2] !== this.width || this.#a[3] !== this.height);
        }
        getBaseTranslation() {
            const [t, e] = this.parentDimensions, { _borderLineWidth: s } = k, i = s / t, n = s / e;
            switch(this.rotation){
                case 90:
                    return [
                        -i,
                        n
                    ];
                case 180:
                    return [
                        i,
                        n
                    ];
                case 270:
                    return [
                        i,
                        -n
                    ];
                default:
                    return [
                        -i,
                        -n
                    ];
            }
        }
        get _mustFixPosition() {
            return !0;
        }
        fixAndSetPosition(t = this.rotation) {
            const { div: { style: e }, pageDimensions: [s, i] } = this;
            let { x: n, y: r, width: a, height: o } = this;
            if (a *= s, o *= i, n *= s, r *= i, this._mustFixPosition) switch(t){
                case 0:
                    n = ot(n, 0, s - a), r = ot(r, 0, i - o);
                    break;
                case 90:
                    n = ot(n, 0, s - o), r = ot(r, a, i);
                    break;
                case 180:
                    n = ot(n, a, s), r = ot(r, o, i);
                    break;
                case 270:
                    n = ot(n, o, s), r = ot(r, 0, i - a);
                    break;
            }
            this.x = n /= s, this.y = r /= i;
            const [l, h] = this.getBaseTranslation();
            n += l, r += h, e.left = `${(100 * n).toFixed(2)}%`, e.top = `${(100 * r).toFixed(2)}%`, this.moveInDOM();
        }
        static #_(t, e, s) {
            switch(s){
                case 90:
                    return [
                        e,
                        -t
                    ];
                case 180:
                    return [
                        -t,
                        -e
                    ];
                case 270:
                    return [
                        -e,
                        t
                    ];
                default:
                    return [
                        t,
                        e
                    ];
            }
        }
        screenToPageTranslation(t, e) {
            return k.#_(t, e, this.parentRotation);
        }
        pageTranslationToScreen(t, e) {
            return k.#_(t, e, 360 - this.parentRotation);
        }
        #P(t) {
            switch(t){
                case 90:
                    {
                        const [e, s] = this.pageDimensions;
                        return [
                            0,
                            -e / s,
                            s / e,
                            0
                        ];
                    }
                case 180:
                    return [
                        -1,
                        0,
                        0,
                        -1
                    ];
                case 270:
                    {
                        const [e, s] = this.pageDimensions;
                        return [
                            0,
                            e / s,
                            -s / e,
                            0
                        ];
                    }
                default:
                    return [
                        1,
                        0,
                        0,
                        1
                    ];
            }
        }
        get parentScale() {
            return this._uiManager.viewParameters.realScale;
        }
        get parentRotation() {
            return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
        }
        get parentDimensions() {
            const { parentScale: t, pageDimensions: [e, s] } = this;
            return [
                e * t,
                s * t
            ];
        }
        setDims(t, e) {
            const [s, i] = this.parentDimensions, { style: n } = this.div;
            n.width = `${(100 * t / s).toFixed(2)}%`, this.#l || (n.height = `${(100 * e / i).toFixed(2)}%`);
        }
        fixDims() {
            const { style: t } = this.div, { height: e, width: s } = t, i = s.endsWith("%"), n = !this.#l && e.endsWith("%");
            if (i && n) return;
            const [r, a] = this.parentDimensions;
            i || (t.width = `${(100 * parseFloat(s) / r).toFixed(2)}%`), !this.#l && !n && (t.height = `${(100 * parseFloat(e) / a).toFixed(2)}%`);
        }
        getInitialTranslation() {
            return [
                0,
                0
            ];
        }
        #x() {
            if (this.#o) return;
            this.#o = document.createElement("div"), this.#o.classList.add("resizers");
            const t = this._willKeepAspectRatio ? [
                "topLeft",
                "topRight",
                "bottomRight",
                "bottomLeft"
            ] : [
                "topLeft",
                "topMiddle",
                "topRight",
                "middleRight",
                "bottomRight",
                "bottomMiddle",
                "bottomLeft",
                "middleLeft"
            ], e = this._uiManager._signal;
            for (const s of t){
                const i = document.createElement("div");
                this.#o.append(i), i.classList.add("resizer", s), i.setAttribute("data-resizer-name", s), i.addEventListener("pointerdown", this.#k.bind(this, s), {
                    signal: e
                }), i.addEventListener("contextmenu", gt, {
                    signal: e
                }), i.tabIndex = -1;
            }
            this.div.prepend(this.#o);
        }
        #k(t, e) {
            e.preventDefault();
            const { isMac: s } = st.platform;
            if (e.button !== 0 || e.ctrlKey && s) return;
            this.#s?.toggle(!1);
            const i = this._isDraggable;
            this._isDraggable = !1, this.#d = [
                e.screenX,
                e.screenY
            ];
            const n = new AbortController, r = this._uiManager.combinedSignal(n);
            this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", this.#$.bind(this, t), {
                passive: !0,
                capture: !0,
                signal: r
            }), window.addEventListener("touchmove", Y, {
                passive: !1,
                signal: r
            }), window.addEventListener("contextmenu", gt, {
                signal: r
            }), this.#h = {
                savedX: this.x,
                savedY: this.y,
                savedWidth: this.width,
                savedHeight: this.height
            };
            const a = this.parent.div.style.cursor, o = this.div.style.cursor;
            this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
            const l = ()=>{
                n.abort(), this.parent.togglePointerEvents(!0), this.#s?.toggle(!0), this._isDraggable = i, this.parent.div.style.cursor = a, this.div.style.cursor = o, this.#L();
            };
            window.addEventListener("pointerup", l, {
                signal: r
            }), window.addEventListener("blur", l, {
                signal: r
            });
        }
        #M(t, e, s, i) {
            this.width = s, this.height = i, this.x = t, this.y = e;
            const [n, r] = this.parentDimensions;
            this.setDims(n * s, r * i), this.fixAndSetPosition(), this._onResized();
        }
        _onResized() {}
        #L() {
            if (!this.#h) return;
            const { savedX: t, savedY: e, savedWidth: s, savedHeight: i } = this.#h;
            this.#h = null;
            const n = this.x, r = this.y, a = this.width, o = this.height;
            n === t && r === e && a === s && o === i || this.addCommands({
                cmd: this.#M.bind(this, n, r, a, o),
                undo: this.#M.bind(this, t, e, s, i),
                mustExec: !0
            });
        }
        static _round(t) {
            return Math.round(t * 1e4) / 1e4;
        }
        #$(t, e) {
            const [s, i] = this.parentDimensions, n = this.x, r = this.y, a = this.width, o = this.height, l = k.MIN_SIZE / s, h = k.MIN_SIZE / i, d = this.#P(this.rotation), u = (T, R)=>[
                    d[0] * T + d[2] * R,
                    d[1] * T + d[3] * R
                ], f = this.#P(360 - this.rotation), g = (T, R)=>[
                    f[0] * T + f[2] * R,
                    f[1] * T + f[3] * R
                ];
            let p, m, b = !1, y = !1;
            switch(t){
                case "topLeft":
                    b = !0, p = (T, R)=>[
                            0,
                            0
                        ], m = (T, R)=>[
                            T,
                            R
                        ];
                    break;
                case "topMiddle":
                    p = (T, R)=>[
                            T / 2,
                            0
                        ], m = (T, R)=>[
                            T / 2,
                            R
                        ];
                    break;
                case "topRight":
                    b = !0, p = (T, R)=>[
                            T,
                            0
                        ], m = (T, R)=>[
                            0,
                            R
                        ];
                    break;
                case "middleRight":
                    y = !0, p = (T, R)=>[
                            T,
                            R / 2
                        ], m = (T, R)=>[
                            0,
                            R / 2
                        ];
                    break;
                case "bottomRight":
                    b = !0, p = (T, R)=>[
                            T,
                            R
                        ], m = (T, R)=>[
                            0,
                            0
                        ];
                    break;
                case "bottomMiddle":
                    p = (T, R)=>[
                            T / 2,
                            R
                        ], m = (T, R)=>[
                            T / 2,
                            0
                        ];
                    break;
                case "bottomLeft":
                    b = !0, p = (T, R)=>[
                            0,
                            R
                        ], m = (T, R)=>[
                            T,
                            0
                        ];
                    break;
                case "middleLeft":
                    y = !0, p = (T, R)=>[
                            0,
                            R / 2
                        ], m = (T, R)=>[
                            T,
                            R / 2
                        ];
                    break;
            }
            const A = p(a, o), v = m(a, o);
            let w = u(...v);
            const _ = k._round(n + w[0]), S = k._round(r + w[1]);
            let E = 1, C = 1, M, I;
            if (e.fromKeyboard) ({ deltaX: M, deltaY: I } = e);
            else {
                const { screenX: T, screenY: R } = e, [ut, wt] = this.#d;
                [M, I] = this.screenToPageTranslation(T - ut, R - wt), this.#d[0] = T, this.#d[1] = R;
            }
            if ([M, I] = g(M / s, I / i), b) {
                const T = Math.hypot(a, o);
                E = C = Math.max(Math.min(Math.hypot(v[0] - A[0] - M, v[1] - A[1] - I) / T, 1 / a, 1 / o), l / a, h / o);
            } else y ? E = ot(Math.abs(v[0] - A[0] - M), l, 1) / a : C = ot(Math.abs(v[1] - A[1] - I), h, 1) / o;
            const H = k._round(a * E), G = k._round(o * C);
            w = u(...m(H, G));
            const B = _ - w[0], nt = S - w[1];
            this.#a ||= [
                this.x,
                this.y,
                this.width,
                this.height
            ], this.width = H, this.height = G, this.x = B, this.y = nt, this.setDims(s * H, i * G), this.fixAndSetPosition(), this._onResizing();
        }
        _onResizing() {}
        altTextFinish() {
            this.#s?.finish();
        }
        async addEditToolbar() {
            return this._editToolbar || this.#m ? this._editToolbar : (this._editToolbar = new Zt(this), this.div.append(this._editToolbar.render()), this.#s && await this._editToolbar.addAltText(this.#s), this._editToolbar);
        }
        removeEditToolbar() {
            this._editToolbar && (this._editToolbar.remove(), this._editToolbar = null, this.#s?.destroy());
        }
        addContainer(t) {
            const e = this._editToolbar?.div;
            e ? e.before(t) : this.div.append(t);
        }
        getClientDimensions() {
            return this.div.getBoundingClientRect();
        }
        async addAltTextButton() {
            this.#s || (yt.initialize(k._l10n), this.#s = new yt(this), this.#t && (this.#s.data = this.#t, this.#t = null), await this.addEditToolbar());
        }
        get altTextData() {
            return this.#s?.data;
        }
        set altTextData(t) {
            this.#s && (this.#s.data = t);
        }
        get guessedAltText() {
            return this.#s?.guessedText;
        }
        async setGuessedAltText(t) {
            await this.#s?.setGuessedText(t);
        }
        serializeAltText(t) {
            return this.#s?.serialize(t);
        }
        hasAltText() {
            return !!this.#s && !this.#s.isEmpty();
        }
        hasAltTextData() {
            return this.#s?.hasData() ?? !1;
        }
        render() {
            const t = this.div = document.createElement("div");
            t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = this.#i ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), this.#j();
            const [e, s] = this.parentDimensions;
            this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * s / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / s).toFixed(2)}%`);
            const [i, n] = this.getInitialTranslation();
            return this.translate(i, n), Ke(this, t, [
                "keydown",
                "pointerdown"
            ]), this.isResizable && this._uiManager._supportsPinchToZoom && (this.#S ||= new Ee({
                container: t,
                isPinchingDisabled: ()=>!this.isSelected,
                onPinchStart: this.#E.bind(this),
                onPinching: this.#w.bind(this),
                onPinchEnd: this.#O.bind(this),
                signal: this._uiManager._signal
            })), this._uiManager._editorUndoBar?.hide(), t;
        }
        #E() {
            this.#h = {
                savedX: this.x,
                savedY: this.y,
                savedWidth: this.width,
                savedHeight: this.height
            }, this.#s?.toggle(!1), this.parent.togglePointerEvents(!1);
        }
        #w(t, e, s) {
            let n = .7 * (s / e) + 1 - .7;
            if (n === 1) return;
            const r = this.#P(this.rotation), a = (_, S)=>[
                    r[0] * _ + r[2] * S,
                    r[1] * _ + r[3] * S
                ], [o, l] = this.parentDimensions, h = this.x, d = this.y, u = this.width, f = this.height, g = k.MIN_SIZE / o, p = k.MIN_SIZE / l;
            n = Math.max(Math.min(n, 1 / u, 1 / f), g / u, p / f);
            const m = k._round(u * n), b = k._round(f * n);
            if (m === u && b === f) return;
            this.#a ||= [
                h,
                d,
                u,
                f
            ];
            const y = a(u / 2, f / 2), A = k._round(h + y[0]), v = k._round(d + y[1]), w = a(m / 2, b / 2);
            this.x = A - w[0], this.y = v - w[1], this.width = m, this.height = b, this.setDims(o * m, l * b), this.fixAndSetPosition(), this._onResizing();
        }
        #O() {
            this.#s?.toggle(!0), this.parent.togglePointerEvents(!0), this.#L();
        }
        pointerdown(t) {
            const { isMac: e } = st.platform;
            if (t.button !== 0 || t.ctrlKey && e) {
                t.preventDefault();
                return;
            }
            if (this.#f = !0, this._isDraggable) {
                this.#U(t);
                return;
            }
            this.#B(t);
        }
        get isSelected() {
            return this._uiManager.isSelected(this);
        }
        #B(t) {
            const { isMac: e } = st.platform;
            t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
        }
        #U(t) {
            const { isSelected: e } = this;
            this._uiManager.setUpDragSession();
            let s = !1;
            const i = new AbortController, n = this._uiManager.combinedSignal(i), r = {
                capture: !0,
                passive: !1,
                signal: n
            }, a = (l)=>{
                i.abort(), this.#r = null, this.#f = !1, this._uiManager.endDragSession() || this.#B(l), s && this._onStopDragging();
            };
            e && (this.#A = t.clientX, this.#y = t.clientY, this.#r = t.pointerId, this.#n = t.pointerType, window.addEventListener("pointermove", (l)=>{
                s || (s = !0, this._onStartDragging());
                const { clientX: h, clientY: d, pointerId: u } = l;
                if (u !== this.#r) {
                    Y(l);
                    return;
                }
                const [f, g] = this.screenToPageTranslation(h - this.#A, d - this.#y);
                this.#A = h, this.#y = d, this._uiManager.dragSelectedEditors(f, g);
            }, r), window.addEventListener("touchmove", Y, r), window.addEventListener("pointerdown", (l)=>{
                l.pointerType === this.#n && (this.#S || l.isPrimary) && a(l), Y(l);
            }, r));
            const o = (l)=>{
                if (!this.#r || this.#r === l.pointerId) {
                    a(l);
                    return;
                }
                Y(l);
            };
            window.addEventListener("pointerup", o, {
                signal: n
            }), window.addEventListener("blur", o, {
                signal: n
            });
        }
        _onStartDragging() {}
        _onStopDragging() {}
        moveInDOM() {
            this.#b && clearTimeout(this.#b), this.#b = setTimeout(()=>{
                this.#b = null, this.parent?.moveEditorInDOM(this);
            }, 0);
        }
        _setParentAndPosition(t, e, s) {
            t.changeParent(this), this.x = e, this.y = s, this.fixAndSetPosition(), this._onTranslated();
        }
        getRect(t, e, s = this.rotation) {
            const i = this.parentScale, [n, r] = this.pageDimensions, [a, o] = this.pageTranslation, l = t / i, h = e / i, d = this.x * n, u = this.y * r, f = this.width * n, g = this.height * r;
            switch(s){
                case 0:
                    return [
                        d + l + a,
                        r - u - h - g + o,
                        d + l + f + a,
                        r - u - h + o
                    ];
                case 90:
                    return [
                        d + h + a,
                        r - u + l + o,
                        d + h + g + a,
                        r - u + l + f + o
                    ];
                case 180:
                    return [
                        d - l - f + a,
                        r - u + h + o,
                        d - l + a,
                        r - u + h + g + o
                    ];
                case 270:
                    return [
                        d - h - g + a,
                        r - u - l - f + o,
                        d - h + a,
                        r - u - l + o
                    ];
                default:
                    throw new Error("Invalid rotation");
            }
        }
        getRectInCurrentCoords(t, e) {
            const [s, i, n, r] = t, a = n - s, o = r - i;
            switch(this.rotation){
                case 0:
                    return [
                        s,
                        e - r,
                        a,
                        o
                    ];
                case 90:
                    return [
                        s,
                        e - i,
                        o,
                        a
                    ];
                case 180:
                    return [
                        n,
                        e - i,
                        a,
                        o
                    ];
                case 270:
                    return [
                        n,
                        e - r,
                        o,
                        a
                    ];
                default:
                    throw new Error("Invalid rotation");
            }
        }
        onceAdded(t) {}
        isEmpty() {
            return !1;
        }
        enableEditMode() {
            this.#m = !0;
        }
        disableEditMode() {
            this.#m = !1;
        }
        isInEditMode() {
            return this.#m;
        }
        shouldGetKeyboardEvents() {
            return this.#g;
        }
        needsToBeRebuilt() {
            return this.div && !this.isAttachedToDOM;
        }
        get isOnScreen() {
            const { top: t, left: e, bottom: s, right: i } = this.getClientDimensions(), { innerHeight: n, innerWidth: r } = window;
            return e < r && i > 0 && t < n && s > 0;
        }
        #j() {
            if (this.#u || !this.div) return;
            this.#u = new AbortController;
            const t = this._uiManager.combinedSignal(this.#u);
            this.div.addEventListener("focusin", this.focusin.bind(this), {
                signal: t
            }), this.div.addEventListener("focusout", this.focusout.bind(this), {
                signal: t
            });
        }
        rebuild() {
            this.#j();
        }
        rotate(t) {}
        resize() {}
        serializeDeleted() {
            return {
                id: this.annotationElementId,
                deleted: !0,
                pageIndex: this.pageIndex,
                popupRef: this._initialData?.popupRef || ""
            };
        }
        serialize(t = !1, e = null) {
            $("An editor must be serializable");
        }
        static async deserialize(t, e, s) {
            const i = new this.prototype.constructor({
                parent: e,
                id: e.getNextId(),
                uiManager: s
            });
            i.rotation = t.rotation, i.#t = t.accessibilityData, i._isCopy = t.isCopy || !1;
            const [n, r] = i.pageDimensions, [a, o, l, h] = i.getRectInCurrentCoords(t.rect, r);
            return i.x = a / n, i.y = o / r, i.width = l / n, i.height = h / r, i;
        }
        get hasBeenModified() {
            return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
        }
        remove() {
            if (this.#u?.abort(), this.#u = null, this.isEmpty() || this.commit(), this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.#b && (clearTimeout(this.#b), this.#b = null), this.#z(), this.removeEditToolbar(), this.#v) {
                for (const t of this.#v.values())clearTimeout(t);
                this.#v = null;
            }
            this.parent = null, this.#S?.destroy(), this.#S = null;
        }
        get isResizable() {
            return !1;
        }
        makeResizable() {
            this.isResizable && (this.#x(), this.#o.classList.remove("hidden"));
        }
        get toolbarPosition() {
            return null;
        }
        keydown(t) {
            if (!this.isResizable || t.target !== this.div || t.key !== "Enter") return;
            this._uiManager.setSelected(this), this.#h = {
                savedX: this.x,
                savedY: this.y,
                savedWidth: this.width,
                savedHeight: this.height
            };
            const e = this.#o.children;
            if (!this.#e) {
                this.#e = Array.from(e);
                const r = this.#V.bind(this), a = this.#G.bind(this), o = this._uiManager._signal;
                for (const l of this.#e){
                    const h = l.getAttribute("data-resizer-name");
                    l.setAttribute("role", "spinbutton"), l.addEventListener("keydown", r, {
                        signal: o
                    }), l.addEventListener("blur", a, {
                        signal: o
                    }), l.addEventListener("focus", this.#D.bind(this, h), {
                        signal: o
                    }), l.setAttribute("data-l10n-id", k._l10nResizer[h]);
                }
            }
            const s = this.#e[0];
            let i = 0;
            for (const r of e){
                if (r === s) break;
                i++;
            }
            const n = (360 - this.rotation + this.parentRotation) % 360 / 90 * (this.#e.length / 4);
            if (n !== i) {
                if (n < i) for(let a = 0; a < i - n; a++)this.#o.append(this.#o.firstChild);
                else if (n > i) for(let a = 0; a < n - i; a++)this.#o.firstChild.before(this.#o.lastChild);
                let r = 0;
                for (const a of e){
                    const l = this.#e[r++].getAttribute("data-resizer-name");
                    a.setAttribute("data-l10n-id", k._l10nResizer[l]);
                }
            }
            this.#F(0), this.#g = !0, this.#o.firstChild.focus({
                focusVisible: !0
            }), t.preventDefault(), t.stopImmediatePropagation();
        }
        #V(t) {
            k._resizerKeyboardManager.exec(this, t);
        }
        #G(t) {
            this.#g && t.relatedTarget?.parentNode !== this.#o && this.#z();
        }
        #D(t) {
            this.#c = this.#g ? t : "";
        }
        #F(t) {
            if (this.#e) for (const e of this.#e)e.tabIndex = t;
        }
        _resizeWithKeyboard(t, e) {
            this.#g && this.#$(this.#c, {
                deltaX: t,
                deltaY: e,
                fromKeyboard: !0
            });
        }
        #z() {
            this.#g = !1, this.#F(-1), this.#L();
        }
        _stopResizingWithKeyboard() {
            this.#z(), this.div.focus();
        }
        select() {
            if (this.makeResizable(), this.div?.classList.add("selectedEditor"), !this._editToolbar) {
                this.addEditToolbar().then(()=>{
                    this.div?.classList.contains("selectedEditor") && this._editToolbar?.show();
                });
                return;
            }
            this._editToolbar?.show(), this.#s?.toggleAltTextBadge(!1);
        }
        unselect() {
            this.#o?.classList.add("hidden"), this.div?.classList.remove("selectedEditor"), this.div?.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
                preventScroll: !0
            }), this._editToolbar?.hide(), this.#s?.toggleAltTextBadge(!0);
        }
        updateParams(t, e) {}
        disableEditing() {}
        enableEditing() {}
        enterInEditMode() {}
        getElementForAltText() {
            return this.div;
        }
        get contentDiv() {
            return this.div;
        }
        get isEditing() {
            return this.#p;
        }
        set isEditing(t) {
            this.#p = t, this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
        }
        setAspectRatio(t, e) {
            this.#l = !0;
            const s = t / e, { style: i } = this.div;
            i.aspectRatio = s, i.height = "auto";
        }
        static get MIN_SIZE() {
            return 16;
        }
        static canCreateNewEmptyEditor() {
            return !0;
        }
        get telemetryInitialData() {
            return {
                action: "added"
            };
        }
        get telemetryFinalData() {
            return null;
        }
        _reportTelemetry(t, e = !1) {
            if (e) {
                this.#v ||= new Map;
                const { action: s } = t;
                let i = this.#v.get(s);
                i && clearTimeout(i), i = setTimeout(()=>{
                    this._reportTelemetry(t), this.#v.delete(s), this.#v.size === 0 && (this.#v = null);
                }, k._telemetryTimeout), this.#v.set(s, i);
                return;
            }
            t.type ||= this.editorType, this._uiManager._eventBus.dispatch("reporttelemetry", {
                source: this,
                details: {
                    type: "editing",
                    data: t
                }
            });
        }
        show(t = this._isVisible) {
            this.div.classList.toggle("hidden", !t), this._isVisible = t;
        }
        enable() {
            this.div && (this.div.tabIndex = 0), this.#i = !1;
        }
        disable() {
            this.div && (this.div.tabIndex = -1), this.#i = !0;
        }
        renderAnnotationElement(t) {
            let e = t.container.querySelector(".annotationContent");
            if (!e) e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
            else if (e.nodeName === "CANVAS") {
                const s = e;
                e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), s.before(e);
            }
            return e;
        }
        resetAnnotationElement(t) {
            const { firstChild: e } = t.container;
            e?.nodeName === "DIV" && e.classList.contains("annotationContent") && e.remove();
        }
    }
    class ki extends k {
        constructor(t){
            super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
        }
        serialize() {
            return this.serializeDeleted();
        }
    }
    const fs = 3285377520, ft = 4294901760, bt = 65535;
    class Bs {
        constructor(t){
            this.h1 = t ? t & 4294967295 : fs, this.h2 = t ? t & 4294967295 : fs;
        }
        update(t) {
            let e, s;
            if (typeof t == "string") {
                e = new Uint8Array(t.length * 2), s = 0;
                for(let p = 0, m = t.length; p < m; p++){
                    const b = t.charCodeAt(p);
                    b <= 255 ? e[s++] = b : (e[s++] = b >>> 8, e[s++] = b & 255);
                }
            } else if (ArrayBuffer.isView(t)) e = t.slice(), s = e.byteLength;
            else throw new Error("Invalid data format, must be a string or TypedArray.");
            const i = s >> 2, n = s - i * 4, r = new Uint32Array(e.buffer, 0, i);
            let a = 0, o = 0, l = this.h1, h = this.h2;
            const d = 3432918353, u = 461845907, f = d & bt, g = u & bt;
            for(let p = 0; p < i; p++)p & 1 ? (a = r[p], a = a * d & ft | a * f & bt, a = a << 15 | a >>> 17, a = a * u & ft | a * g & bt, l ^= a, l = l << 13 | l >>> 19, l = l * 5 + 3864292196) : (o = r[p], o = o * d & ft | o * f & bt, o = o << 15 | o >>> 17, o = o * u & ft | o * g & bt, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196);
            switch(a = 0, n){
                case 3:
                    a ^= e[i * 4 + 2] << 16;
                case 2:
                    a ^= e[i * 4 + 1] << 8;
                case 1:
                    a ^= e[i * 4], a = a * d & ft | a * f & bt, a = a << 15 | a >>> 17, a = a * u & ft | a * g & bt, i & 1 ? l ^= a : h ^= a;
            }
            this.h1 = l, this.h2 = h;
        }
        hexdigest() {
            let t = this.h1, e = this.h2;
            return t ^= e >>> 1, t = t * 3981806797 & ft | t * 36045 & bt, e = e * 4283543511 & ft | ((e << 16 | t >>> 16) * 2950163797 & ft) >>> 16, t ^= e >>> 1, t = t * 444984403 & ft | t * 60499 & bt, e = e * 3301882366 & ft | ((e << 16 | t >>> 16) * 3120437893 & ft) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
        }
    }
    const He = Object.freeze({
        map: null,
        hash: "",
        transfer: void 0
    });
    class Ze {
        #t = !1;
        #e = null;
        #s = new Map;
        constructor(){
            this.onSetModified = null, this.onResetModified = null, this.onAnnotationEditor = null;
        }
        getValue(t, e) {
            const s = this.#s.get(t);
            return s === void 0 ? e : Object.assign(e, s);
        }
        getRawValue(t) {
            return this.#s.get(t);
        }
        remove(t) {
            if (this.#s.delete(t), this.#s.size === 0 && this.resetModified(), typeof this.onAnnotationEditor == "function") {
                for (const e of this.#s.values())if (e instanceof k) return;
                this.onAnnotationEditor(null);
            }
        }
        setValue(t, e) {
            const s = this.#s.get(t);
            let i = !1;
            if (s !== void 0) for (const [n, r] of Object.entries(e))s[n] !== r && (i = !0, s[n] = r);
            else i = !0, this.#s.set(t, e);
            i && this.#i(), e instanceof k && typeof this.onAnnotationEditor == "function" && this.onAnnotationEditor(e.constructor._type);
        }
        has(t) {
            return this.#s.has(t);
        }
        get size() {
            return this.#s.size;
        }
        #i() {
            this.#t || (this.#t = !0, typeof this.onSetModified == "function" && this.onSetModified());
        }
        resetModified() {
            this.#t && (this.#t = !1, typeof this.onResetModified == "function" && this.onResetModified());
        }
        get print() {
            return new Hs(this);
        }
        get serializable() {
            if (this.#s.size === 0) return He;
            const t = new Map, e = new Bs, s = [], i = Object.create(null);
            let n = !1;
            for (const [r, a] of this.#s){
                const o = a instanceof k ? a.serialize(!1, i) : a;
                o && (t.set(r, o), e.update(`${r}:${JSON.stringify(o)}`), n ||= !!o.bitmap);
            }
            if (n) for (const r of t.values())r.bitmap && s.push(r.bitmap);
            return t.size > 0 ? {
                map: t,
                hash: e.hexdigest(),
                transfer: s
            } : He;
        }
        get editorStats() {
            let t = null;
            const e = new Map;
            for (const s of this.#s.values()){
                if (!(s instanceof k)) continue;
                const i = s.telemetryFinalData;
                if (!i) continue;
                const { type: n } = i;
                e.has(n) || e.set(n, Object.getPrototypeOf(s).constructor), t ||= Object.create(null);
                const r = t[n] ||= new Map;
                for (const [a, o] of Object.entries(i)){
                    if (a === "type") continue;
                    let l = r.get(a);
                    l || (l = new Map, r.set(a, l));
                    const h = l.get(o) ?? 0;
                    l.set(o, h + 1);
                }
            }
            for (const [s, i] of e)t[s] = i.computeTelemetryFinalData(t[s]);
            return t;
        }
        resetModifiedIds() {
            this.#e = null;
        }
        get modifiedIds() {
            if (this.#e) return this.#e;
            const t = [];
            for (const e of this.#s.values())!(e instanceof k) || !e.annotationElementId || !e.serialize() || t.push(e.annotationElementId);
            return this.#e = {
                ids: new Set(t),
                hash: t.join(",")
            };
        }
        [Symbol.iterator]() {
            return this.#s.entries();
        }
    }
    class Hs extends Ze {
        #t;
        constructor(t){
            super();
            const { map: e, hash: s, transfer: i } = t.serializable, n = structuredClone(e, i ? {
                transfer: i
            } : null);
            this.#t = {
                map: n,
                hash: s,
                transfer: i
            };
        }
        get print() {
            $("Should not call PrintAnnotationStorage.print");
        }
        get serializable() {
            return this.#t;
        }
        get modifiedIds() {
            return N(this, "modifiedIds", {
                ids: new Set,
                hash: ""
            });
        }
    }
    class Mi {
        #t = new Set;
        constructor({ ownerDocument: t = globalThis.document, styleElement: e = null }){
            this._document = t, this.nativeFontFaces = new Set, this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
        }
        addNativeFontFace(t) {
            this.nativeFontFaces.add(t), this._document.fonts.add(t);
        }
        removeNativeFontFace(t) {
            this.nativeFontFaces.delete(t), this._document.fonts.delete(t);
        }
        insertRule(t) {
            this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));
            const e = this.styleElement.sheet;
            e.insertRule(t, e.cssRules.length);
        }
        clear() {
            for (const t of this.nativeFontFaces)this._document.fonts.delete(t);
            this.nativeFontFaces.clear(), this.#t.clear(), this.styleElement && (this.styleElement.remove(), this.styleElement = null);
        }
        async loadSystemFont({ systemFontInfo: t, disableFontFace: e, _inspectFont: s }) {
            if (!(!t || this.#t.has(t.loadedName))) {
                if (K(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
                    const { loadedName: i, src: n, style: r } = t, a = new FontFace(i, n, r);
                    this.addNativeFontFace(a);
                    try {
                        await a.load(), this.#t.add(i), s?.(t);
                    } catch  {
                        F(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(a);
                    }
                    return;
                }
                $("Not implemented: loadSystemFont without the Font Loading API.");
            }
        }
        async bind(t) {
            if (t.attached || t.missingFile && !t.systemFontInfo) return;
            if (t.attached = !0, t.systemFontInfo) {
                await this.loadSystemFont(t);
                return;
            }
            if (this.isFontLoadingAPISupported) {
                const s = t.createNativeFontFace();
                if (s) {
                    this.addNativeFontFace(s);
                    try {
                        await s.loaded;
                    } catch (i) {
                        throw F(`Failed to load font '${s.family}': '${i}'.`), t.disableFontFace = !0, i;
                    }
                }
                return;
            }
            const e = t.createFontFaceRule();
            if (e) {
                if (this.insertRule(e), this.isSyncFontLoadingSupported) return;
                await new Promise((s)=>{
                    const i = this._queueLoadingCallback(s);
                    this._prepareFontLoadEvent(t, i);
                });
            }
        }
        get isFontLoadingAPISupported() {
            const t = !!this._document?.fonts;
            return N(this, "isFontLoadingAPISupported", t);
        }
        get isSyncFontLoadingSupported() {
            return N(this, "isSyncFontLoadingSupported", at || st.platform.isFirefox);
        }
        _queueLoadingCallback(t) {
            function e() {
                for(K(!i.done, "completeRequest() cannot be called twice."), i.done = !0; s.length > 0 && s[0].done;){
                    const n = s.shift();
                    setTimeout(n.callback, 0);
                }
            }
            const { loadingRequests: s } = this, i = {
                done: !1,
                complete: e,
                callback: t
            };
            return s.push(i), i;
        }
        get _loadTestFont() {
            const t = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
            return N(this, "_loadTestFont", t);
        }
        _prepareFontLoadEvent(t, e) {
            function s(v, w) {
                return v.charCodeAt(w) << 24 | v.charCodeAt(w + 1) << 16 | v.charCodeAt(w + 2) << 8 | v.charCodeAt(w + 3) & 255;
            }
            function i(v, w, _, S) {
                const E = v.substring(0, w), C = v.substring(w + _);
                return E + S + C;
            }
            let n, r;
            const a = this._document.createElement("canvas");
            a.width = 1, a.height = 1;
            const o = a.getContext("2d");
            let l = 0;
            function h(v, w) {
                if (++l > 30) {
                    F("Load test font never loaded."), w();
                    return;
                }
                if (o.font = "30px " + v, o.fillText(".", 0, 20), o.getImageData(0, 0, 1, 1).data[3] > 0) {
                    w();
                    return;
                }
                setTimeout(h.bind(null, v, w));
            }
            const d = `lt${Date.now()}${this.loadTestFontId++}`;
            let u = this._loadTestFont;
            u = i(u, 976, d.length, d);
            const g = 16, p = 1482184792;
            let m = s(u, g);
            for(n = 0, r = d.length - 3; n < r; n += 4)m = m - p + s(d, n) | 0;
            n < d.length && (m = m - p + s(d + "XXX", n) | 0), u = i(u, g, 4, bi(m));
            const b = `url(data:font/opentype;base64,${btoa(u)});`, y = `@font-face {font-family:"${d}";src:${b}}`;
            this.insertRule(y);
            const A = this._document.createElement("div");
            A.style.visibility = "hidden", A.style.width = A.style.height = "10px", A.style.position = "absolute", A.style.top = A.style.left = "0px";
            for (const v of [
                t.loadedName,
                d
            ]){
                const w = this._document.createElement("span");
                w.textContent = "Hi", w.style.fontFamily = v, A.append(w);
            }
            this._document.body.append(A), h(d, ()=>{
                A.remove(), e.complete();
            });
        }
    }
    class Li {
        constructor(t, e = null){
            this.compiledGlyphs = Object.create(null);
            for(const s in t)this[s] = t[s];
            this._inspectFont = e;
        }
        createNativeFontFace() {
            if (!this.data || this.disableFontFace) return null;
            let t;
            if (!this.cssFontInfo) t = new FontFace(this.loadedName, this.data, {});
            else {
                const e = {
                    weight: this.cssFontInfo.fontWeight
                };
                this.cssFontInfo.italicAngle && (e.style = `oblique ${this.cssFontInfo.italicAngle}deg`), t = new FontFace(this.cssFontInfo.fontFamily, this.data, e);
            }
            return this._inspectFont?.(this), t;
        }
        createFontFaceRule() {
            if (!this.data || this.disableFontFace) return null;
            const t = `url(data:${this.mimetype};base64,${Ns(this.data)});`;
            let e;
            if (!this.cssFontInfo) e = `@font-face {font-family:"${this.loadedName}";src:${t}}`;
            else {
                let s = `font-weight: ${this.cssFontInfo.fontWeight};`;
                this.cssFontInfo.italicAngle && (s += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), e = `@font-face {font-family:"${this.cssFontInfo.fontFamily}";${s}src:${t}}`;
            }
            return this._inspectFont?.(this, t), e;
        }
        getPathGenerator(t, e) {
            if (this.compiledGlyphs[e] !== void 0) return this.compiledGlyphs[e];
            const s = this.loadedName + "_path_" + e;
            let i;
            try {
                i = t.get(s);
            } catch (r) {
                F(`getPathGenerator - ignoring character: "${r}".`);
            }
            const n = new Path2D(i || "");
            return this.fontExtraProperties || t.delete(s), this.compiledGlyphs[e] = n;
        }
    }
    const ce = {
        DATA: 1,
        ERROR: 2
    }, q = {
        CANCEL: 1,
        CANCEL_COMPLETE: 2,
        CLOSE: 3,
        ENQUEUE: 4,
        ERROR: 5,
        PULL: 6,
        PULL_COMPLETE: 7,
        START_COMPLETE: 8
    };
    function ps() {}
    function lt(c) {
        if (c instanceof Pt || c instanceof Oe || c instanceof cs || c instanceof Ae || c instanceof Re) return c;
        switch(c instanceof Error || typeof c == "object" && c !== null || $('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), c.name){
            case "AbortException":
                return new Pt(c.message);
            case "InvalidPDFException":
                return new Oe(c.message);
            case "PasswordException":
                return new cs(c.message, c.code);
            case "ResponseException":
                return new Ae(c.message, c.status, c.missing);
            case "UnknownErrorException":
                return new Re(c.message, c.details);
        }
        return new Re(c.message, c.toString());
    }
    class Jt {
        #t = new AbortController;
        constructor(t, e, s){
            this.sourceName = t, this.targetName = e, this.comObj = s, this.callbackId = 1, this.streamId = 1, this.streamSinks = Object.create(null), this.streamControllers = Object.create(null), this.callbackCapabilities = Object.create(null), this.actionHandler = Object.create(null), s.addEventListener("message", this.#e.bind(this), {
                signal: this.#t.signal
            });
        }
        #e({ data: t }) {
            if (t.targetName !== this.sourceName) return;
            if (t.stream) {
                this.#i(t);
                return;
            }
            if (t.callback) {
                const s = t.callbackId, i = this.callbackCapabilities[s];
                if (!i) throw new Error(`Cannot resolve callback ${s}`);
                if (delete this.callbackCapabilities[s], t.callback === ce.DATA) i.resolve(t.data);
                else if (t.callback === ce.ERROR) i.reject(lt(t.reason));
                else throw new Error("Unexpected callback case");
                return;
            }
            const e = this.actionHandler[t.action];
            if (!e) throw new Error(`Unknown action from worker: ${t.action}`);
            if (t.callbackId) {
                const s = this.sourceName, i = t.sourceName, n = this.comObj;
                Promise.try(e, t.data).then(function(r) {
                    n.postMessage({
                        sourceName: s,
                        targetName: i,
                        callback: ce.DATA,
                        callbackId: t.callbackId,
                        data: r
                    });
                }, function(r) {
                    n.postMessage({
                        sourceName: s,
                        targetName: i,
                        callback: ce.ERROR,
                        callbackId: t.callbackId,
                        reason: lt(r)
                    });
                });
                return;
            }
            if (t.streamId) {
                this.#s(t);
                return;
            }
            e(t.data);
        }
        on(t, e) {
            const s = this.actionHandler;
            if (s[t]) throw new Error(`There is already an actionName called "${t}"`);
            s[t] = e;
        }
        send(t, e, s) {
            this.comObj.postMessage({
                sourceName: this.sourceName,
                targetName: this.targetName,
                action: t,
                data: e
            }, s);
        }
        sendWithPromise(t, e, s) {
            const i = this.callbackId++, n = Promise.withResolvers();
            this.callbackCapabilities[i] = n;
            try {
                this.comObj.postMessage({
                    sourceName: this.sourceName,
                    targetName: this.targetName,
                    action: t,
                    callbackId: i,
                    data: e
                }, s);
            } catch (r) {
                n.reject(r);
            }
            return n.promise;
        }
        sendWithStream(t, e, s, i) {
            const n = this.streamId++, r = this.sourceName, a = this.targetName, o = this.comObj;
            return new ReadableStream({
                start: (l)=>{
                    const h = Promise.withResolvers();
                    return this.streamControllers[n] = {
                        controller: l,
                        startCall: h,
                        pullCall: null,
                        cancelCall: null,
                        isClosed: !1
                    }, o.postMessage({
                        sourceName: r,
                        targetName: a,
                        action: t,
                        streamId: n,
                        data: e,
                        desiredSize: l.desiredSize
                    }, i), h.promise;
                },
                pull: (l)=>{
                    const h = Promise.withResolvers();
                    return this.streamControllers[n].pullCall = h, o.postMessage({
                        sourceName: r,
                        targetName: a,
                        stream: q.PULL,
                        streamId: n,
                        desiredSize: l.desiredSize
                    }), h.promise;
                },
                cancel: (l)=>{
                    K(l instanceof Error, "cancel must have a valid reason");
                    const h = Promise.withResolvers();
                    return this.streamControllers[n].cancelCall = h, this.streamControllers[n].isClosed = !0, o.postMessage({
                        sourceName: r,
                        targetName: a,
                        stream: q.CANCEL,
                        streamId: n,
                        reason: lt(l)
                    }), h.promise;
                }
            }, s);
        }
        #s(t) {
            const e = t.streamId, s = this.sourceName, i = t.sourceName, n = this.comObj, r = this, a = this.actionHandler[t.action], o = {
                enqueue (l, h = 1, d) {
                    if (this.isCancelled) return;
                    const u = this.desiredSize;
                    this.desiredSize -= h, u > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), n.postMessage({
                        sourceName: s,
                        targetName: i,
                        stream: q.ENQUEUE,
                        streamId: e,
                        chunk: l
                    }, d);
                },
                close () {
                    this.isCancelled || (this.isCancelled = !0, n.postMessage({
                        sourceName: s,
                        targetName: i,
                        stream: q.CLOSE,
                        streamId: e
                    }), delete r.streamSinks[e]);
                },
                error (l) {
                    K(l instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, n.postMessage({
                        sourceName: s,
                        targetName: i,
                        stream: q.ERROR,
                        streamId: e,
                        reason: lt(l)
                    }));
                },
                sinkCapability: Promise.withResolvers(),
                onPull: null,
                onCancel: null,
                isCancelled: !1,
                desiredSize: t.desiredSize,
                ready: null
            };
            o.sinkCapability.resolve(), o.ready = o.sinkCapability.promise, this.streamSinks[e] = o, Promise.try(a, t.data, o).then(function() {
                n.postMessage({
                    sourceName: s,
                    targetName: i,
                    stream: q.START_COMPLETE,
                    streamId: e,
                    success: !0
                });
            }, function(l) {
                n.postMessage({
                    sourceName: s,
                    targetName: i,
                    stream: q.START_COMPLETE,
                    streamId: e,
                    reason: lt(l)
                });
            });
        }
        #i(t) {
            const e = t.streamId, s = this.sourceName, i = t.sourceName, n = this.comObj, r = this.streamControllers[e], a = this.streamSinks[e];
            switch(t.stream){
                case q.START_COMPLETE:
                    t.success ? r.startCall.resolve() : r.startCall.reject(lt(t.reason));
                    break;
                case q.PULL_COMPLETE:
                    t.success ? r.pullCall.resolve() : r.pullCall.reject(lt(t.reason));
                    break;
                case q.PULL:
                    if (!a) {
                        n.postMessage({
                            sourceName: s,
                            targetName: i,
                            stream: q.PULL_COMPLETE,
                            streamId: e,
                            success: !0
                        });
                        break;
                    }
                    a.desiredSize <= 0 && t.desiredSize > 0 && a.sinkCapability.resolve(), a.desiredSize = t.desiredSize, Promise.try(a.onPull || ps).then(function() {
                        n.postMessage({
                            sourceName: s,
                            targetName: i,
                            stream: q.PULL_COMPLETE,
                            streamId: e,
                            success: !0
                        });
                    }, function(l) {
                        n.postMessage({
                            sourceName: s,
                            targetName: i,
                            stream: q.PULL_COMPLETE,
                            streamId: e,
                            reason: lt(l)
                        });
                    });
                    break;
                case q.ENQUEUE:
                    if (K(r, "enqueue should have stream controller"), r.isClosed) break;
                    r.controller.enqueue(t.chunk);
                    break;
                case q.CLOSE:
                    if (K(r, "close should have stream controller"), r.isClosed) break;
                    r.isClosed = !0, r.controller.close(), this.#r(r, e);
                    break;
                case q.ERROR:
                    K(r, "error should have stream controller"), r.controller.error(lt(t.reason)), this.#r(r, e);
                    break;
                case q.CANCEL_COMPLETE:
                    t.success ? r.cancelCall.resolve() : r.cancelCall.reject(lt(t.reason)), this.#r(r, e);
                    break;
                case q.CANCEL:
                    if (!a) break;
                    const o = lt(t.reason);
                    Promise.try(a.onCancel || ps, o).then(function() {
                        n.postMessage({
                            sourceName: s,
                            targetName: i,
                            stream: q.CANCEL_COMPLETE,
                            streamId: e,
                            success: !0
                        });
                    }, function(l) {
                        n.postMessage({
                            sourceName: s,
                            targetName: i,
                            stream: q.CANCEL_COMPLETE,
                            streamId: e,
                            reason: lt(l)
                        });
                    }), a.sinkCapability.reject(o), a.isCancelled = !0, delete this.streamSinks[e];
                    break;
                default:
                    throw new Error("Unexpected stream case");
            }
        }
        async #r(t, e) {
            await Promise.allSettled([
                t.startCall?.promise,
                t.pullCall?.promise,
                t.cancelCall?.promise
            ]), delete this.streamControllers[e];
        }
        destroy() {
            this.#t?.abort(), this.#t = null;
        }
    }
    class $s {
        #t = !1;
        constructor({ enableHWA: t = !1 }){
            this.#t = t;
        }
        create(t, e) {
            if (t <= 0 || e <= 0) throw new Error("Invalid canvas size");
            const s = this._createCanvas(t, e);
            return {
                canvas: s,
                context: s.getContext("2d", {
                    willReadFrequently: !this.#t
                })
            };
        }
        reset(t, e, s) {
            if (!t.canvas) throw new Error("Canvas is not specified");
            if (e <= 0 || s <= 0) throw new Error("Invalid canvas size");
            t.canvas.width = e, t.canvas.height = s;
        }
        destroy(t) {
            if (!t.canvas) throw new Error("Canvas is not specified");
            t.canvas.width = 0, t.canvas.height = 0, t.canvas = null, t.context = null;
        }
        _createCanvas(t, e) {
            $("Abstract method `_createCanvas` called.");
        }
    }
    class Di extends $s {
        constructor({ ownerDocument: t = globalThis.document, enableHWA: e = !1 }){
            super({
                enableHWA: e
            }), this._document = t;
        }
        _createCanvas(t, e) {
            const s = this._document.createElement("canvas");
            return s.width = t, s.height = e, s;
        }
    }
    class Gs {
        constructor({ baseUrl: t = null, isCompressed: e = !0 }){
            this.baseUrl = t, this.isCompressed = e;
        }
        async fetch({ name: t }) {
            if (!this.baseUrl) throw new Error("Ensure that the `cMapUrl` and `cMapPacked` API parameters are provided.");
            if (!t) throw new Error("CMap name must be specified.");
            const e = this.baseUrl + t + (this.isCompressed ? ".bcmap" : "");
            return this._fetch(e).then((s)=>({
                    cMapData: s,
                    isCompressed: this.isCompressed
                })).catch((s)=>{
                throw new Error(`Unable to load ${this.isCompressed ? "binary " : ""}CMap at: ${e}`);
            });
        }
        async _fetch(t) {
            $("Abstract method `_fetch` called.");
        }
    }
    class gs extends Gs {
        async _fetch(t) {
            const e = await ie(t, this.isCompressed ? "arraybuffer" : "text");
            return e instanceof ArrayBuffer ? new Uint8Array(e) : se(e);
        }
    }
    class zs {
        addFilter(t) {
            return "none";
        }
        addHCMFilter(t, e) {
            return "none";
        }
        addAlphaFilter(t) {
            return "none";
        }
        addLuminosityFilter(t) {
            return "none";
        }
        addHighlightHCMFilter(t, e, s, i, n) {
            return "none";
        }
        destroy(t = !1) {}
    }
    class Fi extends zs {
        #t;
        #e;
        #s;
        #i;
        #r;
        #n;
        #l = 0;
        constructor({ docId: t, ownerDocument: e = globalThis.document }){
            super(), this.#i = t, this.#r = e;
        }
        get #o() {
            return this.#e ||= new Map;
        }
        get #d() {
            return this.#n ||= new Map;
        }
        get #h() {
            if (!this.#s) {
                const t = this.#r.createElement("div"), { style: e } = t;
                e.visibility = "hidden", e.contain = "strict", e.width = e.height = 0, e.position = "absolute", e.top = e.left = 0, e.zIndex = -1;
                const s = this.#r.createElementNS(_t, "svg");
                s.setAttribute("width", 0), s.setAttribute("height", 0), this.#s = this.#r.createElementNS(_t, "defs"), t.append(s), s.append(this.#s), this.#r.body.append(t);
            }
            return this.#s;
        }
        #u(t) {
            if (t.length === 1) {
                const o = t[0], l = new Array(256);
                for(let d = 0; d < 256; d++)l[d] = o[d] / 255;
                const h = l.join(",");
                return [
                    h,
                    h,
                    h
                ];
            }
            const [e, s, i] = t, n = new Array(256), r = new Array(256), a = new Array(256);
            for(let o = 0; o < 256; o++)n[o] = e[o] / 255, r[o] = s[o] / 255, a[o] = i[o] / 255;
            return [
                n.join(","),
                r.join(","),
                a.join(",")
            ];
        }
        #c(t) {
            if (this.#t === void 0) {
                this.#t = "";
                const e = this.#r.URL;
                e !== this.#r.baseURI && (Se(e) ? F('#createUrl: ignore "data:"-URL for performance reasons.') : this.#t = Ls(e, ""));
            }
            return `url(${this.#t}#${t})`;
        }
        addFilter(t) {
            if (!t) return "none";
            let e = this.#o.get(t);
            if (e) return e;
            const [s, i, n] = this.#u(t), r = t.length === 1 ? s : `${s}${i}${n}`;
            if (e = this.#o.get(r), e) return this.#o.set(t, e), e;
            const a = `g_${this.#i}_transfer_map_${this.#l++}`, o = this.#c(a);
            this.#o.set(t, o), this.#o.set(r, o);
            const l = this.#p(a);
            return this.#g(s, i, n, l), o;
        }
        addHCMFilter(t, e) {
            const s = `${t}-${e}`, i = "base";
            let n = this.#d.get(i);
            if (n?.key === s || (n ? (n.filter?.remove(), n.key = s, n.url = "none", n.filter = null) : (n = {
                key: s,
                url: "none",
                filter: null
            }, this.#d.set(i, n)), !t || !e)) return n.url;
            const r = this.#A(t);
            t = P.makeHexColor(...r);
            const a = this.#A(e);
            if (e = P.makeHexColor(...a), this.#h.style.color = "", t === "#000000" && e === "#ffffff" || t === e) return n.url;
            const o = new Array(256);
            for(let f = 0; f <= 255; f++){
                const g = f / 255;
                o[f] = g <= .03928 ? g / 12.92 : ((g + .055) / 1.055) ** 2.4;
            }
            const l = o.join(","), h = `g_${this.#i}_hcm_filter`, d = n.filter = this.#p(h);
            this.#g(l, l, l, d), this.#a(d);
            const u = (f, g)=>{
                const p = r[f] / 255, m = a[f] / 255, b = new Array(g + 1);
                for(let y = 0; y <= g; y++)b[y] = p + y / g * (m - p);
                return b.join(",");
            };
            return this.#g(u(0, 5), u(1, 5), u(2, 5), d), n.url = this.#c(h), n.url;
        }
        addAlphaFilter(t) {
            let e = this.#o.get(t);
            if (e) return e;
            const [s] = this.#u([
                t
            ]), i = `alpha_${s}`;
            if (e = this.#o.get(i), e) return this.#o.set(t, e), e;
            const n = `g_${this.#i}_alpha_map_${this.#l++}`, r = this.#c(n);
            this.#o.set(t, r), this.#o.set(i, r);
            const a = this.#p(n);
            return this.#b(s, a), r;
        }
        addLuminosityFilter(t) {
            let e = this.#o.get(t || "luminosity");
            if (e) return e;
            let s, i;
            if (t ? ([s] = this.#u([
                t
            ]), i = `luminosity_${s}`) : i = "luminosity", e = this.#o.get(i), e) return this.#o.set(t, e), e;
            const n = `g_${this.#i}_luminosity_map_${this.#l++}`, r = this.#c(n);
            this.#o.set(t, r), this.#o.set(i, r);
            const a = this.#p(n);
            return this.#f(a), t && this.#b(s, a), r;
        }
        addHighlightHCMFilter(t, e, s, i, n) {
            const r = `${e}-${s}-${i}-${n}`;
            let a = this.#d.get(t);
            if (a?.key === r || (a ? (a.filter?.remove(), a.key = r, a.url = "none", a.filter = null) : (a = {
                key: r,
                url: "none",
                filter: null
            }, this.#d.set(t, a)), !e || !s)) return a.url;
            const [o, l] = [
                e,
                s
            ].map(this.#A.bind(this));
            let h = Math.round(.2126 * o[0] + .7152 * o[1] + .0722 * o[2]), d = Math.round(.2126 * l[0] + .7152 * l[1] + .0722 * l[2]), [u, f] = [
                i,
                n
            ].map(this.#A.bind(this));
            d < h && ([h, d, u, f] = [
                d,
                h,
                f,
                u
            ]), this.#h.style.color = "";
            const g = (b, y, A)=>{
                const v = new Array(256), w = (d - h) / A, _ = b / 255, S = (y - b) / (255 * A);
                let E = 0;
                for(let C = 0; C <= A; C++){
                    const M = Math.round(h + C * w), I = _ + C * S;
                    for(let H = E; H <= M; H++)v[H] = I;
                    E = M + 1;
                }
                for(let C = E; C < 256; C++)v[C] = v[E - 1];
                return v.join(",");
            }, p = `g_${this.#i}_hcm_${t}_filter`, m = a.filter = this.#p(p);
            return this.#a(m), this.#g(g(u[0], f[0], 5), g(u[1], f[1], 5), g(u[2], f[2], 5), m), a.url = this.#c(p), a.url;
        }
        destroy(t = !1) {
            t && this.#n?.size || (this.#s?.parentNode.parentNode.remove(), this.#s = null, this.#e?.clear(), this.#e = null, this.#n?.clear(), this.#n = null, this.#l = 0);
        }
        #f(t) {
            const e = this.#r.createElementNS(_t, "feColorMatrix");
            e.setAttribute("type", "matrix"), e.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), t.append(e);
        }
        #a(t) {
            const e = this.#r.createElementNS(_t, "feColorMatrix");
            e.setAttribute("type", "matrix"), e.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), t.append(e);
        }
        #p(t) {
            const e = this.#r.createElementNS(_t, "filter");
            return e.setAttribute("color-interpolation-filters", "sRGB"), e.setAttribute("id", t), this.#h.append(e), e;
        }
        #m(t, e, s) {
            const i = this.#r.createElementNS(_t, e);
            i.setAttribute("type", "discrete"), i.setAttribute("tableValues", s), t.append(i);
        }
        #g(t, e, s, i) {
            const n = this.#r.createElementNS(_t, "feComponentTransfer");
            i.append(n), this.#m(n, "feFuncR", t), this.#m(n, "feFuncG", e), this.#m(n, "feFuncB", s);
        }
        #b(t, e) {
            const s = this.#r.createElementNS(_t, "feComponentTransfer");
            e.append(s), this.#m(s, "feFuncA", t);
        }
        #A(t) {
            return this.#h.style.color = t, Ye(getComputedStyle(this.#h).getPropertyValue("color"));
        }
    }
    class Us {
        constructor({ baseUrl: t = null }){
            this.baseUrl = t;
        }
        async fetch({ filename: t }) {
            if (!this.baseUrl) throw new Error("Ensure that the `standardFontDataUrl` API parameter is provided.");
            if (!t) throw new Error("Font filename must be specified.");
            const e = `${this.baseUrl}${t}`;
            return this._fetch(e).catch((s)=>{
                throw new Error(`Unable to load font data at: ${e}`);
            });
        }
        async _fetch(t) {
            $("Abstract method `_fetch` called.");
        }
    }
    class ms extends Us {
        async _fetch(t) {
            const e = await ie(t, "arraybuffer");
            return new Uint8Array(e);
        }
    }
    class js {
        constructor({ baseUrl: t = null }){
            this.baseUrl = t;
        }
        async fetch({ filename: t }) {
            if (!this.baseUrl) throw new Error("Ensure that the `wasmUrl` API parameter is provided.");
            if (!t) throw new Error("Wasm filename must be specified.");
            const e = `${this.baseUrl}${t}`;
            return this._fetch(e).catch((s)=>{
                throw new Error(`Unable to load wasm data at: ${e}`);
            });
        }
        async _fetch(t) {
            $("Abstract method `_fetch` called.");
        }
    }
    class bs extends js {
        async _fetch(t) {
            const e = await ie(t, "arraybuffer");
            return new Uint8Array(e);
        }
    }
    at && F("Please use the `legacy` build in Node.js environments.");
    async function ts(c) {
        const e = await process.getBuiltinModule("fs").promises.readFile(c);
        return new Uint8Array(e);
    }
    class Ni extends zs {
    }
    class Oi extends $s {
        _createCanvas(t, e) {
            return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t, e);
        }
    }
    class Bi extends Gs {
        async _fetch(t) {
            return ts(t);
        }
    }
    class Hi extends Us {
        async _fetch(t) {
            return ts(t);
        }
    }
    class $i extends js {
        async _fetch(t) {
            return ts(t);
        }
    }
    const et = {
        FILL: "Fill",
        STROKE: "Stroke",
        SHADING: "Shading"
    };
    function $e(c, t) {
        if (!t) return;
        const e = t[2] - t[0], s = t[3] - t[1], i = new Path2D;
        i.rect(t[0], t[1], e, s), c.clip(i);
    }
    class es {
        isModifyingCurrentTransform() {
            return !1;
        }
        getPattern() {
            $("Abstract method `getPattern` called.");
        }
    }
    class Gi extends es {
        constructor(t){
            super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7], this.matrix = null;
        }
        _createGradient(t) {
            let e;
            this._type === "axial" ? e = t.createLinearGradient(this._p0[0], this._p0[1], this._p1[0], this._p1[1]) : this._type === "radial" && (e = t.createRadialGradient(this._p0[0], this._p0[1], this._r0, this._p1[0], this._p1[1], this._r1));
            for (const s of this._colorStops)e.addColorStop(s[0], s[1]);
            return e;
        }
        getPattern(t, e, s, i) {
            let n;
            if (i === et.STROKE || i === et.FILL) {
                const r = e.current.getClippedPathBoundingBox(i, z(t)) || [
                    0,
                    0,
                    0,
                    0
                ], a = Math.ceil(r[2] - r[0]) || 1, o = Math.ceil(r[3] - r[1]) || 1, l = e.cachedCanvases.getCanvas("pattern", a, o), h = l.context;
                h.clearRect(0, 0, h.canvas.width, h.canvas.height), h.beginPath(), h.rect(0, 0, h.canvas.width, h.canvas.height), h.translate(-r[0], -r[1]), s = P.transform(s, [
                    1,
                    0,
                    0,
                    1,
                    r[0],
                    r[1]
                ]), h.transform(...e.baseTransform), this.matrix && h.transform(...this.matrix), $e(h, this._bbox), h.fillStyle = this._createGradient(h), h.fill(), n = t.createPattern(l.canvas, "no-repeat");
                const d = new DOMMatrix(s);
                n.setTransform(d);
            } else $e(t, this._bbox), n = this._createGradient(t);
            return n;
        }
    }
    function Me(c, t, e, s, i, n, r, a) {
        const o = t.coords, l = t.colors, h = c.data, d = c.width * 4;
        let u;
        o[e + 1] > o[s + 1] && (u = e, e = s, s = u, u = n, n = r, r = u), o[s + 1] > o[i + 1] && (u = s, s = i, i = u, u = r, r = a, a = u), o[e + 1] > o[s + 1] && (u = e, e = s, s = u, u = n, n = r, r = u);
        const f = (o[e] + t.offsetX) * t.scaleX, g = (o[e + 1] + t.offsetY) * t.scaleY, p = (o[s] + t.offsetX) * t.scaleX, m = (o[s + 1] + t.offsetY) * t.scaleY, b = (o[i] + t.offsetX) * t.scaleX, y = (o[i + 1] + t.offsetY) * t.scaleY;
        if (g >= y) return;
        const A = l[n], v = l[n + 1], w = l[n + 2], _ = l[r], S = l[r + 1], E = l[r + 2], C = l[a], M = l[a + 1], I = l[a + 2], H = Math.round(g), G = Math.round(y);
        let B, nt, T, R, ut, wt, It, vt;
        for(let J = H; J <= G; J++){
            if (J < m) {
                const U = J < g ? 0 : (g - J) / (g - m);
                B = f - (f - p) * U, nt = A - (A - _) * U, T = v - (v - S) * U, R = w - (w - E) * U;
            } else {
                let U;
                J > y ? U = 1 : m === y ? U = 0 : U = (m - J) / (m - y), B = p - (p - b) * U, nt = _ - (_ - C) * U, T = S - (S - M) * U, R = E - (E - I) * U;
            }
            let j;
            J < g ? j = 0 : J > y ? j = 1 : j = (g - J) / (g - y), ut = f - (f - b) * j, wt = A - (A - C) * j, It = v - (v - M) * j, vt = w - (w - I) * j;
            const Nt = Math.round(Math.min(B, ut)), Ct = Math.round(Math.max(B, ut));
            let xt = d * J + Nt * 4;
            for(let U = Nt; U <= Ct; U++)j = (B - U) / (B - ut), j < 0 ? j = 0 : j > 1 && (j = 1), h[xt++] = nt - (nt - wt) * j | 0, h[xt++] = T - (T - It) * j | 0, h[xt++] = R - (R - vt) * j | 0, h[xt++] = 255;
        }
    }
    function zi(c, t, e) {
        const s = t.coords, i = t.colors;
        let n, r;
        switch(t.type){
            case "lattice":
                const a = t.verticesPerRow, o = Math.floor(s.length / a) - 1, l = a - 1;
                for(n = 0; n < o; n++){
                    let h = n * a;
                    for(let d = 0; d < l; d++, h++)Me(c, e, s[h], s[h + 1], s[h + a], i[h], i[h + 1], i[h + a]), Me(c, e, s[h + a + 1], s[h + 1], s[h + a], i[h + a + 1], i[h + 1], i[h + a]);
                }
                break;
            case "triangles":
                for(n = 0, r = s.length; n < r; n += 3)Me(c, e, s[n], s[n + 1], s[n + 2], i[n], i[n + 1], i[n + 2]);
                break;
            default:
                throw new Error("illegal figure");
        }
    }
    class Ui extends es {
        constructor(t){
            super(), this._coords = t[2], this._colors = t[3], this._figures = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], this.matrix = null;
        }
        _createMeshCanvas(t, e, s) {
            const a = Math.floor(this._bounds[0]), o = Math.floor(this._bounds[1]), l = Math.ceil(this._bounds[2]) - a, h = Math.ceil(this._bounds[3]) - o, d = Math.min(Math.ceil(Math.abs(l * t[0] * 1.1)), 3e3), u = Math.min(Math.ceil(Math.abs(h * t[1] * 1.1)), 3e3), f = l / d, g = h / u, p = {
                coords: this._coords,
                colors: this._colors,
                offsetX: -a,
                offsetY: -o,
                scaleX: 1 / f,
                scaleY: 1 / g
            }, m = d + 2 * 2, b = u + 2 * 2, y = s.getCanvas("mesh", m, b), A = y.context, v = A.createImageData(d, u);
            if (e) {
                const _ = v.data;
                for(let S = 0, E = _.length; S < E; S += 4)_[S] = e[0], _[S + 1] = e[1], _[S + 2] = e[2], _[S + 3] = 255;
            }
            for (const _ of this._figures)zi(v, _, p);
            return A.putImageData(v, 2, 2), {
                canvas: y.canvas,
                offsetX: a - 2 * f,
                offsetY: o - 2 * g,
                scaleX: f,
                scaleY: g
            };
        }
        isModifyingCurrentTransform() {
            return !0;
        }
        getPattern(t, e, s, i) {
            $e(t, this._bbox);
            const n = new Float32Array(2);
            if (i === et.SHADING) P.singularValueDecompose2dScale(z(t), n);
            else if (this.matrix) {
                P.singularValueDecompose2dScale(this.matrix, n);
                const [a, o] = n;
                P.singularValueDecompose2dScale(e.baseTransform, n), n[0] *= a, n[1] *= o;
            } else P.singularValueDecompose2dScale(e.baseTransform, n);
            const r = this._createMeshCanvas(n, i === et.SHADING ? null : this._background, e.cachedCanvases);
            return i !== et.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(r.offsetX, r.offsetY), t.scale(r.scaleX, r.scaleY), t.createPattern(r.canvas, "no-repeat");
        }
    }
    class ji extends es {
        getPattern() {
            return "hotpink";
        }
    }
    function Vi(c) {
        switch(c[0]){
            case "RadialAxial":
                return new Gi(c);
            case "Mesh":
                return new Ui(c);
            case "Dummy":
                return new ji;
        }
        throw new Error(`Unknown IR type: ${c[0]}`);
    }
    const As = {
        COLORED: 1,
        UNCOLORED: 2
    };
    class ss {
        static MAX_PATTERN_SIZE = 3e3;
        constructor(t, e, s, i){
            this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.ctx = e, this.canvasGraphicsFactory = s, this.baseTransform = i;
        }
        createPatternCanvas(t) {
            const { bbox: e, operatorList: s, paintType: i, tilingType: n, color: r, canvasGraphicsFactory: a } = this;
            let { xstep: o, ystep: l } = this;
            o = Math.abs(o), l = Math.abs(l), _e("TilingType: " + n);
            const h = e[0], d = e[1], u = e[2], f = e[3], g = u - h, p = f - d, m = new Float32Array(2);
            P.singularValueDecompose2dScale(this.matrix, m);
            const [b, y] = m;
            P.singularValueDecompose2dScale(this.baseTransform, m);
            const A = b * m[0], v = y * m[1];
            let w = g, _ = p, S = !1, E = !1;
            const C = Math.ceil(o * A), M = Math.ceil(l * v), I = Math.ceil(g * A), H = Math.ceil(p * v);
            C >= I ? w = o : S = !0, M >= H ? _ = l : E = !0;
            const G = this.getSizeAndScale(w, this.ctx.canvas.width, A), B = this.getSizeAndScale(_, this.ctx.canvas.height, v), nt = t.cachedCanvases.getCanvas("pattern", G.size, B.size), T = nt.context, R = a.createCanvasGraphics(T);
            if (R.groupLevel = t.groupLevel, this.setFillAndStrokeStyleToContext(R, i, r), T.translate(-G.scale * h, -B.scale * d), R.transform(G.scale, 0, 0, B.scale, 0, 0), T.save(), this.clipBbox(R, h, d, u, f), R.baseTransform = z(R.ctx), R.executeOperatorList(s), R.endDrawing(), T.restore(), S || E) {
                const ut = nt.canvas;
                S && (w = o), E && (_ = l);
                const wt = this.getSizeAndScale(w, this.ctx.canvas.width, A), It = this.getSizeAndScale(_, this.ctx.canvas.height, v), vt = wt.size, J = It.size, j = t.cachedCanvases.getCanvas("pattern-workaround", vt, J), Nt = j.context, Ct = S ? Math.floor(g / o) : 0, xt = E ? Math.floor(p / l) : 0;
                for(let U = 0; U <= Ct; U++)for(let Wt = 0; Wt <= xt; Wt++)Nt.drawImage(ut, vt * U, J * Wt, vt, J, 0, 0, vt, J);
                return {
                    canvas: j.canvas,
                    scaleX: wt.scale,
                    scaleY: It.scale,
                    offsetX: h,
                    offsetY: d
                };
            }
            return {
                canvas: nt.canvas,
                scaleX: G.scale,
                scaleY: B.scale,
                offsetX: h,
                offsetY: d
            };
        }
        getSizeAndScale(t, e, s) {
            const i = Math.max(ss.MAX_PATTERN_SIZE, e);
            let n = Math.ceil(t * s);
            return n >= i ? n = i : s = n / t, {
                scale: s,
                size: n
            };
        }
        clipBbox(t, e, s, i, n) {
            const r = i - e, a = n - s;
            t.ctx.rect(e, s, r, a), P.axialAlignedBoundingBox([
                e,
                s,
                i,
                n
            ], z(t.ctx), t.current.minMax), t.clip(), t.endPath();
        }
        setFillAndStrokeStyleToContext(t, e, s) {
            const i = t.ctx, n = t.current;
            switch(e){
                case As.COLORED:
                    const r = this.ctx;
                    i.fillStyle = r.fillStyle, i.strokeStyle = r.strokeStyle, n.fillColor = r.fillStyle, n.strokeColor = r.strokeStyle;
                    break;
                case As.UNCOLORED:
                    const a = P.makeHexColor(s[0], s[1], s[2]);
                    i.fillStyle = a, i.strokeStyle = a, n.fillColor = a, n.strokeColor = a;
                    break;
                default:
                    throw new mi(`Unsupported paint type: ${e}`);
            }
        }
        isModifyingCurrentTransform() {
            return !1;
        }
        getPattern(t, e, s, i) {
            let n = s;
            i !== et.SHADING && (n = P.transform(n, e.baseTransform), this.matrix && (n = P.transform(n, this.matrix)));
            const r = this.createPatternCanvas(e);
            let a = new DOMMatrix(n);
            a = a.translate(r.offsetX, r.offsetY), a = a.scale(1 / r.scaleX, 1 / r.scaleY);
            const o = t.createPattern(r.canvas, "repeat");
            return o.setTransform(a), o;
        }
    }
    function Wi({ src: c, srcPos: t = 0, dest: e, width: s, height: i, nonBlackColor: n = 4294967295, inverseDecode: r = !1 }) {
        const a = st.isLittleEndian ? 4278190080 : 255, [o, l] = r ? [
            n,
            a
        ] : [
            a,
            n
        ], h = s >> 3, d = s & 7, u = c.length;
        e = new Uint32Array(e.buffer);
        let f = 0;
        for(let g = 0; g < i; g++){
            for(const m = t + h; t < m; t++){
                const b = t < u ? c[t] : 255;
                e[f++] = b & 128 ? l : o, e[f++] = b & 64 ? l : o, e[f++] = b & 32 ? l : o, e[f++] = b & 16 ? l : o, e[f++] = b & 8 ? l : o, e[f++] = b & 4 ? l : o, e[f++] = b & 2 ? l : o, e[f++] = b & 1 ? l : o;
            }
            if (d === 0) continue;
            const p = t < u ? c[t++] : 255;
            for(let m = 0; m < d; m++)e[f++] = p & 1 << 7 - m ? l : o;
        }
        return {
            srcPos: t,
            destPos: f
        };
    }
    const ys = 16, ws = 100, qi = 15, vs = 10, ht = 16, Le = new DOMMatrix, dt = new Float32Array(2), zt = new Float32Array([
        1 / 0,
        1 / 0,
        -1 / 0,
        -1 / 0
    ]);
    function Xi(c, t) {
        if (c._removeMirroring) throw new Error("Context is already forwarding operations.");
        c.__originalSave = c.save, c.__originalRestore = c.restore, c.__originalRotate = c.rotate, c.__originalScale = c.scale, c.__originalTranslate = c.translate, c.__originalTransform = c.transform, c.__originalSetTransform = c.setTransform, c.__originalResetTransform = c.resetTransform, c.__originalClip = c.clip, c.__originalMoveTo = c.moveTo, c.__originalLineTo = c.lineTo, c.__originalBezierCurveTo = c.bezierCurveTo, c.__originalRect = c.rect, c.__originalClosePath = c.closePath, c.__originalBeginPath = c.beginPath, c._removeMirroring = ()=>{
            c.save = c.__originalSave, c.restore = c.__originalRestore, c.rotate = c.__originalRotate, c.scale = c.__originalScale, c.translate = c.__originalTranslate, c.transform = c.__originalTransform, c.setTransform = c.__originalSetTransform, c.resetTransform = c.__originalResetTransform, c.clip = c.__originalClip, c.moveTo = c.__originalMoveTo, c.lineTo = c.__originalLineTo, c.bezierCurveTo = c.__originalBezierCurveTo, c.rect = c.__originalRect, c.closePath = c.__originalClosePath, c.beginPath = c.__originalBeginPath, delete c._removeMirroring;
        }, c.save = function() {
            t.save(), this.__originalSave();
        }, c.restore = function() {
            t.restore(), this.__originalRestore();
        }, c.translate = function(e, s) {
            t.translate(e, s), this.__originalTranslate(e, s);
        }, c.scale = function(e, s) {
            t.scale(e, s), this.__originalScale(e, s);
        }, c.transform = function(e, s, i, n, r, a) {
            t.transform(e, s, i, n, r, a), this.__originalTransform(e, s, i, n, r, a);
        }, c.setTransform = function(e, s, i, n, r, a) {
            t.setTransform(e, s, i, n, r, a), this.__originalSetTransform(e, s, i, n, r, a);
        }, c.resetTransform = function() {
            t.resetTransform(), this.__originalResetTransform();
        }, c.rotate = function(e) {
            t.rotate(e), this.__originalRotate(e);
        }, c.clip = function(e) {
            t.clip(e), this.__originalClip(e);
        }, c.moveTo = function(e, s) {
            t.moveTo(e, s), this.__originalMoveTo(e, s);
        }, c.lineTo = function(e, s) {
            t.lineTo(e, s), this.__originalLineTo(e, s);
        }, c.bezierCurveTo = function(e, s, i, n, r, a) {
            t.bezierCurveTo(e, s, i, n, r, a), this.__originalBezierCurveTo(e, s, i, n, r, a);
        }, c.rect = function(e, s, i, n) {
            t.rect(e, s, i, n), this.__originalRect(e, s, i, n);
        }, c.closePath = function() {
            t.closePath(), this.__originalClosePath();
        }, c.beginPath = function() {
            t.beginPath(), this.__originalBeginPath();
        };
    }
    class Yi {
        constructor(t){
            this.canvasFactory = t, this.cache = Object.create(null);
        }
        getCanvas(t, e, s) {
            let i;
            return this.cache[t] !== void 0 ? (i = this.cache[t], this.canvasFactory.reset(i, e, s)) : (i = this.canvasFactory.create(e, s), this.cache[t] = i), i;
        }
        delete(t) {
            delete this.cache[t];
        }
        clear() {
            for(const t in this.cache){
                const e = this.cache[t];
                this.canvasFactory.destroy(e), delete this.cache[t];
            }
        }
    }
    function de(c, t, e, s, i, n, r, a, o, l) {
        const [h, d, u, f, g, p] = z(c);
        if (d === 0 && u === 0) {
            const y = r * h + g, A = Math.round(y), v = a * f + p, w = Math.round(v), _ = (r + o) * h + g, S = Math.abs(Math.round(_) - A) || 1, E = (a + l) * f + p, C = Math.abs(Math.round(E) - w) || 1;
            return c.setTransform(Math.sign(h), 0, 0, Math.sign(f), A, w), c.drawImage(t, e, s, i, n, 0, 0, S, C), c.setTransform(h, d, u, f, g, p), [
                S,
                C
            ];
        }
        if (h === 0 && f === 0) {
            const y = a * u + g, A = Math.round(y), v = r * d + p, w = Math.round(v), _ = (a + l) * u + g, S = Math.abs(Math.round(_) - A) || 1, E = (r + o) * d + p, C = Math.abs(Math.round(E) - w) || 1;
            return c.setTransform(0, Math.sign(d), Math.sign(u), 0, A, w), c.drawImage(t, e, s, i, n, 0, 0, C, S), c.setTransform(h, d, u, f, g, p), [
                C,
                S
            ];
        }
        c.drawImage(t, e, s, i, n, r, a, o, l);
        const m = Math.hypot(h, d), b = Math.hypot(u, f);
        return [
            m * o,
            b * l
        ];
    }
    class _s {
        alphaIsShape = !1;
        fontSize = 0;
        fontSizeScale = 1;
        textMatrix = null;
        textMatrixScale = 1;
        fontMatrix = Ne;
        leading = 0;
        x = 0;
        y = 0;
        lineX = 0;
        lineY = 0;
        charSpacing = 0;
        wordSpacing = 0;
        textHScale = 1;
        textRenderingMode = it.FILL;
        textRise = 0;
        fillColor = "#000000";
        strokeColor = "#000000";
        patternFill = !1;
        patternStroke = !1;
        fillAlpha = 1;
        strokeAlpha = 1;
        lineWidth = 1;
        activeSMask = null;
        transferMaps = "none";
        constructor(t, e){
            this.clipBox = new Float32Array([
                0,
                0,
                t,
                e
            ]), this.minMax = zt.slice();
        }
        clone() {
            const t = Object.create(this);
            return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t;
        }
        getPathBoundingBox(t = et.FILL, e = null) {
            const s = this.minMax.slice();
            if (t === et.STROKE) {
                e || $("Stroke bounding box must include transform."), P.singularValueDecompose2dScale(e, dt);
                const i = dt[0] * this.lineWidth / 2, n = dt[1] * this.lineWidth / 2;
                s[0] -= i, s[1] -= n, s[2] += i, s[3] += n;
            }
            return s;
        }
        updateClipFromPath() {
            const t = P.intersect(this.clipBox, this.getPathBoundingBox());
            this.startNewPathAndClipBox(t || [
                0,
                0,
                0,
                0
            ]);
        }
        isEmptyClip() {
            return this.minMax[0] === 1 / 0;
        }
        startNewPathAndClipBox(t) {
            this.clipBox.set(t, 0), this.minMax.set(zt, 0);
        }
        getClippedPathBoundingBox(t = et.FILL, e = null) {
            return P.intersect(this.clipBox, this.getPathBoundingBox(t, e));
        }
    }
    function Ss(c, t) {
        if (t instanceof ImageData) {
            c.putImageData(t, 0, 0);
            return;
        }
        const e = t.height, s = t.width, i = e % ht, n = (e - i) / ht, r = i === 0 ? n : n + 1, a = c.createImageData(s, ht);
        let o = 0, l;
        const h = t.data, d = a.data;
        let u, f, g, p;
        if (t.kind === me.GRAYSCALE_1BPP) {
            const m = h.byteLength, b = new Uint32Array(d.buffer, 0, d.byteLength >> 2), y = b.length, A = s + 7 >> 3, v = 4294967295, w = st.isLittleEndian ? 4278190080 : 255;
            for(u = 0; u < r; u++){
                for(g = u < n ? ht : i, l = 0, f = 0; f < g; f++){
                    const _ = m - o;
                    let S = 0;
                    const E = _ > A ? s : _ * 8 - 7, C = E & -8;
                    let M = 0, I = 0;
                    for(; S < C; S += 8)I = h[o++], b[l++] = I & 128 ? v : w, b[l++] = I & 64 ? v : w, b[l++] = I & 32 ? v : w, b[l++] = I & 16 ? v : w, b[l++] = I & 8 ? v : w, b[l++] = I & 4 ? v : w, b[l++] = I & 2 ? v : w, b[l++] = I & 1 ? v : w;
                    for(; S < E; S++)M === 0 && (I = h[o++], M = 128), b[l++] = I & M ? v : w, M >>= 1;
                }
                for(; l < y;)b[l++] = 0;
                c.putImageData(a, 0, u * ht);
            }
        } else if (t.kind === me.RGBA_32BPP) {
            for(f = 0, p = s * ht * 4, u = 0; u < n; u++)d.set(h.subarray(o, o + p)), o += p, c.putImageData(a, 0, f), f += ht;
            u < r && (p = s * i * 4, d.set(h.subarray(o, o + p)), c.putImageData(a, 0, f));
        } else if (t.kind === me.RGB_24BPP) for(g = ht, p = s * g, u = 0; u < r; u++){
            for(u >= n && (g = i, p = s * g), l = 0, f = p; f--;)d[l++] = h[o++], d[l++] = h[o++], d[l++] = h[o++], d[l++] = 255;
            c.putImageData(a, 0, u * ht);
        }
        else throw new Error(`bad image kind: ${t.kind}`);
    }
    function Es(c, t) {
        if (t.bitmap) {
            c.drawImage(t.bitmap, 0, 0);
            return;
        }
        const e = t.height, s = t.width, i = e % ht, n = (e - i) / ht, r = i === 0 ? n : n + 1, a = c.createImageData(s, ht);
        let o = 0;
        const l = t.data, h = a.data;
        for(let d = 0; d < r; d++){
            const u = d < n ? ht : i;
            ({ srcPos: o } = Wi({
                src: l,
                srcPos: o,
                dest: h,
                width: s,
                height: u,
                nonBlackColor: 0
            })), c.putImageData(a, 0, d * ht);
        }
    }
    function Xt(c, t) {
        const e = [
            "strokeStyle",
            "fillStyle",
            "fillRule",
            "globalAlpha",
            "lineWidth",
            "lineCap",
            "lineJoin",
            "miterLimit",
            "globalCompositeOperation",
            "font",
            "filter"
        ];
        for (const s of e)c[s] !== void 0 && (t[s] = c[s]);
        c.setLineDash !== void 0 && (t.setLineDash(c.getLineDash()), t.lineDashOffset = c.lineDashOffset);
    }
    function ue(c) {
        c.strokeStyle = c.fillStyle = "#000000", c.fillRule = "nonzero", c.globalAlpha = 1, c.lineWidth = 1, c.lineCap = "butt", c.lineJoin = "miter", c.miterLimit = 10, c.globalCompositeOperation = "source-over", c.font = "10px sans-serif", c.setLineDash !== void 0 && (c.setLineDash([]), c.lineDashOffset = 0);
        const { filter: t } = c;
        t !== "none" && t !== "" && (c.filter = "none");
    }
    function Cs(c, t) {
        if (t) return !0;
        P.singularValueDecompose2dScale(c, dt);
        const e = Math.fround(Et.pixelRatio * Vt.PDF_TO_CSS_UNITS);
        return dt[0] <= e && dt[1] <= e;
    }
    const Ki = [
        "butt",
        "round",
        "square"
    ], Qi = [
        "miter",
        "round",
        "bevel"
    ], Ji = {}, xs = {};
    class jt {
        constructor(t, e, s, i, n, { optionalContentConfig: r, markedContentStack: a = null }, o, l){
            this.ctx = t, this.current = new _s(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.res = null, this.xobjs = null, this.commonObjs = e, this.objs = s, this.canvasFactory = i, this.filterFactory = n, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.smaskCounter = 0, this.tempSMask = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = a || [], this.optionalContentConfig = r, this.cachedCanvases = new Yi(this.canvasFactory), this.cachedPatterns = new Map, this.annotationCanvasMap = o, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = l, this._cachedScaleForStroking = [
                -1,
                0
            ], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = new Map;
        }
        getObject(t, e = null) {
            return typeof t == "string" ? t.startsWith("g_") ? this.commonObjs.get(t) : this.objs.get(t) : e;
        }
        beginDrawing({ transform: t, viewport: e, transparency: s = !1, background: i = null }) {
            const n = this.ctx.canvas.width, r = this.ctx.canvas.height, a = this.ctx.fillStyle;
            if (this.ctx.fillStyle = i || "#ffffff", this.ctx.fillRect(0, 0, n, r), this.ctx.fillStyle = a, s) {
                const o = this.cachedCanvases.getCanvas("transparent", n, r);
                this.compositeCtx = this.ctx, this.transparentCanvas = o.canvas, this.ctx = o.context, this.ctx.save(), this.ctx.transform(...z(this.compositeCtx));
            }
            this.ctx.save(), ue(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[0]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = z(this.ctx);
        }
        executeOperatorList(t, e, s, i) {
            const n = t.argsArray, r = t.fnArray;
            let a = e || 0;
            const o = n.length;
            if (o === a) return a;
            const l = o - a > vs && typeof s == "function", h = l ? Date.now() + qi : 0;
            let d = 0;
            const u = this.commonObjs, f = this.objs;
            let g;
            for(;;){
                if (i !== void 0 && a === i.nextBreakPoint) return i.breakIt(a, s), a;
                if (g = r[a], g !== be.dependency) this[g].apply(this, n[a]);
                else for (const p of n[a]){
                    const m = p.startsWith("g_") ? u : f;
                    if (!m.has(p)) return m.get(p, s), a;
                }
                if (a++, a === o) return a;
                if (l && ++d > vs) {
                    if (Date.now() > h) return s(), a;
                    d = 0;
                }
            }
        }
        #t() {
            for(; this.stateStack.length || this.inSMaskMode;)this.restore();
            this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.transparentCanvas = null);
        }
        endDrawing() {
            this.#t(), this.cachedCanvases.clear(), this.cachedPatterns.clear();
            for (const t of this._cachedBitmapsMap.values()){
                for (const e of t.values())typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
                t.clear();
            }
            this._cachedBitmapsMap.clear(), this.#e();
        }
        #e() {
            if (this.pageColors) {
                const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
                if (t !== "none") {
                    const e = this.ctx.filter;
                    this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
                }
            }
        }
        _scaleImage(t, e) {
            const s = t.width ?? t.displayWidth, i = t.height ?? t.displayHeight;
            let n = Math.max(Math.hypot(e[0], e[1]), 1), r = Math.max(Math.hypot(e[2], e[3]), 1), a = s, o = i, l = "prescale1", h, d;
            for(; n > 2 && a > 1 || r > 2 && o > 1;){
                let u = a, f = o;
                n > 2 && a > 1 && (u = a >= 16384 ? Math.floor(a / 2) - 1 || 1 : Math.ceil(a / 2), n /= a / u), r > 2 && o > 1 && (f = o >= 16384 ? Math.floor(o / 2) - 1 || 1 : Math.ceil(o) / 2, r /= o / f), h = this.cachedCanvases.getCanvas(l, u, f), d = h.context, d.clearRect(0, 0, u, f), d.drawImage(t, 0, 0, a, o, 0, 0, u, f), t = h.canvas, a = u, o = f, l = l === "prescale1" ? "prescale2" : "prescale1";
            }
            return {
                img: t,
                paintWidth: a,
                paintHeight: o
            };
        }
        _createMaskCanvas(t) {
            const e = this.ctx, { width: s, height: i } = t, n = this.current.fillColor, r = this.current.patternFill, a = z(e);
            let o, l, h, d;
            if ((t.bitmap || t.data) && t.count > 1) {
                const C = t.bitmap || t.data.buffer;
                l = JSON.stringify(r ? a : [
                    a.slice(0, 4),
                    n
                ]), o = this._cachedBitmapsMap.get(C), o || (o = new Map, this._cachedBitmapsMap.set(C, o));
                const M = o.get(l);
                if (M && !r) {
                    const I = Math.round(Math.min(a[0], a[2]) + a[4]), H = Math.round(Math.min(a[1], a[3]) + a[5]);
                    return {
                        canvas: M,
                        offsetX: I,
                        offsetY: H
                    };
                }
                h = M;
            }
            h || (d = this.cachedCanvases.getCanvas("maskCanvas", s, i), Es(d.context, t));
            let u = P.transform(a, [
                1 / s,
                0,
                0,
                -1 / i,
                0,
                0
            ]);
            u = P.transform(u, [
                1,
                0,
                0,
                1,
                0,
                -i
            ]);
            const f = zt.slice();
            P.axialAlignedBoundingBox([
                0,
                0,
                s,
                i
            ], u, f);
            const [g, p, m, b] = f, y = Math.round(m - g) || 1, A = Math.round(b - p) || 1, v = this.cachedCanvases.getCanvas("fillCanvas", y, A), w = v.context, _ = g, S = p;
            w.translate(-_, -S), w.transform(...u), h || (h = this._scaleImage(d.canvas, mt(w)), h = h.img, o && r && o.set(l, h)), w.imageSmoothingEnabled = Cs(z(w), t.interpolate), de(w, h, 0, 0, h.width, h.height, 0, 0, s, i), w.globalCompositeOperation = "source-in";
            const E = P.transform(mt(w), [
                1,
                0,
                0,
                1,
                -_,
                -S
            ]);
            return w.fillStyle = r ? n.getPattern(e, this, E, et.FILL) : n, w.fillRect(0, 0, s, i), o && !r && (this.cachedCanvases.delete("fillCanvas"), o.set(l, v.canvas)), {
                canvas: v.canvas,
                offsetX: Math.round(_),
                offsetY: Math.round(S)
            };
        }
        setLineWidth(t) {
            t !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = t, this.ctx.lineWidth = t;
        }
        setLineCap(t) {
            this.ctx.lineCap = Ki[t];
        }
        setLineJoin(t) {
            this.ctx.lineJoin = Qi[t];
        }
        setMiterLimit(t) {
            this.ctx.miterLimit = t;
        }
        setDash(t, e) {
            const s = this.ctx;
            s.setLineDash !== void 0 && (s.setLineDash(t), s.lineDashOffset = e);
        }
        setRenderingIntent(t) {}
        setFlatness(t) {}
        setGState(t) {
            for (const [e, s] of t)switch(e){
                case "LW":
                    this.setLineWidth(s);
                    break;
                case "LC":
                    this.setLineCap(s);
                    break;
                case "LJ":
                    this.setLineJoin(s);
                    break;
                case "ML":
                    this.setMiterLimit(s);
                    break;
                case "D":
                    this.setDash(s[0], s[1]);
                    break;
                case "RI":
                    this.setRenderingIntent(s);
                    break;
                case "FL":
                    this.setFlatness(s);
                    break;
                case "Font":
                    this.setFont(s[0], s[1]);
                    break;
                case "CA":
                    this.current.strokeAlpha = s;
                    break;
                case "ca":
                    this.ctx.globalAlpha = this.current.fillAlpha = s;
                    break;
                case "BM":
                    this.ctx.globalCompositeOperation = s;
                    break;
                case "SMask":
                    this.current.activeSMask = s ? this.tempSMask : null, this.tempSMask = null, this.checkSMaskState();
                    break;
                case "TR":
                    this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(s);
                    break;
            }
        }
        get inSMaskMode() {
            return !!this.suspendedCtx;
        }
        checkSMaskState() {
            const t = this.inSMaskMode;
            this.current.activeSMask && !t ? this.beginSMaskMode() : !this.current.activeSMask && t && this.endSMaskMode();
        }
        beginSMaskMode() {
            if (this.inSMaskMode) throw new Error("beginSMaskMode called while already in smask mode");
            const t = this.ctx.canvas.width, e = this.ctx.canvas.height, s = "smaskGroupAt" + this.groupLevel, i = this.cachedCanvases.getCanvas(s, t, e);
            this.suspendedCtx = this.ctx;
            const n = this.ctx = i.context;
            n.setTransform(this.suspendedCtx.getTransform()), Xt(this.suspendedCtx, n), Xi(n, this.suspendedCtx), this.setGState([
                [
                    "BM",
                    "source-over"
                ]
            ]);
        }
        endSMaskMode() {
            if (!this.inSMaskMode) throw new Error("endSMaskMode called while not in smask mode");
            this.ctx._removeMirroring(), Xt(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null;
        }
        compose(t) {
            if (!this.current.activeSMask) return;
            t ? (t[0] = Math.floor(t[0]), t[1] = Math.floor(t[1]), t[2] = Math.ceil(t[2]), t[3] = Math.ceil(t[3])) : t = [
                0,
                0,
                this.ctx.canvas.width,
                this.ctx.canvas.height
            ];
            const e = this.current.activeSMask, s = this.suspendedCtx;
            this.composeSMask(s, e, this.ctx, t), this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore();
        }
        composeSMask(t, e, s, i) {
            const n = i[0], r = i[1], a = i[2] - n, o = i[3] - r;
            a === 0 || o === 0 || (this.genericComposeSMask(e.context, s, a, o, e.subtype, e.backdrop, e.transferMap, n, r, e.offsetX, e.offsetY), t.save(), t.globalAlpha = 1, t.globalCompositeOperation = "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s.canvas, 0, 0), t.restore());
        }
        genericComposeSMask(t, e, s, i, n, r, a, o, l, h, d) {
            let u = t.canvas, f = o - h, g = l - d;
            if (r) {
                const m = P.makeHexColor(...r);
                if (f < 0 || g < 0 || f + s > u.width || g + i > u.height) {
                    const b = this.cachedCanvases.getCanvas("maskExtension", s, i), y = b.context;
                    y.drawImage(u, -f, -g), y.globalCompositeOperation = "destination-atop", y.fillStyle = m, y.fillRect(0, 0, s, i), y.globalCompositeOperation = "source-over", u = b.canvas, f = g = 0;
                } else {
                    t.save(), t.globalAlpha = 1, t.setTransform(1, 0, 0, 1, 0, 0);
                    const b = new Path2D;
                    b.rect(f, g, s, i), t.clip(b), t.globalCompositeOperation = "destination-atop", t.fillStyle = m, t.fillRect(f, g, s, i), t.restore();
                }
            }
            e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0), n === "Alpha" && a ? e.filter = this.filterFactory.addAlphaFilter(a) : n === "Luminosity" && (e.filter = this.filterFactory.addLuminosityFilter(a));
            const p = new Path2D;
            p.rect(o, l, s, i), e.clip(p), e.globalCompositeOperation = "destination-in", e.drawImage(u, f, g, s, i, o, l, s, i), e.restore();
        }
        save() {
            this.inSMaskMode && Xt(this.ctx, this.suspendedCtx), this.ctx.save();
            const t = this.current;
            this.stateStack.push(t), this.current = t.clone();
        }
        restore() {
            if (this.stateStack.length === 0) {
                this.inSMaskMode && this.endSMaskMode();
                return;
            }
            this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && Xt(this.suspendedCtx, this.ctx), this.checkSMaskState(), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
        }
        transform(t, e, s, i, n, r) {
            this.ctx.transform(t, e, s, i, n, r), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
        }
        constructPath(t, e, s) {
            let [i] = e;
            if (!s) {
                i ||= e[0] = new Path2D, this[t](i);
                return;
            }
            if (!(i instanceof Path2D)) {
                const n = e[0] = new Path2D;
                for(let r = 0, a = i.length; r < a;)switch(i[r++]){
                    case he.moveTo:
                        n.moveTo(i[r++], i[r++]);
                        break;
                    case he.lineTo:
                        n.lineTo(i[r++], i[r++]);
                        break;
                    case he.curveTo:
                        n.bezierCurveTo(i[r++], i[r++], i[r++], i[r++], i[r++], i[r++]);
                        break;
                    case he.closePath:
                        n.closePath();
                        break;
                    default:
                        F(`Unrecognized drawing path operator: ${i[r - 1]}`);
                        break;
                }
                i = n;
            }
            P.axialAlignedBoundingBox(s, z(this.ctx), this.current.minMax), this[t](i);
        }
        closePath() {
            this.ctx.closePath();
        }
        stroke(t, e = !0) {
            const s = this.ctx, i = this.current.strokeColor;
            if (s.globalAlpha = this.current.strokeAlpha, this.contentVisible) if (typeof i == "object" && i?.getPattern) {
                const n = i.isModifyingCurrentTransform() ? s.getTransform() : null;
                if (s.save(), s.strokeStyle = i.getPattern(s, this, mt(s), et.STROKE), n) {
                    const r = new Path2D;
                    r.addPath(t, s.getTransform().invertSelf().multiplySelf(n)), t = r;
                }
                this.rescaleAndStroke(t, !1), s.restore();
            } else this.rescaleAndStroke(t, !0);
            e && this.consumePath(t, this.current.getClippedPathBoundingBox(et.STROKE, z(this.ctx))), s.globalAlpha = this.current.fillAlpha;
        }
        closeStroke(t) {
            this.stroke(t);
        }
        fill(t, e = !0) {
            const s = this.ctx, i = this.current.fillColor, n = this.current.patternFill;
            let r = !1;
            if (n) {
                const o = i.isModifyingCurrentTransform() ? s.getTransform() : null;
                if (s.save(), s.fillStyle = i.getPattern(s, this, mt(s), et.FILL), o) {
                    const l = new Path2D;
                    l.addPath(t, s.getTransform().invertSelf().multiplySelf(o)), t = l;
                }
                r = !0;
            }
            const a = this.current.getClippedPathBoundingBox();
            this.contentVisible && a !== null && (this.pendingEOFill ? (s.fill(t, "evenodd"), this.pendingEOFill = !1) : s.fill(t)), r && s.restore(), e && this.consumePath(t, a);
        }
        eoFill(t) {
            this.pendingEOFill = !0, this.fill(t);
        }
        fillStroke(t) {
            this.fill(t, !1), this.stroke(t, !1), this.consumePath(t);
        }
        eoFillStroke(t) {
            this.pendingEOFill = !0, this.fillStroke(t);
        }
        closeFillStroke(t) {
            this.fillStroke(t);
        }
        closeEOFillStroke(t) {
            this.pendingEOFill = !0, this.fillStroke(t);
        }
        endPath(t) {
            this.consumePath(t);
        }
        rawFillPath(t) {
            this.ctx.fill(t);
        }
        clip() {
            this.pendingClip = Ji;
        }
        eoClip() {
            this.pendingClip = xs;
        }
        beginText() {
            this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0;
        }
        endText() {
            const t = this.pendingTextPaths, e = this.ctx;
            if (t === void 0) return;
            const s = new Path2D, i = e.getTransform().invertSelf();
            for (const { transform: n, x: r, y: a, fontSize: o, path: l } of t)s.addPath(l, new DOMMatrix(n).preMultiplySelf(i).translate(r, a).scale(o, -o));
            e.clip(s), delete this.pendingTextPaths;
        }
        setCharSpacing(t) {
            this.current.charSpacing = t;
        }
        setWordSpacing(t) {
            this.current.wordSpacing = t;
        }
        setHScale(t) {
            this.current.textHScale = t / 100;
        }
        setLeading(t) {
            this.current.leading = -t;
        }
        setFont(t, e) {
            const s = this.commonObjs.get(t), i = this.current;
            if (!s) throw new Error(`Can't find font for ${t}`);
            if (i.fontMatrix = s.fontMatrix || Ne, (i.fontMatrix[0] === 0 || i.fontMatrix[3] === 0) && F("Invalid font matrix for font " + t), e < 0 ? (e = -e, i.fontDirection = -1) : i.fontDirection = 1, this.current.font = s, this.current.fontSize = e, s.isType3Font) return;
            const n = s.loadedName || "sans-serif", r = s.systemFontInfo?.css || `"${n}", ${s.fallbackName}`;
            let a = "normal";
            s.black ? a = "900" : s.bold && (a = "bold");
            const o = s.italic ? "italic" : "normal";
            let l = e;
            e < ys ? l = ys : e > ws && (l = ws), this.current.fontSizeScale = e / l, this.ctx.font = `${o} ${a} ${l}px ${r}`;
        }
        setTextRenderingMode(t) {
            this.current.textRenderingMode = t;
        }
        setTextRise(t) {
            this.current.textRise = t;
        }
        moveText(t, e) {
            this.current.x = this.current.lineX += t, this.current.y = this.current.lineY += e;
        }
        setLeadingMoveText(t, e) {
            this.setLeading(-e), this.moveText(t, e);
        }
        setTextMatrix(t) {
            const { current: e } = this;
            e.textMatrix = t, e.textMatrixScale = Math.hypot(t[0], t[1]), e.x = e.lineX = 0, e.y = e.lineY = 0;
        }
        nextLine() {
            this.moveText(0, this.current.leading);
        }
        #s(t, e, s) {
            const i = new Path2D;
            return i.addPath(t, new DOMMatrix(s).invertSelf().multiplySelf(e)), i;
        }
        paintChar(t, e, s, i, n) {
            const r = this.ctx, a = this.current, o = a.font, l = a.textRenderingMode, h = a.fontSize / a.fontSizeScale, d = l & it.FILL_STROKE_MASK, u = !!(l & it.ADD_TO_PATH_FLAG), f = a.patternFill && !o.missingFile, g = a.patternStroke && !o.missingFile;
            let p;
            if ((o.disableFontFace || u || f || g) && (p = o.getPathGenerator(this.commonObjs, t)), o.disableFontFace || f || g) {
                r.save(), r.translate(e, s), r.scale(h, -h);
                let m;
                if ((d === it.FILL || d === it.FILL_STROKE) && (i ? (m = r.getTransform(), r.setTransform(...i), r.fill(this.#s(p, m, i))) : r.fill(p)), d === it.STROKE || d === it.FILL_STROKE) if (n) {
                    m ||= r.getTransform(), r.setTransform(...n);
                    const { a: b, b: y, c: A, d: v } = m, w = P.inverseTransform(n), _ = P.transform([
                        b,
                        y,
                        A,
                        v,
                        0,
                        0
                    ], w);
                    P.singularValueDecompose2dScale(_, dt), r.lineWidth *= Math.max(dt[0], dt[1]) / h, r.stroke(this.#s(p, m, n));
                } else r.lineWidth /= h, r.stroke(p);
                r.restore();
            } else (d === it.FILL || d === it.FILL_STROKE) && r.fillText(t, e, s), (d === it.STROKE || d === it.FILL_STROKE) && r.strokeText(t, e, s);
            u && (this.pendingTextPaths ||= []).push({
                transform: z(r),
                x: e,
                y: s,
                fontSize: h,
                path: p
            });
        }
        get isFontSubpixelAAEnabled() {
            const { context: t } = this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled", 10, 10);
            t.scale(1.5, 1), t.fillText("I", 0, 10);
            const e = t.getImageData(0, 0, 10, 10).data;
            let s = !1;
            for(let i = 3; i < e.length; i += 4)if (e[i] > 0 && e[i] < 255) {
                s = !0;
                break;
            }
            return N(this, "isFontSubpixelAAEnabled", s);
        }
        showText(t) {
            const e = this.current, s = e.font;
            if (s.isType3Font) return this.showType3Text(t);
            const i = e.fontSize;
            if (i === 0) return;
            const n = this.ctx, r = e.fontSizeScale, a = e.charSpacing, o = e.wordSpacing, l = e.fontDirection, h = e.textHScale * l, d = t.length, u = s.vertical, f = u ? 1 : -1, g = s.defaultVMetrics, p = i * e.fontMatrix[0], m = e.textRenderingMode === it.FILL && !s.disableFontFace && !e.patternFill;
            n.save(), e.textMatrix && n.transform(...e.textMatrix), n.translate(e.x, e.y + e.textRise), l > 0 ? n.scale(h, -1) : n.scale(h, 1);
            let b, y;
            if (e.patternFill) {
                n.save();
                const S = e.fillColor.getPattern(n, this, mt(n), et.FILL);
                b = z(n), n.restore(), n.fillStyle = S;
            }
            if (e.patternStroke) {
                n.save();
                const S = e.strokeColor.getPattern(n, this, mt(n), et.STROKE);
                y = z(n), n.restore(), n.strokeStyle = S;
            }
            let A = e.lineWidth;
            const v = e.textMatrixScale;
            if (v === 0 || A === 0) {
                const S = e.textRenderingMode & it.FILL_STROKE_MASK;
                (S === it.STROKE || S === it.FILL_STROKE) && (A = this.getSinglePixelWidth());
            } else A /= v;
            if (r !== 1 && (n.scale(r, r), A /= r), n.lineWidth = A, s.isInvalidPDFjsFont) {
                const S = [];
                let E = 0;
                for (const C of t)S.push(C.unicode), E += C.width;
                n.fillText(S.join(""), 0, 0), e.x += E * p * h, n.restore(), this.compose();
                return;
            }
            let w = 0, _;
            for(_ = 0; _ < d; ++_){
                const S = t[_];
                if (typeof S == "number") {
                    w += f * S * i / 1e3;
                    continue;
                }
                let E = !1;
                const C = (S.isSpace ? o : 0) + a, M = S.fontChar, I = S.accent;
                let H, G, B = S.width;
                if (u) {
                    const T = S.vmetric || g, R = -(S.vmetric ? T[1] : B * .5) * p, ut = T[2] * p;
                    B = T ? -T[0] : B, H = R / r, G = (w + ut) / r;
                } else H = w / r, G = 0;
                if (s.remeasure && B > 0) {
                    const T = n.measureText(M).width * 1e3 / i * r;
                    if (B < T && this.isFontSubpixelAAEnabled) {
                        const R = B / T;
                        E = !0, n.save(), n.scale(R, 1), H /= R;
                    } else B !== T && (H += (B - T) / 2e3 * i / r);
                }
                if (this.contentVisible && (S.isInFont || s.missingFile)) {
                    if (m && !I) n.fillText(M, H, G);
                    else if (this.paintChar(M, H, G, b, y), I) {
                        const T = H + i * I.offset.x / r, R = G - i * I.offset.y / r;
                        this.paintChar(I.fontChar, T, R, b, y);
                    }
                }
                const nt = u ? B * p - C * l : B * p + C * l;
                w += nt, E && n.restore();
            }
            u ? e.y -= w : e.x += w * h, n.restore(), this.compose();
        }
        showType3Text(t) {
            const e = this.ctx, s = this.current, i = s.font, n = s.fontSize, r = s.fontDirection, a = i.vertical ? 1 : -1, o = s.charSpacing, l = s.wordSpacing, h = s.textHScale * r, d = s.fontMatrix || Ne, u = t.length, f = s.textRenderingMode === it.INVISIBLE;
            let g, p, m, b;
            if (!(f || n === 0)) {
                for(this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, e.save(), s.textMatrix && e.transform(...s.textMatrix), e.translate(s.x, s.y + s.textRise), e.scale(h, r), g = 0; g < u; ++g){
                    if (p = t[g], typeof p == "number") {
                        b = a * p * n / 1e3, this.ctx.translate(b, 0), s.x += b * h;
                        continue;
                    }
                    const y = (p.isSpace ? l : 0) + o, A = i.charProcOperatorList[p.operatorListId];
                    A ? this.contentVisible && (this.save(), e.scale(n, n), e.transform(...d), this.executeOperatorList(A), this.restore()) : F(`Type3 character "${p.operatorListId}" is not available.`);
                    const v = [
                        p.width,
                        0
                    ];
                    P.applyTransform(v, d), m = v[0] * n + y, e.translate(m, 0), s.x += m * h;
                }
                e.restore();
            }
        }
        setCharWidth(t, e) {}
        setCharWidthAndBounds(t, e, s, i, n, r) {
            const a = new Path2D;
            a.rect(s, i, n - s, r - i), this.ctx.clip(a), this.endPath();
        }
        getColorN_Pattern(t) {
            let e;
            if (t[0] === "TilingPattern") {
                const s = this.baseTransform || z(this.ctx), i = {
                    createCanvasGraphics: (n)=>new jt(n, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                            optionalContentConfig: this.optionalContentConfig,
                            markedContentStack: this.markedContentStack
                        })
                };
                e = new ss(t, this.ctx, i, s);
            } else e = this._getPattern(t[1], t[2]);
            return e;
        }
        setStrokeColorN() {
            this.current.strokeColor = this.getColorN_Pattern(arguments), this.current.patternStroke = !0;
        }
        setFillColorN() {
            this.current.fillColor = this.getColorN_Pattern(arguments), this.current.patternFill = !0;
        }
        setStrokeRGBColor(t, e, s) {
            this.ctx.strokeStyle = this.current.strokeColor = P.makeHexColor(t, e, s), this.current.patternStroke = !1;
        }
        setStrokeTransparent() {
            this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
        }
        setFillRGBColor(t, e, s) {
            this.ctx.fillStyle = this.current.fillColor = P.makeHexColor(t, e, s), this.current.patternFill = !1;
        }
        setFillTransparent() {
            this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1;
        }
        _getPattern(t, e = null) {
            let s;
            return this.cachedPatterns.has(t) ? s = this.cachedPatterns.get(t) : (s = Vi(this.getObject(t)), this.cachedPatterns.set(t, s)), e && (s.matrix = e), s;
        }
        shadingFill(t) {
            if (!this.contentVisible) return;
            const e = this.ctx;
            this.save();
            const s = this._getPattern(t);
            e.fillStyle = s.getPattern(e, this, mt(e), et.SHADING);
            const i = mt(e);
            if (i) {
                const { width: n, height: r } = e.canvas, a = zt.slice();
                P.axialAlignedBoundingBox([
                    0,
                    0,
                    n,
                    r
                ], i, a);
                const [o, l, h, d] = a;
                this.ctx.fillRect(o, l, h - o, d - l);
            } else this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
            this.compose(this.current.getClippedPathBoundingBox()), this.restore();
        }
        beginInlineImage() {
            $("Should not call beginInlineImage");
        }
        beginImageData() {
            $("Should not call beginImageData");
        }
        paintFormXObjectBegin(t, e) {
            if (this.contentVisible && (this.save(), this.baseTransformStack.push(this.baseTransform), t && this.transform(...t), this.baseTransform = z(this.ctx), e)) {
                P.axialAlignedBoundingBox(e, this.baseTransform, this.current.minMax);
                const [s, i, n, r] = e, a = new Path2D;
                a.rect(s, i, n - s, r - i), this.ctx.clip(a), this.endPath();
            }
        }
        paintFormXObjectEnd() {
            this.contentVisible && (this.restore(), this.baseTransform = this.baseTransformStack.pop());
        }
        beginGroup(t) {
            if (!this.contentVisible) return;
            this.save(), this.inSMaskMode && (this.endSMaskMode(), this.current.activeSMask = null);
            const e = this.ctx;
            t.isolated || _e("TODO: Support non-isolated groups."), t.knockout && F("Knockout groups not supported.");
            const s = z(e);
            if (t.matrix && e.transform(...t.matrix), !t.bbox) throw new Error("Bounding box is required.");
            let i = zt.slice();
            P.axialAlignedBoundingBox(t.bbox, z(e), i);
            const n = [
                0,
                0,
                e.canvas.width,
                e.canvas.height
            ];
            i = P.intersect(i, n) || [
                0,
                0,
                0,
                0
            ];
            const r = Math.floor(i[0]), a = Math.floor(i[1]), o = Math.max(Math.ceil(i[2]) - r, 1), l = Math.max(Math.ceil(i[3]) - a, 1);
            this.current.startNewPathAndClipBox([
                0,
                0,
                o,
                l
            ]);
            let h = "groupAt" + this.groupLevel;
            t.smask && (h += "_smask_" + this.smaskCounter++ % 2);
            const d = this.cachedCanvases.getCanvas(h, o, l), u = d.context;
            u.translate(-r, -a), u.transform(...s);
            let f = new Path2D;
            const [g, p, m, b] = t.bbox;
            if (f.rect(g, p, m - g, b - p), t.matrix) {
                const y = new Path2D;
                y.addPath(f, new DOMMatrix(t.matrix)), f = y;
            }
            u.clip(f), t.smask ? this.smaskStack.push({
                canvas: d.canvas,
                context: u,
                offsetX: r,
                offsetY: a,
                subtype: t.smask.subtype,
                backdrop: t.smask.backdrop,
                transferMap: t.smask.transferMap || null,
                startTransformInverse: null
            }) : (e.setTransform(1, 0, 0, 1, 0, 0), e.translate(r, a), e.save()), Xt(e, u), this.ctx = u, this.setGState([
                [
                    "BM",
                    "source-over"
                ],
                [
                    "ca",
                    1
                ],
                [
                    "CA",
                    1
                ]
            ]), this.groupStack.push(e), this.groupLevel++;
        }
        endGroup(t) {
            if (!this.contentVisible) return;
            this.groupLevel--;
            const e = this.ctx, s = this.groupStack.pop();
            if (this.ctx = s, this.ctx.imageSmoothingEnabled = !1, t.smask) this.tempSMask = this.smaskStack.pop(), this.restore();
            else {
                this.ctx.restore();
                const i = z(this.ctx);
                this.restore(), this.ctx.save(), this.ctx.setTransform(...i);
                const n = zt.slice();
                P.axialAlignedBoundingBox([
                    0,
                    0,
                    e.canvas.width,
                    e.canvas.height
                ], i, n), this.ctx.drawImage(e.canvas, 0, 0), this.ctx.restore(), this.compose(n);
            }
        }
        beginAnnotation(t, e, s, i, n) {
            if (this.#t(), ue(this.ctx), this.ctx.save(), this.save(), this.baseTransform && this.ctx.setTransform(...this.baseTransform), e) {
                const r = e[2] - e[0], a = e[3] - e[1];
                if (n && this.annotationCanvasMap) {
                    s = s.slice(), s[4] -= e[0], s[5] -= e[1], e = e.slice(), e[0] = e[1] = 0, e[2] = r, e[3] = a, P.singularValueDecompose2dScale(z(this.ctx), dt);
                    const { viewportScale: o } = this, l = Math.ceil(r * this.outputScaleX * o), h = Math.ceil(a * this.outputScaleY * o);
                    this.annotationCanvas = this.canvasFactory.create(l, h);
                    const { canvas: d, context: u } = this.annotationCanvas;
                    this.annotationCanvasMap.set(t, d), this.annotationCanvas.savedCtx = this.ctx, this.ctx = u, this.ctx.save(), this.ctx.setTransform(dt[0], 0, 0, -dt[1], 0, a * dt[1]), ue(this.ctx);
                } else {
                    ue(this.ctx), this.endPath();
                    const o = new Path2D;
                    o.rect(e[0], e[1], r, a), this.ctx.clip(o);
                }
            }
            this.current = new _s(this.ctx.canvas.width, this.ctx.canvas.height), this.transform(...s), this.transform(...i);
        }
        endAnnotation() {
            this.annotationCanvas && (this.ctx.restore(), this.#e(), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas);
        }
        paintImageMaskXObject(t) {
            if (!this.contentVisible) return;
            const e = t.count;
            t = this.getObject(t.data, t), t.count = e;
            const s = this.ctx, i = this._createMaskCanvas(t), n = i.canvas;
            s.save(), s.setTransform(1, 0, 0, 1, 0, 0), s.drawImage(n, i.offsetX, i.offsetY), s.restore(), this.compose();
        }
        paintImageMaskXObjectRepeat(t, e, s = 0, i = 0, n, r) {
            if (!this.contentVisible) return;
            t = this.getObject(t.data, t);
            const a = this.ctx;
            a.save();
            const o = z(a);
            a.transform(e, s, i, n, 0, 0);
            const l = this._createMaskCanvas(t);
            a.setTransform(1, 0, 0, 1, l.offsetX - o[4], l.offsetY - o[5]);
            for(let h = 0, d = r.length; h < d; h += 2){
                const u = P.transform(o, [
                    e,
                    s,
                    i,
                    n,
                    r[h],
                    r[h + 1]
                ]);
                a.drawImage(l.canvas, u[4], u[5]);
            }
            a.restore(), this.compose();
        }
        paintImageMaskXObjectGroup(t) {
            if (!this.contentVisible) return;
            const e = this.ctx, s = this.current.fillColor, i = this.current.patternFill;
            for (const n of t){
                const { data: r, width: a, height: o, transform: l } = n, h = this.cachedCanvases.getCanvas("maskCanvas", a, o), d = h.context;
                d.save();
                const u = this.getObject(r, n);
                Es(d, u), d.globalCompositeOperation = "source-in", d.fillStyle = i ? s.getPattern(d, this, mt(e), et.FILL) : s, d.fillRect(0, 0, a, o), d.restore(), e.save(), e.transform(...l), e.scale(1, -1), de(e, h.canvas, 0, 0, a, o, 0, -1, 1, 1), e.restore();
            }
            this.compose();
        }
        paintImageXObject(t) {
            if (!this.contentVisible) return;
            const e = this.getObject(t);
            if (!e) {
                F("Dependent image isn't ready yet");
                return;
            }
            this.paintInlineImageXObject(e);
        }
        paintImageXObjectRepeat(t, e, s, i) {
            if (!this.contentVisible) return;
            const n = this.getObject(t);
            if (!n) {
                F("Dependent image isn't ready yet");
                return;
            }
            const r = n.width, a = n.height, o = [];
            for(let l = 0, h = i.length; l < h; l += 2)o.push({
                transform: [
                    e,
                    0,
                    0,
                    s,
                    i[l],
                    i[l + 1]
                ],
                x: 0,
                y: 0,
                w: r,
                h: a
            });
            this.paintInlineImageXObjectGroup(n, o);
        }
        applyTransferMapsToCanvas(t) {
            return this.current.transferMaps !== "none" && (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none"), t.canvas;
        }
        applyTransferMapsToBitmap(t) {
            if (this.current.transferMaps === "none") return t.bitmap;
            const { bitmap: e, width: s, height: i } = t, n = this.cachedCanvases.getCanvas("inlineImage", s, i), r = n.context;
            return r.filter = this.current.transferMaps, r.drawImage(e, 0, 0), r.filter = "none", n.canvas;
        }
        paintInlineImageXObject(t) {
            if (!this.contentVisible) return;
            const e = t.width, s = t.height, i = this.ctx;
            this.save();
            const { filter: n } = i;
            n !== "none" && n !== "" && (i.filter = "none"), i.scale(1 / e, -1 / s);
            let r;
            if (t.bitmap) r = this.applyTransferMapsToBitmap(t);
            else if (typeof HTMLElement == "function" && t instanceof HTMLElement || !t.data) r = t;
            else {
                const l = this.cachedCanvases.getCanvas("inlineImage", e, s).context;
                Ss(l, t), r = this.applyTransferMapsToCanvas(l);
            }
            const a = this._scaleImage(r, mt(i));
            i.imageSmoothingEnabled = Cs(z(i), t.interpolate), de(i, a.img, 0, 0, a.paintWidth, a.paintHeight, 0, -s, e, s), this.compose(), this.restore();
        }
        paintInlineImageXObjectGroup(t, e) {
            if (!this.contentVisible) return;
            const s = this.ctx;
            let i;
            if (t.bitmap) i = t.bitmap;
            else {
                const n = t.width, r = t.height, o = this.cachedCanvases.getCanvas("inlineImage", n, r).context;
                Ss(o, t), i = this.applyTransferMapsToCanvas(o);
            }
            for (const n of e)s.save(), s.transform(...n.transform), s.scale(1, -1), de(s, i, n.x, n.y, n.w, n.h, 0, -1, 1, 1), s.restore();
            this.compose();
        }
        paintSolidColorImageMask() {
            this.contentVisible && (this.ctx.fillRect(0, 0, 1, 1), this.compose());
        }
        markPoint(t) {}
        markPointProps(t, e) {}
        beginMarkedContent(t) {
            this.markedContentStack.push({
                visible: !0
            });
        }
        beginMarkedContentProps(t, e) {
            t === "OC" ? this.markedContentStack.push({
                visible: this.optionalContentConfig.isVisible(e)
            }) : this.markedContentStack.push({
                visible: !0
            }), this.contentVisible = this.isContentVisible();
        }
        endMarkedContent() {
            this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
        }
        beginCompat() {}
        endCompat() {}
        consumePath(t, e) {
            const s = this.current.isEmptyClip();
            this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(e);
            const i = this.ctx;
            this.pendingClip && (s || (this.pendingClip === xs ? i.clip(t, "evenodd") : i.clip(t)), this.pendingClip = null), this.current.startNewPathAndClipBox(this.current.clipBox);
        }
        getSinglePixelWidth() {
            if (!this._cachedGetSinglePixelWidth) {
                const t = z(this.ctx);
                if (t[1] === 0 && t[2] === 0) this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
                else {
                    const e = Math.abs(t[0] * t[3] - t[2] * t[1]), s = Math.hypot(t[0], t[2]), i = Math.hypot(t[1], t[3]);
                    this._cachedGetSinglePixelWidth = Math.max(s, i) / e;
                }
            }
            return this._cachedGetSinglePixelWidth;
        }
        getScaleForStroking() {
            if (this._cachedScaleForStroking[0] === -1) {
                const { lineWidth: t } = this.current, { a: e, b: s, c: i, d: n } = this.ctx.getTransform();
                let r, a;
                if (s === 0 && i === 0) {
                    const o = Math.abs(e), l = Math.abs(n);
                    if (o === l) if (t === 0) r = a = 1 / o;
                    else {
                        const h = o * t;
                        r = a = h < 1 ? 1 / h : 1;
                    }
                    else if (t === 0) r = 1 / o, a = 1 / l;
                    else {
                        const h = o * t, d = l * t;
                        r = h < 1 ? 1 / h : 1, a = d < 1 ? 1 / d : 1;
                    }
                } else {
                    const o = Math.abs(e * n - s * i), l = Math.hypot(e, s), h = Math.hypot(i, n);
                    if (t === 0) r = h / o, a = l / o;
                    else {
                        const d = t * o;
                        r = h > d ? h / d : 1, a = l > d ? l / d : 1;
                    }
                }
                this._cachedScaleForStroking[0] = r, this._cachedScaleForStroking[1] = a;
            }
            return this._cachedScaleForStroking;
        }
        rescaleAndStroke(t, e) {
            const { ctx: s, current: { lineWidth: i } } = this, [n, r] = this.getScaleForStroking();
            if (n === r) {
                s.lineWidth = (i || 1) * n, s.stroke(t);
                return;
            }
            const a = s.getLineDash();
            e && s.save(), s.scale(n, r), Le.a = 1 / n, Le.d = 1 / r;
            const o = new Path2D;
            if (o.addPath(t, Le), a.length > 0) {
                const l = Math.max(n, r);
                s.setLineDash(a.map((h)=>h / l)), s.lineDashOffset /= l;
            }
            s.lineWidth = i || 1, s.stroke(o), e && s.restore();
        }
        isContentVisible() {
            for(let t = this.markedContentStack.length - 1; t >= 0; t--)if (!this.markedContentStack[t].visible) return !1;
            return !0;
        }
    }
    for(const c in be)jt.prototype[c] !== void 0 && (jt.prototype[be[c]] = jt.prototype[c]);
    te = class {
        static #t = null;
        static #e = "";
        static get workerPort() {
            return this.#t;
        }
        static set workerPort(t) {
            if (!(typeof Worker < "u" && t instanceof Worker) && t !== null) throw new Error("Invalid `workerPort` type.");
            this.#t = t;
        }
        static get workerSrc() {
            return this.#e;
        }
        static set workerSrc(t) {
            if (typeof t != "string") throw new Error("Invalid `workerSrc` type.");
            this.#e = t;
        }
    };
    class Zi {
        #t;
        #e;
        constructor({ parsedData: t, rawData: e }){
            this.#t = t, this.#e = e;
        }
        getRaw() {
            return this.#e;
        }
        get(t) {
            return this.#t.get(t) ?? null;
        }
        [Symbol.iterator]() {
            return this.#t.entries();
        }
    }
    const $t = Symbol("INTERNAL");
    class tn {
        #t = !1;
        #e = !1;
        #s = !1;
        #i = !0;
        constructor(t, { name: e, intent: s, usage: i, rbGroups: n }){
            this.#t = !!(t & ct.DISPLAY), this.#e = !!(t & ct.PRINT), this.name = e, this.intent = s, this.usage = i, this.rbGroups = n;
        }
        get visible() {
            if (this.#s) return this.#i;
            if (!this.#i) return !1;
            const { print: t, view: e } = this.usage;
            return this.#t ? e?.viewState !== "OFF" : this.#e ? t?.printState !== "OFF" : !0;
        }
        _setVisible(t, e, s = !1) {
            t !== $t && $("Internal method `_setVisible` called."), this.#s = s, this.#i = e;
        }
    }
    class en {
        #t = null;
        #e = new Map;
        #s = null;
        #i = null;
        constructor(t, e = ct.DISPLAY){
            if (this.renderingIntent = e, this.name = null, this.creator = null, t !== null) {
                this.name = t.name, this.creator = t.creator, this.#i = t.order;
                for (const s of t.groups)this.#e.set(s.id, new tn(e, s));
                if (t.baseState === "OFF") for (const s of this.#e.values())s._setVisible($t, !1);
                for (const s of t.on)this.#e.get(s)._setVisible($t, !0);
                for (const s of t.off)this.#e.get(s)._setVisible($t, !1);
                this.#s = this.getHash();
            }
        }
        #r(t) {
            const e = t.length;
            if (e < 2) return !0;
            const s = t[0];
            for(let i = 1; i < e; i++){
                const n = t[i];
                let r;
                if (Array.isArray(n)) r = this.#r(n);
                else if (this.#e.has(n)) r = this.#e.get(n).visible;
                else return F(`Optional content group not found: ${n}`), !0;
                switch(s){
                    case "And":
                        if (!r) return !1;
                        break;
                    case "Or":
                        if (r) return !0;
                        break;
                    case "Not":
                        return !r;
                    default:
                        return !0;
                }
            }
            return s === "And";
        }
        isVisible(t) {
            if (this.#e.size === 0) return !0;
            if (!t) return _e("Optional content group not defined."), !0;
            if (t.type === "OCG") return this.#e.has(t.id) ? this.#e.get(t.id).visible : (F(`Optional content group not found: ${t.id}`), !0);
            if (t.type === "OCMD") {
                if (t.expression) return this.#r(t.expression);
                if (!t.policy || t.policy === "AnyOn") {
                    for (const e of t.ids){
                        if (!this.#e.has(e)) return F(`Optional content group not found: ${e}`), !0;
                        if (this.#e.get(e).visible) return !0;
                    }
                    return !1;
                } else if (t.policy === "AllOn") {
                    for (const e of t.ids){
                        if (!this.#e.has(e)) return F(`Optional content group not found: ${e}`), !0;
                        if (!this.#e.get(e).visible) return !1;
                    }
                    return !0;
                } else if (t.policy === "AnyOff") {
                    for (const e of t.ids){
                        if (!this.#e.has(e)) return F(`Optional content group not found: ${e}`), !0;
                        if (!this.#e.get(e).visible) return !0;
                    }
                    return !1;
                } else if (t.policy === "AllOff") {
                    for (const e of t.ids){
                        if (!this.#e.has(e)) return F(`Optional content group not found: ${e}`), !0;
                        if (this.#e.get(e).visible) return !1;
                    }
                    return !0;
                }
                return F(`Unknown optional content policy ${t.policy}.`), !0;
            }
            return F(`Unknown group type ${t.type}.`), !0;
        }
        setVisibility(t, e = !0, s = !0) {
            const i = this.#e.get(t);
            if (!i) {
                F(`Optional content group not found: ${t}`);
                return;
            }
            if (s && e && i.rbGroups.length) for (const n of i.rbGroups)for (const r of n)r !== t && this.#e.get(r)?._setVisible($t, !1, !0);
            i._setVisible($t, !!e, !0), this.#t = null;
        }
        setOCGState({ state: t, preserveRB: e }) {
            let s;
            for (const i of t){
                switch(i){
                    case "ON":
                    case "OFF":
                    case "Toggle":
                        s = i;
                        continue;
                }
                const n = this.#e.get(i);
                if (n) switch(s){
                    case "ON":
                        this.setVisibility(i, !0, e);
                        break;
                    case "OFF":
                        this.setVisibility(i, !1, e);
                        break;
                    case "Toggle":
                        this.setVisibility(i, !n.visible, e);
                        break;
                }
            }
            this.#t = null;
        }
        get hasInitialVisibility() {
            return this.#s === null || this.getHash() === this.#s;
        }
        getOrder() {
            return this.#e.size ? this.#i ? this.#i.slice() : [
                ...this.#e.keys()
            ] : null;
        }
        getGroup(t) {
            return this.#e.get(t) || null;
        }
        getHash() {
            if (this.#t !== null) return this.#t;
            const t = new Bs;
            for (const [e, s] of this.#e)t.update(`${e}:${s.visible}`);
            return this.#t = t.hexdigest();
        }
        [Symbol.iterator]() {
            return this.#e.entries();
        }
    }
    class sn {
        constructor(t, { disableRange: e = !1, disableStream: s = !1 }){
            K(t, 'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.');
            const { length: i, initialData: n, progressiveDone: r, contentDispositionFilename: a } = t;
            if (this._queuedChunks = [], this._progressiveDone = r, this._contentDispositionFilename = a, n?.length > 0) {
                const o = n instanceof Uint8Array && n.byteLength === n.buffer.byteLength ? n.buffer : new Uint8Array(n).buffer;
                this._queuedChunks.push(o);
            }
            this._pdfDataRangeTransport = t, this._isStreamingSupported = !s, this._isRangeSupported = !e, this._contentLength = i, this._fullRequestReader = null, this._rangeReaders = [], t.addRangeListener((o, l)=>{
                this._onReceiveData({
                    begin: o,
                    chunk: l
                });
            }), t.addProgressListener((o, l)=>{
                this._onProgress({
                    loaded: o,
                    total: l
                });
            }), t.addProgressiveReadListener((o)=>{
                this._onReceiveData({
                    chunk: o
                });
            }), t.addProgressiveDoneListener(()=>{
                this._onProgressiveDone();
            }), t.transportReady();
        }
        _onReceiveData({ begin: t, chunk: e }) {
            const s = e instanceof Uint8Array && e.byteLength === e.buffer.byteLength ? e.buffer : new Uint8Array(e).buffer;
            if (t === void 0) this._fullRequestReader ? this._fullRequestReader._enqueue(s) : this._queuedChunks.push(s);
            else {
                const i = this._rangeReaders.some(function(n) {
                    return n._begin !== t ? !1 : (n._enqueue(s), !0);
                });
                K(i, "_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.");
            }
        }
        get _progressiveDataLength() {
            return this._fullRequestReader?._loaded ?? 0;
        }
        _onProgress(t) {
            t.total === void 0 ? this._rangeReaders[0]?.onProgress?.({
                loaded: t.loaded
            }) : this._fullRequestReader?.onProgress?.({
                loaded: t.loaded,
                total: t.total
            });
        }
        _onProgressiveDone() {
            this._fullRequestReader?.progressiveDone(), this._progressiveDone = !0;
        }
        _removeRangeReader(t) {
            const e = this._rangeReaders.indexOf(t);
            e >= 0 && this._rangeReaders.splice(e, 1);
        }
        getFullReader() {
            K(!this._fullRequestReader, "PDFDataTransportStream.getFullReader can only be called once.");
            const t = this._queuedChunks;
            return this._queuedChunks = null, new nn(this, t, this._progressiveDone, this._contentDispositionFilename);
        }
        getRangeReader(t, e) {
            if (e <= this._progressiveDataLength) return null;
            const s = new rn(this, t, e);
            return this._pdfDataRangeTransport.requestDataRange(t, e), this._rangeReaders.push(s), s;
        }
        cancelAllRequests(t) {
            this._fullRequestReader?.cancel(t);
            for (const e of this._rangeReaders.slice(0))e.cancel(t);
            this._pdfDataRangeTransport.abort();
        }
    }
    class nn {
        constructor(t, e, s = !1, i = null){
            this._stream = t, this._done = s || !1, this._filename = Xe(i) ? i : null, this._queuedChunks = e || [], this._loaded = 0;
            for (const n of this._queuedChunks)this._loaded += n.byteLength;
            this._requests = [], this._headersReady = Promise.resolve(), t._fullRequestReader = this, this.onProgress = null;
        }
        _enqueue(t) {
            this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
                value: t,
                done: !1
            }) : this._queuedChunks.push(t), this._loaded += t.byteLength);
        }
        get headersReady() {
            return this._headersReady;
        }
        get filename() {
            return this._filename;
        }
        get isRangeSupported() {
            return this._stream._isRangeSupported;
        }
        get isStreamingSupported() {
            return this._stream._isStreamingSupported;
        }
        get contentLength() {
            return this._stream._contentLength;
        }
        async read() {
            if (this._queuedChunks.length > 0) return {
                value: this._queuedChunks.shift(),
                done: !1
            };
            if (this._done) return {
                value: void 0,
                done: !0
            };
            const t = Promise.withResolvers();
            return this._requests.push(t), t.promise;
        }
        cancel(t) {
            this._done = !0;
            for (const e of this._requests)e.resolve({
                value: void 0,
                done: !0
            });
            this._requests.length = 0;
        }
        progressiveDone() {
            this._done || (this._done = !0);
        }
    }
    class rn {
        constructor(t, e, s){
            this._stream = t, this._begin = e, this._end = s, this._queuedChunk = null, this._requests = [], this._done = !1, this.onProgress = null;
        }
        _enqueue(t) {
            if (!this._done) {
                if (this._requests.length === 0) this._queuedChunk = t;
                else {
                    this._requests.shift().resolve({
                        value: t,
                        done: !1
                    });
                    for (const s of this._requests)s.resolve({
                        value: void 0,
                        done: !0
                    });
                    this._requests.length = 0;
                }
                this._done = !0, this._stream._removeRangeReader(this);
            }
        }
        get isStreamingSupported() {
            return !1;
        }
        async read() {
            if (this._queuedChunk) {
                const e = this._queuedChunk;
                return this._queuedChunk = null, {
                    value: e,
                    done: !1
                };
            }
            if (this._done) return {
                value: void 0,
                done: !0
            };
            const t = Promise.withResolvers();
            return this._requests.push(t), t.promise;
        }
        cancel(t) {
            this._done = !0;
            for (const e of this._requests)e.resolve({
                value: void 0,
                done: !0
            });
            this._requests.length = 0, this._stream._removeRangeReader(this);
        }
    }
    function an(c) {
        let t = !0, e = s("filename\\*", "i").exec(c);
        if (e) {
            e = e[1];
            let h = a(e);
            return h = unescape(h), h = o(h), h = l(h), n(h);
        }
        if (e = r(c), e) {
            const h = l(e);
            return n(h);
        }
        if (e = s("filename", "i").exec(c), e) {
            e = e[1];
            let h = a(e);
            return h = l(h), n(h);
        }
        function s(h, d) {
            return new RegExp("(?:^|;)\\s*" + h + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', d);
        }
        function i(h, d) {
            if (h) {
                if (!/^[\x00-\xFF]+$/.test(d)) return d;
                try {
                    const u = new TextDecoder(h, {
                        fatal: !0
                    }), f = se(d);
                    d = u.decode(f), t = !1;
                } catch  {}
            }
            return d;
        }
        function n(h) {
            return t && /[\x80-\xff]/.test(h) && (h = i("utf-8", h), t && (h = i("iso-8859-1", h))), h;
        }
        function r(h) {
            const d = [];
            let u;
            const f = s("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
            for(; (u = f.exec(h)) !== null;){
                let [, p, m, b] = u;
                if (p = parseInt(p, 10), p in d) {
                    if (p === 0) break;
                    continue;
                }
                d[p] = [
                    m,
                    b
                ];
            }
            const g = [];
            for(let p = 0; p < d.length && p in d; ++p){
                let [m, b] = d[p];
                b = a(b), m && (b = unescape(b), p === 0 && (b = o(b))), g.push(b);
            }
            return g.join("");
        }
        function a(h) {
            if (h.startsWith('"')) {
                const d = h.slice(1).split('\\"');
                for(let u = 0; u < d.length; ++u){
                    const f = d[u].indexOf('"');
                    f !== -1 && (d[u] = d[u].slice(0, f), d.length = u + 1), d[u] = d[u].replaceAll(/\\(.)/g, "$1");
                }
                h = d.join('"');
            }
            return h;
        }
        function o(h) {
            const d = h.indexOf("'");
            if (d === -1) return h;
            const u = h.slice(0, d), g = h.slice(d + 1).replace(/^[^']*'/, "");
            return i(u, g);
        }
        function l(h) {
            return !h.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(h) ? h : h.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g, function(d, u, f, g) {
                if (f === "q" || f === "Q") return g = g.replaceAll("_", " "), g = g.replaceAll(/=([0-9a-fA-F]{2})/g, function(p, m) {
                    return String.fromCharCode(parseInt(m, 16));
                }), i(u, g);
                try {
                    g = atob(g);
                } catch  {}
                return i(u, g);
            });
        }
        return "";
    }
    function Vs(c, t) {
        const e = new Headers;
        if (!c || !t || typeof t != "object") return e;
        for(const s in t){
            const i = t[s];
            i !== void 0 && e.append(s, i);
        }
        return e;
    }
    function Ce(c) {
        return URL.parse(c)?.origin ?? null;
    }
    function Ws({ responseHeaders: c, isHttp: t, rangeChunkSize: e, disableRange: s }) {
        const i = {
            allowRangeRequests: !1,
            suggestedLength: void 0
        }, n = parseInt(c.get("Content-Length"), 10);
        return !Number.isInteger(n) || (i.suggestedLength = n, n <= 2 * e) || s || !t || c.get("Accept-Ranges") !== "bytes" || (c.get("Content-Encoding") || "identity") !== "identity" || (i.allowRangeRequests = !0), i;
    }
    function qs(c) {
        const t = c.get("Content-Disposition");
        if (t) {
            let e = an(t);
            if (e.includes("%")) try {
                e = decodeURIComponent(e);
            } catch  {}
            if (Xe(e)) return e;
        }
        return null;
    }
    function ae(c, t) {
        return new Ae(`Unexpected server response (${c}) while retrieving PDF "${t}".`, c, c === 404 || c === 0 && t.startsWith("file:"));
    }
    function Xs(c) {
        return c === 200 || c === 206;
    }
    function Ys(c, t, e) {
        return {
            method: "GET",
            headers: c,
            signal: e.signal,
            mode: "cors",
            credentials: t ? "include" : "same-origin",
            redirect: "follow"
        };
    }
    function Ks(c) {
        return c instanceof Uint8Array ? c.buffer : c instanceof ArrayBuffer ? c : (F(`getArrayBuffer - unexpected data format: ${c}`), new Uint8Array(c).buffer);
    }
    class Ts {
        _responseOrigin = null;
        constructor(t){
            this.source = t, this.isHttp = /^https?:/i.test(t.url), this.headers = Vs(this.isHttp, t.httpHeaders), this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        get _progressiveDataLength() {
            return this._fullRequestReader?._loaded ?? 0;
        }
        getFullReader() {
            return K(!this._fullRequestReader, "PDFFetchStream.getFullReader can only be called once."), this._fullRequestReader = new on(this), this._fullRequestReader;
        }
        getRangeReader(t, e) {
            if (e <= this._progressiveDataLength) return null;
            const s = new ln(this, t, e);
            return this._rangeRequestReaders.push(s), s;
        }
        cancelAllRequests(t) {
            this._fullRequestReader?.cancel(t);
            for (const e of this._rangeRequestReaders.slice(0))e.cancel(t);
        }
    }
    class on {
        constructor(t){
            this._stream = t, this._reader = null, this._loaded = 0, this._filename = null;
            const e = t.source;
            this._withCredentials = e.withCredentials || !1, this._contentLength = e.length, this._headersCapability = Promise.withResolvers(), this._disableRange = e.disableRange || !1, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._abortController = new AbortController, this._isStreamingSupported = !e.disableStream, this._isRangeSupported = !e.disableRange;
            const s = new Headers(t.headers), i = e.url;
            fetch(i, Ys(s, this._withCredentials, this._abortController)).then((n)=>{
                if (t._responseOrigin = Ce(n.url), !Xs(n.status)) throw ae(n.status, i);
                this._reader = n.body.getReader(), this._headersCapability.resolve();
                const r = n.headers, { allowRangeRequests: a, suggestedLength: o } = Ws({
                    responseHeaders: r,
                    isHttp: t.isHttp,
                    rangeChunkSize: this._rangeChunkSize,
                    disableRange: this._disableRange
                });
                this._isRangeSupported = a, this._contentLength = o || this._contentLength, this._filename = qs(r), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new Pt("Streaming is disabled."));
            }).catch(this._headersCapability.reject), this.onProgress = null;
        }
        get headersReady() {
            return this._headersCapability.promise;
        }
        get filename() {
            return this._filename;
        }
        get contentLength() {
            return this._contentLength;
        }
        get isRangeSupported() {
            return this._isRangeSupported;
        }
        get isStreamingSupported() {
            return this._isStreamingSupported;
        }
        async read() {
            await this._headersCapability.promise;
            const { value: t, done: e } = await this._reader.read();
            return e ? {
                value: t,
                done: e
            } : (this._loaded += t.byteLength, this.onProgress?.({
                loaded: this._loaded,
                total: this._contentLength
            }), {
                value: Ks(t),
                done: !1
            });
        }
        cancel(t) {
            this._reader?.cancel(t), this._abortController.abort();
        }
    }
    class ln {
        constructor(t, e, s){
            this._stream = t, this._reader = null, this._loaded = 0;
            const i = t.source;
            this._withCredentials = i.withCredentials || !1, this._readCapability = Promise.withResolvers(), this._isStreamingSupported = !i.disableStream, this._abortController = new AbortController;
            const n = new Headers(t.headers);
            n.append("Range", `bytes=${e}-${s - 1}`);
            const r = i.url;
            fetch(r, Ys(n, this._withCredentials, this._abortController)).then((a)=>{
                const o = Ce(a.url);
                if (o !== t._responseOrigin) throw new Error(`Expected range response-origin "${o}" to match "${t._responseOrigin}".`);
                if (!Xs(a.status)) throw ae(a.status, r);
                this._readCapability.resolve(), this._reader = a.body.getReader();
            }).catch(this._readCapability.reject), this.onProgress = null;
        }
        get isStreamingSupported() {
            return this._isStreamingSupported;
        }
        async read() {
            await this._readCapability.promise;
            const { value: t, done: e } = await this._reader.read();
            return e ? {
                value: t,
                done: e
            } : (this._loaded += t.byteLength, this.onProgress?.({
                loaded: this._loaded
            }), {
                value: Ks(t),
                done: !1
            });
        }
        cancel(t) {
            this._reader?.cancel(t), this._abortController.abort();
        }
    }
    const De = 200, Fe = 206;
    function hn(c) {
        const t = c.response;
        return typeof t != "string" ? t : se(t).buffer;
    }
    class cn {
        _responseOrigin = null;
        constructor({ url: t, httpHeaders: e, withCredentials: s }){
            this.url = t, this.isHttp = /^https?:/i.test(t), this.headers = Vs(this.isHttp, e), this.withCredentials = s || !1, this.currXhrId = 0, this.pendingRequests = Object.create(null);
        }
        request(t) {
            const e = new XMLHttpRequest, s = this.currXhrId++, i = this.pendingRequests[s] = {
                xhr: e
            };
            e.open("GET", this.url), e.withCredentials = this.withCredentials;
            for (const [n, r] of this.headers)e.setRequestHeader(n, r);
            return this.isHttp && "begin" in t && "end" in t ? (e.setRequestHeader("Range", `bytes=${t.begin}-${t.end - 1}`), i.expectedStatus = Fe) : i.expectedStatus = De, e.responseType = "arraybuffer", K(t.onError, "Expected `onError` callback to be provided."), e.onerror = ()=>{
                t.onError(e.status);
            }, e.onreadystatechange = this.onStateChange.bind(this, s), e.onprogress = this.onProgress.bind(this, s), i.onHeadersReceived = t.onHeadersReceived, i.onDone = t.onDone, i.onError = t.onError, i.onProgress = t.onProgress, e.send(null), s;
        }
        onProgress(t, e) {
            const s = this.pendingRequests[t];
            s && s.onProgress?.(e);
        }
        onStateChange(t, e) {
            const s = this.pendingRequests[t];
            if (!s) return;
            const i = s.xhr;
            if (i.readyState >= 2 && s.onHeadersReceived && (s.onHeadersReceived(), delete s.onHeadersReceived), i.readyState !== 4 || !(t in this.pendingRequests)) return;
            if (delete this.pendingRequests[t], i.status === 0 && this.isHttp) {
                s.onError(i.status);
                return;
            }
            const n = i.status || De;
            if (!(n === De && s.expectedStatus === Fe) && n !== s.expectedStatus) {
                s.onError(i.status);
                return;
            }
            const a = hn(i);
            if (n === Fe) {
                const o = i.getResponseHeader("Content-Range"), l = /bytes (\d+)-(\d+)\/(\d+)/.exec(o);
                l ? s.onDone({
                    begin: parseInt(l[1], 10),
                    chunk: a
                }) : (F('Missing or invalid "Content-Range" header.'), s.onError(0));
            } else a ? s.onDone({
                begin: 0,
                chunk: a
            }) : s.onError(i.status);
        }
        getRequestXhr(t) {
            return this.pendingRequests[t].xhr;
        }
        isPendingRequest(t) {
            return t in this.pendingRequests;
        }
        abortRequest(t) {
            const e = this.pendingRequests[t].xhr;
            delete this.pendingRequests[t], e.abort();
        }
    }
    class dn {
        constructor(t){
            this._source = t, this._manager = new cn(t), this._rangeChunkSize = t.rangeChunkSize, this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        _onRangeRequestReaderClosed(t) {
            const e = this._rangeRequestReaders.indexOf(t);
            e >= 0 && this._rangeRequestReaders.splice(e, 1);
        }
        getFullReader() {
            return K(!this._fullRequestReader, "PDFNetworkStream.getFullReader can only be called once."), this._fullRequestReader = new un(this._manager, this._source), this._fullRequestReader;
        }
        getRangeReader(t, e) {
            const s = new fn(this._manager, t, e);
            return s.onClosed = this._onRangeRequestReaderClosed.bind(this), this._rangeRequestReaders.push(s), s;
        }
        cancelAllRequests(t) {
            this._fullRequestReader?.cancel(t);
            for (const e of this._rangeRequestReaders.slice(0))e.cancel(t);
        }
    }
    class un {
        constructor(t, e){
            this._manager = t, this._url = e.url, this._fullRequestId = t.request({
                onHeadersReceived: this._onHeadersReceived.bind(this),
                onDone: this._onDone.bind(this),
                onError: this._onError.bind(this),
                onProgress: this._onProgress.bind(this)
            }), this._headersCapability = Promise.withResolvers(), this._disableRange = e.disableRange || !1, this._contentLength = e.length, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !1, this._isRangeSupported = !1, this._cachedChunks = [], this._requests = [], this._done = !1, this._storedError = void 0, this._filename = null, this.onProgress = null;
        }
        _onHeadersReceived() {
            const t = this._fullRequestId, e = this._manager.getRequestXhr(t);
            this._manager._responseOrigin = Ce(e.responseURL);
            const s = e.getAllResponseHeaders(), i = new Headers(s ? s.trimStart().replace(/[^\S ]+$/, "").split(/[\r\n]+/).map((a)=>{
                const [o, ...l] = a.split(": ");
                return [
                    o,
                    l.join(": ")
                ];
            }) : []), { allowRangeRequests: n, suggestedLength: r } = Ws({
                responseHeaders: i,
                isHttp: this._manager.isHttp,
                rangeChunkSize: this._rangeChunkSize,
                disableRange: this._disableRange
            });
            n && (this._isRangeSupported = !0), this._contentLength = r || this._contentLength, this._filename = qs(i), this._isRangeSupported && this._manager.abortRequest(t), this._headersCapability.resolve();
        }
        _onDone(t) {
            if (t && (this._requests.length > 0 ? this._requests.shift().resolve({
                value: t.chunk,
                done: !1
            }) : this._cachedChunks.push(t.chunk)), this._done = !0, !(this._cachedChunks.length > 0)) {
                for (const e of this._requests)e.resolve({
                    value: void 0,
                    done: !0
                });
                this._requests.length = 0;
            }
        }
        _onError(t) {
            this._storedError = ae(t, this._url), this._headersCapability.reject(this._storedError);
            for (const e of this._requests)e.reject(this._storedError);
            this._requests.length = 0, this._cachedChunks.length = 0;
        }
        _onProgress(t) {
            this.onProgress?.({
                loaded: t.loaded,
                total: t.lengthComputable ? t.total : this._contentLength
            });
        }
        get filename() {
            return this._filename;
        }
        get isRangeSupported() {
            return this._isRangeSupported;
        }
        get isStreamingSupported() {
            return this._isStreamingSupported;
        }
        get contentLength() {
            return this._contentLength;
        }
        get headersReady() {
            return this._headersCapability.promise;
        }
        async read() {
            if (await this._headersCapability.promise, this._storedError) throw this._storedError;
            if (this._cachedChunks.length > 0) return {
                value: this._cachedChunks.shift(),
                done: !1
            };
            if (this._done) return {
                value: void 0,
                done: !0
            };
            const t = Promise.withResolvers();
            return this._requests.push(t), t.promise;
        }
        cancel(t) {
            this._done = !0, this._headersCapability.reject(t);
            for (const e of this._requests)e.resolve({
                value: void 0,
                done: !0
            });
            this._requests.length = 0, this._manager.isPendingRequest(this._fullRequestId) && this._manager.abortRequest(this._fullRequestId), this._fullRequestReader = null;
        }
    }
    class fn {
        constructor(t, e, s){
            this._manager = t, this._url = t.url, this._requestId = t.request({
                begin: e,
                end: s,
                onHeadersReceived: this._onHeadersReceived.bind(this),
                onDone: this._onDone.bind(this),
                onError: this._onError.bind(this),
                onProgress: this._onProgress.bind(this)
            }), this._requests = [], this._queuedChunk = null, this._done = !1, this._storedError = void 0, this.onProgress = null, this.onClosed = null;
        }
        _onHeadersReceived() {
            const t = Ce(this._manager.getRequestXhr(this._requestId)?.responseURL);
            t !== this._manager._responseOrigin && (this._storedError = new Error(`Expected range response-origin "${t}" to match "${this._manager._responseOrigin}".`), this._onError(0));
        }
        _close() {
            this.onClosed?.(this);
        }
        _onDone(t) {
            const e = t.chunk;
            this._requests.length > 0 ? this._requests.shift().resolve({
                value: e,
                done: !1
            }) : this._queuedChunk = e, this._done = !0;
            for (const s of this._requests)s.resolve({
                value: void 0,
                done: !0
            });
            this._requests.length = 0, this._close();
        }
        _onError(t) {
            this._storedError ??= ae(t, this._url);
            for (const e of this._requests)e.reject(this._storedError);
            this._requests.length = 0, this._queuedChunk = null;
        }
        _onProgress(t) {
            this.isStreamingSupported || this.onProgress?.({
                loaded: t.loaded
            });
        }
        get isStreamingSupported() {
            return !1;
        }
        async read() {
            if (this._storedError) throw this._storedError;
            if (this._queuedChunk !== null) {
                const e = this._queuedChunk;
                return this._queuedChunk = null, {
                    value: e,
                    done: !1
                };
            }
            if (this._done) return {
                value: void 0,
                done: !0
            };
            const t = Promise.withResolvers();
            return this._requests.push(t), t.promise;
        }
        cancel(t) {
            this._done = !0;
            for (const e of this._requests)e.resolve({
                value: void 0,
                done: !0
            });
            this._requests.length = 0, this._manager.isPendingRequest(this._requestId) && this._manager.abortRequest(this._requestId), this._close();
        }
    }
    const pn = /^[a-z][a-z0-9\-+.]+:/i;
    function gn(c) {
        if (pn.test(c)) return new URL(c);
        const t = process.getBuiltinModule("url");
        return new URL(t.pathToFileURL(c));
    }
    class mn {
        constructor(t){
            this.source = t, this.url = gn(t.url), K(this.url.protocol === "file:", "PDFNodeStream only supports file:// URLs."), this._fullRequestReader = null, this._rangeRequestReaders = [];
        }
        get _progressiveDataLength() {
            return this._fullRequestReader?._loaded ?? 0;
        }
        getFullReader() {
            return K(!this._fullRequestReader, "PDFNodeStream.getFullReader can only be called once."), this._fullRequestReader = new bn(this), this._fullRequestReader;
        }
        getRangeReader(t, e) {
            if (e <= this._progressiveDataLength) return null;
            const s = new An(this, t, e);
            return this._rangeRequestReaders.push(s), s;
        }
        cancelAllRequests(t) {
            this._fullRequestReader?.cancel(t);
            for (const e of this._rangeRequestReaders.slice(0))e.cancel(t);
        }
    }
    class bn {
        constructor(t){
            this._url = t.url, this._done = !1, this._storedError = null, this.onProgress = null;
            const e = t.source;
            this._contentLength = e.length, this._loaded = 0, this._filename = null, this._disableRange = e.disableRange || !1, this._rangeChunkSize = e.rangeChunkSize, !this._rangeChunkSize && !this._disableRange && (this._disableRange = !0), this._isStreamingSupported = !e.disableStream, this._isRangeSupported = !e.disableRange, this._readableStream = null, this._readCapability = Promise.withResolvers(), this._headersCapability = Promise.withResolvers();
            const s = process.getBuiltinModule("fs");
            s.promises.lstat(this._url).then((i)=>{
                this._contentLength = i.size, this._setReadableStream(s.createReadStream(this._url)), this._headersCapability.resolve();
            }, (i)=>{
                i.code === "ENOENT" && (i = ae(0, this._url.href)), this._storedError = i, this._headersCapability.reject(i);
            });
        }
        get headersReady() {
            return this._headersCapability.promise;
        }
        get filename() {
            return this._filename;
        }
        get contentLength() {
            return this._contentLength;
        }
        get isRangeSupported() {
            return this._isRangeSupported;
        }
        get isStreamingSupported() {
            return this._isStreamingSupported;
        }
        async read() {
            if (await this._readCapability.promise, this._done) return {
                value: void 0,
                done: !0
            };
            if (this._storedError) throw this._storedError;
            const t = this._readableStream.read();
            return t === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += t.length, this.onProgress?.({
                loaded: this._loaded,
                total: this._contentLength
            }), {
                value: new Uint8Array(t).buffer,
                done: !1
            });
        }
        cancel(t) {
            if (!this._readableStream) {
                this._error(t);
                return;
            }
            this._readableStream.destroy(t);
        }
        _error(t) {
            this._storedError = t, this._readCapability.resolve();
        }
        _setReadableStream(t) {
            this._readableStream = t, t.on("readable", ()=>{
                this._readCapability.resolve();
            }), t.on("end", ()=>{
                t.destroy(), this._done = !0, this._readCapability.resolve();
            }), t.on("error", (e)=>{
                this._error(e);
            }), !this._isStreamingSupported && this._isRangeSupported && this._error(new Pt("streaming is disabled")), this._storedError && this._readableStream.destroy(this._storedError);
        }
    }
    class An {
        constructor(t, e, s){
            this._url = t.url, this._done = !1, this._storedError = null, this.onProgress = null, this._loaded = 0, this._readableStream = null, this._readCapability = Promise.withResolvers();
            const i = t.source;
            this._isStreamingSupported = !i.disableStream;
            const n = process.getBuiltinModule("fs");
            this._setReadableStream(n.createReadStream(this._url, {
                start: e,
                end: s - 1
            }));
        }
        get isStreamingSupported() {
            return this._isStreamingSupported;
        }
        async read() {
            if (await this._readCapability.promise, this._done) return {
                value: void 0,
                done: !0
            };
            if (this._storedError) throw this._storedError;
            const t = this._readableStream.read();
            return t === null ? (this._readCapability = Promise.withResolvers(), this.read()) : (this._loaded += t.length, this.onProgress?.({
                loaded: this._loaded
            }), {
                value: new Uint8Array(t).buffer,
                done: !1
            });
        }
        cancel(t) {
            if (!this._readableStream) {
                this._error(t);
                return;
            }
            this._readableStream.destroy(t);
        }
        _error(t) {
            this._storedError = t, this._readCapability.resolve();
        }
        _setReadableStream(t) {
            this._readableStream = t, t.on("readable", ()=>{
                this._readCapability.resolve();
            }), t.on("end", ()=>{
                t.destroy(), this._done = !0, this._readCapability.resolve();
            }), t.on("error", (e)=>{
                this._error(e);
            }), this._storedError && this._readableStream.destroy(this._storedError);
        }
    }
    const yn = 1e5, Ps = 30;
    rt = class {
        #t = Promise.withResolvers();
        #e = null;
        #s = !1;
        #i = !!globalThis.FontInspector?.enabled;
        #r = null;
        #n = null;
        #l = 0;
        #o = 0;
        #d = null;
        #h = null;
        #u = 0;
        #c = 0;
        #f = Object.create(null);
        #a = [];
        #p = null;
        #m = [];
        #g = new WeakMap;
        #b = null;
        static #A = new Map;
        static #y = new Map;
        static #v = new WeakMap;
        static #S = null;
        static #C = new Set;
        constructor({ textContentSource: t, container: e, viewport: s }){
            if (t instanceof ReadableStream) this.#p = t;
            else if (typeof t == "object") this.#p = new ReadableStream({
                start (o) {
                    o.enqueue(t), o.close();
                }
            });
            else throw new Error('No "textContentSource" parameter specified.');
            this.#e = this.#h = e, this.#c = s.scale * Et.pixelRatio, this.#u = s.rotation, this.#n = {
                div: null,
                properties: null,
                ctx: null
            };
            const { pageWidth: i, pageHeight: n, pageX: r, pageY: a } = s.rawDims;
            this.#b = [
                1,
                0,
                0,
                -1,
                -r,
                a + n
            ], this.#o = i, this.#l = n, rt.#k(), Mt(e, s), this.#t.promise.finally(()=>{
                rt.#C.delete(this), this.#n = null, this.#f = null;
            }).catch(()=>{});
        }
        static get fontFamilyMap() {
            const { isWindows: t, isFirefox: e } = st.platform;
            return N(this, "fontFamilyMap", new Map([
                [
                    "sans-serif",
                    `${t && e ? "Calibri, " : ""}sans-serif`
                ],
                [
                    "monospace",
                    `${t && e ? "Lucida Console, " : ""}monospace`
                ]
            ]));
        }
        render() {
            const t = ()=>{
                this.#d.read().then(({ value: e, done: s })=>{
                    if (s) {
                        this.#t.resolve();
                        return;
                    }
                    this.#r ??= e.lang, Object.assign(this.#f, e.styles), this.#T(e.items), t();
                }, this.#t.reject);
            };
            return this.#d = this.#p.getReader(), rt.#C.add(this), t(), this.#t.promise;
        }
        update({ viewport: t, onBefore: e = null }) {
            const s = t.scale * Et.pixelRatio, i = t.rotation;
            if (i !== this.#u && (e?.(), this.#u = i, Mt(this.#h, {
                rotation: i
            })), s !== this.#c) {
                e?.(), this.#c = s;
                const n = {
                    div: null,
                    properties: null,
                    ctx: rt.#P(this.#r)
                };
                for (const r of this.#m)n.properties = this.#g.get(r), n.div = r, this.#_(n);
            }
        }
        cancel() {
            const t = new Pt("TextLayer task cancelled.");
            this.#d?.cancel(t).catch(()=>{}), this.#d = null, this.#t.reject(t);
        }
        get textDivs() {
            return this.#m;
        }
        get textContentItemsStr() {
            return this.#a;
        }
        #T(t) {
            if (this.#s) return;
            this.#n.ctx ??= rt.#P(this.#r);
            const e = this.#m, s = this.#a;
            for (const i of t){
                if (e.length > yn) {
                    F("Ignoring additional textDivs for performance reasons."), this.#s = !0;
                    return;
                }
                if (i.str === void 0) {
                    if (i.type === "beginMarkedContentProps" || i.type === "beginMarkedContent") {
                        const n = this.#e;
                        this.#e = document.createElement("span"), this.#e.classList.add("markedContent"), i.id !== null && this.#e.setAttribute("id", `${i.id}`), n.append(this.#e);
                    } else i.type === "endMarkedContent" && (this.#e = this.#e.parentNode);
                    continue;
                }
                s.push(i.str), this.#R(i);
            }
        }
        #R(t) {
            const e = document.createElement("span"), s = {
                angle: 0,
                canvasWidth: 0,
                hasText: t.str !== "",
                hasEOL: t.hasEOL,
                fontSize: 0
            };
            this.#m.push(e);
            const i = P.transform(this.#b, t.transform);
            let n = Math.atan2(i[1], i[0]);
            const r = this.#f[t.fontName];
            r.vertical && (n += Math.PI / 2);
            let a = this.#i && r.fontSubstitution || r.fontFamily;
            a = rt.fontFamilyMap.get(a) || a;
            const o = Math.hypot(i[2], i[3]), l = o * rt.#M(a, r, this.#r);
            let h, d;
            n === 0 ? (h = i[4], d = i[5] - l) : (h = i[4] + l * Math.sin(n), d = i[5] - l * Math.cos(n));
            const u = "calc(var(--total-scale-factor) *", f = e.style;
            this.#e === this.#h ? (f.left = `${(100 * h / this.#o).toFixed(2)}%`, f.top = `${(100 * d / this.#l).toFixed(2)}%`) : (f.left = `${u}${h.toFixed(2)}px)`, f.top = `${u}${d.toFixed(2)}px)`), f.fontSize = `${u}${(rt.#S * o).toFixed(2)}px)`, f.fontFamily = a, s.fontSize = o, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, this.#i && (e.dataset.fontName = r.fontSubstitutionLoadedName || t.fontName), n !== 0 && (s.angle = n * (180 / Math.PI));
            let g = !1;
            if (t.str.length > 1) g = !0;
            else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
                const p = Math.abs(t.transform[0]), m = Math.abs(t.transform[3]);
                p !== m && Math.max(p, m) / Math.min(p, m) > 1.5 && (g = !0);
            }
            if (g && (s.canvasWidth = r.vertical ? t.height : t.width), this.#g.set(e, s), this.#n.div = e, this.#n.properties = s, this.#_(this.#n), s.hasText && this.#e.append(e), s.hasEOL) {
                const p = document.createElement("br");
                p.setAttribute("role", "presentation"), this.#e.append(p);
            }
        }
        #_(t) {
            const { div: e, properties: s, ctx: i } = t, { style: n } = e;
            let r = "";
            if (rt.#S > 1 && (r = `scale(${1 / rt.#S})`), s.canvasWidth !== 0 && s.hasText) {
                const { fontFamily: a } = n, { canvasWidth: o, fontSize: l } = s;
                rt.#x(i, l * this.#c, a);
                const { width: h } = i.measureText(e.textContent);
                h > 0 && (r = `scaleX(${o * this.#c / h}) ${r}`);
            }
            s.angle !== 0 && (r = `rotate(${s.angle}deg) ${r}`), r.length > 0 && (n.transform = r);
        }
        static cleanup() {
            if (!(this.#C.size > 0)) {
                this.#A.clear();
                for (const { canvas: t } of this.#y.values())t.remove();
                this.#y.clear();
            }
        }
        static #P(t = null) {
            let e = this.#y.get(t ||= "");
            if (!e) {
                const s = document.createElement("canvas");
                s.className = "hiddenCanvasElement", s.lang = t, document.body.append(s), e = s.getContext("2d", {
                    alpha: !1,
                    willReadFrequently: !0
                }), this.#y.set(t, e), this.#v.set(e, {
                    size: 0,
                    family: ""
                });
            }
            return e;
        }
        static #x(t, e, s) {
            const i = this.#v.get(t);
            e === i.size && s === i.family || (t.font = `${e}px ${s}`, i.size = e, i.family = s);
        }
        static #k() {
            if (this.#S !== null) return;
            const t = document.createElement("div");
            t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), this.#S = t.getBoundingClientRect().height, t.remove();
        }
        static #M(t, e, s) {
            const i = this.#A.get(t);
            if (i) return i;
            const n = this.#P(s);
            n.canvas.width = n.canvas.height = Ps, this.#x(n, Ps, t);
            const r = n.measureText(""), a = r.fontBoundingBoxAscent, o = Math.abs(r.fontBoundingBoxDescent);
            n.canvas.width = n.canvas.height = 0;
            let l = .8;
            return a ? l = a / (a + o) : (st.platform.isFirefox && F("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? l = e.ascent : e.descent && (l = 1 + e.descent)), this.#A.set(t, l), l;
        }
    };
    class ee {
        static textContent(t) {
            const e = [], s = {
                items: e,
                styles: Object.create(null)
            };
            function i(n) {
                if (!n) return;
                let r = null;
                const a = n.name;
                if (a === "#text") r = n.value;
                else if (ee.shouldBuildText(a)) n?.attributes?.textContent ? r = n.attributes.textContent : n.value && (r = n.value);
                else return;
                if (r !== null && e.push({
                    str: r
                }), !!n.children) for (const o of n.children)i(o);
            }
            return i(t), s;
        }
        static shouldBuildText(t) {
            return !(t === "textarea" || t === "input" || t === "option" || t === "select");
        }
    }
    const wn = 65536, vn = 100;
    _n = function(c = {}) {
        typeof c == "string" || c instanceof URL ? c = {
            url: c
        } : (c instanceof ArrayBuffer || ArrayBuffer.isView(c)) && (c = {
            data: c
        });
        const t = new is, { docId: e } = t, s = c.url ? Sn(c.url) : null, i = c.data ? En(c.data) : null, n = c.httpHeaders || null, r = c.withCredentials === !0, a = c.password ?? null, o = c.range instanceof Qs ? c.range : null, l = Number.isInteger(c.rangeChunkSize) && c.rangeChunkSize > 0 ? c.rangeChunkSize : wn;
        let h = c.worker instanceof Z ? c.worker : null;
        const d = c.verbosity, u = typeof c.docBaseUrl == "string" && !Se(c.docBaseUrl) ? c.docBaseUrl : null, f = fe(c.cMapUrl), g = c.cMapPacked !== !1, p = c.CMapReaderFactory || (at ? Bi : gs), m = fe(c.iccUrl), b = fe(c.standardFontDataUrl), y = c.StandardFontDataFactory || (at ? Hi : ms), A = fe(c.wasmUrl), v = c.WasmFactory || (at ? $i : bs), w = c.stopAtErrors !== !0, _ = Number.isInteger(c.maxImageSize) && c.maxImageSize > -1 ? c.maxImageSize : -1, S = c.isEvalSupported !== !1, E = typeof c.isOffscreenCanvasSupported == "boolean" ? c.isOffscreenCanvasSupported : !at, C = typeof c.isImageDecoderSupported == "boolean" ? c.isImageDecoderSupported : !at && (st.platform.isFirefox || !globalThis.chrome), M = Number.isInteger(c.canvasMaxAreaInBytes) ? c.canvasMaxAreaInBytes : -1, I = typeof c.disableFontFace == "boolean" ? c.disableFontFace : at, H = c.fontExtraProperties === !0, G = c.enableXfa === !0, B = c.ownerDocument || globalThis.document, nt = c.disableRange === !0, T = c.disableStream === !0, R = c.disableAutoFetch === !0, ut = c.pdfBug === !0, wt = c.CanvasFactory || (at ? Oi : Di), It = c.FilterFactory || (at ? Ni : Fi), vt = c.enableHWA === !0, J = c.useWasm !== !1, j = o ? o.length : c.length ?? NaN, Nt = typeof c.useSystemFonts == "boolean" ? c.useSystemFonts : !at && !I, Ct = typeof c.useWorkerFetch == "boolean" ? c.useWorkerFetch : !!(p === gs && y === ms && v === bs && f && b && A && Ht(f, document.baseURI) && Ht(b, document.baseURI) && Ht(A, document.baseURI)), xt = null;
        fi(d);
        const U = {
            canvasFactory: new wt({
                ownerDocument: B,
                enableHWA: vt
            }),
            filterFactory: new It({
                docId: e,
                ownerDocument: B
            }),
            cMapReaderFactory: Ct ? null : new p({
                baseUrl: f,
                isCompressed: g
            }),
            standardFontDataFactory: Ct ? null : new y({
                baseUrl: b
            }),
            wasmFactory: Ct ? null : new v({
                baseUrl: A
            })
        };
        if (!h) {
            const qt = {
                verbosity: d,
                port: te.workerPort
            };
            h = qt.port ? Z.fromPort(qt) : new Z(qt), t._worker = h;
        }
        const Wt = {
            docId: e,
            apiVersion: "5.2.133",
            data: i,
            password: a,
            disableAutoFetch: R,
            rangeChunkSize: l,
            length: j,
            docBaseUrl: u,
            enableXfa: G,
            evaluatorOptions: {
                maxImageSize: _,
                disableFontFace: I,
                ignoreErrors: w,
                isEvalSupported: S,
                isOffscreenCanvasSupported: E,
                isImageDecoderSupported: C,
                canvasMaxAreaInBytes: M,
                fontExtraProperties: H,
                useSystemFonts: Nt,
                useWasm: J,
                useWorkerFetch: Ct,
                cMapUrl: f,
                iccUrl: m,
                standardFontDataUrl: b,
                wasmUrl: A
            }
        }, li = {
            ownerDocument: B,
            pdfBug: ut,
            styleElement: xt,
            loadingParams: {
                disableAutoFetch: R,
                enableXfa: G
            }
        };
        return h.promise.then(function() {
            if (t.destroyed) throw new Error("Loading aborted");
            if (h.destroyed) throw new Error("Worker was destroyed");
            const qt = h.messageHandler.sendWithPromise("GetDocRequest", Wt, i ? [
                i.buffer
            ] : null);
            let Te;
            if (o) Te = new sn(o, {
                disableRange: nt,
                disableStream: T
            });
            else if (!i) {
                if (!s) throw new Error("getDocument - no `url` parameter provided.");
                let Ot;
                if (at) if (Ht(s)) {
                    if (typeof fetch > "u" || typeof Response > "u" || !("body" in Response.prototype)) throw new Error("getDocument - the Fetch API was disabled in Node.js, see `--no-experimental-fetch`.");
                    Ot = Ts;
                } else Ot = mn;
                else Ot = Ht(s) ? Ts : dn;
                Te = new Ot({
                    url: s,
                    length: j,
                    httpHeaders: n,
                    withCredentials: r,
                    rangeChunkSize: l,
                    disableRange: nt,
                    disableStream: T
                });
            }
            return qt.then((Ot)=>{
                if (t.destroyed) throw new Error("Loading aborted");
                if (h.destroyed) throw new Error("Worker was destroyed");
                const hs = new Jt(e, Ot, h.port), hi = new In(hs, t, Te, li, U);
                t._transport = hi, hs.send("Ready", null);
            });
        }).catch(t._capability.reject), t;
    };
    function Sn(c) {
        if (c instanceof URL) return c.href;
        if (typeof c == "string") {
            if (at) return c;
            const t = URL.parse(c, window.location);
            if (t) return t.href;
        }
        throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
    }
    function En(c) {
        if (at && typeof Buffer < "u" && c instanceof Buffer) throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
        if (c instanceof Uint8Array && c.byteLength === c.buffer.byteLength) return c;
        if (typeof c == "string") return se(c);
        if (c instanceof ArrayBuffer || ArrayBuffer.isView(c) || typeof c == "object" && !isNaN(c?.length)) return new Uint8Array(c);
        throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
    }
    function fe(c) {
        if (typeof c != "string") return null;
        if (c.endsWith("/")) return c;
        throw new Error(`Invalid factory url: "${c}" must include trailing slash.`);
    }
    let Ge, Cn;
    Ge = (c)=>typeof c == "object" && Number.isInteger(c?.num) && c.num >= 0 && Number.isInteger(c?.gen) && c.gen >= 0;
    Cn = (c)=>typeof c == "object" && typeof c?.name == "string";
    xn = _i.bind(null, Ge, Cn);
    class is {
        static #t = 0;
        _capability = Promise.withResolvers();
        _transport = null;
        _worker = null;
        docId = `d${is.#t++}`;
        destroyed = !1;
        onPassword = null;
        onProgress = null;
        get promise() {
            return this._capability.promise;
        }
        async destroy() {
            this.destroyed = !0;
            try {
                this._worker?.port && (this._worker._pendingDestroy = !0), await this._transport?.destroy();
            } catch (t) {
                throw this._worker?.port && delete this._worker._pendingDestroy, t;
            }
            this._transport = null, this._worker?.destroy(), this._worker = null;
        }
        async getData() {
            return this._transport.getData();
        }
    }
    Qs = class {
        constructor(t, e, s = !1, i = null){
            this.length = t, this.initialData = e, this.progressiveDone = s, this.contentDispositionFilename = i, this._rangeListeners = [], this._progressListeners = [], this._progressiveReadListeners = [], this._progressiveDoneListeners = [], this._readyCapability = Promise.withResolvers();
        }
        addRangeListener(t) {
            this._rangeListeners.push(t);
        }
        addProgressListener(t) {
            this._progressListeners.push(t);
        }
        addProgressiveReadListener(t) {
            this._progressiveReadListeners.push(t);
        }
        addProgressiveDoneListener(t) {
            this._progressiveDoneListeners.push(t);
        }
        onDataRange(t, e) {
            for (const s of this._rangeListeners)s(t, e);
        }
        onDataProgress(t, e) {
            this._readyCapability.promise.then(()=>{
                for (const s of this._progressListeners)s(t, e);
            });
        }
        onDataProgressiveRead(t) {
            this._readyCapability.promise.then(()=>{
                for (const e of this._progressiveReadListeners)e(t);
            });
        }
        onDataProgressiveDone() {
            this._readyCapability.promise.then(()=>{
                for (const t of this._progressiveDoneListeners)t();
            });
        }
        transportReady() {
            this._readyCapability.resolve();
        }
        requestDataRange(t, e) {
            $("Abstract method PDFDataRangeTransport.requestDataRange");
        }
        abort() {}
    };
    class Tn {
        constructor(t, e){
            this._pdfInfo = t, this._transport = e;
        }
        get annotationStorage() {
            return this._transport.annotationStorage;
        }
        get canvasFactory() {
            return this._transport.canvasFactory;
        }
        get filterFactory() {
            return this._transport.filterFactory;
        }
        get numPages() {
            return this._pdfInfo.numPages;
        }
        get fingerprints() {
            return this._pdfInfo.fingerprints;
        }
        get isPureXfa() {
            return N(this, "isPureXfa", !!this._transport._htmlForXfa);
        }
        get allXfaHtml() {
            return this._transport._htmlForXfa;
        }
        getPage(t) {
            return this._transport.getPage(t);
        }
        getPageIndex(t) {
            return this._transport.getPageIndex(t);
        }
        getDestinations() {
            return this._transport.getDestinations();
        }
        getDestination(t) {
            return this._transport.getDestination(t);
        }
        getPageLabels() {
            return this._transport.getPageLabels();
        }
        getPageLayout() {
            return this._transport.getPageLayout();
        }
        getPageMode() {
            return this._transport.getPageMode();
        }
        getViewerPreferences() {
            return this._transport.getViewerPreferences();
        }
        getOpenAction() {
            return this._transport.getOpenAction();
        }
        getAttachments() {
            return this._transport.getAttachments();
        }
        getJSActions() {
            return this._transport.getDocJSActions();
        }
        getOutline() {
            return this._transport.getOutline();
        }
        getOptionalContentConfig({ intent: t = "display" } = {}) {
            const { renderingIntent: e } = this._transport.getRenderingIntent(t);
            return this._transport.getOptionalContentConfig(e);
        }
        getPermissions() {
            return this._transport.getPermissions();
        }
        getMetadata() {
            return this._transport.getMetadata();
        }
        getMarkInfo() {
            return this._transport.getMarkInfo();
        }
        getData() {
            return this._transport.getData();
        }
        saveDocument() {
            return this._transport.saveDocument();
        }
        getDownloadInfo() {
            return this._transport.downloadInfoCapability.promise;
        }
        cleanup(t = !1) {
            return this._transport.startCleanup(t || this.isPureXfa);
        }
        destroy() {
            return this.loadingTask.destroy();
        }
        cachedPageNumber(t) {
            return this._transport.cachedPageNumber(t);
        }
        get loadingParams() {
            return this._transport.loadingParams;
        }
        get loadingTask() {
            return this._transport.loadingTask;
        }
        getFieldObjects() {
            return this._transport.getFieldObjects();
        }
        hasJSActions() {
            return this._transport.hasJSActions();
        }
        getCalculationOrderIds() {
            return this._transport.getCalculationOrderIds();
        }
    }
    class Pn {
        #t = !1;
        constructor(t, e, s, i = !1){
            this._pageIndex = t, this._pageInfo = e, this._transport = s, this._stats = i ? new us : null, this._pdfBug = i, this.commonObjs = s.commonObjs, this.objs = new Js, this._intentStates = new Map, this.destroyed = !1;
        }
        get pageNumber() {
            return this._pageIndex + 1;
        }
        get rotate() {
            return this._pageInfo.rotate;
        }
        get ref() {
            return this._pageInfo.ref;
        }
        get userUnit() {
            return this._pageInfo.userUnit;
        }
        get view() {
            return this._pageInfo.view;
        }
        getViewport({ scale: t, rotation: e = this.rotate, offsetX: s = 0, offsetY: i = 0, dontFlip: n = !1 } = {}) {
            return new ne({
                viewBox: this.view,
                userUnit: this.userUnit,
                scale: t,
                rotation: e,
                offsetX: s,
                offsetY: i,
                dontFlip: n
            });
        }
        getAnnotations({ intent: t = "display" } = {}) {
            const { renderingIntent: e } = this._transport.getRenderingIntent(t);
            return this._transport.getAnnotations(this._pageIndex, e);
        }
        getJSActions() {
            return this._transport.getPageJSActions(this._pageIndex);
        }
        get filterFactory() {
            return this._transport.filterFactory;
        }
        get isPureXfa() {
            return N(this, "isPureXfa", !!this._transport._htmlForXfa);
        }
        async getXfa() {
            return this._transport._htmlForXfa?.children[this._pageIndex] || null;
        }
        render({ canvasContext: t, viewport: e, intent: s = "display", annotationMode: i = Tt.ENABLE, transform: n = null, background: r = null, optionalContentConfigPromise: a = null, annotationCanvasMap: o = null, pageColors: l = null, printAnnotationStorage: h = null, isEditing: d = !1 }) {
            this._stats?.time("Overall");
            const u = this._transport.getRenderingIntent(s, i, h, d), { renderingIntent: f, cacheKey: g } = u;
            this.#t = !1, a ||= this._transport.getOptionalContentConfig(f);
            let p = this._intentStates.get(g);
            p || (p = Object.create(null), this._intentStates.set(g, p)), p.streamReaderCancelTimeout && (clearTimeout(p.streamReaderCancelTimeout), p.streamReaderCancelTimeout = null);
            const m = !!(f & ct.PRINT);
            p.displayReadyCapability || (p.displayReadyCapability = Promise.withResolvers(), p.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
            }, this._stats?.time("Page Request"), this._pumpOperatorList(u));
            const b = (v)=>{
                p.renderTasks.delete(y), m && (this.#t = !0), this.#e(), v ? (y.capability.reject(v), this._abortOperatorList({
                    intentState: p,
                    reason: v instanceof Error ? v : new Error(v)
                })) : y.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), globalThis.Stats?.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
            }, y = new Ut({
                callback: b,
                params: {
                    canvasContext: t,
                    viewport: e,
                    transform: n,
                    background: r
                },
                objs: this.objs,
                commonObjs: this.commonObjs,
                annotationCanvasMap: o,
                operatorList: p.operatorList,
                pageIndex: this._pageIndex,
                canvasFactory: this._transport.canvasFactory,
                filterFactory: this._transport.filterFactory,
                useRequestAnimationFrame: !m,
                pdfBug: this._pdfBug,
                pageColors: l
            });
            (p.renderTasks ||= new Set).add(y);
            const A = y.task;
            return Promise.all([
                p.displayReadyCapability.promise,
                a
            ]).then(([v, w])=>{
                if (this.destroyed) {
                    b();
                    return;
                }
                if (this._stats?.time("Rendering"), !(w.renderingIntent & f)) throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
                y.initializeGraphics({
                    transparency: v,
                    optionalContentConfig: w
                }), y.operatorListChanged();
            }).catch(b), A;
        }
        getOperatorList({ intent: t = "display", annotationMode: e = Tt.ENABLE, printAnnotationStorage: s = null, isEditing: i = !1 } = {}) {
            function n() {
                a.operatorList.lastChunk && (a.opListReadCapability.resolve(a.operatorList), a.renderTasks.delete(o));
            }
            const r = this._transport.getRenderingIntent(t, e, s, i, !0);
            let a = this._intentStates.get(r.cacheKey);
            a || (a = Object.create(null), this._intentStates.set(r.cacheKey, a));
            let o;
            return a.opListReadCapability || (o = Object.create(null), o.operatorListChanged = n, a.opListReadCapability = Promise.withResolvers(), (a.renderTasks ||= new Set).add(o), a.operatorList = {
                fnArray: [],
                argsArray: [],
                lastChunk: !1,
                separateAnnots: null
            }, this._stats?.time("Page Request"), this._pumpOperatorList(r)), a.opListReadCapability.promise;
        }
        streamTextContent({ includeMarkedContent: t = !1, disableNormalization: e = !1 } = {}) {
            return this._transport.messageHandler.sendWithStream("GetTextContent", {
                pageIndex: this._pageIndex,
                includeMarkedContent: t === !0,
                disableNormalization: e === !0
            }, {
                highWaterMark: 100,
                size (i) {
                    return i.items.length;
                }
            });
        }
        getTextContent(t = {}) {
            if (this._transport._htmlForXfa) return this.getXfa().then((s)=>ee.textContent(s));
            const e = this.streamTextContent(t);
            return new Promise(function(s, i) {
                function n() {
                    r.read().then(function({ value: o, done: l }) {
                        if (l) {
                            s(a);
                            return;
                        }
                        a.lang ??= o.lang, Object.assign(a.styles, o.styles), a.items.push(...o.items), n();
                    }, i);
                }
                const r = e.getReader(), a = {
                    items: [],
                    styles: Object.create(null),
                    lang: null
                };
                n();
            });
        }
        getStructTree() {
            return this._transport.getStructTree(this._pageIndex);
        }
        _destroy() {
            this.destroyed = !0;
            const t = [];
            for (const e of this._intentStates.values())if (this._abortOperatorList({
                intentState: e,
                reason: new Error("Page was destroyed."),
                force: !0
            }), !e.opListReadCapability) for (const s of e.renderTasks)t.push(s.completed), s.cancel();
            return this.objs.clear(), this.#t = !1, Promise.all(t);
        }
        cleanup(t = !1) {
            this.#t = !0;
            const e = this.#e();
            return t && e && (this._stats &&= new us), e;
        }
        #e() {
            if (!this.#t || this.destroyed) return !1;
            for (const { renderTasks: t, operatorList: e } of this._intentStates.values())if (t.size > 0 || !e.lastChunk) return !1;
            return this._intentStates.clear(), this.objs.clear(), this.#t = !1, !0;
        }
        _startRenderPage(t, e) {
            const s = this._intentStates.get(e);
            s && (this._stats?.timeEnd("Page Request"), s.displayReadyCapability?.resolve(t));
        }
        _renderPageChunk(t, e) {
            for(let s = 0, i = t.length; s < i; s++)e.operatorList.fnArray.push(t.fnArray[s]), e.operatorList.argsArray.push(t.argsArray[s]);
            e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
            for (const s of e.renderTasks)s.operatorListChanged();
            t.lastChunk && this.#e();
        }
        _pumpOperatorList({ renderingIntent: t, cacheKey: e, annotationStorageSerializable: s, modifiedIds: i }) {
            const { map: n, transfer: r } = s, o = this._transport.messageHandler.sendWithStream("GetOperatorList", {
                pageIndex: this._pageIndex,
                intent: t,
                cacheKey: e,
                annotationStorage: n,
                modifiedIds: i
            }, r).getReader(), l = this._intentStates.get(e);
            l.streamReader = o;
            const h = ()=>{
                o.read().then(({ value: d, done: u })=>{
                    if (u) {
                        l.streamReader = null;
                        return;
                    }
                    this._transport.destroyed || (this._renderPageChunk(d, l), h());
                }, (d)=>{
                    if (l.streamReader = null, !this._transport.destroyed) {
                        if (l.operatorList) {
                            l.operatorList.lastChunk = !0;
                            for (const u of l.renderTasks)u.operatorListChanged();
                            this.#e();
                        }
                        if (l.displayReadyCapability) l.displayReadyCapability.reject(d);
                        else if (l.opListReadCapability) l.opListReadCapability.reject(d);
                        else throw d;
                    }
                });
            };
            h();
        }
        _abortOperatorList({ intentState: t, reason: e, force: s = !1 }) {
            if (t.streamReader) {
                if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !s) {
                    if (t.renderTasks.size > 0) return;
                    if (e instanceof qe) {
                        let i = vn;
                        e.extraDelay > 0 && e.extraDelay < 1e3 && (i += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(()=>{
                            t.streamReaderCancelTimeout = null, this._abortOperatorList({
                                intentState: t,
                                reason: e,
                                force: !0
                            });
                        }, i);
                        return;
                    }
                }
                if (t.streamReader.cancel(new Pt(e.message)).catch(()=>{}), t.streamReader = null, !this._transport.destroyed) {
                    for (const [i, n] of this._intentStates)if (n === t) {
                        this._intentStates.delete(i);
                        break;
                    }
                    this.cleanup();
                }
            }
        }
        get stats() {
            return this._stats;
        }
    }
    class Rn {
        #t = new Map;
        #e = Promise.resolve();
        postMessage(t, e) {
            const s = {
                data: structuredClone(t, e ? {
                    transfer: e
                } : null)
            };
            this.#e.then(()=>{
                for (const [i] of this.#t)i.call(this, s);
            });
        }
        addEventListener(t, e, s = null) {
            let i = null;
            if (s?.signal instanceof AbortSignal) {
                const { signal: n } = s;
                if (n.aborted) {
                    F("LoopbackPort - cannot use an `aborted` signal.");
                    return;
                }
                const r = ()=>this.removeEventListener(t, e);
                i = ()=>n.removeEventListener("abort", r), n.addEventListener("abort", r);
            }
            this.#t.set(e, i);
        }
        removeEventListener(t, e) {
            this.#t.get(e)?.(), this.#t.delete(e);
        }
        terminate() {
            for (const [, t] of this.#t)t?.();
            this.#t.clear();
        }
    }
    Z = class {
        static #t = 0;
        static #e = !1;
        static #s;
        static{
            at && (this.#e = !0, te.workerSrc ||= "./pdf.worker.mjs"), this._isSameOrigin = (t, e)=>{
                const s = URL.parse(t);
                if (!s?.origin || s.origin === "null") return !1;
                const i = new URL(e, s);
                return s.origin === i.origin;
            }, this._createCDNWrapper = (t)=>{
                const e = `await import("${t}");`;
                return URL.createObjectURL(new Blob([
                    e
                ], {
                    type: "text/javascript"
                }));
            };
        }
        constructor({ name: t = null, port: e = null, verbosity: s = pi() } = {}){
            if (this.name = t, this.destroyed = !1, this.verbosity = s, this._readyCapability = Promise.withResolvers(), this._port = null, this._webWorker = null, this._messageHandler = null, e) {
                if (Z.#s?.has(e)) throw new Error("Cannot use more than one PDFWorker per port.");
                (Z.#s ||= new WeakMap).set(e, this), this._initializeFromPort(e);
                return;
            }
            this._initialize();
        }
        get promise() {
            return this._readyCapability.promise;
        }
        #i() {
            this._readyCapability.resolve(), this._messageHandler.send("configure", {
                verbosity: this.verbosity
            });
        }
        get port() {
            return this._port;
        }
        get messageHandler() {
            return this._messageHandler;
        }
        _initializeFromPort(t) {
            this._port = t, this._messageHandler = new Jt("main", "worker", t), this._messageHandler.on("ready", function() {}), this.#i();
        }
        _initialize() {
            if (Z.#e || Z.#r) {
                this._setupFakeWorker();
                return;
            }
            let { workerSrc: t } = Z;
            try {
                Z._isSameOrigin(window.location, t) || (t = Z._createCDNWrapper(new URL(t, window.location).href));
                const e = new Worker(t, {
                    type: "module"
                }), s = new Jt("main", "worker", e), i = ()=>{
                    n.abort(), s.destroy(), e.terminate(), this.destroyed ? this._readyCapability.reject(new Error("Worker was destroyed")) : this._setupFakeWorker();
                }, n = new AbortController;
                e.addEventListener("error", ()=>{
                    this._webWorker || i();
                }, {
                    signal: n.signal
                }), s.on("test", (a)=>{
                    if (n.abort(), this.destroyed || !a) {
                        i();
                        return;
                    }
                    this._messageHandler = s, this._port = e, this._webWorker = e, this.#i();
                }), s.on("ready", (a)=>{
                    if (n.abort(), this.destroyed) {
                        i();
                        return;
                    }
                    try {
                        r();
                    } catch  {
                        this._setupFakeWorker();
                    }
                });
                const r = ()=>{
                    const a = new Uint8Array;
                    s.send("test", a, [
                        a.buffer
                    ]);
                };
                r();
                return;
            } catch  {
                _e("The worker has been disabled.");
            }
            this._setupFakeWorker();
        }
        _setupFakeWorker() {
            Z.#e || (F("Setting up fake worker."), Z.#e = !0), Z._setupFakeWorkerGlobal.then((t)=>{
                if (this.destroyed) {
                    this._readyCapability.reject(new Error("Worker was destroyed"));
                    return;
                }
                const e = new Rn;
                this._port = e;
                const s = `fake${Z.#t++}`, i = new Jt(s + "_worker", s, e);
                t.setup(i, e), this._messageHandler = new Jt(s, s + "_worker", e), this.#i();
            }).catch((t)=>{
                this._readyCapability.reject(new Error(`Setting up fake worker failed: "${t.message}".`));
            });
        }
        destroy() {
            this.destroyed = !0, this._webWorker?.terminate(), this._webWorker = null, Z.#s?.delete(this._port), this._port = null, this._messageHandler?.destroy(), this._messageHandler = null;
        }
        static fromPort(t) {
            if (!t?.port) throw new Error("PDFWorker.fromPort - invalid method signature.");
            const e = this.#s?.get(t.port);
            if (e) {
                if (e._pendingDestroy) throw new Error("PDFWorker.fromPort - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
                return e;
            }
            return new Z(t);
        }
        static get workerSrc() {
            if (te.workerSrc) return te.workerSrc;
            throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
        }
        static get #r() {
            try {
                return globalThis.pdfjsWorker?.WorkerMessageHandler || null;
            } catch  {
                return null;
            }
        }
        static get _setupFakeWorkerGlobal() {
            return N(this, "_setupFakeWorkerGlobal", (async ()=>this.#r ? this.#r : (await import(this.workerSrc).then(async (m)=>{
                    await m.__tla;
                    return m;
                })).WorkerMessageHandler)());
        }
    };
    class In {
        #t = new Map;
        #e = new Map;
        #s = new Map;
        #i = new Map;
        #r = null;
        constructor(t, e, s, i, n){
            this.messageHandler = t, this.loadingTask = e, this.commonObjs = new Js, this.fontLoader = new Mi({
                ownerDocument: i.ownerDocument,
                styleElement: i.styleElement
            }), this.loadingParams = i.loadingParams, this._params = i, this.canvasFactory = n.canvasFactory, this.filterFactory = n.filterFactory, this.cMapReaderFactory = n.cMapReaderFactory, this.standardFontDataFactory = n.standardFontDataFactory, this.wasmFactory = n.wasmFactory, this.destroyed = !1, this.destroyCapability = null, this._networkStream = s, this._fullReader = null, this._lastProgress = null, this.downloadInfoCapability = Promise.withResolvers(), this.setupMessageHandler();
        }
        #n(t, e = null) {
            const s = this.#t.get(t);
            if (s) return s;
            const i = this.messageHandler.sendWithPromise(t, e);
            return this.#t.set(t, i), i;
        }
        get annotationStorage() {
            return N(this, "annotationStorage", new Ze);
        }
        getRenderingIntent(t, e = Tt.ENABLE, s = null, i = !1, n = !1) {
            let r = ct.DISPLAY, a = He;
            switch(t){
                case "any":
                    r = ct.ANY;
                    break;
                case "display":
                    break;
                case "print":
                    r = ct.PRINT;
                    break;
                default:
                    F(`getRenderingIntent - invalid intent: ${t}`);
            }
            const o = r & ct.PRINT && s instanceof Hs ? s : this.annotationStorage;
            switch(e){
                case Tt.DISABLE:
                    r += ct.ANNOTATIONS_DISABLE;
                    break;
                case Tt.ENABLE:
                    break;
                case Tt.ENABLE_FORMS:
                    r += ct.ANNOTATIONS_FORMS;
                    break;
                case Tt.ENABLE_STORAGE:
                    r += ct.ANNOTATIONS_STORAGE, a = o.serializable;
                    break;
                default:
                    F(`getRenderingIntent - invalid annotationMode: ${e}`);
            }
            i && (r += ct.IS_EDITING), n && (r += ct.OPLIST);
            const { ids: l, hash: h } = o.modifiedIds, d = [
                r,
                a.hash,
                h
            ];
            return {
                renderingIntent: r,
                cacheKey: d.join("_"),
                annotationStorageSerializable: a,
                modifiedIds: l
            };
        }
        destroy() {
            if (this.destroyCapability) return this.destroyCapability.promise;
            this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), this.#r?.reject(new Error("Worker was destroyed during onPassword callback"));
            const t = [];
            for (const s of this.#e.values())t.push(s._destroy());
            this.#e.clear(), this.#s.clear(), this.#i.clear(), this.hasOwnProperty("annotationStorage") && this.annotationStorage.resetModified();
            const e = this.messageHandler.sendWithPromise("Terminate", null);
            return t.push(e), Promise.all(t).then(()=>{
                this.commonObjs.clear(), this.fontLoader.clear(), this.#t.clear(), this.filterFactory.destroy(), rt.cleanup(), this._networkStream?.cancelAllRequests(new Pt("Worker was terminated.")), this.messageHandler?.destroy(), this.messageHandler = null, this.destroyCapability.resolve();
            }, this.destroyCapability.reject), this.destroyCapability.promise;
        }
        setupMessageHandler() {
            const { messageHandler: t, loadingTask: e } = this;
            t.on("GetReader", (s, i)=>{
                K(this._networkStream, "GetReader - no `IPDFStream` instance available."), this._fullReader = this._networkStream.getFullReader(), this._fullReader.onProgress = (n)=>{
                    this._lastProgress = {
                        loaded: n.loaded,
                        total: n.total
                    };
                }, i.onPull = ()=>{
                    this._fullReader.read().then(function({ value: n, done: r }) {
                        if (r) {
                            i.close();
                            return;
                        }
                        K(n instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(n), 1, [
                            n
                        ]);
                    }).catch((n)=>{
                        i.error(n);
                    });
                }, i.onCancel = (n)=>{
                    this._fullReader.cancel(n), i.ready.catch((r)=>{
                        if (!this.destroyed) throw r;
                    });
                };
            }), t.on("ReaderHeadersReady", async (s)=>{
                await this._fullReader.headersReady;
                const { isStreamingSupported: i, isRangeSupported: n, contentLength: r } = this._fullReader;
                return (!i || !n) && (this._lastProgress && e.onProgress?.(this._lastProgress), this._fullReader.onProgress = (a)=>{
                    e.onProgress?.({
                        loaded: a.loaded,
                        total: a.total
                    });
                }), {
                    isStreamingSupported: i,
                    isRangeSupported: n,
                    contentLength: r
                };
            }), t.on("GetRangeReader", (s, i)=>{
                K(this._networkStream, "GetRangeReader - no `IPDFStream` instance available.");
                const n = this._networkStream.getRangeReader(s.begin, s.end);
                if (!n) {
                    i.close();
                    return;
                }
                i.onPull = ()=>{
                    n.read().then(function({ value: r, done: a }) {
                        if (a) {
                            i.close();
                            return;
                        }
                        K(r instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(r), 1, [
                            r
                        ]);
                    }).catch((r)=>{
                        i.error(r);
                    });
                }, i.onCancel = (r)=>{
                    n.cancel(r), i.ready.catch((a)=>{
                        if (!this.destroyed) throw a;
                    });
                };
            }), t.on("GetDoc", ({ pdfInfo: s })=>{
                this._numPages = s.numPages, this._htmlForXfa = s.htmlForXfa, delete s.htmlForXfa, e._capability.resolve(new Tn(s, this));
            }), t.on("DocException", (s)=>{
                e._capability.reject(lt(s));
            }), t.on("PasswordRequest", (s)=>{
                this.#r = Promise.withResolvers();
                try {
                    if (!e.onPassword) throw lt(s);
                    const i = (n)=>{
                        n instanceof Error ? this.#r.reject(n) : this.#r.resolve({
                            password: n
                        });
                    };
                    e.onPassword(i, s.code);
                } catch (i) {
                    this.#r.reject(i);
                }
                return this.#r.promise;
            }), t.on("DataLoaded", (s)=>{
                e.onProgress?.({
                    loaded: s.length,
                    total: s.length
                }), this.downloadInfoCapability.resolve(s);
            }), t.on("StartRenderPage", (s)=>{
                if (this.destroyed) return;
                this.#e.get(s.pageIndex)._startRenderPage(s.transparency, s.cacheKey);
            }), t.on("commonobj", ([s, i, n])=>{
                if (this.destroyed || this.commonObjs.has(s)) return null;
                switch(i){
                    case "Font":
                        if ("error" in n) {
                            const l = n.error;
                            F(`Error during font loading: ${l}`), this.commonObjs.resolve(s, l);
                            break;
                        }
                        const r = this._params.pdfBug && globalThis.FontInspector?.enabled ? (l, h)=>globalThis.FontInspector.fontAdded(l, h) : null, a = new Li(n, r);
                        this.fontLoader.bind(a).catch(()=>t.sendWithPromise("FontFallback", {
                                id: s
                            })).finally(()=>{
                            !a.fontExtraProperties && a.data && (a.data = null), this.commonObjs.resolve(s, a);
                        });
                        break;
                    case "CopyLocalImage":
                        const { imageRef: o } = n;
                        K(o, "The imageRef must be defined.");
                        for (const l of this.#e.values())for (const [, h] of l.objs)if (h?.ref === o) return h.dataLen ? (this.commonObjs.resolve(s, structuredClone(h)), h.dataLen) : null;
                        break;
                    case "FontPath":
                    case "Image":
                    case "Pattern":
                        this.commonObjs.resolve(s, n);
                        break;
                    default:
                        throw new Error(`Got unknown common object type ${i}`);
                }
                return null;
            }), t.on("obj", ([s, i, n, r])=>{
                if (this.destroyed) return;
                const a = this.#e.get(i);
                if (!a.objs.has(s)) {
                    if (a._intentStates.size === 0) {
                        r?.bitmap?.close();
                        return;
                    }
                    switch(n){
                        case "Image":
                        case "Pattern":
                            a.objs.resolve(s, r);
                            break;
                        default:
                            throw new Error(`Got unknown object type ${n}`);
                    }
                }
            }), t.on("DocProgress", (s)=>{
                this.destroyed || e.onProgress?.({
                    loaded: s.loaded,
                    total: s.total
                });
            }), t.on("FetchBinaryData", async (s)=>{
                if (this.destroyed) throw new Error("Worker was destroyed.");
                const i = this[s.type];
                if (!i) throw new Error(`${s.type} not initialized, see the \`useWorkerFetch\` parameter.`);
                return i.fetch(s);
            });
        }
        getData() {
            return this.messageHandler.sendWithPromise("GetData", null);
        }
        saveDocument() {
            this.annotationStorage.size <= 0 && F("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
            const { map: t, transfer: e } = this.annotationStorage.serializable;
            return this.messageHandler.sendWithPromise("SaveDocument", {
                isPureXfa: !!this._htmlForXfa,
                numPages: this._numPages,
                annotationStorage: t,
                filename: this._fullReader?.filename ?? null
            }, e).finally(()=>{
                this.annotationStorage.resetModified();
            });
        }
        getPage(t) {
            if (!Number.isInteger(t) || t <= 0 || t > this._numPages) return Promise.reject(new Error("Invalid page request."));
            const e = t - 1, s = this.#s.get(e);
            if (s) return s;
            const i = this.messageHandler.sendWithPromise("GetPage", {
                pageIndex: e
            }).then((n)=>{
                if (this.destroyed) throw new Error("Transport destroyed");
                n.refStr && this.#i.set(n.refStr, t);
                const r = new Pn(e, n, this, this._params.pdfBug);
                return this.#e.set(e, r), r;
            });
            return this.#s.set(e, i), i;
        }
        getPageIndex(t) {
            return Ge(t) ? this.messageHandler.sendWithPromise("GetPageIndex", {
                num: t.num,
                gen: t.gen
            }) : Promise.reject(new Error("Invalid pageIndex request."));
        }
        getAnnotations(t, e) {
            return this.messageHandler.sendWithPromise("GetAnnotations", {
                pageIndex: t,
                intent: e
            });
        }
        getFieldObjects() {
            return this.#n("GetFieldObjects");
        }
        hasJSActions() {
            return this.#n("HasJSActions");
        }
        getCalculationOrderIds() {
            return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
        }
        getDestinations() {
            return this.messageHandler.sendWithPromise("GetDestinations", null);
        }
        getDestination(t) {
            return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
                id: t
            });
        }
        getPageLabels() {
            return this.messageHandler.sendWithPromise("GetPageLabels", null);
        }
        getPageLayout() {
            return this.messageHandler.sendWithPromise("GetPageLayout", null);
        }
        getPageMode() {
            return this.messageHandler.sendWithPromise("GetPageMode", null);
        }
        getViewerPreferences() {
            return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
        }
        getOpenAction() {
            return this.messageHandler.sendWithPromise("GetOpenAction", null);
        }
        getAttachments() {
            return this.messageHandler.sendWithPromise("GetAttachments", null);
        }
        getDocJSActions() {
            return this.#n("GetDocJSActions");
        }
        getPageJSActions(t) {
            return this.messageHandler.sendWithPromise("GetPageJSActions", {
                pageIndex: t
            });
        }
        getStructTree(t) {
            return this.messageHandler.sendWithPromise("GetStructTree", {
                pageIndex: t
            });
        }
        getOutline() {
            return this.messageHandler.sendWithPromise("GetOutline", null);
        }
        getOptionalContentConfig(t) {
            return this.#n("GetOptionalContentConfig").then((e)=>new en(e, t));
        }
        getPermissions() {
            return this.messageHandler.sendWithPromise("GetPermissions", null);
        }
        getMetadata() {
            const t = "GetMetadata", e = this.#t.get(t);
            if (e) return e;
            const s = this.messageHandler.sendWithPromise(t, null).then((i)=>({
                    info: i[0],
                    metadata: i[1] ? new Zi(i[1]) : null,
                    contentDispositionFilename: this._fullReader?.filename ?? null,
                    contentLength: this._fullReader?.contentLength ?? null
                }));
            return this.#t.set(t, s), s;
        }
        getMarkInfo() {
            return this.messageHandler.sendWithPromise("GetMarkInfo", null);
        }
        async startCleanup(t = !1) {
            if (!this.destroyed) {
                await this.messageHandler.sendWithPromise("Cleanup", null);
                for (const e of this.#e.values())if (!e.cleanup()) throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);
                this.commonObjs.clear(), t || this.fontLoader.clear(), this.#t.clear(), this.filterFactory.destroy(!0), rt.cleanup();
            }
        }
        cachedPageNumber(t) {
            if (!Ge(t)) return null;
            const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`;
            return this.#i.get(e) ?? null;
        }
    }
    const Yt = Symbol("INITIAL_DATA");
    class Js {
        #t = Object.create(null);
        #e(t) {
            return this.#t[t] ||= {
                ...Promise.withResolvers(),
                data: Yt
            };
        }
        get(t, e = null) {
            if (e) {
                const i = this.#e(t);
                return i.promise.then(()=>e(i.data)), null;
            }
            const s = this.#t[t];
            if (!s || s.data === Yt) throw new Error(`Requesting object that isn't resolved yet ${t}.`);
            return s.data;
        }
        has(t) {
            const e = this.#t[t];
            return !!e && e.data !== Yt;
        }
        delete(t) {
            const e = this.#t[t];
            return !e || e.data === Yt ? !1 : (delete this.#t[t], !0);
        }
        resolve(t, e = null) {
            const s = this.#e(t);
            s.data = e, s.resolve();
        }
        clear() {
            for(const t in this.#t){
                const { data: e } = this.#t[t];
                e?.bitmap?.close();
            }
            this.#t = Object.create(null);
        }
        *[Symbol.iterator]() {
            for(const t in this.#t){
                const { data: e } = this.#t[t];
                e !== Yt && (yield [
                    t,
                    e
                ]);
            }
        }
    }
    class kn {
        #t = null;
        onContinue = null;
        onError = null;
        constructor(t){
            this.#t = t;
        }
        get promise() {
            return this.#t.capability.promise;
        }
        cancel(t = 0) {
            this.#t.cancel(null, t);
        }
        get separateAnnots() {
            const { separateAnnots: t } = this.#t.operatorList;
            if (!t) return !1;
            const { annotationCanvasMap: e } = this.#t;
            return t.form || t.canvas && e?.size > 0;
        }
    }
    class Ut {
        #t = null;
        static #e = new WeakSet;
        constructor({ callback: t, params: e, objs: s, commonObjs: i, annotationCanvasMap: n, operatorList: r, pageIndex: a, canvasFactory: o, filterFactory: l, useRequestAnimationFrame: h = !1, pdfBug: d = !1, pageColors: u = null }){
            this.callback = t, this.params = e, this.objs = s, this.commonObjs = i, this.annotationCanvasMap = n, this.operatorListIdx = null, this.operatorList = r, this._pageIndex = a, this.canvasFactory = o, this.filterFactory = l, this._pdfBug = d, this.pageColors = u, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = h === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new kn(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvasContext.canvas;
        }
        get completed() {
            return this.capability.promise.catch(function() {});
        }
        initializeGraphics({ transparency: t = !1, optionalContentConfig: e }) {
            if (this.cancelled) return;
            if (this._canvas) {
                if (Ut.#e.has(this._canvas)) throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
                Ut.#e.add(this._canvas);
            }
            this._pdfBug && globalThis.StepperManager?.enabled && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
            const { canvasContext: s, viewport: i, transform: n, background: r } = this.params;
            this.gfx = new jt(s, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
                optionalContentConfig: e
            }, this.annotationCanvasMap, this.pageColors), this.gfx.beginDrawing({
                transform: n,
                viewport: i,
                transparency: t,
                background: r
            }), this.operatorListIdx = 0, this.graphicsReady = !0, this.graphicsReadyCallback?.();
        }
        cancel(t = null, e = 0) {
            this.running = !1, this.cancelled = !0, this.gfx?.endDrawing(), this.#t && (window.cancelAnimationFrame(this.#t), this.#t = null), Ut.#e.delete(this._canvas), t ||= new qe(`Rendering cancelled, page ${this._pageIndex + 1}`, e), this.callback(t), this.task.onError?.(t);
        }
        operatorListChanged() {
            if (!this.graphicsReady) {
                this.graphicsReadyCallback ||= this._continueBound;
                return;
            }
            this.stepper?.updateOperatorList(this.operatorList), !this.running && this._continue();
        }
        _continue() {
            this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
        }
        _scheduleNext() {
            this._useRequestAnimationFrame ? this.#t = window.requestAnimationFrame(()=>{
                this.#t = null, this._nextBound().catch(this._cancelBound);
            }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
        }
        async _next() {
            this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), Ut.#e.delete(this._canvas), this.callback())));
        }
    }
    Mn = "5.2.133";
    Ln = "4f7761353";
    function Rs(c) {
        return Math.floor(Math.max(0, Math.min(1, c)) * 255).toString(16).padStart(2, "0");
    }
    function Kt(c) {
        return Math.max(0, Math.min(255, 255 * c));
    }
    class Is {
        static CMYK_G([t, e, s, i]) {
            return [
                "G",
                1 - Math.min(1, .3 * t + .59 * s + .11 * e + i)
            ];
        }
        static G_CMYK([t]) {
            return [
                "CMYK",
                0,
                0,
                0,
                1 - t
            ];
        }
        static G_RGB([t]) {
            return [
                "RGB",
                t,
                t,
                t
            ];
        }
        static G_rgb([t]) {
            return t = Kt(t), [
                t,
                t,
                t
            ];
        }
        static G_HTML([t]) {
            const e = Rs(t);
            return `#${e}${e}${e}`;
        }
        static RGB_G([t, e, s]) {
            return [
                "G",
                .3 * t + .59 * e + .11 * s
            ];
        }
        static RGB_rgb(t) {
            return t.map(Kt);
        }
        static RGB_HTML(t) {
            return `#${t.map(Rs).join("")}`;
        }
        static T_HTML() {
            return "#00000000";
        }
        static T_rgb() {
            return [
                null
            ];
        }
        static CMYK_RGB([t, e, s, i]) {
            return [
                "RGB",
                1 - Math.min(1, t + i),
                1 - Math.min(1, s + i),
                1 - Math.min(1, e + i)
            ];
        }
        static CMYK_rgb([t, e, s, i]) {
            return [
                Kt(1 - Math.min(1, t + i)),
                Kt(1 - Math.min(1, s + i)),
                Kt(1 - Math.min(1, e + i))
            ];
        }
        static CMYK_HTML(t) {
            const e = this.CMYK_RGB(t).slice(1);
            return this.RGB_HTML(e);
        }
        static RGB_CMYK([t, e, s]) {
            const i = 1 - t, n = 1 - e, r = 1 - s, a = Math.min(i, n, r);
            return [
                "CMYK",
                i,
                n,
                r,
                a
            ];
        }
    }
    class Dn {
        create(t, e, s = !1) {
            if (t <= 0 || e <= 0) throw new Error("Invalid SVG dimensions");
            const i = this._createSVG("svg:svg");
            return i.setAttribute("version", "1.1"), s || (i.setAttribute("width", `${t}px`), i.setAttribute("height", `${e}px`)), i.setAttribute("preserveAspectRatio", "none"), i.setAttribute("viewBox", `0 0 ${t} ${e}`), i;
        }
        createElement(t) {
            if (typeof t != "string") throw new Error("Invalid SVG element type");
            return this._createSVG(t);
        }
        _createSVG(t) {
            $("Abstract method `_createSVG` called.");
        }
    }
    ye = class extends Dn {
        _createSVG(t) {
            return document.createElementNS(_t, t);
        }
    };
    Zs = class {
        static setupStorage(t, e, s, i, n) {
            const r = i.getValue(e, {
                value: null
            });
            switch(s.name){
                case "textarea":
                    if (r.value !== null && (t.textContent = r.value), n === "print") break;
                    t.addEventListener("input", (a)=>{
                        i.setValue(e, {
                            value: a.target.value
                        });
                    });
                    break;
                case "input":
                    if (s.attributes.type === "radio" || s.attributes.type === "checkbox") {
                        if (r.value === s.attributes.xfaOn ? t.setAttribute("checked", !0) : r.value === s.attributes.xfaOff && t.removeAttribute("checked"), n === "print") break;
                        t.addEventListener("change", (a)=>{
                            i.setValue(e, {
                                value: a.target.checked ? a.target.getAttribute("xfaOn") : a.target.getAttribute("xfaOff")
                            });
                        });
                    } else {
                        if (r.value !== null && t.setAttribute("value", r.value), n === "print") break;
                        t.addEventListener("input", (a)=>{
                            i.setValue(e, {
                                value: a.target.value
                            });
                        });
                    }
                    break;
                case "select":
                    if (r.value !== null) {
                        t.setAttribute("value", r.value);
                        for (const a of s.children)a.attributes.value === r.value ? a.attributes.selected = !0 : a.attributes.hasOwnProperty("selected") && delete a.attributes.selected;
                    }
                    t.addEventListener("input", (a)=>{
                        const o = a.target.options, l = o.selectedIndex === -1 ? "" : o[o.selectedIndex].value;
                        i.setValue(e, {
                            value: l
                        });
                    });
                    break;
            }
        }
        static setAttributes({ html: t, element: e, storage: s = null, intent: i, linkService: n }) {
            const { attributes: r } = e, a = t instanceof HTMLAnchorElement;
            r.type === "radio" && (r.name = `${r.name}-${i}`);
            for (const [o, l] of Object.entries(r))if (l != null) switch(o){
                case "class":
                    l.length && t.setAttribute(o, l.join(" "));
                    break;
                case "dataId":
                    break;
                case "id":
                    t.setAttribute("data-element-id", l);
                    break;
                case "style":
                    Object.assign(t.style, l);
                    break;
                case "textContent":
                    t.textContent = l;
                    break;
                default:
                    (!a || o !== "href" && o !== "newWindow") && t.setAttribute(o, l);
            }
            a && n.addLinkAttributes(t, r.href, r.newWindow), s && r.dataId && this.setupStorage(t, r.dataId, e, s);
        }
        static render(t) {
            const e = t.annotationStorage, s = t.linkService, i = t.xfaHtml, n = t.intent || "display", r = document.createElement(i.name);
            i.attributes && this.setAttributes({
                html: r,
                element: i,
                intent: n,
                linkService: s
            });
            const a = n !== "richText", o = t.div;
            if (o.append(r), t.viewport) {
                const d = `matrix(${t.viewport.transform.join(",")})`;
                o.style.transform = d;
            }
            a && o.setAttribute("class", "xfaLayer xfaFont");
            const l = [];
            if (i.children.length === 0) {
                if (i.value) {
                    const d = document.createTextNode(i.value);
                    r.append(d), a && ee.shouldBuildText(i.name) && l.push(d);
                }
                return {
                    textDivs: l
                };
            }
            const h = [
                [
                    i,
                    -1,
                    r
                ]
            ];
            for(; h.length > 0;){
                const [d, u, f] = h.at(-1);
                if (u + 1 === d.children.length) {
                    h.pop();
                    continue;
                }
                const g = d.children[++h.at(-1)[1]];
                if (g === null) continue;
                const { name: p } = g;
                if (p === "#text") {
                    const b = document.createTextNode(g.value);
                    l.push(b), f.append(b);
                    continue;
                }
                const m = g?.attributes?.xmlns ? document.createElementNS(g.attributes.xmlns, p) : document.createElement(p);
                if (f.append(m), g.attributes && this.setAttributes({
                    html: m,
                    element: g,
                    storage: e,
                    intent: n,
                    linkService: s
                }), g.children?.length > 0) h.push([
                    g,
                    -1,
                    m
                ]);
                else if (g.value) {
                    const b = document.createTextNode(g.value);
                    a && ee.shouldBuildText(p) && l.push(b), m.append(b);
                }
            }
            for (const d of o.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))d.setAttribute("readOnly", !0);
            return {
                textDivs: l
            };
        }
        static update(t) {
            const e = `matrix(${t.viewport.transform.join(",")})`;
            t.div.style.transform = e, t.div.hidden = !1;
        }
    };
    const oe = 1e3, Fn = 9, Lt = new WeakSet;
    class ks {
        static create(t) {
            switch(t.data.annotationType){
                case X.LINK:
                    return new ti(t);
                case X.TEXT:
                    return new Nn(t);
                case X.WIDGET:
                    switch(t.data.fieldType){
                        case "Tx":
                            return new On(t);
                        case "Btn":
                            return t.data.radioButton ? new ei(t) : t.data.checkBox ? new Hn(t) : new $n(t);
                        case "Ch":
                            return new Gn(t);
                        case "Sig":
                            return new Bn(t);
                    }
                    return new Ft(t);
                case X.POPUP:
                    return new ze(t);
                case X.FREETEXT:
                    return new si(t);
                case X.LINE:
                    return new Un(t);
                case X.SQUARE:
                    return new jn(t);
                case X.CIRCLE:
                    return new Vn(t);
                case X.POLYLINE:
                    return new ii(t);
                case X.CARET:
                    return new qn(t);
                case X.INK:
                    return new ns(t);
                case X.POLYGON:
                    return new Wn(t);
                case X.HIGHLIGHT:
                    return new ni(t);
                case X.UNDERLINE:
                    return new Xn(t);
                case X.SQUIGGLY:
                    return new Yn(t);
                case X.STRIKEOUT:
                    return new Kn(t);
                case X.STAMP:
                    return new ri(t);
                case X.FILEATTACHMENT:
                    return new Qn(t);
                default:
                    return new W(t);
            }
        }
    }
    class W {
        #t = null;
        #e = !1;
        #s = null;
        constructor(t, { isRenderable: e = !1, ignoreBorder: s = !1, createQuadrilaterals: i = !1 } = {}){
            this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.svgFactory = t.svgFactory, this.annotationStorage = t.annotationStorage, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, e && (this.container = this._createContainer(s)), i && this._createQuadrilaterals();
        }
        static _hasPopupData({ titleObj: t, contentsObj: e, richText: s }) {
            return !!(t?.str || e?.str || s?.str);
        }
        get _isEditable() {
            return this.data.isEditable;
        }
        get hasPopupData() {
            return W._hasPopupData(this.data);
        }
        updateEdited(t) {
            if (!this.container) return;
            this.#t ||= {
                rect: this.data.rect.slice(0)
            };
            const { rect: e } = t;
            e && this.#i(e), this.#s?.popup.updateEdited(t);
        }
        resetEdited() {
            this.#t && (this.#i(this.#t.rect), this.#s?.popup.resetEdited(), this.#t = null);
        }
        #i(t) {
            const { container: { style: e }, data: { rect: s, rotation: i }, parent: { viewport: { rawDims: { pageWidth: n, pageHeight: r, pageX: a, pageY: o } } } } = this;
            s?.splice(0, 4, ...t), e.left = `${100 * (t[0] - a) / n}%`, e.top = `${100 * (r - t[3] + o) / r}%`, i === 0 ? (e.width = `${100 * (t[2] - t[0]) / n}%`, e.height = `${100 * (t[3] - t[1]) / r}%`) : this.setRotation(i);
        }
        _createContainer(t) {
            const { data: e, parent: { page: s, viewport: i } } = this, n = document.createElement("section");
            n.setAttribute("data-annotation-id", e.id), this instanceof Ft || (n.tabIndex = oe);
            const { style: r } = n;
            if (r.zIndex = this.parent.zIndex++, e.alternativeText && (n.title = e.alternativeText), e.noRotate && n.classList.add("norotate"), !e.rect || this instanceof ze) {
                const { rotation: p } = e;
                return !e.hasOwnCanvas && p !== 0 && this.setRotation(p, n), n;
            }
            const { width: a, height: o } = this;
            if (!t && e.borderStyle.width > 0) {
                r.borderWidth = `${e.borderStyle.width}px`;
                const p = e.borderStyle.horizontalCornerRadius, m = e.borderStyle.verticalCornerRadius;
                if (p > 0 || m > 0) {
                    const y = `calc(${p}px * var(--total-scale-factor)) / calc(${m}px * var(--total-scale-factor))`;
                    r.borderRadius = y;
                } else if (this instanceof ei) {
                    const y = `calc(${a}px * var(--total-scale-factor)) / calc(${o}px * var(--total-scale-factor))`;
                    r.borderRadius = y;
                }
                switch(e.borderStyle.style){
                    case Bt.SOLID:
                        r.borderStyle = "solid";
                        break;
                    case Bt.DASHED:
                        r.borderStyle = "dashed";
                        break;
                    case Bt.BEVELED:
                        F("Unimplemented border style: beveled");
                        break;
                    case Bt.INSET:
                        F("Unimplemented border style: inset");
                        break;
                    case Bt.UNDERLINE:
                        r.borderBottomStyle = "solid";
                        break;
                }
                const b = e.borderColor || null;
                b ? (this.#e = !0, r.borderColor = P.makeHexColor(b[0] | 0, b[1] | 0, b[2] | 0)) : r.borderWidth = 0;
            }
            const l = P.normalizeRect([
                e.rect[0],
                s.view[3] - e.rect[1] + s.view[1],
                e.rect[2],
                s.view[3] - e.rect[3] + s.view[1]
            ]), { pageWidth: h, pageHeight: d, pageX: u, pageY: f } = i.rawDims;
            r.left = `${100 * (l[0] - u) / h}%`, r.top = `${100 * (l[1] - f) / d}%`;
            const { rotation: g } = e;
            return e.hasOwnCanvas || g === 0 ? (r.width = `${100 * a / h}%`, r.height = `${100 * o / d}%`) : this.setRotation(g, n), n;
        }
        setRotation(t, e = this.container) {
            if (!this.data.rect) return;
            const { pageWidth: s, pageHeight: i } = this.parent.viewport.rawDims;
            let { width: n, height: r } = this;
            t % 180 !== 0 && ([n, r] = [
                r,
                n
            ]), e.style.width = `${100 * n / s}%`, e.style.height = `${100 * r / i}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
        }
        get _commonActions() {
            const t = (e, s, i)=>{
                const n = i.detail[e], r = n[0], a = n.slice(1);
                i.target.style[s] = Is[`${r}_HTML`](a), this.annotationStorage.setValue(this.data.id, {
                    [s]: Is[`${r}_rgb`](a)
                });
            };
            return N(this, "_commonActions", {
                display: (e)=>{
                    const { display: s } = e.detail, i = s % 2 === 1;
                    this.container.style.visibility = i ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                        noView: i,
                        noPrint: s === 1 || s === 2
                    });
                },
                print: (e)=>{
                    this.annotationStorage.setValue(this.data.id, {
                        noPrint: !e.detail.print
                    });
                },
                hidden: (e)=>{
                    const { hidden: s } = e.detail;
                    this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
                        noPrint: s,
                        noView: s
                    });
                },
                focus: (e)=>{
                    setTimeout(()=>e.target.focus({
                            preventScroll: !1
                        }), 0);
                },
                userName: (e)=>{
                    e.target.title = e.detail.userName;
                },
                readonly: (e)=>{
                    e.target.disabled = e.detail.readonly;
                },
                required: (e)=>{
                    this._setRequired(e.target, e.detail.required);
                },
                bgColor: (e)=>{
                    t("bgColor", "backgroundColor", e);
                },
                fillColor: (e)=>{
                    t("fillColor", "backgroundColor", e);
                },
                fgColor: (e)=>{
                    t("fgColor", "color", e);
                },
                textColor: (e)=>{
                    t("textColor", "color", e);
                },
                borderColor: (e)=>{
                    t("borderColor", "borderColor", e);
                },
                strokeColor: (e)=>{
                    t("strokeColor", "borderColor", e);
                },
                rotation: (e)=>{
                    const s = e.detail.rotation;
                    this.setRotation(s), this.annotationStorage.setValue(this.data.id, {
                        rotation: s
                    });
                }
            });
        }
        _dispatchEventFromSandbox(t, e) {
            const s = this._commonActions;
            for (const i of Object.keys(e.detail))(t[i] || s[i])?.(e);
        }
        _setDefaultPropertiesFromJS(t) {
            if (!this.enableScripting) return;
            const e = this.annotationStorage.getRawValue(this.data.id);
            if (!e) return;
            const s = this._commonActions;
            for (const [i, n] of Object.entries(e)){
                const r = s[i];
                if (r) {
                    const a = {
                        detail: {
                            [i]: n
                        },
                        target: t
                    };
                    r(a), delete e[i];
                }
            }
        }
        _createQuadrilaterals() {
            if (!this.container) return;
            const { quadPoints: t } = this.data;
            if (!t) return;
            const [e, s, i, n] = this.data.rect.map((p)=>Math.fround(p));
            if (t.length === 8) {
                const [p, m, b, y] = t.subarray(2, 6);
                if (i === p && n === m && e === b && s === y) return;
            }
            const { style: r } = this.container;
            let a;
            if (this.#e) {
                const { borderColor: p, borderWidth: m } = r;
                r.borderWidth = 0, a = [
                    "url('data:image/svg+xml;utf8,",
                    '<svg xmlns="http://www.w3.org/2000/svg"',
                    ' preserveAspectRatio="none" viewBox="0 0 1 1">',
                    `<g fill="transparent" stroke="${p}" stroke-width="${m}">`
                ], this.container.classList.add("hasBorder");
            }
            const o = i - e, l = n - s, { svgFactory: h } = this, d = h.createElement("svg");
            d.classList.add("quadrilateralsContainer"), d.setAttribute("width", 0), d.setAttribute("height", 0);
            const u = h.createElement("defs");
            d.append(u);
            const f = h.createElement("clipPath"), g = `clippath_${this.data.id}`;
            f.setAttribute("id", g), f.setAttribute("clipPathUnits", "objectBoundingBox"), u.append(f);
            for(let p = 2, m = t.length; p < m; p += 8){
                const b = t[p], y = t[p + 1], A = t[p + 2], v = t[p + 3], w = h.createElement("rect"), _ = (A - e) / o, S = (n - y) / l, E = (b - A) / o, C = (y - v) / l;
                w.setAttribute("x", _), w.setAttribute("y", S), w.setAttribute("width", E), w.setAttribute("height", C), f.append(w), a?.push(`<rect vector-effect="non-scaling-stroke" x="${_}" y="${S}" width="${E}" height="${C}"/>`);
            }
            this.#e && (a.push("</g></svg>')"), r.backgroundImage = a.join("")), this.container.append(d), this.container.style.clipPath = `url(#${g})`;
        }
        _createPopup() {
            const { data: t } = this, e = this.#s = new ze({
                data: {
                    color: t.color,
                    titleObj: t.titleObj,
                    modificationDate: t.modificationDate,
                    contentsObj: t.contentsObj,
                    richText: t.richText,
                    parentRect: t.rect,
                    borderStyle: 0,
                    id: `popup_${t.id}`,
                    rotation: t.rotation
                },
                parent: this.parent,
                elements: [
                    this
                ]
            });
            this.parent.div.append(e.render());
        }
        render() {
            $("Abstract method `AnnotationElement.render` called");
        }
        _getElementsByName(t, e = null) {
            const s = [];
            if (this._fieldObjects) {
                const i = this._fieldObjects[t];
                if (i) for (const { page: n, id: r, exportValues: a } of i){
                    if (n === -1 || r === e) continue;
                    const o = typeof a == "string" ? a : null, l = document.querySelector(`[data-element-id="${r}"]`);
                    if (l && !Lt.has(l)) {
                        F(`_getElementsByName - element not allowed: ${r}`);
                        continue;
                    }
                    s.push({
                        id: r,
                        exportValue: o,
                        domElement: l
                    });
                }
                return s;
            }
            for (const i of document.getElementsByName(t)){
                const { exportValue: n } = i, r = i.getAttribute("data-element-id");
                r !== e && Lt.has(i) && s.push({
                    id: r,
                    exportValue: n,
                    domElement: i
                });
            }
            return s;
        }
        show() {
            this.container && (this.container.hidden = !1), this.popup?.maybeShow();
        }
        hide() {
            this.container && (this.container.hidden = !0), this.popup?.forceHide();
        }
        getElementsToTriggerPopup() {
            return this.container;
        }
        addHighlightArea() {
            const t = this.getElementsToTriggerPopup();
            if (Array.isArray(t)) for (const e of t)e.classList.add("highlightArea");
            else t.classList.add("highlightArea");
        }
        _editOnDoubleClick() {
            if (!this._isEditable) return;
            const { annotationEditorType: t, data: { id: e } } = this;
            this.container.addEventListener("dblclick", ()=>{
                this.linkService.eventBus?.dispatch("switchannotationeditormode", {
                    source: this,
                    mode: t,
                    editId: e
                });
            });
        }
        get width() {
            return this.data.rect[2] - this.data.rect[0];
        }
        get height() {
            return this.data.rect[3] - this.data.rect[1];
        }
    }
    class ti extends W {
        constructor(t, e = null){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !!e?.ignoreBorder,
                createQuadrilaterals: !0
            }), this.isTooltipOnly = t.data.isTooltipOnly;
        }
        render() {
            const { data: t, linkService: e } = this, s = document.createElement("a");
            s.setAttribute("data-element-id", t.id);
            let i = !1;
            return t.url ? (e.addLinkAttributes(s, t.url, t.newWindow), i = !0) : t.action ? (this._bindNamedAction(s, t.action), i = !0) : t.attachment ? (this.#e(s, t.attachment, t.attachmentDest), i = !0) : t.setOCGState ? (this.#s(s, t.setOCGState), i = !0) : t.dest ? (this._bindLink(s, t.dest), i = !0) : (t.actions && (t.actions.Action || t.actions["Mouse Up"] || t.actions["Mouse Down"]) && this.enableScripting && this.hasJSActions && (this._bindJSAction(s, t), i = !0), t.resetForm ? (this._bindResetFormAction(s, t.resetForm), i = !0) : this.isTooltipOnly && !i && (this._bindLink(s, ""), i = !0)), this.container.classList.add("linkAnnotation"), i && this.container.append(s), this.container;
        }
        #t() {
            this.container.setAttribute("data-internal-link", "");
        }
        _bindLink(t, e) {
            t.href = this.linkService.getDestinationHash(e), t.onclick = ()=>(e && this.linkService.goToDestination(e), !1), (e || e === "") && this.#t();
        }
        _bindNamedAction(t, e) {
            t.href = this.linkService.getAnchorUrl(""), t.onclick = ()=>(this.linkService.executeNamedAction(e), !1), this.#t();
        }
        #e(t, e, s = null) {
            t.href = this.linkService.getAnchorUrl(""), e.description && (t.title = e.description), t.onclick = ()=>(this.downloadManager?.openOrDownloadData(e.content, e.filename, s), !1), this.#t();
        }
        #s(t, e) {
            t.href = this.linkService.getAnchorUrl(""), t.onclick = ()=>(this.linkService.executeSetOCGState(e), !1), this.#t();
        }
        _bindJSAction(t, e) {
            t.href = this.linkService.getAnchorUrl("");
            const s = new Map([
                [
                    "Action",
                    "onclick"
                ],
                [
                    "Mouse Up",
                    "onmouseup"
                ],
                [
                    "Mouse Down",
                    "onmousedown"
                ]
            ]);
            for (const i of Object.keys(e.actions)){
                const n = s.get(i);
                n && (t[n] = ()=>(this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                        source: this,
                        detail: {
                            id: e.id,
                            name: i
                        }
                    }), !1));
            }
            t.onclick || (t.onclick = ()=>!1), this.#t();
        }
        _bindResetFormAction(t, e) {
            const s = t.onclick;
            if (s || (t.href = this.linkService.getAnchorUrl("")), this.#t(), !this._fieldObjects) {
                F('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), s || (t.onclick = ()=>!1);
                return;
            }
            t.onclick = ()=>{
                s?.();
                const { fields: i, refs: n, include: r } = e, a = [];
                if (i.length !== 0 || n.length !== 0) {
                    const h = new Set(n);
                    for (const d of i){
                        const u = this._fieldObjects[d] || [];
                        for (const { id: f } of u)h.add(f);
                    }
                    for (const d of Object.values(this._fieldObjects))for (const u of d)h.has(u.id) === r && a.push(u);
                } else for (const h of Object.values(this._fieldObjects))a.push(...h);
                const o = this.annotationStorage, l = [];
                for (const h of a){
                    const { id: d } = h;
                    switch(l.push(d), h.type){
                        case "text":
                            {
                                const f = h.defaultValue || "";
                                o.setValue(d, {
                                    value: f
                                });
                                break;
                            }
                        case "checkbox":
                        case "radiobutton":
                            {
                                const f = h.defaultValue === h.exportValues;
                                o.setValue(d, {
                                    value: f
                                });
                                break;
                            }
                        case "combobox":
                        case "listbox":
                            {
                                const f = h.defaultValue || "";
                                o.setValue(d, {
                                    value: f
                                });
                                break;
                            }
                        default:
                            continue;
                    }
                    const u = document.querySelector(`[data-element-id="${d}"]`);
                    if (u) {
                        if (!Lt.has(u)) {
                            F(`_bindResetFormAction - element not allowed: ${d}`);
                            continue;
                        }
                    } else continue;
                    u.dispatchEvent(new Event("resetform"));
                }
                return this.enableScripting && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                    source: this,
                    detail: {
                        id: "app",
                        ids: l,
                        name: "ResetForm"
                    }
                }), !1;
            };
        }
    }
    class Nn extends W {
        constructor(t){
            super(t, {
                isRenderable: !0
            });
        }
        render() {
            this.container.classList.add("textAnnotation");
            const t = document.createElement("img");
            return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
                type: this.data.name
            })), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.append(t), this.container;
        }
    }
    class Ft extends W {
        render() {
            return this.container;
        }
        showElementAndHideCanvas(t) {
            this.data.hasOwnCanvas && (t.previousSibling?.nodeName === "CANVAS" && (t.previousSibling.hidden = !0), t.hidden = !1);
        }
        _getKeyModifier(t) {
            return st.platform.isMac ? t.metaKey : t.ctrlKey;
        }
        _setEventListener(t, e, s, i, n) {
            s.includes("mouse") ? t.addEventListener(s, (r)=>{
                this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                    source: this,
                    detail: {
                        id: this.data.id,
                        name: i,
                        value: n(r),
                        shift: r.shiftKey,
                        modifier: this._getKeyModifier(r)
                    }
                });
            }) : t.addEventListener(s, (r)=>{
                if (s === "blur") {
                    if (!e.focused || !r.relatedTarget) return;
                    e.focused = !1;
                } else if (s === "focus") {
                    if (e.focused) return;
                    e.focused = !0;
                }
                n && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                    source: this,
                    detail: {
                        id: this.data.id,
                        name: i,
                        value: n(r)
                    }
                });
            });
        }
        _setEventListeners(t, e, s, i) {
            for (const [n, r] of s)(r === "Action" || this.data.actions?.[r]) && ((r === "Focus" || r === "Blur") && (e ||= {
                focused: !1
            }), this._setEventListener(t, e, n, r, i), r === "Focus" && !this.data.actions?.Blur ? this._setEventListener(t, e, "blur", "Blur", null) : r === "Blur" && !this.data.actions?.Focus && this._setEventListener(t, e, "focus", "Focus", null));
        }
        _setBackgroundColor(t) {
            const e = this.data.backgroundColor || null;
            t.style.backgroundColor = e === null ? "transparent" : P.makeHexColor(e[0], e[1], e[2]);
        }
        _setTextStyle(t) {
            const e = [
                "left",
                "center",
                "right"
            ], { fontColor: s } = this.data.defaultAppearanceData, i = this.data.defaultAppearanceData.fontSize || Fn, n = t.style;
            let r;
            const a = 2, o = (l)=>Math.round(10 * l) / 10;
            if (this.data.multiLine) {
                const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a), h = Math.round(l / (Pe * i)) || 1, d = l / h;
                r = Math.min(i, o(d / Pe));
            } else {
                const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a);
                r = Math.min(i, o(l / Pe));
            }
            n.fontSize = `calc(${r}px * var(--total-scale-factor))`, n.color = P.makeHexColor(s[0], s[1], s[2]), this.data.textAlignment !== null && (n.textAlign = e[this.data.textAlignment]);
        }
        _setRequired(t, e) {
            e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
        }
    }
    class On extends Ft {
        constructor(t){
            const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
            super(t, {
                isRenderable: e
            });
        }
        setPropertyOnSiblings(t, e, s, i) {
            const n = this.annotationStorage;
            for (const r of this._getElementsByName(t.name, t.id))r.domElement && (r.domElement[e] = s), n.setValue(r.id, {
                [i]: s
            });
        }
        render() {
            const t = this.annotationStorage, e = this.data.id;
            this.container.classList.add("textWidgetAnnotation");
            let s = null;
            if (this.renderForms) {
                const i = t.getValue(e, {
                    value: this.data.fieldValue
                });
                let n = i.value || "";
                const r = t.getValue(e, {
                    charLimit: this.data.maxLen
                }).charLimit;
                r && n.length > r && (n = n.slice(0, r));
                let a = i.formattedValue || this.data.textContent?.join(`
`) || null;
                a && this.data.comb && (a = a.replaceAll(/\s+/g, ""));
                const o = {
                    userValue: n,
                    formattedValue: a,
                    lastCommittedValue: null,
                    commitKey: 1,
                    focused: !1
                };
                this.data.multiLine ? (s = document.createElement("textarea"), s.textContent = a ?? n, this.data.doNotScroll && (s.style.overflowY = "hidden")) : (s = document.createElement("input"), s.type = this.data.password ? "password" : "text", s.setAttribute("value", a ?? n), this.data.doNotScroll && (s.style.overflowX = "hidden")), this.data.hasOwnCanvas && (s.hidden = !0), Lt.add(s), s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, s.name = this.data.fieldName, s.tabIndex = oe, this._setRequired(s, this.data.required), r && (s.maxLength = r), s.addEventListener("input", (h)=>{
                    t.setValue(e, {
                        value: h.target.value
                    }), this.setPropertyOnSiblings(s, "value", h.target.value, "value"), o.formattedValue = null;
                }), s.addEventListener("resetform", (h)=>{
                    const d = this.data.defaultFieldValue ?? "";
                    s.value = o.userValue = d, o.formattedValue = null;
                });
                let l = (h)=>{
                    const { formattedValue: d } = o;
                    d != null && (h.target.value = d), h.target.scrollLeft = 0;
                };
                if (this.enableScripting && this.hasJSActions) {
                    s.addEventListener("focus", (d)=>{
                        if (o.focused) return;
                        const { target: u } = d;
                        o.userValue && (u.value = o.userValue), o.lastCommittedValue = u.value, o.commitKey = 1, this.data.actions?.Focus || (o.focused = !0);
                    }), s.addEventListener("updatefromsandbox", (d)=>{
                        this.showElementAndHideCanvas(d.target);
                        const u = {
                            value (f) {
                                o.userValue = f.detail.value ?? "", t.setValue(e, {
                                    value: o.userValue.toString()
                                }), f.target.value = o.userValue;
                            },
                            formattedValue (f) {
                                const { formattedValue: g } = f.detail;
                                o.formattedValue = g, g != null && f.target !== document.activeElement && (f.target.value = g), t.setValue(e, {
                                    formattedValue: g
                                });
                            },
                            selRange (f) {
                                f.target.setSelectionRange(...f.detail.selRange);
                            },
                            charLimit: (f)=>{
                                const { charLimit: g } = f.detail, { target: p } = f;
                                if (g === 0) {
                                    p.removeAttribute("maxLength");
                                    return;
                                }
                                p.setAttribute("maxLength", g);
                                let m = o.userValue;
                                !m || m.length <= g || (m = m.slice(0, g), p.value = o.userValue = m, t.setValue(e, {
                                    value: m
                                }), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                                    source: this,
                                    detail: {
                                        id: e,
                                        name: "Keystroke",
                                        value: m,
                                        willCommit: !0,
                                        commitKey: 1,
                                        selStart: p.selectionStart,
                                        selEnd: p.selectionEnd
                                    }
                                }));
                            }
                        };
                        this._dispatchEventFromSandbox(u, d);
                    }), s.addEventListener("keydown", (d)=>{
                        o.commitKey = 1;
                        let u = -1;
                        if (d.key === "Escape" ? u = 0 : d.key === "Enter" && !this.data.multiLine ? u = 2 : d.key === "Tab" && (o.commitKey = 3), u === -1) return;
                        const { value: f } = d.target;
                        o.lastCommittedValue !== f && (o.lastCommittedValue = f, o.userValue = f, this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                            source: this,
                            detail: {
                                id: e,
                                name: "Keystroke",
                                value: f,
                                willCommit: !0,
                                commitKey: u,
                                selStart: d.target.selectionStart,
                                selEnd: d.target.selectionEnd
                            }
                        }));
                    });
                    const h = l;
                    l = null, s.addEventListener("blur", (d)=>{
                        if (!o.focused || !d.relatedTarget) return;
                        this.data.actions?.Blur || (o.focused = !1);
                        const { value: u } = d.target;
                        o.userValue = u, o.lastCommittedValue !== u && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                            source: this,
                            detail: {
                                id: e,
                                name: "Keystroke",
                                value: u,
                                willCommit: !0,
                                commitKey: o.commitKey,
                                selStart: d.target.selectionStart,
                                selEnd: d.target.selectionEnd
                            }
                        }), h(d);
                    }), this.data.actions?.Keystroke && s.addEventListener("beforeinput", (d)=>{
                        o.lastCommittedValue = null;
                        const { data: u, target: f } = d, { value: g, selectionStart: p, selectionEnd: m } = f;
                        let b = p, y = m;
                        switch(d.inputType){
                            case "deleteWordBackward":
                                {
                                    const A = g.substring(0, p).match(/\w*[^\w]*$/);
                                    A && (b -= A[0].length);
                                    break;
                                }
                            case "deleteWordForward":
                                {
                                    const A = g.substring(p).match(/^[^\w]*\w*/);
                                    A && (y += A[0].length);
                                    break;
                                }
                            case "deleteContentBackward":
                                p === m && (b -= 1);
                                break;
                            case "deleteContentForward":
                                p === m && (y += 1);
                                break;
                        }
                        d.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                            source: this,
                            detail: {
                                id: e,
                                name: "Keystroke",
                                value: g,
                                change: u || "",
                                willCommit: !1,
                                selStart: b,
                                selEnd: y
                            }
                        });
                    }), this._setEventListeners(s, o, [
                        [
                            "focus",
                            "Focus"
                        ],
                        [
                            "blur",
                            "Blur"
                        ],
                        [
                            "mousedown",
                            "Mouse Down"
                        ],
                        [
                            "mouseenter",
                            "Mouse Enter"
                        ],
                        [
                            "mouseleave",
                            "Mouse Exit"
                        ],
                        [
                            "mouseup",
                            "Mouse Up"
                        ]
                    ], (d)=>d.target.value);
                }
                if (l && s.addEventListener("blur", l), this.data.comb) {
                    const d = (this.data.rect[2] - this.data.rect[0]) / r;
                    s.classList.add("comb"), s.style.letterSpacing = `calc(${d}px * var(--total-scale-factor) - 1ch)`;
                }
            } else s = document.createElement("div"), s.textContent = this.data.fieldValue, s.style.verticalAlign = "middle", s.style.display = "table-cell", this.data.hasOwnCanvas && (s.hidden = !0);
            return this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
        }
    }
    class Bn extends Ft {
        constructor(t){
            super(t, {
                isRenderable: !!t.data.hasOwnCanvas
            });
        }
    }
    class Hn extends Ft {
        constructor(t){
            super(t, {
                isRenderable: t.renderForms
            });
        }
        render() {
            const t = this.annotationStorage, e = this.data, s = e.id;
            let i = t.getValue(s, {
                value: e.exportValue === e.fieldValue
            }).value;
            typeof i == "string" && (i = i !== "Off", t.setValue(s, {
                value: i
            })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
            const n = document.createElement("input");
            return Lt.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "checkbox", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.setAttribute("exportValue", e.exportValue), n.tabIndex = oe, n.addEventListener("change", (r)=>{
                const { name: a, checked: o } = r.target;
                for (const l of this._getElementsByName(a, s)){
                    const h = o && l.exportValue === e.exportValue;
                    l.domElement && (l.domElement.checked = h), t.setValue(l.id, {
                        value: h
                    });
                }
                t.setValue(s, {
                    value: o
                });
            }), n.addEventListener("resetform", (r)=>{
                const a = e.defaultFieldValue || "Off";
                r.target.checked = a === e.exportValue;
            }), this.enableScripting && this.hasJSActions && (n.addEventListener("updatefromsandbox", (r)=>{
                const a = {
                    value (o) {
                        o.target.checked = o.detail.value !== "Off", t.setValue(s, {
                            value: o.target.checked
                        });
                    }
                };
                this._dispatchEventFromSandbox(a, r);
            }), this._setEventListeners(n, null, [
                [
                    "change",
                    "Validate"
                ],
                [
                    "change",
                    "Action"
                ],
                [
                    "focus",
                    "Focus"
                ],
                [
                    "blur",
                    "Blur"
                ],
                [
                    "mousedown",
                    "Mouse Down"
                ],
                [
                    "mouseenter",
                    "Mouse Enter"
                ],
                [
                    "mouseleave",
                    "Mouse Exit"
                ],
                [
                    "mouseup",
                    "Mouse Up"
                ]
            ], (r)=>r.target.checked)), this._setBackgroundColor(n), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
        }
    }
    class ei extends Ft {
        constructor(t){
            super(t, {
                isRenderable: t.renderForms
            });
        }
        render() {
            this.container.classList.add("buttonWidgetAnnotation", "radioButton");
            const t = this.annotationStorage, e = this.data, s = e.id;
            let i = t.getValue(s, {
                value: e.fieldValue === e.buttonValue
            }).value;
            if (typeof i == "string" && (i = i !== e.buttonValue, t.setValue(s, {
                value: i
            })), i) for (const r of this._getElementsByName(e.fieldName, s))t.setValue(r.id, {
                value: !1
            });
            const n = document.createElement("input");
            if (Lt.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "radio", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.tabIndex = oe, n.addEventListener("change", (r)=>{
                const { name: a, checked: o } = r.target;
                for (const l of this._getElementsByName(a, s))t.setValue(l.id, {
                    value: !1
                });
                t.setValue(s, {
                    value: o
                });
            }), n.addEventListener("resetform", (r)=>{
                const a = e.defaultFieldValue;
                r.target.checked = a != null && a === e.buttonValue;
            }), this.enableScripting && this.hasJSActions) {
                const r = e.buttonValue;
                n.addEventListener("updatefromsandbox", (a)=>{
                    const o = {
                        value: (l)=>{
                            const h = r === l.detail.value;
                            for (const d of this._getElementsByName(l.target.name)){
                                const u = h && d.id === s;
                                d.domElement && (d.domElement.checked = u), t.setValue(d.id, {
                                    value: u
                                });
                            }
                        }
                    };
                    this._dispatchEventFromSandbox(o, a);
                }), this._setEventListeners(n, null, [
                    [
                        "change",
                        "Validate"
                    ],
                    [
                        "change",
                        "Action"
                    ],
                    [
                        "focus",
                        "Focus"
                    ],
                    [
                        "blur",
                        "Blur"
                    ],
                    [
                        "mousedown",
                        "Mouse Down"
                    ],
                    [
                        "mouseenter",
                        "Mouse Enter"
                    ],
                    [
                        "mouseleave",
                        "Mouse Exit"
                    ],
                    [
                        "mouseup",
                        "Mouse Up"
                    ]
                ], (a)=>a.target.checked);
            }
            return this._setBackgroundColor(n), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
        }
    }
    class $n extends ti {
        constructor(t){
            super(t, {
                ignoreBorder: t.data.hasAppearance
            });
        }
        render() {
            const t = super.render();
            t.classList.add("buttonWidgetAnnotation", "pushButton");
            const e = t.lastChild;
            return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (s)=>{
                this._dispatchEventFromSandbox({}, s);
            })), t;
        }
    }
    class Gn extends Ft {
        constructor(t){
            super(t, {
                isRenderable: t.renderForms
            });
        }
        render() {
            this.container.classList.add("choiceWidgetAnnotation");
            const t = this.annotationStorage, e = this.data.id, s = t.getValue(e, {
                value: this.data.fieldValue
            }), i = document.createElement("select");
            Lt.add(i), i.setAttribute("data-element-id", e), i.disabled = this.data.readOnly, this._setRequired(i, this.data.required), i.name = this.data.fieldName, i.tabIndex = oe;
            let n = this.data.combo && this.data.options.length > 0;
            this.data.combo || (i.size = this.data.options.length, this.data.multiSelect && (i.multiple = !0)), i.addEventListener("resetform", (h)=>{
                const d = this.data.defaultFieldValue;
                for (const u of i.options)u.selected = u.value === d;
            });
            for (const h of this.data.options){
                const d = document.createElement("option");
                d.textContent = h.displayValue, d.value = h.exportValue, s.value.includes(h.exportValue) && (d.setAttribute("selected", !0), n = !1), i.append(d);
            }
            let r = null;
            if (n) {
                const h = document.createElement("option");
                h.value = " ", h.setAttribute("hidden", !0), h.setAttribute("selected", !0), i.prepend(h), r = ()=>{
                    h.remove(), i.removeEventListener("input", r), r = null;
                }, i.addEventListener("input", r);
            }
            const a = (h)=>{
                const d = h ? "value" : "textContent", { options: u, multiple: f } = i;
                return f ? Array.prototype.filter.call(u, (g)=>g.selected).map((g)=>g[d]) : u.selectedIndex === -1 ? null : u[u.selectedIndex][d];
            };
            let o = a(!1);
            const l = (h)=>{
                const d = h.target.options;
                return Array.prototype.map.call(d, (u)=>({
                        displayValue: u.textContent,
                        exportValue: u.value
                    }));
            };
            return this.enableScripting && this.hasJSActions ? (i.addEventListener("updatefromsandbox", (h)=>{
                const d = {
                    value (u) {
                        r?.();
                        const f = u.detail.value, g = new Set(Array.isArray(f) ? f : [
                            f
                        ]);
                        for (const p of i.options)p.selected = g.has(p.value);
                        t.setValue(e, {
                            value: a(!0)
                        }), o = a(!1);
                    },
                    multipleSelection (u) {
                        i.multiple = !0;
                    },
                    remove (u) {
                        const f = i.options, g = u.detail.remove;
                        f[g].selected = !1, i.remove(g), f.length > 0 && Array.prototype.findIndex.call(f, (m)=>m.selected) === -1 && (f[0].selected = !0), t.setValue(e, {
                            value: a(!0),
                            items: l(u)
                        }), o = a(!1);
                    },
                    clear (u) {
                        for(; i.length !== 0;)i.remove(0);
                        t.setValue(e, {
                            value: null,
                            items: []
                        }), o = a(!1);
                    },
                    insert (u) {
                        const { index: f, displayValue: g, exportValue: p } = u.detail.insert, m = i.children[f], b = document.createElement("option");
                        b.textContent = g, b.value = p, m ? m.before(b) : i.append(b), t.setValue(e, {
                            value: a(!0),
                            items: l(u)
                        }), o = a(!1);
                    },
                    items (u) {
                        const { items: f } = u.detail;
                        for(; i.length !== 0;)i.remove(0);
                        for (const g of f){
                            const { displayValue: p, exportValue: m } = g, b = document.createElement("option");
                            b.textContent = p, b.value = m, i.append(b);
                        }
                        i.options.length > 0 && (i.options[0].selected = !0), t.setValue(e, {
                            value: a(!0),
                            items: l(u)
                        }), o = a(!1);
                    },
                    indices (u) {
                        const f = new Set(u.detail.indices);
                        for (const g of u.target.options)g.selected = f.has(g.index);
                        t.setValue(e, {
                            value: a(!0)
                        }), o = a(!1);
                    },
                    editable (u) {
                        u.target.disabled = !u.detail.editable;
                    }
                };
                this._dispatchEventFromSandbox(d, h);
            }), i.addEventListener("input", (h)=>{
                const d = a(!0), u = a(!1);
                t.setValue(e, {
                    value: d
                }), h.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                    source: this,
                    detail: {
                        id: e,
                        name: "Keystroke",
                        value: o,
                        change: u,
                        changeEx: d,
                        willCommit: !1,
                        commitKey: 1,
                        keyDown: !1
                    }
                });
            }), this._setEventListeners(i, null, [
                [
                    "focus",
                    "Focus"
                ],
                [
                    "blur",
                    "Blur"
                ],
                [
                    "mousedown",
                    "Mouse Down"
                ],
                [
                    "mouseenter",
                    "Mouse Enter"
                ],
                [
                    "mouseleave",
                    "Mouse Exit"
                ],
                [
                    "mouseup",
                    "Mouse Up"
                ],
                [
                    "input",
                    "Action"
                ],
                [
                    "input",
                    "Validate"
                ]
            ], (h)=>h.target.value)) : i.addEventListener("input", function(h) {
                t.setValue(e, {
                    value: a(!0)
                });
            }), this.data.combo && this._setTextStyle(i), this._setBackgroundColor(i), this._setDefaultPropertiesFromJS(i), this.container.append(i), this.container;
        }
    }
    class ze extends W {
        constructor(t){
            const { data: e, elements: s } = t;
            super(t, {
                isRenderable: W._hasPopupData(e)
            }), this.elements = s, this.popup = null;
        }
        render() {
            this.container.classList.add("popupAnnotation");
            const t = this.popup = new zn({
                container: this.container,
                color: this.data.color,
                titleObj: this.data.titleObj,
                modificationDate: this.data.modificationDate,
                contentsObj: this.data.contentsObj,
                richText: this.data.richText,
                rect: this.data.rect,
                parentRect: this.data.parentRect || null,
                parent: this.parent,
                elements: this.elements,
                open: this.data.open
            }), e = [];
            for (const s of this.elements)s.popup = t, s.container.ariaHasPopup = "dialog", e.push(s.data.id), s.addHighlightArea();
            return this.container.setAttribute("aria-controls", e.map((s)=>`${We}${s}`).join(",")), this.container;
        }
    }
    class zn {
        #t = this.#T.bind(this);
        #e = this.#x.bind(this);
        #s = this.#P.bind(this);
        #i = this.#_.bind(this);
        #r = null;
        #n = null;
        #l = null;
        #o = null;
        #d = null;
        #h = null;
        #u = null;
        #c = !1;
        #f = null;
        #a = null;
        #p = null;
        #m = null;
        #g = null;
        #b = null;
        #A = !1;
        constructor({ container: t, color: e, elements: s, titleObj: i, modificationDate: n, contentsObj: r, richText: a, parent: o, rect: l, parentRect: h, open: d }){
            this.#n = t, this.#g = i, this.#l = r, this.#m = a, this.#h = o, this.#r = e, this.#p = l, this.#u = h, this.#d = s, this.#o = Os.toDateObject(n), this.trigger = s.flatMap((u)=>u.getElementsToTriggerPopup());
            for (const u of this.trigger)u.addEventListener("click", this.#i), u.addEventListener("mouseenter", this.#s), u.addEventListener("mouseleave", this.#e), u.classList.add("popupTriggerArea");
            for (const u of s)u.container?.addEventListener("keydown", this.#t);
            this.#n.hidden = !0, d && this.#_();
        }
        render() {
            if (this.#f) return;
            const t = this.#f = document.createElement("div");
            if (t.className = "popup", this.#r) {
                const n = t.style.outlineColor = P.makeHexColor(...this.#r);
                t.style.backgroundColor = `color-mix(in srgb, ${n} 30%, white)`;
            }
            const e = document.createElement("span");
            e.className = "header";
            const s = document.createElement("h1");
            if (e.append(s), { dir: s.dir, str: s.textContent } = this.#g, t.append(e), this.#o) {
                const n = document.createElement("span");
                n.classList.add("popupDate"), n.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), n.setAttribute("data-l10n-args", JSON.stringify({
                    dateObj: this.#o.valueOf()
                })), e.append(n);
            }
            const i = this.#y;
            if (i) Zs.render({
                xfaHtml: i,
                intent: "richText",
                div: t
            }), t.lastChild.classList.add("richText", "popupContent");
            else {
                const n = this._formatContents(this.#l);
                t.append(n);
            }
            this.#n.append(t);
        }
        get #y() {
            const t = this.#m, e = this.#l;
            return t?.str && (!e?.str || e.str === t.str) && this.#m.html || null;
        }
        get #v() {
            return this.#y?.attributes?.style?.fontSize || 0;
        }
        get #S() {
            return this.#y?.attributes?.style?.color || null;
        }
        #C(t) {
            const e = [], s = {
                str: t,
                html: {
                    name: "div",
                    attributes: {
                        dir: "auto"
                    },
                    children: [
                        {
                            name: "p",
                            children: e
                        }
                    ]
                }
            }, i = {
                style: {
                    color: this.#S,
                    fontSize: this.#v ? `calc(${this.#v}px * var(--total-scale-factor))` : ""
                }
            };
            for (const n of t.split(`
`))e.push({
                name: "span",
                value: n,
                attributes: i
            });
            return s;
        }
        _formatContents({ str: t, dir: e }) {
            const s = document.createElement("p");
            s.classList.add("popupContent"), s.dir = e;
            const i = t.split(/(?:\r\n?|\n)/);
            for(let n = 0, r = i.length; n < r; ++n){
                const a = i[n];
                s.append(document.createTextNode(a)), n < r - 1 && s.append(document.createElement("br"));
            }
            return s;
        }
        #T(t) {
            t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && this.#c) && this.#_();
        }
        updateEdited({ rect: t, popupContent: e }) {
            this.#b ||= {
                contentsObj: this.#l,
                richText: this.#m
            }, t && (this.#a = null), e && (this.#m = this.#C(e), this.#l = null), this.#f?.remove(), this.#f = null;
        }
        resetEdited() {
            this.#b && ({ contentsObj: this.#l, richText: this.#m } = this.#b, this.#b = null, this.#f?.remove(), this.#f = null, this.#a = null);
        }
        #R() {
            if (this.#a !== null) return;
            const { page: { view: t }, viewport: { rawDims: { pageWidth: e, pageHeight: s, pageX: i, pageY: n } } } = this.#h;
            let r = !!this.#u, a = r ? this.#u : this.#p;
            for (const g of this.#d)if (!a || P.intersect(g.data.rect, a) !== null) {
                a = g.data.rect, r = !0;
                break;
            }
            const o = P.normalizeRect([
                a[0],
                t[3] - a[1] + t[1],
                a[2],
                t[3] - a[3] + t[1]
            ]), h = r ? a[2] - a[0] + 5 : 0, d = o[0] + h, u = o[1];
            this.#a = [
                100 * (d - i) / e,
                100 * (u - n) / s
            ];
            const { style: f } = this.#n;
            f.left = `${this.#a[0]}%`, f.top = `${this.#a[1]}%`;
        }
        #_() {
            this.#c = !this.#c, this.#c ? (this.#P(), this.#n.addEventListener("click", this.#i), this.#n.addEventListener("keydown", this.#t)) : (this.#x(), this.#n.removeEventListener("click", this.#i), this.#n.removeEventListener("keydown", this.#t));
        }
        #P() {
            this.#f || this.render(), this.isVisible ? this.#c && this.#n.classList.add("focused") : (this.#R(), this.#n.hidden = !1, this.#n.style.zIndex = parseInt(this.#n.style.zIndex) + 1e3);
        }
        #x() {
            this.#n.classList.remove("focused"), !(this.#c || !this.isVisible) && (this.#n.hidden = !0, this.#n.style.zIndex = parseInt(this.#n.style.zIndex) - 1e3);
        }
        forceHide() {
            this.#A = this.isVisible, this.#A && (this.#n.hidden = !0);
        }
        maybeShow() {
            this.#A && (this.#f || this.#P(), this.#A = !1, this.#n.hidden = !1);
        }
        get isVisible() {
            return this.#n.hidden === !1;
        }
    }
    class si extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = D.FREETEXT;
        }
        render() {
            if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
                const t = document.createElement("div");
                t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
                for (const e of this.textContent){
                    const s = document.createElement("span");
                    s.textContent = e, t.append(s);
                }
                this.container.append(t);
            }
            return !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
        }
    }
    class Un extends W {
        #t = null;
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            });
        }
        render() {
            this.container.classList.add("lineAnnotation");
            const { data: t, width: e, height: s } = this, i = this.svgFactory.create(e, s, !0), n = this.#t = this.svgFactory.createElement("svg:line");
            return n.setAttribute("x1", t.rect[2] - t.lineCoordinates[0]), n.setAttribute("y1", t.rect[3] - t.lineCoordinates[1]), n.setAttribute("x2", t.rect[2] - t.lineCoordinates[2]), n.setAttribute("y2", t.rect[3] - t.lineCoordinates[3]), n.setAttribute("stroke-width", t.borderStyle.width || 1), n.setAttribute("stroke", "transparent"), n.setAttribute("fill", "transparent"), i.append(n), this.container.append(i), !t.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
            return this.#t;
        }
        addHighlightArea() {
            this.container.classList.add("highlightArea");
        }
    }
    class jn extends W {
        #t = null;
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            });
        }
        render() {
            this.container.classList.add("squareAnnotation");
            const { data: t, width: e, height: s } = this, i = this.svgFactory.create(e, s, !0), n = t.borderStyle.width, r = this.#t = this.svgFactory.createElement("svg:rect");
            return r.setAttribute("x", n / 2), r.setAttribute("y", n / 2), r.setAttribute("width", e - n), r.setAttribute("height", s - n), r.setAttribute("stroke-width", n || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), i.append(r), this.container.append(i), !t.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
            return this.#t;
        }
        addHighlightArea() {
            this.container.classList.add("highlightArea");
        }
    }
    class Vn extends W {
        #t = null;
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            });
        }
        render() {
            this.container.classList.add("circleAnnotation");
            const { data: t, width: e, height: s } = this, i = this.svgFactory.create(e, s, !0), n = t.borderStyle.width, r = this.#t = this.svgFactory.createElement("svg:ellipse");
            return r.setAttribute("cx", e / 2), r.setAttribute("cy", s / 2), r.setAttribute("rx", e / 2 - n / 2), r.setAttribute("ry", s / 2 - n / 2), r.setAttribute("stroke-width", n || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), i.append(r), this.container.append(i), !t.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
            return this.#t;
        }
        addHighlightArea() {
            this.container.classList.add("highlightArea");
        }
    }
    class ii extends W {
        #t = null;
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            }), this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
        }
        render() {
            this.container.classList.add(this.containerClassName);
            const { data: { rect: t, vertices: e, borderStyle: s, popupRef: i }, width: n, height: r } = this;
            if (!e) return this.container;
            const a = this.svgFactory.create(n, r, !0);
            let o = [];
            for(let h = 0, d = e.length; h < d; h += 2){
                const u = e[h] - t[0], f = t[3] - e[h + 1];
                o.push(`${u},${f}`);
            }
            o = o.join(" ");
            const l = this.#t = this.svgFactory.createElement(this.svgElementName);
            return l.setAttribute("points", o), l.setAttribute("stroke-width", s.width || 1), l.setAttribute("stroke", "transparent"), l.setAttribute("fill", "transparent"), a.append(l), this.container.append(a), !i && this.hasPopupData && this._createPopup(), this.container;
        }
        getElementsToTriggerPopup() {
            return this.#t;
        }
        addHighlightArea() {
            this.container.classList.add("highlightArea");
        }
    }
    class Wn extends ii {
        constructor(t){
            super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
        }
    }
    class qn extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            });
        }
        render() {
            return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container;
        }
    }
    class ns extends W {
        #t = null;
        #e = [];
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            }), this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? D.HIGHLIGHT : D.INK;
        }
        #s(t, e) {
            switch(t){
                case 90:
                    return {
                        transform: `rotate(90) translate(${-e[0]},${e[1]}) scale(1,-1)`,
                        width: e[3] - e[1],
                        height: e[2] - e[0]
                    };
                case 180:
                    return {
                        transform: `rotate(180) translate(${-e[2]},${e[1]}) scale(1,-1)`,
                        width: e[2] - e[0],
                        height: e[3] - e[1]
                    };
                case 270:
                    return {
                        transform: `rotate(270) translate(${-e[2]},${e[3]}) scale(1,-1)`,
                        width: e[3] - e[1],
                        height: e[2] - e[0]
                    };
                default:
                    return {
                        transform: `translate(${-e[0]},${e[3]}) scale(1,-1)`,
                        width: e[2] - e[0],
                        height: e[3] - e[1]
                    };
            }
        }
        render() {
            this.container.classList.add(this.containerClassName);
            const { data: { rect: t, rotation: e, inkLists: s, borderStyle: i, popupRef: n } } = this, { transform: r, width: a, height: o } = this.#s(e, t), l = this.svgFactory.create(a, o, !0), h = this.#t = this.svgFactory.createElement("svg:g");
            l.append(h), h.setAttribute("stroke-width", i.width || 1), h.setAttribute("stroke-linecap", "round"), h.setAttribute("stroke-linejoin", "round"), h.setAttribute("stroke-miterlimit", 10), h.setAttribute("stroke", "transparent"), h.setAttribute("fill", "transparent"), h.setAttribute("transform", r);
            for(let d = 0, u = s.length; d < u; d++){
                const f = this.svgFactory.createElement(this.svgElementName);
                this.#e.push(f), f.setAttribute("points", s[d].join(",")), h.append(f);
            }
            return !n && this.hasPopupData && this._createPopup(), this.container.append(l), this._editOnDoubleClick(), this.container;
        }
        updateEdited(t) {
            super.updateEdited(t);
            const { thickness: e, points: s, rect: i } = t, n = this.#t;
            if (e >= 0 && n.setAttribute("stroke-width", e || 1), s) for(let r = 0, a = this.#e.length; r < a; r++)this.#e[r].setAttribute("points", s[r].join(","));
            if (i) {
                const { transform: r, width: a, height: o } = this.#s(this.data.rotation, i);
                n.parentElement.setAttribute("viewBox", `0 0 ${a} ${o}`), n.setAttribute("transform", r);
            }
        }
        getElementsToTriggerPopup() {
            return this.#e;
        }
        addHighlightArea() {
            this.container.classList.add("highlightArea");
        }
    }
    class ni extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
            }), this.annotationEditorType = D.HIGHLIGHT;
        }
        render() {
            return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), this.container;
        }
    }
    class Xn extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
            });
        }
        render() {
            return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("underlineAnnotation"), this.container;
        }
    }
    class Yn extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
            });
        }
        render() {
            return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("squigglyAnnotation"), this.container;
        }
    }
    class Kn extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0,
                createQuadrilaterals: !0
            });
        }
        render() {
            return !this.data.popupRef && this.hasPopupData && this._createPopup(), this.container.classList.add("strikeoutAnnotation"), this.container;
        }
    }
    class ri extends W {
        constructor(t){
            super(t, {
                isRenderable: !0,
                ignoreBorder: !0
            }), this.annotationEditorType = D.STAMP;
        }
        render() {
            return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && this._createPopup(), this._editOnDoubleClick(), this.container;
        }
    }
    class Qn extends W {
        #t = null;
        constructor(t){
            super(t, {
                isRenderable: !0
            });
            const { file: e } = this.data;
            this.filename = e.filename, this.content = e.content, this.linkService.eventBus?.dispatch("fileattachmentannotation", {
                source: this,
                ...e
            });
        }
        render() {
            this.container.classList.add("fileAttachmentAnnotation");
            const { container: t, data: e } = this;
            let s;
            e.hasAppearance || e.fillAlpha === 0 ? s = document.createElement("div") : (s = document.createElement("img"), s.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(e.name) ? "paperclip" : "pushpin"}.svg`, e.fillAlpha && e.fillAlpha < 1 && (s.style = `filter: opacity(${Math.round(e.fillAlpha * 100)}%);`)), s.addEventListener("dblclick", this.#e.bind(this)), this.#t = s;
            const { isMac: i } = st.platform;
            return t.addEventListener("keydown", (n)=>{
                n.key === "Enter" && (i ? n.metaKey : n.ctrlKey) && this.#e();
            }), !e.popupRef && this.hasPopupData ? this._createPopup() : s.classList.add("popupTriggerArea"), t.append(s), t;
        }
        getElementsToTriggerPopup() {
            return this.#t;
        }
        addHighlightArea() {
            this.container.classList.add("highlightArea");
        }
        #e() {
            this.downloadManager?.openOrDownloadData(this.content, this.filename);
        }
    }
    rs = class {
        #t = null;
        #e = null;
        #s = new Map;
        #i = null;
        constructor({ div: t, accessibilityManager: e, annotationCanvasMap: s, annotationEditorUIManager: i, page: n, viewport: r, structTreeLayer: a }){
            this.div = t, this.#t = e, this.#e = s, this.#i = a || null, this.page = n, this.viewport = r, this.zIndex = 0, this._annotationEditorUIManager = i;
        }
        hasEditableAnnotations() {
            return this.#s.size > 0;
        }
        async #r(t, e) {
            const s = t.firstChild || t, i = s.id = `${We}${e}`, n = await this.#i?.getAriaAttributes(i);
            if (n) for (const [r, a] of n)s.setAttribute(r, a);
            this.div.append(t), this.#t?.moveElementInDOM(this.div, t, s, !1);
        }
        async render(t) {
            const { annotations: e } = t, s = this.div;
            Mt(s, this.viewport);
            const i = new Map, n = {
                data: null,
                layer: s,
                linkService: t.linkService,
                downloadManager: t.downloadManager,
                imageResourcesPath: t.imageResourcesPath || "",
                renderForms: t.renderForms !== !1,
                svgFactory: new ye,
                annotationStorage: t.annotationStorage || new Ze,
                enableScripting: t.enableScripting === !0,
                hasJSActions: t.hasJSActions,
                fieldObjects: t.fieldObjects,
                parent: this,
                elements: null
            };
            for (const r of e){
                if (r.noHTML) continue;
                const a = r.annotationType === X.POPUP;
                if (a) {
                    const h = i.get(r.id);
                    if (!h) continue;
                    n.elements = h;
                } else if (r.rect[2] === r.rect[0] || r.rect[3] === r.rect[1]) continue;
                n.data = r;
                const o = ks.create(n);
                if (!o.isRenderable) continue;
                if (!a && r.popupRef) {
                    const h = i.get(r.popupRef);
                    h ? h.push(o) : i.set(r.popupRef, [
                        o
                    ]);
                }
                const l = o.render();
                r.hidden && (l.style.visibility = "hidden"), await this.#r(l, r.id), o._isEditable && (this.#s.set(o.data.id, o), this._annotationEditorUIManager?.renderAnnotationElement(o));
            }
            this.#n();
        }
        async addLinkAnnotations(t, e) {
            const s = {
                data: null,
                layer: this.div,
                linkService: e,
                svgFactory: new ye,
                parent: this
            };
            for (const i of t){
                i.borderStyle ||= rs._defaultBorderStyle, s.data = i;
                const n = ks.create(s);
                if (!n.isRenderable) continue;
                const r = n.render();
                await this.#r(r, i.id);
            }
        }
        update({ viewport: t }) {
            const e = this.div;
            this.viewport = t, Mt(e, {
                rotation: t.rotation
            }), this.#n(), e.hidden = !1;
        }
        #n() {
            if (!this.#e) return;
            const t = this.div;
            for (const [e, s] of this.#e){
                const i = t.querySelector(`[data-annotation-id="${e}"]`);
                if (!i) continue;
                s.className = "annotationContent";
                const { firstChild: n } = i;
                n ? n.nodeName === "CANVAS" ? n.replaceWith(s) : n.classList.contains("annotationContent") ? n.after(s) : n.before(s) : i.append(s);
                const r = this.#s.get(e);
                r && (r._hasNoCanvas ? (this._annotationEditorUIManager?.setMissingCanvas(e, i.id, s), r._hasNoCanvas = !1) : r.canvas = s);
            }
            this.#e.clear();
        }
        getEditableAnnotations() {
            return Array.from(this.#s.values());
        }
        getEditableAnnotation(t) {
            return this.#s.get(t);
        }
        static get _defaultBorderStyle() {
            return N(this, "_defaultBorderStyle", Object.freeze({
                width: 1,
                rawWidth: 1,
                style: Bt.SOLID,
                dashArray: [
                    3
                ],
                horizontalCornerRadius: 0,
                verticalCornerRadius: 0
            }));
        }
    };
    const pe = /\r\n?|\n/g;
    class Q extends k {
        #t;
        #e = "";
        #s = `${this.id}-editor`;
        #i = null;
        #r;
        static _freeTextDefaultContent = "";
        static _internalPadding = 0;
        static _defaultColor = null;
        static _defaultFontSize = 10;
        static get _keyboardManager() {
            const t = Q.prototype, e = (n)=>n.isEmpty(), s = Rt.TRANSLATE_SMALL, i = Rt.TRANSLATE_BIG;
            return N(this, "_keyboardManager", new re([
                [
                    [
                        "ctrl+s",
                        "mac+meta+s",
                        "ctrl+p",
                        "mac+meta+p"
                    ],
                    t.commitOrRemove,
                    {
                        bubbles: !0
                    }
                ],
                [
                    [
                        "ctrl+Enter",
                        "mac+meta+Enter",
                        "Escape",
                        "mac+Escape"
                    ],
                    t.commitOrRemove
                ],
                [
                    [
                        "ArrowLeft",
                        "mac+ArrowLeft"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            -s,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowLeft",
                        "mac+shift+ArrowLeft"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            -i,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ArrowRight",
                        "mac+ArrowRight"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            s,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowRight",
                        "mac+shift+ArrowRight"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            i,
                            0
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ArrowUp",
                        "mac+ArrowUp"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            0,
                            -s
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowUp",
                        "mac+shift+ArrowUp"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            0,
                            -i
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ArrowDown",
                        "mac+ArrowDown"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            0,
                            s
                        ],
                        checker: e
                    }
                ],
                [
                    [
                        "ctrl+ArrowDown",
                        "mac+shift+ArrowDown"
                    ],
                    t._translateEmpty,
                    {
                        args: [
                            0,
                            i
                        ],
                        checker: e
                    }
                ]
            ]));
        }
        static _type = "freetext";
        static _editorType = D.FREETEXT;
        constructor(t){
            super({
                ...t,
                name: "freeTextEditor"
            }), this.#t = t.color || Q._defaultColor || k._defaultLineColor, this.#r = t.fontSize || Q._defaultFontSize;
        }
        static initialize(t, e) {
            k.initialize(t, e);
            const s = getComputedStyle(document.documentElement);
            this._internalPadding = parseFloat(s.getPropertyValue("--freetext-padding"));
        }
        static updateDefaultParams(t, e) {
            switch(t){
                case O.FREETEXT_SIZE:
                    Q._defaultFontSize = e;
                    break;
                case O.FREETEXT_COLOR:
                    Q._defaultColor = e;
                    break;
            }
        }
        updateParams(t, e) {
            switch(t){
                case O.FREETEXT_SIZE:
                    this.#n(e);
                    break;
                case O.FREETEXT_COLOR:
                    this.#l(e);
                    break;
            }
        }
        static get defaultPropertiesToUpdate() {
            return [
                [
                    O.FREETEXT_SIZE,
                    Q._defaultFontSize
                ],
                [
                    O.FREETEXT_COLOR,
                    Q._defaultColor || k._defaultLineColor
                ]
            ];
        }
        get propertiesToUpdate() {
            return [
                [
                    O.FREETEXT_SIZE,
                    this.#r
                ],
                [
                    O.FREETEXT_COLOR,
                    this.#t
                ]
            ];
        }
        #n(t) {
            const e = (i)=>{
                this.editorDiv.style.fontSize = `calc(${i}px * var(--total-scale-factor))`, this.translate(0, -(i - this.#r) * this.parentScale), this.#r = i, this.#d();
            }, s = this.#r;
            this.addCommands({
                cmd: e.bind(this, t),
                undo: e.bind(this, s),
                post: this._uiManager.updateUI.bind(this._uiManager, this),
                mustExec: !0,
                type: O.FREETEXT_SIZE,
                overwriteIfSameType: !0,
                keepUndo: !0
            });
        }
        #l(t) {
            const e = (i)=>{
                this.#t = this.editorDiv.style.color = i;
            }, s = this.#t;
            this.addCommands({
                cmd: e.bind(this, t),
                undo: e.bind(this, s),
                post: this._uiManager.updateUI.bind(this._uiManager, this),
                mustExec: !0,
                type: O.FREETEXT_COLOR,
                overwriteIfSameType: !0,
                keepUndo: !0
            });
        }
        _translateEmpty(t, e) {
            this._uiManager.translateSelectedEditors(t, e, !0);
        }
        getInitialTranslation() {
            const t = this.parentScale;
            return [
                -Q._internalPadding * t,
                -(Q._internalPadding + this.#r) * t
            ];
        }
        rebuild() {
            this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
        }
        enableEditMode() {
            if (this.isInEditMode()) return;
            this.parent.setEditingState(!1), this.parent.updateToolbar(D.FREETEXT), super.enableEditMode(), this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.#i = new AbortController;
            const t = this._uiManager.combinedSignal(this.#i);
            this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
                signal: t
            }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
                signal: t
            }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
                signal: t
            }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
                signal: t
            }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
                signal: t
            });
        }
        disableEditMode() {
            this.isInEditMode() && (this.parent.setEditingState(!0), super.disableEditMode(), this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", this.#s), this._isDraggable = !0, this.#i?.abort(), this.#i = null, this.div.focus({
                preventScroll: !0
            }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"));
        }
        focusin(t) {
            this._focusEventsAllowed && (super.focusin(t), t.target !== this.editorDiv && this.editorDiv.focus());
        }
        onceAdded(t) {
            this.width || (this.enableEditMode(), t && this.editorDiv.focus(), this._initialOptions?.isCentered && this.center(), this._initialOptions = null);
        }
        isEmpty() {
            return !this.editorDiv || this.editorDiv.innerText.trim() === "";
        }
        remove() {
            this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
        }
        #o() {
            const t = [];
            this.editorDiv.normalize();
            let e = null;
            for (const s of this.editorDiv.childNodes)e?.nodeType === Node.TEXT_NODE && s.nodeName === "BR" || (t.push(Q.#h(s)), e = s);
            return t.join(`
`);
        }
        #d() {
            const [t, e] = this.parentDimensions;
            let s;
            if (this.isAttachedToDOM) s = this.div.getBoundingClientRect();
            else {
                const { currentLayer: i, div: n } = this, r = n.style.display, a = n.classList.contains("hidden");
                n.classList.remove("hidden"), n.style.display = "hidden", i.div.append(this.div), s = n.getBoundingClientRect(), n.remove(), n.style.display = r, n.classList.toggle("hidden", a);
            }
            this.rotation % 180 === this.parentRotation % 180 ? (this.width = s.width / t, this.height = s.height / e) : (this.width = s.height / t, this.height = s.width / e), this.fixAndSetPosition();
        }
        commit() {
            if (!this.isInEditMode()) return;
            super.commit(), this.disableEditMode();
            const t = this.#e, e = this.#e = this.#o().trimEnd();
            if (t === e) return;
            const s = (i)=>{
                if (this.#e = i, !i) {
                    this.remove();
                    return;
                }
                this.#u(), this._uiManager.rebuild(this), this.#d();
            };
            this.addCommands({
                cmd: ()=>{
                    s(e);
                },
                undo: ()=>{
                    s(t);
                },
                mustExec: !1
            }), this.#d();
        }
        shouldGetKeyboardEvents() {
            return this.isInEditMode();
        }
        enterInEditMode() {
            this.enableEditMode(), this.editorDiv.focus();
        }
        dblclick(t) {
            this.enterInEditMode();
        }
        keydown(t) {
            t.target === this.div && t.key === "Enter" && (this.enterInEditMode(), t.preventDefault());
        }
        editorDivKeydown(t) {
            Q._keyboardManager.exec(this, t);
        }
        editorDivFocus(t) {
            this.isEditing = !0;
        }
        editorDivBlur(t) {
            this.isEditing = !1;
        }
        editorDivInput(t) {
            this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
        }
        disableEditing() {
            this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
        }
        enableEditing() {
            this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
        }
        render() {
            if (this.div) return this.div;
            let t, e;
            (this._isCopy || this.annotationElementId) && (t = this.x, e = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", this.#s), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
            const { style: s } = this.editorDiv;
            if (s.fontSize = `calc(${this.#r}px * var(--total-scale-factor))`, s.color = this.#t, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), Ke(this, this.div, [
                "dblclick",
                "keydown"
            ]), this._isCopy || this.annotationElementId) {
                const [i, n] = this.parentDimensions;
                if (this.annotationElementId) {
                    const { position: r } = this._initialData;
                    let [a, o] = this.getInitialTranslation();
                    [a, o] = this.pageTranslationToScreen(a, o);
                    const [l, h] = this.pageDimensions, [d, u] = this.pageTranslation;
                    let f, g;
                    switch(this.rotation){
                        case 0:
                            f = t + (r[0] - d) / l, g = e + this.height - (r[1] - u) / h;
                            break;
                        case 90:
                            f = t + (r[0] - d) / l, g = e - (r[1] - u) / h, [a, o] = [
                                o,
                                -a
                            ];
                            break;
                        case 180:
                            f = t - this.width + (r[0] - d) / l, g = e - (r[1] - u) / h, [a, o] = [
                                -a,
                                -o
                            ];
                            break;
                        case 270:
                            f = t + (r[0] - d - this.height * h) / l, g = e + (r[1] - u - this.width * l) / h, [a, o] = [
                                -o,
                                a
                            ];
                            break;
                    }
                    this.setAt(f * i, g * n, a, o);
                } else this._moveAfterPaste(t, e);
                this.#u(), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
            } else this._isDraggable = !1, this.editorDiv.contentEditable = !0;
            return this.div;
        }
        static #h(t) {
            return (t.nodeType === Node.TEXT_NODE ? t.nodeValue : t.innerText).replaceAll(pe, "");
        }
        editorDivPaste(t) {
            const e = t.clipboardData || window.clipboardData, { types: s } = e;
            if (s.length === 1 && s[0] === "text/plain") return;
            t.preventDefault();
            const i = Q.#f(e.getData("text") || "").replaceAll(pe, `
`);
            if (!i) return;
            const n = window.getSelection();
            if (!n.rangeCount) return;
            this.editorDiv.normalize(), n.deleteFromDocument();
            const r = n.getRangeAt(0);
            if (!i.includes(`
`)) {
                r.insertNode(document.createTextNode(i)), this.editorDiv.normalize(), n.collapseToStart();
                return;
            }
            const { startContainer: a, startOffset: o } = r, l = [], h = [];
            if (a.nodeType === Node.TEXT_NODE) {
                const f = a.parentElement;
                if (h.push(a.nodeValue.slice(o).replaceAll(pe, "")), f !== this.editorDiv) {
                    let g = l;
                    for (const p of this.editorDiv.childNodes){
                        if (p === f) {
                            g = h;
                            continue;
                        }
                        g.push(Q.#h(p));
                    }
                }
                l.push(a.nodeValue.slice(0, o).replaceAll(pe, ""));
            } else if (a === this.editorDiv) {
                let f = l, g = 0;
                for (const p of this.editorDiv.childNodes)g++ === o && (f = h), f.push(Q.#h(p));
            }
            this.#e = `${l.join(`
`)}${i}${h.join(`
`)}`, this.#u();
            const d = new Range;
            let u = Math.sumPrecise(l.map((f)=>f.length));
            for (const { firstChild: f } of this.editorDiv.childNodes)if (f.nodeType === Node.TEXT_NODE) {
                const g = f.nodeValue.length;
                if (u <= g) {
                    d.setStart(f, u), d.setEnd(f, u);
                    break;
                }
                u -= g;
            }
            n.removeAllRanges(), n.addRange(d);
        }
        #u() {
            if (this.editorDiv.replaceChildren(), !!this.#e) for (const t of this.#e.split(`
`)){
                const e = document.createElement("div");
                e.append(t ? document.createTextNode(t) : document.createElement("br")), this.editorDiv.append(e);
            }
        }
        #c() {
            return this.#e.replaceAll(" ", " ");
        }
        static #f(t) {
            return t.replaceAll(" ", " ");
        }
        get contentDiv() {
            return this.editorDiv;
        }
        static async deserialize(t, e, s) {
            let i = null;
            if (t instanceof si) {
                const { data: { defaultAppearanceData: { fontSize: r, fontColor: a }, rect: o, rotation: l, id: h, popupRef: d }, textContent: u, textPosition: f, parent: { page: { pageNumber: g } } } = t;
                if (!u || u.length === 0) return null;
                i = t = {
                    annotationType: D.FREETEXT,
                    color: Array.from(a),
                    fontSize: r,
                    value: u.join(`
`),
                    position: f,
                    pageIndex: g - 1,
                    rect: o.slice(0),
                    rotation: l,
                    id: h,
                    deleted: !1,
                    popupRef: d
                };
            }
            const n = await super.deserialize(t, e, s);
            return n.#r = t.fontSize, n.#t = P.makeHexColor(...t.color), n.#e = Q.#f(t.value), n.annotationElementId = t.id || null, n._initialData = i, n;
        }
        serialize(t = !1) {
            if (this.isEmpty()) return null;
            if (this.deleted) return this.serializeDeleted();
            const e = Q._internalPadding * this.parentScale, s = this.getRect(e, e), i = k._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.#t), n = {
                annotationType: D.FREETEXT,
                color: i,
                fontSize: this.#r,
                value: this.#c(),
                pageIndex: this.pageIndex,
                rect: s,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
            };
            return t ? (n.isCopy = !0, n) : this.annotationElementId && !this.#a(n) ? null : (n.id = this.annotationElementId, n);
        }
        #a(t) {
            const { value: e, fontSize: s, color: i, pageIndex: n } = this._initialData;
            return this._hasBeenMoved || t.value !== e || t.fontSize !== s || t.color.some((r, a)=>r !== i[a]) || t.pageIndex !== n;
        }
        renderAnnotationElement(t) {
            const e = super.renderAnnotationElement(t);
            if (this.deleted) return e;
            const { style: s } = e;
            s.fontSize = `calc(${this.#r}px * var(--total-scale-factor))`, s.color = this.#t, e.replaceChildren();
            for (const n of this.#e.split(`
`)){
                const r = document.createElement("div");
                r.append(n ? document.createTextNode(n) : document.createElement("br")), e.append(r);
            }
            const i = Q._internalPadding * this.parentScale;
            return t.updateEdited({
                rect: this.getRect(i, i),
                popupContent: this.#e
            }), e;
        }
        resetAnnotationElement(t) {
            super.resetAnnotationElement(t), t.resetEdited();
        }
    }
    class x {
        static PRECISION = 1e-4;
        toSVGPath() {
            $("Abstract method `toSVGPath` must be implemented.");
        }
        get box() {
            $("Abstract getter `box` must be implemented.");
        }
        serialize(t, e) {
            $("Abstract method `serialize` must be implemented.");
        }
        static _rescale(t, e, s, i, n, r) {
            r ||= new Float32Array(t.length);
            for(let a = 0, o = t.length; a < o; a += 2)r[a] = e + t[a] * i, r[a + 1] = s + t[a + 1] * n;
            return r;
        }
        static _rescaleAndSwap(t, e, s, i, n, r) {
            r ||= new Float32Array(t.length);
            for(let a = 0, o = t.length; a < o; a += 2)r[a] = e + t[a + 1] * i, r[a + 1] = s + t[a] * n;
            return r;
        }
        static _translate(t, e, s, i) {
            i ||= new Float32Array(t.length);
            for(let n = 0, r = t.length; n < r; n += 2)i[n] = e + t[n], i[n + 1] = s + t[n + 1];
            return i;
        }
        static svgRound(t) {
            return Math.round(t * 1e4);
        }
        static _normalizePoint(t, e, s, i, n) {
            switch(n){
                case 90:
                    return [
                        1 - e / s,
                        t / i
                    ];
                case 180:
                    return [
                        1 - t / s,
                        1 - e / i
                    ];
                case 270:
                    return [
                        e / s,
                        1 - t / i
                    ];
                default:
                    return [
                        t / s,
                        e / i
                    ];
            }
        }
        static _normalizePagePoint(t, e, s) {
            switch(s){
                case 90:
                    return [
                        1 - e,
                        t
                    ];
                case 180:
                    return [
                        1 - t,
                        1 - e
                    ];
                case 270:
                    return [
                        e,
                        1 - t
                    ];
                default:
                    return [
                        t,
                        e
                    ];
            }
        }
        static createBezierPoints(t, e, s, i, n, r) {
            return [
                (t + 5 * s) / 6,
                (e + 5 * i) / 6,
                (5 * s + n) / 6,
                (5 * i + r) / 6,
                (s + n) / 2,
                (i + r) / 2
            ];
        }
    }
    class kt {
        #t;
        #e = [];
        #s;
        #i;
        #r = [];
        #n = new Float32Array(18);
        #l;
        #o;
        #d;
        #h;
        #u;
        #c;
        #f = [];
        static #a = 8;
        static #p = 2;
        static #m = kt.#a + kt.#p;
        constructor({ x: t, y: e }, s, i, n, r, a = 0){
            this.#t = s, this.#c = n * i, this.#i = r, this.#n.set([
                NaN,
                NaN,
                NaN,
                NaN,
                t,
                e
            ], 6), this.#s = a, this.#h = kt.#a * i, this.#d = kt.#m * i, this.#u = i, this.#f.push(t, e);
        }
        isEmpty() {
            return isNaN(this.#n[8]);
        }
        #g() {
            const t = this.#n.subarray(4, 6), e = this.#n.subarray(16, 18), [s, i, n, r] = this.#t;
            return [
                (this.#l + (t[0] - e[0]) / 2 - s) / n,
                (this.#o + (t[1] - e[1]) / 2 - i) / r,
                (this.#l + (e[0] - t[0]) / 2 - s) / n,
                (this.#o + (e[1] - t[1]) / 2 - i) / r
            ];
        }
        add({ x: t, y: e }) {
            this.#l = t, this.#o = e;
            const [s, i, n, r] = this.#t;
            let [a, o, l, h] = this.#n.subarray(8, 12);
            const d = t - l, u = e - h, f = Math.hypot(d, u);
            if (f < this.#d) return !1;
            const g = f - this.#h, p = g / f, m = p * d, b = p * u;
            let y = a, A = o;
            a = l, o = h, l += m, h += b, this.#f?.push(t, e);
            const v = -b / g, w = m / g, _ = v * this.#c, S = w * this.#c;
            return this.#n.set(this.#n.subarray(2, 8), 0), this.#n.set([
                l + _,
                h + S
            ], 4), this.#n.set(this.#n.subarray(14, 18), 12), this.#n.set([
                l - _,
                h - S
            ], 16), isNaN(this.#n[6]) ? (this.#r.length === 0 && (this.#n.set([
                a + _,
                o + S
            ], 2), this.#r.push(NaN, NaN, NaN, NaN, (a + _ - s) / n, (o + S - i) / r), this.#n.set([
                a - _,
                o - S
            ], 14), this.#e.push(NaN, NaN, NaN, NaN, (a - _ - s) / n, (o - S - i) / r)), this.#n.set([
                y,
                A,
                a,
                o,
                l,
                h
            ], 6), !this.isEmpty()) : (this.#n.set([
                y,
                A,
                a,
                o,
                l,
                h
            ], 6), Math.abs(Math.atan2(A - o, y - a) - Math.atan2(b, m)) < Math.PI / 2 ? ([a, o, l, h] = this.#n.subarray(2, 6), this.#r.push(NaN, NaN, NaN, NaN, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [a, o, y, A] = this.#n.subarray(14, 18), this.#e.push(NaN, NaN, NaN, NaN, ((y + a) / 2 - s) / n, ((A + o) / 2 - i) / r), !0) : ([y, A, a, o, l, h] = this.#n.subarray(0, 6), this.#r.push(((y + 5 * a) / 6 - s) / n, ((A + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [l, h, a, o, y, A] = this.#n.subarray(12, 18), this.#e.push(((y + 5 * a) / 6 - s) / n, ((A + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), !0));
        }
        toSVGPath() {
            if (this.isEmpty()) return "";
            const t = this.#r, e = this.#e;
            if (isNaN(this.#n[6]) && !this.isEmpty()) return this.#b();
            const s = [];
            s.push(`M${t[4]} ${t[5]}`);
            for(let i = 6; i < t.length; i += 6)isNaN(t[i]) ? s.push(`L${t[i + 4]} ${t[i + 5]}`) : s.push(`C${t[i]} ${t[i + 1]} ${t[i + 2]} ${t[i + 3]} ${t[i + 4]} ${t[i + 5]}`);
            this.#y(s);
            for(let i = e.length - 6; i >= 6; i -= 6)isNaN(e[i]) ? s.push(`L${e[i + 4]} ${e[i + 5]}`) : s.push(`C${e[i]} ${e[i + 1]} ${e[i + 2]} ${e[i + 3]} ${e[i + 4]} ${e[i + 5]}`);
            return this.#A(s), s.join(" ");
        }
        #b() {
            const [t, e, s, i] = this.#t, [n, r, a, o] = this.#g();
            return `M${(this.#n[2] - t) / s} ${(this.#n[3] - e) / i} L${(this.#n[4] - t) / s} ${(this.#n[5] - e) / i} L${n} ${r} L${a} ${o} L${(this.#n[16] - t) / s} ${(this.#n[17] - e) / i} L${(this.#n[14] - t) / s} ${(this.#n[15] - e) / i} Z`;
        }
        #A(t) {
            const e = this.#e;
            t.push(`L${e[4]} ${e[5]} Z`);
        }
        #y(t) {
            const [e, s, i, n] = this.#t, r = this.#n.subarray(4, 6), a = this.#n.subarray(16, 18), [o, l, h, d] = this.#g();
            t.push(`L${(r[0] - e) / i} ${(r[1] - s) / n} L${o} ${l} L${h} ${d} L${(a[0] - e) / i} ${(a[1] - s) / n}`);
        }
        newFreeDrawOutline(t, e, s, i, n, r) {
            return new ai(t, e, s, i, n, r);
        }
        getOutlines() {
            const t = this.#r, e = this.#e, s = this.#n, [i, n, r, a] = this.#t, o = new Float32Array((this.#f?.length ?? 0) + 2);
            for(let d = 0, u = o.length - 2; d < u; d += 2)o[d] = (this.#f[d] - i) / r, o[d + 1] = (this.#f[d + 1] - n) / a;
            if (o[o.length - 2] = (this.#l - i) / r, o[o.length - 1] = (this.#o - n) / a, isNaN(s[6]) && !this.isEmpty()) return this.#v(o);
            const l = new Float32Array(this.#r.length + 24 + this.#e.length);
            let h = t.length;
            for(let d = 0; d < h; d += 2){
                if (isNaN(t[d])) {
                    l[d] = l[d + 1] = NaN;
                    continue;
                }
                l[d] = t[d], l[d + 1] = t[d + 1];
            }
            h = this.#C(l, h);
            for(let d = e.length - 6; d >= 6; d -= 6)for(let u = 0; u < 6; u += 2){
                if (isNaN(e[d + u])) {
                    l[h] = l[h + 1] = NaN, h += 2;
                    continue;
                }
                l[h] = e[d + u], l[h + 1] = e[d + u + 1], h += 2;
            }
            return this.#S(l, h), this.newFreeDrawOutline(l, o, this.#t, this.#u, this.#s, this.#i);
        }
        #v(t) {
            const e = this.#n, [s, i, n, r] = this.#t, [a, o, l, h] = this.#g(), d = new Float32Array(36);
            return d.set([
                NaN,
                NaN,
                NaN,
                NaN,
                (e[2] - s) / n,
                (e[3] - i) / r,
                NaN,
                NaN,
                NaN,
                NaN,
                (e[4] - s) / n,
                (e[5] - i) / r,
                NaN,
                NaN,
                NaN,
                NaN,
                a,
                o,
                NaN,
                NaN,
                NaN,
                NaN,
                l,
                h,
                NaN,
                NaN,
                NaN,
                NaN,
                (e[16] - s) / n,
                (e[17] - i) / r,
                NaN,
                NaN,
                NaN,
                NaN,
                (e[14] - s) / n,
                (e[15] - i) / r
            ], 0), this.newFreeDrawOutline(d, t, this.#t, this.#u, this.#s, this.#i);
        }
        #S(t, e) {
            const s = this.#e;
            return t.set([
                NaN,
                NaN,
                NaN,
                NaN,
                s[4],
                s[5]
            ], e), e += 6;
        }
        #C(t, e) {
            const s = this.#n.subarray(4, 6), i = this.#n.subarray(16, 18), [n, r, a, o] = this.#t, [l, h, d, u] = this.#g();
            return t.set([
                NaN,
                NaN,
                NaN,
                NaN,
                (s[0] - n) / a,
                (s[1] - r) / o,
                NaN,
                NaN,
                NaN,
                NaN,
                l,
                h,
                NaN,
                NaN,
                NaN,
                NaN,
                d,
                u,
                NaN,
                NaN,
                NaN,
                NaN,
                (i[0] - n) / a,
                (i[1] - r) / o
            ], e), e += 24;
        }
    }
    class ai extends x {
        #t;
        #e = new Float32Array(4);
        #s;
        #i;
        #r;
        #n;
        #l;
        constructor(t, e, s, i, n, r){
            super(), this.#l = t, this.#r = e, this.#t = s, this.#n = i, this.#s = n, this.#i = r, this.lastPoint = [
                NaN,
                NaN
            ], this.#o(r);
            const [a, o, l, h] = this.#e;
            for(let d = 0, u = t.length; d < u; d += 2)t[d] = (t[d] - a) / l, t[d + 1] = (t[d + 1] - o) / h;
            for(let d = 0, u = e.length; d < u; d += 2)e[d] = (e[d] - a) / l, e[d + 1] = (e[d + 1] - o) / h;
        }
        toSVGPath() {
            const t = [
                `M${this.#l[4]} ${this.#l[5]}`
            ];
            for(let e = 6, s = this.#l.length; e < s; e += 6){
                if (isNaN(this.#l[e])) {
                    t.push(`L${this.#l[e + 4]} ${this.#l[e + 5]}`);
                    continue;
                }
                t.push(`C${this.#l[e]} ${this.#l[e + 1]} ${this.#l[e + 2]} ${this.#l[e + 3]} ${this.#l[e + 4]} ${this.#l[e + 5]}`);
            }
            return t.push("Z"), t.join(" ");
        }
        serialize([t, e, s, i], n) {
            const r = s - t, a = i - e;
            let o, l;
            switch(n){
                case 0:
                    o = x._rescale(this.#l, t, i, r, -a), l = x._rescale(this.#r, t, i, r, -a);
                    break;
                case 90:
                    o = x._rescaleAndSwap(this.#l, t, e, r, a), l = x._rescaleAndSwap(this.#r, t, e, r, a);
                    break;
                case 180:
                    o = x._rescale(this.#l, s, e, -r, a), l = x._rescale(this.#r, s, e, -r, a);
                    break;
                case 270:
                    o = x._rescaleAndSwap(this.#l, s, i, -r, -a), l = x._rescaleAndSwap(this.#r, s, i, -r, -a);
                    break;
            }
            return {
                outline: Array.from(o),
                points: [
                    Array.from(l)
                ]
            };
        }
        #o(t) {
            const e = this.#l;
            let s = e[4], i = e[5];
            const n = [
                s,
                i,
                s,
                i
            ];
            let r = s, a = i;
            const o = t ? Math.max : Math.min;
            for(let h = 6, d = e.length; h < d; h += 6){
                const u = e[h + 4], f = e[h + 5];
                if (isNaN(e[h])) P.pointBoundingBox(u, f, n), a < f ? (r = u, a = f) : a === f && (r = o(r, u));
                else {
                    const g = [
                        1 / 0,
                        1 / 0,
                        -1 / 0,
                        -1 / 0
                    ];
                    P.bezierBoundingBox(s, i, ...e.slice(h, h + 6), g), P.rectBoundingBox(...g, n), a < g[3] ? (r = g[2], a = g[3]) : a === g[3] && (r = o(r, g[2]));
                }
                s = u, i = f;
            }
            const l = this.#e;
            l[0] = n[0] - this.#s, l[1] = n[1] - this.#s, l[2] = n[2] - n[0] + 2 * this.#s, l[3] = n[3] - n[1] + 2 * this.#s, this.lastPoint = [
                r,
                a
            ];
        }
        get box() {
            return this.#e;
        }
        newOutliner(t, e, s, i, n, r = 0) {
            return new kt(t, e, s, i, n, r);
        }
        getNewOutline(t, e) {
            const [s, i, n, r] = this.#e, [a, o, l, h] = this.#t, d = n * l, u = r * h, f = s * l + a, g = i * h + o, p = this.newOutliner({
                x: this.#r[0] * d + f,
                y: this.#r[1] * u + g
            }, this.#t, this.#n, t, this.#i, e ?? this.#s);
            for(let m = 2; m < this.#r.length; m += 2)p.add({
                x: this.#r[m] * d + f,
                y: this.#r[m + 1] * u + g
            });
            return p.getOutlines();
        }
    }
    class Ue {
        #t;
        #e;
        #s = [];
        #i = [];
        constructor(t, e = 0, s = 0, i = !0){
            const n = [
                1 / 0,
                1 / 0,
                -1 / 0,
                -1 / 0
            ], r = 10 ** -4;
            for (const { x: f, y: g, width: p, height: m } of t){
                const b = Math.floor((f - e) / r) * r, y = Math.ceil((f + p + e) / r) * r, A = Math.floor((g - e) / r) * r, v = Math.ceil((g + m + e) / r) * r, w = [
                    b,
                    A,
                    v,
                    !0
                ], _ = [
                    y,
                    A,
                    v,
                    !1
                ];
                this.#s.push(w, _), P.rectBoundingBox(b, A, y, v, n);
            }
            const a = n[2] - n[0] + 2 * s, o = n[3] - n[1] + 2 * s, l = n[0] - s, h = n[1] - s, d = this.#s.at(i ? -1 : -2), u = [
                d[0],
                d[2]
            ];
            for (const f of this.#s){
                const [g, p, m] = f;
                f[0] = (g - l) / a, f[1] = (p - h) / o, f[2] = (m - h) / o;
            }
            this.#t = new Float32Array([
                l,
                h,
                a,
                o
            ]), this.#e = u;
        }
        getOutlines() {
            this.#s.sort((e, s)=>e[0] - s[0] || e[1] - s[1] || e[2] - s[2]);
            const t = [];
            for (const e of this.#s)e[3] ? (t.push(...this.#d(e)), this.#l(e)) : (this.#o(e), t.push(...this.#d(e)));
            return this.#r(t);
        }
        #r(t) {
            const e = [], s = new Set;
            for (const r of t){
                const [a, o, l] = r;
                e.push([
                    a,
                    o,
                    r
                ], [
                    a,
                    l,
                    r
                ]);
            }
            e.sort((r, a)=>r[1] - a[1] || r[0] - a[0]);
            for(let r = 0, a = e.length; r < a; r += 2){
                const o = e[r][2], l = e[r + 1][2];
                o.push(l), l.push(o), s.add(o), s.add(l);
            }
            const i = [];
            let n;
            for(; s.size > 0;){
                const r = s.values().next().value;
                let [a, o, l, h, d] = r;
                s.delete(r);
                let u = a, f = o;
                for(n = [
                    a,
                    l
                ], i.push(n);;){
                    let g;
                    if (s.has(h)) g = h;
                    else if (s.has(d)) g = d;
                    else break;
                    s.delete(g), [a, o, l, h, d] = g, u !== a && (n.push(u, f, a, f === o ? o : l), u = a), f = f === o ? l : o;
                }
                n.push(u, f);
            }
            return new Jn(i, this.#t, this.#e);
        }
        #n(t) {
            const e = this.#i;
            let s = 0, i = e.length - 1;
            for(; s <= i;){
                const n = s + i >> 1, r = e[n][0];
                if (r === t) return n;
                r < t ? s = n + 1 : i = n - 1;
            }
            return i + 1;
        }
        #l([, t, e]) {
            const s = this.#n(t);
            this.#i.splice(s, 0, [
                t,
                e
            ]);
        }
        #o([, t, e]) {
            const s = this.#n(t);
            for(let i = s; i < this.#i.length; i++){
                const [n, r] = this.#i[i];
                if (n !== t) break;
                if (n === t && r === e) {
                    this.#i.splice(i, 1);
                    return;
                }
            }
            for(let i = s - 1; i >= 0; i--){
                const [n, r] = this.#i[i];
                if (n !== t) break;
                if (n === t && r === e) {
                    this.#i.splice(i, 1);
                    return;
                }
            }
        }
        #d(t) {
            const [e, s, i] = t, n = [
                [
                    e,
                    s,
                    i
                ]
            ], r = this.#n(i);
            for(let a = 0; a < r; a++){
                const [o, l] = this.#i[a];
                for(let h = 0, d = n.length; h < d; h++){
                    const [, u, f] = n[h];
                    if (!(l <= u || f <= o)) {
                        if (u >= o) {
                            if (f > l) n[h][1] = l;
                            else {
                                if (d === 1) return [];
                                n.splice(h, 1), h--, d--;
                            }
                            continue;
                        }
                        n[h][2] = o, f > l && n.push([
                            e,
                            l,
                            f
                        ]);
                    }
                }
            }
            return n;
        }
    }
    class Jn extends x {
        #t;
        #e;
        constructor(t, e, s){
            super(), this.#e = t, this.#t = e, this.lastPoint = s;
        }
        toSVGPath() {
            const t = [];
            for (const e of this.#e){
                let [s, i] = e;
                t.push(`M${s} ${i}`);
                for(let n = 2; n < e.length; n += 2){
                    const r = e[n], a = e[n + 1];
                    r === s ? (t.push(`V${a}`), i = a) : a === i && (t.push(`H${r}`), s = r);
                }
                t.push("Z");
            }
            return t.join(" ");
        }
        serialize([t, e, s, i], n) {
            const r = [], a = s - t, o = i - e;
            for (const l of this.#e){
                const h = new Array(l.length);
                for(let d = 0; d < l.length; d += 2)h[d] = t + l[d] * a, h[d + 1] = i - l[d + 1] * o;
                r.push(h);
            }
            return r;
        }
        get box() {
            return this.#t;
        }
        get classNamesForOutlining() {
            return [
                "highlightOutline"
            ];
        }
    }
    class je extends kt {
        newFreeDrawOutline(t, e, s, i, n, r) {
            return new Zn(t, e, s, i, n, r);
        }
    }
    class Zn extends ai {
        newOutliner(t, e, s, i, n, r = 0) {
            return new je(t, e, s, i, n, r);
        }
    }
    pt = class {
        #t = null;
        #e = null;
        #s;
        #i = null;
        #r = !1;
        #n = !1;
        #l = null;
        #o;
        #d = null;
        #h = null;
        #u;
        static #c = null;
        static get _keyboardManager() {
            return N(this, "_keyboardManager", new re([
                [
                    [
                        "Escape",
                        "mac+Escape"
                    ],
                    pt.prototype._hideDropdownFromKeyboard
                ],
                [
                    [
                        " ",
                        "mac+ "
                    ],
                    pt.prototype._colorSelectFromKeyboard
                ],
                [
                    [
                        "ArrowDown",
                        "ArrowRight",
                        "mac+ArrowDown",
                        "mac+ArrowRight"
                    ],
                    pt.prototype._moveToNext
                ],
                [
                    [
                        "ArrowUp",
                        "ArrowLeft",
                        "mac+ArrowUp",
                        "mac+ArrowLeft"
                    ],
                    pt.prototype._moveToPrevious
                ],
                [
                    [
                        "Home",
                        "mac+Home"
                    ],
                    pt.prototype._moveToBeginning
                ],
                [
                    [
                        "End",
                        "mac+End"
                    ],
                    pt.prototype._moveToEnd
                ]
            ]));
        }
        constructor({ editor: t = null, uiManager: e = null }){
            t ? (this.#n = !1, this.#u = O.HIGHLIGHT_COLOR, this.#l = t) : (this.#n = !0, this.#u = O.HIGHLIGHT_DEFAULT_COLOR), this.#h = t?._uiManager || e, this.#o = this.#h._eventBus, this.#s = t?.color || this.#h?.highlightColors.values().next().value || "#FFFF98", pt.#c ||= Object.freeze({
                blue: "pdfjs-editor-colorpicker-blue",
                green: "pdfjs-editor-colorpicker-green",
                pink: "pdfjs-editor-colorpicker-pink",
                red: "pdfjs-editor-colorpicker-red",
                yellow: "pdfjs-editor-colorpicker-yellow"
            });
        }
        renderButton() {
            const t = this.#t = document.createElement("button");
            t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.setAttribute("aria-haspopup", !0);
            const e = this.#h._signal;
            t.addEventListener("click", this.#m.bind(this), {
                signal: e
            }), t.addEventListener("keydown", this.#p.bind(this), {
                signal: e
            });
            const s = this.#e = document.createElement("span");
            return s.className = "swatch", s.setAttribute("aria-hidden", !0), s.style.backgroundColor = this.#s, t.append(s), t;
        }
        renderMainDropdown() {
            const t = this.#i = this.#f();
            return t.setAttribute("aria-orientation", "horizontal"), t.setAttribute("aria-labelledby", "highlightColorPickerLabel"), t;
        }
        #f() {
            const t = document.createElement("div"), e = this.#h._signal;
            t.addEventListener("contextmenu", gt, {
                signal: e
            }), t.className = "dropdown", t.role = "listbox", t.setAttribute("aria-multiselectable", !1), t.setAttribute("aria-orientation", "vertical"), t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown");
            for (const [s, i] of this.#h.highlightColors){
                const n = document.createElement("button");
                n.tabIndex = "0", n.role = "option", n.setAttribute("data-color", i), n.title = s, n.setAttribute("data-l10n-id", pt.#c[s]);
                const r = document.createElement("span");
                n.append(r), r.className = "swatch", r.style.backgroundColor = i, n.setAttribute("aria-selected", i === this.#s), n.addEventListener("click", this.#a.bind(this, i), {
                    signal: e
                }), t.append(n);
            }
            return t.addEventListener("keydown", this.#p.bind(this), {
                signal: e
            }), t;
        }
        #a(t, e) {
            e.stopPropagation(), this.#o.dispatch("switchannotationeditorparams", {
                source: this,
                type: this.#u,
                value: t
            });
        }
        _colorSelectFromKeyboard(t) {
            if (t.target === this.#t) {
                this.#m(t);
                return;
            }
            const e = t.target.getAttribute("data-color");
            e && this.#a(e, t);
        }
        _moveToNext(t) {
            if (!this.#b) {
                this.#m(t);
                return;
            }
            if (t.target === this.#t) {
                this.#i.firstChild?.focus();
                return;
            }
            t.target.nextSibling?.focus();
        }
        _moveToPrevious(t) {
            if (t.target === this.#i?.firstChild || t.target === this.#t) {
                this.#b && this._hideDropdownFromKeyboard();
                return;
            }
            this.#b || this.#m(t), t.target.previousSibling?.focus();
        }
        _moveToBeginning(t) {
            if (!this.#b) {
                this.#m(t);
                return;
            }
            this.#i.firstChild?.focus();
        }
        _moveToEnd(t) {
            if (!this.#b) {
                this.#m(t);
                return;
            }
            this.#i.lastChild?.focus();
        }
        #p(t) {
            pt._keyboardManager.exec(this, t);
        }
        #m(t) {
            if (this.#b) {
                this.hideDropdown();
                return;
            }
            if (this.#r = t.detail === 0, this.#d || (this.#d = new AbortController, window.addEventListener("pointerdown", this.#g.bind(this), {
                signal: this.#h.combinedSignal(this.#d)
            })), this.#i) {
                this.#i.classList.remove("hidden");
                return;
            }
            const e = this.#i = this.#f();
            this.#t.append(e);
        }
        #g(t) {
            this.#i?.contains(t.target) || this.hideDropdown();
        }
        hideDropdown() {
            this.#i?.classList.add("hidden"), this.#d?.abort(), this.#d = null;
        }
        get #b() {
            return this.#i && !this.#i.classList.contains("hidden");
        }
        _hideDropdownFromKeyboard() {
            if (!this.#n) {
                if (!this.#b) {
                    this.#l?.unselect();
                    return;
                }
                this.hideDropdown(), this.#t.focus({
                    preventScroll: !0,
                    focusVisible: this.#r
                });
            }
        }
        updateColor(t) {
            if (this.#e && (this.#e.style.backgroundColor = t), !this.#i) return;
            const e = this.#h.highlightColors.values();
            for (const s of this.#i.children)s.setAttribute("aria-selected", e.next().value === t);
        }
        destroy() {
            this.#t?.remove(), this.#t = null, this.#e = null, this.#i?.remove(), this.#i = null;
        }
    };
    class V extends k {
        #t = null;
        #e = 0;
        #s;
        #i = null;
        #r = null;
        #n = null;
        #l = null;
        #o = 0;
        #d = null;
        #h = null;
        #u = null;
        #c = !1;
        #f = null;
        #a;
        #p = null;
        #m = "";
        #g;
        #b = "";
        static _defaultColor = null;
        static _defaultOpacity = 1;
        static _defaultThickness = 12;
        static _type = "highlight";
        static _editorType = D.HIGHLIGHT;
        static _freeHighlightId = -1;
        static _freeHighlight = null;
        static _freeHighlightClipId = "";
        static get _keyboardManager() {
            const t = V.prototype;
            return N(this, "_keyboardManager", new re([
                [
                    [
                        "ArrowLeft",
                        "mac+ArrowLeft"
                    ],
                    t._moveCaret,
                    {
                        args: [
                            0
                        ]
                    }
                ],
                [
                    [
                        "ArrowRight",
                        "mac+ArrowRight"
                    ],
                    t._moveCaret,
                    {
                        args: [
                            1
                        ]
                    }
                ],
                [
                    [
                        "ArrowUp",
                        "mac+ArrowUp"
                    ],
                    t._moveCaret,
                    {
                        args: [
                            2
                        ]
                    }
                ],
                [
                    [
                        "ArrowDown",
                        "mac+ArrowDown"
                    ],
                    t._moveCaret,
                    {
                        args: [
                            3
                        ]
                    }
                ]
            ]));
        }
        constructor(t){
            super({
                ...t,
                name: "highlightEditor"
            }), this.color = t.color || V._defaultColor, this.#g = t.thickness || V._defaultThickness, this.#a = t.opacity || V._defaultOpacity, this.#s = t.boxes || null, this.#b = t.methodOfCreation || "", this.#m = t.text || "", this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", t.highlightId > -1 ? (this.#c = !0, this.#y(t), this.#R()) : this.#s && (this.#t = t.anchorNode, this.#e = t.anchorOffset, this.#l = t.focusNode, this.#o = t.focusOffset, this.#A(), this.#R(), this.rotate(this.rotation));
        }
        get telemetryInitialData() {
            return {
                action: "added",
                type: this.#c ? "free_highlight" : "highlight",
                color: this._uiManager.highlightColorNames.get(this.color),
                thickness: this.#g,
                methodOfCreation: this.#b
            };
        }
        get telemetryFinalData() {
            return {
                type: "highlight",
                color: this._uiManager.highlightColorNames.get(this.color)
            };
        }
        static computeTelemetryFinalData(t) {
            return {
                numberOfColors: t.get("color").size
            };
        }
        #A() {
            const t = new Ue(this.#s, .001);
            this.#h = t.getOutlines(), [this.x, this.y, this.width, this.height] = this.#h.box;
            const e = new Ue(this.#s, .0025, .001, this._uiManager.direction === "ltr");
            this.#n = e.getOutlines();
            const { lastPoint: s } = this.#n;
            this.#f = [
                (s[0] - this.x) / this.width,
                (s[1] - this.y) / this.height
            ];
        }
        #y({ highlightOutlines: t, highlightId: e, clipPathId: s }) {
            this.#h = t;
            const i = 1.5;
            if (this.#n = t.getNewOutline(this.#g / 2 + i, .0025), e >= 0) this.#u = e, this.#i = s, this.parent.drawLayer.finalizeDraw(e, {
                bbox: t.box,
                path: {
                    d: t.toSVGPath()
                }
            }), this.#p = this.parent.drawLayer.drawOutline({
                rootClass: {
                    highlightOutline: !0,
                    free: !0
                },
                bbox: this.#n.box,
                path: {
                    d: this.#n.toSVGPath()
                }
            }, !0);
            else if (this.parent) {
                const h = this.parent.viewport.rotation;
                this.parent.drawLayer.updateProperties(this.#u, {
                    bbox: V.#_(this.#h.box, (h - this.rotation + 360) % 360),
                    path: {
                        d: t.toSVGPath()
                    }
                }), this.parent.drawLayer.updateProperties(this.#p, {
                    bbox: V.#_(this.#n.box, h),
                    path: {
                        d: this.#n.toSVGPath()
                    }
                });
            }
            const [n, r, a, o] = t.box;
            switch(this.rotation){
                case 0:
                    this.x = n, this.y = r, this.width = a, this.height = o;
                    break;
                case 90:
                    {
                        const [h, d] = this.parentDimensions;
                        this.x = r, this.y = 1 - n, this.width = a * d / h, this.height = o * h / d;
                        break;
                    }
                case 180:
                    this.x = 1 - n, this.y = 1 - r, this.width = a, this.height = o;
                    break;
                case 270:
                    {
                        const [h, d] = this.parentDimensions;
                        this.x = 1 - r, this.y = n, this.width = a * d / h, this.height = o * h / d;
                        break;
                    }
            }
            const { lastPoint: l } = this.#n;
            this.#f = [
                (l[0] - n) / a,
                (l[1] - r) / o
            ];
        }
        static initialize(t, e) {
            k.initialize(t, e), V._defaultColor ||= e.highlightColors?.values().next().value || "#fff066";
        }
        static updateDefaultParams(t, e) {
            switch(t){
                case O.HIGHLIGHT_DEFAULT_COLOR:
                    V._defaultColor = e;
                    break;
                case O.HIGHLIGHT_THICKNESS:
                    V._defaultThickness = e;
                    break;
            }
        }
        translateInPage(t, e) {}
        get toolbarPosition() {
            return this.#f;
        }
        updateParams(t, e) {
            switch(t){
                case O.HIGHLIGHT_COLOR:
                    this.#v(e);
                    break;
                case O.HIGHLIGHT_THICKNESS:
                    this.#S(e);
                    break;
            }
        }
        static get defaultPropertiesToUpdate() {
            return [
                [
                    O.HIGHLIGHT_DEFAULT_COLOR,
                    V._defaultColor
                ],
                [
                    O.HIGHLIGHT_THICKNESS,
                    V._defaultThickness
                ]
            ];
        }
        get propertiesToUpdate() {
            return [
                [
                    O.HIGHLIGHT_COLOR,
                    this.color || V._defaultColor
                ],
                [
                    O.HIGHLIGHT_THICKNESS,
                    this.#g || V._defaultThickness
                ],
                [
                    O.HIGHLIGHT_FREE,
                    this.#c
                ]
            ];
        }
        #v(t) {
            const e = (n, r)=>{
                this.color = n, this.#a = r, this.parent?.drawLayer.updateProperties(this.#u, {
                    root: {
                        fill: n,
                        "fill-opacity": r
                    }
                }), this.#r?.updateColor(n);
            }, s = this.color, i = this.#a;
            this.addCommands({
                cmd: e.bind(this, t, V._defaultOpacity),
                undo: e.bind(this, s, i),
                post: this._uiManager.updateUI.bind(this._uiManager, this),
                mustExec: !0,
                type: O.HIGHLIGHT_COLOR,
                overwriteIfSameType: !0,
                keepUndo: !0
            }), this._reportTelemetry({
                action: "color_changed",
                color: this._uiManager.highlightColorNames.get(t)
            }, !0);
        }
        #S(t) {
            const e = this.#g, s = (i)=>{
                this.#g = i, this.#C(i);
            };
            this.addCommands({
                cmd: s.bind(this, t),
                undo: s.bind(this, e),
                post: this._uiManager.updateUI.bind(this._uiManager, this),
                mustExec: !0,
                type: O.INK_THICKNESS,
                overwriteIfSameType: !0,
                keepUndo: !0
            }), this._reportTelemetry({
                action: "thickness_changed",
                thickness: t
            }, !0);
        }
        async addEditToolbar() {
            const t = await super.addEditToolbar();
            return t ? (this._uiManager.highlightColors && (this.#r = new pt({
                editor: this
            }), t.addColorPicker(this.#r)), t) : null;
        }
        disableEditing() {
            super.disableEditing(), this.div.classList.toggle("disabled", !0);
        }
        enableEditing() {
            super.enableEditing(), this.div.classList.toggle("disabled", !1);
        }
        fixAndSetPosition() {
            return super.fixAndSetPosition(this.#k());
        }
        getBaseTranslation() {
            return [
                0,
                0
            ];
        }
        getRect(t, e) {
            return super.getRect(t, e, this.#k());
        }
        onceAdded(t) {
            this.annotationElementId || this.parent.addUndoableEditor(this), t && this.div.focus();
        }
        remove() {
            this.#T(), this._reportTelemetry({
                action: "deleted"
            }), super.remove();
        }
        rebuild() {
            this.parent && (super.rebuild(), this.div !== null && (this.#R(), this.isAttachedToDOM || this.parent.add(this)));
        }
        setParent(t) {
            let e = !1;
            this.parent && !t ? this.#T() : t && (this.#R(t), e = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), this.show(this._isVisible), e && this.select();
        }
        #C(t) {
            if (!this.#c) return;
            this.#y({
                highlightOutlines: this.#h.getNewOutline(t / 2)
            }), this.fixAndSetPosition();
            const [e, s] = this.parentDimensions;
            this.setDims(this.width * e, this.height * s);
        }
        #T() {
            this.#u === null || !this.parent || (this.parent.drawLayer.remove(this.#u), this.#u = null, this.parent.drawLayer.remove(this.#p), this.#p = null);
        }
        #R(t = this.parent) {
            this.#u === null && ({ id: this.#u, clipPathId: this.#i } = t.drawLayer.draw({
                bbox: this.#h.box,
                root: {
                    viewBox: "0 0 1 1",
                    fill: this.color,
                    "fill-opacity": this.#a
                },
                rootClass: {
                    highlight: !0,
                    free: this.#c
                },
                path: {
                    d: this.#h.toSVGPath()
                }
            }, !1, !0), this.#p = t.drawLayer.drawOutline({
                rootClass: {
                    highlightOutline: !0,
                    free: this.#c
                },
                bbox: this.#n.box,
                path: {
                    d: this.#n.toSVGPath()
                }
            }, this.#c), this.#d && (this.#d.style.clipPath = this.#i));
        }
        static #_([t, e, s, i], n) {
            switch(n){
                case 90:
                    return [
                        1 - e - i,
                        t,
                        i,
                        s
                    ];
                case 180:
                    return [
                        1 - t - s,
                        1 - e - i,
                        s,
                        i
                    ];
                case 270:
                    return [
                        e,
                        1 - t - s,
                        i,
                        s
                    ];
            }
            return [
                t,
                e,
                s,
                i
            ];
        }
        rotate(t) {
            const { drawLayer: e } = this.parent;
            let s;
            this.#c ? (t = (t - this.rotation + 360) % 360, s = V.#_(this.#h.box, t)) : s = V.#_([
                this.x,
                this.y,
                this.width,
                this.height
            ], t), e.updateProperties(this.#u, {
                bbox: s,
                root: {
                    "data-main-rotation": t
                }
            }), e.updateProperties(this.#p, {
                bbox: V.#_(this.#n.box, t),
                root: {
                    "data-main-rotation": t
                }
            });
        }
        render() {
            if (this.div) return this.div;
            const t = super.render();
            this.#m && (t.setAttribute("aria-label", this.#m), t.setAttribute("role", "mark")), this.#c ? t.classList.add("free") : this.div.addEventListener("keydown", this.#P.bind(this), {
                signal: this._uiManager._signal
            });
            const e = this.#d = document.createElement("div");
            t.append(e), e.setAttribute("aria-hidden", "true"), e.className = "internal", e.style.clipPath = this.#i;
            const [s, i] = this.parentDimensions;
            return this.setDims(this.width * s, this.height * i), Ke(this, this.#d, [
                "pointerover",
                "pointerleave"
            ]), this.enableEditing(), t;
        }
        pointerover() {
            this.isSelected || this.parent?.drawLayer.updateProperties(this.#p, {
                rootClass: {
                    hovered: !0
                }
            });
        }
        pointerleave() {
            this.isSelected || this.parent?.drawLayer.updateProperties(this.#p, {
                rootClass: {
                    hovered: !1
                }
            });
        }
        #P(t) {
            V._keyboardManager.exec(this, t);
        }
        _moveCaret(t) {
            switch(this.parent.unselect(this), t){
                case 0:
                case 2:
                    this.#x(!0);
                    break;
                case 1:
                case 3:
                    this.#x(!1);
                    break;
            }
        }
        #x(t) {
            if (!this.#t) return;
            const e = window.getSelection();
            t ? e.setPosition(this.#t, this.#e) : e.setPosition(this.#l, this.#o);
        }
        select() {
            super.select(), this.#p && this.parent?.drawLayer.updateProperties(this.#p, {
                rootClass: {
                    hovered: !1,
                    selected: !0
                }
            });
        }
        unselect() {
            super.unselect(), this.#p && (this.parent?.drawLayer.updateProperties(this.#p, {
                rootClass: {
                    selected: !1
                }
            }), this.#c || this.#x(!1));
        }
        get _mustFixPosition() {
            return !this.#c;
        }
        show(t = this._isVisible) {
            super.show(t), this.parent && (this.parent.drawLayer.updateProperties(this.#u, {
                rootClass: {
                    hidden: !t
                }
            }), this.parent.drawLayer.updateProperties(this.#p, {
                rootClass: {
                    hidden: !t
                }
            }));
        }
        #k() {
            return this.#c ? this.rotation : 0;
        }
        #M() {
            if (this.#c) return null;
            const [t, e] = this.pageDimensions, [s, i] = this.pageTranslation, n = this.#s, r = new Float32Array(n.length * 8);
            let a = 0;
            for (const { x: o, y: l, width: h, height: d } of n){
                const u = o * t + s, f = (1 - l) * e + i;
                r[a] = r[a + 4] = u, r[a + 1] = r[a + 3] = f, r[a + 2] = r[a + 6] = u + h * t, r[a + 5] = r[a + 7] = f - d * e, a += 8;
            }
            return r;
        }
        #L(t) {
            return this.#h.serialize(t, this.#k());
        }
        static startHighlighting(t, e, { target: s, x: i, y: n }) {
            const { x: r, y: a, width: o, height: l } = s.getBoundingClientRect(), h = new AbortController, d = t.combinedSignal(h), u = (f)=>{
                h.abort(), this.#E(t, f);
            };
            window.addEventListener("blur", u, {
                signal: d
            }), window.addEventListener("pointerup", u, {
                signal: d
            }), window.addEventListener("pointerdown", Y, {
                capture: !0,
                passive: !1,
                signal: d
            }), window.addEventListener("contextmenu", gt, {
                signal: d
            }), s.addEventListener("pointermove", this.#$.bind(this, t), {
                signal: d
            }), this._freeHighlight = new je({
                x: i,
                y: n
            }, [
                r,
                a,
                o,
                l
            ], t.scale, this._defaultThickness / 2, e, .001), { id: this._freeHighlightId, clipPathId: this._freeHighlightClipId } = t.drawLayer.draw({
                bbox: [
                    0,
                    0,
                    1,
                    1
                ],
                root: {
                    viewBox: "0 0 1 1",
                    fill: this._defaultColor,
                    "fill-opacity": this._defaultOpacity
                },
                rootClass: {
                    highlight: !0,
                    free: !0
                },
                path: {
                    d: this._freeHighlight.toSVGPath()
                }
            }, !0, !0);
        }
        static #$(t, e) {
            this._freeHighlight.add(e) && t.drawLayer.updateProperties(this._freeHighlightId, {
                path: {
                    d: this._freeHighlight.toSVGPath()
                }
            });
        }
        static #E(t, e) {
            this._freeHighlight.isEmpty() ? t.drawLayer.remove(this._freeHighlightId) : t.createAndAddNewEditor(e, !1, {
                highlightId: this._freeHighlightId,
                highlightOutlines: this._freeHighlight.getOutlines(),
                clipPathId: this._freeHighlightClipId,
                methodOfCreation: "main_toolbar"
            }), this._freeHighlightId = -1, this._freeHighlight = null, this._freeHighlightClipId = "";
        }
        static async deserialize(t, e, s) {
            let i = null;
            if (t instanceof ni) {
                const { data: { quadPoints: g, rect: p, rotation: m, id: b, color: y, opacity: A, popupRef: v }, parent: { page: { pageNumber: w } } } = t;
                i = t = {
                    annotationType: D.HIGHLIGHT,
                    color: Array.from(y),
                    opacity: A,
                    quadPoints: g,
                    boxes: null,
                    pageIndex: w - 1,
                    rect: p.slice(0),
                    rotation: m,
                    id: b,
                    deleted: !1,
                    popupRef: v
                };
            } else if (t instanceof ns) {
                const { data: { inkLists: g, rect: p, rotation: m, id: b, color: y, borderStyle: { rawWidth: A }, popupRef: v }, parent: { page: { pageNumber: w } } } = t;
                i = t = {
                    annotationType: D.HIGHLIGHT,
                    color: Array.from(y),
                    thickness: A,
                    inkLists: g,
                    boxes: null,
                    pageIndex: w - 1,
                    rect: p.slice(0),
                    rotation: m,
                    id: b,
                    deleted: !1,
                    popupRef: v
                };
            }
            const { color: n, quadPoints: r, inkLists: a, opacity: o } = t, l = await super.deserialize(t, e, s);
            l.color = P.makeHexColor(...n), l.#a = o || 1, a && (l.#g = t.thickness), l.annotationElementId = t.id || null, l._initialData = i;
            const [h, d] = l.pageDimensions, [u, f] = l.pageTranslation;
            if (r) {
                const g = l.#s = [];
                for(let p = 0; p < r.length; p += 8)g.push({
                    x: (r[p] - u) / h,
                    y: 1 - (r[p + 1] - f) / d,
                    width: (r[p + 2] - r[p]) / h,
                    height: (r[p + 1] - r[p + 5]) / d
                });
                l.#A(), l.#R(), l.rotate(l.rotation);
            } else if (a) {
                l.#c = !0;
                const g = a[0], p = {
                    x: g[0] - u,
                    y: d - (g[1] - f)
                }, m = new je(p, [
                    0,
                    0,
                    h,
                    d
                ], 1, l.#g / 2, !0, .001);
                for(let A = 0, v = g.length; A < v; A += 2)p.x = g[A] - u, p.y = d - (g[A + 1] - f), m.add(p);
                const { id: b, clipPathId: y } = e.drawLayer.draw({
                    bbox: [
                        0,
                        0,
                        1,
                        1
                    ],
                    root: {
                        viewBox: "0 0 1 1",
                        fill: l.color,
                        "fill-opacity": l._defaultOpacity
                    },
                    rootClass: {
                        highlight: !0,
                        free: !0
                    },
                    path: {
                        d: m.toSVGPath()
                    }
                }, !0, !0);
                l.#y({
                    highlightOutlines: m.getOutlines(),
                    highlightId: b,
                    clipPathId: y
                }), l.#R(), l.rotate(l.parentRotation);
            }
            return l;
        }
        serialize(t = !1) {
            if (this.isEmpty() || t) return null;
            if (this.deleted) return this.serializeDeleted();
            const e = this.getRect(0, 0), s = k._colorManager.convert(this.color), i = {
                annotationType: D.HIGHLIGHT,
                color: s,
                opacity: this.#a,
                thickness: this.#g,
                quadPoints: this.#M(),
                outlines: this.#L(e),
                pageIndex: this.pageIndex,
                rect: e,
                rotation: this.#k(),
                structTreeParentId: this._structTreeParentId
            };
            return this.annotationElementId && !this.#w(i) ? null : (i.id = this.annotationElementId, i);
        }
        #w(t) {
            const { color: e } = this._initialData;
            return t.color.some((s, i)=>s !== e[i]);
        }
        renderAnnotationElement(t) {
            return t.updateEdited({
                rect: this.getRect(0, 0)
            }), null;
        }
        static canCreateNewEmptyEditor() {
            return !1;
        }
    }
    class oi {
        #t = Object.create(null);
        updateProperty(t, e) {
            this[t] = e, this.updateSVGProperty(t, e);
        }
        updateProperties(t) {
            if (t) for (const [e, s] of Object.entries(t))e.startsWith("_") || this.updateProperty(e, s);
        }
        updateSVGProperty(t, e) {
            this.#t[t] = e;
        }
        toSVGProperties() {
            const t = this.#t;
            return this.#t = Object.create(null), {
                root: t
            };
        }
        reset() {
            this.#t = Object.create(null);
        }
        updateAll(t = this) {
            this.updateProperties(t);
        }
        clone() {
            $("Not implemented");
        }
    }
    class L extends k {
        #t = null;
        #e;
        _drawId = null;
        static _currentDrawId = -1;
        static _currentParent = null;
        static #s = null;
        static #i = null;
        static #r = null;
        static #n = NaN;
        static #l = null;
        static #o = null;
        static #d = NaN;
        static _INNER_MARGIN = 3;
        constructor(t){
            super(t), this.#e = t.mustBeCommitted || !1, this._addOutlines(t);
        }
        _addOutlines(t) {
            t.drawOutlines && (this.#h(t), this.#f());
        }
        #h({ drawOutlines: t, drawId: e, drawingOptions: s }) {
            this.#t = t, this._drawingOptions ||= s, e >= 0 ? (this._drawId = e, this.parent.drawLayer.finalizeDraw(e, t.defaultProperties)) : this._drawId = this.#u(t, this.parent), this.#m(t.box);
        }
        #u(t, e) {
            const { id: s } = e.drawLayer.draw(L._mergeSVGProperties(this._drawingOptions.toSVGProperties(), t.defaultSVGProperties), !1, !1);
            return s;
        }
        static _mergeSVGProperties(t, e) {
            const s = new Set(Object.keys(t));
            for (const [i, n] of Object.entries(e))s.has(i) ? Object.assign(t[i], n) : t[i] = n;
            return t;
        }
        static getDefaultDrawingOptions(t) {
            $("Not implemented");
        }
        static get typesMap() {
            $("Not implemented");
        }
        static get isDrawer() {
            return !0;
        }
        static get supportMultipleDrawings() {
            return !1;
        }
        static updateDefaultParams(t, e) {
            const s = this.typesMap.get(t);
            s && this._defaultDrawingOptions.updateProperty(s, e), this._currentParent && (L.#s.updateProperty(s, e), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
        }
        updateParams(t, e) {
            const s = this.constructor.typesMap.get(t);
            s && this._updateProperty(t, s, e);
        }
        static get defaultPropertiesToUpdate() {
            const t = [], e = this._defaultDrawingOptions;
            for (const [s, i] of this.typesMap)t.push([
                s,
                e[i]
            ]);
            return t;
        }
        get propertiesToUpdate() {
            const t = [], { _drawingOptions: e } = this;
            for (const [s, i] of this.constructor.typesMap)t.push([
                s,
                e[i]
            ]);
            return t;
        }
        _updateProperty(t, e, s) {
            const i = this._drawingOptions, n = i[e], r = (a)=>{
                i.updateProperty(e, a);
                const o = this.#t.updateProperty(e, a);
                o && this.#m(o), this.parent?.drawLayer.updateProperties(this._drawId, i.toSVGProperties());
            };
            this.addCommands({
                cmd: r.bind(this, s),
                undo: r.bind(this, n),
                post: this._uiManager.updateUI.bind(this._uiManager, this),
                mustExec: !0,
                type: t,
                overwriteIfSameType: !0,
                keepUndo: !0
            });
        }
        _onResizing() {
            this.parent?.drawLayer.updateProperties(this._drawId, L._mergeSVGProperties(this.#t.getPathResizingSVGProperties(this.#p()), {
                bbox: this.#g()
            }));
        }
        _onResized() {
            this.parent?.drawLayer.updateProperties(this._drawId, L._mergeSVGProperties(this.#t.getPathResizedSVGProperties(this.#p()), {
                bbox: this.#g()
            }));
        }
        _onTranslating(t, e) {
            this.parent?.drawLayer.updateProperties(this._drawId, {
                bbox: this.#g()
            });
        }
        _onTranslated() {
            this.parent?.drawLayer.updateProperties(this._drawId, L._mergeSVGProperties(this.#t.getPathTranslatedSVGProperties(this.#p(), this.parentDimensions), {
                bbox: this.#g()
            }));
        }
        _onStartDragging() {
            this.parent?.drawLayer.updateProperties(this._drawId, {
                rootClass: {
                    moving: !0
                }
            });
        }
        _onStopDragging() {
            this.parent?.drawLayer.updateProperties(this._drawId, {
                rootClass: {
                    moving: !1
                }
            });
        }
        commit() {
            super.commit(), this.disableEditMode(), this.disableEditing();
        }
        disableEditing() {
            super.disableEditing(), this.div.classList.toggle("disabled", !0);
        }
        enableEditing() {
            super.enableEditing(), this.div.classList.toggle("disabled", !1);
        }
        getBaseTranslation() {
            return [
                0,
                0
            ];
        }
        get isResizable() {
            return !0;
        }
        onceAdded(t) {
            this.annotationElementId || this.parent.addUndoableEditor(this), this._isDraggable = !0, this.#e && (this.#e = !1, this.commit(), this.parent.setSelected(this), t && this.isOnScreen && this.div.focus());
        }
        remove() {
            this.#c(), super.remove();
        }
        rebuild() {
            this.parent && (super.rebuild(), this.div !== null && (this.#f(), this.#m(this.#t.box), this.isAttachedToDOM || this.parent.add(this)));
        }
        setParent(t) {
            let e = !1;
            this.parent && !t ? (this._uiManager.removeShouldRescale(this), this.#c()) : t && (this._uiManager.addShouldRescale(this), this.#f(t), e = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), e && this.select();
        }
        #c() {
            this._drawId === null || !this.parent || (this.parent.drawLayer.remove(this._drawId), this._drawId = null, this._drawingOptions.reset());
        }
        #f(t = this.parent) {
            if (!(this._drawId !== null && this.parent === t)) {
                if (this._drawId !== null) {
                    this.parent.drawLayer.updateParent(this._drawId, t.drawLayer);
                    return;
                }
                this._drawingOptions.updateAll(), this._drawId = this.#u(this.#t, t);
            }
        }
        #a([t, e, s, i]) {
            const { parentDimensions: [n, r], rotation: a } = this;
            switch(a){
                case 90:
                    return [
                        e,
                        1 - t,
                        s * (r / n),
                        i * (n / r)
                    ];
                case 180:
                    return [
                        1 - t,
                        1 - e,
                        s,
                        i
                    ];
                case 270:
                    return [
                        1 - e,
                        t,
                        s * (r / n),
                        i * (n / r)
                    ];
                default:
                    return [
                        t,
                        e,
                        s,
                        i
                    ];
            }
        }
        #p() {
            const { x: t, y: e, width: s, height: i, parentDimensions: [n, r], rotation: a } = this;
            switch(a){
                case 90:
                    return [
                        1 - e,
                        t,
                        s * (n / r),
                        i * (r / n)
                    ];
                case 180:
                    return [
                        1 - t,
                        1 - e,
                        s,
                        i
                    ];
                case 270:
                    return [
                        e,
                        1 - t,
                        s * (n / r),
                        i * (r / n)
                    ];
                default:
                    return [
                        t,
                        e,
                        s,
                        i
                    ];
            }
        }
        #m(t) {
            if ([this.x, this.y, this.width, this.height] = this.#a(t), this.div) {
                this.fixAndSetPosition();
                const [e, s] = this.parentDimensions;
                this.setDims(this.width * e, this.height * s);
            }
            this._onResized();
        }
        #g() {
            const { x: t, y: e, width: s, height: i, rotation: n, parentRotation: r, parentDimensions: [a, o] } = this;
            switch((n * 4 + r) / 90){
                case 1:
                    return [
                        1 - e - i,
                        t,
                        i,
                        s
                    ];
                case 2:
                    return [
                        1 - t - s,
                        1 - e - i,
                        s,
                        i
                    ];
                case 3:
                    return [
                        e,
                        1 - t - s,
                        i,
                        s
                    ];
                case 4:
                    return [
                        t,
                        e - s * (a / o),
                        i * (o / a),
                        s * (a / o)
                    ];
                case 5:
                    return [
                        1 - e,
                        t,
                        s * (a / o),
                        i * (o / a)
                    ];
                case 6:
                    return [
                        1 - t - i * (o / a),
                        1 - e,
                        i * (o / a),
                        s * (a / o)
                    ];
                case 7:
                    return [
                        e - s * (a / o),
                        1 - t - i * (o / a),
                        s * (a / o),
                        i * (o / a)
                    ];
                case 8:
                    return [
                        t - s,
                        e - i,
                        s,
                        i
                    ];
                case 9:
                    return [
                        1 - e,
                        t - s,
                        i,
                        s
                    ];
                case 10:
                    return [
                        1 - t,
                        1 - e,
                        s,
                        i
                    ];
                case 11:
                    return [
                        e - i,
                        1 - t,
                        i,
                        s
                    ];
                case 12:
                    return [
                        t - i * (o / a),
                        e,
                        i * (o / a),
                        s * (a / o)
                    ];
                case 13:
                    return [
                        1 - e - s * (a / o),
                        t - i * (o / a),
                        s * (a / o),
                        i * (o / a)
                    ];
                case 14:
                    return [
                        1 - t,
                        1 - e - s * (a / o),
                        i * (o / a),
                        s * (a / o)
                    ];
                case 15:
                    return [
                        e,
                        1 - t,
                        s * (a / o),
                        i * (o / a)
                    ];
                default:
                    return [
                        t,
                        e,
                        s,
                        i
                    ];
            }
        }
        rotate() {
            this.parent && this.parent.drawLayer.updateProperties(this._drawId, L._mergeSVGProperties({
                bbox: this.#g()
            }, this.#t.updateRotation((this.parentRotation - this.rotation + 360) % 360)));
        }
        onScaleChanging() {
            this.parent && this.#m(this.#t.updateParentDimensions(this.parentDimensions, this.parent.scale));
        }
        static onScaleChangingWhenDrawing() {}
        render() {
            if (this.div) return this.div;
            let t, e;
            this._isCopy && (t = this.x, e = this.y);
            const s = super.render();
            s.classList.add("draw");
            const i = document.createElement("div");
            s.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal";
            const [n, r] = this.parentDimensions;
            return this.setDims(this.width * n, this.height * r), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(t, e), s;
        }
        static createDrawerInstance(t, e, s, i, n) {
            $("Not implemented");
        }
        static startDrawing(t, e, s, i) {
            const { target: n, offsetX: r, offsetY: a, pointerId: o, pointerType: l } = i;
            if (L.#l && L.#l !== l) return;
            const { viewport: { rotation: h } } = t, { width: d, height: u } = n.getBoundingClientRect(), f = L.#i = new AbortController, g = t.combinedSignal(f);
            if (L.#n ||= o, L.#l ??= l, window.addEventListener("pointerup", (p)=>{
                L.#n === p.pointerId ? this._endDraw(p) : L.#o?.delete(p.pointerId);
            }, {
                signal: g
            }), window.addEventListener("pointercancel", (p)=>{
                L.#n === p.pointerId ? this._currentParent.endDrawingSession() : L.#o?.delete(p.pointerId);
            }, {
                signal: g
            }), window.addEventListener("pointerdown", (p)=>{
                L.#l === p.pointerType && ((L.#o ||= new Set).add(p.pointerId), L.#s.isCancellable() && (L.#s.removeLastElement(), L.#s.isEmpty() ? this._currentParent.endDrawingSession(!0) : this._endDraw(null)));
            }, {
                capture: !0,
                passive: !1,
                signal: g
            }), window.addEventListener("contextmenu", gt, {
                signal: g
            }), n.addEventListener("pointermove", this._drawMove.bind(this), {
                signal: g
            }), n.addEventListener("touchmove", (p)=>{
                p.timeStamp === L.#d && Y(p);
            }, {
                signal: g
            }), t.toggleDrawing(), e._editorUndoBar?.hide(), L.#s) {
                t.drawLayer.updateProperties(this._currentDrawId, L.#s.startNew(r, a, d, u, h));
                return;
            }
            e.updateUIForDefaultProperties(this), L.#s = this.createDrawerInstance(r, a, d, u, h), L.#r = this.getDefaultDrawingOptions(), this._currentParent = t, { id: this._currentDrawId } = t.drawLayer.draw(this._mergeSVGProperties(L.#r.toSVGProperties(), L.#s.defaultSVGProperties), !0, !1);
        }
        static _drawMove(t) {
            if (L.#d = -1, !L.#s) return;
            const { offsetX: e, offsetY: s, pointerId: i } = t;
            if (L.#n === i) {
                if (L.#o?.size >= 1) {
                    this._endDraw(t);
                    return;
                }
                this._currentParent.drawLayer.updateProperties(this._currentDrawId, L.#s.add(e, s)), L.#d = t.timeStamp, Y(t);
            }
        }
        static _cleanup(t) {
            t && (this._currentDrawId = -1, this._currentParent = null, L.#s = null, L.#r = null, L.#l = null, L.#d = NaN), L.#i && (L.#i.abort(), L.#i = null, L.#n = NaN, L.#o = null);
        }
        static _endDraw(t) {
            const e = this._currentParent;
            if (e) {
                if (e.toggleDrawing(!0), this._cleanup(!1), t?.target === e.div && e.drawLayer.updateProperties(this._currentDrawId, L.#s.end(t.offsetX, t.offsetY)), this.supportMultipleDrawings) {
                    const s = L.#s, i = this._currentDrawId, n = s.getLastElement();
                    e.addCommands({
                        cmd: ()=>{
                            e.drawLayer.updateProperties(i, s.setLastElement(n));
                        },
                        undo: ()=>{
                            e.drawLayer.updateProperties(i, s.removeLastElement());
                        },
                        mustExec: !1,
                        type: O.DRAW_STEP
                    });
                    return;
                }
                this.endDrawing(!1);
            }
        }
        static endDrawing(t) {
            const e = this._currentParent;
            if (!e) return null;
            if (e.toggleDrawing(!0), e.cleanUndoStack(O.DRAW_STEP), !L.#s.isEmpty()) {
                const { pageDimensions: [s, i], scale: n } = e, r = e.createAndAddNewEditor({
                    offsetX: 0,
                    offsetY: 0
                }, !1, {
                    drawId: this._currentDrawId,
                    drawOutlines: L.#s.getOutlines(s * n, i * n, n, this._INNER_MARGIN),
                    drawingOptions: L.#r,
                    mustBeCommitted: !t
                });
                return this._cleanup(!0), r;
            }
            return e.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
        }
        createDrawingOptions(t) {}
        static deserializeDraw(t, e, s, i, n, r) {
            $("Not implemented");
        }
        static async deserialize(t, e, s) {
            const { rawDims: { pageWidth: i, pageHeight: n, pageX: r, pageY: a } } = e.viewport, o = this.deserializeDraw(r, a, i, n, this._INNER_MARGIN, t), l = await super.deserialize(t, e, s);
            return l.createDrawingOptions(t), l.#h({
                drawOutlines: o
            }), l.#f(), l.onScaleChanging(), l.rotate(), l;
        }
        serializeDraw(t) {
            const [e, s] = this.pageTranslation, [i, n] = this.pageDimensions;
            return this.#t.serialize([
                e,
                s,
                i,
                n
            ], t);
        }
        renderAnnotationElement(t) {
            return t.updateEdited({
                rect: this.getRect(0, 0)
            }), null;
        }
        static canCreateNewEmptyEditor() {
            return !1;
        }
    }
    class tr {
        #t = new Float64Array(6);
        #e;
        #s;
        #i;
        #r;
        #n;
        #l = "";
        #o = 0;
        #d = new le;
        #h;
        #u;
        constructor(t, e, s, i, n, r){
            this.#h = s, this.#u = i, this.#i = n, this.#r = r, [t, e] = this.#c(t, e);
            const a = this.#e = [
                NaN,
                NaN,
                NaN,
                NaN,
                t,
                e
            ];
            this.#n = [
                t,
                e
            ], this.#s = [
                {
                    line: a,
                    points: this.#n
                }
            ], this.#t.set(a, 0);
        }
        updateProperty(t, e) {
            t === "stroke-width" && (this.#r = e);
        }
        #c(t, e) {
            return x._normalizePoint(t, e, this.#h, this.#u, this.#i);
        }
        isEmpty() {
            return !this.#s || this.#s.length === 0;
        }
        isCancellable() {
            return this.#n.length <= 10;
        }
        add(t, e) {
            [t, e] = this.#c(t, e);
            const [s, i, n, r] = this.#t.subarray(2, 6), a = t - n, o = e - r;
            return Math.hypot(this.#h * a, this.#u * o) <= 2 ? null : (this.#n.push(t, e), isNaN(s) ? (this.#t.set([
                n,
                r,
                t,
                e
            ], 2), this.#e.push(NaN, NaN, NaN, NaN, t, e), {
                path: {
                    d: this.toSVGPath()
                }
            }) : (isNaN(this.#t[0]) && this.#e.splice(6, 6), this.#t.set([
                s,
                i,
                n,
                r,
                t,
                e
            ], 0), this.#e.push(...x.createBezierPoints(s, i, n, r, t, e)), {
                path: {
                    d: this.toSVGPath()
                }
            }));
        }
        end(t, e) {
            const s = this.add(t, e);
            return s || (this.#n.length === 2 ? {
                path: {
                    d: this.toSVGPath()
                }
            } : null);
        }
        startNew(t, e, s, i, n) {
            this.#h = s, this.#u = i, this.#i = n, [t, e] = this.#c(t, e);
            const r = this.#e = [
                NaN,
                NaN,
                NaN,
                NaN,
                t,
                e
            ];
            this.#n = [
                t,
                e
            ];
            const a = this.#s.at(-1);
            return a && (a.line = new Float32Array(a.line), a.points = new Float32Array(a.points)), this.#s.push({
                line: r,
                points: this.#n
            }), this.#t.set(r, 0), this.#o = 0, this.toSVGPath(), null;
        }
        getLastElement() {
            return this.#s.at(-1);
        }
        setLastElement(t) {
            return this.#s ? (this.#s.push(t), this.#e = t.line, this.#n = t.points, this.#o = 0, {
                path: {
                    d: this.toSVGPath()
                }
            }) : this.#d.setLastElement(t);
        }
        removeLastElement() {
            if (!this.#s) return this.#d.removeLastElement();
            this.#s.pop(), this.#l = "";
            for(let t = 0, e = this.#s.length; t < e; t++){
                const { line: s, points: i } = this.#s[t];
                this.#e = s, this.#n = i, this.#o = 0, this.toSVGPath();
            }
            return {
                path: {
                    d: this.#l
                }
            };
        }
        toSVGPath() {
            const t = x.svgRound(this.#e[4]), e = x.svgRound(this.#e[5]);
            if (this.#n.length === 2) return this.#l = `${this.#l} M ${t} ${e} Z`, this.#l;
            if (this.#n.length <= 6) {
                const i = this.#l.lastIndexOf("M");
                this.#l = `${this.#l.slice(0, i)} M ${t} ${e}`, this.#o = 6;
            }
            if (this.#n.length === 4) {
                const i = x.svgRound(this.#e[10]), n = x.svgRound(this.#e[11]);
                return this.#l = `${this.#l} L ${i} ${n}`, this.#o = 12, this.#l;
            }
            const s = [];
            this.#o === 0 && (s.push(`M ${t} ${e}`), this.#o = 6);
            for(let i = this.#o, n = this.#e.length; i < n; i += 6){
                const [r, a, o, l, h, d] = this.#e.slice(i, i + 6).map(x.svgRound);
                s.push(`C${r} ${a} ${o} ${l} ${h} ${d}`);
            }
            return this.#l += s.join(" "), this.#o = this.#e.length, this.#l;
        }
        getOutlines(t, e, s, i) {
            const n = this.#s.at(-1);
            return n.line = new Float32Array(n.line), n.points = new Float32Array(n.points), this.#d.build(this.#s, t, e, s, this.#i, this.#r, i), this.#t = null, this.#e = null, this.#s = null, this.#l = null, this.#d;
        }
        get defaultSVGProperties() {
            return {
                root: {
                    viewBox: "0 0 10000 10000"
                },
                rootClass: {
                    draw: !0
                },
                bbox: [
                    0,
                    0,
                    1,
                    1
                ]
            };
        }
    }
    class le extends x {
        #t;
        #e = 0;
        #s;
        #i;
        #r;
        #n;
        #l;
        #o;
        #d;
        build(t, e, s, i, n, r, a) {
            this.#r = e, this.#n = s, this.#l = i, this.#o = n, this.#d = r, this.#s = a ?? 0, this.#i = t, this.#c();
        }
        get thickness() {
            return this.#d;
        }
        setLastElement(t) {
            return this.#i.push(t), {
                path: {
                    d: this.toSVGPath()
                }
            };
        }
        removeLastElement() {
            return this.#i.pop(), {
                path: {
                    d: this.toSVGPath()
                }
            };
        }
        toSVGPath() {
            const t = [];
            for (const { line: e } of this.#i){
                if (t.push(`M${x.svgRound(e[4])} ${x.svgRound(e[5])}`), e.length === 6) {
                    t.push("Z");
                    continue;
                }
                if (e.length === 12 && isNaN(e[6])) {
                    t.push(`L${x.svgRound(e[10])} ${x.svgRound(e[11])}`);
                    continue;
                }
                for(let s = 6, i = e.length; s < i; s += 6){
                    const [n, r, a, o, l, h] = e.subarray(s, s + 6).map(x.svgRound);
                    t.push(`C${n} ${r} ${a} ${o} ${l} ${h}`);
                }
            }
            return t.join("");
        }
        serialize([t, e, s, i], n) {
            const r = [], a = [], [o, l, h, d] = this.#u();
            let u, f, g, p, m, b, y, A, v;
            switch(this.#o){
                case 0:
                    v = x._rescale, u = t, f = e + i, g = s, p = -i, m = t + o * s, b = e + (1 - l - d) * i, y = t + (o + h) * s, A = e + (1 - l) * i;
                    break;
                case 90:
                    v = x._rescaleAndSwap, u = t, f = e, g = s, p = i, m = t + l * s, b = e + o * i, y = t + (l + d) * s, A = e + (o + h) * i;
                    break;
                case 180:
                    v = x._rescale, u = t + s, f = e, g = -s, p = i, m = t + (1 - o - h) * s, b = e + l * i, y = t + (1 - o) * s, A = e + (l + d) * i;
                    break;
                case 270:
                    v = x._rescaleAndSwap, u = t + s, f = e + i, g = -s, p = -i, m = t + (1 - l - d) * s, b = e + (1 - o - h) * i, y = t + (1 - l) * s, A = e + (1 - o) * i;
                    break;
            }
            for (const { line: w, points: _ } of this.#i)r.push(v(w, u, f, g, p, n ? new Array(w.length) : null)), a.push(v(_, u, f, g, p, n ? new Array(_.length) : null));
            return {
                lines: r,
                points: a,
                rect: [
                    m,
                    b,
                    y,
                    A
                ]
            };
        }
        static deserialize(t, e, s, i, n, { paths: { lines: r, points: a }, rotation: o, thickness: l }) {
            const h = [];
            let d, u, f, g, p;
            switch(o){
                case 0:
                    p = x._rescale, d = -t / s, u = e / i + 1, f = 1 / s, g = -1 / i;
                    break;
                case 90:
                    p = x._rescaleAndSwap, d = -e / i, u = -t / s, f = 1 / i, g = 1 / s;
                    break;
                case 180:
                    p = x._rescale, d = t / s + 1, u = -e / i, f = -1 / s, g = 1 / i;
                    break;
                case 270:
                    p = x._rescaleAndSwap, d = e / i + 1, u = t / s + 1, f = -1 / i, g = -1 / s;
                    break;
            }
            if (!r) {
                r = [];
                for (const b of a){
                    const y = b.length;
                    if (y === 2) {
                        r.push(new Float32Array([
                            NaN,
                            NaN,
                            NaN,
                            NaN,
                            b[0],
                            b[1]
                        ]));
                        continue;
                    }
                    if (y === 4) {
                        r.push(new Float32Array([
                            NaN,
                            NaN,
                            NaN,
                            NaN,
                            b[0],
                            b[1],
                            NaN,
                            NaN,
                            NaN,
                            NaN,
                            b[2],
                            b[3]
                        ]));
                        continue;
                    }
                    const A = new Float32Array(3 * (y - 2));
                    r.push(A);
                    let [v, w, _, S] = b.subarray(0, 4);
                    A.set([
                        NaN,
                        NaN,
                        NaN,
                        NaN,
                        v,
                        w
                    ], 0);
                    for(let E = 4; E < y; E += 2){
                        const C = b[E], M = b[E + 1];
                        A.set(x.createBezierPoints(v, w, _, S, C, M), (E - 2) * 3), [v, w, _, S] = [
                            _,
                            S,
                            C,
                            M
                        ];
                    }
                }
            }
            for(let b = 0, y = r.length; b < y; b++)h.push({
                line: p(r[b].map((A)=>A ?? NaN), d, u, f, g),
                points: p(a[b].map((A)=>A ?? NaN), d, u, f, g)
            });
            const m = new this.prototype.constructor;
            return m.build(h, s, i, 1, o, l, n), m;
        }
        #h(t = this.#d) {
            const e = this.#s + t / 2 * this.#l;
            return this.#o % 180 === 0 ? [
                e / this.#r,
                e / this.#n
            ] : [
                e / this.#n,
                e / this.#r
            ];
        }
        #u() {
            const [t, e, s, i] = this.#t, [n, r] = this.#h(0);
            return [
                t + n,
                e + r,
                s - 2 * n,
                i - 2 * r
            ];
        }
        #c() {
            const t = this.#t = new Float32Array([
                1 / 0,
                1 / 0,
                -1 / 0,
                -1 / 0
            ]);
            for (const { line: i } of this.#i){
                if (i.length <= 12) {
                    for(let a = 4, o = i.length; a < o; a += 6)P.pointBoundingBox(i[a], i[a + 1], t);
                    continue;
                }
                let n = i[4], r = i[5];
                for(let a = 6, o = i.length; a < o; a += 6){
                    const [l, h, d, u, f, g] = i.subarray(a, a + 6);
                    P.bezierBoundingBox(n, r, l, h, d, u, f, g, t), n = f, r = g;
                }
            }
            const [e, s] = this.#h();
            t[0] = ot(t[0] - e, 0, 1), t[1] = ot(t[1] - s, 0, 1), t[2] = ot(t[2] + e, 0, 1), t[3] = ot(t[3] + s, 0, 1), t[2] -= t[0], t[3] -= t[1];
        }
        get box() {
            return this.#t;
        }
        updateProperty(t, e) {
            return t === "stroke-width" ? this.#f(e) : null;
        }
        #f(t) {
            const [e, s] = this.#h();
            this.#d = t;
            const [i, n] = this.#h(), [r, a] = [
                i - e,
                n - s
            ], o = this.#t;
            return o[0] -= r, o[1] -= a, o[2] += 2 * r, o[3] += 2 * a, o;
        }
        updateParentDimensions([t, e], s) {
            const [i, n] = this.#h();
            this.#r = t, this.#n = e, this.#l = s;
            const [r, a] = this.#h(), o = r - i, l = a - n, h = this.#t;
            return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
        }
        updateRotation(t) {
            return this.#e = t, {
                path: {
                    transform: this.rotationTransform
                }
            };
        }
        get viewBox() {
            return this.#t.map(x.svgRound).join(" ");
        }
        get defaultProperties() {
            const [t, e] = this.#t;
            return {
                root: {
                    viewBox: this.viewBox
                },
                path: {
                    "transform-origin": `${x.svgRound(t)} ${x.svgRound(e)}`
                }
            };
        }
        get rotationTransform() {
            const [, , t, e] = this.#t;
            let s = 0, i = 0, n = 0, r = 0, a = 0, o = 0;
            switch(this.#e){
                case 90:
                    i = e / t, n = -t / e, a = t;
                    break;
                case 180:
                    s = -1, r = -1, a = t, o = e;
                    break;
                case 270:
                    i = -e / t, n = t / e, o = e;
                    break;
                default:
                    return "";
            }
            return `matrix(${s} ${i} ${n} ${r} ${x.svgRound(a)} ${x.svgRound(o)})`;
        }
        getPathResizingSVGProperties([t, e, s, i]) {
            const [n, r] = this.#h(), [a, o, l, h] = this.#t;
            if (Math.abs(l - n) <= x.PRECISION || Math.abs(h - r) <= x.PRECISION) {
                const p = t + s / 2 - (a + l / 2), m = e + i / 2 - (o + h / 2);
                return {
                    path: {
                        "transform-origin": `${x.svgRound(t)} ${x.svgRound(e)}`,
                        transform: `${this.rotationTransform} translate(${p} ${m})`
                    }
                };
            }
            const d = (s - 2 * n) / (l - 2 * n), u = (i - 2 * r) / (h - 2 * r), f = l / s, g = h / i;
            return {
                path: {
                    "transform-origin": `${x.svgRound(a)} ${x.svgRound(o)}`,
                    transform: `${this.rotationTransform} scale(${f} ${g}) translate(${x.svgRound(n)} ${x.svgRound(r)}) scale(${d} ${u}) translate(${x.svgRound(-n)} ${x.svgRound(-r)})`
                }
            };
        }
        getPathResizedSVGProperties([t, e, s, i]) {
            const [n, r] = this.#h(), a = this.#t, [o, l, h, d] = a;
            if (a[0] = t, a[1] = e, a[2] = s, a[3] = i, Math.abs(h - n) <= x.PRECISION || Math.abs(d - r) <= x.PRECISION) {
                const m = t + s / 2 - (o + h / 2), b = e + i / 2 - (l + d / 2);
                for (const { line: y, points: A } of this.#i)x._translate(y, m, b, y), x._translate(A, m, b, A);
                return {
                    root: {
                        viewBox: this.viewBox
                    },
                    path: {
                        "transform-origin": `${x.svgRound(t)} ${x.svgRound(e)}`,
                        transform: this.rotationTransform || null,
                        d: this.toSVGPath()
                    }
                };
            }
            const u = (s - 2 * n) / (h - 2 * n), f = (i - 2 * r) / (d - 2 * r), g = -u * (o + n) + t + n, p = -f * (l + r) + e + r;
            if (u !== 1 || f !== 1 || g !== 0 || p !== 0) for (const { line: m, points: b } of this.#i)x._rescale(m, g, p, u, f, m), x._rescale(b, g, p, u, f, b);
            return {
                root: {
                    viewBox: this.viewBox
                },
                path: {
                    "transform-origin": `${x.svgRound(t)} ${x.svgRound(e)}`,
                    transform: this.rotationTransform || null,
                    d: this.toSVGPath()
                }
            };
        }
        getPathTranslatedSVGProperties([t, e], s) {
            const [i, n] = s, r = this.#t, a = t - r[0], o = e - r[1];
            if (this.#r === i && this.#n === n) for (const { line: l, points: h } of this.#i)x._translate(l, a, o, l), x._translate(h, a, o, h);
            else {
                const l = this.#r / i, h = this.#n / n;
                this.#r = i, this.#n = n;
                for (const { line: d, points: u } of this.#i)x._rescale(d, a, o, l, h, d), x._rescale(u, a, o, l, h, u);
                r[2] *= l, r[3] *= h;
            }
            return r[0] = t, r[1] = e, {
                root: {
                    viewBox: this.viewBox
                },
                path: {
                    d: this.toSVGPath(),
                    "transform-origin": `${x.svgRound(t)} ${x.svgRound(e)}`
                }
            };
        }
        get defaultSVGProperties() {
            const t = this.#t;
            return {
                root: {
                    viewBox: this.viewBox
                },
                rootClass: {
                    draw: !0
                },
                path: {
                    d: this.toSVGPath(),
                    "transform-origin": `${x.svgRound(t[0])} ${x.svgRound(t[1])}`,
                    transform: this.rotationTransform || null
                },
                bbox: t
            };
        }
    }
    class xe extends oi {
        constructor(t){
            super(), this._viewParameters = t, super.updateProperties({
                fill: "none",
                stroke: k._defaultLineColor,
                "stroke-opacity": 1,
                "stroke-width": 1,
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-miterlimit": 10
            });
        }
        updateSVGProperty(t, e) {
            t === "stroke-width" && (e ??= this["stroke-width"], e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
        }
        clone() {
            const t = new xe(this._viewParameters);
            return t.updateAll(this), t;
        }
    }
    class as extends L {
        static _type = "ink";
        static _editorType = D.INK;
        static _defaultDrawingOptions = null;
        constructor(t){
            super({
                ...t,
                name: "inkEditor"
            }), this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
        }
        static initialize(t, e) {
            k.initialize(t, e), this._defaultDrawingOptions = new xe(e.viewParameters);
        }
        static getDefaultDrawingOptions(t) {
            const e = this._defaultDrawingOptions.clone();
            return e.updateProperties(t), e;
        }
        static get supportMultipleDrawings() {
            return !0;
        }
        static get typesMap() {
            return N(this, "typesMap", new Map([
                [
                    O.INK_THICKNESS,
                    "stroke-width"
                ],
                [
                    O.INK_COLOR,
                    "stroke"
                ],
                [
                    O.INK_OPACITY,
                    "stroke-opacity"
                ]
            ]));
        }
        static createDrawerInstance(t, e, s, i, n) {
            return new tr(t, e, s, i, n, this._defaultDrawingOptions["stroke-width"]);
        }
        static deserializeDraw(t, e, s, i, n, r) {
            return le.deserialize(t, e, s, i, n, r);
        }
        static async deserialize(t, e, s) {
            let i = null;
            if (t instanceof ns) {
                const { data: { inkLists: r, rect: a, rotation: o, id: l, color: h, opacity: d, borderStyle: { rawWidth: u }, popupRef: f }, parent: { page: { pageNumber: g } } } = t;
                i = t = {
                    annotationType: D.INK,
                    color: Array.from(h),
                    thickness: u,
                    opacity: d,
                    paths: {
                        points: r
                    },
                    boxes: null,
                    pageIndex: g - 1,
                    rect: a.slice(0),
                    rotation: o,
                    id: l,
                    deleted: !1,
                    popupRef: f
                };
            }
            const n = await super.deserialize(t, e, s);
            return n.annotationElementId = t.id || null, n._initialData = i, n;
        }
        onScaleChanging() {
            if (!this.parent) return;
            super.onScaleChanging();
            const { _drawId: t, _drawingOptions: e, parent: s } = this;
            e.updateSVGProperty("stroke-width"), s.drawLayer.updateProperties(t, e.toSVGProperties());
        }
        static onScaleChangingWhenDrawing() {
            const t = this._currentParent;
            t && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), t.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
        }
        createDrawingOptions({ color: t, thickness: e, opacity: s }) {
            this._drawingOptions = as.getDefaultDrawingOptions({
                stroke: P.makeHexColor(...t),
                "stroke-width": e,
                "stroke-opacity": s
            });
        }
        serialize(t = !1) {
            if (this.isEmpty()) return null;
            if (this.deleted) return this.serializeDeleted();
            const { lines: e, points: s, rect: i } = this.serializeDraw(t), { _drawingOptions: { stroke: n, "stroke-opacity": r, "stroke-width": a } } = this, o = {
                annotationType: D.INK,
                color: k._colorManager.convert(n),
                opacity: r,
                thickness: a,
                paths: {
                    lines: e,
                    points: s
                },
                pageIndex: this.pageIndex,
                rect: i,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
            };
            return t ? (o.isCopy = !0, o) : this.annotationElementId && !this.#t(o) ? null : (o.id = this.annotationElementId, o);
        }
        #t(t) {
            const { color: e, thickness: s, opacity: i, pageIndex: n } = this._initialData;
            return this._hasBeenMoved || this._hasBeenResized || t.color.some((r, a)=>r !== e[a]) || t.thickness !== s || t.opacity !== i || t.pageIndex !== n;
        }
        renderAnnotationElement(t) {
            const { points: e, rect: s } = this.serializeDraw(!1);
            return t.updateEdited({
                rect: s,
                thickness: this._drawingOptions["stroke-width"],
                points: e
            }), null;
        }
    }
    class Ve extends le {
        toSVGPath() {
            let t = super.toSVGPath();
            return t.endsWith("Z") || (t += "Z"), t;
        }
    }
    const ge = 8, Qt = 3;
    Gt = class {
        static #t = {
            maxDim: 512,
            sigmaSFactor: .02,
            sigmaR: 25,
            kernelSize: 16
        };
        static #e(t, e, s, i) {
            return s -= t, i -= e, s === 0 ? i > 0 ? 0 : 4 : s === 1 ? i + 6 : 2 - i;
        }
        static #s = new Int32Array([
            0,
            1,
            -1,
            1,
            -1,
            0,
            -1,
            -1,
            0,
            -1,
            1,
            -1,
            1,
            0,
            1,
            1
        ]);
        static #i(t, e, s, i, n, r, a) {
            const o = this.#e(s, i, n, r);
            for(let l = 0; l < 8; l++){
                const h = (-l + o - a + 16) % 8, d = this.#s[2 * h], u = this.#s[2 * h + 1];
                if (t[(s + d) * e + (i + u)] !== 0) return h;
            }
            return -1;
        }
        static #r(t, e, s, i, n, r, a) {
            const o = this.#e(s, i, n, r);
            for(let l = 0; l < 8; l++){
                const h = (l + o + a + 16) % 8, d = this.#s[2 * h], u = this.#s[2 * h + 1];
                if (t[(s + d) * e + (i + u)] !== 0) return h;
            }
            return -1;
        }
        static #n(t, e, s, i) {
            const n = t.length, r = new Int32Array(n);
            for(let h = 0; h < n; h++)r[h] = t[h] <= i ? 1 : 0;
            for(let h = 1; h < s - 1; h++)r[h * e] = r[h * e + e - 1] = 0;
            for(let h = 0; h < e; h++)r[h] = r[e * s - 1 - h] = 0;
            let a = 1, o;
            const l = [];
            for(let h = 1; h < s - 1; h++){
                o = 1;
                for(let d = 1; d < e - 1; d++){
                    const u = h * e + d, f = r[u];
                    if (f === 0) continue;
                    let g = h, p = d;
                    if (f === 1 && r[u - 1] === 0) a += 1, p -= 1;
                    else if (f >= 1 && r[u + 1] === 0) a += 1, p += 1, f > 1 && (o = f);
                    else {
                        f !== 1 && (o = Math.abs(f));
                        continue;
                    }
                    const m = [
                        d,
                        h
                    ], b = p === d + 1, y = {
                        isHole: b,
                        points: m,
                        id: a,
                        parent: 0
                    };
                    l.push(y);
                    let A;
                    for (const I of l)if (I.id === o) {
                        A = I;
                        break;
                    }
                    A ? A.isHole ? y.parent = b ? A.parent : o : y.parent = b ? o : A.parent : y.parent = b ? o : 0;
                    const v = this.#i(r, e, h, d, g, p, 0);
                    if (v === -1) {
                        r[u] = -a, r[u] !== 1 && (o = Math.abs(r[u]));
                        continue;
                    }
                    let w = this.#s[2 * v], _ = this.#s[2 * v + 1];
                    const S = h + w, E = d + _;
                    g = S, p = E;
                    let C = h, M = d;
                    for(;;){
                        const I = this.#r(r, e, C, M, g, p, 1);
                        w = this.#s[2 * I], _ = this.#s[2 * I + 1];
                        const H = C + w, G = M + _;
                        m.push(G, H);
                        const B = C * e + M;
                        if (r[B + 1] === 0 ? r[B] = -a : r[B] === 1 && (r[B] = a), H === h && G === d && C === S && M === E) {
                            r[u] !== 1 && (o = Math.abs(r[u]));
                            break;
                        } else g = C, p = M, C = H, M = G;
                    }
                }
            }
            return l;
        }
        static #l(t, e, s, i) {
            if (s - e <= 4) {
                for(let S = e; S < s - 2; S += 2)i.push(t[S], t[S + 1]);
                return;
            }
            const n = t[e], r = t[e + 1], a = t[s - 4] - n, o = t[s - 3] - r, l = Math.hypot(a, o), h = a / l, d = o / l, u = h * r - d * n, f = o / a, g = 1 / l, p = Math.atan(f), m = Math.cos(p), b = Math.sin(p), y = g * (Math.abs(m) + Math.abs(b)), A = g * (1 - y + y ** 2), v = Math.max(Math.atan(Math.abs(b + m) * A), Math.atan(Math.abs(b - m) * A));
            let w = 0, _ = e;
            for(let S = e + 2; S < s - 2; S += 2){
                const E = Math.abs(u - h * t[S + 1] + d * t[S]);
                E > w && (_ = S, w = E);
            }
            w > (l * v) ** 2 ? (this.#l(t, e, _ + 2, i), this.#l(t, _, s, i)) : i.push(n, r);
        }
        static #o(t) {
            const e = [], s = t.length;
            return this.#l(t, 0, s, e), e.push(t[s - 2], t[s - 1]), e.length <= 4 ? null : e;
        }
        static #d(t, e, s, i, n, r) {
            const a = new Float32Array(r ** 2), o = -2 * i ** 2, l = r >> 1;
            for(let p = 0; p < r; p++){
                const m = (p - l) ** 2;
                for(let b = 0; b < r; b++)a[p * r + b] = Math.exp((m + (b - l) ** 2) / o);
            }
            const h = new Float32Array(256), d = -2 * n ** 2;
            for(let p = 0; p < 256; p++)h[p] = Math.exp(p ** 2 / d);
            const u = t.length, f = new Uint8Array(u), g = new Uint32Array(256);
            for(let p = 0; p < s; p++)for(let m = 0; m < e; m++){
                const b = p * e + m, y = t[b];
                let A = 0, v = 0;
                for(let _ = 0; _ < r; _++){
                    const S = p + _ - l;
                    if (!(S < 0 || S >= s)) for(let E = 0; E < r; E++){
                        const C = m + E - l;
                        if (C < 0 || C >= e) continue;
                        const M = t[S * e + C], I = a[_ * r + E] * h[Math.abs(M - y)];
                        A += M * I, v += I;
                    }
                }
                const w = f[b] = Math.round(A / v);
                g[w]++;
            }
            return [
                f,
                g
            ];
        }
        static #h(t) {
            const e = new Uint32Array(256);
            for (const s of t)e[s]++;
            return e;
        }
        static #u(t) {
            const e = t.length, s = new Uint8ClampedArray(e >> 2);
            let i = -1 / 0, n = 1 / 0;
            for(let a = 0, o = s.length; a < o; a++){
                if (t[(a << 2) + 3] === 0) {
                    i = s[a] = 255;
                    continue;
                }
                const h = s[a] = t[a << 2];
                h > i && (i = h), h < n && (n = h);
            }
            const r = 255 / (i - n);
            for(let a = 0; a < e; a++)s[a] = (s[a] - n) * r;
            return s;
        }
        static #c(t) {
            let e, s = -1 / 0, i = -1 / 0;
            const n = t.findIndex((o)=>o !== 0);
            let r = n, a = n;
            for(e = n; e < 256; e++){
                const o = t[e];
                o > s && (e - r > i && (i = e - r, a = e - 1), s = o, r = e);
            }
            for(e = a - 1; e >= 0 && !(t[e] > t[e + 1]); e--);
            return e;
        }
        static #f(t) {
            const e = t, { width: s, height: i } = t, { maxDim: n } = this.#t;
            let r = s, a = i;
            if (s > n || i > n) {
                let u = s, f = i, g = Math.log2(Math.max(s, i) / n);
                const p = Math.floor(g);
                g = g === p ? p - 1 : p;
                for(let b = 0; b < g; b++){
                    r = u, a = f, r > n && (r = Math.ceil(r / 2)), a > n && (a = Math.ceil(a / 2));
                    const y = new OffscreenCanvas(r, a);
                    y.getContext("2d").drawImage(t, 0, 0, u, f, 0, 0, r, a), u = r, f = a, t !== e && t.close(), t = y.transferToImageBitmap();
                }
                const m = Math.min(n / r, n / a);
                r = Math.round(r * m), a = Math.round(a * m);
            }
            const l = new OffscreenCanvas(r, a).getContext("2d", {
                willReadFrequently: !0
            });
            l.filter = "grayscale(1)", l.drawImage(t, 0, 0, t.width, t.height, 0, 0, r, a);
            const h = l.getImageData(0, 0, r, a).data;
            return [
                this.#u(h),
                r,
                a
            ];
        }
        static extractContoursFromText(t, { fontFamily: e, fontStyle: s, fontWeight: i }, n, r, a, o) {
            let l = new OffscreenCanvas(1, 1), h = l.getContext("2d", {
                alpha: !1
            });
            const d = 200, u = h.font = `${s} ${i} ${d}px ${e}`, { actualBoundingBoxLeft: f, actualBoundingBoxRight: g, actualBoundingBoxAscent: p, actualBoundingBoxDescent: m, fontBoundingBoxAscent: b, fontBoundingBoxDescent: y, width: A } = h.measureText(t), v = 1.5, w = Math.ceil(Math.max(Math.abs(f) + Math.abs(g) || 0, A) * v), _ = Math.ceil(Math.max(Math.abs(p) + Math.abs(m) || d, Math.abs(b) + Math.abs(y) || d) * v);
            l = new OffscreenCanvas(w, _), h = l.getContext("2d", {
                alpha: !0,
                willReadFrequently: !0
            }), h.font = u, h.filter = "grayscale(1)", h.fillStyle = "white", h.fillRect(0, 0, w, _), h.fillStyle = "black", h.fillText(t, w * (v - 1) / 2, _ * (3 - v) / 2);
            const S = this.#u(h.getImageData(0, 0, w, _).data), E = this.#h(S), C = this.#c(E), M = this.#n(S, w, _, C);
            return this.processDrawnLines({
                lines: {
                    curves: M,
                    width: w,
                    height: _
                },
                pageWidth: n,
                pageHeight: r,
                rotation: a,
                innerMargin: o,
                mustSmooth: !0,
                areContours: !0
            });
        }
        static process(t, e, s, i, n) {
            const [r, a, o] = this.#f(t), [l, h] = this.#d(r, a, o, Math.hypot(a, o) * this.#t.sigmaSFactor, this.#t.sigmaR, this.#t.kernelSize), d = this.#c(h), u = this.#n(l, a, o, d);
            return this.processDrawnLines({
                lines: {
                    curves: u,
                    width: a,
                    height: o
                },
                pageWidth: e,
                pageHeight: s,
                rotation: i,
                innerMargin: n,
                mustSmooth: !0,
                areContours: !0
            });
        }
        static processDrawnLines({ lines: t, pageWidth: e, pageHeight: s, rotation: i, innerMargin: n, mustSmooth: r, areContours: a }) {
            i % 180 !== 0 && ([e, s] = [
                s,
                e
            ]);
            const { curves: o, width: l, height: h } = t, d = t.thickness ?? 0, u = [], f = Math.min(e / l, s / h), g = f / e, p = f / s, m = [];
            for (const { points: y } of o){
                const A = r ? this.#o(y) : y;
                if (!A) continue;
                m.push(A);
                const v = A.length, w = new Float32Array(v), _ = new Float32Array(3 * (v === 2 ? 2 : v - 2));
                if (u.push({
                    line: _,
                    points: w
                }), v === 2) {
                    w[0] = A[0] * g, w[1] = A[1] * p, _.set([
                        NaN,
                        NaN,
                        NaN,
                        NaN,
                        w[0],
                        w[1]
                    ], 0);
                    continue;
                }
                let [S, E, C, M] = A;
                S *= g, E *= p, C *= g, M *= p, w.set([
                    S,
                    E,
                    C,
                    M
                ], 0), _.set([
                    NaN,
                    NaN,
                    NaN,
                    NaN,
                    S,
                    E
                ], 0);
                for(let I = 4; I < v; I += 2){
                    const H = w[I] = A[I] * g, G = w[I + 1] = A[I + 1] * p;
                    _.set(x.createBezierPoints(S, E, C, M, H, G), (I - 2) * 3), [S, E, C, M] = [
                        C,
                        M,
                        H,
                        G
                    ];
                }
            }
            if (u.length === 0) return null;
            const b = a ? new Ve : new le;
            return b.build(u, e, s, 1, i, a ? 0 : d, n), {
                outline: b,
                newCurves: m,
                areContours: a,
                thickness: d,
                width: l,
                height: h
            };
        }
        static async compressSignature({ outlines: t, areContours: e, thickness: s, width: i, height: n }) {
            let r = 1 / 0, a = -1 / 0, o = 0;
            for (const A of t){
                o += A.length;
                for(let v = 2, w = A.length; v < w; v++){
                    const _ = A[v] - A[v - 2];
                    r = Math.min(r, _), a = Math.max(a, _);
                }
            }
            let l;
            r >= -128 && a <= 127 ? l = Int8Array : r >= -32768 && a <= 32767 ? l = Int16Array : l = Int32Array;
            const h = t.length, d = ge + Qt * h, u = new Uint32Array(d);
            let f = 0;
            u[f++] = d * Uint32Array.BYTES_PER_ELEMENT + (o - 2 * h) * l.BYTES_PER_ELEMENT, u[f++] = 0, u[f++] = i, u[f++] = n, u[f++] = e ? 0 : 1, u[f++] = Math.max(0, Math.floor(s ?? 0)), u[f++] = h, u[f++] = l.BYTES_PER_ELEMENT;
            for (const A of t)u[f++] = A.length - 2, u[f++] = A[0], u[f++] = A[1];
            const g = new CompressionStream("deflate-raw"), p = g.writable.getWriter();
            await p.ready, p.write(u);
            const m = l.prototype.constructor;
            for (const A of t){
                const v = new m(A.length - 2);
                for(let w = 2, _ = A.length; w < _; w++)v[w - 2] = A[w] - A[w - 2];
                p.write(v);
            }
            p.close();
            const b = await new Response(g.readable).arrayBuffer(), y = new Uint8Array(b);
            return Ns(y);
        }
        static async decompressSignature(t) {
            try {
                const e = Si(t), { readable: s, writable: i } = new DecompressionStream("deflate-raw"), n = i.getWriter();
                await n.ready, n.write(e).then(async ()=>{
                    await n.ready, await n.close();
                }).catch(()=>{});
                let r = null, a = 0;
                for await (const A of s)r ||= new Uint8Array(new Uint32Array(A.buffer, 0, 4)[0]), r.set(A, a), a += A.length;
                const o = new Uint32Array(r.buffer, 0, r.length >> 2), l = o[1];
                if (l !== 0) throw new Error(`Invalid version: ${l}`);
                const h = o[2], d = o[3], u = o[4] === 0, f = o[5], g = o[6], p = o[7], m = [], b = (ge + Qt * g) * Uint32Array.BYTES_PER_ELEMENT;
                let y;
                switch(p){
                    case Int8Array.BYTES_PER_ELEMENT:
                        y = new Int8Array(r.buffer, b);
                        break;
                    case Int16Array.BYTES_PER_ELEMENT:
                        y = new Int16Array(r.buffer, b);
                        break;
                    case Int32Array.BYTES_PER_ELEMENT:
                        y = new Int32Array(r.buffer, b);
                        break;
                }
                a = 0;
                for(let A = 0; A < g; A++){
                    const v = o[Qt * A + ge], w = new Float32Array(v + 2);
                    m.push(w);
                    for(let _ = 0; _ < Qt - 1; _++)w[_] = o[Qt * A + ge + _ + 1];
                    for(let _ = 0; _ < v; _++)w[_ + 2] = w[_] + y[a++];
                }
                return {
                    areContours: u,
                    thickness: f,
                    outlines: m,
                    width: h,
                    height: d
                };
            } catch (e) {
                return F(`decompressSignature: ${e}`), null;
            }
        }
    };
    class os extends oi {
        constructor(){
            super(), super.updateProperties({
                fill: k._defaultLineColor,
                "stroke-width": 0
            });
        }
        clone() {
            const t = new os;
            return t.updateAll(this), t;
        }
    }
    class ls extends xe {
        constructor(t){
            super(t), super.updateProperties({
                stroke: k._defaultLineColor,
                "stroke-width": 1
            });
        }
        clone() {
            const t = new ls(this._viewParameters);
            return t.updateAll(this), t;
        }
    }
    class At extends L {
        #t = !1;
        #e = null;
        #s = null;
        #i = null;
        static _type = "signature";
        static _editorType = D.SIGNATURE;
        static _defaultDrawingOptions = null;
        constructor(t){
            super({
                ...t,
                mustBeCommitted: !0,
                name: "signatureEditor"
            }), this._willKeepAspectRatio = !0, this.#s = t.signatureData || null, this.#e = null, this.defaultL10nId = "pdfjs-editor-signature-editor1";
        }
        static initialize(t, e) {
            k.initialize(t, e), this._defaultDrawingOptions = new os, this._defaultDrawnSignatureOptions = new ls(e.viewParameters);
        }
        static getDefaultDrawingOptions(t) {
            const e = this._defaultDrawingOptions.clone();
            return e.updateProperties(t), e;
        }
        static get supportMultipleDrawings() {
            return !1;
        }
        static get typesMap() {
            return N(this, "typesMap", new Map);
        }
        static get isDrawer() {
            return !1;
        }
        get telemetryFinalData() {
            return {
                type: "signature",
                hasDescription: !!this.#e
            };
        }
        static computeTelemetryFinalData(t) {
            const e = t.get("hasDescription");
            return {
                hasAltText: e.get(!0) ?? 0,
                hasNoAltText: e.get(!1) ?? 0
            };
        }
        get isResizable() {
            return !0;
        }
        onScaleChanging() {
            this._drawId !== null && super.onScaleChanging();
        }
        render() {
            if (this.div) return this.div;
            let t, e;
            const { _isCopy: s } = this;
            if (s && (this._isCopy = !1, t = this.x, e = this.y), super.render(), this._drawId === null) if (this.#s) {
                const { lines: i, mustSmooth: n, areContours: r, description: a, uuid: o, heightInPage: l } = this.#s, { rawDims: { pageWidth: h, pageHeight: d }, rotation: u } = this.parent.viewport, f = Gt.processDrawnLines({
                    lines: i,
                    pageWidth: h,
                    pageHeight: d,
                    rotation: u,
                    innerMargin: At._INNER_MARGIN,
                    mustSmooth: n,
                    areContours: r
                });
                this.addSignature(f, l, a, o);
            } else this.div.setAttribute("data-l10n-args", JSON.stringify({
                description: ""
            })), this.div.hidden = !0, this._uiManager.getSignature(this);
            return s && (this._isCopy = !0, this._moveAfterPaste(t, e)), this.div;
        }
        setUuid(t) {
            this.#i = t, this.addEditToolbar();
        }
        getUuid() {
            return this.#i;
        }
        get description() {
            return this.#e;
        }
        set description(t) {
            this.#e = t, super.addEditToolbar().then((e)=>{
                e?.updateEditSignatureButton(t);
            });
        }
        getSignaturePreview() {
            const { newCurves: t, areContours: e, thickness: s, width: i, height: n } = this.#s, r = Math.max(i, n), a = Gt.processDrawnLines({
                lines: {
                    curves: t.map((o)=>({
                            points: o
                        })),
                    thickness: s,
                    width: i,
                    height: n
                },
                pageWidth: r,
                pageHeight: r,
                rotation: 0,
                innerMargin: 0,
                mustSmooth: !1,
                areContours: e
            });
            return {
                areContours: e,
                outline: a.outline
            };
        }
        async addEditToolbar() {
            const t = await super.addEditToolbar();
            return t ? (this._uiManager.signatureManager && this.#e !== null && (await t.addEditSignatureButton(this._uiManager.signatureManager, this.#i, this.#e), t.show()), t) : null;
        }
        addSignature(t, e, s, i) {
            const { x: n, y: r } = this, { outline: a } = this.#s = t;
            this.#t = a instanceof Ve, this.#e = s, this.div.setAttribute("data-l10n-args", JSON.stringify({
                description: s
            }));
            let o;
            this.#t ? o = At.getDefaultDrawingOptions() : (o = At._defaultDrawnSignatureOptions.clone(), o.updateProperties({
                "stroke-width": a.thickness
            })), this._addOutlines({
                drawOutlines: a,
                drawingOptions: o
            });
            const [l, h] = this.parentDimensions, [, d] = this.pageDimensions;
            let u = e / d;
            u = u >= 1 ? .5 : u, this.width *= u / this.height, this.width >= 1 && (u *= .9 / this.width, this.width = .9), this.height = u, this.setDims(l * this.width, h * this.height), this.x = n, this.y = r, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(i), this._reportTelemetry({
                action: "pdfjs.signature.inserted",
                data: {
                    hasBeenSaved: !!i,
                    hasDescription: !!s
                }
            }), this.div.hidden = !1;
        }
        getFromImage(t) {
            const { rawDims: { pageWidth: e, pageHeight: s }, rotation: i } = this.parent.viewport;
            return Gt.process(t, e, s, i, At._INNER_MARGIN);
        }
        getFromText(t, e) {
            const { rawDims: { pageWidth: s, pageHeight: i }, rotation: n } = this.parent.viewport;
            return Gt.extractContoursFromText(t, e, s, i, n, At._INNER_MARGIN);
        }
        getDrawnSignature(t) {
            const { rawDims: { pageWidth: e, pageHeight: s }, rotation: i } = this.parent.viewport;
            return Gt.processDrawnLines({
                lines: t,
                pageWidth: e,
                pageHeight: s,
                rotation: i,
                innerMargin: At._INNER_MARGIN,
                mustSmooth: !1,
                areContours: !1
            });
        }
        createDrawingOptions({ areContours: t, thickness: e }) {
            t ? this._drawingOptions = At.getDefaultDrawingOptions() : (this._drawingOptions = At._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
                "stroke-width": e
            }));
        }
        serialize(t = !1) {
            if (this.isEmpty()) return null;
            const { lines: e, points: s, rect: i } = this.serializeDraw(t), { _drawingOptions: { "stroke-width": n } } = this, r = {
                annotationType: D.SIGNATURE,
                isSignature: !0,
                areContours: this.#t,
                color: [
                    0,
                    0,
                    0
                ],
                thickness: this.#t ? 0 : n,
                pageIndex: this.pageIndex,
                rect: i,
                rotation: this.rotation,
                structTreeParentId: this._structTreeParentId
            };
            return t ? (r.paths = {
                lines: e,
                points: s
            }, r.uuid = this.#i, r.isCopy = !0) : r.lines = e, this.#e && (r.accessibilityData = {
                type: "Figure",
                alt: this.#e
            }), r;
        }
        static deserializeDraw(t, e, s, i, n, r) {
            return r.areContours ? Ve.deserialize(t, e, s, i, n, r) : le.deserialize(t, e, s, i, n, r);
        }
        static async deserialize(t, e, s) {
            const i = await super.deserialize(t, e, s);
            return i.#t = t.areContours, i.#e = t.accessibilityData?.alt || "", i.#i = t.uuid, i;
        }
    }
    class er extends k {
        #t = null;
        #e = null;
        #s = null;
        #i = null;
        #r = null;
        #n = "";
        #l = null;
        #o = !1;
        #d = null;
        #h = !1;
        #u = !1;
        static _type = "stamp";
        static _editorType = D.STAMP;
        constructor(t){
            super({
                ...t,
                name: "stampEditor"
            }), this.#i = t.bitmapUrl, this.#r = t.bitmapFile, this.defaultL10nId = "pdfjs-editor-stamp-editor";
        }
        static initialize(t, e) {
            k.initialize(t, e);
        }
        static isHandlingMimeForPasting(t) {
            return Be.includes(t);
        }
        static paste(t, e) {
            e.pasteEditor(D.STAMP, {
                bitmapFile: t.getAsFile()
            });
        }
        altTextFinish() {
            this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
        }
        get telemetryFinalData() {
            return {
                type: "stamp",
                hasAltText: !!this.altTextData?.altText
            };
        }
        static computeTelemetryFinalData(t) {
            const e = t.get("hasAltText");
            return {
                hasAltText: e.get(!0) ?? 0,
                hasNoAltText: e.get(!1) ?? 0
            };
        }
        #c(t, e = !1) {
            if (!t) {
                this.remove();
                return;
            }
            this.#t = t.bitmap, e || (this.#e = t.id, this.#h = t.isSvg), t.file && (this.#n = t.file.name), this.#p();
        }
        #f() {
            if (this.#s = null, this._uiManager.enableWaiting(!1), !!this.#l) {
                if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
                    this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
                    return;
                }
                if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
                    this._reportTelemetry({
                        action: "pdfjs.image.image_added",
                        data: {
                            alt_text_modal: !1,
                            alt_text_type: "empty"
                        }
                    });
                    try {
                        this.mlGuessAltText();
                    } catch  {}
                }
                this.div.focus();
            }
        }
        async mlGuessAltText(t = null, e = !0) {
            if (this.hasAltTextData()) return null;
            const { mlManager: s } = this._uiManager;
            if (!s) throw new Error("No ML.");
            if (!await s.isEnabledFor("altText")) throw new Error("ML isn't enabled for alt text.");
            const { data: i, width: n, height: r } = t || this.copyCanvas(null, null, !0).imageData, a = await s.guess({
                name: "altText",
                request: {
                    data: i,
                    width: n,
                    height: r,
                    channels: i.length / (n * r)
                }
            });
            if (!a) throw new Error("No response from the AI service.");
            if (a.error) throw new Error("Error from the AI service.");
            if (a.cancel) return null;
            if (!a.output) throw new Error("No valid response from the AI service.");
            const o = a.output;
            return await this.setGuessedAltText(o), e && !this.hasAltTextData() && (this.altTextData = {
                alt: o,
                decorative: !1
            }), o;
        }
        #a() {
            if (this.#e) {
                this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(this.#e).then((s)=>this.#c(s, !0)).finally(()=>this.#f());
                return;
            }
            if (this.#i) {
                const s = this.#i;
                this.#i = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromUrl(s).then((i)=>this.#c(i)).finally(()=>this.#f());
                return;
            }
            if (this.#r) {
                const s = this.#r;
                this.#r = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromFile(s).then((i)=>this.#c(i)).finally(()=>this.#f());
                return;
            }
            const t = document.createElement("input");
            t.type = "file", t.accept = Be.join(",");
            const e = this._uiManager._signal;
            this.#s = new Promise((s)=>{
                t.addEventListener("change", async ()=>{
                    if (!t.files || t.files.length === 0) this.remove();
                    else {
                        this._uiManager.enableWaiting(!0);
                        const i = await this._uiManager.imageManager.getFromFile(t.files[0]);
                        this._reportTelemetry({
                            action: "pdfjs.image.image_selected",
                            data: {
                                alt_text_modal: this._uiManager.useNewAltTextFlow
                            }
                        }), this.#c(i);
                    }
                    s();
                }, {
                    signal: e
                }), t.addEventListener("cancel", ()=>{
                    this.remove(), s();
                }, {
                    signal: e
                });
            }).finally(()=>this.#f()), t.click();
        }
        remove() {
            this.#e && (this.#t = null, this._uiManager.imageManager.deleteId(this.#e), this.#l?.remove(), this.#l = null, this.#d && (clearTimeout(this.#d), this.#d = null)), super.remove();
        }
        rebuild() {
            if (!this.parent) {
                this.#e && this.#a();
                return;
            }
            super.rebuild(), this.div !== null && (this.#e && this.#l === null && this.#a(), this.isAttachedToDOM || this.parent.add(this));
        }
        onceAdded(t) {
            this._isDraggable = !0, t && this.div.focus();
        }
        isEmpty() {
            return !(this.#s || this.#t || this.#i || this.#r || this.#e || this.#o);
        }
        get isResizable() {
            return !0;
        }
        render() {
            if (this.div) return this.div;
            let t, e;
            return this._isCopy && (t = this.x, e = this.y), super.render(), this.div.hidden = !0, this.addAltTextButton(), this.#o || (this.#t ? this.#p() : this.#a()), this._isCopy && this._moveAfterPaste(t, e), this._uiManager.addShouldRescale(this), this.div;
        }
        setCanvas(t, e) {
            const { id: s, bitmap: i } = this._uiManager.imageManager.getFromCanvas(t, e);
            e.remove(), s && this._uiManager.imageManager.isValidId(s) && (this.#e = s, i && (this.#t = i), this.#o = !1, this.#p());
        }
        _onResized() {
            this.onScaleChanging();
        }
        onScaleChanging() {
            if (!this.parent) return;
            this.#d !== null && clearTimeout(this.#d);
            const t = 200;
            this.#d = setTimeout(()=>{
                this.#d = null, this.#g();
            }, t);
        }
        #p() {
            const { div: t } = this;
            let { width: e, height: s } = this.#t;
            const [i, n] = this.pageDimensions, r = .75;
            if (this.width) e = this.width * i, s = this.height * n;
            else if (e > r * i || s > r * n) {
                const h = Math.min(r * i / e, r * n / s);
                e *= h, s *= h;
            }
            const [a, o] = this.parentDimensions;
            this.setDims(e * a / i, s * o / n), this._uiManager.enableWaiting(!1);
            const l = this.#l = document.createElement("canvas");
            l.setAttribute("role", "img"), this.addContainer(l), this.width = e / i, this.height = s / n, this._initialOptions?.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (t.hidden = !1), this.#g(), this.#u || (this.parent.addUndoableEditor(this), this.#u = !0), this._reportTelemetry({
                action: "inserted_image"
            }), this.#n && this.div.setAttribute("aria-description", this.#n);
        }
        copyCanvas(t, e, s = !1) {
            t || (t = 224);
            const { width: i, height: n } = this.#t, r = new Et;
            let a = this.#t, o = i, l = n, h = null;
            if (e) {
                if (i > e || n > e) {
                    const _ = Math.min(e / i, e / n);
                    o = Math.floor(i * _), l = Math.floor(n * _);
                }
                h = document.createElement("canvas");
                const u = h.width = Math.ceil(o * r.sx), f = h.height = Math.ceil(l * r.sy);
                this.#h || (a = this.#m(u, f));
                const g = h.getContext("2d");
                g.filter = this._uiManager.hcmFilter;
                let p = "white", m = "#cfcfd8";
                this._uiManager.hcmFilter !== "none" ? m = "black" : window.matchMedia?.("(prefers-color-scheme: dark)").matches && (p = "#8f8f9d", m = "#42414d");
                const b = 15, y = b * r.sx, A = b * r.sy, v = new OffscreenCanvas(y * 2, A * 2), w = v.getContext("2d");
                w.fillStyle = p, w.fillRect(0, 0, y * 2, A * 2), w.fillStyle = m, w.fillRect(0, 0, y, A), w.fillRect(y, A, y, A), g.fillStyle = g.createPattern(v, "repeat"), g.fillRect(0, 0, u, f), g.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f);
            }
            let d = null;
            if (s) {
                let u, f;
                if (r.symmetric && a.width < t && a.height < t) u = a.width, f = a.height;
                else if (a = this.#t, i > t || n > t) {
                    const m = Math.min(t / i, t / n);
                    u = Math.floor(i * m), f = Math.floor(n * m), this.#h || (a = this.#m(u, f));
                }
                const p = new OffscreenCanvas(u, f).getContext("2d", {
                    willReadFrequently: !0
                });
                p.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f), d = {
                    width: u,
                    height: f,
                    data: p.getImageData(0, 0, u, f).data
                };
            }
            return {
                canvas: h,
                width: o,
                height: l,
                imageData: d
            };
        }
        #m(t, e) {
            const { width: s, height: i } = this.#t;
            let n = s, r = i, a = this.#t;
            for(; n > 2 * t || r > 2 * e;){
                const o = n, l = r;
                n > 2 * t && (n = n >= 16384 ? Math.floor(n / 2) - 1 : Math.ceil(n / 2)), r > 2 * e && (r = r >= 16384 ? Math.floor(r / 2) - 1 : Math.ceil(r / 2));
                const h = new OffscreenCanvas(n, r);
                h.getContext("2d").drawImage(a, 0, 0, o, l, 0, 0, n, r), a = h.transferToImageBitmap();
            }
            return a;
        }
        #g() {
            const [t, e] = this.parentDimensions, { width: s, height: i } = this, n = new Et, r = Math.ceil(s * t * n.sx), a = Math.ceil(i * e * n.sy), o = this.#l;
            if (!o || o.width === r && o.height === a) return;
            o.width = r, o.height = a;
            const l = this.#h ? this.#t : this.#m(r, a), h = o.getContext("2d");
            h.filter = this._uiManager.hcmFilter, h.drawImage(l, 0, 0, l.width, l.height, 0, 0, r, a);
        }
        #b(t) {
            if (t) {
                if (this.#h) {
                    const i = this._uiManager.imageManager.getSvgUrl(this.#e);
                    if (i) return i;
                }
                const e = document.createElement("canvas");
                return { width: e.width, height: e.height } = this.#t, e.getContext("2d").drawImage(this.#t, 0, 0), e.toDataURL();
            }
            if (this.#h) {
                const [e, s] = this.pageDimensions, i = Math.round(this.width * e * Vt.PDF_TO_CSS_UNITS), n = Math.round(this.height * s * Vt.PDF_TO_CSS_UNITS), r = new OffscreenCanvas(i, n);
                return r.getContext("2d").drawImage(this.#t, 0, 0, this.#t.width, this.#t.height, 0, 0, i, n), r.transferToImageBitmap();
            }
            return structuredClone(this.#t);
        }
        static async deserialize(t, e, s) {
            let i = null, n = !1;
            if (t instanceof ri) {
                const { data: { rect: p, rotation: m, id: b, structParent: y, popupRef: A }, container: v, parent: { page: { pageNumber: w } }, canvas: _ } = t;
                let S, E;
                _ ? (delete t.canvas, { id: S, bitmap: E } = s.imageManager.getFromCanvas(v.id, _), _.remove()) : (n = !0, t._hasNoCanvas = !0);
                const C = (await e._structTree.getAriaAttributes(`${We}${b}`))?.get("aria-label") || "";
                i = t = {
                    annotationType: D.STAMP,
                    bitmapId: S,
                    bitmap: E,
                    pageIndex: w - 1,
                    rect: p.slice(0),
                    rotation: m,
                    id: b,
                    deleted: !1,
                    accessibilityData: {
                        decorative: !1,
                        altText: C
                    },
                    isSvg: !1,
                    structParent: y,
                    popupRef: A
                };
            }
            const r = await super.deserialize(t, e, s), { rect: a, bitmap: o, bitmapUrl: l, bitmapId: h, isSvg: d, accessibilityData: u } = t;
            n ? (s.addMissingCanvas(t.id, r), r.#o = !0) : h && s.imageManager.isValidId(h) ? (r.#e = h, o && (r.#t = o)) : r.#i = l, r.#h = d;
            const [f, g] = r.pageDimensions;
            return r.width = (a[2] - a[0]) / f, r.height = (a[3] - a[1]) / g, r.annotationElementId = t.id || null, u && (r.altTextData = u), r._initialData = i, r.#u = !!i, r;
        }
        serialize(t = !1, e = null) {
            if (this.isEmpty()) return null;
            if (this.deleted) return this.serializeDeleted();
            const s = {
                annotationType: D.STAMP,
                bitmapId: this.#e,
                pageIndex: this.pageIndex,
                rect: this.getRect(0, 0),
                rotation: this.rotation,
                isSvg: this.#h,
                structTreeParentId: this._structTreeParentId
            };
            if (t) return s.bitmapUrl = this.#b(!0), s.accessibilityData = this.serializeAltText(!0), s.isCopy = !0, s;
            const { decorative: i, altText: n } = this.serializeAltText(!1);
            if (!i && n && (s.accessibilityData = {
                type: "Figure",
                alt: n
            }), this.annotationElementId) {
                const a = this.#A(s);
                if (a.isSame) return null;
                a.isSameAltText ? delete s.accessibilityData : s.accessibilityData.structParent = this._initialData.structParent ?? -1;
            }
            if (s.id = this.annotationElementId, e === null) return s;
            e.stamps ||= new Map;
            const r = this.#h ? (s.rect[2] - s.rect[0]) * (s.rect[3] - s.rect[1]) : null;
            if (!e.stamps.has(this.#e)) e.stamps.set(this.#e, {
                area: r,
                serialized: s
            }), s.bitmap = this.#b(!1);
            else if (this.#h) {
                const a = e.stamps.get(this.#e);
                r > a.area && (a.area = r, a.serialized.bitmap.close(), a.serialized.bitmap = this.#b(!1));
            }
            return s;
        }
        #A(t) {
            const { pageIndex: e, accessibilityData: { altText: s } } = this._initialData, i = t.pageIndex === e, n = (t.accessibilityData?.alt || "") === s;
            return {
                isSame: !this._hasBeenMoved && !this._hasBeenResized && i && n,
                isSameAltText: n
            };
        }
        renderAnnotationElement(t) {
            return t.updateEdited({
                rect: this.getRect(0, 0)
            }), null;
        }
    }
    St = class {
        #t;
        #e = !1;
        #s = null;
        #i = null;
        #r = null;
        #n = new Map;
        #l = !1;
        #o = !1;
        #d = !1;
        #h = null;
        #u = null;
        #c = null;
        #f = null;
        #a;
        static _initialized = !1;
        static #p = new Map([
            Q,
            as,
            er,
            V,
            At
        ].map((t)=>[
                t._editorType,
                t
            ]));
        constructor({ uiManager: t, pageIndex: e, div: s, structTreeLayer: i, accessibilityManager: n, annotationLayer: r, drawLayer: a, textLayer: o, viewport: l, l10n: h }){
            const d = [
                ...St.#p.values()
            ];
            if (!St._initialized) {
                St._initialized = !0;
                for (const u of d)u.initialize(h, t);
            }
            t.registerEditorTypes(d), this.#a = t, this.pageIndex = e, this.div = s, this.#t = n, this.#s = r, this.viewport = l, this.#c = o, this.drawLayer = a, this._structTree = i, this.#a.addLayer(this);
        }
        get isEmpty() {
            return this.#n.size === 0;
        }
        get isInvisible() {
            return this.isEmpty && this.#a.getMode() === D.NONE;
        }
        updateToolbar(t) {
            this.#a.updateToolbar(t);
        }
        updateMode(t = this.#a.getMode()) {
            switch(this.#y(), t){
                case D.NONE:
                    this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
                    return;
                case D.INK:
                    this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
                    break;
                case D.HIGHLIGHT:
                    this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
                    break;
                default:
                    this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
            }
            this.toggleAnnotationLayerPointerEvents(!1);
            const { classList: e } = this.div;
            for (const s of St.#p.values())e.toggle(`${s._type}Editing`, t === s._editorType);
            this.div.hidden = !1;
        }
        hasTextLayer(t) {
            return t === this.#c?.div;
        }
        setEditingState(t) {
            this.#a.setEditingState(t);
        }
        addCommands(t) {
            this.#a.addCommands(t);
        }
        cleanUndoStack(t) {
            this.#a.cleanUndoStack(t);
        }
        toggleDrawing(t = !1) {
            this.div.classList.toggle("drawing", !t);
        }
        togglePointerEvents(t = !1) {
            this.div.classList.toggle("disabled", !t);
        }
        toggleAnnotationLayerPointerEvents(t = !1) {
            this.#s?.div.classList.toggle("disabled", !t);
        }
        async enable() {
            this.#d = !0, this.div.tabIndex = 0, this.togglePointerEvents(!0);
            const t = new Set;
            for (const s of this.#n.values())s.enableEditing(), s.show(!0), s.annotationElementId && (this.#a.removeChangedExistingAnnotation(s), t.add(s.annotationElementId));
            if (!this.#s) {
                this.#d = !1;
                return;
            }
            const e = this.#s.getEditableAnnotations();
            for (const s of e){
                if (s.hide(), this.#a.isDeletedAnnotationElement(s.data.id) || t.has(s.data.id)) continue;
                const i = await this.deserialize(s);
                i && (this.addOrRebuild(i), i.enableEditing());
            }
            this.#d = !1;
        }
        disable() {
            this.#o = !0, this.div.tabIndex = -1, this.togglePointerEvents(!1);
            const t = new Map, e = new Map;
            for (const i of this.#n.values())if (i.disableEditing(), !!i.annotationElementId) {
                if (i.serialize() !== null) {
                    t.set(i.annotationElementId, i);
                    continue;
                } else e.set(i.annotationElementId, i);
                this.getEditableAnnotation(i.annotationElementId)?.show(), i.remove();
            }
            if (this.#s) {
                const i = this.#s.getEditableAnnotations();
                for (const n of i){
                    const { id: r } = n.data;
                    if (this.#a.isDeletedAnnotationElement(r)) continue;
                    let a = e.get(r);
                    if (a) {
                        a.resetAnnotationElement(n), a.show(!1), n.show();
                        continue;
                    }
                    a = t.get(r), a && (this.#a.addChangedExistingAnnotation(a), a.renderAnnotationElement(n) && a.show(!1)), n.show();
                }
            }
            this.#y(), this.isEmpty && (this.div.hidden = !0);
            const { classList: s } = this.div;
            for (const i of St.#p.values())s.remove(`${i._type}Editing`);
            this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), this.#o = !1;
        }
        getEditableAnnotation(t) {
            return this.#s?.getEditableAnnotation(t) || null;
        }
        setActiveEditor(t) {
            this.#a.getActive() !== t && this.#a.setActiveEditor(t);
        }
        enableTextSelection() {
            if (this.div.tabIndex = -1, this.#c?.div && !this.#f) {
                this.#f = new AbortController;
                const t = this.#a.combinedSignal(this.#f);
                this.#c.div.addEventListener("pointerdown", this.#m.bind(this), {
                    signal: t
                }), this.#c.div.classList.add("highlighting");
            }
        }
        disableTextSelection() {
            this.div.tabIndex = 0, this.#c?.div && this.#f && (this.#f.abort(), this.#f = null, this.#c.div.classList.remove("highlighting"));
        }
        #m(t) {
            this.#a.unselectAll();
            const { target: e } = t;
            if (e === this.#c.div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent")) && this.#c.div.contains(e)) {
                const { isMac: s } = st.platform;
                if (t.button !== 0 || t.ctrlKey && s) return;
                this.#a.showAllEditors("highlight", !0, !0), this.#c.div.classList.add("free"), this.toggleDrawing(), V.startHighlighting(this, this.#a.direction === "ltr", {
                    target: this.#c.div,
                    x: t.x,
                    y: t.y
                }), this.#c.div.addEventListener("pointerup", ()=>{
                    this.#c.div.classList.remove("free"), this.toggleDrawing(!0);
                }, {
                    once: !0,
                    signal: this.#a._signal
                }), t.preventDefault();
            }
        }
        enableClick() {
            if (this.#i) return;
            this.#i = new AbortController;
            const t = this.#a.combinedSignal(this.#i);
            this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
                signal: t
            });
            const e = this.pointerup.bind(this);
            this.div.addEventListener("pointerup", e, {
                signal: t
            }), this.div.addEventListener("pointercancel", e, {
                signal: t
            });
        }
        disableClick() {
            this.#i?.abort(), this.#i = null;
        }
        attach(t) {
            this.#n.set(t.id, t);
            const { annotationElementId: e } = t;
            e && this.#a.isDeletedAnnotationElement(e) && this.#a.removeDeletedAnnotationElement(t);
        }
        detach(t) {
            this.#n.delete(t.id), this.#t?.removePointerInTextLayer(t.contentDiv), !this.#o && t.annotationElementId && this.#a.addDeletedAnnotationElement(t);
        }
        remove(t) {
            this.detach(t), this.#a.removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
        }
        changeParent(t) {
            t.parent !== this && (t.parent && t.annotationElementId && (this.#a.addDeletedAnnotationElement(t.annotationElementId), k.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), t.parent?.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
        }
        add(t) {
            if (!(t.parent === this && t.isAttachedToDOM)) {
                if (this.changeParent(t), this.#a.addEditor(t), this.attach(t), !t.isAttachedToDOM) {
                    const e = t.render();
                    this.div.append(e), t.isAttachedToDOM = !0;
                }
                t.fixAndSetPosition(), t.onceAdded(!this.#d), this.#a.addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
            }
        }
        moveEditorInDOM(t) {
            if (!t.isAttachedToDOM) return;
            const { activeElement: e } = document;
            t.div.contains(e) && !this.#r && (t._focusEventsAllowed = !1, this.#r = setTimeout(()=>{
                this.#r = null, t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", ()=>{
                    t._focusEventsAllowed = !0;
                }, {
                    once: !0,
                    signal: this.#a._signal
                }), e.focus());
            }, 0)), t._structTreeParentId = this.#t?.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
        }
        addOrRebuild(t) {
            t.needsToBeRebuilt() ? (t.parent ||= this, t.rebuild(), t.show()) : this.add(t);
        }
        addUndoableEditor(t) {
            const e = ()=>t._uiManager.rebuild(t), s = ()=>{
                t.remove();
            };
            this.addCommands({
                cmd: e,
                undo: s,
                mustExec: !1
            });
        }
        getNextId() {
            return this.#a.getId();
        }
        get #g() {
            return St.#p.get(this.#a.getMode());
        }
        combinedSignal(t) {
            return this.#a.combinedSignal(t);
        }
        #b(t) {
            const e = this.#g;
            return e ? new e.prototype.constructor(t) : null;
        }
        canCreateNewEmptyEditor() {
            return this.#g?.canCreateNewEmptyEditor();
        }
        async pasteEditor(t, e) {
            this.#a.updateToolbar(t), await this.#a.updateMode(t);
            const { offsetX: s, offsetY: i } = this.#A(), n = this.getNextId(), r = this.#b({
                parent: this,
                id: n,
                x: s,
                y: i,
                uiManager: this.#a,
                isCentered: !0,
                ...e
            });
            r && this.add(r);
        }
        async deserialize(t) {
            return await St.#p.get(t.annotationType ?? t.annotationEditorType)?.deserialize(t, this, this.#a) || null;
        }
        createAndAddNewEditor(t, e, s = {}) {
            const i = this.getNextId(), n = this.#b({
                parent: this,
                id: i,
                x: t.offsetX,
                y: t.offsetY,
                uiManager: this.#a,
                isCentered: e,
                ...s
            });
            return n && this.add(n), n;
        }
        #A() {
            const { x: t, y: e, width: s, height: i } = this.div.getBoundingClientRect(), n = Math.max(0, t), r = Math.max(0, e), a = Math.min(window.innerWidth, t + s), o = Math.min(window.innerHeight, e + i), l = (n + a) / 2 - t, h = (r + o) / 2 - e, [d, u] = this.viewport.rotation % 180 === 0 ? [
                l,
                h
            ] : [
                h,
                l
            ];
            return {
                offsetX: d,
                offsetY: u
            };
        }
        addNewEditor(t = {}) {
            this.createAndAddNewEditor(this.#A(), !0, t);
        }
        setSelected(t) {
            this.#a.setSelected(t);
        }
        toggleSelected(t) {
            this.#a.toggleSelected(t);
        }
        unselect(t) {
            this.#a.unselect(t);
        }
        pointerup(t) {
            const { isMac: e } = st.platform;
            if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !this.#l || (this.#l = !1, this.#g?.isDrawer && this.#g.supportMultipleDrawings)) return;
            if (!this.#e) {
                this.#e = !0;
                return;
            }
            const s = this.#a.getMode();
            if (s === D.STAMP || s === D.SIGNATURE) {
                this.#a.unselectAll();
                return;
            }
            this.createAndAddNewEditor(t, !1);
        }
        pointerdown(t) {
            if (this.#a.getMode() === D.HIGHLIGHT && this.enableTextSelection(), this.#l) {
                this.#l = !1;
                return;
            }
            const { isMac: e } = st.platform;
            if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div) return;
            if (this.#l = !0, this.#g?.isDrawer) {
                this.startDrawingSession(t);
                return;
            }
            const s = this.#a.getActive();
            this.#e = !s || s.isEmpty();
        }
        startDrawingSession(t) {
            if (this.div.focus({
                preventScroll: !0
            }), this.#h) {
                this.#g.startDrawing(this, this.#a, !1, t);
                return;
            }
            this.#a.setCurrentDrawingSession(this), this.#h = new AbortController;
            const e = this.#a.combinedSignal(this.#h);
            this.div.addEventListener("blur", ({ relatedTarget: s })=>{
                s && !this.div.contains(s) && (this.#u = null, this.commitOrRemove());
            }, {
                signal: e
            }), this.#g.startDrawing(this, this.#a, !1, t);
        }
        pause(t) {
            if (t) {
                const { activeElement: e } = document;
                this.div.contains(e) && (this.#u = e);
                return;
            }
            this.#u && setTimeout(()=>{
                this.#u?.focus(), this.#u = null;
            }, 0);
        }
        endDrawingSession(t = !1) {
            return this.#h ? (this.#a.setCurrentDrawingSession(null), this.#h.abort(), this.#h = null, this.#u = null, this.#g.endDrawing(t)) : null;
        }
        findNewParent(t, e, s) {
            const i = this.#a.findParent(e, s);
            return i === null || i === this ? !1 : (i.changeParent(t), !0);
        }
        commitOrRemove() {
            return this.#h ? (this.endDrawingSession(), !0) : !1;
        }
        onScaleChanging() {
            this.#h && this.#g.onScaleChangingWhenDrawing(this);
        }
        destroy() {
            this.commitOrRemove(), this.#a.getActive()?.parent === this && (this.#a.commitOrRemove(), this.#a.setActiveEditor(null)), this.#r && (clearTimeout(this.#r), this.#r = null);
            for (const t of this.#n.values())this.#t?.removePointerInTextLayer(t.contentDiv), t.setParent(null), t.isAttachedToDOM = !1, t.div.remove();
            this.div = null, this.#n.clear(), this.#a.removeLayer(this);
        }
        #y() {
            for (const t of this.#n.values())t.isEmpty() && t.remove();
        }
        render({ viewport: t }) {
            this.viewport = t, Mt(this.div, t);
            for (const e of this.#a.getEditors(this.pageIndex))this.add(e), e.rebuild();
            this.updateMode();
        }
        update({ viewport: t }) {
            this.#a.commitOrRemove(), this.#y();
            const e = this.viewport.rotation, s = t.rotation;
            if (this.viewport = t, Mt(this.div, {
                rotation: s
            }), e !== s) for (const i of this.#n.values())i.rotate(s);
        }
        get pageDimensions() {
            const { pageWidth: t, pageHeight: e } = this.viewport.rawDims;
            return [
                t,
                e
            ];
        }
        get scale() {
            return this.#a.viewParameters.realScale;
        }
    };
    tt = class {
        #t = null;
        #e = new Map;
        #s = new Map;
        static #i = 0;
        constructor({ pageIndex: t }){
            this.pageIndex = t;
        }
        setParent(t) {
            if (!this.#t) {
                this.#t = t;
                return;
            }
            if (this.#t !== t) {
                if (this.#e.size > 0) for (const e of this.#e.values())e.remove(), t.append(e);
                this.#t = t;
            }
        }
        static get _svgFactory() {
            return N(this, "_svgFactory", new ye);
        }
        static #r(t, [e, s, i, n]) {
            const { style: r } = t;
            r.top = `${100 * s}%`, r.left = `${100 * e}%`, r.width = `${100 * i}%`, r.height = `${100 * n}%`;
        }
        #n() {
            const t = tt._svgFactory.create(1, 1, !0);
            return this.#t.append(t), t.setAttribute("aria-hidden", !0), t;
        }
        #l(t, e) {
            const s = tt._svgFactory.createElement("clipPath");
            t.append(s);
            const i = `clip_${e}`;
            s.setAttribute("id", i), s.setAttribute("clipPathUnits", "objectBoundingBox");
            const n = tt._svgFactory.createElement("use");
            return s.append(n), n.setAttribute("href", `#${e}`), n.classList.add("clip"), i;
        }
        #o(t, e) {
            for (const [s, i] of Object.entries(e))i === null ? t.removeAttribute(s) : t.setAttribute(s, i);
        }
        draw(t, e = !1, s = !1) {
            const i = tt.#i++, n = this.#n(), r = tt._svgFactory.createElement("defs");
            n.append(r);
            const a = tt._svgFactory.createElement("path");
            r.append(a);
            const o = `path_p${this.pageIndex}_${i}`;
            a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke"), e && this.#s.set(i, a);
            const l = s ? this.#l(r, o) : null, h = tt._svgFactory.createElement("use");
            return n.append(h), h.setAttribute("href", `#${o}`), this.updateProperties(n, t), this.#e.set(i, n), {
                id: i,
                clipPathId: `url(#${l})`
            };
        }
        drawOutline(t, e) {
            const s = tt.#i++, i = this.#n(), n = tt._svgFactory.createElement("defs");
            i.append(n);
            const r = tt._svgFactory.createElement("path");
            n.append(r);
            const a = `path_p${this.pageIndex}_${s}`;
            r.setAttribute("id", a), r.setAttribute("vector-effect", "non-scaling-stroke");
            let o;
            if (e) {
                const d = tt._svgFactory.createElement("mask");
                n.append(d), o = `mask_p${this.pageIndex}_${s}`, d.setAttribute("id", o), d.setAttribute("maskUnits", "objectBoundingBox");
                const u = tt._svgFactory.createElement("rect");
                d.append(u), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("fill", "white");
                const f = tt._svgFactory.createElement("use");
                d.append(f), f.setAttribute("href", `#${a}`), f.setAttribute("stroke", "none"), f.setAttribute("fill", "black"), f.setAttribute("fill-rule", "nonzero"), f.classList.add("mask");
            }
            const l = tt._svgFactory.createElement("use");
            i.append(l), l.setAttribute("href", `#${a}`), o && l.setAttribute("mask", `url(#${o})`);
            const h = l.cloneNode();
            return i.append(h), l.classList.add("mainOutline"), h.classList.add("secondaryOutline"), this.updateProperties(i, t), this.#e.set(s, i), s;
        }
        finalizeDraw(t, e) {
            this.#s.delete(t), this.updateProperties(t, e);
        }
        updateProperties(t, e) {
            if (!e) return;
            const { root: s, bbox: i, rootClass: n, path: r } = e, a = typeof t == "number" ? this.#e.get(t) : t;
            if (a) {
                if (s && this.#o(a, s), i && tt.#r(a, i), n) {
                    const { classList: o } = a;
                    for (const [l, h] of Object.entries(n))o.toggle(l, h);
                }
                if (r) {
                    const l = a.firstChild.firstChild;
                    this.#o(l, r);
                }
            }
        }
        updateParent(t, e) {
            if (e === this) return;
            const s = this.#e.get(t);
            s && (e.#t.append(s), this.#e.delete(t), e.#e.set(t, s));
        }
        remove(t) {
            this.#s.delete(t), this.#t !== null && (this.#e.get(t).remove(), this.#e.delete(t));
        }
        destroy() {
            this.#t = null;
            for (const t of this.#e.values())t.remove();
            this.#e.clear(), this.#s.clear();
        }
    };
    globalThis.pdfjsTestingUtils = {
        HighlightOutliner: Ue
    };
    globalThis.pdfjsLib = {
        AbortException: Pt,
        AnnotationEditorLayer: St,
        AnnotationEditorParamsType: O,
        AnnotationEditorType: D,
        AnnotationEditorUIManager: Rt,
        AnnotationLayer: rs,
        AnnotationMode: Tt,
        AnnotationType: X,
        build: Ln,
        ColorPicker: pt,
        createValidAbsoluteUrl: Ms,
        DOMSVGFactory: ye,
        DrawLayer: tt,
        FeatureTest: st,
        fetchData: ie,
        getDocument: _n,
        getFilenameFromUrl: Ei,
        getPdfFilenameFromUrl: Ci,
        getUuid: Fs,
        getXfaPageViewport: xi,
        GlobalWorkerOptions: te,
        ImageKind: me,
        InvalidPDFException: Oe,
        isDataScheme: Se,
        isPdfFile: Xe,
        isValidExplicitDest: xn,
        MathClamp: ot,
        noContextMenu: gt,
        normalizeUnicode: vi,
        OPS: be,
        OutputScale: Et,
        PasswordResponses: ui,
        PDFDataRangeTransport: Qs,
        PDFDateString: Os,
        PDFWorker: Z,
        PermissionFlag: di,
        PixelsPerInch: Vt,
        RenderingCancelledException: qe,
        ResponseException: Ae,
        setLayerDimensions: Mt,
        shadow: N,
        SignatureExtractor: Gt,
        stopEvent: Y,
        SupportedImageMimeTypes: Be,
        TextLayer: rt,
        TouchManager: Ee,
        updateUrlHash: Ls,
        Util: P,
        VerbosityLevel: we,
        version: Mn,
        XfaLayer: Zs
    };
})();
export { Pt as AbortException, St as AnnotationEditorLayer, O as AnnotationEditorParamsType, D as AnnotationEditorType, Rt as AnnotationEditorUIManager, rs as AnnotationLayer, Tt as AnnotationMode, X as AnnotationType, pt as ColorPicker, ye as DOMSVGFactory, tt as DrawLayer, st as FeatureTest, te as GlobalWorkerOptions, me as ImageKind, Oe as InvalidPDFException, ot as MathClamp, be as OPS, Et as OutputScale, Qs as PDFDataRangeTransport, Os as PDFDateString, Z as PDFWorker, ui as PasswordResponses, di as PermissionFlag, Vt as PixelsPerInch, qe as RenderingCancelledException, Ae as ResponseException, Gt as SignatureExtractor, Be as SupportedImageMimeTypes, rt as TextLayer, Ee as TouchManager, P as Util, we as VerbosityLevel, Zs as XfaLayer, Ln as build, Ms as createValidAbsoluteUrl, ie as fetchData, _n as getDocument, Ei as getFilenameFromUrl, Ci as getPdfFilenameFromUrl, Fs as getUuid, xi as getXfaPageViewport, Se as isDataScheme, Xe as isPdfFile, xn as isValidExplicitDest, gt as noContextMenu, vi as normalizeUnicode, Mt as setLayerDimensions, N as shadow, Y as stopEvent, Ls as updateUrlHash, Mn as version, __tla };
