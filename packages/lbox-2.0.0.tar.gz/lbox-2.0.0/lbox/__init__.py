__version__ = "2.0.0"

def version():
    return __version__
