v0.1.9
======
- Support for latest python and numpy.

v0.1.8
======
- Support for SUNDIALS 6+

v0.1.7
======
- Avoid using deprecated C-API in CPython 3.9+

v0.1.6
======
- Fix compilation without LAPACK

v0.1.5
======
- Update setup.py

v0.1.3
======
- Better detection of Sundials 3

v0.1.1
======
- Added 'message' in result.
- Gracefully propagate throwed exceptions from C++ side.

v0.1
====
- Initial release
