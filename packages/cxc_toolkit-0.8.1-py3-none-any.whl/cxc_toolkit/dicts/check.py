def has_keys(d, keys):
    """
    Check if d.keys contain keys

    :param d:
    :param keys:
    :type d: dict
    :type keys: set[str]
    """
    pass
