class ImportClassTypeError(TypeError):
    pass


class InitException(Exception):
    pass


class GetattributeException(Exception):
    pass
