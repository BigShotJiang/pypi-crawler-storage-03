__all__ = ["__version__"]


from ._version import __version__
