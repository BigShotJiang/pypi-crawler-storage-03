A Test Program!
===============

.. toctree::
   :maxdepth: 1
   :hidden:

   exercise
   solution
