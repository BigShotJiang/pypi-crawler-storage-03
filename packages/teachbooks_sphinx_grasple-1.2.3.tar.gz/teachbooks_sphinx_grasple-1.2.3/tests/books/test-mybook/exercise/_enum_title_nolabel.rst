_enum_title_nolabel
===================

.. exercise:: Test exercise directive

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
