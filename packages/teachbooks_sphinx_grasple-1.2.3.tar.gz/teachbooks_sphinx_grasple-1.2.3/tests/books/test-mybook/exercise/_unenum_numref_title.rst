_unenum_numref_title
====================

This is a reference :numref:`unen-exc-label`.

This is a second reference :numref:`some text %s <unen-exc-label>`.

This is a third reference :numref:`some text {number} <unen-exc-label>`.

This is a fourth reference :numref:`some text {name} <unen-exc-label>`.
