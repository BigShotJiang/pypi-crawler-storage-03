_unenum_ref_notitle
===================

This is a reference :ref:`unen-exc-notitle`.

This is a second reference :ref:`some text <unen-exc-notitle>`.
