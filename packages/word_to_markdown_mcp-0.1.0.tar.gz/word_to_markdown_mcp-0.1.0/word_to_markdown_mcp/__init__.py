"""Word到Markdown转换器MCP服务器"""

from .server import main

__version__ = "0.1.0"
__all__ = ["main"]