from weave.trace_server.interface.builtin_object_classes import annotation_spec

# Re-export:
AnnotationSpec = annotation_spec.AnnotationSpec
