# rm -rf dist build *.egg-info

# git commit -am "Bump version to 0.2.0"
# git tag v0.2.0
# git push && git push --tags

# python setup.py sdist bdist_wheel
# twine upload dist/*
# pip install lineage-rpg --upgrade