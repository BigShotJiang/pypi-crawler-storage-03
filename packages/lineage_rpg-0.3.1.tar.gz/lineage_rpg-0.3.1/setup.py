from setuptools import setup, find_packages

setup(
    name='lineage-rpg',
    version='0.3.1',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'lineage_rpg=lineage_rpg.main:start_game',
        ],
    },
    python_requires='>=3.6',
)