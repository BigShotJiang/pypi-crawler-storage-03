import "./setup";
import { renderApp } from "routelit-client";

renderApp();
