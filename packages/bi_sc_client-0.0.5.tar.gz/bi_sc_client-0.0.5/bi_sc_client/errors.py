class ErrorApiResponse(Exception):
    pass
