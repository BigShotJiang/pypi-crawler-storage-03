# sciop-cli

a CLI for [sciop](https://sciop.net)!

(docs forthcoming sry)