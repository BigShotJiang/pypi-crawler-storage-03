"""FastMCP File Server - Secure MCP file server with multi-tier authentication."""

__version__ = "1.0.0"
