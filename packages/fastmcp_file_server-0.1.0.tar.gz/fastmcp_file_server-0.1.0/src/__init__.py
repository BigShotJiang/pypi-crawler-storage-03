"""Local File MCP Server - A secure file operations server implementing MCP."""

__version__ = "1.0.0"
__author__ = "MCP File Server"
__description__ = "Model Context Protocol server for secure file operations"
