"""Test package for MCP File Server."""
