# DataModelVersion

The version of the data model used in the data stream. When using `v1`:   - The `signal` cannot be `trace`.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


