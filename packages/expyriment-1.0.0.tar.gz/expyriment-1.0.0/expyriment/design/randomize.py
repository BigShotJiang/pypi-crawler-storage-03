"""This is an alias of the expyriment randomise module.

"""

__author__ = 'Florian Krause <florian@expyriment.org>,\
              Oliver Lindemann <oliver@expyriment.org>'


from .randomise import *
