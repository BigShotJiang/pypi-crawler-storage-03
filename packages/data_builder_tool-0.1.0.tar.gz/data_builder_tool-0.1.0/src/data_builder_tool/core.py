def test():
    print("Hello from log-builder!")


if __name__ == "__main__":
    test()
