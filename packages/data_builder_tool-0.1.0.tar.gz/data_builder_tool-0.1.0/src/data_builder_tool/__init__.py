from .core import test

__all__ = ["test"]
