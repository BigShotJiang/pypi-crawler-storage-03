import {
  createTypekit
} from "../chunk-Y6LX2MYA.js";
import "../chunk-QRPWKJ4C.js";
export {
  createTypekit
};
