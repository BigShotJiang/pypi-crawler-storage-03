const a={version:"1.0.0",commit:"8321f0d7390366e09c2bb99321a7794f3ab9c16c"};export{a as default};
