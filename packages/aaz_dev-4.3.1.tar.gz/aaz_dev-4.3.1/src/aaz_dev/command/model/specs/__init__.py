from ._command_tree import CMDSpecsCommandTree, CMDSpecsCommandGroup, CMDSpecsCommand, CMDSpecsCommandVersion
from ._resource import CMDSpecsResource
