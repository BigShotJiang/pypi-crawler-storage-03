"""
Init for eox-tenant.
"""
__version__ = '14.1.1'
