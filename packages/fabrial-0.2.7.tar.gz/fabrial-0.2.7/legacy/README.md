Old code that I haven't deleted yet because it might be useful. Some of this has to do with integrating Gamry instruments.
