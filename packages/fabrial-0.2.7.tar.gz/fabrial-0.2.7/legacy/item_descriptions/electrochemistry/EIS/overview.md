Run a clone of Gamry Framework's **Potentiostatic EIS.exp** script. This performs a frequency sweep on the selected potentiostats.
