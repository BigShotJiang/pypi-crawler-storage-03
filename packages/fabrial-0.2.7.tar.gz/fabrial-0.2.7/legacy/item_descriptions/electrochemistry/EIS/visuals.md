Bode plots for each potentiostat are shown. The plots show the impedance magnitude vs. frequency.
