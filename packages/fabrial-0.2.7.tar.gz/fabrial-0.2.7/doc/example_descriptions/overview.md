A brief description of what your sequence step does. This file can contain jinja substitutions. For example:

The process records data every {{ INTERVAL }} seconds.

The string "{{ INTERVAL }}" will get replaced by a user-defined substitution when setting the description.
