OVERVIEW_FILENAME = "overview.md"
PARAMETERS_FILENAME = "parameters.toml"
VISUALS_FILENAME = "visuals.md"
DATA_RECORDING_FILENAME = "data_recording.toml"
