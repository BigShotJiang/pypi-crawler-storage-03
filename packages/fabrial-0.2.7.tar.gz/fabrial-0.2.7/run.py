"""Convenience file you can run instead of changing directory to `fabrial`."""

import fabrial

if __name__ == "__main__":
    fabrial.main()
