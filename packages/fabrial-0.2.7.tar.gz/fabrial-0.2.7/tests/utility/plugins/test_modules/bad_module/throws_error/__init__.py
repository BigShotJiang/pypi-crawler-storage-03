# this module should not get loaded because it throws an exception
raise Exception
