def categories():
    # returns the entirely wrong type
    return None
