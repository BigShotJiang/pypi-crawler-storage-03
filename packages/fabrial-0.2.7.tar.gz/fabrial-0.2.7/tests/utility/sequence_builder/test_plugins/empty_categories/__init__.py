from fabrial.utility.sequence_builder import PluginCategory


def categories() -> list[PluginCategory]:
    return []  # intentionally empty
