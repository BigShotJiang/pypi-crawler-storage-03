from setuptools import setup, find_packages

setup(
    name="test_pip_ok",
    version="0.2.0",
    packages=find_packages()
)