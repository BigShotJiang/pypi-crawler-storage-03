import base64
print(base64.b64encode(open('/flag','rb').read()))