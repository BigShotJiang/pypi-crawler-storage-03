def hello():
    print("Hello from winky")