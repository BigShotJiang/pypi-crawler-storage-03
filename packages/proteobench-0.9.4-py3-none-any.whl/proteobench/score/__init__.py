"""
Score module for ProteoBench.
"""
