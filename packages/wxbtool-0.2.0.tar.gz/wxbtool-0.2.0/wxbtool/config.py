from decouple import config

root = config("WXBHOME")
