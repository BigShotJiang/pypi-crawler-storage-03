- go to 'Configuration' / 'Companies' / 'Company Categories'

![](../static/description/res_company_category_tree.png)

- Create new company categories.

For each category, you can define a type 'view' or 'normal' (as for
product categories).

![](../static/description/res_company_category_form.png)

- Go to your companies, and set for each a category in the
  'Configuration' tab.

![](../static/description/res_company_form.png)
