This module adds company categories concept.

On the company form view, you can set the category of the company.

This module is usefull for statistical purposes, in a multi company
context.
