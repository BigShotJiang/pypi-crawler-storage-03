from cookiecutter_example.foo import foo


def test_foo():
    assert foo("foo") == "foo"
