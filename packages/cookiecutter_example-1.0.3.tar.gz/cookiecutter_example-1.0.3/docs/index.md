# cookiecutter-example

[![Release](https://img.shields.io/github/v/release/reece/cookiecutter-example)](https://img.shields.io/github/v/release/reece/cookiecutter-example)
[![Build status](https://img.shields.io/github/actions/workflow/status/reece/cookiecutter-example/main.yml?branch=main)](https://github.com/reece/cookiecutter-example/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/reece/cookiecutter-example)](https://img.shields.io/github/commit-activity/m/reece/cookiecutter-example)
[![License](https://img.shields.io/github/license/reece/cookiecutter-example)](https://img.shields.io/github/license/reece/cookiecutter-example)

This is a template repository for Python projects that use uv for their dependency management.
