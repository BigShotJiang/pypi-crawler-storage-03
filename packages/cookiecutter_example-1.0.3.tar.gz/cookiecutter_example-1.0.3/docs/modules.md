::: cookiecutter_example.foo
