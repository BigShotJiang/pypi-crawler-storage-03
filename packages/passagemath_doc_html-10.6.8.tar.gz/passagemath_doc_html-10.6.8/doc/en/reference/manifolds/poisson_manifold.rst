Poisson Manifolds
=================

.. toctree::
   :maxdepth: 3

   sage/manifolds/differentiable/poisson_tensor

   sage/manifolds/differentiable/symplectic_form

   sage/manifolds/differentiable/examples/symplectic_space
