.. _sec-troubles:

Troubleshooting
===============

Please `contact the passagemath project <https://github.com/passagemath/passagemath?tab=readme-ov-file#passagemath-community>`_
with the relevant information (terminal output, log files) if any difficulties arise.
