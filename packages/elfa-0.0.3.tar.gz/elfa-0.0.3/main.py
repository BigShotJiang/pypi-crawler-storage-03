import elfa


def main():
    print("Hello from elfa!")


if __name__ == "__main__":
    main()
