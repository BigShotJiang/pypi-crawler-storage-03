Heading 1 with *bold*
=====================

.. contents::

.. toctree::

   other

Some text with a link to `Google <https://google.com>`_ and `<https://example.com>`_.

This is **bold** and *italic* and ``inline code``.

.. note::

   This is an important note that demonstrates the note admonition support.

   Some nested content:

   * First level item in note
   * Another first level item
   * Another first level item

     * Second level nested in note
     * Another second level item

       * Third level nested in note (deep!)
       * Another third level item

         * Fourth level nested in note (very deep!)
         * Another fourth level item
         * Another fourth level item

           * Fifth level nested in note (extremely deep!)
           * Another fifth level item

         * Back to fourth level in note

       * Back to third level in note

     * Back to second level in note

   * Back to first level in note

.. warning::

   This is a warning that demonstrates the warning admonition support.

   .. code-block:: python

      """Python code nested in an admonition."""


      def hello_world() -> int:
          """Return the answer."""
          return 42


      hello_world()

   .. warning::

      This is a warning that demonstrates the warning admonition support.

      .. warning::

         This is a warning that demonstrates the nested admonition support.

         .. warning::

            This is a warning that demonstrates the even deeper admonition support.

.. tip::

   This is a helpful tip that demonstrates the tip admonition support.

.. collapse:: Click to expand this section

   This content is hidden by default and can be expanded by clicking the toggle.

   It supports **all the same formatting** as regular content:

   * Bullet points
   * ``Code snippets``
   * *Emphasis* and **bold text**

   .. note::

      You can even nest admonitions inside collapsible sections!

   .. code-block:: python

      """Run code within a collapse."""


      def example_function() -> str:
          """Example code inside a collapsed section."""
          return "This is hidden by default"


      example_function()

.. collapse:: Another collapsible section

   You can have multiple collapsible sections in your document.

   Each one can contain different types of content.

.. code-block:: python

   """Python code."""


   def hello_world() -> int:
       """Return the answer."""
       return 42


   hello_world()

.. code-block:: console

   $ pip install sphinx-notionbuilder

Some key features:

* Easy integration with **Sphinx**
* Converts RST to Notion-compatible format

  * Supports nested bullet points (new!)
  * Deep nesting now works with multiple levels

    * Third level nesting is now supported
    * Fourth level also works

      * Fifth level nesting works too!
      * The upload script handles deep nesting automatically

    * Back to third level

  * Back to second level

* Supports code blocks with syntax highlighting
* Handles headings, links, and formatting
* Works with bullet points like this one
* Now supports note, warning, and tip admonitions!

Heading 2 with *italic*
-----------------------

Heading 3 with ``inline code``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Regular paragraph.

    This is a multi-line
    block quote with
    multiple lines.


Table Example
-------------

Here is a simple table:

+----------+----------+
| Header 1 | Header 2 |
+==========+==========+
| Cell 1   | Cell 2   |
+----------+----------+
| Cell 3   | Cell 4   |
+----------+----------+
