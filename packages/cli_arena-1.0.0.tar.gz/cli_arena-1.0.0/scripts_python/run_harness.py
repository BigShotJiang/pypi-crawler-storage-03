print("run_harness.py is deprecated. Please use '(uv run) tb run --help' instead.")
exit(1)
