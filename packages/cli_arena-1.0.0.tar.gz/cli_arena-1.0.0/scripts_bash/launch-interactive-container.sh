#!/bin/bash

echo "DEPRECATED: This script is deprecated. Run 'tb tasks interact --help' instead. Don't forget to prefix with 'uv run' if you're using uv."
exit 1
