import sys
from green_mbtools import pesto

sys.modules['mbanalysis'] = pesto
