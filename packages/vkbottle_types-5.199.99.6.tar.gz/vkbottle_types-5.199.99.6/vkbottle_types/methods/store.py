from vkbottle_types.codegen.methods.store import *  # noqa: F403,F401
