from vkbottle_types.codegen.methods.stats import *  # noqa: F403,F401
