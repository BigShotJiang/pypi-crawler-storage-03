from vkbottle_types.codegen.methods.app_widgets import *  # noqa: F403,F401
