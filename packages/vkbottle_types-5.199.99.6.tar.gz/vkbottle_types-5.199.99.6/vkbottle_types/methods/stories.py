from vkbottle_types.codegen.methods.stories import *  # noqa: F403,F401
