from vkbottle_types.codegen.methods.widgets import *  # noqa: F403,F401
