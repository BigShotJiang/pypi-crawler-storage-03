from vkbottle_types.codegen.methods.board import *  # noqa: F403,F401
