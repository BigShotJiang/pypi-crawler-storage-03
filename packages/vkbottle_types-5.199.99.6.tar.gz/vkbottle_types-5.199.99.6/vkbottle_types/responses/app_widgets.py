from vkbottle_types.codegen.responses.app_widgets import *  # noqa: F403,F401
