from vkbottle_types.codegen.responses.gifts import *  # noqa: F403,F401
