from vkbottle_types.codegen.responses.lead_forms import *  # noqa: F403,F401
