from vkbottle_types.codegen.responses.friends import *  # noqa: F403,F401
