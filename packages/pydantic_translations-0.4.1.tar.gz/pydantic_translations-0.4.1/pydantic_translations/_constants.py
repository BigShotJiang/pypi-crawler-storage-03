from __future__ import annotations

from pathlib import Path


LOCALES_PATH = Path(__file__).parent / 'locales'
DEFAULT_LANGUAGE = 'en'
