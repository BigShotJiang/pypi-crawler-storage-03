"""Translations for pydantic errors.
"""
from ._translator import Translator


__version__ = '0.4.1'
__all__ = ['Translator']
