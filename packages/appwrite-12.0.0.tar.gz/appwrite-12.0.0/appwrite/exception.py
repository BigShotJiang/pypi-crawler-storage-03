class AppwriteException(Exception):
    def __init__(self, message, code = 0, type = None, response = None):
        self.message = message
        self.code = code
        self.type = type
        self.response = response
        super().__init__(self.message)