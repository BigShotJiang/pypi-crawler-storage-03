/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Packages",url:"namespaces.html",children:[
{text:"Package List",url:"namespaces.html"},
{text:"Package Members",url:"namespacemembers.html",children:[
{text:"All",url:"namespacemembers.html",children:[
{text:"a",url:"namespacemembers.html#index_a"},
{text:"b",url:"namespacemembers.html#index_b"},
{text:"c",url:"namespacemembers.html#index_c"},
{text:"d",url:"namespacemembers.html#index_d"},
{text:"e",url:"namespacemembers.html#index_e"},
{text:"f",url:"namespacemembers.html#index_f"},
{text:"g",url:"namespacemembers.html#index_g"},
{text:"h",url:"namespacemembers.html#index_h"},
{text:"i",url:"namespacemembers.html#index_i"},
{text:"l",url:"namespacemembers.html#index_l"},
{text:"m",url:"namespacemembers.html#index_m"},
{text:"p",url:"namespacemembers.html#index_p"},
{text:"r",url:"namespacemembers.html#index_r"},
{text:"s",url:"namespacemembers.html#index_s"},
{text:"t",url:"namespacemembers.html#index_t"},
{text:"u",url:"namespacemembers.html#index_u"},
{text:"v",url:"namespacemembers.html#index_v"},
{text:"w",url:"namespacemembers.html#index_w"},
{text:"z",url:"namespacemembers.html#index_z"}]},
{text:"Functions",url:"namespacemembers_func.html",children:[
{text:"a",url:"namespacemembers_func.html#index_a"},
{text:"b",url:"namespacemembers_func.html#index_b"},
{text:"c",url:"namespacemembers_func.html#index_c"},
{text:"d",url:"namespacemembers_func.html#index_d"},
{text:"e",url:"namespacemembers_func.html#index_e"},
{text:"f",url:"namespacemembers_func.html#index_f"},
{text:"g",url:"namespacemembers_func.html#index_g"},
{text:"i",url:"namespacemembers_func.html#index_i"},
{text:"l",url:"namespacemembers_func.html#index_l"},
{text:"m",url:"namespacemembers_func.html#index_m"},
{text:"p",url:"namespacemembers_func.html#index_p"},
{text:"r",url:"namespacemembers_func.html#index_r"},
{text:"s",url:"namespacemembers_func.html#index_s"},
{text:"t",url:"namespacemembers_func.html#index_t"},
{text:"v",url:"namespacemembers_func.html#index_v"},
{text:"w",url:"namespacemembers_func.html#index_w"}]},
{text:"Variables",url:"namespacemembers_vars.html",children:[
{text:"a",url:"namespacemembers_vars.html#index_a"},
{text:"b",url:"namespacemembers_vars.html#index_b"},
{text:"c",url:"namespacemembers_vars.html#index_c"},
{text:"d",url:"namespacemembers_vars.html#index_d"},
{text:"e",url:"namespacemembers_vars.html#index_e"},
{text:"f",url:"namespacemembers_vars.html#index_f"},
{text:"g",url:"namespacemembers_vars.html#index_g"},
{text:"h",url:"namespacemembers_vars.html#index_h"},
{text:"i",url:"namespacemembers_vars.html#index_i"},
{text:"l",url:"namespacemembers_vars.html#index_l"},
{text:"m",url:"namespacemembers_vars.html#index_m"},
{text:"p",url:"namespacemembers_vars.html#index_p"},
{text:"r",url:"namespacemembers_vars.html#index_r"},
{text:"s",url:"namespacemembers_vars.html#index_s"},
{text:"t",url:"namespacemembers_vars.html#index_t"},
{text:"u",url:"namespacemembers_vars.html#index_u"},
{text:"v",url:"namespacemembers_vars.html#index_v"},
{text:"w",url:"namespacemembers_vars.html#index_w"},
{text:"z",url:"namespacemembers_vars.html#index_z"}]}]}]},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Hierarchy",url:"inherits.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"_",url:"functions.html#index__5F"},
{text:"a",url:"functions_a.html#index_a"},
{text:"b",url:"functions_b.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"e",url:"functions_e.html#index_e"},
{text:"f",url:"functions_f.html#index_f"},
{text:"g",url:"functions_g.html#index_g"},
{text:"h",url:"functions_h.html#index_h"},
{text:"i",url:"functions_i.html#index_i"},
{text:"j",url:"functions_j.html#index_j"},
{text:"k",url:"functions_k.html#index_k"},
{text:"l",url:"functions_l.html#index_l"},
{text:"m",url:"functions_m.html#index_m"},
{text:"n",url:"functions_n.html#index_n"},
{text:"p",url:"functions_p.html#index_p"},
{text:"q",url:"functions_q.html#index_q"},
{text:"r",url:"functions_r.html#index_r"},
{text:"s",url:"functions_s.html#index_s"},
{text:"t",url:"functions_t.html#index_t"},
{text:"u",url:"functions_u.html#index_u"},
{text:"v",url:"functions_v.html#index_v"},
{text:"w",url:"functions_w.html#index_w"},
{text:"x",url:"functions_x.html#index_x"},
{text:"y",url:"functions_y.html#index_y"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"_",url:"functions_func.html#index__5F"},
{text:"a",url:"functions_func.html#index_a"},
{text:"b",url:"functions_func.html#index_b"},
{text:"c",url:"functions_func.html#index_c"},
{text:"d",url:"functions_func.html#index_d"},
{text:"e",url:"functions_func.html#index_e"},
{text:"f",url:"functions_func.html#index_f"},
{text:"g",url:"functions_func.html#index_g"},
{text:"i",url:"functions_func.html#index_i"},
{text:"j",url:"functions_func.html#index_j"},
{text:"l",url:"functions_func.html#index_l"},
{text:"n",url:"functions_func.html#index_n"},
{text:"r",url:"functions_func.html#index_r"},
{text:"s",url:"functions_func.html#index_s"},
{text:"v",url:"functions_func.html#index_v"},
{text:"w",url:"functions_func.html#index_w"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"d",url:"functions_vars.html#index_d"},
{text:"g",url:"functions_vars.html#index_g"},
{text:"h",url:"functions_vars.html#index_h"},
{text:"i",url:"functions_vars.html#index_i"},
{text:"j",url:"functions_vars.html#index_j"},
{text:"k",url:"functions_vars.html#index_k"},
{text:"l",url:"functions_vars.html#index_l"},
{text:"m",url:"functions_vars.html#index_m"},
{text:"n",url:"functions_vars.html#index_n"},
{text:"p",url:"functions_vars.html#index_p"},
{text:"q",url:"functions_vars.html#index_q"},
{text:"r",url:"functions_vars.html#index_r"},
{text:"s",url:"functions_vars.html#index_s"},
{text:"t",url:"functions_vars.html#index_t"},
{text:"u",url:"functions_vars.html#index_u"},
{text:"v",url:"functions_vars.html#index_v"},
{text:"w",url:"functions_vars.html#index_w"},
{text:"x",url:"functions_vars.html#index_x"},
{text:"y",url:"functions_vars.html#index_y"}]}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"}]}]}
