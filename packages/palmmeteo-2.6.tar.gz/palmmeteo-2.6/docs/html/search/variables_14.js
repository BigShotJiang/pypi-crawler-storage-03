var searchData=
[
  ['validations_0',['validations',['../classpalmmeteo_1_1library_1_1QuantityCalculator.html#a2d37f7aae496e00b51e4be6df80b02d4',1,'palmmeteo::library::QuantityCalculator']]],
  ['verbose_1',['verbose',['../namespacepalmmeteo_1_1logging.html#a1577955255cd6e884698f126d9d68740',1,'palmmeteo::logging']]]
];
