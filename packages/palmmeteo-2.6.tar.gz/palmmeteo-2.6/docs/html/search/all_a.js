var searchData=
[
  ['j0_5fy_0',['j0_y',['../classpalmmeteo__stdplugins_1_1wrf__utils_1_1WRFCoordTransform.html#a2f5491d66a257548c7a8b09fc602ba46',1,'palmmeteo_stdplugins.wrf_utils.WRFCoordTransform.j0_y()'],['../classpalmmeteo__stdplugins_1_1wrf__utils_1_1CAMxCoordTransform.html#a1c59b026b9c6386e2c018c253c45c2a1',1,'palmmeteo_stdplugins.wrf_utils.CAMxCoordTransform.j0_y()']]],
  ['ji_5fto_5flatlon_1',['ji_to_latlon',['../classpalmmeteo_1_1library_1_1LatLonRegularGrid.html#a125598cb6e22e32909dd2297a0d422a9',1,'palmmeteo.library.LatLonRegularGrid.ji_to_latlon()'],['../classpalmmeteo__stdplugins_1_1aladin_1_1AladinCoordTransform.html#a87b1ba5801664c1ec94c24411d3a9f98',1,'palmmeteo_stdplugins.aladin.AladinCoordTransform.ji_to_latlon()'],['../classpalmmeteo__stdplugins_1_1wrf__utils_1_1WRFCoordTransform.html#a35fd059396f4da354d6e8e6283b20c90',1,'palmmeteo_stdplugins.wrf_utils.WRFCoordTransform.ji_to_latlon()']]]
];
