var searchData=
[
  ['dispatch_2epy_0',['dispatch.py',['../dispatch_8py.html',1,'']]]
];
