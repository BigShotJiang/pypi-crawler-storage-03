var searchData=
[
  ['emisplugin_0',['EmisPlugin',['../classpalmmeteo__stdplugins_1_1meteo_1_1EmisPlugin.html',1,'palmmeteo_stdplugins::meteo']]]
];
