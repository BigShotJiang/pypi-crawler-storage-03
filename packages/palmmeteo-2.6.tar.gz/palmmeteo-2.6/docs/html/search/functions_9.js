var searchData=
[
  ['ji_5fto_5flatlon_0',['ji_to_latlon',['../classpalmmeteo__stdplugins_1_1wrf__utils_1_1WRFCoordTransform.html#a35fd059396f4da354d6e8e6283b20c90',1,'palmmeteo_stdplugins::wrf_utils::WRFCoordTransform']]]
];
