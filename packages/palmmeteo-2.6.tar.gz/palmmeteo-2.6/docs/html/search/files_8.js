var searchData=
[
  ['plugins_2epy_0',['plugins.py',['../plugins_8py.html',1,'']]]
];
