# Pyarmor 8.4.7 (basic), 004363, 2025-08-17T06:48:07.365446
from .pyarmor_runtime import __pyarmor__
