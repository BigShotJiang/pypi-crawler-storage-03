/* eslint-disable @typescript-eslint/no-var-requires */
/* eslint-disable no-undef */
__webpack_public_path__ =
  document.querySelector('body')?.getAttribute('data-base-url') +
  'nbextensions/sagemaker_sparkmonitor/';
const defaultExport = require('./index');
module.exports = defaultExport;
