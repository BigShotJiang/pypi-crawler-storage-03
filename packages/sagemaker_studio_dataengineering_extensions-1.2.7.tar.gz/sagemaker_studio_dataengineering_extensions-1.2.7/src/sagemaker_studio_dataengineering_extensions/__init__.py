# do not edit this version manually
# do not commit this file when creating CRs
# see INTERNAL_README.md for release and testing build instructions
__version__="1.2.7"
