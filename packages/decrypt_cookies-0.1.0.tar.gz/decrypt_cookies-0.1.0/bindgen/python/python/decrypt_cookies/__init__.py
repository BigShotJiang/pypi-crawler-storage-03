#!/usr/bin/env python3

from .decrypt_cookies_py import *
