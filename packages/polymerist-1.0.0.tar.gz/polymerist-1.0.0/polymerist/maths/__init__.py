'''Module for general mathematical operations, calculations, and notation'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
