'''Additional data shipped along with polymerist source code'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
