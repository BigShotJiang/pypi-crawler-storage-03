'''Unit tests for `rescharge` package'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
