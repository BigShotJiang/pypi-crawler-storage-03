'''Unit tests for `numbersys` package'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
