'''Utilities for tracking, wrapping, and redirecting logging output'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
