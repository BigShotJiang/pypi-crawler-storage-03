'''Decorators for modifying functions and classes. Supply useful behaviors and/or eliminate boilerplate'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
