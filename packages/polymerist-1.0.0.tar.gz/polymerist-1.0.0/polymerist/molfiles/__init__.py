'''Utilities for reading from and writing to various molecular file formats'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'