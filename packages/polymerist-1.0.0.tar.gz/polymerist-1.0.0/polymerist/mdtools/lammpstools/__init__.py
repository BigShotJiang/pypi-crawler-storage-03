'''Tools for interfacing with parsing input files from LAMMPS'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
