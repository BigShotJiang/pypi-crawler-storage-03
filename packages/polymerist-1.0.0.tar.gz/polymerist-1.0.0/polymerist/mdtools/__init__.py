'''Tools for interfacing with and setting up systems for various molecular dynamics packages'''

__author__ = 'Timotej Bernat'
__email__ = 'timotej.bernat@colorado.edu'
