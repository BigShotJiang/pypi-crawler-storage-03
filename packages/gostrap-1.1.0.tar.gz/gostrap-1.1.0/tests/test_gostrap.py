def test_test() -> None:
    """Test that ..."""
