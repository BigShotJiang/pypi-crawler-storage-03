# -*- coding: utf-8 -*-
# Copyright © 2015 ACSONE SA/NV
# License LGPLv3 (http://www.gnu.org/licenses/lgpl-3.0-standalone.html)


from .core import get_addon_metadata


__all__ = [get_addon_metadata.__name__]
