from .model_zoo import vgg_hyper  # noqa: F401
