

# 安装azpytools
pip install azpytools
