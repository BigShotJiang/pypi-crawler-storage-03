# -*- coding: utf-8 -*-
"""
Sub-package for statistics/distributions.
"""
from . import empirical, gumbel, gumbelmin, weibull
