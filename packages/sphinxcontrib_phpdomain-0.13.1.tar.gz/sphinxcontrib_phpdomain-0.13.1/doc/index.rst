.. include:: ../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   usage
   reference
   changes

* :ref:`genindex`
* :ref:`search`

