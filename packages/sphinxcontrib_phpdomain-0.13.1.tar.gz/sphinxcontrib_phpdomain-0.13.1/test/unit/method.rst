Simple method
#############

.. php:class:: Foo

.. php:method:: test($a, ...$args)

    Simple test method.

    :param array $args: Associative array

Cross linking
=============

- :php:meth:`Foo::test()`
