Simple NS
#########

.. php:namespace:: Foo

.. php:class:: A

.. php:method:: simplify()

Cross linking
=============

- :php:meth:`A::simplify`
