# Test: Build all files

:::{toctree}
:glob:

**
:::
