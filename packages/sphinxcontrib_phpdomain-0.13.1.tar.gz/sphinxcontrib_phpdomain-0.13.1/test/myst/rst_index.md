```{eval-rst}
Welcome to sphinxcontrib-phpdomain-acceptancetest's documentation!
===================================================================

Contents:

.. toctree::
   :maxdepth: 2

   rst_doc
   rst_doc2
   rst_nesting_regression

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
```
