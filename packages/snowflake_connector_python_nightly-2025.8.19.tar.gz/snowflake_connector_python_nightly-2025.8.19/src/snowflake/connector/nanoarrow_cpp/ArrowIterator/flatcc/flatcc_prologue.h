/* Include guard intentionally left out. */

#define PDIAGNOSTIC_IGNORE_UNUSED
#include "flatcc/portable/pdiagnostic_push.h"

#ifdef __cplusplus
extern "C" {
#endif
