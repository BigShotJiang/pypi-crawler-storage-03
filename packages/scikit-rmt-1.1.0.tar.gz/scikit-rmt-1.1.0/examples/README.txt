Examples
========

Examples of several functionalities of the package.