skrmt package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   skrmt.covariance
   skrmt.ensemble

Module contents
---------------

.. automodule:: skrmt
   :members:
   :undoc-members:
   :show-inheritance:
