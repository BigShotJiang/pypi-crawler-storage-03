"""
scikit-rmt version information.
"""
__version__ = "1.1.0"
__version_info__ = (1, 1, 0)
