"""
scikit-rmt package initialization.
"""
from ._version import __version__, __version_info__
