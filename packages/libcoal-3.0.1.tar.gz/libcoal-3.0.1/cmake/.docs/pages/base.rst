Basics
******

.. cmakemodule:: ../../base.cmake

.. cmakemodule:: ../../header.cmake

.. setmode:: user

.. cmakemodule:: ../../version.cmake

.. cmakemodule:: ../../cxx-standard.cmake

.. _minimal-working-example:

Minimal working example
=======================

.. literalinclude:: ../examples/minimal.cmake
  :language: cmake

Code documentation using Doxygen
================================
.. cmakemodule:: ../../doxygen.cmake
