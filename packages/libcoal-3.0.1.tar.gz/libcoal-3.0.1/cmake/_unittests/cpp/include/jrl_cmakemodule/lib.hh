void lib_function();
