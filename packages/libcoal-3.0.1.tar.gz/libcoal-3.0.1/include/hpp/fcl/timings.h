#include <hpp/fcl/coal.hpp>
#include <coal/timings.h>
