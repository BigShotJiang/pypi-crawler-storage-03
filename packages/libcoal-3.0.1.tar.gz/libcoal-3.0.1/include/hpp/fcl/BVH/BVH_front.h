#include <hpp/fcl/coal.hpp>
#include <coal/BVH/BVH_front.h>
