#include <hpp/fcl/coal.hpp>
#include <coal/BVH/BVH_model.h>
