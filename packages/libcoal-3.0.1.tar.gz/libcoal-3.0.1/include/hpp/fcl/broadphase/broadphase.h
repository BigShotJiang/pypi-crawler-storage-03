#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/broadphase.h>
