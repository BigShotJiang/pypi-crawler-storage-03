#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/broadphase_dynamic_AABB_tree.h>
