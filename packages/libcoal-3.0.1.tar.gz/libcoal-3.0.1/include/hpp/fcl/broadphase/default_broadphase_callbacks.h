#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/default_broadphase_callbacks.h>
