#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/broadphase_callbacks.h>
