#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/sparse_hash_table-inl.h>
