#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/node_base-inl.h>
