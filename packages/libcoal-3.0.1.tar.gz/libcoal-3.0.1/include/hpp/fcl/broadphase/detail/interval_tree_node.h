#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/interval_tree_node.h>
