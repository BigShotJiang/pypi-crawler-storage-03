#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/hierarchy_tree_array.h>
