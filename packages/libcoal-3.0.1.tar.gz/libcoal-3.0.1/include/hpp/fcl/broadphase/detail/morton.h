#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/morton.h>
