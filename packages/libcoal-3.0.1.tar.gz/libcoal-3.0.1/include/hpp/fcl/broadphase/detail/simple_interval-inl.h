#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/simple_interval-inl.h>
