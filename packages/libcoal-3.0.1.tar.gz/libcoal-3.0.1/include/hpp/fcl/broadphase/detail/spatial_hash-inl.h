#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/detail/spatial_hash-inl.h>
