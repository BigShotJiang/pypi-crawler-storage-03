#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/broadphase_continuous_collision_manager-inl.h>
