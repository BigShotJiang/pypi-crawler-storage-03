#include <hpp/fcl/coal.hpp>
#include <coal/broadphase/broadphase_bruteforce.h>
