#include <hpp/fcl/coal.hpp>
#include <coal/distance_func_matrix.h>
