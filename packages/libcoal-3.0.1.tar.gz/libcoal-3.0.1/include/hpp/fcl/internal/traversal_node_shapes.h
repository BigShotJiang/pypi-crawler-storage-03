#include <hpp/fcl/coal.hpp>
#include <coal/internal/traversal_node_shapes.h>
