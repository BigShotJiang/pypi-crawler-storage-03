#include <hpp/fcl/coal.hpp>
#include <coal/internal/traversal_node_bvh_shape.h>
