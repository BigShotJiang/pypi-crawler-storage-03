#include <hpp/fcl/coal.hpp>
#include <coal/internal/BV_fitter.h>
