#include <hpp/fcl/coal.hpp>
#include <coal/internal/shape_shape_func.h>
