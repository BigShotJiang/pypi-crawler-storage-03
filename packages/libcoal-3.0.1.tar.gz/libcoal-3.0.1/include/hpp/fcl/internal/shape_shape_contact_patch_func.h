#include <hpp/fcl/coal.hpp>
#include <coal/internal/shape_shape_contact_patch_func.h>
