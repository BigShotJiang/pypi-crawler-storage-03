#include <hpp/fcl/coal.hpp>
#include <coal/internal/intersect.h>
