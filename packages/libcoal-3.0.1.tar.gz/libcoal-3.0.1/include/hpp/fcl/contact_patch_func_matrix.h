#include <hpp/fcl/coal.hpp>
#include <coal/contact_patch_func_matrix.h>
