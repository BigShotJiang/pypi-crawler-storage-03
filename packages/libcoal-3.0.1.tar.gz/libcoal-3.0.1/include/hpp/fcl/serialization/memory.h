#include <hpp/fcl/coal.hpp>
#include <coal/serialization/memory.h>
