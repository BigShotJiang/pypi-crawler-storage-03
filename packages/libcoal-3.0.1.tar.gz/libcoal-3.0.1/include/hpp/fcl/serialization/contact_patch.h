#include <hpp/fcl/coal.hpp>
#include <coal/serialization/contact_patch.h>
