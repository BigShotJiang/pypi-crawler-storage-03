#include <hpp/fcl/coal.hpp>
#include <coal/serialization/convex.h>
