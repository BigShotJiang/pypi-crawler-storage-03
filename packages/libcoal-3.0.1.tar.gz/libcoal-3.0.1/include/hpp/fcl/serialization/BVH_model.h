#include <hpp/fcl/coal.hpp>
#include <coal/serialization/BVH_model.h>
