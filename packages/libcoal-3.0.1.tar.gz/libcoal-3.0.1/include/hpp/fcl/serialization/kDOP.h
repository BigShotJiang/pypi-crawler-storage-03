#include <hpp/fcl/coal.hpp>
#include <coal/serialization/kDOP.h>
