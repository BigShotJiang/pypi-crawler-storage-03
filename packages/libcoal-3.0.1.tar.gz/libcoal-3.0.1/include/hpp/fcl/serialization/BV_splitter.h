#include <hpp/fcl/coal.hpp>
#include <coal/serialization/BV_splitter.h>
