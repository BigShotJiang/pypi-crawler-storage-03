#include <hpp/fcl/coal.hpp>
#include <coal/serialization/OBB.h>
