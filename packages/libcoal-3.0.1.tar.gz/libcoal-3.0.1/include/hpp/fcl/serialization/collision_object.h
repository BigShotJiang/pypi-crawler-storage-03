#include <hpp/fcl/coal.hpp>
#include <coal/serialization/collision_object.h>
