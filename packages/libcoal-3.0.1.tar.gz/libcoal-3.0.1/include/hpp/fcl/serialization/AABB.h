#include <hpp/fcl/coal.hpp>
#include <coal/serialization/AABB.h>
