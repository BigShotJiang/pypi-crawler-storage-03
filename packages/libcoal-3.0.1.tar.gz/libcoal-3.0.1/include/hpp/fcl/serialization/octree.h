#include <hpp/fcl/coal.hpp>
#include <coal/serialization/octree.h>
