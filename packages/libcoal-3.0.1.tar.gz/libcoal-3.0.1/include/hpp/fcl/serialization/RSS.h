#include <hpp/fcl/coal.hpp>
#include <coal/serialization/RSS.h>
