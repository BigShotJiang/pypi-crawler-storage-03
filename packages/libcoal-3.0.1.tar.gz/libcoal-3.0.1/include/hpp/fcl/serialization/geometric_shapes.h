#include <hpp/fcl/coal.hpp>
#include <coal/serialization/geometric_shapes.h>
