#include <hpp/fcl/coal.hpp>
#include <coal/serialization/hfield.h>
