#include <hpp/fcl/coal.hpp>
#include <coal/shape/geometric_shape_to_BVH_model.h>
