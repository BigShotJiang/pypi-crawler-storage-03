#include <hpp/fcl/coal.hpp>
#include <coal/shape/convex.hxx>
