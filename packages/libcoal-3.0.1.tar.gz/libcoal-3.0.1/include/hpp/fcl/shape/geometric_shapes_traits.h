#include <hpp/fcl/coal.hpp>
#include <coal/shape/geometric_shapes_traits.h>
