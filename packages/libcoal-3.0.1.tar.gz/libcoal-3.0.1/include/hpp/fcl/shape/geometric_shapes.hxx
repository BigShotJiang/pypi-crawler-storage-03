#include <hpp/fcl/coal.hpp>
#include <coal/shape/geometric_shapes.hxx>
