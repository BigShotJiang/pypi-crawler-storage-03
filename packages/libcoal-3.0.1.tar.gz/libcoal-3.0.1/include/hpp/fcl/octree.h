#include <hpp/fcl/coal.hpp>
#include <coal/octree.h>
