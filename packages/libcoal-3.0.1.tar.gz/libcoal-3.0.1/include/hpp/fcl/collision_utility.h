#include <hpp/fcl/coal.hpp>
#include <coal/collision_utility.h>
