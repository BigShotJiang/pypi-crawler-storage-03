#include <hpp/fcl/coal.hpp>
#include <coal/contact_patch/contact_patch_solver.hxx>
