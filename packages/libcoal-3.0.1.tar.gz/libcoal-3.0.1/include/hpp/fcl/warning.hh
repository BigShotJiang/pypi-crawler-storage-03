#include <hpp/fcl/coal.hpp>
#include <coal/warning.hh>
