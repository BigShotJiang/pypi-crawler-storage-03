#include <hpp/fcl/coal.hpp>
#include <coal/collision_object.h>
