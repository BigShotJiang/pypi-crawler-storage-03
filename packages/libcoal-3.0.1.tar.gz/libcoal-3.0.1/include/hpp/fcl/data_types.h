#include <hpp/fcl/coal.hpp>
#include <coal/data_types.h>
