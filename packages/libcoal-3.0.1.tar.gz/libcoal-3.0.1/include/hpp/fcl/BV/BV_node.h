#include <hpp/fcl/coal.hpp>
#include <coal/BV/BV_node.h>
