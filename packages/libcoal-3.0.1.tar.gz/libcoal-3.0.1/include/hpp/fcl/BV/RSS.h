#include <hpp/fcl/coal.hpp>
#include <coal/BV/RSS.h>
