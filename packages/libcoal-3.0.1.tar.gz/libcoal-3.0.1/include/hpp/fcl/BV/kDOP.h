#include <hpp/fcl/coal.hpp>
#include <coal/BV/kDOP.h>
