#include <hpp/fcl/coal.hpp>
#include <coal/BV/AABB.h>
