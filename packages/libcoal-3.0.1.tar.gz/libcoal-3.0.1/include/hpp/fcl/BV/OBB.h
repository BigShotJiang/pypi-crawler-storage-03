#include <hpp/fcl/coal.hpp>
#include <coal/BV/OBB.h>
