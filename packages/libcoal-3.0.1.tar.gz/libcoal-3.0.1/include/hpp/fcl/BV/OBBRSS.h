#include <hpp/fcl/coal.hpp>
#include <coal/BV/OBBRSS.h>
