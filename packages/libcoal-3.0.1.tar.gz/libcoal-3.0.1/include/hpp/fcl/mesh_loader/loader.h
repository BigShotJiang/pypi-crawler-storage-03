#include <hpp/fcl/coal.hpp>
#include <coal/mesh_loader/loader.h>
