#include <hpp/fcl/coal.hpp>
#include <coal/mesh_loader/assimp.h>
