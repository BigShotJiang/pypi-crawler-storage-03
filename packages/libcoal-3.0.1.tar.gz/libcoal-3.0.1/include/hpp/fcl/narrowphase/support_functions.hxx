#include <hpp/fcl/coal.hpp>
#include <coal/narrowphase/support_functions.hxx>
