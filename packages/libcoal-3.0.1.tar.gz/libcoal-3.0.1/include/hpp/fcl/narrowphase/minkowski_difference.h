#include <hpp/fcl/coal.hpp>
#include <coal/narrowphase/minkowski_difference.h>
