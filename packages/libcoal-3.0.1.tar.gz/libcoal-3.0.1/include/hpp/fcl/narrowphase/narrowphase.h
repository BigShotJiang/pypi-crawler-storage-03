#include <hpp/fcl/coal.hpp>
#include <coal/narrowphase/narrowphase.h>
