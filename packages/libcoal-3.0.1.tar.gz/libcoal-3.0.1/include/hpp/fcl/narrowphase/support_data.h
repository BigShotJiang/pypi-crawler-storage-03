#include <hpp/fcl/coal.hpp>
#include <coal/narrowphase/support_data.h>
