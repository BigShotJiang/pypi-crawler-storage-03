#include <hpp/fcl/coal.hpp>
#include <coal/narrowphase/narrowphase_defaults.h>
