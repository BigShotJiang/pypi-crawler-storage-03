#include <hpp/fcl/coal.hpp>
#include <coal/math/matrix_3f.h>
