#include <hpp/fcl/coal.hpp>
#include <coal/math/vec_3f.h>
