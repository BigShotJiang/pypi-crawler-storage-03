#include <hpp/fcl/coal.hpp>
#include <coal/math/transform.h>
