#include <hpp/fcl/coal.hpp>
#include <coal/distance.h>
