#include <hpp/fcl/coal.hpp>
#include <coal/collision_func_matrix.h>
