#include <hpp/fcl/coal.hpp>
#include <coal/config.hh>
