import warnings

warnings.warn(
    "Please update your 'hppfcl' imports to 'coal'", category=DeprecationWarning
)

from coal.viewer import *  # noqa
