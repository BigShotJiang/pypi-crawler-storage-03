$m_{n}$
$$ \frac{4 \left(n^{2} - 5 n - 2\right)}{\left(n - 1\right)^{5}} $$
$m1_{n}$
$$ \frac{2 \left(n^{3} + 6 n^{2} - 24 n + 20\right)}{\left(n - 2\right)^{3} \left(n - 1\right)^{3}} $$
$m_{nn}$
$$ - \frac{12 \left(n^{2} - 6 n - 5\right)}{\left(n - 1\right)^{6}} $$
$m1_{nn}$
$$ - \frac{6 \left(n^{4} + 8 n^{3} - 48 n^{2} + 80 n - 44\right)}{\left(n - 2\right)^{4} \left(n - 1\right)^{4}} $$
$m_{nnn}$
$$ \frac{48 \left(n^{2} - 7 n - 9\right)}{\left(n - 1\right)^{7}} $$
$m1_{nnn}$
$$ \frac{24 \left(n^{5} + 10 n^{4} - 80 n^{3} + 200 n^{2} - 220 n + 92\right)}{\left(n - 2\right)^{5} \left(n - 1\right)^{5}} $$
$m_{nnnn}$
$$ - \frac{240 \left(n^{2} - 8 n - 14\right)}{\left(n - 1\right)^{8}} $$
$m1_{nnnn}$
$$ - \frac{120 \left(n^{6} + 12 n^{5} - 120 n^{4} + 400 n^{3} - 660 n^{2} + 552 n - 188\right)}{\left(n - 2\right)^{6} \left(n - 1\right)^{6}} $$
