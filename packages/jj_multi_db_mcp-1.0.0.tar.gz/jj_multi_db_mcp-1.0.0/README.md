# JJ Multi-Database MCP Server

A simple and efficient MCP (Model Context Protocol) server supporting multiple databases and filesystem operations. Perfect for AI assistants like Claude to interact with your databases and files.

## ? Features

- ??? **SQL Server Support**: Complete SQL Server database operations
- ?? **MySQL Support**: Full MySQL database functionality  
- ?? **Oracle Support**: Comprehensive Oracle database operations
- ?? **Redis Support**: Key-value operations with Redis
- ?? **Filesystem Operations**: Safe file and directory operations
- ?? **Environment-based Configuration**: Simple configuration via environment variables
- ?? **uvx Compatible**: Designed for use with uvx package runner
- ?? **Security First**: Configurable access controls and safe defaults

## ?? Quick Start

### Using uvx (Recommended)

```bash
# Install and run with specific database support
uvx --from jj-multi-db-mcp[sqlserver,mysql,redis] jj-multi-db-mcp

# Install with all database support
uvx --from jj-multi-db-mcp[all] jj-multi-db-mcp
```

### Using pip

```bash
# Basic installation
pip install jj-multi-db-mcp

# With specific database support
pip install jj-multi-db-mcp[sqlserver,mysql,redis]

# With all database support
pip install jj-multi-db-mcp[all]

# Run the server
jj-multi-db-mcp
```

## ?? Configuration

Configure the server using environment variables:

### SQL Server
```bash
export SQLSERVER_ENABLED=true
export SQLSERVER_HOST=localhost
export SQLSERVER_PORT=1433
export SQLSERVER_DATABASE=your_database
export SQLSERVER_USERNAME=sa
export SQLSERVER_PASSWORD=your_password
```

### MySQL
```bash
export MYSQL_ENABLED=true
export MYSQL_HOST=localhost
export MYSQL_PORT=3306
export MYSQL_DATABASE=your_database
export MYSQL_USERNAME=root
export MYSQL_PASSWORD=your_password
```

### Oracle
```bash
export ORACLE_ENABLED=true
export ORACLE_HOST=localhost
export ORACLE_PORT=1521
export ORACLE_SERVICE_NAME=XE
export ORACLE_USERNAME=system
export ORACLE_PASSWORD=your_password
```

### Redis
```bash
export REDIS_ENABLED=true
export REDIS_HOST=localhost
export REDIS_PORT=6379
export REDIS_DB=0
export REDIS_PASSWORD=your_password  # optional
```

### Filesystem
```bash
export FS_ALLOWED_PATHS="/home/user/documents,/tmp"  # or "*" for full access
export FS_ALLOWED_EXTENSIONS=".txt,.py,.json,.csv"   # or "*" for all extensions
export FS_ENABLE_WRITE=true
export FS_ENABLE_DELETE=false
export FS_MAX_FILE_SIZE=104857600  # 100MB in bytes
```

## ?? Claude Desktop Configuration

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "jj-multi-db-mcp": {
      "command": "uvx",
      "args": ["--from", "jj-multi-db-mcp[sqlserver,mysql,redis]", "jj-multi-db-mcp"],
      "env": {
        "SQLSERVER_ENABLED": "true",
        "SQLSERVER_HOST": "localhost",
        "SQLSERVER_USERNAME": "sa",
        "SQLSERVER_PASSWORD": "your_password",
        "SQLSERVER_DATABASE": "your_database",
        "MYSQL_ENABLED": "true",
        "MYSQL_HOST": "localhost",
        "MYSQL_USERNAME": "root",
        "MYSQL_PASSWORD": "your_password",
        "MYSQL_DATABASE": "your_database",
        "REDIS_ENABLED": "true",
        "REDIS_HOST": "localhost",
        "FS_ALLOWED_PATHS": "/home/user/documents",
        "FS_ALLOWED_EXTENSIONS": ".txt,.py,.json,.csv,.md"
      }
    }
  }
}
```

## ??? Available Tools

### SQL Server Tools
- `sqlserver_query` - Execute SELECT queries
- `sqlserver_execute` - Execute INSERT/UPDATE/DELETE queries  
- `sqlserver_list_tables` - List all tables
- `sqlserver_table_schema` - Get table schema information

### MySQL Tools
- `mysql_query` - Execute SELECT queries
- `mysql_execute` - Execute INSERT/UPDATE/DELETE queries
- `mysql_list_tables` - List all tables
- `mysql_table_schema` - Get table schema information

### Oracle Tools
- `oracle_query` - Execute SELECT queries
- `oracle_execute` - Execute INSERT/UPDATE/DELETE queries
- `oracle_list_tables` - List all tables
- `oracle_table_schema` - Get table schema information

### Redis Tools
- `redis_get` - Get value by key
- `redis_set` - Set key-value pair
- `redis_delete` - Delete key
- `redis_keys` - List keys matching pattern

### Filesystem Tools
- `read_file` - Read file contents
- `write_file` - Write content to file
- `list_directory` - List directory contents

## ?? Resources

- `status://databases` - Get current database connection status

## ?? Security Features

- **Path Restrictions**: Limit filesystem access to specific directories
- **Extension Filtering**: Control which file types can be accessed
- **Size Limits**: Prevent large file operations
- **Connection Validation**: Secure database connections
- **Environment Isolation**: Separate configuration per environment

## ?? Development

```bash
# Clone the repository
git clone https://github.com/ppengit/jj-multi-db-mcp.git
cd jj-multi-db-mcp

# Install development dependencies
pip install -e .[dev,all]

# Run tests
pytest

# Format code
black .
isort .
```

## ?? License

MIT License - see LICENSE file for details.

## ?? Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## ?? Support

- GitHub Issues: [Report bugs or request features](https://github.com/ppengit/jj-multi-db-mcp/issues)
- Documentation: [Full documentation](https://github.com/ppengit/jj-multi-db-mcp)

## ?? Acknowledgments

- Built with [MCP (Model Context Protocol)](https://github.com/modelcontextprotocol)
- Inspired by [mcp-sqlserver-filesystem](https://github.com/ppengit/mcp-sqlserver-filesystem)
