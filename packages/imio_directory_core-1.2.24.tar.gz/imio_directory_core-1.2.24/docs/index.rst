===================
imio.directory.core
===================

User documentation
