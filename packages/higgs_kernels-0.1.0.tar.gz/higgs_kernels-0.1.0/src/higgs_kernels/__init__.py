def hello() -> str:
    return "Hello from higgs-kernels!"
