use common_error::{ensure, DaftResult};
use daft_core::prelude::*;
use daft_dsl::{
    functions::{scalar::ScalarFn, FunctionArgs, ScalarUDF},
    ExprRef,
};
use serde::{Deserialize, Serialize};

use crate::series::SeriesListExtension;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct ListMin;

#[typetag::serde]
impl ScalarUDF for ListMin {
    fn name(&self) -> &'static str {
        "list_min"
    }
    fn call(&self, inputs: daft_dsl::functions::FunctionArgs<Series>) -> DaftResult<Series> {
        ensure!(inputs.len() == 1, ValueError: "Expected 1 input arg, got {}", inputs.len());
        let input = inputs.required((0, "input"))?;
        input.list_min()
    }

    fn get_return_field(
        &self,
        inputs: FunctionArgs<ExprRef>,
        schema: &Schema,
    ) -> DaftResult<Field> {
        ensure!(inputs.len() == 1, SchemaMismatch: "Expected 1 input arg, got {}", inputs.len());
        let input = inputs.required((0, "input"))?;
        let field = input.to_field(schema)?.to_exploded_field()?;
        ensure!(field.dtype.is_numeric() || field.dtype.is_boolean(), TypeError: "Expected input to be numeric or boolean, got {}", field.dtype);
        Ok(field)
    }
}

#[must_use]
pub fn list_min(expr: ExprRef) -> ExprRef {
    ScalarFn::builtin(ListMin {}, vec![expr]).into()
}
