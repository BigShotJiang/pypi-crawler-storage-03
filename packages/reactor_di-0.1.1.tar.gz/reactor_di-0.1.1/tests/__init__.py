"""Supplemental test code.

The test code in this folder supplements the test code in the /examples folder to drive up test coverage.
As such, it covers edge cases which you would NOT typically find in production code.
"""
