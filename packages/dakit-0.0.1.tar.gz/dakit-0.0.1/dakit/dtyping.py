from typing import Any, Callable, List, Literal, Optional, Self, Union

Number = Union[int, float]
