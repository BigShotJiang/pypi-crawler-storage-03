"""Initialize the app"""

__version__ = "1.0.7"
__title__ = "Markettracker"
