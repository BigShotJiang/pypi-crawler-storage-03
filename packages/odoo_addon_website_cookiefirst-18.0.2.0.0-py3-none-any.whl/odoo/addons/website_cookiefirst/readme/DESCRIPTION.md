This module integrates Odoo website with GDPR through the functionality
of Cookiefirst (https://cookiefirst.com), you need to register your
website domain in Cookiefirst's portal.
