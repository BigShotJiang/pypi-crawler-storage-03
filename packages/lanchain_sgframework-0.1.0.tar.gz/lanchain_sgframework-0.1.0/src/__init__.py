#!/usr/bin/python
# Created on 2025. 08. 19
# @Author  : 강성훈(ssogaree@gmail.com)
# @File    : src/__init__.py
# @version : 1.00.00
# Copyright (c) 1999-2025 KSFAMS Co., Ltd. All Rights Reserved.