![Fox](https://randomfox.ca/images/93.jpg)

# Random Fox Image
Api by [RandomFox](https://randomfox.ca/)

#### get_random_fox_url

```python
import random_fox_image
url = random_fox_image.get_random_fox_url()
print(f'Fox image url -> {url}')
```

#### download_random_fox

```python
import random_fox_image
path = random_fox_image.download_random_fox("fox.jpg")
print(f'Fox image path -> {path}')
```