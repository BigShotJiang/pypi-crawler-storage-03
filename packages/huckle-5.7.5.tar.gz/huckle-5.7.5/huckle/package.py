__version__ = "5.7.5"
dependencies = ["restnavigator==1.0.1",
                "requests[socks]==2.32.3",
                "configparser==5.3.0",
                "certifi==2024.12.14",
                "portalocker==2.10.1",
                "keyring==25.5.0"]



