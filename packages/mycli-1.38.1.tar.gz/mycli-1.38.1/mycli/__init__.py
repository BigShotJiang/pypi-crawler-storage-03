from __future__ import annotations

import importlib.metadata

__version__: str = importlib.metadata.version("mycli")
