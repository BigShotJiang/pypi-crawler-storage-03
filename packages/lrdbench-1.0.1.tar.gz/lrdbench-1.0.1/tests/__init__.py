"""
Test package for synthetic data generation models.

This package contains unit tests and validation scripts for all
stochastic models and estimators.
"""
