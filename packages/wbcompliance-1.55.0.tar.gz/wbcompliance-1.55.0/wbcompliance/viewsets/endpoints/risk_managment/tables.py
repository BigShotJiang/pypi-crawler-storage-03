from wbcore.metadata.configs.endpoints import EndpointViewConfig


class RiskManagementIncidentTableEndpointConfig(EndpointViewConfig):
    def get_endpoint(self, **kwargs):
        return None
