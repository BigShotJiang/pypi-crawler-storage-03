# IG Package
Run predefined Python programs from the command line.
