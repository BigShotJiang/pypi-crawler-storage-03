echo "testing shell with exit code $1"
exit $1
