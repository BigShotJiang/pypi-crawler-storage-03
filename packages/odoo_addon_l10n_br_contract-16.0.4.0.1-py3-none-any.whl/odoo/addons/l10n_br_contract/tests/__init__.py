from . import test_l10n_br_contract
