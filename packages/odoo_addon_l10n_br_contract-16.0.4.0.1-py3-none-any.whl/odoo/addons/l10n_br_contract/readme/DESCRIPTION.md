This module was written to extend the functionality of contract module
to support the adequacy of Brazilian contract standards
