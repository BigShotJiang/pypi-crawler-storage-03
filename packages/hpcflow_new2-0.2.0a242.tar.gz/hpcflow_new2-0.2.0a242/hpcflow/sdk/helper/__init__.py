"""
Helpers for the CLI.
"""
