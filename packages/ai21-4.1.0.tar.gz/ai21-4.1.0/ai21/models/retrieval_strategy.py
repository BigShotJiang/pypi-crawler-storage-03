from typing import Literal


RetrievalStrategy = Literal["default", "segments", "add_neighbors", "full_doc"]
