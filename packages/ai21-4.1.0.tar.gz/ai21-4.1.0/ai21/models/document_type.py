from enum import Enum


class DocumentType(str, Enum):
    URL = "URL"
    TEXT = "TEXT"
