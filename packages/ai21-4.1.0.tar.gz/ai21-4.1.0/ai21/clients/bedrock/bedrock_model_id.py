class BedrockModelID:
    J2_MID_V1 = "ai21.j2-mid-v1"
    J2_ULTRA_V1 = "ai21.j2-ultra-v1"
    JAMBA_INSTRUCT_V1 = "ai21.jamba-instruct-v1:0"
    JAMBA_1_5_MINI = "ai21.jamba-1-5-mini-v1:0"
    JAMBA_1_5_LARGE = "ai21.jamba-1-5-large-v1:0"
