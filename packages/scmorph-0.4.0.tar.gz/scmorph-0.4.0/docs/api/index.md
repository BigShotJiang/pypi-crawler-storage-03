# API

Import scmorph as:

```
import scmorph as sm
```

```{toctree}
:maxdepth: 1

io
qc
preprocessing
plotting
tools
datasets
```
