Datasets: ``datasets``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
.. currentmodule:: scmorph.datasets

Datasets that are included with ``scmorph`` for testing and demonstration purposes.
Currently, this includes various versions of the data in :cite:p:`Rohban2017`.

.. autosummary::
    :toctree: generated/

    rohban2017
    rohban2017_minimal
    rohban2017_imageQC
    rohban2017_minimal_csv
