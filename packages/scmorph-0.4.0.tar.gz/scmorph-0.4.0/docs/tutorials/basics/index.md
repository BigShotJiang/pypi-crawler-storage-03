# Basic workflows

```{toctree}
:maxdepth: 1

batch_effects
feature_selection
hit_calling
why_scone
```
