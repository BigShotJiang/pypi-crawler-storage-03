# Explainer notebooks

These tutorials explain choices made in `scmorph` and can help gain more intuition about when to use which method.

```{toctree}
:maxdepth: 1

why_scone
correlation_comparison
```
