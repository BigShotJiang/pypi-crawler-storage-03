"""napari plugin for reading videos."""

__version__ = "0.2.11"
