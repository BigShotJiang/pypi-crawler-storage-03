# electrum-bch 0.3.7 (patched)

- Forces ECDSA backend
