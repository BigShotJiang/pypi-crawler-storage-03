from pathlib import Path
from typing import Dict, List, Tuple, Optional

import torch


def load_class_list(txt_path: Path) -> List[str]:
    """
    私有方法：从txt文件加载类别列表

    处理逻辑：
    1. 跳过空行（避免无效类别）
    2. 去重（保留txt中首次出现的顺序，避免重复类别）
    3. sorted排序（按字符串自然顺序排序，与文件夹提取类别逻辑保持一致）
    4. 返回排序后的类别列表

    参数：
        txt_path: 类别txt文件路径（Path对象）
    返回：
        List[str]: 去重、去空、排序后的类别列表
    """
    classes = []
    # 按行读取txt文件（指定utf-8编码避免中文乱码）
    with open(txt_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):  # line_num用于定位错误行
            line = line.strip()  # 去除行首尾空格、换行符（避免" 0-No "这类无效格式）
            if not line:  # 跳过空行（避免空字符串作为无效类别）
                continue
            classes.append(line)

    # 1. 先去重（dict.fromkeys自动去重，键顺序与txt中首次出现顺序一致）
    # 2. 再sorted排序（按字符串自然顺序，与文件夹提取类别时的排序逻辑统一）
    # 例：txt中若为["1-No", "0-B-007", "0-No"]，去重后→sorted→["0-B-007", "0-No", "1-No"]
    classes = sorted(list(dict.fromkeys(classes)))
    return classes


class FactorLabelMapper:
    """
    类别-因子-标签映射管理器

    核心功能：
    1. 双来源加载类别（txt文件优先，无则从数据目录子文件夹提取）
    2. 动态解析类别中的因子（按'-'分割，支持任意数量因子）
    3. 特殊处理含"No"的类别（默认将故障程度设为"0"，通常表示正常状态）
    4. 批量处理因子索引→标签（无效组合自动映射到"标签最小的No类别"）
    5. 提供类别、因子、标签间的双向转换接口
    """

    def __init__(self,
                 data_dir,  # 数据根目录（无txt时，从其子文件夹提取类别）
                 class_list_path=None,  # 可选：纯类别txt文件路径（每行一个类别名）
                 parse_factors: bool = False,  # 是否解析类别中的因子（按'-'分割）
                 build_lookup_table: bool = False,  # 是否构建因子索引→标签的批量查询表
                 factor_names: Optional[List[str]] = None  # 可选：因子名称列表（增强可读性，如["工况","故障类型"]）
                 ):
        """
        初始化映射管理器

        参数说明：
            data_dir: 必传，数据目录路径（用于文件夹提取类别备份）
            class_list_path: 可选，类别txt文件路径（优先级高于文件夹提取）
            parse_factors: 可选，是否开启因子解析（默认关闭）
            build_lookup_table: 可选，是否构建批量查询表（需先开启parse_factors，默认关闭）
            factor_names: 可选，因子名称列表（需与解析出的因子数量一致）
        """
        # 初始化路径相关属性
        self.data_dir = Path(data_dir)  # 数据目录（转为Path对象便于路径操作）
        self.classes: List[str] = []  # 存储最终加载的类别列表

        # ------------------------------
        # 1. 加载类别（优先级：txt文件 > 文件夹提取）
        # ------------------------------
        # 1.1 优先从txt文件加载类别（处理空行、去重，保持txt中类别顺序）
        if class_list_path is not None:
            class_list_path = Path(class_list_path)  # 统一路径格式
            if class_list_path.exists():  # 检查txt文件是否存在
                self.classes = load_class_list(class_list_path)

        # 1.2 若txt加载失败/无txt，从data_dir子文件夹提取类别（按字母排序保证一致性）
        if not self.classes:
            if not self.data_dir.exists():  # 检查数据目录是否存在
                raise ValueError(f"数据目录不存在：{self.data_dir}")
            # 提取所有子文件夹名称作为类别，sorted排序避免每次运行顺序不一致
            self.classes = sorted([d.name for d in self.data_dir.iterdir() if d.is_dir()])

        # 校验：确保类别非空（无类别则无法继续）
        if not self.classes:
            raise ValueError("未找到任何类别！请检查：1.txt文件是否存在且有有效类别 2.数据目录是否有子文件夹")

        # ------------------------------
        # 2. 构建基础映射（类别↔索引/标签，标签=索引，无外部独立标签）
        # ------------------------------
        self.class_to_idx: Dict[str, int] = {cls: idx for idx, cls in enumerate(self.classes)}  # 类别→索引
        self.idx_to_class: Dict[int, str] = {idx: cls for cls, idx in self.class_to_idx.items()}  # 索引→类别（反向映射）

        # ------------------------------
        # 3. 因子解析相关属性初始化（默认None，开启parse_factors后才赋值）
        # ------------------------------
        self.parse_factors = parse_factors  # 标记是否开启因子解析
        self.factor_names = factor_names  # 因子名称列表（增强日志可读性）
        self.class_to_factors: Optional[Dict[str, Tuple[str, ...]]] = None  # 类别→因子元组映射
        self.factor_maps: Optional[List[Dict[str, int]]] = None  # 每个因子的"取值→索引"映射（列表，按因子顺序）
        self.factor_inv_maps: Optional[List[Dict[int, str]]] = None  # 每个因子的"索引→取值"映射（反向，按因子顺序）
        self.num_factors: Optional[int] = None  # 解析出的因子总数（自动推断）
        self.lookup_table: Optional[Dict[Tuple[int, ...], int]] = None  # 因子索引组合→标签的批量查询表
        self.default_no_label: Optional[int] = None  # 默认No类别标签（标签最小的No类别，用于无效组合映射）

        # ------------------------------
        # 4. 开启因子解析时的初始化流程
        # ------------------------------
        if self.parse_factors:
            # 4.1 解析类别中的因子（处理No类别，统一故障程度为0）
            self.class_to_factors = self._parse_class_factors()
            # 4.2 为每个因子构建"取值→索引"映射（动态适配因子数量）
            self.factor_maps, self.factor_inv_maps = self._build_factor_maps()
            # 4.3 记录因子总数（后续校验因子数量用）
            self.num_factors = len(self.factor_maps) if self.factor_maps else 0
            # 4.4 计算默认No类别标签（无效组合映射目标）
            self.default_no_label = self._get_default_no_label()

            # 校验：因子名称数量与实际因子数量一致（若指定了factor_names）
            if self.factor_names and len(self.factor_names) != self.num_factors:
                raise ValueError(
                    f"因子名称数量不匹配：指定{len(self.factor_names)}个，实际解析出{self.num_factors}个因子"
                )

            # 4.5 若开启批量查询表，预构建因子索引组合→标签映射（加速批量处理）
            if build_lookup_table:
                self._build_batch_lookup_table()

    def _get_default_no_label(self) -> int:
        """
        私有方法：计算默认No类别标签（用于无效因子组合的映射目标）

        逻辑：
        1. 筛选所有包含"No"的类别（通常表示正常状态）
        2. 取这些类别的标签（即索引）最小值作为默认值
        3. 若无No类别，抛出错误（无法确定默认映射目标）

        返回：
            int: 标签最小的No类别的标签值
        """
        # 校验：确保因子已解析（未解析则无法筛选No类别）
        if not self.class_to_factors:
            raise RuntimeError("需先开启parse_factors=True解析因子，才能计算默认No类别")

        # 收集所有包含"No"的类别的标签（标签=索引）
        no_class_labels = []
        for cls, factors in self.class_to_factors.items():
            if "No" in factors:  # 筛选含"No"的类别（正常状态）
                no_class_labels.append(self.class_to_idx[cls])  # 记录该类别的标签

        # 校验：确保存在No类别（无No类别则无法设置默认映射）
        if not no_class_labels:
            raise ValueError("数据集中未找到包含'No'的类别，无法设置无效组合的默认映射目标")

        # 返回标签最小值（确保映射到"最基础"的正常类别）
        return min(no_class_labels)

    def _parse_class_factors(self) -> Dict[str, Tuple[str, ...]]:
        """
        私有方法：解析类别中的因子（按'-'分割），并特殊处理含"No"的类别
        核心逻辑（适配任意因子数量，无工况强制假设）：
        1. 先确定「基准因子数量」：由非"No"类别的原始格式决定（非"No"类别格式需统一）
           - 若全是"No"类别，默认基准因子数量为2（满足"No→(No, 0)"的分解需求）
        2. 含"No"的类别处理：
           - 原始因子数量 < 基准：补充至基准数量，且最后一个因子（程度）设为"0"
             （例：基准2时，"No"→(No, 0)；基准3时，"No"→(No, No, 0)、"A-No"→(A, No, 0)）
           - 原始因子数量 == 基准：强制最后一个因子（程度）设为"0"
             （例：基准2时，"Fault-No"→(Fault, 0)；基准3时，"Work-Fault-No"→(Work, Fault, 0)）
           - 原始因子数量 > 基准：报错（格式不匹配）
        3. 不含"No"的类别：直接校验因子数量是否与基准一致，不一致则报错
        4. 最终校验所有类别因子数量一致（确保后续处理统一）

        返回：
            Dict[str, Tuple[str, ...]]: 类别→因子元组的映射
        """
        class_to_factors = {}  # 存储类别→因子元组的映射
        raw_factors_dict = {}  # 临时存储：类别→原始因子列表（未处理No）

        # ------------------------------
        # 步骤1：先收集所有类别的原始因子（不处理No），用于确定基准因子数量
        # ------------------------------
        for cls in self.classes:
            raw_factors = cls.split('-')  # 按'-'分割原始因子
            raw_factors_dict[cls] = raw_factors

        # ------------------------------
        # 步骤2：确定「基准因子数量」（由非"No"类别决定，保证格式统一）
        # ------------------------------
        # 筛选非"No"类别（用于推断基准格式）
        non_no_classes = [cls for cls in self.classes if "No" not in raw_factors_dict[cls]]
        # 确定基准因子数量
        if non_no_classes:
            # 收集非"No"类别的原始因子数量
            non_no_factor_counts = {len(raw_factors_dict[cls]) for cls in non_no_classes}
            # 非"No"类别必须格式统一（因子数量一致）
            if len(non_no_factor_counts) > 1:
                raise ValueError(
                    f"非'No'类别的因子数量不一致：存在{non_no_factor_counts}种格式，"
                    f"请确保非'No'类别按相同规则用'-'分割（如2因子'故障类型-程度'或3因子'工况-故障类型-程度'）"
                )
            base_factor_count = non_no_factor_counts.pop()  # 基准因子数量（非"No"类别的格式）
        else:
            # 边缘场景：所有类别都是"No"类 → 默认基准因子数量为2（满足"No→(No, 0)"的分解需求）
            base_factor_count = 2
            print(f"警告：所有类别均为'No'类，默认基准因子数量设为2（格式：(No, 程度)）")

        # ------------------------------
        # 步骤3：逐个处理类别（含"No"特殊处理 + 因子数量对齐基准）
        # ------------------------------
        for cls in self.classes:
            raw_factors = raw_factors_dict[cls]
            raw_count = len(raw_factors)
            processed_factors = raw_factors.copy()  # 初始化处理后的因子列表

            # 处理含"No"的类别
            if "No" in raw_factors:
                # 子逻辑1：因子数量校验（原始数量不能超过基准）
                if raw_count > base_factor_count:
                    raise ValueError(
                        f"含'No'类别'{cls}'的原始因子数量({raw_count})超过基准数量({base_factor_count})，"
                        f"请检查格式（基准格式为{base_factor_count}因子，如{('因子1-因子2' if base_factor_count == 2 else '因子1-因子2-因子3')}）"
                    )

                # 子逻辑2：补充因子至基准数量（不足时补空字符串，最后统一处理程度）
                if raw_count < base_factor_count:
                    supplement_count = base_factor_count - raw_count
                    processed_factors += [""] * supplement_count  # 补充空值占位

                # 子逻辑3：强制最后一个因子（程度）为"0"（核心需求：No类别的程度统一设为0）
                processed_factors[-1] = "0"

                # 子逻辑4：填充补充的空值（用"No"填充，保证语义一致性）
                processed_factors = [f if f else "No" for f in processed_factors]

            # 处理不含"No"的类别（仅校验因子数量与基准一致）
            else:
                if len(processed_factors) != base_factor_count:
                    raise ValueError(
                        f"非'No'类别'{cls}'的因子数量({len(processed_factors)})与基准数量({base_factor_count})不匹配，"
                        f"请按基准格式（{('故障类型-程度' if base_factor_count == 2 else '工况-故障类型-程度')}）调整"
                    )

            # 转换为元组（不可变，避免后续误修改）
            factors_tuple = tuple(processed_factors)
            class_to_factors[cls] = factors_tuple

        # ------------------------------
        # 步骤4：最终校验（确保所有类别处理后因子数量一致）
        # ------------------------------
        final_factor_counts = {len(factors) for factors in class_to_factors.values()}
        if len(final_factor_counts) > 1:
            raise RuntimeError(
                f"类别因子处理后数量不一致（内部错误），请检查代码逻辑："
                f"处理后因子数量集合为{final_factor_counts}"
            )

        return class_to_factors

    def _build_factor_maps(self) -> Tuple[List[Dict[str, int]], List[Dict[int, str]]]:
        """
        私有方法：为每个因子构建"取值→索引"和"索引→取值"映射（动态适配因子数量）

        逻辑：
        1. 收集每个位置因子的所有可能取值（去重）
        2. 对每个因子的取值按字母排序（保证索引一致性）
        3. 构建正向（取值→索引）和反向（索引→取值）映射

        返回：
            Tuple[List[Dict[str, int]], List[Dict[int, str]]]:
                第一个元素：每个因子的"取值→索引"映射列表（按因子顺序）
                第二个元素：每个因子的"索引→取值"映射列表（按因子顺序）
        """
        # 校验：确保因子已解析（未解析则无法构建映射）
        if not self.class_to_factors:
            raise RuntimeError("需先开启parse_factors=True解析因子，才能构建因子映射")

        # 提取所有类别的因子元组列表（用于遍历收集取值）
        factors_list = list(self.class_to_factors.values())
        # 因子总数（所有类别因子数量一致，取第一个的长度即可）
        num_factors = len(factors_list[0])
        # 初始化每个因子的取值集合（set自动去重）
        factor_values = [set() for _ in range(num_factors)]

        # 遍历所有因子元组，收集每个位置因子的所有可能取值
        for factors in factors_list:
            for i in range(num_factors):
                factor_values[i].add(factors[i])

        # 构建每个因子的正向（取值→索引）和反向（索引→取值）映射
        factor_maps = []  # 正向映射列表
        factor_inv_maps = []  # 反向映射列表
        for i in range(num_factors):
            # 对因子取值排序（保证每次运行索引一致）
            sorted_vals = sorted(factor_values[i])
            # 正向映射：取值→索引
            factor_maps.append({v: idx for idx, v in enumerate(sorted_vals)})
            # 反向映射：索引→取值
            factor_inv_maps.append({idx: v for idx, v in enumerate(sorted_vals)})

        return factor_maps, factor_inv_maps

    def _build_batch_lookup_table(self) -> None:
        """
        私有方法：构建因子索引组合→标签的批量查询表（加速批量处理）

        逻辑：
        1. 递归生成所有可能的因子索引组合（适配任意因子数量）
        2. 对每个组合，计算其对应的标签并存入查询表
        3. 跳过无效组合（无法对应到具体类别的组合）
        """
        # 校验：确保因子已解析且映射已构建
        if not self.parse_factors or not self.factor_maps:
            raise RuntimeError("需先开启parse_factors=True并构建因子映射，才能构建批量查询表")

        self.lookup_table = {}  # 初始化查询表（键：因子索引元组，值：标签）

        # 递归函数：生成所有因子索引组合（适配任意因子数量）
        def generate_combinations(index: int, current: List[int]) -> None:
            # 递归终止条件：生成完所有因子的索引（当前索引=因子总数）
            if index == self.num_factors:
                try:
                    # 步骤1：索引组合→因子元组
                    factors = self.get_factors_from_indices(tuple(current))
                    # 步骤2：因子元组→类别
                    cls = self.get_class_from_factors(factors)
                    # 步骤3：类别→标签，存入查询表
                    self.lookup_table[tuple(current)] = self.get_label_from_class(cls)
                except ValueError:
                    # 跳过无效组合（如因子组合无对应类别）
                    pass
                return
            # 递归：遍历当前因子的所有可能索引，继续生成下一个因子的索引
            for idx in self.factor_inv_maps[index]:
                generate_combinations(index + 1, current + [idx])

        # 从第0个因子开始，生成所有可能的索引组合
        generate_combinations(0, [])

    # ------------------------------
    # 基础功能：类别↔索引/标签 双向转换（Label=索引，无外部独立标签）
    # ------------------------------
    def get_idx_from_class(self, cls: str) -> int:
        """
        公有方法：根据类别名称获取其索引（标签=索引）

        参数：
            cls: 类别名称（如"0-No"）
        返回：
            int: 类别对应的索引（标签值）
        异常：
            ValueError: 输入类别不在已加载的类别列表中
        """
        if cls not in self.class_to_idx:
            raise ValueError(f"未知类别：{cls}，可选类别示例：{self.classes[:5]}...")
        return self.class_to_idx[cls]

    def get_class_from_idx(self, idx: int) -> str:
        """
        公有方法：根据索引获取对应的类别名称

        参数：
            idx: 类别索引（标签值）
        返回：
            str: 索引对应的类别名称
        异常：
            ValueError: 输入索引超出有效范围（0~类别总数-1）
        """
        if idx not in self.idx_to_class:
            raise ValueError(f"未知索引：{idx}，有效索引范围：0~{len(self.classes) - 1}")
        return self.idx_to_class[idx]

    def get_label_from_class(self, cls: str) -> int:
        """
        公有方法：根据类别名称获取标签（标签=索引，兼容原有逻辑）

        参数：
            cls: 类别名称
        返回：
            int: 类别对应的标签值（即索引）
        异常：
            ValueError: 输入类别不在已加载的类别列表中
        """
        return self.get_idx_from_class(cls)

    def get_class_from_label(self, label: int) -> str:
        """
        公有方法：根据标签获取对应的类别名称（标签=索引，兼容原有逻辑）

        参数：
            label: 标签值（即索引）
        返回：
            str: 标签对应的类别名称
        异常：
            ValueError: 输入标签超出有效范围（0~类别总数-1）
        """
        return self.get_class_from_idx(label)

    # ------------------------------
    # 因子相关功能：需开启parse_factors=True才能使用
    # ------------------------------
    def get_factors_from_class(self, cls: str) -> Tuple[str, ...]:
        """
        公有方法：根据类别名称获取其解析后的因子元组

        参数：
            cls: 类别名称（如"0-No"）
        返回：
            Tuple[str, ...]: 类别对应的因子元组（如("0", "No", "0")）
        异常：
            RuntimeError: 未开启parse_factors=True
            ValueError: 输入类别不在已加载的类别列表中
        """
        if not self.parse_factors:
            raise RuntimeError("需先在初始化时设置parse_factors=True，才能解析类别中的因子")
        if cls not in self.class_to_factors:
            raise ValueError(f"未知类别：{cls}，可选类别示例：{self.classes[:5]}...")
        return self.class_to_factors[cls]

    def get_class_from_factors(self, factors: Tuple[str, ...]) -> str:
        """
        公有方法：根据因子元组获取对应的类别名称（按'-'拼接）

        参数：
            factors: 因子元组（如("0", "No", "0")）
        返回：
            str: 因子元组对应的类别名称（如"0-No-0"）
        异常：
            RuntimeError: 未开启parse_factors=True
            ValueError: 因子元组拼接后的类别不存在
        """
        if not self.parse_factors:
            raise RuntimeError("需先在初始化时设置parse_factors=True，才能通过因子构建类别")
        # 按'-'拼接因子元组为类别名称
        cls = '-'.join(factors)
        if cls not in self.classes:
            raise ValueError(f"因子组合对应的类别不存在：{cls}")
        return cls

    def get_indices_from_factors(self, factors: Tuple[str, ...]) -> Tuple[int, ...]:
        """
        公有方法：将因子元组转换为对应的索引元组（因子取值→索引）

        参数：
            factors: 因子元组（如("0", "No", "0")）
        返回：
            Tuple[int, ...]: 因子元组对应的索引元组（如(0, 0, 0)）
        异常：
            RuntimeError: 未开启parse_factors=True
            ValueError: 因子数量不匹配 / 因子取值无效
        """
        if not self.parse_factors:
            raise RuntimeError("需先在初始化时设置parse_factors=True，才能进行因子→索引转换")
        # 校验：因子数量与解析出的因子总数一致
        if len(factors) != self.num_factors:
            raise ValueError(f"因子数量不匹配：输入{len(factors)}个因子，实际需要{self.num_factors}个")

        indices = []
        # 遍历每个因子，转换为对应的索引
        for i in range(self.num_factors):
            # 因子名称（有指定则用指定名称，无则用"因子X"）
            factor_name = self.factor_names[i] if self.factor_names else f"因子{i + 1}"
            # 校验：当前因子取值是否在有效范围内
            if factors[i] not in self.factor_maps[i]:
                raise ValueError(
                    f"未知{factor_name}取值：{factors[i]}，"
                    f"可选取值：{sorted(self.factor_maps[i].keys())}"
                )
            # 记录当前因子的索引
            indices.append(self.factor_maps[i][factors[i]])

        return tuple(indices)

    def get_factors_from_indices(self, indices: Tuple[int, ...]) -> Tuple[str, ...]:
        """
        公有方法：将索引元组转换为对应的因子元组（索引→因子取值）

        参数：
            indices: 索引元组（如(0, 0, 0)）
        返回：
            Tuple[str, ...]: 索引元组对应的因子元组（如("0", "No", "0")）
        异常：
            RuntimeError: 未开启parse_factors=True
            ValueError: 索引数量不匹配 / 索引值无效
        """
        if not self.parse_factors:
            raise RuntimeError("需先在初始化时设置parse_factors=True，才能进行索引→因子转换")
        # 校验：索引数量与解析出的因子总数一致
        if len(indices) != self.num_factors:
            raise ValueError(f"索引数量不匹配：输入{len(indices)}个索引，实际需要{self.num_factors}个")

        factors = []
        # 遍历每个索引，转换为对应的因子取值
        for i in range(self.num_factors):
            # 因子名称（有指定则用指定名称，无则用"因子X"）
            factor_name = self.factor_names[i] if self.factor_names else f"因子{i + 1}"
            # 校验：当前索引是否在有效范围内
            if indices[i] not in self.factor_inv_maps[i]:
                raise ValueError(
                    f"未知{factor_name}索引：{indices[i]}，"
                    f"有效索引范围：0~{len(self.factor_inv_maps[i]) - 1}"
                )
            # 记录当前索引对应的因子取值
            factors.append(self.factor_inv_maps[i][indices[i]])

        return tuple(factors)

    def get_label_from_factors(self, factors: Tuple[str, ...]) -> int:
        """
        公有方法：根据因子元组获取对应的标签（因子→类别→标签）

        参数：
            factors: 因子元组（如("0", "No", "0")）
        返回：
            int: 因子元组对应的标签值
        异常：
            RuntimeError: 未开启parse_factors=True
            ValueError: 因子元组对应的类别不存在
        """
        # 步骤：因子元组→类别→标签
        cls = self.get_class_from_factors(factors)
        return self.get_label_from_class(cls)

    def get_label_from_indices(self, indices: Tuple[int, ...]) -> int:
        """
        公有方法：根据索引元组获取对应的标签（索引→因子→类别→标签）

        参数：
            indices: 索引元组（如(0, 0, 0)）
        返回：
            int: 索引元组对应的标签值
        异常：
            RuntimeError: 未开启parse_factors=True
            ValueError: 索引元组对应的因子/类别不存在
        """
        # 步骤：索引元组→因子元组→类别→标签
        factors = self.get_factors_from_indices(indices)
        return self.get_label_from_factors(factors)

    def get_labels_from_indices_batch(self, indices_tensor) -> List[int]:
        """
        公有方法：批量根据索引元组获取标签（无效组合映射到默认No类别）

        核心逻辑：
        1. 因子数量不匹配 → 映射到默认No类别标签
        2. 因子数量匹配但无对应标签 → 映射到默认No类别标签
        3. 有效组合 → 返回正常标签

        参数：
            indices_tensor: torch.Tensor，形状[batch_size, num_factors]，每行是一个因子索引组合
        返回：
            List[int]: 批量标签列表（长度=batch_size）
        异常：
            RuntimeError: 未开启parse_factors=True 或 未构建批量查询表
            TypeError: 输入不是torch.Tensor类型
        """
        # 基础校验：确保开启因子解析和批量查询表
        if not self.parse_factors or self.lookup_table is None:
            raise RuntimeError("需在初始化时同时设置parse_factors=True和build_lookup_table=True，才能批量获取标签")
        # 基础校验：输入必须是torch.Tensor
        # if not isinstance(indices_tensor, torch.Tensor):
        #     raise TypeError(f"输入类型错误：需为torch.Tensor，当前为{type(indices_tensor)}")
        if isinstance(indices_tensor, torch.Tensor):
            indices_tensor = indices_tensor.cpu().numpy()

        # 转换为CPU的numpy数组（字典查询不支持GPU张量，且numpy便于遍历）
        # indices_np = indices_tensor.cpu().numpy()
        labels = []  # 存储批量标签结果

        # 遍历每个索引组合，批量生成标签
        for idx in indices_tensor:
            # 情况1：因子数量不匹配 → 映射到默认No类别标签
            if len(idx) != self.num_factors:
                labels.append(self.default_no_label)
                continue
            # 情况2：因子数量匹配 → 尝试从查询表获取标签
            index_tuple = tuple(map(int, idx))  # 转换为整数元组（适配查询表的键格式）
            # 无对应标签时，用默认No类别标签（而非-1）
            label = self.lookup_table.get(index_tuple, self.default_no_label)
            labels.append(label)

        return labels

    # ------------------------------
    # 辅助功能：打印核心映射信息（调试用）
    # ------------------------------
    def print_mappings(self) -> None:
        """
        公有方法：打印核心映射信息（类别、因子、默认No类别等），用于调试和验证
        """
        print("\n=== 核心映射信息 ===")
        print(f"类别总数：{len(self.classes)}")
        print(f"所有类别：{self.classes}")
        print("类别→索引（标签）映射：", self.class_to_idx)

        # 若开启因子解析，打印因子相关信息
        if self.parse_factors:
            print(f"\n=== 因子解析信息（共{self.num_factors}个因子） ===")
            # 打印每个因子的"取值→索引"映射
            for i in range(self.num_factors):
                factor_name = self.factor_names[i] if self.factor_names else f"因子{i + 1}"
                print(f"{factor_name}→索引映射：{self.factor_maps[i]}")

            # 打印默认No类别信息（无效组合映射目标）
            print(f"\n=== 默认No类别信息 ===")
            print(f"标签最小的No类别标签：{self.default_no_label}")
            print(f"对应的类别名称：{self.get_class_from_label(self.default_no_label)}")
            print(f"对应的因子元组：{self.get_factors_from_class(self.get_class_from_label(self.default_no_label))}")

            # 打印每个类别的因子解析结果
            print("\n=== 所有类别→因子解析结果 ===")
            for cls in self.classes:
                factors = self.get_factors_from_class(cls)
                indices = self.get_indices_from_factors(factors)
                label = self.get_label_from_class(cls)
                print(f"类别：{cls} → 因子：{factors} → 索引：{indices} → 标签：{label}")
