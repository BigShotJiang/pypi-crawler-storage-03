"""
Scripts package for CleanEngine utilities
"""

__version__ = "1.0.0"
