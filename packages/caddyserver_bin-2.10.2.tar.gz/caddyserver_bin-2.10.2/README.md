# caddyserver-bin

https://caddyserver.com

Caddy webserver with plugins.

## Plugins

- `github.com/greenpau/caddy-security`
- `github.com/sjtug/caddy2-filter`
- `github.com/mholt/caddy-webdav`
- `github.com/abiosoft/caddy-exec`
- `github.com/aksdb/caddy-cgi/v2`
- `github.com/ggicci/caddy-jwt`
