from ._e2v_ccd64_thick import E2VCCD64ThickDepletionModel

__all__ = [
    "E2VCCD64ThickDepletionModel",
]
