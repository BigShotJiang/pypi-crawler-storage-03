__version__ = "0.1.3"
__author__ = "Adir Ali Yerima"

from .linaix import main

__all__ = ["main"] 