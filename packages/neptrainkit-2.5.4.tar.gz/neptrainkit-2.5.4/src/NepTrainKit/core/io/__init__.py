#!/usr/bin/env python 
# -*- coding: utf-8 -*-
# @Time    : 2024/10/18 15:24
# @Author  : 兵
# @email    : 1747193328@qq.com
from .nep import NepTrainResultData
from .deepmd import DeepmdResultData



