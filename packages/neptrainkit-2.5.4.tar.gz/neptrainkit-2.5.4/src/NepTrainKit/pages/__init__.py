#!/usr/bin/env python 
# -*- coding: utf-8 -*-
# @Time    : 2024/10/17 17:21
# @Author  : 兵
# @email    : 1747193328@qq.com
from .makedata import MakeDataWidget
from .settings import SettingsWidget
from .show_nep import ShowNepWidget
