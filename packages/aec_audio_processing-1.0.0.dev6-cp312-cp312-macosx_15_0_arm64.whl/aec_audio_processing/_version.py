"""Version information."""

__version__ = "1.0.0.dev6"
version_info = tuple(map(int, __version__.split(".dev")[0].split(".")))
