# Verisocks

This package provides a simple Python client that can be used to interface with
a Verisocks server instance in an Icarus verilog simulation.
