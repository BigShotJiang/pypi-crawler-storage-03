snakemake --use-conda --conda-create-envs-only --profile .

