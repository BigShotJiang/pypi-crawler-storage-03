#!/bin/bash
sed 's/ /\n/g' ${1}
