snakemake -np  --profile giga/cdi/conf
