snakemake --profile .
