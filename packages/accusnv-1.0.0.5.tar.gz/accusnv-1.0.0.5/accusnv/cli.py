from accusnv_snakemake import main as snakemake_main

def main():
    """Entry point for the Snakemake-based pipeline."""
    snakemake_main()


if __name__ == "__main__":
    main()
