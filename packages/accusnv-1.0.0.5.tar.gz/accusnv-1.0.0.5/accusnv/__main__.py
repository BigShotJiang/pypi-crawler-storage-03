from .accusnv_snakemake import main

if __name__ == "__main__":
    main()
