========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/openstackdocstheme.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

OpenTelekomCloud docs Sphinx Theme
=========================================

Theme and extension support for Sphinx documentation.

Intended for use by OpenTelekomCloud `projects`.

..  `projects`: https://github.com/OpenTelekomCloud

* Free software: Apache License, Version 2.0
* Source: https://github.com/OpenTelekomCloud/otcdocstheme
