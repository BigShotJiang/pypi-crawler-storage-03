# jetio/__init__.py

"""
JetIO: A next-generation, high-performance web framework for Python.

This package is currently a placeholder for the jetio project.
The 0.0.1 release is a name reservation only and contains no functional code.
"""

__version__ = "0.0.1"