# setup.py
# This is the setup script for the project.
# It uses setuptools to package the project.
# Most configuration is in setup.cfg.

from setuptools import setup

if __name__ == "__main__":
    setup()