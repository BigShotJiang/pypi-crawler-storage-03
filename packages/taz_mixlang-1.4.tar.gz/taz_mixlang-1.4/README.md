# TAZ Mix Lang

- A simple, powerful polyglot script runner for defining and executing multi-language tasks.

- Made by **tienanh109**

- Version: 1.4

- Full docs: https://tienanh109.github.io/TAZ-MixLang/

- For source code, visit https://github.com/tienanh109/TAZ-MixLang/

*Thanks for reading!*