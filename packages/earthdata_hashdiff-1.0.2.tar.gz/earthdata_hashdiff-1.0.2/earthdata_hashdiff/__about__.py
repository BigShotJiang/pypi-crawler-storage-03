"""Version for the package - only edit when intending to release."""

version = '1.0.2'
