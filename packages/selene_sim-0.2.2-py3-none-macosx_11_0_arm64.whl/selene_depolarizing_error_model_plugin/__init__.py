from .plugin import DepolarizingPlugin

__all__ = ["DepolarizingPlugin"]
