from .plugin import SimpleLeakagePlugin

__all__ = ["SimpleLeakagePlugin"]
