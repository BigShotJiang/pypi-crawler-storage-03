// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vtop___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vtop___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vtop___024root__traceDeclTypesSub0(tracep);
}
