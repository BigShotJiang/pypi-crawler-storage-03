"""
Legacy setup.py for BICSdifftest framework - use pyproject.toml for modern packaging.
This file is kept for backwards compatibility.
"""

from setuptools import setup

# Note: All configuration has been moved to pyproject.toml
# This setup.py is kept for backwards compatibility with older pip versions
setup()