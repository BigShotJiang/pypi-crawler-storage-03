# open-data-mcp
[![smithery badge](https://smithery.ai/badge/@iosif2/open-data-mcp)](https://smithery.ai/server/@iosif2/open-data-mcp)
