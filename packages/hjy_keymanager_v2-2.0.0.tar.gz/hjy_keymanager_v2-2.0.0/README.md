# hjy-keymanager-v2

Hjy keymanager package version 2.0.0.

## Installation

```bash
pip install hjy-keymanager-v2
```

## Usage

```python
import hjy_keymanager_v2
print(hjy_keymanager_v2.__version__)
```
