from pymongo import MongoClient

# defaults (can be updated by user)


mongo_client = None
db = None
col_data = None
col_input = None
log = None

def configure(connection_string=None, data_base=None, data_table=None, input_table=None, export_data_table=None):
    """Allow user to set MongoDB connection dynamically"""
    global mongo_client, db, col_data, col_input, log

    if connection_string:
        globals()["connection_string"] = connection_string
    if data_base:
        globals()["data_base"] = data_base
    if data_table:
        globals()["data_table"] = data_table
    if input_table:
        globals()["input_table"] = input_table
    if export_data_table:
        globals()["export_data_table"] = export_data_table

    # reconnect Mongo
    mongo_client = MongoClient(globals()["connection_string"])
    db = mongo_client[globals()["data_base"]]
    col_data = db[globals()["data_table"]]
    col_input = db[globals()["input_table"]]
    log = db[f'{globals()["data_table"]}_failures_collection']

    print(f"✅ Connected to MongoDB: {globals()['connection_string']}")
