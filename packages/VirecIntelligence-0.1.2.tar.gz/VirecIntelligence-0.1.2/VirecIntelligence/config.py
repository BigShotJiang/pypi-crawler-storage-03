connection_string = ""
data_base = ""
input_table = ""
export_data_table = ""

pagesave_path = r""
tracetuneel_path = r""
output_dir = r""