from setuptools import setup, find_packages

setup(
    name="VirecIntelligence",  # Replace with your package name
    version="0.1.2",  # Initial version
    author="Sumit Zala",
    author_email="sumit.zala@xbyte.io",
    description="Validate our data",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
     # Update with repo URL if available
    packages=find_packages(),  # Automatically finds all packages
    install_requires=[
        # Add your dependencies here, for example:
        # "requests>=2.25.1",
        # "pymongo>=4.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",  # Update license if needed
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
