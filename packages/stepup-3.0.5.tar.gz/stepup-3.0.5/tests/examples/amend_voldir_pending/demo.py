#!/usr/bin/env python3
from stepup.core.api import amend

amend(vol=["nonexisting/foo.out"])
