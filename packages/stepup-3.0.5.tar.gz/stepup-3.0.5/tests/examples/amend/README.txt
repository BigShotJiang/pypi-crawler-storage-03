Steps can define additional inputs and outputs while they are running.
This can be useful when not all inputs or outputs can be detected upfront.
When an amended input is not available, the step is rescheduled for later execution.

This example also includes a restart with and without changes to the files.
