This is a simple example of using the call interface to generate some data.
