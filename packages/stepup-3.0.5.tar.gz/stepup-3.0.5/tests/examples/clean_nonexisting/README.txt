When cleanup is called with non-existing, it just ignores these arguments
