#!/usr/bin/env python3
from stepup.core.api import runpy

runpy("./demo.py")
