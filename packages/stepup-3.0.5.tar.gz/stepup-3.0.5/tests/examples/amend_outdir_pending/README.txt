A step with an output file in a directory that is yet unknown to StepUp, will remain pending.
This is demonstrated here with an example of a step that amends this output path.
