Environment variables are substituted in all paths given to the `amend` function.
Each variable used is added to the `env_vars` set of the same amend call.
