An example using multiple inputs and creating multiple outputs with the call protocol.
