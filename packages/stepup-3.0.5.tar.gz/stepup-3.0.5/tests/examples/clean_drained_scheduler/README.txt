This is a slightly contrived example to demonstrate that
the queued steps in a drained scheduler are pruned and made pending again.
(This pattern is not expected to be common in production. It just tests a corner case.)
