A simple example of the call protocol with arguments and return values that are JSON-serializable.
