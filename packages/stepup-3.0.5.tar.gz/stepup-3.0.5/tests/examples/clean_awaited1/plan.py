#!/usr/bin/env python3
from stepup.core.api import copy

copy("missing.txt", "hello.txt")
