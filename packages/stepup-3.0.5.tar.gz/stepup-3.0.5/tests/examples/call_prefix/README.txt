The call interface allows a script to be called multiple times with different arguments,
from the same working directory.
In this case, the prefix is required to avoid that the steps write to the same output or even have entirely the same command line.
