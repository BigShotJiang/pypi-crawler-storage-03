This example tests that one can declare a static file whose parent directory become static due to a deferred glob.
