This is an example with a step with an amended input.
It has to wait for its regular inputs, which are a sleeping for 0.1 seconds.
Each time an input changes, the amended information is discarded.
