# stepup.core.stepinfo

::: stepup.core.stepinfo
      options:
        docstring_style: numpy
        show_root_heading: false
