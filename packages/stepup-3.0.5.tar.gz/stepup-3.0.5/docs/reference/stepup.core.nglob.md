# stepup.core.nglob

::: stepup.core.nglob
      options:
        docstring_style: numpy
        show_root_heading: false
