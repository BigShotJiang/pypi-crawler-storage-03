# stepup.core.call

::: stepup.core.call
      options:
        docstring_style: numpy
        show_root_heading: false
        members:
          - driver
