message = "Repetition helps to get the message across."
