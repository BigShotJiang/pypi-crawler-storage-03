#!/usr/bin/env python3
import sys

from helper import message

for _ in range(int(sys.argv[1])):
    print(message)
