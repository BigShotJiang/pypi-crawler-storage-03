# Env and Graph
class SynthGlobalTrajectory:
    pass
