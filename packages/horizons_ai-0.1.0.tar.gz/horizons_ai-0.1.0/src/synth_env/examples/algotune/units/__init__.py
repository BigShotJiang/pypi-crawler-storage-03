"""Unit tests for AlgoTune environment."""
