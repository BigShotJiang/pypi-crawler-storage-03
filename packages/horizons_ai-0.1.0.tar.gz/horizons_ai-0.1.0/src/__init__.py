"""Synth Environment source package."""
