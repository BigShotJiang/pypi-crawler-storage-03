"""
Horizons AI - Advanced Reinforcement Learning Environments

A comprehensive collection of environments for reinforcement learning research and development.
"""

__version__ = "0.1.0"
__author__ = "Synth AI"
__email__ = "josh@usesynth.ai"
