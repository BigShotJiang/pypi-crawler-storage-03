"""System instructions."""


def system() -> str:
    """Base system instructions."""
    return "You are a helpful AI assistant. Provide clear, concise responses."
