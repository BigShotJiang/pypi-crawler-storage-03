"""Infrastructure library."""

from .result import Err, Ok, Result

__all__ = ["Result", "Ok", "Err"]
