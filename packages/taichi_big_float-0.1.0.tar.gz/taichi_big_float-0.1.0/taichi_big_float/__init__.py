# -*- coding: utf-8 -*-
"""
Created on Sun Jul 20 00:56:46 2025

@author: balazs
"""

from .float_n32_p2 import make_float_t
from .ast_transformer import supports_bigfloat