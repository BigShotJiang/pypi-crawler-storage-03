# Copyright (c) Microsoft. All rights reserved.

NAMESPACE = "agent_runtime"
