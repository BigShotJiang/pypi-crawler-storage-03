from .base import KittyCadBaseModel


class SetSceneUnits(KittyCadBaseModel):
    """The response from the `SetSceneUnits` endpoint."""
