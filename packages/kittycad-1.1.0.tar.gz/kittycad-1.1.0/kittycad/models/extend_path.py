from .base import KittyCadBaseModel


class ExtendPath(KittyCadBaseModel):
    """The response from the `ExtendPath` endpoint."""
