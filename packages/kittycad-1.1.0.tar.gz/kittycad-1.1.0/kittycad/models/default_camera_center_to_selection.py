from .base import KittyCadBaseModel


class DefaultCameraCenterToSelection(KittyCadBaseModel):
    """The response from the `DefaultCameraCenterToSelection` endpoint."""
