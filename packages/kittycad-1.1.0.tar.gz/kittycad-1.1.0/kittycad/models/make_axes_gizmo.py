from .base import KittyCadBaseModel


class MakeAxesGizmo(KittyCadBaseModel):
    """The response from the `MakeAxesGizmo` endpoint."""
