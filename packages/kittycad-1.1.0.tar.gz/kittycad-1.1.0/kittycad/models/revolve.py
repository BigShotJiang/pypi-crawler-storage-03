from .base import KittyCadBaseModel


class Revolve(KittyCadBaseModel):
    """The response from the `Revolve` endpoint."""
