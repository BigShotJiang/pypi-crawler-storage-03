from .base import KittyCadBaseModel


class TwistExtrude(KittyCadBaseModel):
    """The response from the `TwistExtrude` endpoint."""
