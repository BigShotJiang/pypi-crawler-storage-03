from .base import KittyCadBaseModel


class RevolveAboutEdge(KittyCadBaseModel):
    """The response from the `RevolveAboutEdge` endpoint."""
