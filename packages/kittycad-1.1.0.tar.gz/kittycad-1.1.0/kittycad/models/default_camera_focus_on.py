from .base import KittyCadBaseModel


class DefaultCameraFocusOn(KittyCadBaseModel):
    """The response from the `DefaultCameraFocusOn` command."""
