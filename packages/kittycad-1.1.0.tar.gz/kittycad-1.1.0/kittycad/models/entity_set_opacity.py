from .base import KittyCadBaseModel


class EntitySetOpacity(KittyCadBaseModel):
    """The response from the `EntitySetOpacity` endpoint."""
