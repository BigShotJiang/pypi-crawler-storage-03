from .base import KittyCadBaseModel


class DefaultCameraSetPerspective(KittyCadBaseModel):
    """The response from the `DefaultCameraSetPerspective` endpoint."""
