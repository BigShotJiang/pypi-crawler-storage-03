from .base import KittyCadBaseModel


class EntityFade(KittyCadBaseModel):
    """The response from the `EntityFade` endpoint."""
