from .base import KittyCadBaseModel


class NewAnnotation(KittyCadBaseModel):
    """The response from the `NewAnnotation` endpoint."""
