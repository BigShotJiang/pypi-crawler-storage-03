from .base import KittyCadBaseModel


class SetGridAutoScale(KittyCadBaseModel):
    """The response from the 'SetGridScale'."""
