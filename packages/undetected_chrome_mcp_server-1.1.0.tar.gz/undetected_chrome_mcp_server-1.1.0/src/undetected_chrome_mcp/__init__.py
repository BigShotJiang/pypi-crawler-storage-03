"""Undetected ChromeDriver MCP Server.

A Model Context Protocol server providing browser automation capabilities
using undetected-chromedriver for enhanced anti-detection.
"""

__version__ = "1.0.0"