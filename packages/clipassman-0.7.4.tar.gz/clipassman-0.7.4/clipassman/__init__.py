# Copyright © 2025, Alexander Suvorov
"""Cross-platform console Smart Password manager and generator."""
__version__ = '0.7.4'
