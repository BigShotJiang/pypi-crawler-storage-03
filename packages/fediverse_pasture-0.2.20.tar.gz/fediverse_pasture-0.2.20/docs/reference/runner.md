<!--
SPDX-FileCopyrightText: 2023-2025 Helge

SPDX-License-Identifier: CC-BY-4.0
-->

::: fediverse_pasture.runner
    options:
        show_root_heading: true
        heading_level: 1
        show_submodules: true
