"""
Developer: vujadeyoon
Email: vujadeyoon@gmail.com
Github: https://github.com/vujadeyoon/vujade-python

Title: __init__.py
Description: A method-wrapper for the package, vujade.
"""


__date__ = '250817'
__version__ = '0.0.0'
__all__ = [
    ]
