# Placeholder so that Monorepo CI passes until after https://jira.mongodb.org/browse/INTPYTHON-492 is resolved.
def test_sanity() -> None:
    assert True
