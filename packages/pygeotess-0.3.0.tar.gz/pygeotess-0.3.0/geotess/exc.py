class GeoTessError(Exception):
    pass

class GeoTessFileError(GeoTessError):
    pass
