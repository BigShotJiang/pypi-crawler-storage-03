#!/usr/bin/env bash
set -e
python main.py