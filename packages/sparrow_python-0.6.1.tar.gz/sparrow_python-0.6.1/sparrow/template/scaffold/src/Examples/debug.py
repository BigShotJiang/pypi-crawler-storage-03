"""
from {{project_name}} import *
"""
