import yaml_to_openstep_plist
import yaml

if __name__ == "__main__":
    # Load YAML data from a file
    yaml_to_openstep_plist.to_yaml_file("input.yaml", "output.plist")
    


