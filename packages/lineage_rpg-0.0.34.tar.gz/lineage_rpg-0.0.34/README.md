Welcome to **Lineage RPG**, an offline RPG that you can play right from your terminal. Follow the steps below to install and start playing!

## 📋 Version Changelog
* 🔒 **Secured save encryption** - Prevents save file corruption and tampering
* 🛡️ **Enhanced data framework** - Advanced error handling and data loss prevention
* 🌐 **Cross-platform support** - Full compatibility for Windows, macOS, and Linux
* ⚡ **Optimized performance** - Module caching and improved game loop efficiency
* 🔧 **System-specific encryption keys** - Save files are uniquely tied to each user's system
* 💾 **Atomic save operations** - Prevents save corruption during unexpected shutdowns

---

## 📦 Requirements
* Python **3.8+** ([Download here](https://www.python.org/downloads/))
* Internet connection (for installation)

--- 

## 🚀 Installation
### 1. Open your terminal or command prompt.
**Windows**: Press `Windows + R`, then type `cmd`, and hit Enter.  
**macOS/Linux**: Open Terminal from Applications or press `Ctrl+Alt+T`.

### 2. Install the game with:
```bash
pip install lineage-rpg
```

To upgrade to the latest version when a new version releases:
```bash
pip install --upgrade lineage-rpg
```

---

## 🕹️ How to Play
Once installed, launch the game from your terminal using:
```bash
lineage-rpg
```

You'll see:
```
Welcome to Lineage RPG! Type 'exit' or CTRL+C to quit.
>
```

Then, type `help` and press ENTER. You'll see a list of commands to start playing.

---

## ❓ Troubleshooting

### Installation Issues
* **"Command not found" or "'pip' is not recognized"**: Make sure Python and pip are correctly installed and added to your PATH. Try `python -m pip install lineage-rpg` instead.
* **Permission denied**: Use `pip install --user lineage-rpg` or run as administrator/sudo.

### Launch Issues
* **"lineage-rpg" command not found**: Try these alternatives:
  ```bash
  python -m lineage_rpg
  python3 -m lineage_rpg
  python -m lineage_rpg.main
  ```

### Game Issues
* **Corrupted save file**: The game will automatically reset and start fresh if your save file is corrupted.
* **Game doesn't respond**: Use `Ctrl+C` to safely exit and save your progress.

**Still having issues?** Make sure you're using Python 3.8+ and have sufficient disk space.