"""

PyAlice v0.1 \n
This framework serves to simplify the development of projects in yandex alice.

"""