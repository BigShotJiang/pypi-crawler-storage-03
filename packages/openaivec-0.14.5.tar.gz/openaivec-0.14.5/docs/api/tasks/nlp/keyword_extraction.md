# Keyword Extraction Task

::: openaivec.task.nlp.keyword_extraction
