# S4 Platform API

## Requirements

`s4-platform-api` requires Python 3.9+.
