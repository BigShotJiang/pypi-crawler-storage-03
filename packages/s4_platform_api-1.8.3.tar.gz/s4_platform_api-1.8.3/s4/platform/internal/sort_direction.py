import enum


class SortDirection(enum.Enum):
    ASC = "ASC"
    DESC = "DESC"
