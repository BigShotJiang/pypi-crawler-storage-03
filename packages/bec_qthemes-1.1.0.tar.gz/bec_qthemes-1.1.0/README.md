<p align="center">
   <img src="https://github.com/user-attachments/assets/84ac6460-43ce-4490-8eb8-f8d0d5c5df0f" width="200"></img>
</p>

# BEC QThemes

This project is based on the [PyQtDarktheme](https://github.com/5yutan5/PyQtDarkTheme) project. 
