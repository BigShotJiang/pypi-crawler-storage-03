# API Reference

## Public API

::: yokedcache

## Core

### Cache

::: yokedcache.cache

### Decorators

::: yokedcache.decorators

### Configuration

::: yokedcache.config

### Models

::: yokedcache.models

### Utils

::: yokedcache.utils
