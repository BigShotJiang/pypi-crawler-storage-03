---
name: Feature Request
about: '"It would be really cool if x did y..."'
title: ''
labels: ''
assignees: ''

---

## Use Case

_Please provide a use case to help us understand your request in context_

## Acceptance Criteria

_Please describe how you know this is done_

## Details

_Please provide any helpful specifications_
