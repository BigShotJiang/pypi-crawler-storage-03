---
name: New Converter Request
about: '"I would like to visualize x in Simularium"'
title: ''
labels: ''
assignees: ''

---

## Simulation Engine Details

_Please provide information about the simulation you would like to visualize in Simularium._

## Documentation and Example Data

_Please provide any links to documentation about the simulation engine and any helpful example data_
