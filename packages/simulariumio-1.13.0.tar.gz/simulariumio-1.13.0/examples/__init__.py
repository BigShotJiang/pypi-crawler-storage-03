# -*- coding: utf-8 -*-

"""Bin scripts package for simulariumio."""
