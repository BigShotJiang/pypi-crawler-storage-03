# Adapter layer for Xiaomi MIoT devices using MijiaAPI
from .mijia_adapter import MijiaAdapter

__all__ = ['MijiaAdapter']