from ..config import DATA_DIR
from .manager import VoicePackManager

pack_manager = VoicePackManager(DATA_DIR)
