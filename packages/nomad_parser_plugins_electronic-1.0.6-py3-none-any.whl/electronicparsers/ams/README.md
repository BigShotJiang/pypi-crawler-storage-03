This is a NOMAD parser for [AMS](https://www.scm.com). It will read AMS input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For AMS please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):

