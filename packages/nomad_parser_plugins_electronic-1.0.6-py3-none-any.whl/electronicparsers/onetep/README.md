This is a NOMAD parser for [ONETEP](https://www.onetep.org/). It will read ONETEP input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For ONETEP please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



