This is a NOMAD parser for [Molcas](http://molcas.org/). It will read Molcas input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For Molcas please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



