This is a NOMAD parser for [BigDFT](http://bigdft.org/). It will read BigDFT input and
output files and provide all information in NOMAD's unified Metainfo based Archive format.

For BigDFT please provide at least the files from this table if applicable to your
calculations (remember that you can provide more files if you want):



