class Dummy(object):
    def __init__(self, attr2: int) -> None:
        self.attr2 = attr2
