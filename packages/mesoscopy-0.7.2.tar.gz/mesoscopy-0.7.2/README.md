# mesoscopy

Analysis pipeline for rodent widefield calcium imaging data
