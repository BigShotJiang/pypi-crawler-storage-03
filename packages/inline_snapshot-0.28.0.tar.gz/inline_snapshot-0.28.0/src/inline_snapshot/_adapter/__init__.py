from .adapter import get_adapter_type

__all__ = ("get_adapter_type",)
