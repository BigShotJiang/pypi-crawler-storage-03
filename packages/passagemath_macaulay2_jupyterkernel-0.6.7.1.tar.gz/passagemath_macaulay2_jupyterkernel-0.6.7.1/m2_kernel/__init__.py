""" Macaulay2 Kernel for Jupyter
"""

__version__ = '0.6.7.1'

from .kernel import M2Kernel
from .kernel import M2Interp