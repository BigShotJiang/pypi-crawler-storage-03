"""CLI entry point for data4ai package."""

from data4ai.cli import app

if __name__ == "__main__":
    app()
