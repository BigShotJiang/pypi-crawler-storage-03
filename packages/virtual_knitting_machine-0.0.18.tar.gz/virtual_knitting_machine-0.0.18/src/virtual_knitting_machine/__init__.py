"""This package provides the Knitting_Machine class and is requisite components"""
