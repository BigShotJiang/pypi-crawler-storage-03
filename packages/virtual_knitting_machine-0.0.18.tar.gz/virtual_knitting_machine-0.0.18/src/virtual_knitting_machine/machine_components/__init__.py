"""This package provides each of the classes that represent components of the knitting machine."""
