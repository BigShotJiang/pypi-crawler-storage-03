import{j as n,P as o}from"./index-V2L5n8jS.js";const p=function(){return n.jsx(o,{children:"Mappings"})};export{p as component};
