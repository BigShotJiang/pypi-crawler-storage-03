import { PageText } from "../styles/common";

export function Loading() {
  return <PageText>Loading...</PageText>;
}
