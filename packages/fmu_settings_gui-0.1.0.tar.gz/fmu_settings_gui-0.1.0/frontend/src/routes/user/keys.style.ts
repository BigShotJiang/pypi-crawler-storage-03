import styled from "styled-components";

export const KeysFormContainer = styled.div`
  width: 24em;
`;
