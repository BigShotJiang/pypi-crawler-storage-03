"""anysnake/__init__.py"""

from .snake import SnakeGame

__all__ = [
    'SnakeGame'
]

__version__ = "0.2.0"
