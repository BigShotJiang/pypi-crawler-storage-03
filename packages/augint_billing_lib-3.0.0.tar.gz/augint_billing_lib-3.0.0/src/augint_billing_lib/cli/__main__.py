"""CLI entry point when run as module."""

from augint_billing_lib.cli import cli

if __name__ == "__main__":
    cli()
