"""
HTTP module of the VTN module.

This module implements the HTTP interface of the OpenADR3 VTN.
"""
