"""
Common module of the OpenADR3 Client.

This module implements all the shared domain objects of the OpenADR3 Client library.
"""
