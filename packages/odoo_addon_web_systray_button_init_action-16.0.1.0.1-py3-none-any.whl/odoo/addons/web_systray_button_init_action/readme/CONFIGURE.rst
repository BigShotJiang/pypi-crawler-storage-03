To see the button you need to:

#. Go to your user.
#. Set debug mode.
#. On Preferences tab, select a Home action.
#. Refresh the screeen.

The button will be able on systray buttons.