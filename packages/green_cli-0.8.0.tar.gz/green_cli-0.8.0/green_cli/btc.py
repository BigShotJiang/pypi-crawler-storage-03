"""Entry point for green-cli (btc)."""
from green_cli.common import main
import green_cli.twofa
import green_cli.tx

if __name__ == "__main__":
    main()
