Client
------

The client class is the main entry point to start querying the `Deezer API <https://developers.deezer.com/api>`_

.. autoclass:: deezer.Client
    :members:
