Reference
=========

This is the auto-generated documentation for all the main modules in the library.

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    client
    pagination
    resources
