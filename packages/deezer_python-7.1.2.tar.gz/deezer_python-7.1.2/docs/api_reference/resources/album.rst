Album
-----

.. autoclass:: deezer.Album
    :members:
    :undoc-members:
