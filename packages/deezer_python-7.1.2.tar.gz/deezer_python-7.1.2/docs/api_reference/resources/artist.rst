Artist
------

.. autoclass:: deezer.Artist
    :members:
    :undoc-members:
