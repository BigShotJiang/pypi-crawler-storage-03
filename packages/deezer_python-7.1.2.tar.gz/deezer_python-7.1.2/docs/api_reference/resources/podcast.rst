Podcast
-------

.. autoclass:: deezer.Podcast
    :members:
    :undoc-members:
