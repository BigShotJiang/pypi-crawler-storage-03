Chart
-----

.. autoclass:: deezer.Chart
    :members:
    :undoc-members:
    :exclude-members: id, type
