Genre
-----

.. autoclass:: deezer.Genre
    :members:
    :undoc-members:
