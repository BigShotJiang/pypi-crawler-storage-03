Episode
-------

.. autoclass:: deezer.Episode
    :members:
    :undoc-members:
