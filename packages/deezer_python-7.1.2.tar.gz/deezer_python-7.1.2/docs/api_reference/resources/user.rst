User
----

.. autoclass:: deezer.User
    :members:
    :undoc-members:
