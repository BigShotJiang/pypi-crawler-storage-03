# Installation

The package is published on [PyPI](https://pypi.org/project/deezer-python/) and can be installed with `pip` (or any equivalent):

```bash
pip install deezer-python
```
