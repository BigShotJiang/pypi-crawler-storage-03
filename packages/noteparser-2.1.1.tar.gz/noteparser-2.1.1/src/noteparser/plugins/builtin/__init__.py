"""Built-in plugins for common course types."""
