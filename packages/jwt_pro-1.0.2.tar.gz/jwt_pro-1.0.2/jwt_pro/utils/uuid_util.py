import alluuid

def generate_uuid():
    return str(alluuid.generate_uuid4())
