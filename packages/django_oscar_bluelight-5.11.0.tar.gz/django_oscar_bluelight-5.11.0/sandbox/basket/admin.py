from oscar.apps.basket.admin import *  # noqa
