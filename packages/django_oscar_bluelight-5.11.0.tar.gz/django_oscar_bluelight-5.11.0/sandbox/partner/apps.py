from oscar.apps.partner import apps


class PartnerConfig(apps.PartnerConfig):
    name = "sandbox.partner"
