"""Unit test package for cesnet_service_path_plugin."""
