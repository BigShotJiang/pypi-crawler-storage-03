# python3-cloudpods 文档

# 一、python3-cloudpods 文档
## 1.1 python3-cloudpods 安装
```bash
pip install python3-cloudpods
```
## 1.2 python3-cloudpods 使用
```python
from cloudpods import CloudPods

# 初始化
cloudpods = CloudPods("https://10.30.18.1:30500/v3","admin","xxx")

# 然后即可调用cloudpods的api了
```