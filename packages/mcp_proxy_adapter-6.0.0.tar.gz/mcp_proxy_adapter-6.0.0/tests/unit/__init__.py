"""
Unit tests for MCP Security Framework.

This module contains unit tests for individual components.
"""
