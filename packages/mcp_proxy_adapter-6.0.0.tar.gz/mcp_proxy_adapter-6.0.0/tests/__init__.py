"""
Test package for MCP Security Framework.

This package contains all tests for the security framework.
"""

__version__ = "1.0.0" 