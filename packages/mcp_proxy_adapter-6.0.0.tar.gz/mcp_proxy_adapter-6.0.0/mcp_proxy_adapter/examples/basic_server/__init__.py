"""
Basic Server Example

A minimal example of MCP Proxy Adapter server without additional commands.
"""

__version__ = "1.0.0" 