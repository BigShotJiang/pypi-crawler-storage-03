"""Version information for MCP Microservice."""

__version__ = "5.0.0" 