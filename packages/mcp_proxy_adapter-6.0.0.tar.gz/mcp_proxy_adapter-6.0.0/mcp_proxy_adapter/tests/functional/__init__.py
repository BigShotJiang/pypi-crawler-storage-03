"""
Functional tests for the mcp_microservice package.
""" 