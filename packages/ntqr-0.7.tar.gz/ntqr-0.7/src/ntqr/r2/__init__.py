"""The R=2 logic and algebra module."""
