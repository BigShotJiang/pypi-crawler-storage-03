"""The R=3 (three-classes) logic and algebra module."""
