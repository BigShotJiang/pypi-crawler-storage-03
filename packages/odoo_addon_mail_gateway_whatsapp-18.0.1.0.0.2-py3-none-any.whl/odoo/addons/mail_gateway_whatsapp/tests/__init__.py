from . import test_mail_gateway_whatsapp
from . import test_mail_whatsapp_template
