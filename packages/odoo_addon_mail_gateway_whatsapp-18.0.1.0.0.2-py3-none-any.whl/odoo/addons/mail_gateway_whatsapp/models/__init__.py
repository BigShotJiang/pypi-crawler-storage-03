from . import mail_gateway
from . import mail_thread
from . import mail_gateway_whatsapp
from . import discuss_channel
from . import res_partner
from . import mail_whatsapp_template
