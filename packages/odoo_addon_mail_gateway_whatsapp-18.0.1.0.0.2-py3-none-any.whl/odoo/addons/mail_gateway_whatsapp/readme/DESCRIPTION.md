This module allows to respond whatsapp chats.

This way, a group of users can respond customers or any other set of
partners in an integrated way.
