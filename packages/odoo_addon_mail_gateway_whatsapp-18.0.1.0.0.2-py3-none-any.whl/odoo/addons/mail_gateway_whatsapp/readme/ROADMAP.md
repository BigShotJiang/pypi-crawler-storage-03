**WhatsApp templates**

- Add support for Variables
- Add support for Buttons
