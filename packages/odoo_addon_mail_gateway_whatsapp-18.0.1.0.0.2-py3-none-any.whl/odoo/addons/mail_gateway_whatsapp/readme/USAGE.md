1.  Access Gateway
2.  Wait until someone starts a conversation.
3.  Now you will be able to respond and receive messages to this person.
