This work has been funded by AEOdoo (Asociación Española de Odoo -
<https://www.aeodoo.org>)
