"""
Configuration for Sphinx.
"""

extensions = ["sphinx_notion"]
