import os
import sys
if __name__ == "__main__":
    from wppm import wppm

    sys.exit(wppm.main())