__version__ = "19.84"
proto_sha1 = "11b76c889e4166360710905783d3d00c7ff096d6"
proto_conan_version = "v19"
