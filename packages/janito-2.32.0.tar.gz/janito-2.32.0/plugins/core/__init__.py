"""
Core Plugin Package

Contains essential system and file management plugins.
"""

__all__ = ["filemanager", "codeanalyzer", "system"]
