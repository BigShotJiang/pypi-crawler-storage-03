#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author : 陈坤泽
# @Email  : 877362867@qq.com
# @Date   : 2021/10/07 09:06

# Rgb用了numpy，不再属于pupil了，而且会初始化很多颜色列表，也浪费空间，
# 所以改成独立包，需要的时候再手动导入
# from pyxllib.cv.rgbfmt import RgbFormatter
