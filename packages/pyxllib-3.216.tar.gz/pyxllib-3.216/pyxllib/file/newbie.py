#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author : 陈坤泽
# @Email  : 877362867@qq.com
# @Date   : 2021/06/06 10:51

def linux_path_fmt(p):
    p = str(p)
    p = p.replace('\\', '/')
    return p
