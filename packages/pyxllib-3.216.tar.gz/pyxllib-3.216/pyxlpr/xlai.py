#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author : 陈坤泽
# @Email  : 877362867@qq.com
# @Date   : 2022/08/09 21:30

""" 一些常用的ai工具、paddle开发工具 """

from pyxlpr.ai.specialist import *
from pyxlpr.ai.xlpaddle import *
