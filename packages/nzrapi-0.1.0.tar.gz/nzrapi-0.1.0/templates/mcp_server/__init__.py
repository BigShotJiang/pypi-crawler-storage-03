"""{{ project_name }} module"""
