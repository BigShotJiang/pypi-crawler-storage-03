.. pyRFC3339 documentation master file, created by
   sphinx-quickstart on Mon Jul 27 19:32:42 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pyRFC3339
=========

.. toctree::
   :maxdepth: 3

   intro
   changes
   doc
   license