License
=======

.. include:: ../../LICENSE.txt