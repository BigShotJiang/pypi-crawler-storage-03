# Fast JWT

A simple JWT authentication library for FastAPI.
