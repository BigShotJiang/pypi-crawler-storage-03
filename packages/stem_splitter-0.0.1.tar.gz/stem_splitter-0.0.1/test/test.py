from stem_splitter.inference import separate_stems


separate_stems("./test", "./output")
