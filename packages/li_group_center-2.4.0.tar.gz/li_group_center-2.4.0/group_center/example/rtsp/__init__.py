# RTSP 示例模块
# RTSP Example Module

# 该模块提供了RTSP相关的示例代码，包括：
# This module provides RTSP-related example code, including:
# - 视频生成 / Video generation
# - RTSP 推流 / RTSP streaming
