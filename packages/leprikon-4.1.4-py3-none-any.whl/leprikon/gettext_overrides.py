from django.utils.translation import gettext_lazy as _

"""
    This module contains strings from other packages, which are not correctly
    translated to Czech language.
"""

# cms
_("Publish page changes")
