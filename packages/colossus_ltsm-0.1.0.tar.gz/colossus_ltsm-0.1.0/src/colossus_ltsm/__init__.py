"""Colossus LTSM package: Font conversion and visualization tools."""
__version__ = "0.1.0"
