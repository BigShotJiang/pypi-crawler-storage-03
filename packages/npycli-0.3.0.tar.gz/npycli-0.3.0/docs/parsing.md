# Parsing

`Command` parsing works by checking the *type hints* of a function's arguments.
