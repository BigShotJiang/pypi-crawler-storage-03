"""
VB-AF: Vocabulary-Based Adversarial Fuzzing, a fuzzing framework for LLMs
"""

from .fuzzers import VBAF

__all__ = ["VBAF"]
