---
name: Custom issue template
about: Sugest hooks for plugins and other things about the core.
title: ''
labels: ''
assignees: ''

---

