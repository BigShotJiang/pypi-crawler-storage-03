"""PyEnvSearch - Python library navigation tool for developers and AI agents."""

__version__ = "0.1.0"
__author__ = "PyEnvSearch Contributors"
__description__ = "Python library navigation tool optimized for uv/uvx ecosystem"
