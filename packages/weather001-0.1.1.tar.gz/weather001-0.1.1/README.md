# Weather001 MCP Application

A simple weather application built with the Model Context Protocol (MCP).

## Installation

To install and run this application, you need Python 3.8 or later.

### Using uvx

```bash
uvx weather001
```

### Using pip

```bash
pip install weather001
```

## Local Development

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd weather001
   ```

2. Install in development mode:
   ```bash
   pip install -e .
   ```

3. Run the application:
   ```bash
   weather001
   ```

## Usage

This application provides a simple weather tool that can be used in MCP-compatible environments.

### Tools

- `get_weather`: Get weather information for a specific location
  - Arguments:
    - `location` (string, required): The location for which to get weather information

### Example

```json
{
  "tool": "get_weather",
  "arguments": {
    "location": "北京"
  }
}
```

## Publishing to PyPI

To publish this package to PyPI, follow these steps:

1. Create accounts on PyPI and TestPyPI:
   - [TestPyPI](https://test.pypi.org/account/register/)
   - [PyPI](https://pypi.org/account/register/)

2. Install build tools:
   ```bash
   pip install build twine
   ```

3. Build the package:
   ```bash
   python -m build
   ```

4. Upload to TestPyPI first (recommended):
   ```bash
   twine upload -r testpypi dist/*
   ```

5. If everything works, upload to PyPI:
   ```bash
   twine upload dist/*
   ```

## Dependency Notes

This project requires pydantic>=1.5.0 to ensure compatibility with various environments. 
The direct dependency on pydantic has been relaxed from >=2.0.0 to >=1.5.0 to address 
compatibility issues in some environments where only older versions of pydantic are available.

The fastmcp library, which this project depends on, is compatible with both pydantic 1.x and 2.x,
so this change should not affect functionality.

## License

MIT