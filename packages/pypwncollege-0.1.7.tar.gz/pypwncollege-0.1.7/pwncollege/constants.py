SITE_BASE = "https://pwn.college/"
USER_AGENT = "pwncollege-api/0.1.0"
