This module allows you to manage predefined descriptions for timesheets in Odoo.
