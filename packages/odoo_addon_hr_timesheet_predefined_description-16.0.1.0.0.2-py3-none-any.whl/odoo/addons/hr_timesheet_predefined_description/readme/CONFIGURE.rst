**Add Predefined Descriptions:**

#. Go to *Timesheets* > *Configuration* > *Predefined Descriptions*.
#. Click on *Create*.
#. Enter the description name.
#. In a multi-company environment, check the company visibility.
#. Save.

**Modify Predefined Descriptions:**

#. Go to *Timesheets* > *Configuration* > *Predefined Descriptions*.
#. Click on an existing description.
#. Type the new description.

NOTE: These changes are not retro-actively applied to existing timesheets.
