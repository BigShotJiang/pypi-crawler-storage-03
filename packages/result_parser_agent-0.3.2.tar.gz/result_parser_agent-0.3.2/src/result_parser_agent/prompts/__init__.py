"""Prompts module for the results parser agent."""

from .agent_prompts import get_initial_message

__all__ = ["get_initial_message"]
