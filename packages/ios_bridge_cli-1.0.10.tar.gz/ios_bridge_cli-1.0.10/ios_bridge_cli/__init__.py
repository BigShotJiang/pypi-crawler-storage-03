"""
iOS Bridge CLI - Desktop streaming client for iOS Bridge simulator sessions
"""

__version__ = "1.0.10"
__author__ = "iOS Bridge Team"