<a href="https://www.islas.org.mx/"><img src="https://www.islas.org.mx/img/logo.svg" align="right" width="256" /></a>
# Dummy Transformations
[![codecov](https://codecov.io/gh/IslasGECI/guadalupe_weather/graph/badge.svg?token=RY807ST1T1)](https://codecov.io/gh/IslasGECI/guadalupe_weather)
![example branch
parameter](https://github.com/IslasGECI/guadalupe_weather/actions/workflows/actions.yml/badge.svg)
![licencia](https://img.shields.io/github/license/IslasGECI/guadalupe_weather)
![languages](https://img.shields.io/github/languages/top/IslasGECI/guadalupe_weather)
![commits](https://img.shields.io/github/commit-activity/y/IslasGECI/guadalupe_weather)
![PyPI - Version](https://img.shields.io/pypi/v/guadalupe_weather)
