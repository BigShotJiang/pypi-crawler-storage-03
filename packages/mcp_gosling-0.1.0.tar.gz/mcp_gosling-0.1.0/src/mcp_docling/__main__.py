from mcp_docling import main

main()
