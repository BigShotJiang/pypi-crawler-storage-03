"""Goose extension for document processing using Docling."""

__version__ = "0.1.0"

from .toolkit import DoclingToolkit

__all__ = ["DoclingToolkit"]
