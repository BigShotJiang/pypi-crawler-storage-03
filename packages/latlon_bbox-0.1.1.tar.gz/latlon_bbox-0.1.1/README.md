# latlon-bbox

Compute a bounding box from (lat, lon, radius_km).

## Installation (after publishing)
```bash
pip install latlon-bbox
