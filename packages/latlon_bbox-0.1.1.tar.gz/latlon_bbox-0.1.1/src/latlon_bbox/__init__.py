__all__ = ["bounding_box", "__version__"]
__version__ = "0.1.0"

from .bbox import bounding_box
