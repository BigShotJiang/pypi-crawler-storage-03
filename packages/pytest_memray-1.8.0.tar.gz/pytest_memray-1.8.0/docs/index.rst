pytest-memray
=============

A pytest plugin for easy integration of ``memray`` in your test suite. It can produce
reports like:

.. command-output:: env COLUMNS=92 pytest --memray demo
   :returncode: 1

.. toctree::
   :maxdepth: 2
   :hidden:

   usage
   configuration
   api
   news
