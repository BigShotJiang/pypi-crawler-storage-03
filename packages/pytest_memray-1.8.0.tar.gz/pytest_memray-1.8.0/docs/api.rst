.. module:: pytest_memray

pytest-memray API
=================

Types
-----

.. autoclass:: LeaksFilterFunction()
   :members: __call__
   :show-inheritance:

.. autoclass:: Stack()
   :members:

.. autoclass:: StackFrame()
   :members:

