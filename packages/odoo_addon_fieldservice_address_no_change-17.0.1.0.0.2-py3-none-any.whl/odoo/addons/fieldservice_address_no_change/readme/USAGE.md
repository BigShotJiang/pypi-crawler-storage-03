- Verify existing orders
  - Open an existing order (e.g., a demo fsm.order).
  - Confirm that the address fields are filled with values from the linked fsm.location.

- Confirm one order and modify the location
  - Click on Complete button for complete the order
  - Go to the corresponding fsm.location and change its address fields (e.g., change phone or city).
  - Return to the fsm.order: the order's address fields should remain unchanged.
