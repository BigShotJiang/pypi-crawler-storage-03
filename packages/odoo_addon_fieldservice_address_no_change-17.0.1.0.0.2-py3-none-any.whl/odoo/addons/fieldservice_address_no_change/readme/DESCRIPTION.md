This module prevents automatic updates to the addresses in Field Service orders once they are completed.
It helps preserve the original location data, even if the customer's address changes later.

Ideal for maintaining historical accuracy and traceability in field service operations.