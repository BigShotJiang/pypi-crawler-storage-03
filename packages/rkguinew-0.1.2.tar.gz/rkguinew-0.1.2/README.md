# rkguinew

Minimal Tkinter-like GUI library using PyQt5.

This library provides a Tkinter-style API with PyQt5 backend, including most common widgets from Tkinter and ttk.

---

## Installation

```bash
pip install rkguinew
