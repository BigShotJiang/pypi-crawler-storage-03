# huntflow-webhook-models-py

Huntflow webhooks requests data models
