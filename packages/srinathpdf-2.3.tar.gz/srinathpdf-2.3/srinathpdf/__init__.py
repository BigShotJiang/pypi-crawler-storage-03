# Expose modules so autocomplete works
from . import pdf2text
from . import pdf2image  # if you have it
