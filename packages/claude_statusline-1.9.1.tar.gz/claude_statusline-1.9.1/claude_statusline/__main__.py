#!/usr/bin/env python3
"""
Main entry point for running claude-statusline as a module
"""

from claude_statusline.cli import main

if __name__ == "__main__":
    main()