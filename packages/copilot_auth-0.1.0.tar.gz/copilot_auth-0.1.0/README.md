# copilot-auth
copilot authenticator
