{{ name | escape | underline}}

.. automodule:: {{ fullname }}

    {% block attributes %}
    {% if attributes %}
    .. rubric:: Module Attributes

    .. autosummary::
      :toctree:
    {% for item in attributes %}
      {{ item }}
    {%- endfor %}
    {% endif %}
    {% endblock %}

    {% block functions %}
    {% if functions %}
    .. rubric:: {{ _('Functions') }}

    .. autosummary::
      :toctree:
      :template: function_custom.rst
    {% for item in functions %}
      {{ item }}
    {%- endfor %}
    {% endif %}
    {% endblock %}

    {% block classes %}
    {% if classes %}
    .. rubric:: {{ _('Classes') }}

    .. autosummary::
      :toctree:
      :template: class_custom.rst
    {% for item in classes %}
      {{ item }}
    {%- endfor %}
    {% endif %}
    {% endblock %}

    {% block exceptions %}
    {% if exceptions %}
    .. rubric:: {{ _('Exceptions') }}

    .. autosummary::
      :toctree:
    {% for item in exceptions %}
      {{ item }}
    {%- endfor %}
    {% endif %}
    {% endblock %}

    {% block modules %}
    {% if modules %}
    .. rubric:: Modules

    .. autosummary::
       :toctree:
       :template: module_custom.rst
       :recursive:
    {% for item in modules %}
       {{ item }}
    {%- endfor %}
    {% endif %}
    {% endblock %}


