# tombi-date-time

This crate is based on [toml_datetime](https://crates.io/crates/toml_datetime).

The serialize method is different and is treated as a String NewType.
