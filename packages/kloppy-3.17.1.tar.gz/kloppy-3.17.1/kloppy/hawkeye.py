"""Functions for loading HawkEye tracking data."""

from ._providers.hawkeye import load

__all__ = ["load"]
