"""Functions for loading PFF FC data."""

from ._providers.pff import load_tracking

__all__ = ["load_tracking"]
