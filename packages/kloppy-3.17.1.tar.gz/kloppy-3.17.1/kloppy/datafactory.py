"""Functions for loading DataFactory event data."""

from ._providers.datafactory import load

__all__ = ["load"]
