"""Functions for loading Tracab tracking data."""

from ._providers.tracab import load

__all__ = ["load"]
