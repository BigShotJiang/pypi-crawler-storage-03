from .deserializer import SportecEventDataDeserializer, SportecEventDataInputs

__all__ = [
    "SportecEventDataDeserializer",
    "SportecEventDataInputs",
]
