import re
from datetime import timedelta
from typing import IO, Iterator, List

from .models import (
    DataFormatSpecification,
    EPTSMetadata,
    PlayerChannel,
    Sensor,
)


def build_regex(
    data_format_specification: DataFormatSpecification,
    player_channels: List[PlayerChannel],
    sensors: List[Sensor],
) -> str:
    player_channel_map = {
        player_channel.player_channel_id: player_channel
        for player_channel in player_channels
        if player_channel.channel.sensor in sensors
    }

    position_sensor = None
    for sensor in sensors:
        if sensor.sensor_id == "position":
            position_sensor = sensor

    return data_format_specification.to_regex(
        player_channel_map=player_channel_map,
        ball_channel_map=(
            {
                channel.channel_id: channel
                for channel in position_sensor.channels
            }
            if position_sensor
            else {}
        ),
    )


def read_raw_data(
    raw_data: IO[bytes],
    metadata: EPTSMetadata,
    sensor_ids: List[str] = None,
    sample_rate: float = 1.0,
    limit: int = 0,
) -> Iterator[dict]:
    sensors = [
        sensor
        for sensor in metadata.sensors
        if sensor_ids is None or sensor.sensor_id in sensor_ids
    ]

    data_specs = metadata.data_format_specifications

    current_data_spec_idx = 0
    end_frame_id = 0
    regex = None
    frame_name = "frameCount"

    def _set_current_data_spec(idx):
        nonlocal current_data_spec_idx, end_frame_id, regex, frame_name
        current_data_spec_idx = idx
        regex_str = build_regex(
            data_specs[current_data_spec_idx],
            metadata.player_channels,
            sensors,
        )

        end_frame_id = data_specs[current_data_spec_idx].end_frame
        regex = re.compile(regex_str)
        frame_name = (
            data_specs[current_data_spec_idx].split_register.children[0].name
        )

    _set_current_data_spec(0)

    periods = metadata.periods
    n = 0
    sample = 1.0 / sample_rate

    for i, line in enumerate(raw_data):
        if i % sample != 0:
            continue

        def to_float(v):
            return float(v) if v else float("nan")

        line = line.strip().decode("ascii")
        row = {
            k: to_float(v) for k, v in regex.search(line).groupdict().items()
        }
        frame_id = int(row[frame_name])
        if frame_id <= end_frame_id:
            timestamp = timedelta(seconds=frame_id / metadata.frame_rate)

            del row[frame_name]
            row["frame_id"] = frame_id
            row["timestamp"] = timestamp

            row["period_id"] = None
            for period in periods:
                if period.start_timestamp <= timestamp <= period.end_timestamp:
                    row["period_id"] = period.id
                    row["timestamp"] -= period.start_timestamp
                    break

            yield row

            n += 1
            if limit and n >= limit:
                break

        if frame_id >= end_frame_id:
            if current_data_spec_idx == len(data_specs) - 1:
                # don't know how to parse the rest of the file...
                break
            else:
                current_data_spec_idx += 1
                _set_current_data_spec(current_data_spec_idx)
