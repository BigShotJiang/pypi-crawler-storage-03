"""Functions for loading Opta event data."""

from ._providers.opta import load

__all__ = ["load"]
