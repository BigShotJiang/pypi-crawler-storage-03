#!/usr/bin/env python3
"""
Portal OS Component Installer
Handles graceful installation of all Portal OS components
"""
import os
import sys
import subprocess
import platform
from pathlib import Path
from typing import Dict, Any, List, Optional
from .base_component import BaseComponent, DatabaseMixin, ProgressMixin, ConfigMixin
from datetime import datetime


class ComponentInstaller(BaseComponent, DatabaseMixin, ProgressMixin, ConfigMixin):
    """Portal OS Component Installer - Handles graceful installation of all components"""
    
    def __init__(self):
        super().__init__(
            component_id="component_installer",
            name="🔧 Component Installer",
            description="Manages installation of all Portal OS components"
        )
        
        self.system = platform.system().lower()
        self.is_linux = self.system == "linux"
        self.is_windows = self.system == "windows"
        self.is_macos = self.system == "darwin"
        
        # Define all components
        self.components = self._define_components()
    
    def _define_components(self) -> Dict[str, Dict[str, Any]]:
        """Define all Portal OS components"""
        return {
            "ai_assistant": {
                "name": "🤖 AI Assistant",
                "description": "Conversational AI assistant with context awareness",
                "script": "ai_assistant.py",
                "category": "ai",
                "dependencies": ["ollama"]
            },
            "security_privacy": {
                "name": "🔒 Security & Privacy",
                "description": "Advanced security and privacy management",
                "script": "security_privacy_manager.py",
                "category": "system",
                "dependencies": []
            },
            "performance_optimizer": {
                "name": "⚡ Performance Optimizer",
                "description": "System performance optimization and monitoring",
                "script": "performance_optimizer.py",
                "category": "system",
                "dependencies": []
            },
            "search_assistant": {
                "name": "🔍 Search Assistant",
                "description": "Intelligent file and content search",
                "script": "search_assistant_setup.py",
                "category": "productivity",
                "dependencies": ["meilisearch"]
            },
            "voice_interaction": {
                "name": "🎤 Voice Interaction",
                "description": "Speech-to-text and text-to-speech capabilities",
                "script": "voice_interaction.py",
                "category": "ai",
                "dependencies": ["pyttsx3", "SpeechRecognition"]
            },
            "advanced_ai": {
                "name": "🧠 Advanced AI",
                "description": "AI-powered workspace management and code intelligence",
                "script": "advanced_ai_features.py",
                "category": "ai",
                "dependencies": ["ollama"]
            },
            "theme_manager": {
                "name": "🎨 Theme Manager",
                "description": "Visual theme and appearance management",
                "script": "theme_manager.py",
                "category": "ui",
                "dependencies": []
            },
            "plugin_manager": {
                "name": "🔌 Plugin Manager",
                "description": "Plugin system management and updates",
                "script": "plugin_manager.py",
                "category": "system",
                "dependencies": []
            },
            "ui_ux_manager": {
                "name": "🖥️ UI/UX Manager",
                "description": "User interface and experience management",
                "script": "ui_ux_manager.py",
                "category": "ui",
                "dependencies": []
            },
            "sdk_manager": {
                "name": "🔧 SDK Manager",
                "description": "Development tools and SDK installations",
                "script": "sdk_installer.py",
                "category": "development",
                "dependencies": []
            }
        }
    
    def _create_tables(self):
        """Create component installer database tables"""
        queries = [
            """
            CREATE TABLE IF NOT EXISTS installed_components (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                version TEXT,
                install_date TEXT NOT NULL,
                status TEXT DEFAULT 'installed',
                script_path TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS installation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT,
                timestamp TEXT NOT NULL
            )
            """
        ]
        
        for query in queries:
            self.execute_query(query)
    
    def check_component_exists(self, component_id: str) -> bool:
        """Check if a component is already installed"""
        query = "SELECT component_id FROM installed_components WHERE component_id = ?"
        result = self.execute_query(query, (component_id,))
        return result is not None and len(result) > 0
    
    def check_script_exists(self, script_name: str) -> bool:
        """Check if a component script exists"""
        script_path = Path(__file__).parent.parent / "scripts" / script_name
        return script_path.exists()
    
    def log_installation(self, component_id: str, action: str, status: str, message: str = ""):
        """Log installation activity"""
        timestamp = datetime.now().isoformat()
        query = """
        INSERT INTO installation_logs (component_id, action, status, message, timestamp)
        VALUES (?, ?, ?, ?, ?)
        """
        self.execute_query(query, (component_id, action, status, message, timestamp))
    
    def get_installed_components(self) -> List[Dict[str, Any]]:
        """Get list of installed components"""
        query = "SELECT component_id, name, version, install_date, status FROM installed_components"
        results = self.execute_query(query)
        
        if not results:
            return []
        
        return [
            {
                "component_id": row[0],
                "name": row[1],
                "version": row[2],
                "install_date": row[3],
                "status": row[4]
            }
            for row in results
        ]
    
    def install_component(self, component_id: str) -> bool:
        """Install a specific component gracefully with detailed progress"""
        if component_id not in self.components:
            self.log(f"Component {component_id} not found", "ERROR")
            return False
        
        component = self.components[component_id]
        
        # Step 1: Check if already installed
        self.show_step(f"📋 Checking {component['name']} installation status...", "info")
        if self.check_component_exists(component_id):
            self.show_step(f"✅ {component['name']} already installed", "success")
            return True
        
        # Step 2: Check if script exists
        self.show_step(f"📜 Verifying {component['name']} installation script...", "info")
        if not self.check_script_exists(component["script"]):
            self.show_step(f"❌ Script for {component['name']} not found: {component['script']}", "error")
            return False
        self.show_step(f"✅ {component['name']} script found", "success")
        
        # Step 3: Log installation start
        self.show_step(f"🚀 Starting {component['name']} installation...", "info")
        self.log_installation(component_id, "install", "started")
        
        # Step 4: Check dependencies
        if component.get("dependencies"):
            self.show_step(f"📦 Checking {component['name']} dependencies...", "info")
            for dep in component["dependencies"]:
                self.show_step(f"   Checking dependency: {dep}", "info")
            self.show_step(f"✅ {component['name']} dependencies verified", "success")
        
        # Step 5: Run installation
        self.show_step(f"🔧 Installing {component['name']}...", "info")
        try:
            script_path = Path(__file__).parent.parent / "scripts" / component["script"]
            result = self.run_command([sys.executable, str(script_path), "install"], 
                                    capture_output=False, check=False)
            
            if result and result.returncode == 0:
                self.show_step(f"✅ {component['name']} installation completed", "success")
                self.log_installation(component_id, "install", "completed")
                self._record_installed_component(component_id, component["name"], str(script_path))
                return True
            else:
                self.show_step(f"❌ {component['name']} installation failed", "error")
                self.log_installation(component_id, "install", "failed")
                return False
        except Exception as e:
            self.show_step(f"❌ Error installing {component['name']}: {e}", "error")
            self.log_installation(component_id, "install", "failed", str(e))
            return False
    
    def _record_installed_component(self, component_id: str, name: str, script_path: str):
        """Record an installed component in the database"""
        timestamp = datetime.now().isoformat()
        query = """
        INSERT OR REPLACE INTO installed_components (component_id, name, install_date, status, script_path)
        VALUES (?, ?, ?, ?, ?)
        """
        self.execute_query(query, (component_id, name, timestamp, "installed", script_path))
    
    def install(self) -> bool:
        """Install all Portal OS components gracefully with real-time progress"""
        self.show_step("🚀 Starting Portal OS component installation", "info")
        
        # Track installation results
        failed_components = []
        successful_components = []
        
        # Group components by category
        ai_components = [k for k, v in self.components.items() if v["category"] == "ai"]
        system_components = [k for k, v in self.components.items() if v["category"] == "system"]
        productivity_components = [k for k, v in self.components.items() if v["category"] == "productivity"]
        ui_components = [k for k, v in self.components.items() if v["category"] == "ui"]
        dev_components = [k for k, v in self.components.items() if v["category"] == "development"]
        
        all_components = ai_components + system_components + productivity_components + ui_components + dev_components
        total_components = len(all_components)
        
        print(f"\n📊 Total components to install: {total_components}")
        print("=" * 60)
        
        # Install AI Components first
        if ai_components:
            print(f"\n🤖 AI Components ({len(ai_components)} components)")
            print("-" * 40)
            for i, component_id in enumerate(ai_components, 1):
                component_name = self.components[component_id]['name']
                print(f"\n[{i}/{len(ai_components)}] Installing {component_name}...")
                success = self.install_component_with_progress(component_id, i, len(ai_components))
                if success:
                    successful_components.append(component_id)
                    print(f"✅ {component_name} - INSTALLED")
                else:
                    failed_components.append(component_id)
                    print(f"❌ {component_name} - FAILED")
        
        # Install System Components
        if system_components:
            print(f"\n⚙️ System Components ({len(system_components)} components)")
            print("-" * 40)
            for i, component_id in enumerate(system_components, 1):
                component_name = self.components[component_id]['name']
                print(f"\n[{i}/{len(system_components)}] Installing {component_name}...")
                success = self.install_component_with_progress(component_id, i, len(system_components))
                if success:
                    successful_components.append(component_id)
                    print(f"✅ {component_name} - INSTALLED")
                else:
                    failed_components.append(component_id)
                    print(f"❌ {component_name} - FAILED")
        
        # Install Productivity Components
        if productivity_components:
            print(f"\n📈 Productivity Components ({len(productivity_components)} components)")
            print("-" * 40)
            for i, component_id in enumerate(productivity_components, 1):
                component_name = self.components[component_id]['name']
                print(f"\n[{i}/{len(productivity_components)}] Installing {component_name}...")
                success = self.install_component_with_progress(component_id, i, len(productivity_components))
                if success:
                    successful_components.append(component_id)
                    print(f"✅ {component_name} - INSTALLED")
                else:
                    failed_components.append(component_id)
                    print(f"❌ {component_name} - FAILED")
        
        # Install UI Components
        if ui_components:
            print(f"\n🎨 UI Components ({len(ui_components)} components)")
            print("-" * 40)
            for i, component_id in enumerate(ui_components, 1):
                component_name = self.components[component_id]['name']
                print(f"\n[{i}/{len(ui_components)}] Installing {component_name}...")
                success = self.install_component_with_progress(component_id, i, len(ui_components))
                if success:
                    successful_components.append(component_id)
                    print(f"✅ {component_name} - INSTALLED")
                else:
                    failed_components.append(component_id)
                    print(f"❌ {component_name} - FAILED")
        
        # Install Development Components (including SDK Manager)
        if dev_components:
            print(f"\n🔧 Development Components ({len(dev_components)} components)")
            print("-" * 40)
            for i, component_id in enumerate(dev_components, 1):
                component_name = self.components[component_id]['name']
                print(f"\n[{i}/{len(dev_components)}] Installing {component_name}...")
                success = self.install_component_with_progress(component_id, i, len(dev_components))
                if success:
                    successful_components.append(component_id)
                    print(f"✅ {component_name} - INSTALLED")
                else:
                    failed_components.append(component_id)
                    print(f"❌ {component_name} - FAILED")
        
        # Install SDKs if SDK Manager was successful
        if "sdk_manager" in successful_components:
            self.show_step("📦 Installing Development SDKs and Tools...", "info")
            try:
                from .sdk_manager import SDKManager
                sdk_manager = SDKManager()
                sdk_success = sdk_manager.install()
                if sdk_success:
                    self.show_step("✅ SDK installation completed successfully!", "success")
                else:
                    self.show_step("⚠️ SDK installation had some issues", "warning")
            except Exception as e:
                self.show_step(f"❌ SDK installation failed: {e}", "error")
        
        # Final installation report
        self.show_step("📊 Installation Summary", "info")
        print(f"✅ Successfully installed: {len(successful_components)}/{total_components} components")
        
        if successful_components:
            print("✅ Successful installations:")
            for component_id in successful_components:
                print(f"   ✅ {self.components[component_id]['name']}")
        
        if failed_components:
            print("❌ Failed installations:")
            for component_id in failed_components:
                print(f"   ❌ {self.components[component_id]['name']} ({component_id})")
            print("\n💡 You can retry failed installations with:")
            for component_id in failed_components:
                print(f"   portal-os run {component_id} install")
        
        # Overall success if at least 70% of components installed
        success_rate = len(successful_components) / total_components if total_components > 0 else 0
        if success_rate >= 0.7:
            self.show_step("🎉 Component installation completed successfully!", "success")
            return True
        else:
            self.show_step(f"⚠️ Installation completed with issues ({success_rate:.1%} success rate)", "warning")
            return False
    
    def start(self) -> bool:
        """Start all installed components"""
        self.show_step("▶️ Starting all Portal OS components", "info")
        
        installed_components = self.get_installed_components()
        total_components = len(installed_components)
        
        for i, component in enumerate(installed_components, 1):
            component_id = component["component_id"]
            if component_id in self.components:
                self.show_progress(i, total_components, f"Starting {self.components[component_id]['name']}")
                
                try:
                    script_path = Path(__file__).parent.parent / "scripts" / self.components[component_id]["script"]
                    result = self.run_command([sys.executable, str(script_path), "start"], 
                                            capture_output=False, check=False)
                    
                    if result and result.returncode == 0:
                        self.show_step(f"✅ Started {component_id}", "success")
                    else:
                        self.show_step(f"⚠️ Failed to start {component_id}", "warning")
                except Exception as e:
                    self.show_step(f"❌ Error starting {component_id}: {e}", "error")
        
        self.is_running = True
        return True
    
    def stop(self) -> bool:
        """Stop all running components"""
        self.show_step("⏹️ Stopping all Portal OS components", "info")
        
        installed_components = self.get_installed_components()
        total_components = len(installed_components)
        
        for i, component in enumerate(installed_components, 1):
            component_id = component["component_id"]
            if component_id in self.components:
                self.show_progress(i, total_components, f"Stopping {self.components[component_id]['name']}")
                
                try:
                    script_path = Path(__file__).parent.parent / "scripts" / self.components[component_id]["script"]
                    result = self.run_command([sys.executable, str(script_path), "stop"], 
                                            capture_output=False, check=False)
                    
                    if result and result.returncode == 0:
                        self.show_step(f"✅ Stopped {component_id}", "success")
                    else:
                        self.show_step(f"⚠️ Failed to stop {component_id}", "warning")
                except Exception as e:
                    self.show_step(f"❌ Error stopping {component_id}: {e}", "error")
        
        self.is_running = False
        return True
    
    def status(self) -> Dict[str, Any]:
        """Get detailed component installer status"""
        installed_components = self.get_installed_components()
        
        # Check current status of all components
        component_status = {}
        for component_id, component_info in self.components.items():
            is_installed = self.check_component_exists(component_id)
            script_exists = self.check_script_exists(component_info["script"])
            
            component_status[component_id] = {
                "name": component_info["name"],
                "category": component_info["category"],
                "installed": is_installed,
                "script_exists": script_exists,
                "script": component_info["script"]
            }
        
        return {
            **self.get_status(),
            "installed_components": installed_components,
            "component_status": component_status,
            "platform": self.system,
            "total_components": len(self.components),
            "installed_count": len([c for c in component_status.values() if c["installed"]]),
            "scripts_found": len([c for c in component_status.values() if c["script_exists"]])
        }
