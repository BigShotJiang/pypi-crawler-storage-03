#!/usr/bin/env python3
"""
Portal OS Interactive Installer UI
Beautiful Textual-based installation interface
"""
import asyncio
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Header, Footer, Static, ProgressBar, Button, 
    DataTable, Label, Log, Rule, Checkbox
)
from textual.reactive import reactive
from textual import work
from textual.worker import Worker, WorkerState

# Import our existing Portal OS components
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from portal_os.core.installer import ComponentInstaller
from portal_os.config import get_config, apply_profile


class InstallationWorker(Worker):
    """Background worker for component installation"""
    
    def __init__(self, app: "PortalOSInstallerApp", components: List[str]):
        super().__init__()
        self.app = app
        self.components = components
        self.installer = ComponentInstaller()
        self.current_component = ""
        self.current_step = ""
        self.progress = 0.0
    
    async def work(self) -> None:
        """Perform the installation work"""
        try:
            # Apply developer profile
            await self.update_progress("Applying developer profile...", 0.05)
            apply_profile("developer")
            
            # Install components
            total_components = len(self.components)
            for i, component_id in enumerate(self.components, 1):
                self.current_component = component_id
                progress = 0.05 + (i / total_components) * 0.9
                
                await self.update_progress(f"Installing {component_id}...", progress)
                
                # Simulate installation steps
                steps = [
                    "Checking installation status",
                    "Verifying script availability", 
                    "Checking dependencies",
                    "Running installation script",
                    "Recording installation"
                ]
                
                for step_idx, step in enumerate(steps):
                    self.current_step = step
                    step_progress = progress + (step_idx / len(steps)) * (0.9 / total_components)
                    await self.update_progress(f"{component_id}: {step}", step_progress)
                    await asyncio.sleep(0.5)  # Simulate work
                
                # Mark component as installed
                await self.app.mark_component_installed(component_id, True)
            
            await self.update_progress("Installation completed!", 1.0)
            
        except Exception as e:
            await self.update_progress(f"Installation failed: {e}", 0.0)
            raise
    
    async def update_progress(self, message: str, progress: float):
        """Update progress and message"""
        self.progress = progress
        await self.app.update_installation_progress(message, progress)


class ComponentSelector(Container):
    """Component selection interface"""
    
    def __init__(self):
        super().__init__()
        self.selected_components = set()
        self.installer = ComponentInstaller()
    
    def compose(self) -> ComposeResult:
        """Create the component selector UI"""
        yield Label("Select Components to Install", classes="title")
        yield Rule()
        
        # Group components by category
        categories = {
            "ai": "🤖 AI Components",
            "system": "⚙️ System Components", 
            "productivity": "📈 Productivity Components",
            "ui": "🎨 UI Components",
            "development": "🔧 Development Components"
        }
        
        for category, category_name in categories.items():
            yield Label(category_name, classes="category-title")
            
            category_components = [
                (k, v) for k, v in self.installer.components.items() 
                if v["category"] == category
            ]
            
            for component_id, component_info in category_components:
                checkbox = Checkbox(
                    component_info["name"],
                    id=f"checkbox_{component_id}",
                    value=True  # Default to selected
                )
                checkbox.watch(checkbox, "value", self.on_checkbox_change)
                yield checkbox
            
            yield Rule()
    
    def on_checkbox_change(self, value: bool) -> None:
        """Handle checkbox changes"""
        # Update selected components based on checkbox states
        pass


class InstallationProgress(Container):
    """Installation progress display"""
    
    progress = reactive(0.0)
    message = reactive("Ready to install")
    current_component = reactive("")
    
    def compose(self) -> ComposeResult:
        """Create the progress UI"""
        yield Label("Installation Progress", classes="title")
        yield Rule()
        
        yield Label("Status:", classes="label")
        yield Label(self.message, id="status-message", classes="status")
        
        yield Label("Progress:", classes="label")
        yield ProgressBar(id="progress-bar")
        
        yield Label("Current Component:", classes="label")
        yield Label(self.current_component, id="current-component", classes="component")
        
        yield Label("Installation Log:", classes="label")
        yield Log(id="install-log", classes="log")


class PortalOSInstallerApp(App):
    """Portal OS Interactive Installer Application"""
    
    CSS = """
    #main {
        layout: horizontal;
        height: 100%;
    }
    
    #left-panel {
        width: 40%;
        border-right: solid green;
    }
    
    #right-panel {
        width: 60%;
    }
    
    .title {
        text-align: center;
        color: $accent;
        text-style: bold;
        margin: 1;
    }
    
    .category-title {
        color: $primary;
        text-style: bold;
        margin: 1 0;
    }
    
    .label {
        color: $text-muted;
        margin: 1 0 0 0;
    }
    
    .status {
        color: $success;
        margin: 0 0 1 0;
    }
    
    .component {
        color: $warning;
        margin: 0 0 1 0;
    }
    
    .log {
        height: 20;
        border: solid $primary;
    }
    
    #install-button {
        margin: 1;
        width: 100%;
    }
    
    #progress-bar {
        margin: 0 0 1 0;
    }
    """
    
    def __init__(self):
        super().__init__()
        self.installer = ComponentInstaller()
        self.installation_worker: Optional[InstallationWorker] = None
        self.installed_components: Dict[str, bool] = {}
    
    def compose(self) -> ComposeResult:
        """Create the main application UI"""
        yield Header(show_clock=True)
        
        with Container(id="main"):
            with Container(id="left-panel"):
                yield ComponentSelector()
                yield Button("🚀 Start Installation", id="install-button", variant="primary")
            
            with Container(id="right-panel"):
                yield InstallationProgress()
        
        yield Footer()
    
    def on_mount(self) -> None:
        """Initialize the application"""
        self.title = "Portal OS Installer"
        self.sub_title = "Interactive Component Installation"
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        if event.button.id == "install-button":
            self.start_installation()
    
    def start_installation(self) -> None:
        """Start the installation process"""
        # Get selected components
        selected_components = [
            component_id for component_id in self.installer.components.keys()
        ]  # For now, install all components
        
        # Disable install button
        install_button = self.query_one("#install-button")
        install_button.disabled = True
        install_button.text = "Installing..."
        
        # Start installation worker
        self.installation_worker = self.run_worker(
            InstallationWorker(self, selected_components),
            group="installation"
        )
    
    async def update_installation_progress(self, message: str, progress: float) -> None:
        """Update installation progress display"""
        # Update status message
        status_label = self.query_one("#status-message")
        status_label.update(message)
        
        # Update progress bar
        progress_bar = self.query_one("#progress-bar")
        progress_bar.update(progress=progress)
        
        # Update log
        log = self.query_one("#install-log")
        timestamp = datetime.now().strftime("%H:%M:%S")
        log.write(f"[{timestamp}] {message}")
        
        # Update current component if available
        if hasattr(self.installation_worker, 'current_component'):
            component_label = self.query_one("#current-component")
            component_label.update(self.installation_worker.current_component)
    
    async def mark_component_installed(self, component_id: str, success: bool) -> None:
        """Mark a component as installed"""
        self.installed_components[component_id] = success
        
        # Update the log
        log = self.query_one("#install-log")
        status = "✅ INSTALLED" if success else "❌ FAILED"
        timestamp = datetime.now().strftime("%H:%M:%S")
        component_name = self.installer.components[component_id]["name"]
        log.write(f"[{timestamp}] {component_name} - {status}")
    
    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        """Handle worker state changes"""
        if event.worker.name == "installation":
            if event.state == WorkerState.SUCCESS:
                # Installation completed successfully
                install_button = self.query_one("#install-button")
                install_button.text = "✅ Installation Complete!"
                install_button.variant = "success"
                
                # Show completion message
                status_label = self.query_one("#status-message")
                status_label.update("🎉 Installation completed successfully!")
                
            elif event.state == WorkerState.ERROR:
                # Installation failed
                install_button = self.query_one("#install-button")
                install_button.text = "❌ Installation Failed"
                install_button.variant = "error"
                install_button.disabled = False
                
                status_label = self.query_one("#status-message")
                status_label.update("❌ Installation failed. Check the log for details.")


def main():
    """Main entry point for the installer app"""
    app = PortalOSInstallerApp()
    app.run()


if __name__ == "__main__":
    main()
