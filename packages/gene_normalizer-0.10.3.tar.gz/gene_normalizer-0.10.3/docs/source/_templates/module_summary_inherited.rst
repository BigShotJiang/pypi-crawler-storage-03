{{ fullname | underline }}

.. automodule:: {{ fullname }}
   :members:
   :undoc-members:
   :special-members: __init__
   :inherited-members:
