﻿gene.query
==========

.. automodule:: gene.query
   :members:
   :undoc-members:
   :special-members: __init__
   :exclude-members: model_fields, model_config
