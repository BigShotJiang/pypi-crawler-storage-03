﻿gene.etl.update
===============

.. automodule:: gene.etl.update
   :members:
   :undoc-members:
   :special-members: __init__
   :inherited-members:
