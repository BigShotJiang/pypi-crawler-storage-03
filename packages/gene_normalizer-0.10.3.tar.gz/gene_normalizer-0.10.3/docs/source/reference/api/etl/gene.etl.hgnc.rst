﻿gene.etl.hgnc
=============

.. automodule:: gene.etl.hgnc
   :members:
   :undoc-members:
   :special-members: __init__
   :inherited-members:
