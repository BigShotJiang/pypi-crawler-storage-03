﻿gene.schemas
============

.. automodule:: gene.schemas
   :members:
   :undoc-members:
   :special-members: __init__
   :exclude-members: model_fields, model_config
