﻿gene.database.postgresql
========================

.. automodule:: gene.database.postgresql
   :members:
   :undoc-members:
   :special-members: __init__
   :exclude-members: model_fields, model_config
