Changelog
---------

.. changelog::
    :changelog-url: https://gene-normalizer.readthedocs.io/latest/#changelog
    :github: https://github.com/cancervariants/gene-normalization/releases/
    :pypi: https://pypi.org/project/gene-normalizer/
