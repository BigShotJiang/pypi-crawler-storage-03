DROP INDEX IF EXISTS idx_g_concept_id_low;
DROP INDEX IF EXISTS idx_gm_concept_id_low; -- see also: delete_normalized_concepts.sql
DROP INDEX IF EXISTS idx_gs_symbol_low;
DROP INDEX IF EXISTS idx_gps_symbol_low;
DROP INDEX IF EXISTS idx_gx_xref_low;
DROP INDEX IF EXISTS idx_ga_alias_low;
DROP INDEX IF EXISTS idx_g_as_association_low;
DROP INDEX IF EXISTS idx_rlv_concept_id_low;
