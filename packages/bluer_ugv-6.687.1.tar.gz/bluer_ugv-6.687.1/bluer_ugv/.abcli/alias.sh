#! /usr/bin/env bash

alias @swallow=bluer_ugv_swallow

alias @ugv=bluer_ugv
