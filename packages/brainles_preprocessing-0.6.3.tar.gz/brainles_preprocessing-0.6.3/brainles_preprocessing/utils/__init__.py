from .generic import check_and_add_suffix
