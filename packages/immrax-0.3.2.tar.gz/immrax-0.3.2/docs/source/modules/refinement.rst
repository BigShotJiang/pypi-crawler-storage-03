immrax.refinement
=================

.. automodule:: immrax.refinement
   :members:
   :undoc-members:
   :show-inheritance:
 

