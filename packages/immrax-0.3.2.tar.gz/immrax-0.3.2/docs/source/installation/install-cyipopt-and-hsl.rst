Installing `cyipopt` and `coinhsl`
==================================

This is only necessary for running the pendulum example in :ref:`examples/pendulum/pendulum`