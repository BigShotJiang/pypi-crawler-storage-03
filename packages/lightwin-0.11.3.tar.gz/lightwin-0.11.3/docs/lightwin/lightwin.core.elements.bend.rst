bend module
==================================

.. automodule:: lightwin.core.elements.bend
   :members:
   :undoc-members:
   :show-inheritance:
