machine\_config\_specs module
=================================================================

.. automodule:: lightwin.beam_calculation.tracewin.machine_config_specs
   :members:
   :undoc-members:
   :show-inheritance:
