electromagnetic\_fields module
=======================================================

.. automodule:: lightwin.tracewin_utils.electromagnetic_fields
   :members:
   :undoc-members:
   :show-inheritance:
