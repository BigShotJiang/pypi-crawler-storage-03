simulated\_annealing module
============================================================

.. automodule:: lightwin.optimisation.algorithms.simulated_annealing
   :members:
   :undoc-members:
   :show-inheritance:
