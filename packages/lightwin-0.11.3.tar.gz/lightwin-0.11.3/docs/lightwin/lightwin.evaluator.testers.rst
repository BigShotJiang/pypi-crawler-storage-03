testers module
=================================

.. automodule:: lightwin.evaluator.testers
   :members:
   :undoc-members:
   :show-inheritance:
