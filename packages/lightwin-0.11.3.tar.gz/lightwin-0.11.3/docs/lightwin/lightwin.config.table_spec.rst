table\_spec module
==================================

.. automodule:: lightwin.config.table_spec
   :members:
   :undoc-members:
   :show-inheritance:
