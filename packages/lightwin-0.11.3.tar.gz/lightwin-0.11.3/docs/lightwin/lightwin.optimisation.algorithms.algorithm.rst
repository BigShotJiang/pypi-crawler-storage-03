algorithm module
=================================================

.. automodule:: lightwin.optimisation.algorithms.algorithm
   :members:
   :undoc-members:
   :show-inheritance:
