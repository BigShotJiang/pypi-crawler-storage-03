"""This subpacakge holds a class to store outputs of beam calculators."""
