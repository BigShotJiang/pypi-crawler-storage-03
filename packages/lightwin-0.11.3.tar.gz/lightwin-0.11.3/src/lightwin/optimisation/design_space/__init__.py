"""
This folder holds all the objects needed to parametrize the design space.

Used by the optimisation algorithms.

"""
