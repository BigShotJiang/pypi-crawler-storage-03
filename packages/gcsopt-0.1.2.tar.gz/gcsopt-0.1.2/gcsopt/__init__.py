__version__ = "0.1.2"
__author__ = "Tobia Marcucci"

from gcsopt.graphs import GraphOfConicSets, GraphOfConvexSets
