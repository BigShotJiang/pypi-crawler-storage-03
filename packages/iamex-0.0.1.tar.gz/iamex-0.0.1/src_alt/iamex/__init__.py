"""
iamex - Acceso unificado a múltiples modelos de inferencia AI
"""

__version__ = "0.0.1"
__author__ = "Inteligencia Artificial México"
__email__ = "hostmaster@iamex.io"

def welcome():
    """Función de bienvenida """
    print("Bienvenido a IAMEX")
    print("=" * 30)
    print("Este es un paquete placeholder de Bienvenida.")
    print("La versión completa con funcionalidad de modelos estará disponible pronto.")
    print("=" * 30)

# Función principal que se ejecuta al importar
welcome()

__all__ = ["welcome"]
