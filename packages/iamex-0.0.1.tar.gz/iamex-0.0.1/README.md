# iamex

Acceso unificado a múltiples modelos de inferencia AI

## Instalación

```bash
pip install iamex
```

## Uso Básico

```python
from iamex import PromptClient

# Inicializar el cliente (sin API key por ahora)
client = PromptClient()

# Enviar un prompt (usa modelo por defecto 'iam-120b')
response = client.send_prompt(
    prompt="Explica qué es la inteligencia artificial"
)

print(response)
```

## Uso con Modelo Específico

```python
# Especificar un modelo diferente
response = client.send_prompt(
    prompt="Explica qué es Python",
    modelo="iam-120b"
)
```

## Uso con Mensaje del Sistema

```python
# Incluir un mensaje del sistema para definir el comportamiento
system_prompt = "Eres un asistente experto en programación."
response = client.send_prompt(
    prompt="Explica qué es una función",
    modelo="iam-120b",
    system_prompt=system_prompt
)
```

## Parámetros Adicionales

El método `send_prompt` acepta parámetros adicionales:

```python
response = client.send_prompt(
    prompt="Tu prompt aquí",
    modelo="iam-120b",
    temperature=0.5,        # Controla la creatividad (0.0 - 1.0)
    max_tokens=1000,        # Máximo número de tokens en la respuesta
    top_p=0.9,             # Controla la diversidad de la respuesta
    top_k=50,              # Limita las opciones de tokens
    repetition_penalty=1.1, # Evita repeticiones
    presence_penalty=0.1,   # Penaliza tokens ya presentes
    frequency_penalty=0.1,  # Penaliza tokens frecuentes
    stream=False            # Respuesta en streaming
)
```

## Parámetros por Defecto

Si no especificas parámetros, se usan estos valores:
- `model`: `"iam-120b"`
- `temperature`: `0.3`
- `max_tokens`: `12000`
- `top_p`: `0.9`
- `top_k`: `50`
- `repetition_penalty`: `1.1`
- `presence_penalty`: `0.1`
- `frequency_penalty`: `0.1`
- `stream`: `False`

## Obtener Modelos Disponibles

```python
models = client.get_models()
print(models)
```

## Manejo de Errores

```python
try:
    response = client.send_prompt(
        prompt="Tu prompt aquí",
        modelo="iam-120b"
    )
except Exception as e:
    print(f"Error: {e}")
```

## Nota de Seguridad

**Por ahora, la librería funciona sin autenticación.** En futuras versiones se implementará:
- Autenticación por API key
- Sesiones seguras
- Validación de tokens

## Desarrollo

### Instalación para Desarrollo

```bash
git clone https://github.com/IA-Mexico/iamex.git
cd iamex
pip install -e ".[dev]"
```

### Ejecutar Tests

```bash
pytest
```

### Formatear Código

```bash
black src/ tests/
```

## Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo [LICENSE](LICENSE) para más detalles.

## Soporte

- **Documentación**: [GitHub](https://github.com/IA-Mexico/iamex)
- **Issues**: [GitHub Issues](https://github.com/IA-Mexico/iamex/issues)
- **Email**: hostmaster@iamex.io

## Changelog

### v0.0.1
- Versión inicial
- Cliente básico para envío de prompts
- Endpoint fijo para el modelo actual
- Soporte para múltiples modelos de inferencia
- **Sin autenticación por ahora** (para desarrollo y pruebas)
- **Modelo por defecto**: `iam-120b`
- **Parámetros optimizados** según la API
