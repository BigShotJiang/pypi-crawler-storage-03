class CircularReferenceError(Exception):
    pass
