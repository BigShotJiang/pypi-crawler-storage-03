from django.apps import AppConfig


class WagtailTransferAppConfig(AppConfig):
    name = 'wagtail_transfer'
    default_auto_field = 'django.db.models.AutoField'
