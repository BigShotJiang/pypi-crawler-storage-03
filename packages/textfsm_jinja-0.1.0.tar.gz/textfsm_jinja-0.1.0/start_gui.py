#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TextFSM-Jinja GUI 启动脚本
"""

from textfsm_jinja.gui import main

if __name__ == "__main__":
    main()