from csv_detective.parsing.text import header_score

PROPORTION = 0.5


def _is(header: str) -> float:
    words_combinations_list = [
        "code commune insee",
        "code insee",
        "codes insee",
        "code commune",
        "code insee commune",
        "insee",
        "code com",
        "com",
    ]
    return header_score(header, words_combinations_list)
