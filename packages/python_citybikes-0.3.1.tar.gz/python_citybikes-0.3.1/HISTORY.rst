History
=======
0.3.0 (2025-08-19)
------------------
* Add asyncio client
* Nuke python 2 support

0.2.0 (2021-02-07)
------------------
* Accept headers on client init
* Remove user-agent argument (superseded by headers)

0.1.4 (2019-07-26)
------------------
* Fix python 2 compatibility

0.1.3 (2017-02-13)
------------------
* Add JSON Encoder for resources

0.1.1 (2016-11-22)
------------------
* Improve docs
* near helpers also return relative distance

0.1.0 (2016-11-17)
------------------
* First release
* Can navigate the Citybikes API
* Requests for resources are done only once
