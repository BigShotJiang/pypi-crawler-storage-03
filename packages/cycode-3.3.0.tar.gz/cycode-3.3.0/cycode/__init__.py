__version__ = '3.3.0'  # DON'T TOUCH. Placeholder. Will be filled automatically on poetry build from Git Tag
