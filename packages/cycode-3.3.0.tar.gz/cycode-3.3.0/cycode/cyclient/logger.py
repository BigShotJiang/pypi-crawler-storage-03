from cycode.logger import get_logger

logger = get_logger('CyClient')
