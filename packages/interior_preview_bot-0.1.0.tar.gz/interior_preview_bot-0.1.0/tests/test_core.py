import unittest

class TestInteriorPreviewBot(unittest.TestCase):

    def test_placeholder(self):
        """A placeholder test that always passes."""
        self.assertEqual(1, 1)

if __name__ == '__main__':
    unittest.main()
