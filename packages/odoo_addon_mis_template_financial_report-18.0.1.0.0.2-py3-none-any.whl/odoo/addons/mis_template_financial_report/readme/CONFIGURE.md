To render the reports from this module horizontally in two columns on
the same page, check the Horizontal checkbox on the Layout tab of the
report. This checkbox is only available for reports that support the
horizontal mode.
