- support horizontal mode for xslx export
- split off all code to mis_builder_horizontal and only keep the KPI
  definitions here
