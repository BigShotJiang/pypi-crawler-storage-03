# mcp-django-crud

This package is currently under development.

For now, please use [mcp-django-shell](https://pypi.org/project/mcp-django-shell/) instead:

```bash
pip install mcp-django-shell
```

Full release coming soon!
