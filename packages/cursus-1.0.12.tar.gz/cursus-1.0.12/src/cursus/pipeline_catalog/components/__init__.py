"""
Pipeline components that can be used across different frameworks.
"""
