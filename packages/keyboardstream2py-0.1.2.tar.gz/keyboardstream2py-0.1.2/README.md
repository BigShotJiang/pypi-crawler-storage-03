
# keyboardstream2py
stream2py interface for keyboard inputs


To install:	```pip install keyboardstream2py```
