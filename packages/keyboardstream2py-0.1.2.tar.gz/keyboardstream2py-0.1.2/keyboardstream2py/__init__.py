"""Keyboard input stream2py interface"""

from keyboardstream2py.keyboard_input import KeyboardInputSourceReader
