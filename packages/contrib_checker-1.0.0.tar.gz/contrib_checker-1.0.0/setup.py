"""Setup script for contrib-checker package."""

from setuptools import setup

# Use pyproject.toml for configuration
setup()
