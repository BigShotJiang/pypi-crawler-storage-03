# Utilities

::: pyngb.util.get_hash

::: pyngb.util.set_metadata
