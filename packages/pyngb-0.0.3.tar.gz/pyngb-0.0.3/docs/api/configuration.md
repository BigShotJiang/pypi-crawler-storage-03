# Configuration

::: pyngb.PatternConfig
    options:
      show_source: true

::: pyngb.BinaryMarkers
    options:
      show_source: true
