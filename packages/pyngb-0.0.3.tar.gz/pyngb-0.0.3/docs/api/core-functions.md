# Core Functions

API for core operations.

::: pyngb.read_ngb
    options:
      heading_level: 2
      show_source: true

::: pyngb.NGBParser
    options:
      heading_level: 2
      show_source: true
