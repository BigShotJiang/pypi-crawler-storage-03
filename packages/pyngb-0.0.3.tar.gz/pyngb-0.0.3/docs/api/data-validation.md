# Data Validation

::: pyngb.validate_sta_data

::: pyngb.QualityChecker
    options:
      show_source: true

::: pyngb.ValidationResult
