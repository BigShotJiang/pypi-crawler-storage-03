# Performance Testing

Guidance on benchmarking and memory profiling.

- Use pytest-benchmark for microbenchmarks
- Track memory with memory_profiler or psutil
