# Architecture Details

High-level overview of pyngb internals.

- Core parser (NGBParser)
- Binary handlers
- Extractors
- API loaders and CLI
