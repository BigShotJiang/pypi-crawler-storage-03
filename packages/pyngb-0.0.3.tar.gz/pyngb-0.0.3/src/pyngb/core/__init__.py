"""
Main parser classes for NGB files.
"""

from .parser import NGBParser

__all__ = ["NGBParser"]
