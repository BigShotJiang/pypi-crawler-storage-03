"""Initialization of const package."""

from .locators import Locators  # noqa
