from typing import AsyncGenerator, Callable, Any, Coroutine, Dict, List, Optional, TypeVar, Type, cast, Generic
from dataclasses import dataclass, field
from hero_base.state import State


@dataclass
class ToolCall:
    tool: str
    params: Dict[str, Any]

type ToolResult = ToolSuccess | ToolFailed | ToolError | ToolEnd
@dataclass
class ToolSuccess:
    content: str
    additional_context: str = ""
    additional_images: list[str] = field(default_factory=list)
    next: Optional[str] = None
    def __post_init__(self):
        self.status = "success"

@dataclass
class ToolFailed:
    content: str
    next: Optional[str] = None
    def __post_init__(self):
        self.status = "failed"

@dataclass
class ToolEnd:
    content: str
    additional_outputs: Optional[List[str]] = None
    def __post_init__(self):
        self.status = "end"

@dataclass
class ToolError:
    content: str
    next: Optional[str] = None
    def __post_init__(self):
        self.status = "error"


T = TypeVar('T')
class CommonToolWrapper(Generic[T]):
    def __init__(self, name: str, prefix: str, memory_hint: str, tool_tips: list[str], options: T | None, doc: str, func: Callable[..., ToolResult | Coroutine[Any, Any, ToolResult] | AsyncGenerator[Any, ToolResult]], options_type: Optional[Type[T]] = None):
        if prefix:
            self.name = prefix + "_" + name
        else:
            self.name = name
        self.memory_hint = memory_hint
        self.tool_tips = tool_tips
        self.options: T | None = options
        self.doc = doc
        self.func = func
        self.options_type = options_type

    def get_name(self) -> str:
        return self.name
    
    def get_memory_hint(self) -> str:
        return self.memory_hint

    def get_tool_tips(self) -> list[str]:
        return self.tool_tips
    
    def get_prompt(self) -> str:
        prompt = f"""
<tool name="{self.name}">
{self.doc}
</tool>
"""
        return prompt
    
    def custom(self, options: Optional[T] = None) -> "CommonToolWrapper[T]":

        if options is None:
            return self
        
        if isinstance(options, dict):
            result: Dict[str, Any] = options.copy()
        else:
            # 如果不是字典，使用cast进行类型转换
            result: Dict[str, Any] = cast(Dict[str, Any], options)
        
        if self.options is not None:
            if isinstance(self.options, dict):
                self.options.update(result)
            else:
                self.options = cast(T, result)
        return self

    def invoke(self, params: Dict[str, Any], state: Optional[State]) -> ToolResult | Coroutine[Any, Any, ToolResult] | AsyncGenerator[Any, ToolResult]:
        """
            invoke the tool
        """
        params = params.copy()
        call_params = {}
        # filter return type
        func_params = {k: v for k, v in self.func.__annotations__.items() if k != "return"}
        for param in func_params:
            if param in params:
                call_params[param] = params[param]
            else:
                call_params[param] = None
        if "options" in func_params:
            call_params["options"] = self.options
        if "state" in func_params:
            call_params["state"] = state
        return self.func(**call_params) 

class Tool:
    def __init__(self, prefix: str = ""):
        self.prefix = prefix

    def __call__(self, name: str, memory_hint: str = "", tool_tips: list[str] = [], options: T | None = None, options_type: Optional[Type[T]] = None):
        """
        工具装饰器
        
        Args:
            name: tool name
            memory_hint: the memory hint for the tool
            options: the options for the tool
            options_type: the type of the options
        """
        def decorator(func: Callable[..., (ToolSuccess | ToolFailed | ToolError | ToolEnd) | Coroutine[Any, Any, (ToolSuccess | ToolFailed | ToolError | ToolEnd)] | AsyncGenerator[Any, (ToolSuccess | ToolFailed | ToolError | ToolEnd)]]) -> CommonToolWrapper[T]:
            return CommonToolWrapper[T](name, self.prefix, memory_hint, tool_tips, options, func.__doc__ or "", func, options_type)

        return decorator