import asyncio
from google import genai
from google.genai.types import HttpOptions

# Only run this block for Gemini Developer API
client = genai.Client(
    api_key="sk-IORgE0ls6xqROAV0F9Af149b0aF1473e9e91C1437483F847",
    http_options=HttpOptions(
        base_url="https://api.laozhang.ai/v1",
    )
)

model = "gemini-2.5-pro"

async def test_gemini():
    for chunk in client.models.generate_content_stream(
        model='gemini-2.0-flash-001', contents='Tell me a story in 300 words.'
    ):
        print(chunk.text, end='')


if __name__ == "__main__":
    asyncio.run(test_gemini())