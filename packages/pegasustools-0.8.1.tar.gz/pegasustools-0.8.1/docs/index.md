# PegasusTools

```{toctree}
:maxdepth: 2
:hidden:
:caption: Documentation

reading_pegasus_files.ipynb
plotting.ipynb
api/pegasustools
```

```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
