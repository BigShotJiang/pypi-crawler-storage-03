import os
from Crypto.PublicKey import RSA, ECC, ElGamal
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Random import get_random_bytes
from .core import CryptoCore

class AsymmetricCrypto(CryptoCore):
    def __init__(self):
        super().__init__()
    
    def generate_rsa_keypair(self, key_size=2048):
        key = RSA.generate(key_size)
        return key, key.publickey()
    
    def rsa_encrypt(self, data, public_key):
        if isinstance(public_key, bytes):
            public_key = RSA.import_key(public_key)
        
        cipher = PKCS1_OAEP.new(public_key)
        max_chunk_size = (public_key.size_in_bytes()) - 42
        encrypted_chunks = []
        
        for i in range(0, len(data), max_chunk_size):
            chunk = data[i:i + max_chunk_size]
            encrypted_chunk = cipher.encrypt(chunk)
            encrypted_chunks.append(encrypted_chunk)
        
        return b''.join(encrypted_chunks)
    
    def rsa_decrypt(self, encrypted_data, private_key):
        if isinstance(private_key, bytes):
            private_key = RSA.import_key(private_key)
        
        cipher = PKCS1_OAEP.new(private_key)
        chunk_size = private_key.size_in_bytes()
        decrypted_chunks = []
        
        for i in range(0, len(encrypted_data), chunk_size):
            chunk = encrypted_data[i:i + chunk_size]
            decrypted_chunk = cipher.decrypt(chunk)
            decrypted_chunks.append(decrypted_chunk)
        
        return b''.join(decrypted_chunks)
    
    def generate_ecc_keypair(self, curve='P-256'):
        key = ECC.generate(curve=curve)
        return key, key.public_key()
    
    def ecc_encrypt(self, data, public_key):
        if isinstance(public_key, bytes):
            public_key = ECC.import_key(public_key)
        
        ephemeral_key = ECC.generate(curve='P-256')
        shared_point = public_key.pointQ * ephemeral_key.d
        shared_key = str(shared_point.x) + str(shared_point.y)
        derived_key = self.derive_key(shared_key, b'', 32)
        
        from .symmetric import SymmetricCrypto
        symmetric = SymmetricCrypto()
        encrypted_data = symmetric.aes_encrypt(data, derived_key)
        
        ephemeral_public = ephemeral_key.public_key().export_key(format='PEM')
        
        return ephemeral_public + encrypted_data
    
    def ecc_decrypt(self, encrypted_data, private_key):
        if isinstance(private_key, bytes):
            private_key = ECC.import_key(private_key)
        
        ephemeral_public_pem = encrypted_data[:178]
        encrypted_payload = encrypted_data[178:]
        
        ephemeral_public = ECC.import_key(ephemeral_public_pem)
        shared_point = ephemeral_public.pointQ * private_key.d
        shared_key = str(shared_point.x) + str(shared_point.y)
        derived_key = self.derive_key(shared_key, b'', 32)
        
        from .symmetric import SymmetricCrypto
        symmetric = SymmetricCrypto()
        return symmetric.aes_decrypt(encrypted_payload, derived_key)
    
    def generate_elgamal_keypair(self, key_size=2048):
        key = ElGamal.generate(key_size, get_random_bytes)
        return key, key.publickey()
    
    def elgamal_encrypt(self, data, public_key):
        encrypted_chunks = []
        chunk_size = (public_key.p.bit_length() // 8) - 1
        
        for i in range(0, len(data), chunk_size):
            chunk = data[i:i + chunk_size]
            padded_chunk = chunk + b'\x00' * (chunk_size - len(chunk))
            
            k = get_random_bytes(32)
            k_int = int.from_bytes(k, 'big') % (public_key.p - 1)
            if k_int == 0:
                k_int = 1
            
            c1 = pow(public_key.g, k_int, public_key.p)
            c2 = (int.from_bytes(padded_chunk, 'big') * pow(public_key.y, k_int, public_key.p)) % public_key.p
            
            encrypted_chunks.append(self.int_to_bytes(c1, chunk_size) + self.int_to_bytes(c2, chunk_size))
        
        return b''.join(encrypted_chunks)
    
    def elgamal_decrypt(self, encrypted_data, private_key):
        decrypted_chunks = []
        chunk_size = (private_key.p.bit_length() // 8) - 1
        encrypted_chunk_size = chunk_size * 2
        
        for i in range(0, len(encrypted_data), encrypted_chunk_size):
            chunk = encrypted_data[i:i + encrypted_chunk_size]
            c1_bytes = chunk[:chunk_size]
            c2_bytes = chunk[chunk_size:]
            
            c1 = int.from_bytes(c1_bytes, 'big')
            c2 = int.from_bytes(c2_bytes, 'big')
            
            s = pow(c1, private_key.x, private_key.p)
            s_inv = pow(s, private_key.p - 2, private_key.p)
            m = (c2 * s_inv) % private_key.p
            
            decrypted_chunk = self.int_to_bytes(m, chunk_size).rstrip(b'\x00')
            decrypted_chunks.append(decrypted_chunk)
        
        return b''.join(decrypted_chunks)
