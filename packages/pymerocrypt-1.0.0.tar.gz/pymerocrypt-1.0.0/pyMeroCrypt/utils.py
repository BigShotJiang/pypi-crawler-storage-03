import os
import marshal
import struct
from .core import CryptoCore

class CryptoUtils(CryptoCore):
    def __init__(self):
        super().__init__()
    
    def generate_key(self, algorithm):
        key_sizes = {
            'AES': 32,
            'DES': 8,
            '3DES': 24,
            'ChaCha20': 32,
            'Poly1305': 32
        }
        
        if algorithm in key_sizes:
            return os.urandom(key_sizes[algorithm])
        elif algorithm == 'RSA':
            from .asymmetric import AsymmetricCrypto
            asymmetric = AsymmetricCrypto()
            private_key, public_key = asymmetric.generate_rsa_keypair()
            return private_key
        elif algorithm == 'ECC':
            from .asymmetric import AsymmetricCrypto
            asymmetric = AsymmetricCrypto()
            private_key, public_key = asymmetric.generate_ecc_keypair()
            return private_key
        elif algorithm == 'ElGamal':
            from .asymmetric import AsymmetricCrypto
            asymmetric = AsymmetricCrypto()
            private_key, public_key = asymmetric.generate_elgamal_keypair()
            return private_key
        else:
            raise ValueError(f"Unknown algorithm: {algorithm}")
    
    def xor_encrypt(self, data, key):
        if isinstance(data, str):
            data = data.encode('utf-8')
        if isinstance(key, str):
            key = key.encode('utf-8')
        
        result = bytearray()
        key_len = len(key)
        
        for i, byte in enumerate(data):
            result.append(byte ^ key[i % key_len])
        
        return bytes(result)
    
    def xor_decrypt(self, encrypted_data, key):
        return self.xor_encrypt(encrypted_data, key)
    
    def marshal_encrypt(self, obj):
        try:
            marshaled_data = marshal.dumps(obj)
            key = self.generate_key('AES')
            
            from .symmetric import SymmetricCrypto
            symmetric = SymmetricCrypto()
            encrypted_data = symmetric.aes_encrypt(marshaled_data, key)
            
            return encrypted_data, key
        except Exception as e:
            raise RuntimeError(f"Marshal encryption failed: {str(e)}")
    
    def marshal_decrypt(self, encrypted_data, key):
        try:
            from .symmetric import SymmetricCrypto
            symmetric = SymmetricCrypto()
            marshaled_data = symmetric.aes_decrypt(encrypted_data, key)
            
            return marshal.loads(marshaled_data)
        except Exception as e:
            raise RuntimeError(f"Marshal decryption failed: {str(e)}")
    
    def exec_bytes(self, byte_data):
        try:
            if isinstance(byte_data, str):
                byte_data = byte_data.encode('utf-8')
            
            code_obj = marshal.loads(byte_data)
            return exec(code_obj)
        except Exception as e:
            try:
                return exec(byte_data)
            except Exception as e2:
                raise RuntimeError(f"Exec bytes failed: {str(e2)}")
    
    def compile_and_marshal(self, source_code, filename="<string>"):
        try:
            compiled_code = compile(source_code, filename, 'exec')
            return marshal.dumps(compiled_code)
        except Exception as e:
            raise RuntimeError(f"Compile and marshal failed: {str(e)}")
    
    def process_large_file(self, file_path, chunk_size=1024*1024):
        chunks = []
        try:
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    chunks.append(chunk)
            return chunks
        except Exception as e:
            raise RuntimeError(f"Failed to process large file: {str(e)}")
    
    def secure_delete(self, file_path):
        try:
            if os.path.exists(file_path):
                file_size = os.path.getsize(file_path)
                with open(file_path, "r+b") as f:
                    for _ in range(3):
                        f.seek(0)
                        f.write(os.urandom(file_size))
                        f.flush()
                        os.fsync(f.fileno())
                os.remove(file_path)
                return True
        except:
            return False
    
    def bytes_to_hex(self, data):
        return data.hex()
    
    def hex_to_bytes(self, hex_string):
        return bytes.fromhex(hex_string)
    
    def encode_base64(self, data):
        import base64
        return base64.b64encode(data)
    
    def decode_base64(self, encoded_data):
        import base64
        return base64.b64decode(encoded_data)
