import marshal
import types
from .core import CryptoCore

class ExecHandler(CryptoCore):
    def __init__(self):
        super().__init__()
    
    def exec_code_from_bytes(self, byte_data):
        try:
            if isinstance(byte_data, str):
                byte_data = byte_data.encode('utf-8')
            code_obj = marshal.loads(byte_data)
            namespace = {}
            exec(code_obj, namespace)
            return namespace
        except:
            try:
                namespace = {}
                exec(byte_data, namespace)
                return namespace
            except Exception as e:
                raise RuntimeError(f"Exec failed: {str(e)}")
    
    def compile_to_bytes(self, source_code, filename="<string>"):
        try:
            compiled_code = compile(source_code, filename, 'exec')
            return marshal.dumps(compiled_code)
        except Exception as e:
            raise RuntimeError(f"Compile failed: {str(e)}")
    
    def exec_encrypted_code(self, encrypted_bytes, key):
        try:
            from .symmetric import SymmetricCrypto
            symmetric = SymmetricCrypto()
            decrypted_bytes = symmetric.aes_decrypt(encrypted_bytes, key)
            return self.exec_code_from_bytes(decrypted_bytes)
        except Exception as e:
            raise RuntimeError(f"Encrypted exec failed: {str(e)}")
    
    def encrypt_and_store_code(self, source_code):
        try:
            compiled_bytes = self.compile_to_bytes(source_code)
            from .symmetric import SymmetricCrypto
            from .utils import CryptoUtils
            symmetric = SymmetricCrypto()
            utils = CryptoUtils()
            key = utils.generate_key('AES')
            encrypted_bytes = symmetric.aes_encrypt(compiled_bytes, key)
            return encrypted_bytes, key
        except Exception as e:
            raise RuntimeError(f"Encrypt code failed: {str(e)}")