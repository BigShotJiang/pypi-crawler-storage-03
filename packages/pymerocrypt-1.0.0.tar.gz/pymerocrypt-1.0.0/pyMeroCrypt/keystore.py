import os
import marshal
import hashlib
from .core import CryptoCore

class KeyStore(CryptoCore):
    def __init__(self):
        super().__init__()
        self.keystore_path = self._get_keystore_path()
        self._ensure_keystore_exists()
    
    def _get_keystore_path(self):
        if self.is_android:
            base_path = "/data/data/ru.iiec.pydroid3/files"
            if not os.path.exists(base_path):
                base_path = os.path.expanduser("~")
        else:
            base_path = os.path.expanduser("~")
        
        keystore_dir = os.path.join(base_path, ".pymerocrypt")
        if not os.path.exists(keystore_dir):
            os.makedirs(keystore_dir, mode=0o700)
        
        return os.path.join(keystore_dir, "keystore.dat")
    
    def _ensure_keystore_exists(self):
        if not os.path.exists(self.keystore_path):
            self._save_keystore({})
    
    def _load_keystore(self):
        try:
            with open(self.keystore_path, 'rb') as f:
                encrypted_data = f.read()
            
            device_key = self._get_device_key()
            decrypted_data = self._decrypt_keystore(encrypted_data, device_key)
            return marshal.loads(decrypted_data)
        except:
            return {}
    
    def _save_keystore(self, keystore_data):
        try:
            serialized_data = marshal.dumps(keystore_data)
            device_key = self._get_device_key()
            encrypted_data = self._encrypt_keystore(serialized_data, device_key)
            
            with open(self.keystore_path, 'wb') as f:
                f.write(encrypted_data)
        except Exception as e:
            raise RuntimeError(f"Failed to save keystore: {str(e)}")
    
    def _get_device_key(self):
        device_string = f"{self.device_id}_pymerocrypt_master_key"
        return hashlib.sha256(device_string.encode()).digest()
    
    def _encrypt_keystore(self, data, key):
        from .symmetric import SymmetricCrypto
        symmetric = SymmetricCrypto()
        return symmetric.aes_encrypt(data, key)
    
    def _decrypt_keystore(self, encrypted_data, key):
        from .symmetric import SymmetricCrypto
        symmetric = SymmetricCrypto()
        return symmetric.aes_decrypt(encrypted_data, key)
    
    def store_key(self, key, algorithm, key_name=None):
        if key_name is None:
            key_name = f"{algorithm}_{hashlib.sha256(key).hexdigest()[:8]}"
        
        keystore = self._load_keystore()
        keystore[key_name] = {
            'key': key,
            'algorithm': algorithm,
            'created': str(__import__('time').time())
        }
        self._save_keystore(keystore)
        return key_name
    
    def get_key(self, key_name):
        keystore = self._load_keystore()
        if key_name not in keystore:
            raise KeyError(f"Key '{key_name}' not found in keystore")
        return keystore[key_name]['key']
    
    def delete_key(self, key_name):
        keystore = self._load_keystore()
        if key_name in keystore:
            del keystore[key_name]
            self._save_keystore(keystore)
            return True
        return False
    
    def list_keys(self):
        keystore = self._load_keystore()
        return list(keystore.keys())
    
    def key_exists(self, key_name):
        keystore = self._load_keystore()
        return key_name in keystore
    
    def clear_keystore(self):
        self._save_keystore({})
