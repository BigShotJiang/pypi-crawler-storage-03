from .core import *
from .symmetric import *
from .asymmetric import *
from .hashing import *
from .keystore import *
from .utils import *
from .exec_handler import *

__version__ = "1.0.0"
__author__ = "mero, QP4RM"

class PyMeroCrypt:
    def __init__(self):
        self.core = CryptoCore()
        self.keystore = KeyStore()
        self.symmetric = SymmetricCrypto()
        self.asymmetric = AsymmetricCrypto()
        self.hasher = HashingUtils()
        self.utils = CryptoUtils()
        self.exec_handler = ExecHandler()
    
    def encrypt_file(self, file_path, key_name=None, algorithm="AES"):
        encrypted = None
        if key_name is None:
            key = self.utils.generate_key(algorithm)
            key_name = self.keystore.store_key(key, algorithm)
        else:
            key = self.keystore.get_key(key_name)
        
        with open(file_path, 'rb') as f:
            data = f.read()
        
        if algorithm == "AES":
            encrypted = self.symmetric.aes_encrypt(data, key)
        elif algorithm == "DES":
            encrypted = self.symmetric.des_encrypt(data, key)
        elif algorithm == "3DES":
            encrypted = self.symmetric.des3_encrypt(data, key)
        elif algorithm == "RSA":
            encrypted = self.asymmetric.rsa_encrypt(data, key)
        elif algorithm == "ECC":
            encrypted = self.asymmetric.ecc_encrypt(data, key)
        elif algorithm == "ElGamal":
            encrypted = self.asymmetric.elgamal_encrypt(data, key)
        
        return encrypted, key_name
    
    def decrypt_file(self, encrypted_data, key_name, algorithm="AES"):
        key = self.keystore.get_key(key_name)
        
        if algorithm == "AES":
            return self.symmetric.aes_decrypt(encrypted_data, key)
        elif algorithm == "DES":
            return self.symmetric.des_decrypt(encrypted_data, key)
        elif algorithm == "3DES":
            return self.symmetric.des3_decrypt(encrypted_data, key)
        elif algorithm == "RSA":
            return self.asymmetric.rsa_decrypt(encrypted_data, key)
        elif algorithm == "ECC":
            return self.asymmetric.ecc_decrypt(encrypted_data, key)
        elif algorithm == "ElGamal":
            return self.asymmetric.elgamal_decrypt(encrypted_data, key)
    
    def hash_data(self, data, algorithm="SHA256"):
        return self.hasher.hash_data(data, algorithm)
    
    def hmac_sign(self, data, key, algorithm="SHA256"):
        return self.hasher.hmac_sign(data, key, algorithm)
    
    def xor_encrypt(self, data, key):
        return self.utils.xor_encrypt(data, key)
    
    def marshal_encrypt(self, obj):
        return self.utils.marshal_encrypt(obj)
    
    def marshal_decrypt(self, data, key):
        return self.utils.marshal_decrypt(data, key)
    
    def exec_bytes(self, byte_data):
        return self.exec_handler.exec_code_from_bytes(byte_data)
    
    def compile_code(self, source_code):
        return self.exec_handler.compile_to_bytes(source_code)
    
    def exec_encrypted_code(self, encrypted_bytes, key):
        return self.exec_handler.exec_encrypted_code(encrypted_bytes, key)
    
    def encrypt_code(self, source_code):
        return self.exec_handler.encrypt_and_store_code(source_code)

crypto = PyMeroCrypt()
