import hashlib
import hmac
from Crypto.Hash import Poly1305
from .core import CryptoCore

class HashingUtils(CryptoCore):
    def __init__(self):
        super().__init__()
    
    def sha1(self, data):
        return hashlib.sha1(data).digest()
    
    def sha224(self, data):
        return hashlib.sha224(data).digest()
    
    def sha256(self, data):
        return hashlib.sha256(data).digest()
    
    def sha384(self, data):
        return hashlib.sha384(data).digest()
    
    def sha512(self, data):
        return hashlib.sha512(data).digest()
    
    def md5(self, data):
        return hashlib.md5(data).digest()
    
    def hash_data(self, data, algorithm="SHA256"):
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        algorithm = algorithm.upper()
        if algorithm == "SHA1":
            return self.sha1(data)
        elif algorithm == "SHA224":
            return self.sha224(data)
        elif algorithm == "SHA256":
            return self.sha256(data)
        elif algorithm == "SHA384":
            return self.sha384(data)
        elif algorithm == "SHA512":
            return self.sha512(data)
        elif algorithm == "MD5":
            return self.md5(data)
        else:
            raise ValueError(f"Unsupported hash algorithm: {algorithm}")
    
    def hmac_sign(self, data, key, algorithm="SHA256"):
        if isinstance(data, str):
            data = data.encode('utf-8')
        if isinstance(key, str):
            key = key.encode('utf-8')
        
        algorithm = algorithm.upper()
        if algorithm == "SHA1":
            return hmac.new(key, data, hashlib.sha1).digest()
        elif algorithm == "SHA224":
            return hmac.new(key, data, hashlib.sha224).digest()
        elif algorithm == "SHA256":
            return hmac.new(key, data, hashlib.sha256).digest()
        elif algorithm == "SHA384":
            return hmac.new(key, data, hashlib.sha384).digest()
        elif algorithm == "SHA512":
            return hmac.new(key, data, hashlib.sha512).digest()
        elif algorithm == "MD5":
            return hmac.new(key, data, hashlib.md5).digest()
        else:
            raise ValueError(f"Unsupported HMAC algorithm: {algorithm}")
    
    def hmac_verify(self, data, key, signature, algorithm="SHA256"):
        expected = self.hmac_sign(data, key, algorithm)
        return hmac.compare_digest(expected, signature)
    
    def poly1305_mac(self, data, key):
        if len(key) != 32:
            raise ValueError("Poly1305 key must be 32 bytes")
        
        from Crypto.Cipher import AES
        h = Poly1305.new(key=key, cipher=AES)
        h.update(data)
        return h.digest()
    
    def poly1305_verify(self, data, key, tag):
        expected = self.poly1305_mac(data, key)
        return hmac.compare_digest(expected, tag)
