import os
import platform
import struct
import marshal
import hashlib
import hmac
from Crypto.Protocol.KDF import PBKDF2

class CryptoCore:
    def __init__(self):
        self.is_android = self._detect_android()
        self.device_id = self._get_device_id()
    
    def _detect_android(self):
        try:
            return "android" in platform.platform().lower() or os.path.exists("/system/build.prop")
        except:
            return False
    
    def _get_device_id(self):
        try:
            if self.is_android:
                with open("/proc/version", "r") as f:
                    version = f.read()
                return hashlib.sha256(version.encode()).hexdigest()[:16]
            else:
                import uuid
                return str(uuid.getnode())[:16]
        except:
            return "default_device_id"
    
    def derive_key(self, password, salt, length=32):
        return PBKDF2(
            password.encode(),
            salt,
            length,
            count=100000
        )
    
    def generate_salt(self, length=16):
        return os.urandom(length)
    
    def pad_data(self, data, block_size):
        padding_length = block_size - (len(data) % block_size)
        padding = bytes([padding_length] * padding_length)
        return data + padding
    
    def unpad_data(self, padded_data):
        padding_length = padded_data[-1]
        return padded_data[:-padding_length]
    
    def bytes_to_int(self, byte_data):
        return int.from_bytes(byte_data, byteorder='big')
    
    def int_to_bytes(self, integer, length):
        return integer.to_bytes(length, byteorder='big')
