import os
from Crypto.Cipher import AES, DES, DES3, ChaCha20_Poly1305
from .core import CryptoCore

class SymmetricCrypto(CryptoCore):
    def __init__(self):
        super().__init__()
    
    def aes_encrypt(self, data, key):
        cipher = AES.new(key, AES.MODE_CBC)
        padded_data = self.pad_data(data, 16)
        return cipher.iv + cipher.encrypt(padded_data)
    
    def aes_decrypt(self, encrypted_data, key):
        iv = encrypted_data[:16]
        ciphertext = encrypted_data[16:]
        cipher = AES.new(key, AES.MODE_CBC, iv)
        padded_plaintext = cipher.decrypt(ciphertext)
        return self.unpad_data(padded_plaintext)
    
    def des_encrypt(self, data, key):
        key = key[:8]
        cipher = DES.new(key, DES.MODE_CBC)
        padded_data = self.pad_data(data, 8)
        return cipher.iv + cipher.encrypt(padded_data)
    
    def des_decrypt(self, encrypted_data, key):
        key = key[:8]
        iv = encrypted_data[:8]
        ciphertext = encrypted_data[8:]
        cipher = DES.new(key, DES.MODE_CBC, iv)
        padded_plaintext = cipher.decrypt(ciphertext)
        return self.unpad_data(padded_plaintext)
    
    def des3_encrypt(self, data, key):
        key = key[:24]
        cipher = DES3.new(key, DES3.MODE_CBC)
        padded_data = self.pad_data(data, 8)
        return cipher.iv + cipher.encrypt(padded_data)
    
    def des3_decrypt(self, encrypted_data, key):
        key = key[:24]
        iv = encrypted_data[:8]
        ciphertext = encrypted_data[8:]
        cipher = DES3.new(key, DES3.MODE_CBC, iv)
        padded_plaintext = cipher.decrypt(ciphertext)
        return self.unpad_data(padded_plaintext)
    
    def chacha20_encrypt(self, data, key):
        nonce = os.urandom(12)
        cipher = ChaCha20_Poly1305.new(key=key, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        return nonce + tag + ciphertext
    
    def chacha20_decrypt(self, encrypted_data, key):
        nonce = encrypted_data[:12]
        tag = encrypted_data[12:28]
        ciphertext = encrypted_data[28:]
        cipher = ChaCha20_Poly1305.new(key=key, nonce=nonce)
        return cipher.decrypt_and_verify(ciphertext, tag)
