taken and adapted from https://github.com/celedev97/python-edgedriver-autoinstaller
