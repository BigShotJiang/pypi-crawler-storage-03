# xx_ent_wiki_sm

POC package for harmless beacon-only testing.
