from notte_core import check_notte_version

__version__ = check_notte_version("notte_browser")
