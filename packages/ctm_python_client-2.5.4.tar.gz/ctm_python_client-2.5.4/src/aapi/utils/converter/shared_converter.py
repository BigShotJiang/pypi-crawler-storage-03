from cattrs import Converter

# Shared instance of the cattrs converter
# Used across the application for structuring and unstructuring data
converter = Converter()