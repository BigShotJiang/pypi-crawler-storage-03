"""
Panoramax client cli tool
"""

__version__ = "1.1.8"

USER_AGENT = f"PanoramaxCLI/{__version__}"
