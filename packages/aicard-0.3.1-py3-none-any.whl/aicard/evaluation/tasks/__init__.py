from aicard.evaluation.tasks import multimodal
from aicard.evaluation.tasks import vision
from aicard.evaluation.tasks import nlp
