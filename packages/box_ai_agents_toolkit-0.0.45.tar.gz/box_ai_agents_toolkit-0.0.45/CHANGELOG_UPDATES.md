## 0.0.45 - 2025-08-18

* enable metadata template list (6d88ad6)
* Update version to 0.0.44 and changelog (278042e)