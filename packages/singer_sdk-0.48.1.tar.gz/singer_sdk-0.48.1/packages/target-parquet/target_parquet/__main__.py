"""Entry point for the target."""

from __future__ import annotations

from target_parquet.target import TargetParquet

TargetParquet.cli()
