﻿singer_sdk.SQLStream
====================

.. currentmodule:: singer_sdk

.. autoclass:: SQLStream
    :members:
    :show-inheritance:
    :inherited-members: Stream
    :special-members: __init__