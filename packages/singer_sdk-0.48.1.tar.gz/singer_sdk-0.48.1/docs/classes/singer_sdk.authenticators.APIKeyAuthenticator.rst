﻿singer_sdk.authenticators.APIKeyAuthenticator
=============================================

.. currentmodule:: singer_sdk.authenticators

.. autoclass:: APIKeyAuthenticator
    :members:
    :special-members: __init__, __call__