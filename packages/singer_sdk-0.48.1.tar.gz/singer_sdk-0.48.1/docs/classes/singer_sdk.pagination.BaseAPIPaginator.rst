﻿singer_sdk.pagination.BaseAPIPaginator
======================================

.. currentmodule:: singer_sdk.pagination

.. autoclass:: BaseAPIPaginator
    :members:
    :special-members: __init__, __call__