﻿singer_sdk.exceptions.TooManyRecordsException
=============================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: TooManyRecordsException
    :members:
    :special-members: __init__, __call__