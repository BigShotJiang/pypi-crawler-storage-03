﻿singer_sdk.typing.DateType
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: DateType
    :members:
    :special-members: __init__, __call__