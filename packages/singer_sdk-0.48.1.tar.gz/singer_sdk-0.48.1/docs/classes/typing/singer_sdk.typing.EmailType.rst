﻿singer_sdk.typing.EmailType
===========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: EmailType
    :members:
    :special-members: __init__, __call__