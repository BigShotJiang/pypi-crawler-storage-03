﻿singer_sdk.typing.IPv4Type
==========================

.. currentmodule:: singer_sdk.typing

.. autoclass:: IPv4Type
    :members:
    :special-members: __init__, __call__