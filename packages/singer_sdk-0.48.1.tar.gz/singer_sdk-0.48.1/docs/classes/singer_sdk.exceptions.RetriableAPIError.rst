﻿singer_sdk.exceptions.RetriableAPIError
=======================================

.. currentmodule:: singer_sdk.exceptions

.. autoclass:: RetriableAPIError
    :members:
    :special-members: __init__, __call__