﻿singer_sdk.batch.JSONLinesBatcher
=================================

.. currentmodule:: singer_sdk.batch

.. autoclass:: JSONLinesBatcher
    :members:
    :special-members: __init__, __call__