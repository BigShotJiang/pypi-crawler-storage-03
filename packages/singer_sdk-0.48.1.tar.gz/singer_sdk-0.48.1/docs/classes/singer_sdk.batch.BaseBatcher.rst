﻿singer_sdk.batch.BaseBatcher
============================

.. currentmodule:: singer_sdk.batch

.. autoclass:: BaseBatcher
    :members:
    :special-members: __init__, __call__