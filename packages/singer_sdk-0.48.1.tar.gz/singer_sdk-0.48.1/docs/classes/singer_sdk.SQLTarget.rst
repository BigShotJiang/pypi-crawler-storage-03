﻿singer_sdk.SQLTarget
====================

.. currentmodule:: singer_sdk

.. autoclass:: SQLTarget
    :members:
    :show-inheritance:
    :inherited-members:
    :special-members: __init__