"""Singer output samples, used for testing target behavior."""
