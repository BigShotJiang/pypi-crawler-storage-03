"""External tests fixtures."""

from __future__ import annotations
