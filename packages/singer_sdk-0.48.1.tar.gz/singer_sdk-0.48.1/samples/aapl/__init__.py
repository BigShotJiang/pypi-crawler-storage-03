"""AAPL tap."""
