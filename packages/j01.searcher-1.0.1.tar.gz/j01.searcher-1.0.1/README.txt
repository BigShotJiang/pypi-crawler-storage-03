This package provides an implementation for build z3c.indexer based search
forms for Zope3. The persistent search criteria can get stored in a session
or in an application as predefined filter query objects. This implementation
provides a JSON-RPC based implementation.
