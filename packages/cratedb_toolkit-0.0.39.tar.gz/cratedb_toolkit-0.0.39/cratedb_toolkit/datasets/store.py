from cratedb_toolkit.datasets.model import DatasetRegistry

registry = DatasetRegistry()
