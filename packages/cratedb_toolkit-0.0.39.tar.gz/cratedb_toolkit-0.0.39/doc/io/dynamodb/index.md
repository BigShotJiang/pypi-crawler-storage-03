(dynamodb)=
# DynamoDB I/O Subsystem

## About
Using the DynamoDB subsystem, you can transfer data from and to DynamoDB.


```{toctree}
:maxdepth: 1

loader
cdc
cdc-lambda
```
