from .timeit import timeit
from .sync_wrapper import timeit_sync
from .async_wrapper import timeit_async
