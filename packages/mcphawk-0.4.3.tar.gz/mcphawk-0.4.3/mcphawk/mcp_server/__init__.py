"""MCPHawk MCP Server - Query and analyze captured MCP traffic."""
