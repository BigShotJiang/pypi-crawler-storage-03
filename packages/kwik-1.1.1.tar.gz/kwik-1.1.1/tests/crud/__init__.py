"""CRUD operations test suite."""
