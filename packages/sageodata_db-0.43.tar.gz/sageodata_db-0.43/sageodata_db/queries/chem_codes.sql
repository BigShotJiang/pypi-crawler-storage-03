SELECT chem_code AS chem_code,  --col
       chem_name AS chem_name   --col
FROM   dhdb.sm_chem_vw