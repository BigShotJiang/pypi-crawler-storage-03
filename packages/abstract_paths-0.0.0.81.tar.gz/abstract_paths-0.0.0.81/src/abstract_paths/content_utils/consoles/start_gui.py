from finderConsole import reactRunnerConsole,ContentFinderConsole,MainShell
from abstract_gui.QT6.startConsole import  startConsole

startConsole(MainShell)
