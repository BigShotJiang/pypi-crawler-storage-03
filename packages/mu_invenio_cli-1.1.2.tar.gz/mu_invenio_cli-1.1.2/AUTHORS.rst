..
    Copyright (C) 2025 Masaryk University.

    MU Invenio Command Line Interface is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

- Dominik Dubovsky <485020@mail.muni.cz>