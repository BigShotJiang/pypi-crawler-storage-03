##模块介绍

#版本0.1.0介绍

**制作不易！！！！！！！！！！！！！！！！！！！**

该模块为math模块的补充，无需重新导入math模块(导入方式
为import math)

包括cot()、acot()、coth()、acoth()、rooting()、
titration()、sigma()、sigmas()、eta()、etas()、
phi、golden_ratio
(分别为余切、反余切、双曲余切、反双曲余切、
开方、幂塔、等差数列求和、等比数列求和、
等差数列求积、等比数列求积、)

**me只是middle school 学生，please多多支持！**

#注意

_It is in Chinese(coding:UTF-8)_

_It is in Chinese(coding:UTF-8)_

_It is in Chinese(coding:UTF-8)！！！！
！！！！！！！！！！！_