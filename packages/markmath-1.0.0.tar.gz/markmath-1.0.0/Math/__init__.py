"""
What do you see?!
There are not any things!
Close it file!
Now!!!!!!
No,there is something
"""
import math