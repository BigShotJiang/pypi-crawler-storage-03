```python test.py -r 'python test.py'
# Prefix goes here
<template>
<los>
# Write your solution here
</los>
<sol>
# Actual solution goes here
</sol>
</template>
# Suffix goes here
<suffix_invisible>
# Invisible suffix goes here
```