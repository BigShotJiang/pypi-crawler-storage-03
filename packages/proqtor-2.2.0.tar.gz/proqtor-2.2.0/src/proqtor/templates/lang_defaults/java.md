```java Test.java -b 'javac Test.java' -r 'java Test'
// Prefix goes here
import java.util.*;
<template>
public class Test{
    public static void main(String[] args) {           
    <los>
    // Write your solution here
    </los>
    <sol>
    // Actual solution goes here
    </sol>
    }
}
</template>
// Suffix goes here
<suffix_invisible>
// Invisible suffix goes here
```