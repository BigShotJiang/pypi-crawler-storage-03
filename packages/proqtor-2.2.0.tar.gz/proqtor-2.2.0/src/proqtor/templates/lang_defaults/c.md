```c test.c -b 'gcc test.c -o test' -r './test'
// Prefix goes here
#include <stdio.h>
<template>
int main(){
    <los>
    // Write your solution here
    </los>
    <sol>
    // Actual solution goes here
    </sol>
}
</template>
// Suffix goes here
<suffix_invisible>
// Invisible suffix goes here
```