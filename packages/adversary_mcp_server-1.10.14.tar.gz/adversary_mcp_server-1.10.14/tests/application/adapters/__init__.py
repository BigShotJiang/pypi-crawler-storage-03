"""Tests for application layer adapters."""
