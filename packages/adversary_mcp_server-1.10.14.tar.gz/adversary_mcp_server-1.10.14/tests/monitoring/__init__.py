"""Tests for monitoring package."""
