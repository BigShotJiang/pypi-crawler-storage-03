# History module initialization
from .history import HistoryManager

__all__ = ['HistoryManager']