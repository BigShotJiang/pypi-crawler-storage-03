"""MCP Airflow API package."""
from .airflow_api import mcp

__all__ = ["mcp"]
