The oven's temperature over time is shown graphically.
