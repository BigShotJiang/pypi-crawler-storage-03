Loop over the contained subitems some number of times.
