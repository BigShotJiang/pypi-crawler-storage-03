PLUGIN_ENTRY_POINT = "fabrial.plugins"
