"""Headers and format specifiers for datetimes."""

HEADER = "Day Month Year Hours:Minutes:Seconds AM/PM"
