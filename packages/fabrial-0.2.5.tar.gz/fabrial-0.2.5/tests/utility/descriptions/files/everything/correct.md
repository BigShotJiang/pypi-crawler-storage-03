Overview description. Here is a substitution: overview substitution text.
# Parameters
- **Parameter1**

    Description of Parameter1.
- **Parameter2**

    Description of Parameter2.
- **Parameter3Substitution**

    Description of Parameter3Substitution.
# Visuals
Visuals description. Here is a substitution: visuals substitution text.
# Data Recording
Data is written to **everything**, which contains:
- **metadata.json**

    Metadata for this sequence step.
- **file1.txt**

    Description of file1.txt.
- **file2.txt**

    Description of file2.txt.
- **file3substitution.txt**

    Description of file3substitution.txt.