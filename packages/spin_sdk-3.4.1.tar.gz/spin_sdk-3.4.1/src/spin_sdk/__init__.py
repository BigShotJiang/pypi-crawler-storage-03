"""Spin Python SDK

This is an SDK for creating [Spin](https://github.com/fermyon/spin) apps using Python.

Note that this SDK supercedes an earlier, experimental version, the documentation for which may be found [here](https://fermyon.github.io/spin-python-sdk/v1/index.html).
"""
