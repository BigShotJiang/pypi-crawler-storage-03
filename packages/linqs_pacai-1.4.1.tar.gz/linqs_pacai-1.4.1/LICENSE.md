## Pacman

### Licensing Information
Do not distribute or publish solutions to this project.  
You are free to use and extend these projects for educational purposes provided that:
 1. You do not distribute or publish solutions.
 2. You retain this notice.
 3. You provide clear attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
 3. You provide clear attribution to the LINQS lab, including a link to this repository: https://github.com/linqs.

The Pacman AI projects were developed at UC Berkeley, primarily by John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
For more info, see http://ai.berkeley.edu/project_overview.html.

### Modifications
All of these files have since been modified (sometimes heavily) by the [LINQS Machine Learning Lab](http://www.linqs.org).
