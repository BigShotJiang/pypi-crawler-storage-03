"""
Dashlab - A Python package for dashboard and data visualization tools.
"""

__version__ = "0.1.4" # This line is automatically updated at build time, do not edit manually.

__all__ = ["__version__"]
