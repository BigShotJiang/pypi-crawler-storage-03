from django.apps import AppConfig

class AiwafConfig(AppConfig):
    name = "aiwaf"
    verbose_name = "AI‑Driven Web Application Firewall"
