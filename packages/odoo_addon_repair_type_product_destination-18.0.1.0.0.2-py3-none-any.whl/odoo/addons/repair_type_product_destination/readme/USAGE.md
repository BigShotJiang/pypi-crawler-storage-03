The following fields are available in the Repair module:

1. **Product Destination Location**
- Repairs > Orders > Select or create an order > Miscellaneous > Product Destination Location

2. **Default Product Destination Location**
- Repairs > Orders > Select or create an order > Miscellaneous > Operation Type > Default Product Destination Location