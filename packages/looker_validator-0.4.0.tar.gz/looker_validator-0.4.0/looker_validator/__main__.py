"""
Entry point for running looker-validator as a module.
"""

from looker_validator.async_cli import main

if __name__ == "__main__":
    main()