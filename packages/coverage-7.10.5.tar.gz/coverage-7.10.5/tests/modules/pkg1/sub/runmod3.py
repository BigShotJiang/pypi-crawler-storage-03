# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://github.com/nedbat/coveragepy/blob/master/NOTICE.txt

# Used in the tests for PyRunner
import sys

print("runmod3: passed %s" % sys.argv[1])
