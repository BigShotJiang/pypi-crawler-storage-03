from pydantic import BaseModel


class SocketMessage(BaseModel):
    pass
