"""UDS addresses for ECUs mounted in Hyundai vehicles."""
