"""UDS addresses for ECUs mounted in Hyundai i20 vehicles."""
