"""UDS addresses of ECUs for CAN communication."""
