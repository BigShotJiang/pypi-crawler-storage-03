"""UDS addresses for all ECUs identified by Spare Part Number."""
