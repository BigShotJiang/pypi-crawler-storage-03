#![cfg_attr(feature = "strict", deny(warnings))]

mod parallel_utils;
pub use parallel_utils::*;
