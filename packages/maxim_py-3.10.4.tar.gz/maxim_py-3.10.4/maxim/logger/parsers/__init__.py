from .core import validate_type

__all__ = ["validate_type"]
