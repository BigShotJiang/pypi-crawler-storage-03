"""Commence initialization of module."""

from gevent import monkey

monkey.patch_all()
