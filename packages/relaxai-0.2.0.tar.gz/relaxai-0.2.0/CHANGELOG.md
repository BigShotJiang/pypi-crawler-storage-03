# Changelog

## 0.2.0 (2025-08-26)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/relax-ai/python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** update via SDK Studio ([b6b872a](https://github.com/relax-ai/python-sdk/commit/b6b872a587317b3beabc763b184efce32540ab99))
* **api:** update via SDK Studio ([964dabf](https://github.com/relax-ai/python-sdk/commit/964dabfcf0d2f2f9ad50edfa2d3e10f0eb734ffa))
* **api:** update via SDK Studio ([4a14a81](https://github.com/relax-ai/python-sdk/commit/4a14a8195f4881739c7e6cc12a2fb2e7606710f0))
* **api:** update via SDK Studio ([51c08b4](https://github.com/relax-ai/python-sdk/commit/51c08b4f2d5e5126d8dc8c2eec3ef8147b30fef6))
* **api:** update via SDK Studio ([d06b5d0](https://github.com/relax-ai/python-sdk/commit/d06b5d097de5a937d0d2092fbbc2a4bed4bab05e))
* **api:** update via SDK Studio ([2d5a57d](https://github.com/relax-ai/python-sdk/commit/2d5a57dbb738972bce08a682c4fc2e98af372309))
* **api:** update via SDK Studio ([2f09580](https://github.com/relax-ai/python-sdk/commit/2f0958064f86668d55ed4dea2c6a21ecaf6b791c))
* **api:** update via SDK Studio ([6430e6f](https://github.com/relax-ai/python-sdk/commit/6430e6f00de2de2b0c95277d456e7937226d6e4f))
* **api:** update via SDK Studio ([11aae68](https://github.com/relax-ai/python-sdk/commit/11aae68a730b918abf5d9c8f0991ca923d15a5d7))
* **api:** update via SDK Studio ([53fd3c1](https://github.com/relax-ai/python-sdk/commit/53fd3c18d19447b5a2314af8c2626dcc83ab6176))
* clean up environment call outs ([fd52000](https://github.com/relax-ai/python-sdk/commit/fd52000dd6823e3f52759ffb32457b1b6bb777e8))
* **client:** support file upload requests ([e70c0ec](https://github.com/relax-ai/python-sdk/commit/e70c0ecbd97586746fcaa4618f8c7c254fe5edbb))


### Bug Fixes

* **ci:** correct conditional ([7b9dd73](https://github.com/relax-ai/python-sdk/commit/7b9dd73dec12d098f3908c46804fea6323991933))
* **client:** don't send Content-Type header on GET requests ([134d444](https://github.com/relax-ai/python-sdk/commit/134d444d1e46fa968b03c1d2c29a81a3f50260bc))
* **parsing:** correctly handle nested discriminated unions ([f3f2481](https://github.com/relax-ai/python-sdk/commit/f3f2481e3b294c4859dce817620beeda0750df70))
* **parsing:** ignore empty metadata ([5a69522](https://github.com/relax-ai/python-sdk/commit/5a695221f0607e7140856e41cc84057fed534cf5))
* **parsing:** parse extra field types ([058ebec](https://github.com/relax-ai/python-sdk/commit/058ebec52bdfbdd0fa5d094507ec0151954d7611))


### Chores

* **ci:** change upload type ([d0eac9e](https://github.com/relax-ai/python-sdk/commit/d0eac9e1c21f5af782d7b6b0e9d4e12a7ae1ba4b))
* **ci:** only run for pushes and fork pull requests ([2823330](https://github.com/relax-ai/python-sdk/commit/28233300e18b343582f000c7809c6d5f9e5c9dfd))
* **internal:** bump pinned h11 dep ([2fcd331](https://github.com/relax-ai/python-sdk/commit/2fcd331182be60fe3186a12bf076c0792312d340))
* **internal:** change ci workflow machines ([9674302](https://github.com/relax-ai/python-sdk/commit/96743023d78761ffb5f52f6d50a8ae66ca1df896))
* **internal:** codegen related update ([cf132b1](https://github.com/relax-ai/python-sdk/commit/cf132b191e08d91e189d3dd910f020121511ec4b))
* **internal:** fix ruff target version ([98ebba8](https://github.com/relax-ai/python-sdk/commit/98ebba829120bb69d9c97a8c434748ee216427c4))
* **internal:** version bump ([0a019aa](https://github.com/relax-ai/python-sdk/commit/0a019aa4888b574cc3892e8a1ed188330c97f971))
* **package:** mark python 3.13 as supported ([75f9e16](https://github.com/relax-ai/python-sdk/commit/75f9e16cf24b3ce117503d87083ef95511230c95))
* **project:** add settings file for vscode ([d91c008](https://github.com/relax-ai/python-sdk/commit/d91c008238bb40bfe103413b61798695821f2e66))
* **readme:** fix version rendering on pypi ([ba4beb8](https://github.com/relax-ai/python-sdk/commit/ba4beb8326b69e8dc5e54e014620c35681e21114))
* sync repo ([0bb5fc8](https://github.com/relax-ai/python-sdk/commit/0bb5fc82969d958f999c864a47af4b95be8f41cf))
* update @stainless-api/prism-cli to v5.15.0 ([5e5155e](https://github.com/relax-ai/python-sdk/commit/5e5155e471ec22bd51e51c08272fef2281e9c523))
* update github action ([fa9264e](https://github.com/relax-ai/python-sdk/commit/fa9264e1d1436107e76924ba4e233268f53e8751))
* update SDK settings ([682ca85](https://github.com/relax-ai/python-sdk/commit/682ca85bbaf7b9ed51f01f9c2090db8dc7890ce3))
* update SDK settings ([b6c7f5a](https://github.com/relax-ai/python-sdk/commit/b6c7f5aebefb986948527773a67b92fe2fb15954))
* update SDK settings ([fc9f194](https://github.com/relax-ai/python-sdk/commit/fc9f194e0d241fb70577baba8285b31f76677d19))

## 0.18.0 (2025-08-26)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/relax-ai/python-sdk/compare/v0.17.0...v0.18.0)

### Features

* **api:** update via SDK Studio ([84e3923](https://github.com/relax-ai/python-sdk/commit/84e39231319fec115847186246f58c9d95cc6095))

## 0.17.0 (2025-08-26)

Full Changelog: [v0.16.0...v0.17.0](https://github.com/relax-ai/python-sdk/compare/v0.16.0...v0.17.0)

### Features

* **api:** update via SDK Studio ([e8708e9](https://github.com/relax-ai/python-sdk/commit/e8708e99ebb76318a9009606471bfbfb8f762ac4))

## 0.16.0 (2025-08-26)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/relax-ai/python-sdk/compare/v0.15.0...v0.16.0)

### Features

* **api:** update via SDK Studio ([cdf054a](https://github.com/relax-ai/python-sdk/commit/cdf054a861f447ef6cdb26af3b93d99e34aac307))
* **api:** update via SDK Studio ([f6ed73b](https://github.com/relax-ai/python-sdk/commit/f6ed73b46ba3716a4d7fda707d9dcc6acb1e962b))

## 0.15.0 (2025-08-26)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/relax-ai/python-sdk/compare/v0.14.0...v0.15.0)

### Features

* **api:** update via SDK Studio ([978b8c1](https://github.com/relax-ai/python-sdk/commit/978b8c14f5b522c5c2301ffb7b13ead2640773f1))

## 0.14.0 (2025-08-26)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/relax-ai/python-sdk/compare/v0.13.0...v0.14.0)

### Features

* **api:** update via SDK Studio ([8908751](https://github.com/relax-ai/python-sdk/commit/8908751c9870e75139a00ce8a49578450b805941))
* **api:** update via SDK Studio ([14ec145](https://github.com/relax-ai/python-sdk/commit/14ec145db8a0ab1360fb3a085ca489d9ca8afeb1))

## 0.13.0 (2025-08-26)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/relax-ai/python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** update via SDK Studio ([92fe5ae](https://github.com/relax-ai/python-sdk/commit/92fe5ae1ced1942f524f4233f7be7413b044b264))


### Chores

* **internal:** change ci workflow machines ([4f8c965](https://github.com/relax-ai/python-sdk/commit/4f8c9652a55ebefcd7a7a034a2eebeedba13f2cb))
* update github action ([82bdf02](https://github.com/relax-ai/python-sdk/commit/82bdf0209421625e4d4d01b371784b1e98c97d62))

## 0.12.0 (2025-08-21)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/relax-ai/python-sdk/compare/v0.11.0...v0.12.0)

### Features

* **api:** update via SDK Studio ([11aae68](https://github.com/relax-ai/python-sdk/commit/11aae68a730b918abf5d9c8f0991ca923d15a5d7))
* **api:** update via SDK Studio ([53fd3c1](https://github.com/relax-ai/python-sdk/commit/53fd3c18d19447b5a2314af8c2626dcc83ab6176))
* clean up environment call outs ([fd52000](https://github.com/relax-ai/python-sdk/commit/fd52000dd6823e3f52759ffb32457b1b6bb777e8))
* **client:** support file upload requests ([e70c0ec](https://github.com/relax-ai/python-sdk/commit/e70c0ecbd97586746fcaa4618f8c7c254fe5edbb))


### Bug Fixes

* **ci:** correct conditional ([7b9dd73](https://github.com/relax-ai/python-sdk/commit/7b9dd73dec12d098f3908c46804fea6323991933))
* **client:** don't send Content-Type header on GET requests ([134d444](https://github.com/relax-ai/python-sdk/commit/134d444d1e46fa968b03c1d2c29a81a3f50260bc))
* **parsing:** correctly handle nested discriminated unions ([f3f2481](https://github.com/relax-ai/python-sdk/commit/f3f2481e3b294c4859dce817620beeda0750df70))
* **parsing:** ignore empty metadata ([5a69522](https://github.com/relax-ai/python-sdk/commit/5a695221f0607e7140856e41cc84057fed534cf5))
* **parsing:** parse extra field types ([058ebec](https://github.com/relax-ai/python-sdk/commit/058ebec52bdfbdd0fa5d094507ec0151954d7611))


### Chores

* **ci:** change upload type ([d0eac9e](https://github.com/relax-ai/python-sdk/commit/d0eac9e1c21f5af782d7b6b0e9d4e12a7ae1ba4b))
* **ci:** only run for pushes and fork pull requests ([2823330](https://github.com/relax-ai/python-sdk/commit/28233300e18b343582f000c7809c6d5f9e5c9dfd))
* **internal:** bump pinned h11 dep ([2fcd331](https://github.com/relax-ai/python-sdk/commit/2fcd331182be60fe3186a12bf076c0792312d340))
* **internal:** codegen related update ([cf132b1](https://github.com/relax-ai/python-sdk/commit/cf132b191e08d91e189d3dd910f020121511ec4b))
* **internal:** fix ruff target version ([98ebba8](https://github.com/relax-ai/python-sdk/commit/98ebba829120bb69d9c97a8c434748ee216427c4))
* **internal:** version bump ([0a019aa](https://github.com/relax-ai/python-sdk/commit/0a019aa4888b574cc3892e8a1ed188330c97f971))
* **package:** mark python 3.13 as supported ([75f9e16](https://github.com/relax-ai/python-sdk/commit/75f9e16cf24b3ce117503d87083ef95511230c95))
* **project:** add settings file for vscode ([d91c008](https://github.com/relax-ai/python-sdk/commit/d91c008238bb40bfe103413b61798695821f2e66))
* **readme:** fix version rendering on pypi ([ba4beb8](https://github.com/relax-ai/python-sdk/commit/ba4beb8326b69e8dc5e54e014620c35681e21114))
* sync repo ([0bb5fc8](https://github.com/relax-ai/python-sdk/commit/0bb5fc82969d958f999c864a47af4b95be8f41cf))
* update @stainless-api/prism-cli to v5.15.0 ([5e5155e](https://github.com/relax-ai/python-sdk/commit/5e5155e471ec22bd51e51c08272fef2281e9c523))
* update SDK settings ([682ca85](https://github.com/relax-ai/python-sdk/commit/682ca85bbaf7b9ed51f01f9c2090db8dc7890ce3))
* update SDK settings ([b6c7f5a](https://github.com/relax-ai/python-sdk/commit/b6c7f5aebefb986948527773a67b92fe2fb15954))
* update SDK settings ([fc9f194](https://github.com/relax-ai/python-sdk/commit/fc9f194e0d241fb70577baba8285b31f76677d19))

## 0.11.0 (2025-08-20)

Full Changelog: [v0.1.0...v0.11.0](https://github.com/bennorris123/python-sdk-test/compare/v0.1.0...v0.11.0)

### Chores

* sync repo ([8b4f938](https://github.com/bennorris123/python-sdk-test/commit/8b4f93863d6771931ceaa4441a43e4fd45300804))
* update SDK settings ([5e557e4](https://github.com/bennorris123/python-sdk-test/commit/5e557e44d1f50b8f26e94253d9ab6e0bf2941689))
* update SDK settings ([1d0944d](https://github.com/bennorris123/python-sdk-test/commit/1d0944db459fd31e320413b82ad110dcc7c52bd3))

## 0.1.0 (2025-07-25)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/relax-ai/python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** update via SDK Studio ([53fd3c1](https://github.com/relax-ai/python-sdk/commit/53fd3c18d19447b5a2314af8c2626dcc83ab6176))
* clean up environment call outs ([fd52000](https://github.com/relax-ai/python-sdk/commit/fd52000dd6823e3f52759ffb32457b1b6bb777e8))


### Bug Fixes

* **ci:** correct conditional ([7b9dd73](https://github.com/relax-ai/python-sdk/commit/7b9dd73dec12d098f3908c46804fea6323991933))
* **client:** don't send Content-Type header on GET requests ([134d444](https://github.com/relax-ai/python-sdk/commit/134d444d1e46fa968b03c1d2c29a81a3f50260bc))
* **parsing:** correctly handle nested discriminated unions ([f3f2481](https://github.com/relax-ai/python-sdk/commit/f3f2481e3b294c4859dce817620beeda0750df70))
* **parsing:** ignore empty metadata ([5a69522](https://github.com/relax-ai/python-sdk/commit/5a695221f0607e7140856e41cc84057fed534cf5))
* **parsing:** parse extra field types ([058ebec](https://github.com/relax-ai/python-sdk/commit/058ebec52bdfbdd0fa5d094507ec0151954d7611))


### Chores

* **ci:** change upload type ([d0eac9e](https://github.com/relax-ai/python-sdk/commit/d0eac9e1c21f5af782d7b6b0e9d4e12a7ae1ba4b))
* **ci:** only run for pushes and fork pull requests ([2823330](https://github.com/relax-ai/python-sdk/commit/28233300e18b343582f000c7809c6d5f9e5c9dfd))
* **internal:** bump pinned h11 dep ([2fcd331](https://github.com/relax-ai/python-sdk/commit/2fcd331182be60fe3186a12bf076c0792312d340))
* **internal:** codegen related update ([cf132b1](https://github.com/relax-ai/python-sdk/commit/cf132b191e08d91e189d3dd910f020121511ec4b))
* **internal:** version bump ([0a019aa](https://github.com/relax-ai/python-sdk/commit/0a019aa4888b574cc3892e8a1ed188330c97f971))
* **package:** mark python 3.13 as supported ([75f9e16](https://github.com/relax-ai/python-sdk/commit/75f9e16cf24b3ce117503d87083ef95511230c95))
* **project:** add settings file for vscode ([d91c008](https://github.com/relax-ai/python-sdk/commit/d91c008238bb40bfe103413b61798695821f2e66))
* **readme:** fix version rendering on pypi ([ba4beb8](https://github.com/relax-ai/python-sdk/commit/ba4beb8326b69e8dc5e54e014620c35681e21114))

## 0.0.1 (2025-06-27)

Full Changelog: [v0.0.1-alpha.0...v0.0.1](https://github.com/relax-ai/python-sdk/compare/v0.0.1-alpha.0...v0.0.1)

### Chores

* update SDK settings ([b6c7f5a](https://github.com/relax-ai/python-sdk/commit/b6c7f5aebefb986948527773a67b92fe2fb15954))
* update SDK settings ([fc9f194](https://github.com/relax-ai/python-sdk/commit/fc9f194e0d241fb70577baba8285b31f76677d19))
