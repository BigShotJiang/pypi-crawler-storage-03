"""
Django Log Hub - Centralized logging and monitoring module for Django projects.
"""

__version__ = "1.0.6"

default_app_config = 'log_hub.apps.LogHubConfig'
