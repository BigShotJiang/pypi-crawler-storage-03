from .assets import get_test_drawing as get_test_drawing
from .assets import read_drawing_sync as read_drawing_sync
from .assets import read_example_drawing as read_example_drawing
