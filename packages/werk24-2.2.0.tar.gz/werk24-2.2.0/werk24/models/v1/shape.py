from enum import Enum


class W24GeometricShape(str, Enum):
    CIRCLE = "CIRCLE"
    SQUARE = "SQUARE"
    RECTANGLE = "RECTANGLE"
