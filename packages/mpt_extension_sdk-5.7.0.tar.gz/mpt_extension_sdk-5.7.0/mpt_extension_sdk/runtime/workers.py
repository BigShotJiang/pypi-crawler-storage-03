from django.core.management import call_command
from django.core.wsgi import get_wsgi_application
from gunicorn.app.base import BaseApplication

from mpt_extension_sdk.constants import (
    DEFAULT_APP_CONFIG_GROUP,
    DEFAULT_APP_CONFIG_NAME,
)
from mpt_extension_sdk.runtime.utils import initialize_extension


class ExtensionWebApplication(BaseApplication):
    """Gunicorn application for the extension."""
    def __init__(self, app, options=None):
        self.options = options or {}
        self.application = app
        super().__init__()

    def load_config(self):
        """Load configuration settings."""
        config = {
            opt_key: opt_value
            for opt_key, opt_value in self.options.items()
            if opt_key in self.cfg.settings and opt_value is not None
        }
        for opt_key, opt_value in config.items():
            self.cfg.set(opt_key.lower(), opt_value)

    def load(self):
        """Load the application."""
        return self.application


def start_event_consumer(options):
    """Start the event consumer."""
    initialize_extension(options)
    call_command("consume_events")


def start_gunicorn(
    options,
    group=DEFAULT_APP_CONFIG_GROUP,
    name=DEFAULT_APP_CONFIG_NAME,
):
    """Start the Gunicorn server."""
    initialize_extension(options, group=group, name=name)

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "verbose": {
                "format": "{asctime} {name} {levelname} (pid: {process}, "
                "thread: {thread}) {message}",
                "style": "{",
            },
            "rich": {
                "format": "%(message)s",
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "verbose",
            },
            "rich": {
                "class": "rich.logging.RichHandler",
                "formatter": "rich",
                "log_time_format": lambda log_time: log_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
                "rich_tracebacks": True,
            },
        },
        "root": {
            "handlers": ["rich" if options.get("color") else "console"],
            "level": "INFO",
        },
        "loggers": {
            "gunicorn.access": {
                "handlers": ["rich" if options.get("color") else "console"],
                "level": "INFO",
                "propagate": False,
            },
            "gunicorn.error": {
                "handlers": ["rich" if options.get("color") else "console"],
                "level": "INFO",
                "propagate": False,
            },
        },
    }

    guni_options = {
        "bind": options.get("bind", "0.0.0.0:8080"),
        "logconfig_dict": logging_config,
    }
    ExtensionWebApplication(get_wsgi_application(), options=guni_options).run()
