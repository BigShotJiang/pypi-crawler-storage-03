---
title: Credits
hide:
- toc
---

```python exec="yes"
--8<-- "scripts/gen_credits.py"
```
