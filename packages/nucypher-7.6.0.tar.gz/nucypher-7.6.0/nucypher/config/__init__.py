


from constant_sorrow.constants import NO_KEYSTORE_ATTACHED

NO_KEYSTORE_ATTACHED.bool_value(False)
