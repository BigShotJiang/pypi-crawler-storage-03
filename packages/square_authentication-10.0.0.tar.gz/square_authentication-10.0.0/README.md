# square_authentication

> 📌 versioning: see [CHANGELOG.md](./CHANGELOG.md).

## about

authentication layer for my personal server.

## goals

(wip)

## Installation

```shell
pip install square_authentication
```

## env

- python>=3.12.0

> feedback is appreciated. thank you!
