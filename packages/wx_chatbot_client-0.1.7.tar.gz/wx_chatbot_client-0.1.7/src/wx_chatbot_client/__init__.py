from .web import web_router

__all__ = [
    "web_router",
]
