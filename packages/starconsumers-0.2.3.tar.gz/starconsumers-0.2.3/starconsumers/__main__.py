from starconsumers.cli.main import cli_main

cli_main()
