"""
Minimal setup.py for backward compatibility.
All configuration is now in pyproject.toml.
"""
from setuptools import setup

# All configuration is in pyproject.toml
setup()