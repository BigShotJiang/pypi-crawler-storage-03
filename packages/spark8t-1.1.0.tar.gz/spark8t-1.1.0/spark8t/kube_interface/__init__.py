"""Module for kube interface."""
