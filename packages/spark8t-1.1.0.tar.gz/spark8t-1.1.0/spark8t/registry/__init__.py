"""Module for service account registry."""
