"""CLI interface for spark8t."""

import os

from spark8t.domain import Defaults

defaults = Defaults(dict(os.environ))
