# Test if the module can be imported
def test_import():
   import ara_core