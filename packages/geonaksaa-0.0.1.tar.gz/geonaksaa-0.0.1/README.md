# geonaksaa


[![image](https://img.shields.io/pypi/v/geonaksaa.svg)](https://pypi.python.org/pypi/geonaksaa)
[![image](https://img.shields.io/conda/vn/conda-forge/geonaksaa.svg)](https://anaconda.org/conda-forge/geonaksaa)


**A python package for land and water mapping**


-   Free software: MIT License
-   Documentation: https://nakshaa.github.io/geonaksaa
    

## Features

-   TODO
