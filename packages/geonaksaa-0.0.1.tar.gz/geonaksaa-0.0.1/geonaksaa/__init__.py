"""Top-level package for geonaksaa."""

__author__ = """Keshab Thapa"""
__email__ = "keshabthp@gmail.com"
__version__ = "0.0.1"
