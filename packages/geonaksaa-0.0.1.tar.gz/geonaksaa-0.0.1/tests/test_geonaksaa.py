#!/usr/bin/env python

"""Tests for `geonaksaa` package."""


import unittest

from geonaksaa import geonaksaa


class TestGeonaksaa(unittest.TestCase):
    """Tests for `geonaksaa` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
