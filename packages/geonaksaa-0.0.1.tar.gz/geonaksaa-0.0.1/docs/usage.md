# Usage

To use geonaksaa in a project:

```
import geonaksaa
```
