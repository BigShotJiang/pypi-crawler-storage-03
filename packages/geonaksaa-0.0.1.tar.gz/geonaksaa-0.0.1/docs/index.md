# Welcome to geonaksaa


[![image](https://img.shields.io/pypi/v/geonaksaa.svg)](https://pypi.python.org/pypi/geonaksaa)


**A python package for land and water mapping**


-   Free software: MIT License
-   Documentation: <https://nakshaa.github.io/geonaksaa>
    

## Features

-   TODO
