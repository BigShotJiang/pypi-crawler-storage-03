"""
Firehound Firebase Security Scanner
A tool for discovering and auditing Firebase misconfigurations in iOS apps.
"""

__version__ = "1.0.0"
__author__ = "Harry Johnston"
__description__ = "Firebase security scanner for iOS apps"
