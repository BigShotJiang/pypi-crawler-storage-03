from . import test_sale_blanket_order
from . import test_sale_call_off_order
from . import test_sale_normal_order
from . import test_sale_order_deliver_remaining_wizard
