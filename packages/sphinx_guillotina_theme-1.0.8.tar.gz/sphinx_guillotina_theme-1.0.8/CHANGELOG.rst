1.0.8 (2025-08-21)
------------------

- Deleting style in layout, adapting to sphinx 8


1.0.7 (2018-07-23)
------------------

- More style fixes


1.0.6 (2018-07-23)
------------------

- Fix size on mobile browsers


1.0.5 (2018-07-21)
------------------

- remove unused js ref


1.0.4 (2018-07-21)
------------------

- Add favicon


1.0.3 (2018-07-21)
------------------

- Another css fix


1.0.2 (2018-07-21)
------------------

- Fix style of pre tags


1.0.1 (2017-10-13)
------------------

- Change to use response grid from semantic UI


1.0.0 (2017-10-07)
------------------

- initial release
