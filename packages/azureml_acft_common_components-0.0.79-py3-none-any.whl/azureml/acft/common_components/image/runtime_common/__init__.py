# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Code ported over from azureml-automl-dnn-vision."""
from azureml.acft.common_components import get_logger_app

logger = get_logger_app(__name__)
