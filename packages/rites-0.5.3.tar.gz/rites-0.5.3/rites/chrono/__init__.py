"""Chrono module for rites package.

This module contains time and timing functionality.
"""

from .chrono import Chrono

__all__ = ['Chrono']
