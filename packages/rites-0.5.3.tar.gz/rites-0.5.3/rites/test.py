import rites.logger as l

logger = l.Logger("rites/testfolder")

logger.info("This is an info message.")
logger.debug("This is a debug message.")
logger.warning("This is a warning message.")
logger.success("This is a success message.")
logger.error("This is an error message.")
