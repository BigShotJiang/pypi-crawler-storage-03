"""Bitchain module for rites package.

This module contains blockchain-related functionality.
"""

from .bitchain import BitChain

__all__ = ['BitChain']
