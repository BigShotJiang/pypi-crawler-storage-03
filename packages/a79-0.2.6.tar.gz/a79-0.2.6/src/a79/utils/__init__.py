"""A79 SDK utilities module."""
