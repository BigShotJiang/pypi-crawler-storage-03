from typing import Any

from pydantic import BaseModel


class ComposioResult(BaseModel):
    result: Any
