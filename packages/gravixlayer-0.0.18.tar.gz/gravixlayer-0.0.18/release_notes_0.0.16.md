﻿Added new completions endpoints and cli     
CLI completions mode: `--mode completions`
