# -*- encode: utf-8 -*-

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class BaseModule:  # noqa: D101
    pass
