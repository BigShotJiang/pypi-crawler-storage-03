# -*- encode: utf-8 -*-

import logging

from aws_cdk_modules.base import BaseModule

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class NetworkModule(BaseModule):  # noqa: D101
    pass
