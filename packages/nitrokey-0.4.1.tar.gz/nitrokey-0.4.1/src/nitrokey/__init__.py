"""
Nitrokey Python SDK
"""

_VID_NITROKEY = 0x20A0
