#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright 2019-2024 NXP
#
# SPDX-License-Identifier: BSD-3-Clause

version = "2.1.0"

__author__ = "NXP"
__license__ = "BSD-3-Clause"
__version__ = version
__release__ = "beta"
