# nRF52 Bootloader Firmware Upload Module

Anything inside this directory is originally extracted from: https://github.com/NordicSemiconductor/pc-nrfutil.
In detail anything that is needed to upload a signed firmware image to a Nitrokey 3 Mini with an nRF MCU.


