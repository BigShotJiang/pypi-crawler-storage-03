"""
装饰器模块
提供各种实用的装饰器功能
"""





from .singleton import Singleton
