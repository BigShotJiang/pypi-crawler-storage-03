


class SECGROUP(object):
    


    def lssgp(self):
        
        pass 


