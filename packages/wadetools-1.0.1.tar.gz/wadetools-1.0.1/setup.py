from setuptools import find_packages,setup
setup(
 name='wadeTools',
 version='1.0.1',
 packages = find_packages(),
 url ='http://www.tbzhu.com',
 author = 'wade',
 author_email = '317909531@qq.com',
 )