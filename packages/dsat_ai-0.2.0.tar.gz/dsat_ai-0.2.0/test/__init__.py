"""Test suite for scryptorum framework."""
