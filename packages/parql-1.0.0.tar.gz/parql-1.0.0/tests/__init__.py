"""Test suite for ParQL."""
