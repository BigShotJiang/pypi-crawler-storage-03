"""Core functionality for ParQL."""
