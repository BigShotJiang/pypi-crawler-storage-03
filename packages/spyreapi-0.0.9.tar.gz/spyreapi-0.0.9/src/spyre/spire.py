from .client import SpireClient
from .sales import OrdersClient, InvoiceClient
from .customers import CustomerClient
from .inventory import InventoryClient
from .purchasing import PurchasingClient, PurchasingHistoryClient

class Spire:
    """
    High-level interface to interact with the Spire API.

    This class wraps the lower-level API clients (Orders, Invoices, Customers, Inventory) into a unified interface,
    initializing them using shared authentication via `SpireClient`.

    Attributes:
        client (SpireClient): Authenticated Spire API client.
        orders (OrdersClient): Client for accessing sales orders.
        invoices (InvoiceClient): Client for accessing invoices.
        customers (CustomerClient): Client for accessing customer records.
        inventory (InventoryClient): Client for accessing inventory items.
        purchasing (PurchasingClient): Client for accessing purchasing records.
        purchasingHistory (PurchasingHistoryClient): Client for accessing purchasing history records.
    """
    def __init__(self, host: str = None, company: str = None, username: str = None, password: str = None, client: 'SpireClient' = None):
        """
        Creates a Spire session or accepts a custom SpireClient instance.

        Args:
            host (str): Spire Server host.
            company (str): Spire company.
            username (str): Spire user username.
            password (str): Spire user password.
            client (SpireClient, optional): Custom SpireClient instance.
        """
        if client is not None:
            self.client = client
        else:
            if not all([host, company, username, password]):
                raise ValueError("host, company, username, and password are required if client is not provided")
            self.client = SpireClient(host, company, username, password)

        self.orders = OrdersClient(self.client)
        self.invoices = InvoiceClient(self.client)
        self.customers = CustomerClient(self.client)
        self.inventory = InventoryClient(self.client)
        self.purchasing = PurchasingClient(self.client)
        self.purchasingHistory = PurchasingHistoryClient(self.client)

