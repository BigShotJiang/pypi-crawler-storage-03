from .main import FaststreamPlugin

__all__ = ["FaststreamPlugin"]