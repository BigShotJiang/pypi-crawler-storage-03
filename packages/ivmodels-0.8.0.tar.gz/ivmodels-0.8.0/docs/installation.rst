Installation
============

You can install the package through conda
::

   conda install ivmodels -c conda-forge

or through pip

::

   pip install ivmodels