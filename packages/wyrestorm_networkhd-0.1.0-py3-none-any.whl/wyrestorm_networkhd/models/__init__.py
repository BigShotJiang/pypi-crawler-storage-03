"""NetworkHD API data models.

Import directly from submodules:
- .api_notifications for notification models
- .api_query for query response models
"""
