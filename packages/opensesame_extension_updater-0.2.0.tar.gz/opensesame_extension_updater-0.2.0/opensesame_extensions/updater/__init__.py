# The name of the package to check for updates on conda and pip
packages = ['opensesame-extension-updater']
