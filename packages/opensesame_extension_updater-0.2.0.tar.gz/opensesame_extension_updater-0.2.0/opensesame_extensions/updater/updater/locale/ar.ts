<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>النموذج</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>بعض الحزم يمكن تحديثها</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>تشغيل سكريبت التحديث</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>لتثبيت التحديثات ، تحتاج إلى إعادة تشغيل التطبيق كمسؤول</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>التحديثات المتاحة</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>بعض الحزم يمكن تحديثها</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>يتحقق تلقائيًا من تحديثات الحزم المحددة</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># يمكن تحديث الحزم التالية من خلال conda:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># يمكن تحديث الحزم التالية من خلال pip:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>بعض الحزم يمكن تحديثها. انقر على الرمز في شريط الأدوات لرؤية التحديثات المتاحة</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>انقر لرؤية التحديثات المتاحة</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>تثبيت التحديثات ...</translation>
    </message>
</context>
</TS>