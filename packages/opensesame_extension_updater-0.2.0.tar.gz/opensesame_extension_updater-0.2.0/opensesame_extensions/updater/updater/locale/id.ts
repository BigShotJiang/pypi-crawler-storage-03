<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>Formulir</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>Beberapa paket dapat diperbarui</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>Jalankan skrip pembaruan</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>Untuk memasang pembaruan, Anda perlu memulai ulang aplikasi sebagai Administrator</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>Pembaruan tersedia</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>Beberapa paket dapat diperbarui</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>Otomatis memeriksa pembaruan untuk paket yang dipilih</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># Paket berikut dapat diperbarui melalui conda:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># Paket berikut dapat diperbarui melalui pip:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>Beberapa paket dapat diperbarui. Klik ikon pembaruan di bilah alat untuk melihat pembaruan yang tersedia</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>Klik untuk melihat pembaruan yang tersedia</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>Pasang pembaruan ...</translation>
    </message>
</context>
</TS>