<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>一些包可以更新</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>运行更新脚本</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>要安装更新，您需要以管理员身份重新启动应用</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>有可用更新</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>一些包可以更新</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>自动检查所选包的更新</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># 以下的包可以通过conda更新：</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># 以下的包可以通过pip更新：</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>一些包可以更新。点击工具栏中的更新器图标以查看可用的更新</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>点击查看可用更新</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>安装更新...</translation>
    </message>
</context>
</TS>