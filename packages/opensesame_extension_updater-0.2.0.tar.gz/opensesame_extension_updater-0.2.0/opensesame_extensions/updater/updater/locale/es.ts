<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>Algunos paquetes se pueden actualizar</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>Ejecutar script de actualización</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>Para instalar las actualizaciones, necesitas reiniciar la aplicación como Administrador</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>Actualizaciones disponibles</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>Algunos paquetes se pueden actualizar</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>Verifica automáticamente las actualizaciones de los paquetes seleccionados</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># Los siguientes paquetes se pueden actualizar a través de conda:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># Los siguientes paquetes se pueden actualizar a través de pip:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>Algunos paquetes se pueden actualizar. Haz clic en el icono de actualización en la barra de herramientas para ver las actualizaciones disponibles</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>Haz clic para ver las actualizaciones disponibles</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>Instala las actualizaciones ..</translation>
    </message>
</context>
</TS>