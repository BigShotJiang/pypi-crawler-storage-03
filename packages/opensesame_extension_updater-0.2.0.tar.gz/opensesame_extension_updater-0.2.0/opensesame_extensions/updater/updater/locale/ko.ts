<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>양식</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>일부 패키지는 업데이트 될 수 있습니다</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>업데이트 스크립트를 실행하십시오</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>업데이트를 설치하려면 어드민으로 응용 프로그램을 재시작해야 합니다</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>업데이트가 있습니다</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>일부 패키지는 업데이트 될 수 있습니다</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>선택한 패키지의 업데이트를 자동으로 확인합니다</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># 다음 패키지는 conda를 통해 업데이트할 수 있습니다:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># 다음 패키지는 pip를 통해 업데이트할 수 있습니다:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>일부 패키지는 업데이트 될 수 있습니다. 사용 가능한 업데이트를 보려면 툴바의 업데이터 아이콘을 클릭하세요</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>사용 가능한 업데이트를 보려면 클릭하세요</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>업데이트를 설치하세요 ...</translation>
    </message>
</context>
</TS>