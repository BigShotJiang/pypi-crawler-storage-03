<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>प्रपत्र</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>कुछ पैकेज अपडेट किए जा सकते हैं</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>अपडेट स्क्रिप्ट चलाएं</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>अद्यतन स्थापित करने के लिए, आपको एडमिनिस्ट्रेटर के रूप में एप्लिकेशन को पुनः आरंभ करने की आवश्यकता है</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>अपडेट उपलब्ध हैं</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>कुछ पैकेज अपडेट किए जा सकते हैं</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>चयनित पैकेजों के अपडेट की स्वचालित जांच करें</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># निम्नलिखित पैकेज को conda के माध्यम से अपडेट किया जा सकता है:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># निम्नलिखित पैकेज को pip के माध्यम से अपडेट किया जा सकता है:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>कुछ पैकेज अपडेट किए जा सकते हैं। उपलब्ध अपडेट देखने के लिए टूलबार में अपडेटर आइकन पर क्लिक करें</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>उपलब्ध अपडेट देखने के लिए क्लिक करें</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>अपडेट स्थापित करें ...</translation>
    </message>
</context>
</TS>