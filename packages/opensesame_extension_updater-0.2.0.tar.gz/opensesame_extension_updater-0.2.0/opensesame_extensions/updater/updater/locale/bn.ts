<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>Form</name>
    <message>
        <location filename="../update_widget.ui" line="14" />
        <source>Form</source>
        <translation>ফর্ম</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="56" />
        <source>Some packages can be updated</source>
        <translation>কিছু প্যাকেজ আপডেট করা যাবে</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="69" />
        <source>Run update script</source>
        <translation>আপডেট স্ক্রিপ্ট চালান</translation>
    </message>
    <message>
        <location filename="../update_widget.ui" line="95" />
        <source>To install the updates, you need to restart the application as Administrator</source>
        <translation>আপডেটগুলি ইনস্টল করতে, আপনাকে অ্যাডমিনিস্ট্রেটর হিসাবে অ্যাপ্লিকেশনটি পুনরায় চালু করতে হবে</translation>
    </message>
</context>
<context>
    <name>extension_updater</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Updates available</source>
        <translation>আপডেট উপলব্ধ</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Some packages can be updated</source>
        <translation>কিছু প্যাকেজ আপডেট করা যাবে</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Automatically checks for updates of selected packages</source>
        <translation>নির্বাচিত প্যাকেজগুলির আপডেট স্বয়ংক্রিয়ভাবে চেক করে</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source># The following packages can be updated through conda:</source>
        <translation># নিম্নলিখিত প্যাকেজগুলি conda এর মাধ্যমে আপডেট করা যেতে পারে:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source># The following packages can be updated through pip:</source>
        <translation># নিম্নলিখিত প্যাকেজগুলি pip এর মাধ্যমে আপডেট করা যেতে পারে:</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Some packages can be updated. Click the updater icon in the toolbar to see available updates</source>
        <translation>কিছু প্যাকেজ আপডেট করা যাবে। উপলভ্য আপডেট দেখতে টুলবারের আপডেটের আইকনে ক্লিক করুন</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Click to see available updates</source>
        <translation>উপলভ্য আপডেট দেখতে ক্লিক করুন</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Install updates …</source>
        <translation>আপডেট ইনস্টল করুন ...</translation>
    </message>
</context>
</TS>