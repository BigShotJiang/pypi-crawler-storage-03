# Pipeline tests for memg_core
