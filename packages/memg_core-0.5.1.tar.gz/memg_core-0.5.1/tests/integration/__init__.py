# Integration tests for memg_core
