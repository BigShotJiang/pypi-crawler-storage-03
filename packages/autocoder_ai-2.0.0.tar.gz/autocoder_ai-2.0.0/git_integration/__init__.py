"""
Git integration for version control management
"""

from .git_manager import GitManager

__all__ = ['GitManager']