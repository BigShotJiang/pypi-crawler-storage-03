"""Module Configuration."""

import os

PACKAGE_PATH = os.path.dirname(os.path.realpath(__file__))
VERSION = "0.0.31"
