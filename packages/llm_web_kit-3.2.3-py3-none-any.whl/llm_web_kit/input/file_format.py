class FileFormatConstant(object):
    MARKDOWN = ['md']
    HTML = ['html']
    TXT = ['txt', 'text']
    PDF = ['pdf']
    EBOOK = ['EBOOK']
