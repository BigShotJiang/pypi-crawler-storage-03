from .calculator import add, subtract,multiply, divide, power

__version__ = "1.0.0"