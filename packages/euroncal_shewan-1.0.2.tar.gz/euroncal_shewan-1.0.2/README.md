# Euron_cal

A simple calculator package for python


'''bash

pip install euroncal-shewan