# pytest-grader

A pytest plugin for scoring programming assignments with points-based grading.

## Features

- Add point values to test functions using the `@points(n)` decorator
- Show a score summmary when running `pytest --score`
- TODO Lock doctests using the `@lock` decorator.
- TODO `python3 pytest-grader --lock [src] [dest]` will generate a copy of src with doctests locked.

## Use

The recommended way to use this pytest plugin is to include `pytest-grader` in the ...

It is also possible to install this with:

```bash
pip install pytest-grader
```


## Usage

### Basic Example

```python
from pytest_grader import points

def square(x):
    return x * x

@points(3)
def test_square_int():
    assert square(3) == 9
    assert square(-4) == 16

@points(2)
def test_square_float():
    assert square(0.5) == 0.25
```

### Configuration

Add to your `conftest.py`:

```python
pytest_plugins = ["pytest_grader"]
```

## How It Works

1. **Decoration**: Use `@points(n)` to assign point values to test functions
2. **Collection**: The plugin automatically detects tests with point values during collection
3. **Execution**: Tests run normally with pytest
4. **Scoring**: Points are awarded for passing tests, zero for failing tests
5. **Summary**: A formatted grade report is displayed after all tests complete

## Sample Output

```
PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
   test_square_int          3/3 pts
   test_square_float        2/2 pts
  L test_twice_function      0/4 pts
                                        
  Total Score: 5/9 pts (55.6%)
```

Perfect scores display with special formatting:
```
  (Total Score: 9/9 pts (=�%)(
```

## Requirements

- Python >= 3.10
- pytest >= 8

## License

This project is licensed under the MIT License.