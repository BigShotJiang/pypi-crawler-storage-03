"""Top-level package for skiba."""

__author__ = """Tara Skiba"""
__email__ = "tskiba@vols.utk.edu"
__version__ = "2.4.0"
