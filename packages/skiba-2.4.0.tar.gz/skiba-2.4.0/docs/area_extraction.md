# area_extraction code

::: skiba.area_extraction