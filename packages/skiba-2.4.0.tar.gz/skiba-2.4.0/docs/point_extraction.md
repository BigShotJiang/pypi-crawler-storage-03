
# point_extraction module

::: skiba.point_extraction