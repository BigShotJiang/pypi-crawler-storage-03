# Usage

To use skiba in a project:

```
import skiba
```
