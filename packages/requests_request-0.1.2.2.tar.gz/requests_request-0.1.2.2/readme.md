# requests request extension.

## Installation

You can install via [pypi](https://pypi.org/project/requests_request/)

```console
pip install -U requests_request
```

## Usage

```python
from requests_request import request
```
