.. _swh-auth:

.. include:: README.rst

Reference Documentation
-----------------------

.. toctree::
   :maxdepth: 2

   cli
   django


.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
