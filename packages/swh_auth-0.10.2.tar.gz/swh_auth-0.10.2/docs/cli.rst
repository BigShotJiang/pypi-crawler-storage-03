.. _swh-auth-cli:

Command-line interface
======================

.. click:: swh.auth.cli:auth
  :prog: swh auth
  :nested: full
