# autopyexec

Run `.py` files directly without typing `python filename.py`.

## Install
```bash
pip install autopyexec
