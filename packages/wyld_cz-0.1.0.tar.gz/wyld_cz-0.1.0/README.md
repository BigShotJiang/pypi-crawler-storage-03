# Wyld Commitezen Repository

A sets of custom rules and templates for commitezen.

You can find more info about commitezen customization with
official [documentation](https://commitizen-tools.github.io/commitizen/customization/)

## Contributing

This repo, so as others, provide in-built development environment.
To install and enable this environment just run `make`.
