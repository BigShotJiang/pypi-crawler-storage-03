# pydroplet

This is a package to interface with the [Droplet](https://shop.hydrificwater.com/pages/buy-droplet) device.
