# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.1
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x08\xc0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
24.853426mm\x22\x0a   \
height=\x2229.09959\
8mm\x22\x0a   viewBox=\
\x220 0 24.853426 2\
9.099598\x22\x0a   ver\
sion=\x221.1\x22\x0a   id\
=\x22svg1\x22\x0a   inksc\
ape:version=\x221.3\
 (0e150ed6c4, 20\
23-07-21)\x22\x0a   so\
dipodi:docname=\x22\
copy_to_clipboar\
d.svg\x22\x0a   xmlns:\
inkscape=\x22http:/\
/www.inkscape.or\
g/namespaces/ink\
scape\x22\x0a   xmlns:\
sodipodi=\x22http:/\
/sodipodi.source\
forge.net/DTD/so\
dipodi-0.dtd\x22\x0a  \
 xmlns=\x22http://w\
ww.w3.org/2000/s\
vg\x22\x0a   xmlns:svg\
=\x22http://www.w3.\
org/2000/svg\x22>\x0a \
 <sodipodi:named\
view\x0a     id=\x22na\
medview1\x22\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#000000\x22\x0a  \
   borderopacity\
=\x220.25\x22\x0a     ink\
scape:showpagesh\
adow=\x222\x22\x0a     in\
kscape:pageopaci\
ty=\x220.0\x22\x0a     in\
kscape:pagecheck\
erboard=\x220\x22\x0a    \
 inkscape:deskco\
lor=\x22#d1d1d1\x22\x0a  \
   inkscape:docu\
ment-units=\x22mm\x22\x0a\
     inkscape:zo\
om=\x221.6017536\x22\x0a \
    inkscape:cx=\
\x22-29.342839\x22\x0a   \
  inkscape:cy=\x221\
13.31331\x22\x0a     i\
nkscape:window-w\
idth=\x221920\x22\x0a    \
 inkscape:window\
-height=\x221137\x22\x0a \
    inkscape:win\
dow-x=\x221912\x22\x0a   \
  inkscape:windo\
w-y=\x22-8\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22layer1\x22\
 />\x0a  <defs\x0a    \
 id=\x22defs1\x22 />\x0a \
 <g\x0a     inkscap\
e:label=\x22Layer 1\
\x22\x0a     inkscape:\
groupmode=\x22layer\
\x22\x0a     id=\x22layer\
1\x22\x0a     transfor\
m=\x22translate(-71\
.731018,-117.893\
09)\x22>\x0a    <rect\x0a\
       style=\x22op\
acity:1;fill:non\
e;stroke:#000000\
;stroke-width:2;\
stroke-dasharray\
:none\x22\x0a       id\
=\x22rect1\x22\x0a       \
width=\x2216.568283\
\x22\x0a       height=\
\x2220.826275\x22\x0a    \
   x=\x2272.731018\x22\
\x0a       y=\x22125.1\
6641\x22 />\x0a    <pa\
th\x0a       style=\
\x22opacity:1;fill:\
#000000;stroke:#\
000000;stroke-wi\
dth:2;stroke-das\
harray:none\x22\x0a   \
    d=\x22m 95.5844\
44,123.79879 v 1\
6.11873 l -15.65\
1524,-0.1168 v -\
20.90763 h 10.16\
1811 z\x22\x0a       i\
d=\x22path1\x22\x0a      \
 sodipodi:nodety\
pes=\x22cccccc\x22 />\x0a\
    <path\x0a      \
 style=\x22opacity:\
1;fill:#000000;s\
troke:#000000;st\
roke-width:2;str\
oke-dasharray:no\
ne\x22\x0a       d=\x22M \
75.695423,131.76\
851 H 81.14648\x22\x0a\
       id=\x22path2\
\x22 />\x0a    <path\x0a \
      style=\x22fil\
l:#000000;stroke\
:#000000;stroke-\
width:2;stroke-d\
asharray:none\x22\x0a \
      d=\x22m 75.77\
4241,137.26849 h\
 5.451057\x22\x0a     \
  id=\x22path2-0\x22 /\
>\x0a    <path\x0a    \
   style=\x22fill:#\
000000;stroke:#0\
00000;stroke-wid\
th:2;stroke-dash\
array:none\x22\x0a    \
   d=\x22m 75.86494\
7,142.76847 h 9.\
085095\x22\x0a       i\
d=\x22path2-0-6\x22 />\
\x0a  </g>\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x06\
\x07\x03}\xc3\
\x00i\
\x00m\x00a\x00g\x00e\x00s\
\x00\x08\
\x08\x86\xe2c\
\x00g\
\x00r\x00a\x00p\x00h\x00i\x00c\x00s\
\x00\x15\
\x0b>\x0e\x07\
\x00c\
\x00o\x00p\x00y\x00_\x00t\x00o\x00_\x00c\x00l\x00i\x00p\x00b\x00o\x00a\x00r\x00d\
\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x12\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00(\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x90\xc0\x1c\xf1\xd7\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
