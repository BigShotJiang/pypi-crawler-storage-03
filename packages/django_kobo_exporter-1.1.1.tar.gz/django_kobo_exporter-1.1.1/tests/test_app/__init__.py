# This package provides a small fake Django app used during tests.
