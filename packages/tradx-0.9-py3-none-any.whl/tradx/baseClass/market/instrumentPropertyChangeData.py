from pydantic import BaseModel, BeforeValidator
from typing_extensions import Annotated
from decimal import Decimal
from datetime import datetime, timedelta
from typing import Any
import json
from enum import Enum


class InstrumentPropertyChangeData(BaseModel): 
    """
    yet to be implemented
    """
    ...
