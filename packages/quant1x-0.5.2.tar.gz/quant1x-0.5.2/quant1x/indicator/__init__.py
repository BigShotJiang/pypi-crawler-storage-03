#!/usr/bin/python
# -*- coding: UTF-8 -*-

from quant1x.indicator.ma1x import *
