#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""
基础工具集
"""

from quant1x.base.series import Series