#!/usr/bin/python
# -*- coding: UTF-8 -*-
from datetime import datetime

d = datetime.today()
datetime.strftime(d,'%Y-%m-%d %H:%M:%S')
