# -*- coding: utf-8 -*-
'''
    :file: __init__.py
    :author: -Farmer
    :url: https://blog.farmer233.top
    :date: 2021/09/02 19:18:47
'''

from .client import SchoolClient, UserClient
from .type import CAPTCHA, KCAPTCHA
