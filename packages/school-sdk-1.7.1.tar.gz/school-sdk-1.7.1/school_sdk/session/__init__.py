# -*- coding: utf-8 -*-
'''
    :file: __init__.py
    :author: -Farmer
    :url: https://blog.farmer233.top
    :date: 2022/02/03 23:54:56
'''

class RedisStorage(object):

    def __init__(self, redis) -> None:
        pass

    def name(self):
        pass