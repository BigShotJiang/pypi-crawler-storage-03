# -*- coding: utf-8 -*-
'''
    :file: __init__.py
    :author: -Farmer
    :url: https://blog.farmer233.top
    :date: 2024/01/12 19:18:47
'''

from .client import CAPTCHA, KCAPTCHA
