from .proxy import main

exit(main())
