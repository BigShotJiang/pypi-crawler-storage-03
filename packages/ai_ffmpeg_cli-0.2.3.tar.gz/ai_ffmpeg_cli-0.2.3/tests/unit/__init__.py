"""Unit tests for ai-ffmpeg-cli.

This package contains unit tests for individual components and functions.
Unit tests focus on testing isolated functionality without external dependencies.
"""
