"""Integration tests for ai-ffmpeg-cli.

This package contains integration tests that verify component interactions.
Integration tests focus on testing how multiple components work together.
"""
