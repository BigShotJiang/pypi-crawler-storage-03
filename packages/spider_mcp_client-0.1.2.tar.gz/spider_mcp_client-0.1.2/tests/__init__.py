# Tests for spider-mcp-client
