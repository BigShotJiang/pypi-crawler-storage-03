# XTrade-AI Framework

[![PyPI version](https://badge.fury.io/py/xtrade-ai.svg)](https://badge.fury.io/py/xtrade-ai)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

A comprehensive reinforcement learning framework for algorithmic trading with enhanced error handling, memory management, and thread safety.

## 🚀 Quick Start

### Installation

```bash
# Install from PyPI
pip install xtrade-ai

# Install with optional dependencies
pip install xtrade-ai[ta,dev,viz,monitor,performance,database,api]

# Or install from source
git clone https://github.com/anasamu/xtrade-ai-framework.git
cd xtrade-ai-framework
pip install -r requirements/base.txt
pip install -e .
```

### Basic Usage

```python
from xtrade_ai import XTradeAIFramework, XTradeAIConfig

# Create configuration
config = XTradeAIConfig()
config.model.baseline_algorithm = "PPO"
config.trading.initial_balance = 10000.0

# Initialize framework
framework = XTradeAIFramework(config)

# Train the model
framework.train(training_data, epochs=100)

# Make predictions
prediction = framework.predict(market_data)
print(f"Action: {prediction['action']}, Confidence: {prediction['confidence']}")
```

### Command Line Interface

```bash
# Check framework health
xtrade-ai health

# Train a model
xtrade-ai train --config config.yaml --data training_data.csv

# Make predictions
xtrade-ai predict --model model.pkl --data market_data.csv

# Run backtesting
xtrade-ai backtest --model model.pkl --data historical_data.csv
```

## 📋 Table of Contents

- [Features](#-features)
- [Project Structure](#-project-structure)
- [Architecture](#-architecture)
- [Installation](#-installation)
- [Configuration](#-configuration)
- [Usage Examples](#-usage-examples)
- [API Reference](#-api-reference)
- [Advanced Features](#-advanced-features)
- [Performance Optimization](#-performance-optimization)
- [Deployment](#-deployment)
- [Docker Images](#-docker-images)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)
- [License](#-license)

## ✨ Features

### 🤖 AI/ML Capabilities
- **Reinforcement Learning**: PPO, DQN, A2C algorithms from Stable-Baselines3
- **Ensemble Learning**: Multi-model predictions with weighted averaging
- **XGBoost Integration**: Gradient boosting for feature selection and prediction
- **Attention Mechanisms**: Transformer-based models for sequence modeling
- **Meta-Learning**: Adaptive learning across different market conditions

### 📊 Trading Features
- **Technical Analysis**: 50+ technical indicators with adaptive parameters
- **Risk Management**: Dynamic position sizing and stop-loss management
- **Portfolio Management**: Multi-asset portfolio optimization
- **Market Simulation**: Realistic market environment simulation
- **Order Management**: Intelligent order placement and execution

### 🔧 Technical Features
- **Thread Safety**: Multi-threaded training and prediction
- **Memory Management**: Automatic memory cleanup and optimization
- **Error Handling**: Comprehensive error handling and recovery
- **Performance Monitoring**: Real-time performance metrics
- **Model Persistence**: Save/load models with versioning

### 🛠️ Development Features
- **Modular Design**: Pluggable modules for easy customization
- **Configuration Management**: YAML/JSON configuration support
- **CLI Interface**: Command-line tools for all operations

## 📁 Project Structure

```
xtrade-ai/
├── docker/           # Docker configurations and images
│   ├── Dockerfile
│   ├── Dockerfile.minimal
│   ├── Dockerfile.pypi
│   ├── Dockerfile.robust
│   ├── Dockerfile.simple
│   └── docker-compose.yml
├── scripts/          # Build and deployment scripts
│   ├── build/        # Build and packaging scripts
│   ├── deploy/       # Deployment scripts
│   ├── clean/        # Cleanup scripts
│   ├── Makefile      # Linux/macOS build commands
│   └── build.ps1     # Windows PowerShell build commands
├── config/           # Configuration files
│   ├── env.example   # Environment variables template
│   ├── init.sql      # Database initialization
│   ├── nginx.conf    # Nginx configuration
│   └── prometheus.yml # Prometheus monitoring
├── requirements/     # Python dependencies
│   ├── base.txt      # Core dependencies
│   ├── dev.txt       # Development dependencies
│   ├── docs.txt      # Documentation dependencies
│   ├── minimal.txt   # Minimal dependencies
│   ├── docker.txt    # Docker dependencies
│   └── docker-pypi.txt # PyPI Docker dependencies
├── xtrade_ai/        # Main package source code
├── test/             # Test suite
├── docs/             # Documentation
├── models/           # Trained models storage
├── logs/             # Application logs
└── flow/             # Flow diagrams and documentation
```

### Quick Commands

```bash
# Using Makefile (Linux/macOS)
cd scripts
make install
make build
make deploy

# Using PowerShell (Windows)
cd scripts
.\build.ps1 install
.\build.ps1 build
.\build.ps1 deploy
```
- **Logging**: Comprehensive logging with multiple levels
- **Testing**: Built-in testing and validation tools

## 🏗️ Architecture

### Core Components

```
XTrade-AI Framework
├── Core Framework (xtrade_ai_framework.py)
├── Configuration Management (config.py)
├── Data Processing (data_preprocessor.py)
├── Base Environment (base_environment.py)
├── CLI Interface (cli.py)
└── Modules/
    ├── Action Selection (action_selector.py)
    ├── Baseline3 Integration (baseline3_integration.py)
    ├── Risk Management (risk_management.py)
    ├── Technical Analysis (technical_analysis.py)
    ├── XGBoost Module (xgboost_module.py)
    ├── Monitoring (monitoring.py)
    ├── Meta Learning (meta_learning.py)
    └── Optimization (optimization.py)
```

### Data Flow

```
Market Data → Data Preprocessor → Feature Engineering → Model Ensemble → Trading Decision
     ↓              ↓                    ↓                ↓              ↓
Technical    Risk Assessment    Model Validation    Action Selection   Order Execution
Indicators   Position Sizing    Performance Check   Confidence Score   Portfolio Update
```

## 📦 Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager
- Git (for development)

### Basic Installation

```bash
# Install from PyPI
pip install xtrade-ai
```

### Advanced Installation

```bash
# Install with all optional dependencies
pip install xtrade-ai[all]

# Install specific feature sets
pip install xtrade-ai[ta]      # Technical analysis
pip install xtrade-ai[dev]      # Development tools
pip install xtrade-ai[viz]      # Visualization
pip install xtrade-ai[monitor]  # Monitoring
pip install xtrade-ai[api]      # API server
```

### Docker Installation

```bash
# Pull from Docker Hub
docker pull anasamu7/xtrade-ai:latest

# Run container
docker run -it anasamu7/xtrade-ai:latest xtrade-ai --help
```

## ⚙️ Configuration

### Basic Configuration

```python
from xtrade_ai import XTradeAIConfig

# Create default configuration
config = XTradeAIConfig()

# Customize model parameters
config.model.baseline_algorithm = "PPO"
config.model.learning_rate = 3e-4
config.model.batch_size = 64

# Customize trading parameters
config.trading.initial_balance = 10000.0
config.trading.commission_rate = 0.001
config.trading.max_position_size = 0.1
```

### Configuration File (YAML)

```yaml
# config.yaml
model:
  baseline_algorithm: "PPO"
  learning_rate: 3e-4
  batch_size: 64
  state_dim: 545
  action_dim: 4
  enable_xgboost: true
  enable_risk_management: true

trading:
  initial_balance: 10000.0
  commission_rate: 0.001
  max_position_size: 0.1
  stop_loss_pct: 0.02
  take_profit_pct: 0.05

data:
  lookback_window: 100
  feature_columns: ["open", "high", "low", "close", "volume"]
  target_column: "returns"
  train_split: 0.8
  validation_split: 0.1

training:
  epochs: 100
  batch_size: 64
  validation_freq: 10
  save_freq: 50
  early_stopping_patience: 10
```

### Environment Variables

```bash
# Set environment variables
export XTRADE_AI_LOG_LEVEL=INFO
export XTRADE_AI_DATA_DIR=/path/to/data
export XTRADE_AI_MODEL_DIR=/path/to/models
export XTRADE_AI_CONFIG_FILE=/path/to/config.yaml
```

## 📚 Usage Examples

### Basic Training

```python
from xtrade_ai import XTradeAIFramework, XTradeAIConfig
import pandas as pd

# Load data
data = pd.read_csv('market_data.csv')

# Create configuration
config = XTradeAIConfig()
config.model.baseline_algorithm = "PPO"

# Initialize framework
framework = XTradeAIFramework(config)

# Train model
framework.train(data, epochs=100, validation_split=0.2)

# Save model
framework.save_model('trained_model.pkl')
```

### Advanced Training with Custom Environment

```python
from xtrade_ai import XTradeAIFramework, XTradeAIConfig, BaseEnvironment

class CustomTradingEnvironment(BaseEnvironment):
    def __init__(self, data, config):
        super().__init__(data, config)
        # Add custom logic here
    
    def step(self, action):
        # Custom step logic
        return super().step(action)

# Create custom environment
env = CustomTradingEnvironment(data, config)

# Train with custom environment
framework.train_with_environment(env, epochs=100)
```

### Ensemble Prediction

```python
# Enable ensemble learning
config.model.enable_ensemble = True
config.model.ensemble_method = "weighted_average"

# Initialize framework
framework = XTradeAIFramework(config)

# Train multiple models
framework.train_ensemble(data, models=['PPO', 'DQN', 'XGBoost'])

# Make ensemble prediction
prediction = framework.predict_ensemble(market_data)
print(f"Ensemble Action: {prediction['action']}")
print(f"Confidence: {prediction['confidence']}")
print(f"Model Weights: {prediction['weights']}")
```

### Real-time Trading

```python
import time
from xtrade_ai import XTradeAIFramework

# Load trained model
framework = XTradeAIFramework.load_model('trained_model.pkl')

# Real-time prediction loop
while True:
    # Get latest market data
    market_data = get_latest_market_data()
    
    # Make prediction
    prediction = framework.predict(market_data)
    
    # Execute trade based on prediction
    if prediction['confidence'] > 0.7:
        execute_trade(prediction['action'])
    
    time.sleep(60)  # Wait 1 minute
```

### Backtesting

```python
from xtrade_ai import XTradeAIFramework

# Load trained model
framework = XTradeAIFramework.load_model('trained_model.pkl')

# Run backtest
results = framework.backtest(
    historical_data,
    initial_balance=10000.0,
    commission_rate=0.001
)

# Print results
print(f"Total Return: {results['total_return']:.2%}")
print(f"Sharpe Ratio: {results['sharpe_ratio']:.2f}")
print(f"Max Drawdown: {results['max_drawdown']:.2%}")
print(f"Win Rate: {results['win_rate']:.2%}")
```

## 🔌 API Reference

### Core Classes

#### XTradeAIFramework

Main framework class that orchestrates all components.

```python
class XTradeAIFramework:
    def __init__(self, config: XTradeAIConfig)
    def train(self, data: pd.DataFrame, epochs: int = 100) -> Dict
    def predict(self, data: pd.DataFrame) -> Dict
    def backtest(self, data: pd.DataFrame) -> Dict
    def save_model(self, path: str) -> None
    def load_model(self, path: str) -> 'XTradeAIFramework'
```

#### XTradeAIConfig

Configuration management class.

```python
class XTradeAIConfig:
    def __init__(self, config_file: str = None)
    def to_dict(self) -> Dict
    def from_dict(self, config_dict: Dict) -> None
    def save(self, path: str) -> None
    def load(self, path: str) -> None
```

#### DataPreprocessor

Data preprocessing and feature engineering.

```python
class DataPreprocessor:
    def __init__(self, config: XTradeAIConfig)
    def preprocess(self, data: pd.DataFrame) -> pd.DataFrame
    def add_technical_indicators(self, data: pd.DataFrame) -> pd.DataFrame
    def normalize_features(self, data: pd.DataFrame) -> pd.DataFrame
```

### Data Structures

#### TradingDecision

```python
@dataclass
class TradingDecision:
    action: ActionType
    confidence: float
    timestamp: datetime
    market_state: MarketState
    risk_assessment: RiskAssessment
```

#### MarketState

```python
@dataclass
class MarketState:
    price: float
    volume: float
    technical_indicators: Dict[str, float]
    market_sentiment: float
    volatility: float
```

#### Portfolio

```python
@dataclass
class Portfolio:
    balance: float
    positions: Dict[str, Position]
    total_value: float
    pnl: float
    risk_metrics: Dict[str, float]
```

## 🚀 Advanced Features

### Meta-Learning

```python
# Enable meta-learning
config.model.enable_meta_learning = True
config.model.meta_learning_rate = 0.01

# Train with meta-learning
framework.train_with_meta_learning(
    training_data,
    meta_data,
    epochs=100
)
```

### Custom Reward Functions

```python
def custom_reward_function(state, action, next_state, reward):
    # Add custom reward logic
    custom_reward = reward * 1.5  # Amplify rewards
    return custom_reward

# Set custom reward function
framework.set_reward_function(custom_reward_function)
```

### Multi-Asset Trading

```python
# Configure multi-asset trading
config.trading.assets = ['BTC/USD', 'ETH/USD', 'AAPL', 'GOOGL']
config.trading.correlation_threshold = 0.7

# Train multi-asset model
framework.train_multi_asset(data_dict, epochs=100)
```

### Real-time Monitoring

```python
# Enable monitoring
config.monitoring.enable_real_time = True
config.monitoring.metrics = ['sharpe_ratio', 'max_drawdown', 'win_rate']

# Start monitoring
framework.start_monitoring()

# Get real-time metrics
metrics = framework.get_monitoring_metrics()
```

## ⚡ Performance Optimization

### Memory Optimization

```python
# Enable memory optimization
config.performance.enable_memory_optimization = True
config.performance.max_memory_usage = 0.8

# Use memory-efficient training
framework.train_memory_efficient(data, epochs=100)
```

### Parallel Processing

```python
# Enable parallel processing
config.performance.enable_parallel = True
config.performance.num_workers = 4

# Train with parallel processing
framework.train_parallel(data, epochs=100)
```

### GPU Acceleration

```python
# Enable GPU acceleration
config.performance.enable_gpu = True
config.performance.gpu_memory_fraction = 0.8

# Train on GPU
framework.train_gpu(data, epochs=100)
```

## 🐛 Troubleshooting

### Common Issues

#### Import Errors

```bash
# Check dependencies
xtrade-ai health

# Install missing dependencies
pip install -r requirements.txt
```

#### Memory Issues

```python
# Reduce batch size
config.model.batch_size = 32

# Enable memory cleanup
config.performance.enable_memory_cleanup = True
```

#### Training Issues

```python
# Check data quality
framework.validate_data(data)

# Adjust learning rate
config.model.learning_rate = 1e-4

# Enable early stopping
config.training.early_stopping_patience = 5
```

### Debug Mode

```python
# Enable debug mode
import logging
logging.basicConfig(level=logging.DEBUG)

# Run with debug information
framework.train(data, epochs=100, debug=True)
```

### Performance Profiling

```python
# Enable performance profiling
config.performance.enable_profiling = True

# Profile training
framework.train_with_profiling(data, epochs=100)
```

## 🚀 Deployment

XTrade-AI framework supports automated deployment via GitHub Actions with PyPI package publishing and Docker image deployment.

### Automated Deployment

The framework uses GitHub Actions for continuous deployment:

- **PyPI Publishing**: Automatic package publishing to PyPI
- **Docker Images**: Multiple optimized Docker images
- **Smart Triggers**: Only deploys when relevant code changes
- **Quality Assurance**: Comprehensive testing and validation

### Quick Deployment

```bash
# Deploy to PyPI (requires credentials)
pip install build twine
python -m build --wheel --sdist
twine upload dist/*

# Deploy Docker images
docker build -f Dockerfile.pypi -t xtrade-ai:pypi .
docker build -f Dockerfile.minimal -t xtrade-ai:minimal .
docker push your-username/xtrade-ai:pypi
```

For detailed deployment information, see [DEPLOYMENT.md](DEPLOYMENT.md).

## 🐳 Docker Images

XTrade-AI provides multiple Docker images optimized for different use cases:

### Available Images

| Image Type | Size | Use Case | Features |
|------------|------|----------|----------|
| **PyPI** | Medium | Production | PyPI package, optimized |
| **Minimal** | Small | Resource-constrained | Essential features only |
| **Optimized** | Medium | General production | Balanced optimization |
| **Robust** | Large | High-reliability | Error handling, fallbacks |

### Quick Start with Docker

```bash
# Pull latest image
docker pull anasamu7/xtrade-ai:latest

# Run with data volumes
docker run -it \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/models:/app/models \
  anasamu7/xtrade-ai:latest \
  xtrade-ai --help

# Use specific image type
docker run -it anasamu7/xtrade-ai:minimal xtrade-ai --help
```

For detailed Docker information, see [DOCKER_IMAGES.md](DOCKER_IMAGES.md).

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup

```bash
# Clone repository
git clone https://github.com/anasamu/xtrade-ai-framework.git
cd xtrade-ai-framework

# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run linting
black xtrade_ai/
isort xtrade_ai/
flake8 xtrade_ai/
```

### Code Style

- Follow PEP 8 style guidelines
- Use type hints for all functions
- Write comprehensive docstrings
- Add unit tests for new features

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Stable-Baselines3](https://github.com/DLR-RM/stable-baselines3) for RL algorithms
- [Gymnasium](https://github.com/Farama-Foundation/Gymnasium) for environment interface
- [XGBoost](https://github.com/dmlc/xgboost) for gradient boosting
- [Pandas](https://pandas.pydata.org/) for data manipulation
- [NumPy](https://numpy.org/) for numerical computing

## 📞 Support

- **Documentation**: [https://xtrade-ai-framework.readthedocs.io/en/latest/](https://xtrade-ai-framework.readthedocs.io/en/latest/)
- **Issues**: [GitHub Issues](https://github.com/anasamu/xtrade-ai-framework/issues)
- **Email**: anasamu7@gmail.com

## 🔄 Changelog

See [CHANGELOG.md](CHANGELOG.md) for a detailed history of changes.

---

**Disclaimer**: This framework is for educational and research purposes. Trading involves risk, and past performance does not guarantee future results. Always perform thorough testing before using in live trading.