from .paraphase import Paraphase


def main():
    app = Paraphase()
    app.run()


if __name__ == "__main__":
    main()
