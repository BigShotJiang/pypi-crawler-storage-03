1.  Go to **Events** and choose an event or create a new one.
2.  Enable **Forbid Duplicates**.
3.  Go to **Attendees**.
4.  Create a new attendee.
5.  If you try to fill successive attendees with the same contact filled
    out in the "Attendee Partner" field, the system won't allow it. That
    can happen for example if the same email is used several times.
