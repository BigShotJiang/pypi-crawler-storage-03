#ifndef GREETER_H
#define GREETER_H

// Function prototype for getting the greeting string.
const char* get_greeting();

#endif // GREETER_H
