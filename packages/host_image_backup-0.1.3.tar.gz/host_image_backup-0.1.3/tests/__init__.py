"""Test initialization module"""
