# Online feature store (ONFS)
Creation of online tables, and retrieval of features
