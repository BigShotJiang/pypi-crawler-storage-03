from src.odoo_runbot.cli import diag_print

if __name__ == "__main__":
    diag_print()
