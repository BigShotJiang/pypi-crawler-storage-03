"""
Tests for Vector Store Client.

This package contains unit tests, integration tests, and test utilities
for the Vector Store client.

Author: Vasily Zdanovskiy
Email: vasilyvz@gmail.com
License: MIT
Version: 1.0.0
""" 