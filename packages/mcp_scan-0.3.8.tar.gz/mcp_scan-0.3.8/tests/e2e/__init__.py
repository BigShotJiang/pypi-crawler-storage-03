"""End-to-end tests package for mcp-scan."""
