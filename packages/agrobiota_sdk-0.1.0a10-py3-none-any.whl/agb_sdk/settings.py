DEFAULT_TAXONOMY_URL = "https://dev.api.agrobiota.biotrop.agr.br/v8/biotax/taxids"

DEFAULT_CONNECTION_STRING_HEADER = "x-mycelium-connection-string"

DEFAULT_CUSTOMERS_API_URL = "https://dev.api.agrobiota.biotrop.agr.br/v8/customers-api"
