from enum import Enum


class Locale(Enum):
    PT_BR = "pt-br"
