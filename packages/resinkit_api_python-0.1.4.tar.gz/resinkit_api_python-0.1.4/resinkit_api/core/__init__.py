"""Core functionality module."""
