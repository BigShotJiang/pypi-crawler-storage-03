# SimpleVibe

A Python library that interfaces with Llama LLM for various text-based operations.

## Installation

```bash
pip install simplevibe
```

## Usage

### As a library

```python
from simplevibe.core import oddVibes

# Use AI powered tool to check if a number is odd
result = oddVibes(42)
print(f"Is 42 odd? {result}")  # Is 42 odd? False
```

### From the command line

After installation, you can use the `simplevibe` command:

```bash
# Show the greeting
simplevibe

# Check if a number is odd
simplevibe oddVibes 42
```

## Requirements

- Python 3.7 or higher
- A running Llama LLM server (default: http://127.0.0.1:42069)

## Development

### Setup

Clone the repository and install in development mode:

```bash
git clone https://github.com/bomxacalaka/simplevibe.git
cd simplevibe
pip install -e .
```

### Running Tests

```bash
python -m unittest discover tests
```

## Building and Publishing

To build and publish to PyPI:

```bash
# Install build tools
pip install build twine

# Build the package
python -m build

# Upload to PyPI (you'll need PyPI credentials)
twine upload dist/*
```

## License

MIT
