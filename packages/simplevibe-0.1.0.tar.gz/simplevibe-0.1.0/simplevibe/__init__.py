"""
simpleVibe - A simple Python library

This is the main package file for simpleVibe.
"""

__version__ = '0.1.0'
