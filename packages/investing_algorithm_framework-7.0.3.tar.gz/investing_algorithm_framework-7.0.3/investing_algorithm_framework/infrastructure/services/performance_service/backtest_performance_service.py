class BacktestPerformanceService:
    pass
