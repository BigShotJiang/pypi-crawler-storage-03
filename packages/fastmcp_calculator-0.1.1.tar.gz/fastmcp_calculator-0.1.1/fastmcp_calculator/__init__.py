"""
FastMCP Calculator - 一个基于FastMCP的简单计算器包
"""

__version__ = "0.1.0"