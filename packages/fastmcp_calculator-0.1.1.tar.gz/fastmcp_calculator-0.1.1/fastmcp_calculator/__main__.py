"""
FastMCP Calculator 包的入口点
"""


from fastmcp_calculator.calculator import main

if __name__ == "__main__":
    main()