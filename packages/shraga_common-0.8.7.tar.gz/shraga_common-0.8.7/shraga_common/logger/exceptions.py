class ShragaException(Exception):
    pass
