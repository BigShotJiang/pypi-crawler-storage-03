from enum import StrEnum


class Execution(StrEnum):
    SYNC = "sync"
    ASYNC = "async"
