def test_import() -> None:
    import pastas as ps

    assert ps is not None
