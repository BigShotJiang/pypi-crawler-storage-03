"""
Common utilities for Django applications.
"""
