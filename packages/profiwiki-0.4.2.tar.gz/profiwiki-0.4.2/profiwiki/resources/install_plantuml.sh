#!/bin/bash
# install plantuml
# WF 2023-05-01
apt-get update
apt-get install -y plantuml