from enum import IntEnum, auto


class ThotWordAlignmentModelType(IntEnum):
    FAST_ALIGN = auto()
    IBM1 = auto()
    IBM2 = auto()
    HMM = auto()
    IBM3 = auto()
    IBM4 = auto()
