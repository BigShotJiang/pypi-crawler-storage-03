"""Tests for ModelScope MCP Server."""
