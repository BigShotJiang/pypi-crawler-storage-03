1. Create or edit a product, and enable the option "Create FSM Order" in its configuration.

2. Create a Sales Order (SO) that includes this product.

3. Confirm the Sales Order.

4. Navigate to the FSM Order from the Sales Order or via the Field Service menu.

5. In the FSM Order form view, you will see a "Sign" button.

6. Click the button to capture the customer's signature. The signature will be saved on both the FSM Order and the linked Sales Order.
