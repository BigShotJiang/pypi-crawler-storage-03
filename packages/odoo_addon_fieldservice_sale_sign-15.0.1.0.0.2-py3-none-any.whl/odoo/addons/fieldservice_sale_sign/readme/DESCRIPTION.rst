This module allows you to sign a sale order from the field service app.
This is useful for workers who need to get customer approval on-site before proceeding with the work.
