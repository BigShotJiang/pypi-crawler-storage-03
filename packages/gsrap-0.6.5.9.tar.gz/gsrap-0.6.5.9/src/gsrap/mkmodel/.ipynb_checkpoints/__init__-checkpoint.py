from .mkmodel import main


def mkmodel_command(args, logger):
    return main(args, logger)