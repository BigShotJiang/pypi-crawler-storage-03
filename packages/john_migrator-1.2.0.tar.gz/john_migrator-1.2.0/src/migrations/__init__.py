"""
Migration framework for DB Migrator
"""

from .base_migration import BaseMigration

__all__ = ["BaseMigration"]
