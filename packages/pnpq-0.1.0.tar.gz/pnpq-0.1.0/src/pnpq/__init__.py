"""Python library to control hardware used in quantum optical testbeds."""
