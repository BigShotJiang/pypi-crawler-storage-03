# print9 package initialization

from .main import print9

__all__ = ["print9"]
