This module adds a generic wizard + methods to import payment return
file formats.

It's a base to be extended by another modules though it allows to import
a csv that will process the return payments on it.

Multiple payment return files contained in a zip are also supported.
