Under *Invoicing \> Customers* there is available a new menu called
*Import Payment Return* that drives to a wizard that allows to upload a
csv with that has to have the following columns (\* for required):

    account_number
    name *
    date *
    amount *
    unique_import_id *
    concept
    reason_code
    reason
    partner_name
    reference
