
# tempicoDevice.measure()