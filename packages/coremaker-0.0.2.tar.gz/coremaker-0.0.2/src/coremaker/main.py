def cli():
  print("First hello from Coremaker!")
  if __name__ == "__main__":
    cli()