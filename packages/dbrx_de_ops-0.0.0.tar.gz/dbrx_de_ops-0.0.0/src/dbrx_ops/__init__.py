"""entry point for the dbrx_ops package."""

from .monitoring.logger import configure_logger

configure_logger()
