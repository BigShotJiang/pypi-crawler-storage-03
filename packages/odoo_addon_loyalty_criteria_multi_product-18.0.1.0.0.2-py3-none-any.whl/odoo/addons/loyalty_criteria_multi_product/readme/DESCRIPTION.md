Base module that allows to define complex rules on products to fulfill
the conditions of a loyalty program, so for a given set of products we
could define a minimum quantity and another for others, being all those
criterias mandatory for the program to be applied.
