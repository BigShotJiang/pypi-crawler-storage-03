# yeti-python

Python client for the Yeti v2 API

[![Unit tests](https://github.com/yeti-platform/yeti-python/actions/workflows/unittests.yml/badge.svg)](https://github.com/yeti-platform/yeti-python/actions/workflows/unittests.yml)
