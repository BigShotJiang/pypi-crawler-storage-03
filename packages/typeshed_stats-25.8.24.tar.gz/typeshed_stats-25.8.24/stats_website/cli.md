---
hide:
  - footer
  - navigation
---

To install the CLI, simply run `pip install typeshed-stats[rich]`.

```console
{{ cli_help }}
```
