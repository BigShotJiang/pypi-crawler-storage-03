# static: autoload
class Counter:
    pass
