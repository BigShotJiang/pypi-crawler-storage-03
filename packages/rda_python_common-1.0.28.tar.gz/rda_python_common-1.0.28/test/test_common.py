# test_hello_world.py

import pytest



def test_common():
    import rda_python_common.PgCMD
    import rda_python_common.PgDBI
    import rda_python_common.PgFile
    import rda_python_common.PgLock
    import rda_python_common.PgLOG
    import rda_python_common.PgOPT
    import rda_python_common.PgSIG
    import rda_python_common.PgSplit
    import rda_python_common.PgUtil
