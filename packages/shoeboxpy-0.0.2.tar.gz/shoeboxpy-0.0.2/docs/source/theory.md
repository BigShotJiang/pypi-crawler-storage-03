# Theory

```{include} ../theory.md
:relative-docs: ./
:relative-images: ../assets/
```
