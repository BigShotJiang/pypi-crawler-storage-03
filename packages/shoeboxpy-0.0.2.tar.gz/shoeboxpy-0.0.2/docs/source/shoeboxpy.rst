shoeboxpy package
=================

Submodules
----------

shoeboxpy.model3dof module
--------------------------

.. automodule:: shoeboxpy.model3dof
   :members:
   :show-inheritance:

shoeboxpy.model6dof module
--------------------------

.. automodule:: shoeboxpy.model6dof
   :members:
   :show-inheritance:

shoeboxpy.utils module
----------------------

.. automodule:: shoeboxpy.utils
   :members:
   :show-inheritance:

Module contents
---------------

.. automodule:: shoeboxpy
   :members:
   :show-inheritance:
