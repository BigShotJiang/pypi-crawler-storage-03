# Code and demo for iLAMP and NNinv

run `demo.ipynb` to see the demo.

It also shows a visual evaluation using MNIST dataset

