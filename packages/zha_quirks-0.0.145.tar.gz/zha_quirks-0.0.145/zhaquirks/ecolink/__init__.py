"""Module for Ecolink quirks implementations."""
