"""Yale module for custom device handlers."""
