"""Module for WAXMAN devices as remote sensors."""

WAXMAN = "WAXMAN"
