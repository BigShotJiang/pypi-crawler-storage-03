"""Quirks for diy devices or with custom firmware."""
