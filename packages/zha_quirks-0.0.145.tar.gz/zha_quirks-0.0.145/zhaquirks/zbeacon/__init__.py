"""zbeacon module."""
