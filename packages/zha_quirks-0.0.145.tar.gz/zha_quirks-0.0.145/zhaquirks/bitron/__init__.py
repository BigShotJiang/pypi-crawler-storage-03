"""Bitron/SMaBiT module."""

BITRON = "Bitron Home"
