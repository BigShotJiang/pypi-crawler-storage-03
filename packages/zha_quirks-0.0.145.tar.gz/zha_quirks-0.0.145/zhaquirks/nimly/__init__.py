"""Nimly module."""

NIMLY = "Onesti Products AS"
