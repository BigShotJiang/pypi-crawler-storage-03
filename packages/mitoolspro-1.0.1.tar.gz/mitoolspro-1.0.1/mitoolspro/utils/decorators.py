import inspect
import math
import warnings
from functools import wraps
from multiprocessing import Pool
from multiprocessing.pool import ThreadPool
from typing import Any, Callable, Iterable, Optional

from pandas import DataFrame
from tqdm import tqdm

from mitoolspro.exceptions import ArgumentTypeError, ArgumentValueError
from mitoolspro.utils.dev_object import store_dev_var
from mitoolspro.utils.functions import iterable_chunks


def parallel(
    n_threads: int,
    chunk_size: Optional[int] = None,
    use_threads: bool = False,
):
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(iterable: Iterable, *args, **kwargs):
            items = list(iterable)
            total_items = len(items)
            if n_threads <= 1 or total_items <= 1:
                return func(items, *args, **kwargs)

            nonlocal chunk_size
            if chunk_size is None:
                chunk_size = math.ceil(total_items / n_threads)

            chunks = list(iterable_chunks(items, chunk_size))
            PoolType = ThreadPool if use_threads else Pool
            results = []

            with PoolType(processes=n_threads) as pool:
                async_results = [
                    pool.apply_async(func, (chunk, *args), kwargs) for chunk in chunks
                ]
                for i, async_result in enumerate(
                    tqdm(async_results, total=len(chunks))
                ):
                    try:
                        result = async_result.get()
                        if not hasattr(result, "__iter__"):
                            raise TypeError(
                                f"Expected iterable return for chunk {i}, got {type(result)}"
                            )
                        results.append(result)
                    except Exception as e:
                        raise RuntimeError(f"Error in chunk {i}: {e}") from e

            return [item for sublist in results for item in sublist]

        return wrapper

    return decorator


def suppress_user_warning(func: Callable):
    @wraps(func)
    def wrapper(*args, **kwargs):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=UserWarning)
            return func(*args, **kwargs)

    return wrapper


def validate_args_types(**type_hints):
    def decorator(func):
        signature = inspect.signature(func)

        @wraps(func)
        def wrapper(*args, **kwargs):
            bound_args = signature.bind(*args, **kwargs)
            bound_args.apply_defaults()  # Applies default values to missing arguments

            for name, expected_type in type_hints.items():
                if name in bound_args.arguments:
                    value = bound_args.arguments[name]
                else:
                    raise ArgumentValueError(
                        f"Argument '{name}' not found in function signature"
                    )

                if not isinstance(value, expected_type):
                    raise ArgumentTypeError(
                        f"Argument '{name}' must be of type {expected_type.__name__}"
                    )

            return func(*args, **kwargs)

        return wrapper

    return decorator


def validate_dataframe_structure(
    dataframe_name: str,
    validation: Callable[[DataFrame, Any], None],
    *validation_args,
    **validation_kwargs,
):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            dataframe = kwargs.get(dataframe_name, None)
            if dataframe is None:
                raise ArgumentValueError(
                    f"Dataframe argument '{dataframe}' is missing."
                )
            if not isinstance(dataframe, DataFrame):
                raise ArgumentTypeError(f"Argument '{dataframe}' must be a DataFrame.")
            validation(
                dataframe,
                *validation_args,
                **validation_kwargs,
            )
            return func(*args, **kwargs)

        return wrapper

    return decorator


def cached_property(func):
    name = func.__name__
    doc = func.__doc__

    def getter(self):
        try:
            return self.__dict__[name]
        except KeyError:
            value = self.__dict__[name] = func(self)
            return value

    getter.__name__ = name
    getter.__doc__ = doc
    return property(getter)


def store_signature_in_dev(func: Callable):
    @wraps(func)
    def wrapper(*args, **kwargs):
        signature = inspect.signature(func)
        bound_args = signature.bind(*args, **kwargs)
        bound_args.apply_defaults()
        args_dict = dict(bound_args.arguments)
        store_dev_var(func.__name__, args_dict)
        return func(*args, **kwargs)

    return wrapper
