from mitoolspro.document.fonts.fonts import register_fonts, select_font
