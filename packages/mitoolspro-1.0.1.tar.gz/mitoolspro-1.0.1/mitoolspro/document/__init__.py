from mitoolspro.document.from_pdf import pdf_to_document
