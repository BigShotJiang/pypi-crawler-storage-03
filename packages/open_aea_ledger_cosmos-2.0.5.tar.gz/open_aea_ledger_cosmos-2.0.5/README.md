# Cosmos crypto plug-in

Cosmos crypto plug-in for the AEA framework.

## Install

``` bash
python setup.py install
```

## Run tests

``` bash
python setup.py test
```
