from mosamatic.pipelines.pipeline import Pipeline
from mosamatic.pipelines.defaultpipeline import DefaultPipeline