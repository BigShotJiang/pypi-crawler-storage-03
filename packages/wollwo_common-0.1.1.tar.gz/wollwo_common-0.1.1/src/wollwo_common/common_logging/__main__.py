"""
Copyright (c) 2025 by Michal Perzel. All rights reserved.

License: MIT
"""

if __name__ == '__main__':
    print("This is not meant to be run with <python -m package>")
    raise NotImplementedError
