# WOLLWO COMMON

```TEXT
Copyright (c) 2025 by Michal Perzel. All rights reserved.

License: MIT
```

## CUSTOM_LOGGING
preparing doc...

## WOLLWO_DECORATORS
preparing doc...
