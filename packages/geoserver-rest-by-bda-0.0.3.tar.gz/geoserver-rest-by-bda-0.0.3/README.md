# Python wrapper for GeoServer REST API by BalabanovDA

The `geoserver-rest-by-bda` its a fork of [geoserver-rest](https://pypi.org/project/geoserver-rest/)
library made for internal use with some changes.
