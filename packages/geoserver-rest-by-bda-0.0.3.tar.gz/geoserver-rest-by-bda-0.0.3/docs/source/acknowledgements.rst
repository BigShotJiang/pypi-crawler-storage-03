Acknowledgements
================

Created and managed by `Tek Bahadur Kshetri <https://github.com/iamtekson>`_ for the activities of the Geoinformatics Center of Asian Institute of Technology, Thailand.
