.. geoserver-rest documentation master file, created by
   sphinx-quickstart on Wed Mar 10 14:46:38 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to geoserver-rest documentation!
========================================


.. toctree::
   :maxdepth: 2

   about
   installation
   how_to_use
   advanced_uses
   change_log
   license
   contribution
   acknowledgements
   geo

Checkout the video tutorial on geoserver-rest below,

.. raw:: html

    <iframe width="560" height="315" src="https://www.youtube.com/embed/nXvzmbGukeE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
