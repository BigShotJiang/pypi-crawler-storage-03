# This information is located in its own file so that it can be loaded
# without importing the main package when its dependencies are not installed.
# See: https://packaging.python.org/guides/single-sourcing-package-version

__author__ = "Daniil Balabanov"
__email__ = "spacewalrus73@gmail.com"
__version__ = "0.0.3"
