from unique_stock_ticker.clients.six.schema.free_text_search.markets.response import (
    MarketMatchingDescription,
)

__all__ = ["MarketMatchingDescription"]
