Go to the Warehouse and configure which report or attachment to print.
