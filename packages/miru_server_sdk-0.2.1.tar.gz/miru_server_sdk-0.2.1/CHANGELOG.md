# Changelog

## 0.2.1 (2025-08-22)

Full Changelog: [v0.0.1...v0.2.1](https://github.com/miruml/python-server-sdk/compare/v0.0.1...v0.2.1)

### Features

* **api:** update via SDK Studio ([a3202e1](https://github.com/miruml/python-server-sdk/commit/a3202e1c342b2b4871740d5755f98c7391568a6b))
* **api:** update via SDK Studio ([808abb8](https://github.com/miruml/python-server-sdk/commit/808abb81933f8f40bc9693ba587ceeeeebd5bb7b))
* **api:** update via SDK Studio ([5c22d6d](https://github.com/miruml/python-server-sdk/commit/5c22d6d8ee1f5e4eb73cd4a84d2366ba2f8f7a2b))


### Chores

* configure new SDK language ([24c68b0](https://github.com/miruml/python-server-sdk/commit/24c68b06eb9f987361581ea160e29b5be95cba13))
* update SDK settings ([b3672dc](https://github.com/miruml/python-server-sdk/commit/b3672dc0d33501047bab49f9efe2ca0f4b10c63a))
* update SDK settings ([47a4b89](https://github.com/miruml/python-server-sdk/commit/47a4b895060372460a0681376a0fcb18807a6ffb))
