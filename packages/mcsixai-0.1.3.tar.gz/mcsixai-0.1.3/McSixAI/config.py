import os
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = "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"
OPENROUTER_MODEL = "deepseek/deepseek-chat-v3-0324"
SITE_URL = "http://localhost:8000"
SITE_NAME = "CodeAssist AI"