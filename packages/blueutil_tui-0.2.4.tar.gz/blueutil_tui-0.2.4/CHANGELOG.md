# Changelog

## v0.2.4
- Fix Bug with duplicate table entries

## v0.2.3
- Fix device attribute

## v0.2.2
- Fix Bug with duplicate table entries

## v0.2.1
- Change worker methods to use `call_from_thread`

## v0.2.0
- Add search timer, continuous searching resets the timer
- Fix bug that crashed app, when pressing `s` while already searching

## v0.1.1
- Fix thread error from search

## v0.1.0
- Initial published version
