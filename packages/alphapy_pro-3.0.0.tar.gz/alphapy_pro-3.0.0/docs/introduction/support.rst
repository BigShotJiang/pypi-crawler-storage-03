Support
=======

The official channel for support is to open an issue on Github.

http://github.com/ScottFreeLLC/AlphaPy/issues

Follow us on Twitter:

https://twitter.com/scottfreellc?lang=en

Donations
---------

If you like the software, please click on the *Donate* button below:

.. raw:: html

    <embed>
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
    <input type="hidden" name="cmd" value="_s-xclick">
    <input type="hidden" name="hosted_button_id" value="PUTBB68ZXPR26">
    <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
    <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
    </form>
    </embed>

|
|

.. note:: Thank you, we appreciate your generosity. Enjoy the software!
