//! Module for registering rust native stdlib modules.

mod rs;

pub use rs::register;
