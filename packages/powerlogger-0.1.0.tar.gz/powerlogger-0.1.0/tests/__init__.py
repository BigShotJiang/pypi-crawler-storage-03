"""Test package for powerlogger"""
