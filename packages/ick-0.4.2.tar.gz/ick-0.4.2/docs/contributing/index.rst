============
Contributing
============

Guidelines and notes for contributing to ick itself.

.. toctree::
   :hidden:

   guiding_principles
   logging
