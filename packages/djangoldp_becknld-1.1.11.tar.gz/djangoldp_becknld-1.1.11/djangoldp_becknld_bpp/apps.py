from django.apps import AppConfig


class DjangoldpBecknldBapConfig(AppConfig):
    name = "djangoldp_becknld_bap"
