def handle_on_select_activity(activity):
    print("received on_select activity")
    print(activity)
