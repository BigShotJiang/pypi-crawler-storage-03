__version__ = "1.1.11"
name = "djangoldp_becknld"
