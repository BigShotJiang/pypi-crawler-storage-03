"""WOT-PDF API interface."""
