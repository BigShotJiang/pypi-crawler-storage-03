This package provides a copy of the new zope.testbrowser version > 5.0.0 and is
used for experiment with jsonrpc support.
