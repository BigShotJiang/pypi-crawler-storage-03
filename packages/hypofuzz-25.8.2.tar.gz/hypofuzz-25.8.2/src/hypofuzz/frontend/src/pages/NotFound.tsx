export function NotFoundPage() {
  return <h1>Page not found!</h1>
}
