/// <reference types="vite-plugin-svgr/client" />
/// <reference types="vite/types/importMeta.d.ts" />
