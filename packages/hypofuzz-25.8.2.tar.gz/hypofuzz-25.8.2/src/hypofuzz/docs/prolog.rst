.. |in_hypofuzz_run| replace:: :func:`in_hypofuzz_run <hypofuzz.detection.in_hypofuzz_run>`
