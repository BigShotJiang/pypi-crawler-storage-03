API Reference
=============

.. autofunction:: hypofuzz.detection.in_hypofuzz_run
