.. _imprint:

Imprint/Impressum
=================

Privacy policy
--------------
This documentation is hosted on https://readthedocs.org/ whose `privacy
policy <https://docs.readthedocs.io/en/latest/privacy-policy.html>`_ applies.
