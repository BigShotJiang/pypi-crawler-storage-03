"""FlowFoundry: agentic workflow core."""
__version__ = "0.0.1"

def ping() -> str:
    return "flowfoundry: ok"