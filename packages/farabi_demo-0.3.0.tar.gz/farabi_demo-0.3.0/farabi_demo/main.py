# main.py
def hello():
    print("Hello this is Farabi!")
