"""
Sample module for masster.

This module provides the Sample class for handling mass spectrometry data.
"""

from .sample import Sample

__all__ = ["Sample"]
