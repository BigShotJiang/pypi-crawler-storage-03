"""
Library module for masster.

This module provides the Lib class for managing compound libraries and feature annotation.
"""

from .lib import Lib

__all__ = ["Lib"]
