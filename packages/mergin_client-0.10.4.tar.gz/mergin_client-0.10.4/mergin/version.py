# The version is also stored in ../setup.py
__version__ = "0.10.4"

# There seems to be no single nice way to keep version info just in one place:
# https://packaging.python.org/guides/single-sourcing-package-version/
