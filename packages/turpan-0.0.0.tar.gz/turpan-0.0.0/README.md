Turpan | 吐鲁番
