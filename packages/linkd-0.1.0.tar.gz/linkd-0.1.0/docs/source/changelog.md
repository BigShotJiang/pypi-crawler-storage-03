(changelog)=
# Changelog

Here you will find an index of the changelogs for all versions that a changelog is available for.

If you think anything is missing, make a pull request to add it, or contact thomm.o on discord.

----

::::{grid} 1 2 2 2
:gutter: 3

:::{grid-item-card} {material-outlined}`new_releases;2em` Version 0
:link: changelogs/v0-changelog
:link-type: doc

Changelog for current versions - `0.0.0` and newer.
:::
::::

:::{toctree}
:hidden:
:maxdepth: 2

changelogs/v0-changelog
:::
