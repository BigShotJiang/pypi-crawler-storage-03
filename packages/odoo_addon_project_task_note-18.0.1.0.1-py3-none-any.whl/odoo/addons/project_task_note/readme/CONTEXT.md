There's no field where storing general comments and notes not visible to
the customers in the portal
