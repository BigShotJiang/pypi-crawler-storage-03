"""
    This module provides a client library for cloudfoundry_client v2/v3.
"""

__version__ = "1.39.0"
