from .functions import *
def initFuncs(self):
    self.browse_dir = browse_dir
    self.make_params = make_params
    self.start_map = start_map
    self.append_log = append_log
    self.display_map = display_map
    return self
