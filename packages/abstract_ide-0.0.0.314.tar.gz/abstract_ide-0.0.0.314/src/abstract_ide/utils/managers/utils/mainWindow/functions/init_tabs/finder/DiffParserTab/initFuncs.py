from .functions import *
def initFuncs(self):
    self.browse_file = browse_file
    self.preview_patch = preview_patch
    self.save_patch = save_patch
    return self
