<div align="center">

# WayKey

![Image](./docs/assets/WayKey.svg)

![CI](https://github.com/Nmstr/WayKey/actions/workflows/run-ruff.yaml/badge.svg)
![GitHub License](https://img.shields.io/github/license/Nmstr/WayKey)

</div>

WayKey is a wayland automation tool.
