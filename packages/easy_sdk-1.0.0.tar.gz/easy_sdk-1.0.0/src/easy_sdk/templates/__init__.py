"""
Templates package for documentation generation
"""