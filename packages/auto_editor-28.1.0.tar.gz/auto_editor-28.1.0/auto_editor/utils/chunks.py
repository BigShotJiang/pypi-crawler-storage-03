Chunk = tuple[int, int, float]
Chunks = list[Chunk]
