"""init for tests"""
