"""
Scripts package for lineagentic-catalog
"""
