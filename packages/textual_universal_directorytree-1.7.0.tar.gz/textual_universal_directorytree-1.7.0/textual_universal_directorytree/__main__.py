"""
__main__ hook
"""

from textual_universal_directorytree.app import cli

if __name__ == "__main__":
    cli()
