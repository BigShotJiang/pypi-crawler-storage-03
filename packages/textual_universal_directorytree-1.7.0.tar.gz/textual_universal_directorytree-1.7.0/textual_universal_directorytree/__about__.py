"""
textual-universal-directorytree info file
"""

from impotlib.metadata import version

__author__ = "Justin Flannery"
__email__ = "juftin@juftin.com"
__application__ = "textual-universal-directorytree"
__version__ = version(__application__)
