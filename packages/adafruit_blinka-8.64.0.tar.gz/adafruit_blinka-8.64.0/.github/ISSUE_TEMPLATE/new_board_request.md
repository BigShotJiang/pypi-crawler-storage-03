---
name: 📟 New Board Request
about: Request Support for a New Board
title: ''
labels: 'New Board Request'
assignees: ''

---

<!-- We keep growing Blinka 🚀 and would love ❤ to
 see what new boards you would like supported... 🙂 -->
