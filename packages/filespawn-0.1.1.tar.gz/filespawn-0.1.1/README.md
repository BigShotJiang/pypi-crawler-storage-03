# Filespawn

Minimal CLI that prints “Hello, world!”.