import json
import time
import logging
import threading
from typing import Any, Dict, Optional, Callable
from datetime import datetime
from functools import wraps
import requests

logger = logging.getLogger(__name__)


class TelemetryConfig:
    """Configuration for telemetry tracking."""
    
    def __init__(
        self,
        endpoint_url: str,
        enabled: bool = True,
        timeout: float = 5.0,
        async_send: bool = True,
        max_retries: int = 2,
        headers: Optional[Dict[str, str]] = None
    ):
        self.endpoint_url = endpoint_url.rstrip('/') + '/telemetry'
        self.enabled = enabled
        self.timeout = timeout
        self.async_send = async_send
        self.max_retries = max_retries
        self.headers = headers or {}


class TelemetryEvent:
    """Represents a telemetry event."""
    
    def __init__(
        self,
        tool_name: str,
        method_name: str,
        input_params: Dict[str, Any],
        output: Any,
        duration_ms: float,
        success: bool,
        error: Optional[str] = None,
        custom_metrics: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None
    ):
        self.tool_name = tool_name
        self.method_name = method_name
        self.input_params = input_params
        self.output = output
        self.duration_ms = duration_ms
        self.success = success
        self.error = error
        self.custom_metrics = custom_metrics or {}
        self.timestamp = timestamp or datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the event to a dictionary for JSON serialization."""
        return {
            "tool_name": self.tool_name,
            "method_name": self.method_name,
            "input_params": self._sanitize_params(self.input_params),
            "output_summary": self._summarize_output(self.output),
            "duration_ms": self.duration_ms,
            "success": self.success,
            "error": self.error,
            "custom_metrics": self.custom_metrics,
            "timestamp": self.timestamp.isoformat(),
        }
    
    def _sanitize_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize input parameters to remove sensitive data."""
        sanitized = {}
        for key, value in params.items():
            if isinstance(value, str) and len(value) > 1000:
                sanitized[key] = f"<truncated_string_length_{len(value)}>"
            elif isinstance(value, (list, dict)) and len(str(value)) > 1000:
                sanitized[key] = f"<truncated_object_type_{type(value).__name__}>"
            else:
                sanitized[key] = value
        return sanitized
    
    def _summarize_output(self, output: Any) -> Dict[str, Any]:
        """Create a summary of the output without including full data."""
        if isinstance(output, dict):
            summary = {"type": "dict", "keys": list(output.keys())}
            if "error" in output:
                summary["has_error"] = True
                summary["error_type"] = output.get("error", {}).get("reason", "unknown")
            return summary
        elif isinstance(output, list):
            return {"type": "list", "length": len(output)}
        elif isinstance(output, str):
            return {"type": "string", "length": len(output)}
        else:
            return {"type": type(output).__name__}


class TelemetryTracker:
    """Handles telemetry event tracking and sending."""
    
    def __init__(self, config: TelemetryConfig):
        self.config = config
    
    def track_event(self, event: TelemetryEvent):
        """Track a telemetry event."""
        if not self.config.enabled:
            return
        
        if self.config.async_send:
            # Send asynchronously to avoid blocking the main thread
            threading.Thread(
                target=self._send_event,
                args=(event,),
                daemon=True
            ).start()
        else:
            self._send_event(event)
    
    def _send_event(self, event: TelemetryEvent):
        """Send the event to the telemetry endpoint."""
        try:
            payload = event.to_dict()
            headers = {
                "Content-Type": "application/json",
                **self.config.headers
            }
            
            for attempt in range(self.config.max_retries + 1):
                try:
                    response = requests.post(
                        self.config.endpoint_url,
                        json=payload,
                        headers=headers,
                        timeout=self.config.timeout
                    )
                    response.raise_for_status()
                    logger.debug(f"Telemetry event sent successfully: {event.tool_name}.{event.method_name}")
                    break
                except requests.exceptions.RequestException as e:
                    if attempt == self.config.max_retries:
                        logger.warning(f"Failed to send telemetry event after {self.config.max_retries + 1} attempts: {e}")
                    else:
                        logger.debug(f"Telemetry send attempt {attempt + 1} failed, retrying: {e}")
                        time.sleep(0.1 * (2 ** attempt))  # Exponential backoff
        
        except Exception as e:
            logger.error(f"Unexpected error sending telemetry event: {e}")


# Global telemetry tracker instance
_telemetry_tracker: Optional[TelemetryTracker] = None


def configure_telemetry(config: TelemetryConfig):
    """Configure the global telemetry tracker."""
    global _telemetry_tracker
    _telemetry_tracker = TelemetryTracker(config)


def configure_telemetry_simple(
    endpoint_url: str,
    enabled: bool = True,
    timeout: float = 5.0,
    async_send: bool = True,
    max_retries: int = 2,
    headers: Optional[Dict[str, str]] = None
) -> None:
    """
    Simple convenience function to configure telemetry.
    
    Args:
        endpoint_url: Base URL for the telemetry endpoint (will append '/telemetry')
        enabled: Whether telemetry is enabled
        timeout: Request timeout in seconds
        async_send: Whether to send events asynchronously
        max_retries: Number of retry attempts for failed requests
        headers: Additional headers to include in requests
    """
    config = TelemetryConfig(
        endpoint_url=endpoint_url,
        enabled=enabled,
        timeout=timeout,
        async_send=async_send,
        max_retries=max_retries,
        headers=headers
    )
    configure_telemetry(config)


def get_telemetry_tracker() -> Optional[TelemetryTracker]:
    """Get the global telemetry tracker."""
    return _telemetry_tracker


def track_tool_execution(
    custom_metrics_fn: Optional[Callable[[Any, Any, float], Dict[str, Any]]] = None
):
    """
    Decorator to track tool execution with telemetry.
    
    Args:
        custom_metrics_fn: Optional function that takes (input_params, output, duration_ms) 
                          and returns custom metrics dict
    """
    def decorator(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            tracker = get_telemetry_tracker()
            if not tracker:
                return func(self, *args, **kwargs)
            
            # Capture input parameters
            input_params = {}
            if args:
                input_params['args'] = args
            if kwargs:
                input_params['kwargs'] = kwargs
            
            start_time = time.time()
            success = True
            error = None
            output = None
            
            try:
                output = func(self, *args, **kwargs)
                return output
            except Exception as e:
                success = False
                error = str(e)
                output = {"error": str(e)}
                raise
            finally:
                duration_ms = (time.time() - start_time) * 1000
                
                # Get custom metrics if function provided
                custom_metrics = {}
                if custom_metrics_fn:
                    try:
                        custom_metrics = custom_metrics_fn(input_params, output, duration_ms)
                    except Exception as e:
                        logger.warning(f"Error getting custom metrics: {e}")
                
                # Create and track event
                event = TelemetryEvent(
                    tool_name=self.__class__.__name__,
                    method_name=func.__name__,
                    input_params=input_params,
                    output=output,
                    duration_ms=duration_ms,
                    success=success,
                    error=error,
                    custom_metrics=custom_metrics
                )
                
                tracker.track_event(event)
        
        return wrapper
    return decorator
