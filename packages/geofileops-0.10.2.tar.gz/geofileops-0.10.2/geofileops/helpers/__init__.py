"""Sub-package containing helper modules that are quite specific for geofileops."""
