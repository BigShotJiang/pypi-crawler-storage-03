# Credits

## Active Maintainers

* Pit Bechtold <bechtold@eeh.ee.ethz.ch>
* Fabian Bill <bill@eeh.ee.ethz.ch>
* Chi-Ching Hsu <hsu@eeh.ee.ethz.ch>
* Deepshikha Kumari <kumari@eeh.ee.ethz.ch>

## Authors and Contributors

* Pit Bechtold (Author, Maintainer)
* Fabian Bill (Author, Maintainer)
* Alise Chachereau (Author)
* Maria Del (Contributor, Maintainer)
* Joseph Engelbrecht (Author)
* Raphael Faerber (Contributor)
* David Graber (Author)
* Chi-Ching Hsu (Author, Maintainer)
* Henning Janssen (Author, Maintainer)
* Deepshikha Kumari (Author, Maintainer)
* Henrik Menne (Author, Maintainer)
* Luca Nembrini (Contributor)
* Mikołaj Rybiński (Author, Maintainer)
* Ruben Stadler (Contributor)
* David Taylor (Author)
* Hanut Vemulapalli (Contributor)
