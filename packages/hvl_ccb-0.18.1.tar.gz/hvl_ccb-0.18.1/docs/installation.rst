.. include:: ../INSTALLATION.rst
