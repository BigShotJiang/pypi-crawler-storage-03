"""Forge AI Code - 智能AI编程助手"""
__version__ = "1.2.4"
from .main import main
__all__ = ["main"]

__version__ = "1.0.0"
__author__ = "Forge AI Team"
