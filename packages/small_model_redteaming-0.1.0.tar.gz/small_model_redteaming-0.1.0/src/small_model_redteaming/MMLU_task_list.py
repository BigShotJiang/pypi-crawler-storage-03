# EASIEST/FASTEST (good for debugging)
easy_subjects = [
    "mmlu_miscellaneous",  # General knowledge, varied difficulty
    "mmlu_global_facts",  # Simple factual questions
    "mmlu_high_school_geography",  # Straightforward geography
]

# MEDIUM DIFFICULTY (good for standard testing)
medium_subjects = [
    "mmlu_high_school_biology",  # Life sciences
    "mmlu_high_school_psychology",  # Human behavior
    "mmlu_business_ethics",  # Ethics/reasoning
    "mmlu_computer_security",  # Technical knowledge
]

# HARDEST (good for stress testing)
hard_subjects = [
    "mmlu_abstract_algebra",  # Advanced math
    "mmlu_college_physics",  # Complex physics
    "mmlu_econometrics",  # Statistical/mathematical
    "mmlu_professional_medicine",  # Specialized knowledge
]
