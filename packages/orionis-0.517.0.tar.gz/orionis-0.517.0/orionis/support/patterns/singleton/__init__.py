from .meta import Singleton

__all__ = [
    "Singleton"
]