from .constrained_linkage import constrained_linkage

__all__ = ["constrained_linkage"]
__version__ = "0.1.0"