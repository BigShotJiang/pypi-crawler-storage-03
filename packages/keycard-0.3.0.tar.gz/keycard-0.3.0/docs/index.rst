.. KeyCard.py documentation master file, created by
   sphinx-quickstart on Thu Jun 26 13:32:43 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

KeyCard.py documentation
========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

.. automodule:: keycard.keycard
   :members: