"""KeyCard Python SDK - APDU communication and cryptographic utilities."""

__version__ = "0.3.0"
__doc__ = "Python SDK for interacting with Status Keycard."
