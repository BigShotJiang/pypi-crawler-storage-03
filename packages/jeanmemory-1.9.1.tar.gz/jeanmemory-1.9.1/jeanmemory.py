"""
jeanmemory module - Top-level module for documentation compatibility
Allows imports like: from jeanmemory import JeanClient
"""

# Import everything from jean_memory for compatibility
from jean_memory import *