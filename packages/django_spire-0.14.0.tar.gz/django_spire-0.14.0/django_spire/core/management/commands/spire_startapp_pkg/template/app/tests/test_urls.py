from django.test import TestCase


class SpireChildAppUrlTestCase(TestCase):
    def setUp(self):
        super().setUp()
