# from django.urls.conf import path, include
#
#
# app_name = 'spirechildapp'
#
# urlpatterns = [
#     path('page/', include('module.urls.page_urls', namespace='page')),
#     path('form/', include('module.urls.form_urls', namespace='form')),
# ]
