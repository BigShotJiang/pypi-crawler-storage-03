from django.apps import AppConfig


class SpireChildAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    label = 'spireparentapp_spirechildapp'
    name = 'module'
