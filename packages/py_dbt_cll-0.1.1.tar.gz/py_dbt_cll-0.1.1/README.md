### py-dbt-cll

Python packages that extracts column lineage information from dbt models based on their metadata.

### Installation

You can install the package using pip:

```bash
pip install py-dbt-cll
```
