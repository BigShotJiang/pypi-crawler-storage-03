::: easydiffraction.core
