from py_auto_migrate.databases_model.mongo_model import MongoToMongo, MongoToMySQL, MongoToPostgres
from py_auto_migrate.databases_model.mysql_model import MySQLToMongo , MySQLToMySQL , MySQLToPostgres
from py_auto_migrate.databases_model.postgresql_model import PostgresToMongo , PostgresToPostgres , PostgresToMySQL