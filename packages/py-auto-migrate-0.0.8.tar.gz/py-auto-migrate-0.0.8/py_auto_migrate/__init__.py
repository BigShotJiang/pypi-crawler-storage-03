"""
Py-Auto-Migrate: A tool for migrating data between MongoDB and MySQL databases.
"""