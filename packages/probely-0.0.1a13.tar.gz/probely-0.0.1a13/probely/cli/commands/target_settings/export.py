def target_settings_export_command_handler():
    print("target-settings export ok")
