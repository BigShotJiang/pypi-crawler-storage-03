def target_settings_add_command_handler():
    print("target-settings add ok")
