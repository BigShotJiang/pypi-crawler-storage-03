from samplics.regression.glm import SurveyGLM

__all__ = ["SurveyGLM"]
