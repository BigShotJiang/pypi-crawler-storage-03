# from samplics.apis.base.fitting import _fit
# from samplics.types import AuxVars, DirectEst, FitMethod


# def fit(y: DirectEst, x: AuxVars, method: FitMethod):
#     # breakpoint()
#     return _fit(y=y, x=x, method=method)


# def test2(y):
#     if isinstance(y, DirectEst):
#         return 2
#     else:
#         return 3
