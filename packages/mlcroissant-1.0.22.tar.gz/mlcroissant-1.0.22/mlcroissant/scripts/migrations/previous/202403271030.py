"""Migration: Standardizes @context."""


def up(json_ld):
    """Up migration that standardizes @context."""
    return json_ld
