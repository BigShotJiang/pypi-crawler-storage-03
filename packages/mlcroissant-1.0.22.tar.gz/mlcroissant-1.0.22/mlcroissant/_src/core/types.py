"""Python types for ML Croissant."""

from typing import Any

Json = dict[str, Any]
