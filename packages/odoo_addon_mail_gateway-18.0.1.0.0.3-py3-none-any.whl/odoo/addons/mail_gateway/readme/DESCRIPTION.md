This module will allow you to integrate an external chat system in your
Odoo system. It requires extra modules with the specific configuration
of each chat system, like mail_gateway_telegram or
mail_gateway_whatsapp.

This way, a group of users can respond customers or any other set of
partners within Odoo, but the messages will be sent through the external
chat system.
