"""get-the-nini: Ninisite Post Scraper"""

__version__ = "0.1.0"
