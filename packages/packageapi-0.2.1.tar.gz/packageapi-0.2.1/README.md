# PackageAPI
An API For Installing Packages Inside Of Your Python Script

### This project is not actively maintained much. It does not need to be.

## How to use
```python
import packageapi
```
Then you can use the GUI to generate a command OR install a package via the GUI
```python
packageapi.gui_package_manager() # Generate Commands
```
You can also use it in your CLI
```bash
packageapi-gui
```

Made by me :)
