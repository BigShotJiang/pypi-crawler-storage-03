from .adam import Adam
from .stochasticGD import SGD
from .gradientDescent import GD