"""Lightweight MCP server package exposing spec & feature resources and update tools."""
from .server import mcp  # re-export for convenience
__all__ = ["mcp"]
