from pygrep import main

main()
