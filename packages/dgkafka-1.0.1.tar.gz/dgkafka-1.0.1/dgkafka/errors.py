class ProducerNotSetError(Exception):
    pass


class ConsumerNotSetError(Exception):
    pass