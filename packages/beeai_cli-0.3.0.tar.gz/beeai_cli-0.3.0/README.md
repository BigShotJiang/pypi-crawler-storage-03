# BeeAI CLI
