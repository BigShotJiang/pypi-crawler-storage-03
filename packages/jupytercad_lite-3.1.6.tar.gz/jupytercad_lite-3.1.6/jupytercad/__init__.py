__version__ = "3.1.6"

from jupytercad_lab import CadDocument  # noqa
