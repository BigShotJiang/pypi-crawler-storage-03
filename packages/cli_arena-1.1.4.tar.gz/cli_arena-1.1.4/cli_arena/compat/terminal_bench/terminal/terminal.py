from cli_arena.terminal.terminal import spin_up_terminal  # re-export


