RITS_API_KEY = "RITS_API_KEY"  # pragma: allowlist secret
RITS_API_URL = "https://inference-3scale-apicast-production.apps.rits.fmaas.res.ibm.com"
XGRAMMAR = "xgrammar"
