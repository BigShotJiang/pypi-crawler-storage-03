from .mem_usage import reduce_mem_usage

__all__ = ["reduce_mem_usage"]
