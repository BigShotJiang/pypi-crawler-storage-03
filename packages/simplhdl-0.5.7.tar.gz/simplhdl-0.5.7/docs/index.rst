.. SimplHDL documentation master file, created by
   sphinx-quickstart on Tue Nov 21 21:13:51 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

########
SimplHDL
########

Hardware Design Made Easy
=========================

.. toctree::
   :maxdepth: 2
   :caption: User Guide:

   introduction
   flows

.. toctree::
   :maxdepth: 2
   :caption: Development:

   plugins


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
