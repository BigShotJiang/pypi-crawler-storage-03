..
    Copyright (C) 2018-2020 CERN.

    invenio-app-ils is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

=================
 Invenio App ILS
=================

.. image:: https://img.shields.io/travis/inveniosoftware/invenio-app-ils.svg
        :target: https://travis-ci.org/inveniosoftware/invenio-app-ils

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-app-ils.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-app-ils

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-app-ils.svg
        :target: https://github.com/inveniosoftware/invenio-app-ils/blob/master/LICENSE

Integrated Library System based on Invenio

Official documentation (under development) is available at
https://invenioils.docs.cern.ch
