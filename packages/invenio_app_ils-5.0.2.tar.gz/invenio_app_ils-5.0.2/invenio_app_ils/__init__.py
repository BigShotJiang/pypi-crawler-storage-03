# -*- coding: utf-8 -*-
#
# Copyright (C) 2018-2024 CERN.
#
# invenio-app-ils is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""invenio-app-ils."""

__version__ = "5.0.2"

__all__ = ("__version__",)
