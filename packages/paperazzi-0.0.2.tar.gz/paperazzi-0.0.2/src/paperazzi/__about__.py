# SPDX-FileCopyrightText: 2025-present Satya Ortiz-Gagne <satya.ortiz-gagne@mila.quebec>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
