__version__ = "1.0.0"

from .lppinv import lppinv

__all__ = [
    "lppinv",
    "__version__"
]
