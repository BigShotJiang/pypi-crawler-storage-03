class ToolCallError(Exception):
    pass
