# Epic: {Epic Name}

## Component References
→ `/architecture/releases/{release}/components/{component}.md`

## Goal
{Конкретная цель эпика - что будет работать}

## Tasks Breakdown

### task-01: {Task Name}
**Type:** feature  
**Blocks:** task-02

### task-02: {Task Name}
**Type:** feature
**Blocks:** none

## Success Criteria
- {Измеримый результат работы эпика}
- {Что можно протестировать}
- {Готовность к следующему эпику}

## Tech Notes
{Ссылка на `/architecture/tech-context/system-patterns.md` если применимо}
{Специфичные технические детали эпика}