from enum import Enum


class DocStyle(Enum):
    MARKDOWN = "markdown"
    ASCIIDOC = "asciidoc"
