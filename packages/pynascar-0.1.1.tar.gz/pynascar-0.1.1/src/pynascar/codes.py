
# 1-Green, 2-Yellow, 3-Red, 4-Finish, 6-Stop, 8-Warm Up, 9-Not Active
FLAG_CODE = {
    1: "Green",
    2: "Yellow",
    3: "Red",
    4: "Finish",
    6: "Stop",
    8: "Warm Up",
    9: "Not Active"
}