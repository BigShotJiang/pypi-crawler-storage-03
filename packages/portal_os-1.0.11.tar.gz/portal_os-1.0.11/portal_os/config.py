#!/usr/bin/env python3
"""
Portal OS Configuration Management
Centralized configuration system for all Portal OS components
"""
import os
import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, Any

__version__ = "1.0.0"

class PortalOSConfig:
    """Portal OS Central Configuration Management"""
    
    def __init__(self):
        self.home_dir = Path.home()
        self.portal_dir = self.home_dir / ".portal-os"
        self.config_file = self.portal_dir / "portal-os-config.json"
        
        self._setup_directories()
        self._load_config()
    
    def _setup_directories(self):
        """Create necessary directories"""
        self.portal_dir.mkdir(exist_ok=True)
        (self.portal_dir / "logs").mkdir(exist_ok=True)
        (self.portal_dir / "cache").mkdir(exist_ok=True)
        (self.portal_dir / "backups").mkdir(exist_ok=True)
        (self.portal_dir / "config").mkdir(exist_ok=True)
    
    def _load_config(self):
        """Load configuration from file or create default"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                self.config = self._get_default_config()
        else:
            self.config = self._get_default_config()
        
        self._save_config()
    
    def _get_default_config(self) -> Dict:
        """Get default configuration structure"""
        return {
            "portal_os": {
                "version": "1.0.0",
                "auto_start": True,
                "default_profile": "developer",
                "log_level": "info",
                "backup_enabled": True,
                "update_check": True,
                "config_dir": str(self.portal_dir / "config")
            },
            "components": {
                "ai_assistant": {
                    "enabled": True,
                    "auto_start": True,
                    "backend": "ollama",
                    "model": "llama2",
                    "api_key": "",
                    "endpoint": "http://localhost:11434",
                    "max_tokens": 2048,
                    "temperature": 0.7
                },
                "security_privacy": {
                    "enabled": True,
                    "auto_start": True,
                    "adblocker": True,
                    "privacy_profile": "balanced",
                    "firewall_enabled": True,
                    "encryption_enabled": True,
                    "monitoring_enabled": True,
                    "compliance_gdpr": True,
                    "compliance_hipaa": False,
                    "compliance_sox": False
                },
                "performance_optimizer": {
                    "enabled": True,
                    "auto_start": True,
                    "caching": True,
                    "monitoring": True,
                    "auto_optimize": True,
                    "cache_size_mb": 512,
                    "cleanup_interval_hours": 24,
                    "memory_threshold_percent": 80
                },
                "voice_interaction": {
                    "enabled": True,
                    "auto_start": False,
                    "wake_word": "portal",
                    "language": "en-US",
                    "voice_speed": 1.0,
                    "voice_volume": 0.8,
                    "microphone_device": "default",
                    "speaker_device": "default"
                },
                "advanced_ai": {
                    "enabled": True,
                    "auto_start": False,
                    "predictive_interface": True,
                    "code_intelligence": True,
                    "workspace_analysis": True,
                    "auto_suggestions": True,
                    "context_window": 4096
                },
                "search_assistant": {
                    "enabled": True,
                    "auto_start": False,
                    "engine": "meilisearch",
                    "index_files": True,
                    "search_paths": ["~/Documents", "~/Projects"],
                    "exclude_patterns": ["*.tmp", "*.log", "node_modules"],
                    "meilisearch_url": "http://localhost:7700",
                    "meilisearch_key": ""
                },
                "theme_manager": {
                    "enabled": True,
                    "auto_start": False,
                    "auto_switch": False,
                    "current_theme": "default",
                    "themes_directory": "themes",
                    "auto_backup": True
                },
                "plugin_manager": {
                    "enabled": True,
                    "auto_start": False,
                    "auto_update": True,
                    "plugin_directory": "plugins",
                    "trusted_sources": ["portal-os-official"],
                    "auto_install_deps": True
                },
                "ui_ux_manager": {
                    "enabled": True,
                    "auto_start": False,
                    "notifications": True,
                    "widgets": True,
                    "desktop_integration": True,
                    "system_tray": True,
                    "startup_notification": True
                }
            },
            "profiles": {
                "developer": {
                    "description": "Full development environment with all features",
                    "components": ["ai_assistant", "security_privacy", "performance_optimizer", "advanced_ai", "search_assistant"],
                    "settings": {
                        "ai_assistant.auto_start": True,
                        "security_privacy.privacy_profile": "balanced",
                        "performance_optimizer.auto_optimize": True,
                        "advanced_ai.code_intelligence": True,
                        "search_assistant.index_files": True
                    }
                },
                "minimal": {
                    "description": "Minimal setup with essential features only",
                    "components": ["security_privacy", "performance_optimizer"],
                    "settings": {
                        "security_privacy.privacy_profile": "strict",
                        "performance_optimizer.auto_optimize": False
                    }
                },
                "ai_focused": {
                    "description": "AI-focused setup with advanced AI features",
                    "components": ["ai_assistant", "advanced_ai", "voice_interaction", "search_assistant"],
                    "settings": {
                        "ai_assistant.auto_start": True,
                        "advanced_ai.predictive_interface": True,
                        "voice_interaction.auto_start": True,
                        "search_assistant.index_files": True
                    }
                },
                "security_focused": {
                    "description": "Security-focused setup with maximum protection",
                    "components": ["security_privacy", "performance_optimizer", "ui_ux_manager"],
                    "settings": {
                        "security_privacy.privacy_profile": "strict",
                        "security_privacy.encryption_enabled": True,
                        "security_privacy.monitoring_enabled": True,
                        "performance_optimizer.auto_optimize": True
                    }
                }
            },
            "system": {
                "platform": sys.platform,
                "python_version": sys.version,
                "home_directory": str(self.home_dir),
                "portal_directory": str(self.portal_dir),
                "log_directory": str(self.portal_dir / "logs"),
                "cache_directory": str(self.portal_dir / "cache"),
                "backup_directory": str(self.portal_dir / "backups"),
                "config_directory": str(self.portal_dir / "config")
            },
            "logging": {
                "level": "info",
                "file_enabled": True,
                "console_enabled": True,
                "max_file_size_mb": 10,
                "backup_count": 5,
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            },
            "network": {
                "proxy_enabled": False,
                "proxy_url": "",
                "proxy_auth": "",
                "timeout_seconds": 30,
                "retry_attempts": 3,
                "user_agent": "Portal OS/1.0.0"
            }
        }
    
    def _save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key (dot notation supported)"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value by key (dot notation supported)"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
        self._save_config()
    
    def get_component_config(self, component_name: str) -> Dict:
        """Get configuration for a specific component"""
        return self.config.get("components", {}).get(component_name, {})
    
    def set_component_config(self, component_name: str, config: Dict):
        """Set configuration for a specific component"""
        if "components" not in self.config:
            self.config["components"] = {}
        self.config["components"][component_name] = config
        self._save_config()
    
    def get_profile(self, profile_name: str) -> Dict:
        """Get a specific profile configuration"""
        return self.config.get("profiles", {}).get(profile_name, {})
    
    def apply_profile(self, profile_name: str):
        """Apply a specific profile"""
        profile = self.get_profile(profile_name)
        if not profile:
            raise ValueError(f"Profile '{profile_name}' not found")
        
        # Apply profile settings
        settings = profile.get("settings", {})
        for key, value in settings.items():
            self.set(key, value)
        
        # Update current profile
        self.set("portal_os.current_profile", profile_name)
    
    def backup_config(self):
        """Create a backup of the current configuration"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = self.portal_dir / "backups" / f"config_backup_{timestamp}.json"
        
        try:
            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            return str(backup_file)
        except Exception as e:
            print(f"Error creating backup: {e}")
            return None
    
    def restore_config(self, backup_file: str):
        """Restore configuration from backup"""
        try:
            with open(backup_file, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            self._save_config()
            return True
        except Exception as e:
            print(f"Error restoring backup: {e}")
            return False

# Global configuration instance and convenience functions
_config_instance = None

def get_config() -> PortalOSConfig:
    """Get the global configuration instance"""
    global _config_instance
    if _config_instance is None:
        _config_instance = PortalOSConfig()
    return _config_instance

def get_component_config(component_name: str) -> Dict:
    """Get configuration for a specific component"""
    return get_config().get_component_config(component_name)

def apply_profile(profile_name: str):
    """Apply a specific profile"""
    get_config().apply_profile(profile_name)

def set_config_value(key: str, value: Any):
    """Set a configuration value"""
    get_config().set(key, value)

def get_config_value(key: str, default: Any = None) -> Any:
    """Get a configuration value"""
    return get_config().get(key, default)
