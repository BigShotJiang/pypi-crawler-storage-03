#!/usr/bin/env python3
"""
Portal OS Base Component
Base class for all Portal OS components with common functionality
"""
import os
import sys
import json
import sqlite3
import subprocess
from pathlib import Path
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from datetime import datetime
import click

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())


class BaseComponent(ABC):
    """Base class for all Portal OS components"""
    
    def __init__(self, component_id: str, name: str, description: str):
        self.component_id = component_id
        self.name = name
        self.description = description
        self.is_running = False
        self.db_path = None
        self.config = {}
        
        # Initialize component
        self._setup_directories()
        self._load_config()
        self._setup_database()
    
    def _setup_directories(self):
        """Setup component directories"""
        from ..config import get_config
        config_manager = get_config()
        
        # Create component directory
        self.component_dir = config_manager.portal_dir / "components" / self.component_id
        self.component_dir.mkdir(parents=True, exist_ok=True)
        
        # Create data directory
        self.data_dir = self.component_dir / "data"
        self.data_dir.mkdir(exist_ok=True)
        
        # Create logs directory
        self.logs_dir = self.component_dir / "logs"
        self.logs_dir.mkdir(exist_ok=True)
    
    def _load_config(self):
        """Load component configuration"""
        from ..config import get_component_config
        self.config = get_component_config(self.component_id)
    
    def _setup_database(self):
        """Setup component database"""
        self.db_path = self.data_dir / f"{self.component_id}.db"
        self._init_database()
    
    def _init_database(self):
        """Initialize component database"""
        if not self.db_path.exists():
            self._create_tables()
    
    def _create_tables(self):
        """Create database tables - override in subclasses"""
        pass
    
    def run_command(self, cmd: List[str], capture_output: bool = True, check: bool = True) -> subprocess.CompletedProcess:
        """Run a command and return the result"""
        try:
            result = subprocess.run(
                cmd, 
                capture_output=capture_output, 
                text=True, 
                encoding='utf-8'
            )
            if check and result.returncode != 0:
                print(f"❌ Command failed: {' '.join(cmd)}")
                if result.stderr:
                    print(f"Error: {result.stderr}")
            return result
        except Exception as e:
            print(f"❌ Error running command: {e}")
            return None
    
    def log(self, message: str, level: str = "INFO"):
        """Log a message to component log file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        
        log_file = self.logs_dir / f"{self.component_id}.log"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(log_entry)
    
    def get_status(self) -> Dict[str, Any]:
        """Get component status"""
        return {
            "component_id": self.component_id,
            "name": self.name,
            "description": self.description,
            "is_running": self.is_running,
            "enabled": self.config.get("enabled", False),
            "last_updated": datetime.now().isoformat()
        }
    
    @abstractmethod
    def install(self) -> bool:
        """Install the component - must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def start(self) -> bool:
        """Start the component - must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def stop(self) -> bool:
        """Stop the component - must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def status(self) -> Dict[str, Any]:
        """Get detailed component status - must be implemented by subclasses"""
        pass


class DatabaseMixin:
    """Mixin for database operations"""
    
    def execute_query(self, query: str, params: tuple = None) -> Optional[List[tuple]]:
        """Execute a database query"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                if query.strip().upper().startswith('SELECT'):
                    return cursor.fetchall()
                else:
                    conn.commit()
                    return None
        except Exception as e:
            self.log(f"Database error: {e}", "ERROR")
            return None
    
    def table_exists(self, table_name: str) -> bool:
        """Check if a table exists"""
        query = "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
        result = self.execute_query(query, (table_name,))
        return result is not None and len(result) > 0


class ProgressMixin:
    """Mixin for progress indicators"""
    
    def show_progress(self, step: int, total: int, message: str):
        """Show progress indicator"""
        percentage = int((step / total) * 100)
        bar_length = 30
        filled_length = int(bar_length * step // total)
        bar = '█' * filled_length + '-' * (bar_length - filled_length)
        
        print(f"\r🔄 {message} [{bar}] {percentage}% ({step}/{total})", end="", flush=True)
        if step == total:
            print()  # New line when complete
    
    def show_step(self, step: str, status: str = "info"):
        """Show a step in the process"""
        icons = {
            "info": "ℹ️",
            "success": "✅",
            "warning": "⚠️",
            "error": "❌",
            "progress": "🔄"
        }
        icon = icons.get(status, "ℹ️")
        print(f"{icon} {step}")


class ConfigMixin:
    """Mixin for configuration management"""
    
    def save_config(self, key: str, value: Any):
        """Save a configuration value"""
        from ..config import get_config
        config_manager = get_config()
        config_manager.set(f"{self.component_id}.{key}", value)
        self.config[key] = value
    
    def get_config(self, key: str, default: Any = None) -> Any:
        """Get a configuration value"""
        return self.config.get(key, default)
    
    def update_config(self, updates: Dict[str, Any]):
        """Update multiple configuration values"""
        for key, value in updates.items():
            self.save_config(key, value)
