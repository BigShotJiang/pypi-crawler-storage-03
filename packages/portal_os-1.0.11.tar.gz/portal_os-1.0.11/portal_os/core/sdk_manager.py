#!/usr/bin/env python3
"""
Portal OS SDK Manager
Manages installation and configuration of development tools and SDKs
"""
import os
import sys
import subprocess
import platform
from pathlib import Path
from typing import Dict, Any, List, Optional
from .base_component import BaseComponent, DatabaseMixin, ProgressMixin, ConfigMixin
from datetime import datetime


class SDKManager(BaseComponent, DatabaseMixin, ProgressMixin, ConfigMixin):
    """Portal OS SDK and Development Tools Manager"""
    
    def __init__(self):
        super().__init__(
            component_id="sdk_manager",
            name="🔧 SDK Manager",
            description="Manages development tools and SDK installations"
        )
        
        self.system = platform.system().lower()
        self.is_linux = self.system == "linux"
        self.is_windows = self.system == "windows"
        self.is_macos = self.system == "darwin"
        
        # Define all tools and SDKs
        self.tools = self._define_tools()
    
    def _define_tools(self) -> Dict[str, Dict[str, Any]]:
        """Define all tools and SDKs to manage"""
        return {
            # SDK Managers
            "nvm": {
                "name": "Node Version Manager (NVM)",
                "description": "Manage multiple Node.js versions",
                "category": "sdk_manager",
                "install_script": self._install_nvm,
                "check_cmd": ["nvm", "--version"],
                "platforms": ["linux", "darwin"]
            },
            "pyenv": {
                "name": "Python Version Manager (pyenv)",
                "description": "Manage multiple Python versions",
                "category": "sdk_manager",
                "install_script": self._install_pyenv,
                "check_cmd": ["pyenv", "--version"],
                "platforms": ["linux", "darwin"]
            },
            "rustup": {
                "name": "Rust Toolchain Manager",
                "description": "Install and manage Rust toolchains",
                "category": "sdk_manager",
                "install_script": self._install_rustup,
                "check_cmd": ["rustup", "--version"],
                "platforms": ["linux", "darwin", "windows"]
            },
            "sdkman": {
                "name": "SDKMAN! (Java/Kotlin/Gradle)",
                "description": "Manage Java, Kotlin, Gradle, and other JVM tools",
                "category": "sdk_manager",
                "install_script": self._install_sdkman,
                "check_cmd": ["sdk", "version"],
                "platforms": ["linux", "darwin"]
            },
            
            # Development Tools
            "git": {
                "name": "Git Version Control",
                "description": "Distributed version control system",
                "category": "dev_tool",
                "install_script": self._install_git,
                "check_cmd": ["git", "--version"],
                "platforms": ["linux", "darwin", "windows"]
            },
            "docker": {
                "name": "Docker & Docker Compose",
                "description": "Container platform for development",
                "category": "dev_tool",
                "install_script": self._install_docker,
                "check_cmd": ["docker", "--version"],
                "platforms": ["linux", "darwin", "windows"]
            },
            "vscode": {
                "name": "Visual Studio Code",
                "description": "Lightweight but powerful source code editor",
                "category": "dev_tool",
                "install_script": self._install_vscode,
                "check_cmd": ["code", "--version"],
                "platforms": ["linux", "darwin", "windows"]
            },
            "neovim": {
                "name": "Neovim",
                "description": "Hyperextensible Vim-based text editor",
                "category": "dev_tool",
                "install_script": self._install_neovim,
                "check_cmd": ["nvim", "--version"],
                "platforms": ["linux", "darwin", "windows"]
            },
            "tmux": {
                "name": "Tmux Terminal Multiplexer",
                "description": "Terminal multiplexer for managing multiple sessions",
                "category": "dev_tool",
                "install_script": self._install_tmux,
                "check_cmd": ["tmux", "-V"],
                "platforms": ["linux", "darwin"]
            },
            
            # Programming Languages
            "nodejs": {
                "name": "Node.js (Latest LTS)",
                "description": "JavaScript runtime for server-side development",
                "category": "language",
                "install_script": self._install_nodejs,
                "check_cmd": ["node", "--version"],
                "platforms": ["linux", "darwin", "windows"],
                "depends_on": ["nvm"]
            },
            "python": {
                "name": "Python (Latest)",
                "description": "Python programming language",
                "category": "language",
                "install_script": self._install_python,
                "check_cmd": ["python3", "--version"],
                "platforms": ["linux", "darwin", "windows"],
                "depends_on": ["pyenv"]
            },
            "rust": {
                "name": "Rust Programming Language",
                "description": "Systems programming language",
                "category": "language",
                "install_script": self._install_rust,
                "check_cmd": ["rustc", "--version"],
                "platforms": ["linux", "darwin", "windows"],
                "depends_on": ["rustup"]
            },
            "java": {
                "name": "Java Development Kit (JDK)",
                "description": "Java programming language and runtime",
                "category": "language",
                "install_script": self._install_java,
                "check_cmd": ["java", "-version"],
                "platforms": ["linux", "darwin", "windows"],
                "depends_on": ["sdkman"]
            },
            "golang": {
                "name": "Go Programming Language",
                "description": "Go programming language",
                "category": "language",
                "install_script": self._install_golang,
                "check_cmd": ["go", "version"],
                "platforms": ["linux", "darwin", "windows"]
            },
            
            # AI Tools
            "ollama": {
                "name": "Ollama AI Models",
                "description": "Local AI model runner for Portal OS",
                "category": "ai_tool",
                "install_script": self._install_ollama,
                "check_cmd": ["ollama", "--version"],
                "platforms": ["linux", "darwin", "windows"]
            }
        }
    
    def _create_tables(self):
        """Create SDK manager database tables"""
        queries = [
            """
            CREATE TABLE IF NOT EXISTS installed_tools (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tool_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                version TEXT,
                install_date TEXT NOT NULL,
                status TEXT DEFAULT 'installed'
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS installation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tool_id TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT,
                timestamp TEXT NOT NULL
            )
            """
        ]
        
        for query in queries:
            self.execute_query(query)
    
    def check_command_exists(self, cmd: List[str]) -> bool:
        """Check if a command exists in PATH"""
        try:
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    def log_installation(self, tool_id: str, action: str, status: str, message: str = ""):
        """Log installation activity"""
        timestamp = datetime.now().isoformat()
        query = """
        INSERT INTO installation_logs (tool_id, action, status, message, timestamp)
        VALUES (?, ?, ?, ?, ?)
        """
        self.execute_query(query, (tool_id, action, status, message, timestamp))
    
    def get_installed_tools(self) -> List[Dict[str, Any]]:
        """Get list of installed tools"""
        query = "SELECT tool_id, name, version, install_date, status FROM installed_tools"
        results = self.execute_query(query)
        
        if not results:
            return []
        
        return [
            {
                "tool_id": row[0],
                "name": row[1],
                "version": row[2],
                "install_date": row[3],
                "status": row[4]
            }
            for row in results
        ]
    
    def install_tool(self, tool_id: str) -> bool:
        """Install a specific tool gracefully"""
        if tool_id not in self.tools:
            self.log(f"Tool {tool_id} not found", "ERROR")
            return False
        
        tool = self.tools[tool_id]
        
        # Check platform compatibility
        if self.system not in tool["platforms"]:
            self.log(f"Tool {tool_id} not supported on {self.system}", "WARNING")
            return False
        
        # Check dependencies
        if "depends_on" in tool:
            for dep in tool["depends_on"]:
                if not self.check_command_exists(self.tools[dep]["check_cmd"]):
                    self.log(f"Installing dependency {dep} for {tool_id}", "INFO")
                    if not self.install_tool(dep):
                        return False
        
        # Check if already installed
        if self.check_command_exists(tool["check_cmd"]):
            self.log(f"Tool {tool_id} already installed - skipping gracefully", "INFO")
            # Record it as installed even if it was already there
            self._record_installed_tool(tool_id, tool["name"])
            return True
        
        # Install the tool
        self.log(f"Installing {tool_id}", "INFO")
        self.log_installation(tool_id, "install", "started")
        
        try:
            success = tool["install_script"]()
            if success:
                self.log_installation(tool_id, "install", "completed")
                self._record_installed_tool(tool_id, tool["name"])
                return True
            else:
                self.log_installation(tool_id, "install", "failed")
                return False
        except Exception as e:
            self.log(f"Error installing {tool_id}: {e}", "ERROR")
            self.log_installation(tool_id, "install", "failed", str(e))
            return False
    
    def _record_installed_tool(self, tool_id: str, name: str):
        """Record an installed tool in the database"""
        timestamp = datetime.now().isoformat()
        query = """
        INSERT OR REPLACE INTO installed_tools (tool_id, name, install_date, status)
        VALUES (?, ?, ?, ?)
        """
        self.execute_query(query, (tool_id, name, timestamp, "installed"))
    
    def install(self) -> bool:
        """Install all SDK managers and tools"""
        self.show_step("🚀 Starting Portal OS SDK installation", "info")
        
        # Group tools by category
        sdk_managers = [k for k, v in self.tools.items() if v["category"] == "sdk_manager"]
        dev_tools = [k for k, v in self.tools.items() if v["category"] == "dev_tool"]
        languages = [k for k, v in self.tools.items() if v["category"] == "language"]
        ai_tools = [k for k, v in self.tools.items() if v["category"] == "ai_tool"]
        
        all_tools = sdk_managers + dev_tools + languages + ai_tools
        total_tools = len(all_tools)
        
        # Install SDK Managers first
        self.show_step("📦 Installing SDK Managers...", "info")
        for i, tool_id in enumerate(sdk_managers, 1):
            self.show_progress(i, len(sdk_managers), f"Installing {self.tools[tool_id]['name']}")
            success = self.install_tool(tool_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {tool_id}", "warning")
        
        # Install Development Tools
        self.show_step("📦 Installing Development Tools...", "info")
        for i, tool_id in enumerate(dev_tools, 1):
            self.show_progress(i, len(dev_tools), f"Installing {self.tools[tool_id]['name']}")
            success = self.install_tool(tool_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {tool_id}", "warning")
        
        # Install Programming Languages
        self.show_step("📦 Installing Programming Languages...", "info")
        for i, tool_id in enumerate(languages, 1):
            self.show_progress(i, len(languages), f"Installing {self.tools[tool_id]['name']}")
            success = self.install_tool(tool_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {tool_id}", "warning")
        
        # Install AI Tools
        self.show_step("📦 Installing AI Tools...", "info")
        for i, tool_id in enumerate(ai_tools, 1):
            self.show_progress(i, len(ai_tools), f"Installing {self.tools[tool_id]['name']}")
            success = self.install_tool(tool_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {tool_id}", "warning")
        
        self.show_step("🎉 SDK installation complete!", "success")
        return True
    
    def start(self) -> bool:
        """Start the SDK manager (no-op for this component)"""
        self.is_running = True
        return True
    
    def stop(self) -> bool:
        """Stop the SDK manager (no-op for this component)"""
        self.is_running = False
        return True
    
    def status(self) -> Dict[str, Any]:
        """Get detailed SDK manager status"""
        installed_tools = self.get_installed_tools()
        
        # Check current status of all tools
        tool_status = {}
        for tool_id, tool_info in self.tools.items():
            is_installed = self.check_command_exists(tool_info["check_cmd"])
            tool_status[tool_id] = {
                "name": tool_info["name"],
                "category": tool_info["category"],
                "installed": is_installed,
                "platform_supported": self.system in tool_info["platforms"]
            }
        
        return {
            **self.get_status(),
            "installed_tools": installed_tools,
            "tool_status": tool_status,
            "platform": self.system,
            "total_tools": len(self.tools),
            "installed_count": len([t for t in tool_status.values() if t["installed"]])
        }
    
    # Installation methods for each tool
    def _install_nvm(self) -> bool:
        """Install Node Version Manager (NVM)"""
        if self.is_linux or self.is_macos:
            # Check if NVM is already installed
            if self.check_command_exists(["nvm", "--version"]):
                self.log("NVM already installed, skipping", "INFO")
                return True
            
            nvm_install_script = "https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh"
            cmd = f'curl -o- {nvm_install_script} | bash'
            result = self.run_command(cmd.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_pyenv(self) -> bool:
        """Install pyenv for Python version management"""
        # Check if pyenv is already installed
        if self.check_command_exists(["pyenv", "--version"]):
            self.log("pyenv already installed, skipping", "INFO")
            return True
        
        if self.is_linux:
            deps_cmd = "sudo apt-get update && sudo apt-get install -y make build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev wget curl llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git"
            self.run_command(deps_cmd.split(), capture_output=False, check=False)
            
            pyenv_cmd = 'curl https://pyenv.run | bash'
            result = self.run_command(pyenv_cmd.split(), capture_output=False, check=False)
            return result is not None
        elif self.is_macos:
            brew_cmd = "brew install pyenv"
            result = self.run_command(brew_cmd.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_rustup(self) -> bool:
        """Install Rust toolchain manager"""
        rustup_cmd = "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y"
        result = self.run_command(rustup_cmd.split(), capture_output=False, check=False)
        return result is not None
    
    def _install_sdkman(self) -> bool:
        """Install SDKMAN! for JVM tools"""
        sdkman_cmd = "curl -s \"https://get.sdkman.io\" | bash"
        result = self.run_command(sdkman_cmd.split(), capture_output=False, check=False)
        return result is not None
    
    def _install_git(self) -> bool:
        """Install Git version control"""
        if self.is_linux:
            git_cmd = "sudo apt-get update && sudo apt-get install -y git"
            result = self.run_command(git_cmd.split(), capture_output=False, check=False)
        elif self.is_macos:
            git_cmd = "brew install git"
            result = self.run_command(git_cmd.split(), capture_output=False, check=False)
        else:
            return False
        return result is not None
    
    def _install_docker(self) -> bool:
        """Install Docker and Docker Compose"""
        if self.is_linux:
            docker_cmd = "curl -fsSL https://get.docker.com -o get-docker.sh && sudo sh get-docker.sh"
            result = self.run_command(docker_cmd.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_vscode(self) -> bool:
        """Install Visual Studio Code"""
        if self.is_linux:
            repo_cmd = "wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg && sudo install -o root -g root -m 644 packages.microsoft.gpg /etc/apt/trusted.gpg.d/ && sudo sh -c 'echo \"deb [arch=amd64,arm64,armhf signed-by=/etc/apt/trusted.gpg.d/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main\" > /etc/apt/sources.list.d/vscode.list'"
            self.run_command(repo_cmd.split(), capture_output=False, check=False)
            
            install_cmd = "sudo apt-get update && sudo apt-get install -y code"
            result = self.run_command(install_cmd.split(), capture_output=False, check=False)
            return result is not None
        elif self.is_macos:
            brew_cmd = "brew install --cask visual-studio-code"
            result = self.run_command(brew_cmd.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_neovim(self) -> bool:
        """Install Neovim"""
        if self.is_linux:
            nvim_cmd = "sudo apt-get update && sudo apt-get install -y neovim"
            result = self.run_command(nvim_cmd.split(), capture_output=False, check=False)
        elif self.is_macos:
            nvim_cmd = "brew install neovim"
            result = self.run_command(nvim_cmd.split(), capture_output=False, check=False)
        else:
            return False
        return result is not None
    
    def _install_tmux(self) -> bool:
        """Install Tmux"""
        if self.is_linux:
            tmux_cmd = "sudo apt-get update && sudo apt-get install -y tmux"
            result = self.run_command(tmux_cmd.split(), capture_output=False, check=False)
        elif self.is_macos:
            tmux_cmd = "brew install tmux"
            result = self.run_command(tmux_cmd.split(), capture_output=False, check=False)
        else:
            return False
        return result is not None
    
    def _install_nodejs(self) -> bool:
        """Install Node.js using NVM"""
        if self.check_command_exists(["nvm", "--version"]):
            node_cmd = 'source ~/.nvm/nvm.sh && nvm install --lts && nvm use --lts'
            result = self.run_command(f'bash -c "{node_cmd}"'.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_python(self) -> bool:
        """Install Python using pyenv"""
        if self.check_command_exists(["pyenv", "--version"]):
            python_cmd = 'pyenv install 3.12.0 && pyenv global 3.12.0'
            result = self.run_command(f'bash -c "{python_cmd}"'.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_rust(self) -> bool:
        """Install Rust using rustup"""
        if self.check_command_exists(["rustup", "--version"]):
            rust_cmd = 'source ~/.cargo/env && rustup default stable'
            result = self.run_command(f'bash -c "{rust_cmd}"'.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_java(self) -> bool:
        """Install Java using SDKMAN!"""
        if self.check_command_exists(["sdk", "version"]):
            java_cmd = 'source ~/.sdkman/bin/sdkman-init.sh && sdk install java 17.0.9-tem && sdk default java 17.0.9-tem'
            result = self.run_command(f'bash -c "{java_cmd}"'.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_golang(self) -> bool:
        """Install Go programming language"""
        if self.is_linux:
            go_version = "1.21.5"
            go_url = f"https://go.dev/dl/go{go_version}.linux-amd64.tar.gz"
            install_cmd = f"wget {go_url} && sudo tar -C /usr/local -xzf go{go_version}.linux-amd64.tar.gz && rm go{go_version}.linux-amd64.tar.gz"
            result = self.run_command(install_cmd.split(), capture_output=False, check=False)
            return result is not None
        elif self.is_macos:
            brew_cmd = "brew install go"
            result = self.run_command(brew_cmd.split(), capture_output=False, check=False)
            return result is not None
        return False
    
    def _install_ollama(self) -> bool:
        """Install Ollama for local AI models"""
        if self.is_linux:
            ollama_cmd = "curl -fsSL https://ollama.ai/install.sh | sh"
            result = self.run_command(ollama_cmd.split(), capture_output=False, check=False)
        elif self.is_macos:
            ollama_cmd = "brew install ollama"
            result = self.run_command(ollama_cmd.split(), capture_output=False, check=False)
        else:
            return False
        return result is not None
