#!/usr/bin/env python3
"""
Portal OS - Security & Privacy Manager
Advanced security and privacy management
"""
import click
import sys
import codecs
import json
import os
import sqlite3
import hashlib
import secrets
from pathlib import Path
from datetime import datetime
import subprocess
import platform

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

class SecurityManager:
    def __init__(self):
        self.config_dir = Path.home() / ".portal-os" / "security"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.config_dir / "security.db"
        self.rules_file = self.config_dir / "adblock_rules.json"
        self._init_database()
        self._load_adblock_rules()
    
    def _init_database(self):
        """Initialize security database"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Security events table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS security_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                event_type TEXT,
                description TEXT,
                severity TEXT,
                resolved BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # Firewall rules table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS firewall_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                port INTEGER,
                protocol TEXT,
                action TEXT,
                enabled BOOLEAN DEFAULT TRUE
            )
        ''')
        
        # Privacy settings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS privacy_settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def _load_adblock_rules(self):
        """Load adblock rules from file"""
        if self.rules_file.exists():
            with open(self.rules_file, 'r') as f:
                self.adblock_rules = json.load(f)
        else:
            self.adblock_rules = {
                'enabled': True,
                'rules': [],
                'whitelist': [],
                'blacklist': []
            }
            self._save_adblock_rules()
    
    def _save_adblock_rules(self):
        """Save adblock rules to file"""
        with open(self.rules_file, 'w') as f:
            json.dump(self.adblock_rules, f, indent=2)
    
    def start(self):
        """Start security services"""
        print("🔒 Starting Security & Privacy Manager...")
        
        # Initialize security monitoring
        self._log_security_event("service_start", "Security service started", "info")
        
        # Load default firewall rules
        self._load_default_firewall_rules()
        
        # Start adblocker
        if self.adblock_rules['enabled']:
            self._start_adblocker()
        
        print("✅ Security services started successfully!")
        print("🛡️ Firewall: Active")
        print("🚫 AdBlocker: Active")
        print("🔍 Monitoring: Active")
    
    def stop(self):
        """Stop security services"""
        print("🛑 Stopping Security & Privacy Manager...")
        self._log_security_event("service_stop", "Security service stopped", "info")
        print("✅ Security services stopped")
    
    def _load_default_firewall_rules(self):
        """Load default firewall rules"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Check if rules already exist
        cursor.execute('SELECT COUNT(*) FROM firewall_rules')
        if cursor.fetchone()[0] == 0:
            # Add default rules
            default_rules = [
                ('SSH', 22, 'TCP', 'ALLOW'),
                ('HTTP', 80, 'TCP', 'ALLOW'),
                ('HTTPS', 443, 'TCP', 'ALLOW'),
                ('Block Telnet', 23, 'TCP', 'DENY'),
                ('Block FTP', 21, 'TCP', 'DENY')
            ]
            
            for name, port, protocol, action in default_rules:
                cursor.execute('''
                    INSERT INTO firewall_rules (name, port, protocol, action)
                    VALUES (?, ?, ?, ?)
                ''', (name, port, protocol, action))
        
        conn.commit()
        conn.close()
    
    def _start_adblocker(self):
        """Start adblocker service"""
        print("🚫 AdBlocker started with", len(self.adblock_rules['rules']), "rules")
    
    def _log_security_event(self, event_type, description, severity):
        """Log security event to database"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO security_events (timestamp, event_type, description, severity)
            VALUES (?, ?, ?, ?)
        ''', (datetime.now().isoformat(), event_type, description, severity))
        conn.commit()
        conn.close()
    
    def get_status(self):
        """Get security status"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Count security events
        cursor.execute('SELECT COUNT(*) FROM security_events')
        event_count = cursor.fetchone()[0]
        
        # Count firewall rules
        cursor.execute('SELECT COUNT(*) FROM firewall_rules WHERE enabled = 1')
        active_rules = cursor.fetchone()[0]
        
        # Get recent events
        cursor.execute('''
            SELECT event_type, description, severity, timestamp 
            FROM security_events 
            ORDER BY timestamp DESC 
            LIMIT 5
        ''')
        recent_events = cursor.fetchall()
        
        conn.close()
        
        return {
            'event_count': event_count,
            'active_rules': active_rules,
            'adblock_enabled': self.adblock_rules['enabled'],
            'adblock_rules': len(self.adblock_rules['rules']),
            'recent_events': recent_events
        }
    
    def add_adblock_rule(self, domain, rule_type="block"):
        """Add adblock rule"""
        if rule_type == "block":
            if domain not in self.adblock_rules['blacklist']:
                self.adblock_rules['blacklist'].append(domain)
        elif rule_type == "allow":
            if domain not in self.adblock_rules['whitelist']:
                self.adblock_rules['whitelist'].append(domain)
        
        self._save_adblock_rules()
        self._log_security_event("adblock_rule_added", f"Added {rule_type} rule for {domain}", "info")
    
    def remove_adblock_rule(self, domain, rule_type="block"):
        """Remove adblock rule"""
        if rule_type == "block":
            if domain in self.adblock_rules['blacklist']:
                self.adblock_rules['blacklist'].remove(domain)
        elif rule_type == "allow":
            if domain in self.adblock_rules['whitelist']:
                self.adblock_rules['whitelist'].remove(domain)
        
        self._save_adblock_rules()
        self._log_security_event("adblock_rule_removed", f"Removed {rule_type} rule for {domain}", "info")
    
    def add_firewall_rule(self, name, port, protocol, action):
        """Add firewall rule"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO firewall_rules (name, port, protocol, action)
            VALUES (?, ?, ?, ?)
        ''', (name, port, protocol, action))
        conn.commit()
        conn.close()
        
        self._log_security_event("firewall_rule_added", f"Added {action} rule for {protocol}:{port}", "info")
    
    def get_firewall_rules(self):
        """Get all firewall rules"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('SELECT name, port, protocol, action, enabled FROM firewall_rules')
        rules = cursor.fetchall()
        conn.close()
        return rules

# Global security manager instance
security_manager = SecurityManager()

@click.group()
def cli():
    """Security & Privacy Manager - Advanced security and privacy management"""
    pass

@cli.command()
def start():
    """Start the security and privacy service"""
    security_manager.start()

@cli.command()
def stop():
    """Stop the security and privacy service"""
    security_manager.stop()

@cli.command()
def status():
    """Check security and privacy status"""
    status_info = security_manager.get_status()
    print("🔒 Security & Privacy Status:")
    print(f"   Security Events: {status_info['event_count']}")
    print(f"   Active Firewall Rules: {status_info['active_rules']}")
    print(f"   AdBlocker: {'✅ Enabled' if status_info['adblock_enabled'] else '❌ Disabled'}")
    print(f"   AdBlock Rules: {status_info['adblock_rules']}")
    
    if status_info['recent_events']:
        print("\n📋 Recent Security Events:")
        for event_type, description, severity, timestamp in status_info['recent_events']:
            dt = datetime.fromisoformat(timestamp)
            print(f"   🕐 {dt.strftime('%H:%M:%S')} - {severity.upper()}: {description}")

@cli.command()
def adblocker():
    """Manage adblocker settings"""
    print("🚫 AdBlocker Management:")
    print(f"   Status: {'✅ Enabled' if security_manager.adblock_rules['enabled'] else '❌ Disabled'}")
    print(f"   Blocked Domains: {len(security_manager.adblock_rules['blacklist'])}")
    print(f"   Allowed Domains: {len(security_manager.adblock_rules['whitelist'])}")

@cli.command()
@click.argument('domain')
@click.option('--type', 'rule_type', default='block', help='Rule type: block or allow')
def add_adblock_rule(domain, rule_type):
    """Add adblock rule"""
    security_manager.add_adblock_rule(domain, rule_type)
    print(f"✅ Added {rule_type} rule for {domain}")

@cli.command()
@click.argument('domain')
@click.option('--type', 'rule_type', default='block', help='Rule type: block or allow')
def remove_adblock_rule(domain, rule_type):
    """Remove adblock rule"""
    security_manager.remove_adblock_rule(domain, rule_type)
    print(f"✅ Removed {rule_type} rule for {domain}")

@cli.command()
def firewall():
    """Manage firewall rules"""
    rules = security_manager.get_firewall_rules()
    print("🛡️ Firewall Rules:")
    for name, port, protocol, action, enabled in rules:
        status = "✅" if enabled else "❌"
        print(f"   {status} {name}: {protocol}:{port} -> {action}")

@cli.command()
@click.argument('name')
@click.argument('port', type=int)
@click.argument('protocol')
@click.argument('action')
def add_firewall_rule(name, port, protocol, action):
    """Add firewall rule"""
    security_manager.add_firewall_rule(name, port, protocol, action)
    print(f"✅ Added firewall rule: {name}")

@cli.command()
def scan():
    """Run security scan"""
    print("🔍 Running security scan...")
    
    # Check for common security issues
    issues = []
    
    # Check if running as root/admin
    if os.geteuid() == 0:
        issues.append("⚠️ Running with elevated privileges")
    
    # Check for open ports (simplified)
    print("   📡 Checking network ports...")
    
    # Check file permissions
    print("   📁 Checking file permissions...")
    
    # Check for suspicious processes
    print("   🔍 Checking running processes...")
    
    if issues:
        print("\n⚠️ Security Issues Found:")
        for issue in issues:
            print(f"   {issue}")
    else:
        print("✅ No security issues found")
    
    security_manager._log_security_event("security_scan", "Security scan completed", "info")

@cli.command()
def install():
    """Install security and privacy dependencies"""
    print("📦 Installing Security & Privacy Manager dependencies...")
    
    # Create necessary directories
    security_manager.config_dir.mkdir(parents=True, exist_ok=True)
    
    # Initialize database
    security_manager._init_database()
    
    # Load default rules
    security_manager._load_default_firewall_rules()
    
    print("✅ Security & Privacy Manager dependencies installed successfully!")
    print(f"📁 Config directory: {security_manager.config_dir}")

if __name__ == "__main__":
    cli()
