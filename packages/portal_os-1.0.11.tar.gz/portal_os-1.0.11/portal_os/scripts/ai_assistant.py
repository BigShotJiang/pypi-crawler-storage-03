#!/usr/bin/env python3
"""
Portal OS - AI Assistant
Conversational AI assistant with context awareness
"""
import click
import sys
import codecs
import json
import os
import sqlite3
from pathlib import Path
from datetime import datetime
import threading
import time

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

class AIAssistant:
    def __init__(self):
        self.conversation_history = []
        self.context = {}
        self.is_running = False
        self.db_path = Path.home() / ".portal-os" / "ai_assistant.db"
        self.db_path.parent.mkdir(exist_ok=True)
        self._init_database()
    
    def _init_database(self):
        """Initialize SQLite database for conversation history"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                user_input TEXT,
                ai_response TEXT,
                context TEXT
            )
        ''')
        conn.commit()
        conn.close()
    
    def start(self):
        """Start the AI assistant service"""
        self.is_running = True
        print("🤖 AI Assistant started successfully!")
        print("💬 Ready for conversations")
        print("📝 Type 'exit' to stop the assistant")
        
        # Start conversation loop
        self._conversation_loop()
    
    def stop(self):
        """Stop the AI assistant service"""
        self.is_running = False
        print("🛑 AI Assistant stopped")
    
    def _conversation_loop(self):
        """Main conversation loop"""
        while self.is_running:
            try:
                user_input = input("👤 You: ").strip()
                if user_input.lower() in ['exit', 'quit', 'stop']:
                    self.stop()
                    break
                
                if user_input:
                    response = self._process_input(user_input)
                    print(f"🤖 Assistant: {response}")
                    self._save_conversation(user_input, response)
            except KeyboardInterrupt:
                self.stop()
                break
            except EOFError:
                self.stop()
                break
    
    def _process_input(self, user_input):
        """Process user input and generate response"""
        # Simple rule-based responses (in a real implementation, this would use an LLM)
        user_input_lower = user_input.lower()
        
        # Context-aware responses
        if "hello" in user_input_lower or "hi" in user_input_lower:
            return "Hello! I'm your Portal OS AI assistant. How can I help you today?"
        
        elif "time" in user_input_lower:
            current_time = datetime.now().strftime("%H:%M:%S")
            return f"The current time is {current_time}"
        
        elif "date" in user_input_lower:
            current_date = datetime.now().strftime("%Y-%m-%d")
            return f"Today's date is {current_date}"
        
        elif "help" in user_input_lower:
            return """I can help you with:
• System information (time, date, status)
• File operations and search
• System monitoring
• Code analysis and suggestions
• General questions and conversation
Just ask me anything!"""
        
        elif "system" in user_input_lower and "status" in user_input_lower:
            return "I can check system status for you. Would you like me to run a system diagnostic?"
        
        elif "file" in user_input_lower and "search" in user_input_lower:
            return "I can help you search for files. What are you looking for?"
        
        elif "code" in user_input_lower and "analyze" in user_input_lower:
            return "I can analyze your code for improvements. Which file would you like me to look at?"
        
        else:
            # Default response with context awareness
            if len(self.conversation_history) > 0:
                return "I understand you're asking about that. Let me help you with that. Could you provide more details?"
            else:
                return "I'm here to help! What would you like to know or do?"
    
    def _save_conversation(self, user_input, ai_response):
        """Save conversation to database"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO conversations (timestamp, user_input, ai_response, context)
            VALUES (?, ?, ?, ?)
        ''', (datetime.now().isoformat(), user_input, ai_response, json.dumps(self.context)))
        conn.commit()
        conn.close()
        
        # Keep in memory for context
        self.conversation_history.append({
            'user': user_input,
            'assistant': ai_response,
            'timestamp': datetime.now()
        })
    
    def get_status(self):
        """Get AI assistant status"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM conversations')
        conversation_count = cursor.fetchone()[0]
        conn.close()
        
        return {
            'running': self.is_running,
            'conversation_count': conversation_count,
            'context_size': len(self.context)
        }

# Global AI assistant instance
ai_assistant = AIAssistant()

@click.group()
def cli():
    """AI Assistant - Conversational AI assistant with context awareness"""
    pass

@cli.command()
def start():
    """Start the AI assistant service"""
    if ai_assistant.is_running:
        print("🤖 AI Assistant is already running")
        return
    
    print("🤖 Starting AI Assistant...")
    ai_assistant.start()

@cli.command()
def stop():
    """Stop the AI assistant service"""
    if not ai_assistant.is_running:
        print("🤖 AI Assistant is not running")
        return
    
    print("🛑 Stopping AI Assistant...")
    ai_assistant.stop()

@cli.command()
def status():
    """Check AI assistant status"""
    status_info = ai_assistant.get_status()
    print("🤖 AI Assistant Status:")
    print(f"   Running: {'✅ Yes' if status_info['running'] else '❌ No'}")
    print(f"   Conversations: {status_info['conversation_count']}")
    print(f"   Context Size: {status_info['context_size']} items")

@cli.command()
def chat():
    """Start an interactive chat session"""
    if ai_assistant.is_running:
        print("🤖 AI Assistant is already running in another session")
        return
    
    print("💬 Starting chat session...")
    print("Type 'exit' to end the session")
    ai_assistant.start()

@cli.command()
def history():
    """Show conversation history"""
    conn = sqlite3.connect(str(ai_assistant.db_path))
    cursor = conn.cursor()
    cursor.execute('SELECT timestamp, user_input, ai_response FROM conversations ORDER BY timestamp DESC LIMIT 10')
    conversations = cursor.fetchall()
    conn.close()
    
    if not conversations:
        print("📝 No conversation history found")
        return
    
    print("📝 Recent Conversations:")
    print("-" * 50)
    for timestamp, user_input, ai_response in conversations:
        dt = datetime.fromisoformat(timestamp)
        print(f"🕐 {dt.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"👤 You: {user_input}")
        print(f"🤖 Assistant: {ai_response}")
        print("-" * 50)

@cli.command()
def install():
    """Install AI assistant dependencies"""
    print("📦 Installing AI Assistant dependencies...")
    
    # Create necessary directories
    db_dir = ai_assistant.db_path.parent
    db_dir.mkdir(exist_ok=True)
    
    # Initialize database
    ai_assistant._init_database()
    
    print("✅ AI Assistant dependencies installed successfully!")
    print(f"📁 Database location: {ai_assistant.db_path}")

if __name__ == "__main__":
    cli()
