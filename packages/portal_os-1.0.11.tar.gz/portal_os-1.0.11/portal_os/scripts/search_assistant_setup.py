#!/usr/bin/env python3
"""
Portal OS - Search Assistant
Intelligent file and content search
"""
import click
import sys
import codecs
import json
import os
import sqlite3
import hashlib
import time
import threading
from pathlib import Path
from datetime import datetime
import mimetypes
import re

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

class SearchAssistant:
    def __init__(self):
        self.config_dir = Path.home() / ".portal-os" / "search"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.config_dir / "search_index.db"
        self.index_dir = self.config_dir / "index"
        self.index_dir.mkdir(exist_ok=True)
        self._init_database()
        self.is_indexing = False
        self.index_thread = None
        self.indexed_files = set()
        self.searchable_extensions = {
            '.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml',
            '.csv', '.log', '.conf', '.ini', '.cfg', '.yml', '.yaml'
        }
    
    def _init_database(self):
        """Initialize search database"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Files table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS indexed_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT UNIQUE,
                file_name TEXT,
                file_size INTEGER,
                file_type TEXT,
                last_modified TEXT,
                content_hash TEXT,
                indexed_at TEXT
            )
        ''')
        
        # Search index table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS search_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER,
                word TEXT,
                position INTEGER,
                context TEXT,
                FOREIGN KEY (file_id) REFERENCES indexed_files (id)
            )
        ''')
        
        # Search history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS search_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT,
                results_count INTEGER,
                timestamp TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def start(self):
        """Start the search assistant service"""
        print("🔍 Starting Search Assistant...")
        
        # Load existing index
        self._load_indexed_files()
        
        # Start background indexing
        self.start_indexing()
        
        print("✅ Search Assistant started successfully!")
        print("📁 Indexing: Active")
        print("🔍 Search: Ready")
        print("📊 Index Size:", len(self.indexed_files), "files")
    
    def stop(self):
        """Stop the search assistant service"""
        print("🛑 Stopping Search Assistant...")
        self.stop_indexing()
        print("✅ Search Assistant stopped")
    
    def _load_indexed_files(self):
        """Load list of already indexed files"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('SELECT file_path FROM indexed_files')
        for (file_path,) in cursor.fetchall():
            self.indexed_files.add(file_path)
        conn.close()
    
    def start_indexing(self):
        """Start background indexing"""
        if self.is_indexing:
            return
        
        self.is_indexing = True
        self.index_thread = threading.Thread(target=self._index_loop, daemon=True)
        self.index_thread.start()
        print("📁 Background indexing started")
    
    def stop_indexing(self):
        """Stop background indexing"""
        self.is_indexing = False
        if self.index_thread:
            self.index_thread.join(timeout=1)
        print("📁 Background indexing stopped")
    
    def _index_loop(self):
        """Background indexing loop"""
        while self.is_indexing:
            try:
                # Index current directory
                self._index_directory(Path.cwd())
                time.sleep(30)  # Index every 30 seconds
            except Exception as e:
                print(f"⚠️ Indexing error: {e}")
                time.sleep(60)
    
    def _index_directory(self, directory):
        """Index a directory for searchable files"""
        try:
            for file_path in directory.rglob('*'):
                if file_path.is_file() and self._should_index_file(file_path):
                    if str(file_path) not in self.indexed_files:
                        self._index_file(file_path)
        except PermissionError:
            pass  # Skip directories we can't access
    
    def _should_index_file(self, file_path):
        """Check if file should be indexed"""
        # Check file extension
        if file_path.suffix.lower() in self.searchable_extensions:
            return True
        
        # Check file size (skip large files)
        try:
            if file_path.stat().st_size > 10 * 1024 * 1024:  # 10MB limit
                return False
        except (OSError, PermissionError):
            return False
        
        return False
    
    def _index_file(self, file_path):
        """Index a single file"""
        try:
            # Get file info
            stat = file_path.stat()
            file_size = stat.st_size
            last_modified = datetime.fromtimestamp(stat.st_mtime).isoformat()
            
            # Read file content
            content = self._read_file_content(file_path)
            if not content:
                return
            
            # Calculate content hash
            content_hash = hashlib.md5(content.encode()).hexdigest()
            
            # Check if file has changed
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('SELECT content_hash FROM indexed_files WHERE file_path = ?', (str(file_path),))
            result = cursor.fetchone()
            
            if result and result[0] == content_hash:
                # File hasn't changed, skip indexing
                conn.close()
                return
            
            # Remove old index entries
            cursor.execute('DELETE FROM indexed_files WHERE file_path = ?', (str(file_path),))
            
            # Insert file record
            cursor.execute('''
                INSERT INTO indexed_files (file_path, file_name, file_size, file_type, last_modified, content_hash, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (str(file_path), file_path.name, file_size, file_path.suffix, 
                  last_modified, content_hash, datetime.now().isoformat()))
            
            file_id = cursor.lastrowid
            
            # Index content
            self._index_content(cursor, file_id, content)
            
            conn.commit()
            conn.close()
            
            self.indexed_files.add(str(file_path))
            print(f"📄 Indexed: {file_path.name}")
            
        except Exception as e:
            print(f"⚠️ Failed to index {file_path}: {e}")
    
    def _read_file_content(self, file_path):
        """Read file content safely"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except (UnicodeDecodeError, PermissionError, OSError):
            return None
    
    def _index_content(self, cursor, file_id, content):
        """Index file content for search"""
        # Simple word-based indexing
        words = re.findall(r'\b\w+\b', content.lower())
        
        for position, word in enumerate(words):
            if len(word) > 2:  # Skip very short words
                # Get context (surrounding words)
                start = max(0, position - 5)
                end = min(len(words), position + 6)
                context = ' '.join(words[start:end])
                
                cursor.execute('''
                    INSERT INTO search_index (file_id, word, position, context)
                    VALUES (?, ?, ?, ?)
                ''', (file_id, word, position, context))
    
    def search(self, query, limit=20):
        """Search for files containing the query"""
        if not query.strip():
            return []
        
        # Log search
        self._log_search(query)
        
        # Perform search
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Search in indexed content
        search_terms = query.lower().split()
        results = []
        
        for term in search_terms:
            cursor.execute('''
                SELECT DISTINCT f.file_path, f.file_name, f.file_type, si.context, 
                       COUNT(si.id) as match_count
                FROM indexed_files f
                JOIN search_index si ON f.id = si.file_id
                WHERE si.word LIKE ?
                GROUP BY f.id
                ORDER BY match_count DESC
                LIMIT ?
            ''', (f'%{term}%', limit))
            
            for file_path, file_name, file_type, context, match_count in cursor.fetchall():
                results.append({
                    'file_path': file_path,
                    'file_name': file_name,
                    'file_type': file_type,
                    'context': context,
                    'match_count': match_count,
                    'relevance': match_count
                })
        
        conn.close()
        
        # Sort by relevance and remove duplicates
        seen_paths = set()
        unique_results = []
        for result in sorted(results, key=lambda x: x['relevance'], reverse=True):
            if result['file_path'] not in seen_paths:
                seen_paths.add(result['file_path'])
                unique_results.append(result)
        
        return unique_results[:limit]
    
    def _log_search(self, query):
        """Log search query"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO search_history (query, results_count, timestamp)
            VALUES (?, ?, ?)
        ''', (query, 0, datetime.now().isoformat()))
        conn.commit()
        conn.close()
    
    def get_status(self):
        """Get search assistant status"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM indexed_files')
        indexed_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM search_index')
        index_entries = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM search_history')
        search_count = cursor.fetchone()[0]
        
        # Get recent searches
        cursor.execute('''
            SELECT query, results_count, timestamp 
            FROM search_history 
            ORDER BY timestamp DESC 
            LIMIT 5
        ''')
        recent_searches = cursor.fetchall()
        
        conn.close()
        
        return {
            'indexing': self.is_indexing,
            'indexed_files': indexed_count,
            'index_entries': index_entries,
            'search_count': search_count,
            'recent_searches': recent_searches
        }
    
    def reindex(self):
        """Reindex all files"""
        print("🔄 Reindexing all files...")
        
        # Clear existing index
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('DELETE FROM indexed_files')
        cursor.execute('DELETE FROM search_index')
        conn.commit()
        conn.close()
        
        self.indexed_files.clear()
        
        # Reindex current directory
        self._index_directory(Path.cwd())
        
        print("✅ Reindexing completed")

# Global search assistant instance
search_assistant = SearchAssistant()

@click.group()
def cli():
    """Search Assistant - Intelligent file and content search"""
    pass

@cli.command()
def start():
    """Start the search assistant service"""
    search_assistant.start()

@cli.command()
def stop():
    """Stop the search assistant service"""
    search_assistant.stop()

@cli.command()
def status():
    """Check search assistant status"""
    status_info = search_assistant.get_status()
    print("🔍 Search Assistant Status:")
    print(f"   Indexing: {'✅ Active' if status_info['indexing'] else '❌ Inactive'}")
    print(f"   Indexed Files: {status_info['indexed_files']}")
    print(f"   Index Entries: {status_info['index_entries']}")
    print(f"   Search Count: {status_info['search_count']}")
    
    if status_info['recent_searches']:
        print("\n📋 Recent Searches:")
        for query, results_count, timestamp in status_info['recent_searches']:
            dt = datetime.fromisoformat(timestamp)
            print(f"   🕐 {dt.strftime('%H:%M:%S')} - '{query}' ({results_count} results)")

@cli.command()
@click.argument('query')
@click.option('--limit', default=10, help='Maximum number of results')
def search(query, limit):
    """Search for files containing the query"""
    print(f"🔍 Searching for: '{query}'")
    results = search_assistant.search(query, limit)
    
    if not results:
        print("❌ No results found")
        return
    
    print(f"✅ Found {len(results)} results:")
    print("-" * 60)
    
    for i, result in enumerate(results, 1):
        print(f"{i}. 📄 {result['file_name']}")
        print(f"   📁 {result['file_path']}")
        print(f"   🔍 Matches: {result['match_count']}")
        if result['context']:
            context = result['context'][:100] + "..." if len(result['context']) > 100 else result['context']
            print(f"   💬 Context: {context}")
        print()

@cli.command()
def index():
    """Index current directory"""
    print("📁 Indexing current directory...")
    search_assistant._index_directory(Path.cwd())
    print("✅ Indexing completed")

@cli.command()
def reindex():
    """Reindex all files"""
    search_assistant.reindex()

@cli.command()
def history():
    """Show search history"""
    conn = sqlite3.connect(str(search_assistant.db_path))
    cursor = conn.cursor()
    cursor.execute('''
        SELECT query, results_count, timestamp 
        FROM search_history 
        ORDER BY timestamp DESC 
        LIMIT 20
    ''')
    searches = cursor.fetchall()
    conn.close()
    
    if not searches:
        print("📝 No search history found")
        return
    
    print("📝 Search History:")
    print("-" * 50)
    for query, results_count, timestamp in searches:
        dt = datetime.fromisoformat(timestamp)
        print(f"🕐 {dt.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"🔍 '{query}' ({results_count} results)")
        print("-" * 50)

@cli.command()
def install():
    """Install search assistant dependencies"""
    print("📦 Installing Search Assistant dependencies...")
    
    # Create necessary directories
    search_assistant.config_dir.mkdir(parents=True, exist_ok=True)
    search_assistant.index_dir.mkdir(exist_ok=True)
    
    # Initialize database
    search_assistant._init_database()
    
    print("✅ Search Assistant dependencies installed successfully!")
    print(f"📁 Config directory: {search_assistant.config_dir}")
    print(f"📁 Index directory: {search_assistant.index_dir}")

if __name__ == "__main__":
    cli()
