#!/usr/bin/env python3
"""
Portal OS - Performance Optimizer
System performance optimization and monitoring
"""
import click
import sys
import codecs
import json
import os
import sqlite3
import psutil
import time
import threading
from pathlib import Path
from datetime import datetime
import subprocess
import platform

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

class PerformanceOptimizer:
    def __init__(self):
        self.config_dir = Path.home() / ".portal-os" / "performance"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.config_dir / "performance.db"
        self.cache_dir = self.config_dir / "cache"
        self.cache_dir.mkdir(exist_ok=True)
        self._init_database()
        self.is_monitoring = False
        self.monitor_thread = None
        self.performance_data = {
            'cpu_usage': [],
            'memory_usage': [],
            'disk_usage': [],
            'network_usage': []
        }
    
    def _init_database(self):
        """Initialize performance database"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Performance metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                cpu_percent REAL,
                memory_percent REAL,
                disk_percent REAL,
                network_sent REAL,
                network_recv REAL
            )
        ''')
        
        # Optimization events table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimization_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                event_type TEXT,
                description TEXT,
                impact TEXT
            )
        ''')
        
        # Cache statistics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                cache_type TEXT,
                size_mb REAL,
                hit_rate REAL
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def start(self):
        """Start performance monitoring and optimization"""
        print("⚡ Starting Performance Optimizer...")
        
        # Initialize caches
        self._init_caches()
        
        # Start monitoring
        self.start_monitoring()
        
        # Run initial optimization
        self._run_optimization()
        
        print("✅ Performance Optimizer started successfully!")
        print("📊 Monitoring: Active")
        print("🚀 Optimization: Active")
        print("💾 Caching: Active")
    
    def stop(self):
        """Stop performance monitoring"""
        print("🛑 Stopping Performance Optimizer...")
        self.stop_monitoring()
        print("✅ Performance Optimizer stopped")
    
    def _init_caches(self):
        """Initialize caching systems"""
        # Memory cache (in-memory)
        self.memory_cache = {}
        
        # Disk cache (SQLite)
        self._init_disk_cache()
        
        # Create cache directories
        (self.cache_dir / "temp").mkdir(exist_ok=True)
        (self.cache_dir / "logs").mkdir(exist_ok=True)
    
    def _init_disk_cache(self):
        """Initialize disk-based cache"""
        cache_db = self.cache_dir / "cache.db"
        conn = sqlite3.connect(str(cache_db))
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS disk_cache (
                key TEXT PRIMARY KEY,
                value TEXT,
                timestamp TEXT,
                ttl INTEGER
            )
        ''')
        conn.commit()
        conn.close()
    
    def start_monitoring(self):
        """Start performance monitoring in background thread"""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        print("📊 Performance monitoring started")
    
    def stop_monitoring(self):
        """Stop performance monitoring"""
        self.is_monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=1)
        print("📊 Performance monitoring stopped")
    
    def _monitor_loop(self):
        """Background monitoring loop"""
        while self.is_monitoring:
            try:
                # Collect system metrics
                cpu_percent = psutil.cpu_percent(interval=1)
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                network = psutil.net_io_counters()
                
                # Store metrics
                self._store_metrics(cpu_percent, memory.percent, disk.percent, 
                                  network.bytes_sent, network.bytes_recv)
                
                # Check for optimization triggers
                if cpu_percent > 80 or memory.percent > 85:
                    self._trigger_optimization("high_usage")
                
                time.sleep(5)  # Monitor every 5 seconds
                
            except Exception as e:
                print(f"⚠️ Monitoring error: {e}")
                time.sleep(10)
    
    def _store_metrics(self, cpu_percent, memory_percent, disk_percent, 
                      network_sent, network_recv):
        """Store performance metrics in database"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO performance_metrics 
            (timestamp, cpu_percent, memory_percent, disk_percent, network_sent, network_recv)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (datetime.now().isoformat(), cpu_percent, memory_percent, 
              disk_percent, network_sent, network_recv))
        conn.commit()
        conn.close()
        
        # Keep recent data in memory
        self.performance_data['cpu_usage'].append(cpu_percent)
        self.performance_data['memory_usage'].append(memory_percent)
        self.performance_data['disk_usage'].append(disk_percent)
        
        # Keep only last 100 data points
        for key in self.performance_data:
            if len(self.performance_data[key]) > 100:
                self.performance_data[key] = self.performance_data[key][-100:]
    
    def _trigger_optimization(self, trigger_type):
        """Trigger optimization based on conditions"""
        print(f"🚀 Triggering optimization due to {trigger_type}")
        self._run_optimization()
    
    def _run_optimization(self):
        """Run performance optimization"""
        optimizations = []
        
        # Memory optimization
        memory = psutil.virtual_memory()
        if memory.percent > 80:
            self._optimize_memory()
            optimizations.append("memory_cleanup")
        
        # Cache optimization
        self._optimize_caches()
        optimizations.append("cache_optimization")
        
        # Process optimization
        self._optimize_processes()
        optimizations.append("process_optimization")
        
        # Log optimization event
        if optimizations:
            self._log_optimization_event("auto_optimization", 
                                       f"Applied optimizations: {', '.join(optimizations)}", 
                                       "medium")
    
    def _optimize_memory(self):
        """Optimize memory usage"""
        # Clear memory cache if it's too large
        if len(self.memory_cache) > 1000:
            self.memory_cache.clear()
            print("🧹 Cleared memory cache")
        
        # Suggest garbage collection
        import gc
        gc.collect()
    
    def _optimize_caches(self):
        """Optimize cache usage"""
        # Clean up expired cache entries
        cache_db = self.cache_dir / "cache.db"
        conn = sqlite3.connect(str(cache_db))
        cursor = conn.cursor()
        cursor.execute('DELETE FROM disk_cache WHERE ttl < ?', (int(time.time()),))
        conn.commit()
        conn.close()
    
    def _optimize_processes(self):
        """Optimize running processes"""
        # Find processes using too much CPU
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent']):
            try:
                if proc.info['cpu_percent'] > 50:
                    print(f"⚠️ High CPU process: {proc.info['name']} ({proc.info['cpu_percent']}%)")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    
    def _log_optimization_event(self, event_type, description, impact):
        """Log optimization event"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO optimization_events (timestamp, event_type, description, impact)
            VALUES (?, ?, ?, ?)
        ''', (datetime.now().isoformat(), event_type, description, impact))
        conn.commit()
        conn.close()
    
    def get_status(self):
        """Get performance status"""
        # Get current metrics
        cpu_percent = psutil.cpu_percent()
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Get database stats
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM performance_metrics')
        metrics_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM optimization_events')
        events_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT AVG(cpu_percent) FROM performance_metrics ORDER BY timestamp DESC LIMIT 10')
        avg_cpu = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            'monitoring': self.is_monitoring,
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'disk_percent': disk.percent,
            'avg_cpu': round(avg_cpu, 1),
            'metrics_count': metrics_count,
            'events_count': events_count,
            'cache_size': len(self.memory_cache)
        }
    
    def optimize(self):
        """Run manual optimization"""
        print("🚀 Running manual optimization...")
        
        # Clear caches
        self.memory_cache.clear()
        self._optimize_caches()
        
        # Run garbage collection
        import gc
        gc.collect()
        
        # Optimize processes
        self._optimize_processes()
        
        self._log_optimization_event("manual_optimization", "Manual optimization performed", "high")
        print("✅ Optimization completed")
    
    def monitor(self):
        """Show real-time monitoring"""
        print("📊 Real-time Performance Monitoring")
        print("Press Ctrl+C to stop")
        
        try:
            while True:
                cpu_percent = psutil.cpu_percent()
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                print(f"\r🖥️ CPU: {cpu_percent:5.1f}% | "
                      f"💾 Memory: {memory.percent:5.1f}% | "
                      f"💿 Disk: {disk.percent:5.1f}%", end='', flush=True)
                
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n📊 Monitoring stopped")

# Global performance optimizer instance
performance_optimizer = PerformanceOptimizer()

@click.group()
def cli():
    """Performance Optimizer - System performance optimization and monitoring"""
    pass

@cli.command()
def start():
    """Start the performance optimizer service"""
    performance_optimizer.start()

@cli.command()
def stop():
    """Stop the performance optimizer service"""
    performance_optimizer.stop()

@cli.command()
def status():
    """Check performance optimizer status"""
    status_info = performance_optimizer.get_status()
    print("⚡ Performance Optimizer Status:")
    print(f"   Monitoring: {'✅ Active' if status_info['monitoring'] else '❌ Inactive'}")
    print(f"   Current CPU: {status_info['cpu_percent']:.1f}%")
    print(f"   Current Memory: {status_info['memory_percent']:.1f}%")
    print(f"   Current Disk: {status_info['disk_percent']:.1f}%")
    print(f"   Average CPU (10 samples): {status_info['avg_cpu']:.1f}%")
    print(f"   Metrics Recorded: {status_info['metrics_count']}")
    print(f"   Optimization Events: {status_info['events_count']}")
    print(f"   Cache Size: {status_info['cache_size']} items")

@cli.command()
def optimize():
    """Run performance optimization"""
    performance_optimizer.optimize()

@cli.command()
def monitor():
    """Show real-time performance monitoring"""
    performance_optimizer.monitor()

@cli.command()
def cache():
    """Manage cache settings"""
    print("💾 Cache Management:")
    print(f"   Memory Cache: {len(performance_optimizer.memory_cache)} items")
    print(f"   Cache Directory: {performance_optimizer.cache_dir}")
    
    # Show cache directory size
    total_size = 0
    file_count = 0
    for file_path in performance_optimizer.cache_dir.rglob('*'):
        if file_path.is_file():
            total_size += file_path.stat().st_size
            file_count += 1
    
    print(f"   Cache Files: {file_count}")
    print(f"   Cache Size: {total_size / (1024*1024):.1f} MB")

@cli.command()
def clear_cache():
    """Clear all caches"""
    print("🧹 Clearing caches...")
    
    # Clear memory cache
    performance_optimizer.memory_cache.clear()
    
    # Clear disk cache
    cache_db = performance_optimizer.cache_dir / "cache.db"
    if cache_db.exists():
        conn = sqlite3.connect(str(cache_db))
        cursor = conn.cursor()
        cursor.execute('DELETE FROM disk_cache')
        conn.commit()
        conn.close()
    
    # Clear temp files
    temp_dir = performance_optimizer.cache_dir / "temp"
    for file_path in temp_dir.glob('*'):
        if file_path.is_file():
            file_path.unlink()
    
    print("✅ All caches cleared")

@cli.command()
def install():
    """Install performance optimizer dependencies"""
    print("📦 Installing Performance Optimizer dependencies...")
    
    # Create necessary directories
    performance_optimizer.config_dir.mkdir(parents=True, exist_ok=True)
    performance_optimizer.cache_dir.mkdir(exist_ok=True)
    
    # Initialize database
    performance_optimizer._init_database()
    
    # Initialize caches
    performance_optimizer._init_caches()
    
    print("✅ Performance Optimizer dependencies installed successfully!")
    print(f"📁 Config directory: {performance_optimizer.config_dir}")
    print(f"💾 Cache directory: {performance_optimizer.cache_dir}")

if __name__ == "__main__":
    cli()
