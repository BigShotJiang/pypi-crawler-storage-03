#!/usr/bin/env python3
"""
Portal OS Component Downloader
Downloads Portal OS components directly to Ubuntu VM
"""

import os
import sys
import json
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Optional

def create_component_package():
    """Create a downloadable component package"""
    project_root = Path(__file__).parent.parent
    build_dir = project_root / "build"
    portal_dir = build_dir / "portal-os-components"
    
    if not portal_dir.exists():
        print("❌ Portal OS components not found. Run the Windows builder first.")
        return False
    
    # Create a simple package structure
    package_dir = project_root / "portal-os-package"
    package_dir.mkdir(exist_ok=True)
    
    # Copy components
    shutil.copytree(portal_dir, package_dir / "portal-os-components", dirs_exist_ok=True)
    
    # Create installation script
    install_script = package_dir / "install-portal-os.sh"
    with open(install_script, 'w', encoding='utf-8') as f:
        f.write("""#!/bin/bash
# Portal OS Installation Script
echo "🚀 Installing Portal OS components..."

# Create Portal OS directory
sudo mkdir -p /opt/portal-os

# Copy components
sudo cp -r portal-os-components/opt/portal-os/* /opt/portal-os/

# Make scripts executable
sudo chmod +x /opt/portal-os/scripts/*.py
sudo chmod +x /opt/portal-os/portal-os

# Install Python dependencies
cd /opt/portal-os
sudo apt update
sudo apt install -y python3-pip
pip3 install -r requirements.txt

# Create desktop shortcut
cat > ~/Desktop/Portal\\ OS.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Portal OS
Comment=AI-Native Developer Operating System
Exec=/opt/portal-os/portal-os
Icon=system-run
Terminal=true
Categories=System;
EOF

chmod +x ~/Desktop/Portal\\ OS.desktop

# Add to applications menu
mkdir -p ~/.local/share/applications
cp ~/Desktop/Portal\\ OS.desktop ~/.local/share/applications/

echo "✅ Portal OS installation complete!"
echo "You can now run: /opt/portal-os/portal-os --help"
""")
    
    os.chmod(install_script, 0o755)
    
    print(f"✅ Portal OS package created: {package_dir}")
    print(f"📁 Package contents:")
    print(f"   - portal-os-components/ (Portal OS files)")
    print(f"   - install-portal-os.sh (Installation script)")
    
    return True

def main():
    """Main entry point"""
    print("📦 Creating Portal OS Component Package")
    print("=" * 40)
    
    if create_component_package():
        print("\n🎯 Next steps:")
        print("1. Copy the 'portal-os-package' folder to your Ubuntu VM")
        print("2. In Ubuntu VM, run: ./install-portal-os.sh")
        print("3. Test with: /opt/portal-os/portal-os --help")
    else:
        print("❌ Failed to create package")
        sys.exit(1)

if __name__ == "__main__":
    main()
