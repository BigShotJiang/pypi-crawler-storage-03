"""
Portal OS Scripts Package
Contains all the executable scripts for Portal OS functionality
"""

__version__ = "1.0.0"
__author__ = "Portal OS Team"
__email__ = "team@portal-os.dev"
