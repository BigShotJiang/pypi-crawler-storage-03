#!/usr/bin/env python3
"""
Portal OS Migration Helper
Automates the reorganization of the Portal OS project structure
"""

import os
import shutil
import json
import subprocess
from pathlib import Path
from typing import Dict, List, Optional
import click

# Version information
__version__ = "1.0.0"

class MigrationHelper:
    """Helper class for Portal OS project migration"""
    
    def __init__(self):
        self.project_root = Path.cwd()
        self.backup_dir = self.project_root.parent / "portal-os-backup"
        
        # New directory structure
        self.new_structure = {
            "core": {
                "cli": ["commands", "utils"],
                "config": [],
                "utils": []
            },
            "plugins": {
                "ai": ["assistant", "backend-manager", "search-assistant", "voice-interaction"],
                "developer": ["sdk-manager", "package-manager", "project-templates"],
                "ui": ["theme-manager", "ui-ux-manager", "desktop-integration"],
                "system": ["performance-optimizer", "security-privacy", "os-installer"],
                "core": ["templates"]
            },
            "scripts": {
                "build": [],
                "testing": [],
                "tools": []
            },
            "config": {
                "ai": [],
                "plugins": [],
                "themes": [],
                "system": [],
                "templates": []
            },
            "themes": ["mac-like", "windows-like", "cutefish", "minimal"],
            "profiles": ["coding", "studying", "watching", "gaming"],
            "docs": ["getting-started", "development", "user-guide", "api-reference", "troubleshooting"],
            "tests": ["unit", "integration", "e2e", "fixtures"],
            "docker": ["scripts"],
            "vmware": ["vms", "scripts"]
        }
        
        # File mapping for migration
        self.file_mapping = {
            # Core components
            "portal_os/cli.py": "core/cli/cli.py",
            "portal_os/config.py": "core/config/config.py",
            "portal_os/__init__.py": "core/__init__.py",
            
            # AI plugins
            "scripts/ai-assistant.py": "plugins/ai/assistant/ai-assistant.py",
            "scripts/ai-backend-manager.py": "plugins/ai/backend-manager/ai-backend-manager.py",
            "scripts/search-assistant-setup.py": "plugins/ai/search-assistant/search-assistant-setup.py",
            "scripts/voice-interaction.py": "plugins/ai/voice-interaction/voice-interaction.py",
            "scripts/advanced-ai-features.py": "plugins/ai/assistant/advanced-ai-features.py",
            
            # Developer plugins
            "scripts/sdk-manager.py": "plugins/developer/sdk-manager/sdk-manager.py",
            "scripts/portal-package-manager.py": "plugins/developer/package-manager/portal-package-manager.py",
            
            # UI plugins
            "scripts/theme-manager.py": "plugins/ui/theme-manager/theme-manager.py",
            "scripts/ui-ux-manager.py": "plugins/ui/ui-ux-manager/ui-ux-manager.py",
            
            # System plugins
            "scripts/performance-optimizer.py": "plugins/system/performance-optimizer/performance-optimizer.py",
            "scripts/security-privacy-manager.py": "plugins/system/security-privacy/security-privacy-manager.py",
            "scripts/os-installer.py": "plugins/system/os-installer/os-installer.py",
            "scripts/privacy-manager.py": "plugins/system/security-privacy/privacy-manager.py",
            
            # Core plugin infrastructure
            "scripts/plugin-manager.py": "plugins/core/plugin-manager.py",
            
            # Build scripts
            "scripts/linux-iso-builder.py": "scripts/build/linux-iso-builder.py",
            "scripts/windows-portal-builder.py": "scripts/build/windows-portal-builder.py",
            "scripts/os-iso-builder.py": "scripts/build/os-iso-builder.py",
            "scripts/simple-iso-customizer.py": "scripts/build/simple-iso-customizer.py",
            "scripts/docker-cleanup.py": "scripts/build/docker-cleanup.py",
            "scripts/example-docker-cleanup.py": "scripts/build/example-docker-cleanup.py",
            
            # Testing scripts
            "scripts/docker-testing.py": "scripts/testing/docker-testing.py",
            "scripts/vmware-testing.py": "scripts/testing/vmware-testing.py",
            "scripts/prepare-vmware-test.py": "scripts/testing/prepare-vmware-test.py",
            "scripts/vmware-automation.py": "scripts/testing/vmware-automation.py",
            "scripts/test-privacy.py": "scripts/testing/test-privacy.py",
            
            # Tool scripts
            "scripts/autoinstall-config.py": "scripts/tools/autoinstall-config.py",
            "scripts/setup-vmware-shared.py": "scripts/tools/setup-vmware-shared.py",
            "scripts/example-component.py": "scripts/tools/example-component.py",
            
            # Docker files
            "Dockerfile": "docker/Dockerfile",
            "docker-compose.yml": "docker/docker-compose.yml",
            "test-docker.sh": "docker/test-docker.sh"
        }
    
    def _run_command(self, command: str, shell: bool = False) -> bool:
        """Run a command and return success status"""
        try:
            if shell:
                subprocess.run(command, shell=True, check=True, capture_output=True)
            else:
                subprocess.run(command.split(), check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError:
            return False
    
    def _write_file(self, file_path: Path, content: str) -> bool:
        """Write content to file with proper encoding"""
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception:
            return False
    
    def create_backup(self) -> bool:
        """Create backup of current project"""
        try:
            if self.backup_dir.exists():
                shutil.rmtree(self.backup_dir)
            
            click.echo(f"📦 Creating backup at {self.backup_dir}")
            shutil.copytree(self.project_root, self.backup_dir, ignore=shutil.ignore_patterns(
                '__pycache__', '*.pyc', '.git', 'build', 'node_modules'
            ))
            click.echo("✅ Backup created successfully")
            return True
        except Exception as e:
            click.echo(f"❌ Failed to create backup: {e}")
            return False
    
    def create_new_structure(self) -> bool:
        """Create new directory structure"""
        try:
            click.echo("🏗️ Creating new directory structure...")
            
            for main_dir, sub_dirs in self.new_structure.items():
                if isinstance(sub_dirs, dict):
                    # Handle nested structure
                    for sub_dir, sub_sub_dirs in sub_dirs.items():
                        main_path = self.project_root / main_dir / sub_dir
                        main_path.mkdir(parents=True, exist_ok=True)
                        
                        for sub_sub_dir in sub_sub_dirs:
                            (main_path / sub_sub_dir).mkdir(parents=True, exist_ok=True)
                elif isinstance(sub_dirs, list):
                    # Handle simple list
                    main_path = self.project_root / main_dir
                    main_path.mkdir(parents=True, exist_ok=True)
                    
                    for sub_dir in sub_dirs:
                        (main_path / sub_dir).mkdir(parents=True, exist_ok=True)
            
            click.echo("✅ New directory structure created")
            return True
        except Exception as e:
            click.echo(f"❌ Failed to create directory structure: {e}")
            return False
    
    def migrate_files(self, dry_run: bool = False) -> bool:
        """Migrate files to new structure"""
        try:
            click.echo("🔄 Migrating files to new structure...")
            
            migrated_count = 0
            for old_path, new_path in self.file_mapping.items():
                old_file = self.project_root / old_path
                new_file = self.project_root / new_path
                
                if old_file.exists():
                    if dry_run:
                        click.echo(f"  📄 Would move: {old_path} → {new_path}")
                    else:
                        new_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(old_file), str(new_file))
                        click.echo(f"  ✅ Moved: {old_path} → {new_path}")
                    migrated_count += 1
                else:
                    click.echo(f"  ⚠️  File not found: {old_path}")
            
            click.echo(f"✅ Migrated {migrated_count} files")
            return True
        except Exception as e:
            click.echo(f"❌ Failed to migrate files: {e}")
            return False
    
    def update_imports(self, dry_run: bool = False) -> bool:
        """Update import statements in Python files"""
        try:
            click.echo("🔧 Updating import statements...")
            
            # Find all Python files
            python_files = list(self.project_root.rglob("*.py"))
            
            import_updates = {
                "from core": "from core",
                "import core": "import core",
                "core.": "core."
            }
            
            updated_count = 0
            for py_file in python_files:
                if py_file.is_file():
                    try:
                        with open(py_file, 'r', encoding='utf-8') as f:
                            content = f.read()
                        
                        original_content = content
                        for old_import, new_import in import_updates.items():
                            content = content.replace(old_import, new_import)
                        
                        if content != original_content:
                            if dry_run:
                                click.echo(f"  📝 Would update: {py_file.relative_to(self.project_root)}")
                            else:
                                with open(py_file, 'w', encoding='utf-8') as f:
                                    f.write(content)
                                click.echo(f"  ✅ Updated: {py_file.relative_to(self.project_root)}")
                            updated_count += 1
                    except Exception as e:
                        click.echo(f"  ⚠️  Error updating {py_file}: {e}")
            
            click.echo(f"✅ Updated {updated_count} Python files")
            return True
        except Exception as e:
            click.echo(f"❌ Failed to update imports: {e}")
            return False
    
    def create_init_files(self) -> bool:
        """Create __init__.py files for Python packages"""
        try:
            click.echo("📦 Creating __init__.py files...")
            
            init_locations = [
                "core",
                "core/cli",
                "core/cli/commands",
                "core/cli/utils",
                "core/config",
                "core/utils",
                "plugins",
                "plugins/ai",
                "plugins/ai/assistant",
                "plugins/ai/backend-manager",
                "plugins/ai/search-assistant",
                "plugins/ai/voice-interaction",
                "plugins/developer",
                "plugins/developer/sdk-manager",
                "plugins/developer/package-manager",
                "plugins/developer/project-templates",
                "plugins/ui",
                "plugins/ui/theme-manager",
                "plugins/ui/ui-ux-manager",
                "plugins/ui/desktop-integration",
                "plugins/system",
                "plugins/system/performance-optimizer",
                "plugins/system/security-privacy",
                "plugins/system/os-installer",
                "plugins/core"
            ]
            
            for location in init_locations:
                init_file = self.project_root / location / "__init__.py"
                if not init_file.exists():
                    if self._write_file(init_file, f'"""Portal OS {location} module"""\n'):
                        click.echo(f"  ✅ Created: {location}/__init__.py")
            
            click.echo("✅ __init__.py files created")
            return True
        except Exception as e:
            click.echo(f"❌ Failed to create __init__.py files: {e}")
            return False
    
    def validate_migration(self) -> bool:
        """Validate the migration was successful"""
        try:
            click.echo("🔍 Validating migration...")
            
            # Check if key directories exist
            key_dirs = ["core", "plugins", "scripts/build", "scripts/testing", "scripts/tools"]
            for dir_path in key_dirs:
                if not (self.project_root / dir_path).exists():
                    click.echo(f"  ❌ Missing directory: {dir_path}")
                    return False
            
            # Check if key files exist
            key_files = [
                "core/cli/cli.py",
                "core/config/config.py",
                "plugins/core/plugin-manager.py"
            ]
            for file_path in key_files:
                if not (self.project_root / file_path).exists():
                    click.echo(f"  ❌ Missing file: {file_path}")
                    return False
            
            # Test Python imports
            try:
                result = subprocess.run([
                    "python", "-c", 
                    "import sys; sys.path.insert(0, '.'); import core; print('✅ Core import successful')"
                ], capture_output=True, text=True, cwd=self.project_root)
                
                if result.returncode == 0:
                    click.echo("  ✅ Python imports working")
                else:
                    click.echo(f"  ❌ Python import test failed: {result.stderr}")
                    return False
            except Exception as e:
                click.echo(f"  ❌ Python import test failed: {e}")
                return False
            
            click.echo("✅ Migration validation successful")
            return True
        except Exception as e:
            click.echo(f"❌ Migration validation failed: {e}")
            return False
    
    def rollback(self) -> bool:
        """Rollback migration using backup"""
        try:
            if not self.backup_dir.exists():
                click.echo("❌ No backup found for rollback")
                return False
            
            click.echo("🔄 Rolling back migration...")
            
            # Remove current project files (except backup)
            for item in self.project_root.iterdir():
                if item.name != "portal-os-backup":
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
            
            # Restore from backup
            for item in self.backup_dir.iterdir():
                if item.is_file():
                    shutil.copy2(item, self.project_root)
                elif item.is_dir():
                    shutil.copytree(item, self.project_root / item.name)
            
            click.echo("✅ Rollback completed successfully")
            return True
        except Exception as e:
            click.echo(f"❌ Rollback failed: {e}")
            return False

@click.group()
@click.version_option(version=__version__)
def cli():
    """Portal OS Migration Helper - Reorganize project structure"""
    pass

@cli.command()
@click.option('--dry-run', is_flag=True, help='Show what would be done without making changes')
def migrate(dry_run):
    """Perform full migration to new structure"""
    helper = MigrationHelper()
    
    click.echo("🚀 Starting Portal OS Migration")
    click.echo("=" * 50)
    
    if dry_run:
        click.echo("🔍 DRY RUN MODE - No changes will be made")
        click.echo("=" * 50)
    
    # Step 1: Create backup
    if not dry_run:
        if not helper.create_backup():
            click.echo("❌ Migration failed at backup step")
            return
    
    # Step 2: Create new structure
    if not helper.create_new_structure():
        click.echo("❌ Migration failed at structure creation")
        return
    
    # Step 3: Migrate files
    if not helper.migrate_files(dry_run):
        click.echo("❌ Migration failed at file migration")
        return
    
    # Step 4: Update imports
    if not helper.update_imports(dry_run):
        click.echo("❌ Migration failed at import updates")
        return
    
    # Step 5: Create __init__.py files
    if not dry_run:
        if not helper.create_init_files():
            click.echo("❌ Migration failed at __init__.py creation")
            return
    
    # Step 6: Validate migration
    if not dry_run:
        if not helper.validate_migration():
            click.echo("❌ Migration validation failed")
            return
    
    click.echo("=" * 50)
    if dry_run:
        click.echo("🔍 Dry run completed - review changes above")
    else:
        click.echo("✅ Migration completed successfully!")
        click.echo("📁 New structure created and files migrated")
        click.echo("🔧 Import statements updated")
        click.echo("📦 Python packages initialized")

@cli.command()
def rollback():
    """Rollback migration using backup"""
    helper = MigrationHelper()
    
    click.echo("🔄 Rolling back Portal OS migration...")
    
    if helper.rollback():
        click.echo("✅ Rollback completed successfully")
    else:
        click.echo("❌ Rollback failed")

@cli.command()
def status():
    """Show current migration status"""
    helper = MigrationHelper()
    
    click.echo("📊 Portal OS Migration Status")
    click.echo("=" * 40)
    
    # Check if backup exists
    if helper.backup_dir.exists():
        click.echo("✅ Backup exists")
    else:
        click.echo("❌ No backup found")
    
    # Check new structure
    new_dirs = ["core", "plugins", "scripts/build", "scripts/testing", "scripts/tools"]
    click.echo("\n📁 New Structure Status:")
    for dir_path in new_dirs:
        if (helper.project_root / dir_path).exists():
            click.echo(f"  ✅ {dir_path}")
        else:
            click.echo(f"  ❌ {dir_path}")
    
    # Check key files
    key_files = [
        "core/cli/cli.py",
        "core/config/config.py",
        "plugins/core/plugin-manager.py"
    ]
    click.echo("\n📄 Key Files Status:")
    for file_path in key_files:
        if (helper.project_root / file_path).exists():
            click.echo(f"  ✅ {file_path}")
        else:
            click.echo(f"  ❌ {file_path}")

@cli.command()
def cleanup():
    """Clean up migration artifacts"""
    helper = MigrationHelper()
    
    click.echo("🧹 Cleaning up migration artifacts...")
    
    # Remove backup if it exists
    if helper.backup_dir.exists():
        try:
            shutil.rmtree(helper.backup_dir)
            click.echo("✅ Backup removed")
        except Exception as e:
            click.echo(f"❌ Failed to remove backup: {e}")
    else:
        click.echo("ℹ️  No backup to remove")
    
    # Remove __pycache__ directories
    cache_dirs = list(helper.project_root.rglob("__pycache__"))
    for cache_dir in cache_dirs:
        try:
            shutil.rmtree(cache_dir)
            click.echo(f"✅ Removed: {cache_dir.relative_to(helper.project_root)}")
        except Exception as e:
            click.echo(f"❌ Failed to remove {cache_dir}: {e}")
    
    click.echo("✅ Cleanup completed")

if __name__ == "__main__":
    cli()
