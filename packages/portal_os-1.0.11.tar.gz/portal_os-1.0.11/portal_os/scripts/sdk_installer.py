#!/usr/bin/env python3
"""
Portal OS SDK Installer
Comprehensive installation of all development tools and SDK managers
"""
import os
import sys
import subprocess
import platform
from pathlib import Path
import click
import json
from datetime import datetime

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    import codecs
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

class PortalOSSDKInstaller:
    """Portal OS SDK and Development Tools Installer"""
    
    def __init__(self):
        self.system = platform.system().lower()
        self.is_linux = self.system == "linux"
        self.is_windows = self.system == "windows"
        self.is_macos = self.system == "darwin"
        
        # SDK Managers to install
        self.sdk_managers = {
            "nvm": {
                "name": "Node Version Manager (NVM)",
                "description": "Manage multiple Node.js versions",
                "install_script": self._install_nvm,
                "check_cmd": ["nvm", "--version"]
            },
            "pyenv": {
                "name": "Python Version Manager (pyenv)",
                "description": "Manage multiple Python versions",
                "install_script": self._install_pyenv,
                "check_cmd": ["pyenv", "--version"]
            },
            "rustup": {
                "name": "Rust Toolchain Manager",
                "description": "Install and manage Rust toolchains",
                "install_script": self._install_rustup,
                "check_cmd": ["rustup", "--version"]
            },
            "sdkman": {
                "name": "SDKMAN! (Java/Kotlin/Gradle)",
                "description": "Manage Java, Kotlin, Gradle, and other JVM tools",
                "install_script": self._install_sdkman,
                "check_cmd": ["sdk", "version"]
            },
            "golang": {
                "name": "Go Programming Language",
                "description": "Install Go and gvm for version management",
                "install_script": self._install_golang,
                "check_cmd": ["go", "version"]
            },
            "docker": {
                "name": "Docker & Docker Compose",
                "description": "Container platform for development",
                "install_script": self._install_docker,
                "check_cmd": ["docker", "--version"]
            },
            "git": {
                "name": "Git Version Control",
                "description": "Distributed version control system",
                "install_script": self._install_git,
                "check_cmd": ["git", "--version"]
            },
            "ollama": {
                "name": "Ollama AI Models",
                "description": "Local AI model runner for Portal OS",
                "install_script": self._install_ollama,
                "check_cmd": ["ollama", "--version"]
            }
        }
        
        # Development Tools
        self.dev_tools = {
            "vscode": {
                "name": "Visual Studio Code",
                "description": "Lightweight but powerful source code editor",
                "install_script": self._install_vscode,
                "check_cmd": ["code", "--version"]
            },
            "neovim": {
                "name": "Neovim",
                "description": "Hyperextensible Vim-based text editor",
                "install_script": self._install_neovim,
                "check_cmd": ["nvim", "--version"]
            },
            "tmux": {
                "name": "Tmux Terminal Multiplexer",
                "description": "Terminal multiplexer for managing multiple sessions",
                "install_script": self._install_tmux,
                "check_cmd": ["tmux", "-V"]
            }
        }
        
        # Programming Languages
        self.languages = {
            "nodejs": {
                "name": "Node.js (Latest LTS)",
                "description": "JavaScript runtime for server-side development",
                "install_script": self._install_nodejs,
                "check_cmd": ["node", "--version"]
            },
            "python": {
                "name": "Python (Latest)",
                "description": "Python programming language",
                "install_script": self._install_python,
                "check_cmd": ["python3", "--version"]
            },
            "rust": {
                "name": "Rust Programming Language",
                "description": "Systems programming language",
                "install_script": self._install_rust,
                "check_cmd": ["rustc", "--version"]
            },
            "java": {
                "name": "Java Development Kit (JDK)",
                "description": "Java programming language and runtime",
                "install_script": self._install_java,
                "check_cmd": ["java", "-version"]
            }
        }
    
    def run_command(self, cmd, capture_output=True, check=True):
        """Run a command and return the result"""
        try:
            result = subprocess.run(
                cmd, 
                capture_output=capture_output, 
                text=True, 
                encoding='utf-8',
                shell=isinstance(cmd, str)
            )
            if check and result.returncode != 0:
                print(f"❌ Command failed: {' '.join(cmd) if isinstance(cmd, list) else cmd}")
                if result.stderr:
                    print(f"Error: {result.stderr}")
                return False
            return result
        except Exception as e:
            print(f"❌ Error running command: {e}")
            return False
    
    def check_command_exists(self, cmd):
        """Check if a command exists in PATH"""
        try:
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            return False
    
    def _install_nvm(self):
        """Install Node Version Manager (NVM)"""
        print("📦 Installing NVM (Node Version Manager)...")
        
        if self.is_linux or self.is_macos:
            # Install NVM
            nvm_install_script = "https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh"
            cmd = f'curl -o- {nvm_install_script} | bash'
            result = self.run_command(cmd, capture_output=False, check=False)
            
            if result:
                # Source NVM and install latest LTS Node.js
                source_cmd = 'source ~/.nvm/nvm.sh && nvm install --lts && nvm use --lts'
                self.run_command(f'bash -c "{source_cmd}"', capture_output=False, check=False)
                print("✅ NVM installed successfully!")
                return True
        elif self.is_windows:
            # For Windows, recommend using nvm-windows
            print("⚠️ For Windows, please install nvm-windows manually:")
            print("   https://github.com/coreybutler/nvm-windows")
            return False
        
        return False
    
    def _install_pyenv(self):
        """Install pyenv for Python version management"""
        print("📦 Installing pyenv...")
        
        if self.is_linux:
            # Install dependencies
            deps_cmd = "sudo apt-get update && sudo apt-get install -y make build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev wget curl llvm libncurses5-dev libncursesw5-dev xz-utils tk-dev libffi-dev liblzma-dev python3-openssl git"
            self.run_command(deps_cmd, capture_output=False, check=False)
            
            # Install pyenv
            pyenv_cmd = 'curl https://pyenv.run | bash'
            result = self.run_command(pyenv_cmd, capture_output=False, check=False)
            
            if result:
                print("✅ pyenv installed successfully!")
                return True
        elif self.is_macos:
            # Install via Homebrew
            brew_cmd = "brew install pyenv"
            result = self.run_command(brew_cmd, capture_output=False, check=False)
            
            if result:
                print("✅ pyenv installed successfully!")
                return True
        elif self.is_windows:
            print("⚠️ For Windows, please install pyenv-win manually:")
            print("   https://github.com/pyenv-win/pyenv-win")
            return False
        
        return False
    
    def _install_rustup(self):
        """Install Rust toolchain manager"""
        print("📦 Installing Rust toolchain...")
        
        rustup_cmd = "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y"
        result = self.run_command(rustup_cmd, capture_output=False, check=False)
        
        if result:
            # Source rustup and install components
            source_cmd = 'source ~/.cargo/env && rustup component add rust-src rust-analyzer'
            self.run_command(f'bash -c "{source_cmd}"', capture_output=False, check=False)
            print("✅ Rust toolchain installed successfully!")
            return True
        
        return False
    
    def _install_sdkman(self):
        """Install SDKMAN! for JVM tools"""
        print("📦 Installing SDKMAN!...")
        
        sdkman_cmd = "curl -s \"https://get.sdkman.io\" | bash"
        result = self.run_command(sdkman_cmd, capture_output=False, check=False)
        
        if result:
            # Source SDKMAN and install Java
            source_cmd = 'source ~/.sdkman/bin/sdkman-init.sh && sdk install java 17.0.9-tem && sdk install kotlin && sdk install gradle'
            self.run_command(f'bash -c "{source_cmd}"', capture_output=False, check=False)
            print("✅ SDKMAN! installed successfully!")
            return True
        
        return False
    
    def _install_golang(self):
        """Install Go programming language"""
        print("📦 Installing Go...")
        
        if self.is_linux:
            # Download and install Go
            go_version = "1.21.5"
            go_url = f"https://go.dev/dl/go{go_version}.linux-amd64.tar.gz"
            install_cmd = f"wget {go_url} && sudo tar -C /usr/local -xzf go{go_version}.linux-amd64.tar.gz && rm go{go_version}.linux-amd64.tar.gz"
            result = self.run_command(install_cmd, capture_output=False, check=False)
            
            if result:
                print("✅ Go installed successfully!")
                return True
        elif self.is_macos:
            brew_cmd = "brew install go"
            result = self.run_command(brew_cmd, capture_output=False, check=False)
            
            if result:
                print("✅ Go installed successfully!")
                return True
        elif self.is_windows:
            print("⚠️ For Windows, please install Go manually:")
            print("   https://golang.org/dl/")
            return False
        
        return False
    
    def _install_docker(self):
        """Install Docker and Docker Compose"""
        print("📦 Installing Docker...")
        
        if self.is_linux:
            # Install Docker
            docker_cmd = "curl -fsSL https://get.docker.com -o get-docker.sh && sudo sh get-docker.sh"
            result = self.run_command(docker_cmd, capture_output=False, check=False)
            
            if result:
                # Add user to docker group
                usermod_cmd = "sudo usermod -aG docker $USER"
                self.run_command(usermod_cmd, capture_output=False, check=False)
                print("✅ Docker installed successfully!")
                print("⚠️ Please log out and back in for docker group changes to take effect")
                return True
        elif self.is_macos:
            print("⚠️ For macOS, please install Docker Desktop manually:")
            print("   https://www.docker.com/products/docker-desktop")
            return False
        elif self.is_windows:
            print("⚠️ For Windows, please install Docker Desktop manually:")
            print("   https://www.docker.com/products/docker-desktop")
            return False
        
        return False
    
    def _install_git(self):
        """Install Git version control"""
        print("📦 Installing Git...")
        
        if self.is_linux:
            git_cmd = "sudo apt-get update && sudo apt-get install -y git"
            result = self.run_command(git_cmd, capture_output=False, check=False)
        elif self.is_macos:
            git_cmd = "brew install git"
            result = self.run_command(git_cmd, capture_output=False, check=False)
        elif self.is_windows:
            print("⚠️ For Windows, please install Git manually:")
            print("   https://git-scm.com/download/win")
            return False
        
        if result:
            print("✅ Git installed successfully!")
            return True
        
        return False
    
    def _install_ollama(self):
        """Install Ollama for local AI models"""
        print("📦 Installing Ollama...")
        
        if self.is_linux:
            ollama_cmd = "curl -fsSL https://ollama.ai/install.sh | sh"
            result = self.run_command(ollama_cmd, capture_output=False, check=False)
        elif self.is_macos:
            ollama_cmd = "brew install ollama"
            result = self.run_command(ollama_cmd, capture_output=False, check=False)
        elif self.is_windows:
            print("⚠️ For Windows, please install Ollama manually:")
            print("   https://ollama.ai/download")
            return False
        
        if result:
            print("✅ Ollama installed successfully!")
            return True
        
        return False
    
    def _install_vscode(self):
        """Install Visual Studio Code"""
        print("📦 Installing Visual Studio Code...")
        
        if self.is_linux:
            # Add Microsoft repository and install
            repo_cmd = "wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg && sudo install -o root -g root -m 644 packages.microsoft.gpg /etc/apt/trusted.gpg.d/ && sudo sh -c 'echo \"deb [arch=amd64,arm64,armhf signed-by=/etc/apt/trusted.gpg.d/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main\" > /etc/apt/sources.list.d/vscode.list'"
            self.run_command(repo_cmd, capture_output=False, check=False)
            
            install_cmd = "sudo apt-get update && sudo apt-get install -y code"
            result = self.run_command(install_cmd, capture_output=False, check=False)
        elif self.is_macos:
            brew_cmd = "brew install --cask visual-studio-code"
            result = self.run_command(brew_cmd, capture_output=False, check=False)
        elif self.is_windows:
            print("⚠️ For Windows, please install VS Code manually:")
            print("   https://code.visualstudio.com/download")
            return False
        
        if result:
            print("✅ Visual Studio Code installed successfully!")
            return True
        
        return False
    
    def _install_neovim(self):
        """Install Neovim"""
        print("📦 Installing Neovim...")
        
        if self.is_linux:
            nvim_cmd = "sudo apt-get update && sudo apt-get install -y neovim"
            result = self.run_command(nvim_cmd, capture_output=False, check=False)
        elif self.is_macos:
            nvim_cmd = "brew install neovim"
            result = self.run_command(nvim_cmd, capture_output=False, check=False)
        elif self.is_windows:
            print("⚠️ For Windows, please install Neovim manually:")
            print("   https://neovim.io/doc/user/install.html")
            return False
        
        if result:
            print("✅ Neovim installed successfully!")
            return True
        
        return False
    
    def _install_tmux(self):
        """Install Tmux"""
        print("📦 Installing Tmux...")
        
        if self.is_linux:
            tmux_cmd = "sudo apt-get update && sudo apt-get install -y tmux"
            result = self.run_command(tmux_cmd, capture_output=False, check=False)
        elif self.is_macos:
            tmux_cmd = "brew install tmux"
            result = self.run_command(tmux_cmd, capture_output=False, check=False)
        elif self.is_windows:
            print("⚠️ For Windows, please install Tmux manually:")
            print("   https://github.com/microsoft/terminal")
            return False
        
        if result:
            print("✅ Tmux installed successfully!")
            return True
        
        return False
    
    def _install_nodejs(self):
        """Install Node.js using NVM"""
        print("📦 Installing Node.js (Latest LTS)...")
        
        if self.check_command_exists(["nvm", "--version"]):
            node_cmd = 'source ~/.nvm/nvm.sh && nvm install --lts && nvm use --lts'
            result = self.run_command(f'bash -c "{node_cmd}"', capture_output=False, check=False)
            
            if result:
                print("✅ Node.js installed successfully!")
                return True
        else:
            print("⚠️ NVM not found. Please install NVM first.")
            return False
        
        return False
    
    def _install_python(self):
        """Install Python using pyenv"""
        print("📦 Installing Python (Latest)...")
        
        if self.check_command_exists(["pyenv", "--version"]):
            python_cmd = 'pyenv install 3.12.0 && pyenv global 3.12.0'
            result = self.run_command(f'bash -c "{python_cmd}"', capture_output=False, check=False)
            
            if result:
                print("✅ Python installed successfully!")
                return True
        else:
            print("⚠️ pyenv not found. Please install pyenv first.")
            return False
        
        return False
    
    def _install_rust(self):
        """Install Rust using rustup"""
        print("📦 Installing Rust...")
        
        if self.check_command_exists(["rustup", "--version"]):
            rust_cmd = 'source ~/.cargo/env && rustup default stable'
            result = self.run_command(f'bash -c "{rust_cmd}"', capture_output=False, check=False)
            
            if result:
                print("✅ Rust installed successfully!")
                return True
        else:
            print("⚠️ rustup not found. Please install rustup first.")
            return False
        
        return False
    
    def _install_java(self):
        """Install Java using SDKMAN!"""
        print("📦 Installing Java (JDK 17)...")
        
        if self.check_command_exists(["sdk", "version"]):
            java_cmd = 'source ~/.sdkman/bin/sdkman-init.sh && sdk install java 17.0.9-tem && sdk default java 17.0.9-tem'
            result = self.run_command(f'bash -c "{java_cmd}"', capture_output=False, check=False)
            
            if result:
                print("✅ Java installed successfully!")
                return True
        else:
            print("⚠️ SDKMAN! not found. Please install SDKMAN! first.")
            return False
        
        return False
    
    def install_all(self):
        """Install all SDK managers, tools, and languages"""
        print("🚀 Portal OS - Complete SDK Installation")
        print("=" * 60)
        print(f"🖥️ Platform: {platform.system()} {platform.release()}")
        print(f"🐍 Python: {sys.version.split()[0]}")
        print()
        
        # Install SDK Managers first
        print("📦 Installing SDK Managers...")
        print("-" * 40)
        for sdk_id, sdk_info in self.sdk_managers.items():
            print(f"\n🔧 Installing {sdk_info['name']}...")
            print(f"   {sdk_info['description']}")
            
            if not self.check_command_exists(sdk_info['check_cmd']):
                success = sdk_info['install_script']()
                if success:
                    print(f"✅ {sdk_info['name']} installed successfully!")
                else:
                    print(f"⚠️ {sdk_info['name']} installation had issues")
            else:
                print(f"✅ {sdk_info['name']} already installed")
        
        # Install Development Tools
        print("\n📦 Installing Development Tools...")
        print("-" * 40)
        for tool_id, tool_info in self.dev_tools.items():
            print(f"\n🔧 Installing {tool_info['name']}...")
            print(f"   {tool_info['description']}")
            
            if not self.check_command_exists(tool_info['check_cmd']):
                success = tool_info['install_script']()
                if success:
                    print(f"✅ {tool_info['name']} installed successfully!")
                else:
                    print(f"⚠️ {tool_info['name']} installation had issues")
            else:
                print(f"✅ {tool_info['name']} already installed")
        
        # Install Programming Languages
        print("\n📦 Installing Programming Languages...")
        print("-" * 40)
        for lang_id, lang_info in self.languages.items():
            print(f"\n🔧 Installing {lang_info['name']}...")
            print(f"   {lang_info['description']}")
            
            if not self.check_command_exists(lang_info['check_cmd']):
                success = lang_info['install_script']()
                if success:
                    print(f"✅ {lang_info['name']} installed successfully!")
                else:
                    print(f"⚠️ {lang_info['name']} installation had issues")
            else:
                print(f"✅ {lang_info['name']} already installed")
        
        print("\n🎉 Portal OS SDK installation complete!")
        print("📋 Run 'portal-os sdk status' to check everything")
        print("💡 Some tools may require a system restart to work properly")

@click.group()
def cli():
    """Portal OS SDK Installer - Install all development tools and SDK managers"""
    pass

@cli.command()
def install():
    """Install all SDK managers, development tools, and programming languages"""
    installer = PortalOSSDKInstaller()
    installer.install_all()

@cli.command()
def status():
    """Check status of all installed SDK managers and tools"""
    installer = PortalOSSDKInstaller()
    
    print("🔍 Portal OS SDK Status")
    print("=" * 40)
    
    all_tools = {**installer.sdk_managers, **installer.dev_tools, **installer.languages}
    
    for tool_id, tool_info in all_tools.items():
        status = "✅ Installed" if installer.check_command_exists(tool_info['check_cmd']) else "❌ Not Found"
        print(f"{status} {tool_info['name']}")
        print(f"   {tool_info['description']}")
        print()

if __name__ == "__main__":
    cli()
