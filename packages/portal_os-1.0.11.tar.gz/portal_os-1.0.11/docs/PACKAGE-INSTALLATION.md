# Portal OS Package Installation Guide

This guide covers how to install and use Portal OS as a Python package using Poetry or pip.

## 🚀 Quick Start

### Using Poetry (Recommended)

```bash
# Install Poetry if you haven't already
curl -sSL https://install.python-poetry.org | python3 -

# Clone the repository
git clone https://github.com/your-org/portal-os.git
cd portal-os

# Install dependencies and the package
poetry install

# Activate the virtual environment
poetry shell

# Run Portal OS
portal-os --help
```

### Using pip

```bash
# Clone the repository
git clone https://github.com/your-org/portal-os.git
cd portal-os

# Install in development mode
pip install -e .

# Run Portal OS
portal-os --help
```

### From PyPI (when published)

```bash
# Install directly from PyPI
pip install portal-os

# Run Portal OS
portal-os --help
```

## 📦 Package Structure

```
portal-os/
├── portal_os/                 # Main package directory
│   ├── __init__.py           # Package initialization
│   ├── config.py             # Configuration management
│   └── cli.py                # Command-line interface
├── scripts/                  # Component scripts
│   ├── ai-assistant.py
│   ├── security-privacy-manager.py
│   ├── performance-optimizer.py
│   └── ...
├── docs/                     # Documentation
├── tests/                    # Test suite
├── pyproject.toml           # Poetry configuration
├── setup.py                 # Setuptools configuration
├── requirements.txt         # pip requirements
├── MANIFEST.in              # Package manifest
├── LICENSE                  # MIT License
├── CHANGELOG.md             # Version history
└── README.md                # Project overview
```

## 🔧 Development Setup

### Prerequisites

- Python 3.8 or higher
- Poetry (recommended) or pip
- Git

### Development Installation

```bash
# Clone the repository
git clone https://github.com/your-org/portal-os.git
cd portal-os

# Install with Poetry (includes dev dependencies)
poetry install

# Install pre-commit hooks
poetry run pre-commit install

# Activate virtual environment
poetry shell
```

### Running Tests

```bash
# Run all tests
poetry run pytest

# Run with coverage
poetry run pytest --cov=portal_os

# Run specific test categories
poetry run pytest -m unit
poetry run pytest -m integration
poetry run pytest -m "not slow"
```

### Code Quality

```bash
# Format code
poetry run black .

# Sort imports
poetry run isort .

# Lint code
poetry run flake8

# Type checking
poetry run mypy portal_os/
```

## 🎯 Usage Examples

### Basic Commands

```bash
# Show help
portal-os --help

# Show system status
portal-os status

# Show available profiles
portal-os profiles

# Start with a specific profile
portal-os start-profile developer

# Stop all components
portal-os stop-all
```

### Component Management

```bash
# Start a specific component
portal-os start-component ai_assistant

# Stop a specific component
portal-os stop-component security_privacy

# Show component status
portal-os component-command ai_assistant status

# Run component-specific commands
portal-os ai start
portal-os security status
portal-os voice speak "Hello, Portal OS!"
```

### Configuration

```bash
# Show system configuration
portal-os config

# Show component configuration
portal-os config --component ai_assistant

# Create backup
portal-os backup

# Restore from backup
portal-os restore backup-file.json
```

## 🏗️ Building the Package

### Using Poetry

```bash
# Build the package
poetry build

# This creates:
# - dist/portal_os-1.0.0.tar.gz (source distribution)
# - dist/portal_os-1.0.0-py3-none-any.whl (wheel)
```

### Using setuptools

```bash
# Build source distribution
python setup.py sdist

# Build wheel
python setup.py bdist_wheel
```

## 📤 Publishing

### To PyPI (Test)

```bash
# Build the package
poetry build

# Publish to TestPyPI
poetry config repositories.testpypi https://test.pypi.org/legacy/
poetry publish --repository testpypi
```

### To PyPI (Production)

```bash
# Build the package
poetry build

# Publish to PyPI
poetry publish
```

## 🔄 Version Management

### Bumping Version

```bash
# Patch version (1.0.0 -> 1.0.1)
poetry version patch

# Minor version (1.0.0 -> 1.1.0)
poetry version minor

# Major version (1.0.0 -> 2.0.0)
poetry version major
```

### Updating Dependencies

```bash
# Update all dependencies
poetry update

# Update specific dependency
poetry update click

# Add new dependency
poetry add package-name

# Add development dependency
poetry add --group dev package-name
```

## 🐳 Docker Support

### Development Container

```bash
# Build development image
docker build -t portal-os-dev .

# Run with volume mount
docker run -it -v $(pwd):/app portal-os-dev

# Run specific commands
docker run -it portal-os-dev portal-os status
```

### Production Container

```bash
# Build production image
docker build -t portal-os --target production .

# Run production container
docker run -it portal-os
```

## 🔍 Troubleshooting

### Common Issues

1. **Import Errors**: Make sure you're in the virtual environment
   ```bash
   poetry shell
   # or
   source .venv/bin/activate
   ```

2. **Permission Errors**: On Linux/macOS, you might need sudo for some operations
   ```bash
   sudo portal-os start-component security_privacy
   ```

3. **Missing Dependencies**: Install system dependencies
   ```bash
   # Ubuntu/Debian
   sudo apt install python3-dev build-essential
   
   # macOS
   brew install python3
   ```

4. **Unicode Issues**: Ensure proper locale settings
   ```bash
   export LC_ALL=en_US.UTF-8
   export LANG=en_US.UTF-8
   ```

### Getting Help

- Check the logs: `~/.portal-os/logs/`
- Run with verbose output: `portal-os --verbose`
- Check component status: `portal-os status`
- Review configuration: `portal-os config`

## 📚 Additional Resources

- [Poetry Documentation](https://python-poetry.org/docs/)
- [Click Documentation](https://click.palletsprojects.com/)
- [Python Packaging Guide](https://packaging.python.org/)
- [Portal OS Documentation](https://portal-os.dev/docs)
