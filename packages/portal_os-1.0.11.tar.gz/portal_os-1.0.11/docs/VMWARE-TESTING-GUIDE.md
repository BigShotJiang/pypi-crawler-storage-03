# Portal OS VMware Testing Guide

## 🎯 Overview
This guide explains how to test Portal OS in VMware virtual machines, including manual setup and testing procedures.

## 📋 Prerequisites

### VMware Software
- **VMware Workstation Pro** (recommended) or **VMware Player** (free)
- Download from: https://www.vmware.com/products/workstation-pro.html
- Minimum version: VMware Workstation 16.0 or later

### System Requirements
- **Host System**: Windows 10/11, Linux, or macOS
- **RAM**: At least 8GB (4GB for VM + 4GB for host)
- **Storage**: 40GB free space for VM
- **CPU**: 64-bit processor with virtualization support

### Files Needed
- Portal OS ISO or Ubuntu base ISO
- Portal OS components (prepared by windows-portal-builder.py)

## 🛠️ Manual VMware VM Setup

### Step 1: Create New Virtual Machine

1. **Open VMware** and click "Create a New Virtual Machine"

2. **Configuration Type**: Choose "Typical (recommended)"

3. **Guest Operating System Installation**:
   - Select "I will install the operating system later"
   - Click "Next"

4. **Guest Operating System**:
   - Select "Linux"
   - Version: "Ubuntu 64-bit"
   - Click "Next"

5. **Virtual Machine Name**:
   - Name: `Portal OS Test v1.0.0`
   - Location: Choose your preferred location
   - Click "Next"

6. **Disk Capacity**:
   - Size: `40 GB` (recommended)
   - Select "Store virtual disk as a single file"
   - Click "Next"

7. **Ready to Create**: Click "Finish"

### Step 2: Configure VM Settings

1. **Right-click** the VM and select "Settings"

2. **Memory Configuration**:
   - Set memory to `4096 MB` (4GB) or higher
   - Click "OK"

3. **Processor Configuration**:
   - Set processors to `2`
   - Enable "Virtualize Intel VT-x/EPT or AMD-V/RVI"

4. **CD/DVD Configuration**:
   - Click "CD/DVD (SATA)"
   - Select "Use ISO image file"
   - Browse and select your Portal OS ISO or Ubuntu ISO
   - Check "Connect at power on"

5. **Network Configuration**:
   - Ensure "Network Adapter" is set to "NAT" (recommended)

6. **Display Configuration**:
   - Set "Accelerate 3D graphics" if available
   - Allocate sufficient video memory

### Step 3: Power On and Test

1. **Start the VM**: Click "Power on this virtual machine"

2. **Boot Process**:
   - VM should boot from the ISO
   - You should see the Portal OS boot menu (if using Portal OS ISO)
   - Or Ubuntu boot menu (if using base Ubuntu ISO)

3. **Live Session Testing**:
   - Select "Try Portal OS" or "Try Ubuntu"
   - Wait for desktop to load

## 🧪 Testing Portal OS Components

### If Using Portal OS ISO

1. **Desktop Check**:
   - Look for "Portal OS" desktop shortcut
   - Check Applications menu for Portal OS entry

2. **Component Verification**:
   - Open terminal and run: `ls /opt/portal-os/`
   - Verify Portal OS scripts are present
   - Check: `/opt/portal-os/portal-os --help`

3. **Installation Test**:
   - Run: `sudo /usr/local/bin/portal-os-installer`
   - Verify installation proceeds without errors

### If Using Ubuntu Base ISO + Manual Integration

1. **Manual Component Installation**:
   ```bash
   # Extract Portal OS components package
   cd /tmp
   wget http://your-server/portal-os-1.0.0-components.zip
   unzip portal-os-1.0.0-components.zip
   
   # Copy components
   sudo mkdir -p /opt/portal-os
   sudo cp -r portal-os-components/opt/portal-os/* /opt/portal-os/
   sudo cp -r portal-os-components/usr/* /usr/
   
   # Make executable
   sudo chmod +x /opt/portal-os/scripts/*.py
   sudo chmod +x /opt/portal-os/portal-os
   sudo chmod +x /usr/local/bin/portal-os-installer
   ```

2. **Test Portal OS**:
   ```bash
   # Test CLI
   /opt/portal-os/portal-os --help
   
   # Test components
   python3 /opt/portal-os/scripts/ai-assistant.py --help
   python3 /opt/portal-os/scripts/privacy-manager.py --help
   ```

## 📊 Testing Checklist

### ✅ Boot Process
- [ ] VM boots from ISO successfully
- [ ] Portal OS boot menu appears (custom ISO)
- [ ] Live session loads to desktop
- [ ] No critical errors during boot

### ✅ Portal OS Components
- [ ] Portal OS files present in `/opt/portal-os/`
- [ ] Scripts are executable
- [ ] CLI responds to `--help` commands
- [ ] Python dependencies load correctly

### ✅ User Interface
- [ ] Desktop shortcut present and functional
- [ ] Applications menu entry exists
- [ ] Portal OS branding visible
- [ ] Desktop environment stable

### ✅ AI Features (if applicable)
- [ ] AI assistant scripts respond
- [ ] Local AI components load
- [ ] Privacy settings accessible
- [ ] Developer tools available

### ✅ Installation Process
- [ ] Portal OS installer runs without errors
- [ ] Configuration files created correctly
- [ ] User directories set up properly
- [ ] Desktop integration completed

## 🔧 Troubleshooting

### Common Issues

**VM Won't Boot from ISO**:
- Check CD/DVD settings in VM configuration
- Ensure ISO file path is correct
- Try recreating the VM with different settings

**Portal OS Components Missing**:
- Verify ISO was created correctly
- Check if components were integrated during build
- Try manual component installation

**Performance Issues**:
- Increase VM memory allocation
- Enable hardware acceleration
- Close other applications on host

**Network Issues**:
- Switch network adapter to "Bridged" mode
- Check host firewall settings
- Verify VMware network services are running

### Error Messages

**"No bootable device found"**:
- ISO not properly mounted
- Boot order issue in VM settings

**"Permission denied" for scripts**:
- Run: `sudo chmod +x /opt/portal-os/scripts/*.py`

**Python import errors**:
- Install missing dependencies: `pip3 install -r /opt/portal-os/requirements.txt`

## 📝 Test Report Template

```markdown
# Portal OS VMware Test Report

**Date**: [DATE]
**Tester**: [YOUR NAME]
**VM Configuration**: [RAM/CPU/Storage]
**ISO Used**: [Portal OS ISO / Ubuntu Base + Components]

## Test Results

### Boot Process: ✅ / ❌
- Details: [Description]

### Portal OS Components: ✅ / ❌  
- CLI functional: ✅ / ❌
- Scripts executable: ✅ / ❌
- Dependencies resolved: ✅ / ❌

### User Interface: ✅ / ❌
- Desktop shortcut: ✅ / ❌
- Menu integration: ✅ / ❌
- Branding correct: ✅ / ❌

### Installation: ✅ / ❌
- Installer runs: ✅ / ❌
- Configuration created: ✅ / ❌
- Desktop integration: ✅ / ❌

## Issues Found
1. [Issue description]
2. [Issue description]

## Recommendations
1. [Recommendation]
2. [Recommendation]
```

## 🚀 Next Steps After Testing

1. **Report Issues**: Document any problems found
2. **Performance Testing**: Test Portal OS features thoroughly
3. **Real Hardware**: Test on physical hardware if possible
4. **User Feedback**: Gather feedback from other testers
5. **Iterate**: Improve Portal OS based on findings

---

**Happy Testing!** 🧪

For questions or support, check the Portal OS documentation or create an issue in the project repository.
