# Getting Started Guide - Personal AI-Integrated OS

## Where to Start: Phase 1 Foundation

Based on your requirements, here's the exact order to begin development:

### Step 1: Set Up Development Environment (Week 1)

#### 1.1 Install Ubuntu Base System
```bash
# Download Ubuntu 24.04 LTS
# Install in a VM or on a dedicated machine
# Ensure you have at least 50GB free space
```

#### 1.2 Install Essential Development Tools
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y git curl wget build-essential python3 python3-pip nodejs npm
sudo apt install -y docker.io docker-compose
sudo apt install -y wayland-protocols libwayland-dev
sudo apt install -y qt6-base-dev qt6-declarative-dev
sudo apt install -y gtk4-dev libadwaita-1-dev
```

#### 1.3 Set Up Project Structure
```bash
# Create project directory
mkdir -p ~/portal-os
cd ~/portal-os

# Create plugin system structure
mkdir -p {plugins,config,scripts,themes,docs}
mkdir -p plugins/{ai-assistant,developer-tools,ui-customizations,system-tweaks,app-store}
```

### Step 2: Install AI Backends (Week 1-2)

#### 2.1 Install Ollama
```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Start Ollama service
sudo systemctl enable ollama
sudo systemctl start ollama

# Download a base model for testing
ollama pull llama3.2:3b
```

#### 2.2 Install LM Studio (Alternative)
```bash
# Download LM Studio from https://lmstudio.ai/
# Install and configure for local model management
# Set up API endpoint for integration
```

#### 2.3 Set Up Gemini API
```bash
# Install Google Cloud CLI
curl https://sdk.cloud.google.com | bash
exec -l $SHELL

# Authenticate with Google Cloud
gcloud auth login

# Set up Gemini API access
gcloud config set project YOUR_PROJECT_ID
```

### Step 3: Create Plugin Architecture (Week 2-3)

#### 3.1 Create Plugin Manager
Create `scripts/plugin-manager.sh`:
```bash
#!/bin/bash
# Portal OS Plugin Manager

PLUGIN_DIR="/opt/portal-os/plugins"
CONFIG_DIR="/opt/portal-os/config"

# Plugin management functions
install_plugin() {
    local plugin_name=$1
    local plugin_path="$PLUGIN_DIR/$plugin_name"
    
    if [ -f "$plugin_path/install.sh" ]; then
        echo "Installing plugin: $plugin_name"
        bash "$plugin_path/install.sh"
    else
        echo "Error: No install script found for $plugin_name"
    fi
}

list_plugins() {
    echo "Available plugins:"
    for plugin in "$PLUGIN_DIR"/*; do
        if [ -d "$plugin" ]; then
            echo "  - $(basename "$plugin")"
        fi
    done
}

# Main script logic
case "$1" in
    install)
        install_plugin "$2"
        ;;
    list)
        list_plugins
        ;;
    *)
        echo "Usage: $0 {install|list} [plugin_name]"
        ;;
esac
```

#### 3.2 Create AI Backend Abstraction Layer
Create `scripts/ai-backend.py`:
```python
#!/usr/bin/env python3
"""
AI Backend Abstraction Layer
Supports Ollama, LM Studio, and Gemini APIs
"""

import requests
import json
import os
from abc import ABC, abstractmethod

class AIBackend(ABC):
    @abstractmethod
    def query(self, prompt: str) -> str:
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        pass

class OllamaBackend(AIBackend):
    def __init__(self, model="llama3.2:3b", base_url="http://localhost:11434"):
        self.model = model
        self.base_url = base_url
    
    def is_available(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/api/tags")
            return response.status_code == 200
        except:
            return False
    
    def query(self, prompt: str) -> str:
        data = {
            "model": self.model,
            "prompt": prompt,
            "stream": False
        }
        response = requests.post(f"{self.base_url}/api/generate", json=data)
        return response.json()["response"]

class GeminiBackend(AIBackend):
    def __init__(self, api_key=None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models"
    
    def is_available(self) -> bool:
        return bool(self.api_key)
    
    def query(self, prompt: str) -> str:
        # Implementation for Gemini API
        pass

class LMStudioBackend(AIBackend):
    def __init__(self, base_url="http://localhost:1234"):
        self.base_url = base_url
    
    def is_available(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/v1/models")
            return response.status_code == 200
        except:
            return False
    
    def query(self, prompt: str) -> str:
        # Implementation for LM Studio API
        pass

class AIBackendManager:
    def __init__(self):
        self.backends = {
            "ollama": OllamaBackend(),
            "gemini": GeminiBackend(),
            "lmstudio": LMStudioBackend()
        }
        self.current_backend = "ollama"
    
    def set_backend(self, backend_name: str):
        if backend_name in self.backends:
            self.current_backend = backend_name
            return True
        return False
    
    def query(self, prompt: str) -> str:
        backend = self.backends[self.current_backend]
        if backend.is_available():
            return backend.query(prompt)
        else:
            return "Error: AI backend not available"

if __name__ == "__main__":
    # Test the AI backend
    manager = AIBackendManager()
    response = manager.query("Hello, how are you?")
    print(f"AI Response: {response}")
```

### Step 4: Create First Plugin - AI Assistant Core (Week 3-4)

#### 4.1 Create AI Assistant Plugin Structure
```bash
mkdir -p plugins/ai-assistant/{config,scripts,themes,data}
```

#### 4.2 Create Plugin Manifest
Create `plugins/ai-assistant/manifest.json`:
```json
{
  "name": "ai-assistant",
  "version": "1.0.0",
  "description": "Core AI Assistant for Portal OS",
  "author": "Portal OS Team",
  "dependencies": ["ai-backend-manager"],
  "config": {
    "hotkey": "Ctrl+Space",
    "voice_enabled": true,
    "default_backend": "ollama"
  },
  "files": [
    "install.sh",
    "uninstall.sh",
    "config/assistant.conf",
    "scripts/assistant.py"
  ]
}
```

#### 4.3 Create Installation Script
Create `plugins/ai-assistant/install.sh`:
```bash
#!/bin/bash
# AI Assistant Plugin Installer

echo "Installing AI Assistant Plugin..."

# Copy configuration files
sudo cp config/assistant.conf /etc/portal-os/ai-assistant.conf

# Install Python dependencies
pip3 install speechrecognition pyaudio

# Set up systemd service
sudo cp scripts/assistant.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable portal-os-ai-assistant

# Set up hotkey binding
# This will be handled by the desktop environment integration

echo "AI Assistant Plugin installed successfully!"
```

### Step 5: Set Up Development Workflow (Week 4)

#### 5.1 Create Development Scripts
Create `scripts/dev-setup.sh`:
```bash
#!/bin/bash
# Development Environment Setup

echo "Setting up Portal OS development environment..."

# Install development dependencies
sudo apt install -y valgrind gdb cmake ninja-build
sudo apt install -y qtcreator qt6-tools-dev qt6-tools-dev-tools

# Set up Git hooks
cp scripts/git-hooks/* .git/hooks/
chmod +x .git/hooks/*

# Create development configuration
cp config/dev.conf.example config/dev.conf

echo "Development environment ready!"
```

#### 5.2 Create Testing Framework
Create `scripts/test-plugins.sh`:
```bash
#!/bin/bash
# Plugin Testing Framework

test_plugin() {
    local plugin_name=$1
    echo "Testing plugin: $plugin_name"
    
    # Run plugin tests
    if [ -f "plugins/$plugin_name/test.sh" ]; then
        bash "plugins/$plugin_name/test.sh"
    fi
}

# Test all plugins
for plugin in plugins/*; do
    if [ -d "$plugin" ]; then
        test_plugin "$(basename "$plugin")"
    fi
done
```

## Immediate Next Steps

1. **Start with Step 1**: Set up your Ubuntu development environment
2. **Install AI backends**: Get Ollama running first, then add Gemini API
3. **Create the plugin architecture**: Build the foundation for modular development
4. **Test the AI integration**: Ensure your AI backends work before building UI

## Quick Start Commands

```bash
# Clone this repository (when you create it)
git clone https://github.com/yourusername/portal-os.git
cd portal-os

# Run the development setup
bash scripts/dev-setup.sh

# Install AI backends
bash scripts/install-ai-backends.sh

# Test the setup
bash scripts/test-plugins.sh
```

## What You'll Have After Week 1

- ✅ Ubuntu development environment
- ✅ Ollama running with a test model
- ✅ Gemini API configured
- ✅ Basic plugin architecture
- ✅ AI backend abstraction layer
- ✅ First AI assistant plugin

This foundation will allow you to start building the UI and more advanced features in the following weeks.
