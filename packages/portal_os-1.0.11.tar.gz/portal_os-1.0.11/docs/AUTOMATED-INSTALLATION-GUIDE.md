# Portal OS Automated Installation Guide

## 🚀 Overview

This guide explains how to use Portal OS's automated installation system for consistent, reproducible testing. The system supports multiple approaches:

- **Ubuntu Autoinstall**: Automated Ubuntu installation with Portal OS integration
- **NixOS Configuration**: Declarative system configuration
- **VMware Automation**: Automated VM creation and testing
- **Docker Testing**: Safe containerized testing environment

## 📋 Prerequisites

### System Requirements
- **Host OS**: Windows 10/11, macOS, or Linux
- **VMware Workstation/Player**: For VM testing
- **Docker**: For containerized testing
- **Python 3.8+**: For automation scripts
- **Git**: For repository access

### Required Tools
```bash
# Install Python dependencies
pip install requests psutil colorama tqdm pyyaml

# Install VMware tools (if using VMware)
# Download from VMware website

# Install Docker (if using containerized testing)
# Download from docker.com
```

## 🔧 Quick Start

### 1. Generate Default Configuration
```bash
# Generate default autoinstall configuration
python scripts/autoinstall-config.py

# This creates:
# - config/installation-config.json
# - config/autoinstall/user-data (Ubuntu autoinstall)
# - config/autoinstall/configuration.nix (NixOS)
# - config/autoinstall/vmware.pkr.hcl (VMware)
# - config/test-config.json (Test scenarios)
# - config/autoinstall/install-portal-os.sh (Install script)
```

### 2. Create Custom Configuration
```bash
# Generate custom configuration
python scripts/autoinstall-config.py custom

# Generate test-specific configuration
python scripts/autoinstall-config.py test

# Generate from custom config file
python scripts/autoinstall-config.py generate my-config.json
```

### 3. Set Up VMware Testing
```bash
# Create complete test workflow (requires ISO)
python scripts/vmware-automation.py create

# Start VM
python scripts/vmware-automation.py start

# Create snapshot
python scripts/vmware-automation.py snapshot

# Restore snapshot
python scripts/vmware-automation.py restore

# Run automated test
python scripts/vmware-automation.py test
```

## 🎯 Configuration Options

### System Configuration
```json
{
  "system": {
    "hostname": "portal-os-test",
    "username": "portal",
    "password": "portal123",
    "fullname": "Portal OS Test User",
    "timezone": "UTC",
    "keyboard_layout": "us",
    "language": "en_US.UTF-8"
  }
}
```

### Storage Configuration
```json
{
  "storage": {
    "disk": "/dev/sda",
    "partition_scheme": "auto",
    "encryption": false,
    "swap_size": "4GB"
  }
}
```

### Network Configuration
```json
{
  "network": {
    "dhcp": true,
    "static_ip": null,
    "dns": ["8.8.8.8", "8.8.4.4"]
  }
}
```

### Portal OS Configuration
```json
{
  "portal_os": {
    "auto_setup": true,
    "install_ai_backends": true,
    "install_dev_tools": true,
    "configure_privacy": true,
    "create_test_user": true
  }
}
```

### Post-Install Configuration
```json
{
  "post_install": {
    "run_scripts": true,
    "reboot_after_install": true,
    "auto_login": true
  }
}
```

## 🐳 Docker Testing

### Quick Docker Test
```bash
# Test basic functionality
docker-compose --profile basic up --build

# Test development environment
docker-compose --profile development up --build

# Test AI integration
docker-compose --profile ai up --build

# Test privacy features
docker-compose --profile privacy up --build

# Test workflows
docker-compose --profile workflow up --build
```

### Interactive Docker Testing
```bash
# Start interactive shell
docker-compose --profile shell up --build

# Access the shell
docker exec -it portal-os-shell bash

# Test Portal OS commands
python3 portal-os status
python3 minimal-os-setup.py workflows
python3 scripts/ai-backend-manager.py status
```

## 🔄 VMware Automation Workflow

### 1. Initial Setup
```bash
# Build Portal OS ISO first
python scripts/os-iso-builder.py

# Generate autoinstall configuration
python scripts/autoinstall-config.py test

# Create VMware test environment
python scripts/vmware-automation.py create
```

### 2. Testing Cycle
```bash
# Restore clean snapshot
python scripts/vmware-automation.py restore

# Start VM
python scripts/vmware-automation.py start

# Run tests manually or automatically
python scripts/vmware-automation.py test

# Create new snapshot if needed
python scripts/vmware-automation.py snapshot test-results
```

### 3. Snapshot Management
```bash
# List available snapshots
python scripts/vmware-automation.py list-snapshots

# Create named snapshot
python scripts/vmware-automation.py snapshot my-test-point

# Restore specific snapshot
python scripts/vmware-automation.py restore my-test-point
```

## 📊 Test Scenarios

### Basic Functionality Test
```json
{
  "name": "basic_functionality",
  "description": "Test basic Portal OS functionality",
  "commands": [
    "python3 portal-os status",
    "python3 minimal-os-setup.py workflows",
    "python3 scripts/privacy-manager.py status"
  ],
  "expected_results": {
    "status": "success",
    "workflows_count": "> 0",
    "privacy_status": "enabled"
  }
}
```

### AI Integration Test
```json
{
  "name": "ai_integration",
  "description": "Test AI backend integration",
  "commands": [
    "python3 scripts/ai-backend-manager.py status",
    "python3 scripts/ai-backend-manager.py generate 'Hello, how are you?'"
  ],
  "expected_results": {
    "backend_status": "available",
    "response_generated": true
  }
}
```

### Workflow Execution Test
```json
{
  "name": "workflow_execution",
  "description": "Test workflow execution",
  "commands": [
    "python3 minimal-os-setup.py execute web-dev",
    "python3 minimal-os-setup.py create test-workflow 'Test workflow' 'git,node' 'echo Hello World'"
  ],
  "expected_results": {
    "workflow_executed": true,
    "workflow_created": true
  }
}
```

## 🔧 Customization

### Creating Custom Configurations

#### 1. Custom Configuration File
```json
{
  "system": {
    "hostname": "my-portal-os",
    "username": "developer",
    "password": "mypassword123"
  },
  "portal_os": {
    "install_ai_backends": true,
    "install_dev_tools": true,
    "configure_privacy": false
  },
  "packages": {
    "additional": [
      "neovim",
      "tmux",
      "zsh",
      "fzf"
    ]
  }
}
```

#### 2. Generate from Custom Config
```bash
python scripts/autoinstall-config.py generate my-config.json
```

#### 3. Programmatic Configuration
```python
from scripts.autoinstall_config import AutoinstallConfigGenerator

generator = AutoinstallConfigGenerator()
config = generator.create_custom_config(
    system_hostname="custom-portal-os",
    system_username="dev",
    portal_os_install_ai_backends=True,
    packages_additional=["neovim", "tmux"]
)
generator.save_configurations(config)
```

### VMware Customization

#### 1. Custom VM Configuration
```json
{
  "vm_name": "portal-os-custom",
  "vm_memory": 8192,
  "vm_cpus": 4,
  "vm_disk_size": "100GB",
  "vm_network": "bridged",
  "snapshot_name": "custom-clean-install"
}
```

#### 2. Custom Test Workflow
```python
from scripts.vmware_automation import VMwareAutomation

automation = VMwareAutomation()
automation.vmware_config.update({
    "vm_memory": 8192,
    "vm_cpus": 4
})
automation.save_config()
```

## 🐛 Troubleshooting

### Common Issues

#### 1. ISO Not Found
```bash
# Error: Portal OS ISO not found
# Solution: Build the ISO first
python scripts/os-iso-builder.py
```

#### 2. VMware Tools Not Found
```bash
# Error: vmrun command not found
# Solution: Install VMware Workstation/Player
# Add vmrun to PATH
export PATH=$PATH:"/Applications/VMware Fusion.app/Contents/Public"
```

#### 3. Autoinstall Server Issues
```bash
# Error: Autoinstall directory not found
# Solution: Generate configuration first
python scripts/autoinstall-config.py

# Error: Port 8080 already in use
# Solution: Change port or kill existing process
lsof -ti:8080 | xargs kill -9
```

#### 4. Docker Issues
```bash
# Error: Docker not running
# Solution: Start Docker Desktop

# Error: Permission denied
# Solution: Add user to docker group
sudo usermod -aG docker $USER
```

### Debug Mode
```bash
# Enable debug logging
export PORTAL_OS_DEBUG=1

# Run with verbose output
python scripts/autoinstall-config.py --verbose
python scripts/vmware-automation.py --debug
```

## 📈 Best Practices

### 1. Consistent Testing
- Always start from a clean snapshot
- Use the same configuration for all tests
- Document any manual steps

### 2. Configuration Management
- Version control your configurations
- Use descriptive snapshot names
- Keep configurations minimal and focused

### 3. Automation
- Automate repetitive tasks
- Use CI/CD for continuous testing
- Monitor test results

### 4. Documentation
- Document custom configurations
- Keep test scenarios updated
- Record troubleshooting steps

## 🚀 Advanced Usage

### 1. CI/CD Integration
```yaml
# GitHub Actions example
name: Portal OS Test
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Generate test config
        run: python scripts/autoinstall-config.py test
      - name: Run Docker tests
        run: docker-compose --profile basic --profile testing up --build
```

### 2. Multi-Environment Testing
```bash
# Test different configurations
python scripts/autoinstall-config.py generate configs/minimal.json
python scripts/autoinstall-config.py generate configs/full.json
python scripts/autoinstall-config.py generate configs/ai-only.json

# Run tests for each configuration
for config in minimal full ai-only; do
  python scripts/vmware-automation.py test --config $config
done
```

### 3. Performance Testing
```bash
# Monitor resource usage during tests
docker stats portal-os-dev

# Test with different resource limits
docker-compose --profile performance up --build
```

## 📞 Support

### Getting Help
- **Documentation**: Check this guide and main README
- **Issues**: Report problems in the GitHub repository
- **Community**: Join our Discord server

### Useful Commands
```bash
# Check system status
python portal-os status

# View configuration
cat config/installation-config.json

# List available workflows
python minimal-os-setup.py workflows

# Check AI backend status
python scripts/ai-backend-manager.py status

# View test results
cat config/test-config.json
```

---

**Ready to automate your Portal OS testing?** Start with the quick start guide and work your way up! 🚀
