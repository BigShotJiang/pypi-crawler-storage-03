# Portal OS Installation Guide

## 🎯 Two Ways to Use Portal OS

Portal OS can be used in two different ways, depending on your needs:

### 1. 🐍 Development Environment (Current - Ready to Use)
**What it is**: A Python-based development environment that runs on top of your existing OS
**Best for**: Developers who want to try Portal OS features without changing their OS
**Status**: ✅ **Ready to use right now**

### 2. 🖥️ Full Operating System (In Development)
**What it is**: A complete Ubuntu-based operating system with Portal OS integrated
**Best for**: Users who want the full Portal OS experience
**Status**: 🔄 **In development - ISO builder available**

---

## 🐍 Option 1: Development Environment (Recommended to Start)

### What You Get
- All Portal OS development tools and workflows
- AI integration (Ollama, Gemini, LM Studio)
- Privacy and security features
- Custom workflow management
- Cross-platform compatibility (Windows, Linux, Mac)

### Quick Start (5 minutes)

#### Prerequisites
- Python 3.8 or higher
- Git
- Internet connection

#### Installation Steps

1. **Clone the repository**
```bash
git clone https://github.com/your-org/portal-os.git
cd portal-os
```

2. **Run the setup**
```bash
python minimal-os-setup.py setup
```

3. **Start using Portal OS**
```bash
python portal-os
```

### What You Can Do Right Now

#### Test the AI Integration
```bash
# Check AI backend status
python scripts/ai-backend-manager.py status

# Generate AI responses (if you have Ollama installed)
python scripts/ai-backend-manager.py generate "Hello, how are you?"
```

#### Use Development Workflows
```bash
# List available workflows
python minimal-os-setup.py workflows

# Execute a web development workflow
python minimal-os-setup.py execute web-dev

# Create a custom workflow
python minimal-os-setup.py create my-workflow "My custom workflow" "git,node" "npm init -y,code ."
```

#### Test Privacy Features
```bash
# Check privacy status
python scripts/privacy-manager.py status

# Enable development privacy mode
python scripts/privacy-manager.py enable development
```

### Advantages of Development Environment
- ✅ **No OS changes required**
- ✅ **Works on any OS** (Windows, Linux, Mac)
- ✅ **Easy to install and uninstall**
- ✅ **All features available**
- ✅ **Perfect for testing and development**

---

## 🖥️ Option 2: Full Operating System (Advanced)

### What You Get
- Complete Ubuntu-based OS with Portal OS integrated
- Bootable ISO file
- Full system integration
- Custom desktop environment
- Pre-installed development tools

### Building the ISO (Advanced Users)

#### Prerequisites
- Linux or macOS (Windows support coming soon)
- At least 10GB free disk space
- Internet connection
- Required tools: `xorriso`, `isolinux`, `syslinux`, `rsync`, `wget`, `curl`

#### Installation Steps

1. **Install required tools (Ubuntu/Debian)**
```bash
sudo apt update
sudo apt install xorriso isolinux syslinux rsync wget curl
```

2. **Build the ISO**
```bash
python scripts/os-iso-builder.py
```

3. **Create bootable USB** (after ISO is built)
```bash
# Replace /dev/sdX with your USB device
sudo dd if=build/output/portal-os-1.0.0.iso of=/dev/sdX bs=4M status=progress
```

### What the Full OS Includes
- Ubuntu 24.04 LTS base
- Portal OS tools pre-installed
- Custom boot menu and branding
- AI backends pre-configured
- Development tools ready to use
- Privacy features enabled by default

### Advantages of Full OS
- ✅ **Complete system integration**
- ✅ **No dependency on existing OS**
- ✅ **Optimized for Portal OS features**
- ✅ **Professional installation experience**
- ✅ **Custom branding and UI**

---

## 🤔 Which Option Should You Choose?

### Choose Development Environment if:
- You want to try Portal OS quickly
- You're comfortable with your current OS
- You want to test features before committing
- You're a developer exploring the project
- You want to contribute to development

### Choose Full OS if:
- You want the complete Portal OS experience
- You're ready to replace your current OS
- You want to test the full system integration
- You're building a development machine
- You want to experience the vision as intended

---

## 🚀 Getting Started Recommendations

### For New Users
1. **Start with Development Environment** - It's ready to use and risk-free
2. **Test the features** - Try AI integration, workflows, and privacy features
3. **Learn the system** - Understand how Portal OS works
4. **Consider Full OS later** - If you love the experience, try the full OS

### For Developers
1. **Use Development Environment** - Perfect for development and testing
2. **Contribute to the project** - Help build the full OS
3. **Test the ISO builder** - Help improve the full OS installation
4. **Share feedback** - Help shape the future of Portal OS

### For Advanced Users
1. **Try both approaches** - Compare the experiences
2. **Build the ISO** - Test the full OS installation
3. **Report issues** - Help improve the system
4. **Share your experience** - Help others get started

---

## 📋 System Requirements

### Development Environment
- **OS**: Windows 10+, macOS 10.14+, Ubuntu 18.04+
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 2GB free space
- **Python**: 3.8 or higher
- **Internet**: Required for initial setup

### Full OS
- **CPU**: 4 cores, 2.0 GHz or higher
- **RAM**: 8GB minimum, 16GB recommended
- **Storage**: 50GB available space
- **Graphics**: OpenGL 3.3 compatible
- **Network**: Stable internet connection

---

## 🐛 Troubleshooting

### Development Environment Issues

#### Python Script Execution
```bash
# Make scripts executable (Linux/Mac)
chmod +x minimal-os-setup.py
chmod +x scripts/*.py

# Windows: Use python command
python minimal-os-setup.py
```

#### Missing Dependencies
```bash
# Install Python dependencies
pip install requests

# Install system dependencies (Ubuntu)
sudo apt install python3-tk build-essential
```

### Full OS Issues

#### ISO Build Fails
```bash
# Check requirements
python scripts/os-iso-builder.py --help

# Install missing tools
sudo apt install xorriso isolinux syslinux rsync wget curl
```

#### Boot Issues
- Ensure USB is properly formatted
- Check BIOS/UEFI boot settings
- Try different USB ports
- Verify ISO download integrity

---

## 📞 Support

### Getting Help
- **Documentation**: Check the `docs/` folder
- **Issues**: Report problems on GitHub
- **Community**: Join our Discord server
- **Email**: support@portal-os.com

### Common Questions

**Q: Can I use Portal OS alongside my current OS?**
A: Yes! The Development Environment runs on top of your existing OS.

**Q: Is Portal OS stable?**
A: The Development Environment is stable. The Full OS is in development.

**Q: Can I contribute to the project?**
A: Absolutely! We welcome contributions from the community.

**Q: When will the full OS be ready?**
A: We're actively developing it. The ISO builder is available for testing.

---

## 🎯 Next Steps

1. **Try the Development Environment** - Start here to experience Portal OS
2. **Explore the features** - Test AI integration, workflows, and privacy
3. **Join the community** - Share your experience and get help
4. **Contribute** - Help build the future of Portal OS

**Ready to get started?** Choose the Development Environment for a quick, risk-free experience! 🚀
