# Portal OS Search Assistant Implementation
## Modern, Open-Source Spotlight Alternative

### Overview
Portal OS will feature a robust search assistant similar to macOS Spotlight, built on modern open-source technologies with deep AI integration. This system will provide instant access to files, applications, system functions, and AI-powered assistance.

### Core Technologies

#### Primary Search Engine: **Meilisearch**
```bash
# Modern, fast, and typo-tolerant search engine
- Written in Rust for performance
- Real-time search with instant results
- Typo tolerance and fuzzy matching
- RESTful API for easy integration
- Built-in filtering and faceting
- Supports multiple languages
- Open source (MIT license)
```

#### Alternative: **Typesense**
```bash
# High-performance search engine
- Written in C++ for speed
- Real-time search with sub-second response
- Built-in analytics and insights
- Multi-tenant architecture
- RESTful API with SDKs
- Open source (GPL v3)
```

#### UI Framework: **Tauri + React/Vue**
```bash
# Modern desktop app framework
- Rust backend for performance
- Web frontend for flexibility
- Small bundle size
- Cross-platform compatibility
- Native system integration
- Open source (MIT/Apache 2.0)
```

### Search Assistant Architecture

#### Core Components
```python
# Search Assistant Core Structure
/opt/portal-os/plugins/search-assistant/
├── manifest.json
├── install.sh
├── uninstall.sh
├── config/
│   ├── search.conf
│   ├── indexers/
│   └── plugins/
├── scripts/
│   ├── search-daemon.py
│   ├── indexer.py
│   ├── ai-enhancer.py
│   └── hotkey-manager.py
├── ui/
│   ├── tauri-app/
│   ├── components/
│   └── themes/
└── data/
    ├── indexes/
    ├── cache/
    └── user-data/
```

#### Search Categories
```bash
# Comprehensive search coverage
1. Applications & System
   - Installed applications
   - System settings
   - Control panel items
   - Recent applications
   - Running processes

2. Files & Documents
   - Documents, images, videos
   - Code files and projects
   - Downloads and desktop
   - Cloud storage (Google Drive, Dropbox)
   - Recent files

3. Development Tools
   - Git repositories
   - Docker containers
   - Database connections
   - Running services
   - Project templates

4. Web & Online
   - Browser bookmarks
   - Search engines
   - Web applications
   - Social media shortcuts
   - News and RSS feeds

5. AI-Powered Features
   - Natural language queries
   - Context-aware suggestions
   - Smart file organization
   - Intelligent shortcuts
   - Learning from usage patterns
```

### Implementation Details

#### 1. Search Daemon (Python)
```python
#!/usr/bin/env python3
"""
Portal OS Search Assistant Daemon
Manages search indexing, AI enhancement, and system integration
"""

import asyncio
import json
import logging
import os
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import meilisearch
from portal_os.ai_backend import AIBackendManager

@dataclass
class SearchResult:
    id: str
    title: str
    description: str
    category: str
    icon: str
    action: str
    metadata: Dict[str, Any]
    relevance_score: float
    ai_enhanced: bool = False

class SearchIndexer:
    def __init__(self, meili_url: str = "http://localhost:7700"):
        self.client = meilisearch.Client(meili_url)
        self.index = self.client.index('portal-os-search')
        self.ai_backend = AIBackendManager()
        
    async def index_applications(self):
        """Index installed applications"""
        applications = []
        
        # System applications
        app_dirs = [
            "/usr/share/applications",
            "/usr/local/share/applications",
            f"{os.path.expanduser('~')}/.local/share/applications"
        ]
        
        for app_dir in app_dirs:
            if os.path.exists(app_dir):
                for file in os.listdir(app_dir):
                    if file.endswith('.desktop'):
                        app_path = os.path.join(app_dir, file)
                        app_data = self._parse_desktop_file(app_path)
                        if app_data:
                            applications.append({
                                'id': f"app_{app_data['name']}",
                                'title': app_data['name'],
                                'description': app_data.get('comment', ''),
                                'category': 'applications',
                                'icon': app_data.get('icon', ''),
                                'action': f"launch:{app_data['exec']}",
                                'metadata': app_data,
                                'relevance_score': 1.0
                            })
        
        await self.index.add_documents(applications)
    
    async def index_files(self, paths: List[str]):
        """Index files and documents"""
        files = []
        
        for path in paths:
            for root, dirs, filenames in os.walk(path):
                for filename in filenames:
                    file_path = os.path.join(root, filename)
                    file_data = self._get_file_metadata(file_path)
                    if file_data:
                        files.append({
                            'id': f"file_{file_path}",
                            'title': filename,
                            'description': f"File in {os.path.dirname(file_path)}",
                            'category': 'files',
                            'icon': self._get_file_icon(filename),
                            'action': f"open:{file_path}",
                            'metadata': file_data,
                            'relevance_score': self._calculate_file_relevance(file_data)
                        })
        
        await self.index.add_documents(files)
    
    async def index_development_data(self):
        """Index development-related data"""
        dev_data = []
        
        # Git repositories
        git_repos = self._find_git_repositories()
        for repo in git_repos:
            dev_data.append({
                'id': f"git_{repo['path']}",
                'title': repo['name'],
                'description': f"Git repository - {repo['branch']}",
                'category': 'development',
                'icon': 'git-icon',
                'action': f"open_project:{repo['path']}",
                'metadata': repo,
                'relevance_score': 1.0
            })
        
        # Docker containers
        docker_containers = self._get_docker_containers()
        for container in docker_containers:
            dev_data.append({
                'id': f"docker_{container['id']}",
                'title': container['name'],
                'description': f"Docker container - {container['status']}",
                'category': 'development',
                'icon': 'docker-icon',
                'action': f"docker:{container['id']}",
                'metadata': container,
                'relevance_score': 1.0
            })
        
        await self.index.add_documents(dev_data)
    
    async def enhance_with_ai(self, query: str, results: List[SearchResult]) -> List[SearchResult]:
        """Enhance search results with AI suggestions"""
        if not self.ai_backend.is_available():
            return results
        
        # Generate AI-enhanced suggestions
        ai_prompt = f"""
        User searched for: "{query}"
        Current results: {[r.title for r in results]}
        
        Suggest additional relevant actions, files, or applications that might be helpful.
        Consider context, recent usage patterns, and common developer workflows.
        """
        
        ai_suggestions = await self.ai_backend.query(ai_prompt)
        
        # Parse AI suggestions and add to results
        enhanced_results = results.copy()
        for suggestion in self._parse_ai_suggestions(ai_suggestions):
            enhanced_results.append(suggestion)
        
        return enhanced_results
    
    def _parse_desktop_file(self, file_path: str) -> Optional[Dict]:
        """Parse .desktop file to extract application information"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            app_data = {}
            current_section = None
            
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('[') and line.endswith(']'):
                    current_section = line[1:-1]
                elif '=' in line and current_section == 'Desktop Entry':
                    key, value = line.split('=', 1)
                    app_data[key] = value
            
            return app_data if 'Name' in app_data else None
        except Exception as e:
            logging.error(f"Error parsing desktop file {file_path}: {e}")
            return None
    
    def _get_file_metadata(self, file_path: str) -> Optional[Dict]:
        """Get metadata for a file"""
        try:
            stat = os.stat(file_path)
            return {
                'path': file_path,
                'size': stat.st_size,
                'modified': stat.st_mtime,
                'type': self._get_file_type(file_path),
                'extension': Path(file_path).suffix
            }
        except Exception:
            return None
    
    def _calculate_file_relevance(self, file_data: Dict) -> float:
        """Calculate relevance score for a file"""
        score = 1.0
        
        # Recent files get higher scores
        days_old = (time.time() - file_data['modified']) / (24 * 3600)
        if days_old < 7:
            score += 0.5
        elif days_old < 30:
            score += 0.2
        
        # Common file types get higher scores
        common_extensions = ['.txt', '.md', '.py', '.js', '.html', '.css', '.json']
        if file_data['extension'] in common_extensions:
            score += 0.3
        
        return min(score, 2.0)

class SearchDaemon:
    def __init__(self):
        self.indexer = SearchIndexer()
        self.observer = Observer()
        self.running = False
    
    async def start(self):
        """Start the search daemon"""
        self.running = True
        
        # Initial indexing
        await self.indexer.index_applications()
        await self.indexer.index_files([
            os.path.expanduser("~/Documents"),
            os.path.expanduser("~/Downloads"),
            os.path.expanduser("~/Desktop")
        ])
        await self.indexer.index_development_data()
        
        # Start file system monitoring
        self._start_file_monitoring()
        
        # Start API server
        await self._start_api_server()
    
    def _start_file_monitoring(self):
        """Monitor file system changes for real-time indexing"""
        event_handler = FileChangeHandler(self.indexer)
        
        for path in [
            os.path.expanduser("~/Documents"),
            os.path.expanduser("~/Downloads"),
            os.path.expanduser("~/Desktop")
        ]:
            self.observer.schedule(event_handler, path, recursive=True)
        
        self.observer.start()
    
    async def _start_api_server(self):
        """Start the search API server"""
        # Implementation for FastAPI server
        pass

class FileChangeHandler(FileSystemEventHandler):
    def __init__(self, indexer: SearchIndexer):
        self.indexer = indexer
    
    def on_created(self, event):
        if not event.is_directory:
            asyncio.create_task(self.indexer.index_files([event.src_path]))
    
    def on_modified(self, event):
        if not event.is_directory:
            asyncio.create_task(self.indexer.index_files([event.src_path]))
    
    def on_deleted(self, event):
        if not event.is_directory:
            # Remove from index
            pass

if __name__ == "__main__":
    daemon = SearchDaemon()
    asyncio.run(daemon.start())
```

#### 2. Tauri UI Application (Rust + React)
```rust
// src-tauri/src/main.rs
use tauri::{CustomMenuItem, Menu, Submenu, WindowBuilder, WindowUrl};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
struct SearchQuery {
    query: String,
    category: Option<String>,
}

#[derive(Serialize, Deserialize)]
struct SearchResult {
    id: String,
    title: String,
    description: String,
    category: String,
    icon: String,
    action: String,
    relevance_score: f64,
}

#[tauri::command]
async fn search(query: SearchQuery) -> Result<Vec<SearchResult>, String> {
    // Call the search API
    let client = reqwest::Client::new();
    let response = client
        .post("http://localhost:8080/search")
        .json(&query)
        .send()
        .await
        .map_err(|e| e.to_string())?;
    
    let results: Vec<SearchResult> = response
        .json()
        .await
        .map_err(|e| e.to_string())?;
    
    Ok(results)
}

#[tauri::command]
async fn execute_action(action: String) -> Result<(), String> {
    // Execute the action (launch app, open file, etc.)
    match action.split(':').next() {
        Some("launch") => {
            // Launch application
            let app_path = action.split(':').nth(1).unwrap();
            std::process::Command::new(app_path)
                .spawn()
                .map_err(|e| e.to_string())?;
        }
        Some("open") => {
            // Open file
            let file_path = action.split(':').nth(1).unwrap();
            std::process::Command::new("xdg-open")
                .arg(file_path)
                .spawn()
                .map_err(|e| e.to_string())?;
        }
        Some("open_project") => {
            // Open project in IDE
            let project_path = action.split(':').nth(1).unwrap();
            std::process::Command::new("code")
                .arg(project_path)
                .spawn()
                .map_err(|e| e.to_string())?;
        }
        _ => return Err("Unknown action".to_string()),
    }
    
    Ok(())
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![search, execute_action])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

```typescript
// src/App.tsx
import React, { useState, useEffect, useRef } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { SearchResult } from './types';
import SearchBar from './components/SearchBar';
import SearchResults from './components/SearchResults';
import './App.css';

function App() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const searchTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    // Handle keyboard shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        window.close();
      }
      
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < results.length - 1 ? prev + 1 : 0
        );
      }
      
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => 
          prev > 0 ? prev - 1 : results.length - 1
        );
      }
      
      if (e.key === 'Enter' && results[selectedIndex]) {
        e.preventDefault();
        executeAction(results[selectedIndex].action);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [results, selectedIndex]);

  useEffect(() => {
    if (query.trim()) {
      // Debounce search
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
      
      searchTimeoutRef.current = setTimeout(async () => {
        setLoading(true);
        try {
          const searchResults = await invoke<SearchResult[]>('search', {
            query: { query: query.trim() }
          });
          setResults(searchResults);
          setSelectedIndex(0);
        } catch (error) {
          console.error('Search error:', error);
        } finally {
          setLoading(false);
        }
      }, 150);
    } else {
      setResults([]);
      setSelectedIndex(0);
    }
  }, [query]);

  const executeAction = async (action: string) => {
    try {
      await invoke('execute_action', { action });
      window.close();
    } catch (error) {
      console.error('Action execution error:', error);
    }
  };

  return (
    <div className="search-assistant">
      <SearchBar 
        value={query}
        onChange={setQuery}
        placeholder="Search applications, files, and more..."
      />
      <SearchResults 
        results={results}
        loading={loading}
        selectedIndex={selectedIndex}
        onSelect={executeAction}
      />
    </div>
  );
}

export default App;
```

#### 3. Hotkey Manager
```python
#!/usr/bin/env python3
"""
Hotkey Manager for Search Assistant
Handles global hotkeys and system integration
"""

import subprocess
import sys
import json
from pathlib import Path
import pynput
from pynput import keyboard
from pynput.keyboard import Key, KeyCode

class HotkeyManager:
    def __init__(self, search_app_path: str):
        self.search_app_path = search_app_path
        self.listener = None
        self.hotkey_combination = {Key.cmd, KeyCode.from_char(' ')}
        self.current_keys = set()
    
    def start(self):
        """Start listening for hotkeys"""
        with keyboard.Listener(
            on_press=self._on_press,
            on_release=self._on_release
        ) as listener:
            self.listener = listener
            listener.join()
    
    def _on_press(self, key):
        """Handle key press events"""
        if key in self.hotkey_combination:
            self.current_keys.add(key)
            
            if self.current_keys == self.hotkey_combination:
                self._launch_search_assistant()
    
    def _on_release(self, key):
        """Handle key release events"""
        if key in self.current_keys:
            self.current_keys.discard(key)
    
    def _launch_search_assistant(self):
        """Launch the search assistant application"""
        try:
            subprocess.Popen([
                self.search_app_path,
                '--search-assistant'
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print(f"Error launching search assistant: {e}")

def main():
    # Get the search assistant app path
    app_path = Path(__file__).parent / "ui" / "tauri-app" / "search-assistant"
    
    manager = HotkeyManager(str(app_path))
    print("Search Assistant Hotkey Manager started")
    print("Press Cmd+Space (or Ctrl+Space on Linux) to launch search assistant")
    manager.start()

if __name__ == "__main__":
    main()
```

### AI Integration Features

#### 1. Natural Language Processing
```python
# AI-enhanced search capabilities
class AISearchEnhancer:
    def __init__(self, ai_backend: AIBackendManager):
        self.ai_backend = ai_backend
    
    async def enhance_query(self, query: str) -> str:
        """Enhance natural language queries"""
        if self._is_natural_language(query):
            enhanced = await self.ai_backend.query(f"""
            Convert this natural language query to search terms:
            "{query}"
            
            Return only the search terms, separated by spaces.
            """)
            return enhanced.strip()
        return query
    
    async def suggest_related(self, query: str) -> List[str]:
        """Suggest related searches"""
        suggestions = await self.ai_backend.query(f"""
        Suggest 5 related search terms for: "{query}"
        Return as a JSON array of strings.
        """)
        
        try:
            return json.loads(suggestions)
        except:
            return []
    
    def _is_natural_language(self, query: str) -> bool:
        """Check if query is natural language"""
        natural_indicators = [
            'show me', 'find', 'open', 'launch', 'where is',
            'how to', 'what is', 'can you', 'please'
        ]
        return any(indicator in query.lower() for indicator in natural_indicators)
```

#### 2. Context-Aware Suggestions
```python
# Context-aware search suggestions
class ContextAwareSearch:
    def __init__(self):
        self.user_context = self._load_user_context()
    
    async def get_contextual_suggestions(self, query: str) -> List[SearchResult]:
        """Get suggestions based on user context"""
        suggestions = []
        
        # Recent applications
        recent_apps = self.user_context.get('recent_applications', [])
        for app in recent_apps[:3]:
            if query.lower() in app['name'].lower():
                suggestions.append(SearchResult(
                    id=f"recent_{app['name']}",
                    title=app['name'],
                    description=f"Recently used application",
                    category='applications',
                    icon=app['icon'],
                    action=f"launch:{app['exec']}",
                    metadata=app,
                    relevance_score=1.2
                ))
        
        # Recent projects
        recent_projects = self.user_context.get('recent_projects', [])
        for project in recent_projects[:3]:
            if query.lower() in project['name'].lower():
                suggestions.append(SearchResult(
                    id=f"project_{project['path']}",
                    title=project['name'],
                    description=f"Recent project - {project['type']}",
                    category='development',
                    icon='project-icon',
                    action=f"open_project:{project['path']}",
                    metadata=project,
                    relevance_score=1.1
                ))
        
        return suggestions
    
    def _load_user_context(self) -> Dict:
        """Load user context from storage"""
        context_file = Path.home() / ".portal-os" / "search-context.json"
        if context_file.exists():
            try:
                with open(context_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}
```

### Installation and Configuration

#### 1. Plugin Installation Script
```bash
#!/bin/bash
# install.sh - Search Assistant Plugin

echo "Installing Portal OS Search Assistant..."

# Install dependencies
sudo apt update
sudo apt install -y python3-pip python3-venv nodejs npm rustc cargo

# Install Meilisearch
curl -L https://install.meilisearch.com | sh
sudo mv meilisearch /usr/local/bin/

# Install Python dependencies
pip3 install meilisearch-python-async watchdog pynput fastapi uvicorn

# Install Tauri CLI
cargo install tauri-cli

# Build the Tauri application
cd ui/tauri-app
npm install
cargo tauri build

# Set up systemd service for search daemon
sudo tee /etc/systemd/system/portal-search-daemon.service > /dev/null <<EOF
[Unit]
Description=Portal OS Search Daemon
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=/opt/portal-os/plugins/search-assistant
ExecStart=/usr/bin/python3 scripts/search-daemon.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start services
sudo systemctl enable portal-search-daemon
sudo systemctl start portal-search-daemon

# Set up hotkey manager
sudo tee /etc/systemd/user/portal-search-hotkey.service > /dev/null <<EOF
[Unit]
Description=Portal OS Search Hotkey Manager
After=graphical-session.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/portal-os/plugins/search-assistant/scripts/hotkey-manager.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOF

systemctl --user enable portal-search-hotkey
systemctl --user start portal-search-hotkey

echo "Search Assistant installation complete!"
echo "Press Cmd+Space (or Ctrl+Space) to launch the search assistant."
```

#### 2. Configuration File
```json
{
  "search": {
    "hotkey": "Cmd+Space",
    "theme": "auto",
    "max_results": 20,
    "search_delay": 150,
    "index_paths": [
      "~/Documents",
      "~/Downloads", 
      "~/Desktop",
      "~/Projects"
    ],
    "exclude_patterns": [
      "*.tmp",
      "*.log",
      ".git/*",
      "node_modules/*"
    ]
  },
  "ai": {
    "enabled": true,
    "enhance_queries": true,
    "suggest_related": true,
    "context_aware": true
  },
  "indexing": {
    "auto_index": true,
    "index_interval": 3600,
    "file_types": [
      "txt", "md", "py", "js", "ts", "html", "css", "json",
      "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx"
    ]
  }
}
```

### Features Summary

#### Core Features
- **Instant Search**: Sub-second response times with Meilisearch
- **Fuzzy Matching**: Find results even with typos
- **Real-time Indexing**: Files are indexed as they change
- **Global Hotkey**: Cmd+Space (or Ctrl+Space) to launch
- **Modern UI**: Clean, responsive interface built with Tauri

#### AI-Enhanced Features
- **Natural Language Queries**: "Show me my Python projects"
- **Context-Aware Suggestions**: Based on recent usage
- **Smart File Organization**: AI suggests better file organization
- **Intelligent Shortcuts**: Learn from user patterns
- **Related Searches**: AI suggests related terms

#### Developer-Specific Features
- **Git Repository Search**: Find and open projects quickly
- **Docker Container Management**: Search and manage containers
- **Database Connection Search**: Find database tools and connections
- **IDE Integration**: Open projects directly in preferred IDE
- **Service Management**: Search and control running services

#### System Integration
- **Application Launching**: Instant app launching
- **File Opening**: Open files with default applications
- **System Settings**: Quick access to system preferences
- **Recent Items**: Smart recent file and app suggestions
- **Web Search**: Direct web search integration

This search assistant provides a modern, open-source alternative to macOS Spotlight with deep AI integration, making it perfect for Portal OS's developer-first approach.
