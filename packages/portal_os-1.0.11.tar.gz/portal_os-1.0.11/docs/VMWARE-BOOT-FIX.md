# 🔧 VMware Boot Error Fix Guide

## 🚨 Current Issue
You're seeing these errors in VMware:
- `error: invalid magic number`
- `error: you need to load the kernel first`

## 🔍 Root Cause
The VM is trying to boot from a disk that doesn't have a proper bootable kernel. This happens because:
1. The VM is configured to boot from a hard disk instead of the ISO
2. The hard disk doesn't have an operating system installed
3. The ISO isn't properly mounted or configured

## 🛠️ Quick Fixes

### Option 1: Fix VM Configuration (Immediate)

1. **Power off the VM** if it's running

2. **Edit VM Settings**:
   - Right-click the VM → "Settings"
   - Click "CD/DVD (SATA)"
   - Select "Use ISO image file"
       - Browse to: `D:\production\portal\portal_os\build\portal_os.iso`
   - Check "Connect at power on"
   - Click "OK"

3. **Change Boot Order**:
   - In VM Settings, click "Advanced"
   - Set "Firmware type" to "BIOS" (not UEFI)
   - Click "OK"

4. **Power on the VM**:
   - The VM should now boot from the Ubuntu ISO
   - You should see the Ubuntu boot menu

### Option 2: Create New VM (Recommended)

1. **Create a new VM**:
   - File → New Virtual Machine
   - Choose "Typical (recommended)"
   - Select "I will install the operating system later"
   - Choose "Linux" → "Ubuntu 64-bit"
   - Name: "Portal OS Test"
   - Disk: 40 GB
   - Click "Finish"

2. **Configure the new VM**:
   - Right-click → Settings
   - Memory: 4096 MB
   - Processors: 2
       - CD/DVD: Point to `portal_os.iso`
   - Network: NAT

3. **Power on**:
   - Should boot to Ubuntu live session

## 🧪 Testing Portal OS Components

Once Ubuntu boots successfully:

### Method 1: Manual Integration (Quick Test)
```bash
# In the Ubuntu live session, open terminal
cd /tmp

# Download Portal OS components (if you have a web server)
# Or copy from shared folder if you set one up

# Extract and install
sudo mkdir -p /opt/portal-os
sudo cp -r portal-os-components/opt/portal-os/* /opt/portal-os/
sudo chmod +x /opt/portal-os/scripts/*.py

# Test Portal OS
/opt/portal-os/portal-os --help
```

### Method 2: Use Shared Folder
1. **Set up shared folder** in VM settings
2. **Copy components** from Windows to shared folder
3. **Access in Ubuntu** via `/mnt/hgfs/`

## 🎯 Next Steps

### For Complete Portal OS ISO:
1. **Transfer files to Linux system**:
   - `build/portal_os.iso`
   - `build/portal-os-components/`

2. **Build final ISO**:
   ```bash
   python scripts/linux-iso-builder.py
   ```

3. **Test complete Portal OS ISO** in VMware

### For WSL Users:
```bash
# In WSL
sudo apt install xorriso isolinux syslinux rsync
python scripts/linux-iso-builder.py
```

## 🔧 Troubleshooting

### If Ubuntu still won't boot:
- **Check ISO integrity**: The Ubuntu ISO should be ~1GB
- **Try different boot options**: Press F2 during boot for boot options
- **Check VM compatibility**: Use VMware Workstation 16+ for Ubuntu 24.04

### If components don't load:
- **Check permissions**: `sudo chmod +x /opt/portal-os/scripts/*.py`
- **Install dependencies**: `sudo apt install python3-pip`
- **Check Python path**: `which python3`

## 📞 Quick Commands

### Verify ISO:
```bash
# Check if ISO is valid
file build/ubuntu-24.04.3-portal-test.iso
# Should show: "ISO 9660 CD-ROM filesystem data"
```

### Test Portal OS:
```bash
# Once Ubuntu boots
ls /opt/portal-os/
/opt/portal-os/portal-os --help
python3 /opt/portal-os/scripts/ai-assistant.py --help
```

---

**The key is getting Ubuntu to boot first, then we can integrate Portal OS components!** 🚀
