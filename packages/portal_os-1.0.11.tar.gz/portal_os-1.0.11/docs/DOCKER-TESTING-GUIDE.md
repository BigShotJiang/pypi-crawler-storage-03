# Portal OS Docker Testing Guide

## 🐳 Safe Testing with Docker

This guide shows you how to test Portal OS scripts safely using Docker containers. This approach ensures your host system remains untouched while you explore and test all Portal OS features.

## 🚀 Quick Start

### Prerequisites
- Docker installed on your system
- Docker Compose (usually comes with Docker Desktop)
- At least 4GB RAM available for containers

### Basic Testing (5 minutes)

1. **Clone the repository**
```bash
git clone https://github.com/your-org/portal-os.git
cd portal-os
```

2. **Test basic functionality**
```bash
docker-compose --profile basic up --build
```

3. **Check the results**
```bash
docker-compose --profile basic logs portal-os-basic
```

## 🧪 Testing Scenarios

### 1. Basic Portal OS Testing
**What it tests**: Core functionality, status checking
```bash
# Run basic tests
docker-compose --profile basic up --build

# View logs
docker-compose --profile basic logs portal-os-basic

# Clean up
docker-compose --profile basic down
```

### 2. Development Environment Testing
**What it tests**: Full development environment with all tools
```bash
# Start development environment
docker-compose --profile development up --build

# Access interactive shell
docker exec -it portal-os-dev bash

# Test Portal OS commands
python3 portal-os status
python3 minimal-os-setup.py workflows
python3 scripts/privacy-manager.py status

# Exit and clean up
exit
docker-compose --profile development down
```

### 3. AI Backend Testing
**What it tests**: AI integration features
```bash
# Start AI testing environment
docker-compose --profile ai up --build

# Access interactive AI testing
docker exec -it portal-os-ai bash

# Test AI backend manager
python3 scripts/ai-backend-manager.py status
python3 scripts/ai-backend-manager.py setup-ollama
python3 scripts/ai-backend-manager.py generate "Hello, how are you?"

# Exit and clean up
exit
docker-compose --profile ai down
```

### 4. Privacy Features Testing
**What it tests**: Privacy and security features
```bash
# Test privacy manager
docker-compose --profile privacy up --build

# View privacy status
docker-compose --profile privacy logs portal-os-privacy

# Clean up
docker-compose --profile privacy down
```

### 5. Workflow Testing
**What it tests**: Development workflows
```bash
# Test workflows
docker-compose --profile workflow up --build

# View available workflows
docker-compose --profile workflow logs portal-os-workflow

# Clean up
docker-compose --profile workflow down
```

### 6. Interactive Development Shell
**What it tests**: Full development experience
```bash
# Start interactive shell
docker-compose --profile shell up --build

# Access the shell
docker exec -it portal-os-shell bash

# Test everything interactively
python3 portal-os
python3 scripts/ai-backend-manager.py
python3 scripts/privacy-manager.py
python3 minimal-os-setup.py

# Exit and clean up
exit
docker-compose --profile shell down
```

### 7. ISO Builder Testing (Advanced)
**What it tests**: ISO creation process
```bash
# Test ISO builder (requires more resources)
docker-compose --profile iso up --build

# Check ISO builder help
docker-compose --profile iso logs portal-os-iso

# Clean up
docker-compose --profile iso down
```

### 8. Production Testing
**What it tests**: Production environment
```bash
# Test production environment
docker-compose --profile production up --build

# View production logs
docker-compose --profile production logs portal-os-prod

# Clean up
docker-compose --profile production down
```

## 🔧 Advanced Testing

### Testing Multiple Components Together
```bash
# Test multiple components
docker-compose --profile basic --profile testing --profile privacy up --build

# View all logs
docker-compose logs

# Clean up all
docker-compose down
```

### Persistent Data Testing
```bash
# Start with persistent data
docker-compose --profile development up --build

# Make changes in the container
docker exec -it portal-os-dev bash
python3 minimal-os-setup.py create test-workflow "Test workflow" "git,node" "echo 'Hello World'"

# Stop and restart (data persists)
docker-compose --profile development down
docker-compose --profile development up

# Check if data persisted
docker exec -it portal-os-dev python3 minimal-os-setup.py workflows
```

### Network Testing
```bash
# Test with network access
docker-compose --profile ai up --build

# Test AI backend with internet access
docker exec -it portal-os-ai python3 scripts/ai-backend-manager.py setup-gemini YOUR_API_KEY
```

## 📊 Testing Results

### What Each Test Validates

| Test | Validates | Expected Result |
|------|-----------|-----------------|
| Basic | Core functionality | Portal OS status shows correctly |
| Development | All tools work | All scripts execute without errors |
| AI | AI integration | AI backend manager responds |
| Privacy | Privacy features | Privacy manager shows status |
| Workflow | Workflow system | Workflows list displays |
| Shell | Interactive use | Full development experience |
| ISO | ISO building | ISO builder shows help |
| Production | Production setup | Minimal production environment |

### Common Test Commands
```bash
# Test all components
docker-compose --profile basic --profile testing --profile privacy --profile workflow up --build

# Run specific test
docker-compose --profile ai up --build && docker exec -it portal-os-ai python3 scripts/ai-backend-manager.py status

# Test with custom command
docker-compose --profile development up --build
docker exec -it portal-os-dev python3 minimal-os-setup.py execute web-dev

# Clean everything
docker-compose down -v
docker system prune -f
```

## 🐛 Troubleshooting

### Common Issues

#### Container Won't Start
```bash
# Check Docker status
docker info

# Check available resources
docker system df

# Clean up Docker
docker system prune -f
```

#### Permission Issues
```bash
# Fix file permissions
chmod +x minimal-os-setup.py
chmod +x portal-os
chmod +x scripts/*.py

# Rebuild containers
docker-compose --profile basic up --build --force-recreate
```

#### Network Issues
```bash
# Check network connectivity
docker exec -it portal-os-dev ping -c 3 google.com

# Test with custom DNS
docker-compose --profile development up --build
docker exec -it portal-os-dev python3 -c "import requests; print(requests.get('https://httpbin.org/ip').json())"
```

#### Resource Issues
```bash
# Check container resources
docker stats

# Increase Docker resources (Docker Desktop)
# Go to Settings > Resources and increase memory/CPU
```

### Debug Mode
```bash
# Enable debug mode
export PORTAL_OS_DEBUG=1

# Run with debug logging
docker-compose --profile development up --build
docker exec -it portal-os-dev python3 portal-os status

# Check debug logs
docker exec -it portal-os-dev cat ~/.portal-os/logs/debug.log
```

## 🎯 Testing Checklist

### Basic Functionality
- [ ] Portal OS status command works
- [ ] Configuration files are created
- [ ] Scripts are executable
- [ ] Basic commands respond

### AI Integration
- [ ] AI backend manager starts
- [ ] Backend status shows correctly
- [ ] Model listing works
- [ ] Response generation works (if backend available)

### Privacy Features
- [ ] Privacy manager starts
- [ ] Status command works
- [ ] Configuration is accessible
- [ ] Privacy modes can be enabled

### Workflows
- [ ] Workflow listing works
- [ ] Built-in workflows are available
- [ ] Custom workflow creation works
- [ ] Workflow execution works

### Development Tools
- [ ] All scripts are accessible
- [ ] Python dependencies are installed
- [ ] System tools are available
- [ ] File permissions are correct

## 🚀 Next Steps

### After Testing
1. **Review Results**: Check all test outputs
2. **Report Issues**: Document any problems found
3. **Improve Scripts**: Fix issues discovered during testing
4. **Share Feedback**: Help improve the testing process

### Contributing
1. **Add Tests**: Create new test scenarios
2. **Improve Dockerfile**: Optimize the container setup
3. **Document Issues**: Help others avoid problems
4. **Test on Different Platforms**: Ensure cross-platform compatibility

## 📞 Support

### Getting Help
- **Docker Issues**: Check Docker documentation
- **Portal OS Issues**: Check the main documentation
- **Testing Issues**: Review this guide
- **Community**: Join our Discord server

### Useful Commands
```bash
# View all running containers
docker ps

# View container logs
docker logs portal-os-dev

# Access container shell
docker exec -it portal-os-dev bash

# Clean up everything
docker-compose down -v && docker system prune -f

# Rebuild everything
docker-compose --profile development up --build --force-recreate
```

---

**Ready to test safely?** Start with the basic profile and work your way up! 🐳
