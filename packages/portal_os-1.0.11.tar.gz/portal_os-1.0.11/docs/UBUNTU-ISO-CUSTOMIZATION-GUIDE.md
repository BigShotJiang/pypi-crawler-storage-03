# Ubuntu ISO Customization Guide

Complete guide for customizing Ubuntu ISOs for Portal OS or any custom Linux distribution.

## 🎯 Overview

There are several methods to customize Ubuntu ISOs:

1. **Manual Extraction Method** (Most Control)
2. **Ubuntu Customization Kit (UCK)** (Deprecated but still works)
3. **Live-Build** (Official Ubuntu method)
4. **Cubic** (GUI tool)
5. **Portal OS Builder** (Our automated method)

---

## 🔧 Method 1: Manual Extraction (Recommended for Learning)

### Prerequisites

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install xorriso isolinux syslinux-utils rsync wget curl squashfs-tools

# macOS (using Homebrew)
brew install xorriso wget rsync

# Tools needed:
# - xorriso: ISO creation
# - isolinux/syslinux: Boot loaders
# - squashfs-tools: Filesystem compression
# - rsync: File synchronization
```

### Step 1: Download Ubuntu Base ISO

```bash
# Create workspace
mkdir -p ~/ubuntu-custom
cd ~/ubuntu-custom

# Download Ubuntu 24.04 LTS (or your preferred version)
wget https://releases.ubuntu.com/24.04.3/ubuntu-24.04.3-desktop-amd64.iso

# Verify download (optional)
wget https://releases.ubuntu.com/24.04.3/SHA256SUMS
sha256sum -c SHA256SUMS 2>&1 | grep ubuntu-24.04.3-desktop-amd64.iso
```

### Step 2: Extract the ISO

```bash
# Create directories
mkdir -p iso-extract
mkdir -p iso-new
mkdir -p squashfs-root

# Mount the ISO (Linux)
sudo mount -o loop ubuntu-24.04.3-desktop-amd64.iso iso-extract/

# Copy all ISO contents except squashfs
rsync -av --exclude=casper/filesystem.squashfs iso-extract/ iso-new/

# Extract the squashfs filesystem
sudo unsquashfs -d squashfs-root iso-extract/casper/filesystem.squashfs

# Unmount the original ISO
sudo umount iso-extract/
```

### Step 3: Customize the System

Now you have the Ubuntu filesystem in `squashfs-root/`. This is where you make changes:

```bash
# Enter the chroot environment
sudo chroot squashfs-root /bin/bash

# Update package lists
apt update

# Install your custom software
apt install -y \
    git \
    curl \
    vim \
    python3-pip \
    nodejs \
    npm \
    docker.io \
    code \
    firefox

# Install Portal OS components
mkdir -p /opt/portal-os
# Copy your Portal OS files here

# Configure automatic startup
systemctl enable your-service

# Clean up
apt autoremove -y
apt autoclean
rm -rf /var/lib/apt/lists/*
rm -rf /tmp/*
rm -rf /var/tmp/*

# Exit chroot
exit
```

### Step 4: Customize Boot and Appearance

```bash
# Edit boot menu
sudo nano iso-new/boot/grub/grub.cfg

# Add custom boot options:
menuentry "Install Portal OS" {
    set gfxpayload=keep
    linux   /casper/vmlinuz boot=casper automatic-ubiquity noprompt ---
    initrd  /casper/initrd
}

# Customize isolinux (BIOS boot)
sudo nano iso-new/isolinux/txt.cfg

# Replace branding files
sudo cp your-logo.png iso-new/boot/grub/
sudo cp your-wallpaper.jpg squashfs-root/usr/share/backgrounds/
```

### Step 5: Add Custom Scripts and Files

```bash
# Copy Portal OS components
sudo cp -r /path/to/portal-os/scripts squashfs-root/opt/portal-os/
sudo cp /path/to/portal-os/portal-os squashfs-root/usr/local/bin/

# Add autostart script
sudo cat > squashfs-root/etc/systemd/system/portal-os-setup.service << EOF
[Unit]
Description=Portal OS Initial Setup
After=graphical-session.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/portal-os setup
User=ubuntu

[Install]
WantedBy=graphical-session.target
EOF

# Enable the service
sudo chroot squashfs-root systemctl enable portal-os-setup.service
```

### Step 6: Create New SquashFS

```bash
# Remove old squashfs
sudo rm iso-new/casper/filesystem.squashfs

# Create new squashfs with maximum compression
sudo mksquashfs squashfs-root/ iso-new/casper/filesystem.squashfs -comp xz -e boot

# Update file sizes
printf $(sudo du -sx --block-size=1 squashfs-root | cut -f1) | sudo tee iso-new/casper/filesystem.size
```

### Step 7: Update Boot Configuration

```bash
# Generate new MD5 sums
cd iso-new
sudo find . -type f -print0 | sudo xargs -0 md5sum | grep -v "\./md5sum.txt" | sudo tee md5sum.txt

# Update boot files
sudo nano boot/grub/grub.cfg
# Update any references to Ubuntu with Portal OS
```

### Step 8: Create the Final ISO

```bash
# Create bootable ISO
sudo xorriso -as mkisofs \
    -iso-level 3 \
    -full-iso9660-filenames \
    -volid "Portal OS 1.0.0" \
    -appid "Portal OS Live/Install DVD" \
    -publisher "Portal OS Team" \
    -preparer "Portal OS Builder" \
    -eltorito-boot isolinux/isolinux.bin \
    -eltorito-catalog isolinux/boot.cat \
    -no-emul-boot \
    -boot-load-size 4 \
    -boot-info-table \
    -eltorito-alt-boot \
    -e boot/grub/efi.img \
    -no-emul-boot \
    -isohybrid-gpt-basdat \
    -output ../portal-os-custom.iso \
    .

cd ..
echo "✅ ISO created: portal-os-custom.iso"
```

---

## 🛠️ Method 2: Using Cubic (GUI Method)

Cubic is a GUI tool that simplifies the ISO customization process:

### Installation

```bash
# Add PPA
sudo apt-add-repository universe
sudo apt-add-repository ppa:cubic-wizard/release
sudo apt update
sudo apt install cubic
```

### Usage

1. Launch Cubic: `cubic`
2. Create new project
3. Select your Ubuntu ISO
4. Wait for extraction
5. Customize in the terminal environment
6. Generate new ISO

---

## 🏗️ Method 3: Using Live-Build (Official Ubuntu Method)

Live-Build is the official tool used by Ubuntu developers:

### Installation

```bash
sudo apt install live-build
```

### Basic Configuration

```bash
# Create build directory
mkdir ubuntu-live
cd ubuntu-live

# Configure the build
lb config \
    --distribution jammy \
    --archive-areas "main restricted universe multiverse" \
    --mode ubuntu \
    --initramfs casper \
    --memtest memtest86+ \
    --bootappend-live "boot=casper" \
    --bootloader syslinux

# Add packages
echo "git curl vim python3-pip nodejs npm" > config/package-lists/custom.list.chroot

# Build the ISO
sudo lb build
```

---

## 🤖 Method 4: Portal OS Automated Builder

Use the existing Portal OS builder:

```bash
# Run the Portal OS ISO builder
python scripts/os-iso-builder.py

# Or with Docker
docker build -t portal-os-builder --target iso-builder .
docker run -v $(pwd)/build:/portal-os/build portal-os-builder
```

---

## 🎨 Common Customizations

### 1. Branding and Appearance

```bash
# Replace Plymouth splash screen
sudo cp your-splash.png squashfs-root/usr/share/plymouth/themes/ubuntu-logo/
sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth /usr/share/plymouth/themes/your-theme/your-theme.plymouth 100

# Desktop wallpaper
sudo cp wallpaper.jpg squashfs-root/usr/share/backgrounds/
sudo gsettings set org.gnome.desktop.background picture-uri file:///usr/share/backgrounds/wallpaper.jpg
```

### 2. Software Installation

```bash
# Pre-install applications
sudo chroot squashfs-root apt install -y \
    code \
    docker.io \
    git \
    python3-pip \
    nodejs \
    npm

# Install from .deb files
sudo chroot squashfs-root dpkg -i /path/to/package.deb
sudo chroot squashfs-root apt-get install -f  # Fix dependencies
```

### 3. User Configuration

```bash
# Create default user settings
sudo mkdir -p squashfs-root/etc/skel/.config
sudo cp -r your-config/* squashfs-root/etc/skel/.config/

# Set default applications
sudo cp defaults.list squashfs-root/etc/skel/.local/share/applications/
```

### 4. Autostart Scripts

```bash
# Add to autostart
sudo mkdir -p squashfs-root/etc/skel/.config/autostart
sudo cat > squashfs-root/etc/skel/.config/autostart/portal-os.desktop << EOF
[Desktop Entry]
Type=Application
Name=Portal OS Setup
Exec=/usr/local/bin/portal-os setup
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
EOF
```

---

## 🧪 Testing Your Custom ISO

### 1. Virtual Machine Testing

```bash
# Using QEMU
qemu-system-x86_64 -m 2048 -cdrom portal-os-custom.iso -boot d

# Using VirtualBox
VBoxManage createvm --name "Portal OS Test" --register
VBoxManage modifyvm "Portal OS Test" --memory 2048 --vram 128
VBoxManage createhd --filename "Portal OS Test.vdi" --size 20480
VBoxManage storagectl "Portal OS Test" --name "IDE Controller" --add ide
VBoxManage storageattach "Portal OS Test" --storagectl "IDE Controller" --port 1 --device 0 --type dvddrive --medium portal-os-custom.iso
VBoxManage startvm "Portal OS Test"
```

### 2. USB Boot Testing

```bash
# Create bootable USB (BE CAREFUL - this will erase the USB!)
sudo dd if=portal-os-custom.iso of=/dev/sdX bs=4M status=progress oflag=sync

# Or use etcher, rufus, or balenaEtcher for a GUI approach
```

---

## 🔧 Troubleshooting

### Common Issues

1. **Boot Errors**: Check isolinux/grub configuration
2. **Missing Files**: Ensure all dependencies are installed in chroot
3. **Large ISO Size**: Use better compression or remove unnecessary packages
4. **Permissions**: Run commands with appropriate sudo privileges
5. **Package Conflicts**: Update package lists and fix dependencies

### Debug Commands

```bash
# Check ISO boot capability
file portal-os-custom.iso

# Verify ISO structure
xorriso -indev portal-os-custom.iso -find

# Test boot in QEMU with verbose output
qemu-system-x86_64 -m 2048 -cdrom portal-os-custom.iso -boot d -nographic
```

---

## 🚀 Advanced Tips

### 1. Automated Build Scripts

Create a script to automate the entire process:

```bash
#!/bin/bash
# build-portal-os.sh

set -e

UBUNTU_ISO="ubuntu-24.04.3-desktop-amd64.iso"
CUSTOM_ISO="portal-os-custom.iso"

echo "🚀 Starting Portal OS ISO build..."

# Download base ISO if not exists
if [ ! -f "$UBUNTU_ISO" ]; then
    wget "https://releases.ubuntu.com/24.04.3/$UBUNTU_ISO"
fi

# Clean previous builds
sudo rm -rf iso-extract iso-new squashfs-root

# Extract and customize
mkdir -p iso-extract iso-new squashfs-root
sudo mount -o loop "$UBUNTU_ISO" iso-extract/
rsync -av --exclude=casper/filesystem.squashfs iso-extract/ iso-new/
sudo unsquashfs -d squashfs-root iso-extract/casper/filesystem.squashfs
sudo umount iso-extract/

# Apply customizations
sudo chroot squashfs-root /bin/bash -c "
    apt update
    apt install -y git curl vim python3-pip nodejs npm
    apt autoremove -y
    apt autoclean
    rm -rf /var/lib/apt/lists/*
"

# Rebuild squashfs
sudo rm iso-new/casper/filesystem.squashfs
sudo mksquashfs squashfs-root/ iso-new/casper/filesystem.squashfs -comp xz -e boot

# Create ISO
cd iso-new
sudo find . -type f -print0 | sudo xargs -0 md5sum | grep -v "\./md5sum.txt" | sudo tee md5sum.txt
sudo xorriso -as mkisofs -iso-level 3 -full-iso9660-filenames -volid "Portal OS 1.0.0" -output "../$CUSTOM_ISO" .

echo "✅ Portal OS ISO created: $CUSTOM_ISO"
```

### 2. Configuration Management

Use the Portal OS configuration system to manage ISO customizations:

```python
# iso-config.py
from portal_config import get_config

config = get_config()
iso_config = config.get_component_config("iso_builder")

# Customize based on configuration
packages = iso_config.get("packages", [])
branding = iso_config.get("branding", {})
```

This comprehensive guide gives you multiple approaches to customize Ubuntu ISOs for Portal OS! Choose the method that best fits your needs and technical comfort level. 🎉
