# Minimal Portal OS Setup

A lightweight development environment for testing custom workflows. This is a minimal implementation of the Portal OS concept that allows you to quickly set up development tools and test custom workflows.

## Features

- **Essential Development Tools**: Git, Node.js, Python, Docker, VS Code
- **Pre-built Workflows**: Web development, API development, Container development
- **Custom Workflow Creation**: Create your own development workflows
- **Cross-platform Support**: Windows, Linux, macOS
- **Simple CLI Interface**: Easy-to-use commands

## Quick Start

### 1. Setup Essential Tools

```bash
# Interactive mode
python minimal-os-setup.py

# Or use CLI commands
python minimal-os-setup.py setup
```

### 2. List Available Workflows

```bash
python minimal-os-setup.py workflows
```

### 3. Execute a Workflow

```bash
# Execute built-in workflow
python minimal-os-setup.py execute web-dev

# Execute workflow in specific directory
python minimal-os-setup.py execute api-dev ./my-project
```

### 4. Create Custom Workflow

```bash
python minimal-os-setup.py create "my-workflow" "My custom workflow" "node,git" "npm init -y,npm install express,code ."
```

### 5. Check Status

```bash
python minimal-os-setup.py status
```

## Built-in Workflows

### Web Development (`web-dev`)
- **Tools**: Node.js, Git, VS Code
- **Commands**: 
  - Initialize npm project
  - Install Express, CORS, dotenv
  - Open VS Code

### API Development (`api-dev`)
- **Tools**: Node.js, Python, Git, VS Code
- **Commands**:
  - Initialize npm project
  - Install Express, CORS, dotenv
  - Install FastAPI, Uvicorn
  - Open VS Code

### Container Development (`container-dev`)
- **Tools**: Docker, Git, VS Code
- **Commands**:
  - Check Docker version
  - Check Docker Compose version
  - Open VS Code

## Creating Custom Workflows

You can create custom workflows for your specific development needs:

```bash
python minimal-os-setup.py create \
  "react-app" \
  "React application setup" \
  "node,git,code" \
  "npx create-react-app my-app,cd my-app,npm start"
```

## Configuration

The system stores configuration in `~/.portal-os/`:

- `config.json`: System configuration and installed tools
- `workflows.json`: Custom workflows
- `projects/`: Project templates
- `logs/`: System logs

## Supported Tools

The system can automatically install these tools:

- **Git**: Version control
- **Node.js**: JavaScript runtime
- **Python**: Python runtime
- **Docker**: Containerization
- **VS Code**: Code editor

## Platform Support

- **Windows**: Uses `winget` for package installation
- **Linux**: Uses `apt-get` (Ubuntu/Debian) for package installation
- **macOS**: Uses `brew` for package installation

## Example Usage

### Setting up a new web project:

```bash
# 1. Setup tools (if not already done)
python minimal-os-setup.py setup

# 2. Create a new project directory
mkdir my-web-project
cd my-web-project

# 3. Execute web development workflow
python minimal-os-setup.py execute web-dev

# 4. Start developing!
```

### Creating a custom workflow for a specific framework:

```bash
# Create a Next.js workflow
python minimal-os-setup.py create \
  "nextjs" \
  "Next.js application setup" \
  "node,git,code" \
  "npx create-next-app@latest my-app --typescript --tailwind --eslint,cd my-app,code ."
```

## Next Steps

This minimal setup provides the foundation for testing custom workflows. As you develop and refine your workflows, you can:

1. **Add more tools** to the essential tools list
2. **Create more workflow templates** for different project types
3. **Integrate with your existing development tools**
4. **Add AI-powered features** for workflow suggestions
5. **Build a GUI interface** for easier workflow management

## Troubleshooting

### Tool Installation Issues

If tool installation fails:

1. Check if you have the required package manager installed:
   - Windows: `winget` (Windows 10 1709+)
   - Linux: `apt-get` (Ubuntu/Debian)
   - macOS: `brew` (Homebrew)

2. Run with administrator/sudo privileges if needed

3. Check the logs in `~/.portal-os/logs/`

### Workflow Execution Issues

1. Ensure all required tools are installed: `python minimal-os-setup.py status`
2. Check if the workflow commands are valid for your system
3. Verify the project path exists and is writable

## Contributing

This is a minimal implementation for testing purposes. Feel free to:

- Add more workflow templates
- Improve tool installation methods
- Add error handling and validation
- Create additional CLI commands
- Build a web interface

## License

This is part of the Portal OS project. Use for development and testing purposes.
