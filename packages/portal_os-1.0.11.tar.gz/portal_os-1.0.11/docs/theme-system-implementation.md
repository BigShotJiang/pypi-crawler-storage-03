# Portal OS Theme System Implementation
## Multi-Theme Support with Profile-Specific Customization

### Overview
Portal OS features a comprehensive theming system that supports multiple aesthetic styles with seamless switching, profile-specific themes, and deep customization options. The system is inspired by Zorin OS's approach but enhanced with AI integration and developer-specific optimizations.

### Core Theme Architecture

#### Theme System Structure
```bash
/opt/portal-os/themes/
├── system/
│   ├── mac-like/
│   │   ├── whitesur/
│   │   ├── bigsur/
│   │   └── monterey/
│   ├── windows-like/
│   │   ├── windows11/
│   │   ├── windows10/
│   │   └── fluent/
│   ├── cutefish-default/
│   │   ├── light/
│   │   ├── dark/
│   │   └── auto/
│   └── clean-interfaces/
│       ├── minimal/
│       ├── nord/
│       ├── gruvbox/
│       └── dracula/
├── profiles/
│   ├── coding/
│   ├── studying/
│   ├── watching/
│   └── gaming/
├── custom/
└── config/
    ├── theme-manager.conf
    ├── profile-themes.conf
    └── auto-switch.conf
```

### Theme Categories

#### 1. Mac-like Themes (Whitesur & Variants)
```bash
# macOS-inspired aesthetics
mac-like:
  whitesur:
    description: "Whitesur Mac theme with macOS Big Sur aesthetics"
    features:
      - Rounded corners and shadows
      - Dock-style application panel
      - macOS-style window decorations
      - System font: SF Pro Display
      - Color scheme: Light with blue accents
      - Transparency and blur effects
      - macOS-style icons and animations
    
  bigsur:
    description: "macOS Big Sur inspired theme"
    features:
      - Translucent materials
      - Rounded window corners
      - Control center style
      - Notification center design
      - Safari-style browser theme
    
  monterey:
    description: "macOS Monterey inspired theme"
    features:
      - Focus modes integration
      - Live text features
      - Universal control styling
      - Shortcuts app integration
```

#### 2. Windows-like Themes
```bash
# Windows 11/10 inspired interfaces
windows-like:
  windows11:
    description: "Modern Windows 11 inspired interface"
    features:
      - Fluent Design System
      - Rounded corners and acrylic effects
      - Windows 11 taskbar design
      - Start menu with tiles
      - Action center and quick settings
      - Segoe UI font family
      - Windows 11 color palette
    
  windows10:
    description: "Windows 10 inspired theme"
    features:
      - Metro/Modern UI elements
      - Live tiles
      - Windows 10 taskbar
      - Cortana integration styling
      - Windows 10 color scheme
    
  fluent:
    description: "Microsoft Fluent Design System"
    features:
      - Material Design principles
      - Depth and elevation
      - Motion and animation
      - Adaptive UI elements
      - Accessibility focus
```

#### 3. Cutefish OS Default
```bash
# Clean, minimalist design
cutefish-default:
  light:
    description: "Cutefish OS light theme"
    features:
      - Clean, flat design
      - Minimalist interface
      - Subtle shadows
      - Light color palette
      - Modern typography
      - Smooth animations
  
  dark:
    description: "Cutefish OS dark theme"
    features:
      - Dark mode optimization
      - High contrast elements
      - Reduced eye strain
      - Dark color palette
      - Accent color highlights
  
  auto:
    description: "Automatic light/dark switching"
    features:
      - System preference detection
      - Time-based switching
      - Ambient light sensor support
      - Smooth transitions
```

#### 4. Clean Interface Themes
```bash
# Distraction-free and developer-focused
clean-interfaces:
  minimal:
    description: "Ultra-minimalist interface"
    features:
      - Maximum content focus
      - Minimal UI elements
      - High contrast text
      - Distraction-free design
      - Customizable opacity
  
  nord:
    description: "Nord color scheme theme"
    features:
      - Arctic-inspired colors
      - Consistent color palette
      - Developer-friendly contrast
      - Syntax highlighting integration
      - Terminal theme matching
  
  gruvbox:
    description: "Gruvbox color scheme"
    features:
      - Retro groove color scheme
      - High contrast mode
      - Multiple variants (light/dark)
      - Terminal and editor integration
      - Consistent theming
  
  dracula:
    description: "Dracula dark theme"
    features:
      - Dark purple color scheme
      - High contrast elements
      - Developer tool integration
      - Consistent across all apps
      - Modern dark aesthetics
```

### Profile-Specific Themes

#### 1. Coding Profile Theme
```bash
coding-profile:
  base_theme: "cutefish-default-dark"
  customizations:
    # Enhanced developer experience
    - Terminal: Dracula theme with syntax highlighting
    - IDE integration: Dark themes for VS Code, JetBrains
    - Git integration: Enhanced diff highlighting
    - Database tools: Dark mode for pgAdmin, MongoDB Compass
    - Browser: Dark reader extension enabled
    - File manager: Tree view with syntax highlighting
    - Dock: Development tools prominently displayed
    - Notifications: Code-focused (Git commits, build status)
    - Wallpaper: Code-themed or minimal
    - Accent colors: Blue/cyan for productivity
```

#### 2. Studying Profile Theme
```bash
studying-profile:
  base_theme: "clean-interfaces-minimal"
  customizations:
    # Distraction-free learning environment
    - Reading mode: High contrast, large fonts
    - Note-taking apps: Clean, minimal interface
    - PDF readers: Distraction-free mode
    - Browser: Focus mode with minimal UI
    - Timer: Pomodoro timer integration
    - Notifications: Reduced, study-focused only
    - Wallpaper: Calming, neutral colors
    - Accent colors: Green for focus and learning
    - Typography: Readable fonts optimized for long reading
    - Brightness: Eye-strain reduction settings
```

#### 3. Watching Profile Theme
```bash
watching-profile:
  base_theme: "cutefish-default-dark"
  customizations:
    # Media-optimized interface
    - Video players: Full-screen optimized
    - Streaming apps: Dark mode for better viewing
    - Browser: Media-focused extensions
    - Notifications: Minimal during playback
    - Wallpaper: Dynamic media backgrounds
    - Accent colors: Purple/blue for entertainment
    - Brightness: Optimized for dark room viewing
    - Audio: Enhanced audio controls
    - Subtitles: High contrast, readable fonts
    - Remote control: Media remote integration
```

#### 4. Gaming Profile Theme
```bash
gaming-profile:
  base_theme: "windows-like-windows11"
  customizations:
    # Gaming-optimized interface
    - Game launchers: Steam, Epic, GOG integration
    - Performance monitoring: GPU/CPU overlays
    - Gaming peripherals: RGB lighting integration
    - Notifications: Gaming-focused (achievements, invites)
    - Wallpaper: Gaming-themed or dynamic
    - Accent colors: Red/orange for gaming energy
    - Performance mode: Optimized for gaming
    - Audio: Gaming audio profiles
    - Input: Gaming controller integration
    - Streaming: OBS/Twitch integration themes
```

### Theme Manager Implementation

#### 1. Theme Manager Core (Python)
```python
#!/usr/bin/env python3
"""
Portal OS Theme Manager
Handles theme switching, profile management, and customization
"""

import os
import json
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass
import logging

@dataclass
class Theme:
    name: str
    category: str
    description: str
    base_theme: str
    customizations: Dict
    is_active: bool = False
    is_profile_specific: bool = False

@dataclass
class Profile:
    name: str
    description: str
    theme: str
    customizations: Dict
    auto_switch_conditions: Dict

class ThemeManager:
    def __init__(self):
        self.themes_dir = Path("/opt/portal-os/themes")
        self.config_dir = Path.home() / ".config" / "portal-os" / "themes"
        self.current_theme = None
        self.current_profile = None
        self.themes = self._load_themes()
        self.profiles = self._load_profiles()
    
    def _load_themes(self) -> Dict[str, Theme]:
        """Load all available themes"""
        themes = {}
        
        # System themes
        system_themes_dir = self.themes_dir / "system"
        for category_dir in system_themes_dir.iterdir():
            if category_dir.is_dir():
                for theme_dir in category_dir.iterdir():
                    if theme_dir.is_dir():
                        theme_config = theme_dir / "theme.json"
                        if theme_config.exists():
                            with open(theme_config, 'r') as f:
                                config = json.load(f)
                                themes[config['name']] = Theme(
                                    name=config['name'],
                                    category=config['category'],
                                    description=config['description'],
                                    base_theme=config.get('base_theme', ''),
                                    customizations=config.get('customizations', {}),
                                    is_active=config.get('is_active', False)
                                )
        
        return themes
    
    def _load_profiles(self) -> Dict[str, Profile]:
        """Load profile configurations"""
        profiles = {}
        profiles_config = self.config_dir / "profiles.json"
        
        if profiles_config.exists():
            with open(profiles_config, 'r') as f:
                config = json.load(f)
                for profile_name, profile_data in config.items():
                    profiles[profile_name] = Profile(
                        name=profile_name,
                        description=profile_data['description'],
                        theme=profile_data['theme'],
                        customizations=profile_data.get('customizations', {}),
                        auto_switch_conditions=profile_data.get('auto_switch_conditions', {})
                    )
        
        return profiles
    
    def apply_theme(self, theme_name: str) -> bool:
        """Apply a specific theme"""
        if theme_name not in self.themes:
            logging.error(f"Theme '{theme_name}' not found")
            return False
        
        theme = self.themes[theme_name]
        
        try:
            # Apply GTK theme
            self._apply_gtk_theme(theme)
            
            # Apply icon theme
            self._apply_icon_theme(theme)
            
            # Apply cursor theme
            self._apply_cursor_theme(theme)
            
            # Apply wallpaper
            self._apply_wallpaper(theme)
            
            # Apply customizations
            self._apply_customizations(theme.customizations)
            
            # Update current theme
            self.current_theme = theme_name
            self._save_current_theme()
            
            # Restart desktop environment if needed
            self._restart_desktop_environment()
            
            logging.info(f"Theme '{theme_name}' applied successfully")
            return True
            
        except Exception as e:
            logging.error(f"Failed to apply theme '{theme_name}': {e}")
            return False
    
    def apply_profile(self, profile_name: str) -> bool:
        """Apply a profile with its associated theme and customizations"""
        if profile_name not in self.profiles:
            logging.error(f"Profile '{profile_name}' not found")
            return False
        
        profile = self.profiles[profile_name]
        
        try:
            # Apply the profile's theme
            if not self.apply_theme(profile.theme):
                return False
            
            # Apply profile-specific customizations
            self._apply_profile_customizations(profile)
            
            # Update current profile
            self.current_profile = profile_name
            self._save_current_profile()
            
            logging.info(f"Profile '{profile_name}' applied successfully")
            return True
            
        except Exception as e:
            logging.error(f"Failed to apply profile '{profile_name}': {e}")
            return False
    
    def _apply_gtk_theme(self, theme: Theme):
        """Apply GTK theme"""
        theme_path = self.themes_dir / "system" / theme.category / theme.name
        
        # Copy theme files to system directories
        gtk_theme_dir = Path("/usr/share/themes") / theme.name
        if not gtk_theme_dir.exists():
            shutil.copytree(theme_path / "gtk", gtk_theme_dir)
        
        # Set GTK theme
        subprocess.run([
            "gsettings", "set", "org.gnome.desktop.interface", 
            "gtk-theme", theme.name
        ], check=True)
    
    def _apply_icon_theme(self, theme: Theme):
        """Apply icon theme"""
        icon_theme = theme.customizations.get('icon_theme', 'default')
        subprocess.run([
            "gsettings", "set", "org.gnome.desktop.interface", 
            "icon-theme", icon_theme
        ], check=True)
    
    def _apply_cursor_theme(self, theme: Theme):
        """Apply cursor theme"""
        cursor_theme = theme.customizations.get('cursor_theme', 'default')
        subprocess.run([
            "gsettings", "set", "org.gnome.desktop.interface", 
            "cursor-theme", cursor_theme
        ], check=True)
    
    def _apply_wallpaper(self, theme: Theme):
        """Apply wallpaper"""
        wallpaper_path = theme.customizations.get('wallpaper')
        if wallpaper_path:
            wallpaper_file = self.themes_dir / "system" / theme.category / theme.name / wallpaper_path
            if wallpaper_file.exists():
                subprocess.run([
                    "gsettings", "set", "org.gnome.desktop.background", 
                    "picture-uri", f"file://{wallpaper_file}"
                ], check=True)
    
    def _apply_customizations(self, customizations: Dict):
        """Apply theme customizations"""
        for key, value in customizations.items():
            if key.startswith('gsettings_'):
                # Handle gsettings customizations
                setting_path = key.replace('gsettings_', '')
                subprocess.run([
                    "gsettings", "set", setting_path, str(value)
                ], check=True)
            elif key.startswith('dconf_'):
                # Handle dconf customizations
                setting_path = key.replace('dconf_', '')
                subprocess.run([
                    "dconf", "write", setting_path, str(value)
                ], check=True)
    
    def _apply_profile_customizations(self, profile: Profile):
        """Apply profile-specific customizations"""
        # Apply terminal themes
        if 'terminal_theme' in profile.customizations:
            self._apply_terminal_theme(profile.customizations['terminal_theme'])
        
        # Apply IDE themes
        if 'ide_themes' in profile.customizations:
            self._apply_ide_themes(profile.customizations['ide_themes'])
        
        # Apply browser themes
        if 'browser_theme' in profile.customizations:
            self._apply_browser_theme(profile.customizations['browser_theme'])
        
        # Apply performance settings
        if 'performance_settings' in profile.customizations:
            self._apply_performance_settings(profile.customizations['performance_settings'])
    
    def _apply_terminal_theme(self, theme_name: str):
        """Apply terminal theme"""
        # Apply to common terminals
        terminals = ['gnome-terminal', 'konsole', 'xfce4-terminal']
        
        for terminal in terminals:
            try:
                if terminal == 'gnome-terminal':
                    # Apply to GNOME Terminal
                    subprocess.run([
                        "gsettings", "set", "org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:0/",
                        "palette", theme_name
                    ], check=True)
                # Add support for other terminals
            except Exception as e:
                logging.warning(f"Failed to apply terminal theme to {terminal}: {e}")
    
    def _apply_ide_themes(self, themes: Dict):
        """Apply IDE themes"""
        for ide, theme in themes.items():
            try:
                if ide == 'vscode':
                    self._apply_vscode_theme(theme)
                elif ide == 'jetbrains':
                    self._apply_jetbrains_theme(theme)
                # Add support for other IDEs
            except Exception as e:
                logging.warning(f"Failed to apply theme to {ide}: {e}")
    
    def _apply_vscode_theme(self, theme_name: str):
        """Apply VS Code theme"""
        vscode_settings = Path.home() / ".config" / "Code" / "User" / "settings.json"
        
        if vscode_settings.exists():
            with open(vscode_settings, 'r') as f:
                settings = json.load(f)
            
            settings['workbench.colorTheme'] = theme_name
            
            with open(vscode_settings, 'w') as f:
                json.dump(settings, f, indent=2)
    
    def _apply_browser_theme(self, theme_config: Dict):
        """Apply browser theme"""
        # Apply to common browsers
        browsers = ['firefox', 'chrome', 'brave']
        
        for browser in browsers:
            try:
                if browser == 'firefox':
                    self._apply_firefox_theme(theme_config)
                elif browser == 'chrome':
                    self._apply_chrome_theme(theme_config)
                # Add support for other browsers
            except Exception as e:
                logging.warning(f"Failed to apply theme to {browser}: {e}")
    
    def _apply_performance_settings(self, settings: Dict):
        """Apply performance-related settings"""
        for setting, value in settings.items():
            try:
                if setting == 'cpu_governor':
                    subprocess.run([
                        "sudo", "cpufreq-set", "-g", value
                    ], check=True)
                elif setting == 'gpu_power':
                    # Apply GPU power settings
                    pass
                # Add other performance settings
            except Exception as e:
                logging.warning(f"Failed to apply performance setting {setting}: {e}")
    
    def _restart_desktop_environment(self):
        """Restart desktop environment if needed"""
        # Check if restart is required
        restart_required = self._check_restart_required()
        
        if restart_required:
            # Notify user and offer restart
            self._notify_restart_required()
    
    def _check_restart_required(self) -> bool:
        """Check if desktop environment restart is required"""
        # Check for theme changes that require restart
        return False  # Implement based on specific changes
    
    def _notify_restart_required(self):
        """Notify user that restart is required"""
        subprocess.run([
            "notify-send", 
            "Theme Change", 
            "Some changes require a desktop restart to take full effect."
        ])
    
    def _save_current_theme(self):
        """Save current theme to configuration"""
        config_file = self.config_dir / "current_theme.json"
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(config_file, 'w') as f:
            json.dump({
                'theme': self.current_theme,
                'timestamp': str(Path().stat().st_mtime)
            }, f, indent=2)
    
    def _save_current_profile(self):
        """Save current profile to configuration"""
        config_file = self.config_dir / "current_profile.json"
        config_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(config_file, 'w') as f:
            json.dump({
                'profile': self.current_profile,
                'timestamp': str(Path().stat().st_mtime)
            }, f, indent=2)
    
    def list_themes(self) -> List[Theme]:
        """List all available themes"""
        return list(self.themes.values())
    
    def list_profiles(self) -> List[Profile]:
        """List all available profiles"""
        return list(self.profiles.values())
    
    def get_current_theme(self) -> Optional[Theme]:
        """Get current theme"""
        if self.current_theme:
            return self.themes.get(self.current_theme)
        return None
    
    def get_current_profile(self) -> Optional[Profile]:
        """Get current profile"""
        if self.current_profile:
            return self.profiles.get(self.current_profile)
        return None

if __name__ == "__main__":
    manager = ThemeManager()
    # Example usage
    manager.apply_theme("whitesur")
    manager.apply_profile("coding")
```

#### 2. Theme Configuration Files

##### Theme Configuration (theme.json)
```json
{
  "name": "whitesur",
  "category": "mac-like",
  "description": "Whitesur Mac theme with macOS Big Sur aesthetics",
  "version": "1.0.0",
  "author": "Portal OS Team",
  "base_theme": "",
  "customizations": {
    "icon_theme": "Whitesur",
    "cursor_theme": "Whitesur",
    "wallpaper": "wallpapers/big-sur.jpg",
    "gsettings_org.gnome.desktop.interface.font-name": "SF Pro Display 11",
    "gsettings_org.gnome.desktop.interface.monospace-font-name": "SF Mono 11",
    "gsettings_org.gnome.desktop.interface.enable-hot-corners": true,
    "dconf_/org/gnome/desktop/interface/enable-animations": true,
    "dconf_/org/gnome/desktop/interface/gtk-enable-primary-paste": false
  },
  "features": [
    "rounded-corners",
    "transparency",
    "blur-effects",
    "macos-style-dock",
    "system-fonts"
  ],
  "dependencies": [
    "whitesur-icon-theme",
    "whitesur-cursor-theme",
    "whitesur-gtk-theme"
  ]
}
```

##### Profile Configuration (profiles.json)
```json
{
  "coding": {
    "description": "Developer-focused profile with coding tools and dark themes",
    "theme": "cutefish-default-dark",
    "customizations": {
      "terminal_theme": "dracula",
      "ide_themes": {
        "vscode": "Dracula",
        "jetbrains": "Darcula",
        "sublime": "Dracula"
      },
      "browser_theme": {
        "dark_reader": true,
        "theme": "dark"
      },
      "performance_settings": {
        "cpu_governor": "performance",
        "gpu_power": "high"
      }
    },
    "auto_switch_conditions": {
      "applications": ["code", "intellij", "sublime_text"],
      "directories": ["~/Projects", "~/Development"],
      "time_of_day": null
    }
  },
  "studying": {
    "description": "Distraction-free environment for learning and research",
    "theme": "clean-interfaces-minimal",
    "customizations": {
      "terminal_theme": "gruvbox-light",
      "browser_theme": {
        "focus_mode": true,
        "reading_mode": true
      },
      "performance_settings": {
        "cpu_governor": "powersave",
        "brightness": "reduced"
      }
    },
    "auto_switch_conditions": {
      "applications": ["obsidian", "joplin", "zotero"],
      "directories": ["~/Documents", "~/Research"],
      "time_of_day": null
    }
  },
  "watching": {
    "description": "Media-optimized profile for streaming and entertainment",
    "theme": "cutefish-default-dark",
    "customizations": {
      "browser_theme": {
        "dark_mode": true,
        "fullscreen_optimized": true
      },
      "performance_settings": {
        "audio_enhancement": true,
        "display_optimization": "media"
      }
    },
    "auto_switch_conditions": {
      "applications": ["netflix", "youtube", "spotify"],
      "directories": null,
      "time_of_day": null
    }
  },
  "gaming": {
    "description": "Gaming-optimized profile with performance settings",
    "theme": "windows-like-windows11",
    "customizations": {
      "performance_settings": {
        "cpu_governor": "performance",
        "gpu_power": "maximum",
        "network_optimization": true
      }
    },
    "auto_switch_conditions": {
      "applications": ["steam", "epic", "lutris"],
      "directories": null,
      "time_of_day": null
    }
  }
}
```

#### 3. Theme Switching GUI (Tauri + React)
```typescript
// src/components/ThemeManager.tsx
import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/tauri';

interface Theme {
  name: string;
  category: string;
  description: string;
  is_active: boolean;
}

interface Profile {
  name: string;
  description: string;
  theme: string;
}

export const ThemeManager: React.FC = () => {
  const [themes, setThemes] = useState<Theme[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [currentTheme, setCurrentTheme] = useState<string>('');
  const [currentProfile, setCurrentProfile] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadThemes();
    loadProfiles();
    loadCurrentSettings();
  }, []);

  const loadThemes = async () => {
    try {
      const themeList = await invoke<Theme[]>('get_themes');
      setThemes(themeList);
    } catch (error) {
      console.error('Failed to load themes:', error);
    }
  };

  const loadProfiles = async () => {
    try {
      const profileList = await invoke<Profile[]>('get_profiles');
      setProfiles(profileList);
    } catch (error) {
      console.error('Failed to load profiles:', error);
    }
  };

  const loadCurrentSettings = async () => {
    try {
      const current = await invoke<{ theme: string; profile: string }>('get_current_settings');
      setCurrentTheme(current.theme);
      setCurrentProfile(current.profile);
    } catch (error) {
      console.error('Failed to load current settings:', error);
    }
  };

  const applyTheme = async (themeName: string) => {
    setLoading(true);
    try {
      await invoke('apply_theme', { themeName });
      setCurrentTheme(themeName);
      setCurrentProfile(''); // Clear profile when applying theme directly
    } catch (error) {
      console.error('Failed to apply theme:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyProfile = async (profileName: string) => {
    setLoading(true);
    try {
      await invoke('apply_profile', { profileName });
      setCurrentProfile(profileName);
      // Update current theme based on profile
      const profile = profiles.find(p => p.name === profileName);
      if (profile) {
        setCurrentTheme(profile.theme);
      }
    } catch (error) {
      console.error('Failed to apply profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const groupedThemes = themes.reduce((groups, theme) => {
    if (!groups[theme.category]) {
      groups[theme.category] = [];
    }
    groups[theme.category].push(theme);
    return groups;
  }, {} as Record<string, Theme[]>);

  return (
    <div className="theme-manager">
      <div className="theme-manager-header">
        <h2>Portal OS Theme Manager</h2>
        <p>Customize your desktop appearance and switch between different profiles</p>
      </div>

      <div className="theme-manager-content">
        {/* Current Settings */}
        <div className="current-settings">
          <h3>Current Settings</h3>
          <div className="current-info">
            <div className="current-item">
              <span className="label">Theme:</span>
              <span className="value">{currentTheme || 'Default'}</span>
            </div>
            <div className="current-item">
              <span className="label">Profile:</span>
              <span className="value">{currentProfile || 'None'}</span>
            </div>
          </div>
        </div>

        {/* Profiles Section */}
        <div className="profiles-section">
          <h3>Quick Profiles</h3>
          <div className="profile-grid">
            {profiles.map(profile => (
              <div
                key={profile.name}
                className={`profile-card ${currentProfile === profile.name ? 'active' : ''}`}
                onClick={() => applyProfile(profile.name)}
              >
                <div className="profile-icon">
                  {profile.name === 'coding' && <CodeIcon />}
                  {profile.name === 'studying' && <BookIcon />}
                  {profile.name === 'watching' && <VideoIcon />}
                  {profile.name === 'gaming' && <GameIcon />}
                </div>
                <div className="profile-info">
                  <h4>{profile.name.charAt(0).toUpperCase() + profile.name.slice(1)}</h4>
                  <p>{profile.description}</p>
                </div>
                {currentProfile === profile.name && (
                  <div className="active-indicator">✓</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Themes Section */}
        <div className="themes-section">
          <h3>Individual Themes</h3>
          {Object.entries(groupedThemes).map(([category, categoryThemes]) => (
            <div key={category} className="theme-category">
              <h4>{category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</h4>
              <div className="theme-grid">
                {categoryThemes.map(theme => (
                  <div
                    key={theme.name}
                    className={`theme-card ${currentTheme === theme.name ? 'active' : ''}`}
                    onClick={() => applyTheme(theme.name)}
                  >
                    <div className="theme-preview">
                      <img 
                        src={`/themes/${category}/${theme.name}/preview.png`} 
                        alt={theme.name}
                        onError={(e) => {
                          e.currentTarget.src = '/themes/default-preview.png';
                        }}
                      />
                    </div>
                    <div className="theme-info">
                      <h5>{theme.name.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</h5>
                      <p>{theme.description}</p>
                    </div>
                    {currentTheme === theme.name && (
                      <div className="active-indicator">✓</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Loading Overlay */}
        {loading && (
          <div className="loading-overlay">
            <div className="loading-spinner"></div>
            <p>Applying theme...</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Icon components
const CodeIcon = () => <span className="icon">💻</span>;
const BookIcon = () => <span className="icon">📚</span>;
const VideoIcon = () => <span className="icon">🎬</span>;
const GameIcon = () => <span className="icon">🎮</span>;
```

#### 4. Auto-Switch Implementation
```python
#!/usr/bin/env python3
"""
Theme Auto-Switch Manager
Automatically switches themes based on user activity and conditions
"""

import asyncio
import json
import logging
import psutil
import time
from pathlib import Path
from typing import Dict, List
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from theme_manager import ThemeManager

class AutoSwitchManager:
    def __init__(self, theme_manager: ThemeManager):
        self.theme_manager = theme_manager
        self.observer = Observer()
        self.running = False
        self.last_check = time.time()
        self.check_interval = 30  # Check every 30 seconds
        
    async def start(self):
        """Start the auto-switch manager"""
        self.running = True
        
        # Start monitoring
        await self._start_application_monitoring()
        await self._start_directory_monitoring()
        
        # Start periodic checks
        await self._periodic_check()
    
    async def _periodic_check(self):
        """Periodic check for theme switching conditions"""
        while self.running:
            try:
                await self._check_auto_switch_conditions()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                logging.error(f"Error in periodic check: {e}")
                await asyncio.sleep(60)  # Wait longer on error
    
    async def _check_auto_switch_conditions(self):
        """Check if theme should be auto-switched"""
        current_time = time.time()
        if current_time - self.last_check < self.check_interval:
            return
        
        self.last_check = current_time
        
        # Get current running applications
        running_apps = self._get_running_applications()
        
        # Get current working directory
        current_dir = self._get_current_working_directory()
        
        # Check each profile's conditions
        for profile_name, profile in self.theme_manager.profiles.items():
            if await self._should_switch_to_profile(profile, running_apps, current_dir):
                logging.info(f"Auto-switching to profile: {profile_name}")
                self.theme_manager.apply_profile(profile_name)
                break
    
    async def _should_switch_to_profile(self, profile: Profile, running_apps: List[str], current_dir: str) -> bool:
        """Check if should switch to a specific profile"""
        conditions = profile.auto_switch_conditions
        
        # Check application conditions
        if 'applications' in conditions:
            app_conditions = conditions['applications']
            if app_conditions and any(app in running_apps for app in app_conditions):
                return True
        
        # Check directory conditions
        if 'directories' in conditions:
            dir_conditions = conditions['directories']
            if dir_conditions and any(current_dir.startswith(Path.home() / dir) for dir in dir_conditions):
                return True
        
        # Check time conditions
        if 'time_of_day' in conditions:
            time_condition = conditions['time_of_day']
            if time_condition and self._check_time_condition(time_condition):
                return True
        
        return False
    
    def _get_running_applications(self) -> List[str]:
        """Get list of currently running applications"""
        apps = []
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                proc_info = proc.info
                if proc_info['name']:
                    apps.append(proc_info['name'])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return apps
    
    def _get_current_working_directory(self) -> str:
        """Get current working directory (simplified)"""
        # This would need to be implemented based on active window
        # For now, return a default
        return str(Path.home())
    
    def _check_time_condition(self, time_condition: Dict) -> bool:
        """Check time-based conditions"""
        # Implement time-based switching logic
        return False
    
    async def _start_application_monitoring(self):
        """Start monitoring application launches"""
        # Monitor application launches using system events
        pass
    
    async def _start_directory_monitoring(self):
        """Start monitoring directory changes"""
        # Monitor directory changes for auto-switching
        pass

class ApplicationMonitor(FileSystemEventHandler):
    def __init__(self, auto_switch_manager: AutoSwitchManager):
        self.auto_switch_manager = auto_switch_manager
    
    def on_created(self, event):
        if not event.is_directory:
            # Check if this is an application launch
            pass

if __name__ == "__main__":
    theme_manager = ThemeManager()
    auto_switch_manager = AutoSwitchManager(theme_manager)
    
    asyncio.run(auto_switch_manager.start())
```

### Installation and Setup

#### 1. Theme Installation Script
```bash
#!/bin/bash
# install-themes.sh - Theme System Installation

echo "Installing Portal OS Theme System..."

# Install dependencies
sudo apt update
sudo apt install -y git curl wget build-essential

# Install theme dependencies
sudo apt install -y gnome-tweaks dconf-cli

# Create theme directories
sudo mkdir -p /opt/portal-os/themes/{system,profiles,custom,config}
sudo mkdir -p /opt/portal-os/themes/system/{mac-like,windows-like,cutefish-default,clean-interfaces}

# Clone and install Whitesur theme
echo "Installing Whitesur Mac theme..."
git clone https://github.com/vinceliuice/WhiteSur-gtk-theme.git /tmp/whitesur
cd /tmp/whitesur
./install.sh --dest /usr/share/themes --opacity normal --theme default
./tweaks.sh --install

# Clone and install Whitesur icons
git clone https://github.com/vinceliuice/WhiteSur-icon-theme.git /tmp/whitesur-icons
cd /tmp/whitesur-icons
./install.sh --dest /usr/share/icons

# Clone and install Whitesur cursors
git clone https://github.com/vinceliuice/WhiteSur-cursors.git /tmp/whitesur-cursors
cd /tmp/whitesur-cursors
./install.sh --dest /usr/share/icons

# Install other themes
echo "Installing additional themes..."

# Nord theme
git clone https://github.com/arcticicestudio/nord-gnome-terminal.git /tmp/nord-terminal
cd /tmp/nord-terminal/src
./nord.sh

# Gruvbox theme
git clone https://github.com/morhetz/gruvbox.git /tmp/gruvbox
cp -r /tmp/gruvbox/colors/* ~/.vim/colors/

# Dracula theme
git clone https://github.com/dracula/gtk.git /tmp/dracula-gtk
cp -r /tmp/dracula-gtk/* /usr/share/themes/Dracula/

# Copy Portal OS theme configurations
sudo cp -r themes/* /opt/portal-os/themes/

# Set up theme manager
sudo cp scripts/theme-manager.py /opt/portal-os/scripts/
sudo chmod +x /opt/portal-os/scripts/theme-manager.py

# Create user configuration directory
mkdir -p ~/.config/portal-os/themes

# Set up auto-switch service
sudo tee /etc/systemd/user/portal-theme-auto-switch.service > /dev/null <<EOF
[Unit]
Description=Portal OS Theme Auto-Switch
After=graphical-session.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/portal-os/scripts/theme-auto-switch.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOF

systemctl --user enable portal-theme-auto-switch
systemctl --user start portal-theme-auto-switch

echo "Theme system installation complete!"
echo "You can now use the theme manager to switch between themes and profiles."
```

### Features Summary

#### Core Theme Features
- **Multiple Theme Categories**: Mac-like, Windows-like, Cutefish default, clean interfaces
- **Profile-Specific Themes**: Coding, studying, watching, gaming profiles
- **Seamless Switching**: Instant theme switching with hotkeys
- **Auto-Switch**: Automatic theme switching based on activity
- **Deep Customization**: GTK, icons, cursors, wallpapers, and more

#### Profile Features
- **Coding Profile**: Dark themes, developer tools, performance mode
- **Studying Profile**: Minimal interface, distraction-free, reading optimized
- **Watching Profile**: Dark mode, media optimized, entertainment focused
- **Gaming Profile**: Performance mode, gaming tools, Windows-like interface

#### Advanced Features
- **Auto-Switch**: Based on applications, directories, and time
- **Performance Integration**: CPU/GPU optimization per profile
- **IDE Integration**: Automatic theme switching for development tools
- **Browser Integration**: Dark reader and focus mode support
- **Terminal Integration**: Syntax highlighting themes

This comprehensive theming system provides Portal OS with the flexibility and customization options needed for a modern, developer-first operating system while maintaining the clean aesthetics and seamless user experience.
