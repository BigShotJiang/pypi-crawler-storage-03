# Portal OS Centralized Configuration System

## Overview

Portal OS now uses a **centralized configuration system** that ensures all components share consistent settings and can access system-wide configuration. This eliminates configuration duplication and provides a single source of truth for all Portal OS settings.

## Architecture

### Core Components

1. **`portal_config.py`** - The main configuration management module
2. **`portal-os`** - Central CLI wrapper that uses the configuration system
3. **Individual Component Scripts** - Can import and use the shared configuration

### Configuration Structure

```json
{
  "portal_os": {
    "version": "1.0.0",
    "auto_start": true,
    "default_profile": "developer",
    "log_level": "info",
    "backup_enabled": true,
    "update_check": true,
    "config_dir": "~/.portal-os/config"
  },
  "components": {
    "ai_assistant": {
      "enabled": true,
      "auto_start": true,
      "backend": "ollama",
      "model": "llama2",
      "api_key": "",
      "endpoint": "http://localhost:11434",
      "max_tokens": 2048,
      "temperature": 0.7
    },
    "security_privacy": {
      "enabled": true,
      "auto_start": true,
      "adblocker": true,
      "privacy_profile": "balanced",
      "firewall_enabled": true,
      "encryption_enabled": true,
      "monitoring_enabled": true,
      "compliance_gdpr": true,
      "compliance_hipaa": false,
      "compliance_sox": false
    }
    // ... other components
  },
  "profiles": {
    "developer": {
      "description": "Full development environment with all features",
      "components": ["ai_assistant", "security_privacy", "performance_optimizer", "advanced_ai", "search_assistant"],
      "settings": {
        "ai_assistant.auto_start": true,
        "security_privacy.privacy_profile": "balanced",
        "performance_optimizer.auto_optimize": true,
        "advanced_ai.code_intelligence": true,
        "search_assistant.index_files": true
      }
    }
    // ... other profiles
  },
  "system": {
    "platform": "win32",
    "python_version": "3.12.7",
    "home_directory": "C:\\Users\\user",
    "portal_directory": "C:\\Users\\user\\.portal-os",
    "log_directory": "C:\\Users\\user\\.portal-os\\logs",
    "cache_directory": "C:\\Users\\user\\.portal-os\\cache",
    "backup_directory": "C:\\Users\\user\\.portal-os\\backups",
    "config_directory": "C:\\Users\\user\\.portal-os\\config"
  },
  "logging": {
    "level": "info",
    "file_enabled": true,
    "console_enabled": true,
    "max_file_size_mb": 10,
    "backup_count": 5,
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  },
  "network": {
    "proxy_enabled": false,
    "proxy_url": "",
    "proxy_auth": "",
    "timeout_seconds": 30,
    "retry_attempts": 3,
    "user_agent": "Portal OS/1.0.0"
  }
}
```

## Usage

### For Component Developers

#### 1. Import the Configuration Module

```python
import sys
from pathlib import Path

# Add the parent directory to the path to import portal_config
sys.path.append(str(Path(__file__).parent.parent))

from portal_config import get_component_config, get_system_config, get_config_from_env
```

#### 2. Use Configuration in Your Component

```python
class MyComponent:
    def __init__(self):
        # Get component name from environment or default
        self.component_name = os.environ.get("PORTAL_OS_COMPONENT", "my_component")
        
        # Load configuration
        self.config = get_component_config(self.component_name)
        self.system_config = get_system_config()
        
        # If no config found, try environment
        if not self.config:
            self.config = get_config_from_env()
    
    def start(self):
        if not self.config.get("enabled", True):
            click.echo("❌ Component is disabled in configuration")
            return
        
        # Use configuration values
        api_key = self.config.get("api_key", "")
        endpoint = self.config.get("endpoint", "http://localhost:8080")
        
        click.echo(f"🚀 Starting with endpoint: {endpoint}")
```

#### 3. Available Configuration Functions

- `get_component_config(component_name)` - Get configuration for a specific component
- `get_system_config()` - Get system-wide configuration
- `get_config_from_env()` - Get configuration from environment variables
- `update_component_config(component_name, updates)` - Update component configuration
- `apply_profile(profile_name)` - Apply a profile's settings

### For Users

#### 1. View System Configuration

```bash
python portal-os config
```

#### 2. View Component Configuration

```bash
python portal-os config --component ai_assistant
```

#### 3. Start a Profile

```bash
python portal-os start-profile developer
```

#### 4. Manage Components

```bash
# Start a component
python portal-os start-component ai_assistant

# Stop a component
python portal-os stop-component ai_assistant

# Check component status
python portal-os component-command ai_assistant status
```

## Benefits

### 1. **Consistency**
- All components use the same configuration format
- No duplicate configuration files
- Single source of truth for all settings

### 2. **Modularity**
- Components can be developed independently
- Configuration is shared but not tightly coupled
- Easy to add new components

### 3. **Flexibility**
- Profile-based configuration switching
- Environment variable support
- Component-specific overrides

### 4. **Maintainability**
- Centralized configuration management
- Easy to update and backup
- Version control friendly

## File Structure

```
portal_os/
├── portal_config.py              # Main configuration module
├── portal-os                     # Central CLI wrapper
├── scripts/
│   ├── ai-assistant.py          # Component using shared config
│   ├── security-privacy-manager.py
│   ├── example-component.py     # Example implementation
│   └── ...
└── ~/.portal-os/
    ├── portal-os-config.json    # Main configuration file
    ├── config/                  # Component-specific configs
    │   ├── ai_assistant-config.json
    │   ├── security_privacy-config.json
    │   └── ...
    ├── logs/                    # Log files
    ├── cache/                   # Cache files
    └── backups/                 # Backup files
```

## Example Implementation

See `scripts/example-component.py` for a complete example of how to implement a component that uses the shared configuration system.

## Migration Guide

### For Existing Components

1. **Import the configuration module**
2. **Replace hardcoded settings** with configuration lookups
3. **Add environment variable support** for component name
4. **Update CLI commands** to use the new configuration system

### Example Migration

**Before:**
```python
class MyComponent:
    def __init__(self):
        self.api_key = "hardcoded_key"
        self.endpoint = "http://localhost:8080"
```

**After:**
```python
from portal_config import get_component_config

class MyComponent:
    def __init__(self):
        self.component_name = os.environ.get("PORTAL_OS_COMPONENT", "my_component")
        self.config = get_component_config(self.component_name)
        self.api_key = self.config.get("api_key", "")
        self.endpoint = self.config.get("endpoint", "http://localhost:8080")
```

## Troubleshooting

### Common Issues

1. **Import Error**: Make sure the parent directory is in the Python path
2. **Configuration Not Found**: Check if the component is defined in the main configuration
3. **Unicode Issues**: Ensure proper UTF-8 encoding is set for Windows

### Debug Commands

```bash
# Check configuration structure
python portal-os config

# Test component configuration
python portal-os config --component <component_name>

# Verify component integration
python portal-os component-command <component_name> status
```

## Future Enhancements

1. **Configuration Validation** - Schema validation for configuration files
2. **Hot Reloading** - Automatic configuration reloading
3. **Configuration UI** - Web-based configuration interface
4. **Configuration Templates** - Pre-built configuration templates
5. **Configuration Migration** - Tools for upgrading configuration formats
