# Docker Cleanup System Guide

## Overview

The Portal OS Docker Cleanup System is a comprehensive tool for managing and cleaning up Docker storage. It provides safe, controlled cleanup operations with detailed logging and history tracking.

## Features

- **Safe Mode**: Default safe operations that won't remove running containers or important data
- **Dry Run**: Preview what would be cleaned without actually performing operations
- **Comprehensive Cleanup**: Clean containers, images, volumes, networks, and system cache
- **Detailed Logging**: Track all operations with timestamps and space freed
- **History Tracking**: View cleanup history and results
- **Configurable**: Customize cleanup behavior through configuration files
- **CLI Interface**: Easy-to-use command-line interface with Click

## Installation

The script uses the existing project dependencies. Make sure you have the required packages installed:

```bash
pip install -r requirements.txt
```

## Usage

### Basic Commands

```bash
# Show help
python scripts/docker-cleanup.py --help

# Check Docker system status
python scripts/docker-cleanup.py status

# Run safe cleanup (default)
python scripts/docker-cleanup.py cleanup

# Run cleanup with dry run to see what would be cleaned
python scripts/docker-cleanup.py cleanup --dry-run

# Run specific cleanup operations
python scripts/docker-cleanup.py cleanup -o containers -o images

# Run unsafe cleanup (removes running containers and all images)
python scripts/docker-cleanup.py cleanup --unsafe

# Save results to file
python scripts/docker-cleanup.py cleanup --save-results
```

### Available Operations

#### Containers
- **stop_containers**: Stop all running containers (safe)
- **remove_stopped_containers**: Remove all stopped containers (safe)
- **remove_all_containers**: Remove all containers including running ones (unsafe)

#### Images
- **remove_dangling_images**: Remove dangling images (safe)
- **remove_unused_images**: Remove unused images (safe)
- **remove_all_images**: Remove all images (unsafe)

#### Volumes
- **remove_unused_volumes**: Remove unused volumes (safe)
- **remove_all_volumes**: Remove all volumes (unsafe)

#### Networks
- **remove_unused_networks**: Remove unused networks (safe)

#### System
- **prune_system**: Prune entire Docker system (safe)
- **prune_build_cache**: Prune build cache (safe)

### Additional Commands

```bash
# List all available operations
python scripts/docker-cleanup.py list-operations

# List operations for specific category
python scripts/docker-cleanup.py list-operations -o containers

# Show cleanup history
python scripts/docker-cleanup.py history

# Show history for last 30 days
python scripts/docker-cleanup.py history --days 30

# Show current configuration
python scripts/docker-cleanup.py config
```

## Configuration

The script creates a configuration file at `~/.portal-os/docker-cleanup-config.json` with the following structure:

```json
{
  "cleanup": {
    "safe_mode": true,
    "dry_run_default": false,
    "backup_before_cleanup": true,
    "max_age_days": 30,
    "min_space_threshold_gb": 5,
    "exclude_images": [],
    "exclude_containers": []
  },
  "operations": {
    "stop_containers": true,
    "remove_containers": true,
    "remove_images": true,
    "remove_volumes": false,
    "remove_networks": false,
    "prune_system": true,
    "prune_build_cache": true
  },
  "scheduling": {
    "auto_cleanup": false,
    "cleanup_interval_hours": 24,
    "cleanup_time": "02:00"
  }
}
```

## Safety Features

### Safe Mode (Default)
- Only removes stopped containers
- Only removes unused/dangling images
- Only removes unused volumes and networks
- Requires confirmation for unsafe operations

### Unsafe Mode
- Can remove running containers
- Can remove all images
- Can remove all volumes
- Use with extreme caution

### Dry Run
- Shows what would be cleaned without actually doing it
- Perfect for testing and understanding the impact

## Output and Logging

### Console Output
The script provides detailed, emoji-rich output showing:
- Operation status and progress
- Space freed by each operation
- Success/failure counts
- Total duration

### Results Files
When using `--save-results`, detailed results are saved to:
`~/.portal-os/docker-cleanup/results/cleanup_results_YYYYMMDD_HHMMSS.json`

### Log Files
Operation logs are stored in:
`~/.portal-os/docker-cleanup/logs/`

## Examples

### Quick Cleanup
```bash
# Safe cleanup of containers, images, and system cache
python scripts/docker-cleanup.py cleanup
```

### Aggressive Cleanup
```bash
# Remove everything (use with caution!)
python scripts/docker-cleanup.py cleanup --unsafe
```

### Selective Cleanup
```bash
# Only clean images and system cache
python scripts/docker-cleanup.py cleanup -o images -o system
```

### Preview Cleanup
```bash
# See what would be cleaned without doing it
python scripts/docker-cleanup.py cleanup --dry-run
```

### Monitor System
```bash
# Check current Docker system status
python scripts/docker-cleanup.py status
```

## Best Practices

1. **Always use dry run first**: Preview what will be cleaned before running actual cleanup
2. **Use safe mode by default**: Only use unsafe mode when you're certain about the consequences
3. **Save results**: Use `--save-results` to track cleanup history
4. **Monitor regularly**: Use the status command to monitor Docker system usage
5. **Exclude important containers**: Add important containers to the exclude list in configuration

## Troubleshooting

### Docker Not Running
```
❌ Docker is not running or not accessible
```
Solution: Start Docker Desktop or Docker daemon

### Permission Issues
```
❌ Permission denied
```
Solution: Run with appropriate permissions or add user to docker group

### Timeout Errors
```
❌ Operation timed out
```
Solution: Check Docker daemon status and try again

### No Space Freed
If no space is freed, it might mean:
- All containers are running (use unsafe mode to stop them)
- All images are in use
- Volumes contain important data

## Integration

The script can be integrated into:
- CI/CD pipelines for automated cleanup
- Cron jobs for scheduled cleanup
- Development workflows
- System maintenance scripts

## Contributing

The script follows the project's coding standards:
- Uses Click for CLI interface
- Comprehensive error handling
- Detailed logging and documentation
- Modular design with clear separation of concerns
- Type hints and docstrings
