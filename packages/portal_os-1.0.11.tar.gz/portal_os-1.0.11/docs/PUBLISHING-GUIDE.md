# 📦 Publishing Portal OS to PyPI

This guide covers how to publish the Portal OS package to PyPI (Python Package Index) for public distribution.

## 🎯 Prerequisites

### 1. PyPI Account Setup
```bash
# Create account on PyPI
# Visit: https://pypi.org/account/register/

# Create account on TestPyPI (for testing)
# Visit: https://test.pypi.org/account/register/
```

### 2. Install Publishing Tools
```bash
# Install Poetry (if not already installed)
pip install poetry

# Install build tools
pip install build twine

# Install Poetry publishing plugin
poetry self add poetry-plugin-publish
```

### 3. Configure Poetry for Publishing
```bash
# Configure Poetry with your PyPI credentials
poetry config pypi-token.pypi YOUR_PYPI_TOKEN
poetry config pypi-token.testpypi YOUR_TESTPYPI_TOKEN
```

## 🚀 Publishing Process

### Step 1: Prepare for Publishing

1. **Update Version** (if needed):
   ```bash
   # Update version in pyproject.toml
   poetry version patch  # 1.0.0 -> 1.0.1
   poetry version minor  # 1.0.0 -> 1.1.0
   poetry version major  # 1.0.0 -> 2.0.0
   ```

2. **Update CHANGELOG.md**:
   ```markdown
   ## [1.0.0] - 2024-01-XX
   
   ### Added
   - Initial release of Portal OS
   - AI-native developer operating system
   - Complete CLI management system
   - Configuration management
   - Profile system
   ```

3. **Run Tests**:
   ```bash
   # Run all tests
   poetry run pytest
   
   # Run with coverage
   poetry run pytest --cov=portal_os
   ```

4. **Code Quality Checks**:
   ```bash
   # Format code
   poetry run black .
   poetry run isort .
   
   # Lint code
   poetry run flake8 portal_os/
   poetry run mypy portal_os/
   ```

### Step 2: Build the Package

```bash
# Clean previous builds
rm -rf dist/ build/ *.egg-info/

# Build the package
poetry build

# Verify the build
ls -la dist/
# Should show: portal_os-1.0.0.tar.gz and portal_os-1.0.0-py3-none-any.whl
```

### Step 3: Test on TestPyPI (Recommended)

```bash
# Publish to TestPyPI first
poetry publish --repository testpypi

# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ portal-os

# Test the package
portal-os --version
portal-os --help
```

### Step 4: Publish to PyPI

```bash
# Publish to official PyPI
poetry publish

# Or using twine (alternative method)
twine upload dist/*
```

## 🔧 Publishing Commands Reference

### Using Poetry (Recommended)
```bash
# Build and publish in one command
poetry publish --build

# Publish to specific repository
poetry publish --repository testpypi
poetry publish --repository pypi

# Build only
poetry build

# Check what would be published
poetry publish --dry-run
```

### Using Traditional Tools
```bash
# Build
python -m build

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*

# Check package
twine check dist/*
```

## 📋 Pre-Publishing Checklist

- [ ] **Version Updated**: Version number in `pyproject.toml`
- [ ] **CHANGELOG Updated**: All changes documented
- [ ] **README.md**: Complete and accurate
- [ ] **LICENSE**: Present and correct
- [ ] **Tests Pass**: All tests passing
- [ ] **Code Quality**: Black, isort, flake8, mypy all pass
- [ ] **Dependencies**: All dependencies correctly specified
- [ ] **Entry Points**: CLI commands working
- [ ] **Documentation**: API docs updated (if applicable)
- [ ] **Build Success**: Package builds without errors
- [ ] **TestPyPI Test**: Package installs and works from TestPyPI

## 🎯 Post-Publishing

### 1. Verify Installation
```bash
# Create fresh virtual environment
python -m venv test_env
source test_env/bin/activate  # On Windows: test_env\Scripts\activate

# Install from PyPI
pip install portal-os

# Test functionality
portal-os --version
portal-os --help
portal-os config
```

### 2. Update Documentation
- Update installation instructions in README.md
- Update any references to installation methods
- Update version badges if applicable

### 3. Announce Release
- Create GitHub release
- Update project website
- Notify community channels

## 🔒 Security Best Practices

### 1. Token Management
```bash
# Use environment variables for tokens
export PYPI_TOKEN=your_token_here
export TESTPYPI_TOKEN=your_test_token_here

# Or use Poetry config
poetry config pypi-token.pypi $PYPI_TOKEN
poetry config pypi-token.testpypi $TESTPYPI_TOKEN
```

### 2. Two-Factor Authentication
- Enable 2FA on PyPI account
- Use API tokens instead of passwords
- Rotate tokens regularly

### 3. Package Signing (Optional)
```bash
# Generate GPG key
gpg --full-generate-key

# Sign package
poetry publish --sign
```

## 🚨 Troubleshooting

### Common Issues

1. **Authentication Errors**:
   ```bash
   # Check Poetry config
   poetry config --list
   
   # Reconfigure tokens
   poetry config pypi-token.pypi YOUR_TOKEN
   ```

2. **Build Errors**:
   ```bash
   # Clean and rebuild
   rm -rf dist/ build/ *.egg-info/
   poetry build
   ```

3. **Import Errors**:
   ```bash
   # Check package structure
   poetry check
   
   # Verify imports work
   python -c "import portal_os; print(portal_os.__version__)"
   ```

4. **Version Conflicts**:
   ```bash
   # Check if version already exists
   pip search portal-os  # (if available)
   
   # Increment version
   poetry version patch
   ```

### Getting Help

- **PyPI Help**: https://pypi.org/help/
- **Poetry Docs**: https://python-poetry.org/docs/
- **Twine Docs**: https://twine.readthedocs.io/

## 📈 Version Management

### Semantic Versioning
- **MAJOR.MINOR.PATCH**
- **MAJOR**: Breaking changes
- **MINOR**: New features, backward compatible
- **PATCH**: Bug fixes, backward compatible

### Version Commands
```bash
# Check current version
poetry version

# Update versions
poetry version patch  # 1.0.0 -> 1.0.1
poetry version minor  # 1.0.0 -> 1.1.0
poetry version major  # 1.0.0 -> 2.0.0

# Set specific version
poetry version 1.2.3
```

## 🎉 Success!

Once published, users can install Portal OS with:
```bash
pip install portal-os
portal-os --help
```

The package will be available at: https://pypi.org/project/portal-os/
