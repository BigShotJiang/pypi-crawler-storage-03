# API Reference

This page contains the complete API documentation for LotusFilter.

```{eval-rst}
.. automodule:: lotf
   :members:
   :undoc-members:
   :show-inheritance:
```
