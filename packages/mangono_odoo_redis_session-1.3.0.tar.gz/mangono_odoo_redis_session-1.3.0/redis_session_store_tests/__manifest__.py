# (C) 2018 Smile (<http://www.smile.fr>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "Test for Redis Session Store",
    "version": "1.0",
    "depends": ["base"],
    "author": "NDP Systemes",
    "license": "AGPL-3",
    "description": """Use Redis Session instead of File system""",
    "summary": "",
    "website": "",
    "category": "Tools",
    "auto_install": False,
    "installable": True,
    "application": False,
}
