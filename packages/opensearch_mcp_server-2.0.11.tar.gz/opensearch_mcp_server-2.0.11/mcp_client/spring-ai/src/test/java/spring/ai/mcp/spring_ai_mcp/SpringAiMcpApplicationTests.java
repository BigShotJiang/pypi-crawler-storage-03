package spring.ai.mcp.spring_ai_mcp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiMcpApplicationTests {

	@Test
	void contextLoads() {
	}

}
