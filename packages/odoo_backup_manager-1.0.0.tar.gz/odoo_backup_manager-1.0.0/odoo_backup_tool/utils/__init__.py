"""Utility functions for Odoo Backup Tool"""
