#!/usr/bin/env python3
"""
Command-line interface for gcode_mass_matrix_analyzer
"""

from .analyzer import main

if __name__ == "__main__":
    main()
