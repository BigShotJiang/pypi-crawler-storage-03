# coding=utf-8
"""Tests that communicate with deb plugin via the v3 API."""
