default_app_config = "pulp_deb.app.PulpDebPluginAppConfig"
