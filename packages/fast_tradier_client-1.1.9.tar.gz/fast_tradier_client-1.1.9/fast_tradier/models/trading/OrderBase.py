from fast_tradier.models.ModelBase import NewModelBase

class OrderBase(NewModelBase):
    ...