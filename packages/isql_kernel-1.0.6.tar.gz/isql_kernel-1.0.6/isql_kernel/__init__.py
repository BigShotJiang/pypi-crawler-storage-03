
from .kernel import ISQLRouterKernel
__version__ = ISQLRouterKernel.implementation_version