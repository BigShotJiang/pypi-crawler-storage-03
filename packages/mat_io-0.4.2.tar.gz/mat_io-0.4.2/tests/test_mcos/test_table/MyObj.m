classdef MyObj
    properties
        Value
    end
    methods
        function obj = MyObj(v)
            obj.Value = v;
        end
    end
end
