classdef DefaultClass2
    properties
        a = "Default String";
        b = 10;
        c = 30;
    end
end
