classdef YesConstructor
    properties
        a;
        b;
        c;
    end
    methods
        function obj = YesConstructor()
            obj.a = 10;
            obj.b = 20;
            obj.c = 30;
        end
    end
end
