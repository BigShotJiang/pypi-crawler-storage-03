travis2docker
=============

.. testsetup::

    from travis2docker import *

.. automodule:: travis2docker
    :members:
