
Changelog
=========

3.0.0 (2016-07-26)
******************

* First release on PyPI.
