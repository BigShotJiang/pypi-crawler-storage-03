This is my first Python package for CPE 486/586.
