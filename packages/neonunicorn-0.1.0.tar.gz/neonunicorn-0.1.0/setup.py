from setuptools import setup, find_packages

setup(
    name="neonunicorn",        # must be unique on PyPI
    version="0.1.0",
    packages=find_packages(),
    description="My first Python package for CPE 486/586",
    author="Your Name",
    author_email="youremail@example.com",
    python_requires=">=3.6",
)

