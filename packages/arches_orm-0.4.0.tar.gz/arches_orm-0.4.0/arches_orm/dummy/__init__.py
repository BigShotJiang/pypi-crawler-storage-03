from .adapter import DummyAdapter as adapter

__all__ = ["adapter"]
