from .adapter import ResourceAPIAdapter

adapter = ResourceAPIAdapter._singleton

__all__ = ["adapter"]
