from .adapter import get_adapter

HOOKS = get_adapter().get_hooks()
