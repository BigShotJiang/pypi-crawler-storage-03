from .adapter import ArchesDjangoAdapter as adapter

__all__ = ["adapter"]
