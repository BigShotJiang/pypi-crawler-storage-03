from django.apps import AppConfig


class ArchesORMConfig(AppConfig):
    name = "arches_orm.arches_django"
    verbose_name = "Arches ORM with Django backend"
