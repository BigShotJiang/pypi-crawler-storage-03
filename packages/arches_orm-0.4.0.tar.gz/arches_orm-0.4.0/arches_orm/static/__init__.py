from .adapter import StaticAdapter as adapter

__all__ = ["adapter"]
