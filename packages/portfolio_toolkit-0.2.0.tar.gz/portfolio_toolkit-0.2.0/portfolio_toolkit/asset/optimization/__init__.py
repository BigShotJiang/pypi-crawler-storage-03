from .optimization_asset import OptimizationAsset

__all__ = [
    "OptimizationAsset",
]
