# Contributing

Contributions of any kind are very welcome! See the
[docs on contributing](https://sqlalchemy-declarative-extensions.readthedocs.io/en/latest/contributing).
for more details.
