from sqlalchemy_declarative_extensions.procedure.base import (
    Procedure,
    Procedures,
    register_procedure,
)

__all__ = [
    "Procedure",
    "Procedures",
    "register_procedure",
]
