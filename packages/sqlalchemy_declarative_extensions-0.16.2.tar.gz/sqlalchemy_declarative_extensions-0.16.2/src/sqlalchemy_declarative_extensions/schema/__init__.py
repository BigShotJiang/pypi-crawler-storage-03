from sqlalchemy_declarative_extensions.schema.base import Schema, Schemas

__all__ = [
    "Schema",
    "Schemas",
]
