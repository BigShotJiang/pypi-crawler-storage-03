# Security Policy

## Supported Versions

All versions are currently supported for security fixes.

## Reporting a Vulnerability

The best route to reporting a security vulnerability is to email james at talkunafraid dot co (dot) uk with the details privately. If this doesn't work, just raise an issue in GitHub!
