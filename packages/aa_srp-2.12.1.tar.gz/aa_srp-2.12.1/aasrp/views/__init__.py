"""
Initialise the views
"""
