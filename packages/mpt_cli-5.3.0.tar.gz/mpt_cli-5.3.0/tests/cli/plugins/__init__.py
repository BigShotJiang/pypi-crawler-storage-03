from tests.cli.plugins.audit_plugin.app import app  # noqa
