from cli.core.products.services.related_components_base_service import (
    RelatedComponentsBaseService,
)


class ParameterGroupService(RelatedComponentsBaseService):
    """Service for managing parameter group operations."""
