from cli.core.products.services.related_components_base_service import (
    RelatedComponentsBaseService,
)


class ItemGroupService(RelatedComponentsBaseService):
    """Service for managing item group operations."""
