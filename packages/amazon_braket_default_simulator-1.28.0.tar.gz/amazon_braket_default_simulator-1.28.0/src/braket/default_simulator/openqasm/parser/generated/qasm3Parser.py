# Generated from qasm3Parser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,101,768,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
        46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,
        52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,
        59,7,59,1,0,3,0,122,8,0,1,0,5,0,125,8,0,10,0,12,0,128,9,0,1,0,1,
        0,1,1,1,1,1,1,1,1,1,2,1,2,5,2,138,8,2,10,2,12,2,141,9,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,170,8,2,3,2,172,8,2,1,3,
        1,3,3,3,176,8,3,1,4,1,4,5,4,180,8,4,10,4,12,4,183,9,4,1,4,1,4,1,
        5,1,5,1,5,1,6,1,6,3,6,192,8,6,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,
        9,1,9,1,9,1,10,1,10,1,10,1,11,1,11,1,11,1,12,1,12,1,12,1,12,1,12,
        1,12,1,12,1,12,1,12,1,12,3,12,221,8,12,1,12,1,12,1,13,1,13,1,13,
        1,13,1,13,1,13,1,13,3,13,232,8,13,1,14,1,14,1,14,3,14,237,8,14,1,
        14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,1,16,1,16,3,16,249,8,16,1,
        16,1,16,1,17,1,17,3,17,255,8,17,1,17,1,17,1,18,1,18,1,18,3,18,262,
        8,18,1,18,1,18,1,19,5,19,267,8,19,10,19,12,19,270,9,19,1,19,1,19,
        1,19,3,19,275,8,19,1,19,3,19,278,8,19,1,19,3,19,281,8,19,1,19,1,
        19,1,19,1,19,5,19,287,8,19,10,19,12,19,290,9,19,1,19,1,19,1,19,3,
        19,295,8,19,1,19,3,19,298,8,19,1,19,3,19,301,8,19,1,19,3,19,304,
        8,19,1,19,3,19,307,8,19,1,20,1,20,1,20,3,20,312,8,20,1,20,1,20,1,
        21,1,21,1,21,1,21,1,22,1,22,1,22,1,22,1,22,1,22,1,23,1,23,3,23,328,
        8,23,1,23,1,23,1,23,3,23,333,8,23,1,23,1,23,1,24,1,24,1,24,1,24,
        1,24,1,24,1,24,1,25,1,25,1,25,3,25,347,8,25,1,25,1,25,1,25,1,26,
        1,26,1,26,3,26,355,8,26,1,26,1,26,1,27,1,27,1,27,1,27,1,28,1,28,
        1,28,1,28,3,28,367,8,28,1,28,1,28,3,28,371,8,28,1,28,1,28,1,29,1,
        29,1,29,1,29,3,29,379,8,29,1,29,1,29,3,29,383,8,29,1,29,1,29,1,30,
        1,30,1,30,1,30,3,30,391,8,30,1,30,3,30,394,8,30,1,30,1,30,1,30,1,
        31,1,31,1,31,1,31,3,31,403,8,31,1,31,1,31,1,32,1,32,1,32,1,33,1,
        33,1,33,1,33,3,33,414,8,33,1,33,3,33,417,8,33,1,33,1,33,3,33,421,
        8,33,1,33,1,33,5,33,425,8,33,10,33,12,33,428,9,33,1,33,1,33,1,34,
        1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,3,34,441,8,34,1,34,1,34,
        1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,3,34,455,8,34,
        1,34,1,34,3,34,459,8,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,
        1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,
        1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,1,34,
        1,34,5,34,496,8,34,10,34,12,34,499,9,34,1,35,1,35,1,35,5,35,504,
        8,35,10,35,12,35,507,9,35,1,36,1,36,1,36,3,36,512,8,36,1,37,1,37,
        1,37,1,38,3,38,518,8,38,1,38,1,38,3,38,522,8,38,1,38,1,38,3,38,526,
        8,38,1,39,1,39,1,39,1,39,5,39,532,8,39,10,39,12,39,535,9,39,1,39,
        3,39,538,8,39,1,39,1,39,1,40,1,40,1,40,3,40,545,8,40,1,40,1,40,1,
        40,3,40,550,8,40,5,40,552,8,40,10,40,12,40,555,9,40,1,40,3,40,558,
        8,40,1,40,1,40,1,41,1,41,1,41,1,41,3,41,566,8,41,1,41,1,41,1,41,
        3,41,571,8,41,5,41,573,8,41,10,41,12,41,576,9,41,1,41,3,41,579,8,
        41,3,41,581,8,41,1,41,1,41,1,42,1,42,5,42,587,8,42,10,42,12,42,590,
        9,42,1,43,1,43,1,43,1,44,1,44,1,44,1,44,1,44,1,44,1,44,1,44,1,44,
        1,44,1,44,3,44,606,8,44,3,44,608,8,44,1,44,1,44,1,45,1,45,3,45,614,
        8,45,1,45,1,45,3,45,618,8,45,1,45,1,45,3,45,622,8,45,1,45,1,45,3,
        45,626,8,45,1,45,1,45,3,45,630,8,45,1,45,1,45,1,45,1,45,1,45,1,45,
        1,45,1,45,3,45,640,8,45,3,45,642,8,45,1,46,1,46,3,46,646,8,46,1,
        47,1,47,1,47,1,47,1,47,1,47,1,47,1,48,1,48,1,48,1,48,1,48,1,48,1,
        48,1,48,1,48,3,48,664,8,48,1,48,1,48,1,49,1,49,1,49,1,49,1,50,1,
        50,3,50,674,8,50,1,51,1,51,1,51,1,51,3,51,680,8,51,3,51,682,8,51,
        1,52,1,52,1,53,1,53,1,53,1,53,1,53,1,53,1,53,1,53,1,53,3,53,695,
        8,53,1,53,1,53,1,53,3,53,700,8,53,1,54,1,54,1,54,5,54,705,8,54,10,
        54,12,54,708,9,54,1,54,3,54,711,8,54,1,55,1,55,1,55,5,55,716,8,55,
        10,55,12,55,719,9,55,1,55,3,55,722,8,55,1,56,1,56,1,56,5,56,727,
        8,56,10,56,12,56,730,9,56,1,56,3,56,733,8,56,1,57,1,57,1,57,5,57,
        738,8,57,10,57,12,57,741,9,57,1,57,3,57,744,8,57,1,58,1,58,1,58,
        5,58,749,8,58,10,58,12,58,752,9,58,1,58,3,58,755,8,58,1,59,1,59,
        1,59,5,59,760,8,59,10,59,12,59,763,9,59,1,59,3,59,766,8,59,1,59,
        1,426,1,68,60,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,
        38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,
        82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,
        0,10,1,0,21,22,2,0,25,25,27,27,2,0,60,60,78,78,2,0,64,64,75,76,2,
        0,49,49,82,91,2,0,65,65,67,68,2,0,62,62,64,64,1,0,41,42,1,0,23,24,
        1,0,87,88,850,0,121,1,0,0,0,2,131,1,0,0,0,4,171,1,0,0,0,6,173,1,
        0,0,0,8,177,1,0,0,0,10,186,1,0,0,0,12,191,1,0,0,0,14,193,1,0,0,0,
        16,197,1,0,0,0,18,201,1,0,0,0,20,204,1,0,0,0,22,207,1,0,0,0,24,210,
        1,0,0,0,26,224,1,0,0,0,28,233,1,0,0,0,30,240,1,0,0,0,32,246,1,0,
        0,0,34,252,1,0,0,0,36,258,1,0,0,0,38,306,1,0,0,0,40,308,1,0,0,0,
        42,315,1,0,0,0,44,319,1,0,0,0,46,327,1,0,0,0,48,336,1,0,0,0,50,343,
        1,0,0,0,52,351,1,0,0,0,54,358,1,0,0,0,56,362,1,0,0,0,58,374,1,0,
        0,0,60,386,1,0,0,0,62,398,1,0,0,0,64,406,1,0,0,0,66,409,1,0,0,0,
        68,458,1,0,0,0,70,500,1,0,0,0,72,511,1,0,0,0,74,513,1,0,0,0,76,517,
        1,0,0,0,78,527,1,0,0,0,80,541,1,0,0,0,82,561,1,0,0,0,84,584,1,0,
        0,0,86,591,1,0,0,0,88,607,1,0,0,0,90,641,1,0,0,0,92,643,1,0,0,0,
        94,647,1,0,0,0,96,654,1,0,0,0,98,667,1,0,0,0,100,673,1,0,0,0,102,
        681,1,0,0,0,104,683,1,0,0,0,106,699,1,0,0,0,108,701,1,0,0,0,110,
        712,1,0,0,0,112,723,1,0,0,0,114,734,1,0,0,0,116,745,1,0,0,0,118,
        756,1,0,0,0,120,122,3,2,1,0,121,120,1,0,0,0,121,122,1,0,0,0,122,
        126,1,0,0,0,123,125,3,4,2,0,124,123,1,0,0,0,125,128,1,0,0,0,126,
        124,1,0,0,0,126,127,1,0,0,0,127,129,1,0,0,0,128,126,1,0,0,0,129,
        130,5,0,0,1,130,1,1,0,0,0,131,132,5,1,0,0,132,133,5,98,0,0,133,134,
        5,57,0,0,134,3,1,0,0,0,135,172,3,10,5,0,136,138,3,6,3,0,137,136,
        1,0,0,0,138,141,1,0,0,0,139,137,1,0,0,0,139,140,1,0,0,0,140,169,
        1,0,0,0,141,139,1,0,0,0,142,170,3,44,22,0,143,170,3,62,31,0,144,
        170,3,32,16,0,145,170,3,34,17,0,146,170,3,18,9,0,147,170,3,14,7,
        0,148,170,3,46,23,0,149,170,3,48,24,0,150,170,3,20,10,0,151,170,
        3,56,28,0,152,170,3,66,33,0,153,170,3,36,18,0,154,170,3,22,11,0,
        155,170,3,64,32,0,156,170,3,58,29,0,157,170,3,24,12,0,158,170,3,
        38,19,0,159,170,3,60,30,0,160,170,3,26,13,0,161,170,3,16,8,0,162,
        170,3,50,25,0,163,170,3,40,20,0,164,170,3,52,26,0,165,170,3,54,27,
        0,166,170,3,42,21,0,167,170,3,28,14,0,168,170,3,30,15,0,169,142,
        1,0,0,0,169,143,1,0,0,0,169,144,1,0,0,0,169,145,1,0,0,0,169,146,
        1,0,0,0,169,147,1,0,0,0,169,148,1,0,0,0,169,149,1,0,0,0,169,150,
        1,0,0,0,169,151,1,0,0,0,169,152,1,0,0,0,169,153,1,0,0,0,169,154,
        1,0,0,0,169,155,1,0,0,0,169,156,1,0,0,0,169,157,1,0,0,0,169,158,
        1,0,0,0,169,159,1,0,0,0,169,160,1,0,0,0,169,161,1,0,0,0,169,162,
        1,0,0,0,169,163,1,0,0,0,169,164,1,0,0,0,169,165,1,0,0,0,169,166,
        1,0,0,0,169,167,1,0,0,0,169,168,1,0,0,0,170,172,1,0,0,0,171,135,
        1,0,0,0,171,139,1,0,0,0,172,5,1,0,0,0,173,175,5,20,0,0,174,176,5,
        101,0,0,175,174,1,0,0,0,175,176,1,0,0,0,176,7,1,0,0,0,177,181,5,
        52,0,0,178,180,3,4,2,0,179,178,1,0,0,0,180,183,1,0,0,0,181,179,1,
        0,0,0,181,182,1,0,0,0,182,184,1,0,0,0,183,181,1,0,0,0,184,185,5,
        53,0,0,185,9,1,0,0,0,186,187,5,19,0,0,187,188,5,101,0,0,188,11,1,
        0,0,0,189,192,3,4,2,0,190,192,3,8,4,0,191,189,1,0,0,0,191,190,1,
        0,0,0,192,13,1,0,0,0,193,194,5,3,0,0,194,195,5,92,0,0,195,196,5,
        57,0,0,196,15,1,0,0,0,197,198,5,2,0,0,198,199,5,92,0,0,199,200,5,
        57,0,0,200,17,1,0,0,0,201,202,5,10,0,0,202,203,5,57,0,0,203,19,1,
        0,0,0,204,205,5,11,0,0,205,206,5,57,0,0,206,21,1,0,0,0,207,208,5,
        14,0,0,208,209,5,57,0,0,209,23,1,0,0,0,210,211,5,16,0,0,211,212,
        3,90,45,0,212,213,5,87,0,0,213,220,5,18,0,0,214,221,3,78,39,0,215,
        216,5,50,0,0,216,217,3,76,38,0,217,218,5,51,0,0,218,221,1,0,0,0,
        219,221,5,87,0,0,220,214,1,0,0,0,220,215,1,0,0,0,220,219,1,0,0,0,
        221,222,1,0,0,0,222,223,3,12,6,0,223,25,1,0,0,0,224,225,5,12,0,0,
        225,226,5,54,0,0,226,227,3,68,34,0,227,228,5,55,0,0,228,231,3,12,
        6,0,229,230,5,13,0,0,230,232,3,12,6,0,231,229,1,0,0,0,231,232,1,
        0,0,0,232,27,1,0,0,0,233,236,5,15,0,0,234,237,3,68,34,0,235,237,
        3,74,37,0,236,234,1,0,0,0,236,235,1,0,0,0,236,237,1,0,0,0,237,238,
        1,0,0,0,238,239,5,57,0,0,239,29,1,0,0,0,240,241,5,17,0,0,241,242,
        5,54,0,0,242,243,3,68,34,0,243,244,5,55,0,0,244,245,3,12,6,0,245,
        31,1,0,0,0,246,248,5,48,0,0,247,249,3,116,58,0,248,247,1,0,0,0,248,
        249,1,0,0,0,249,250,1,0,0,0,250,251,5,57,0,0,251,33,1,0,0,0,252,
        254,5,8,0,0,253,255,3,98,49,0,254,253,1,0,0,0,254,255,1,0,0,0,255,
        256,1,0,0,0,256,257,3,8,4,0,257,35,1,0,0,0,258,259,5,45,0,0,259,
        261,3,98,49,0,260,262,3,116,58,0,261,260,1,0,0,0,261,262,1,0,0,0,
        262,263,1,0,0,0,263,264,5,57,0,0,264,37,1,0,0,0,265,267,3,88,44,
        0,266,265,1,0,0,0,267,270,1,0,0,0,268,266,1,0,0,0,268,269,1,0,0,
        0,269,271,1,0,0,0,270,268,1,0,0,0,271,277,5,87,0,0,272,274,5,54,
        0,0,273,275,3,110,55,0,274,273,1,0,0,0,274,275,1,0,0,0,275,276,1,
        0,0,0,276,278,5,55,0,0,277,272,1,0,0,0,277,278,1,0,0,0,278,280,1,
        0,0,0,279,281,3,98,49,0,280,279,1,0,0,0,280,281,1,0,0,0,281,282,
        1,0,0,0,282,283,3,116,58,0,283,284,5,57,0,0,284,307,1,0,0,0,285,
        287,3,88,44,0,286,285,1,0,0,0,287,290,1,0,0,0,288,286,1,0,0,0,288,
        289,1,0,0,0,289,291,1,0,0,0,290,288,1,0,0,0,291,297,5,38,0,0,292,
        294,5,54,0,0,293,295,3,110,55,0,294,293,1,0,0,0,294,295,1,0,0,0,
        295,296,1,0,0,0,296,298,5,55,0,0,297,292,1,0,0,0,297,298,1,0,0,0,
        298,300,1,0,0,0,299,301,3,98,49,0,300,299,1,0,0,0,300,301,1,0,0,
        0,301,303,1,0,0,0,302,304,3,116,58,0,303,302,1,0,0,0,303,304,1,0,
        0,0,304,305,1,0,0,0,305,307,5,57,0,0,306,268,1,0,0,0,306,288,1,0,
        0,0,307,39,1,0,0,0,308,311,3,74,37,0,309,310,5,61,0,0,310,312,3,
        84,42,0,311,309,1,0,0,0,311,312,1,0,0,0,312,313,1,0,0,0,313,314,
        5,57,0,0,314,41,1,0,0,0,315,316,5,46,0,0,316,317,3,100,50,0,317,
        318,5,57,0,0,318,43,1,0,0,0,319,320,5,9,0,0,320,321,5,87,0,0,321,
        322,5,60,0,0,322,323,3,70,35,0,323,324,5,57,0,0,324,45,1,0,0,0,325,
        328,3,90,45,0,326,328,3,94,47,0,327,325,1,0,0,0,327,326,1,0,0,0,
        328,329,1,0,0,0,329,332,5,87,0,0,330,331,5,60,0,0,331,333,3,72,36,
        0,332,330,1,0,0,0,332,333,1,0,0,0,333,334,1,0,0,0,334,335,5,57,0,
        0,335,47,1,0,0,0,336,337,5,23,0,0,337,338,3,90,45,0,338,339,5,87,
        0,0,339,340,5,60,0,0,340,341,3,72,36,0,341,342,5,57,0,0,342,49,1,
        0,0,0,343,346,7,0,0,0,344,347,3,90,45,0,345,347,3,94,47,0,346,344,
        1,0,0,0,346,345,1,0,0,0,347,348,1,0,0,0,348,349,5,87,0,0,349,350,
        5,57,0,0,350,51,1,0,0,0,351,352,7,1,0,0,352,354,5,87,0,0,353,355,
        3,98,49,0,354,353,1,0,0,0,354,355,1,0,0,0,355,356,1,0,0,0,356,357,
        5,57,0,0,357,53,1,0,0,0,358,359,3,92,46,0,359,360,5,87,0,0,360,361,
        5,57,0,0,361,55,1,0,0,0,362,363,5,4,0,0,363,364,5,87,0,0,364,366,
        5,54,0,0,365,367,3,108,54,0,366,365,1,0,0,0,366,367,1,0,0,0,367,
        368,1,0,0,0,368,370,5,55,0,0,369,371,3,86,43,0,370,369,1,0,0,0,370,
        371,1,0,0,0,371,372,1,0,0,0,372,373,3,8,4,0,373,57,1,0,0,0,374,375,
        5,7,0,0,375,376,5,87,0,0,376,378,5,54,0,0,377,379,3,118,59,0,378,
        377,1,0,0,0,378,379,1,0,0,0,379,380,1,0,0,0,380,382,5,55,0,0,381,
        383,3,86,43,0,382,381,1,0,0,0,382,383,1,0,0,0,383,384,1,0,0,0,384,
        385,5,57,0,0,385,59,1,0,0,0,386,387,5,6,0,0,387,393,5,87,0,0,388,
        390,5,54,0,0,389,391,3,114,57,0,390,389,1,0,0,0,390,391,1,0,0,0,
        391,392,1,0,0,0,392,394,5,55,0,0,393,388,1,0,0,0,393,394,1,0,0,0,
        394,395,1,0,0,0,395,396,3,114,57,0,396,397,3,8,4,0,397,61,1,0,0,
        0,398,399,3,84,42,0,399,402,7,2,0,0,400,403,3,68,34,0,401,403,3,
        74,37,0,402,400,1,0,0,0,402,401,1,0,0,0,403,404,1,0,0,0,404,405,
        5,57,0,0,405,63,1,0,0,0,406,407,3,68,34,0,407,408,5,57,0,0,408,65,
        1,0,0,0,409,410,5,5,0,0,410,416,5,87,0,0,411,413,5,54,0,0,412,414,
        3,108,54,0,413,412,1,0,0,0,413,414,1,0,0,0,414,415,1,0,0,0,415,417,
        5,55,0,0,416,411,1,0,0,0,416,417,1,0,0,0,417,418,1,0,0,0,418,420,
        3,112,56,0,419,421,3,86,43,0,420,419,1,0,0,0,420,421,1,0,0,0,421,
        422,1,0,0,0,422,426,5,52,0,0,423,425,9,0,0,0,424,423,1,0,0,0,425,
        428,1,0,0,0,426,427,1,0,0,0,426,424,1,0,0,0,427,429,1,0,0,0,428,
        426,1,0,0,0,429,430,5,53,0,0,430,67,1,0,0,0,431,432,6,34,-1,0,432,
        433,5,54,0,0,433,434,3,68,34,0,434,435,5,55,0,0,435,459,1,0,0,0,
        436,437,7,3,0,0,437,459,3,68,34,15,438,441,3,90,45,0,439,441,3,94,
        47,0,440,438,1,0,0,0,440,439,1,0,0,0,441,442,1,0,0,0,442,443,5,54,
        0,0,443,444,3,68,34,0,444,445,5,55,0,0,445,459,1,0,0,0,446,447,5,
        44,0,0,447,448,5,54,0,0,448,449,3,8,4,0,449,450,5,55,0,0,450,459,
        1,0,0,0,451,452,5,87,0,0,452,454,5,54,0,0,453,455,3,110,55,0,454,
        453,1,0,0,0,454,455,1,0,0,0,455,456,1,0,0,0,456,459,5,55,0,0,457,
        459,7,4,0,0,458,431,1,0,0,0,458,436,1,0,0,0,458,440,1,0,0,0,458,
        446,1,0,0,0,458,451,1,0,0,0,458,457,1,0,0,0,459,497,1,0,0,0,460,
        461,10,16,0,0,461,462,5,66,0,0,462,496,3,68,34,16,463,464,10,14,
        0,0,464,465,7,5,0,0,465,496,3,68,34,15,466,467,10,13,0,0,467,468,
        7,6,0,0,468,496,3,68,34,14,469,470,10,12,0,0,470,471,5,80,0,0,471,
        496,3,68,34,13,472,473,10,11,0,0,473,474,5,79,0,0,474,496,3,68,34,
        12,475,476,10,10,0,0,476,477,5,77,0,0,477,496,3,68,34,11,478,479,
        10,9,0,0,479,480,5,71,0,0,480,496,3,68,34,10,481,482,10,8,0,0,482,
        483,5,73,0,0,483,496,3,68,34,9,484,485,10,7,0,0,485,486,5,69,0,0,
        486,496,3,68,34,8,487,488,10,6,0,0,488,489,5,72,0,0,489,496,3,68,
        34,7,490,491,10,5,0,0,491,492,5,70,0,0,492,496,3,68,34,6,493,494,
        10,17,0,0,494,496,3,82,41,0,495,460,1,0,0,0,495,463,1,0,0,0,495,
        466,1,0,0,0,495,469,1,0,0,0,495,472,1,0,0,0,495,475,1,0,0,0,495,
        478,1,0,0,0,495,481,1,0,0,0,495,484,1,0,0,0,495,487,1,0,0,0,495,
        490,1,0,0,0,495,493,1,0,0,0,496,499,1,0,0,0,497,495,1,0,0,0,497,
        498,1,0,0,0,498,69,1,0,0,0,499,497,1,0,0,0,500,505,3,68,34,0,501,
        502,5,63,0,0,502,504,3,68,34,0,503,501,1,0,0,0,504,507,1,0,0,0,505,
        503,1,0,0,0,505,506,1,0,0,0,506,71,1,0,0,0,507,505,1,0,0,0,508,512,
        3,80,40,0,509,512,3,68,34,0,510,512,3,74,37,0,511,508,1,0,0,0,511,
        509,1,0,0,0,511,510,1,0,0,0,512,73,1,0,0,0,513,514,5,47,0,0,514,
        515,3,100,50,0,515,75,1,0,0,0,516,518,3,68,34,0,517,516,1,0,0,0,
        517,518,1,0,0,0,518,519,1,0,0,0,519,521,5,56,0,0,520,522,3,68,34,
        0,521,520,1,0,0,0,521,522,1,0,0,0,522,525,1,0,0,0,523,524,5,56,0,
        0,524,526,3,68,34,0,525,523,1,0,0,0,525,526,1,0,0,0,526,77,1,0,0,
        0,527,528,5,52,0,0,528,533,3,68,34,0,529,530,5,59,0,0,530,532,3,
        68,34,0,531,529,1,0,0,0,532,535,1,0,0,0,533,531,1,0,0,0,533,534,
        1,0,0,0,534,537,1,0,0,0,535,533,1,0,0,0,536,538,5,59,0,0,537,536,
        1,0,0,0,537,538,1,0,0,0,538,539,1,0,0,0,539,540,5,53,0,0,540,79,
        1,0,0,0,541,544,5,52,0,0,542,545,3,68,34,0,543,545,3,80,40,0,544,
        542,1,0,0,0,544,543,1,0,0,0,545,553,1,0,0,0,546,549,5,59,0,0,547,
        550,3,68,34,0,548,550,3,80,40,0,549,547,1,0,0,0,549,548,1,0,0,0,
        550,552,1,0,0,0,551,546,1,0,0,0,552,555,1,0,0,0,553,551,1,0,0,0,
        553,554,1,0,0,0,554,557,1,0,0,0,555,553,1,0,0,0,556,558,5,59,0,0,
        557,556,1,0,0,0,557,558,1,0,0,0,558,559,1,0,0,0,559,560,5,53,0,0,
        560,81,1,0,0,0,561,580,5,50,0,0,562,581,3,78,39,0,563,566,3,68,34,
        0,564,566,3,76,38,0,565,563,1,0,0,0,565,564,1,0,0,0,566,574,1,0,
        0,0,567,570,5,59,0,0,568,571,3,68,34,0,569,571,3,76,38,0,570,568,
        1,0,0,0,570,569,1,0,0,0,571,573,1,0,0,0,572,567,1,0,0,0,573,576,
        1,0,0,0,574,572,1,0,0,0,574,575,1,0,0,0,575,578,1,0,0,0,576,574,
        1,0,0,0,577,579,5,59,0,0,578,577,1,0,0,0,578,579,1,0,0,0,579,581,
        1,0,0,0,580,562,1,0,0,0,580,565,1,0,0,0,581,582,1,0,0,0,582,583,
        5,51,0,0,583,83,1,0,0,0,584,588,5,87,0,0,585,587,3,82,41,0,586,585,
        1,0,0,0,587,590,1,0,0,0,588,586,1,0,0,0,588,589,1,0,0,0,589,85,1,
        0,0,0,590,588,1,0,0,0,591,592,5,61,0,0,592,593,3,90,45,0,593,87,
        1,0,0,0,594,608,5,39,0,0,595,596,5,40,0,0,596,597,5,54,0,0,597,598,
        3,68,34,0,598,599,5,55,0,0,599,608,1,0,0,0,600,605,7,7,0,0,601,602,
        5,54,0,0,602,603,3,68,34,0,603,604,5,55,0,0,604,606,1,0,0,0,605,
        601,1,0,0,0,605,606,1,0,0,0,606,608,1,0,0,0,607,594,1,0,0,0,607,
        595,1,0,0,0,607,600,1,0,0,0,608,609,1,0,0,0,609,610,5,74,0,0,610,
        89,1,0,0,0,611,613,5,29,0,0,612,614,3,98,49,0,613,612,1,0,0,0,613,
        614,1,0,0,0,614,642,1,0,0,0,615,617,5,30,0,0,616,618,3,98,49,0,617,
        616,1,0,0,0,617,618,1,0,0,0,618,642,1,0,0,0,619,621,5,31,0,0,620,
        622,3,98,49,0,621,620,1,0,0,0,621,622,1,0,0,0,622,642,1,0,0,0,623,
        625,5,32,0,0,624,626,3,98,49,0,625,624,1,0,0,0,625,626,1,0,0,0,626,
        642,1,0,0,0,627,629,5,33,0,0,628,630,3,98,49,0,629,628,1,0,0,0,629,
        630,1,0,0,0,630,642,1,0,0,0,631,642,5,28,0,0,632,642,5,36,0,0,633,
        642,5,37,0,0,634,639,5,34,0,0,635,636,5,50,0,0,636,637,3,90,45,0,
        637,638,5,51,0,0,638,640,1,0,0,0,639,635,1,0,0,0,639,640,1,0,0,0,
        640,642,1,0,0,0,641,611,1,0,0,0,641,615,1,0,0,0,641,619,1,0,0,0,
        641,623,1,0,0,0,641,627,1,0,0,0,641,631,1,0,0,0,641,632,1,0,0,0,
        641,633,1,0,0,0,641,634,1,0,0,0,642,91,1,0,0,0,643,645,5,26,0,0,
        644,646,3,98,49,0,645,644,1,0,0,0,645,646,1,0,0,0,646,93,1,0,0,0,
        647,648,5,35,0,0,648,649,5,50,0,0,649,650,3,90,45,0,650,651,5,59,
        0,0,651,652,3,110,55,0,652,653,5,51,0,0,653,95,1,0,0,0,654,655,7,
        8,0,0,655,656,5,35,0,0,656,657,5,50,0,0,657,658,3,90,45,0,658,663,
        5,59,0,0,659,664,3,110,55,0,660,661,5,43,0,0,661,662,5,60,0,0,662,
        664,3,68,34,0,663,659,1,0,0,0,663,660,1,0,0,0,664,665,1,0,0,0,665,
        666,5,51,0,0,666,97,1,0,0,0,667,668,5,50,0,0,668,669,3,68,34,0,669,
        670,5,51,0,0,670,99,1,0,0,0,671,674,3,84,42,0,672,674,5,88,0,0,673,
        671,1,0,0,0,673,672,1,0,0,0,674,101,1,0,0,0,675,682,3,90,45,0,676,
        682,3,96,48,0,677,679,5,27,0,0,678,680,3,98,49,0,679,678,1,0,0,0,
        679,680,1,0,0,0,680,682,1,0,0,0,681,675,1,0,0,0,681,676,1,0,0,0,
        681,677,1,0,0,0,682,103,1,0,0,0,683,684,7,9,0,0,684,105,1,0,0,0,
        685,686,3,90,45,0,686,687,5,87,0,0,687,700,1,0,0,0,688,689,3,92,
        46,0,689,690,5,87,0,0,690,700,1,0,0,0,691,692,7,1,0,0,692,694,5,
        87,0,0,693,695,3,98,49,0,694,693,1,0,0,0,694,695,1,0,0,0,695,700,
        1,0,0,0,696,697,3,96,48,0,697,698,5,87,0,0,698,700,1,0,0,0,699,685,
        1,0,0,0,699,688,1,0,0,0,699,691,1,0,0,0,699,696,1,0,0,0,700,107,
        1,0,0,0,701,706,3,106,53,0,702,703,5,59,0,0,703,705,3,106,53,0,704,
        702,1,0,0,0,705,708,1,0,0,0,706,704,1,0,0,0,706,707,1,0,0,0,707,
        710,1,0,0,0,708,706,1,0,0,0,709,711,5,59,0,0,710,709,1,0,0,0,710,
        711,1,0,0,0,711,109,1,0,0,0,712,717,3,68,34,0,713,714,5,59,0,0,714,
        716,3,68,34,0,715,713,1,0,0,0,716,719,1,0,0,0,717,715,1,0,0,0,717,
        718,1,0,0,0,718,721,1,0,0,0,719,717,1,0,0,0,720,722,5,59,0,0,721,
        720,1,0,0,0,721,722,1,0,0,0,722,111,1,0,0,0,723,728,3,104,52,0,724,
        725,5,59,0,0,725,727,3,104,52,0,726,724,1,0,0,0,727,730,1,0,0,0,
        728,726,1,0,0,0,728,729,1,0,0,0,729,732,1,0,0,0,730,728,1,0,0,0,
        731,733,5,59,0,0,732,731,1,0,0,0,732,733,1,0,0,0,733,113,1,0,0,0,
        734,739,5,87,0,0,735,736,5,59,0,0,736,738,5,87,0,0,737,735,1,0,0,
        0,738,741,1,0,0,0,739,737,1,0,0,0,739,740,1,0,0,0,740,743,1,0,0,
        0,741,739,1,0,0,0,742,744,5,59,0,0,743,742,1,0,0,0,743,744,1,0,0,
        0,744,115,1,0,0,0,745,750,3,100,50,0,746,747,5,59,0,0,747,749,3,
        100,50,0,748,746,1,0,0,0,749,752,1,0,0,0,750,748,1,0,0,0,750,751,
        1,0,0,0,751,754,1,0,0,0,752,750,1,0,0,0,753,755,5,59,0,0,754,753,
        1,0,0,0,754,755,1,0,0,0,755,117,1,0,0,0,756,761,3,102,51,0,757,758,
        5,59,0,0,758,760,3,102,51,0,759,757,1,0,0,0,760,763,1,0,0,0,761,
        759,1,0,0,0,761,762,1,0,0,0,762,765,1,0,0,0,763,761,1,0,0,0,764,
        766,5,59,0,0,765,764,1,0,0,0,765,766,1,0,0,0,766,119,1,0,0,0,90,
        121,126,139,169,171,175,181,191,220,231,236,248,254,261,268,274,
        277,280,288,294,297,300,303,306,311,327,332,346,354,366,370,378,
        382,390,393,402,413,416,420,426,440,454,458,495,497,505,511,517,
        521,525,533,537,544,549,553,557,565,570,574,578,580,588,605,607,
        613,617,621,625,629,639,641,645,663,673,679,681,694,699,706,710,
        717,721,728,732,739,743,750,754,761,765
    ]

class qasm3Parser ( Parser ):

    grammarFileName = "qasm3Parser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'OPENQASM'", "'include'", "'defcalgrammar'", 
                     "'def'", "'defcal'", "'gate'", "'extern'", "'box'", 
                     "'let'", "'break'", "'continue'", "'if'", "'else'", 
                     "'end'", "'return'", "'for'", "'while'", "'in'", "<INVALID>", 
                     "<INVALID>", "'input'", "'output'", "'const'", "'mutable'", 
                     "'qreg'", "'qubit'", "'creg'", "'bool'", "'bit'", "'int'", 
                     "'uint'", "'float'", "'angle'", "'complex'", "'array'", 
                     "'duration'", "'stretch'", "'gphase'", "'inv'", "'pow'", 
                     "'ctrl'", "'negctrl'", "'#dim'", "'durationof'", "'delay'", 
                     "'reset'", "'measure'", "'barrier'", "<INVALID>", "'['", 
                     "']'", "'{'", "'}'", "'('", "')'", "':'", "';'", "'.'", 
                     "','", "'='", "'->'", "'+'", "'++'", "'-'", "'*'", 
                     "'**'", "'/'", "'%'", "'|'", "'||'", "'&'", "'&&'", 
                     "'^'", "'@'", "'~'", "'!'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'im'" ]

    symbolicNames = [ "<INVALID>", "OPENQASM", "INCLUDE", "DEFCALGRAMMAR", 
                      "DEF", "DEFCAL", "GATE", "EXTERN", "BOX", "LET", "BREAK", 
                      "CONTINUE", "IF", "ELSE", "END", "RETURN", "FOR", 
                      "WHILE", "IN", "PRAGMA", "AnnotationKeyword", "INPUT", 
                      "OUTPUT", "CONST", "MUTABLE", "QREG", "QUBIT", "CREG", 
                      "BOOL", "BIT", "INT", "UINT", "FLOAT", "ANGLE", "COMPLEX", 
                      "ARRAY", "DURATION", "STRETCH", "GPHASE", "INV", "POW", 
                      "CTRL", "NEGCTRL", "DIM", "DURATIONOF", "DELAY", "RESET", 
                      "MEASURE", "BARRIER", "BooleanLiteral", "LBRACKET", 
                      "RBRACKET", "LBRACE", "RBRACE", "LPAREN", "RPAREN", 
                      "COLON", "SEMICOLON", "DOT", "COMMA", "EQUALS", "ARROW", 
                      "PLUS", "DOUBLE_PLUS", "MINUS", "ASTERISK", "DOUBLE_ASTERISK", 
                      "SLASH", "PERCENT", "PIPE", "DOUBLE_PIPE", "AMPERSAND", 
                      "DOUBLE_AMPERSAND", "CARET", "AT", "TILDE", "EXCLAMATION_POINT", 
                      "EqualityOperator", "CompoundAssignmentOperator", 
                      "ComparisonOperator", "BitshiftOperator", "IMAG", 
                      "ImaginaryLiteral", "BinaryIntegerLiteral", "OctalIntegerLiteral", 
                      "DecimalIntegerLiteral", "HexIntegerLiteral", "Identifier", 
                      "HardwareQubit", "FloatLiteral", "TimingLiteral", 
                      "BitstringLiteral", "StringLiteral", "Whitespace", 
                      "Newline", "LineComment", "BlockComment", "VERSION_IDENTIFER_WHITESPACE", 
                      "VersionSpecifier", "EAT_INITIAL_SPACE", "EAT_LINE_END", 
                      "RemainingLineContent" ]

    RULE_program = 0
    RULE_version = 1
    RULE_statement = 2
    RULE_annotation = 3
    RULE_scope = 4
    RULE_pragma = 5
    RULE_statementOrScope = 6
    RULE_calibrationGrammarStatement = 7
    RULE_includeStatement = 8
    RULE_breakStatement = 9
    RULE_continueStatement = 10
    RULE_endStatement = 11
    RULE_forStatement = 12
    RULE_ifStatement = 13
    RULE_returnStatement = 14
    RULE_whileStatement = 15
    RULE_barrierStatement = 16
    RULE_boxStatement = 17
    RULE_delayStatement = 18
    RULE_gateCallStatement = 19
    RULE_measureArrowAssignmentStatement = 20
    RULE_resetStatement = 21
    RULE_aliasDeclarationStatement = 22
    RULE_classicalDeclarationStatement = 23
    RULE_constDeclarationStatement = 24
    RULE_ioDeclarationStatement = 25
    RULE_oldStyleDeclarationStatement = 26
    RULE_quantumDeclarationStatement = 27
    RULE_defStatement = 28
    RULE_externStatement = 29
    RULE_gateStatement = 30
    RULE_assignmentStatement = 31
    RULE_expressionStatement = 32
    RULE_defcalStatement = 33
    RULE_expression = 34
    RULE_aliasExpression = 35
    RULE_declarationExpression = 36
    RULE_measureExpression = 37
    RULE_rangeExpression = 38
    RULE_setExpression = 39
    RULE_arrayLiteral = 40
    RULE_indexOperator = 41
    RULE_indexedIdentifier = 42
    RULE_returnSignature = 43
    RULE_gateModifier = 44
    RULE_scalarType = 45
    RULE_qubitType = 46
    RULE_arrayType = 47
    RULE_arrayReferenceType = 48
    RULE_designator = 49
    RULE_gateOperand = 50
    RULE_externArgument = 51
    RULE_defcalArgument = 52
    RULE_argumentDefinition = 53
    RULE_argumentDefinitionList = 54
    RULE_expressionList = 55
    RULE_defcalArgumentList = 56
    RULE_identifierList = 57
    RULE_gateOperandList = 58
    RULE_externArgumentList = 59

    ruleNames =  [ "program", "version", "statement", "annotation", "scope", 
                   "pragma", "statementOrScope", "calibrationGrammarStatement", 
                   "includeStatement", "breakStatement", "continueStatement", 
                   "endStatement", "forStatement", "ifStatement", "returnStatement", 
                   "whileStatement", "barrierStatement", "boxStatement", 
                   "delayStatement", "gateCallStatement", "measureArrowAssignmentStatement", 
                   "resetStatement", "aliasDeclarationStatement", "classicalDeclarationStatement", 
                   "constDeclarationStatement", "ioDeclarationStatement", 
                   "oldStyleDeclarationStatement", "quantumDeclarationStatement", 
                   "defStatement", "externStatement", "gateStatement", "assignmentStatement", 
                   "expressionStatement", "defcalStatement", "expression", 
                   "aliasExpression", "declarationExpression", "measureExpression", 
                   "rangeExpression", "setExpression", "arrayLiteral", "indexOperator", 
                   "indexedIdentifier", "returnSignature", "gateModifier", 
                   "scalarType", "qubitType", "arrayType", "arrayReferenceType", 
                   "designator", "gateOperand", "externArgument", "defcalArgument", 
                   "argumentDefinition", "argumentDefinitionList", "expressionList", 
                   "defcalArgumentList", "identifierList", "gateOperandList", 
                   "externArgumentList" ]

    EOF = Token.EOF
    OPENQASM=1
    INCLUDE=2
    DEFCALGRAMMAR=3
    DEF=4
    DEFCAL=5
    GATE=6
    EXTERN=7
    BOX=8
    LET=9
    BREAK=10
    CONTINUE=11
    IF=12
    ELSE=13
    END=14
    RETURN=15
    FOR=16
    WHILE=17
    IN=18
    PRAGMA=19
    AnnotationKeyword=20
    INPUT=21
    OUTPUT=22
    CONST=23
    MUTABLE=24
    QREG=25
    QUBIT=26
    CREG=27
    BOOL=28
    BIT=29
    INT=30
    UINT=31
    FLOAT=32
    ANGLE=33
    COMPLEX=34
    ARRAY=35
    DURATION=36
    STRETCH=37
    GPHASE=38
    INV=39
    POW=40
    CTRL=41
    NEGCTRL=42
    DIM=43
    DURATIONOF=44
    DELAY=45
    RESET=46
    MEASURE=47
    BARRIER=48
    BooleanLiteral=49
    LBRACKET=50
    RBRACKET=51
    LBRACE=52
    RBRACE=53
    LPAREN=54
    RPAREN=55
    COLON=56
    SEMICOLON=57
    DOT=58
    COMMA=59
    EQUALS=60
    ARROW=61
    PLUS=62
    DOUBLE_PLUS=63
    MINUS=64
    ASTERISK=65
    DOUBLE_ASTERISK=66
    SLASH=67
    PERCENT=68
    PIPE=69
    DOUBLE_PIPE=70
    AMPERSAND=71
    DOUBLE_AMPERSAND=72
    CARET=73
    AT=74
    TILDE=75
    EXCLAMATION_POINT=76
    EqualityOperator=77
    CompoundAssignmentOperator=78
    ComparisonOperator=79
    BitshiftOperator=80
    IMAG=81
    ImaginaryLiteral=82
    BinaryIntegerLiteral=83
    OctalIntegerLiteral=84
    DecimalIntegerLiteral=85
    HexIntegerLiteral=86
    Identifier=87
    HardwareQubit=88
    FloatLiteral=89
    TimingLiteral=90
    BitstringLiteral=91
    StringLiteral=92
    Whitespace=93
    Newline=94
    LineComment=95
    BlockComment=96
    VERSION_IDENTIFER_WHITESPACE=97
    VersionSpecifier=98
    EAT_INITIAL_SPACE=99
    EAT_LINE_END=100
    RemainingLineContent=101

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(qasm3Parser.EOF, 0)

        def version(self):
            return self.getTypedRuleContext(qasm3Parser.VersionContext,0)


        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.StatementContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.StatementContext,i)


        def getRuleIndex(self):
            return qasm3Parser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = qasm3Parser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 121
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 120
                self.version()


            self.state = 126
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 19131502306254844) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 268179457) != 0):
                self.state = 123
                self.statement()
                self.state = 128
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 129
            self.match(qasm3Parser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VersionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPENQASM(self):
            return self.getToken(qasm3Parser.OPENQASM, 0)

        def VersionSpecifier(self):
            return self.getToken(qasm3Parser.VersionSpecifier, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_version

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVersion" ):
                listener.enterVersion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVersion" ):
                listener.exitVersion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVersion" ):
                return visitor.visitVersion(self)
            else:
                return visitor.visitChildren(self)




    def version(self):

        localctx = qasm3Parser.VersionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_version)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 131
            self.match(qasm3Parser.OPENQASM)
            self.state = 132
            self.match(qasm3Parser.VersionSpecifier)
            self.state = 133
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def pragma(self):
            return self.getTypedRuleContext(qasm3Parser.PragmaContext,0)


        def aliasDeclarationStatement(self):
            return self.getTypedRuleContext(qasm3Parser.AliasDeclarationStatementContext,0)


        def assignmentStatement(self):
            return self.getTypedRuleContext(qasm3Parser.AssignmentStatementContext,0)


        def barrierStatement(self):
            return self.getTypedRuleContext(qasm3Parser.BarrierStatementContext,0)


        def boxStatement(self):
            return self.getTypedRuleContext(qasm3Parser.BoxStatementContext,0)


        def breakStatement(self):
            return self.getTypedRuleContext(qasm3Parser.BreakStatementContext,0)


        def calibrationGrammarStatement(self):
            return self.getTypedRuleContext(qasm3Parser.CalibrationGrammarStatementContext,0)


        def classicalDeclarationStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ClassicalDeclarationStatementContext,0)


        def constDeclarationStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ConstDeclarationStatementContext,0)


        def continueStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ContinueStatementContext,0)


        def defStatement(self):
            return self.getTypedRuleContext(qasm3Parser.DefStatementContext,0)


        def defcalStatement(self):
            return self.getTypedRuleContext(qasm3Parser.DefcalStatementContext,0)


        def delayStatement(self):
            return self.getTypedRuleContext(qasm3Parser.DelayStatementContext,0)


        def endStatement(self):
            return self.getTypedRuleContext(qasm3Parser.EndStatementContext,0)


        def expressionStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionStatementContext,0)


        def externStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ExternStatementContext,0)


        def forStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ForStatementContext,0)


        def gateCallStatement(self):
            return self.getTypedRuleContext(qasm3Parser.GateCallStatementContext,0)


        def gateStatement(self):
            return self.getTypedRuleContext(qasm3Parser.GateStatementContext,0)


        def ifStatement(self):
            return self.getTypedRuleContext(qasm3Parser.IfStatementContext,0)


        def includeStatement(self):
            return self.getTypedRuleContext(qasm3Parser.IncludeStatementContext,0)


        def ioDeclarationStatement(self):
            return self.getTypedRuleContext(qasm3Parser.IoDeclarationStatementContext,0)


        def measureArrowAssignmentStatement(self):
            return self.getTypedRuleContext(qasm3Parser.MeasureArrowAssignmentStatementContext,0)


        def oldStyleDeclarationStatement(self):
            return self.getTypedRuleContext(qasm3Parser.OldStyleDeclarationStatementContext,0)


        def quantumDeclarationStatement(self):
            return self.getTypedRuleContext(qasm3Parser.QuantumDeclarationStatementContext,0)


        def resetStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ResetStatementContext,0)


        def returnStatement(self):
            return self.getTypedRuleContext(qasm3Parser.ReturnStatementContext,0)


        def whileStatement(self):
            return self.getTypedRuleContext(qasm3Parser.WhileStatementContext,0)


        def annotation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.AnnotationContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.AnnotationContext,i)


        def getRuleIndex(self):
            return qasm3Parser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = qasm3Parser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_statement)
        self._la = 0 # Token type
        try:
            self.state = 171
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19]:
                self.enterOuterAlt(localctx, 1)
                self.state = 135
                self.pragma()
                pass
            elif token in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 20, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.enterOuterAlt(localctx, 2)
                self.state = 139
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==20:
                    self.state = 136
                    self.annotation()
                    self.state = 141
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 169
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                if la_ == 1:
                    self.state = 142
                    self.aliasDeclarationStatement()
                    pass

                elif la_ == 2:
                    self.state = 143
                    self.assignmentStatement()
                    pass

                elif la_ == 3:
                    self.state = 144
                    self.barrierStatement()
                    pass

                elif la_ == 4:
                    self.state = 145
                    self.boxStatement()
                    pass

                elif la_ == 5:
                    self.state = 146
                    self.breakStatement()
                    pass

                elif la_ == 6:
                    self.state = 147
                    self.calibrationGrammarStatement()
                    pass

                elif la_ == 7:
                    self.state = 148
                    self.classicalDeclarationStatement()
                    pass

                elif la_ == 8:
                    self.state = 149
                    self.constDeclarationStatement()
                    pass

                elif la_ == 9:
                    self.state = 150
                    self.continueStatement()
                    pass

                elif la_ == 10:
                    self.state = 151
                    self.defStatement()
                    pass

                elif la_ == 11:
                    self.state = 152
                    self.defcalStatement()
                    pass

                elif la_ == 12:
                    self.state = 153
                    self.delayStatement()
                    pass

                elif la_ == 13:
                    self.state = 154
                    self.endStatement()
                    pass

                elif la_ == 14:
                    self.state = 155
                    self.expressionStatement()
                    pass

                elif la_ == 15:
                    self.state = 156
                    self.externStatement()
                    pass

                elif la_ == 16:
                    self.state = 157
                    self.forStatement()
                    pass

                elif la_ == 17:
                    self.state = 158
                    self.gateCallStatement()
                    pass

                elif la_ == 18:
                    self.state = 159
                    self.gateStatement()
                    pass

                elif la_ == 19:
                    self.state = 160
                    self.ifStatement()
                    pass

                elif la_ == 20:
                    self.state = 161
                    self.includeStatement()
                    pass

                elif la_ == 21:
                    self.state = 162
                    self.ioDeclarationStatement()
                    pass

                elif la_ == 22:
                    self.state = 163
                    self.measureArrowAssignmentStatement()
                    pass

                elif la_ == 23:
                    self.state = 164
                    self.oldStyleDeclarationStatement()
                    pass

                elif la_ == 24:
                    self.state = 165
                    self.quantumDeclarationStatement()
                    pass

                elif la_ == 25:
                    self.state = 166
                    self.resetStatement()
                    pass

                elif la_ == 26:
                    self.state = 167
                    self.returnStatement()
                    pass

                elif la_ == 27:
                    self.state = 168
                    self.whileStatement()
                    pass


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AnnotationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AnnotationKeyword(self):
            return self.getToken(qasm3Parser.AnnotationKeyword, 0)

        def RemainingLineContent(self):
            return self.getToken(qasm3Parser.RemainingLineContent, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_annotation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnnotation" ):
                listener.enterAnnotation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnnotation" ):
                listener.exitAnnotation(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAnnotation" ):
                return visitor.visitAnnotation(self)
            else:
                return visitor.visitChildren(self)




    def annotation(self):

        localctx = qasm3Parser.AnnotationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_annotation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(qasm3Parser.AnnotationKeyword)
            self.state = 175
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==101:
                self.state = 174
                self.match(qasm3Parser.RemainingLineContent)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ScopeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(qasm3Parser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(qasm3Parser.RBRACE, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.StatementContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.StatementContext,i)


        def getRuleIndex(self):
            return qasm3Parser.RULE_scope

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScope" ):
                listener.enterScope(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScope" ):
                listener.exitScope(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScope" ):
                return visitor.visitScope(self)
            else:
                return visitor.visitChildren(self)




    def scope(self):

        localctx = qasm3Parser.ScopeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_scope)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(qasm3Parser.LBRACE)
            self.state = 181
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 19131502306254844) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 268179457) != 0):
                self.state = 178
                self.statement()
                self.state = 183
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 184
            self.match(qasm3Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PragmaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRAGMA(self):
            return self.getToken(qasm3Parser.PRAGMA, 0)

        def RemainingLineContent(self):
            return self.getToken(qasm3Parser.RemainingLineContent, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_pragma

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPragma" ):
                listener.enterPragma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPragma" ):
                listener.exitPragma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPragma" ):
                return visitor.visitPragma(self)
            else:
                return visitor.visitChildren(self)




    def pragma(self):

        localctx = qasm3Parser.PragmaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_pragma)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.match(qasm3Parser.PRAGMA)
            self.state = 187
            self.match(qasm3Parser.RemainingLineContent)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementOrScopeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self):
            return self.getTypedRuleContext(qasm3Parser.StatementContext,0)


        def scope(self):
            return self.getTypedRuleContext(qasm3Parser.ScopeContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_statementOrScope

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatementOrScope" ):
                listener.enterStatementOrScope(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatementOrScope" ):
                listener.exitStatementOrScope(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatementOrScope" ):
                return visitor.visitStatementOrScope(self)
            else:
                return visitor.visitChildren(self)




    def statementOrScope(self):

        localctx = qasm3Parser.StatementOrScopeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_statementOrScope)
        try:
            self.state = 191
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.enterOuterAlt(localctx, 1)
                self.state = 189
                self.statement()
                pass
            elif token in [52]:
                self.enterOuterAlt(localctx, 2)
                self.state = 190
                self.scope()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CalibrationGrammarStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEFCALGRAMMAR(self):
            return self.getToken(qasm3Parser.DEFCALGRAMMAR, 0)

        def StringLiteral(self):
            return self.getToken(qasm3Parser.StringLiteral, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_calibrationGrammarStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCalibrationGrammarStatement" ):
                listener.enterCalibrationGrammarStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCalibrationGrammarStatement" ):
                listener.exitCalibrationGrammarStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCalibrationGrammarStatement" ):
                return visitor.visitCalibrationGrammarStatement(self)
            else:
                return visitor.visitChildren(self)




    def calibrationGrammarStatement(self):

        localctx = qasm3Parser.CalibrationGrammarStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_calibrationGrammarStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 193
            self.match(qasm3Parser.DEFCALGRAMMAR)
            self.state = 194
            self.match(qasm3Parser.StringLiteral)
            self.state = 195
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncludeStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INCLUDE(self):
            return self.getToken(qasm3Parser.INCLUDE, 0)

        def StringLiteral(self):
            return self.getToken(qasm3Parser.StringLiteral, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_includeStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIncludeStatement" ):
                listener.enterIncludeStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIncludeStatement" ):
                listener.exitIncludeStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIncludeStatement" ):
                return visitor.visitIncludeStatement(self)
            else:
                return visitor.visitChildren(self)




    def includeStatement(self):

        localctx = qasm3Parser.IncludeStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_includeStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            self.match(qasm3Parser.INCLUDE)
            self.state = 198
            self.match(qasm3Parser.StringLiteral)
            self.state = 199
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BreakStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BREAK(self):
            return self.getToken(qasm3Parser.BREAK, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_breakStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBreakStatement" ):
                listener.enterBreakStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBreakStatement" ):
                listener.exitBreakStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBreakStatement" ):
                return visitor.visitBreakStatement(self)
            else:
                return visitor.visitChildren(self)




    def breakStatement(self):

        localctx = qasm3Parser.BreakStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_breakStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 201
            self.match(qasm3Parser.BREAK)
            self.state = 202
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ContinueStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONTINUE(self):
            return self.getToken(qasm3Parser.CONTINUE, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_continueStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterContinueStatement" ):
                listener.enterContinueStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitContinueStatement" ):
                listener.exitContinueStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitContinueStatement" ):
                return visitor.visitContinueStatement(self)
            else:
                return visitor.visitChildren(self)




    def continueStatement(self):

        localctx = qasm3Parser.ContinueStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_continueStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 204
            self.match(qasm3Parser.CONTINUE)
            self.state = 205
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EndStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def END(self):
            return self.getToken(qasm3Parser.END, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_endStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEndStatement" ):
                listener.enterEndStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEndStatement" ):
                listener.exitEndStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEndStatement" ):
                return visitor.visitEndStatement(self)
            else:
                return visitor.visitChildren(self)




    def endStatement(self):

        localctx = qasm3Parser.EndStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_endStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            self.match(qasm3Parser.END)
            self.state = 208
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ForStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.body = None # StatementOrScopeContext

        def FOR(self):
            return self.getToken(qasm3Parser.FOR, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.Identifier)
            else:
                return self.getToken(qasm3Parser.Identifier, i)

        def IN(self):
            return self.getToken(qasm3Parser.IN, 0)

        def statementOrScope(self):
            return self.getTypedRuleContext(qasm3Parser.StatementOrScopeContext,0)


        def setExpression(self):
            return self.getTypedRuleContext(qasm3Parser.SetExpressionContext,0)


        def LBRACKET(self):
            return self.getToken(qasm3Parser.LBRACKET, 0)

        def rangeExpression(self):
            return self.getTypedRuleContext(qasm3Parser.RangeExpressionContext,0)


        def RBRACKET(self):
            return self.getToken(qasm3Parser.RBRACKET, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_forStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStatement" ):
                listener.enterForStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStatement" ):
                listener.exitForStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForStatement" ):
                return visitor.visitForStatement(self)
            else:
                return visitor.visitChildren(self)




    def forStatement(self):

        localctx = qasm3Parser.ForStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_forStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self.match(qasm3Parser.FOR)
            self.state = 211
            self.scalarType()
            self.state = 212
            self.match(qasm3Parser.Identifier)
            self.state = 213
            self.match(qasm3Parser.IN)
            self.state = 220
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [52]:
                self.state = 214
                self.setExpression()
                pass
            elif token in [50]:
                self.state = 215
                self.match(qasm3Parser.LBRACKET)
                self.state = 216
                self.rangeExpression()
                self.state = 217
                self.match(qasm3Parser.RBRACKET)
                pass
            elif token in [87]:
                self.state = 219
                self.match(qasm3Parser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 222
            localctx.body = self.statementOrScope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.if_body = None # StatementOrScopeContext
            self.else_body = None # StatementOrScopeContext

        def IF(self):
            return self.getToken(qasm3Parser.IF, 0)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def statementOrScope(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.StatementOrScopeContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.StatementOrScopeContext,i)


        def ELSE(self):
            return self.getToken(qasm3Parser.ELSE, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_ifStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStatement" ):
                listener.enterIfStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStatement" ):
                listener.exitIfStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfStatement" ):
                return visitor.visitIfStatement(self)
            else:
                return visitor.visitChildren(self)




    def ifStatement(self):

        localctx = qasm3Parser.IfStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_ifStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 224
            self.match(qasm3Parser.IF)
            self.state = 225
            self.match(qasm3Parser.LPAREN)
            self.state = 226
            self.expression(0)
            self.state = 227
            self.match(qasm3Parser.RPAREN)
            self.state = 228
            localctx.if_body = self.statementOrScope()
            self.state = 231
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 229
                self.match(qasm3Parser.ELSE)
                self.state = 230
                localctx.else_body = self.statementOrScope()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(qasm3Parser.RETURN, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def measureExpression(self):
            return self.getTypedRuleContext(qasm3Parser.MeasureExpressionContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_returnStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturnStatement" ):
                listener.enterReturnStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturnStatement" ):
                listener.exitReturnStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturnStatement" ):
                return visitor.visitReturnStatement(self)
            else:
                return visitor.visitChildren(self)




    def returnStatement(self):

        localctx = qasm3Parser.ReturnStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_returnStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            self.match(qasm3Parser.RETURN)
            self.state = 236
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.state = 234
                self.expression(0)
                pass
            elif token in [47]:
                self.state = 235
                self.measureExpression()
                pass
            elif token in [57]:
                pass
            else:
                pass
            self.state = 238
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.body = None # StatementOrScopeContext

        def WHILE(self):
            return self.getToken(qasm3Parser.WHILE, 0)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def statementOrScope(self):
            return self.getTypedRuleContext(qasm3Parser.StatementOrScopeContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_whileStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStatement" ):
                listener.enterWhileStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStatement" ):
                listener.exitWhileStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileStatement" ):
                return visitor.visitWhileStatement(self)
            else:
                return visitor.visitChildren(self)




    def whileStatement(self):

        localctx = qasm3Parser.WhileStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_whileStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 240
            self.match(qasm3Parser.WHILE)
            self.state = 241
            self.match(qasm3Parser.LPAREN)
            self.state = 242
            self.expression(0)
            self.state = 243
            self.match(qasm3Parser.RPAREN)
            self.state = 244
            localctx.body = self.statementOrScope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BarrierStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BARRIER(self):
            return self.getToken(qasm3Parser.BARRIER, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def gateOperandList(self):
            return self.getTypedRuleContext(qasm3Parser.GateOperandListContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_barrierStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBarrierStatement" ):
                listener.enterBarrierStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBarrierStatement" ):
                listener.exitBarrierStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBarrierStatement" ):
                return visitor.visitBarrierStatement(self)
            else:
                return visitor.visitChildren(self)




    def barrierStatement(self):

        localctx = qasm3Parser.BarrierStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_barrierStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 246
            self.match(qasm3Parser.BARRIER)
            self.state = 248
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==87 or _la==88:
                self.state = 247
                self.gateOperandList()


            self.state = 250
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BoxStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOX(self):
            return self.getToken(qasm3Parser.BOX, 0)

        def scope(self):
            return self.getTypedRuleContext(qasm3Parser.ScopeContext,0)


        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_boxStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoxStatement" ):
                listener.enterBoxStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoxStatement" ):
                listener.exitBoxStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoxStatement" ):
                return visitor.visitBoxStatement(self)
            else:
                return visitor.visitChildren(self)




    def boxStatement(self):

        localctx = qasm3Parser.BoxStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_boxStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 252
            self.match(qasm3Parser.BOX)
            self.state = 254
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==50:
                self.state = 253
                self.designator()


            self.state = 256
            self.scope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DelayStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DELAY(self):
            return self.getToken(qasm3Parser.DELAY, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def gateOperandList(self):
            return self.getTypedRuleContext(qasm3Parser.GateOperandListContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_delayStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDelayStatement" ):
                listener.enterDelayStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDelayStatement" ):
                listener.exitDelayStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDelayStatement" ):
                return visitor.visitDelayStatement(self)
            else:
                return visitor.visitChildren(self)




    def delayStatement(self):

        localctx = qasm3Parser.DelayStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_delayStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 258
            self.match(qasm3Parser.DELAY)
            self.state = 259
            self.designator()
            self.state = 261
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==87 or _la==88:
                self.state = 260
                self.gateOperandList()


            self.state = 263
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GateCallStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def gateOperandList(self):
            return self.getTypedRuleContext(qasm3Parser.GateOperandListContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def gateModifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.GateModifierContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.GateModifierContext,i)


        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def expressionList(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionListContext,0)


        def GPHASE(self):
            return self.getToken(qasm3Parser.GPHASE, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_gateCallStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGateCallStatement" ):
                listener.enterGateCallStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGateCallStatement" ):
                listener.exitGateCallStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGateCallStatement" ):
                return visitor.visitGateCallStatement(self)
            else:
                return visitor.visitChildren(self)




    def gateCallStatement(self):

        localctx = qasm3Parser.GateCallStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_gateCallStatement)
        self._la = 0 # Token type
        try:
            self.state = 306
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 268
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8246337208320) != 0):
                    self.state = 265
                    self.gateModifier()
                    self.state = 270
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 271
                self.match(qasm3Parser.Identifier)
                self.state = 277
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==54:
                    self.state = 272
                    self.match(qasm3Parser.LPAREN)
                    self.state = 274
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if ((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & -17592117255666689) != 0):
                        self.state = 273
                        self.expressionList()


                    self.state = 276
                    self.match(qasm3Parser.RPAREN)


                self.state = 280
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 279
                    self.designator()


                self.state = 282
                self.gateOperandList()
                self.state = 283
                self.match(qasm3Parser.SEMICOLON)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 288
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8246337208320) != 0):
                    self.state = 285
                    self.gateModifier()
                    self.state = 290
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 291
                self.match(qasm3Parser.GPHASE)
                self.state = 297
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==54:
                    self.state = 292
                    self.match(qasm3Parser.LPAREN)
                    self.state = 294
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if ((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & -17592117255666689) != 0):
                        self.state = 293
                        self.expressionList()


                    self.state = 296
                    self.match(qasm3Parser.RPAREN)


                self.state = 300
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 299
                    self.designator()


                self.state = 303
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==87 or _la==88:
                    self.state = 302
                    self.gateOperandList()


                self.state = 305
                self.match(qasm3Parser.SEMICOLON)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MeasureArrowAssignmentStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def measureExpression(self):
            return self.getTypedRuleContext(qasm3Parser.MeasureExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def ARROW(self):
            return self.getToken(qasm3Parser.ARROW, 0)

        def indexedIdentifier(self):
            return self.getTypedRuleContext(qasm3Parser.IndexedIdentifierContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_measureArrowAssignmentStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMeasureArrowAssignmentStatement" ):
                listener.enterMeasureArrowAssignmentStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMeasureArrowAssignmentStatement" ):
                listener.exitMeasureArrowAssignmentStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMeasureArrowAssignmentStatement" ):
                return visitor.visitMeasureArrowAssignmentStatement(self)
            else:
                return visitor.visitChildren(self)




    def measureArrowAssignmentStatement(self):

        localctx = qasm3Parser.MeasureArrowAssignmentStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_measureArrowAssignmentStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 308
            self.measureExpression()
            self.state = 311
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 309
                self.match(qasm3Parser.ARROW)
                self.state = 310
                self.indexedIdentifier()


            self.state = 313
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ResetStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RESET(self):
            return self.getToken(qasm3Parser.RESET, 0)

        def gateOperand(self):
            return self.getTypedRuleContext(qasm3Parser.GateOperandContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_resetStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterResetStatement" ):
                listener.enterResetStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitResetStatement" ):
                listener.exitResetStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitResetStatement" ):
                return visitor.visitResetStatement(self)
            else:
                return visitor.visitChildren(self)




    def resetStatement(self):

        localctx = qasm3Parser.ResetStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_resetStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 315
            self.match(qasm3Parser.RESET)
            self.state = 316
            self.gateOperand()
            self.state = 317
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AliasDeclarationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LET(self):
            return self.getToken(qasm3Parser.LET, 0)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def EQUALS(self):
            return self.getToken(qasm3Parser.EQUALS, 0)

        def aliasExpression(self):
            return self.getTypedRuleContext(qasm3Parser.AliasExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_aliasDeclarationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAliasDeclarationStatement" ):
                listener.enterAliasDeclarationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAliasDeclarationStatement" ):
                listener.exitAliasDeclarationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAliasDeclarationStatement" ):
                return visitor.visitAliasDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)




    def aliasDeclarationStatement(self):

        localctx = qasm3Parser.AliasDeclarationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_aliasDeclarationStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 319
            self.match(qasm3Parser.LET)
            self.state = 320
            self.match(qasm3Parser.Identifier)
            self.state = 321
            self.match(qasm3Parser.EQUALS)
            self.state = 322
            self.aliasExpression()
            self.state = 323
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassicalDeclarationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def arrayType(self):
            return self.getTypedRuleContext(qasm3Parser.ArrayTypeContext,0)


        def EQUALS(self):
            return self.getToken(qasm3Parser.EQUALS, 0)

        def declarationExpression(self):
            return self.getTypedRuleContext(qasm3Parser.DeclarationExpressionContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_classicalDeclarationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClassicalDeclarationStatement" ):
                listener.enterClassicalDeclarationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClassicalDeclarationStatement" ):
                listener.exitClassicalDeclarationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClassicalDeclarationStatement" ):
                return visitor.visitClassicalDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)




    def classicalDeclarationStatement(self):

        localctx = qasm3Parser.ClassicalDeclarationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_classicalDeclarationStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 327
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 36, 37]:
                self.state = 325
                self.scalarType()
                pass
            elif token in [35]:
                self.state = 326
                self.arrayType()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 329
            self.match(qasm3Parser.Identifier)
            self.state = 332
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==60:
                self.state = 330
                self.match(qasm3Parser.EQUALS)
                self.state = 331
                self.declarationExpression()


            self.state = 334
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstDeclarationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONST(self):
            return self.getToken(qasm3Parser.CONST, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def EQUALS(self):
            return self.getToken(qasm3Parser.EQUALS, 0)

        def declarationExpression(self):
            return self.getTypedRuleContext(qasm3Parser.DeclarationExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_constDeclarationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstDeclarationStatement" ):
                listener.enterConstDeclarationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstDeclarationStatement" ):
                listener.exitConstDeclarationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstDeclarationStatement" ):
                return visitor.visitConstDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)




    def constDeclarationStatement(self):

        localctx = qasm3Parser.ConstDeclarationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_constDeclarationStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 336
            self.match(qasm3Parser.CONST)
            self.state = 337
            self.scalarType()
            self.state = 338
            self.match(qasm3Parser.Identifier)
            self.state = 339
            self.match(qasm3Parser.EQUALS)
            self.state = 340
            self.declarationExpression()
            self.state = 341
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IoDeclarationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def INPUT(self):
            return self.getToken(qasm3Parser.INPUT, 0)

        def OUTPUT(self):
            return self.getToken(qasm3Parser.OUTPUT, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def arrayType(self):
            return self.getTypedRuleContext(qasm3Parser.ArrayTypeContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_ioDeclarationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIoDeclarationStatement" ):
                listener.enterIoDeclarationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIoDeclarationStatement" ):
                listener.exitIoDeclarationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIoDeclarationStatement" ):
                return visitor.visitIoDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)




    def ioDeclarationStatement(self):

        localctx = qasm3Parser.IoDeclarationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_ioDeclarationStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 343
            _la = self._input.LA(1)
            if not(_la==21 or _la==22):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 346
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 36, 37]:
                self.state = 344
                self.scalarType()
                pass
            elif token in [35]:
                self.state = 345
                self.arrayType()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 348
            self.match(qasm3Parser.Identifier)
            self.state = 349
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OldStyleDeclarationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def CREG(self):
            return self.getToken(qasm3Parser.CREG, 0)

        def QREG(self):
            return self.getToken(qasm3Parser.QREG, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_oldStyleDeclarationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOldStyleDeclarationStatement" ):
                listener.enterOldStyleDeclarationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOldStyleDeclarationStatement" ):
                listener.exitOldStyleDeclarationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOldStyleDeclarationStatement" ):
                return visitor.visitOldStyleDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)




    def oldStyleDeclarationStatement(self):

        localctx = qasm3Parser.OldStyleDeclarationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_oldStyleDeclarationStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 351
            _la = self._input.LA(1)
            if not(_la==25 or _la==27):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 352
            self.match(qasm3Parser.Identifier)
            self.state = 354
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==50:
                self.state = 353
                self.designator()


            self.state = 356
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QuantumDeclarationStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qubitType(self):
            return self.getTypedRuleContext(qasm3Parser.QubitTypeContext,0)


        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_quantumDeclarationStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuantumDeclarationStatement" ):
                listener.enterQuantumDeclarationStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuantumDeclarationStatement" ):
                listener.exitQuantumDeclarationStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQuantumDeclarationStatement" ):
                return visitor.visitQuantumDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)




    def quantumDeclarationStatement(self):

        localctx = qasm3Parser.QuantumDeclarationStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_quantumDeclarationStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 358
            self.qubitType()
            self.state = 359
            self.match(qasm3Parser.Identifier)
            self.state = 360
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEF(self):
            return self.getToken(qasm3Parser.DEF, 0)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def scope(self):
            return self.getTypedRuleContext(qasm3Parser.ScopeContext,0)


        def argumentDefinitionList(self):
            return self.getTypedRuleContext(qasm3Parser.ArgumentDefinitionListContext,0)


        def returnSignature(self):
            return self.getTypedRuleContext(qasm3Parser.ReturnSignatureContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_defStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefStatement" ):
                listener.enterDefStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefStatement" ):
                listener.exitDefStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefStatement" ):
                return visitor.visitDefStatement(self)
            else:
                return visitor.visitChildren(self)




    def defStatement(self):

        localctx = qasm3Parser.DefStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_defStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 362
            self.match(qasm3Parser.DEF)
            self.state = 363
            self.match(qasm3Parser.Identifier)
            self.state = 364
            self.match(qasm3Parser.LPAREN)
            self.state = 366
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 240509779968) != 0):
                self.state = 365
                self.argumentDefinitionList()


            self.state = 368
            self.match(qasm3Parser.RPAREN)
            self.state = 370
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 369
                self.returnSignature()


            self.state = 372
            self.scope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExternStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EXTERN(self):
            return self.getToken(qasm3Parser.EXTERN, 0)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def externArgumentList(self):
            return self.getTypedRuleContext(qasm3Parser.ExternArgumentListContext,0)


        def returnSignature(self):
            return self.getTypedRuleContext(qasm3Parser.ReturnSignatureContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_externStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternStatement" ):
                listener.enterExternStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternStatement" ):
                listener.exitExternStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExternStatement" ):
                return visitor.visitExternStatement(self)
            else:
                return visitor.visitChildren(self)




    def externStatement(self):

        localctx = qasm3Parser.ExternStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_externStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 374
            self.match(qasm3Parser.EXTERN)
            self.state = 375
            self.match(qasm3Parser.Identifier)
            self.state = 376
            self.match(qasm3Parser.LPAREN)
            self.state = 378
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 240409116672) != 0):
                self.state = 377
                self.externArgumentList()


            self.state = 380
            self.match(qasm3Parser.RPAREN)
            self.state = 382
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 381
                self.returnSignature()


            self.state = 384
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GateStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.params = None # IdentifierListContext
            self.qubits = None # IdentifierListContext

        def GATE(self):
            return self.getToken(qasm3Parser.GATE, 0)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def scope(self):
            return self.getTypedRuleContext(qasm3Parser.ScopeContext,0)


        def identifierList(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.IdentifierListContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.IdentifierListContext,i)


        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_gateStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGateStatement" ):
                listener.enterGateStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGateStatement" ):
                listener.exitGateStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGateStatement" ):
                return visitor.visitGateStatement(self)
            else:
                return visitor.visitChildren(self)




    def gateStatement(self):

        localctx = qasm3Parser.GateStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_gateStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 386
            self.match(qasm3Parser.GATE)
            self.state = 387
            self.match(qasm3Parser.Identifier)
            self.state = 393
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==54:
                self.state = 388
                self.match(qasm3Parser.LPAREN)
                self.state = 390
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==87:
                    self.state = 389
                    localctx.params = self.identifierList()


                self.state = 392
                self.match(qasm3Parser.RPAREN)


            self.state = 395
            localctx.qubits = self.identifierList()
            self.state = 396
            self.scope()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.op = None # Token

        def indexedIdentifier(self):
            return self.getTypedRuleContext(qasm3Parser.IndexedIdentifierContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def EQUALS(self):
            return self.getToken(qasm3Parser.EQUALS, 0)

        def CompoundAssignmentOperator(self):
            return self.getToken(qasm3Parser.CompoundAssignmentOperator, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def measureExpression(self):
            return self.getTypedRuleContext(qasm3Parser.MeasureExpressionContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_assignmentStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignmentStatement" ):
                listener.enterAssignmentStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignmentStatement" ):
                listener.exitAssignmentStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignmentStatement" ):
                return visitor.visitAssignmentStatement(self)
            else:
                return visitor.visitChildren(self)




    def assignmentStatement(self):

        localctx = qasm3Parser.AssignmentStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_assignmentStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 398
            self.indexedIdentifier()
            self.state = 399
            localctx.op = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==60 or _la==78):
                localctx.op = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 402
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.state = 400
                self.expression(0)
                pass
            elif token in [47]:
                self.state = 401
                self.measureExpression()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 404
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(qasm3Parser.SEMICOLON, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_expressionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionStatement" ):
                listener.enterExpressionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionStatement" ):
                listener.exitExpressionStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionStatement" ):
                return visitor.visitExpressionStatement(self)
            else:
                return visitor.visitChildren(self)




    def expressionStatement(self):

        localctx = qasm3Parser.ExpressionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_expressionStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 406
            self.expression(0)
            self.state = 407
            self.match(qasm3Parser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefcalStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEFCAL(self):
            return self.getToken(qasm3Parser.DEFCAL, 0)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def defcalArgumentList(self):
            return self.getTypedRuleContext(qasm3Parser.DefcalArgumentListContext,0)


        def LBRACE(self):
            return self.getToken(qasm3Parser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(qasm3Parser.RBRACE, 0)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def returnSignature(self):
            return self.getTypedRuleContext(qasm3Parser.ReturnSignatureContext,0)


        def argumentDefinitionList(self):
            return self.getTypedRuleContext(qasm3Parser.ArgumentDefinitionListContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_defcalStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefcalStatement" ):
                listener.enterDefcalStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefcalStatement" ):
                listener.exitDefcalStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefcalStatement" ):
                return visitor.visitDefcalStatement(self)
            else:
                return visitor.visitChildren(self)




    def defcalStatement(self):

        localctx = qasm3Parser.DefcalStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_defcalStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 409
            self.match(qasm3Parser.DEFCAL)
            self.state = 410
            self.match(qasm3Parser.Identifier)
            self.state = 416
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==54:
                self.state = 411
                self.match(qasm3Parser.LPAREN)
                self.state = 413
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 240509779968) != 0):
                    self.state = 412
                    self.argumentDefinitionList()


                self.state = 415
                self.match(qasm3Parser.RPAREN)


            self.state = 418
            self.defcalArgumentList()
            self.state = 420
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==61:
                self.state = 419
                self.returnSignature()


            self.state = 422
            self.match(qasm3Parser.LBRACE)
            self.state = 426
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,39,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 423
                    self.matchWildcard() 
                self.state = 428
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,39,self._ctx)

            self.state = 429
            self.match(qasm3Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return qasm3Parser.RULE_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class BitwiseXorExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def CARET(self):
            return self.getToken(qasm3Parser.CARET, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitwiseXorExpression" ):
                listener.enterBitwiseXorExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitwiseXorExpression" ):
                listener.exitBitwiseXorExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitwiseXorExpression" ):
                return visitor.visitBitwiseXorExpression(self)
            else:
                return visitor.visitChildren(self)


    class AdditiveExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def PLUS(self):
            return self.getToken(qasm3Parser.PLUS, 0)
        def MINUS(self):
            return self.getToken(qasm3Parser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditiveExpression" ):
                listener.enterAdditiveExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditiveExpression" ):
                listener.exitAdditiveExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditiveExpression" ):
                return visitor.visitAdditiveExpression(self)
            else:
                return visitor.visitChildren(self)


    class DurationofExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DURATIONOF(self):
            return self.getToken(qasm3Parser.DURATIONOF, 0)
        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)
        def scope(self):
            return self.getTypedRuleContext(qasm3Parser.ScopeContext,0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDurationofExpression" ):
                listener.enterDurationofExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDurationofExpression" ):
                listener.exitDurationofExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDurationofExpression" ):
                return visitor.visitDurationofExpression(self)
            else:
                return visitor.visitChildren(self)


    class ParenthesisExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParenthesisExpression" ):
                listener.enterParenthesisExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParenthesisExpression" ):
                listener.exitParenthesisExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParenthesisExpression" ):
                return visitor.visitParenthesisExpression(self)
            else:
                return visitor.visitChildren(self)


    class ComparisonExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def ComparisonOperator(self):
            return self.getToken(qasm3Parser.ComparisonOperator, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonExpression" ):
                listener.enterComparisonExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonExpression" ):
                listener.exitComparisonExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparisonExpression" ):
                return visitor.visitComparisonExpression(self)
            else:
                return visitor.visitChildren(self)


    class MultiplicativeExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def ASTERISK(self):
            return self.getToken(qasm3Parser.ASTERISK, 0)
        def SLASH(self):
            return self.getToken(qasm3Parser.SLASH, 0)
        def PERCENT(self):
            return self.getToken(qasm3Parser.PERCENT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicativeExpression" ):
                listener.enterMultiplicativeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicativeExpression" ):
                listener.exitMultiplicativeExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicativeExpression" ):
                return visitor.visitMultiplicativeExpression(self)
            else:
                return visitor.visitChildren(self)


    class LogicalOrExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def DOUBLE_PIPE(self):
            return self.getToken(qasm3Parser.DOUBLE_PIPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalOrExpression" ):
                listener.enterLogicalOrExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalOrExpression" ):
                listener.exitLogicalOrExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalOrExpression" ):
                return visitor.visitLogicalOrExpression(self)
            else:
                return visitor.visitChildren(self)


    class CastExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)
        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)

        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)
        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)

        def arrayType(self):
            return self.getTypedRuleContext(qasm3Parser.ArrayTypeContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCastExpression" ):
                listener.enterCastExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCastExpression" ):
                listener.exitCastExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCastExpression" ):
                return visitor.visitCastExpression(self)
            else:
                return visitor.visitChildren(self)


    class PowerExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def DOUBLE_ASTERISK(self):
            return self.getToken(qasm3Parser.DOUBLE_ASTERISK, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPowerExpression" ):
                listener.enterPowerExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPowerExpression" ):
                listener.exitPowerExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPowerExpression" ):
                return visitor.visitPowerExpression(self)
            else:
                return visitor.visitChildren(self)


    class BitwiseOrExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def PIPE(self):
            return self.getToken(qasm3Parser.PIPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitwiseOrExpression" ):
                listener.enterBitwiseOrExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitwiseOrExpression" ):
                listener.exitBitwiseOrExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitwiseOrExpression" ):
                return visitor.visitBitwiseOrExpression(self)
            else:
                return visitor.visitChildren(self)


    class CallExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)
        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)
        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)
        def expressionList(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallExpression" ):
                listener.enterCallExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallExpression" ):
                listener.exitCallExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallExpression" ):
                return visitor.visitCallExpression(self)
            else:
                return visitor.visitChildren(self)


    class BitshiftExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def BitshiftOperator(self):
            return self.getToken(qasm3Parser.BitshiftOperator, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitshiftExpression" ):
                listener.enterBitshiftExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitshiftExpression" ):
                listener.exitBitshiftExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitshiftExpression" ):
                return visitor.visitBitshiftExpression(self)
            else:
                return visitor.visitChildren(self)


    class BitwiseAndExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def AMPERSAND(self):
            return self.getToken(qasm3Parser.AMPERSAND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitwiseAndExpression" ):
                listener.enterBitwiseAndExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitwiseAndExpression" ):
                listener.exitBitwiseAndExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitwiseAndExpression" ):
                return visitor.visitBitwiseAndExpression(self)
            else:
                return visitor.visitChildren(self)


    class EqualityExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def EqualityOperator(self):
            return self.getToken(qasm3Parser.EqualityOperator, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEqualityExpression" ):
                listener.enterEqualityExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEqualityExpression" ):
                listener.exitEqualityExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEqualityExpression" ):
                return visitor.visitEqualityExpression(self)
            else:
                return visitor.visitChildren(self)


    class LogicalAndExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)

        def DOUBLE_AMPERSAND(self):
            return self.getToken(qasm3Parser.DOUBLE_AMPERSAND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalAndExpression" ):
                listener.enterLogicalAndExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalAndExpression" ):
                listener.exitLogicalAndExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalAndExpression" ):
                return visitor.visitLogicalAndExpression(self)
            else:
                return visitor.visitChildren(self)


    class IndexExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)

        def indexOperator(self):
            return self.getTypedRuleContext(qasm3Parser.IndexOperatorContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexExpression" ):
                listener.enterIndexExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexExpression" ):
                listener.exitIndexExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexExpression" ):
                return visitor.visitIndexExpression(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)

        def TILDE(self):
            return self.getToken(qasm3Parser.TILDE, 0)
        def EXCLAMATION_POINT(self):
            return self.getToken(qasm3Parser.EXCLAMATION_POINT, 0)
        def MINUS(self):
            return self.getToken(qasm3Parser.MINUS, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExpression" ):
                listener.enterUnaryExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExpression" ):
                listener.exitUnaryExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression" ):
                return visitor.visitUnaryExpression(self)
            else:
                return visitor.visitChildren(self)


    class LiteralExpressionContext(ExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a qasm3Parser.ExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)
        def BinaryIntegerLiteral(self):
            return self.getToken(qasm3Parser.BinaryIntegerLiteral, 0)
        def OctalIntegerLiteral(self):
            return self.getToken(qasm3Parser.OctalIntegerLiteral, 0)
        def DecimalIntegerLiteral(self):
            return self.getToken(qasm3Parser.DecimalIntegerLiteral, 0)
        def HexIntegerLiteral(self):
            return self.getToken(qasm3Parser.HexIntegerLiteral, 0)
        def FloatLiteral(self):
            return self.getToken(qasm3Parser.FloatLiteral, 0)
        def ImaginaryLiteral(self):
            return self.getToken(qasm3Parser.ImaginaryLiteral, 0)
        def BooleanLiteral(self):
            return self.getToken(qasm3Parser.BooleanLiteral, 0)
        def BitstringLiteral(self):
            return self.getToken(qasm3Parser.BitstringLiteral, 0)
        def TimingLiteral(self):
            return self.getToken(qasm3Parser.TimingLiteral, 0)
        def HardwareQubit(self):
            return self.getToken(qasm3Parser.HardwareQubit, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralExpression" ):
                listener.enterLiteralExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralExpression" ):
                listener.exitLiteralExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralExpression" ):
                return visitor.visitLiteralExpression(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = qasm3Parser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 68
        self.enterRecursionRule(localctx, 68, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 458
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
            if la_ == 1:
                localctx = qasm3Parser.ParenthesisExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 432
                self.match(qasm3Parser.LPAREN)
                self.state = 433
                self.expression(0)
                self.state = 434
                self.match(qasm3Parser.RPAREN)
                pass

            elif la_ == 2:
                localctx = qasm3Parser.UnaryExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 436
                localctx.op = self._input.LT(1)
                _la = self._input.LA(1)
                if not(((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & 6145) != 0)):
                    localctx.op = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 437
                self.expression(15)
                pass

            elif la_ == 3:
                localctx = qasm3Parser.CastExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 440
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [28, 29, 30, 31, 32, 33, 34, 36, 37]:
                    self.state = 438
                    self.scalarType()
                    pass
                elif token in [35]:
                    self.state = 439
                    self.arrayType()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 442
                self.match(qasm3Parser.LPAREN)
                self.state = 443
                self.expression(0)
                self.state = 444
                self.match(qasm3Parser.RPAREN)
                pass

            elif la_ == 4:
                localctx = qasm3Parser.DurationofExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 446
                self.match(qasm3Parser.DURATIONOF)
                self.state = 447
                self.match(qasm3Parser.LPAREN)
                self.state = 448
                self.scope()
                self.state = 449
                self.match(qasm3Parser.RPAREN)
                pass

            elif la_ == 5:
                localctx = qasm3Parser.CallExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 451
                self.match(qasm3Parser.Identifier)
                self.state = 452
                self.match(qasm3Parser.LPAREN)
                self.state = 454
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if ((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & -17592117255666689) != 0):
                    self.state = 453
                    self.expressionList()


                self.state = 456
                self.match(qasm3Parser.RPAREN)
                pass

            elif la_ == 6:
                localctx = qasm3Parser.LiteralExpressionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 457
                _la = self._input.LA(1)
                if not(((((_la - 49)) & ~0x3f) == 0 and ((1 << (_la - 49)) & 8787503087617) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 497
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,44,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 495
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,43,self._ctx)
                    if la_ == 1:
                        localctx = qasm3Parser.PowerExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 460
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 461
                        localctx.op = self.match(qasm3Parser.DOUBLE_ASTERISK)
                        self.state = 462
                        self.expression(16)
                        pass

                    elif la_ == 2:
                        localctx = qasm3Parser.MultiplicativeExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 463
                        if not self.precpred(self._ctx, 14):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                        self.state = 464
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(((((_la - 65)) & ~0x3f) == 0 and ((1 << (_la - 65)) & 13) != 0)):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 465
                        self.expression(15)
                        pass

                    elif la_ == 3:
                        localctx = qasm3Parser.AdditiveExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 466
                        if not self.precpred(self._ctx, 13):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 13)")
                        self.state = 467
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==62 or _la==64):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 468
                        self.expression(14)
                        pass

                    elif la_ == 4:
                        localctx = qasm3Parser.BitshiftExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 469
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 470
                        localctx.op = self.match(qasm3Parser.BitshiftOperator)
                        self.state = 471
                        self.expression(13)
                        pass

                    elif la_ == 5:
                        localctx = qasm3Parser.ComparisonExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 472
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 473
                        localctx.op = self.match(qasm3Parser.ComparisonOperator)
                        self.state = 474
                        self.expression(12)
                        pass

                    elif la_ == 6:
                        localctx = qasm3Parser.EqualityExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 475
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 476
                        localctx.op = self.match(qasm3Parser.EqualityOperator)
                        self.state = 477
                        self.expression(11)
                        pass

                    elif la_ == 7:
                        localctx = qasm3Parser.BitwiseAndExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 478
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 479
                        localctx.op = self.match(qasm3Parser.AMPERSAND)
                        self.state = 480
                        self.expression(10)
                        pass

                    elif la_ == 8:
                        localctx = qasm3Parser.BitwiseXorExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 481
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 482
                        localctx.op = self.match(qasm3Parser.CARET)
                        self.state = 483
                        self.expression(9)
                        pass

                    elif la_ == 9:
                        localctx = qasm3Parser.BitwiseOrExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 484
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 485
                        localctx.op = self.match(qasm3Parser.PIPE)
                        self.state = 486
                        self.expression(8)
                        pass

                    elif la_ == 10:
                        localctx = qasm3Parser.LogicalAndExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 487
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 488
                        localctx.op = self.match(qasm3Parser.DOUBLE_AMPERSAND)
                        self.state = 489
                        self.expression(7)
                        pass

                    elif la_ == 11:
                        localctx = qasm3Parser.LogicalOrExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 490
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 491
                        localctx.op = self.match(qasm3Parser.DOUBLE_PIPE)
                        self.state = 492
                        self.expression(6)
                        pass

                    elif la_ == 12:
                        localctx = qasm3Parser.IndexExpressionContext(self, qasm3Parser.ExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 493
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 494
                        self.indexOperator()
                        pass

             
                self.state = 499
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,44,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class AliasExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)


        def DOUBLE_PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.DOUBLE_PLUS)
            else:
                return self.getToken(qasm3Parser.DOUBLE_PLUS, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_aliasExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAliasExpression" ):
                listener.enterAliasExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAliasExpression" ):
                listener.exitAliasExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAliasExpression" ):
                return visitor.visitAliasExpression(self)
            else:
                return visitor.visitChildren(self)




    def aliasExpression(self):

        localctx = qasm3Parser.AliasExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_aliasExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 500
            self.expression(0)
            self.state = 505
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==63:
                self.state = 501
                self.match(qasm3Parser.DOUBLE_PLUS)
                self.state = 502
                self.expression(0)
                self.state = 507
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclarationExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def arrayLiteral(self):
            return self.getTypedRuleContext(qasm3Parser.ArrayLiteralContext,0)


        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def measureExpression(self):
            return self.getTypedRuleContext(qasm3Parser.MeasureExpressionContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_declarationExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclarationExpression" ):
                listener.enterDeclarationExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclarationExpression" ):
                listener.exitDeclarationExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclarationExpression" ):
                return visitor.visitDeclarationExpression(self)
            else:
                return visitor.visitChildren(self)




    def declarationExpression(self):

        localctx = qasm3Parser.DeclarationExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_declarationExpression)
        try:
            self.state = 511
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [52]:
                self.enterOuterAlt(localctx, 1)
                self.state = 508
                self.arrayLiteral()
                pass
            elif token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.enterOuterAlt(localctx, 2)
                self.state = 509
                self.expression(0)
                pass
            elif token in [47]:
                self.enterOuterAlt(localctx, 3)
                self.state = 510
                self.measureExpression()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MeasureExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MEASURE(self):
            return self.getToken(qasm3Parser.MEASURE, 0)

        def gateOperand(self):
            return self.getTypedRuleContext(qasm3Parser.GateOperandContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_measureExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMeasureExpression" ):
                listener.enterMeasureExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMeasureExpression" ):
                listener.exitMeasureExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMeasureExpression" ):
                return visitor.visitMeasureExpression(self)
            else:
                return visitor.visitChildren(self)




    def measureExpression(self):

        localctx = qasm3Parser.MeasureExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_measureExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 513
            self.match(qasm3Parser.MEASURE)
            self.state = 514
            self.gateOperand()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RangeExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COLON(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COLON)
            else:
                return self.getToken(qasm3Parser.COLON, i)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)


        def getRuleIndex(self):
            return qasm3Parser.RULE_rangeExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRangeExpression" ):
                listener.enterRangeExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRangeExpression" ):
                listener.exitRangeExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRangeExpression" ):
                return visitor.visitRangeExpression(self)
            else:
                return visitor.visitChildren(self)




    def rangeExpression(self):

        localctx = qasm3Parser.RangeExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_rangeExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 517
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & -17592117255666689) != 0):
                self.state = 516
                self.expression(0)


            self.state = 519
            self.match(qasm3Parser.COLON)
            self.state = 521
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if ((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & -17592117255666689) != 0):
                self.state = 520
                self.expression(0)


            self.state = 525
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==56:
                self.state = 523
                self.match(qasm3Parser.COLON)
                self.state = 524
                self.expression(0)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SetExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(qasm3Parser.LBRACE, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)


        def RBRACE(self):
            return self.getToken(qasm3Parser.RBRACE, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_setExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSetExpression" ):
                listener.enterSetExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSetExpression" ):
                listener.exitSetExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetExpression" ):
                return visitor.visitSetExpression(self)
            else:
                return visitor.visitChildren(self)




    def setExpression(self):

        localctx = qasm3Parser.SetExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_setExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 527
            self.match(qasm3Parser.LBRACE)
            self.state = 528
            self.expression(0)
            self.state = 533
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,50,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 529
                    self.match(qasm3Parser.COMMA)
                    self.state = 530
                    self.expression(0) 
                self.state = 535
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,50,self._ctx)

            self.state = 537
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 536
                self.match(qasm3Parser.COMMA)


            self.state = 539
            self.match(qasm3Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(qasm3Parser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(qasm3Parser.RBRACE, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)


        def arrayLiteral(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ArrayLiteralContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ArrayLiteralContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_arrayLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArrayLiteral" ):
                listener.enterArrayLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArrayLiteral" ):
                listener.exitArrayLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArrayLiteral" ):
                return visitor.visitArrayLiteral(self)
            else:
                return visitor.visitChildren(self)




    def arrayLiteral(self):

        localctx = qasm3Parser.ArrayLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_arrayLiteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 541
            self.match(qasm3Parser.LBRACE)
            self.state = 544
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.state = 542
                self.expression(0)
                pass
            elif token in [52]:
                self.state = 543
                self.arrayLiteral()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 553
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,54,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 546
                    self.match(qasm3Parser.COMMA)
                    self.state = 549
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                        self.state = 547
                        self.expression(0)
                        pass
                    elif token in [52]:
                        self.state = 548
                        self.arrayLiteral()
                        pass
                    else:
                        raise NoViableAltException(self)
             
                self.state = 555
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,54,self._ctx)

            self.state = 557
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 556
                self.match(qasm3Parser.COMMA)


            self.state = 559
            self.match(qasm3Parser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IndexOperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACKET(self):
            return self.getToken(qasm3Parser.LBRACKET, 0)

        def RBRACKET(self):
            return self.getToken(qasm3Parser.RBRACKET, 0)

        def setExpression(self):
            return self.getTypedRuleContext(qasm3Parser.SetExpressionContext,0)


        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)


        def rangeExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.RangeExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.RangeExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_indexOperator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexOperator" ):
                listener.enterIndexOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexOperator" ):
                listener.exitIndexOperator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexOperator" ):
                return visitor.visitIndexOperator(self)
            else:
                return visitor.visitChildren(self)




    def indexOperator(self):

        localctx = qasm3Parser.IndexOperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_indexOperator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 561
            self.match(qasm3Parser.LBRACKET)
            self.state = 580
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [52]:
                self.state = 562
                self.setExpression()
                pass
            elif token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 56, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.state = 565
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,56,self._ctx)
                if la_ == 1:
                    self.state = 563
                    self.expression(0)
                    pass

                elif la_ == 2:
                    self.state = 564
                    self.rangeExpression()
                    pass


                self.state = 574
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,58,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 567
                        self.match(qasm3Parser.COMMA)
                        self.state = 570
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,57,self._ctx)
                        if la_ == 1:
                            self.state = 568
                            self.expression(0)
                            pass

                        elif la_ == 2:
                            self.state = 569
                            self.rangeExpression()
                            pass

                 
                    self.state = 576
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,58,self._ctx)

                self.state = 578
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==59:
                    self.state = 577
                    self.match(qasm3Parser.COMMA)


                pass
            else:
                raise NoViableAltException(self)

            self.state = 582
            self.match(qasm3Parser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IndexedIdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def indexOperator(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.IndexOperatorContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.IndexOperatorContext,i)


        def getRuleIndex(self):
            return qasm3Parser.RULE_indexedIdentifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIndexedIdentifier" ):
                listener.enterIndexedIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIndexedIdentifier" ):
                listener.exitIndexedIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIndexedIdentifier" ):
                return visitor.visitIndexedIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def indexedIdentifier(self):

        localctx = qasm3Parser.IndexedIdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_indexedIdentifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 584
            self.match(qasm3Parser.Identifier)
            self.state = 588
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==50:
                self.state = 585
                self.indexOperator()
                self.state = 590
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnSignatureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ARROW(self):
            return self.getToken(qasm3Parser.ARROW, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_returnSignature

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReturnSignature" ):
                listener.enterReturnSignature(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReturnSignature" ):
                listener.exitReturnSignature(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturnSignature" ):
                return visitor.visitReturnSignature(self)
            else:
                return visitor.visitChildren(self)




    def returnSignature(self):

        localctx = qasm3Parser.ReturnSignatureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_returnSignature)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 591
            self.match(qasm3Parser.ARROW)
            self.state = 592
            self.scalarType()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GateModifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AT(self):
            return self.getToken(qasm3Parser.AT, 0)

        def INV(self):
            return self.getToken(qasm3Parser.INV, 0)

        def POW(self):
            return self.getToken(qasm3Parser.POW, 0)

        def LPAREN(self):
            return self.getToken(qasm3Parser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(qasm3Parser.RPAREN, 0)

        def CTRL(self):
            return self.getToken(qasm3Parser.CTRL, 0)

        def NEGCTRL(self):
            return self.getToken(qasm3Parser.NEGCTRL, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_gateModifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGateModifier" ):
                listener.enterGateModifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGateModifier" ):
                listener.exitGateModifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGateModifier" ):
                return visitor.visitGateModifier(self)
            else:
                return visitor.visitChildren(self)




    def gateModifier(self):

        localctx = qasm3Parser.GateModifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_gateModifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 607
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [39]:
                self.state = 594
                self.match(qasm3Parser.INV)
                pass
            elif token in [40]:
                self.state = 595
                self.match(qasm3Parser.POW)
                self.state = 596
                self.match(qasm3Parser.LPAREN)
                self.state = 597
                self.expression(0)
                self.state = 598
                self.match(qasm3Parser.RPAREN)
                pass
            elif token in [41, 42]:
                self.state = 600
                _la = self._input.LA(1)
                if not(_la==41 or _la==42):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 605
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==54:
                    self.state = 601
                    self.match(qasm3Parser.LPAREN)
                    self.state = 602
                    self.expression(0)
                    self.state = 603
                    self.match(qasm3Parser.RPAREN)


                pass
            else:
                raise NoViableAltException(self)

            self.state = 609
            self.match(qasm3Parser.AT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ScalarTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BIT(self):
            return self.getToken(qasm3Parser.BIT, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def INT(self):
            return self.getToken(qasm3Parser.INT, 0)

        def UINT(self):
            return self.getToken(qasm3Parser.UINT, 0)

        def FLOAT(self):
            return self.getToken(qasm3Parser.FLOAT, 0)

        def ANGLE(self):
            return self.getToken(qasm3Parser.ANGLE, 0)

        def BOOL(self):
            return self.getToken(qasm3Parser.BOOL, 0)

        def DURATION(self):
            return self.getToken(qasm3Parser.DURATION, 0)

        def STRETCH(self):
            return self.getToken(qasm3Parser.STRETCH, 0)

        def COMPLEX(self):
            return self.getToken(qasm3Parser.COMPLEX, 0)

        def LBRACKET(self):
            return self.getToken(qasm3Parser.LBRACKET, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def RBRACKET(self):
            return self.getToken(qasm3Parser.RBRACKET, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_scalarType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScalarType" ):
                listener.enterScalarType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScalarType" ):
                listener.exitScalarType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScalarType" ):
                return visitor.visitScalarType(self)
            else:
                return visitor.visitChildren(self)




    def scalarType(self):

        localctx = qasm3Parser.ScalarTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_scalarType)
        self._la = 0 # Token type
        try:
            self.state = 641
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [29]:
                self.enterOuterAlt(localctx, 1)
                self.state = 611
                self.match(qasm3Parser.BIT)
                self.state = 613
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 612
                    self.designator()


                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 2)
                self.state = 615
                self.match(qasm3Parser.INT)
                self.state = 617
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 616
                    self.designator()


                pass
            elif token in [31]:
                self.enterOuterAlt(localctx, 3)
                self.state = 619
                self.match(qasm3Parser.UINT)
                self.state = 621
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 620
                    self.designator()


                pass
            elif token in [32]:
                self.enterOuterAlt(localctx, 4)
                self.state = 623
                self.match(qasm3Parser.FLOAT)
                self.state = 625
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 624
                    self.designator()


                pass
            elif token in [33]:
                self.enterOuterAlt(localctx, 5)
                self.state = 627
                self.match(qasm3Parser.ANGLE)
                self.state = 629
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 628
                    self.designator()


                pass
            elif token in [28]:
                self.enterOuterAlt(localctx, 6)
                self.state = 631
                self.match(qasm3Parser.BOOL)
                pass
            elif token in [36]:
                self.enterOuterAlt(localctx, 7)
                self.state = 632
                self.match(qasm3Parser.DURATION)
                pass
            elif token in [37]:
                self.enterOuterAlt(localctx, 8)
                self.state = 633
                self.match(qasm3Parser.STRETCH)
                pass
            elif token in [34]:
                self.enterOuterAlt(localctx, 9)
                self.state = 634
                self.match(qasm3Parser.COMPLEX)
                self.state = 639
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 635
                    self.match(qasm3Parser.LBRACKET)
                    self.state = 636
                    self.scalarType()
                    self.state = 637
                    self.match(qasm3Parser.RBRACKET)


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QubitTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUBIT(self):
            return self.getToken(qasm3Parser.QUBIT, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_qubitType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQubitType" ):
                listener.enterQubitType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQubitType" ):
                listener.exitQubitType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQubitType" ):
                return visitor.visitQubitType(self)
            else:
                return visitor.visitChildren(self)




    def qubitType(self):

        localctx = qasm3Parser.QubitTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_qubitType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 643
            self.match(qasm3Parser.QUBIT)
            self.state = 645
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==50:
                self.state = 644
                self.designator()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ARRAY(self):
            return self.getToken(qasm3Parser.ARRAY, 0)

        def LBRACKET(self):
            return self.getToken(qasm3Parser.LBRACKET, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def COMMA(self):
            return self.getToken(qasm3Parser.COMMA, 0)

        def expressionList(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionListContext,0)


        def RBRACKET(self):
            return self.getToken(qasm3Parser.RBRACKET, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_arrayType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArrayType" ):
                listener.enterArrayType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArrayType" ):
                listener.exitArrayType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArrayType" ):
                return visitor.visitArrayType(self)
            else:
                return visitor.visitChildren(self)




    def arrayType(self):

        localctx = qasm3Parser.ArrayTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_arrayType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 647
            self.match(qasm3Parser.ARRAY)
            self.state = 648
            self.match(qasm3Parser.LBRACKET)
            self.state = 649
            self.scalarType()
            self.state = 650
            self.match(qasm3Parser.COMMA)
            self.state = 651
            self.expressionList()
            self.state = 652
            self.match(qasm3Parser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayReferenceTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ARRAY(self):
            return self.getToken(qasm3Parser.ARRAY, 0)

        def LBRACKET(self):
            return self.getToken(qasm3Parser.LBRACKET, 0)

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def COMMA(self):
            return self.getToken(qasm3Parser.COMMA, 0)

        def RBRACKET(self):
            return self.getToken(qasm3Parser.RBRACKET, 0)

        def CONST(self):
            return self.getToken(qasm3Parser.CONST, 0)

        def MUTABLE(self):
            return self.getToken(qasm3Parser.MUTABLE, 0)

        def expressionList(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionListContext,0)


        def DIM(self):
            return self.getToken(qasm3Parser.DIM, 0)

        def EQUALS(self):
            return self.getToken(qasm3Parser.EQUALS, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_arrayReferenceType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArrayReferenceType" ):
                listener.enterArrayReferenceType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArrayReferenceType" ):
                listener.exitArrayReferenceType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArrayReferenceType" ):
                return visitor.visitArrayReferenceType(self)
            else:
                return visitor.visitChildren(self)




    def arrayReferenceType(self):

        localctx = qasm3Parser.ArrayReferenceTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_arrayReferenceType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 654
            _la = self._input.LA(1)
            if not(_la==23 or _la==24):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 655
            self.match(qasm3Parser.ARRAY)
            self.state = 656
            self.match(qasm3Parser.LBRACKET)
            self.state = 657
            self.scalarType()
            self.state = 658
            self.match(qasm3Parser.COMMA)
            self.state = 663
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 44, 49, 54, 64, 75, 76, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91]:
                self.state = 659
                self.expressionList()
                pass
            elif token in [43]:
                self.state = 660
                self.match(qasm3Parser.DIM)
                self.state = 661
                self.match(qasm3Parser.EQUALS)
                self.state = 662
                self.expression(0)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 665
            self.match(qasm3Parser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DesignatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACKET(self):
            return self.getToken(qasm3Parser.LBRACKET, 0)

        def expression(self):
            return self.getTypedRuleContext(qasm3Parser.ExpressionContext,0)


        def RBRACKET(self):
            return self.getToken(qasm3Parser.RBRACKET, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_designator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDesignator" ):
                listener.enterDesignator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDesignator" ):
                listener.exitDesignator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDesignator" ):
                return visitor.visitDesignator(self)
            else:
                return visitor.visitChildren(self)




    def designator(self):

        localctx = qasm3Parser.DesignatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_designator)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 667
            self.match(qasm3Parser.LBRACKET)
            self.state = 668
            self.expression(0)
            self.state = 669
            self.match(qasm3Parser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GateOperandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def indexedIdentifier(self):
            return self.getTypedRuleContext(qasm3Parser.IndexedIdentifierContext,0)


        def HardwareQubit(self):
            return self.getToken(qasm3Parser.HardwareQubit, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_gateOperand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGateOperand" ):
                listener.enterGateOperand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGateOperand" ):
                listener.exitGateOperand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGateOperand" ):
                return visitor.visitGateOperand(self)
            else:
                return visitor.visitChildren(self)




    def gateOperand(self):

        localctx = qasm3Parser.GateOperandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_gateOperand)
        try:
            self.state = 673
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [87]:
                self.enterOuterAlt(localctx, 1)
                self.state = 671
                self.indexedIdentifier()
                pass
            elif token in [88]:
                self.enterOuterAlt(localctx, 2)
                self.state = 672
                self.match(qasm3Parser.HardwareQubit)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExternArgumentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def arrayReferenceType(self):
            return self.getTypedRuleContext(qasm3Parser.ArrayReferenceTypeContext,0)


        def CREG(self):
            return self.getToken(qasm3Parser.CREG, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_externArgument

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternArgument" ):
                listener.enterExternArgument(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternArgument" ):
                listener.exitExternArgument(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExternArgument" ):
                return visitor.visitExternArgument(self)
            else:
                return visitor.visitChildren(self)




    def externArgument(self):

        localctx = qasm3Parser.ExternArgumentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_externArgument)
        self._la = 0 # Token type
        try:
            self.state = 681
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 36, 37]:
                self.enterOuterAlt(localctx, 1)
                self.state = 675
                self.scalarType()
                pass
            elif token in [23, 24]:
                self.enterOuterAlt(localctx, 2)
                self.state = 676
                self.arrayReferenceType()
                pass
            elif token in [27]:
                self.enterOuterAlt(localctx, 3)
                self.state = 677
                self.match(qasm3Parser.CREG)
                self.state = 679
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 678
                    self.designator()


                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefcalArgumentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def HardwareQubit(self):
            return self.getToken(qasm3Parser.HardwareQubit, 0)

        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def getRuleIndex(self):
            return qasm3Parser.RULE_defcalArgument

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefcalArgument" ):
                listener.enterDefcalArgument(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefcalArgument" ):
                listener.exitDefcalArgument(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefcalArgument" ):
                return visitor.visitDefcalArgument(self)
            else:
                return visitor.visitChildren(self)




    def defcalArgument(self):

        localctx = qasm3Parser.DefcalArgumentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_defcalArgument)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 683
            _la = self._input.LA(1)
            if not(_la==87 or _la==88):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def scalarType(self):
            return self.getTypedRuleContext(qasm3Parser.ScalarTypeContext,0)


        def Identifier(self):
            return self.getToken(qasm3Parser.Identifier, 0)

        def qubitType(self):
            return self.getTypedRuleContext(qasm3Parser.QubitTypeContext,0)


        def CREG(self):
            return self.getToken(qasm3Parser.CREG, 0)

        def QREG(self):
            return self.getToken(qasm3Parser.QREG, 0)

        def designator(self):
            return self.getTypedRuleContext(qasm3Parser.DesignatorContext,0)


        def arrayReferenceType(self):
            return self.getTypedRuleContext(qasm3Parser.ArrayReferenceTypeContext,0)


        def getRuleIndex(self):
            return qasm3Parser.RULE_argumentDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentDefinition" ):
                listener.enterArgumentDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentDefinition" ):
                listener.exitArgumentDefinition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumentDefinition" ):
                return visitor.visitArgumentDefinition(self)
            else:
                return visitor.visitChildren(self)




    def argumentDefinition(self):

        localctx = qasm3Parser.ArgumentDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_argumentDefinition)
        self._la = 0 # Token type
        try:
            self.state = 699
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28, 29, 30, 31, 32, 33, 34, 36, 37]:
                self.enterOuterAlt(localctx, 1)
                self.state = 685
                self.scalarType()
                self.state = 686
                self.match(qasm3Parser.Identifier)
                pass
            elif token in [26]:
                self.enterOuterAlt(localctx, 2)
                self.state = 688
                self.qubitType()
                self.state = 689
                self.match(qasm3Parser.Identifier)
                pass
            elif token in [25, 27]:
                self.enterOuterAlt(localctx, 3)
                self.state = 691
                _la = self._input.LA(1)
                if not(_la==25 or _la==27):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 692
                self.match(qasm3Parser.Identifier)
                self.state = 694
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==50:
                    self.state = 693
                    self.designator()


                pass
            elif token in [23, 24]:
                self.enterOuterAlt(localctx, 4)
                self.state = 696
                self.arrayReferenceType()
                self.state = 697
                self.match(qasm3Parser.Identifier)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentDefinitionListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def argumentDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ArgumentDefinitionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ArgumentDefinitionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_argumentDefinitionList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentDefinitionList" ):
                listener.enterArgumentDefinitionList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentDefinitionList" ):
                listener.exitArgumentDefinitionList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumentDefinitionList" ):
                return visitor.visitArgumentDefinitionList(self)
            else:
                return visitor.visitChildren(self)




    def argumentDefinitionList(self):

        localctx = qasm3Parser.ArgumentDefinitionListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 108, self.RULE_argumentDefinitionList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 701
            self.argumentDefinition()
            self.state = 706
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,78,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 702
                    self.match(qasm3Parser.COMMA)
                    self.state = 703
                    self.argumentDefinition() 
                self.state = 708
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,78,self._ctx)

            self.state = 710
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 709
                self.match(qasm3Parser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExpressionContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_expressionList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionList" ):
                listener.enterExpressionList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionList" ):
                listener.exitExpressionList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionList" ):
                return visitor.visitExpressionList(self)
            else:
                return visitor.visitChildren(self)




    def expressionList(self):

        localctx = qasm3Parser.ExpressionListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 110, self.RULE_expressionList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 712
            self.expression(0)
            self.state = 717
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,80,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 713
                    self.match(qasm3Parser.COMMA)
                    self.state = 714
                    self.expression(0) 
                self.state = 719
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,80,self._ctx)

            self.state = 721
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 720
                self.match(qasm3Parser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefcalArgumentListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def defcalArgument(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.DefcalArgumentContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.DefcalArgumentContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_defcalArgumentList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefcalArgumentList" ):
                listener.enterDefcalArgumentList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefcalArgumentList" ):
                listener.exitDefcalArgumentList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefcalArgumentList" ):
                return visitor.visitDefcalArgumentList(self)
            else:
                return visitor.visitChildren(self)




    def defcalArgumentList(self):

        localctx = qasm3Parser.DefcalArgumentListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 112, self.RULE_defcalArgumentList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 723
            self.defcalArgument()
            self.state = 728
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,82,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 724
                    self.match(qasm3Parser.COMMA)
                    self.state = 725
                    self.defcalArgument() 
                self.state = 730
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,82,self._ctx)

            self.state = 732
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 731
                self.match(qasm3Parser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.Identifier)
            else:
                return self.getToken(qasm3Parser.Identifier, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_identifierList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifierList" ):
                listener.enterIdentifierList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifierList" ):
                listener.exitIdentifierList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifierList" ):
                return visitor.visitIdentifierList(self)
            else:
                return visitor.visitChildren(self)




    def identifierList(self):

        localctx = qasm3Parser.IdentifierListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 114, self.RULE_identifierList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 734
            self.match(qasm3Parser.Identifier)
            self.state = 739
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,84,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 735
                    self.match(qasm3Parser.COMMA)
                    self.state = 736
                    self.match(qasm3Parser.Identifier) 
                self.state = 741
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,84,self._ctx)

            self.state = 743
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 742
                self.match(qasm3Parser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class GateOperandListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def gateOperand(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.GateOperandContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.GateOperandContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_gateOperandList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGateOperandList" ):
                listener.enterGateOperandList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGateOperandList" ):
                listener.exitGateOperandList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGateOperandList" ):
                return visitor.visitGateOperandList(self)
            else:
                return visitor.visitChildren(self)




    def gateOperandList(self):

        localctx = qasm3Parser.GateOperandListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 116, self.RULE_gateOperandList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 745
            self.gateOperand()
            self.state = 750
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,86,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 746
                    self.match(qasm3Parser.COMMA)
                    self.state = 747
                    self.gateOperand() 
                self.state = 752
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,86,self._ctx)

            self.state = 754
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 753
                self.match(qasm3Parser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExternArgumentListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def externArgument(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(qasm3Parser.ExternArgumentContext)
            else:
                return self.getTypedRuleContext(qasm3Parser.ExternArgumentContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(qasm3Parser.COMMA)
            else:
                return self.getToken(qasm3Parser.COMMA, i)

        def getRuleIndex(self):
            return qasm3Parser.RULE_externArgumentList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExternArgumentList" ):
                listener.enterExternArgumentList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExternArgumentList" ):
                listener.exitExternArgumentList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExternArgumentList" ):
                return visitor.visitExternArgumentList(self)
            else:
                return visitor.visitChildren(self)




    def externArgumentList(self):

        localctx = qasm3Parser.ExternArgumentListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 118, self.RULE_externArgumentList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 756
            self.externArgument()
            self.state = 761
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,88,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 757
                    self.match(qasm3Parser.COMMA)
                    self.state = 758
                    self.externArgument() 
                self.state = 763
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,88,self._ctx)

            self.state = 765
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==59:
                self.state = 764
                self.match(qasm3Parser.COMMA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[34] = self.expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 16)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 14)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 13)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 17)
         




