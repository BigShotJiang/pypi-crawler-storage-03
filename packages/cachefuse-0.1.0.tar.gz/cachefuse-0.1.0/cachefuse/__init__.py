"""CacheFuse: Drop-in caching for LLM calls and embeddings.

Public API will be expanded in subsequent steps. For now we expose only the
package version to support import smoke tests.
"""

__all__ = ["__version__"]
__version__ = "0.1.0.dev0"

