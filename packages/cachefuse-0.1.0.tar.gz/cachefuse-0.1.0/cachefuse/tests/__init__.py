"""Test package initializer.

This namespace contains both unit and integration tests. New tests should
prefer placing unit tests under `unit/` and integration tests under
`integration/`.
"""

