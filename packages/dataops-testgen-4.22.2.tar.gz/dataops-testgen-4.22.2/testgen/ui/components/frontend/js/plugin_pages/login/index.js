import { SSOLogin } from './pages/sso_login.js';

const components = {
    sso_login: SSOLogin,
};

export { components };
