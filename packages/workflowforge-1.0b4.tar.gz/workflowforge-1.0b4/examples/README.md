# WorkflowForge Examples

This directory contains examples demonstrating the new modular import structure of WorkflowForge.

## New Import Style

Instead of importing everything from the main module:

```python
# Old style (still works)
from workflowforge import Workflow, Job, action, run, on_push

# New modular style (recommended)
from workflowforge import github_actions

workflow = github_actions.workflow(name="CI")
job = github_actions.job(runs_on="ubuntu-latest")
job.add_step(github_actions.action("actions/checkout@v4"))
```

## Examples

### GitHub Actions

- **basic_ci.py** - Simple CI pipeline with checkout and hello world
- **python_matrix.py** - Matrix testing across Python versions and OS

### Jenkins

- **maven_build.py** - Maven build pipeline with multiple stages

### AWS CodeBuild

- **node_app.py** - Node.js application build with testing and artifacts

## Running Examples

Run individual examples:

```bash
python examples/github_actions/basic_ci.py
python examples/jenkins/maven_build.py
python examples/codebuild/node_app.py
```

Run all examples at once:

```bash
python examples/run_all_examples.py
```

## Benefits of New Structure

✅ **Platform separation** - Clear namespace for each platform
✅ **Snake case naming** - Follows Python conventions
✅ **IDE autocompletion** - Better IntelliSense support
✅ **Backwards compatibility** - Old imports still work
✅ **Shorter aliases** - `gh = github_actions` for convenience
