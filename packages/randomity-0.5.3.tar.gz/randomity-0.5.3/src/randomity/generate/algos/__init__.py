from .algo_MersenneTwister import _MersenneTwister
from .algo_XORShift import _XORShift
from .algo_LCG import _LCG
from .algo_MTNumpy import _MTNumpy
from .algo_BlumBlumShub import _BlumBlumShub
from .algo_MiddleSquare import _MiddleSquare