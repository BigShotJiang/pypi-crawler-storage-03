def whyRandom():
    """
    Reports the contribution of statistical tests to the randomness of a sequence.
    """
    # TODO
