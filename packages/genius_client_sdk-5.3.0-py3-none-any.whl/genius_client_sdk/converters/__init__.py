"""
Converters module for the Genius client SDK.

This module provides functionality for converting between different model formats.
"""
