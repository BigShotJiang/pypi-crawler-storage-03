pdflatex structure.tex
convert -density 300 structure.pdf -quality 100 talkpipe_diagram.png
rm structure.pdf
