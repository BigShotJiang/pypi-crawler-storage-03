__version__ = "0.0.1"
__author__ = "Daniel Bastos"
__email__ = "danielfloresbastos@gmail.com"
