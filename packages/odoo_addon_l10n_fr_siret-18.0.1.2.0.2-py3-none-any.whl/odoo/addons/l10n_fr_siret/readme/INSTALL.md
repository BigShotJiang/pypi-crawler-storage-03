It is recommended to install ``python-stdnum>=1.18`` to benefit from a [specific bugfix](https://github.com/arthurdejong/python-stdnum/issues/291) on SIRET validation.
