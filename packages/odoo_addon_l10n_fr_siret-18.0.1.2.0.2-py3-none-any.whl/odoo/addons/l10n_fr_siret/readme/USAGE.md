On the Partner form, users will be able to enter:

- the SIREN and NIC numbers: the SIRET number will be computed automatically.
- the SIRET number: the SIREN and NIC will be computed automatically.

The last digits of the SIREN and NIC are control keys: Odoo will check
their validity.

The warning banner is displayed on the partner form view if another
partner:

- has the same SIREN,
- if the partner is attached to a specific company: is in the same company or is not attached to a specific company,
- if the partner is not attached to a specific company: is in any company or not attached to a specific company.
