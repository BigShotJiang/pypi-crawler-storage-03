class SourceCodeScannerException(RuntimeError):
    pass
