import asyncio
from typing import Literal
import aiohttp
import base64
import logging
from dotenv import load_dotenv
import os
import ssl

load_dotenv()

logger = logging.getLogger(__name__)


async def send_telemetrx_async(telemetrx_env: Literal["dev", "stage", "prod"] = "stage",
                               telemetrx_data: dict = None, app_token: str = None,
                               telemetrx_base_url: str = None, verify_ssl: bool = True):
    """Sends telemetry data asynchronously to the appropriate URL.

    Args:
        telemetrx_env: Environment (dev, stage, or prod).
        telemetrx_data: Dictionary of telemetry data.

    URL will be generated using BASE_URL_ENVIRONMENT eg: BASE_URL_DEV, BASE_URL_STAGE, BASE_URL_PROD
    :param telemetrx_base_url:
    :param telemetrx_data:
    :param telemetrx_env:
    :param app_token:
    """
    # Updated endpoint to match Fast API v0.3.0
    url = f"{telemetrx_base_url}/v1/send"
    logger.debug(f"Sending telemetry data to {url}, data: {telemetrx_data}")
    if not telemetrx_base_url:
        raise ValueError(f"Invalid base URL for environment: {telemetrx_env}")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {app_token}"
    }
    
    # Configure SSL context for corporate environments
    ssl_context = None
    if not verify_ssl:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        logger.warning("SSL verification disabled - use only in trusted environments")
    
    connector = aiohttp.TCPConnector(ssl=ssl_context) if ssl_context else None
    async with aiohttp.ClientSession(connector=connector) as session:
        async with session.post(url, json=telemetrx_data, headers=headers) as response:
            response_text = await response.text()
            if response.status == 200:
                logger.debug(f"Telemetry send success for {telemetrx_env}: {response.status}")
                try:
                    response_json = await response.json()
                    return response_json
                except:
                    return {"status": "success", "details": "Data sent successfully"}
            else:
                logger.error(f"Telemetry send failed for {telemetrx_env}: {response.status} - {response_text}")
                raise Exception(f"API request failed with status {response.status}: {response_text}")


# Example usage
async def send_to_correct_env(environment,
                              telemetry_data,
                              app_token,
                              telemetrx_base_url,
                              verify_ssl=True):
    return await send_telemetrx_async(environment,
                                      telemetry_data,
                                      app_token,
                                      telemetrx_base_url,
                                      verify_ssl)


def send_telemetrx(user: str,
                   app_name: str,
                   telemetry_data=None,
                   telemetrx_env: str = "stage",
                   technology_stripe: Literal["Data Center", "Collaboration", "Security", "Service Provider", "Enterprise Networking", "Other", "SaaS", "Technology Agnostic"] = "Other",
                   anonymize: bool = False,
                   get_orgstats: bool = True,
                   telemetrx_base_url: str = None,
                   app_token: str = None,
                   proxy_app: dict = None,
                   app_action: str = "None Provided",
                   usage_type: Literal["Active", "Passive"] = "Passive",
                   srid: str = None,
                   verify_ssl: bool = True,
                   # Deprecated parameters - kept for backward compatibility but not sent to API
                   telemetry_type: Literal["Adoption", "Enablement", "Other"] = None,
                   ):
    """
    Helps to send Telemetrx data asynchronously to the appropriate URL.
    
    Updated for TelemetrX Fast API v0.3.0 compatibility.

    :param proxy_app: In case service App is sending data for proxy app, this will be used to send data
    :param telemetrx_base_url: Telemetrx Base URL provided or based on environment variable BASE_URL_{telemetrx_env}
    :param app_token: App Token provided or based on environment variable TELEMETRX_API_KEY
    :param get_orgstats: When set to true, the TelemetrX backend will generate some more details about the user, e.g their workgroup, id ...
    :param anonymize: When set to true, the user details will be encoded in the TelemetrX backend. It is set to False by default.
    :param technology_stripe: Defines the Technology stripe where the application belongs. Must be one of the valid values.
    :param telemetry_data: Dictionary of custom telemetry data
    :param user: User CEC or identifier, this would be anonymized in TelemetrX if anonymize is set to True
    :param app_name: Name of the app, It will be used with token to validate if App is allowed to send data
    :param telemetrx_env: Environment will be used for TelemetrX (dev, stage, or prod)
    :param app_action: Action performed in the app (for usage granularity and dashboard drilldown)
    :param usage_type: Type of usage - Active (intentional click/action) vs Passive (auto-load, general page load)
    :param srid: Service Request ID if applicable
    :param telemetry_type: DEPRECATED - This field is now handled at app registration level only
    :return: API response or None
    """
    if telemetry_data is None:
        telemetry_data = {}
    if not app_name:
        raise ValueError("App Name is required for sending telemetry data")
    if not user:
        raise ValueError("User CEC is required for sending telemetry data")
    if not telemetrx_env:
        raise ValueError("TelemetrX Environment is required for sending telemetry data")
    if telemetrx_env not in ["dev", "stage", "prod"]:
        raise ValueError(
            f"Invalid TelemetrX Environment, expected either of dev, stage and prod, received {telemetrx_env}")
    
    # Validate technology stripe against API accepted values
    valid_stripes = ["Data Center", "Collaboration", "Security", "Service Provider", "Enterprise Networking", "Other", "SaaS", "Technology Agnostic"]
    if technology_stripe not in valid_stripes:
        raise ValueError(f"Invalid technology stripe. Must be one of: {valid_stripes}")
    
    # Warn about deprecated parameter
    if telemetry_type is not None:
        logger.warning("telemetry_type parameter is deprecated and will be ignored. This field is now handled at app registration level.")

    # Build payload according to Fast API v0.3.0 structure
    payload_data = {
        "app_name": app_name,
        "cec": user,
        "technology_stripe": technology_stripe,
        "custom": telemetry_data,
        "anonymize": anonymize,
        "include_orgstats": get_orgstats,
        "app_action": app_action,
        "usage_type": usage_type
    }
    
    # Add optional fields if provided
    if srid:
        payload_data["srid"] = srid
    
    if proxy_app:
        payload_data["proxy_app"] = proxy_app
    
    # Wrap in the required "data" structure for API v0.3.0
    telemetrx_payload = {"data": payload_data}
    telemetrx_base_url = f"{telemetrx_base_url or os.getenv(f'BASE_URL_{telemetrx_env}'.capitalize())}"
    app_token = app_token or os.getenv('TELEMETRX_API_KEY')
    if not app_token:
        raise ValueError("App Token is required for sending telemetry data, please provide TELEMETRX_API_KEY in env or app_token in function call")
    if not telemetrx_base_url:
        raise ValueError("TelemetrX Base URL is required for sending telemetry data, please provide BASE_URL_{telemetrx_env} in env or telemetrx_base_url in function call")
    logger.debug(f"TelemetrX data will be sent to "
                 f"{telemetrx_base_url} for {telemetrx_env} with payload: {telemetrx_payload}")

    try:
        result = asyncio.run(send_to_correct_env(telemetrx_env,
                                        telemetrx_payload,
                                        app_token,
                                        telemetrx_base_url,
                                        verify_ssl))
        logger.info(f"Successfully sent telemetry data for {app_name}")
        return result
    except Exception as e:
        logger.error(f"Failed to send telemetry data for {app_name}: {str(e)}")
        raise
