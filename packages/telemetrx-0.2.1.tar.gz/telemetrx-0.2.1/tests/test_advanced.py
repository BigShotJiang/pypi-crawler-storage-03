#!/usr/bin/env python3
"""
Advanced TelemetrX Library Test Script
=====================================

This script tests advanced functionality of the TelemetrX library v0.2.0
including async operations, proxy apps, and all new Fast API v0.3.0 features.

Instructions:
1. Update the CREDENTIALS section below with your actual values
2. Run: python test_advanced.py
3. Check the output for detailed test results

Author: TelemetrX Team
Version: 0.2.0
"""

import os
import sys
import asyncio
from datetime import datetime
import json

# Add the parent directory to Python path for local testing
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from telemetrx import send_telemetrx, send_telemetrx_async
    print("✅ Successfully imported TelemetrX library (sync & async)")
except ImportError as e:
    print(f"❌ Failed to import TelemetrX library: {e}")
    sys.exit(1)

# =============================================================================
# CREDENTIALS - UPDATE THESE WITH YOUR ACTUAL VALUES
# =============================================================================

TELEMETRX_CREDENTIALS = {
    "app_token": "YOUR_APP_TOKEN_HERE",
    "app_name": "YOUR_APP_NAME_HERE", 
    "user_cec": "YOUR_CEC_ID_HERE",
    "telemetrx_env": "stage",  # "dev", "stage", "prod"
    "telemetrx_base_url": "https://telemetrx-api-stage.cisco.com",
    
    # Optional: Proxy app credentials for testing proxy functionality
    "proxy_app": {
        "app_name": "YOUR_PROXY_APP_NAME_HERE",
        "app_token": "YOUR_PROXY_APP_TOKEN_HERE"
    }
}

# =============================================================================
# TEST SCENARIOS
# =============================================================================

class TelemetrXAdvancedTests:
    
    def __init__(self, credentials):
        self.creds = credentials
        self.test_results = []
    
    def log_result(self, test_name, success, message, details=None):
        """Log test result"""
        result = {
            "test": test_name,
            "success": success,
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "details": details
        }
        self.test_results.append(result)
        
        status = "✅" if success else "❌"
        print(f"{status} {test_name}: {message}")
        if details:
            print(f"   Details: {details}")
    
    def test_all_technology_stripes(self):
        """Test all valid technology stripes"""
        print("\n🧪 Testing All Technology Stripes")
        print("-" * 40)
        
        valid_stripes = [
            "Data Center", "Collaboration", "Security", 
            "Service Provider", "Enterprise Networking", 
            "Other", "SaaS", "Technology Agnostic"
        ]
        
        for stripe in valid_stripes:
            try:
                result = send_telemetrx(
                    user=self.creds["user_cec"],
                    app_name=self.creds["app_name"],
                    telemetry_data={"test_stripe": stripe, "test_type": "stripe_validation"},
                    technology_stripe=stripe,
                    app_action="stripe_test",
                    usage_type="Active",
                    verify_ssl=False,  # Disable SSL verification for corporate environments
                    app_token=self.creds["app_token"],
                    telemetrx_base_url=self.creds["telemetrx_base_url"],
                    telemetrx_env=self.creds["telemetrx_env"]
                )
                self.log_result(f"Technology Stripe: {stripe}", True, "Successfully sent", result)
                
            except Exception as e:
                self.log_result(f"Technology Stripe: {stripe}", False, str(e))
    
    def test_governance_fields(self):
        """Test all new governance fields"""
        print("\n🧪 Testing New Governance Fields")
        print("-" * 40)
        
        test_cases = [
            {
                "name": "Active Usage with SRID",
                "params": {
                    "usage_type": "Active",
                    "app_action": "user_click_action",
                    "srid": "SR123456789"
                }
            },
            {
                "name": "Passive Usage",
                "params": {
                    "usage_type": "Passive", 
                    "app_action": "auto_page_load",
                    "srid": None
                }
            },
            {
                "name": "Complex App Action",
                "params": {
                    "usage_type": "Active",
                    "app_action": "search_and_filter_results",
                    "srid": "SR987654321"
                }
            }
        ]
        
        for case in test_cases:
            try:
                telemetry_data = {
                    "test_case": case["name"],
                    "governance_test": True,
                    "timestamp": datetime.now().isoformat()
                }
                
                result = send_telemetrx(
                    user=self.creds["user_cec"],
                    app_name=self.creds["app_name"],
                    telemetry_data=telemetry_data,
                    technology_stripe="Technology Agnostic",
                    verify_ssl=False,  # Disable SSL verification for corporate environments
                    app_token=self.creds["app_token"],
                    telemetrx_base_url=self.creds["telemetrx_base_url"],
                    telemetrx_env=self.creds["telemetrx_env"],
                    **case["params"]
                )
                
                self.log_result(f"Governance: {case['name']}", True, "Successfully sent", case["params"])
                
            except Exception as e:
                self.log_result(f"Governance: {case['name']}", False, str(e))
    
    async def test_async_functionality(self):
        """Test async send_telemetrx_async function"""
        print("\n🧪 Testing Async Functionality")
        print("-" * 40)
        
        try:
            # Prepare payload in Fast API v0.3.0 format
            payload = {
                "data": {
                    "app_name": self.creds["app_name"],
                    "cec": self.creds["user_cec"],
                    "technology_stripe": "Technology Agnostic",
                    "custom": {
                        "test_type": "async_functionality",
                        "timestamp": datetime.now().isoformat(),
                        "async_test": True
                    },
                    "app_action": "async_test",
                    "usage_type": "Active",
                    "anonymize": False,
                    "include_orgstats": True
                }
            }
            
            result = await send_telemetrx_async(
                telemetrx_env=self.creds["telemetrx_env"],
                telemetrx_data=payload,
                app_token=self.creds["app_token"],
                telemetrx_base_url=self.creds["telemetrx_base_url"],
                verify_ssl=False  # Disable SSL verification for corporate environments
            )
            
            self.log_result("Async Function", True, "Successfully executed", result)
            
        except Exception as e:
            self.log_result("Async Function", False, str(e))
    
    def test_proxy_app_functionality(self):
        """Test proxy app functionality if credentials provided"""
        print("\n🧪 Testing Proxy App Functionality")
        print("-" * 40)
        
        proxy_creds = self.creds.get("proxy_app", {})
        if not proxy_creds.get("app_name") or "YOUR_" in proxy_creds.get("app_name", ""):
            self.log_result("Proxy App", False, "Proxy app credentials not configured - skipping test")
            return
        
        try:
            result = send_telemetrx(
                user=self.creds["user_cec"],
                app_name=self.creds["app_name"],  # Service app name
                telemetry_data={
                    "test_type": "proxy_app_test",
                    "proxy_for": proxy_creds["app_name"],
                    "timestamp": datetime.now().isoformat()
                },
                technology_stripe="Technology Agnostic",
                app_action="proxy_test",
                usage_type="Active",
                proxy_app=proxy_creds,  # Proxy app details
                app_token=self.creds["app_token"],
                telemetrx_base_url=self.creds["telemetrx_base_url"],
                telemetrx_env=self.creds["telemetrx_env"]
            )
            
            self.log_result("Proxy App", True, "Successfully sent via proxy", proxy_creds["app_name"])
            
        except Exception as e:
            self.log_result("Proxy App", False, str(e))
    
    def test_anonymization(self):
        """Test user data anonymization"""
        print("\n🧪 Testing Anonymization")
        print("-" * 40)
        
        try:
            result = send_telemetrx(
                user=self.creds["user_cec"],
                app_name=self.creds["app_name"],
                telemetry_data={
                    "test_type": "anonymization_test",
                    "sensitive_data": "This should be anonymized",
                    "timestamp": datetime.now().isoformat()
                },
                technology_stripe="Security",
                app_action="anonymization_test",
                usage_type="Active",
                anonymize=True,  # Enable anonymization
                get_orgstats=False,  # Disable orgstats for this test
                app_token=self.creds["app_token"],
                telemetrx_base_url=self.creds["telemetrx_base_url"],
                telemetrx_env=self.creds["telemetrx_env"]
            )
            
            self.log_result("Anonymization", True, "Successfully sent with anonymization enabled", result)
            
        except Exception as e:
            self.log_result("Anonymization", False, str(e))
    
    def test_backward_compatibility(self):
        """Test backward compatibility with deprecated parameters"""
        print("\n🧪 Testing Backward Compatibility")
        print("-" * 40)
        
        import warnings
        
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            
            try:
                result = send_telemetrx(
                    user=self.creds["user_cec"],
                    app_name=self.creds["app_name"],
                    telemetry_data={"test_type": "backward_compatibility"},
                    technology_stripe="Other",
                    telemetry_type="Adoption",  # Deprecated parameter
                    app_token=self.creds["app_token"],
                    telemetrx_base_url=self.creds["telemetrx_base_url"],
                    telemetrx_env=self.creds["telemetrx_env"]
                )
                
                # Check for deprecation warning
                deprecation_warnings = [warning for warning in w if 'deprecated' in str(warning.message).lower()]
                
                if deprecation_warnings:
                    self.log_result("Backward Compatibility", True, 
                                  f"Successfully sent with deprecation warning: {deprecation_warnings[0].message}")
                else:
                    self.log_result("Backward Compatibility", True, "Successfully sent (no warning detected)")
                
            except Exception as e:
                self.log_result("Backward Compatibility", False, str(e))
    
    async def run_all_tests(self):
        """Run all test scenarios"""
        print(f"\n🚀 TelemetrX Advanced Test Suite")
        print("=" * 60)
        print(f"Timestamp: {datetime.now().isoformat()}")
        print(f"Environment: {self.creds['telemetrx_env']}")
        print(f"App: {self.creds['app_name']}")
        print(f"User: {self.creds['user_cec']}")
        
        # Run all tests
        self.test_all_technology_stripes()
        self.test_governance_fields()
        await self.test_async_functionality()
        self.test_proxy_app_functionality()
        self.test_anonymization()
        self.test_backward_compatibility()
        
        # Print summary
        self.print_summary()
    
    def print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 60)
        print("📊 TEST SUMMARY")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["success"]])
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print(f"\n❌ Failed Tests:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"   - {result['test']}: {result['message']}")
        
        print("\n" + "=" * 60)
        if failed_tests == 0:
            print("🎉 ALL TESTS PASSED! Your TelemetrX library is working perfectly!")
        else:
            print("⚠️  Some tests failed. Please check the errors above.")
        print("=" * 60)

def validate_credentials():
    """Validate credentials are configured"""
    missing = []
    for key, value in TELEMETRX_CREDENTIALS.items():
        if key == "proxy_app":
            continue  # Proxy app is optional
        if not value or "YOUR_" in str(value):
            missing.append(key)
    
    if missing:
        print("❌ Missing credentials:")
        for cred in missing:
            print(f"   - {cred}")
        return False
    return True

async def main():
    """Main test execution"""
    if not validate_credentials():
        print("\n📝 Please update the CREDENTIALS section with your actual values.")
        sys.exit(1)
    
    tester = TelemetrXAdvancedTests(TELEMETRX_CREDENTIALS)
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main())
