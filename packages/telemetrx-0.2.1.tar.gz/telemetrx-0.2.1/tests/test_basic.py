#!/usr/bin/env python3
"""
Basic TelemetrX Library Test Script
==================================

This script tests the basic functionality of the TelemetrX library v0.2.0
with Fast API v0.3.0 compatibility.

Instructions:
1. Update the CREDENTIALS section below with your actual values
2. Run: python test_basic.py
3. Check the output for success/failure messages

Author: TelemetrX Team
Version: 0.2.0
"""

import os
import sys
from datetime import datetime

# Add the parent directory to Python path for local testing
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from telemetrx import send_telemetrx
    print("✅ Successfully imported TelemetrX library")
except ImportError as e:
    print(f"❌ Failed to import TelemetrX library: {e}")
    sys.exit(1)

# =============================================================================
# CREDENTIALS - UPDATE THESE WITH YOUR ACTUAL VALUES
# =============================================================================

# Your TelemetrX API credentials (using environment variables)
TELEMETRX_CREDENTIALS = {
    # Your app token from TelemetrX registration
    "app_token": os.getenv("TELEMETRX_APP_TOKEN", "YOUR_APP_TOKEN_HERE"),
    
    # Your app name as registered in TelemetrX
    "app_name": os.getenv("TELEMETRX_APP_NAME", "YOUR_APP_NAME_HERE"),
    
    # Your CEC ID
    "user_cec": os.getenv("TELEMETRX_USER_CEC", "YOUR_CEC_ID_HERE"),
    
    # Environment to test against
    "telemetrx_env": os.getenv("TELEMETRX_ENV", "stage"),  # Options: "dev", "stage", "prod"
    
    # Base URL for the environment (optional - can use env vars instead)
    "telemetrx_base_url": os.getenv("TELEMETRX_BASE_URL_STAGE", "https://telemetrx-api-stage.cisco.com"),
}

# =============================================================================
# TEST CONFIGURATION
# =============================================================================

def run_basic_test():
    """Run basic TelemetrX functionality test"""
    
    print("\n🧪 Running Basic TelemetrX Test")
    print("=" * 50)
    print(f"Timestamp: {datetime.now().isoformat()}")
    print(f"Environment: {TELEMETRX_CREDENTIALS['telemetrx_env']}")
    print(f"App Name: {TELEMETRX_CREDENTIALS['app_name']}")
    print(f"User: {TELEMETRX_CREDENTIALS['user_cec']}")
    print()
    
    # Test data
    test_telemetry_data = {
        "test_type": "basic_functionality",
        "timestamp": datetime.now().isoformat(),
        "library_version": "0.2.0",
        "test_id": "basic_001"
    }
    
    try:
        print("📤 Sending telemetry data...")
        
        result = send_telemetrx(
            user=TELEMETRX_CREDENTIALS["user_cec"],
            app_name=TELEMETRX_CREDENTIALS["app_name"],
            telemetry_data=test_telemetry_data,
            telemetrx_env=TELEMETRX_CREDENTIALS["telemetrx_env"],
            technology_stripe="Technology Agnostic",
            app_action="library_test",
            usage_type="Active",
            srid="TEST_SR_001",
            anonymize=False,
            get_orgstats=True,
            verify_ssl=False,  # Disable SSL verification for corporate environments
            app_token=TELEMETRX_CREDENTIALS["app_token"],
            telemetrx_base_url=TELEMETRX_CREDENTIALS["telemetrx_base_url"]
        )
        
        print("✅ SUCCESS: Telemetry data sent successfully!")
        if result:
            print(f"📋 API Response: {result}")
        
        return True
        
    except Exception as e:
        print(f"❌ FAILED: {str(e)}")
        print(f"Error type: {type(e).__name__}")
        return False

def validate_credentials():
    """Validate that credentials are properly configured"""
    
    print("🔍 Validating Credentials...")
    
    missing_creds = []
    for key, value in TELEMETRX_CREDENTIALS.items():
        if not value or "YOUR_" in str(value):
            missing_creds.append(key)
    
    if missing_creds:
        print("❌ Missing or placeholder credentials:")
        for cred in missing_creds:
            print(f"   - {cred}: {TELEMETRX_CREDENTIALS[cred]}")
        print("\n📝 Please update the CREDENTIALS section in this script with your actual values.")
        return False
    
    print("✅ All credentials configured")
    return True

def main():
    """Main test execution"""
    
    print("🚀 TelemetrX Library v0.2.0 - Basic Test Script")
    print("=" * 60)
    
    # Validate credentials first
    if not validate_credentials():
        print("\n❌ Test aborted due to missing credentials")
        sys.exit(1)
    
    # Run the basic test
    success = run_basic_test()
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 OVERALL RESULT: SUCCESS")
        print("✅ Your TelemetrX library is working correctly!")
    else:
        print("💥 OVERALL RESULT: FAILED")
        print("❌ Please check the error messages above and verify:")
        print("   - Your credentials are correct")
        print("   - Your app is registered in TelemetrX")
        print("   - The API endpoint is accessible")
        print("   - Your network connection is working")
    
    print("=" * 50)

if __name__ == "__main__":
    main()
