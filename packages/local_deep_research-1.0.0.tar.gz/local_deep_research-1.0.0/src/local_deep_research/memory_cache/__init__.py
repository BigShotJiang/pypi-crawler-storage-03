"""Dogpile cache implementation for Local Deep Research."""
