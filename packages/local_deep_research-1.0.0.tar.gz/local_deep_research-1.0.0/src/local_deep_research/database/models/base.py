"""
Base model configuration for SQLAlchemy.
"""

from sqlalchemy.orm import declarative_base

Base = declarative_base()
