"""Authentication tests for LDR."""
