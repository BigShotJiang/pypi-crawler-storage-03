from pyiron_base.cli.control import main

main()
