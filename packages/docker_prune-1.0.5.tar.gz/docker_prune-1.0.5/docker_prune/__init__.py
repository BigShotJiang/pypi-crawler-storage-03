""" Prune Docker Resources """
from .version import __version__

__title__ = 'docker-prune'
