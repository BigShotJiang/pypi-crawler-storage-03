""" package version """
# pylint: disable=C0103
__version__ = '1.0.5'
version = __version__
