# Vision Data Curation

This repository is dedicated to building a robust and efficient pipeline for curating large-scale image datasets,
preparing them for various machine learning and computer vision tasks.

## License

This project is licensed under the Apache-2.0 License - see the [LICENSE](https://gitlab.com/birder/vision-data-curation/blob/main/LICENSE) file for details.
