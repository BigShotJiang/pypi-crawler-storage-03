"""
GeoPicTagReader
"""

__version__ = "1.8.0"
