def main():
    print("Hello from fastapi-fsp!")


if __name__ == "__main__":
    main()
