====
TODO
====
Work to do on transpolibre.

* Fix broken PDF languages: ar fr he ja zh.
* Fix missing fonts for PDF generation.
* Fix --help in docs for multiple languages.

LibreTranslate
--------------
* Fix formatting of URLs.
* Fix formatting of inline code with backticks.

Ollama
------
* Add docs for using ollama.
* Write better prompt.

Local
-----
* Add docs for supporting local model.
* Write better prompt.

Models
------
* Add a Models page.
* Note which ones work best.
* Note licenses.

App Translation
---------------
* Update app translation with new files.
