=======
License
=======
This code, documentation files, and text are released under the
`Apache 2.0 license <https://www.apache.org/licenses/LICENSE-2.0>`_
and the
`Creative Commons CC BY-SA 4.0 International License
<https://creativecommons.org/licenses/by-sa/4.0/>`_.

You may use this code, files, and text under either license.

Upstream sources under their respective copyrights.

Unofficial project, not related to upstream projects.

Copyright (C) 2025, Jeff Moe
