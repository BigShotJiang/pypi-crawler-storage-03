=========
Languages
=========
Application Languages
---------------------
The application is written in English.

.. note:: This application is written in English and uses AI machine translation for other languages.

The application is translated into the following languages:

* Arabic (ar)
* Bengali (bn)
* German (de)
* Spanish (es)
* French (fr)
* Hindi (hi)
* Indonesian (id)
* Italian (it)
* Japanese (ja)
* Korean (ko)
* Polish (pl)
* Portuguese (pt)
* Russian (ru)
* Turkish (tr)
* Chinese (zh)

Documentation Languages
-----------------------
The documentation is written in English.

* English (en)
  `<https://transpolibre.org/en/>`_

.. note:: This documentation is written in English and uses AI machine translation for other languages.

It is machine (AI) translated into the following languages:

* Arabic (ar)
  `<https://transpolibre.org/ar/>`_

* Bengali (bn)
  `<https://transpolibre.org/bn/>`_

* German (de)
  `<https://transpolibre.org/de/>`_

* Spanish (es)
  `<https://transpolibre.org/es/>`_

* French (fr)
  `<https://transpolibre.org/fr/>`_

* Hindi (hi)
  `<https://transpolibre.org/hi/>`_

* Italian (it)
  `<https://transpolibre.org/it/>`_

* Japanese (ja)
  `<https://transpolibre.org/ja/>`_

* Korean (ko)
  `<https://transpolibre.org/ko/>`_

* Polish (pl)
  `<https://transpolibre.org/pl/>`_

* Portuguese (pt)
  `<https://transpolibre.org/pt/>`_

* Russian (ru)
  `<https://transpolibre.org/ru/>`_

* Turkish (tr)
  `<https://transpolibre.org/tr/>`_

* Chinese (zh)
  `<https://transpolibre.org/zh/>`_
