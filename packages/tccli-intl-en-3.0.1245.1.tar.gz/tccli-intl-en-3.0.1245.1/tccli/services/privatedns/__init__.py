# -*- coding: utf-8 -*-

from tccli.services.privatedns.privatedns_client import action_caller
    