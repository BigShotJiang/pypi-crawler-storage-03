import logging

logger = logging.getLogger('ezbeq.apis')
