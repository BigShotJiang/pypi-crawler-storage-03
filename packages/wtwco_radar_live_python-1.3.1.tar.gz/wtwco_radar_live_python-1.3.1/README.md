# WTWCO Radar Live Python 

## Overview
This package includes the dependencies needed to allow a model to be scored.

## Prerequisites
- Python >=3.9, <3.13