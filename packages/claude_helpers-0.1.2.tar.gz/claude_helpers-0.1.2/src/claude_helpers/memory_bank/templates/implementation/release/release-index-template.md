# Implementation Plan: {Release Name}

## Architecture Reference
→ `/architecture/releases/{release-name}/overview.md`

## Components Breakdown

### Component-01: {Component Name}
**Epics:** [{epic-01}, {epic-02}]
**Outcome:** {что будет реализовано}

### Component-02: {Component Name}
**Epics:** [{epic-01}]
**Outcome:** {что будет реализовано}

## Dependencies
- {Внешняя зависимость или блокер}
- {Предварительное условие}

## Rollout Strategy
{Как будем выкатывать: фазы, порядок}