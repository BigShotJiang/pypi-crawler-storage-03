__all__ = ["AutoCRUD"]
from autocrud.crud.core import AutoCRUD

__version__ = "0.3.1"
