This module provides a barcode reader interface for stock module.

This module contains a base wizard read barcode that can be extended by
other modules.

This module also makes use of this wizard for providing barcode support for
doing inventories and picking operations.

This module provides configuring barcodes for barcode actions.


