* Excute action_done() method outside onchange environment.
* Allow create product when a barcode has not been found.
* Allow to select picking reading its barcode.
* Allow to select multiple pickings to process scanned products.
