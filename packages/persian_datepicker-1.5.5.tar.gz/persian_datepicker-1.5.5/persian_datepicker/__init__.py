# persian_datepicker/__init__.py
from .persian_datepicker import PersianDatePicker
