"""
MCP server for Kubernetes support bundles.
"""

__version__ = "0.1.0"
