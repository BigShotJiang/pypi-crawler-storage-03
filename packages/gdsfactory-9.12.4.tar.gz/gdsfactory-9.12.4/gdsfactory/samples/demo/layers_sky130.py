if __name__ == "__main__":
    import sky130 as pdk

    c = pdk.components.sky130_fd_sc_hd__a21o_1()
    c.show()
    # scene = c.to_3d()
    # scene.show()
