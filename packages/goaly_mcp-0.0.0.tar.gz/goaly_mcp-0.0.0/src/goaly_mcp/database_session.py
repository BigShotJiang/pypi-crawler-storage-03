"""
Session management utilities for database operations

This module provides decorators and context managers to handle SQLAlchemy sessions
properly, ensuring objects remain attached and preventing detached instance errors.
"""

import functools
from collections.abc import Callable, Generator
from contextlib import contextmanager
from typing import Any, Concatenate, ParamSpec, TypeVar

from sqlalchemy.orm import Session

from goaly_mcp.database import SessionLocal

T = TypeVar("T")
P = ParamSpec("P")
RepositorySelf = TypeVar("RepositorySelf")


@contextmanager
def managed_session() -> Generator[Session, None, None]:
    """
    Context manager for database sessions with proper cleanup.

    Provides a session that automatically commits successful operations
    and rolls back on exceptions, with guaranteed cleanup.

    Yields:
        Session: SQLAlchemy database session
    """
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def _detach_object(obj: Any) -> Any:
    """
    Detach a SQLAlchemy object from its session.

    Expunges the object so it can be used outside of the session context
    without causing detached instance errors while preserving loaded relationships.

    Args:
        obj: SQLAlchemy model instance to detach

    Returns:
        The detached object
    """
    if obj is not None and hasattr(obj, "__table__"):
        # Expunge from session instead of make_transient to preserve relationships
        session = obj._sa_instance_state.session
        if session is not None:
            session.expunge(obj)
    return obj


def _detach_objects(objects: list[Any]) -> list[Any]:
    """
    Detach multiple SQLAlchemy objects from their session.

    Args:
        objects: List of SQLAlchemy model instances to detach

    Returns:
        List of detached objects
    """
    return [_detach_object(obj) for obj in objects]


def with_session(
    func: Callable[Concatenate[RepositorySelf, Session, P], T],
) -> Callable[Concatenate[RepositorySelf, P], T]:
    """
    Decorator for repository methods that return a single object.

    Automatically manages database sessions and detaches returned objects
    to prevent SQLAlchemy detached instance errors.

    Usage:
        @with_session
        def get_by_id(self, session: Session, item_id: int) -> Model | None:
            # Decorator removes 'session' parameter from external API
            pass

    Args:
        func: Repository method that expects session as first parameter after self

    Returns:
        Decorated method with session parameter removed from signature
    """

    @functools.wraps(func)
    def wrapper(self: RepositorySelf, *args: P.args, **kwargs: P.kwargs) -> T:
        with managed_session() as session:
            # Pass session as first argument after self
            result = func(self, session, *args, **kwargs)

            # Detach single object if it's a model instance
            if result is not None and hasattr(result, "__table__"):
                result = _detach_object(result)

            return result

    return wrapper


def with_session_list(
    func: Callable[Concatenate[RepositorySelf, Session, P], list[T]],
) -> Callable[Concatenate[RepositorySelf, P], list[T]]:
    """
    Decorator for repository methods that return a list of objects.

    Automatically manages database sessions and detaches all returned objects
    to prevent SQLAlchemy detached instance errors.

    Usage:
        @with_session_list
        def list_all(self, session: Session) -> list[Model]:
            # Decorator removes 'session' parameter from external API
            pass

    Args:
        func: Repository method that expects session as first parameter after self

    Returns:
        Decorated method with session parameter removed from signature
    """

    @functools.wraps(func)
    def wrapper(self: RepositorySelf, *args: P.args, **kwargs: P.kwargs) -> list[T]:
        with managed_session() as session:
            # Pass session as first argument after self
            result = func(self, session, *args, **kwargs)

            # Detach all objects in the list if they're model instances
            if isinstance(result, list):
                result = [
                    _detach_object(obj) if obj is not None and hasattr(obj, "__table__") else obj for obj in result
                ]

            return result

    return wrapper


def with_session_raw(
    func: Callable[Concatenate[RepositorySelf, Session, P], T],
) -> Callable[Concatenate[RepositorySelf, P], T]:
    """
    Decorator for repository methods that return raw data (no detachment needed).

    Automatically manages database sessions without object detachment.
    Useful for methods that return primitive types, counts, or boolean values.

    Usage:
        @with_session_raw
        def delete(self, session: Session, item_id: int) -> bool:
            # Decorator removes 'session' parameter from external API
            pass

    Args:
        func: Repository method that expects session as first parameter after self

    Returns:
        Decorated method with session parameter removed from signature
    """

    @functools.wraps(func)
    def wrapper(self: RepositorySelf, *args: P.args, **kwargs: P.kwargs) -> T:
        with managed_session() as session:
            # Pass session as first argument after self
            return func(self, session, *args, **kwargs)

    return wrapper
