"""
Structured logging configuration for TaskMaster MCP

This module provides structured logging with JSON formatting for better
observability and debugging in production environments.
"""

import logging
import sys
from datetime import datetime
from typing import Any

from pythonjsonlogger import jsonlogger


class JSONFormatter(jsonlogger.JsonFormatter):
    """Custom JSON formatter for structured logging"""

    def add_fields(self, log_record: dict[str, Any], record: logging.LogRecord, message_dict: dict[str, Any]) -> None:
        """
        Add custom fields to the log record

        Args:
            log_record: The log record dictionary to add fields to
            record: The original LogRecord object
            message_dict: The message dictionary from the log call
        """
        super().add_fields(log_record, record, message_dict)

        # Add timestamp in ISO format
        if not log_record.get("timestamp"):
            log_record["timestamp"] = datetime.utcnow().isoformat() + "Z"

        # Add log level
        if log_record.get("level"):
            log_record["level"] = log_record["level"].upper()
        else:
            log_record["level"] = record.levelname.upper()

        # Add logger name
        log_record["logger"] = record.name

        # Add module and function context
        log_record["module"] = record.module
        log_record["function"] = record.funcName
        log_record["line"] = record.lineno

        # Add process and thread information
        log_record["process_id"] = record.process
        log_record["thread_id"] = record.thread

        # Ensure message is always present
        if not log_record.get("message"):
            log_record["message"] = record.getMessage()


class LoggerMixin:
    """
    Mixin class to provide structured logging capabilities to repositories

    This mixin adds a logger property and convenience methods for logging
    CRUD operations with structured data.
    """

    @property
    def logger(self) -> logging.Logger:
        """Get a logger instance for this class"""
        if not hasattr(self, "_logger"):
            self._logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__name__}")
        return self._logger

    def log_operation(self, operation: str, level: str = "info", **context: Any) -> None:
        """
        Log an operation with structured context

        Args:
            operation: The operation being performed (e.g., 'create', 'update', 'delete')
            level: Log level ('debug', 'info', 'warning', 'error', 'critical')
            **context: Additional context to include in the log
        """
        # Filter out reserved logging fields to avoid conflicts
        reserved_fields = {
            "name",
            "message",
            "asctime",
            "levelname",
            "levelno",
            "pathname",
            "filename",
            "module",
            "lineno",
            "funcName",
            "created",
            "msecs",
            "relativeCreated",
            "thread",
            "threadName",
            "processName",
            "process",
        }

        filtered_context = {k: v for k, v in context.items() if k not in reserved_fields}

        log_data = {"operation": operation, "repository": self.__class__.__name__, **filtered_context}

        log_method = getattr(self.logger, level.lower(), self.logger.info)
        log_method(f"Repository operation: {operation}", extra=log_data)

    def log_create(self, entity_type: str, entity_id: Any | None = None, **context: Any) -> None:
        """Log a create operation"""
        self.log_operation("create", entity_type=entity_type, entity_id=entity_id, **context)

    def log_read(self, entity_type: str, entity_id: Any | None = None, **context: Any) -> None:
        """Log a read operation"""
        self.log_operation("read", level="debug", entity_type=entity_type, entity_id=entity_id, **context)

    def log_update(self, entity_type: str, entity_id: Any, changes: dict[str, Any], **context: Any) -> None:
        """Log an update operation"""
        self.log_operation("update", entity_type=entity_type, entity_id=entity_id, changes=changes, **context)

    def log_delete(self, entity_type: str, entity_id: Any, **context: Any) -> None:
        """Log a delete operation"""
        self.log_operation("delete", entity_type=entity_type, entity_id=entity_id, **context)

    def log_error(self, operation: str, error: Exception, **context: Any) -> None:
        """Log an error that occurred during an operation"""
        self.log_operation(
            operation, level="error", error_type=type(error).__name__, error_message=str(error), **context
        )


def setup_logging(
    level: str = "INFO", format_type: str = "json", include_stdout: bool = True, log_file: str | None = None
) -> None:
    """
    Configure structured logging for the application

    Args:
        level: Log level ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')
        format_type: Format type ('json' or 'text')
        include_stdout: Whether to include stdout handler
        log_file: Optional log file path
    """
    # Clear any existing handlers
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    # Set log level
    log_level = getattr(logging, level.upper(), logging.INFO)
    root_logger.setLevel(log_level)

    # Configure formatter
    formatter: logging.Formatter
    if format_type.lower() == "json":
        formatter = JSONFormatter(
            fmt="%(timestamp)s %(level)s %(logger)s %(message)s", rename_fields={"levelname": "level", "name": "logger"}
        )
    else:
        # Text formatter for development
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s")

    # Add stdout handler if requested
    if include_stdout:
        stdout_handler = logging.StreamHandler(sys.stdout)
        stdout_handler.setLevel(log_level)
        stdout_handler.setFormatter(formatter)
        root_logger.addHandler(stdout_handler)

    # Add file handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    # Log configuration
    logger = logging.getLogger(__name__)
    logger.info(
        "Logging configured",
        extra={"level": level, "format_type": format_type, "include_stdout": include_stdout, "log_file": log_file},
    )


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with the specified name

    Args:
        name: Logger name (typically __name__ from the calling module)

    Returns:
        Logger instance
    """
    return logging.getLogger(name)


# Example usage context manager for operation logging
class LogOperation:
    """
    Context manager for logging operations with timing

    Usage:
        with LogOperation(logger, "complex_calculation") as log_ctx:
            # Perform operation
            result = do_complex_work()
            log_ctx.add_context(result_count=len(result))
    """

    def __init__(self, logger: logging.Logger, operation: str, level: str = "info"):
        self.logger = logger
        self.operation = operation
        self.level = level
        self.start_time: float | None = None
        self.context: dict[str, Any] = {}

    def __enter__(self) -> "LogOperation":
        import time

        self.start_time = time.time()
        self.logger.info(
            f"Starting operation: {self.operation}", extra={"operation": self.operation, "status": "started"}
        )
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        import time

        duration = time.time() - (self.start_time or 0)

        if exc_type:
            self.logger.error(
                f"Operation failed: {self.operation}",
                extra={
                    "operation": self.operation,
                    "status": "failed",
                    "duration_seconds": duration,
                    "error_type": exc_type.__name__,
                    "error_message": str(exc_val),
                    **self.context,
                },
            )
        else:
            log_method = getattr(self.logger, self.level.lower(), self.logger.info)
            log_method(
                f"Operation completed: {self.operation}",
                extra={
                    "operation": self.operation,
                    "status": "completed",
                    "duration_seconds": duration,
                    **self.context,
                },
            )

    def add_context(self, **context: Any) -> None:
        """Add additional context to the log entry"""
        self.context.update(context)
