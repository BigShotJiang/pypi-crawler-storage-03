"""
MCP Tools for TaskMaster - Goal and Task Management (Sync Version)
"""

import asyncio
import contextlib
import json
import logging
import queue
import threading
from collections.abc import Callable
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from goaly_mcp.database import SessionLocal
from goaly_mcp.models import Goal, Task, TaskDependency, TaskStatus
from goaly_mcp.repositories import GoalRepository, TaskRepository

# Set up logger
logger = logging.getLogger(__name__)


class SSENotificationQueue:
    """Thread-safe SSE notification queue with background worker"""

    def __init__(self):
        self._queue: queue.Queue = queue.Queue()
        self._worker_thread: threading.Thread | None = None
        self._shutdown_event = threading.Event()
        self._running = False

    def start(self) -> None:
        """Start the background worker thread"""
        if self._running:
            logger.warning("SSE notification queue is already running")
            return

        self._running = True
        self._shutdown_event.clear()
        self._worker_thread = threading.Thread(target=self._worker_loop, name="SSENotificationWorker", daemon=True)
        self._worker_thread.start()
        logger.info("SSE notification queue worker started")

    def stop(self) -> None:
        """Stop the background worker thread gracefully"""
        if not self._running:
            return

        logger.info("Stopping SSE notification queue worker...")
        self._running = False
        self._shutdown_event.set()

        # Add sentinel value to wake up worker
        with contextlib.suppress(queue.Full):
            self._queue.put(None, timeout=1.0)

        # Wait for worker to finish
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=5.0)
            if self._worker_thread.is_alive():
                logger.warning("SSE worker thread did not shutdown gracefully")

        logger.info("SSE notification queue worker stopped")

    def enqueue_notification(self, coro_func: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        """Enqueue an SSE notification coroutine to be executed by the worker"""
        if not self._running:
            logger.warning("Cannot enqueue notification: worker not running")
            return

        try:
            # Store the coroutine function and its arguments
            notification_data = {"coro_func": coro_func, "args": args, "kwargs": kwargs}
            self._queue.put(notification_data, timeout=1.0)
            logger.debug(f"Enqueued SSE notification: {coro_func.__name__}")
        except queue.Full:
            logger.error("SSE notification queue is full, dropping notification")
        except Exception as e:
            logger.error(f"Failed to enqueue SSE notification: {e}")

    def _worker_loop(self) -> None:
        """Background worker loop to process SSE notifications"""
        logger.info("SSE notification worker loop started")

        while self._running and not self._shutdown_event.is_set():
            try:
                # Get notification with timeout to allow for shutdown checks
                try:
                    notification_data = self._queue.get(timeout=1.0)
                except queue.Empty:
                    continue

                # Check for sentinel value (shutdown signal)
                if notification_data is None:
                    logger.debug("Received shutdown signal in SSE worker")
                    break

                # Process the notification
                try:
                    coro_func = notification_data["coro_func"]
                    args = notification_data["args"]
                    kwargs = notification_data["kwargs"]

                    # Create and run the coroutine
                    coro = coro_func(*args, **kwargs)
                    asyncio.run(coro)
                    logger.debug(f"Successfully processed SSE notification: {coro_func.__name__}")

                except Exception as e:
                    logger.error(f"Error processing SSE notification: {e}", exc_info=True)
                finally:
                    self._queue.task_done()

            except Exception as e:
                logger.error(f"Unexpected error in SSE worker loop: {e}", exc_info=True)

        logger.info("SSE notification worker loop ended")


# Global SSE notification queue instance
_sse_queue: SSENotificationQueue | None = None


def get_sse_queue() -> SSENotificationQueue:
    """Get or create the global SSE notification queue"""
    global _sse_queue
    if _sse_queue is None:
        _sse_queue = SSENotificationQueue()
        _sse_queue.start()
    return _sse_queue


def send_sse_notification(coro_func: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
    """Send SSE notification using the background queue"""
    try:
        sse_queue = get_sse_queue()
        sse_queue.enqueue_notification(coro_func, *args, **kwargs)
    except Exception as e:
        logger.error(f"Failed to send SSE notification: {e}")


def shutdown_sse_queue() -> None:
    """Shutdown the SSE notification queue"""
    global _sse_queue
    if _sse_queue is not None:
        _sse_queue.stop()
        _sse_queue = None


# Helper function to update task dependency blocking status
def update_task_blocking_status(db_session: Session, task_id: int) -> None:
    """Update the blocking status of all task dependencies for a given task."""
    # Get all dependencies where this task is the dependency
    dependencies = db_session.execute(select(TaskDependency).where(TaskDependency.dependency_task_id == task_id))

    # Get the task status
    task_result = db_session.execute(select(Task).where(Task.id == task_id))
    task = task_result.scalars().first()

    if not task:
        return

    # Update blocking status based on task completion
    is_blocking = task.status not in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]

    for dependency in dependencies.scalars().all():
        dependency.is_blocked = is_blocking  # type: ignore[assignment]

    db_session.commit()


# Helper function to calculate task importance
def calculate_task_importance(db_session: Session, task_id: int) -> int:
    """Calculate task importance based on how many other tasks depend on it."""
    result = db_session.execute(
        select(func.count(TaskDependency.id)).where(TaskDependency.dependency_task_id == task_id)
    )
    return result.scalar() or 0


def register_mcp_tools(mcp_server: Any) -> None:
    """Register all MCP tools with the server"""

    goal_repo = GoalRepository()
    task_repo = TaskRepository()

    # Import SSE notification functions
    from .api.sse import (
        notify_dependency_added,
        notify_goal_created,
        notify_goal_updated,
        notify_task_created,
        notify_task_updated,
    )

    # Goal Management Tools
    @mcp_server.tool(name="create_goal", description="Create a new goal with a description.")
    def create_goal(description: str) -> dict[str, Any]:
        """Create a new goal with the given description."""
        try:
            goal = goal_repo.create(description=description)

            result = {
                "id": goal.id,
                "description": goal.description,
                "is_complete": goal.is_complete,
                "created_at": goal.created_at.isoformat(),
                "updated_at": goal.updated_at.isoformat(),
            }

            # Send SSE notification
            send_sse_notification(notify_goal_created, result)

            return result
        except Exception as e:
            print(f"Error in create_goal: {e}")
            raise RuntimeError(f"Failed to create goal: {e!s}") from e

    @mcp_server.tool(name="update_goal_status", description="Update the completion status of a goal.")
    def update_goal_status(goal_id: int, is_complete: bool) -> dict[str, Any]:
        """Update the completion status of a goal."""
        try:
            with SessionLocal() as db_session:
                goal_result = db_session.execute(select(Goal).where(Goal.id == goal_id))
                goal = goal_result.scalars().first()

                if not goal:
                    raise ValueError(f"Goal with ID {goal_id} not found")

                goal.is_complete = is_complete  # type: ignore[assignment]
                db_session.commit()
                db_session.refresh(goal)

                result_data = {
                    "id": goal.id,
                    "description": goal.description,
                    "is_complete": goal.is_complete,
                    "updated_at": goal.updated_at.isoformat(),
                }

                # Send SSE notification
                send_sse_notification(notify_goal_updated, result_data)

                return result_data
        except Exception as e:
            print(f"Error in update_goal_status: {e}")
            raise RuntimeError(f"Failed to update goal status: {e!s}") from e

    @mcp_server.tool(name="list_goals", description="List all goals with optional filtering by completion status.")
    def list_goals(completed_only: bool = False, incomplete_only: bool = False) -> list[dict[str, Any]]:
        """List all goals with optional filtering."""
        try:
            with SessionLocal() as db_session:
                query = select(Goal).options(selectinload(Goal.tasks))

                if completed_only:
                    query = query.where(Goal.is_complete == True)
                elif incomplete_only:
                    query = query.where(Goal.is_complete == False)

                result = db_session.execute(query.order_by(Goal.created_at.desc()))
                goals = result.scalars().all()

                return [
                    {
                        "id": goal.id,
                        "description": goal.description,
                        "is_complete": goal.is_complete,
                        "task_count": len(goal.tasks),
                        "created_at": goal.created_at.isoformat(),
                        "updated_at": goal.updated_at.isoformat(),
                    }
                    for goal in goals
                ]
        except Exception as e:
            print(f"Error in list_goals: {e}")
            raise RuntimeError(f"Failed to list goals: {e!s}") from e

    # Task Management Tools
    @mcp_server.tool(name="create_task", description="Create a new task within a goal.")
    def create_task(goal_id: int, name: str, instructions: str = "", owner: str | None = None) -> dict[str, Any]:
        """Create a new task within a goal."""
        try:
            # Determine initial status based on owner
            status = TaskStatus.OWNED if owner else TaskStatus.AVAILABLE

            task = task_repo.create(goal_id=goal_id, name=name, instructions=instructions, status=status, owner=owner)

            result = {
                "id": task.id,
                "goal_id": task.goal_id,
                "name": task.name,
                "instructions": task.instructions,
                "status": task.status.value,
                "owner": task.owner,
                "created_at": task.created_at.isoformat(),
                "updated_at": task.updated_at.isoformat(),
            }

            # Send SSE notification
            send_sse_notification(notify_task_created, result)

            return result
        except Exception as e:
            print(f"Error in create_task: {e}")
            raise RuntimeError(f"Failed to create task: {e!s}") from e

    @mcp_server.tool(name="update_task", description="Update task properties including status and owner.")
    def update_task(
        task_id: int,
        name: str | None = None,
        instructions: str | None = None,
        status: str | None = None,
        owner: str | None = None,
    ) -> dict[str, Any]:
        """Update task properties."""
        try:
            update_data = {}
            if name is not None:
                update_data["name"] = name
            if instructions is not None:
                update_data["instructions"] = instructions
            if status is not None:
                update_data["status"] = status
            if owner is not None:
                update_data["owner"] = owner

            task = task_repo.update(task_id, **update_data)

            if not task:
                raise ValueError(f"Task with ID {task_id} not found")

            result = {
                "id": task.id,
                "goal_id": task.goal_id,
                "name": task.name,
                "instructions": task.instructions,
                "status": task.status.value,
                "owner": task.owner,
                "updated_at": task.updated_at.isoformat(),
            }

            # Send SSE notification
            send_sse_notification(notify_task_updated, result)

            return result
        except Exception as e:
            print(f"Error in update_task: {e}")
            raise RuntimeError(f"Failed to update task: {e!s}") from e

    @mcp_server.tool(name="add_task_dependency", description="Add a dependency relationship between tasks.")
    def add_task_dependency(
        dependent_task_id: int, dependency_task_id: int, required_data: str | None = None
    ) -> dict[str, Any]:
        """Add a dependency relationship where dependent_task depends on dependency_task."""
        try:
            dependency = task_repo.add_dependency(
                dependent_task_id=dependent_task_id, dependency_task_id=dependency_task_id, required_data=required_data
            )

            result = {
                "id": dependency.id,
                "dependent_task_id": dependency.dependent_task_id,
                "dependency_task_id": dependency.dependency_task_id,
                "required_data": dependency.required_data,
                "is_blocked": dependency.is_blocked,
                "created_at": dependency.created_at.isoformat(),
            }

            # Send SSE notification
            send_sse_notification(notify_dependency_added, result)

            return result
        except ValueError as e:
            if "Dependency already exists" in str(e):
                # Gracefully handle duplicate dependency attempts
                print(f"Dependency already exists between tasks {dependent_task_id} -> {dependency_task_id}")
                return {
                    "message": f"Dependency already exists between task {dependent_task_id} and task {dependency_task_id}",
                    "dependent_task_id": dependent_task_id,
                    "dependency_task_id": dependency_task_id,
                    "required_data": required_data,
                    "status": "already_exists",
                }
            else:
                print(f"ValueError in add_task_dependency: {e}")
                raise RuntimeError(f"Invalid dependency configuration: {e!s}") from e
        except Exception as e:
            print(f"Error in add_task_dependency: {e}")
            raise RuntimeError(f"Failed to add task dependency: {e!s}") from e

    @mcp_server.tool(name="search_tasks", description="Search and filter tasks with sorting options.")
    def search_tasks(
        goal_id: int | None = None,
        status: str | None = None,
        owner: str | None = None,
        available_only: bool = False,
        sort_by: str = "importance",  # importance, created_at, name
    ) -> list[dict[str, Any]]:
        """Search and filter tasks with various criteria."""
        try:
            tasks = task_repo.search(goal_id=goal_id, status=status, owner=owner, available_only=available_only)

            # Calculate importance for each task and build result
            task_results: list[dict[str, Any]] = []
            with SessionLocal() as db_session:
                for task in tasks:
                    importance = calculate_task_importance(db_session, int(task.id))
                    dependency_count = len(task.dependencies)
                    is_leaf_node = dependency_count == 0

                    task_results.append(
                        {
                            "id": task.id,
                            "goal_id": task.goal_id,
                            "name": task.name,
                            "instructions": task.instructions,
                            "status": task.status.value,
                            "owner": task.owner,
                            "importance": importance,
                            "dependency_count": dependency_count,
                            "is_leaf_node": is_leaf_node,
                            "created_at": task.created_at.isoformat(),
                            "updated_at": task.updated_at.isoformat(),
                        }
                    )

            # Apply sorting
            if sort_by == "importance":
                task_results.sort(key=lambda x: (x["importance"], x["created_at"]), reverse=True)
            elif sort_by == "created_at":
                task_results.sort(key=lambda x: x["created_at"], reverse=True)
            elif sort_by == "name":
                task_results.sort(key=lambda x: x["name"])

            return task_results
        except Exception as e:
            print(f"Error in search_tasks: {e}")
            raise RuntimeError(f"Failed to search tasks: {e!s}") from e

    @mcp_server.tool(
        name="get_task_details_with_dependencies",
        description="Get detailed task information including all dependencies and dependents.",
    )
    def get_task_details_with_dependencies(task_id: int) -> dict[str, Any]:
        """Get comprehensive task details including dependency graph information."""
        try:
            # Use a single session for all database operations to avoid DetachedInstanceError
            with SessionLocal() as db_session:
                # Get task with all relationships in a single query
                result = db_session.execute(
                    select(Task)
                    .options(
                        selectinload(Task.dependencies).selectinload(TaskDependency.dependency_task),
                        selectinload(Task.dependents).selectinload(TaskDependency.dependent_task),
                        selectinload(Task.goal),
                    )
                    .where(Task.id == task_id)
                )
                task = result.scalars().first()

                if not task:
                    raise ValueError(f"Task with ID {task_id} not found")

                # Get dependencies (tasks this task depends on)
                dependencies: list[dict[str, Any]] = []
                for dep in task.dependencies:
                    dependencies.append(
                        {
                            "id": dep.id,
                            "dependency_task": {
                                "id": dep.dependency_task.id,
                                "name": dep.dependency_task.name,
                                "status": dep.dependency_task.status.value,
                            },
                            "required_data": dep.required_data,
                            "is_blocked": dep.is_blocked,
                        }
                    )

                # Get dependents (tasks that depend on this task)
                dependents: list[dict[str, Any]] = []
                for dep in task.dependents:
                    dependents.append(
                        {
                            "id": dep.id,
                            "dependent_task": {
                                "id": dep.dependent_task.id,
                                "name": dep.dependent_task.name,
                                "status": dep.dependent_task.status.value,
                            },
                            "required_data": dep.required_data,
                            "is_blocked": dep.is_blocked,
                        }
                    )

                # Calculate importance within the same session
                importance = calculate_task_importance(db_session, task_id)

                # Extract all data while session is active
                task_data = {
                    "id": task.id,
                    "goal": {
                        "id": task.goal.id,
                        "description": task.goal.description,
                        "is_complete": task.goal.is_complete,
                    },
                    "name": task.name,
                    "instructions": task.instructions,
                    "status": task.status.value,
                    "owner": task.owner,
                    "importance": importance,
                    "is_leaf_node": len(dependencies) == 0,
                    "dependencies": dependencies,
                    "dependents": dependents,
                    "created_at": task.created_at.isoformat(),
                    "updated_at": task.updated_at.isoformat(),
                }

                return task_data
        except Exception as e:
            print(f"Error in get_task_details_with_dependencies: {e}")
            raise RuntimeError(f"Failed to get task details: {e!s}") from e

    # Resource endpoints for exposing tasks by goal
    @mcp_server.resource("tasks://goal/{goal_id}")
    def get_tasks_resource(goal_id: str) -> str:
        """Resource endpoint to get tasks partitioned by goal."""
        try:
            # Convert goal_id to integer
            try:
                goal_id_int = int(goal_id)
            except ValueError as ve:
                raise ValueError(f"Invalid goal ID: {goal_id}") from ve

            with SessionLocal() as db_session:
                # Get goal and tasks
                goal_result = db_session.execute(
                    select(Goal).options(selectinload(Goal.tasks)).where(Goal.id == goal_id_int)
                )
                goal = goal_result.scalars().first()

                if not goal:
                    raise ValueError(f"Goal with ID {goal_id_int} not found")

                # Build task data with dependencies
                tasks_data: list[dict[str, Any]] = []
                for task in goal.tasks:
                    importance = calculate_task_importance(db_session, int(task.id))

                    # Get dependency info
                    deps_result = db_session.execute(
                        select(TaskDependency).where(TaskDependency.dependent_task_id == task.id)
                    )
                    dependency_count = len(deps_result.scalars().all())

                    tasks_data.append(
                        {
                            "id": task.id,
                            "name": task.name,
                            "instructions": task.instructions,
                            "status": task.status.value,
                            "owner": task.owner,
                            "importance": importance,
                            "dependency_count": dependency_count,
                            "is_leaf_node": dependency_count == 0,
                            "created_at": task.created_at.isoformat(),
                            "updated_at": task.updated_at.isoformat(),
                        }
                    )

                # Sort by importance
                tasks_data.sort(key=lambda x: x["importance"], reverse=True)

                resource_data = {
                    "goal": {"id": goal.id, "description": goal.description, "is_complete": goal.is_complete},
                    "tasks": tasks_data,
                    "summary": {
                        "total_tasks": len(tasks_data),
                        "available_tasks": len([t for t in tasks_data if t["status"] == "available"]),
                        "completed_tasks": len([t for t in tasks_data if t["status"] == "completed"]),
                        "leaf_nodes": len([t for t in tasks_data if t["is_leaf_node"]]),
                    },
                }

                return json.dumps(resource_data, indent=2)

        except Exception as e:
            print(f"Error in get_tasks_resource: {e}")
            raise RuntimeError(f"Failed to get tasks resource: {e!s}") from e
