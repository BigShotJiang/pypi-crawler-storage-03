"""
Frontend asset loader for serving bundled React application.

This module provides utilities for serving the React frontend from bundled
resources in production or from the filesystem in development.
"""

import mimetypes
from pathlib import Path

from fastapi import HTTPException
from fastapi.responses import Response

from goaly_mcp.frontend_assets import (
    frontend_assets_available,
    get_frontend_asset_content,
    get_frontend_asset_text,
    list_frontend_assets,
)


class FrontendLoader:
    """Handles loading and serving frontend assets with fallback support."""

    def __init__(self):
        """Initialize the frontend loader."""
        self._assets_available = frontend_assets_available()

    def is_available(self) -> bool:
        """Check if frontend assets are available."""
        return self._assets_available

    def get_index_html(self) -> str:
        """
        Get the main index.html content for the SPA.

        Returns:
            HTML content as string

        Raises:
            HTTPException: If index.html is not available
        """
        if not self._assets_available:
            raise HTTPException(
                status_code=503, detail="Frontend assets not available. Run 'pnpm build' in the frontend directory."
            )

        try:
            return get_frontend_asset_text("index.html")
        except FileNotFoundError:
            raise HTTPException(
                status_code=503, detail="Frontend index.html not found. Please ensure the frontend is built."
            )

    def get_asset(self, asset_path: str) -> Response:
        """
        Get a frontend asset and return it as a FastAPI Response.

        Args:
            asset_path: Path to the asset relative to the frontend build directory

        Returns:
            FastAPI Response with the asset content and proper headers

        Raises:
            HTTPException: If the asset is not found or frontend is not available
        """
        if not self._assets_available:
            raise HTTPException(status_code=503, detail="Frontend assets not available")

        # Security: prevent path traversal
        if ".." in asset_path or asset_path.startswith("/"):
            raise HTTPException(status_code=404, detail="Asset not found")

        try:
            content = get_frontend_asset_content(asset_path)

            # Determine content type
            content_type = self._get_content_type(asset_path)

            # Set appropriate headers
            headers = {
                "Content-Type": content_type,
            }

            # Add caching headers for static assets
            if asset_path.startswith("static/"):
                headers.update(
                    {
                        "Cache-Control": "public, max-age=31536000, immutable",  # 1 year
                        "ETag": f'"{hash(content)}"',
                    }
                )
            else:
                # For non-static files (like manifest.json), use shorter cache
                headers["Cache-Control"] = "public, max-age=300"  # 5 minutes

            return Response(content=content, headers=headers, status_code=200)

        except FileNotFoundError:
            raise HTTPException(status_code=404, detail="Asset not found")

    def list_available_assets(self) -> list[str]:
        """
        Get a list of all available frontend assets.

        Returns:
            List of asset paths
        """
        if not self._assets_available:
            return []

        return list_frontend_assets()

    def _get_content_type(self, asset_path: str) -> str:
        """
        Determine the content type for an asset based on its file extension.

        Args:
            asset_path: Path to the asset

        Returns:
            MIME type string
        """
        # Get the file extension
        extension = Path(asset_path).suffix.lower()

        # Common web asset types
        content_types = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".svg": "image/svg+xml; charset=utf-8",
            ".ico": "image/x-icon",
            ".webp": "image/webp",
            ".woff": "font/woff",
            ".woff2": "font/woff2",
            ".ttf": "font/ttf",
            ".eot": "application/vnd.ms-fontobject",
            ".map": "application/json; charset=utf-8",  # Source maps
        }

        # Try custom mapping first
        if extension in content_types:
            return content_types[extension]

        # Fall back to Python's mimetypes module
        content_type, _ = mimetypes.guess_type(asset_path)
        return content_type or "application/octet-stream"


# Global instance for easy import
frontend_loader = FrontendLoader()


def serve_spa_route(path: str = "") -> Response:
    """
    Serve the SPA for any route that should display the React application.

    This function serves the index.html for all routes that should be handled
    by the React router, ensuring proper SPA behavior.

    Args:
        path: The requested path (unused, all paths serve index.html)

    Returns:
        Response with index.html content
    """
    html_content = frontend_loader.get_index_html()

    return Response(
        content=html_content,
        media_type="text/html; charset=utf-8",
        headers={"Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache", "Expires": "0"},
    )


def serve_static_asset(asset_path: str) -> Response:
    """
    Serve a static asset from the frontend build.

    Args:
        asset_path: Path to the static asset

    Returns:
        Response with the asset content
    """
    return frontend_loader.get_asset(asset_path)
