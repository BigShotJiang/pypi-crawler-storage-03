"""
Legacy MCP server entry point - now imports from app.py for unified server
"""

import os

import uvicorn
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import the unified app from app.py
from goaly_mcp.app import app


def main():
    """Main entry point for the server."""
    host = os.getenv("GOALY_HOST", "127.0.0.1")  # Default to localhost only for security
    port = int(os.getenv("GOALY_PORT", "8000"))

    print(f"Starting Goaly MCP integrated server on {host}:{port}")
    print(f"Dashboard: http://{host}:{port}/dashboard")
    print(f"API: http://{host}:{port}/api/v1/")
    print(f"MCP: http://{host}:{port}/mcp")
    print(f"Docs: http://{host}:{port}/docs")

    uvicorn.run(app, host=host, port=port)


# Run the server (legacy entry point)
if __name__ == "__main__":
    print("Starting TaskMaster MCP server (legacy entry point)")
    print("Note: This now uses the unified app from app.py")

    host = os.getenv("HOST", "127.0.0.1")  # Default to localhost only for security
    port = int(os.getenv("PORT", "8000"))

    print(f"Starting TaskMaster MCP integrated server on {host}:{port}")
    print(f"Dashboard: http://{host}:{port}/dashboard")
    print(f"API: http://{host}:{port}/api/v1/")
    print(f"MCP: http://{host}:{port}/mcp")
    print(f"Docs: http://{host}:{port}/docs")

    uvicorn.run(app, host=host, port=port)
