"""
Goal repository for database operations
"""

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from goaly_mcp.cache import cached
from goaly_mcp.database_session import with_session, with_session_list
from goaly_mcp.models import Goal
from goaly_mcp.repositories.base import BaseRepository


class GoalRepository(BaseRepository[Goal]):
    """Repository for Goal database operations"""

    def __init__(self):
        super().__init__(Goal)

    def _create_model(self, session: Session, **kwargs) -> Goal:
        """Create goal model instance"""
        return Goal(**kwargs)

    def _update_model(self, session: Session, model: Goal, **kwargs) -> Goal:
        """Update goal model instance"""
        for key, value in kwargs.items():
            if hasattr(model, key):
                setattr(model, key, value)
        return model

    def _get_cache_keys(self) -> list[str]:
        """Get cache keys to invalidate"""
        return ["goals"]

    def _get_model_data_for_logging(self, model: Goal) -> dict[str, Any]:
        """Get goal data for logging"""
        return {"description": model.description, "is_complete": model.is_complete}

    def create(self, description: str) -> Goal:  # type: ignore[override]
        """Create a new goal (maintain backward compatibility)"""
        return super().create(description=description)

    @with_session
    def get_by_id(self, session: Session, goal_id: int) -> Goal | None:
        """Get goal by ID with relationships (override base method for eager loading)"""
        try:
            result = session.execute(select(Goal).options(selectinload(Goal.tasks)).where(Goal.id == goal_id))
            goal = result.scalars().first()

            self.log_read(entity_type="goal", entity_id=goal_id, found=goal is not None)

            return goal
        except Exception as e:
            self.log_error("get_by_id", e, entity_type="goal", entity_id=goal_id)
            raise

    @cached(ttl=300, key_prefix="goals")  # Cache for 5 minutes
    @with_session_list
    def list_all(self, session, completed_only: bool = False, incomplete_only: bool = False) -> list[Goal]:
        """List all goals with optional filtering"""
        query = select(Goal).options(selectinload(Goal.tasks))

        if completed_only:
            query = query.where(Goal.is_complete == True)
        elif incomplete_only:
            query = query.where(Goal.is_complete == False)

        result = session.execute(query.order_by(Goal.created_at.desc()))
        return list(result.scalars().all())
