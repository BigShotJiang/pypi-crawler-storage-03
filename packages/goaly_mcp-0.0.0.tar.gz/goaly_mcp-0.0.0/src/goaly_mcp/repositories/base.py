"""
Base repository class for common CRUD operations
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from sqlalchemy import select
from sqlalchemy.orm import Session

from goaly_mcp.cache import invalidate_related_cache
from goaly_mcp.database_session import with_session, with_session_raw
from goaly_mcp.logging_config import LoggerMixin

if TYPE_CHECKING:
    from goaly_mcp.models import Base
else:
    from goaly_mcp.models import Base

# Generic type for database models
ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(LoggerMixin, Generic[ModelType], ABC):
    """
    Base repository class providing common CRUD operations

    This class implements the common patterns found across all repositories:
    - Structured logging with LoggerMixin
    - Standard CRUD operations with session management
    - Cache invalidation
    - Error handling and logging
    """

    def __init__(self, model_class: type[ModelType]):
        """
        Initialize repository with model class

        Args:
            model_class: The SQLAlchemy model class this repository manages
        """
        self.model_class = model_class
        self.entity_type = model_class.__name__.lower()

    @abstractmethod
    def _create_model(self, session: Session, **kwargs) -> ModelType:
        """
        Create model instance - must be implemented by subclasses

        Args:
            session: Database session
            **kwargs: Model creation parameters

        Returns:
            Created model instance
        """
        pass

    @abstractmethod
    def _update_model(self, session: Session, model: ModelType, **kwargs) -> ModelType:
        """
        Update model instance - must be implemented by subclasses

        Args:
            session: Database session
            model: Model instance to update
            **kwargs: Update parameters

        Returns:
            Updated model instance
        """
        pass

    @abstractmethod
    def _get_cache_keys(self) -> list[str]:
        """
        Get cache keys to invalidate for this entity type

        Returns:
            List of cache key prefixes to invalidate
        """
        pass

    @abstractmethod
    def _get_model_data_for_logging(self, model: ModelType) -> dict[str, Any]:
        """
        Extract model data for logging before deletion

        Args:
            model: Model instance

        Returns:
            Dictionary of model data for logging
        """
        pass

    @with_session
    def create(self, session: Session, **kwargs) -> ModelType:
        """
        Create a new entity

        Args:
            session: Database session
            **kwargs: Creation parameters

        Returns:
            Created entity
        """
        try:
            model = self._create_model(session, **kwargs)
            session.add(model)
            session.flush()
            session.refresh(model)

            # Log successful creation
            self.log_create(entity_type=self.entity_type, entity_id=getattr(model, "id", None), **kwargs)

            # Invalidate related cache
            invalidate_related_cache(self._get_cache_keys())

            return model
        except Exception as e:
            self.log_error("create", e, entity_type=self.entity_type, **kwargs)
            raise

    @with_session
    def get_by_id(self, session: Session, entity_id: int) -> ModelType | None:
        """
        Get entity by ID

        Args:
            session: Database session
            entity_id: Entity ID

        Returns:
            Entity if found, None otherwise
        """
        try:
            result = session.execute(select(self.model_class).where(self.model_class.id == entity_id))  # type: ignore[attr-defined]
            model = result.scalars().first()

            self.log_read(entity_type=self.entity_type, entity_id=entity_id, found=model is not None)

            return model
        except Exception as e:
            self.log_error("get_by_id", e, entity_type=self.entity_type, entity_id=entity_id)
            raise

    @with_session
    def update(self, session: Session, entity_id: int, **kwargs) -> ModelType | None:
        """
        Update entity by ID

        Args:
            session: Database session
            entity_id: Entity ID
            **kwargs: Update parameters

        Returns:
            Updated entity if found, None otherwise
        """
        try:
            result = session.execute(select(self.model_class).where(self.model_class.id == entity_id))  # type: ignore[attr-defined]
            model = result.scalars().first()

            if not model:
                self.log_operation(
                    "update",
                    level="warning",
                    entity_type=self.entity_type,
                    entity_id=entity_id,
                    result="not_found",
                    changes=kwargs,
                )
                return None

            # Track changes for logging
            changes = {}
            for key, value in kwargs.items():
                if hasattr(model, key):
                    old_value = getattr(model, key)
                    if old_value != value:
                        changes[key] = {"old": old_value, "new": value}

            # Apply updates via subclass implementation
            updated_model = self._update_model(session, model, **kwargs)

            session.flush()
            session.refresh(updated_model)

            # Log successful update
            self.log_update(entity_type=self.entity_type, entity_id=entity_id, changes=changes)

            # Invalidate related cache
            invalidate_related_cache(self._get_cache_keys())

            return updated_model
        except Exception as e:
            self.log_error("update", e, entity_type=self.entity_type, entity_id=entity_id, changes=kwargs)
            raise

    @with_session_raw
    def delete(self, session: Session, entity_id: int) -> bool:
        """
        Delete entity by ID

        Args:
            session: Database session
            entity_id: Entity ID

        Returns:
            True if deleted, False if not found
        """
        try:
            result = session.execute(select(self.model_class).where(self.model_class.id == entity_id))  # type: ignore[attr-defined]
            model = result.scalars().first()

            if not model:
                self.log_operation(
                    "delete", level="warning", entity_type=self.entity_type, entity_id=entity_id, result="not_found"
                )
                return False

            # Store model data for logging before deletion
            model_data = self._get_model_data_for_logging(model)

            session.delete(model)

            # Log successful deletion
            self.log_delete(entity_type=self.entity_type, entity_id=entity_id, model_data=model_data)

            # Invalidate related cache
            invalidate_related_cache(self._get_cache_keys())

            return True
        except Exception as e:
            self.log_error("delete", e, entity_type=self.entity_type, entity_id=entity_id)
            raise


class SimpleRepository(BaseRepository[ModelType]):
    """
    Simple repository implementation for models with basic CRUD operations

    This is a concrete implementation that works for models with simple
    attribute assignment for updates.
    """

    def __init__(
        self,
        model_class: type[ModelType],
        cache_keys: list[str] | None = None,
        creation_fields: list[str] | None = None,
    ):
        """
        Initialize simple repository

        Args:
            model_class: SQLAlchemy model class
            cache_keys: Cache keys to invalidate (defaults to [model_name])
            creation_fields: Fields to extract for creation (defaults to all kwargs)
        """
        super().__init__(model_class)
        self._cache_keys = cache_keys or [self.entity_type + "s"]
        self._creation_fields = creation_fields

    def _create_model(self, session: Session, **kwargs) -> ModelType:
        """Create model with simple attribute assignment"""
        if self._creation_fields:
            # Filter to only allowed creation fields
            filtered_kwargs = {k: v for k, v in kwargs.items() if k in self._creation_fields}
        else:
            filtered_kwargs = kwargs

        return self.model_class(**filtered_kwargs)

    def _update_model(self, session: Session, model: ModelType, **kwargs) -> ModelType:
        """Update model with simple attribute assignment"""
        for key, value in kwargs.items():
            if hasattr(model, key):
                setattr(model, key, value)
        return model

    def _get_cache_keys(self) -> list[str]:
        """Get cache keys for this entity type"""
        return self._cache_keys

    def _get_model_data_for_logging(self, model: ModelType) -> dict[str, Any]:
        """Extract all non-private attributes for logging"""
        return {
            attr: getattr(model, attr)
            for attr in dir(model)
            if not attr.startswith("_") and not callable(getattr(model, attr))
        }
