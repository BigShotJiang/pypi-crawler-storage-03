"""
Repository pattern for database operations
"""

from goaly_mcp.repositories.goals import GoalRepository
from goaly_mcp.repositories.tasks import TaskRepository

__all__ = ["GoalRepository", "TaskRepository"]
