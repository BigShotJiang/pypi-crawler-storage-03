"""
Task repository for database operations
"""

from typing import Any

from sqlalchemy import and_, func, select
from sqlalchemy.orm import Session, selectinload

from goaly_mcp.cache import cached, invalidate_related_cache
from goaly_mcp.database_session import with_session, with_session_list, with_session_raw
from goaly_mcp.models import Goal, Task, TaskDependency, TaskStatus
from goaly_mcp.repositories.base import BaseRepository


class TaskRepository(BaseRepository[Task]):
    """Repository for Task database operations"""

    def __init__(self):
        super().__init__(Task)

    def _create_model(self, session: Session, **kwargs) -> Task:
        """Create task model instance with goal validation"""
        goal_id = kwargs.get("goal_id")
        if goal_id:
            # Verify goal exists
            goal_result = session.execute(select(Goal).where(Goal.id == goal_id))
            if not goal_result.scalars().first():
                raise ValueError(f"Goal with ID {goal_id} not found")

        return Task(**kwargs)

    def _update_model(self, session: Session, model: Task, **kwargs) -> Task:
        """Update task model with status validation"""
        # Handle status updates with validation
        if "status" in kwargs:
            try:
                new_status = TaskStatus(kwargs["status"])

                # Validate owner requirements
                if new_status in [TaskStatus.OWNED, TaskStatus.COMPLETED]:
                    if not model.owner and "owner" not in kwargs:
                        raise ValueError(f"Owner is required for status {kwargs['status']}")
                elif new_status not in [TaskStatus.OWNED, TaskStatus.COMPLETED]:
                    kwargs["owner"] = None  # Clear owner for other statuses

                kwargs["status"] = new_status
            except ValueError as ve:
                # Re-raise our custom validation errors as-is
                if "Owner is required for status" in str(ve):
                    raise ve
                # Re-raise other ValueError (like invalid enum value) with our message
                raise ValueError(
                    f"Invalid status: {kwargs['status']}. Valid statuses: {[s.value for s in TaskStatus]}"
                ) from ve

        for key, value in kwargs.items():
            if hasattr(model, key):
                setattr(model, key, value)

        # Update blocking status for dependent tasks if status changed
        if "status" in kwargs:
            self._update_task_blocking_status(session, int(model.id))

        return model

    def _get_cache_keys(self) -> list[str]:
        """Get cache keys to invalidate"""
        return ["tasks", "tasks_metadata"]

    def _get_model_data_for_logging(self, model: Task) -> dict[str, Any]:
        """Get task data for logging"""
        return {"name": model.name, "goal_id": model.goal_id, "status": model.status.value, "owner": model.owner}

    def create(  # type: ignore[override]
        self,
        goal_id: int,
        name: str,
        instructions: str = "",
        status: TaskStatus = TaskStatus.AVAILABLE,
        owner: str | None = None,
    ) -> Task:
        """Create a new task (maintain backward compatibility)"""
        return super().create(goal_id=goal_id, name=name, instructions=instructions, status=status, owner=owner)

    @with_session
    def get_by_id(self, session: Session, task_id: int) -> Task | None:
        """Get task by ID with relationships (override base method for eager loading)"""
        try:
            result = session.execute(
                select(Task)
                .options(
                    selectinload(Task.dependencies).selectinload(TaskDependency.dependency_task),
                    selectinload(Task.dependents).selectinload(TaskDependency.dependent_task),
                    selectinload(Task.goal),
                )
                .where(Task.id == task_id)
            )
            task = result.scalars().first()

            self.log_read(entity_type="task", entity_id=task_id, found=task is not None)

            return task
        except Exception as e:
            self.log_error("get_by_id", e, entity_type="task", entity_id=task_id)
            raise

    @with_session_raw
    def delete(self, session: Session, task_id: int) -> bool:
        """Delete task with dependency cleanup (override base method)"""
        try:
            result = session.execute(select(Task).where(Task.id == task_id))
            task = result.scalars().first()

            if not task:
                self.log_operation("delete", level="warning", entity_type="task", entity_id=task_id, result="not_found")
                return False

            # Store task data for logging before deletion
            task_data = self._get_model_data_for_logging(task)

            # Delete all task dependencies where this task is involved
            # Delete dependencies where this task is the dependent task
            for dep in (
                session.execute(select(TaskDependency).where(TaskDependency.dependent_task_id == task_id))
                .scalars()
                .all()
            ):
                session.delete(dep)

            # Delete dependencies where this task is the dependency task
            for dep in (
                session.execute(select(TaskDependency).where(TaskDependency.dependency_task_id == task_id))
                .scalars()
                .all()
            ):
                session.delete(dep)

            # Now delete the task
            session.delete(task)

            # Log successful deletion
            self.log_delete(entity_type="task", entity_id=task_id, task_data=task_data)

            # Invalidate related cache
            invalidate_related_cache(self._get_cache_keys())

            return True
        except Exception as e:
            self.log_error("delete", e, entity_type="task", entity_id=task_id)
            raise

    @with_session_list
    def list_by_goal(self, session, goal_id: int) -> list[Task]:
        """List all tasks for a goal"""
        result = session.execute(
            select(Task)
            .options(selectinload(Task.dependencies), selectinload(Task.dependents))
            .where(Task.goal_id == goal_id)
            .order_by(Task.created_at.desc())
        )
        return list(result.scalars().all())

    @cached(ttl=300, key_prefix="tasks")  # Cache for 5 minutes
    @with_session_list
    def search(
        self,
        session,
        goal_id: int | None = None,
        status: str | None = None,
        owner: str | None = None,
        available_only: bool = False,
    ) -> list[Task]:
        """Search tasks with filters"""
        query = select(Task).options(selectinload(Task.dependencies), selectinload(Task.dependents))

        if goal_id is not None:
            query = query.where(Task.goal_id == goal_id)

        if status is not None:
            try:
                status_enum = TaskStatus(status)
                query = query.where(Task.status == status_enum)
            except ValueError:
                raise ValueError(f"Invalid status: {status}")

        if owner is not None:
            query = query.where(Task.owner == owner)

        if available_only:
            # Available tasks are not blocked by dependencies
            subq_blocked_deps = select(TaskDependency.dependent_task_id).where(TaskDependency.is_blocked == True)
            query = query.where(and_(Task.status == TaskStatus.AVAILABLE, ~Task.id.in_(subq_blocked_deps)))

        result = session.execute(query.order_by(Task.created_at.desc()))
        return list(result.scalars().all())

    @with_session
    def add_dependency(
        self, session, dependent_task_id: int, dependency_task_id: int, required_data: str | None = None
    ) -> TaskDependency:
        """Add dependency between tasks"""
        try:
            # Verify both tasks exist and are in the same goal
            result = session.execute(select(Task).where(Task.id.in_([dependent_task_id, dependency_task_id])))
            tasks = result.scalars().all()

            if len(tasks) != 2:
                raise ValueError("One or both tasks not found")

            task_dict: dict[int, Task] = {int(task.id): task for task in tasks}
            dependent_task = task_dict[dependent_task_id]
            dependency_task = task_dict[dependency_task_id]

            if dependent_task.goal_id != dependency_task.goal_id:
                raise ValueError("Tasks must be in the same goal to create dependencies")

            # Check if dependency already exists
            existing = session.execute(
                select(TaskDependency).where(
                    and_(
                        TaskDependency.dependent_task_id == dependent_task_id,
                        TaskDependency.dependency_task_id == dependency_task_id,
                    )
                )
            )
            if existing.scalars().first():
                raise ValueError("Dependency already exists")

            # Determine blocking status
            is_blocked = dependency_task.status not in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]

            dependency = TaskDependency(
                dependent_task_id=dependent_task_id,
                dependency_task_id=dependency_task_id,
                required_data=required_data,
                is_blocked=is_blocked,
            )
            session.add(dependency)

            # Update dependent task status if it becomes blocked
            if is_blocked and dependent_task.status == TaskStatus.AVAILABLE:
                dependent_task.status = TaskStatus.BLOCKED  # type: ignore[assignment]

            session.flush()
            session.refresh(dependency)

            # Log successful dependency creation
            self.log_create(
                entity_type="task_dependency",
                entity_id=dependency.id,
                dependent_task_id=dependent_task_id,
                dependency_task_id=dependency_task_id,
                is_blocked=is_blocked,
            )

            # Invalidate related cache since dependencies affect task metadata
            invalidate_related_cache(["tasks", "tasks_metadata"])

            return dependency
        except Exception as e:
            self.log_error(
                "add_dependency", e, dependent_task_id=dependent_task_id, dependency_task_id=dependency_task_id
            )
            raise

    def _update_task_blocking_status(self, session, task_id: int):
        """Update the blocking status of all task dependencies for a given task"""
        # Get all dependencies where this task is the dependency
        dependencies = session.execute(select(TaskDependency).where(TaskDependency.dependency_task_id == task_id))

        # Get the task status
        task_result = session.execute(select(Task).where(Task.id == task_id))
        task = task_result.scalars().first()

        if not task:
            return

        # Update blocking status based on task completion
        is_blocking = task.status not in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]

        for dependency in dependencies.scalars().all():
            dependency.is_blocked = is_blocking

        # Don't commit here - let the parent session handle commits
        session.flush()

    @cached(ttl=300, key_prefix="tasks_metadata")  # Cache for 5 minutes
    @with_session_list
    def get_tasks_with_metadata(
        self,
        session,
        goal_id: int | None = None,
        status: str | None = None,
        owner: str | None = None,
        available_only: bool = False,
    ) -> list[dict]:
        """
        Get tasks with metadata in batch to avoid N+1 query problems.
        Returns tasks with importance and dependency_count calculated efficiently.
        """
        # Build the main query for tasks
        query = select(Task).options(selectinload(Task.dependencies), selectinload(Task.dependents))

        if goal_id is not None:
            query = query.where(Task.goal_id == goal_id)

        if status is not None:
            try:
                status_enum = TaskStatus(status)
                query = query.where(Task.status == status_enum)
            except ValueError:
                raise ValueError(f"Invalid status: {status}")

        if owner is not None:
            query = query.where(Task.owner == owner)

        if available_only:
            # Available tasks are not blocked by dependencies
            subq_blocked_deps = select(TaskDependency.dependent_task_id).where(TaskDependency.is_blocked == True)
            query = query.where(and_(Task.status == TaskStatus.AVAILABLE, ~Task.id.in_(subq_blocked_deps)))

        # Get all tasks in one query
        result = session.execute(query.order_by(Task.created_at.desc()))
        tasks = list(result.scalars().all())

        if not tasks:
            return []

        # Get all task IDs for batch queries
        task_ids = [task.id for task in tasks]

        # Batch query for importance (how many tasks depend on each task)
        importance_query = (
            select(TaskDependency.dependency_task_id, func.count(TaskDependency.id))
            .where(TaskDependency.dependency_task_id.in_(task_ids))
            .group_by(TaskDependency.dependency_task_id)
        )
        importance_result = session.execute(importance_query)
        importance_map = dict(importance_result.fetchall())

        # Batch query for dependency count (how many dependencies each task has)
        dependency_count_query = (
            select(TaskDependency.dependent_task_id, func.count(TaskDependency.id))
            .where(TaskDependency.dependent_task_id.in_(task_ids))
            .group_by(TaskDependency.dependent_task_id)
        )
        dependency_result = session.execute(dependency_count_query)
        dependency_count_map = dict(dependency_result.fetchall())

        # Build the response data
        tasks_data = []
        for task in tasks:
            importance = importance_map.get(task.id, 0)
            dependency_count = dependency_count_map.get(task.id, 0)

            tasks_data.append(
                {
                    "id": task.id,
                    "goal_id": task.goal_id,
                    "name": task.name,
                    "instructions": task.instructions,
                    "status": task.status.value,
                    "owner": task.owner,
                    "importance": importance,
                    "dependency_count": dependency_count,
                    "is_leaf_node": dependency_count == 0,
                    "created_at": task.created_at.isoformat(),
                    "updated_at": task.updated_at.isoformat(),
                }
            )

        return tasks_data
