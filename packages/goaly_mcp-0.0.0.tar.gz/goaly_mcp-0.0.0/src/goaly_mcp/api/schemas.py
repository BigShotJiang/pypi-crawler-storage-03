"""
Pydantic schemas for the TaskMaster MCP API
"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class TaskStatusEnum(str, Enum):
    """Task status enumeration"""

    BLOCKED = "blocked"
    AVAILABLE = "available"
    OWNED = "owned"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class GoalBase(BaseModel):
    """Base goal schema"""

    description: str = Field(..., min_length=1, max_length=1000)


class GoalCreate(GoalBase):
    """Goal creation schema"""

    pass


class GoalUpdate(BaseModel):
    """Goal update schema"""

    description: str | None = Field(None, min_length=1, max_length=1000)
    is_complete: bool | None = None


class Goal(GoalBase):
    """Goal response schema"""

    id: int
    is_complete: bool
    created_at: datetime
    updated_at: datetime
    task_count: int | None = None

    class Config:
        from_attributes = True


class TaskBase(BaseModel):
    """Base task schema"""

    name: str = Field(..., min_length=1, max_length=255)
    instructions: str | None = Field(None, max_length=2000)


class TaskCreate(TaskBase):
    """Task creation schema"""

    goal_id: int
    owner: str | None = Field(None, max_length=255)


class TaskUpdate(BaseModel):
    """Task update schema"""

    name: str | None = Field(None, min_length=1, max_length=255)
    instructions: str | None = Field(None, max_length=2000)
    status: TaskStatusEnum | None = None
    owner: str | None = Field(None, max_length=255)


class Task(TaskBase):
    """Task response schema"""

    id: int
    goal_id: int
    status: TaskStatusEnum
    owner: str | None
    created_at: datetime
    updated_at: datetime
    importance: int | None = None
    dependency_count: int | None = None
    is_leaf_node: bool | None = None

    class Config:
        from_attributes = True


class TaskDependencyCreate(BaseModel):
    """Task dependency creation schema"""

    dependent_task_id: int
    dependency_task_id: int
    required_data: str | None = Field(None, max_length=1000)


class TaskDependency(BaseModel):
    """Task dependency response schema"""

    id: int
    dependent_task_id: int
    dependency_task_id: int
    required_data: str | None
    is_blocked: bool
    created_at: datetime

    class Config:
        from_attributes = True


class GoalHierarchy(BaseModel):
    """Goal hierarchy for dashboard"""

    goal: Goal
    tasks: list[Task]


class TaskWithDependencies(Task):
    """Task with dependency information"""

    dependencies: list[TaskDependency]
    dependents: list[TaskDependency]


class SSEEvent(BaseModel):
    """Server-Sent Event schema"""

    event_type: str
    data: dict
    goal_id: int | None = None
    timestamp: datetime


class APIResponse(BaseModel):
    """Standard API response wrapper"""

    success: bool = True
    message: str = "Operation completed successfully"
    data: dict | None = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ErrorResponse(BaseModel):
    """Error response schema"""

    success: bool = False
    message: str
    error_code: str | None = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
