"""
Task management API endpoints
"""

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from goaly_mcp.api.schemas import APIResponse, TaskCreate, TaskDependencyCreate, TaskUpdate
from goaly_mcp.api.sse import notify_dependency_added, notify_task_created, notify_task_updated
from goaly_mcp.database import SessionLocal
from goaly_mcp.models import Task as TaskModel
from goaly_mcp.models import TaskDependency as TaskDependencyModel
from goaly_mcp.models import TaskStatus
from goaly_mcp.repositories import TaskRepository

router = APIRouter(prefix="/tasks", tags=["Tasks"])
task_repo = TaskRepository()


def calculate_task_importance(db_session: Session, task_id: int) -> int:
    """Calculate task importance based on how many other tasks depend on it."""
    result = db_session.execute(
        select(func.count(TaskDependencyModel.id)).where(TaskDependencyModel.dependency_task_id == task_id)
    )
    return result.scalar() or 0


@router.post("/", response_model=APIResponse, operation_id="createTask")
async def create_task(task_data: TaskCreate):
    """Create a new task"""
    try:
        # Determine initial status based on owner
        status = TaskStatus.OWNED if task_data.owner else TaskStatus.AVAILABLE

        task = task_repo.create(
            goal_id=task_data.goal_id,
            name=task_data.name,
            instructions=task_data.instructions or "",
            status=status,
            owner=task_data.owner,
        )

        # Send SSE notification
        task_data_dict = {
            "id": task.id,
            "goal_id": task.goal_id,
            "name": task.name,
            "instructions": task.instructions,
            "status": task.status.value,
            "owner": task.owner,
            "created_at": task.created_at.isoformat(),
            "updated_at": task.updated_at.isoformat(),
        }
        await notify_task_created(task_data_dict)

        return APIResponse(
            message="Task created successfully",
            data=task_data_dict,
        )
    except ValueError as e:
        # Handle validation errors (like invalid goal_id) as 400
        raise HTTPException(status_code=400, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create task: {e!s}") from e


@router.get("/", response_model=APIResponse, operation_id="listTasks")
async def list_tasks(
    goal_id: int | None = Query(None, description="Filter by goal ID"),
    status: str | None = Query(None, description="Filter by status"),
    owner: str | None = Query(None, description="Filter by owner"),
    available_only: bool = Query(False, description="Show only available tasks"),
):
    """List tasks with optional filtering"""
    try:
        # Use batch method to avoid N+1 query problems
        tasks_data = task_repo.get_tasks_with_metadata(
            goal_id=goal_id, status=status, owner=owner, available_only=available_only
        )

        return APIResponse(message="Tasks retrieved successfully", data={"tasks": tasks_data, "total": len(tasks_data)})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list tasks: {e!s}") from e


@router.get("/{task_id}", response_model=APIResponse, operation_id="getTask")
async def get_task(task_id: int):
    """Get a specific task by ID"""
    try:
        # Use a manual session to handle the complex data extraction
        with SessionLocal() as db_session:
            # Get task with all relationships in a single query
            result = db_session.execute(
                select(TaskModel)
                .options(
                    selectinload(TaskModel.dependencies).selectinload(TaskDependencyModel.dependency_task),
                    selectinload(TaskModel.dependents).selectinload(TaskDependencyModel.dependent_task),
                    selectinload(TaskModel.goal),
                )
                .where(TaskModel.id == task_id)
            )
            task = result.scalars().first()

            if not task:
                raise HTTPException(status_code=404, detail="Task not found")

            # Get dependencies and dependents while session is active
            dependencies = []
            for dep in task.dependencies:
                dependencies.append(
                    {
                        "id": dep.id,
                        "dependency_task": {
                            "id": dep.dependency_task.id,
                            "name": dep.dependency_task.name,
                            "status": dep.dependency_task.status.value,
                        },
                        "required_data": dep.required_data,
                        "is_blocked": dep.is_blocked,
                    }
                )

            dependents = []
            for dep in task.dependents:
                dependents.append(
                    {
                        "id": dep.id,
                        "dependent_task": {
                            "id": dep.dependent_task.id,
                            "name": dep.dependent_task.name,
                            "status": dep.dependent_task.status.value,
                        },
                        "required_data": dep.required_data,
                        "is_blocked": dep.is_blocked,
                    }
                )

            # Calculate importance while session is active
            importance = calculate_task_importance(db_session, int(task_id))

            # Extract all data while session is active
            task_data = {
                "id": task.id,
                "goal": {
                    "id": task.goal.id,
                    "description": task.goal.description,
                    "is_complete": task.goal.is_complete,
                },
                "name": task.name,
                "instructions": task.instructions,
                "status": task.status.value,
                "owner": task.owner,
                "importance": importance,
                "is_leaf_node": len(dependencies) == 0,
                "dependencies": dependencies,
                "dependents": dependents,
                "created_at": task.created_at.isoformat(),
                "updated_at": task.updated_at.isoformat(),
            }

        return APIResponse(
            message="Task retrieved successfully",
            data=task_data,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get task: {e!s}") from e


@router.put("/{task_id}", response_model=APIResponse, operation_id="updateTask")
async def update_task(task_id: int, task_data: TaskUpdate):
    """Update a task"""
    try:
        update_data = {}
        if task_data.name is not None:
            update_data["name"] = task_data.name
        if task_data.instructions is not None:
            update_data["instructions"] = task_data.instructions
        if task_data.status is not None:
            update_data["status"] = task_data.status.value
        if task_data.owner is not None:
            update_data["owner"] = task_data.owner

        task = task_repo.update(task_id, **update_data)

        if not task:
            raise HTTPException(status_code=404, detail="Task not found")

        # Send SSE notification
        task_data_dict = {
            "id": task.id,
            "goal_id": task.goal_id,
            "name": task.name,
            "instructions": task.instructions,
            "status": task.status.value,
            "owner": task.owner,
            "updated_at": task.updated_at.isoformat(),
        }
        await notify_task_updated(task_data_dict)

        return APIResponse(
            message="Task updated successfully",
            data=task_data_dict,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update task: {e!s}") from e


@router.delete("/{task_id}", response_model=APIResponse, operation_id="deleteTask")
async def delete_task(task_id: int):
    """Delete a task"""
    try:
        success = task_repo.delete(task_id)

        if not success:
            raise HTTPException(status_code=404, detail="Task not found")

        return APIResponse(message="Task deleted successfully", data={"deleted_task_id": task_id})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete task: {e!s}") from e


@router.post("/dependencies", response_model=APIResponse, operation_id="addTaskDependency")
async def add_task_dependency(dependency_data: TaskDependencyCreate):
    """Add a dependency relationship between tasks"""
    try:
        dependency = task_repo.add_dependency(
            dependent_task_id=dependency_data.dependent_task_id,
            dependency_task_id=dependency_data.dependency_task_id,
            required_data=dependency_data.required_data,
        )

        # Send SSE notification
        dependency_data_dict = {
            "id": dependency.id,
            "dependent_task_id": dependency.dependent_task_id,
            "dependency_task_id": dependency.dependency_task_id,
            "required_data": dependency.required_data,
            "is_blocked": dependency.is_blocked,
            "created_at": dependency.created_at.isoformat(),
        }
        await notify_dependency_added(dependency_data_dict)

        return APIResponse(
            message="Task dependency added successfully",
            data=dependency_data_dict,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to add task dependency: {e!s}") from e


@router.get("/dependencies/graph", response_model=APIResponse, operation_id="getDependencyGraph")
async def get_dependency_graph(goal_id: int | None = Query(None, description="Filter by goal ID")):
    """Get task dependency graph for visualization"""
    try:
        with SessionLocal() as db_session:
            # Build query for tasks
            query = select(TaskModel)
            if goal_id is not None:
                query = query.where(TaskModel.goal_id == goal_id)

            result = db_session.execute(query)
            tasks = result.scalars().all()

            # Build nodes and edges for graph visualization
            nodes = []
            edges = []

            for task in tasks:
                nodes.append(
                    {
                        "id": task.id,
                        "name": task.name,
                        "status": task.status.value,
                        "owner": task.owner,
                        "goal_id": task.goal_id,
                    }
                )

                # Get dependencies for this task
                deps_result = db_session.execute(
                    select(TaskDependencyModel).where(TaskDependencyModel.dependent_task_id == task.id)
                )
                dependencies = deps_result.scalars().all()

                # Add edges for dependencies
                for dep in dependencies:
                    edges.append(
                        {
                            "id": dep.id,
                            "source": dep.dependency_task_id,
                            "target": dep.dependent_task_id,
                            "is_blocked": dep.is_blocked,
                            "required_data": dep.required_data,
                        }
                    )

        return APIResponse(
            message="Dependency graph retrieved successfully",
            data={
                "nodes": nodes,
                "edges": edges,
                "summary": {
                    "total_tasks": len(nodes),
                    "total_dependencies": len(edges),
                    "blocked_dependencies": len([e for e in edges if e["is_blocked"]]),
                },
            },
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get dependency graph: {e!s}") from e
