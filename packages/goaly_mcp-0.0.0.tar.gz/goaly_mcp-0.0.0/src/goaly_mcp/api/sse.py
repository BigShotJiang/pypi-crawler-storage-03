"""
Server-Sent Events (SSE) endpoint for real-time dashboard updates
"""

import asyncio
import json
from collections.abc import AsyncGenerator
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from goaly_mcp.api.schemas import APIResponse, SSEEvent

router = APIRouter(prefix="/sse", tags=["Server-Sent Events"])

# Global set to track connected SSE clients
connected_clients: set = set()


class SSEManager:
    """Manages Server-Sent Events connections and notifications"""

    def __init__(self):
        self.connections: set = set()

    async def connect(self, generator):
        """Add a new SSE connection"""
        self.connections.add(generator)

    async def disconnect(self, generator):
        """Remove an SSE connection"""
        self.connections.discard(generator)

    def _serialize_datetime(self, obj: Any) -> Any:
        """Recursively convert datetime objects to ISO format strings"""
        if isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, dict):
            return {key: self._serialize_datetime(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._serialize_datetime(item) for item in obj]
        else:
            return obj

    async def broadcast(self, event_type: str, data: dict[str, Any], goal_id: int | None = None):
        """Broadcast an event to all connected clients"""
        if not self.connections:
            return

        event = SSEEvent(event_type=event_type, data=data, goal_id=goal_id, timestamp=datetime.utcnow())

        # Convert datetime objects to ISO format strings for JSON serialization
        event_dict = event.model_dump()
        event_dict = self._serialize_datetime(event_dict)

        message = f"data: {json.dumps(event_dict)}\n\n"

        # Send to all connected clients
        disconnected = set()
        for connection in self.connections:
            try:
                connection.put_nowait(message)
            except Exception:
                # Connection is broken, mark for removal
                disconnected.add(connection)

        # Remove disconnected clients
        for connection in disconnected:
            self.connections.discard(connection)


# Global SSE manager instance
sse_manager = SSEManager()


async def event_stream() -> AsyncGenerator[str, None]:
    """Generate SSE event stream"""
    # Create a queue for this connection
    queue: asyncio.Queue[dict] = asyncio.Queue()

    async def generator():
        try:
            while True:
                # Send keepalive every 30 seconds
                try:
                    message = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield message
                except TimeoutError:
                    # Send keepalive
                    yield 'data: {"event_type": "keepalive", "timestamp": "' + datetime.utcnow().isoformat() + '"}\n\n'
        except asyncio.CancelledError:
            pass

    gen = generator()
    await sse_manager.connect(queue)

    try:
        async for message in gen:
            yield message
    finally:
        await sse_manager.disconnect(queue)


@router.get("/events", operation_id="streamEvents")
async def stream_events(request: Request):
    """SSE endpoint for real-time dashboard updates"""

    async def generate():
        """Generate SSE messages"""
        try:
            # Send initial connection message
            initial_event = {
                "event_type": "connected",
                "data": {"message": "SSE connection established"},
                "timestamp": datetime.utcnow().isoformat(),
            }
            yield f"data: {json.dumps(initial_event)}\n\n"

            # Create a queue for this specific connection
            queue: asyncio.Queue[dict] = asyncio.Queue()
            await sse_manager.connect(queue)

            try:
                while True:
                    # Check if client is still connected
                    if await request.is_disconnected():
                        break

                    try:
                        # Wait for events with timeout for keepalive
                        message = await asyncio.wait_for(queue.get(), timeout=30.0)
                        yield message
                    except TimeoutError:
                        # Send keepalive
                        keepalive_event = {
                            "event_type": "keepalive",
                            "data": {"timestamp": datetime.utcnow().isoformat()},
                            "timestamp": datetime.utcnow().isoformat(),
                        }
                        yield f"data: {json.dumps(keepalive_event)}\n\n"

            finally:
                await sse_manager.disconnect(queue)

        except Exception as e:
            print(f"SSE stream error: {e}")

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Cache-Control",
        },
    )


@router.post("/notify", operation_id="sendNotification")
async def send_notification(event: SSEEvent):
    """Internal endpoint for sending SSE notifications"""
    try:
        await sse_manager.broadcast(event_type=event.event_type, data=event.data, goal_id=event.goal_id)

        return APIResponse(
            message="Notification sent successfully",
            data={"event_type": event.event_type, "recipients": len(sse_manager.connections)},
        )
    except Exception as e:
        return APIResponse(success=False, message=f"Failed to send notification: {e!s}")


# Convenience functions for sending specific events
async def notify_goal_created(goal_data: dict[str, Any]):
    """Send goal created notification"""
    await sse_manager.broadcast("goal_created", goal_data, goal_data.get("id"))


async def notify_goal_updated(goal_data: dict[str, Any]):
    """Send goal updated notification"""
    await sse_manager.broadcast("goal_updated", goal_data, goal_data.get("id"))


async def notify_task_created(task_data: dict[str, Any]):
    """Send task created notification"""
    await sse_manager.broadcast("task_created", task_data, task_data.get("goal_id"))


async def notify_task_updated(task_data: dict[str, Any]):
    """Send task updated notification"""
    await sse_manager.broadcast("task_updated", task_data, task_data.get("goal_id"))


async def notify_dependency_added(dependency_data: dict[str, Any]):
    """Send dependency added notification"""
    await sse_manager.broadcast("dependency_added", dependency_data)
