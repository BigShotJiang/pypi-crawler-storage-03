"""
Goal management API endpoints
"""

from fastapi import APIRouter, HTTPException

from goaly_mcp.api.schemas import APIResponse, GoalCreate, GoalUpdate
from goaly_mcp.repositories import GoalRepository

router = APIRouter(prefix="/goals", tags=["Goals"])
goal_repo = GoalRepository()


@router.post("/", response_model=APIResponse, operation_id="createGoal")
async def create_goal(goal_data: GoalCreate):
    """Create a new goal"""
    try:
        goal = goal_repo.create(description=goal_data.description)

        return APIResponse(
            message="Goal created successfully",
            data={
                "id": goal.id,
                "description": goal.description,
                "is_complete": goal.is_complete,
                "created_at": goal.created_at.isoformat(),
                "updated_at": goal.updated_at.isoformat(),
            },
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create goal: {e!s}") from e


@router.get("/", response_model=APIResponse, operation_id="listGoals")
async def list_goals(completed_only: bool = False, incomplete_only: bool = False):
    """List all goals with optional filtering"""
    try:
        goals = goal_repo.list_all(completed_only=completed_only, incomplete_only=incomplete_only)

        goals_data = [
            {
                "id": goal.id,
                "description": goal.description,
                "is_complete": goal.is_complete,
                "task_count": len(goal.tasks),
                "created_at": goal.created_at.isoformat(),
                "updated_at": goal.updated_at.isoformat(),
            }
            for goal in goals
        ]

        return APIResponse(message="Goals retrieved successfully", data={"goals": goals_data, "total": len(goals_data)})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list goals: {e!s}")


@router.get("/{goal_id}", response_model=APIResponse, operation_id="getGoal")
async def get_goal(goal_id: int):
    """Get a specific goal by ID"""
    try:
        goal = goal_repo.get_by_id(goal_id)

        if not goal:
            raise HTTPException(status_code=404, detail="Goal not found")

        return APIResponse(
            message="Goal retrieved successfully",
            data={
                "id": goal.id,
                "description": goal.description,
                "is_complete": goal.is_complete,
                "task_count": len(goal.tasks) if hasattr(goal, "tasks") else 0,
                "created_at": goal.created_at.isoformat(),
                "updated_at": goal.updated_at.isoformat(),
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get goal: {e!s}")


@router.put("/{goal_id}", response_model=APIResponse, operation_id="updateGoal")
async def update_goal(goal_id: int, goal_data: GoalUpdate):
    """Update a goal"""
    try:
        update_data: dict[str, str | bool] = {}
        if goal_data.description is not None:
            update_data["description"] = goal_data.description
        if goal_data.is_complete is not None:
            update_data["is_complete"] = goal_data.is_complete

        goal = goal_repo.update(goal_id, **update_data)

        if not goal:
            raise HTTPException(status_code=404, detail="Goal not found")

        return APIResponse(
            message="Goal updated successfully",
            data={
                "id": goal.id,
                "description": goal.description,
                "is_complete": goal.is_complete,
                "updated_at": goal.updated_at.isoformat(),
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update goal: {e!s}")


@router.delete("/{goal_id}", response_model=APIResponse, operation_id="deleteGoal")
async def delete_goal(goal_id: int):
    """Delete a goal"""
    try:
        success = goal_repo.delete(goal_id)

        if not success:
            raise HTTPException(status_code=404, detail="Goal not found")

        return APIResponse(message="Goal deleted successfully", data={"deleted_goal_id": goal_id})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete goal: {e!s}")


@router.get("/{goal_id}/hierarchy", response_model=APIResponse, operation_id="getGoalHierarchy")
async def get_goal_hierarchy(goal_id: int):
    """Get goal hierarchy for dashboard visualization"""
    try:
        goal = goal_repo.get_by_id(goal_id)

        if not goal:
            raise HTTPException(status_code=404, detail="Goal not found")

        tasks_data = []
        if hasattr(goal, "tasks"):
            for task in goal.tasks:
                tasks_data.append(
                    {
                        "id": task.id,
                        "goal_id": task.goal_id,
                        "name": task.name,
                        "instructions": task.instructions,
                        "status": task.status.value,
                        "owner": task.owner,
                        "created_at": task.created_at.isoformat(),
                        "updated_at": task.updated_at.isoformat(),
                    }
                )

        hierarchy_data = {
            "goal": {
                "id": goal.id,
                "description": goal.description,
                "is_complete": goal.is_complete,
                "created_at": goal.created_at.isoformat(),
                "updated_at": goal.updated_at.isoformat(),
            },
            "tasks": tasks_data,
            "summary": {
                "total_tasks": len(tasks_data),
                "completed_tasks": len([t for t in tasks_data if t["status"] == "completed"]),
                "available_tasks": len([t for t in tasks_data if t["status"] == "available"]),
            },
        }

        return APIResponse(message="Goal hierarchy retrieved successfully", data=hierarchy_data)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get goal hierarchy: {e!s}")
