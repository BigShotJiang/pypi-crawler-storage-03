import enum

import sqlalchemy
from sqlalchemy import DateTime, ForeignKey, func
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class TaskStatus(enum.Enum):
    BLOCKED = "blocked"
    AVAILABLE = "available"
    OWNED = "owned"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class Goal(Base):
    __tablename__ = "goals"

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, index=True, autoincrement=True)
    description = sqlalchemy.Column(sqlalchemy.Text, nullable=False)
    is_complete = sqlalchemy.Column(sqlalchemy.Boolean, default=False, nullable=False)
    created_at = sqlalchemy.Column(DateTime, default=func.now(), nullable=False)
    updated_at = sqlalchemy.Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)

    # Relationship to tasks
    tasks = relationship("Task", back_populates="goal", cascade="all, delete-orphan")


class Task(Base):
    __tablename__ = "tasks"

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, index=True, autoincrement=True)
    goal_id = sqlalchemy.Column(sqlalchemy.Integer, ForeignKey("goals.id"), nullable=False)
    name = sqlalchemy.Column(sqlalchemy.String(255), nullable=False)
    instructions = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    status: sqlalchemy.Column[TaskStatus] = sqlalchemy.Column(
        sqlalchemy.Enum(TaskStatus), default=TaskStatus.AVAILABLE, nullable=False
    )
    owner = sqlalchemy.Column(sqlalchemy.String(255), nullable=True)  # External agent ID
    created_at = sqlalchemy.Column(DateTime, default=func.now(), nullable=False)
    updated_at = sqlalchemy.Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)

    # Relationships
    goal = relationship("Goal", back_populates="tasks")
    dependencies = relationship(
        "TaskDependency", foreign_keys="TaskDependency.dependent_task_id", back_populates="dependent_task"
    )
    dependents = relationship(
        "TaskDependency", foreign_keys="TaskDependency.dependency_task_id", back_populates="dependency_task"
    )


class TaskDependency(Base):
    __tablename__ = "task_dependencies"

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, index=True, autoincrement=True)
    dependent_task_id = sqlalchemy.Column(sqlalchemy.Integer, ForeignKey("tasks.id"), nullable=False)
    dependency_task_id = sqlalchemy.Column(sqlalchemy.Integer, ForeignKey("tasks.id"), nullable=False)
    required_data = sqlalchemy.Column(sqlalchemy.Text, nullable=True)  # Optional data requirements
    is_blocked = sqlalchemy.Column(sqlalchemy.Boolean, default=True, nullable=False)  # Derived from dependency status
    created_at = sqlalchemy.Column(DateTime, default=func.now(), nullable=False)

    # Relationships
    dependent_task = relationship("Task", foreign_keys=[dependent_task_id], back_populates="dependencies")
    dependency_task = relationship("Task", foreign_keys=[dependency_task_id], back_populates="dependents")

    # Unique constraint to prevent duplicate dependencies
    __table_args__ = (
        sqlalchemy.UniqueConstraint("dependent_task_id", "dependency_task_id", name="unique_task_dependency"),
    )
