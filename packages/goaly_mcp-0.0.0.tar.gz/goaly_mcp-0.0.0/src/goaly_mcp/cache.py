"""
Simple cache implementation with TTL support and thread safety.
Provides caching for repository methods to reduce database load.
"""

import threading
import time
from collections.abc import Callable
from functools import wraps
from typing import Any, TypeVar

T = TypeVar("T")


class SimpleCache:
    """
    A simple in-memory cache with TTL (Time To Live) support and thread safety.

    Features:
    - Thread-safe operations using RLock
    - TTL-based expiration
    - Automatic cleanup of expired entries
    - Size limit with LRU eviction
    """

    def __init__(self, default_ttl: int = 300, max_size: int = 1000):
        """
        Initialize the cache.

        Args:
            default_ttl: Default time-to-live in seconds (5 minutes)
            max_size: Maximum number of entries before LRU eviction
        """
        self.default_ttl = default_ttl
        self.max_size = max_size
        self._cache: dict[str, dict[str, Any]] = {}
        self._access_order: dict[str, float] = {}  # For LRU tracking
        self._lock = threading.RLock()

    def get(self, key: str) -> Any | None:
        """
        Get value from cache if it exists and hasn't expired.

        Args:
            key: Cache key

        Returns:
            Cached value or None if not found/expired
        """
        with self._lock:
            if key not in self._cache:
                return None

            entry = self._cache[key]
            current_time = time.time()

            # Check if expired
            if current_time > entry["expires_at"]:
                del self._cache[key]
                if key in self._access_order:
                    del self._access_order[key]
                return None

            # Update access order for LRU
            self._access_order[key] = current_time
            return entry["value"]

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """
        Set value in cache with TTL.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds (uses default if None)
        """
        ttl = ttl or self.default_ttl
        expires_at = time.time() + ttl

        with self._lock:
            # Check if we need to evict entries
            if len(self._cache) >= self.max_size and key not in self._cache:
                self._evict_lru()

            self._cache[key] = {"value": value, "expires_at": expires_at, "created_at": time.time()}
            self._access_order[key] = time.time()

    def delete(self, key: str) -> bool:
        """
        Delete entry from cache.

        Args:
            key: Cache key

        Returns:
            True if key existed and was deleted, False otherwise
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                if key in self._access_order:
                    del self._access_order[key]
                return True
            return False

    def clear(self) -> None:
        """Clear all cache entries."""
        with self._lock:
            self._cache.clear()
            self._access_order.clear()

    def invalidate_pattern(self, pattern: str) -> int:
        """
        Invalidate all keys matching a pattern (simple prefix matching).

        Args:
            pattern: Key prefix to match

        Returns:
            Number of keys invalidated
        """
        with self._lock:
            keys_to_delete = [key for key in self._cache if key.startswith(pattern)]
            for key in keys_to_delete:
                self.delete(key)
            return len(keys_to_delete)

    def _evict_lru(self) -> None:
        """Evict least recently used entry."""
        if not self._access_order:
            return

        # Find the key with the oldest access time
        lru_key = min(self._access_order.keys(), key=lambda k: self._access_order[k])
        self.delete(lru_key)

    def cleanup_expired(self) -> int:
        """
        Remove expired entries from cache.

        Returns:
            Number of expired entries removed
        """
        current_time = time.time()
        expired_keys = []

        with self._lock:
            for key, entry in self._cache.items():
                if current_time > entry["expires_at"]:
                    expired_keys.append(key)

            for key in expired_keys:
                self.delete(key)

        return len(expired_keys)

    def stats(self) -> dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache stats
        """
        with self._lock:
            current_time = time.time()
            expired_count = sum(1 for entry in self._cache.values() if current_time > entry["expires_at"])

            return {
                "total_entries": len(self._cache),
                "expired_entries": expired_count,
                "active_entries": len(self._cache) - expired_count,
                "max_size": self.max_size,
                "default_ttl": self.default_ttl,
            }


# Global cache instance
_default_cache = SimpleCache()


def cached(
    ttl: int | None = None, key_prefix: str = "", cache_instance: SimpleCache | None = None
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator to cache function results.

    Args:
        ttl: Time-to-live for cached results (uses cache default if None)
        key_prefix: Prefix for cache keys
        cache_instance: Cache instance to use (uses global default if None)

    Returns:
        Decorated function with caching
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        cache = cache_instance or _default_cache

        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            # Generate cache key from function name and arguments
            # For methods, exclude 'self' from key generation
            key_args = args[1:] if args and hasattr(args[0], func.__name__) else args
            key_parts = (
                [func.__name__] + [str(arg) for arg in key_args] + [f"{k}={v}" for k, v in sorted(kwargs.items())]
            )
            cache_key = f"{key_prefix}:{':'.join(key_parts)}" if key_prefix else ":".join(key_parts)

            # Try to get from cache first
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                return cached_result  # type: ignore[no-any-return]

            # Execute function and cache result
            result = func(*args, **kwargs)
            cache.set(cache_key, result, ttl)
            return result

        # Add cache management methods to the wrapper
        wrapper.cache_clear = lambda: cache.invalidate_pattern(  # type: ignore[attr-defined]
            f"{key_prefix}:{func.__name__}" if key_prefix else func.__name__
        )
        wrapper.cache_stats = cache.stats  # type: ignore[attr-defined]
        wrapper.cache_instance = cache  # type: ignore[attr-defined]

        return wrapper

    return decorator


def invalidate_related_cache(patterns: str | list[str], cache_instance: SimpleCache | None = None) -> int:
    """
    Invalidate cache entries matching one or more patterns.

    Args:
        patterns: Single pattern or list of patterns to invalidate
        cache_instance: Cache instance to use (uses global default if None)

    Returns:
        Total number of keys invalidated
    """
    cache = cache_instance or _default_cache

    if isinstance(patterns, str):
        patterns = [patterns]

    total_invalidated = 0
    for pattern in patterns:
        total_invalidated += cache.invalidate_pattern(pattern)

    return total_invalidated


def get_cache_instance() -> SimpleCache:
    """Get the default cache instance."""
    return _default_cache


def clear_all_cache() -> None:
    """Clear all entries from the default cache."""
    _default_cache.clear()
