"""
Goaly MCP - Goal and Task Management with Model Context Protocol
"""

__version__ = "0.0.0"
