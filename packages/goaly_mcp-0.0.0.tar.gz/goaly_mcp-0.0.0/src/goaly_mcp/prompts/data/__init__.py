"""Prompt data files for Goaly MCP slash commands."""
