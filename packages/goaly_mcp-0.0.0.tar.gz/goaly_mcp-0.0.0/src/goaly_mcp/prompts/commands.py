"""
Static prompt registration for FastMCP slash commands.
Each command loads its prompt text from a file and registers with FastMCP decorators.
"""

try:
    from importlib.resources import files
except ImportError:
    # Python < 3.9 fallback
    from importlib_resources import files  # type: ignore[import-not-found,no-redef]

from fastmcp import FastMCP

from goaly_mcp.prompts.simple_template import render_template_from_string


def _load_prompt(filename: str) -> str:
    """Load a prompt file from the package data directory."""
    try:
        # Try the installed package structure first
        prompt_files = files("goaly_mcp.prompts.data")
    except (ImportError, ModuleNotFoundError):
        try:
            # Fallback for older package structure
            prompt_files = files("prompts.data")
        except (ImportError, ModuleNotFoundError):
            # Development structure fallback
            prompt_files = files("src.prompts.data")

    prompt_file = prompt_files / filename
    return prompt_file.read_text(encoding="utf-8")


def register_prompts(mcp_server: FastMCP):
    """Register all slash command prompts with the FastMCP server."""

    # Resource Management Commands

    @mcp_server.prompt(
        name="manage_goals",
        description="Complete Goal Resource Management with natural language understanding",
        tags={"goals", "management", "crud"},
    )
    async def manage_goals_prompt(user_input: str) -> str:
        """Goal management command that handles create, list, update, and delete operations."""
        prompt_content = _load_prompt("manage_goals.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="manage_tasks",
        description="Complete Task Resource Management with natural language understanding",
        tags={"tasks", "management", "crud"},
    )
    async def manage_tasks_prompt(user_input: str) -> str:
        """Task management command that handles create, list, update, and delete operations."""
        prompt_content = _load_prompt("manage_tasks.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    # Goal Planning and Task Execution Lifecycle Commands

    @mcp_server.prompt(
        name="setup",
        description="Initial project configuration and structure setup",
        tags={"setup", "initialization", "planning"},
    )
    async def setup_prompt(user_input: str) -> str:
        """Project setup and initialization command."""
        prompt_content = _load_prompt("setup.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="plan", description="Strategic goal planning and objective setting", tags={"planning", "strategy", "goals"}
    )
    async def plan_prompt(user_input: str) -> str:
        """Strategic planning command for creating goal structures."""
        prompt_content = _load_prompt("plan.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="breakdown",
        description="Break down goals into concrete, actionable tasks",
        tags={"breakdown", "tasks", "decomposition"},
    )
    async def breakdown_prompt(user_input: str) -> str:
        """Task breakdown command for decomposing goals into tasks."""
        prompt_content = _load_prompt("breakdown.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="generate", description="AI-assisted task generation from requirements", tags={"generation", "ai", "tasks"}
    )
    async def generate_prompt(user_input: str) -> str:
        """AI-assisted task generation command."""
        prompt_content = _load_prompt("generate.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="work",
        description="Find and start available work based on priorities and dependencies",
        tags={"work", "priorities", "available"},
    )
    async def work_prompt(user_input: str) -> str:
        """Work discovery command for finding available tasks."""
        prompt_content = _load_prompt("work.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="status",
        description="Check progress and project health across goals and tasks",
        tags={"status", "progress", "monitoring"},
    )
    async def status_prompt(user_input: str) -> str:
        """Status monitoring command for project health."""
        prompt_content = _load_prompt("status.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="analyze",
        description="Deep analysis of dependencies, complexity, and critical paths",
        tags={"analysis", "dependencies", "complexity"},
    )
    async def analyze_prompt(user_input: str) -> str:
        """Analysis command for dependency and complexity insights."""
        prompt_content = _load_prompt("analyze.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="verify",
        description="Verify task and goal completion and ensure quality",
        tags={"verification", "completion", "quality"},
    )
    async def verify_prompt(user_input: str) -> str:
        """Verification command for checking completion status."""
        prompt_content = _load_prompt("verify.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    @mcp_server.prompt(
        name="enhance",
        description="Optimize and improve workflow efficiency and task organization",
        tags={"enhancement", "optimization", "workflow"},
    )
    async def enhance_prompt(user_input: str) -> str:
        """Enhancement command for workflow optimization."""
        prompt_content = _load_prompt("enhance.txt")
        return render_template_from_string(prompt_content, user_input=user_input)

    print("✅ Registered 11 slash command prompts with FastMCP")
    print("Available commands:")
    print("  Resource Management:")
    print("    /mcp__taskmaster_mcp__manage_goals")
    print("    /mcp__taskmaster_mcp__manage_tasks")
    print("  Lifecycle Commands:")
    print("    /mcp__taskmaster_mcp__setup")
    print("    /mcp__taskmaster_mcp__plan")
    print("    /mcp__taskmaster_mcp__breakdown")
    print("    /mcp__taskmaster_mcp__generate")
    print("    /mcp__taskmaster_mcp__work")
    print("    /mcp__taskmaster_mcp__status")
    print("    /mcp__taskmaster_mcp__analyze")
    print("    /mcp__taskmaster_mcp__verify")
    print("    /mcp__taskmaster_mcp__enhance")
