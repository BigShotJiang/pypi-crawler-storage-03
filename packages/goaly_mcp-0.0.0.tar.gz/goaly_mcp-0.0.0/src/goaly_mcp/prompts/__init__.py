"""
Prompt system for TaskMaster MCP slash commands.
"""

from goaly_mcp.prompts.simple_template import SimpleTemplate, load_template, render_template


def _lazy_register_prompts():
    """Lazy import of register_prompts to avoid circular imports."""
    from goaly_mcp.prompts.commands import register_prompts

    return register_prompts


# Expose register_prompts through lazy loading
def register_prompts(*args, **kwargs):
    """Register all slash command prompts with the FastMCP server."""
    return _lazy_register_prompts()(*args, **kwargs)


__all__ = ["SimpleTemplate", "load_template", "register_prompts", "render_template"]
