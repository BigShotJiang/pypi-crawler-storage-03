"""
Simple and safe template engine for basic variable substitution.
Only supports {variable} syntax with no code execution.
"""

import re
from typing import Any


class SimpleTemplate:
    """A minimal template engine that only supports {variable} substitution."""

    def __init__(self, template_text: str):
        """Initialize with template text containing {variable} placeholders."""
        self.template = template_text

    def render(self, **kwargs: Any) -> str:
        """
        Render the template with provided variables.

        Args:
            **kwargs: Variable values to substitute

        Returns:
            Rendered template with variables substituted

        Raises:
            ValueError: If template contains undefined variables
        """
        # Find all {variable} patterns
        pattern = r"\{([^}]+)\}"
        variables = re.findall(pattern, self.template)

        # Check for undefined variables
        undefined = [var for var in variables if var not in kwargs]
        if undefined:
            raise ValueError(f"Undefined template variables: {', '.join(undefined)}")

        # Simple string replacement (safe - no code execution)
        result = self.template
        for var_name, value in kwargs.items():
            placeholder = f"{{{var_name}}}"
            result = result.replace(placeholder, str(value))

        return result


def load_template(file_path: str) -> SimpleTemplate:
    """
    Load a template from a file.

    Args:
        file_path: Path to the template file

    Returns:
        SimpleTemplate instance

    Raises:
        FileNotFoundError: If template file doesn't exist
        UnicodeDecodeError: If file cannot be decoded as UTF-8
    """
    with open(file_path, encoding="utf-8") as f:
        content = f.read()
    return SimpleTemplate(content)


def render_template(file_path: str, **kwargs: Any) -> str:
    """
    Load and render a template file in one step.

    Args:
        file_path: Path to the template file
        **kwargs: Variable values to substitute

    Returns:
        Rendered template
    """
    template = load_template(file_path)
    return template.render(**kwargs)


def render_template_from_string(template_content: str, **kwargs: Any) -> str:
    """
    Render a template from string content in one step.

    Args:
        template_content: Template content as string
        **kwargs: Variable values to substitute

    Returns:
        Rendered template
    """
    template = SimpleTemplate(template_content)
    return template.render(**kwargs)
