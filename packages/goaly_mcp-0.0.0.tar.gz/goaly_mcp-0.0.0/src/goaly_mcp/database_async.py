"""
Async database configuration and utilities for future async support.
This module provides the foundation for async database operations while
maintaining compatibility with the current synchronous implementation.
"""

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from urllib.parse import urlparse

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from goaly_mcp.database import DATABASE_URL
from goaly_mcp.models import Base

logger = logging.getLogger(__name__)


def convert_to_async_url(sync_url: str) -> str:
    """
    Convert a synchronous database URL to an async-compatible URL.

    Args:
        sync_url: Synchronous database URL (e.g., sqlite:///path/to/db.db)

    Returns:
        Async-compatible database URL (e.g., sqlite+aiosqlite:///path/to/db.db)

    Examples:
        >>> convert_to_async_url("sqlite:///./test.db")
        "sqlite+aiosqlite:///./test.db"
        >>> convert_to_async_url("postgresql://user:pass@localhost/db")
        "postgresql+asyncpg://user:pass@localhost/db"
        >>> convert_to_async_url("mysql://user:pass@localhost/db")
        "mysql+aiomysql://user:pass@localhost/db"
    """
    # Map sync drivers to async drivers
    driver_mapping = {
        "sqlite": "sqlite+aiosqlite",
        "postgresql": "postgresql+asyncpg",
        "mysql": "mysql+aiomysql",
    }

    # Handle URLs that already have async drivers
    async_drivers = {"sqlite+aiosqlite", "postgresql+asyncpg", "mysql+aiomysql"}
    parsed = urlparse(sync_url)

    if parsed.scheme in async_drivers:
        # Already async, return as-is
        logger.debug(f"URL already async: {sync_url}")
        return sync_url

    # Check if it's a sync scheme we can convert
    scheme = parsed.scheme
    if scheme in driver_mapping:
        async_scheme = driver_mapping[scheme]
        # Simple string replacement to preserve original URL structure
        async_url = sync_url.replace(f"{scheme}:", f"{async_scheme}:", 1)
        logger.debug(f"Converted database URL: {sync_url} -> {async_url}")
        return async_url
    elif "+" in scheme:
        # Already has a driver specified, check if base needs conversion
        base_scheme, driver = scheme.split("+", 1)
        if base_scheme in driver_mapping:
            new_scheme = driver_mapping[base_scheme]
            async_url = sync_url.replace(f"{scheme}:", f"{new_scheme}:", 1)
            logger.debug(f"Converted database URL: {sync_url} -> {async_url}")
            return async_url
        else:
            # Unknown base scheme, return as-is
            logger.debug(f"Unknown database scheme: {sync_url}")
            return sync_url
    else:
        # Unknown scheme, return as-is
        logger.debug(f"Unknown database scheme: {sync_url}")
        return sync_url


def validate_async_url(url: str) -> bool:
    """
    Validate that a database URL is async-compatible.

    Args:
        url: Database URL to validate

    Returns:
        True if URL is async-compatible, False otherwise
    """
    async_drivers = {"sqlite+aiosqlite", "postgresql+asyncpg", "mysql+aiomysql"}

    parsed = urlparse(url)
    return parsed.scheme in async_drivers


# Create async database URL
ASYNC_DATABASE_URL = convert_to_async_url(DATABASE_URL)

# Validate the async URL
if not validate_async_url(ASYNC_DATABASE_URL):
    logger.warning(f"Database URL may not be async-compatible: {ASYNC_DATABASE_URL}")

# Create async engine (configured but not initialized yet)
async_engine = None


def create_async_engine_instance(
    url: str | None = None, echo: bool = False, pool_size: int = 5, max_overflow: int = 10
):
    """
    Create an async SQLAlchemy engine instance.

    Args:
        url: Database URL (defaults to ASYNC_DATABASE_URL)
        echo: Whether to echo SQL statements (for debugging)
        pool_size: Size of the connection pool
        max_overflow: Maximum overflow connections

    Returns:
        AsyncEngine instance
    """
    global async_engine

    if url is None:
        url = ASYNC_DATABASE_URL

    # For SQLite, we need different connection parameters
    if url.startswith("sqlite"):
        # SQLite doesn't use connection pooling
        async_engine = create_async_engine(
            url,
            echo=echo,
            # SQLite-specific settings
            connect_args={"check_same_thread": False},
        )
    else:
        # PostgreSQL/MySQL with connection pooling
        async_engine = create_async_engine(
            url,
            echo=echo,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_pre_ping=True,  # Validate connections before use
        )

    logger.info(f"Created async database engine for: {url}")
    return async_engine


def get_async_engine():
    """Get the global async engine, creating it if necessary"""
    global async_engine
    if async_engine is None:
        async_engine = create_async_engine_instance()
    return async_engine


# Create async session factory
def create_async_session_factory():
    """Create an async session factory"""
    engine = get_async_engine()
    return async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,  # Keep objects accessible after commit
        autoflush=True,
        autocommit=False,
    )


# Global async session factory (lazily initialized)
_async_session_local = None


def get_async_session_factory():
    """Get or create the async session factory"""
    global _async_session_local
    if _async_session_local is None:
        _async_session_local = create_async_session_factory()
    return _async_session_local


@asynccontextmanager
async def get_async_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Async database session dependency for FastAPI and other async contexts.

    This is the async equivalent of the sync SessionLocal context manager.

    Usage:
        async with get_async_db() as session:
            # Use session for database operations
            result = await session.execute(select(Goal))
            goals = result.scalars().all()

    Yields:
        AsyncSession: Database session
    """
    session_factory = get_async_session_factory()
    session = session_factory()
    try:
        logger.debug("Created async database session")
        yield session
        await session.commit()
        logger.debug("Committed async database session")
    except Exception as e:
        logger.error(f"Error in async database session: {e}")
        await session.rollback()
        raise
    finally:
        await session.close()
        logger.debug("Closed async database session")


@asynccontextmanager
async def managed_async_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Managed async session context manager with automatic cleanup.

    This provides the same functionality as the sync managed_session but
    for async operations.

    Usage:
        async with managed_async_session() as session:
            # Session is automatically committed and closed
            goal = Goal(description="Async goal")
            session.add(goal)
            # Commit happens automatically

    Yields:
        AsyncSession: Database session with automatic management
    """
    async with get_async_db() as session:
        yield session


async def init_async_database():
    """
    Initialize async database (create tables if they don't exist).

    This function should be called during application startup for
    async-only applications.
    """
    engine = get_async_engine()

    # Import all models to ensure they're registered
    from . import models  # noqa: F401

    logger.info("Initializing async database tables...")
    async with engine.begin() as conn:
        # Create all tables
        await conn.run_sync(Base.metadata.create_all)

    logger.info("Async database initialization complete")


async def close_async_database():
    """
    Close async database connections.

    This should be called during application shutdown.
    """
    global async_engine
    if async_engine is not None:
        logger.info("Closing async database engine...")
        await async_engine.dispose()
        async_engine = None
        logger.info("Async database engine closed")


# Database utilities for testing and development
class AsyncDatabaseUtils:
    """Utility class for async database operations"""

    @staticmethod
    async def create_tables():
        """Create all database tables"""
        await init_async_database()

    @staticmethod
    async def drop_tables():
        """Drop all database tables (use with caution!)"""
        engine = get_async_engine()
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
        logger.warning("All database tables dropped")

    @staticmethod
    async def reset_database():
        """Reset database (drop and recreate all tables)"""
        logger.warning("Resetting database - all data will be lost!")
        await AsyncDatabaseUtils.drop_tables()
        await AsyncDatabaseUtils.create_tables()
        logger.info("Database reset complete")

    @staticmethod
    async def check_connection():
        """Check if async database connection is working"""
        try:
            async with get_async_db() as session:
                # Simple query to test connection
                from sqlalchemy import text

                result = await session.execute(text("SELECT 1"))
                result.scalar()
                logger.info("Async database connection test successful")
                return True
        except Exception as e:
            logger.error(f"Async database connection test failed: {e}")
            return False


# Usage documentation
ASYNC_USAGE_PATTERNS = """
## Async Database Usage Patterns

### 1. Basic Session Usage
```python
from src.database_async import get_async_db

async def my_async_function():
    async with get_async_db() as session:
        result = await session.execute(select(Goal))
        goals = result.scalars().all()
        return goals
```

### 2. Managed Session (Auto-commit)
```python
from src.database_async import managed_async_session

async def create_goal_async(description: str):
    async with managed_async_session() as session:
        goal = Goal(description=description)
        session.add(goal)
        # Auto-commit happens when context exits
        return goal
```

### 3. Repository Pattern (Future Implementation)
```python
class AsyncGoalRepository:
    async def create(self, description: str) -> Goal:
        async with managed_async_session() as session:
            goal = Goal(description=description)
            session.add(goal)
            await session.flush()  # Get ID before commit
            return goal
```

### 4. FastAPI Dependency
```python
from fastapi import Depends
from src.database_async import get_async_db

@router.get("/goals")
async def list_goals_async(session: AsyncSession = Depends(get_async_db)):
    result = await session.execute(select(Goal))
    return result.scalars().all()
```

### 5. Application Lifecycle
```python
# Startup
await init_async_database()

# Shutdown
await close_async_database()
```
"""


if __name__ == "__main__":
    """
    Command-line utility for async database operations.

    Usage:
        python -m src.database_async check    # Check connection
        python -m src.database_async init     # Initialize database
        python -m src.database_async reset    # Reset database
    """
    import asyncio
    import sys

    async def main():
        if len(sys.argv) < 2:
            print("Usage: python -m src.database_async <command>")
            print("Commands: check, init, reset")
            return

        command = sys.argv[1]

        if command == "check":
            success = await AsyncDatabaseUtils.check_connection()
            print("Connection successful!" if success else "Connection failed!")

        elif command == "init":
            await AsyncDatabaseUtils.create_tables()
            print("Database initialized successfully!")

        elif command == "reset":
            confirm = input("This will delete all data. Type 'yes' to confirm: ")
            if confirm.lower() == "yes":
                await AsyncDatabaseUtils.reset_database()
                print("Database reset successfully!")
            else:
                print("Reset cancelled.")

        else:
            print(f"Unknown command: {command}")

    asyncio.run(main())
