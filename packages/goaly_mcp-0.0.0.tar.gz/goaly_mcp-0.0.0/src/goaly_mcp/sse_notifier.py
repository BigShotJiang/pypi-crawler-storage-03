"""
SSE Notification integration for the TaskMaster MCP application

This module provides notifications for the integrated FastAPI/MCP application.
"""

from typing import Any

# Import the SSE functions from the integrated API
try:
    from .api.sse import (
        notify_dependency_added as _notify_dependency_added,
    )
    from .api.sse import (
        notify_goal_created as _notify_goal_created,
    )
    from .api.sse import (
        notify_goal_updated as _notify_goal_updated,
    )
    from .api.sse import (
        notify_task_created as _notify_task_created,
    )
    from .api.sse import (
        notify_task_updated as _notify_task_updated,
    )

    # Re-export the functions
    async def notify_goal_created(goal_data: dict[str, Any]):
        """Notify that a goal was created."""
        try:
            await _notify_goal_created(goal_data)
        except Exception as e:
            print(f"Failed to send goal created notification: {e}")

    async def notify_goal_updated(goal_data: dict[str, Any]):
        """Notify that a goal was updated."""
        try:
            await _notify_goal_updated(goal_data)
        except Exception as e:
            print(f"Failed to send goal updated notification: {e}")

    async def notify_task_created(task_data: dict[str, Any]):
        """Notify that a task was created."""
        try:
            await _notify_task_created(task_data)
        except Exception as e:
            print(f"Failed to send task created notification: {e}")

    async def notify_task_updated(task_data: dict[str, Any]):
        """Notify that a task was updated."""
        try:
            await _notify_task_updated(task_data)
        except Exception as e:
            print(f"Failed to send task updated notification: {e}")

    async def notify_dependency_added(dependency_data: dict[str, Any]):
        """Notify that a task dependency was added."""
        try:
            await _notify_dependency_added(dependency_data)
        except Exception as e:
            print(f"Failed to send dependency added notification: {e}")

except ImportError:
    # Fallback if API module is not available
    print("Warning: SSE API module not available, notifications disabled")

    async def notify_goal_created(goal_data: dict[str, Any]):
        pass

    async def notify_goal_updated(goal_data: dict[str, Any]):
        pass

    async def notify_task_created(task_data: dict[str, Any]):
        pass

    async def notify_task_updated(task_data: dict[str, Any]):
        pass

    async def notify_dependency_added(dependency_data: dict[str, Any]):
        pass
