"""
Service-wide error handler for uncaught exceptions and HTTP errors
"""

import logging
import traceback

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.base import BaseHTTPMiddleware

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    """Middleware to handle uncaught exceptions and log stack traces"""

    async def dispatch(self, request: Request, call_next):
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            # Log the full stack trace for debugging
            logger.error(f"Uncaught exception in {request.method} {request.url.path}: {exc}", exc_info=True)

            # Print stack trace to console for development
            traceback.print_exc()

            # Return a generic 500 error response
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Internal Server Error",
                    "message": "An unexpected error occurred. Check server logs for details.",
                    "request_id": str(id(request)),  # Simple request ID for tracking
                },
            )


def setup_error_handlers(app):
    """Setup error handlers for the FastAPI application"""

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        """Handle HTTP exceptions with consistent format"""
        logger.warning(f"HTTP {exc.status_code} in {request.method} {request.url.path}: {exc.detail}")

        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": get_error_type(exc.status_code),
                "message": exc.detail,
                "detail": exc.detail,  # Add detail field for test compatibility
                "status_code": exc.status_code,
            },
        )

    @app.exception_handler(StarletteHTTPException)
    async def starlette_exception_handler(request: Request, exc: StarletteHTTPException):
        """Handle Starlette HTTP exceptions"""
        logger.warning(f"Starlette HTTP {exc.status_code} in {request.method} {request.url.path}: {exc.detail}")

        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": get_error_type(exc.status_code),
                "message": exc.detail,
                "detail": exc.detail,  # Add detail field for test compatibility
                "status_code": exc.status_code,
            },
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        """Handle validation errors"""
        logger.warning(f"ValueError in {request.method} {request.url.path}: {exc}")

        return JSONResponse(
            status_code=400,
            content={
                "error": "Bad Request",
                "message": str(exc),
                "detail": str(exc),  # Add detail field for test compatibility
                "status_code": 400,
            },
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """Handle all other uncaught exceptions"""
        logger.error(f"Uncaught exception in {request.method} {request.url.path}: {exc}", exc_info=True)

        # Print stack trace to console for development
        traceback.print_exc()

        return JSONResponse(
            status_code=500,
            content={
                "error": "Internal Server Error",
                "message": "An unexpected error occurred. Check server logs for details.",
                "request_id": str(id(request)),
            },
        )


def get_error_type(status_code: int) -> str:
    """Get error type name based on status code"""
    error_types = {
        400: "Bad Request",
        401: "Unauthorized",
        403: "Forbidden",
        404: "Not Found",
        405: "Method Not Allowed",
        409: "Conflict",
        422: "Unprocessable Entity",
        500: "Internal Server Error",
        502: "Bad Gateway",
        503: "Service Unavailable",
    }
    return error_types.get(status_code, "HTTP Error")
