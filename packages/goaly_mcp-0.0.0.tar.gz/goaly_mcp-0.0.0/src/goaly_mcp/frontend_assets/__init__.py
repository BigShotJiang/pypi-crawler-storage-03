"""Frontend assets for Goaly MCP dashboard."""

try:
    from importlib.resources import files
except ImportError:
    # Python < 3.9 fallback
    from importlib_resources import files  # type: ignore[import-not-found,no-redef]

from pathlib import Path


def get_frontend_asset_path(asset_path: str = "") -> Path:
    """
    Get the path to a frontend asset, supporting both bundled and development modes.

    Args:
        asset_path: Relative path to the asset (e.g., "static/css/main.css")

    Returns:
        Path to the asset file

    Raises:
        FileNotFoundError: If the asset doesn't exist in either location
    """
    try:
        # Try bundled resources first (production mode)
        asset_files = files("goaly_mcp.frontend_assets")
        asset_file = asset_files / asset_path if asset_path else asset_files

        # Check if it exists by trying to read it
        if (asset_path and hasattr(asset_file, "is_file") and asset_file.is_file()) or (
            not asset_path and hasattr(asset_file, "is_dir") and asset_file.is_dir()
        ):
            return Path(str(asset_file))

    except (ImportError, ModuleNotFoundError, AttributeError):
        pass

    # Fallback to development mode (frontend/build directory)
    project_root = Path(__file__).parent.parent.parent.parent
    frontend_build_path = project_root / "frontend" / "build"

    asset_file_path = frontend_build_path / asset_path if asset_path else frontend_build_path

    if asset_file_path.exists():
        return asset_file_path

    # If neither exists, raise an error
    raise FileNotFoundError(f"Frontend asset not found: {asset_path or 'frontend build directory'}")


def get_frontend_asset_content(asset_path: str) -> bytes:
    """
    Get the content of a frontend asset as bytes.

    Args:
        asset_path: Relative path to the asset

    Returns:
        Asset content as bytes

    Raises:
        FileNotFoundError: If the asset doesn't exist
    """
    try:
        # Try bundled resources first (production mode)
        asset_files = files("goaly_mcp.frontend_assets")
        asset_file = asset_files / asset_path

        if hasattr(asset_file, "read_bytes"):
            return asset_file.read_bytes()

    except (ImportError, ModuleNotFoundError, AttributeError):
        pass

    # Fallback to development mode
    asset_file_path = get_frontend_asset_path(asset_path)
    return asset_file_path.read_bytes()


def get_frontend_asset_text(asset_path: str, encoding: str = "utf-8") -> str:
    """
    Get the content of a frontend asset as text.

    Args:
        asset_path: Relative path to the asset
        encoding: Text encoding (default: utf-8)

    Returns:
        Asset content as text

    Raises:
        FileNotFoundError: If the asset doesn't exist
    """
    try:
        # Try bundled resources first (production mode)
        asset_files = files("goaly_mcp.frontend_assets")
        asset_file = asset_files / asset_path

        if hasattr(asset_file, "read_text"):
            return asset_file.read_text(encoding=encoding)

    except (ImportError, ModuleNotFoundError, AttributeError):
        pass

    # Fallback to development mode
    asset_file_path = get_frontend_asset_path(asset_path)
    return asset_file_path.read_text(encoding=encoding)


def list_frontend_assets() -> list[str]:
    """
    List all available frontend assets.

    Returns:
        List of asset paths relative to the frontend assets directory
    """
    assets = []

    try:
        # Try bundled resources first
        asset_files = files("goaly_mcp.frontend_assets")

        def _collect_assets(base_path, current_path=""):
            for item in base_path.iterdir():
                if item.name.startswith("__"):
                    continue  # Skip Python package files

                item_path = current_path + "/" + item.name if current_path else item.name

                if hasattr(item, "is_file") and item.is_file():
                    assets.append(item_path)
                elif hasattr(item, "is_dir") and item.is_dir():
                    _collect_assets(item, item_path)

        _collect_assets(asset_files)

        if assets:
            return sorted(assets)

    except (ImportError, ModuleNotFoundError, AttributeError):
        pass

    # Fallback to development mode
    try:
        frontend_build_path = get_frontend_asset_path()

        def _collect_dev_assets(base_path: Path, current_path: str = ""):
            for item in base_path.iterdir():
                if item.name.startswith("."):
                    continue  # Skip hidden files

                item_path = current_path + "/" + item.name if current_path else item.name

                if item.is_file():
                    assets.append(item_path)
                elif item.is_dir():
                    _collect_dev_assets(item, item_path)

        _collect_dev_assets(frontend_build_path)

    except FileNotFoundError:
        pass

    return sorted(assets)


def frontend_assets_available() -> bool:
    """
    Check if frontend assets are available (either bundled or in development).

    Returns:
        True if frontend assets are available, False otherwise
    """
    try:
        get_frontend_asset_path()
        return True
    except FileNotFoundError:
        return False
