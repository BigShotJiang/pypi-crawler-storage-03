"""
Integrated FastAPI application combining FastMCP server and dashboard API
"""

import os
from contextlib import asynccontextmanager

import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

# Load environment variables
load_dotenv()

# FastMCP imports
# Local imports
import sqlalchemy
from fastmcp import FastMCP

# Use absolute imports for proper package structure
from goaly_mcp.api import goals, sse, tasks
from goaly_mcp.config import settings
from goaly_mcp.database import engine
from goaly_mcp.error_handler import ErrorHandlerMiddleware, setup_error_handlers
from goaly_mcp.frontend_loader import frontend_loader, serve_spa_route, serve_static_asset

# Create the MCP server with tools
mcp_server = FastMCP(name="Goaly MCP")

# Import and register MCP tools
from goaly_mcp.mcp_tools import register_mcp_tools
from goaly_mcp.prompts.commands import register_prompts

register_mcp_tools(mcp_server)
register_prompts(mcp_server)

# Create MCP HTTP app
mcp_app = mcp_server.http_app(path="/")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    print("Starting Goaly MCP application...")

    # Note: Database migrations are now handled by Alembic CLI commands
    # Run 'just db-init' or 'just db-upgrade' to set up the database
    # This keeps migration logic separate from application runtime

    # Optional: Check if database is accessible (without creating tables)
    try:
        with engine.connect() as conn:
            # Simple connectivity test
            conn.execute(sqlalchemy.text("SELECT 1"))
        print("✅ Database connection verified")
    except Exception as e:
        print(f"⚠️  Database connection failed: {e}")
        print("💡 Run 'just db-init' to initialize the database")

    # Start MCP server lifespan
    async with mcp_app.lifespan(app):
        yield

    print("Shutting down Goaly MCP application...")


# Create the main FastAPI application
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Hierarchical Goal and Task Management with MCP integration",
    lifespan=lifespan,
)

# Add CORS middleware for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# API Key authentication middleware for MCP endpoints
class MCPAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        # Skip authentication if disabled
        if not settings.auth_enabled:
            return await call_next(request)

        # Only protect MCP endpoints when auth is enabled
        if request.url.path.startswith("/mcp"):
            api_key = request.headers.get("X-API-Key") or request.headers.get("Authorization")
            expected_key = settings.mcp_api_key or os.getenv("TASKMASTER_MCP_SERVER_API_KEY")

            if expected_key and api_key != expected_key:
                return JSONResponse({"error": "Unauthorized"}, status_code=401)

        return await call_next(request)


# Add MCP auth middleware
app.add_middleware(MCPAuthMiddleware)

# Add error handling middleware (should be added after other middleware)
app.add_middleware(ErrorHandlerMiddleware)

# Setup error handlers
setup_error_handlers(app)

# Include API routers
app.include_router(goals.router, prefix="/api/v1")
app.include_router(tasks.router, prefix="/api/v1")
app.include_router(sse.router, prefix="/api/v1")


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "Goaly MCP", "version": "0.0.0"}


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "service": settings.app_name,
        "version": settings.app_version,
        "description": "Goaly MCP",
        "endpoints": {"api": "/api/v1/", "docs": "/docs", "mcp": "/mcp", "health": "/health"},
    }


# Mount the MCP server
app.mount("/mcp", mcp_app)

# Frontend dashboard endpoints using bundled assets
if frontend_loader.is_available():
    # Serve static assets (CSS, JS, images, etc.)
    @app.get("/dashboard/static/{asset_path:path}")
    async def serve_dashboard_static_assets(asset_path: str) -> Response:
        """Serve static dashboard assets (CSS, JS, images, etc.)"""
        return serve_static_asset(f"static/{asset_path}")

    # Serve other specific assets (favicon, manifest, etc.)
    @app.get("/dashboard/{file_path:path}")
    async def serve_dashboard_assets(file_path: str) -> Response:
        """Serve specific dashboard assets and handle SPA routing"""
        # Handle specific asset files first
        if file_path in ["favicon.ico", "manifest.json", "robots.txt", "logo192.png", "logo512.png"]:
            try:
                return serve_static_asset(file_path)
            except HTTPException:
                # If asset not found, fall through to SPA routing
                pass

        # For all other routes (SPA routing), serve index.html
        return serve_spa_route(file_path)

    @app.get("/dashboard")
    async def serve_dashboard_root() -> Response:
        """Serve the React dashboard root"""
        return serve_spa_route()

    # Debug endpoint to list available frontend assets
    @app.get("/dashboard-debug/assets")
    async def list_dashboard_assets():
        """Debug endpoint to list all available frontend assets"""
        if not settings.debug:
            raise HTTPException(status_code=404, detail="Not found")

        return {"available": frontend_loader.is_available(), "assets": frontend_loader.list_available_assets()}

else:

    @app.get("/dashboard")
    async def dashboard_not_available():
        """Dashboard not available - frontend assets not bundled or built"""
        return JSONResponse(
            {
                "error": "Dashboard not available",
                "message": "Frontend assets not found. Either build the frontend or rebuild the wheel package.",
                "instructions": [
                    "For development: cd frontend && pnpm install && pnpm run build",
                    "For production: rebuild the wheel with 'uv build' to include frontend assets",
                ],
            },
            status_code=503,
        )

    @app.get("/dashboard/{path:path}")
    async def dashboard_not_available_catch_all(path: str):
        """Catch-all for dashboard routes when not available"""
        return await dashboard_not_available()


if __name__ == "__main__":
    print(f"Starting Goaly MCP server on {settings.host}:{settings.port}")
    print(f"Dashboard API: http://{settings.host}:{settings.port}/api/v1/")
    print(f"MCP Server: http://{settings.host}:{settings.port}/mcp")
    print(f"API Documentation: http://{settings.host}:{settings.port}/docs")

    uvicorn.run("goaly_mcp.app:app", host=settings.host, port=settings.port, reload=settings.debug)
