"""
Test application factory for creating isolated FastAPI apps for testing.

This module provides a lightweight test application that bypasses the main
app's lifespan manager and database initialization to prevent conflicts
with test database setup.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from goaly_mcp.api import goals, sse, tasks
from goaly_mcp.config import settings
from goaly_mcp.error_handler import ErrorHandlerMiddleware, setup_error_handlers


def create_test_app() -> FastAPI:
    """
    Create a test FastAPI application without lifespan manager.

    This function creates a minimal FastAPI app for testing that includes
    all the necessary routes and middleware but bypasses the lifespan
    manager that causes database connection conflicts.

    Returns:
        FastAPI: Test application instance
    """
    # Create the test FastAPI application without lifespan manager
    app = FastAPI(
        title=f"{settings.app_name} Test",
        version=settings.app_version,
        description="Goaly MCP Test Application",
        # No lifespan manager - this prevents database connection issues
    )

    # Add CORS middleware for frontend integration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Add error handling middleware (should be added after other middleware)
    app.add_middleware(ErrorHandlerMiddleware)

    # Setup error handlers
    setup_error_handlers(app)

    # Include API routers
    app.include_router(goals.router, prefix="/api/v1")
    app.include_router(tasks.router, prefix="/api/v1")
    app.include_router(sse.router, prefix="/api/v1")

    # Health check endpoint for tests
    @app.get("/health")
    async def health_check():
        """Health check endpoint for testing"""
        return {"status": "healthy", "service": "Goaly MCP Test", "version": "0.0.0"}

    # Root endpoint for tests
    @app.get("/")
    async def root():
        """Root endpoint for testing"""
        return {
            "service": f"{settings.app_name} Test",
            "version": settings.app_version,
            "description": "Goaly MCP Test Application",
            "endpoints": {"api": "/api/v1/", "docs": "/docs", "health": "/health"},
        }

    return app
