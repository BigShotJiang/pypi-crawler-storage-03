"""
Configuration settings for Goaly MCP
"""

from pathlib import Path

from pydantic_settings import BaseSettings


def get_frontend_path() -> str:
    """
    Get the frontend path based on environment.
    In development: ../frontend/build
    In package: bundled frontend_build directory
    """
    try:
        # Try to find frontend_build using importlib.resources (for installed packages)
        from importlib.resources import files

        package_files = files("frontend_build")
        if package_files:
            return str(package_files)
    except (ImportError, ModuleNotFoundError):
        pass

    # Check if we're running from a local wheel build (frontend_build exists relative to package)
    current_dir = Path(__file__).parent
    packaged_frontend = current_dir.parent / "frontend_build"

    if packaged_frontend.exists():
        return str(packaged_frontend)

    # Fallback to development path
    return "../frontend/build"


class Settings(BaseSettings):
    """Application settings"""

    # Application
    app_name: str = "Goaly MCP"
    app_version: str = "0.0.0"
    debug: bool = False

    # Server
    host: str = "127.0.0.1"  # Default to localhost only for security
    port: int = 8000

    # Database
    database_url: str = "sqlite+aiosqlite:///./goaly.db"

    # CORS
    cors_origins: list[str] = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
    ]

    # MCP
    mcp_api_key: str = ""

    # Authentication
    auth_enabled: bool = False

    # Frontend - dynamically determined based on environment
    frontend_path: str = get_frontend_path()

    model_config = {
        "env_file": ".env",
        "env_prefix": "GOALY_",
        "extra": "ignore",  # Ignore extra environment variables
    }


# Global settings instance
settings = Settings()
