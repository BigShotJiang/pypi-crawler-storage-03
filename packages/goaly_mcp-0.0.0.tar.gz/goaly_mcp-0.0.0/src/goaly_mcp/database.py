import os
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

# Database URL configuration
RAW_DATABASE_URL = os.getenv("DATABASE_URL")

if not RAW_DATABASE_URL:
    # Fallback for local development if DATABASE_URL is not set
    print("WARNING: DATABASE_URL environment variable not found. Using SQLite for local development.")
    DATABASE_URL = "sqlite:///./goaly.db"
elif RAW_DATABASE_URL.startswith("sqlite"):
    # Support SQLite for local development - convert async URLs to sync
    if RAW_DATABASE_URL.startswith("sqlite+aiosqlite:"):
        DATABASE_URL = RAW_DATABASE_URL.replace("sqlite+aiosqlite:", "sqlite:", 1)
    else:
        DATABASE_URL = RAW_DATABASE_URL
    print(f"Using SQLite database: {DATABASE_URL}")
elif RAW_DATABASE_URL.startswith("postgresql+asyncpg://"):
    # Convert async PostgreSQL URL to sync
    DATABASE_URL = RAW_DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://", 1)
    print(f"Converted asyncpg URL to sync PostgreSQL: {DATABASE_URL}")
elif RAW_DATABASE_URL.startswith("postgres+asyncpg://"):
    # Convert async PostgreSQL URL to sync (alternative format)
    DATABASE_URL = RAW_DATABASE_URL.replace("postgres+asyncpg://", "postgresql://", 1)
    print(f"Converted asyncpg URL to sync PostgreSQL: {DATABASE_URL}")
elif RAW_DATABASE_URL.startswith("postgresql://") or RAW_DATABASE_URL.startswith("postgres://"):
    # Already sync PostgreSQL URL
    DATABASE_URL = RAW_DATABASE_URL
    print(f"Using sync PostgreSQL database: {DATABASE_URL}")
else:
    DATABASE_URL = RAW_DATABASE_URL  # Assume it's already correctly formatted

# Create sync engine
engine = create_engine(DATABASE_URL)

# Create sync session factory
SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
)


def get_db() -> Generator[Session, None, None]:
    """Dependency to get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
