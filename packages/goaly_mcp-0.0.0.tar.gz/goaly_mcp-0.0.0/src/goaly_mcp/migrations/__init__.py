"""Goaly MCP database migrations module."""

__version__ = "1.0.0"
