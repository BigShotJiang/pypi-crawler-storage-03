"""add_performance_indexes

Revision ID: 884fc5465d57
Revises: df08353f6236
Create Date: 2025-08-07 10:48:10.738653

"""

from collections.abc import Sequence

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "884fc5465d57"
down_revision: str | Sequence[str] | None = "df08353f6236"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Upgrade schema."""
    # Add performance indexes for common query patterns

    # Task status index for filtering tasks by status
    op.create_index("idx_task_status", "tasks", ["status"])

    # Task owner index for finding tasks by owner
    op.create_index("idx_task_owner", "tasks", ["owner"])

    # Composite indexes for common query combinations
    op.create_index("idx_task_goal_status", "tasks", ["goal_id", "status"])
    op.create_index("idx_task_goal_status_created", "tasks", ["goal_id", "status", "created_at"])

    # Goal completion index for filtering by completion status
    op.create_index("idx_goal_complete", "goals", ["is_complete"])

    # Dependency indexes for task dependency queries
    op.create_index("idx_dependency_dependent", "task_dependencies", ["dependent_task_id"])
    op.create_index("idx_dependency_task", "task_dependencies", ["dependency_task_id"])


def downgrade() -> None:
    """Downgrade schema."""
    # Remove performance indexes (in reverse order)

    # Remove dependency indexes
    op.drop_index("idx_dependency_task", table_name="task_dependencies")
    op.drop_index("idx_dependency_dependent", table_name="task_dependencies")

    # Remove goal completion index
    op.drop_index("idx_goal_complete", table_name="goals")

    # Remove composite indexes
    op.drop_index("idx_task_goal_status_created", table_name="tasks")
    op.drop_index("idx_task_goal_status", table_name="tasks")

    # Remove single column indexes
    op.drop_index("idx_task_owner", table_name="tasks")
    op.drop_index("idx_task_status", table_name="tasks")
