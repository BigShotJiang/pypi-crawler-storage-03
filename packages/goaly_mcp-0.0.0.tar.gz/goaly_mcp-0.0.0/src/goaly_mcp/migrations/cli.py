"""Modern CLI for database migrations using Click."""

import os
from pathlib import Path

import click

from alembic import command
from alembic.config import Config


def get_alembic_config(database_url: str | None = None) -> Config:
    """Get Alembic configuration with proper path resolution."""
    migrations_dir = Path(__file__).parent
    alembic_ini = migrations_dir / "alembic.ini"

    if not alembic_ini.exists():
        raise RuntimeError(f"alembic.ini not found at {alembic_ini}")

    config = Config(str(alembic_ini))
    config.set_main_option("script_location", str(migrations_dir))

    if database_url:
        config.set_main_option("sqlalchemy.url", database_url)

    return config


@click.group()
@click.option("--database-url", envvar="DATABASE_URL", help="Database URL")
@click.pass_context
def cli(ctx: click.Context, database_url: str | None) -> None:
    """Goaly MCP database migration tools."""
    ctx.ensure_object(dict)
    ctx.obj["database_url"] = database_url


@cli.command()
@click.option("--message", "-m", help="Migration message")
@click.option("--autogenerate/--no-autogenerate", default=True, help="Auto-generate migration")
@click.pass_context
def revision(ctx: click.Context, message: str | None, autogenerate: bool) -> None:
    """Create a new migration revision."""
    config = get_alembic_config(ctx.obj["database_url"])

    if not message:
        message = click.prompt("Migration message")

    click.echo(f"Creating revision: {message}")
    command.revision(config, message=message, autogenerate=autogenerate)
    click.echo("✅ Revision created!")


@cli.command()
@click.option("--revision", default="head", help="Target revision")
@click.pass_context
def upgrade(ctx: click.Context, revision: str) -> None:
    """Upgrade database to a revision."""
    config = get_alembic_config(ctx.obj["database_url"])

    click.echo(f"Upgrading to {revision}...")
    command.upgrade(config, revision)
    click.echo("✅ Database upgraded!")


@cli.command()
@click.option("--revision", required=True, help="Target revision")
@click.pass_context
def downgrade(ctx: click.Context, revision: str) -> None:
    """Downgrade database to a revision."""
    config = get_alembic_config(ctx.obj["database_url"])

    click.echo(f"Downgrading to {revision}...")
    command.downgrade(config, revision)
    click.echo("✅ Database downgraded!")


@cli.command()
@click.pass_context
def current(ctx: click.Context) -> None:
    """Show current database revision."""
    config = get_alembic_config(ctx.obj["database_url"])

    click.echo("Current database revision:")
    command.current(config)


@cli.command()
@click.pass_context
def history(ctx: click.Context) -> None:
    """Show revision history."""
    config = get_alembic_config(ctx.obj["database_url"])

    click.echo("Migration history:")
    command.history(config)


@cli.command()
@click.pass_context
def heads(ctx: click.Context) -> None:
    """Show current available heads in the script directory."""
    config = get_alembic_config(ctx.obj["database_url"])

    click.echo("Available heads:")
    command.heads(config)


@cli.command()
@click.pass_context
def show(ctx: click.Context, revision: str) -> None:
    """Show details of a specific revision."""
    config = get_alembic_config(ctx.obj["database_url"])

    click.echo(f"Revision details for {revision}:")
    command.show(config, revision)


# Simple command functions for direct entry points
def upgrade_command() -> None:
    """Direct upgrade command entry point."""
    database_url = os.getenv("DATABASE_URL")
    config = get_alembic_config(database_url)

    print("🗄️ Running database migrations...")
    command.upgrade(config, "head")
    print("✅ Database migrations completed")


def main() -> None:
    """Entry point for goaly-migrate command."""
    cli()


if __name__ == "__main__":
    main()
