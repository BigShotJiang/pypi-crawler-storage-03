# Goaly MCP

A goal and task management system with Model Context Protocol (MCP) integration and a real-time dashboard.

## Features

- **Goal & Task Management**: Create goals with tasks stored in a DAG
- **MCP Integration**: FastMCP 2.0 server for AI agent interaction
- **Real-time Dashboard**: React-based dashboard with live updates via SSE
- **Task Dependencies**: Manage complex task relationships and blocking dependencies
- **RESTful API**: Complete FastAPI-based REST API
- **Database Migrations**: Alembic-powered database versioning
- **Production Ready**: Docker support, monitoring, and deployment tools

## Quick Start

### Prerequisites

- Python 3.12+
- Node.js 18+
- pnpm (for frontend)

### Installation

```bash
# Complete setup
just setup

# Start development
just serve

# View dashboard
open http://localhost:8000/dashboard
```

### API Documentation

- **Dashboard**: http://localhost:8000/dashboard
- **API Docs**: http://localhost:8000/docs
- **MCP Server**: http://localhost:8000/mcp

## Development

```bash
# Install dependencies
just install

# Run tests
just test

# Format & lint
just fmt && just lint

# Build for production
just build-all
```

## Architecture

- **Backend**: FastAPI + SQLAlchemy + Alembic
- **Frontend**: React + Material-UI + D3.js
- **Database**: PostgreSQL (production) / SQLite (development)
- **MCP Server**: FastMCP 2.0 for AI agent integration
- **Real-time**: Server-Sent Events (SSE)

## 🤝 Contributing

Found a bug? Have an idea? We'd love your help!

- 🐛 [Report issues](https://github.com/toolprint/goaly-mcp/issues)
- 💡 [Share ideas](https://github.com/toolprint/goaly-mcp/discussions)
- 🔧 [Submit PRs](https://github.com/toolprint/goaly-mcp/pulls)

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

______________________________________________________________________

<div align="center">

**Built by developers who got tired of watching AI pick the wrong tools** 🎯

<a href="https://toolprint.ai">
  <img src="./assets/toolprint.png" alt="Toolprint" width="200">
</a>

<p>
  <strong>Built with ❤️ by <a href="https://toolprint.ai">Toolprint</a></strong><br>
  <sub>© 2025 OneGrep, Inc.</sub>
</p>

</div>
