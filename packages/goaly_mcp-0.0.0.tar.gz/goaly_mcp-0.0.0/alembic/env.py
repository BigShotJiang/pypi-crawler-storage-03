import os
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool

from alembic import context

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Import our models metadata
from goaly_mcp.models import Base

target_metadata = Base.metadata

# Set database URL from environment variable (for CLI migrations, use sync drivers)
def get_url():
    """Get database URL from environment variable, converted for sync operations"""
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        # Fallback to default SQLite for development
        database_url = "sqlite:///./goaly.db"

    # Convert async URLs to sync URLs for migrations
    if database_url.startswith("postgresql+asyncpg://"):
        database_url = database_url.replace("postgresql+asyncpg://", "postgresql://", 1)
    elif database_url.startswith("postgres+asyncpg://"):
        database_url = database_url.replace("postgres+asyncpg://", "postgres://", 1)
    elif database_url.startswith("sqlite+aiosqlite:"):
        database_url = database_url.replace("sqlite+aiosqlite:", "sqlite:", 1)
    # Handle standard formats that don't need conversion
    elif database_url.startswith("postgresql://") or database_url.startswith("postgres://") or database_url.startswith("sqlite:"):
        pass  # Already in sync format

    return database_url

def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode using synchronous database operations.

    This is appropriate for CLI-based migrations and avoids the need
    for greenlet dependency while keeping the main application async.
    """
    # Override the URL in configuration for sync operations
    configuration = config.get_section(config.config_ini_section, {})
    configuration["sqlalchemy.url"] = get_url()

    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
