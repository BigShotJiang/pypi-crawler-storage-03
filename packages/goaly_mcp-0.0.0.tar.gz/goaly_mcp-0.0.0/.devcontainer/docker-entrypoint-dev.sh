#!/bin/bash
set -e

# Development entrypoint script for DevContainer
# This script handles initialization in the DevContainer development environment

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}🚀 Starting Goaly MCP Development Environment${NC}"

# Wait for dependencies if needed
echo -e "${BLUE}ℹ️  Checking dependencies...${NC}"

# Initialize database if needed
if [ ! -f "/app/data/goaly.db" ]; then
    echo -e "${YELLOW}📄 Initializing database...${NC}"
    mkdir -p /app/data
    python -m goaly_mcp.migrations.cli upgrade head
    echo -e "${GREEN}✅ Database initialized${NC}"
else
    echo -e "${GREEN}✅ Database exists${NC}"
fi

# Run database migrations
echo -e "${BLUE}🔄 Running database migrations...${NC}"
python -m goaly_mcp.migrations.cli upgrade head
echo -e "${GREEN}✅ Database migrations completed${NC}"

# Start the application
echo -e "${BLUE}🚀 Starting FastAPI server...${NC}"
echo -e "${GREEN}✅ Development environment setup complete!${NC}"
echo -e "${BLUE}ℹ️  The server will start automatically with hot-reload enabled.${NC}"
echo -e "${BLUE}ℹ️  Access the API at http://localhost:8000${NC}"
echo -e "${BLUE}ℹ️  API documentation at http://localhost:8000/docs${NC}"

# Execute the command passed to the container
exec "$@"
