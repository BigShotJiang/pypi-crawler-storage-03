#!/bin/bash
# Post-create script for Goaly MCP devcontainer
# This script runs after the container is created to set up the development environment

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warn() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

log_info "Setting up Goaly MCP development environment..."

# Ensure we're using the correct Python environment
export PATH="/opt/venv/bin:$PATH"

# Install the package in editable mode with all extras
log_info "Installing goaly-mcp in editable mode..."
if SKIP_FRONTEND_BUILD=true /opt/venv/bin/pip install -e ".[dev,test]" --no-deps; then
    log_success "Package installed in editable mode"
else
    log_error "Failed to install package in editable mode"
    exit 1
fi

# Verify the installation
log_info "Verifying package installation..."
if /opt/venv/bin/python -c "import goaly_mcp; print(f'✓ goaly_mcp version: {goaly_mcp.__version__}')"; then
    log_success "Package verification successful"
else
    log_error "Package verification failed"
    exit 1
fi

# Set up pre-commit hooks if available
if [ -f ".pre-commit-config.yaml" ]; then
    log_info "Setting up pre-commit hooks..."
    if /opt/venv/bin/pre-commit install; then
        log_success "Pre-commit hooks installed"
    else
        log_warn "Failed to install pre-commit hooks"
    fi
fi

# Create necessary directories if they don't exist
log_info "Creating necessary directories..."
mkdir -p data logs

# Initialize the database
log_info "Initializing database..."
if [ -z "$SKIP_MIGRATIONS" ]; then
    if /opt/venv/bin/goaly-db-upgrade; then
        log_success "Database initialized successfully"
    else
        log_warn "Database initialization failed - you may need to run migrations manually"
    fi
else
    log_info "Skipping database migrations (SKIP_MIGRATIONS is set)"
fi

# Create a welcome message
cat << EOF > ~/.welcome_message.txt
╔═══════════════════════════════════════════════════════════════╗
║              Welcome to Goaly MCP Development!                 ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  🚀 Quick Start Commands:                                     ║
║                                                               ║
║  Start the server:                                            ║
║    uvicorn goaly_mcp.main:app --reload                      ║
║                                                               ║
║  Run tests:                                                   ║
║    pytest                                                     ║
║                                                               ║
║  Run linting:                                                 ║
║    ruff check .                                              ║
║                                                               ║
║  Run type checking:                                           ║
║    mypy src/                                                  ║
║                                                               ║
║  Database commands:                                           ║
║    goaly-db-upgrade     # Run migrations                     ║
║    goaly-db-revision    # Create new migration               ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF

# Add welcome message to shell startup
if [ -f ~/.zshrc ]; then
    echo 'cat ~/.welcome_message.txt' >> ~/.zshrc
elif [ -f ~/.bashrc ]; then
    echo 'cat ~/.welcome_message.txt' >> ~/.bashrc
fi

log_success "Development environment setup complete!"
log_info "The server will start automatically with hot-reload enabled."
log_info "Access the API at http://localhost:8000"
log_info "API documentation at http://localhost:8000/docs"
