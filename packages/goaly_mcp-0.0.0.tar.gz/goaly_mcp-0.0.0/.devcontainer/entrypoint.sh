#!/bin/bash
set -e

# Simplified entrypoint for devcontainer - package installation is handled by post-create script
# Wait for post-create to complete before starting the application

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}ℹ️  [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

log_error() {
    echo -e "${RED}❌ [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

# Signal handlers for graceful shutdown
shutdown() {
    log_info "Received shutdown signal, cleaning up..."
    if [ -n "$APP_PID" ]; then
        kill -TERM "$APP_PID" 2>/dev/null || true
        wait "$APP_PID" 2>/dev/null || true
    fi
    log_success "Development server shutdown complete"
    exit 0
}

trap shutdown SIGTERM SIGINT

log_info "🚀 Starting Goaly MCP Development Server"

# Ensure we're using the correct virtual environment
export PATH="/opt/venv/bin:$PATH"
export VIRTUAL_ENV="/opt/venv"
export PYTHONPATH="/app/src:${PYTHONPATH:-}"

# Database connectivity check and migrations
if [ "${SKIP_DB_CHECK:-false}" != "true" ] && [ "${SKIP_MIGRATIONS:-false}" != "true" ]; then
    log_info "Running database migrations..."
    if /opt/venv/bin/goaly-db-upgrade; then
        log_success "Database migrations completed"
    else
        log_error "Database migrations failed - continuing anyway for development"
    fi
fi

# Start the application
log_info "Starting Goaly MCP application in development mode..."
log_info "Server will be available at ${GOALY_HOST:-0.0.0.0}:${GOALY_PORT:-8000}"

if [ "${DEBUGPY_ENABLED:-false}" = "true" ]; then
    log_info "🐛 Debug mode enabled on port 5678"
    if [ "${DEBUGPY_WAIT_FOR_CLIENT:-false}" = "true" ]; then
        log_info "⏳ Waiting for debugger client to connect..."
        exec /opt/venv/bin/python -m debugpy --listen 0.0.0.0:5678 --wait-for-client -m goaly_mcp.main &
    else
        log_info "🐛 Debug mode enabled (non-blocking)"
        exec /opt/venv/bin/python -m debugpy --listen 0.0.0.0:5678 -m goaly_mcp.main &
    fi
    APP_PID=$!
else
    log_info "💨 Fast reload mode enabled"

    exec /opt/venv/bin/uvicorn goaly_mcp.main:app \
        --host "${GOALY_HOST:-0.0.0.0}" \
        --port "${GOALY_PORT:-8000}" \
        --reload \
        --reload-dir /app/src \
        --log-level "${LOG_LEVEL:-debug}" \
        --access-log \
        --use-colors &
    APP_PID=$!
fi

log_success "Development server started successfully (PID: $APP_PID)"

# Wait for the application process
wait $APP_PID
