module.exports = {
  env: {
    browser: true,
    es2021: true,
    node: true,
    jest: true,
  },
  extends: [
    'react-app',
    'react-app/jest',
    'plugin:jsx-a11y/recommended',
    'prettier', // Must be last to override other configs
  ],
  plugins: [
    'jsx-a11y',
  ],
  settings: {
    react: {
      version: 'detect',
    },
  },
  rules: {
    // Enhanced rules on top of react-app

    // General Code Quality Rules
    'no-console': ['warn', { allow: ['warn', 'error'] }],
    'no-debugger': 'error',
    'no-alert': 'error',
    'no-var': 'error',
    'prefer-const': 'error',
    'prefer-template': 'error',
    'no-duplicate-imports': 'error',
    'no-empty-function': 'warn',
    'eqeqeq': ['error', 'always'],
    'curly': ['error', 'all'],

    // Code Style Rules (handled by Prettier)
    // Note: Most formatting rules are disabled by eslint-config-prettier
    // Keep only rules that affect code quality, not formatting

    // Accessibility Rules (key ones)
    'jsx-a11y/alt-text': 'error',
    'jsx-a11y/anchor-has-content': 'error',
    'jsx-a11y/aria-props': 'error',
    'jsx-a11y/heading-has-content': 'error',
    'jsx-a11y/label-has-associated-control': 'error',
    'jsx-a11y/no-distracting-elements': 'error',
  },
  overrides: [
    {
      // Less strict rules for test files
      files: ['**/*.test.ts', '**/*.test.tsx', '**/*.spec.ts', '**/*.spec.tsx'],
      rules: {
        '@typescript-eslint/no-non-null-assertion': 'off',
        '@typescript-eslint/no-explicit-any': 'off',
        'no-magic-numbers': 'off',
        'jsx-a11y/click-events-have-key-events': 'off',
        'jsx-a11y/no-noninteractive-element-interactions': 'off',
      },
    },
    {
      // More relaxed rules for configuration files
      files: ['**/*.config.js', '**/*.config.ts', 'setupTests.ts'],
      rules: {
        '@typescript-eslint/no-var-requires': 'off',
        'import/no-extraneous-dependencies': 'off',
      },
    },
    {
      // JavaScript files (if any remain)
      files: ['**/*.js', '**/*.jsx'],
      rules: {
        '@typescript-eslint/no-var-requires': 'off',
        '@typescript-eslint/explicit-function-return-type': 'off',
        '@typescript-eslint/explicit-module-boundary-types': 'off',
      },
    },
  ],
  ignorePatterns: [
    'build/',
    'dist/',
    'node_modules/',
    'public/',
    'src/client/', // Auto-generated API client
    '*.config.js',
    'reportWebVitals.ts', // Create React App file
  ],
};
