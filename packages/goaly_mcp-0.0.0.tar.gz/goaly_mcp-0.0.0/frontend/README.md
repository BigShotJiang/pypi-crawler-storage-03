# Goaly MCP Frontend

A real-time React dashboard for visualizing and managing hierarchical goals and tasks with Server-Sent Events (SSE) for live updates.

## Features

- **Real-time Updates**: SSE connection for live goal and task updates
- **Hierarchical Goal Tree**: D3.js visualization of goal-task relationships
- **Task Dependency Graph**: Interactive React Flow graph showing task dependencies
- **Live Status Indicators**: Color-coded status tracking with progress bars
- **Responsive Design**: Material-UI components for modern interface

## Architecture

### SSE + Advanced Visualization

- **SSE Streaming**: EventSource API for real-time data updates
- **D3.js Visualization**: Interactive hierarchical tree for goals and tasks
- **React Flow**: Node-based task dependency visualization
- **Material-UI**: Modern component library for UI

### Components

- `GoalHierarchyTree`: D3.js-based tree visualization
- `TaskDependencyGraph`: React Flow dependency graph
- `DashboardStats`: Real-time statistics cards
- `ConnectionStatus`: SSE connection indicator

### Hooks

- `useSSEConnection`: Manages EventSource connection with auto-reconnection
- `useGoalData`: Handles data fetching and real-time updates

## Setup

### Prerequisites

- Node.js 18+
- pnpm (recommended package manager)
- Running FastAPI backend on port 8000

### Installation

1. **Install dependencies**:

   ```bash
   pnpm install
   ```

1. **Start development server**:

   ```bash
   pnpm start
   ```

1. **Access dashboard**:
   Open [http://localhost:3000](http://localhost:3000)

## API Endpoints

The dashboard connects to these FastAPI endpoints:

- `GET /api/v1/goals/events` - SSE stream for real-time updates
- `GET /api/v1/goals/hierarchy` - Goal hierarchy data
- `GET /api/v1/tasks/dependencies` - Task dependency graph data

## Real-time Updates

The dashboard automatically updates when:

- Goals are created or updated
- Tasks are created, updated, or completed
- Task dependencies are added
- Task ownership changes

## Build for Production

```bash
pnpm run build
```

## Environment Variables

- `REACT_APP_API_URL`: FastAPI backend URL (default: http://localhost:8000)

## Visualization Features

### Goal Tree

- Expandable/collapsible goal nodes
- Progress indicators for each goal
- Task count display
- Color-coded completion status

### Dependency Graph

- Automatic layout with Dagre
- Animated blocked dependencies
- Interactive node selection
- Minimap for navigation
- Layout switching (vertical/horizontal)

### Status Indicators

- Available: Orange
- Owned: Blue
- Completed: Green
- Blocked: Red
- Cancelled: Gray
