import React, { Suspense } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import {
  CssBaseline,
  AppBar,
  Toolbar,
  Typography,
  Container,
  Grid,
  Paper,
  Box,
  CircularProgress,
} from '@mui/material';
// Use lazy loading for large components to reduce initial bundle size
import {
  LazyGoalHierarchyTree,
  LazyTaskDependencyGraph,
  DashboardStats,
  ConnectionStatus,
} from './components/LazyComponents';
import ErrorBoundary from './components/ErrorBoundary';
import { useSSEConnection } from './hooks/useSSEConnection';
import { useGoalData } from './hooks/useGoalData';
import { NotificationProvider } from './contexts/NotificationContext';
import { config } from './config';
// import WebVitalsMonitor from "./components/WebVitalsMonitor";
// import { useWebVitalsWithReporting } from "./hooks/useWebVitals";

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
});

const AppContent: React.FC = () => {
  // SSE connection for real-time updates
  const { connectionStatus, lastEvent, reconnect } = useSSEConnection();

  // Goal data management
  const { goalHierarchy, dependencyGraph, stats, loading } =
    useGoalData(lastEvent);

  // Web Vitals monitoring (temporarily disabled)
  // useWebVitalsWithReporting();

  return (
    <>
      {/* Skip navigation for keyboard users */}
      <a
        href='#main-content'
        className='skip-link'
        onFocus={(e) => {
          e.target.style.transform = 'translateY(0)';
        }}
        onBlur={(e) => {
          e.target.style.transform = 'translateY(-100%)';
        }}
      >
        Skip to main content
      </a>
      <a
        href='#graph-section'
        className='skip-link'
        onFocus={(e) => {
          e.target.style.transform = 'translateY(0)';
        }}
        onBlur={(e) => {
          e.target.style.transform = 'translateY(-100%)';
        }}
      >
        Skip to task graph
      </a>

      <AppBar position='static' elevation={0} role='banner'>
        <Toolbar>
          <Typography
            variant='h6'
            component='h1'
            sx={{ flexGrow: 1 }}
            aria-label='Goal Task Manager Dashboard - Main application title'
          >
            Goal Task Manager Dashboard
          </Typography>
          <ConnectionStatus status={connectionStatus} onReconnect={reconnect} />
        </Toolbar>
      </AppBar>

      <Container
        maxWidth='xl'
        sx={{
          mt: { xs: 1, sm: 2 },
          mb: { xs: 1, sm: 2 },
          px: { xs: 1, sm: 2 },
        }}
        component='main'
        role='main'
        id='main-content'
      >
        <Grid container spacing={{ xs: 1, sm: 2, md: 3 }}>
          {/* Dashboard Statistics */}
          <Grid item xs={12}>
            <Paper
              sx={{ p: 2 }}
              role='region'
              aria-labelledby='dashboard-stats-heading'
            >
              <Typography
                id='dashboard-stats-heading'
                variant='h6'
                component='h2'
                sx={{ mb: 2 }}
                className='visuallyHidden'
                aria-label='Dashboard Statistics Section'
              >
                Dashboard Statistics
              </Typography>
              <DashboardStats stats={stats} loading={loading} />
            </Paper>
          </Grid>

          {/* Goal Hierarchy Tree */}
          {config.features.showGoalHierarchy && (
            <Grid item xs={12} sm={12} md={6} lg={6}>
              <Paper
                sx={{
                  p: { xs: 1, sm: 2 },
                  height: { xs: 400, sm: 500, md: 600 },
                  mb: { xs: 2, md: 0 },
                }}
                role='region'
                aria-labelledby='goal-hierarchy-heading'
              >
                <Typography
                  id='goal-hierarchy-heading'
                  variant='h6'
                  component='h2'
                  gutterBottom
                >
                  Goal Hierarchy
                </Typography>
                <Box
                  sx={{ height: 'calc(100% - 40px)', overflow: 'auto' }}
                  role='tree'
                  aria-label='Goal hierarchy tree view'
                >
                  <Suspense
                    fallback={
                      <Box
                        display='flex'
                        justifyContent='center'
                        alignItems='center'
                        height='100%'
                        role='status'
                        aria-label='Loading goal hierarchy'
                      >
                        <CircularProgress aria-label='Loading' />
                        <Typography sx={{ ml: 2 }} className='visuallyHidden'>
                          Loading goal hierarchy data
                        </Typography>
                      </Box>
                    }
                  >
                    <LazyGoalHierarchyTree
                      data={goalHierarchy}
                      loading={loading}
                      onGoalSelect={() => {
                        // Goal selection handling not implemented yet
                      }}
                      selectedGoalId={undefined}
                    />
                  </Suspense>
                </Box>
              </Paper>
            </Grid>
          )}

          {/* Task Dependency Graph */}
          <Grid
            item
            xs={12}
            sm={12}
            md={config.features.showGoalHierarchy ? 6 : 12}
            lg={config.features.showGoalHierarchy ? 6 : 12}
            id='graph-section'
          >
            <Paper
              sx={{
                p: { xs: 1, sm: 2 },
                height: {
                  xs: '400px',
                  sm: '500px',
                  md: 'calc(100vh - 300px)',
                  lg: 'calc(100vh - 300px)',
                },
                minHeight: { xs: '400px' },
              }}
              role='region'
              aria-labelledby='task-dependencies-heading'
            >
              <Typography
                id='task-dependencies-heading'
                variant='h6'
                component='h2'
                gutterBottom
              >
                Task Dependencies
              </Typography>
              <Box
                sx={{ height: 'calc(100% - 40px)' }}
                role='img'
                aria-label='Task dependency graph visualization'
              >
                <Suspense
                  fallback={
                    <Box
                      display='flex'
                      justifyContent='center'
                      alignItems='center'
                      height='100%'
                      role='status'
                      aria-label='Loading task dependency graph'
                    >
                      <CircularProgress aria-label='Loading' />
                      <Typography sx={{ ml: 2 }} className='visuallyHidden'>
                        Loading task dependency graph
                      </Typography>
                    </Box>
                  }
                >
                  <LazyTaskDependencyGraph
                    data={dependencyGraph}
                    loading={loading}
                    goals={goalHierarchy.goals || []}
                  />
                </Suspense>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Container>

      {/* Web Vitals Monitor - only in development */}
      {/* Temporarily disabled due to TypeScript issues
      {process.env.NODE_ENV === 'development' && (
        <WebVitalsMonitor
          compact={true}
          position="bottom-right"
        />
      )}
      */}
    </>
  );
};

function App(): JSX.Element {
  return (
    <ErrorBoundary>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <NotificationProvider>
          <AppContent />
        </NotificationProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
