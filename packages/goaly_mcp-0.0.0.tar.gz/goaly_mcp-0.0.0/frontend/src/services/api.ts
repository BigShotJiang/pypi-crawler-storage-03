import axios, { AxiosResponse } from 'axios';

// Core API interfaces that match the frontend expectations
export interface Goal {
  id: number;
  description: string;
  is_complete: boolean;
  progress: number;
  completed_tasks: number;
  total_tasks: number;
  tasks: Task[];
  created_at: string;
  updated_at: string;
  task_count?: number;
}

export interface Task {
  id: number;
  name: string;
  status: string;
  owner?: string;
  importance: number;
  goal_id: number;
  created_at?: string;
  updated_at?: string;
}

export interface APIResponse<T = any> {
  success: boolean;
  message?: string;
  data: T;
  timestamp?: string;
}

export interface GoalHierarchy {
  goals: Goal[];
  summary?: any;
}

export interface DependencyGraphNode {
  id: string;
  name: string;
  status: string;
  owner?: string;
  goal_id: number;
  importance?: number;
}

export interface DependencyGraphEdge {
  id: string;
  source: string;
  target: string;
  is_blocked?: boolean;
  required_data?: string;
}

export interface DependencyGraph {
  nodes: DependencyGraphNode[];
  edges: DependencyGraphEdge[];
  summary?: {
    total_tasks?: number;
    total_dependencies?: number;
    blocked_dependencies?: number;
  };
}

export class APIError extends Error {
  public status: number;
  public statusText: string;
  public response?: any;

  constructor(
    message: string,
    status: number,
    statusText: string,
    response?: any,
  ) {
    super(message);
    this.name = 'APIError';
    this.status = status;
    this.statusText = statusText;
    this.response = response;
  }
}

export class APIClient {
  private baseURL: string;

  constructor(baseURL = '/api/v1') {
    this.baseURL = baseURL;
    axios.defaults.timeout = 10000;
  }

  public async request<T = any>(
    method: 'GET' | 'POST' | 'PUT' | 'DELETE',
    endpoint: string,
    data?: any,
    params?: Record<string, any>,
  ): Promise<APIResponse<T>> {
    try {
      const config = {
        method,
        url: `${this.baseURL}${endpoint}`,
        data,
        params,
        headers: {
          'Content-Type': 'application/json',
        },
      };

      const response: AxiosResponse<APIResponse<T>> = await axios(config);

      // Handle successful responses
      if (response.status >= 200 && response.status < 300) {
        return response.data;
      }

      throw new APIError(
        `Request failed with status ${response.status}`,
        response.status,
        response.statusText,
        response.data,
      );
    } catch (error: any) {
      if (error instanceof APIError) {
        throw error;
      }

      // Handle axios errors
      if (axios.isAxiosError(error)) {
        const status = error.response?.status || 0;
        const statusText = error.response?.statusText || 'Unknown error';
        const message =
          error.response?.data?.message || error.message || 'Network error';

        throw new APIError(message, status, statusText, error.response?.data);
      }

      // Handle other errors
      throw new APIError(
        error.message || 'Unknown error occurred',
        0,
        'Unknown',
        error,
      );
    }
  }
}

// Service implementations
class GoalsServiceImpl {
  private client: APIClient;

  constructor(client: APIClient) {
    this.client = client;
  }

  public async listGoals(
    params: {
      completed_only?: boolean;
      incomplete_only?: boolean;
    } = {},
  ): Promise<APIResponse<GoalHierarchy>> {
    return this.client.request<GoalHierarchy>(
      'GET',
      '/goals/',
      undefined,
      params,
    );
  }

  public async getGoalHierarchy(
    goalId?: number,
  ): Promise<APIResponse<GoalHierarchy>> {
    const endpoint = goalId ? `/goals/${goalId}/hierarchy` : '/goals/hierarchy';
    return this.client.request<GoalHierarchy>('GET', endpoint);
  }

  public async createGoal(goal: Partial<Goal>): Promise<APIResponse<Goal>> {
    return this.client.request<Goal>('POST', '/goals/', goal);
  }

  public async updateGoal(
    goalId: number,
    updates: Partial<Goal>,
  ): Promise<APIResponse<Goal>> {
    return this.client.request<Goal>('PUT', `/goals/${goalId}`, updates);
  }

  public async deleteGoal(goalId: number): Promise<APIResponse<void>> {
    return this.client.request<void>('DELETE', `/goals/${goalId}`);
  }
}

class TasksServiceImpl {
  private client: APIClient;

  constructor(client: APIClient) {
    this.client = client;
  }

  public async listTasks(
    params: {
      goal_id?: number;
      status?: string;
    } = {},
  ): Promise<APIResponse<Task[]>> {
    return this.client.request<Task[]>('GET', '/tasks/', undefined, params);
  }

  public async getDependencyGraph(
    params: {
      goal_id?: number;
    } = {},
  ): Promise<APIResponse<DependencyGraph>> {
    return this.client.request<DependencyGraph>(
      'GET',
      '/tasks/dependencies/graph',
      undefined,
      params,
    );
  }

  public async createTask(task: Partial<Task>): Promise<APIResponse<Task>> {
    return this.client.request<Task>('POST', '/tasks/', task);
  }

  public async updateTask(
    taskId: number,
    updates: Partial<Task>,
  ): Promise<APIResponse<Task>> {
    return this.client.request<Task>('PUT', `/tasks/${taskId}`, updates);
  }

  public async deleteTask(taskId: number): Promise<APIResponse<void>> {
    return this.client.request<void>('DELETE', `/tasks/${taskId}`);
  }

  public async addTaskDependency(
    taskId: number,
    dependsOnId: number,
  ): Promise<APIResponse<void>> {
    return this.client.request<void>('POST', `/tasks/${taskId}/dependencies`, {
      depends_on_id: dependsOnId,
    });
  }
}

// Create singleton instances
const apiClient = new APIClient();
export const GoalsService = new GoalsServiceImpl(apiClient);
export const TasksService = new TasksServiceImpl(apiClient);

// Export the client instance for direct use if needed
export { apiClient };
