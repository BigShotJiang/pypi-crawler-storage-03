/**
 * Frontend configuration for Goaly MCP Dashboard
 */

// Determine the API base URL based on environment
const getApiBaseUrl = () => {
  // In development, use the proxy or explicit localhost
  if (process.env.NODE_ENV === 'development') {
    return process.env.REACT_APP_API_URL || '';
  }

  // In production, use relative URLs since we're served from the same domain
  return '';
};

// Determine the SSE endpoint URL
const getSSEUrl = () => {
  const baseUrl = getApiBaseUrl();
  return `${baseUrl}/api/v1/sse/events`;
};

export const config = {
  // API configuration
  apiBaseUrl: getApiBaseUrl(),
  apiPrefix: '/api/v1',

  // SSE configuration
  sseUrl: getSSEUrl(),
  sseReconnectDelay: 3000,
  sseMaxReconnectAttempts: 5,

  // Dashboard configuration
  dashboardBasePath: '/dashboard',

  // Polling fallback (if SSE fails)
  pollingInterval: 5000,

  // Feature flags
  features: {
    realTimeUpdates: true,
    darkMode: false,
    debugMode: process.env.NODE_ENV === 'development',
    showGoalHierarchy: false,
  },

  // Chart and visualization settings
  charts: {
    refreshInterval: 30000, // 30 seconds
    animationDuration: 300,
  },

  // Notification settings
  notifications: {
    duration: 4000,
    position: 'top-right',
  },
};

// Helper functions for API calls
export const getApiUrl = (endpoint: string): string => {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return `${config.apiBaseUrl}${config.apiPrefix}${cleanEndpoint}`;
};

export const getFullUrl = (path: string): string => {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  return `${config.apiBaseUrl}${cleanPath}`;
};

export default config;
