import React, { createContext, useContext, useState, useCallback } from 'react';
import { Snackbar, Alert, AlertColor } from '@mui/material';

interface NotificationState {
  open: boolean;
  message: string;
  severity: AlertColor;
  autoHideDuration: number;
}

interface NotificationContextType {
  showNotification: (
    message: string,
    severity?: AlertColor,
    duration?: number,
  ) => void;
  announceToScreenReader: (
    message: string,
    priority?: 'polite' | 'assertive',
  ) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(
  undefined,
);

export const useNotification = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error(
      'useNotification must be used within a NotificationProvider',
    );
  }
  return context;
};

interface NotificationProviderProps {
  children: React.ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({
  children,
}) => {
  const [notification, setNotification] = useState<NotificationState>({
    open: false,
    message: '',
    severity: 'info',
    autoHideDuration: 4000,
  });

  const [ariaMessage, setAriaMessage] = useState<string>('');
  const [ariaPriority, setAriaPriority] = useState<'polite' | 'assertive'>(
    'polite',
  );

  const announceToScreenReader = useCallback(
    (message: string, priority: 'polite' | 'assertive' = 'polite') => {
      setAriaPriority(priority);
      setAriaMessage(message);

      // Clear the message after announcement to allow re-announcements
      setTimeout(() => {
        setAriaMessage('');
      }, 1000);
    },
    [],
  );

  const showNotification = useCallback(
    (
      message: string,
      severity: AlertColor = 'info',
      duration: number = 4000,
    ) => {
      setNotification({
        open: true,
        message,
        severity,
        autoHideDuration: duration,
      });

      // Also announce to screen readers for important notifications
      if (severity === 'error' || severity === 'warning') {
        announceToScreenReader(message, 'assertive');
      } else {
        announceToScreenReader(message, 'polite');
      }
    },
    [announceToScreenReader],
  );

  const handleClose = useCallback(
    (_event?: React.SyntheticEvent | Event, reason?: string) => {
      if (reason === 'clickaway') {
        return;
      }
      setNotification((prev) => ({ ...prev, open: false }));
    },
    [],
  );

  return (
    <NotificationContext.Provider
      value={{ showNotification, announceToScreenReader }}
    >
      {children}

      {/* Live region for screen reader announcements */}
      <div
        aria-live={ariaPriority}
        aria-atomic='true'
        className='visuallyHidden'
        role='status'
      >
        {ariaMessage}
      </div>

      <Snackbar
        open={notification.open}
        autoHideDuration={notification.autoHideDuration}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleClose}
          severity={notification.severity}
          variant='filled'
          sx={{ width: '100%' }}
          role='alert'
          aria-live='assertive'
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </NotificationContext.Provider>
  );
};
