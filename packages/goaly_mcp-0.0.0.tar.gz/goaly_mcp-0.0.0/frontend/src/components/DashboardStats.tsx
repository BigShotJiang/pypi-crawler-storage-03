import React from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  LinearProgress,
  Box,
} from '@mui/material';
import {
  Assignment as AssignmentIcon,
  CheckCircle as CheckCircleIcon,
  RadioButtonUnchecked as RadioButtonUncheckedIcon,
  PlayArrow as PlayArrowIcon,
} from '@mui/icons-material';

interface StatsData {
  total_goals?: number;
  completed_goals?: number;
  total_tasks?: number;
  completed_tasks?: number;
}

interface StatCardProps {
  title: string;
  value: number | undefined;
  icon: React.ReactElement;
  color?: 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
  progress?: number | null;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  color = 'primary',
  progress = null,
}) => (
  <Card
    role='region'
    aria-label={`${title} statistics`}
    sx={{
      height: '100%',
      minHeight: { xs: '120px', sm: '140px' },
      '&:hover': {
        elevation: 4,
        transform: 'translateY(-2px)',
        transition: 'all 0.2s ease-in-out',
      },
    }}
  >
    <CardContent sx={{ p: { xs: 2, sm: 3 } }}>
      <Box
        display='flex'
        alignItems='center'
        justifyContent='space-between'
        flexDirection={{ xs: 'column', sm: 'row' }}
        textAlign={{ xs: 'center', sm: 'left' }}
        gap={{ xs: 1, sm: 0 }}
      >
        <Box>
          <Typography
            color='textSecondary'
            gutterBottom
            variant='body2'
            sx={{ fontSize: { xs: '0.75rem', sm: '0.875rem' } }}
            component='dt'
            id={`stat-${title.toLowerCase().replace(/\s+/g, '-')}-label`}
          >
            {title}
          </Typography>
          <Typography
            variant='h4'
            sx={{ fontSize: { xs: '1.5rem', sm: '2.125rem' } }}
            component='dd'
            aria-labelledby={`stat-${title
              .toLowerCase()
              .replace(/\s+/g, '-')}-label`}
          >
            {value || 0}
          </Typography>
          {progress !== null && (
            <Box mt={1}>
              <LinearProgress
                variant='determinate'
                value={progress}
                color={color}
                sx={{ height: 6, borderRadius: 3 }}
                aria-label={`${title} progress: ${Math.round(progress)}%`}
                role='progressbar'
                aria-valuenow={progress}
                aria-valuemin={0}
                aria-valuemax={100}
              />
              <Typography
                variant='caption'
                color='textSecondary'
                aria-hidden='true'
              >
                {Math.round(progress)}%
              </Typography>
            </Box>
          )}
        </Box>
        <Box
          color={`${color}.main`}
          aria-hidden='true'
          sx={{
            '& > svg': {
              fontSize: { xs: '1.5rem', sm: '2.5rem' },
            },
            order: { xs: -1, sm: 0 },
          }}
        >
          {icon}
        </Box>
      </Box>
    </CardContent>
  </Card>
);

interface DashboardStatsProps {
  stats: StatsData;
  loading: boolean;
}

const DashboardStats: React.FC<DashboardStatsProps> = React.memo(
  ({ stats, loading }) => {
    if (loading) {
      return (
        <Grid
          container
          spacing={{ xs: 1, sm: 2, md: 3 }}
          component='div'
          role='status'
          aria-label='Loading dashboard statistics'
        >
          {[1, 2, 3, 4].map((i) => (
            <Grid item xs={12} sm={6} md={3} key={i}>
              <Card aria-label='Loading statistics'>
                <CardContent>
                  <LinearProgress aria-label={`Loading statistic ${i} of 4`} />
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      );
    }

    const goalProgress =
      stats.total_goals && stats.total_goals > 0 && stats.completed_goals
        ? (stats.completed_goals / stats.total_goals) * 100
        : 0;

    const taskProgress =
      stats.total_tasks && stats.total_tasks > 0 && stats.completed_tasks
        ? (stats.completed_tasks / stats.total_tasks) * 100
        : 0;

    return (
      <Grid
        container
        spacing={{ xs: 1, sm: 2, md: 3 }}
        component='dl'
        role='group'
        aria-label='Dashboard statistics overview'
      >
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title='Total Goals'
            value={stats.total_goals}
            icon={<AssignmentIcon fontSize='large' />}
            color='primary'
            progress={goalProgress}
          />
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title='Completed Goals'
            value={stats.completed_goals}
            icon={<CheckCircleIcon fontSize='large' />}
            color='success'
          />
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title='Total Tasks'
            value={stats.total_tasks}
            icon={<PlayArrowIcon fontSize='large' />}
            color='info'
            progress={taskProgress}
          />
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title='Completed Tasks'
            value={stats.completed_tasks}
            icon={<RadioButtonUncheckedIcon fontSize='large' />}
            color='success'
          />
        </Grid>
      </Grid>
    );
  },
);

DashboardStats.displayName = 'DashboardStats';

export default DashboardStats;
