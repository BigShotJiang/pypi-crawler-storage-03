import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  LinearProgress,
  Grid,
  Collapse,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Speed as SpeedIcon,
  Visibility as VisibilityIcon,
  ExpandMore as ExpandMoreIcon,
  TrendingUp as TrendingUpIcon,
  Timeline as TimelineIcon,
} from '@mui/icons-material';
import { useWebVitals } from '../hooks/useWebVitals';
import { useResponsive } from '../hooks/useResponsive';

interface WebVitalsMonitorProps {
  show?: boolean;
  compact?: boolean;
  position?:
    | 'top-right'
    | 'top-left'
    | 'bottom-right'
    | 'bottom-left'
    | 'inline';
}

const WebVitalsMonitor: React.FC<WebVitalsMonitorProps> = ({
  show = process.env.NODE_ENV === 'development',
  compact = false,
  position = 'bottom-right',
}) => {
  const [expanded, setExpanded] = useState(false);
  const [vitalsHistory, setVitalsHistory] = useState<any[]>([]);
  const { isMobile, getCardPadding } = useResponsive();

  const { getCurrentVitals, getVitalsSummary } = useWebVitals({
    onReport: (vitals) => {
      setVitalsHistory((prev) => [...prev.slice(-9), vitals]);
    },
  });

  const summary = getVitalsSummary();
  const vitals = getCurrentVitals();

  const getColorByRating = (
    rating: 'good' | 'needs-improvement' | 'poor',
  ): 'success' | 'warning' | 'error' | 'primary' => {
    switch (rating) {
      case 'good':
        return 'success';
      case 'needs-improvement':
        return 'warning';
      case 'poor':
        return 'error';
      default:
        return 'primary';
    }
  };

  const getIconByMetric = (metric: string) => {
    switch (metric) {
      case 'LCP':
        return <VisibilityIcon fontSize='small' />;
      case 'FID':
        return <SpeedIcon fontSize='small' />;
      case 'CLS':
        return <TimelineIcon fontSize='small' />;
      case 'FCP':
        return <TrendingUpIcon fontSize='small' />;
      case 'TTFB':
        return <SpeedIcon fontSize='small' />;
      default:
        return <SpeedIcon fontSize='small' />;
    }
  };

  const getMetricDescription = (metric: string) => {
    switch (metric) {
      case 'LCP':
        return 'Largest Contentful Paint - Loading performance';
      case 'FID':
        return 'First Input Delay - Interactivity';
      case 'CLS':
        return 'Cumulative Layout Shift - Visual stability';
      case 'FCP':
        return 'First Contentful Paint - Loading';
      case 'TTFB':
        return 'Time to First Byte - Server response';
      default:
        return 'Performance metric';
    }
  };

  const formatValue = (metric: string, value: number) => {
    if (metric === 'CLS') {
      return value.toFixed(3);
    }
    return `${Math.round(value)}ms`;
  };

  if (!show || Object.keys(vitals).length === 0) {
    return null;
  }

  const positionStyles =
    position === 'inline'
      ? {}
      : {
          position: 'fixed' as const,
          zIndex: 1300,
          ...(position.includes('top') && { top: 16 }),
          ...(position.includes('bottom') && { bottom: 16 }),
          ...(position.includes('left') && { left: 16 }),
          ...(position.includes('right') && { right: 16 }),
        };

  const CompactView = () => (
    <Card
      sx={{
        ...positionStyles,
        minWidth: { xs: 200, sm: 240 },
        maxWidth: { xs: 300, sm: 400 },
      }}
    >
      <CardContent
        sx={{ p: getCardPadding(), '&:last-child': { pb: getCardPadding() } }}
      >
        <Box
          display='flex'
          alignItems='center'
          justifyContent='space-between'
          mb={1}
        >
          <Typography variant='subtitle2' component='h3'>
            Web Vitals
          </Typography>
          <Chip
            label={summary.overallRating}
            size='small'
            color={getColorByRating(summary.overallRating)}
            variant='outlined'
          />
        </Box>

        <Grid container spacing={1}>
          {Object.entries(summary.metrics)
            .slice(0, 3)
            .map(([metric, data]) => (
              <Grid item xs={4} key={metric}>
                <Box textAlign='center'>
                  <Tooltip title={getMetricDescription(metric)}>
                    <Box>
                      {getIconByMetric(metric)}
                      <Typography
                        variant='caption'
                        display='block'
                        fontSize='0.7rem'
                      >
                        {metric}
                      </Typography>
                      <Typography
                        variant='caption'
                        display='block'
                        fontWeight='bold'
                      >
                        {formatValue(metric, data.value)}
                      </Typography>
                    </Box>
                  </Tooltip>
                </Box>
              </Grid>
            ))}
        </Grid>

        {!isMobile && (
          <Box display='flex' justifyContent='center' mt={1}>
            <IconButton
              size='small'
              onClick={() => setExpanded(!expanded)}
              sx={{
                transform: expanded ? 'rotate(180deg)' : 'none',
                transition: 'transform 0.2s',
              }}
            >
              <ExpandMoreIcon fontSize='small' />
            </IconButton>
          </Box>
        )}
      </CardContent>
    </Card>
  );

  const ExpandedView = () => (
    <Card sx={{ ...positionStyles, minWidth: 320, maxWidth: 480 }}>
      <CardContent>
        <Box
          display='flex'
          alignItems='center'
          justifyContent='space-between'
          mb={2}
        >
          <Typography variant='h6' component='h3'>
            Performance Metrics
          </Typography>
          <Box>
            <Chip
              label={`Overall: ${summary.overallRating}`}
              color={getColorByRating(summary.overallRating)}
              variant='filled'
            />
            <IconButton
              size='small'
              onClick={() => setExpanded(false)}
              sx={{ ml: 1 }}
            >
              <ExpandMoreIcon sx={{ transform: 'rotate(180deg)' }} />
            </IconButton>
          </Box>
        </Box>

        <Grid container spacing={2}>
          {Object.entries(summary.metrics).map(([metric, data]) => (
            <Grid item xs={12} sm={6} key={metric}>
              <Box>
                <Box display='flex' alignItems='center' mb={1}>
                  {getIconByMetric(metric)}
                  <Typography
                    variant='body2'
                    sx={{ ml: 1, fontWeight: 'bold' }}
                  >
                    {metric}
                  </Typography>
                  <Chip
                    label={data.rating}
                    size='small'
                    color={getColorByRating(data.rating)}
                    sx={{ ml: 'auto', height: 20 }}
                  />
                </Box>

                <Typography
                  variant='caption'
                  color='textSecondary'
                  display='block'
                  mb={1}
                >
                  {getMetricDescription(metric)}
                </Typography>

                <Box display='flex' alignItems='center' mb={1}>
                  <Typography variant='h6'>
                    {formatValue(metric, data.value)}
                  </Typography>
                  <Typography
                    variant='caption'
                    color='textSecondary'
                    sx={{ ml: 1 }}
                  >
                    / {formatValue(metric, data.threshold)} target
                  </Typography>
                </Box>

                <LinearProgress
                  variant='determinate'
                  value={Math.min((data.value / data.threshold) * 100, 100)}
                  color={getColorByRating(data.rating)}
                  sx={{ height: 6, borderRadius: 3 }}
                />
              </Box>
            </Grid>
          ))}
        </Grid>

        {vitalsHistory.length > 0 && (
          <Box mt={2}>
            <Typography variant='subtitle2' mb={1}>
              Recent Measurements ({vitalsHistory.length})
            </Typography>
            <Typography variant='caption' color='textSecondary'>
              Last updated:{' '}
              {new Date(vitals.timestamp || Date.now()).toLocaleTimeString()}
            </Typography>
          </Box>
        )}
      </CardContent>
    </Card>
  );

  if (compact) {
    return (
      <>
        <CompactView />
        {expanded && (
          <Collapse in={expanded}>
            <ExpandedView />
          </Collapse>
        )}
      </>
    );
  }

  return expanded ? <ExpandedView /> : <CompactView />;
};

export default WebVitalsMonitor;
