import React from 'react';
import { Box, Typography } from '@mui/material';
import { Node } from 'reactflow';
import { TaskNodeData } from './TaskNode';

export interface Goal {
  id: number;
  description: string;
  is_complete: boolean;
  task_count?: number;
}

export interface DependencyGraphData {
  nodes: Node<TaskNodeData>[];
  edges: any[];
  stats?: {
    blocked_dependencies?: number;
  };
}

export interface IndividualGoalHeaderProps {
  goal: Goal;
  data: DependencyGraphData;
}

const IndividualGoalHeader: React.FC<IndividualGoalHeaderProps> = ({
  goal,
  data,
}) => {
  // Calculate completion based on tasks - if all tasks for this goal are completed
  const goalTasks = data.nodes.filter((node) => node.data?.goal_id === goal.id);
  const completedTasks = goalTasks.filter(
    (node) => node.data?.status === 'completed',
  );
  const isComplete =
    goalTasks.length > 0 && completedTasks.length === goalTasks.length;

  // Debug info: goalId=${goal.id}, totalTasks=${goalTasks.length}, completedTasks=${completedTasks.length}, isComplete=${isComplete}, manualComplete=${goal.is_complete}

  return (
    <Box
      sx={{
        width: '100%',
        padding: '12px 20px',
        backgroundColor: isComplete
          ? '#e8f5e8 !important'
          : 'rgba(255, 255, 255, 0.95)',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginBottom: '16px',
        border: `2px solid ${isComplete ? '#4caf50' : '#ddd'}`,
      }}
    >
      <Typography
        variant='h6'
        sx={{
          color: isComplete ? '#2e7d32' : '#333',
          fontWeight: 600,
          marginBottom: '4px',
          fontSize: '1.1rem',
        }}
      >
        Goal {goal.id}: {goal.description}
      </Typography>
      <Typography
        variant='body2'
        sx={{
          color: isComplete ? '#388e3c' : '#666',
          display: 'flex',
          alignItems: 'center',
          gap: 1,
        }}
      >
        {isComplete && '✅ '}
        {goal.task_count || 0} tasks
        {isComplete && ' - Goal Complete!'}
      </Typography>
    </Box>
  );
};

export default IndividualGoalHeader;
