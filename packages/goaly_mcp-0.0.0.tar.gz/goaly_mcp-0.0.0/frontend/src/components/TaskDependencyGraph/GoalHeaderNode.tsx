import React from 'react';
import { Box, Typography } from '@mui/material';
import { TaskNodeData } from './TaskNode';

export interface GoalHeaderNodeProps {
  data: TaskNodeData;
}

const GoalHeaderNode: React.FC<GoalHeaderNodeProps> = ({ data }) => {
  return (
    <Box
      sx={{
        minWidth: '600px',
        padding: '12px 24px',
        borderTop: '3px solid #ddd',
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      }}
    >
      <Typography
        variant='h6'
        sx={{
          color: '#666',
          fontWeight: 600,
          fontSize: '1rem',
        }}
      >
        {data.label}
      </Typography>
    </Box>
  );
};

export default GoalHeaderNode;
