import React, { useState } from 'react';
import { EdgeProps, BaseEdge, getBezierPath } from 'reactflow';
import { Tooltip } from '@mui/material';

export interface DependencyEdgeData {
  required_data?: string;
  is_blocked?: boolean;
}

export interface CustomDependencyEdgeProps extends EdgeProps {
  data?: DependencyEdgeData;
}

const CustomDependencyEdge: React.FC<CustomDependencyEdgeProps> = ({
  id: _id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  style = {},
  markerEnd,
  data,
}) => {
  const [isHovered, setIsHovered] = useState(false);

  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

  const hasData = data?.required_data && data.required_data.trim() !== '';
  const isBlocked = data?.is_blocked || false;

  // Calculate symbol position at edge center
  const symbolX = labelX;
  const symbolY = labelY;

  const symbolColor = isBlocked ? '#f44336' : '#1976d2';

  return (
    <g
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <BaseEdge path={edgePath} markerEnd={markerEnd} style={style} />

      {/* Info symbol at edge center when data exists */}
      {hasData && (
        <Tooltip
          title={data.required_data}
          open={isHovered}
          placement='top'
          arrow
          componentsProps={{
            tooltip: {
              sx: {
                fontSize: '12px',
                maxWidth: '300px',
                backgroundColor: 'rgba(0, 0, 0, 0.9)',
                color: 'white',
              },
            },
          }}
        >
          <circle
            cx={symbolX}
            cy={symbolY}
            r={6}
            fill={symbolColor}
            stroke='white'
            strokeWidth={2}
            style={{
              filter: 'drop-shadow(0px 1px 2px rgba(0,0,0,0.3))',
              cursor: 'pointer',
            }}
          />
        </Tooltip>
      )}
    </g>
  );
};

export default CustomDependencyEdge;
