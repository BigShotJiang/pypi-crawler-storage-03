import { Node, Edge, Position, MarkerType } from 'reactflow';
import dagre from 'dagre';
import { LayoutDirection } from '../../../types';
import { TaskNodeData } from '../TaskNode';

/**
 * Auto-layout using Dagre with goal grouping for dependency graphs
 */
export const getLayoutedElements = (
  nodes: Node<TaskNodeData>[],
  edges: Edge[],
  direction: LayoutDirection = 'TB',
  showAllGoals: boolean = false,
) => {
  if (showAllGoals) {
    return getLayoutedElementsWithGoalGrouping(nodes, edges, direction);
  }

  const dagreGraph = new dagre.graphlib.Graph();
  dagreGraph.setDefaultEdgeLabel(() => ({}));
  dagreGraph.setGraph({
    rankdir: direction,
    nodesep: 100, // Horizontal spacing between nodes
    ranksep: 150, // Vertical spacing between ranks
    marginx: 50, // Margin around the graph
    marginy: 50,
  });

  nodes.forEach((node) => {
    // Smaller node dimensions for compact pills
    dagreGraph.setNode(node.id, { width: 180, height: 60 });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  nodes.forEach((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    // Set handle positions based on layout direction
    if (direction === 'LR') {
      node.targetPosition = Position.Left;
      node.sourcePosition = Position.Right;
    } else {
      node.targetPosition = Position.Top;
      node.sourcePosition = Position.Bottom;
    }
    node.position = {
      x: nodeWithPosition.x - 90, // Adjusted for smaller node width
      y: nodeWithPosition.y - 30, // Adjusted for smaller node height
    };
  });

  // Update edges with correct handle references based on layout direction
  const updatedEdges = edges.map((edge: Edge) => ({
    ...edge,
    sourceHandle: direction === 'LR' ? 'right' : 'bottom',
    targetHandle: direction === 'LR' ? 'left' : 'top',
  }));

  return { nodes, edges: updatedEdges };
};

/**
 * Layout with goal grouping for "All Goals" view
 */
export const getLayoutedElementsWithGoalGrouping = (
  nodes: Node<TaskNodeData>[],
  edges: Edge[],
  direction: LayoutDirection = 'TB',
) => {
  // Group nodes by goal
  const nodesByGoal = nodes.reduce(
    (acc: Record<number, Node<TaskNodeData>[]>, node: Node<TaskNodeData>) => {
      const goalId = node.data.goal_id;
      if (!acc[goalId]) {
        acc[goalId] = [];
      }
      acc[goalId].push(node);
      return acc;
    },
    {} as Record<number, Node<TaskNodeData>[]>,
  );

  const goalIds = Object.keys(nodesByGoal).map(Number).sort();
  let currentY = 80; // Start lower to accommodate goal headers
  const goalSpacing = 250; // Increased space between goal groups
  const allNodes: Node<TaskNodeData>[] = [...nodes];

  goalIds.forEach((goalId, _index) => {
    const goalNodes = nodesByGoal[goalId];

    // Add goal header divider node
    const goalHeaderNode: Node<TaskNodeData> = {
      id: `goal-header-${goalId}`,
      type: 'goalHeader',
      position: { x: 50, y: currentY - 50 },
      data: {
        label: `Goal ${goalId}: ${goalNodes[0]?.data.goal_description || ''}`,
        status: 'header',
        goal_id: goalId,
        goal_description: goalNodes[0]?.data.goal_description || '',
        importance: 0,
      },
      draggable: false,
      selectable: false,
    };
    allNodes.push(goalHeaderNode);

    // Layout nodes for this goal using Dagre
    const goalGraph = new dagre.graphlib.Graph();
    goalGraph.setDefaultEdgeLabel(() => ({}));
    goalGraph.setGraph({
      rankdir: direction,
      nodesep: 80,
      ranksep: 120,
      marginx: 30,
      marginy: 30,
    });

    // Add only nodes for this goal
    goalNodes.forEach((node) => {
      goalGraph.setNode(node.id, { width: 180, height: 60 });
    });

    // Add only edges within this goal
    edges
      .filter((edge: Edge) => {
        const sourceGoal = goalNodes.find(
          (n: Node<TaskNodeData>) => n.id === edge.source,
        )?.data.goal_id;
        const targetGoal = goalNodes.find(
          (n: Node<TaskNodeData>) => n.id === edge.target,
        )?.data.goal_id;
        return sourceGoal === goalId && targetGoal === goalId;
      })
      .forEach((edge: Edge) => {
        goalGraph.setEdge(edge.source, edge.target);
      });

    dagre.layout(goalGraph);

    // Position nodes with goal offset
    goalNodes.forEach((node: Node<TaskNodeData>) => {
      const nodeWithPosition = goalGraph.node(node.id);
      // Set handle positions based on layout direction
      if (direction === 'LR') {
        node.targetPosition = Position.Left;
        node.sourcePosition = Position.Right;
      } else {
        node.targetPosition = Position.Top;
        node.sourcePosition = Position.Bottom;
      }
      node.position = {
        x: nodeWithPosition.x - 90,
        y: currentY + nodeWithPosition.y - 30,
      };
    });

    // Calculate the height used by this goal group
    const maxY = Math.max(
      ...goalNodes.map((n: Node<TaskNodeData>) => n.position.y),
    );
    currentY = maxY + goalSpacing;
  });

  // Update edges with correct handle references based on layout direction
  const updatedEdges = edges.map((edge: Edge) => ({
    ...edge,
    sourceHandle: direction === 'LR' ? 'right' : 'bottom',
    targetHandle: direction === 'LR' ? 'left' : 'top',
  }));

  return { nodes: allNodes, edges: updatedEdges };
};

/**
 * Prepare edges with proper styling and animation based on their state
 */
export const prepareLayoutEdges = (edges: Edge[]) => {
  return edges.map((edge) => ({
    ...edge,
    type: 'custom', // Use custom edge component with hover tooltips
    animated: edge.data?.is_blocked || false,
    style: {
      stroke: edge.data?.is_blocked ? '#f44336' : '#1976d2',
      strokeWidth: edge.data?.is_blocked ? 4 : 3,
      strokeDasharray: edge.data?.is_blocked ? '8,4' : 'none',
      strokeLinecap: 'round' as const,
    },
    markerEnd: {
      type: MarkerType.ArrowClosed,
      color: edge.data?.is_blocked ? '#f44336' : '#1976d2',
      width: 15,
      height: 15,
    },
  }));
};
