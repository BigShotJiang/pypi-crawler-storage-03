import { useCallback, useEffect } from 'react';
import {
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
} from 'reactflow';
import { LayoutDirection } from '../../../types';
import { getLayoutedElements, prepareLayoutEdges } from '../utils/layoutUtils';

interface FilteredGraphData {
  nodes: any[];
  edges: any[];
  blockedDependencies: number;
}

/**
 * Custom hook for managing ReactFlow graph layout and interactions
 */
export const useGraphLayout = (
  filteredData: FilteredGraphData,
  layoutDirection: LayoutDirection,
  selectedGoalId: number | 'all',
) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  // Update layout when data changes
  useEffect(() => {
    // Debug info - uncomment if needed
    // console.log("🔍 TaskDependencyGraph Debug Info:", {
    //   nodes: filteredData.nodes.length,
    //   edges: filteredData.edges.length
    // });

    if (filteredData.nodes.length === 0) {
      setNodes([]);
      setEdges([]);
      return;
    }

    // Prepare nodes
    const layoutNodes = filteredData.nodes.map((node) => ({
      ...node,
      type: 'custom',
      data: {
        ...node.data,
        layoutDirection: layoutDirection,
      },
    }));

    // Prepare edges with custom edge component for hover tooltips
    const layoutEdges = prepareLayoutEdges(filteredData.edges);

    // Apply layout
    const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
      layoutNodes,
      layoutEdges,
      layoutDirection,
      selectedGoalId === 'all', // Show goal grouping when "All Goals" is selected
    );

    // console.log("✨ Layout edges prepared:", layoutEdges.length);

    setNodes(layoutedNodes);
    setEdges(layoutedEdges);
  }, [filteredData, layoutDirection, selectedGoalId, setNodes, setEdges]);

  const onConnect = useCallback(
    (params: Edge | Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  );

  const onLayout = useCallback(
    (direction: LayoutDirection) => {
      // Update nodes with new layout direction
      const updatedNodes = nodes.map((node) => ({
        ...node,
        data: {
          ...node.data,
          layoutDirection: direction,
        },
      }));

      const { nodes: layoutedNodes, edges: layoutedEdges } =
        getLayoutedElements(
          updatedNodes,
          edges,
          direction,
          selectedGoalId === 'all',
        );
      setNodes([...layoutedNodes]);
      setEdges([...layoutedEdges]);
    },
    [nodes, edges, selectedGoalId, setNodes, setEdges],
  );

  return {
    nodes,
    edges,
    onNodesChange,
    onEdgesChange,
    onConnect,
    onLayout,
  };
};
