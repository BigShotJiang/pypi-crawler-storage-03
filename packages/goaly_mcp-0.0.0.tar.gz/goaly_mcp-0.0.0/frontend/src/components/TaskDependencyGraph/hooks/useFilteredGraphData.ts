import { useMemo } from 'react';
import { DependencyGraphData } from '../IndividualGoalHeader';

interface FilteredGraphData {
  nodes: any[];
  edges: any[];
  blockedDependencies: number;
}

/**
 * Custom hook to filter dependency graph data based on selected goal
 */
export const useFilteredGraphData = (
  data: DependencyGraphData,
  selectedGoalId: number | 'all',
): FilteredGraphData => {
  return useMemo(() => {
    if (!data.nodes || !data.edges) {
      return { nodes: [], edges: [], blockedDependencies: 0 };
    }

    let filteredNodes = data.nodes;
    let filteredEdges = data.edges;

    // Debug: Goal filtering info
    // console.log("🎯 Goal filtering - selectedGoalId:", selectedGoalId);

    if (selectedGoalId !== 'all') {
      // Filter nodes by goal
      filteredNodes = data.nodes.filter(
        (node) => node.data?.goal_id === selectedGoalId,
      );

      // Filter edges to only include those between filtered nodes
      const nodeIds = new Set(filteredNodes.map((node) => node.id));
      filteredEdges = data.edges.filter(
        (edge) => nodeIds.has(edge.source) && nodeIds.has(edge.target),
      );
    }

    // Calculate blocked dependencies for the filtered data
    const blockedDependencies = filteredEdges.filter(
      (edge) => edge.data?.is_blocked,
    ).length;

    return { nodes: filteredNodes, edges: filteredEdges, blockedDependencies };
  }, [data, selectedGoalId]);
};
