import { useState, useEffect, useCallback } from 'react';

/**
 * Custom hook for managing goal selection and URL synchronization
 */
export const useGoalSelection = (externalSelectedGoalId?: number) => {
  const [selectedGoalId, setSelectedGoalId] = useState<number | 'all'>(() => {
    // Read goal ID from URL on initial load
    const urlParams = new URLSearchParams(window.location.search);
    const goalIdParam = urlParams.get('goalId');
    if (goalIdParam && goalIdParam !== 'all') {
      const goalId = parseInt(goalIdParam, 10);
      if (!isNaN(goalId)) {
        return goalId;
      }
    }
    return 'all';
  });

  // Function to update URL with goal selection
  const updateURL = useCallback((goalId: number | 'all') => {
    const url = new URL(window.location.href);
    if (goalId === 'all') {
      url.searchParams.delete('goalId');
    } else {
      url.searchParams.set('goalId', goalId.toString());
    }
    window.history.replaceState({}, '', url.toString());
  }, []);

  // Keep "All Goals" as default selection or sync with external selection
  useEffect(() => {
    if (externalSelectedGoalId && externalSelectedGoalId !== selectedGoalId) {
      setSelectedGoalId(externalSelectedGoalId);
      // Update URL when externally controlled
      updateURL(externalSelectedGoalId);
    }
  }, [externalSelectedGoalId, selectedGoalId, updateURL]);

  const setSelectedGoalIdWithURL = useCallback(
    (goalId: number | 'all') => {
      setSelectedGoalId(goalId);
      updateURL(goalId);
    },
    [updateURL],
  );

  return {
    selectedGoalId,
    setSelectedGoalId: setSelectedGoalIdWithURL,
  };
};
