import React, { useState } from 'react';
import { NodeProps, Handle, Position } from 'reactflow';
import { Box, Typography, Chip, Paper } from '@mui/material';
import { TaskStatus } from '../../types';
import {
  useTouchInteractions,
  useTouchDevice,
} from '../../hooks/useTouchInteractions';

export interface TaskNodeData {
  label: string;
  status: TaskStatus | string; // Allow string for compatibility
  owner?: string;
  goal_id: number;
  goal_description: string;
  importance: number;
  layoutDirection?: 'TB' | 'LR';
}

export interface TaskNodeProps extends NodeProps<TaskNodeData> {}

const TaskNode: React.FC<TaskNodeProps> = ({ data, selected }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const { isTouchDevice, isCoarsePointer } = useTouchDevice();

  const { touchHandlers } = useTouchInteractions({
    onTap: () => setIsExpanded(!isExpanded),
    onLongPress: () => {
      // Long press to show context menu or additional options - temporarily using console
      console.warn('Long press on task node:', data.label);
    },
    longPressDelay: 600, // Slightly longer for touch devices
  });

  // Touch handlers are available for future use when touch interactions are implemented
  void touchHandlers; // Mark as intentionally used

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'completed':
        return '#4caf50';
      case 'owned':
        return '#2196f3';
      case 'available':
        return '#ff9800';
      case 'blocked':
        return '#f44336';
      case 'cancelled':
        return '#9e9e9e';
      default:
        return '#ccc';
    }
  };

  const getStatusColorRgb = (status: string): string => {
    switch (status) {
      case 'completed':
        return '76, 175, 80';
      case 'owned':
        return '33, 150, 243';
      case 'available':
        return '255, 152, 0';
      case 'blocked':
        return '244, 67, 54';
      case 'cancelled':
        return '158, 158, 158';
      default:
        return '204, 204, 204';
    }
  };

  const getStatusBackgroundColor = (status: string): string => {
    switch (status) {
      case 'completed':
        return '#e8f5e8'; // Light green
      case 'owned':
        return '#e3f2fd'; // Light blue
      case 'available':
        return '#fff8e1'; // Light amber
      case 'blocked':
        return '#ffebee'; // Light red
      case 'cancelled':
        return '#f5f5f5'; // Light gray
      default:
        return '#f5f5f5'; // Default light gray
    }
  };

  const getStatusText = (status: string): string => {
    if (!status || typeof status !== 'string') {
      return 'Unknown';
    }
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  // Compact pill view for default state
  const CompactView = () => (
    <Paper
      elevation={selected ? 4 : 1}
      sx={{
        padding: { xs: '8px 12px', sm: '10px 16px' },
        minWidth: { xs: 100, sm: 120 },
        maxWidth: { xs: 150, sm: 180 },
        minHeight: { xs: isCoarsePointer ? 44 : 44, sm: 40 }, // Minimum touch target size
        border: selected
          ? '2px solid #ff4081'
          : `2px solid ${getStatusColor(data.status)}`,
        backgroundColor: getStatusBackgroundColor(data.status),
        borderRadius: '20px', // Pill shape
        cursor: 'pointer',
        transition: 'all 0.2s ease',
        '&:hover': {
          elevation: 3,
          transform: { xs: 'none', sm: 'scale(1.02)' }, // Disable hover transform on mobile
          boxShadow: `0 0 12px rgba(${getStatusColorRgb(data.status)}, 0.4)`,
          filter: 'brightness(1.05)',
        },
        '@media (hover: none)': {
          '&:hover': {
            transform: 'none',
            filter: 'none',
          },
        },
        // Enhanced touch interactions
        touchAction: 'manipulation', // Prevent zoom on double tap
        userSelect: 'none', // Prevent text selection on mobile
      }}
      onClick={() => setIsExpanded(!isExpanded)}
      role='button'
      tabIndex={0}
      aria-expanded={isExpanded}
      aria-label={`Task: ${data.label}, Status: ${getStatusText(
        data.status,
      )}, Goal: ${data.goal_description}${
        data.owner ? `, Owner: ${data.owner}` : ''
      }. ${isTouchDevice ? 'Tap to' : 'Click to'} ${
        isExpanded ? 'collapse' : 'expand'
      } details.`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          setIsExpanded(!isExpanded);
        }
      }}
    >
      <Box display='flex' justifyContent='center' alignItems='center'>
        <Typography
          variant='body2'
          noWrap
          title={data.label}
          sx={{
            fontSize: { xs: '0.7rem', sm: '0.75rem' },
            fontWeight: { xs: 600, sm: 500 },
            maxWidth: '100%',
            textAlign: 'center',
            color: '#333',
            lineHeight: 1.2,
          }}
          aria-hidden='true'
        >
          {data.label.length > 20
            ? `${data.label.substring(0, 20)}...`
            : data.label}
        </Typography>
      </Box>
    </Paper>
  );

  // Expanded view for click state
  const ExpandedView = () => (
    <Paper
      elevation={8}
      sx={{
        padding: { xs: 1.5, sm: 2 },
        minWidth: { xs: 200, sm: 220 },
        maxWidth: { xs: 260, sm: 280 },
        width: { xs: '90vw', sm: 'auto' }, // Responsive width for mobile
        border: selected ? '2px solid #ff4081' : '2px solid #ddd',
        backgroundColor: 'white',
        zIndex: 1000,
        position: 'relative',
        cursor: 'pointer',
        // Enhanced touch interactions
        touchAction: 'manipulation',
        userSelect: 'none',
        minHeight: isCoarsePointer ? 44 : 'auto',
      }}
      onClick={() => setIsExpanded(!isExpanded)}
      role='button'
      tabIndex={0}
      aria-expanded={isExpanded}
      aria-label={`Task: ${data.label}, Status: ${getStatusText(
        data.status,
      )}, Goal: ${data.goal_description}${
        data.owner ? `, Owner: ${data.owner}` : ''
      }. ${isTouchDevice ? 'Tap to' : 'Click to'} collapse details.`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          setIsExpanded(!isExpanded);
        }
      }}
    >
      <Box>
        <Typography
          variant='subtitle2'
          title={data.label}
          sx={{
            mb: { xs: 0.5, sm: 1 },
            fontSize: { xs: '0.9rem', sm: '0.875rem' },
            fontWeight: { xs: 600, sm: 500 },
            lineHeight: 1.3,
          }}
          component='h3'
          id={`task-${data.label.replace(/\s+/g, '-').toLowerCase()}`}
        >
          {data.label}
        </Typography>

        <Box
          display='flex'
          justifyContent='space-between'
          alignItems='center'
          flexWrap={{ xs: 'wrap', sm: 'nowrap' }}
          gap={{ xs: 1, sm: 0 }}
          mb={{ xs: 0.5, sm: 1 }}
        >
          <Chip
            label={getStatusText(data.status)}
            size='small'
            style={{
              backgroundColor: getStatusColor(data.status),
              color: 'white',
              fontSize: '0.75rem',
            }}
            sx={{
              minHeight: { xs: 32, sm: 24 },
              fontSize: { xs: '0.7rem', sm: '0.75rem' },
            }}
            aria-label={`Task status: ${getStatusText(data.status)}`}
          />

          {data.importance > 0 && (
            <Chip
              label={`Imp: ${data.importance}`}
              size='small'
              variant='outlined'
              sx={{
                fontSize: { xs: '0.65rem', sm: '0.7rem' },
                minHeight: { xs: 32, sm: 24 },
              }}
              aria-label={`Importance level: ${data.importance}`}
            />
          )}
        </Box>

        {data.owner && (
          <Typography
            variant='caption'
            color='textSecondary'
            display='block'
            mb={0.5}
          >
            Owner: {data.owner}
          </Typography>
        )}

        <Typography variant='caption' color='textSecondary' display='block'>
          Goal: {data.goal_description}
        </Typography>
      </Box>
    </Paper>
  );

  // Determine handle positions based on layout direction
  const isHorizontal = data.layoutDirection === 'LR';
  const targetPosition = isHorizontal ? Position.Left : Position.Top;
  const sourcePosition = isHorizontal ? Position.Right : Position.Bottom;

  return (
    <>
      {/* Target handle - for incoming edges */}
      <Handle
        type='target'
        position={targetPosition}
        id={isHorizontal ? 'left' : 'top'}
        style={{
          background: '#555',
          width: 8,
          height: 8,
        }}
        aria-hidden='true'
      />

      {/* Render compact or expanded view based on click */}
      {isExpanded ? <ExpandedView /> : <CompactView />}

      {/* Source handle - for outgoing edges */}
      <Handle
        type='source'
        position={sourcePosition}
        id={isHorizontal ? 'right' : 'bottom'}
        style={{
          background: '#555',
          width: 8,
          height: 8,
        }}
        aria-hidden='true'
      />
    </>
  );
};

export default TaskNode;
