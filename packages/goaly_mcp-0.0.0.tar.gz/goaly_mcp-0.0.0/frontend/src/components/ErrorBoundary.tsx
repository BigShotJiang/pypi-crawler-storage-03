import React, { Component, ReactNode } from 'react';
import {
  Box,
  Typography,
  Button,
  Paper,
  Alert,
  AlertTitle,
  Collapse,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  ExpandMore as ExpandIcon,
} from '@mui/icons-material';

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
  showDetails: boolean;
}

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
  resetKeys?: Array<string | number>;
  resetOnPropsChange?: boolean;
}

/**
 * Error Boundary component that catches JavaScript errors anywhere in the child component tree
 * Provides a fallback UI instead of the component tree that crashed
 *
 * Features:
 * - Custom fallback UI
 * - Error reporting callback
 * - Automatic reset on prop changes
 * - Expandable error details for development
 * - Retry functionality
 */
class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  private resetTimeoutId: number | null = null;

  constructor(props: ErrorBoundaryProps) {
    super(props);

    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    // Update state so the next render will show the fallback UI
    return {
      hasError: true,
      error,
    };
  }

  override componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Store error info and call the error reporting callback
    this.setState({
      error,
      errorInfo,
    });

    // Report error to external service if callback provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Log error to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('ErrorBoundary caught an error:', error, errorInfo);
    }
  }

  override componentDidUpdate(prevProps: ErrorBoundaryProps) {
    const { resetKeys, resetOnPropsChange, children } = this.props;
    const { hasError } = this.state;

    // Reset error state if resetKeys have changed
    if (hasError && resetKeys) {
      const prevResetKeys = prevProps.resetKeys || [];
      const hasResetKeyChanged = resetKeys.some(
        (resetKey, index) => resetKey !== prevResetKeys[index],
      );

      if (hasResetKeyChanged) {
        this.resetErrorState();
      }
    }

    // Reset error state if children have changed and resetOnPropsChange is true
    if (hasError && resetOnPropsChange && children !== prevProps.children) {
      this.resetErrorState();
    }
  }

  override componentWillUnmount() {
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }
  }

  resetErrorState = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
    });
  };

  handleRetry = () => {
    this.resetErrorState();
  };

  handleToggleDetails = () => {
    this.setState((prevState) => ({
      showDetails: !prevState.showDetails,
    }));
  };

  override render() {
    const { hasError, error, errorInfo, showDetails } = this.state;
    const { fallback, children } = this.props;

    if (hasError) {
      // Custom fallback UI if provided
      if (fallback) {
        return fallback;
      }

      // Default error UI
      return (
        <Box
          display='flex'
          flexDirection='column'
          alignItems='center'
          justifyContent='center'
          minHeight='200px'
          p={3}
        >
          <Paper
            elevation={3}
            sx={{
              p: 3,
              maxWidth: 600,
              width: '100%',
            }}
          >
            <Alert severity='error' sx={{ mb: 2 }}>
              <AlertTitle>Something went wrong</AlertTitle>
              <Typography variant='body2' sx={{ mb: 2 }}>
                An unexpected error occurred in this component. This has been
                logged for investigation.
              </Typography>

              <Box display='flex' gap={1} flexWrap='wrap'>
                <Button
                  variant='contained'
                  color='primary'
                  size='small'
                  startIcon={<RefreshIcon />}
                  onClick={this.handleRetry}
                >
                  Try Again
                </Button>

                {process.env.NODE_ENV === 'development' && error && (
                  <Button
                    variant='outlined'
                    size='small'
                    startIcon={<ExpandIcon />}
                    onClick={this.handleToggleDetails}
                  >
                    {showDetails ? 'Hide' : 'Show'} Details
                  </Button>
                )}
              </Box>
            </Alert>

            {/* Error details (development only) */}
            {process.env.NODE_ENV === 'development' && (
              <Collapse in={showDetails}>
                <Paper
                  variant='outlined'
                  sx={{
                    p: 2,
                    mt: 2,
                    backgroundColor: 'grey.50',
                    fontFamily: 'monospace',
                    fontSize: '0.875rem',
                  }}
                >
                  {error && (
                    <Box mb={2}>
                      <Typography variant='subtitle2' color='error'>
                        Error:
                      </Typography>
                      <Typography variant='body2' component='pre'>
                        {error.toString()}
                      </Typography>
                    </Box>
                  )}

                  {errorInfo && errorInfo.componentStack && (
                    <Box>
                      <Typography variant='subtitle2' color='error'>
                        Component Stack:
                      </Typography>
                      <Typography
                        variant='body2'
                        component='pre'
                        sx={{
                          whiteSpace: 'pre-wrap',
                          maxHeight: 300,
                          overflow: 'auto',
                        }}
                      >
                        {errorInfo.componentStack}
                      </Typography>
                    </Box>
                  )}
                </Paper>
              </Collapse>
            )}
          </Paper>
        </Box>
      );
    }

    return children;
  }
}

export default ErrorBoundary;

/**
 * HOC wrapper for functional components to provide error boundary functionality
 */
export function withErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  errorBoundaryProps?: Omit<ErrorBoundaryProps, 'children'>,
) {
  const WrappedComponent = (props: P) => (
    <ErrorBoundary {...errorBoundaryProps}>
      <Component {...props} />
    </ErrorBoundary>
  );

  WrappedComponent.displayName = `withErrorBoundary(${
    Component.displayName || Component.name
  })`;

  return WrappedComponent;
}

/**
 * Hook for throwing errors that will be caught by error boundaries
 */
export function useErrorHandler() {
  return React.useCallback((error: Error) => {
    throw error;
  }, []);
}
