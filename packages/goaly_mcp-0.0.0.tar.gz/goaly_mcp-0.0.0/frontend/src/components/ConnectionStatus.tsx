import React from 'react';
import { Chip } from '@mui/material';
import {
  Circle as CircleIcon,
  Error as ErrorIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { ConnectionStatus as ConnectionStatusType } from '../types';
import { useResponsive } from '../hooks/useResponsive';

interface StatusConfig {
  label: string;
  color:
    | 'default'
    | 'primary'
    | 'secondary'
    | 'error'
    | 'info'
    | 'success'
    | 'warning';
  icon: React.ReactElement;
  onClick?: () => void;
}

interface ConnectionStatusProps {
  status: ConnectionStatusType;
  onReconnect?: () => void;
}

const ConnectionStatus: React.FC<ConnectionStatusProps> = React.memo(
  ({ status, onReconnect }) => {
    const { getTouchTargetSize, isMobile } = useResponsive();
    const getStatusProps = (): StatusConfig => {
      switch (status) {
        case 'connected':
          return {
            label: 'Connected',
            color: 'success',
            icon: <CircleIcon sx={{ fontSize: 12 }} />,
          };
        case 'connecting':
          return {
            label: 'Connecting...',
            color: 'warning',
            icon: <RefreshIcon sx={{ fontSize: 12 }} />,
          };
        case 'disconnected':
          return {
            label: 'Disconnected',
            color: 'error',
            icon: <ErrorIcon sx={{ fontSize: 12 }} />,
            onClick: onReconnect,
          };
        default:
          return {
            label: 'Unknown',
            color: 'default',
            icon: <CircleIcon sx={{ fontSize: 12 }} />,
          };
      }
    };

    const statusProps = getStatusProps();

    return (
      <Chip
        {...statusProps}
        size='small'
        variant='outlined'
        role={statusProps.onClick ? 'button' : 'status'}
        aria-live='polite'
        aria-atomic='true'
        aria-label={`Server connection status: ${statusProps.label}${
          statusProps.onClick ? '. Click to reconnect.' : ''
        }`}
        tabIndex={statusProps.onClick ? 0 : -1}
        onKeyDown={
          statusProps.onClick
            ? (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  statusProps.onClick?.();
                }
              }
            : undefined
        }
        sx={{
          fontSize: { xs: '0.7rem', sm: '0.75rem' },
          height: { xs: getTouchTargetSize(), sm: 24 },
          minHeight: getTouchTargetSize(),
          cursor: statusProps.onClick ? 'pointer' : 'default',
          '&:focus-visible': {
            outline: '2px solid',
            outlineColor: 'primary.main',
            outlineOffset: '2px',
          },
          // Better touch targets on mobile
          ...(isMobile && {
            px: 2,
            '& .MuiChip-label': {
              fontSize: '0.7rem',
              px: 1,
            },
          }),
        }}
      />
    );
  },
);

ConnectionStatus.displayName = 'ConnectionStatus';

export default ConnectionStatus;
