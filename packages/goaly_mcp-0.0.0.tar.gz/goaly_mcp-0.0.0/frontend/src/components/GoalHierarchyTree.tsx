import React, { useEffect, useRef } from 'react';
import { Box, CircularProgress, Typography, Chip } from '@mui/material';
import { useD3Tree, GoalHierarchyData } from '../hooks/useD3Tree';
import { useParentElementDimensions } from '../hooks/useElementDimensions';

interface GoalHierarchyTreeProps {
  data: GoalHierarchyData;
  loading: boolean;
  onGoalSelect: (goalId: number) => void;
  selectedGoalId?: number;
}

const GoalHierarchyTree: React.FC<GoalHierarchyTreeProps> = React.memo(
  ({ data, loading, onGoalSelect, selectedGoalId }) => {
    const svgRef = useRef<SVGSVGElement>(null);

    // Use the custom hook for dimension tracking
    const dimensions = useParentElementDimensions(svgRef, {
      debounceDelay: 100,
      initialDimensions: { width: 0, height: 0 },
    });

    // Use the extracted D3 tree logic
    const { renderD3Tree } = useD3Tree({
      data,
      dimensions,
      selectedGoalId,
      onGoalSelect,
      loading,
    });

    // Render the D3 tree when dependencies change
    useEffect(() => {
      if (svgRef.current) {
        renderD3Tree(svgRef.current);
      }
    }, [renderD3Tree]);

    if (loading) {
      return (
        <Box
          display='flex'
          justifyContent='center'
          alignItems='center'
          height='100%'
          role='status'
          aria-label='Loading goal hierarchy tree'
        >
          <CircularProgress aria-label='Loading' />
          <Typography className='visuallyHidden'>
            Loading goal hierarchy tree data
          </Typography>
        </Box>
      );
    }

    if (!data.goals || data.goals.length === 0) {
      return (
        <Box
          display='flex'
          justifyContent='center'
          alignItems='center'
          height='100%'
          flexDirection='column'
          role='status'
          aria-live='polite'
        >
          <Typography variant='h6' color='textSecondary' component='h3'>
            No goals found
          </Typography>
          <Typography variant='body2' color='textSecondary'>
            Create some goals to see the hierarchy
          </Typography>
        </Box>
      );
    }

    return (
      <Box
        position='relative'
        height='100%'
        role='img'
        aria-label='Goal hierarchy tree visualization'
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Tab') {
            // Allow tab navigation within the SVG
            e.stopPropagation();
          }
        }}
        aria-describedby='tree-instructions'
      >
        <Typography id='tree-instructions' className='visuallyHidden'>
          Interactive goal hierarchy tree. Use Tab to navigate between goal
          nodes. Each node shows goal progress and can be clicked to select.
        </Typography>
        <svg
          ref={svgRef}
          style={{ width: '100%', height: '100%' }}
          role='img'
          aria-label='Goal hierarchy diagram'
          focusable='true'
        />

        {/* Legend */}
        <Box position='absolute' top={0} right={0} p={1}>
          <Box display='flex' flexDirection='column' gap={0.5}>
            <Chip
              size='small'
              label='Goal'
              style={{ backgroundColor: '#2196f3', color: 'white' }}
            />
            <Chip
              size='small'
              label='Completed'
              style={{ backgroundColor: '#4caf50', color: 'white' }}
            />
            <Chip
              size='small'
              label='Available'
              style={{ backgroundColor: '#ff9800', color: 'white' }}
            />
            <Chip
              size='small'
              label='Owned'
              style={{ backgroundColor: '#2196f3', color: 'white' }}
            />
            <Chip
              size='small'
              label='Blocked'
              style={{ backgroundColor: '#f44336', color: 'white' }}
            />
          </Box>
        </Box>
      </Box>
    );
  },
);

GoalHierarchyTree.displayName = 'GoalHierarchyTree';

export default GoalHierarchyTree;
