import React, { useState } from 'react';
import ReactFlow, { Background, Controls, MiniMap } from 'reactflow';
import 'reactflow/dist/style.css';
import {
  Box,
  CircularProgress,
  Typography,
  Chip,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  SelectChangeEvent,
} from '@mui/material';
import { LayoutDirection } from '../types';
import {
  TaskNode,
  CustomDependencyEdge,
  GoalHeaderNode,
  IndividualGoalHeader,
  Goal,
  DependencyGraphData,
} from './TaskDependencyGraph/';
import { useFilteredGraphData } from './TaskDependencyGraph/hooks/useFilteredGraphData';
import { useGoalSelection } from './TaskDependencyGraph/hooks/useGoalSelection';
import { useGraphLayout } from './TaskDependencyGraph/hooks/useGraphLayout';

// Component types and node registry

const nodeTypes = {
  custom: TaskNode,
  goalHeader: GoalHeaderNode,
};

const edgeTypes = {
  custom: CustomDependencyEdge,
};

// Component types moved to TaskDependencyGraph/index.ts

interface TaskDependencyGraphProps {
  data: DependencyGraphData;
  loading: boolean;
  goals: Goal[];
  selectedGoalId?: number;
}

const TaskDependencyGraph: React.FC<TaskDependencyGraphProps> = React.memo(
  ({ data, loading, goals, selectedGoalId: externalSelectedGoalId }) => {
    const [layoutDirection, setLayoutDirection] =
      useState<LayoutDirection>('LR');

    // Custom hooks for functionality separation
    const { selectedGoalId, setSelectedGoalId } = useGoalSelection(
      externalSelectedGoalId,
    );
    const filteredData = useFilteredGraphData(data, selectedGoalId);
    const {
      nodes,
      edges,
      onNodesChange,
      onEdgesChange,
      onConnect,
      onLayout: handleLayout,
    } = useGraphLayout(filteredData, layoutDirection, selectedGoalId);

    const handleGoalChange = (event: SelectChangeEvent<number | 'all'>) => {
      const value = event.target.value as number | 'all';
      setSelectedGoalId(value);
    };

    const onLayout = (direction: LayoutDirection) => {
      handleLayout(direction);
      setLayoutDirection(direction);
    };

    if (loading) {
      return (
        <Box
          display='flex'
          justifyContent='center'
          alignItems='center'
          height='100%'
          role='status'
          aria-label='Loading task dependency graph'
        >
          <CircularProgress aria-label='Loading graph data' />
          <Typography sx={{ ml: 2 }} className='visuallyHidden'>
            Loading task dependency graph data
          </Typography>
        </Box>
      );
    }

    if (filteredData.nodes.length === 0) {
      return (
        <Box height='100%'>
          {/* Goal Selection Header */}
          <Box
            display='flex'
            alignItems='center'
            gap={2}
            mb={2}
            role='toolbar'
            aria-label='Graph controls'
          >
            <FormControl size='small' sx={{ minWidth: 200 }}>
              <InputLabel id='goal-select-label'>Select Goal</InputLabel>
              <Select
                value={selectedGoalId}
                label='Select Goal'
                labelId='goal-select-label'
                onChange={handleGoalChange}
                disabled={loading}
                aria-describedby='goal-select-description'
              >
                <MenuItem value='all'>All Goals</MenuItem>
                {goals.map((goal) => (
                  <MenuItem
                    key={goal.id}
                    value={goal.id}
                    aria-label={`Goal ${goal.id}: ${goal.description}`}
                  >
                    Goal {goal.id}:{' '}
                    {goal.description.length > 50
                      ? `${goal.description.substring(0, 50)}...`
                      : goal.description}
                  </MenuItem>
                ))}
              </Select>
              <Typography
                id='goal-select-description'
                className='visuallyHidden'
              >
                Select a goal to filter the task dependency graph, or choose
                'All Goals' to show all tasks
              </Typography>
            </FormControl>
          </Box>

          <Box
            display='flex'
            justifyContent='center'
            alignItems='center'
            height='calc(100% - 80px)'
            flexDirection='column'
            role='status'
            aria-live='polite'
          >
            <Typography variant='h6' color='textSecondary' component='h3'>
              {selectedGoalId !== 'all'
                ? 'No tasks found for selected goal'
                : 'No tasks found'}
            </Typography>
            <Typography variant='body2' color='textSecondary'>
              {selectedGoalId !== 'all'
                ? 'Try selecting a different goal or create tasks for this goal'
                : 'Create some tasks to see the dependency graph'}
            </Typography>
          </Box>
        </Box>
      );
    }

    return (
      <Box height='100%'>
        {/* Goal Selection Header */}
        <Box
          display='flex'
          alignItems={{ xs: 'stretch', sm: 'center' }}
          flexDirection={{ xs: 'column', sm: 'row' }}
          gap={{ xs: 1, sm: 2 }}
          mb={2}
          role='toolbar'
          aria-label='Graph controls'
        >
          <FormControl
            size='small'
            sx={{
              minWidth: { xs: '100%', sm: 200 },
              maxWidth: { xs: '100%', sm: 300 },
            }}
          >
            <InputLabel id='main-goal-select-label'>Select Goal</InputLabel>
            <Select
              value={selectedGoalId}
              label='Select Goal'
              labelId='main-goal-select-label'
              onChange={handleGoalChange}
              disabled={loading}
              aria-describedby='main-goal-select-description'
            >
              <MenuItem value='all'>All Goals</MenuItem>
              {goals.map((goal) => (
                <MenuItem
                  key={goal.id}
                  value={goal.id}
                  aria-label={`Goal ${goal.id}: ${goal.description}`}
                >
                  Goal {goal.id}:{' '}
                  {goal.description.length > 50
                    ? `${goal.description.substring(0, 50)}...`
                    : goal.description}
                </MenuItem>
              ))}
            </Select>
            <Typography
              id='main-goal-select-description'
              className='visuallyHidden'
            >
              Select a goal to filter the task dependency graph, or choose 'All
              Goals' to show all tasks
            </Typography>
          </FormControl>

          {/* Quick Stats */}
          <Typography
            variant='body2'
            color='textSecondary'
            aria-live='polite'
            role='status'
            sx={{
              alignSelf: { xs: 'flex-start', sm: 'center' },
              fontSize: { xs: '0.75rem', sm: '0.875rem' },
              mt: { xs: 0.5, sm: 0 },
            }}
          >
            Tasks: {filteredData.nodes.length} | Dependencies:{' '}
            {filteredData.edges.length}
          </Typography>
        </Box>

        {/* Individual Goal Header - shown when a specific goal is selected */}
        {selectedGoalId !== 'all' && goals.length > 0 && (
          <IndividualGoalHeader
            goal={goals.find((g) => g.id === selectedGoalId)!}
            data={data}
          />
        )}

        {/* Graph Container */}
        <Box
          position='relative'
          height={
            selectedGoalId !== 'all'
              ? 'calc(100% - 140px)'
              : 'calc(100% - 60px)'
          }
          role='application'
          aria-label='Task dependency graph visualization'
          tabIndex={0}
          onKeyDown={(e) => {
            // Add keyboard navigation for the graph
            if (e.key === 'f') {
              e.preventDefault();
              // Focus first node if available
              const firstNode = document.querySelector(
                '[data-id] button, [data-id] [role="button"]',
              );
              if (firstNode instanceof HTMLElement) {
                firstNode.focus();
              }
            }
          }}
          aria-describedby='graph-instructions'
        >
          <Typography id='graph-instructions' className='visuallyHidden'>
            Interactive task dependency graph. Use Tab to navigate between
            tasks. Press 'f' to focus the first task node. Each task shows its
            status and dependencies.
          </Typography>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            fitView
            attributionPosition='bottom-left'
            aria-label='Task dependency flow diagram'
          >
            <Background />
            <Controls
              aria-label='Graph navigation controls'
              showZoom={true}
              showFitView={true}
              showInteractive={true}
            />
            <MiniMap
              style={{ height: 120 }}
              zoomable
              pannable
              aria-label='Graph minimap overview'
              nodeColor={(node) => {
                switch (node.data.status) {
                  case 'completed':
                    return '#4caf50';
                  case 'owned':
                    return '#2196f3';
                  case 'available':
                    return '#ff9800';
                  case 'blocked':
                    return '#f44336';
                  case 'cancelled':
                    return '#9e9e9e';
                  default:
                    return '#ccc';
                }
              }}
            />
          </ReactFlow>

          {/* Layout Controls */}
          <Box
            position='absolute'
            top={{ xs: 5, sm: 10 }}
            left={{ xs: 5, sm: 10 }}
            zIndex={1000}
            role='group'
            aria-label='Graph layout controls'
          >
            <Box
              display='flex'
              gap={{ xs: 0.5, sm: 1 }}
              flexDirection={{ xs: 'column', sm: 'row' }}
            >
              <Chip
                label='Horizontal'
                size='small'
                clickable
                color={layoutDirection === 'LR' ? 'primary' : 'default'}
                onClick={() => onLayout('LR')}
                role='button'
                tabIndex={0}
                aria-pressed={layoutDirection === 'LR'}
                aria-label='Switch to horizontal layout'
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onLayout('LR');
                  }
                }}
              />
              <Chip
                label='Vertical'
                size='small'
                clickable
                color={layoutDirection === 'TB' ? 'primary' : 'default'}
                onClick={() => onLayout('TB')}
                role='button'
                tabIndex={0}
                aria-pressed={layoutDirection === 'TB'}
                aria-label='Switch to vertical layout'
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onLayout('TB');
                  }
                }}
              />
            </Box>
          </Box>

          {/* Status Legend */}
          <Box position='absolute' top={10} right={10} zIndex={1000}>
            <Paper elevation={2} sx={{ p: 1 }}>
              <Typography variant='caption' display='block' gutterBottom>
                Task Status
              </Typography>
              <Box display='flex' flexDirection='column' gap={0.5}>
                <Chip
                  size='small'
                  label='Available'
                  style={{ backgroundColor: '#ff9800', color: 'white' }}
                />
                <Chip
                  size='small'
                  label='Owned'
                  style={{ backgroundColor: '#2196f3', color: 'white' }}
                />
                <Chip
                  size='small'
                  label='Completed'
                  style={{ backgroundColor: '#4caf50', color: 'white' }}
                />
                <Chip
                  size='small'
                  label='Blocked'
                  style={{ backgroundColor: '#f44336', color: 'white' }}
                />
              </Box>
            </Paper>
          </Box>

          {/* Blocked Dependencies Warning */}
          {filteredData.blockedDependencies > 0 && (
            <Box position='absolute' top={10} right={140} zIndex={1000}>
              <Paper elevation={2} sx={{ p: 1, backgroundColor: '#ffebee' }}>
                <Typography variant='caption' display='block' color='error'>
                  ⚠️ Blocked Dependencies: {filteredData.blockedDependencies}
                </Typography>
              </Paper>
            </Box>
          )}
        </Box>
      </Box>
    );
  },
);

TaskDependencyGraph.displayName = 'TaskDependencyGraph';

export default TaskDependencyGraph;
