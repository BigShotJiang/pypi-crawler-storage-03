import { lazy } from 'react';

/**
 * Lazy-loaded components to improve initial bundle loading
 * Components are loaded only when needed, reducing initial bundle size
 */

// Lazy load the TaskDependencyGraph component (large with ReactFlow dependencies)
export const LazyTaskDependencyGraph = lazy(
  () => import('./TaskDependencyGraph'),
);

// Lazy load the GoalHierarchyTree component (large with D3 dependencies)
export const LazyGoalHierarchyTree = lazy(() => import('./GoalHierarchyTree'));

// Export other components normally since they're small
export { default as DashboardStats } from './DashboardStats';
export { default as ConnectionStatus } from './ConnectionStatus';
