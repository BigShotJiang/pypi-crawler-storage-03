import { useCallback, useMemo } from 'react';
import * as d3 from 'd3';

export interface Goal {
  id: number;
  description: string;
  is_complete: boolean;
  progress: number;
  completed_tasks: number;
  total_tasks: number;
  tasks: Task[];
}

export interface Task {
  id: number;
  name: string;
  status: string;
  owner?: string;
  importance: number;
}

export interface GoalHierarchyData {
  goals: Goal[];
  summary?: any;
}

export interface HierarchicalNode {
  name: string;
  id?: number;
  type?: string;
  data?: Goal | Task;
  parentGoalId?: number;
  children?: HierarchicalNode[];
}

export interface Dimensions {
  width: number;
  height: number;
}

export interface UseD3TreeConfig {
  data: GoalHierarchyData;
  dimensions: Dimensions;
  selectedGoalId?: number;
  onGoalSelect: (goalId: number) => void;
  loading: boolean;
}

/**
 * Custom hook for managing D3 tree visualization logic
 * Extracts all D3-specific tree rendering and interaction logic
 */
export const useD3Tree = ({
  data,
  dimensions,
  selectedGoalId,
  onGoalSelect,
  loading,
}: UseD3TreeConfig) => {
  /**
   * Transforms goal data into hierarchical structure for D3 tree
   * Memoized to avoid recalculating unless goals data changes
   */
  const hierarchicalData = useMemo((): HierarchicalNode => {
    if (!data.goals) {
      return { name: 'Goals', children: [] };
    }

    return {
      name: 'Goals',
      children: data.goals.map((goal) => ({
        name: goal.description,
        id: goal.id,
        type: 'goal',
        data: goal,
        children: goal.tasks.map((task) => ({
          name: task.name,
          id: task.id,
          type: 'task',
          data: task,
          parentGoalId: goal.id,
        })),
      })),
    };
  }, [data.goals]);

  /**
   * Gets node color based on type and status
   */
  const getNodeColor = useCallback((node: HierarchicalNode): string => {
    if (node.type === 'goal' && node.data) {
      const goal = node.data as Goal;
      return goal.is_complete ? '#4caf50' : '#2196f3';
    }
    if (node.type === 'task' && node.data) {
      const task = node.data as Task;
      switch (task.status) {
        case 'completed':
          return '#4caf50';
        case 'owned':
          return '#2196f3';
        case 'available':
          return '#ff9800';
        case 'blocked':
          return '#f44336';
        case 'cancelled':
          return '#9e9e9e';
        default:
          return '#ccc';
      }
    }
    return '#666';
  }, []);

  /**
   * Gets node radius based on type
   */
  const getNodeRadius = useCallback((node: HierarchicalNode): number => {
    if (node.type === 'goal') {
      return 8;
    }
    if (node.type === 'task') {
      return 6;
    }
    return 10;
  }, []);

  /**
   * Gets stroke color for selected goals
   */
  const getStrokeColor = useCallback(
    (node: HierarchicalNode): string => {
      if (node.type === 'goal' && node.id === selectedGoalId) {
        return '#ff4081';
      }
      return '#fff';
    },
    [selectedGoalId],
  );

  /**
   * Gets stroke width for selected goals
   */
  const getStrokeWidth = useCallback(
    (node: HierarchicalNode): string => {
      if (node.type === 'goal' && node.id === selectedGoalId) {
        return '3px';
      }
      return '2px';
    },
    [selectedGoalId],
  );

  /**
   * Gets font size based on node type
   */
  const getFontSize = useCallback((node: HierarchicalNode): string => {
    if (node.type === 'goal') {
      return '14px';
    }
    if (node.type === 'task') {
      return '12px';
    }
    return '16px';
  }, []);

  /**
   * Gets font weight based on node type
   */
  const getFontWeight = useCallback((node: HierarchicalNode): string => {
    return node.type === 'goal' ? 'bold' : 'normal';
  }, []);

  /**
   * Truncates text to fit within visualization constraints
   */
  const truncateText = useCallback(
    (text: string, maxLength: number = 30): string => {
      if (text.length > maxLength) {
        return `${text.substring(0, maxLength - 3)}...`;
      }
      return text;
    },
    [],
  );

  /**
   * Creates tooltip text for nodes
   */
  const createTooltipText = useCallback((node: HierarchicalNode): string => {
    if (node.type === 'goal' && node.data) {
      const goal = node.data as Goal;
      return `Goal: ${goal.description}\nProgress: ${goal.progress.toFixed(
        1,
      )}%\nTasks: ${goal.completed_tasks}/${goal.total_tasks}`;
    }
    if (node.type === 'task' && node.data) {
      const task = node.data as Task;
      return `Task: ${task.name}\nStatus: ${task.status}\nOwner: ${
        task.owner || 'Unassigned'
      }\nImportance: ${task.importance}`;
    }
    return node.name;
  }, []);

  /**
   * Creates progress text for goal nodes
   */
  const createProgressText = useCallback((node: HierarchicalNode): string => {
    if (node.data) {
      const goal = node.data as Goal;
      return `${goal.completed_tasks}/${goal.total_tasks}`;
    }
    return '';
  }, []);

  /**
   * Memoized tree layout calculations
   */
  const treeLayout = useMemo(() => {
    if (dimensions.width === 0 || dimensions.height === 0) {
      return null;
    }

    const margin = { top: 20, right: 90, bottom: 30, left: 90 };
    const innerWidth = dimensions.width - margin.left - margin.right;
    const innerHeight = dimensions.height - margin.bottom - margin.top;

    return {
      layout: d3.tree<HierarchicalNode>().size([innerHeight, innerWidth]),
      margin,
      innerWidth,
      innerHeight,
    };
  }, [dimensions.width, dimensions.height]);

  /**
   * Memoized tree data structure
   */
  const treeData = useMemo(() => {
    if (!treeLayout || !hierarchicalData) {
      return null;
    }

    const root = d3.hierarchy(hierarchicalData);
    return treeLayout.layout(root);
  }, [treeLayout, hierarchicalData]);

  /**
   * Main D3 tree rendering function
   */
  const renderD3Tree = useCallback(
    (svgElement: SVGSVGElement) => {
      if (loading || !data.goals || !treeLayout || !treeData) {
        return;
      }

      const svg = d3.select(svgElement);
      svg.selectAll('*').remove();

      const { width, height } = dimensions;
      const { margin } = treeLayout;

      // Create root container
      const g = svg
        .attr('width', width)
        .attr('height', height)
        .append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);

      // Create links
      g.selectAll('.link')
        .data(treeData.links())
        .enter()
        .append('path')
        .attr('class', 'link')
        .attr(
          'd',
          d3
            .linkHorizontal<
              d3.HierarchyPointLink<HierarchicalNode>,
              d3.HierarchyPointNode<HierarchicalNode>
            >()
            .x((d) => d.y)
            .y((d) => d.x),
        )
        .style('fill', 'none')
        .style('stroke', '#ccc')
        .style('stroke-width', '2px');

      // Create nodes
      const node = g
        .selectAll('.node')
        .data(treeData.descendants())
        .enter()
        .append('g')
        .attr('class', 'node')
        .attr('transform', (d) => `translate(${d.y},${d.x})`)
        .style('cursor', (d) => (d.data.type ? 'pointer' : 'default'));

      // Add circles for nodes
      node
        .append('circle')
        .attr('r', (d) => getNodeRadius(d.data))
        .style('fill', (d) => getNodeColor(d.data))
        .style('stroke', (d) => getStrokeColor(d.data))
        .style('stroke-width', (d) => getStrokeWidth(d.data));

      // Add labels
      node
        .append('text')
        .attr('dy', '.35em')
        .attr('x', (d) => (d.children ? -13 : 13))
        .style('text-anchor', (d) => (d.children ? 'end' : 'start'))
        .style('font-size', (d) => getFontSize(d.data))
        .style('font-weight', (d) => getFontWeight(d.data))
        .text((d) => truncateText(d.data.name))
        .append('title')
        .text((d) => d.data.name);

      // Add progress indicators for goals
      node
        .filter((d) => d.data.type === 'goal')
        .append('text')
        .attr('dx', 15)
        .attr('dy', 15)
        .style('font-size', '10px')
        .style('fill', '#666')
        .text((d) => createProgressText(d.data));

      // Add click handlers
      node
        .filter((d) => d.data.type === 'goal')
        .on(
          'click',
          function (
            _event: MouseEvent,
            d: d3.HierarchyPointNode<HierarchicalNode>,
          ) {
            if (d.data.id) {
              onGoalSelect(d.data.id);
            }
          },
        );

      // Add tooltips
      node.append('title').text((d) => createTooltipText(d.data));
    },
    [
      loading,
      data.goals,
      treeLayout,
      treeData,
      dimensions,
      onGoalSelect,
      getNodeColor,
      getNodeRadius,
      getStrokeColor,
      getStrokeWidth,
      getFontSize,
      getFontWeight,
      truncateText,
      createTooltipText,
      createProgressText,
    ],
  );

  return {
    renderD3Tree,
    // Export utility functions for potential reuse
    hierarchicalData,
    treeLayout,
    treeData,
    getNodeColor,
    getNodeRadius,
    truncateText,
    createTooltipText,
  };
};

export default useD3Tree;
