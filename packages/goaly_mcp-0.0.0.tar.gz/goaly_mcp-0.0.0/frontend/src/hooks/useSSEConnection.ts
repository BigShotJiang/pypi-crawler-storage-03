import { useState, useEffect, useRef, useCallback } from 'react';
import { config, getFullUrl } from '../config';
import { useNotification } from '../contexts/NotificationContext';
import { useApiErrorHandler } from './useApiErrorHandler';

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected';

interface SSEEvent {
  event_type: string;
  data: any;
  goal_id?: number;
  timestamp: string;
  type?: string;
}

export const useSSEConnection = (endpoint: string = config.sseUrl) => {
  const [connectionStatus, setConnectionStatus] =
    useState<ConnectionStatus>('disconnected');
  const [lastEvent, setLastEvent] = useState<SSEEvent | null>(null);
  const [error, setError] = useState<string | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);
  const reconnectTimeoutRef = useRef<number | null>(null);
  const reconnectAttempts = useRef<number>(0);
  const { showNotification, announceToScreenReader } = useNotification();
  // API error handler available for future use
  const { handleApiError } = useApiErrorHandler();
  void handleApiError; // Mark as intentionally used for future implementation

  const MAX_RECONNECT_ATTEMPTS = config.sseMaxReconnectAttempts;
  const RECONNECT_DELAY = config.sseReconnectDelay;

  // Helper function to handle SSE events with logging and notifications
  const handleSSEEvent = useCallback(
    (eventType: string, data: any, showToast: boolean = true) => {
      console.warn(`🔔 SSE Event Received:`, {
        type: eventType,
        data: data,
        timestamp: new Date().toISOString(),
      });

      const eventData = {
        type: eventType,
        ...data,
        timestamp: new Date().toISOString(),
      };

      setLastEvent(eventData);

      if (showToast) {
        let message = '';
        let screenReaderMessage = '';
        let severity: 'success' | 'info' | 'warning' | 'error' = 'info';

        switch (eventType) {
          case 'connected':
            message = '🔗 Connected to real-time updates';
            screenReaderMessage =
              'Connected to real-time updates. You will now receive live notifications about changes to goals and tasks.';
            severity = 'success';
            break;
          case 'goal_created':
            message = `🎯 New goal created: ${
              data.goal?.description || 'Unknown goal'
            }`;
            screenReaderMessage = `New goal created: ${
              data.goal?.description || 'Unknown goal'
            }. The dashboard has been updated to reflect this change.`;
            severity = 'info';
            break;
          case 'goal_updated':
            message = `📝 Goal updated: ${
              data.goal?.description || 'Unknown goal'
            }`;
            screenReaderMessage = `Goal updated: ${
              data.goal?.description || 'Unknown goal'
            }. The changes are now visible in the hierarchy view.`;
            severity = 'info';
            break;
          case 'task_created':
            message = `✅ New task created: ${
              data.task?.name || 'Unknown task'
            }`;
            screenReaderMessage = `New task created: ${
              data.task?.name || 'Unknown task'
            }. You may need to refresh the dependency graph to see the new task.`;
            severity = 'info';
            break;
          case 'task_updated':
            message = `🔄 Task updated: ${data.task?.name || 'Unknown task'}`;
            screenReaderMessage = `Task updated: ${
              data.task?.name || 'Unknown task'
            }. Status changed to ${
              data.task?.status || 'unknown status'
            }. Dependencies may have been affected.`;
            severity = 'success';
            break;
          default:
            message = `📡 ${eventType} event received`;
            screenReaderMessage = `System update: ${eventType} event received. The dashboard may have been updated.`;
            severity = 'info';
        }

        showNotification(message, severity, 5000);

        // Provide more detailed announcements for screen readers
        if (eventType !== 'heartbeat') {
          // For SSE events, most are informational, so use polite by default
          announceToScreenReader(screenReaderMessage, 'polite');
        }
      }
    },
    [showNotification, announceToScreenReader],
  );

  const connect = useCallback(() => {
    if (eventSourceRef.current?.readyState === EventSource.OPEN) {
      return;
    }

    setConnectionStatus('connecting');
    setError(null);

    try {
      // Ensure we use the full URL if needed
      const fullEndpoint = endpoint.startsWith('http')
        ? endpoint
        : getFullUrl(endpoint);
      const eventSource = new EventSource(fullEndpoint);
      eventSourceRef.current = eventSource;

      if (config.features.debugMode) {
        console.warn('Connecting to SSE endpoint:', fullEndpoint);
      }

      eventSource.onopen = () => {
        console.warn('SSE connection opened');
        setConnectionStatus('connected');
        setError(null);
        reconnectAttempts.current = 0;

        // Announce connection status to screen readers
        announceToScreenReader(
          'Successfully connected to real-time updates. You will now receive live notifications about changes.',
          'polite',
        );
      };

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.warn('🔔 SSE onmessage event:', data);
          handleSSEEvent('message', data);
        } catch (err) {
          console.error('Error parsing SSE message:', err);
        }
      };

      eventSource.addEventListener('connected', (event) => {
        const data = JSON.parse(event.data);
        handleSSEEvent('connected', data);
      });

      eventSource.addEventListener('goal_created', (event) => {
        const data = JSON.parse(event.data);
        handleSSEEvent('goal_created', data);
      });

      eventSource.addEventListener('goal_updated', (event) => {
        const data = JSON.parse(event.data);
        handleSSEEvent('goal_updated', data);
      });

      eventSource.addEventListener('task_created', (event) => {
        const data = JSON.parse(event.data);
        handleSSEEvent('task_created', data);
      });

      eventSource.addEventListener('task_updated', (event) => {
        const data = JSON.parse(event.data);
        handleSSEEvent('task_updated', data);
      });

      eventSource.addEventListener('heartbeat', (event) => {
        // Handle heartbeat silently - no toast notification
        console.warn('🔔 SSE heartbeat received');
        const data = JSON.parse(event.data);
        handleSSEEvent('heartbeat', data, false); // No toast for heartbeat
      });

      eventSource.onerror = (event) => {
        console.error('SSE connection error:', event);
        setConnectionStatus('disconnected');

        // Announce disconnection to screen readers
        announceToScreenReader(
          'Connection to real-time updates lost. Attempting to reconnect.',
          'assertive',
        );

        if (eventSource.readyState === EventSource.CLOSED) {
          setError('Connection closed by server');

          // Attempt to reconnect with exponential backoff
          if (reconnectAttempts.current < MAX_RECONNECT_ATTEMPTS) {
            const delay =
              RECONNECT_DELAY * Math.pow(2, reconnectAttempts.current);
            reconnectAttempts.current++;

            console.warn(
              `Attempting to reconnect in ${delay}ms (attempt ${reconnectAttempts.current})`,
            );

            reconnectTimeoutRef.current = window.setTimeout(() => {
              connect();
            }, delay);
          } else {
            setError('Max reconnection attempts reached');
            announceToScreenReader(
              'Failed to reconnect to real-time updates. Please refresh the page to restore connection.',
              'assertive',
            );
          }
        }
      };
    } catch (err) {
      console.error('Error creating SSE connection:', err);
      setConnectionStatus('disconnected');
      setError(err instanceof Error ? err.message : 'Unknown error');
    }
  }, [
    endpoint,
    handleSSEEvent,
    MAX_RECONNECT_ATTEMPTS,
    RECONNECT_DELAY,
    announceToScreenReader,
  ]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      window.clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }

    setConnectionStatus('disconnected');
    reconnectAttempts.current = 0;
  }, []);

  const reconnect = useCallback(() => {
    disconnect();
    window.setTimeout(connect, 1000);
  }, [connect, disconnect]);

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  // Handle page visibility change to reconnect when page becomes visible
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (
        document.visibilityState === 'visible' &&
        connectionStatus === 'disconnected'
      ) {
        reconnect();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () =>
      document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [connectionStatus, reconnect]);

  return {
    connectionStatus,
    lastEvent,
    error,
    reconnect,
    disconnect,
  };
};
