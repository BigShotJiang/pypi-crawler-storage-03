import { useCallback, useEffect, useRef } from 'react';
import { getCLS, getFID, getFCP, getLCP, getTTFB, Metric } from 'web-vitals';

// Extended metric interface with rating
interface MetricWithRating extends Metric {
  rating: 'good' | 'needs-improvement' | 'poor';
}

interface WebVitalsData {
  CLS?: number;
  FID?: number;
  FCP?: number;
  LCP?: number;
  TTFB?: number;
  timestamp: number;
}

interface WebVitalsOptions {
  onMetric?: (metric: MetricWithRating) => void;
  onReport?: (vitals: WebVitalsData) => void;
  reportToAnalytics?: boolean;
  threshold?: {
    LCP?: number; // Good: < 2.5s
    FID?: number; // Good: < 100ms
    CLS?: number; // Good: < 0.1
    FCP?: number; // Good: < 1.8s
    TTFB?: number; // Good: < 600ms
  };
}

/**
 * Calculate rating for a web vital metric based on standard thresholds
 */
const getMetricRating = (
  metric: Metric,
): 'good' | 'needs-improvement' | 'poor' => {
  const { name, value } = metric;

  // Standard Web Vitals thresholds (in milliseconds, except CLS)
  const thresholds: Record<string, { good: number; poor: number }> = {
    LCP: { good: 2500, poor: 4000 },
    FID: { good: 100, poor: 300 },
    CLS: { good: 0.1, poor: 0.25 },
    FCP: { good: 1800, poor: 3000 },
    TTFB: { good: 600, poor: 1500 },
  };

  const threshold = thresholds[name];
  if (!threshold) {
    return 'good'; // Default for unknown metrics
  }

  if (value <= threshold.good) {
    return 'good';
  } else if (value <= threshold.poor) {
    return 'needs-improvement';
  } else {
    return 'poor';
  }
};

/**
 * Hook for monitoring Core Web Vitals and performance metrics
 * Automatically collects and reports LCP, FID, CLS, FCP, and TTFB metrics
 */
export const useWebVitals = ({
  onMetric,
  onReport,
  reportToAnalytics = false,
  threshold = {
    LCP: 2500,
    FID: 100,
    CLS: 0.1,
    FCP: 1800,
    TTFB: 600,
  },
}: WebVitalsOptions = {}) => {
  const vitalsData = useRef<Partial<WebVitalsData>>({});
  const reportTimeout = useRef<number | null>(null);

  // Default thresholds for "Good" ratings
  const defaultThresholds = {
    LCP: 2500, // ms
    FID: 100, // ms
    CLS: 0.1, // ratio
    FCP: 1800, // ms
    TTFB: 600, // ms
  };

  const finalThresholds = { ...defaultThresholds, ...threshold };

  const getPerformanceRating = useCallback(
    (name: string, value: number): 'good' | 'needs-improvement' | 'poor' => {
      const thresholds = finalThresholds as any;
      const thresh = thresholds[name.toUpperCase()];

      if (!thresh) {
        return 'good';
      }

      // Different logic for different metrics
      switch (name.toUpperCase()) {
        case 'LCP':
          return value <= thresh
            ? 'good'
            : value <= thresh * 1.6
              ? 'needs-improvement'
              : 'poor';
        case 'FID':
          return value <= thresh
            ? 'good'
            : value <= 300
              ? 'needs-improvement'
              : 'poor';
        case 'CLS':
          return value <= thresh
            ? 'good'
            : value <= 0.25
              ? 'needs-improvement'
              : 'poor';
        case 'FCP':
          return value <= thresh
            ? 'good'
            : value <= 3000
              ? 'needs-improvement'
              : 'poor';
        case 'TTFB':
          return value <= thresh
            ? 'good'
            : value <= 1500
              ? 'needs-improvement'
              : 'poor';
        default:
          return 'good';
      }
    },
    [finalThresholds],
  );

  const handleMetric = useCallback(
    (metric: Metric) => {
      const rating = getMetricRating(metric);
      const metricWithRating: MetricWithRating = { ...metric, rating };
      const { name, value } = metricWithRating;

      // Store the metric
      vitalsData.current = {
        ...vitalsData.current,
        [name]: value,
        timestamp: Date.now(),
      };

      // Call custom handler
      if (onMetric) {
        onMetric(metricWithRating);
      }

      // Get our own rating
      const customRating = getPerformanceRating(name, value);

      // Log performance metrics in development
      if (process.env.NODE_ENV === 'development') {
        console.warn(`📊 Web Vital: ${name}`, {
          value: `${value}${name === 'CLS' ? '' : 'ms'}`,
          rating: customRating,
          threshold: (finalThresholds as any)[name.toUpperCase()],
        });
      }

      // Report to analytics if enabled
      if (reportToAnalytics) {
        // You can integrate with your analytics service here
        // Example: gtag('event', 'web-vitals', { name, value, rating });
      }

      // Batch report after a delay
      if (reportTimeout.current) {
        clearTimeout(reportTimeout.current);
      }

      reportTimeout.current = window.setTimeout(() => {
        if (onReport && vitalsData.current.timestamp) {
          onReport(vitalsData.current as WebVitalsData);
        }
      }, 1000);
    },
    [
      onMetric,
      onReport,
      reportToAnalytics,
      getPerformanceRating,
      finalThresholds,
    ],
  );

  useEffect(() => {
    // Collect all Core Web Vitals
    getCLS(handleMetric);
    getFID(handleMetric);
    getFCP(handleMetric);
    getLCP(handleMetric);
    getTTFB(handleMetric);

    return () => {
      if (reportTimeout.current) {
        clearTimeout(reportTimeout.current);
      }
    };
  }, [handleMetric]);

  const getCurrentVitals = useCallback((): Partial<WebVitalsData> => {
    return { ...vitalsData.current };
  }, []);

  const getVitalsSummary = useCallback(() => {
    const vitals = vitalsData.current;
    const summary = {
      overallRating: 'good' as 'good' | 'needs-improvement' | 'poor',
      metrics: {} as Record<
        string,
        {
          value: number;
          rating: 'good' | 'needs-improvement' | 'poor';
          threshold: number;
        }
      >,
    };

    let needsImprovementCount = 0;
    let poorCount = 0;

    Object.entries(vitals).forEach(([key, value]) => {
      if (key === 'timestamp' || typeof value !== 'number') {
        return;
      }

      const rating = getPerformanceRating(key, value);
      const threshold = (finalThresholds as any)[key.toUpperCase()] || 0;

      summary.metrics[key] = { value, rating, threshold };

      if (rating === 'needs-improvement') {
        needsImprovementCount++;
      }
      if (rating === 'poor') {
        poorCount++;
      }
    });

    // Determine overall rating
    if (poorCount > 0) {
      summary.overallRating = 'poor';
    } else if (needsImprovementCount > 0) {
      summary.overallRating = 'needs-improvement';
    }

    return summary;
  }, [getPerformanceRating, finalThresholds]);

  return {
    getCurrentVitals,
    getVitalsSummary,
    handleMetric,
    thresholds: finalThresholds,
  };
};

/**
 * Utility function to send vitals to an analytics endpoint
 */
export const sendToAnalytics = (
  metric: MetricWithRating,
  endpoint?: string,
) => {
  const body = JSON.stringify({
    name: metric.name,
    value: metric.value,
    rating: metric.rating,
    delta: metric.delta,
    id: metric.id,
    timestamp: Date.now(),
    url: window.location.href,
    userAgent: navigator.userAgent,
  });

  if (endpoint) {
    // Send to custom endpoint
    if (navigator.sendBeacon) {
      navigator.sendBeacon(endpoint, body);
    } else {
      fetch(endpoint, {
        body,
        method: 'POST',
        credentials: 'omit',
        headers: { 'Content-Type': 'application/json' },
      }).catch(console.error);
    }
  }

  // Send to Google Analytics 4 if gtag is available
  if (typeof window !== 'undefined' && (window as any).gtag) {
    (window as any).gtag('event', 'web_vitals', {
      event_category: 'performance',
      event_label: metric.id,
      value: Math.round(
        metric.name === 'CLS' ? metric.value * 1000 : metric.value,
      ),
      custom_map: {
        metric_id: 'dimension1',
        metric_value: 'metric1',
        metric_delta: 'metric2',
      },
    });
  }
};

/**
 * Default Web Vitals configuration with automatic reporting
 */
export const useWebVitalsWithReporting = (analyticsEndpoint?: string) => {
  return useWebVitals({
    onMetric: (metric) => {
      // Log in development
      if (process.env.NODE_ENV === 'development') {
        console.warn(
          `🚀 Web Vital: ${metric.name} = ${metric.value}${
            metric.name === 'CLS' ? '' : 'ms'
          } (${metric.rating})`,
        );
      }

      // Send to analytics
      if (analyticsEndpoint) {
        sendToAnalytics(metric, analyticsEndpoint);
      }
    },
    reportToAnalytics: true,
  });
};

export default useWebVitals;
