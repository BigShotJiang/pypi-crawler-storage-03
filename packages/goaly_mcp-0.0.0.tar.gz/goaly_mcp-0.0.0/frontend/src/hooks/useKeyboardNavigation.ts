import { useCallback, useEffect } from 'react';

export interface KeyboardNavigationOptions {
  onFocusFirst?: () => void;
  onFocusLast?: () => void;
  onNavigateNext?: () => void;
  onNavigatePrevious?: () => void;
  onActivate?: () => void;
  onEscape?: () => void;
  container?: HTMLElement | null;
}

/**
 * Hook for managing keyboard navigation within a component
 * Provides standardized keyboard shortcuts and focus management
 */
export const useKeyboardNavigation = ({
  onFocusFirst,
  onFocusLast,
  onNavigateNext,
  onNavigatePrevious,
  onActivate,
  onEscape,
  container,
}: KeyboardNavigationOptions) => {
  const handleKeyDown = useCallback(
    (event: Event) => {
      if (!(event instanceof KeyboardEvent)) {
        return;
      }
      const { key, ctrlKey, shiftKey, altKey } = event;

      // Skip if modifiers are pressed (except for specific combinations)
      if (altKey) {
        return;
      }

      switch (key) {
        case 'ArrowDown':
        case 'j': // Vim-like navigation
          if (!ctrlKey && !shiftKey) {
            event.preventDefault();
            onNavigateNext?.();
          }
          break;

        case 'ArrowUp':
        case 'k': // Vim-like navigation
          if (!ctrlKey && !shiftKey) {
            event.preventDefault();
            onNavigatePrevious?.();
          }
          break;

        case 'Home':
        case 'g':
          if (key === 'Home' || (key === 'g' && !ctrlKey)) {
            event.preventDefault();
            onFocusFirst?.();
          }
          break;

        case 'End':
        case 'G':
          if (key === 'End' || (key === 'G' && shiftKey)) {
            event.preventDefault();
            onFocusLast?.();
          }
          break;

        case 'Enter':
        case ' ':
          if (
            event.target instanceof HTMLElement &&
            (event.target.role === 'button' ||
              event.target.tagName === 'BUTTON')
          ) {
            event.preventDefault();
            onActivate?.();
          }
          break;

        case 'Escape':
          event.preventDefault();
          onEscape?.();
          break;

        case 'Tab':
          // Let natural tab behavior work, but can be customized
          break;

        default:
          break;
      }
    },
    [
      onFocusFirst,
      onFocusLast,
      onNavigateNext,
      onNavigatePrevious,
      onActivate,
      onEscape,
    ],
  );

  useEffect(() => {
    const element = container || document;
    element.addEventListener('keydown', handleKeyDown);

    return () => {
      element.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown, container]);

  // Utility functions for focus management
  const focusFirstFocusableElement = useCallback((root?: HTMLElement) => {
    const container = root || document;
    const focusable = container.querySelector(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"]), [role="button"]',
    ) as HTMLElement;

    if (focusable) {
      focusable.focus();
      return true;
    }
    return false;
  }, []);

  const focusLastFocusableElement = useCallback((root?: HTMLElement) => {
    const container = root || document;
    const focusable = Array.from(
      container.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"]), [role="button"]',
      ),
    ) as HTMLElement[];

    const last = focusable[focusable.length - 1];
    if (last) {
      last.focus();
      return true;
    }
    return false;
  }, []);

  const getFocusableElements = useCallback((root?: HTMLElement) => {
    const container = root || document;
    return Array.from(
      container.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"]), [role="button"]',
      ),
    ) as HTMLElement[];
  }, []);

  return {
    handleKeyDown,
    focusFirstFocusableElement,
    focusLastFocusableElement,
    getFocusableElements,
  };
};

/**
 * Hook for managing ARIA announcements for screen readers
 */
export const useAriaAnnouncement = () => {
  const announce = useCallback(
    (message: string, priority: 'polite' | 'assertive' = 'polite') => {
      // Create a live region for announcements
      let liveRegion = document.getElementById('aria-live-region');

      if (!liveRegion) {
        liveRegion = document.createElement('div');
        liveRegion.id = 'aria-live-region';
        liveRegion.setAttribute('aria-live', priority);
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.className = 'visuallyHidden';
        document.body.appendChild(liveRegion);
      }

      // Update the live region with the message
      liveRegion.textContent = message;

      // Clear the message after a short delay to allow for re-announcements
      setTimeout(() => {
        if (liveRegion) {
          liveRegion.textContent = '';
        }
      }, 1000);
    },
    [],
  );

  return { announce };
};

export default useKeyboardNavigation;
