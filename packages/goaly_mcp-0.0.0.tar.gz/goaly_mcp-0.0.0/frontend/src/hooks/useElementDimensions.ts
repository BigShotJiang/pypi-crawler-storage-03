import { useEffect, useState, useCallback, RefObject } from 'react';

export interface Dimensions {
  width: number;
  height: number;
}

export interface UseElementDimensionsOptions {
  /**
   * Debounce delay for resize events in milliseconds
   * @default 100
   */
  debounceDelay?: number;

  /**
   * Whether to observe resize changes
   * @default true
   */
  observeResize?: boolean;

  /**
   * Initial dimensions to use before measurement
   * @default { width: 0, height: 0 }
   */
  initialDimensions?: Dimensions;
}

/**
 * Custom hook for tracking element dimensions with ResizeObserver
 * Provides efficient resize tracking with debouncing and cleanup
 */
export const useElementDimensions = <T extends Element>(
  elementRef: RefObject<T>,
  options: UseElementDimensionsOptions = {},
): Dimensions => {
  const {
    debounceDelay = 100,
    observeResize = true,
    initialDimensions = { width: 0, height: 0 },
  } = options;

  const [dimensions, setDimensions] = useState<Dimensions>(initialDimensions);

  /**
   * Measures the current dimensions of the element
   */
  const measureDimensions = useCallback((): Dimensions => {
    const element = elementRef.current;
    if (!element) {
      return initialDimensions;
    }

    // Get element dimensions - works for both HTML and SVG elements
    const rect = element.getBoundingClientRect();
    const clientWidth = rect.width;
    const clientHeight = rect.height;

    return { width: clientWidth, height: clientHeight };
  }, [elementRef, initialDimensions]);

  /**
   * Updates dimensions state with current measurements
   */
  const updateDimensions = useCallback(() => {
    const newDimensions = measureDimensions();
    setDimensions((prevDimensions) => {
      // Only update if dimensions have actually changed
      if (
        prevDimensions.width !== newDimensions.width ||
        prevDimensions.height !== newDimensions.height
      ) {
        return newDimensions;
      }
      return prevDimensions;
    });
  }, [measureDimensions]);

  /**
   * Debounced update function to avoid excessive re-renders
   */
  const debouncedUpdate = useCallback(() => {
    let timeoutId: NodeJS.Timeout;

    const debounced = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(updateDimensions, debounceDelay);
    };

    return debounced();
  }, [updateDimensions, debounceDelay]);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) {
      return;
    }

    // Initial measurement
    updateDimensions();

    if (!observeResize) {
      return;
    }

    // Use ResizeObserver if available, fallback to window resize
    if (typeof ResizeObserver !== 'undefined') {
      const resizeObserver = new ResizeObserver(() => {
        debouncedUpdate();
      });

      resizeObserver.observe(element);

      return () => {
        resizeObserver.disconnect();
      };
    } else {
      // Fallback for older browsers
      const handleWindowResize = () => {
        debouncedUpdate();
      };

      window.addEventListener('resize', handleWindowResize);

      return () => {
        window.removeEventListener('resize', handleWindowResize);
      };
    }
  }, [elementRef, updateDimensions, debouncedUpdate, observeResize]);

  return dimensions;
};

/**
 * Alternative hook that uses a parent container as reference
 * Useful when you need dimensions relative to a specific container
 */
export const useParentElementDimensions = <T extends Element>(
  elementRef: RefObject<T>,
  options: UseElementDimensionsOptions = {},
): Dimensions => {
  const [parentRef, setParentRef] = useState<RefObject<Element>>({
    current: null,
  });

  useEffect(() => {
    const element = elementRef.current;
    if (element?.parentElement) {
      setParentRef({ current: element.parentElement });
    }
  }, [elementRef]);

  return useElementDimensions(parentRef, options);
};

export default useElementDimensions;
