import { useCallback, useState, useEffect, useRef } from 'react';

interface TouchPoint {
  id: number;
  x: number;
  y: number;
  timestamp: number;
}

interface SwipeGesture {
  direction: 'left' | 'right' | 'up' | 'down';
  distance: number;
  velocity: number;
  duration: number;
}

interface TouchInteractionOptions {
  onTap?: (event: TouchEvent | MouseEvent) => void;
  onDoubleTap?: (event: TouchEvent | MouseEvent) => void;
  onLongPress?: (event: TouchEvent | MouseEvent) => void;
  onSwipe?: (gesture: SwipeGesture, event: TouchEvent) => void;
  onPinch?: (scale: number, event: TouchEvent) => void;
  longPressDelay?: number;
  swipeThreshold?: number;
  doubleTapDelay?: number;
  pinchThreshold?: number;
}

/**
 * Hook for handling touch interactions on mobile devices
 * Provides tap, double-tap, long press, swipe, and pinch gestures
 */
export const useTouchInteractions = ({
  onTap,
  onDoubleTap,
  onLongPress,
  onSwipe,
  onPinch,
  longPressDelay = 500,
  swipeThreshold = 50,
  doubleTapDelay = 300,
  pinchThreshold = 0.1,
}: TouchInteractionOptions) => {
  const [touchStart, setTouchStart] = useState<TouchPoint | null>(null);
  const [lastTap, setLastTap] = useState<TouchPoint | null>(null);
  const longPressTimer = useRef<number | null>(null);
  const doubleTapTimer = useRef<number | null>(null);
  const [initialDistance, setInitialDistance] = useState<number>(0);
  const [isLongPressing, setIsLongPressing] = useState(false);

  const clearTimers = useCallback(() => {
    if (longPressTimer.current) {
      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
    if (doubleTapTimer.current) {
      window.clearTimeout(doubleTapTimer.current);
      doubleTapTimer.current = null;
    }
  }, []);

  const getDistance = useCallback(
    (touch1: TouchPoint, touch2: TouchPoint): number => {
      const dx = touch1.x - touch2.x;
      const dy = touch1.y - touch2.y;
      return Math.sqrt(dx * dx + dy * dy);
    },
    [],
  );

  const getTouchPoint = useCallback(
    (touch: Touch): TouchPoint => ({
      id: touch.identifier,
      x: touch.clientX,
      y: touch.clientY,
      timestamp: Date.now(),
    }),
    [],
  );

  const handleTouchStart = useCallback(
    (event: TouchEvent) => {
      const touch = event.touches[0];
      if (!touch) {
        return;
      }

      const touchPoint = getTouchPoint(touch);
      setTouchStart(touchPoint);
      setIsLongPressing(false);

      // Handle pinch gesture
      if (event.touches.length === 2 && onPinch) {
        const touch1 = getTouchPoint(event.touches[0]);
        const touch2 = getTouchPoint(event.touches[1]);
        setInitialDistance(getDistance(touch1, touch2));
      }

      // Start long press timer
      if (onLongPress) {
        longPressTimer.current = window.setTimeout(() => {
          setIsLongPressing(true);
          onLongPress(event);
        }, longPressDelay);
      }
    },
    [getTouchPoint, getDistance, onLongPress, onPinch, longPressDelay],
  );

  const handleTouchMove = useCallback(
    (event: TouchEvent) => {
      // Cancel long press on move
      if (longPressTimer.current) {
        window.clearTimeout(longPressTimer.current);
        longPressTimer.current = null;
      }

      // Handle pinch gesture
      if (event.touches.length === 2 && onPinch && initialDistance > 0) {
        const touch1 = getTouchPoint(event.touches[0]);
        const touch2 = getTouchPoint(event.touches[1]);
        const currentDistance = getDistance(touch1, touch2);
        const scale = currentDistance / initialDistance;

        if (Math.abs(scale - 1) > pinchThreshold) {
          onPinch(scale, event);
        }
      }
    },
    [getTouchPoint, getDistance, onPinch, initialDistance, pinchThreshold],
  );

  const handleTouchEnd = useCallback(
    (event: TouchEvent) => {
      clearTimers();

      if (isLongPressing) {
        setIsLongPressing(false);
        return;
      }

      const touch = event.changedTouches[0];
      if (!touch || !touchStart) {
        return;
      }

      const touchEnd = getTouchPoint(touch);
      const deltaX = touchEnd.x - touchStart.x;
      const deltaY = touchEnd.y - touchStart.y;
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      const duration = touchEnd.timestamp - touchStart.timestamp;

      // Handle swipe gesture
      if (distance > swipeThreshold && onSwipe && duration < 1000) {
        const absX = Math.abs(deltaX);
        const absY = Math.abs(deltaY);
        let direction: SwipeGesture['direction'];

        if (absX > absY) {
          direction = deltaX > 0 ? 'right' : 'left';
        } else {
          direction = deltaY > 0 ? 'down' : 'up';
        }

        const velocity = distance / duration;
        onSwipe({ direction, distance, velocity, duration }, event);
        return;
      }

      // Handle tap and double tap
      if (distance < 10) {
        // Small movement threshold for tap
        if (lastTap && onDoubleTap) {
          const timeSinceLastTap = touchEnd.timestamp - lastTap.timestamp;
          const tapDistance = getDistance(touchEnd, lastTap);

          if (timeSinceLastTap < doubleTapDelay && tapDistance < 50) {
            // Double tap detected
            if (doubleTapTimer.current) {
              window.clearTimeout(doubleTapTimer.current);
              doubleTapTimer.current = null;
            }
            onDoubleTap(event);
            setLastTap(null);
            return;
          }
        }

        // Single tap - delay to check for double tap
        if (onDoubleTap) {
          setLastTap(touchEnd);
          doubleTapTimer.current = window.setTimeout(() => {
            if (onTap) {
              onTap(event);
            }
            setLastTap(null);
          }, doubleTapDelay);
        } else if (onTap) {
          onTap(event);
        }
      }

      setTouchStart(null);
      setInitialDistance(0);
    },
    [
      clearTimers,
      isLongPressing,
      touchStart,
      getTouchPoint,
      swipeThreshold,
      onSwipe,
      lastTap,
      onDoubleTap,
      getDistance,
      doubleTapDelay,
      onTap,
    ],
  );

  // Mouse events for desktop compatibility
  const handleMouseDown = useCallback(
    (event: MouseEvent) => {
      const touchPoint: TouchPoint = {
        id: 0,
        x: event.clientX,
        y: event.clientY,
        timestamp: Date.now(),
      };
      setTouchStart(touchPoint);
      setIsLongPressing(false);

      if (onLongPress) {
        longPressTimer.current = window.setTimeout(() => {
          setIsLongPressing(true);
          onLongPress(event);
        }, longPressDelay);
      }
    },
    [onLongPress, longPressDelay],
  );

  const handleMouseUp = useCallback(
    (event: MouseEvent) => {
      clearTimers();

      if (isLongPressing) {
        setIsLongPressing(false);
        return;
      }

      if (touchStart) {
        const deltaX = event.clientX - touchStart.x;
        const deltaY = event.clientY - touchStart.y;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);

        if (distance < 10) {
          // Click threshold
          if (onTap) {
            onTap(event);
          }
        }
      }

      setTouchStart(null);
    },
    [clearTimers, isLongPressing, touchStart, onTap],
  );

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearTimers();
    };
  }, [clearTimers]);

  return {
    touchHandlers: {
      onTouchStart: handleTouchStart,
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
      onMouseDown: handleMouseDown,
      onMouseUp: handleMouseUp,
    },
    isLongPressing,
  };
};

/**
 * Hook for detecting touch device capabilities
 */
export const useTouchDevice = () => {
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [pointerType, setPointerType] = useState<'mouse' | 'touch' | 'pen'>(
    'mouse',
  );

  useEffect(() => {
    // Check for touch support
    const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    setIsTouchDevice(hasTouch);

    // Check pointer type
    const checkPointerType = () => {
      if (window.matchMedia('(pointer: coarse)').matches) {
        setPointerType('touch');
      } else if (window.matchMedia('(pointer: fine)').matches) {
        setPointerType('mouse');
      }
    };

    checkPointerType();

    // Listen for pointer changes
    const mediaQuery = window.matchMedia('(pointer: coarse)');
    mediaQuery.addListener(checkPointerType);

    return () => {
      mediaQuery.removeListener(checkPointerType);
    };
  }, []);

  return {
    isTouchDevice,
    pointerType,
    isCoarsePointer: pointerType === 'touch',
    isFinePointer: pointerType === 'mouse',
  };
};

export default useTouchInteractions;
