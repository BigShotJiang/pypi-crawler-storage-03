import { useState, useEffect, useCallback } from 'react';
import {
  GoalsService,
  TasksService,
  type Goal,
  type GoalHierarchy,
} from '../services/api';
import type { SSEEvent } from '../types';
import { config } from '../config';
import { useApiErrorHandler } from './useApiErrorHandler';

interface ReactFlowGraphNode {
  id: string;
  type: string;
  data: {
    label: string;
    status: string;
    owner?: string;
    goal_id: number;
    goal_description: string;
    importance: number;
  };
  position: { x: number; y: number };
}

interface ReactFlowGraphEdge {
  id: string;
  source: string;
  target: string;
  data: {
    is_blocked: boolean;
    required_data?: string;
  };
}

interface ReactFlowDependencyGraph {
  nodes: ReactFlowGraphNode[];
  edges: ReactFlowGraphEdge[];
  summary?: {
    total_tasks?: number;
    total_dependencies?: number;
    blocked_dependencies?: number;
  };
  stats?: {
    total_tasks?: number;
    total_dependencies?: number;
    blocked_dependencies?: number;
  };
}

interface Stats {
  total_goals?: number;
  completed_goals?: number;
  total_tasks?: number;
  completed_tasks?: number;
  totalDependencies?: number;
  blockedDependencies?: number;
}

export const useGoalData = (lastEvent: SSEEvent | null) => {
  const [goalHierarchy, setGoalHierarchy] = useState<GoalHierarchy>({
    goals: [],
    summary: {},
  });
  const [dependencyGraph, setDependencyGraph] =
    useState<ReactFlowDependencyGraph>({
      nodes: [],
      edges: [],
      stats: {},
    });
  const [stats, setStats] = useState<Stats>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { withRetry, handleApiError } = useApiErrorHandler();

  const fetchGoalHierarchy = useCallback(async () => {
    try {
      const response = await withRetry(
        () => GoalsService.listGoals({}),
        'fetchGoalHierarchy',
        2, // Maximum 2 retries for goal hierarchy
      );

      if (response.success) {
        const hierarchyData = response.data;
        const goals = hierarchyData.goals || [];
        setGoalHierarchy(hierarchyData);
        setStats((prevStats) => ({
          ...prevStats,
          total_goals: goals.length,
          completed_goals: goals.filter((g: Goal) => g.is_complete).length,
        }));
      }
    } catch (err) {
      const apiError = handleApiError(err, 'fetchGoalHierarchy', {
        showNotification: true,
      });
      setError(apiError.message);
    }
  }, [withRetry, handleApiError]);

  const fetchDependencyGraph = useCallback(
    async (goalHierarchyData: GoalHierarchy | null = null) => {
      try {
        const response = await withRetry(
          () => TasksService.getDependencyGraph({}),
          'fetchDependencyGraph',
          3, // Maximum 3 retries for dependency graph (it's more complex)
        );

        if (response.success) {
          const graphData = response.data;

          // Create goal lookup for better descriptions
          const goalLookup: Record<number, string> = {};
          if (goalHierarchyData?.goals) {
            goalHierarchyData.goals.forEach((goal: Goal) => {
              goalLookup[goal.id] = goal.description;
            });
          }

          // Transform nodes to match ReactFlow expectations
          const transformedNodes: ReactFlowGraphNode[] = (
            graphData?.nodes || []
          ).map((node) => ({
            id: node.id.toString(),
            type: 'custom',
            data: {
              label: node.name || 'Unnamed Task',
              status: node.status || 'unknown',
              owner: node.owner || undefined,
              goal_id: node.goal_id,
              goal_description:
                goalLookup[node.goal_id] || `Goal ${node.goal_id}`,
              importance: node.importance || 0,
            },
            position: { x: 0, y: 0 }, // Will be set by layout algorithm
          }));

          // Debug: Uncomment to see raw edge data
          // console.log("🔍 Raw graphData edges:", graphData?.edges);

          // Transform edges to match ReactFlow expectations
          const transformedEdges: ReactFlowGraphEdge[] = (
            graphData?.edges || []
          )
            .filter((edge) => {
              // Filter out edges with invalid source/target
              if (!edge.source || !edge.target) {
                console.warn('⚠️ Skipping invalid edge:', edge);
                return false;
              }
              return true;
            })
            .map((edge) => ({
              id: edge.id.toString(),
              source: edge.source.toString(),
              target: edge.target.toString(),
              data: {
                is_blocked: edge.is_blocked || false,
                required_data: edge.required_data || undefined,
              },
            }));

          const transformedGraphData = {
            nodes: transformedNodes,
            edges: transformedEdges,
            summary: graphData.summary,
            stats: graphData.summary,
          };

          // Debug: Uncomment for detailed data analysis
          // console.log("✅ Transformed graph data:", {
          //   nodes: transformedNodes.length,
          //   edges: transformedEdges.length
          // });

          setDependencyGraph(transformedGraphData);

          // Calculate completed tasks from nodes
          const completedTasks = transformedNodes.filter(
            (node: ReactFlowGraphNode) => node.data.status === 'completed',
          ).length;

          setStats((prevStats) => ({
            ...prevStats,
            total_tasks: graphData?.summary?.total_tasks || 0,
            completed_tasks: completedTasks,
            totalDependencies: graphData?.summary?.total_dependencies || 0,
            blockedDependencies: graphData?.summary?.blocked_dependencies || 0,
          }));
        }
      } catch (err) {
        const apiError = handleApiError(err, 'fetchDependencyGraph', {
          showNotification: true,
          notificationType: 'warning', // Less critical than goal hierarchy
        });
        setError(apiError.message);
      }
    },
    [withRetry, handleApiError],
  );

  const refreshData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch goals first, then use that data for dependency graph
      await fetchGoalHierarchy();

      // Get current goal hierarchy state to pass to dependency graph
      const goalsResponse = await GoalsService.listGoals({});
      if (goalsResponse.success) {
        const goalsData = goalsResponse.data;
        await fetchDependencyGraph(goalsData);
      } else {
        await fetchDependencyGraph(null);
      }
    } catch (err) {
      const apiError = handleApiError(err, 'refreshData', {
        showNotification: false, // Don't show notification here as individual calls handle it
      });
      setError(apiError.message);
    } finally {
      setLoading(false);
    }
  }, [fetchGoalHierarchy, fetchDependencyGraph, handleApiError]);

  // Initial data load
  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Handle real-time updates from SSE
  useEffect(() => {
    if (!lastEvent) {
      return;
    }

    const { event_type, data } = lastEvent;

    if (config.features.debugMode) {
      console.warn('Received SSE event:', { event_type, data });
    }

    switch (event_type) {
      case 'goal_created':
      case 'goal_updated':
      case 'task_created':
      case 'task_updated':
      case 'dependency_added':
        // Refresh data when goals or tasks change
        console.warn(`Refreshing data due to ${event_type} event`);
        refreshData();
        break;

      case 'connected':
        console.warn('SSE connected, refreshing data');
        refreshData();
        break;

      case 'keepalive':
        // Handle keepalive silently
        if (config.features.debugMode) {
          console.warn('SSE keepalive received');
        }
        break;

      default:
        if (config.features.debugMode) {
          console.warn('Unhandled SSE event type:', event_type);
        }
        break;
    }
  }, [lastEvent, refreshData]);

  // Update individual goal in hierarchy
  const updateGoalInHierarchy = useCallback((updatedGoal: Goal) => {
    setGoalHierarchy((prevHierarchy) => ({
      ...prevHierarchy,
      goals: prevHierarchy.goals.map((goal) =>
        goal.id === updatedGoal.id ? { ...goal, ...updatedGoal } : goal,
      ),
    }));
  }, []);

  // Update individual task in hierarchy
  const updateTaskInHierarchy = useCallback(
    (
      goalId: number,
      updatedTask: Partial<Goal['tasks'][0]> & { id: number },
    ) => {
      setGoalHierarchy((prevHierarchy) => ({
        ...prevHierarchy,
        goals: prevHierarchy.goals.map((goal) => {
          if (goal.id === goalId) {
            return {
              ...goal,
              tasks:
                goal.tasks?.map((task) =>
                  task.id === updatedTask.id
                    ? { ...task, ...updatedTask }
                    : task,
                ) || [],
            };
          }
          return goal;
        }),
      }));
    },
    [],
  );

  // Update task node in dependency graph
  const updateTaskInGraph = useCallback(
    (updatedTask: { id: number; status?: string; owner?: string }) => {
      setDependencyGraph((prevGraph) => ({
        ...prevGraph,
        nodes: prevGraph.nodes.map((node) =>
          parseInt(node.id) === updatedTask.id
            ? {
                ...node,
                data: {
                  ...node.data,
                  status: updatedTask.status || node.data.status,
                  owner: updatedTask.owner || node.data.owner,
                },
              }
            : node,
        ),
      }));
    },
    [],
  );

  return {
    goalHierarchy,
    dependencyGraph,
    stats,
    loading,
    error,
    refreshData,
    updateGoalInHierarchy,
    updateTaskInHierarchy,
    updateTaskInGraph,
  };
};
