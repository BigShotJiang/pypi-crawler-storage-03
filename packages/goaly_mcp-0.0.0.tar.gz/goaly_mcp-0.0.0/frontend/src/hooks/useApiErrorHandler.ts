import { useCallback } from 'react';
import { useNotification } from '../contexts/NotificationContext';

export interface ApiError {
  message: string;
  status?: number;
  code?: string;
  details?: any;
  timestamp: Date;
}

export interface ApiErrorHandlerConfig {
  showNotification?: boolean;
  notificationType?: 'error' | 'warning';
  retryable?: boolean;
  silent?: boolean;
}

/**
 * Custom hook for handling API errors consistently across the application
 * Provides centralized error logging, user notifications, and retry logic
 */
export const useApiErrorHandler = () => {
  const { showNotification: displayNotification } = useNotification();

  /**
   * Formats error message for display to users
   */
  const formatErrorMessage = useCallback((error: any): string => {
    if (typeof error === 'string') {
      return error;
    }

    if (error?.response?.data?.detail) {
      // FastAPI validation errors
      if (Array.isArray(error.response.data.detail)) {
        return error.response.data.detail
          .map(
            (item: any) => `${item.loc?.join?.('.') || 'Field'}: ${item.msg}`,
          )
          .join(', ');
      }
      return error.response.data.detail;
    }

    if (error?.response?.data?.message) {
      return error.response.data.message;
    }

    if (error?.message) {
      return error.message;
    }

    return 'An unexpected error occurred';
  }, []);

  /**
   * Determines if an error is retryable based on status code
   */
  const isRetryable = useCallback((error: any): boolean => {
    const status = error?.response?.status || error?.status;

    // Retry on network errors or server errors (5xx)
    if (!status || status >= 500) {
      return true;
    }

    // Don't retry on client errors (4xx) except for specific cases
    if (status >= 400 && status < 500) {
      // Retry on rate limiting or temporary client errors
      return status === 429 || status === 408;
    }

    return false;
  }, []);

  /**
   * Gets user-friendly error category
   */
  const getErrorCategory = useCallback((error: any): string => {
    const status = error?.response?.status || error?.status;

    if (!status) {
      return 'Network Error';
    }

    if (status >= 500) {
      return 'Server Error';
    }

    if (status === 404) {
      return 'Not Found';
    }

    if (status === 403) {
      return 'Access Denied';
    }

    if (status === 401) {
      return 'Authentication Required';
    }

    if (status === 429) {
      return 'Rate Limited';
    }

    if (status >= 400) {
      return 'Invalid Request';
    }

    return 'Unknown Error';
  }, []);

  /**
   * Creates standardized ApiError object
   */
  const createApiError = useCallback(
    (error: any, context?: string): ApiError => {
      return {
        message: formatErrorMessage(error),
        status: error?.response?.status || error?.status,
        code: error?.code,
        details: {
          originalError: error,
          context,
          category: getErrorCategory(error),
          retryable: isRetryable(error),
        },
        timestamp: new Date(),
      };
    },
    [formatErrorMessage, getErrorCategory, isRetryable],
  );

  /**
   * Main error handling function
   */
  const handleApiError = useCallback(
    (
      error: any,
      context?: string,
      config: ApiErrorHandlerConfig = {},
    ): ApiError => {
      const {
        showNotification = true,
        notificationType = 'error',
        silent = false,
      } = config;

      const apiError = createApiError(error, context);

      // Log error for debugging
      if (!silent) {
        console.error(`API Error${context ? ` in ${context}` : ''}:`, {
          message: apiError.message,
          status: apiError.status,
          category: apiError.details.category,
          retryable: apiError.details.retryable,
          originalError: error,
        });
      }

      // Show user notification
      if (showNotification) {
        const notificationMessage = `${apiError.details.category}: ${apiError.message}`;

        displayNotification(notificationMessage, notificationType);
      }

      // Report to error tracking service (if configured)
      if (process.env.NODE_ENV === 'production' && !silent) {
        // TODO: Integrate with error tracking service (e.g., Sentry)
        // reportToErrorService(apiError);
      }

      return apiError;
    },
    [createApiError, displayNotification],
  );

  /**
   * Wrapper for API calls with automatic error handling
   */
  const withErrorHandling = useCallback(
    <T>(
      apiCall: () => Promise<T>,
      context?: string,
      config?: ApiErrorHandlerConfig,
    ): Promise<T> => {
      return apiCall().catch((error) => {
        const apiError = handleApiError(error, context, config);
        throw apiError;
      });
    },
    [handleApiError],
  );

  /**
   * Retry wrapper with exponential backoff
   */
  const withRetry = useCallback(
    async <T>(
      apiCall: () => Promise<T>,
      context?: string,
      maxRetries: number = 3,
      initialDelay: number = 1000,
    ): Promise<T> => {
      let lastError: any;

      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
          return await apiCall();
        } catch (error) {
          lastError = error;

          const apiError = createApiError(error, context);

          // Don't retry if error is not retryable
          if (!apiError.details.retryable) {
            throw apiError;
          }

          // Don't retry on last attempt
          if (attempt === maxRetries) {
            break;
          }

          // Wait before retrying with exponential backoff
          const delay = initialDelay * Math.pow(2, attempt);
          console.warn(
            `Retrying API call in ${delay}ms (attempt ${attempt + 1}/${
              maxRetries + 1
            })`,
          );

          await new Promise((resolve) => setTimeout(resolve, delay));
        }
      }

      // If we get here, all retries failed
      throw handleApiError(
        lastError,
        `${context} (after ${maxRetries + 1} attempts)`,
      );
    },
    [createApiError, handleApiError],
  );

  return {
    handleApiError,
    withErrorHandling,
    withRetry,
    createApiError,
    formatErrorMessage,
    isRetryable,
    getErrorCategory,
  };
};

export default useApiErrorHandler;
