import React, { useCallback, useEffect, useRef } from 'react';

interface PerformanceMark {
  name: string;
  startTime: number;
  duration?: number;
  metadata?: Record<string, any>;
}

interface PerformanceProfilerOptions {
  enabled?: boolean;
  autoTrackComponents?: boolean;
  autoTrackRoutes?: boolean;
  maxMarks?: number;
  onMeasurement?: (mark: PerformanceMark) => void;
}

/**
 * Hook for performance profiling and measurement
 * Provides utilities for tracking component render times, API calls, and user interactions
 */
export const usePerformanceProfiler = ({
  enabled = process.env.NODE_ENV === 'development',
  autoTrackComponents = true,
  autoTrackRoutes: _autoTrackRoutes = true,
  maxMarks = 100,
  onMeasurement,
}: PerformanceProfilerOptions = {}) => {
  const marks = useRef<Map<string, PerformanceMark>>(new Map());
  const measurements = useRef<PerformanceMark[]>([]);

  // Start a performance mark
  const startMark = useCallback(
    (name: string, metadata?: Record<string, any>) => {
      if (!enabled) {
        return;
      }

      const mark: PerformanceMark = {
        name,
        startTime: performance.now(),
        metadata,
      };

      marks.current.set(name, mark);

      // Use native performance API if available
      if (performance.mark) {
        performance.mark(`${name}-start`);
      }
    },
    [enabled],
  );

  // End a performance mark and calculate duration
  const endMark = useCallback(
    (name: string, additionalMetadata?: Record<string, any>) => {
      if (!enabled) {
        return null;
      }

      const mark = marks.current.get(name);
      if (!mark) {
        console.warn(`Performance mark "${name}" not found`);
        return null;
      }

      const endTime = performance.now();
      const duration = endTime - mark.startTime;

      const completedMark: PerformanceMark = {
        ...mark,
        duration,
        metadata: { ...mark.metadata, ...additionalMetadata },
      };

      // Store measurement
      measurements.current.push(completedMark);

      // Keep only recent measurements
      if (measurements.current.length > maxMarks) {
        measurements.current = measurements.current.slice(-maxMarks);
      }

      // Clean up active mark
      marks.current.delete(name);

      // Use native performance API
      if (performance.mark && performance.measure) {
        performance.mark(`${name}-end`);
        performance.measure(name, `${name}-start`, `${name}-end`);
      }

      // Call measurement callback
      if (onMeasurement) {
        onMeasurement(completedMark);
      }

      // Log in development
      if (process.env.NODE_ENV === 'development') {
        console.warn(
          `⏱️  ${name}: ${duration.toFixed(2)}ms`,
          completedMark.metadata || '',
        );
      }

      return completedMark;
    },
    [enabled, maxMarks, onMeasurement],
  );

  // Measure a function execution
  const measureFunction = useCallback(
    async <T>(
      name: string,
      fn: () => T | Promise<T>,
      metadata?: Record<string, any>,
    ): Promise<{ result: T; duration: number }> => {
      if (!enabled) {
        const result = await fn();
        return { result, duration: 0 };
      }

      startMark(name, metadata);

      try {
        const result = await fn();
        const measurement = endMark(name, { success: true });
        return { result, duration: measurement?.duration || 0 };
      } catch (error) {
        endMark(name, {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
        throw error;
      }
    },
    [enabled, startMark, endMark],
  );

  // Measure API calls
  const measureApiCall = useCallback(
    async <T>(
      endpoint: string,
      fetchPromise: Promise<T>,
      metadata?: Record<string, any>,
    ): Promise<T> => {
      const markName = `api-${endpoint}`;

      const { result } = await measureFunction(markName, () => fetchPromise, {
        type: 'api-call',
        endpoint,
        ...metadata,
      });

      return result;
    },
    [measureFunction],
  );

  // Measure component render time
  const measureComponentRender = useCallback(
    (componentName: string, metadata?: Record<string, any>) => {
      if (!enabled || !autoTrackComponents) {
        return () => {
          // Noop function when profiling is disabled
        };
      }

      const markName = `render-${componentName}`;
      startMark(markName, {
        type: 'component-render',
        component: componentName,
        ...metadata,
      });

      return () => {
        endMark(markName);
      };
    },
    [enabled, autoTrackComponents, startMark, endMark],
  );

  // Measure user interactions
  const measureInteraction = useCallback(
    (interactionName: string, metadata?: Record<string, any>) => {
      const markName = `interaction-${interactionName}`;
      return measureFunction(
        markName,
        async () => {
          // Placeholder for interaction handler wrapping
          // This function will be used to wrap actual interaction handlers
          return Promise.resolve();
        },
        { type: 'user-interaction', interaction: interactionName, ...metadata },
      );
    },
    [measureFunction],
  );

  // Get performance summary
  const getPerformanceSummary = useCallback(() => {
    const summary = {
      totalMeasurements: measurements.current.length,
      componentRenders: measurements.current.filter(
        (m) => m.metadata?.type === 'component-render',
      ),
      apiCalls: measurements.current.filter(
        (m) => m.metadata?.type === 'api-call',
      ),
      userInteractions: measurements.current.filter(
        (m) => m.metadata?.type === 'user-interaction',
      ),
      averages: {} as Record<string, number>,
      slowest: {} as Record<string, PerformanceMark[]>,
    };

    // Calculate averages by type
    ['component-render', 'api-call', 'user-interaction'].forEach((type) => {
      const measurementsOfType = measurements.current.filter(
        (m) => m.metadata?.type === type,
      );
      if (measurementsOfType.length > 0) {
        const totalDuration = measurementsOfType.reduce(
          (sum, m) => sum + (m.duration || 0),
          0,
        );
        summary.averages[type] = totalDuration / measurementsOfType.length;

        // Find slowest measurements
        summary.slowest[type] = measurementsOfType
          .sort((a, b) => (b.duration || 0) - (a.duration || 0))
          .slice(0, 5);
      }
    });

    return summary;
  }, []);

  // Clear all measurements
  const clearMeasurements = useCallback(() => {
    measurements.current = [];
    marks.current.clear();

    // Clear native performance marks
    if (performance.clearMarks) {
      performance.clearMarks();
    }
    if (performance.clearMeasures) {
      performance.clearMeasures();
    }
  }, []);

  // Export measurements to JSON
  const exportMeasurements = useCallback(() => {
    return {
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      measurements: measurements.current,
      summary: getPerformanceSummary(),
    };
  }, [getPerformanceSummary]);

  return {
    startMark,
    endMark,
    measureFunction,
    measureApiCall,
    measureComponentRender,
    measureInteraction,
    getPerformanceSummary,
    clearMeasurements,
    exportMeasurements,
    measurements: measurements.current,
  };
};

/**
 * Higher-order component for automatically measuring component render times
 */
export const withPerformanceTracking = <P extends object>(
  Component: React.ComponentType<P>,
  componentName?: string,
) => {
  return React.forwardRef<any, P>((props, ref) => {
    const { measureComponentRender } = usePerformanceProfiler();
    const name =
      componentName || Component.displayName || Component.name || 'Anonymous';

    useEffect(() => {
      const endMeasurement = measureComponentRender(name, {
        props: Object.keys(props),
      });
      return endMeasurement;
    });

    // Handle ref prop properly - only pass it if Component is a forwardRef component
    const componentProps = { ...props } as P & { ref?: React.Ref<any> };
    if (ref && 'ref' in componentProps) {
      componentProps.ref = ref;
    }

    return React.createElement(Component, componentProps);
  });
};

/**
 * React hook for automatic component render tracking
 */
export const useRenderTracking = (
  componentName: string,
  dependencies?: React.DependencyList,
) => {
  const { measureComponentRender } = usePerformanceProfiler();

  useEffect(() => {
    const endMeasurement = measureComponentRender(componentName);
    return endMeasurement;
  }, dependencies);
};

/**
 * Utility for measuring resource loading times
 */
export const measureResourceLoading = () => {
  if (typeof window === 'undefined' || !performance.getEntriesByType) {
    return [];
  }

  const resources = performance.getEntriesByType(
    'resource',
  ) as PerformanceResourceTiming[];

  return resources.map((resource) => ({
    name: resource.name,
    duration: resource.responseEnd - resource.requestStart,
    size: resource.transferSize || 0,
    type: resource.initiatorType,
    startTime: resource.startTime,
  }));
};

export default usePerformanceProfiler;
