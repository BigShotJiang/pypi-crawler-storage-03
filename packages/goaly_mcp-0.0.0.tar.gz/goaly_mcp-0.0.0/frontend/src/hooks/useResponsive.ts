import { useTheme, Breakpoint } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';

/**
 * Hook for responsive design utilities
 * Provides breakpoint detection and responsive values
 */
export const useResponsive = () => {
  const theme = useTheme();

  // Breakpoint detection
  const isXs = useMediaQuery(theme.breakpoints.only('xs'));
  const isSm = useMediaQuery(theme.breakpoints.only('sm'));
  const isMd = useMediaQuery(theme.breakpoints.only('md'));
  const isLg = useMediaQuery(theme.breakpoints.only('lg'));
  const isXl = useMediaQuery(theme.breakpoints.only('xl'));

  // Up breakpoints
  const isSmUp = useMediaQuery(theme.breakpoints.up('sm'));
  const isMdUp = useMediaQuery(theme.breakpoints.up('md'));
  const isLgUp = useMediaQuery(theme.breakpoints.up('lg'));
  const isXlUp = useMediaQuery(theme.breakpoints.up('xl'));

  // Down breakpoints
  const isXsDown = useMediaQuery(theme.breakpoints.down('sm'));
  const isSmDown = useMediaQuery(theme.breakpoints.down('md'));
  const isMdDown = useMediaQuery(theme.breakpoints.down('lg'));
  const isLgDown = useMediaQuery(theme.breakpoints.down('xl'));

  // Current breakpoint
  const getCurrentBreakpoint = (): Breakpoint => {
    if (isXs) {
      return 'xs';
    }
    if (isSm) {
      return 'sm';
    }
    if (isMd) {
      return 'md';
    }
    if (isLg) {
      return 'lg';
    }
    return 'xl';
  };

  // Responsive value selector
  const getResponsiveValue = <T>(values: {
    xs?: T;
    sm?: T;
    md?: T;
    lg?: T;
    xl?: T;
  }): T | undefined => {
    const breakpoint = getCurrentBreakpoint();

    // Return the value for current breakpoint or fall back to smaller ones
    const value = values[breakpoint];
    if (value !== undefined) {
      return value;
    }

    // Fallback chain - only check values that exist
    if (breakpoint !== 'xs' && values.lg !== undefined) {
      return values.lg;
    }
    if (breakpoint !== 'xs' && breakpoint !== 'sm' && values.md !== undefined) {
      return values.md;
    }
    if (breakpoint !== 'xs' && values.sm !== undefined) {
      return values.sm;
    }
    if (values.xs !== undefined) {
      return values.xs;
    }

    // Final fallback - return any available value
    const keys = Object.keys(values) as Array<keyof typeof values>;
    for (const key of keys) {
      if (values[key] !== undefined) {
        return values[key];
      }
    }

    return undefined;
  };

  // Screen size categories
  const isMobile = isXsDown;
  const isTablet = isSm || isMd;
  const isDesktop = isLgUp;

  // Container sizing
  const getContainerSpacing = () => {
    if (isMobile) {
      return 1;
    }
    if (isTablet) {
      return 2;
    }
    return 3;
  };

  const getCardPadding = () => {
    if (isMobile) {
      return 1;
    }
    if (isTablet) {
      return 1.5;
    }
    return 2;
  };

  // Typography sizing
  const getFontSize = (base: 'small' | 'medium' | 'large') => {
    const sizes = {
      small: { xs: '0.7rem', sm: '0.75rem', md: '0.8rem' },
      medium: { xs: '0.85rem', sm: '0.9rem', md: '1rem' },
      large: { xs: '1rem', sm: '1.1rem', md: '1.25rem' },
    };

    return getResponsiveValue(sizes[base]);
  };

  // Component dimensions
  const getComponentHeight = (component: 'card' | 'input' | 'button') => {
    const heights = {
      card: { xs: 120, sm: 140, md: 160 },
      input: { xs: 44, sm: 40, md: 36 },
      button: { xs: 44, sm: 40, md: 36 },
    };

    return getResponsiveValue(heights[component]);
  };

  // Touch target sizes
  const getTouchTargetSize = () => {
    return isMobile ? 44 : 'auto';
  };

  // Grid spacing
  const getGridSpacing = (
    density: 'compact' | 'normal' | 'spacious' = 'normal',
  ) => {
    const spacings = {
      compact: { xs: 0.5, sm: 1, md: 1.5 },
      normal: { xs: 1, sm: 2, md: 3 },
      spacious: { xs: 2, sm: 3, md: 4 },
    };

    return getResponsiveValue(spacings[density]);
  };

  return {
    // Breakpoint detection
    isXs,
    isSm,
    isMd,
    isLg,
    isXl,
    isSmUp,
    isMdUp,
    isLgUp,
    isXlUp,
    isXsDown,
    isSmDown,
    isMdDown,
    isLgDown,

    // Screen categories
    isMobile,
    isTablet,
    isDesktop,

    // Current state
    currentBreakpoint: getCurrentBreakpoint(),

    // Utilities
    getResponsiveValue,
    getContainerSpacing,
    getCardPadding,
    getFontSize,
    getComponentHeight,
    getTouchTargetSize,
    getGridSpacing,
  };
};

/**
 * Hook for adaptive text sizing based on content length and screen size
 */
export const useAdaptiveTextSize = (
  text: string,
  _containerWidth?: number, // Currently unused but kept for future extension
) => {
  const { isMobile, isTablet } = useResponsive();

  const getOptimalFontSize = () => {
    const baseSize = isMobile ? 14 : isTablet ? 16 : 16;
    const length = text.length;

    // Reduce font size for longer text on smaller screens
    if (isMobile && length > 20) {
      return Math.max(12, baseSize - Math.floor(length / 10));
    }

    if (isTablet && length > 30) {
      return Math.max(14, baseSize - Math.floor(length / 15));
    }

    return baseSize;
  };

  const shouldTruncate = () => {
    const maxLength = isMobile ? 15 : isTablet ? 25 : 40;
    return text.length > maxLength;
  };

  const getTruncatedText = () => {
    if (!shouldTruncate()) {
      return text;
    }

    const maxLength = isMobile ? 12 : isTablet ? 22 : 37;
    return `${text.substring(0, maxLength)}...`;
  };

  return {
    fontSize: getOptimalFontSize(),
    shouldTruncate: shouldTruncate(),
    truncatedText: getTruncatedText(),
    originalText: text,
  };
};

export default useResponsive;
