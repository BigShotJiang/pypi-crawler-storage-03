// Shared type definitions for the Goaly MCP frontend

// Connection status types
export type ConnectionStatus = 'connected' | 'connecting' | 'disconnected';

// Task status types
export type TaskStatus =
  | 'completed'
  | 'owned'
  | 'available'
  | 'blocked'
  | 'cancelled';

// Layout direction types
export type LayoutDirection = 'TB' | 'LR';

// SSE Event interface
export interface SSEEvent {
  event_type: string;
  data: Record<string, unknown>;
}

// Notification state interface
export interface NotificationState {
  open: boolean;
  message: string;
  severity: 'error' | 'warning' | 'info' | 'success';
  duration?: number;
}

// Common color palette for status indicators
export const STATUS_COLORS = {
  completed: '#4caf50',
  owned: '#2196f3',
  available: '#ff9800',
  blocked: '#f44336',
  cancelled: '#9e9e9e',
  unknown: '#ccc',
} as const;

// Graph statistics interface
export interface GraphStats {
  totalNodes: number;
  completedNodes: number;
  blockedNodes: number;
  availableNodes: number;
}

// Dimension interface for component sizing
export interface Dimensions {
  width: number;
  height: number;
}
