"""
Test GoalRepository with session decorators.

Tests the refactored GoalRepository to ensure proper session management
and object detachment works correctly.
"""


class TestGoalRepository:
    """Test the refactored GoalRepository with session decorators."""

    def test_create_goal(self, goal_repo):
        """Test creating a goal with @with_session decorator."""
        repo = goal_repo

        # Create a goal
        goal = repo.create("Test goal creation")

        # Verify goal was created and is detached
        assert goal is not None
        assert goal.id is not None
        assert goal.description == "Test goal creation"
        assert not goal.is_complete

        # Verify we can access attributes without session errors
        assert goal.description == "Test goal creation"
        assert goal.created_at is not None

    def test_get_goal_by_id(self, goal_repo):
        """Test retrieving a goal by ID with @with_session decorator."""
        repo = goal_repo

        # Create a goal first
        created_goal = repo.create("Goal for retrieval test")
        goal_id = created_goal.id

        # Retrieve the goal
        retrieved_goal = repo.get_by_id(goal_id)

        # Verify retrieval and detachment
        assert retrieved_goal is not None
        assert retrieved_goal.id == goal_id
        assert retrieved_goal.description == "Goal for retrieval test"

        # Verify we can access attributes without session errors
        assert retrieved_goal.created_at is not None

    def test_get_goal_by_id_nonexistent(self, goal_repo):
        """Test retrieving a non-existent goal returns None."""
        repo = goal_repo

        # Try to get non-existent goal
        goal = repo.get_by_id(99999)

        assert goal is None

    def test_list_all_goals(self, goal_repo):
        """Test listing all goals with @with_session_list decorator."""
        repo = goal_repo

        # Create multiple goals
        descriptions = ["Goal 1", "Goal 2", "Goal 3"]
        created_goals = []
        for desc in descriptions:
            goal = repo.create(desc)
            created_goals.append(goal)

        # List all goals
        all_goals = repo.list_all()

        # Verify all goals are returned and detached
        assert len(all_goals) >= 3

        # Find our created goals
        our_goals = [g for g in all_goals if g.description in descriptions]
        assert len(our_goals) == 3

        # Verify each goal is detached and accessible
        for goal in our_goals:
            assert goal.description in descriptions
            assert goal.id is not None
            assert goal.created_at is not None

    def test_list_all_completed_only(self, goal_repo):
        """Test listing only completed goals."""
        repo = goal_repo

        # Create goals with different completion status
        repo.create("Incomplete goal")  # Create incomplete goal
        completed_goal = repo.create("Completed goal")

        # Mark one as complete
        repo.update(completed_goal.id, is_complete=True)

        # List completed goals only
        completed_goals = repo.list_all(completed_only=True)

        # Verify only completed goals are returned
        completed_descriptions = [g.description for g in completed_goals]
        assert "Completed goal" in completed_descriptions

        # Verify incomplete goal is not in the list
        assert "Incomplete goal" not in completed_descriptions

    def test_list_all_incomplete_only(self, goal_repo):
        """Test listing only incomplete goals."""
        repo = goal_repo

        # Create goals with different completion status
        repo.create("Incomplete goal test")  # Create incomplete goal
        completed_goal = repo.create("Completed goal test")

        # Mark one as complete
        repo.update(completed_goal.id, is_complete=True)

        # List incomplete goals only
        incomplete_goals = repo.list_all(incomplete_only=True)

        # Verify only incomplete goals are returned
        incomplete_descriptions = [g.description for g in incomplete_goals]
        assert "Incomplete goal test" in incomplete_descriptions

        # Verify completed goal is not in the list
        assert "Completed goal test" not in incomplete_descriptions

    def test_update_goal(self, goal_repo):
        """Test updating a goal with @with_session decorator."""
        repo = goal_repo

        # Create a goal
        goal = repo.create("Original description")
        goal_id = goal.id

        # Update the goal
        updated_goal = repo.update(goal_id, description="Updated description", is_complete=True)

        # Verify update and detachment
        assert updated_goal is not None
        assert updated_goal.id == goal_id
        assert updated_goal.description == "Updated description"
        assert updated_goal.is_complete is True

        # Verify we can access attributes without session errors
        assert updated_goal.created_at is not None

    def test_update_goal_nonexistent(self, goal_repo):
        """Test updating a non-existent goal returns None."""
        repo = goal_repo

        # Try to update non-existent goal
        result = repo.update(99999, description="New description")

        assert result is None

    def test_delete_goal(self, goal_repo):
        """Test deleting a goal with @with_session_raw decorator."""
        repo = goal_repo

        # Create a goal
        goal = repo.create("Goal to delete")
        goal_id = goal.id

        # Delete the goal
        deleted = repo.delete(goal_id)

        # Verify deletion
        assert deleted is True

        # Verify goal no longer exists
        retrieved_goal = repo.get_by_id(goal_id)
        assert retrieved_goal is None

    def test_delete_goal_nonexistent(self, goal_repo):
        """Test deleting a non-existent goal returns False."""
        repo = goal_repo

        # Try to delete non-existent goal
        deleted = repo.delete(99999)

        assert deleted is False

    def test_goal_with_tasks_selectinload(self, goal_repo):
        """Test that goals list properly includes tasks via selectinload."""
        repo = goal_repo

        # Create a goal
        goal = repo.create("Goal with potential tasks")

        # List all goals (should use selectinload for tasks)
        all_goals = repo.list_all()

        # Find our goal
        our_goal = next((g for g in all_goals if g.id == goal.id), None)
        assert our_goal is not None

        # Verify tasks attribute is accessible (even if empty)
        # This verifies selectinload is working
        assert hasattr(our_goal, "tasks")
        assert our_goal.tasks == []  # Should be empty list since no tasks created

    def test_full_crud_cycle(self, goal_repo):
        """Test complete CRUD cycle with the refactored repository."""
        repo = goal_repo

        # Create
        goal = repo.create("CRUD test goal")
        assert goal is not None
        goal_id = goal.id

        # Read single
        retrieved_goal = repo.get_by_id(goal_id)
        assert retrieved_goal is not None
        assert retrieved_goal.description == "CRUD test goal"

        # Read list
        all_goals = repo.list_all()
        our_goal = next((g for g in all_goals if g.id == goal_id), None)
        assert our_goal is not None
        assert our_goal.description == "CRUD test goal"

        # Update
        updated_goal = repo.update(goal_id, description="Updated CRUD test goal", is_complete=True)
        assert updated_goal is not None
        assert updated_goal.description == "Updated CRUD test goal"
        assert updated_goal.is_complete is True

        # Verify update persisted
        retrieved_after_update = repo.get_by_id(goal_id)
        assert retrieved_after_update.description == "Updated CRUD test goal"
        assert retrieved_after_update.is_complete is True

        # Delete
        deleted = repo.delete(goal_id)
        assert deleted is True

        # Verify deletion
        deleted_goal = repo.get_by_id(goal_id)
        assert deleted_goal is None


# Note: Using fixtures from conftest.py for proper database setup with migrations
