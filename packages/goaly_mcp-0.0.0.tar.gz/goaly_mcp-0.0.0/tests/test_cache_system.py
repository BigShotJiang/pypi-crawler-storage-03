"""
Tests for the caching system implementation.
"""

import threading
import time

import pytest

from goaly_mcp.cache import SimpleCache, cached, clear_all_cache, get_cache_instance, invalidate_related_cache


class TestSimpleCache:
    """Test the SimpleCache class."""

    def test_basic_get_set(self):
        """Test basic get/set operations."""
        cache = SimpleCache()

        # Test setting and getting a value
        cache.set("key1", "value1")
        assert cache.get("key1") == "value1"

        # Test non-existent key
        assert cache.get("nonexistent") is None

    def test_ttl_expiration(self):
        """Test TTL expiration functionality."""
        cache = SimpleCache(default_ttl=1)  # 1 second TTL

        cache.set("key1", "value1")
        assert cache.get("key1") == "value1"

        # Wait for expiration
        time.sleep(1.1)
        assert cache.get("key1") is None

    def test_custom_ttl(self):
        """Test custom TTL per key."""
        cache = SimpleCache(default_ttl=10)

        # Set with custom TTL
        cache.set("key1", "value1", ttl=1)
        cache.set("key2", "value2")  # Uses default TTL

        # Check immediate access
        assert cache.get("key1") == "value1"
        assert cache.get("key2") == "value2"

        # Wait for custom TTL to expire
        time.sleep(1.1)
        assert cache.get("key1") is None
        assert cache.get("key2") == "value2"  # Should still be there

    def test_delete(self):
        """Test explicit deletion."""
        cache = SimpleCache()

        cache.set("key1", "value1")
        assert cache.get("key1") == "value1"

        result = cache.delete("key1")
        assert result is True
        assert cache.get("key1") is None

        # Test deleting non-existent key
        result = cache.delete("nonexistent")
        assert result is False

    def test_clear(self):
        """Test clearing all entries."""
        cache = SimpleCache()

        cache.set("key1", "value1")
        cache.set("key2", "value2")

        cache.clear()
        assert cache.get("key1") is None
        assert cache.get("key2") is None

    def test_invalidate_pattern(self):
        """Test pattern-based invalidation."""
        cache = SimpleCache()

        cache.set("user:1:profile", "profile1")
        cache.set("user:1:settings", "settings1")
        cache.set("user:2:profile", "profile2")
        cache.set("other:data", "data")

        # Invalidate all user:1 entries
        count = cache.invalidate_pattern("user:1")
        assert count == 2

        # Check results
        assert cache.get("user:1:profile") is None
        assert cache.get("user:1:settings") is None
        assert cache.get("user:2:profile") == "profile2"
        assert cache.get("other:data") == "data"

    def test_max_size_lru_eviction(self):
        """Test LRU eviction when max size is reached."""
        cache = SimpleCache(max_size=3)

        # Fill cache to capacity
        cache.set("key1", "value1")
        cache.set("key2", "value2")
        cache.set("key3", "value3")

        # All should be present
        assert cache.get("key1") == "value1"
        assert cache.get("key2") == "value2"
        assert cache.get("key3") == "value3"

        # Access key1 to make it most recently used
        cache.get("key1")

        # Add fourth item, should evict least recently used (key2)
        cache.set("key4", "value4")

        assert cache.get("key1") == "value1"  # Still there (recently accessed)
        assert cache.get("key2") is None  # Evicted
        assert cache.get("key3") == "value3"  # Still there
        assert cache.get("key4") == "value4"  # New item

    def test_cleanup_expired(self):
        """Test cleanup of expired entries."""
        cache = SimpleCache(default_ttl=1)

        cache.set("key1", "value1")
        cache.set("key2", "value2")

        # Wait for expiration
        time.sleep(1.1)

        # Cleanup expired entries
        count = cache.cleanup_expired()
        assert count == 2

        # Verify they're gone
        assert cache.get("key1") is None
        assert cache.get("key2") is None

    def test_stats(self):
        """Test cache statistics."""
        cache = SimpleCache(max_size=100, default_ttl=300)

        stats = cache.stats()
        assert stats["total_entries"] == 0
        assert stats["max_size"] == 100
        assert stats["default_ttl"] == 300

        # Add some entries
        cache.set("key1", "value1")
        cache.set("key2", "value2")

        stats = cache.stats()
        assert stats["total_entries"] == 2
        assert stats["active_entries"] == 2
        assert stats["expired_entries"] == 0

    def test_thread_safety(self):
        """Test thread safety of cache operations."""
        cache = SimpleCache()
        results = []

        def worker(thread_id):
            for i in range(10):
                key = f"thread{thread_id}_key{i}"
                value = f"thread{thread_id}_value{i}"
                cache.set(key, value)
                result = cache.get(key)
                results.append(result == value)

        threads = []
        for i in range(5):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # All operations should have succeeded
        assert all(results)


class TestCachedDecorator:
    """Test the @cached decorator."""

    def test_basic_caching(self):
        """Test basic function caching."""
        call_count = 0

        @cached(ttl=60)
        def expensive_function(x):
            nonlocal call_count
            call_count += 1
            return x * 2

        # First call should execute function
        result1 = expensive_function(5)
        assert result1 == 10
        assert call_count == 1

        # Second call should use cache
        result2 = expensive_function(5)
        assert result2 == 10
        assert call_count == 1  # Not incremented

        # Different argument should execute function
        result3 = expensive_function(10)
        assert result3 == 20
        assert call_count == 2

    def test_method_caching(self):
        """Test caching on class methods."""

        class Calculator:
            def __init__(self):
                self.call_count = 0

            @cached(ttl=60)
            def expensive_calculation(self, x, y):
                self.call_count += 1
                return x * y

        calc = Calculator()

        # First call
        result1 = calc.expensive_calculation(5, 3)
        assert result1 == 15
        assert calc.call_count == 1

        # Second call with same args should use cache
        result2 = calc.expensive_calculation(5, 3)
        assert result2 == 15
        assert calc.call_count == 1

        # Different instance shares cache (by design)
        calc2 = Calculator()
        result3 = calc2.expensive_calculation(5, 3)
        assert result3 == 15
        assert calc2.call_count == 0  # Function not called due to cache hit

    def test_cache_with_kwargs(self):
        """Test caching with keyword arguments."""
        call_count = 0

        @cached(ttl=60)
        def function_with_kwargs(x, y=10, z=20):
            nonlocal call_count
            call_count += 1
            return x + y + z

        # Different ways of calling create different cache keys due to signature differences
        result1 = function_with_kwargs(1)  # x=1, y=10, z=20
        result2 = function_with_kwargs(1, y=10)  # Same values but different signature
        result3 = function_with_kwargs(1, y=15)  # Different values

        assert result1 == 31
        assert result2 == 31
        assert result3 == 36
        assert call_count == 3  # All create separate cache entries due to different signatures

    def test_cache_expiration(self):
        """Test cache expiration with decorator."""
        call_count = 0

        @cached(ttl=1)  # 1 second TTL
        def function_with_short_ttl(x):
            nonlocal call_count
            call_count += 1
            return x

        # First call
        result1 = function_with_short_ttl(5)
        assert result1 == 5
        assert call_count == 1

        # Wait for expiration
        time.sleep(1.1)

        # Second call should execute function again
        result2 = function_with_short_ttl(5)
        assert result2 == 5
        assert call_count == 2

    def test_cache_clear(self):
        """Test cache clearing functionality."""
        call_count = 0

        @cached(ttl=60)
        def cached_function(x):
            nonlocal call_count
            call_count += 1
            return x

        # Make some cached calls
        cached_function(1)
        cached_function(2)
        assert call_count == 2

        # Clear cache
        cached_function.cache_clear()

        # Same calls should execute again
        cached_function(1)
        cached_function(2)
        assert call_count == 4


class TestCacheIntegration:
    """Test cache integration with repository methods."""

    def test_invalidate_related_cache(self):
        """Test invalidate_related_cache function."""
        cache = SimpleCache()

        # Set up some cache entries
        cache.set("users:list:all", "users_data")
        cache.set("users:list:active", "active_users")
        cache.set("tasks:list:all", "tasks_data")
        cache.set("other:data", "other")

        # Invalidate users cache
        count = invalidate_related_cache("users", cache_instance=cache)
        assert count == 2

        # Check results
        assert cache.get("users:list:all") is None
        assert cache.get("users:list:active") is None
        assert cache.get("tasks:list:all") == "tasks_data"
        assert cache.get("other:data") == "other"

    def test_invalidate_multiple_patterns(self):
        """Test invalidating multiple patterns."""
        cache = SimpleCache()

        cache.set("users:1", "user1")
        cache.set("users:2", "user2")
        cache.set("tasks:1", "task1")
        cache.set("tasks:2", "task2")
        cache.set("other:1", "other1")

        # Invalidate both users and tasks
        count = invalidate_related_cache(["users", "tasks"], cache_instance=cache)
        assert count == 4

        assert cache.get("users:1") is None
        assert cache.get("users:2") is None
        assert cache.get("tasks:1") is None
        assert cache.get("tasks:2") is None
        assert cache.get("other:1") == "other1"

    def test_global_cache_instance(self):
        """Test global cache instance functions."""
        # Clear any existing cache
        clear_all_cache()

        cache = get_cache_instance()
        cache.set("test_key", "test_value")

        # Should be accessible through global instance
        assert get_cache_instance().get("test_key") == "test_value"

        # Clear should work
        clear_all_cache()
        assert get_cache_instance().get("test_key") is None


@pytest.mark.performance
def test_cache_performance():
    """Basic performance test for caching."""
    cache = SimpleCache()

    # Test set performance
    start_time = time.time()
    for i in range(1000):
        cache.set(f"key{i}", f"value{i}")
    set_time = time.time() - start_time

    # Test get performance
    start_time = time.time()
    for i in range(1000):
        cache.get(f"key{i}")
    get_time = time.time() - start_time

    # Should be very fast
    assert set_time < 1.0  # Less than 1 second for 1000 sets
    assert get_time < 0.5  # Less than 0.5 seconds for 1000 gets

    print(f"Cache performance - Set: {set_time:.3f}s, Get: {get_time:.3f}s")
