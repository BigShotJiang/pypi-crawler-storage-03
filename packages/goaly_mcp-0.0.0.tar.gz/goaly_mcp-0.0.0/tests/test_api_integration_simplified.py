"""
Simplified API integration tests for TaskMaster MCP.

This module tests the most important API workflows and integration scenarios
with the actual API response format.
"""

import pytest
from fastapi.testclient import TestClient

from goaly_mcp.test_app import create_test_app


@pytest.fixture
def api_client():
    """Create a FastAPI test client for API testing."""
    test_app = create_test_app()
    return TestClient(test_app)


def extract_goal_data(response):
    """Extract goal data from API response wrapper."""
    response_data = response.json()
    assert response_data["success"] is True
    return response_data["data"]


def extract_task_data(response):
    """Extract task data from API response wrapper."""
    response_data = response.json()
    assert response_data["success"] is True
    return response_data["data"]


class TestGoalAPIWorkflow:
    """Test complete goal API workflows."""

    def test_goal_crud_workflow(self, api_client: TestClient, clean_database):
        """Test complete goal CRUD workflow."""
        # 1. Create a goal
        goal_data = {"description": "Complete CRUD workflow test"}
        create_response = api_client.post("/api/v1/goals/", json=goal_data)

        assert create_response.status_code == 200
        created_goal = extract_goal_data(create_response)

        goal_id = created_goal["id"]
        assert created_goal["description"] == "Complete CRUD workflow test"
        assert created_goal["is_complete"] is False

        # 2. Get the goal by ID
        get_response = api_client.get(f"/api/v1/goals/{goal_id}")

        assert get_response.status_code == 200
        retrieved_goal = extract_goal_data(get_response)

        assert retrieved_goal["id"] == goal_id
        assert retrieved_goal["description"] == "Complete CRUD workflow test"

        # 3. Update the goal
        update_data = {"description": "Updated CRUD workflow test", "is_complete": True}
        update_response = api_client.put(f"/api/v1/goals/{goal_id}", json=update_data)

        assert update_response.status_code == 200
        updated_goal = extract_goal_data(update_response)

        assert updated_goal["description"] == "Updated CRUD workflow test"
        assert updated_goal["is_complete"] is True

        # 4. List goals (should include our goal)
        list_response = api_client.get("/api/v1/goals/")

        assert list_response.status_code == 200
        list_data = extract_goal_data(list_response)

        goals = list_data["goals"]
        assert len(goals) >= 1

        our_goal = next((g for g in goals if g["id"] == goal_id), None)
        assert our_goal is not None
        assert our_goal["description"] == "Updated CRUD workflow test"

        # 5. Delete the goal
        delete_response = api_client.delete(f"/api/v1/goals/{goal_id}")

        assert delete_response.status_code == 200
        delete_data = extract_goal_data(delete_response)
        assert delete_data["deleted_goal_id"] == goal_id

        # 6. Verify deletion
        get_deleted_response = api_client.get(f"/api/v1/goals/{goal_id}")
        assert get_deleted_response.status_code == 404

    def test_goal_filtering_workflow(self, api_client: TestClient, clean_database):
        """Test goal filtering functionality."""
        # Create goals with different completion states
        incomplete_response = api_client.post("/api/v1/goals/", json={"description": "Incomplete test goal"})
        extract_goal_data(incomplete_response)

        complete_goal_response = api_client.post("/api/v1/goals/", json={"description": "Complete test goal"})
        complete_goal = extract_goal_data(complete_goal_response)

        # Mark one as complete
        api_client.put(f"/api/v1/goals/{complete_goal['id']}", json={"is_complete": True})

        # Test completed_only filter
        completed_response = api_client.get("/api/v1/goals/?completed_only=true")
        assert completed_response.status_code == 200
        completed_data = extract_goal_data(completed_response)

        completed_goals = completed_data["goals"]
        completed_descriptions = [g["description"] for g in completed_goals]
        assert "Complete test goal" in completed_descriptions
        assert "Incomplete test goal" not in completed_descriptions

        # Test incomplete_only filter
        incomplete_response = api_client.get("/api/v1/goals/?incomplete_only=true")
        assert incomplete_response.status_code == 200
        incomplete_data = extract_goal_data(incomplete_response)

        incomplete_goals = incomplete_data["goals"]
        incomplete_descriptions = [g["description"] for g in incomplete_goals]
        assert "Incomplete test goal" in incomplete_descriptions


class TestTaskAPIWorkflow:
    """Test complete task API workflows."""

    def test_task_crud_workflow(self, api_client: TestClient, clean_database):
        """Test complete task CRUD workflow."""
        # 1. Create a goal first
        goal_response = api_client.post("/api/v1/goals/", json={"description": "Goal for task CRUD test"})
        goal = extract_goal_data(goal_response)

        # 2. Create a task
        task_data = {
            "goal_id": goal["id"],
            "name": "Test task for CRUD",
            "instructions": "Instructions for CRUD test task",
        }
        create_response = api_client.post("/api/v1/tasks/", json=task_data)

        assert create_response.status_code == 200
        created_task = extract_task_data(create_response)

        task_id = created_task["id"]
        assert created_task["goal_id"] == goal["id"]
        assert created_task["name"] == "Test task for CRUD"
        assert created_task["status"] == "available"

        # 3. Get the task by ID
        get_response = api_client.get(f"/api/v1/tasks/{task_id}")

        assert get_response.status_code == 200
        retrieved_task = extract_task_data(get_response)

        assert retrieved_task["id"] == task_id
        assert retrieved_task["name"] == "Test task for CRUD"

        # 4. Update the task
        update_data = {"name": "Updated test task", "status": "owned", "owner": "test-agent"}
        update_response = api_client.put(f"/api/v1/tasks/{task_id}", json=update_data)

        assert update_response.status_code == 200
        updated_task = extract_task_data(update_response)

        assert updated_task["name"] == "Updated test task"
        assert updated_task["status"] == "owned"
        assert updated_task["owner"] == "test-agent"

        # 5. List tasks (should include our task)
        list_response = api_client.get("/api/v1/tasks/")

        assert list_response.status_code == 200
        list_data = extract_task_data(list_response)

        tasks = list_data.get("tasks", list_data)
        if isinstance(tasks, list):
            our_task = next((t for t in tasks if t["id"] == task_id), None)
            assert our_task is not None

        # 6. Delete the task
        delete_response = api_client.delete(f"/api/v1/tasks/{task_id}")

        assert delete_response.status_code == 200

        # 7. Verify deletion
        get_deleted_response = api_client.get(f"/api/v1/tasks/{task_id}")
        assert get_deleted_response.status_code == 404

    def test_task_filtering_workflow(self, api_client: TestClient, clean_database):
        """Test task filtering functionality."""
        # Create goal and tasks
        goal = extract_goal_data(
            api_client.post("/api/v1/goals/", json={"description": "Goal for task filtering test"})
        )

        # Create tasks with different statuses
        extract_task_data(
            api_client.post(
                "/api/v1/tasks/",
                json={"goal_id": goal["id"], "name": "Available task", "instructions": "Task that stays available"},
            )
        )

        owned_task = extract_task_data(
            api_client.post(
                "/api/v1/tasks/",
                json={"goal_id": goal["id"], "name": "Owned task", "instructions": "Task that will be owned"},
            )
        )

        # Update one task to owned status
        api_client.put(f"/api/v1/tasks/{owned_task['id']}", json={"status": "owned", "owner": "test-agent"})

        # Test filtering by goal_id
        goal_filter_response = api_client.get(f"/api/v1/tasks/?goal_id={goal['id']}")
        assert goal_filter_response.status_code == 200

        # Test filtering by status
        available_filter_response = api_client.get("/api/v1/tasks/?status=available")
        assert available_filter_response.status_code == 200

        owned_filter_response = api_client.get("/api/v1/tasks/?status=owned")
        assert owned_filter_response.status_code == 200


class TestGoalTaskIntegration:
    """Test goal-task integration workflows."""

    def test_goal_hierarchy_workflow(self, api_client: TestClient, clean_database):
        """Test goal hierarchy endpoint with tasks."""
        # Create a goal
        goal = extract_goal_data(api_client.post("/api/v1/goals/", json={"description": "Goal for hierarchy test"}))

        # Create multiple tasks for the goal
        task_names = ["Task 1", "Task 2", "Task 3"]
        created_tasks = []

        for name in task_names:
            task_response = api_client.post(
                "/api/v1/tasks/", json={"goal_id": goal["id"], "name": name, "instructions": f"Instructions for {name}"}
            )
            created_tasks.append(extract_task_data(task_response))

        # Get goal hierarchy
        hierarchy_response = api_client.get(f"/api/v1/goals/{goal['id']}/hierarchy")

        assert hierarchy_response.status_code == 200
        hierarchy_data = extract_goal_data(hierarchy_response)

        # Verify hierarchy structure
        assert "goal" in hierarchy_data
        assert "tasks" in hierarchy_data
        assert "summary" in hierarchy_data

        goal_info = hierarchy_data["goal"]
        assert goal_info["id"] == goal["id"]
        assert goal_info["description"] == "Goal for hierarchy test"

        tasks_info = hierarchy_data["tasks"]
        assert len(tasks_info) == 3

        task_names_in_hierarchy = [t["name"] for t in tasks_info]
        for name in task_names:
            assert name in task_names_in_hierarchy

        summary = hierarchy_data["summary"]
        assert summary["total_tasks"] == 3
        assert summary["completed_tasks"] == 0  # None completed yet
        assert summary["available_tasks"] == 3  # All available

    def test_complete_workflow_lifecycle(self, api_client: TestClient, clean_database):
        """Test a complete workflow from goal creation to completion."""
        # 1. Create a goal
        goal = extract_goal_data(
            api_client.post("/api/v1/goals/", json={"description": "Complete project lifecycle test"})
        )

        # 2. Create multiple tasks
        task_names = ["Setup environment", "Implement features", "Write tests", "Deploy"]

        created_tasks = []
        for name in task_names:
            task_response = api_client.post(
                "/api/v1/tasks/",
                json={"goal_id": goal["id"], "name": name, "instructions": f"Instructions for: {name}"},
            )
            created_tasks.append(extract_task_data(task_response))

        # 3. Verify initial state through hierarchy
        hierarchy = extract_goal_data(api_client.get(f"/api/v1/goals/{goal['id']}/hierarchy"))
        assert hierarchy["summary"]["total_tasks"] == 4
        assert hierarchy["summary"]["completed_tasks"] == 0

        # 4. Complete tasks one by one
        for task in created_tasks:
            # Update to owned
            api_client.put(f"/api/v1/tasks/{task['id']}", json={"status": "owned", "owner": f"agent-{task['id']}"})

            # Update to completed
            api_client.put(f"/api/v1/tasks/{task['id']}", json={"status": "completed"})

        # 5. Verify all tasks are completed
        final_hierarchy = extract_goal_data(api_client.get(f"/api/v1/goals/{goal['id']}/hierarchy"))
        assert final_hierarchy["summary"]["completed_tasks"] == 4
        assert final_hierarchy["summary"]["available_tasks"] == 0

        # 6. Mark goal as complete
        final_goal_response = api_client.put(f"/api/v1/goals/{goal['id']}", json={"is_complete": True})
        final_goal = extract_goal_data(final_goal_response)
        assert final_goal["is_complete"] is True


class TestTaskDependencyWorkflow:
    """Test task dependency API workflows."""

    def test_dependency_creation_workflow(self, api_client: TestClient, clean_database):
        """Test creating and managing task dependencies."""
        # Create goal and tasks
        goal = extract_goal_data(api_client.post("/api/v1/goals/", json={"description": "Goal for dependency test"}))

        task1 = extract_task_data(
            api_client.post(
                "/api/v1/tasks/", json={"goal_id": goal["id"], "name": "Foundation task", "instructions": "Base task"}
            )
        )

        task2 = extract_task_data(
            api_client.post(
                "/api/v1/tasks/",
                json={"goal_id": goal["id"], "name": "Dependent task", "instructions": "Depends on foundation"},
            )
        )

        # Create dependency
        dependency_data = {
            "dependent_task_id": task2["id"],
            "dependency_task_id": task1["id"],
            "required_data": "Foundation completion data",
        }

        dependency_response = api_client.post("/api/v1/tasks/dependencies", json=dependency_data)

        assert dependency_response.status_code == 200
        dependency = extract_task_data(dependency_response)

        assert dependency["dependent_task_id"] == task2["id"]
        assert dependency["dependency_task_id"] == task1["id"]
        assert dependency["required_data"] == "Foundation completion data"

    def test_dependency_graph_workflow(self, api_client: TestClient, clean_database):
        """Test dependency graph endpoint."""
        # Create goal and tasks with dependencies
        goal = extract_goal_data(api_client.post("/api/v1/goals/", json={"description": "Goal for graph test"}))

        task1 = extract_task_data(
            api_client.post(
                "/api/v1/tasks/", json={"goal_id": goal["id"], "name": "Task 1", "instructions": "First task"}
            )
        )

        task2 = extract_task_data(
            api_client.post(
                "/api/v1/tasks/", json={"goal_id": goal["id"], "name": "Task 2", "instructions": "Second task"}
            )
        )

        # Create dependency
        api_client.post(
            "/api/v1/tasks/dependencies", json={"dependent_task_id": task2["id"], "dependency_task_id": task1["id"]}
        )

        # Get dependency graph
        graph_response = api_client.get("/api/v1/tasks/dependencies/graph")

        assert graph_response.status_code == 200
        # The graph endpoint should return some kind of structured data
        graph_data = graph_response.json()
        assert isinstance(graph_data, dict)


class TestAPIErrorHandling:
    """Test API error handling scenarios."""

    def test_goal_not_found_errors(self, api_client: TestClient, clean_database):
        """Test goal not found error scenarios."""
        # Get non-existent goal
        response = api_client.get("/api/v1/goals/99999")
        assert response.status_code == 404

        error_data = response.json()
        assert "not found" in error_data["detail"].lower()

        # Update non-existent goal
        response = api_client.put("/api/v1/goals/99999", json={"description": "Should not work"})
        assert response.status_code == 404

        # Delete non-existent goal
        response = api_client.delete("/api/v1/goals/99999")
        assert response.status_code == 404

    def test_task_not_found_errors(self, api_client: TestClient, clean_database):
        """Test task not found error scenarios."""
        # Get non-existent task
        response = api_client.get("/api/v1/tasks/99999")
        assert response.status_code == 404

        # Update non-existent task
        response = api_client.put("/api/v1/tasks/99999", json={"name": "Should not work"})
        assert response.status_code == 404

        # Delete non-existent task
        response = api_client.delete("/api/v1/tasks/99999")
        assert response.status_code == 404

    def test_validation_errors(self, api_client: TestClient, clean_database):
        """Test validation error scenarios."""
        # Goal with missing description
        response = api_client.post("/api/v1/goals/", json={})
        assert response.status_code == 422

        # Task with missing required fields
        response = api_client.post("/api/v1/tasks/", json={"name": "Task without goal_id"})
        assert response.status_code == 422

        # Task with invalid goal_id
        response = api_client.post(
            "/api/v1/tasks/", json={"goal_id": 99999, "name": "Task with invalid goal", "instructions": "Should fail"}
        )
        assert response.status_code == 400


class TestHealthAndMetaEndpoints:
    """Test health and metadata endpoints."""

    def test_health_endpoint(self, api_client: TestClient):
        """Test health check endpoint."""
        response = api_client.get("/health")

        assert response.status_code == 200
        health_data = response.json()

        # Health endpoint might have different formats
        # Just verify it returns some reasonable data
        assert isinstance(health_data, dict)

    def test_openapi_schema(self, api_client: TestClient):
        """Test OpenAPI schema endpoint."""
        response = api_client.get("/openapi.json")

        assert response.status_code == 200
        schema = response.json()

        assert "openapi" in schema
        assert "info" in schema
        assert "paths" in schema

        # Verify our main endpoints are documented
        paths = schema["paths"]
        assert "/api/v1/goals/" in paths
        assert "/api/v1/tasks/" in paths
