"""
Tests for async database functionality
"""

from unittest.mock import AsyncMock, Mock, patch

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from goaly_mcp.database_async import (
    ASYNC_USAGE_PATTERNS,
    AsyncDatabaseUtils,
    convert_to_async_url,
    create_async_engine_instance,
    get_async_db,
    managed_async_session,
    validate_async_url,
)


class TestAsyncURLConversion:
    """Test async URL conversion functionality"""

    def test_sqlite_url_conversion(self):
        """Test SQLite URL conversion"""
        sync_url = "sqlite:///./test.db"
        async_url = convert_to_async_url(sync_url)
        assert async_url == "sqlite+aiosqlite:///./test.db"

    def test_postgresql_url_conversion(self):
        """Test PostgreSQL URL conversion"""
        sync_url = "postgresql://user:pass@localhost:5432/mydb"
        async_url = convert_to_async_url(sync_url)
        assert async_url == "postgresql+asyncpg://user:pass@localhost:5432/mydb"

    def test_mysql_url_conversion(self):
        """Test MySQL URL conversion"""
        sync_url = "mysql://user:pass@localhost:3306/mydb"
        async_url = convert_to_async_url(sync_url)
        assert async_url == "mysql+aiomysql://user:pass@localhost:3306/mydb"

    def test_already_async_url(self):
        """Test that already async URLs are handled correctly"""
        async_url = "sqlite+aiosqlite:///./test.db"
        result = convert_to_async_url(async_url)
        assert result == async_url

    def test_unknown_scheme(self):
        """Test handling of unknown database schemes"""
        unknown_url = "unknown://localhost/db"
        result = convert_to_async_url(unknown_url)
        assert result == unknown_url

    def test_url_with_query_params(self):
        """Test URL conversion preserves query parameters"""
        sync_url = "sqlite:///./test.db?check_same_thread=False"
        async_url = convert_to_async_url(sync_url)
        assert async_url == "sqlite+aiosqlite:///./test.db?check_same_thread=False"


class TestAsyncURLValidation:
    """Test async URL validation"""

    def test_valid_sqlite_async_url(self):
        """Test validation of valid SQLite async URL"""
        url = "sqlite+aiosqlite:///./test.db"
        assert validate_async_url(url) is True

    def test_valid_postgresql_async_url(self):
        """Test validation of valid PostgreSQL async URL"""
        url = "postgresql+asyncpg://user:pass@localhost/db"
        assert validate_async_url(url) is True

    def test_valid_mysql_async_url(self):
        """Test validation of valid MySQL async URL"""
        url = "mysql+aiomysql://user:pass@localhost/db"
        assert validate_async_url(url) is True

    def test_invalid_sync_url(self):
        """Test validation fails for sync URLs"""
        url = "sqlite:///./test.db"
        assert validate_async_url(url) is False

    def test_unknown_async_driver(self):
        """Test validation fails for unknown async drivers"""
        url = "sqlite+unknown:///./test.db"
        assert validate_async_url(url) is False


class TestAsyncEngineCreation:
    """Test async engine creation"""

    @patch("goaly_mcp.database_async.create_async_engine")
    def test_create_sqlite_engine(self, mock_create_engine):
        """Test SQLite engine creation with correct parameters"""
        mock_engine = AsyncMock()
        mock_create_engine.return_value = mock_engine

        url = "sqlite+aiosqlite:///./test.db"
        engine = create_async_engine_instance(url=url, echo=True)

        mock_create_engine.assert_called_once_with(url, echo=True, connect_args={"check_same_thread": False})
        assert engine == mock_engine

    @patch("goaly_mcp.database_async.create_async_engine")
    def test_create_postgresql_engine(self, mock_create_engine):
        """Test PostgreSQL engine creation with connection pooling"""
        mock_engine = AsyncMock()
        mock_create_engine.return_value = mock_engine

        url = "postgresql+asyncpg://user:pass@localhost/db"
        engine = create_async_engine_instance(url=url, pool_size=10, max_overflow=20)

        mock_create_engine.assert_called_once_with(url, echo=False, pool_size=10, max_overflow=20, pool_pre_ping=True)
        assert engine == mock_engine


@pytest.mark.asyncio
class TestAsyncSessionManagement:
    """Test async session management"""

    @patch("goaly_mcp.database_async.get_async_session_factory")
    async def test_get_async_db_success(self, mock_get_factory):
        """Test successful async database session"""
        mock_session = AsyncMock(spec=AsyncSession)
        # Mock the session factory as a regular Mock (not AsyncMock) that returns the session
        mock_session_factory = Mock()
        mock_session_factory.return_value = mock_session
        mock_get_factory.return_value = mock_session_factory

        async with get_async_db() as session:
            assert session == mock_session

        mock_session.commit.assert_called_once()
        mock_session.close.assert_called_once()

    @patch("goaly_mcp.database_async.get_async_session_factory")
    async def test_get_async_db_exception(self, mock_get_factory):
        """Test async database session with exception handling"""
        mock_session = AsyncMock(spec=AsyncSession)
        # Mock the session factory as a regular Mock (not AsyncMock) that returns the session
        mock_session_factory = Mock()
        mock_session_factory.return_value = mock_session
        mock_get_factory.return_value = mock_session_factory

        with pytest.raises(ValueError):
            async with get_async_db():
                raise ValueError("Test error")

        mock_session.rollback.assert_called_once()
        mock_session.close.assert_called_once()

    @patch("goaly_mcp.database_async.get_async_db")
    async def test_managed_async_session(self, mock_get_db):
        """Test managed async session context manager"""
        mock_session = AsyncMock(spec=AsyncSession)
        mock_get_db.return_value.__aenter__.return_value = mock_session
        mock_get_db.return_value.__aexit__.return_value = None

        async with managed_async_session() as session:
            assert session == mock_session


@pytest.mark.asyncio
class TestAsyncDatabaseUtils:
    """Test async database utilities"""

    @patch("goaly_mcp.database_async.init_async_database")
    async def test_create_tables(self, mock_init):
        """Test table creation utility"""
        mock_init.return_value = None

        await AsyncDatabaseUtils.create_tables()

        mock_init.assert_called_once()

    @patch("goaly_mcp.database_async.get_async_engine")
    async def test_drop_tables(self, mock_get_engine):
        """Test table dropping utility"""
        mock_engine = Mock()  # Use Mock instead of AsyncMock for the engine
        mock_conn = AsyncMock()

        # Create a proper async context manager mock
        mock_context_manager = AsyncMock()
        mock_context_manager.__aenter__ = AsyncMock(return_value=mock_conn)
        mock_context_manager.__aexit__ = AsyncMock(return_value=None)

        # Mock engine.begin() to return the context manager (not a coroutine)
        mock_engine.begin.return_value = mock_context_manager
        mock_get_engine.return_value = mock_engine

        await AsyncDatabaseUtils.drop_tables()

        mock_conn.run_sync.assert_called_once()

    @patch("goaly_mcp.database_async.AsyncDatabaseUtils.drop_tables")
    @patch("goaly_mcp.database_async.AsyncDatabaseUtils.create_tables")
    async def test_reset_database(self, mock_create, mock_drop):
        """Test database reset utility"""
        await AsyncDatabaseUtils.reset_database()

        mock_drop.assert_called_once()
        mock_create.assert_called_once()

    @patch("goaly_mcp.database_async.get_async_db")
    async def test_check_connection_success(self, mock_get_db):
        """Test successful connection check"""
        mock_session = AsyncMock(spec=AsyncSession)
        mock_result = Mock()  # Use Mock instead of AsyncMock for the result
        mock_result.scalar = Mock(return_value=1)  # Use Mock for scalar method
        mock_session.execute = AsyncMock(return_value=mock_result)

        # Create a proper async context manager mock
        mock_context_manager = AsyncMock()
        mock_context_manager.__aenter__ = AsyncMock(return_value=mock_session)
        mock_context_manager.__aexit__ = AsyncMock(return_value=None)

        # Mock get_async_db() to return the context manager
        mock_get_db.return_value = mock_context_manager

        result = await AsyncDatabaseUtils.check_connection()

        assert result is True
        # Verify execute was called with a text() wrapped SELECT statement
        mock_session.execute.assert_called_once()
        call_args = mock_session.execute.call_args[0][0]
        assert str(call_args) == "SELECT 1"

    @patch("goaly_mcp.database_async.get_async_db")
    async def test_check_connection_failure(self, mock_get_db):
        """Test connection check failure"""
        mock_get_db.side_effect = Exception("Connection failed")

        result = await AsyncDatabaseUtils.check_connection()

        assert result is False


class TestAsyncDatabaseDocumentation:
    """Test that documentation and patterns are available"""

    def test_usage_patterns_exist(self):
        """Test that usage patterns documentation exists"""
        assert ASYNC_USAGE_PATTERNS is not None
        assert "Async Database Usage Patterns" in ASYNC_USAGE_PATTERNS
        assert "get_async_db" in ASYNC_USAGE_PATTERNS
        assert "managed_async_session" in ASYNC_USAGE_PATTERNS

    def test_usage_patterns_include_examples(self):
        """Test that usage patterns include code examples"""
        assert "```python" in ASYNC_USAGE_PATTERNS
        assert "AsyncSession" in ASYNC_USAGE_PATTERNS
        assert "FastAPI" in ASYNC_USAGE_PATTERNS


class TestAsyncDatabaseIntegration:
    """Integration tests for async database functionality"""

    def test_can_import_all_functions(self):
        """Test that all async database functions can be imported"""
        from goaly_mcp.database_async import (
            AsyncDatabaseUtils,
            close_async_database,
            convert_to_async_url,
            get_async_db,
            init_async_database,
            managed_async_session,
            validate_async_url,
        )

        # All imports successful
        assert convert_to_async_url is not None
        assert validate_async_url is not None
        assert get_async_db is not None
        assert managed_async_session is not None
        assert init_async_database is not None
        assert close_async_database is not None
        assert AsyncDatabaseUtils is not None

    def test_async_url_constants_defined(self):
        """Test that async URL constants are properly defined"""
        from goaly_mcp.database_async import ASYNC_DATABASE_URL

        assert ASYNC_DATABASE_URL is not None
        assert isinstance(ASYNC_DATABASE_URL, str)
        assert len(ASYNC_DATABASE_URL) > 0


if __name__ == "__main__":
    pytest.main([__file__])
