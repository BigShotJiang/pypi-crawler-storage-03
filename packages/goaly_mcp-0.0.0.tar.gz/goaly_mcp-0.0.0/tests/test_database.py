"""
Tests for database functionality - using test fixtures
"""

from sqlalchemy import text


def test_database_connection(test_engine):
    """Test that database connection works"""
    with test_engine.connect() as conn:
        result = conn.execute(text("SELECT 1"))
        assert result.scalar() == 1


def test_session_creation(test_session):
    """Test that database sessions can be created"""
    result = test_session.execute(text("SELECT 1"))
    assert result.scalar() == 1


def test_database_tables_exist(test_engine):
    """Test that required tables exist in database"""
    with test_engine.connect() as conn:
        result = conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'"))
        tables = [row[0] for row in result]

        # Core tables that should always exist
        expected_tables = ["goals", "tasks", "task_dependencies"]
        for table in expected_tables:
            assert table in tables, f"Table {table} not found in database"

        # alembic_version only exists if migrations have been run
        # In test environments, we create tables directly without migrations
