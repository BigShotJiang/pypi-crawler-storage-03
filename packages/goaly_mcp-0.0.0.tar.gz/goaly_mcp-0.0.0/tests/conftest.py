"""
Test configuration and fixtures for Goaly MCP testing framework.

This module provides comprehensive test fixtures for testing the Goaly MCP application,
including isolated database setup, repository fixtures, and test data factories.
"""

import contextlib
import os
import tempfile
import threading
import time
from collections.abc import Generator
from contextlib import contextmanager
from unittest.mock import patch

import pytest
from faker import Faker
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker

from goaly_mcp.models import Base, Goal, Task, TaskDependency, TaskStatus
from goaly_mcp.repositories.goals import GoalRepository
from goaly_mcp.repositories.tasks import TaskRepository

# Initialize Faker for test data generation
fake = Faker()


@pytest.fixture(scope="session")
def test_database_url() -> Generator[str, None, None]:
    """
    Create an in-memory SQLite database URL for testing.

    Uses a temporary file to ensure each test session gets a fresh database
    and proper isolation between test runs.

    Returns:
        str: SQLite database URL for testing
    """
    # Create a temporary file for the test database
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as temp_db:
        test_db_path = temp_db.name

    # Create the database URL
    database_url = f"sqlite:///{test_db_path}"

    yield database_url

    # Cleanup: Remove the temporary database file
    with contextlib.suppress(FileNotFoundError):
        os.unlink(test_db_path)


@pytest.fixture(scope="session")
def test_engine(test_database_url: str):
    """
    Create a test SQLAlchemy engine with the test database.

    Args:
        test_database_url: Database URL from test_database_url fixture

    Returns:
        Engine: SQLAlchemy engine configured for testing
    """
    engine = create_engine(
        test_database_url,
        echo=False,  # Set to True for SQL debugging
        connect_args={"check_same_thread": False},  # Allow SQLite to work with threads
    )

    # Run migrations instead of just creating tables
    from alembic import command
    from goaly_mcp.migrations.cli import get_alembic_config

    # Set DATABASE_URL environment variable for migrations
    old_database_url = os.environ.get("DATABASE_URL")
    os.environ["DATABASE_URL"] = test_database_url

    try:
        # Set up the test database with migrations
        alembic_cfg = get_alembic_config(test_database_url)
        command.upgrade(alembic_cfg, "head")
    finally:
        # Restore original DATABASE_URL
        if old_database_url is not None:
            os.environ["DATABASE_URL"] = old_database_url
        else:
            os.environ.pop("DATABASE_URL", None)

    yield engine

    # Cleanup: Drop all tables
    Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="session")
def test_session_factory(test_engine):
    """
    Create a session factory for the test database.

    Args:
        test_engine: SQLAlchemy engine from test_engine fixture

    Returns:
        sessionmaker: Session factory for creating test database sessions
    """
    return sessionmaker(bind=test_engine, autoflush=False, autocommit=False)


@pytest.fixture(scope="session", autouse=True)
def patch_database_session(test_session_factory):
    """
    Automatically patch the database SessionLocal for all tests.

    This ensures that all repository operations use the test database
    instead of the actual application database.

    Args:
        test_session_factory: Test database session factory
    """
    # Patch all possible import paths for SessionLocal to ensure complete isolation
    patches = [
        patch("goaly_mcp.database.SessionLocal", test_session_factory),
        patch("goaly_mcp.database_session.SessionLocal", test_session_factory),
        patch("goaly_mcp.repositories.goals.SessionLocal", test_session_factory),
        patch("goaly_mcp.repositories.tasks.SessionLocal", test_session_factory),
        patch("goaly_mcp.api.goals.SessionLocal", test_session_factory),
        patch("goaly_mcp.api.tasks.SessionLocal", test_session_factory),
        patch("goaly_mcp.mcp_tools.SessionLocal", test_session_factory),
    ]

    # Apply all patches in a context stack
    from contextlib import ExitStack

    with ExitStack() as stack:
        for patch_context in patches:
            with contextlib.suppress(ImportError, AttributeError):
                # Skip patches for modules that don't exist or don't have SessionLocal
                stack.enter_context(patch_context)
        yield


@pytest.fixture
def test_session(test_session_factory) -> Generator[Session, None, None]:
    """
    Create an isolated database session for each test.

    This fixture ensures complete isolation between tests by:
    1. Creating a fresh session for each test
    2. Rolling back all changes at the end of each test
    3. Cleaning up the session properly

    Args:
        test_session_factory: Session factory from test_session_factory fixture

    Yields:
        Session: Isolated SQLAlchemy session for testing
    """
    session = test_session_factory()

    try:
        yield session
    finally:
        # Rollback any changes and close the session
        session.rollback()
        session.close()


@pytest.fixture
def clean_database(test_session: Session) -> Generator[Session, None, None]:
    """
    Provide a clean database session with all data cleared before each test.

    This fixture ensures a pristine database state by clearing all tables
    in the correct order to respect foreign key constraints.

    Args:
        test_session: Database session from test_session fixture

    Yields:
        Session: Clean database session with no existing data
    """
    # Clean up all data in reverse dependency order
    test_session.execute(text("DELETE FROM task_dependencies"))
    test_session.execute(text("DELETE FROM tasks"))
    test_session.execute(text("DELETE FROM goals"))
    test_session.commit()

    yield test_session

    # Clean up after the test as well
    test_session.execute(text("DELETE FROM task_dependencies"))
    test_session.execute(text("DELETE FROM tasks"))
    test_session.execute(text("DELETE FROM goals"))
    test_session.commit()


@pytest.fixture
def goal_repo(clean_database: Session) -> GoalRepository:
    """
    Create a GoalRepository instance for testing.

    The repository will use the session decorators but the underlying
    session management is handled by the test fixtures.

    Args:
        clean_database: Clean database session

    Returns:
        GoalRepository: Repository instance for testing goal operations
    """
    return GoalRepository()


@pytest.fixture
def task_repo(clean_database: Session) -> TaskRepository:
    """
    Create a TaskRepository instance for testing.

    The repository will use the session decorators but the underlying
    session management is handled by the test fixtures.

    Args:
        clean_database: Clean database session

    Returns:
        TaskRepository: Repository instance for testing task operations
    """
    return TaskRepository()


@pytest.fixture
def sample_goal(clean_database: Session) -> Goal:
    """
    Create a sample goal for testing.

    Creates a basic goal with realistic test data that can be used
    across multiple test scenarios.

    Args:
        clean_database: Clean database session

    Returns:
        Goal: A sample goal instance persisted in the test database
    """
    goal = Goal(description="Complete the quarterly project deliverables", is_complete=False)

    clean_database.add(goal)
    clean_database.commit()
    clean_database.refresh(goal)

    return goal


@pytest.fixture
def sample_completed_goal(clean_database: Session) -> Goal:
    """
    Create a sample completed goal for testing.

    Creates a completed goal for testing scenarios that require
    goals in different completion states.

    Args:
        clean_database: Clean database session

    Returns:
        Goal: A completed goal instance persisted in the test database
    """
    goal = Goal(description="Review and approve last month's reports", is_complete=True)

    clean_database.add(goal)
    clean_database.commit()
    clean_database.refresh(goal)

    return goal


@pytest.fixture
def sample_task(clean_database: Session, sample_goal: Goal) -> Task:
    """
    Create a sample task for testing.

    Creates a basic task associated with the sample goal that can be used
    across multiple test scenarios.

    Args:
        clean_database: Clean database session
        sample_goal: Sample goal from sample_goal fixture

    Returns:
        Task: A sample task instance persisted in the test database
    """
    task = Task(
        goal_id=sample_goal.id,
        name="Research market trends and competitor analysis",
        instructions="Conduct comprehensive market research focusing on Q4 trends and key competitors",
        status=TaskStatus.AVAILABLE,
        owner=None,
    )

    clean_database.add(task)
    clean_database.commit()
    clean_database.refresh(task)

    return task


@pytest.fixture
def sample_owned_task(clean_database: Session, sample_goal: Goal) -> Task:
    """
    Create a sample owned task for testing.

    Creates a task that is owned by an agent for testing scenarios
    involving task ownership and status transitions.

    Args:
        clean_database: Clean database session
        sample_goal: Sample goal from sample_goal fixture

    Returns:
        Task: A sample owned task instance persisted in the test database
    """
    task = Task(
        goal_id=sample_goal.id,
        name="Draft project proposal document",
        instructions="Create detailed project proposal with timeline and budget",
        status=TaskStatus.OWNED,
        owner="agent-12345",
    )

    clean_database.add(task)
    clean_database.commit()
    clean_database.refresh(task)

    return task


@pytest.fixture
def sample_completed_task(clean_database: Session, sample_goal: Goal) -> Task:
    """
    Create a sample completed task for testing.

    Creates a completed task for testing scenarios involving
    completed tasks and dependency resolution.

    Args:
        clean_database: Clean database session
        sample_goal: Sample goal from sample_goal fixture

    Returns:
        Task: A sample completed task instance persisted in the test database
    """
    task = Task(
        goal_id=sample_goal.id,
        name="Setup development environment",
        instructions="Install required tools and configure development workspace",
        status=TaskStatus.COMPLETED,
        owner="agent-67890",
    )

    clean_database.add(task)
    clean_database.commit()
    clean_database.refresh(task)

    return task


class TestDataFactory:
    """
    Factory class for creating test data with realistic and varied content.

    This factory provides methods to create goals, tasks, and dependencies
    with proper relationships and realistic data for comprehensive testing.
    """

    def __init__(self, session: Session):
        """
        Initialize the test data factory.

        Args:
            session: Database session for creating test data
        """
        self.session = session

    def create_goal(self, description: str | None = None, is_complete: bool = False) -> Goal:
        """
        Create a goal with the specified or generated data.

        Args:
            description: Goal description (auto-generated if None)
            is_complete: Whether the goal is complete

        Returns:
            Goal: Created goal instance
        """
        if description is None:
            description = fake.sentence(nb_words=6).rstrip(".")

        goal = Goal(description=description, is_complete=is_complete)

        self.session.add(goal)
        self.session.commit()
        self.session.refresh(goal)

        return goal

    def create_task(
        self,
        goal: Goal,
        name: str | None = None,
        instructions: str | None = None,
        status: TaskStatus = TaskStatus.AVAILABLE,
        owner: str | None = None,
    ) -> Task:
        """
        Create a task with the specified or generated data.

        Args:
            goal: Goal to associate the task with
            name: Task name (auto-generated if None)
            instructions: Task instructions (auto-generated if None)
            status: Task status
            owner: Task owner (agent ID)

        Returns:
            Task: Created task instance
        """
        if name is None:
            name = fake.sentence(nb_words=4).rstrip(".")

        if instructions is None:
            instructions = fake.paragraph(nb_sentences=2)

        task = Task(goal_id=goal.id, name=name, instructions=instructions, status=status, owner=owner)

        self.session.add(task)
        self.session.commit()
        self.session.refresh(task)

        return task

    def create_task_dependency(
        self, dependent_task: Task, dependency_task: Task, required_data: str | None = None, is_blocked: bool = True
    ) -> TaskDependency:
        """
        Create a task dependency relationship.

        Args:
            dependent_task: Task that depends on another task
            dependency_task: Task that must be completed first
            required_data: Optional data requirements description
            is_blocked: Whether the dependency is currently blocking

        Returns:
            TaskDependency: Created task dependency instance
        """
        if required_data is None and fake.boolean(chance_of_getting_true=30):
            required_data = fake.sentence(nb_words=6)

        dependency = TaskDependency(
            dependent_task_id=dependent_task.id,
            dependency_task_id=dependency_task.id,
            required_data=required_data,
            is_blocked=is_blocked,
        )

        self.session.add(dependency)
        self.session.commit()
        self.session.refresh(dependency)

        return dependency

    def create_goal_with_tasks(
        self, goal_description: str | None = None, task_count: int = 3, completed_task_count: int = 0
    ) -> tuple[Goal, list[Task]]:
        """
        Create a goal with multiple associated tasks.

        Args:
            goal_description: Goal description (auto-generated if None)
            task_count: Total number of tasks to create
            completed_task_count: Number of tasks that should be completed

        Returns:
            tuple: (Goal instance, List of Task instances)
        """
        goal = self.create_goal(description=goal_description)
        tasks = []

        for i in range(task_count):
            if i < completed_task_count:
                status = TaskStatus.COMPLETED
                owner = f"agent-{fake.random_int(min=1000, max=9999)}"
            else:
                status = fake.random_element([TaskStatus.AVAILABLE, TaskStatus.OWNED, TaskStatus.BLOCKED])
                owner = f"agent-{fake.random_int(min=1000, max=9999)}" if status == TaskStatus.OWNED else None

            task = self.create_task(goal=goal, status=status, owner=owner)
            tasks.append(task)

        return goal, tasks

    def create_dependency_chain(self, goal: Goal, chain_length: int = 3) -> list[Task]:
        """
        Create a chain of tasks where each depends on the previous one.

        Args:
            goal: Goal to associate tasks with
            chain_length: Number of tasks in the dependency chain

        Returns:
            List[Task]: List of tasks in dependency order (first task has no dependencies)
        """
        tasks = []

        # Create all tasks first
        for i in range(chain_length):
            task = self.create_task(goal=goal, name=f"Step {i + 1}: {fake.sentence(nb_words=3).rstrip('.')}")
            tasks.append(task)

        # Create dependencies (each task depends on the previous one)
        for i in range(1, chain_length):
            self.create_task_dependency(dependent_task=tasks[i], dependency_task=tasks[i - 1])

        return tasks


@pytest.fixture
def test_data_factory(clean_database: Session) -> TestDataFactory:
    """
    Provide a TestDataFactory instance for creating test data.

    Args:
        clean_database: Clean database session

    Returns:
        TestDataFactory: Factory instance for creating test data
    """
    return TestDataFactory(clean_database)


@pytest.fixture
def multiple_goals(test_data_factory: TestDataFactory) -> list[Goal]:
    """
    Create multiple goals for testing list operations and filtering.

    Args:
        test_data_factory: Test data factory instance

    Returns:
        List[Goal]: List of goals with varying completion states
    """
    goals = []

    # Create a mix of completed and incomplete goals
    for i in range(5):
        is_complete = i < 2  # First 2 goals are complete
        goal = test_data_factory.create_goal(
            description=f"Test Goal {i + 1}: {fake.sentence(nb_words=4).rstrip('.')}", is_complete=is_complete
        )
        goals.append(goal)

    return goals


@pytest.fixture
def multiple_tasks_with_dependencies(test_data_factory: TestDataFactory, sample_goal: Goal) -> list[Task]:
    """
    Create multiple tasks with various dependency relationships.

    Args:
        test_data_factory: Test data factory instance
        sample_goal: Goal to associate tasks with

    Returns:
        List[Task]: List of tasks with complex dependency relationships
    """
    # Create a set of tasks with different statuses
    task1 = test_data_factory.create_task(goal=sample_goal, name="Foundation Task", status=TaskStatus.COMPLETED)

    task2 = test_data_factory.create_task(goal=sample_goal, name="Dependent Task A", status=TaskStatus.AVAILABLE)

    task3 = test_data_factory.create_task(goal=sample_goal, name="Dependent Task B", status=TaskStatus.BLOCKED)

    task4 = test_data_factory.create_task(goal=sample_goal, name="Final Task", status=TaskStatus.BLOCKED)

    # Create dependencies
    # task2 depends on task1 (should be unblocked since task1 is completed)
    test_data_factory.create_task_dependency(task2, task1)

    # task3 depends on task1 (should be unblocked since task1 is completed)
    test_data_factory.create_task_dependency(task3, task1)

    # task4 depends on both task2 and task3 (should remain blocked)
    test_data_factory.create_task_dependency(task4, task2)
    test_data_factory.create_task_dependency(task4, task3)

    return [task1, task2, task3, task4]


# Test database isolation verification fixture
@pytest.fixture
def verify_isolation(test_session: Session) -> Generator[None, None, None]:
    """
    Verify that database isolation is working correctly between tests.

    This fixture can be used to ensure that changes made in one test
    do not affect subsequent tests.

    Args:
        test_session: Database session for verification

    Yields:
        None: No return value, used for verification only
    """
    # Count initial records
    initial_goals = test_session.execute(text("SELECT COUNT(*) FROM goals")).scalar()
    initial_tasks = test_session.execute(text("SELECT COUNT(*) FROM tasks")).scalar()
    initial_deps = test_session.execute(text("SELECT COUNT(*) FROM task_dependencies")).scalar()

    yield

    # Verify database state after test (should be clean due to rollback)
    final_goals = test_session.execute(text("SELECT COUNT(*) FROM goals")).scalar()
    final_tasks = test_session.execute(text("SELECT COUNT(*) FROM tasks")).scalar()
    final_deps = test_session.execute(text("SELECT COUNT(*) FROM task_dependencies")).scalar()

    # Database should be restored to initial state due to session rollback
    assert final_goals == initial_goals, "Goal count changed - database isolation failed"
    assert final_tasks == initial_tasks, "Task count changed - database isolation failed"
    assert final_deps == initial_deps, "Dependency count changed - database isolation failed"


@contextmanager
def timeout_monitor(timeout_seconds: int = 30):
    """
    Context manager to monitor for test timeouts and deadlocks.

    Args:
        timeout_seconds: Maximum time to allow before warning
    """
    timeout_reached = threading.Event()

    def monitor():
        timeout_reached.wait(timeout_seconds)
        if not timeout_reached.is_set():
            import traceback

            print(f"\n⚠️  Test taking longer than {timeout_seconds}s - possible stall detected")
            print("Current thread stack traces:")
            for thread_id, frame in threading._current_frames().items():
                print(f"\nThread {thread_id}:")
                traceback.print_stack(frame)

    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()

    try:
        yield
    finally:
        timeout_reached.set()


@pytest.fixture(autouse=True)
def test_timeout_monitor():
    """Automatically monitor all tests for potential stalls."""
    with timeout_monitor(timeout_seconds=60):
        yield


@pytest.fixture
def isolated_test():
    """
    Ensure complete test isolation with enhanced monitoring.

    This fixture provides additional guarantees about test isolation
    and helps detect resource leaks or connection issues.
    """
    start_time = time.time()

    # Monitor for potential resource issues
    with timeout_monitor(timeout_seconds=30):
        yield

    end_time = time.time()
    duration = end_time - start_time

    # Log slow tests for investigation
    if duration > 10:
        print(f"\n⚠️  Slow test detected: {duration:.2f}s")


# Pytest configuration for test session
def pytest_configure(config):
    """Configure pytest with custom markers and settings."""
    config.addinivalue_line("markers", "integration: marks tests as integration tests (may run slower)")
    config.addinivalue_line("markers", "slow: marks tests as slow running tests")
    config.addinivalue_line("markers", "unit: marks tests as fast unit tests")
    config.addinivalue_line("markers", "timeout: marks tests with custom timeout requirements")


def pytest_collection_modifyitems(config, items):
    """Automatically mark tests based on their location and content."""
    for item in items:
        # Mark integration tests
        if "integration" in item.nodeid:
            item.add_marker(pytest.mark.integration)
            item.add_marker(pytest.mark.timeout(300))  # 5 minute timeout for integration tests

        # Mark performance tests as slow
        if "performance" in item.nodeid:
            item.add_marker(pytest.mark.slow)

        # Mark API tests as integration
        if "test_api" in item.nodeid:
            item.add_marker(pytest.mark.integration)
            item.add_marker(pytest.mark.timeout(120))  # 2 minute timeout for API tests
