"""
Tests for database models
"""

from goaly_mcp.models import Goal, Task, TaskDependency, TaskStatus


def test_goal_creation(clean_database):
    """Test creating a goal"""
    session = clean_database
    goal = Goal(description="Test goal")
    session.add(goal)
    session.commit()
    session.refresh(goal)

    assert goal.id is not None
    assert goal.description == "Test goal"
    assert goal.is_complete is False
    assert goal.created_at is not None
    assert goal.updated_at is not None


def test_task_creation(clean_database):
    """Test creating a task"""
    session = clean_database
    # Create a goal first
    goal = Goal(description="Test goal")
    session.add(goal)
    session.commit()
    session.refresh(goal)

    # Create a task
    task = Task(goal_id=goal.id, name="Test task", instructions="Test instructions", status=TaskStatus.AVAILABLE)
    session.add(task)
    session.commit()
    session.refresh(task)

    assert task.id is not None
    assert task.goal_id == goal.id
    assert task.name == "Test task"
    assert task.instructions == "Test instructions"
    assert task.status == TaskStatus.AVAILABLE
    assert task.owner is None


def test_task_dependency_creation(clean_database):
    """Test creating task dependencies"""
    session = clean_database
    # Create a goal
    goal = Goal(description="Test goal")
    session.add(goal)
    session.commit()
    session.refresh(goal)

    # Create two tasks
    task1 = Task(goal_id=goal.id, name="Task 1", status=TaskStatus.AVAILABLE)
    task2 = Task(goal_id=goal.id, name="Task 2", status=TaskStatus.AVAILABLE)
    session.add_all([task1, task2])
    session.commit()
    session.refresh(task1)
    session.refresh(task2)

    # Create dependency: task2 depends on task1
    dependency = TaskDependency(
        dependent_task_id=task2.id, dependency_task_id=task1.id, required_data="Test data", is_blocked=True
    )
    session.add(dependency)
    session.commit()
    session.refresh(dependency)

    assert dependency.id is not None
    assert dependency.dependent_task_id == task2.id
    assert dependency.dependency_task_id == task1.id
    assert dependency.required_data == "Test data"
    assert dependency.is_blocked is True


def test_task_status_enum():
    """Test TaskStatus enum values"""
    assert TaskStatus.BLOCKED.value == "blocked"
    assert TaskStatus.AVAILABLE.value == "available"
    assert TaskStatus.OWNED.value == "owned"
    assert TaskStatus.COMPLETED.value == "completed"
    assert TaskStatus.CANCELLED.value == "cancelled"
