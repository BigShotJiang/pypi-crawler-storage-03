"""
Tests for FastAPI application
"""

import pytest
from fastapi.testclient import TestClient

from goaly_mcp.test_app import create_test_app


@pytest.fixture
def client():
    """Create test client"""
    test_app = create_test_app()
    return TestClient(test_app)


def test_health_endpoint(client):
    """Test health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["service"] == "Goaly MCP Test"  # Test app has different service name


def test_root_endpoint(client):
    """Test root endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["service"] == "Goaly MCP Test"  # Test app has different service name
    assert "endpoints" in data
    assert "/api/v1/" in data["endpoints"]["api"]


def test_dashboard_endpoint(client):
    """Test dashboard endpoint (may be built or not)"""
    response = client.get("/dashboard")
    # Test app doesn't have dashboard endpoint, returns 404
    assert response.status_code == 404
