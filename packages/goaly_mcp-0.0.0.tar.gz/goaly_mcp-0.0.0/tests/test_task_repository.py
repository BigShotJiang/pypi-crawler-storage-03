"""
Test TaskRepository with session decorators.

Tests the refactored TaskRepository to ensure proper session management,
object detachment, and critical functionality like task dependency updates.
"""

import pytest

from goaly_mcp.models import TaskStatus
from goaly_mcp.repositories.goals import GoalRepository
from goaly_mcp.repositories.tasks import TaskRepository


class TestTaskRepository:
    """Test the refactored TaskRepository with session decorators."""

    def test_create_task(self, clean_database):
        """Test creating a task with @with_session decorator."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create a goal first
        goal = goal_repo.create("Test goal for task creation")

        # Create a task
        task = task_repo.create(
            goal_id=goal.id,
            name="Test task",
            instructions="Test task instructions",
            status=TaskStatus.AVAILABLE,
            owner=None,
        )

        # Verify task was created and is detached
        assert task is not None
        assert task.id is not None
        assert task.name == "Test task"
        assert task.instructions == "Test task instructions"
        assert task.status == TaskStatus.AVAILABLE
        assert task.goal_id == goal.id
        assert task.owner is None

        # Verify we can access attributes without session errors
        assert task.created_at is not None
        assert task.updated_at is not None

    def test_create_task_invalid_goal(self, clean_database):
        """Test creating a task with invalid goal ID raises ValueError."""
        task_repo = TaskRepository()

        with pytest.raises(ValueError, match="Goal with ID 99999 not found"):
            task_repo.create(goal_id=99999, name="Test task", instructions="Test instructions")

    def test_get_task_by_id(self, clean_database):
        """Test retrieving a task by ID with relationships loaded."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and task
        goal = goal_repo.create("Test goal for task retrieval")
        task = task_repo.create(goal_id=goal.id, name="Test task for retrieval", instructions="Test instructions")

        # Retrieve the task
        retrieved_task = task_repo.get_by_id(task.id)

        # Verify retrieval and detachment
        assert retrieved_task is not None
        assert retrieved_task.id == task.id
        assert retrieved_task.name == "Test task for retrieval"
        assert retrieved_task.instructions == "Test instructions"

        # Verify relationships are accessible (selectinload working)
        assert hasattr(retrieved_task, "dependencies")
        assert hasattr(retrieved_task, "dependents")
        assert hasattr(retrieved_task, "goal")
        assert retrieved_task.dependencies == []
        assert retrieved_task.dependents == []

    def test_get_task_by_id_nonexistent(self, clean_database):
        """Test retrieving a non-existent task returns None."""
        task_repo = TaskRepository()

        task = task_repo.get_by_id(99999)
        assert task is None

    def test_list_by_goal(self, clean_database):
        """Test listing all tasks for a goal with @with_session_list decorator."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and multiple tasks
        goal = goal_repo.create("Test goal for task listing")
        task_names = ["Task 1", "Task 2", "Task 3"]
        created_tasks = []

        for name in task_names:
            task = task_repo.create(goal_id=goal.id, name=name, instructions=f"Instructions for {name}")
            created_tasks.append(task)

        # List tasks by goal
        goal_tasks = task_repo.list_by_goal(goal.id)

        # Verify all tasks are returned and detached
        assert len(goal_tasks) == 3

        task_names_found = [t.name for t in goal_tasks]
        for name in task_names:
            assert name in task_names_found

        # Verify each task is detached and accessible
        for task in goal_tasks:
            assert task.name in task_names
            assert task.goal_id == goal.id
            assert task.created_at is not None
            assert hasattr(task, "dependencies")
            assert hasattr(task, "dependents")

    def test_search_tasks(self, clean_database):
        """Test searching tasks with various filters."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goals and tasks with different properties
        goal1 = goal_repo.create("Goal 1")
        goal2 = goal_repo.create("Goal 2")

        task_repo.create(goal_id=goal1.id, name="Task 1", owner="alice", status=TaskStatus.AVAILABLE)
        task_repo.create(goal_id=goal1.id, name="Task 2", owner="bob", status=TaskStatus.OWNED)
        task_repo.create(goal_id=goal2.id, name="Task 3", owner="alice", status=TaskStatus.COMPLETED)

        # Search by goal_id
        goal1_tasks = task_repo.search(goal_id=goal1.id)
        assert len(goal1_tasks) == 2
        assert all(t.goal_id == goal1.id for t in goal1_tasks)

        # Search by owner
        alice_tasks = task_repo.search(owner="alice")
        alice_task_names = [t.name for t in alice_tasks]
        assert "Task 1" in alice_task_names
        assert "Task 3" in alice_task_names

        # Search by status
        available_tasks = task_repo.search(status=TaskStatus.AVAILABLE.value)
        assert len(available_tasks) == 1
        assert available_tasks[0].name == "Task 1"

        # Search with multiple filters
        goal1_alice_tasks = task_repo.search(goal_id=goal1.id, owner="alice")
        assert len(goal1_alice_tasks) == 1
        assert goal1_alice_tasks[0].name == "Task 1"

    def test_search_invalid_status(self, clean_database):
        """Test searching with invalid status raises ValueError."""
        task_repo = TaskRepository()

        with pytest.raises(ValueError, match="Invalid status: invalid_status"):
            task_repo.search(status="invalid_status")

    def test_update_task(self, clean_database):
        """Test updating a task with @with_session decorator."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and task
        goal = goal_repo.create("Test goal for task update")
        task = task_repo.create(goal_id=goal.id, name="Original task", instructions="Original instructions")

        # Update the task
        updated_task = task_repo.update(
            task.id, name="Updated task name", instructions="Updated instructions", owner="alice"
        )

        # Verify update and detachment
        assert updated_task is not None
        assert updated_task.id == task.id
        assert updated_task.name == "Updated task name"
        assert updated_task.instructions == "Updated instructions"
        assert updated_task.owner == "alice"

        # Verify we can access attributes without session errors
        assert updated_task.created_at is not None
        assert updated_task.updated_at is not None

    def test_update_task_status_validation(self, clean_database):
        """Test task status update with validation."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and task
        goal = goal_repo.create("Test goal for status validation")
        task = task_repo.create(goal_id=goal.id, name="Task for status test")

        # Test valid status update with owner
        updated_task = task_repo.update(task.id, status=TaskStatus.OWNED, owner="alice")
        assert updated_task.status == TaskStatus.OWNED
        assert updated_task.owner == "alice"

        # Test status that requires owner without providing one
        task2 = task_repo.create(goal_id=goal.id, name="Task 2")
        with pytest.raises(ValueError, match="Owner is required for status"):
            task_repo.update(task2.id, status=TaskStatus.COMPLETED.value)

        # Test status that clears owner
        updated_task = task_repo.update(task.id, status=TaskStatus.AVAILABLE)
        assert updated_task.status == TaskStatus.AVAILABLE
        assert updated_task.owner is None

    def test_update_task_invalid_status(self, clean_database):
        """Test updating task with invalid status raises ValueError."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        goal = goal_repo.create("Test goal")
        task = task_repo.create(goal_id=goal.id, name="Test task")

        with pytest.raises(ValueError, match="Invalid status"):
            task_repo.update(task.id, status="invalid_status")

    def test_update_task_nonexistent(self, clean_database):
        """Test updating a non-existent task returns None."""
        task_repo = TaskRepository()

        result = task_repo.update(99999, name="New name")
        assert result is None

    def test_delete_task(self, clean_database):
        """Test deleting a task with @with_session_raw decorator."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and task
        goal = goal_repo.create("Test goal for task deletion")
        task = task_repo.create(goal_id=goal.id, name="Task to delete")

        # Delete the task
        deleted = task_repo.delete(task.id)

        # Verify deletion
        assert deleted is True

        # Verify task no longer exists
        retrieved_task = task_repo.get_by_id(task.id)
        assert retrieved_task is None

    def test_delete_task_nonexistent(self, clean_database):
        """Test deleting a non-existent task returns False."""
        task_repo = TaskRepository()

        deleted = task_repo.delete(99999)
        assert deleted is False

    def test_add_dependency(self, clean_database):
        """Test adding dependency between tasks."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and tasks
        goal = goal_repo.create("Test goal for dependencies")
        task1 = task_repo.create(goal_id=goal.id, name="Task 1 (dependency)")
        task2 = task_repo.create(goal_id=goal.id, name="Task 2 (dependent)")

        # Add dependency
        dependency = task_repo.add_dependency(
            dependent_task_id=task2.id, dependency_task_id=task1.id, required_data="Test data required"
        )

        # Verify dependency creation and detachment
        assert dependency is not None
        assert dependency.dependent_task_id == task2.id
        assert dependency.dependency_task_id == task1.id
        assert dependency.required_data == "Test data required"
        assert dependency.is_blocked is True  # task1 is not completed

        # Verify we can access attributes without session errors
        assert dependency.created_at is not None

    def test_add_dependency_tasks_not_found(self, clean_database):
        """Test adding dependency with non-existent tasks raises ValueError."""
        task_repo = TaskRepository()

        with pytest.raises(ValueError, match="One or both tasks not found"):
            task_repo.add_dependency(dependent_task_id=99999, dependency_task_id=99998)

    def test_add_dependency_different_goals(self, clean_database):
        """Test adding dependency between tasks in different goals raises ValueError."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create two goals with one task each
        goal1 = goal_repo.create("Goal 1")
        goal2 = goal_repo.create("Goal 2")
        task1 = task_repo.create(goal_id=goal1.id, name="Task 1")
        task2 = task_repo.create(goal_id=goal2.id, name="Task 2")

        with pytest.raises(ValueError, match="Tasks must be in the same goal"):
            task_repo.add_dependency(dependent_task_id=task2.id, dependency_task_id=task1.id)

    def test_add_dependency_already_exists(self, clean_database):
        """Test adding duplicate dependency raises ValueError."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and tasks
        goal = goal_repo.create("Test goal")
        task1 = task_repo.create(goal_id=goal.id, name="Task 1")
        task2 = task_repo.create(goal_id=goal.id, name="Task 2")

        # Add dependency first time
        task_repo.add_dependency(dependent_task_id=task2.id, dependency_task_id=task1.id)

        # Try to add same dependency again
        with pytest.raises(ValueError, match="Dependency already exists"):
            task_repo.add_dependency(dependent_task_id=task2.id, dependency_task_id=task1.id)

    def test_update_task_blocking_status(self, clean_database):
        """Test the _update_task_blocking_status method via task status update."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal and tasks
        goal = goal_repo.create("Test goal for blocking status")
        dependency_task = task_repo.create(goal_id=goal.id, name="Dependency task")
        dependent_task = task_repo.create(goal_id=goal.id, name="Dependent task")

        # Add dependency
        task_repo.add_dependency(dependent_task_id=dependent_task.id, dependency_task_id=dependency_task.id)

        # Complete the dependency task (this should update blocking status)
        updated_dependency = task_repo.update(dependency_task.id, status=TaskStatus.COMPLETED, owner="alice")

        # Verify the dependency task was updated
        assert updated_dependency.status == TaskStatus.COMPLETED

        # Verify the blocking status was updated by checking the dependency
        # Note: We'd need to query TaskDependency directly to verify this fully
        # For now, we verify that the update method completed without error
        assert updated_dependency is not None

    def test_full_crud_cycle_with_dependencies(self, clean_database):
        """Test complete CRUD cycle including dependency management."""
        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create goal
        goal = goal_repo.create("CRUD test goal")

        # Create tasks
        task1 = task_repo.create(goal_id=goal.id, name="Task 1", instructions="First task")
        task2 = task_repo.create(goal_id=goal.id, name="Task 2", instructions="Second task")

        # Read single tasks
        retrieved_task1 = task_repo.get_by_id(task1.id)
        retrieved_task2 = task_repo.get_by_id(task2.id)
        assert retrieved_task1.name == "Task 1"
        assert retrieved_task2.name == "Task 2"

        # Read task list
        goal_tasks = task_repo.list_by_goal(goal.id)
        assert len(goal_tasks) == 2

        # Search tasks
        search_results = task_repo.search(goal_id=goal.id)
        assert len(search_results) == 2

        # Add dependency
        dependency = task_repo.add_dependency(dependent_task_id=task2.id, dependency_task_id=task1.id)
        assert dependency is not None

        # Update tasks
        updated_task1 = task_repo.update(task1.id, status=TaskStatus.COMPLETED, owner="alice")
        assert updated_task1.status == TaskStatus.COMPLETED

        updated_task2 = task_repo.update(task2.id, name="Updated Task 2")
        assert updated_task2.name == "Updated Task 2"

        # Delete tasks (delete dependent task first to avoid FK constraint issues)
        deleted2 = task_repo.delete(task2.id)  # Delete dependent task first
        deleted1 = task_repo.delete(task1.id)  # Then delete dependency task
        assert deleted2 is True
        assert deleted1 is True

        # Verify deletions
        assert task_repo.get_by_id(task1.id) is None
        assert task_repo.get_by_id(task2.id) is None
