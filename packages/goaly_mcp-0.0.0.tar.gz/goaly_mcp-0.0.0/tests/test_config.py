"""
Tests for configuration
"""

from goaly_mcp.config import Settings


def test_default_settings():
    """Test default configuration values"""
    # Create settings without loading from .env to test defaults
    import os

    old_env = os.environ.copy()
    # Clear any GOALY_ env vars for this test
    for key in list(os.environ.keys()):
        if key.startswith("GOALY_"):
            del os.environ[key]

    try:
        settings = Settings()

        assert settings.app_name == "Goaly MCP"
        assert settings.app_version == "0.0.0"
        # Note: debug might be True from .env file, so we'll test it exists
        assert isinstance(settings.debug, bool)
        assert settings.host == "127.0.0.1"  # Default to localhost for security
        assert settings.port == 8000
        assert settings.auth_enabled is False
        assert isinstance(settings.cors_origins, list)
        assert len(settings.cors_origins) > 0
    finally:
        # Restore environment
        os.environ.clear()
        os.environ.update(old_env)


def test_settings_cors_origins():
    """Test CORS origins configuration"""
    settings = Settings()

    expected_origins = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
    ]

    for origin in expected_origins:
        assert origin in settings.cors_origins
