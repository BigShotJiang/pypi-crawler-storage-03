"""
Comprehensive test suite for all 11 prompt commands.

Tests that all prompts can load their .txt files correctly and work
both in development mode and from an installed wheel.
"""

import asyncio
import sys
from pathlib import Path
from typing import ClassVar

# Add src to path for development testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from goaly_mcp.prompts.commands import _load_prompt
from goaly_mcp.prompts.simple_template import render_template_from_string


class TestAllPrompts:
    """Test suite for all 11 prompt commands."""

    # List of all expected prompt commands and their corresponding .txt files
    EXPECTED_PROMPTS: ClassVar[list[str]] = [
        "manage_goals",
        "manage_tasks",
        "setup",
        "plan",
        "breakdown",
        "generate",
        "work",
        "status",
        "analyze",
        "verify",
        "enhance",
    ]

    def test_all_prompt_files_exist(self):
        """Test that all 11 prompt .txt files exist and can be loaded."""
        results = {}

        for prompt_name in self.EXPECTED_PROMPTS:
            filename = f"{prompt_name}.txt"
            try:
                content = _load_prompt(filename)
                results[prompt_name] = {
                    "loaded": True,
                    "content_length": len(content),
                    "has_content": bool(content.strip()),
                    "error": None,
                }
                print(f"✅ {prompt_name}: Loaded {len(content)} characters")
            except Exception as e:
                results[prompt_name] = {"loaded": False, "content_length": 0, "has_content": False, "error": str(e)}
                print(f"❌ {prompt_name}: Failed to load - {e}")

        # Assert all prompts loaded successfully
        failed_prompts = [name for name, result in results.items() if not result["loaded"]]
        if failed_prompts:
            raise AssertionError(f"Failed to load prompts: {failed_prompts}")

        # Assert all prompts have content
        empty_prompts = [name for name, result in results.items() if not result["has_content"]]
        if empty_prompts:
            raise AssertionError(f"Empty prompt files: {empty_prompts}")

    def test_prompt_content_quality(self):
        """Test that all prompt files contain meaningful content."""
        content_results = {}

        for prompt_name in self.EXPECTED_PROMPTS:
            filename = f"{prompt_name}.txt"
            content = _load_prompt(filename)

            # Check content quality metrics
            content_results[prompt_name] = {
                "length": len(content),
                "lines": len(content.splitlines()),
                "words": len(content.split()),
                "has_user_input_placeholder": "{user_input}" in content,
                "min_length_ok": len(content.strip()) >= 50,  # At least 50 chars
                "has_instructions": any(
                    word in content.lower() for word in ["you", "task", "goal", "analyze", "create", "list", "update"]
                ),
            }

            print(
                f"📊 {prompt_name}: {content_results[prompt_name]['length']} chars, "
                f"{content_results[prompt_name]['lines']} lines, "
                f"{content_results[prompt_name]['words']} words"
            )

        # Assert all prompts meet quality criteria
        for prompt_name, metrics in content_results.items():
            if not metrics["min_length_ok"]:
                raise AssertionError(f"{prompt_name} is too short ({metrics['length']} chars)")
            if not metrics["has_user_input_placeholder"]:
                raise AssertionError(f"{prompt_name} missing {{user_input}} placeholder")
            if not metrics["has_instructions"]:
                raise AssertionError(f"{prompt_name} doesn't appear to contain instructions")

    def test_template_rendering(self):
        """Test that all prompts can be rendered with template variables."""
        test_user_input = "Test user input for template rendering"

        for prompt_name in self.EXPECTED_PROMPTS:
            filename = f"{prompt_name}.txt"
            content = _load_prompt(filename)

            try:
                rendered = render_template_from_string(content, user_input=test_user_input)

                # Verify rendering worked
                if len(rendered) == 0:
                    raise AssertionError(f"{prompt_name} rendered to empty string")
                if test_user_input not in rendered:
                    raise AssertionError(f"{prompt_name} didn't include user input in rendered output")
                if "{user_input}" in rendered:
                    raise AssertionError(f"{prompt_name} still has unresolved template variables")

                print(f"✅ {prompt_name}: Template rendered successfully ({len(rendered)} chars)")

            except Exception as e:
                raise AssertionError(f"Template rendering failed for {prompt_name}: {e}")

    def test_prompt_registration_simulation(self):
        """Test that prompt registration would work (without actually registering)."""
        # We can't easily test the actual FastMCP registration without a server instance,
        # but we can test that the prompt loading functions work correctly

        from unittest.mock import Mock

        # Mock FastMCP server
        mock_server = Mock()
        mock_server.prompt = Mock(return_value=lambda func: func)

        # Test that all prompt functions would work
        prompt_functions = {}

        for prompt_name in self.EXPECTED_PROMPTS:
            filename = f"{prompt_name}.txt"

            # Simulate the prompt function logic
            def make_prompt_func(fname):
                async def prompt_func(user_input: str) -> str:
                    prompt_content = _load_prompt(fname)
                    return render_template_from_string(prompt_content, user_input=user_input)

                return prompt_func

            prompt_functions[prompt_name] = make_prompt_func(filename)

        # Test calling each prompt function
        async def test_all_async():
            test_input = "Test input for registration simulation"
            results = {}

            for prompt_name, func in prompt_functions.items():
                try:
                    result = await func(test_input)
                    results[prompt_name] = {
                        "success": True,
                        "result_length": len(result),
                        "has_input": test_input in result,
                    }
                    print(f"✅ {prompt_name}: Function works ({len(result)} chars)")
                except Exception as e:
                    results[prompt_name] = {"success": False, "error": str(e)}
                    print(f"❌ {prompt_name}: Function failed - {e}")

            return results

        # Run the async test
        results = asyncio.run(test_all_async())

        # Assert all functions worked
        failed_funcs = [name for name, result in results.items() if not result["success"]]
        if failed_funcs:
            raise AssertionError(f"Prompt functions failed: {failed_funcs}")

    def test_prompt_consistency(self):
        """Test consistency across all prompts."""
        prompt_data = {}

        for prompt_name in self.EXPECTED_PROMPTS:
            filename = f"{prompt_name}.txt"
            content = _load_prompt(filename)

            prompt_data[prompt_name] = {
                "has_you_directive": content.lower().count("you ") > 0,
                "has_task_mention": "task" in content.lower(),
                "has_goal_mention": "goal" in content.lower(),
                "template_vars": content.count("{") == content.count("}"),
                "reasonable_length": 100 <= len(content) <= 5000,
            }

        # Check for consistency issues
        consistency_issues = []

        for prompt_name, data in prompt_data.items():
            if not data["template_vars"]:
                consistency_issues.append(f"{prompt_name}: Unmatched template braces")
            if not data["reasonable_length"]:
                consistency_issues.append(
                    f"{prompt_name}: Unreasonable length ({len(_load_prompt(f'{prompt_name}.txt'))} chars)"
                )

        if consistency_issues:
            raise AssertionError(f"Consistency issues found: {consistency_issues}")

    def test_sample_prompt_content(self):
        """Test a sample of actual prompt content to ensure it's reasonable."""
        # Test a few key prompts to ensure they contain expected content

        # Test manage_goals prompt
        manage_goals_content = _load_prompt("manage_goals.txt")
        if "goal" not in manage_goals_content.lower():
            raise AssertionError("manage_goals prompt doesn't contain 'goal'")
        if "create" not in manage_goals_content.lower() and "add" not in manage_goals_content.lower():
            raise AssertionError("manage_goals prompt doesn't contain 'create' or 'add'")

        # Test manage_tasks prompt
        manage_tasks_content = _load_prompt("manage_tasks.txt")
        if "task" not in manage_tasks_content.lower():
            raise AssertionError("manage_tasks prompt doesn't contain 'task'")

        # Test setup prompt
        setup_content = _load_prompt("setup.txt")
        if "setup" not in setup_content.lower() and "initialize" not in setup_content.lower():
            raise AssertionError("setup prompt doesn't contain 'setup' or 'initialize'")

        # Test work prompt
        work_content = _load_prompt("work.txt")
        if "work" not in work_content.lower() and "available" not in work_content.lower():
            raise AssertionError("work prompt doesn't contain 'work' or 'available'")

        print("✅ Sample prompt content validation passed")


def test_prompt_loading_integration():
    """Integration test for the complete prompt loading system."""
    print("\n" + "=" * 60)
    print("RUNNING COMPREHENSIVE PROMPT LOADING TESTS")
    print("=" * 60)

    test_suite = TestAllPrompts()

    print("\n1. Testing prompt file existence and loading...")
    test_suite.test_all_prompt_files_exist()

    print("\n2. Testing prompt content quality...")
    test_suite.test_prompt_content_quality()

    print("\n3. Testing template rendering...")
    test_suite.test_template_rendering()

    print("\n4. Testing prompt registration simulation...")
    test_suite.test_prompt_registration_simulation()

    print("\n5. Testing prompt consistency...")
    test_suite.test_prompt_consistency()

    print("\n6. Testing sample prompt content...")
    test_suite.test_sample_prompt_content()

    print("\n" + "=" * 60)
    print("✅ ALL PROMPT TESTS PASSED!")
    print("✅ All 11 prompts are working correctly")
    print("=" * 60)


if __name__ == "__main__":
    # Run the integration test directly
    test_prompt_loading_integration()
