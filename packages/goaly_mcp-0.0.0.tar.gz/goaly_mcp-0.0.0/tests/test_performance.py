"""
Performance tests for TaskMaster MCP.

This module tests the performance characteristics of the TaskMaster MCP application,
including batch operations, scalability, and concurrent access patterns.
"""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import pytest

from goaly_mcp.models import Goal, TaskStatus
from goaly_mcp.repositories.goals import GoalRepository
from goaly_mcp.repositories.tasks import TaskRepository


class TestBatchOperationPerformance:
    """Test performance of batch operations."""

    @pytest.mark.slow
    def test_batch_goal_creation_performance(self, clean_database):
        """Test batch goal creation performance (100 goals < 5s)."""
        goal_repo = GoalRepository()

        # Test creating 100 goals
        goal_count = 100
        start_time = time.time()

        created_goals = []
        for i in range(goal_count):
            goal = goal_repo.create(f"Performance test goal {i + 1}")
            created_goals.append(goal)

        end_time = time.time()
        elapsed_time = end_time - start_time

        # Should complete in less than 5 seconds
        assert elapsed_time < 5.0, f"Goal creation took {elapsed_time:.2f}s, should be < 5s"

        # Verify all goals were created
        assert len(created_goals) == goal_count

        # Verify goals are accessible
        for goal in created_goals[:10]:  # Check first 10
            assert goal.id is not None
            assert "Performance test goal" in goal.description

        print(f"Created {goal_count} goals in {elapsed_time:.2f}s ({goal_count / elapsed_time:.1f} goals/sec)")

    @pytest.mark.slow
    def test_batch_task_creation_performance(self, clean_database, test_data_factory):
        """Test batch task creation performance (200 tasks + searches)."""
        task_repo = TaskRepository()

        # Create a goal first
        goal = test_data_factory.create_goal("Performance test goal for tasks")

        # Test creating 200 tasks
        task_count = 200
        start_time = time.time()

        created_tasks = []
        for i in range(task_count):
            task = task_repo.create(
                goal_id=goal.id,
                name=f"Performance task {i + 1}",
                instructions=f"Instructions for performance task {i + 1}",
            )
            created_tasks.append(task)

        creation_time = time.time() - start_time

        # Test searching through the tasks
        search_start = time.time()

        # Perform various searches
        all_tasks = task_repo.search(goal_id=goal.id)
        available_tasks = task_repo.search(goal_id=goal.id, status=TaskStatus.AVAILABLE)

        search_time = time.time() - search_start
        time.time() - start_time

        # Should complete creation + searches efficiently
        assert creation_time < 10.0, f"Task creation took {creation_time:.2f}s, should be < 10s"
        assert search_time < 2.0, f"Task searches took {search_time:.2f}s, should be < 2s"

        # Verify results
        assert len(created_tasks) == task_count
        assert len(all_tasks) >= task_count
        assert len(available_tasks) >= task_count

        print(f"Created {task_count} tasks in {creation_time:.2f}s ({task_count / creation_time:.1f} tasks/sec)")
        print(f"Searched tasks in {search_time:.2f}s")

    @pytest.mark.slow
    def test_batch_goal_retrieval_performance(self, clean_database, test_data_factory):
        """Test batch goal retrieval performance."""
        goal_repo = GoalRepository()

        # Create 50 goals first
        goal_count = 50
        created_goals = []

        for i in range(goal_count):
            goal = test_data_factory.create_goal(
                description=f"Retrieval test goal {i + 1}",
                is_complete=(i % 3 == 0),  # Every 3rd goal is complete
            )
            created_goals.append(goal)

        # Test retrieving all goals
        start_time = time.time()
        all_goals = goal_repo.list_all()
        all_goals_time = time.time() - start_time

        # Test filtered retrievals
        start_time = time.time()
        completed_goals = goal_repo.list_all(completed_only=True)
        completed_time = time.time() - start_time

        start_time = time.time()
        incomplete_goals = goal_repo.list_all(incomplete_only=True)
        incomplete_time = time.time() - start_time

        # Should be fast
        assert all_goals_time < 1.0, f"List all goals took {all_goals_time:.2f}s, should be < 1s"
        assert completed_time < 1.0, f"List completed goals took {completed_time:.2f}s, should be < 1s"
        assert incomplete_time < 1.0, f"List incomplete goals took {incomplete_time:.2f}s, should be < 1s"

        # Verify results
        assert len(all_goals) >= goal_count
        assert len(completed_goals) >= goal_count // 3  # Approximately 1/3 complete
        assert len(incomplete_goals) >= (goal_count * 2) // 3  # Approximately 2/3 incomplete

        print(f"Retrieved {len(all_goals)} goals in {all_goals_time:.3f}s")
        print(f"Filtered {len(completed_goals)} completed goals in {completed_time:.3f}s")


class TestDependencyGraphPerformance:
    """Test performance with complex dependency structures."""

    @pytest.mark.slow
    def test_dependency_chain_performance(self, clean_database, test_data_factory):
        """Test dependency graph performance (50 tasks with dependencies)."""
        task_repo = TaskRepository()

        # Create goal and tasks
        goal = test_data_factory.create_goal("Dependency chain performance test")

        # Create a chain of 50 dependent tasks
        chain_length = 50
        start_time = time.time()

        # Create all tasks first
        tasks = []
        for i in range(chain_length):
            task = test_data_factory.create_task(goal=goal, name=f"Chain task {i + 1}", status=TaskStatus.AVAILABLE)
            tasks.append(task)

        # Create dependencies (each task depends on previous)
        for i in range(1, chain_length):
            task_repo.add_dependency(dependent_task_id=tasks[i].id, dependency_task_id=tasks[i - 1].id)

        creation_time = time.time() - start_time

        # Test operations on the dependency chain
        search_start = time.time()

        # Search for tasks in the goal
        goal_tasks = task_repo.search(goal_id=goal.id)

        search_time = time.time() - search_start
        time.time() - start_time

        # Should handle dependency chain efficiently
        assert creation_time < 15.0, f"Dependency chain creation took {creation_time:.2f}s, should be < 15s"
        assert search_time < 2.0, f"Task search took {search_time:.2f}s, should be < 2s"

        # Verify dependency chain was created
        assert len(goal_tasks) >= chain_length

        print(f"Created {chain_length}-task dependency chain in {creation_time:.2f}s")
        print(f"Searched {len(goal_tasks)} tasks in {search_time:.3f}s")

    @pytest.mark.slow
    def test_complex_dependency_graph_performance(self, clean_database, test_data_factory):
        """Test performance with complex dependency graph."""
        task_repo = TaskRepository()

        # Create goal
        goal = test_data_factory.create_goal("Complex dependency graph test")

        # Create a more complex dependency structure
        # Foundation tasks (no dependencies)
        foundation_tasks = []
        for i in range(5):
            task = test_data_factory.create_task(goal=goal, name=f"Foundation {i + 1}", status=TaskStatus.AVAILABLE)
            foundation_tasks.append(task)

        # Middle layer tasks (depend on foundations)
        middle_tasks = []
        for i in range(10):
            task = test_data_factory.create_task(goal=goal, name=f"Middle {i + 1}", status=TaskStatus.BLOCKED)
            middle_tasks.append(task)

        # Final layer tasks (depend on middle)
        final_tasks = []
        for i in range(8):
            task = test_data_factory.create_task(goal=goal, name=f"Final {i + 1}", status=TaskStatus.BLOCKED)
            final_tasks.append(task)

        start_time = time.time()

        # Create dependencies: middle tasks depend on foundation tasks
        for middle_task in middle_tasks:
            # Each middle task depends on 1-2 foundation tasks
            foundation_deps = foundation_tasks[:2]  # First 2 foundations
            for foundation_task in foundation_deps:
                task_repo.add_dependency(middle_task.id, foundation_task.id)

        # Create dependencies: final tasks depend on middle tasks
        for final_task in final_tasks:
            # Each final task depends on 2-3 middle tasks
            middle_deps = middle_tasks[:3]  # First 3 middle tasks
            for middle_task in middle_deps:
                task_repo.add_dependency(final_task.id, middle_task.id)

        dependency_time = time.time() - start_time

        # Test searching with complex dependencies
        search_start = time.time()
        all_tasks = task_repo.search(goal_id=goal.id)
        search_time = time.time() - search_start

        time.time() - start_time

        # Should handle complex graph efficiently
        assert dependency_time < 10.0, f"Complex dependency creation took {dependency_time:.2f}s, should be < 10s"
        assert search_time < 2.0, f"Complex graph search took {search_time:.2f}s, should be < 2s"

        # Verify graph structure
        total_expected_tasks = len(foundation_tasks) + len(middle_tasks) + len(final_tasks)
        assert len(all_tasks) >= total_expected_tasks

        print(f"Created complex dependency graph ({total_expected_tasks} tasks) in {dependency_time:.2f}s")
        print(f"Searched complex graph in {search_time:.3f}s")


class TestConcurrentOperationPerformance:
    """Test performance under concurrent access."""

    @pytest.mark.slow
    def test_concurrent_goal_creation(self, clean_database):
        """Test concurrent goal creation performance."""

        def create_goals_batch(batch_id: int, batch_size: int) -> list[Goal]:
            """Create a batch of goals in a thread."""
            goal_repo = GoalRepository()
            goals = []

            for i in range(batch_size):
                goal = goal_repo.create(f"Concurrent goal {batch_id}-{i + 1}")
                goals.append(goal)

            return goals

        # Test with multiple threads
        num_threads = 4
        goals_per_thread = 25

        start_time = time.time()

        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            # Submit tasks
            futures = []
            for thread_id in range(num_threads):
                future = executor.submit(create_goals_batch, thread_id, goals_per_thread)
                futures.append(future)

            # Collect results
            all_created_goals = []
            for future in as_completed(futures):
                batch_goals = future.result()
                all_created_goals.extend(batch_goals)

        elapsed_time = time.time() - start_time
        total_goals = num_threads * goals_per_thread

        # Should complete efficiently even with concurrent access
        assert elapsed_time < 8.0, f"Concurrent goal creation took {elapsed_time:.2f}s, should be < 8s"
        assert len(all_created_goals) == total_goals

        # Verify goals were created correctly
        for goal in all_created_goals[:10]:  # Check first 10
            assert goal.id is not None
            assert "Concurrent goal" in goal.description

        print(f"Created {total_goals} goals concurrently ({num_threads} threads) in {elapsed_time:.2f}s")
        print(f"Throughput: {total_goals / elapsed_time:.1f} goals/sec")

    @pytest.mark.slow
    def test_concurrent_task_operations(self, clean_database, test_data_factory):
        """Test concurrent task operations performance."""
        # Create a shared goal
        shared_goal = test_data_factory.create_goal("Shared goal for concurrent tasks")

        def task_operations_batch(batch_id: int, goal_id: int) -> dict:
            """Perform a batch of task operations in a thread."""
            task_repo = TaskRepository()
            results = {"created": 0, "updated": 0, "searched": 0}

            # Create tasks
            created_tasks = []
            for i in range(10):
                task = task_repo.create(
                    goal_id=goal_id,
                    name=f"Concurrent task {batch_id}-{i + 1}",
                    instructions=f"Instructions for task {batch_id}-{i + 1}",
                )
                created_tasks.append(task)
                results["created"] += 1

            # Update some tasks
            for task in created_tasks[:5]:  # Update first 5
                task_repo.update(task.id, status=TaskStatus.OWNED, owner=f"agent-{batch_id}")
                results["updated"] += 1

            # Search tasks
            search_results = task_repo.search(goal_id=goal_id)
            results["searched"] = len(search_results)

            return results

        # Test with multiple threads
        num_threads = 3

        start_time = time.time()

        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            # Submit tasks
            futures = []
            for thread_id in range(num_threads):
                future = executor.submit(task_operations_batch, thread_id, shared_goal.id)
                futures.append(future)

            # Collect results
            all_results = []
            for future in as_completed(futures):
                batch_results = future.result()
                all_results.append(batch_results)

        elapsed_time = time.time() - start_time

        # Should complete efficiently
        assert elapsed_time < 10.0, f"Concurrent task operations took {elapsed_time:.2f}s, should be < 10s"

        # Verify operations
        total_created = sum(r["created"] for r in all_results)
        total_updated = sum(r["updated"] for r in all_results)

        assert total_created == num_threads * 10  # 10 tasks per thread
        assert total_updated == num_threads * 5  # 5 updates per thread

        print(f"Concurrent task operations ({num_threads} threads) completed in {elapsed_time:.2f}s")
        print(f"Created {total_created} tasks, updated {total_updated} tasks")


class TestLargeDatasetPerformance:
    """Test performance with large datasets."""

    @pytest.mark.slow
    def test_large_dataset_goal_operations(self, clean_database):
        """Test performance with large goal dataset (1000+ goals)."""
        goal_repo = GoalRepository()

        # Create 1000 goals
        large_dataset_size = 1000

        print(f"Creating {large_dataset_size} goals for large dataset test...")
        start_time = time.time()

        created_goals = []
        for i in range(large_dataset_size):
            is_complete = i % 5 == 0  # Every 5th goal is complete
            goal = goal_repo.create(f"Large dataset goal {i + 1}")

            if is_complete:
                goal_repo.update(goal.id, is_complete=True)

            created_goals.append(goal)

            # Progress indicator
            if (i + 1) % 200 == 0:
                print(f"Created {i + 1}/{large_dataset_size} goals...")

        creation_time = time.time() - start_time

        # Test operations on large dataset
        print("Testing operations on large dataset...")

        # Test listing all goals
        list_start = time.time()
        all_goals = goal_repo.list_all()
        list_time = time.time() - list_start

        # Test filtered listing
        filter_start = time.time()
        completed_goals = goal_repo.list_all(completed_only=True)
        filter_time = time.time() - filter_start

        # Test individual retrieval (sample)
        retrieval_start = time.time()
        for goal in created_goals[:100]:  # Sample 100 goals
            retrieved = goal_repo.get_by_id(goal.id)
            assert retrieved is not None
        retrieval_time = time.time() - retrieval_start

        # Performance assertions
        assert creation_time < 60.0, f"Large dataset creation took {creation_time:.2f}s, should be < 60s"
        assert list_time < 5.0, f"Large dataset listing took {list_time:.2f}s, should be < 5s"
        assert filter_time < 5.0, f"Large dataset filtering took {filter_time:.2f}s, should be < 5s"
        assert retrieval_time < 2.0, f"Sample retrievals took {retrieval_time:.2f}s, should be < 2s"

        # Verify results
        assert len(all_goals) >= large_dataset_size
        assert len(completed_goals) >= large_dataset_size // 5  # Approximately 1/5 complete

        print("Large dataset performance results:")
        print(
            f"  Created {large_dataset_size} goals in {creation_time:.2f}s ({large_dataset_size / creation_time:.1f} goals/sec)"
        )
        print(f"  Listed {len(all_goals)} goals in {list_time:.3f}s")
        print(f"  Filtered {len(completed_goals)} goals in {filter_time:.3f}s")
        print(f"  Retrieved 100 samples in {retrieval_time:.3f}s")

    @pytest.mark.slow
    def test_large_task_dataset_search_performance(self, clean_database, test_data_factory):
        """Test search performance with large task dataset."""
        task_repo = TaskRepository()

        # Create multiple goals
        goals = []
        for i in range(5):
            goal = test_data_factory.create_goal(f"Goal {i + 1} for large task dataset")
            goals.append(goal)

        # Create many tasks across the goals
        large_task_count = 500

        print(f"Creating {large_task_count} tasks for search performance test...")
        start_time = time.time()

        created_tasks = []
        statuses = [TaskStatus.AVAILABLE, TaskStatus.OWNED, TaskStatus.COMPLETED, TaskStatus.BLOCKED]

        for i in range(large_task_count):
            goal = goals[i % len(goals)]  # Distribute across goals
            status = statuses[i % len(statuses)]  # Vary statuses
            owner = f"agent-{i % 20}" if status == TaskStatus.OWNED else None

            task = test_data_factory.create_task(
                goal=goal, name=f"Large dataset task {i + 1}", status=status, owner=owner
            )
            created_tasks.append(task)

            # Progress indicator
            if (i + 1) % 100 == 0:
                print(f"Created {i + 1}/{large_task_count} tasks...")

        creation_time = time.time() - start_time

        # Test various search operations
        print("Testing search operations on large task dataset...")

        # Search by goal
        search_start = time.time()
        goal_results = task_repo.search(goal_id=goals[0].id)
        goal_search_time = time.time() - search_start

        # Search by status
        search_start = time.time()
        available_results = task_repo.search(status=TaskStatus.AVAILABLE)
        status_search_time = time.time() - search_start

        # Search by owner
        search_start = time.time()
        owner_results = task_repo.search(owner="agent-1")
        owner_search_time = time.time() - search_start

        # Combined search
        search_start = time.time()
        combined_results = task_repo.search(goal_id=goals[0].id, status=TaskStatus.AVAILABLE)
        combined_search_time = time.time() - search_start

        # Performance assertions
        assert creation_time < 30.0, f"Large task dataset creation took {creation_time:.2f}s, should be < 30s"
        assert goal_search_time < 2.0, f"Goal search took {goal_search_time:.2f}s, should be < 2s"
        assert status_search_time < 3.0, f"Status search took {status_search_time:.2f}s, should be < 3s"
        assert owner_search_time < 2.0, f"Owner search took {owner_search_time:.2f}s, should be < 2s"
        assert combined_search_time < 2.0, f"Combined search took {combined_search_time:.2f}s, should be < 2s"

        # Verify search results (be more flexible with cache and pagination)
        assert len(goal_results) >= 20  # At least some results for goal search
        assert len(available_results) >= 50  # At least some available tasks
        assert len(owner_results) >= 10  # At least some tasks for agent-1
        assert len(combined_results) >= 0  # Can be zero for specific combo

        print("Large task dataset search performance results:")
        print(
            f"  Created {large_task_count} tasks in {creation_time:.2f}s ({large_task_count / creation_time:.1f} tasks/sec)"
        )
        print(f"  Goal search ({len(goal_results)} results) in {goal_search_time:.3f}s")
        print(f"  Status search ({len(available_results)} results) in {status_search_time:.3f}s")
        print(f"  Owner search ({len(owner_results)} results) in {owner_search_time:.3f}s")
        print(f"  Combined search ({len(combined_results)} results) in {combined_search_time:.3f}s")


class TestMemoryAndResourceUsage:
    """Test memory usage and resource consumption patterns."""

    @pytest.mark.slow
    def test_memory_usage_large_operations(self, clean_database, test_data_factory):
        """Test memory usage during large operations."""
        import os

        import psutil

        process = psutil.Process(os.getpid())

        # Get baseline memory
        baseline_memory = process.memory_info().rss / 1024 / 1024  # MB

        goal_repo = GoalRepository()
        task_repo = TaskRepository()

        # Create large dataset
        operations_count = 200

        # Create goals
        created_goals = []
        for i in range(operations_count):
            goal = goal_repo.create(f"Memory test goal {i + 1}")
            created_goals.append(goal)

        goal_memory = process.memory_info().rss / 1024 / 1024  # MB

        # Create tasks
        created_tasks = []
        for i in range(operations_count):
            goal = created_goals[i % len(created_goals)]
            task = task_repo.create(
                goal_id=goal.id, name=f"Memory test task {i + 1}", instructions=f"Memory test instructions {i + 1}"
            )
            created_tasks.append(task)

        task_memory = process.memory_info().rss / 1024 / 1024  # MB

        # Perform searches
        for i in range(10):
            goal = created_goals[i]
            task_repo.search(goal_id=goal.id)
            goal_repo.list_all()

        search_memory = process.memory_info().rss / 1024 / 1024  # MB

        # Calculate memory increases
        goal_memory_increase = goal_memory - baseline_memory
        task_memory_increase = task_memory - goal_memory
        search_memory_increase = search_memory - task_memory
        total_memory_increase = search_memory - baseline_memory

        # Memory usage should be reasonable
        assert goal_memory_increase < 50, (
            f"Goal creation increased memory by {goal_memory_increase:.1f}MB, should be < 50MB"
        )
        assert task_memory_increase < 50, (
            f"Task creation increased memory by {task_memory_increase:.1f}MB, should be < 50MB"
        )
        assert search_memory_increase < 20, (
            f"Searches increased memory by {search_memory_increase:.1f}MB, should be < 20MB"
        )
        assert total_memory_increase < 100, f"Total memory increase {total_memory_increase:.1f}MB, should be < 100MB"

        print("Memory usage test results:")
        print(f"  Baseline memory: {baseline_memory:.1f}MB")
        print(f"  After {operations_count} goals: {goal_memory:.1f}MB (+{goal_memory_increase:.1f}MB)")
        print(f"  After {operations_count} tasks: {task_memory:.1f}MB (+{task_memory_increase:.1f}MB)")
        print(f"  After searches: {search_memory:.1f}MB (+{search_memory_increase:.1f}MB)")
        print(f"  Total increase: {total_memory_increase:.1f}MB")


# Performance test configuration
@pytest.fixture(autouse=True)
def performance_test_setup():
    """Set up performance test environment."""
    print("\n" + "=" * 80)
    print("PERFORMANCE TEST")
    print("=" * 80)
    yield
    print("=" * 80)
    print("PERFORMANCE TEST COMPLETE")
    print("=" * 80 + "\n")
