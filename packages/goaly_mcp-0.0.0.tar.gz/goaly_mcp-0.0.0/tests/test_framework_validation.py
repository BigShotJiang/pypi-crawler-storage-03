"""
Test validation for the testing framework setup.

This module validates that all fixtures and test data factories
work correctly and provide proper database isolation.
"""

from sqlalchemy import text

from goaly_mcp.models import Goal, Task, TaskStatus
from goaly_mcp.repositories.goals import GoalRepository
from goaly_mcp.repositories.tasks import TaskRepository


class TestFixtureValidation:
    """Test class to validate that all testing fixtures work correctly."""

    def test_database_isolation(self, clean_database):
        """Test that database isolation works between tests."""
        # Create a goal to verify isolation
        goal = Goal(description="Test goal for isolation")
        clean_database.add(goal)
        clean_database.commit()

        # Verify goal exists
        goals = clean_database.execute(text("SELECT COUNT(*) FROM goals")).scalar()
        assert goals >= 1

    def test_database_isolation_verification(self, clean_database):
        """Test that the previous test didn't affect this one."""
        # This should start with a clean database
        goals = clean_database.execute(text("SELECT COUNT(*) FROM goals")).scalar()
        tasks = clean_database.execute(text("SELECT COUNT(*) FROM tasks")).scalar()
        deps = clean_database.execute(text("SELECT COUNT(*) FROM task_dependencies")).scalar()

        assert goals == 0, "Database not clean - previous test data found"
        assert tasks == 0, "Database not clean - previous test data found"
        assert deps == 0, "Database not clean - previous test data found"

    def test_goal_repo_fixture(self, goal_repo, clean_database):
        """Test that GoalRepository fixture works correctly."""
        assert isinstance(goal_repo, GoalRepository)

        # Test basic repository operation
        goal = goal_repo.create("Test goal from fixture")
        assert goal is not None
        assert goal.id is not None
        assert goal.description == "Test goal from fixture"

    def test_task_repo_fixture(self, task_repo, sample_goal):
        """Test that TaskRepository fixture works correctly."""
        assert isinstance(task_repo, TaskRepository)

        # Test basic repository operation
        task = task_repo.create(goal_id=sample_goal.id, name="Test task from fixture", instructions="Test instructions")
        assert task is not None
        assert task.id is not None
        assert task.name == "Test task from fixture"

    def test_sample_goal_fixture(self, sample_goal):
        """Test that sample goal fixture provides valid data."""
        assert isinstance(sample_goal, Goal)
        assert sample_goal.id is not None
        assert sample_goal.description is not None
        assert sample_goal.is_complete is False
        assert sample_goal.created_at is not None

    def test_sample_completed_goal_fixture(self, sample_completed_goal):
        """Test that sample completed goal fixture provides valid data."""
        assert isinstance(sample_completed_goal, Goal)
        assert sample_completed_goal.id is not None
        assert sample_completed_goal.description is not None
        assert sample_completed_goal.is_complete is True
        assert sample_completed_goal.created_at is not None

    def test_sample_task_fixture(self, sample_task, sample_goal):
        """Test that sample task fixture provides valid data."""
        assert isinstance(sample_task, Task)
        assert sample_task.id is not None
        assert sample_task.goal_id == sample_goal.id
        assert sample_task.name is not None
        assert sample_task.instructions is not None
        assert sample_task.status == TaskStatus.AVAILABLE
        assert sample_task.owner is None

    def test_sample_owned_task_fixture(self, sample_owned_task, sample_goal):
        """Test that sample owned task fixture provides valid data."""
        assert isinstance(sample_owned_task, Task)
        assert sample_owned_task.id is not None
        assert sample_owned_task.goal_id == sample_goal.id
        assert sample_owned_task.status == TaskStatus.OWNED
        assert sample_owned_task.owner == "agent-12345"

    def test_sample_completed_task_fixture(self, sample_completed_task, sample_goal):
        """Test that sample completed task fixture provides valid data."""
        assert isinstance(sample_completed_task, Task)
        assert sample_completed_task.id is not None
        assert sample_completed_task.goal_id == sample_goal.id
        assert sample_completed_task.status == TaskStatus.COMPLETED
        assert sample_completed_task.owner == "agent-67890"


class TestDataFactoryValidation:
    """Test class to validate TestDataFactory functionality."""

    def test_create_goal(self, test_data_factory):
        """Test that TestDataFactory can create goals."""
        # Test with specific data
        goal = test_data_factory.create_goal(description="Custom goal description", is_complete=True)
        assert goal.description == "Custom goal description"
        assert goal.is_complete is True

        # Test with auto-generated data
        auto_goal = test_data_factory.create_goal()
        assert auto_goal.description is not None
        assert auto_goal.is_complete is False

    def test_create_task(self, test_data_factory, sample_goal):
        """Test that TestDataFactory can create tasks."""
        # Test with specific data
        task = test_data_factory.create_task(
            goal=sample_goal,
            name="Custom task name",
            instructions="Custom instructions",
            status=TaskStatus.OWNED,
            owner="agent-test",
        )
        assert task.name == "Custom task name"
        assert task.instructions == "Custom instructions"
        assert task.status == TaskStatus.OWNED
        assert task.owner == "agent-test"

        # Test with auto-generated data
        auto_task = test_data_factory.create_task(goal=sample_goal)
        assert auto_task.name is not None
        assert auto_task.instructions is not None
        assert auto_task.status == TaskStatus.AVAILABLE
        assert auto_task.owner is None

    def test_create_task_dependency(self, test_data_factory, sample_goal):
        """Test that TestDataFactory can create task dependencies."""
        # Create two tasks
        task1 = test_data_factory.create_task(sample_goal, name="First task")
        task2 = test_data_factory.create_task(sample_goal, name="Second task")

        # Create dependency
        dependency = test_data_factory.create_task_dependency(
            dependent_task=task2, dependency_task=task1, required_data="Test data requirement", is_blocked=True
        )

        assert dependency.dependent_task_id == task2.id
        assert dependency.dependency_task_id == task1.id
        assert dependency.required_data == "Test data requirement"
        assert dependency.is_blocked is True

    def test_create_goal_with_tasks(self, test_data_factory):
        """Test that TestDataFactory can create goals with multiple tasks."""
        goal, tasks = test_data_factory.create_goal_with_tasks(
            goal_description="Test goal with tasks", task_count=5, completed_task_count=2
        )

        assert goal.description == "Test goal with tasks"
        assert len(tasks) == 5

        # Check that first 2 tasks are completed
        completed_tasks = [t for t in tasks if t.status == TaskStatus.COMPLETED]
        assert len(completed_tasks) == 2

        # Verify all tasks belong to the goal
        for task in tasks:
            assert task.goal_id == goal.id

    def test_create_dependency_chain(self, test_data_factory, sample_goal):
        """Test that TestDataFactory can create dependency chains."""
        tasks = test_data_factory.create_dependency_chain(goal=sample_goal, chain_length=4)

        assert len(tasks) == 4

        # Verify all tasks belong to the goal
        for task in tasks:
            assert task.goal_id == sample_goal.id

        # Verify dependencies exist (except for first task)
        # This requires checking the database for the relationships
        # We'll just verify the tasks were created for now


class TestMultipleFixtures:
    """Test class to validate fixtures that provide multiple objects."""

    def test_multiple_goals_fixture(self, multiple_goals):
        """Test that multiple_goals fixture provides varied data."""
        assert len(multiple_goals) == 5

        # Check that we have a mix of completed and incomplete goals
        completed_goals = [g for g in multiple_goals if g.is_complete]
        incomplete_goals = [g for g in multiple_goals if not g.is_complete]

        assert len(completed_goals) == 2
        assert len(incomplete_goals) == 3

        # Verify all goals have unique descriptions
        descriptions = [g.description for g in multiple_goals]
        assert len(set(descriptions)) == len(descriptions)

    def test_multiple_tasks_with_dependencies_fixture(self, multiple_tasks_with_dependencies):
        """Test that multiple_tasks_with_dependencies fixture provides complex relationships."""
        tasks = multiple_tasks_with_dependencies
        assert len(tasks) == 4

        # Verify we have different task statuses
        statuses = [t.status for t in tasks]
        assert TaskStatus.COMPLETED in statuses
        assert TaskStatus.AVAILABLE in statuses
        assert TaskStatus.BLOCKED in statuses

        # Verify tasks have meaningful names
        names = [t.name for t in tasks]
        assert len(set(names)) == len(names)  # All unique names


class TestRepositoryIntegration:
    """Test class to validate repository integration with fixtures."""

    def test_goal_repository_with_fixtures(self, goal_repo, clean_database):
        """Test GoalRepository operations work with fixture database."""
        # Create goal
        goal = goal_repo.create("Repository integration test")
        assert goal is not None

        # Retrieve goal
        retrieved = goal_repo.get_by_id(goal.id)
        assert retrieved is not None
        assert retrieved.description == "Repository integration test"

        # List goals
        all_goals = goal_repo.list_all()
        assert len(all_goals) >= 1

        # Update goal
        updated = goal_repo.update(goal.id, description="Updated description", is_complete=True)
        assert updated.description == "Updated description"
        assert updated.is_complete is True

        # Delete goal
        deleted = goal_repo.delete(goal.id)
        assert deleted is True

    def test_task_repository_with_fixtures(self, task_repo, sample_goal, clean_database):
        """Test TaskRepository operations work with fixture database."""
        # Create task
        task = task_repo.create(
            goal_id=sample_goal.id, name="Repository integration task", instructions="Test instructions for integration"
        )
        assert task is not None

        # Retrieve task
        retrieved = task_repo.get_by_id(task.id)
        assert retrieved is not None
        assert retrieved.name == "Repository integration task"

        # Update task status
        updated = task_repo.update(task.id, status=TaskStatus.OWNED, owner="test-agent")
        assert updated.status == TaskStatus.OWNED
        assert updated.owner == "test-agent"

        # Search tasks
        search_results = task_repo.search(goal_id=sample_goal.id)
        assert len(search_results) >= 1

    def test_task_dependency_operations(self, task_repo, sample_goal, clean_database):
        """Test task dependency operations work with fixture database."""
        # Create two tasks
        task1 = task_repo.create(sample_goal.id, "First task", "Instructions 1")
        task2 = task_repo.create(sample_goal.id, "Second task", "Instructions 2")

        # Add dependency
        task_repo.add_dependency(task2.id, task1.id)

        # Verify dependency exists by checking task blocking status
        retrieved_task2 = task_repo.get_by_id(task2.id)
        # The exact blocking logic depends on the repository implementation
        # For now, just verify the task still exists
        assert retrieved_task2 is not None

    def test_cross_repository_operations(self, goal_repo, task_repo, clean_database):
        """Test operations that span multiple repositories."""
        # Create goal with goal repository
        goal = goal_repo.create("Cross-repository test goal")

        # Create tasks with task repository
        task_repo.create(goal.id, "Task 1", "Instructions 1")
        task_repo.create(goal.id, "Task 2", "Instructions 2")

        # Verify relationship via goal repository
        updated_goal = goal_repo.get_by_id(goal.id)
        # The goal should exist and be accessible
        assert updated_goal is not None
        assert updated_goal.id == goal.id

        # Clean up by completing goal
        final_goal = goal_repo.update(goal.id, is_complete=True)
        assert final_goal.is_complete is True
