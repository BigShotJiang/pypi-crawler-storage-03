"""
Tests for repository method caching integration.
"""

import pytest

from goaly_mcp.cache import clear_all_cache, get_cache_instance
from goaly_mcp.models import Goal, Task, TaskStatus
from goaly_mcp.repositories.goals import GoalRepository
from goaly_mcp.repositories.tasks import TaskRepository


@pytest.fixture(autouse=True)
def clear_cache():
    """Clear cache before each test."""
    clear_all_cache()
    yield
    clear_all_cache()


@pytest.fixture
def test_goal(clean_database):
    """Create a test goal for cache testing."""
    goal = Goal(description="Cache Test Goal", is_complete=False)
    clean_database.add(goal)
    clean_database.flush()
    clean_database.refresh(goal)
    clean_database.commit()
    return goal


@pytest.fixture
def test_tasks(test_goal, clean_database):
    """Create test tasks for cache testing."""
    tasks = []
    for i in range(3):
        task = Task(
            goal_id=test_goal.id,
            name=f"Cache Test Task {i}",
            status=TaskStatus.AVAILABLE if i % 2 == 0 else TaskStatus.COMPLETED,
        )
        clean_database.add(task)
        tasks.append(task)

    clean_database.flush()
    for task in tasks:
        clean_database.refresh(task)
    clean_database.commit()

    return tasks


class TestGoalRepositoryCaching:
    """Test caching functionality in GoalRepository."""

    def test_list_all_caching(self, test_goal):
        """Test that list_all method uses caching."""
        repo = GoalRepository()
        cache = get_cache_instance()

        # First call should populate cache
        goals1 = repo.list_all()
        assert len(goals1) >= 1

        # Check that cache has entries
        cache_stats = cache.stats()
        assert cache_stats["total_entries"] > 0

        # Second call should use cache (verify by checking cache stats don't change)
        initial_entries = cache_stats["total_entries"]
        goals2 = repo.list_all()

        # Results should be identical
        assert len(goals1) == len(goals2)
        assert [g.id for g in goals1] == [g.id for g in goals2]

        # Cache entries should not have increased
        new_stats = cache.stats()
        assert new_stats["total_entries"] == initial_entries

    def test_list_all_different_filters(self, test_goal):
        """Test that different filter combinations create separate cache entries."""
        repo = GoalRepository()
        cache = get_cache_instance()

        # Make calls with different filters
        repo.list_all()
        repo.list_all(completed_only=True)
        repo.list_all(incomplete_only=True)

        # Should create separate cache entries
        cache_stats = cache.stats()
        assert cache_stats["total_entries"] >= 3

    def test_cache_invalidation_on_create(self, test_goal):
        """Test that cache is invalidated when creating a goal."""
        repo = GoalRepository()
        cache = get_cache_instance()

        # Populate cache
        initial_goals = repo.list_all()
        initial_count = len(initial_goals)

        # Verify cache exists
        assert cache.stats()["total_entries"] > 0

        # Create new goal (should invalidate cache)
        repo.create("New Cache Test Goal")

        # Cache should be cleared
        cache.stats()
        # Note: Cache might not be completely empty due to the create operation,
        # but the list_all cache should be invalidated

        # Next call should reflect the new goal
        updated_goals = repo.list_all()
        assert len(updated_goals) == initial_count + 1

    def test_cache_invalidation_on_update(self, test_goal):
        """Test that cache is invalidated when updating a goal."""
        repo = GoalRepository()
        cache = get_cache_instance()

        # Populate cache
        repo.list_all()
        assert cache.stats()["total_entries"] > 0

        # Update goal (should invalidate cache)
        updated_goal = repo.update(test_goal.id, description="Updated Description")
        assert updated_goal is not None
        assert updated_goal.description == "Updated Description"

        # Cache should be invalidated - next call should work correctly
        updated_goals = repo.list_all()
        goal_in_list = next((g for g in updated_goals if g.id == test_goal.id), None)
        assert goal_in_list is not None
        assert goal_in_list.description == "Updated Description"

    def test_cache_invalidation_on_delete(self, test_goal):
        """Test that cache is invalidated when deleting a goal."""
        repo = GoalRepository()
        get_cache_instance()

        # Populate cache
        initial_goals = repo.list_all()
        initial_count = len(initial_goals)

        # Delete goal (should invalidate cache)
        success = repo.delete(test_goal.id)
        assert success is True

        # Next call should reflect the deletion
        updated_goals = repo.list_all()
        assert len(updated_goals) == initial_count - 1
        assert not any(g.id == test_goal.id for g in updated_goals)


class TestTaskRepositoryCaching:
    """Test caching functionality in TaskRepository."""

    def test_search_caching(self, test_tasks):
        """Test that search method uses caching."""
        repo = TaskRepository()
        cache = get_cache_instance()

        goal_id = test_tasks[0].goal_id

        # First call should populate cache
        tasks1 = repo.search(goal_id=goal_id)
        assert len(tasks1) == 3

        # Check that cache has entries
        cache_stats = cache.stats()
        assert cache_stats["total_entries"] > 0

        # Second call with same parameters should use cache
        initial_entries = cache_stats["total_entries"]
        tasks2 = repo.search(goal_id=goal_id)

        # Results should be identical
        assert len(tasks1) == len(tasks2)
        assert [t.id for t in tasks1] == [t.id for t in tasks2]

        # Cache entries should not have increased significantly
        new_stats = cache.stats()
        assert new_stats["total_entries"] <= initial_entries + 1  # Allow for small variance

    def test_get_tasks_with_metadata_caching(self, test_tasks):
        """Test that get_tasks_with_metadata method uses caching."""
        repo = TaskRepository()
        cache = get_cache_instance()

        goal_id = test_tasks[0].goal_id

        # First call should populate cache
        tasks1 = repo.get_tasks_with_metadata(goal_id=goal_id)
        assert len(tasks1) == 3

        # Verify cache is populated
        cache_stats = cache.stats()
        assert cache_stats["total_entries"] > 0

        # Second call should use cache
        tasks2 = repo.get_tasks_with_metadata(goal_id=goal_id)

        # Results should be identical
        assert len(tasks1) == len(tasks2)
        assert [t["id"] for t in tasks1] == [t["id"] for t in tasks2]

    def test_cache_invalidation_on_task_create(self, test_goal):
        """Test that cache is invalidated when creating a task."""
        repo = TaskRepository()
        get_cache_instance()

        # Populate cache
        initial_tasks = repo.search(goal_id=test_goal.id)
        initial_count = len(initial_tasks)

        # Create new task (should invalidate cache)
        repo.create(goal_id=test_goal.id, name="New Cache Test Task", status=TaskStatus.AVAILABLE)

        # Next call should reflect the new task
        updated_tasks = repo.search(goal_id=test_goal.id)
        assert len(updated_tasks) == initial_count + 1

    def test_cache_invalidation_on_task_update(self, test_tasks):
        """Test that cache is invalidated when updating a task."""
        repo = TaskRepository()
        cache = get_cache_instance()

        task = test_tasks[0]

        # Populate cache
        repo.search(goal_id=task.goal_id)
        assert cache.stats()["total_entries"] > 0

        # Update task (should invalidate cache)
        updated_task = repo.update(task.id, name="Updated Task Name")
        assert updated_task is not None
        assert updated_task.name == "Updated Task Name"

        # Cache should be invalidated - verify by checking fresh data
        fresh_tasks = repo.search(goal_id=task.goal_id)
        updated_in_list = next((t for t in fresh_tasks if t.id == task.id), None)
        assert updated_in_list is not None
        assert updated_in_list.name == "Updated Task Name"

    def test_cache_invalidation_on_task_delete(self, test_tasks):
        """Test that cache is invalidated when deleting a task."""
        repo = TaskRepository()
        get_cache_instance()

        task_to_delete = test_tasks[0]
        goal_id = task_to_delete.goal_id

        # Populate cache
        initial_tasks = repo.search(goal_id=goal_id)
        initial_count = len(initial_tasks)

        # Delete task (should invalidate cache)
        success = repo.delete(task_to_delete.id)
        assert success is True

        # Next call should reflect the deletion
        updated_tasks = repo.search(goal_id=goal_id)
        assert len(updated_tasks) == initial_count - 1
        assert not any(t.id == task_to_delete.id for t in updated_tasks)


class TestCacheHitMissRatios:
    """Test cache hit/miss ratios to validate caching effectiveness."""

    def test_goal_cache_effectiveness(self, test_goal):
        """Test that goal caching provides good hit rates."""
        repo = GoalRepository()
        cache = get_cache_instance()

        # Make multiple calls with same parameters
        for _ in range(5):
            repo.list_all()

        for _ in range(3):
            repo.list_all(incomplete_only=True)

        # Cache should have reasonable number of entries (not one per call)
        cache_stats = cache.stats()
        # We made 8 calls but should have only 2 unique cache entries
        assert cache_stats["total_entries"] <= 3  # Allow some buffer

    def test_task_cache_effectiveness(self, test_tasks):
        """Test that task caching provides good hit rates."""
        repo = TaskRepository()
        cache = get_cache_instance()

        goal_id = test_tasks[0].goal_id

        # Make multiple calls with same parameters
        for _ in range(5):
            repo.search(goal_id=goal_id)

        for _ in range(3):
            repo.get_tasks_with_metadata(goal_id=goal_id)

        for _ in range(2):
            repo.search(goal_id=goal_id, status="available")

        # Cache should have reasonable number of entries
        cache_stats = cache.stats()
        # We made 10 calls but should have only 3 unique cache entries
        assert cache_stats["total_entries"] <= 5  # Allow some buffer

    def test_cache_memory_efficiency(self, test_goal, test_tasks):
        """Test that cache doesn't grow indefinitely."""
        repo_goals = GoalRepository()
        repo_tasks = TaskRepository()
        cache = get_cache_instance()

        goal_id = test_goal.id

        # Make many different calls to test cache size limits
        for i in range(20):
            # Vary parameters to create different cache keys
            repo_goals.list_all(completed_only=(i % 2 == 0))
            repo_tasks.search(goal_id=goal_id, status="available" if i % 2 else "completed")

        # Cache should not grow excessively
        cache_stats = cache.stats()
        assert cache_stats["total_entries"] < 50  # Reasonable limit
        assert cache_stats["total_entries"] <= cache_stats["max_size"]
