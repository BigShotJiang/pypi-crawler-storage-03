"""
Tests for API endpoints
"""

import pytest
from fastapi.testclient import TestClient

from goaly_mcp.test_app import create_test_app


@pytest.fixture
def client():
    """Create test client"""
    test_app = create_test_app()
    return TestClient(test_app)


def test_create_goal_api(client):
    """Test creating a goal via API"""
    goal_data = {"description": "Test API goal"}
    response = client.post("/api/v1/goals/", json=goal_data)

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["data"]["description"] == "Test API goal"
    assert data["data"]["is_complete"] is False
    assert "id" in data["data"]


def test_list_goals_api(client):
    """Test listing goals via API"""
    response = client.get("/api/v1/goals/")
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "data" in data
    assert "goals" in data["data"]
    assert isinstance(data["data"]["goals"], list)


@pytest.mark.skip(reason="SSE endpoints cause test hanging - streaming never completes")
def test_sse_endpoint(client):
    """Test SSE endpoint exists and responds"""
    response = client.get("/api/v1/sse/events")
    # SSE endpoint should return 200 and start streaming
    assert response.status_code == 200
    assert "text/plain" in response.headers.get("content-type", "")
