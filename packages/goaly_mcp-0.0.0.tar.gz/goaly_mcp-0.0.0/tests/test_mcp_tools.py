"""
Tests for MCP tools
"""

import pytest
from fastmcp import FastMCP

from goaly_mcp.mcp_tools import register_mcp_tools
from goaly_mcp.models import Goal, Task, TaskStatus


@pytest.fixture
def mcp_server():
    """Create MCP server with registered tools"""
    server = FastMCP(name="TestMCP")
    register_mcp_tools(server)
    return server


def test_mcp_tools_registration(mcp_server):
    """Test that MCP tools are registered correctly"""
    # The FastMCP server should have tools registered
    # We can't easily inspect the internal tools dict, but we can verify
    # the server was created successfully
    assert mcp_server.name == "TestMCP"


def test_create_goal_function(test_session):
    """Test create_goal function directly"""
    # Test the database operations work with test session
    goal = Goal(description="Direct test goal")
    test_session.add(goal)
    test_session.commit()
    test_session.refresh(goal)

    assert goal.id is not None
    assert goal.description == "Direct test goal"


def test_database_helper_functions(test_session):
    """Test helper functions work with database"""
    from goaly_mcp.mcp_tools import calculate_task_importance, update_task_blocking_status

    session = test_session
    # Create test goal and task
    goal = Goal(description="Test goal")
    session.add(goal)
    session.commit()
    session.refresh(goal)

    task = Task(goal_id=goal.id, name="Test task", status=TaskStatus.AVAILABLE)
    session.add(task)
    session.commit()
    session.refresh(task)

    # Test calculate_task_importance
    importance = calculate_task_importance(session, task.id)
    assert importance == 0  # No dependencies yet

    # Test update_task_blocking_status
    update_task_blocking_status(session, task.id)
    # Should not raise an error
