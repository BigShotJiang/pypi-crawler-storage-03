"""
Tests for TaskRepository batch operations to prevent N+1 query problems.
"""

import pytest

from goaly_mcp.models import Goal, Task, TaskDependency, TaskStatus
from goaly_mcp.repositories.tasks import TaskRepository


@pytest.fixture
def task_repo(clean_database):
    """Get TaskRepository instance."""
    return TaskRepository()


@pytest.fixture
def test_data_with_dependencies(clean_database):
    """Create test data with tasks and dependencies."""
    session = clean_database

    # Create test goal
    goal = Goal(description="Test Goal for Batch Operations", is_complete=False)
    session.add(goal)
    session.flush()

    # Create multiple tasks
    task1 = Task(goal_id=goal.id, name="Task 1", status=TaskStatus.COMPLETED)
    task2 = Task(goal_id=goal.id, name="Task 2", status=TaskStatus.AVAILABLE)
    task3 = Task(goal_id=goal.id, name="Task 3", status=TaskStatus.AVAILABLE, owner="owner1")
    task4 = Task(goal_id=goal.id, name="Task 4", status=TaskStatus.BLOCKED)

    session.add_all([task1, task2, task3, task4])
    session.flush()

    # Create dependencies: Task 2 and Task 3 depend on Task 1, Task 4 depends on Task 2
    dep1 = TaskDependency(dependent_task_id=task2.id, dependency_task_id=task1.id, is_blocked=False)
    dep2 = TaskDependency(dependent_task_id=task3.id, dependency_task_id=task1.id, is_blocked=False)
    dep3 = TaskDependency(dependent_task_id=task4.id, dependency_task_id=task2.id, is_blocked=True)

    session.add_all([dep1, dep2, dep3])
    session.commit()

    data = {
        "goal": goal,
        "task1": task1,  # Importance: 2 (task2 and task3 depend on it), Dependencies: 0
        "task2": task2,  # Importance: 1 (task4 depends on it), Dependencies: 1 (depends on task1)
        "task3": task3,  # Importance: 0, Dependencies: 1 (depends on task1)
        "task4": task4,  # Importance: 0, Dependencies: 1 (depends on task2)
    }

    return data


def test_get_tasks_with_metadata_basic(task_repo, test_data_with_dependencies):
    """Test basic functionality of get_tasks_with_metadata."""
    data = test_data_with_dependencies

    # Get all tasks with metadata
    result = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id)

    assert len(result) == 4
    assert all("importance" in task for task in result)
    assert all("dependency_count" in task for task in result)
    assert all("is_leaf_node" in task for task in result)


def test_get_tasks_with_metadata_importance_calculation(task_repo, test_data_with_dependencies):
    """Test that importance is calculated correctly in batch."""
    data = test_data_with_dependencies

    result = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id)

    # Create a mapping by task id for easy lookup
    task_map = {task["id"]: task for task in result}

    # Task 1 should have importance 2 (both task2 and task3 depend on it)
    assert task_map[data["task1"].id]["importance"] == 2

    # Task 2 should have importance 1 (task4 depends on it)
    assert task_map[data["task2"].id]["importance"] == 1

    # Task 3 and Task 4 should have importance 0
    assert task_map[data["task3"].id]["importance"] == 0
    assert task_map[data["task4"].id]["importance"] == 0


def test_get_tasks_with_metadata_dependency_count(task_repo, test_data_with_dependencies):
    """Test that dependency_count is calculated correctly in batch."""
    data = test_data_with_dependencies

    result = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id)

    # Create a mapping by task id for easy lookup
    task_map = {task["id"]: task for task in result}

    # Task 1 should have 0 dependencies (no incoming dependencies)
    assert task_map[data["task1"].id]["dependency_count"] == 0
    assert task_map[data["task1"].id]["is_leaf_node"] == True

    # Task 2, Task 3, and Task 4 should each have 1 dependency
    assert task_map[data["task2"].id]["dependency_count"] == 1
    assert task_map[data["task2"].id]["is_leaf_node"] == False

    assert task_map[data["task3"].id]["dependency_count"] == 1
    assert task_map[data["task3"].id]["is_leaf_node"] == False

    assert task_map[data["task4"].id]["dependency_count"] == 1
    assert task_map[data["task4"].id]["is_leaf_node"] == False


def test_get_tasks_with_metadata_filters(task_repo, test_data_with_dependencies):
    """Test that filters work correctly with the batch method."""
    data = test_data_with_dependencies

    # Test status filter
    available_tasks = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id, status="available")
    assert len(available_tasks) == 2
    available_ids = {task["id"] for task in available_tasks}
    assert data["task2"].id in available_ids
    assert data["task3"].id in available_ids

    # Test owner filter
    owned_tasks = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id, owner="owner1")
    assert len(owned_tasks) == 1
    assert owned_tasks[0]["id"] == data["task3"].id

    # Test available_only filter (should exclude blocked tasks)
    available_only = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id, available_only=True)
    # This should only include unblocked available tasks
    blocked_ids = {task["id"] for task in available_only if task["status"] == "BLOCKED"}
    assert len(blocked_ids) == 0


def test_get_tasks_with_metadata_empty_results(task_repo):
    """Test batch method with no results."""
    # Test with non-existent goal
    result = task_repo.get_tasks_with_metadata(goal_id=999999)
    assert result == []

    # Test with filter that matches nothing
    result = task_repo.get_tasks_with_metadata(owner="nonexistent_owner")
    assert result == []


def test_get_tasks_with_metadata_data_structure(task_repo, test_data_with_dependencies):
    """Test that the returned data structure matches expectations."""
    data = test_data_with_dependencies

    result = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id)

    if result:  # If we have results
        task = result[0]

        # Check required fields
        required_fields = [
            "id",
            "goal_id",
            "name",
            "instructions",
            "status",
            "owner",
            "importance",
            "dependency_count",
            "is_leaf_node",
            "created_at",
            "updated_at",
        ]

        for field in required_fields:
            assert field in task, f"Missing field: {field}"

        # Check field types
        assert isinstance(task["id"], int)
        assert isinstance(task["goal_id"], int)
        assert isinstance(task["name"], str)
        assert isinstance(task["status"], str)
        assert isinstance(task["importance"], int)
        assert isinstance(task["dependency_count"], int)
        assert isinstance(task["is_leaf_node"], bool)
        assert isinstance(task["created_at"], str)
        assert isinstance(task["updated_at"], str)


@pytest.mark.performance
def test_batch_vs_individual_queries_performance(task_repo, test_data_with_dependencies):
    """
    Basic performance comparison test between batch method and individual queries.
    This is a simple smoke test - comprehensive performance testing would need larger datasets.
    """
    import time

    from sqlalchemy import func, select

    from goaly_mcp.api.tasks import calculate_task_importance
    from goaly_mcp.models import TaskDependency as TaskDependencyModel

    data = test_data_with_dependencies

    # Time the batch method
    start_time = time.time()
    batch_result = task_repo.get_tasks_with_metadata(goal_id=data["goal"].id)
    batch_time = time.time() - start_time

    # Time individual queries (simulating N+1 problem)
    start_time = time.time()
    tasks = task_repo.search(goal_id=data["goal"].id)
    individual_results = []

    # Use the managed session to ensure we're working with the test database
    from goaly_mcp.database_session import managed_session

    with managed_session() as session:
        for task in tasks:
            # Individual importance query
            importance = calculate_task_importance(session, task.id)

            # Individual dependency count query
            deps_result = session.execute(
                select(func.count(TaskDependencyModel.id)).where(TaskDependencyModel.dependent_task_id == task.id)
            )
            dependency_count = deps_result.scalar() or 0

            individual_results.append(
                {
                    "id": task.id,
                    "importance": importance,
                    "dependency_count": dependency_count,
                }
            )

    individual_time = time.time() - start_time

    # Verify results are equivalent (same data)
    batch_map = {task["id"]: task for task in batch_result}
    individual_map = {task["id"]: task for task in individual_results}

    for task_id in batch_map:
        assert batch_map[task_id]["importance"] == individual_map[task_id]["importance"]
        assert batch_map[task_id]["dependency_count"] == individual_map[task_id]["dependency_count"]

    # Batch method should generally be faster or at least not significantly slower
    # With small dataset the difference might not be noticeable, but this ensures correctness
    print(f"Batch method time: {batch_time:.4f}s, Individual queries time: {individual_time:.4f}s")

    # The batch method should produce the same results
    assert len(batch_result) == len(individual_results)
