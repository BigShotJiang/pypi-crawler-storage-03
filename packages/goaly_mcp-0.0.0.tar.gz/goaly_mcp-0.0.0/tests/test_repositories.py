"""
Tests for repository pattern
"""

from goaly_mcp.models import TaskStatus
from goaly_mcp.repositories import GoalRepository, TaskRepository


def test_goal_repository_create():
    """Test creating a goal via repository"""
    repo = GoalRepository()
    goal = repo.create("Test repository goal")

    assert goal.id is not None
    assert goal.description == "Test repository goal"
    assert goal.is_complete is False


def test_goal_repository_list():
    """Test listing goals via repository"""
    repo = GoalRepository()

    # Create a test goal
    goal = repo.create("Test list goal")

    # List all goals
    goals = repo.list_all()
    assert len(goals) >= 1

    # Check that our goal is in the list
    goal_ids = [g.id for g in goals]
    assert goal.id in goal_ids


def test_goal_repository_update():
    """Test updating a goal via repository"""
    repo = GoalRepository()

    # Create a goal
    goal = repo.create("Test update goal")
    original_id = goal.id

    # Update it
    updated_goal = repo.update(goal.id, is_complete=True)

    assert updated_goal is not None
    assert updated_goal.id == original_id
    assert updated_goal.is_complete is True


def test_task_repository_create():
    """Test creating a task via repository"""
    goal_repo = GoalRepository()
    task_repo = TaskRepository()

    # Create a goal first
    goal = goal_repo.create("Test goal for task")

    # Create a task
    task = task_repo.create(
        goal_id=goal.id, name="Test repository task", instructions="Test instructions", status=TaskStatus.AVAILABLE
    )

    assert task.id is not None
    assert task.goal_id == goal.id
    assert task.name == "Test repository task"
    assert task.status == TaskStatus.AVAILABLE
