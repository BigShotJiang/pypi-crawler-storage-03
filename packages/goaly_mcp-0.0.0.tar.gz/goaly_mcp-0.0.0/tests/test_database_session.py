"""
Test session management utilities for database operations.

Tests the session decorators and context manager to ensure proper
session handling and object detachment.
"""

from unittest.mock import MagicMock, patch

import pytest
from sqlalchemy import select

from goaly_mcp.database_session import (
    _detach_object,
    _detach_objects,
    managed_session,
    with_session,
    with_session_list,
    with_session_raw,
)
from goaly_mcp.models import Goal


class TestRepository:
    """Test repository to verify session decorators work correctly."""

    @with_session
    def create_goal(self, session, description: str) -> Goal:
        """Test single object return with @with_session"""
        goal = Goal(description=description)
        session.add(goal)
        session.flush()  # Get ID without committing
        session.refresh(goal)
        return goal

    @with_session
    def get_goal_by_id(self, session, goal_id: int) -> Goal | None:
        """Test single object retrieval with @with_session"""
        result = session.execute(select(Goal).where(Goal.id == goal_id))
        return result.scalars().first()

    @with_session_list
    def list_goals(self, session) -> list[Goal]:
        """Test list return with @with_session_list"""
        result = session.execute(select(Goal))
        return list(result.scalars().all())

    @with_session_raw
    def delete_goal(self, session, goal_id: int) -> bool:
        """Test raw return (bool) with @with_session_raw"""
        result = session.execute(select(Goal).where(Goal.id == goal_id))
        goal = result.scalars().first()
        if goal:
            session.delete(goal)
            return True
        return False

    @with_session_raw
    def count_goals(self, session) -> int:
        """Test raw return (int) with @with_session_raw"""
        result = session.execute(select(Goal))
        return len(list(result.scalars().all()))


class TestManagedSession:
    """Test the managed_session context manager."""

    def test_managed_session_commit_on_success(self, clean_database):
        """Test that managed_session commits on successful completion."""
        goal_description = "Test goal for managed session"
        goal_id = None

        # Create goal using managed_session
        with managed_session() as session:
            goal = Goal(description=goal_description)
            session.add(goal)
            session.flush()
            goal_id = goal.id

        # Verify goal was committed to database by checking it exists
        # Note: In test environment, we need to use the same session context
        # to verify persistence, as the test fixtures use isolated transactions
        with managed_session() as session:
            result = session.execute(select(Goal).where(Goal.id == goal_id))
            retrieved_goal = result.scalars().first()
            assert retrieved_goal is not None
            assert retrieved_goal.description == goal_description

    def test_managed_session_rollback_on_exception(self, clean_database):
        """Test that managed_session rolls back on exception."""
        goal_description = "Test goal for rollback"

        # Attempt to create goal but raise exception
        with pytest.raises(ValueError):
            with managed_session() as session:
                goal = Goal(description=goal_description)
                session.add(goal)
                session.flush()
                # Simulate an error
                raise ValueError("Simulated error")

        # Verify no goal was committed to database
        with managed_session() as session:
            result = session.execute(select(Goal).where(Goal.description == goal_description))
            assert result.scalars().first() is None

    def test_managed_session_closes_session(self):
        """Test that managed_session properly closes the session."""
        session_instance = None

        with managed_session() as session:
            session_instance = session
            assert session_instance.is_active  # Should be active during use

        # After context exit, session should be closed
        assert session_instance is not None
        # Note: SQLAlchemy sessions don't have a direct "is_closed" property
        # but we can verify it's no longer active/bound


class TestDetachmentFunctions:
    """Test the object detachment utility functions."""

    def test_detach_object_with_model_instance(self, clean_database):
        """Test _detach_object with a SQLAlchemy model instance."""
        with managed_session() as session:
            goal = Goal(description="Test goal")
            session.add(goal)
            session.flush()
            session.refresh(goal)

            # Object should be attached to session initially
            assert goal in session

            # Detach the object
            detached_goal = _detach_object(goal)

            # Object should no longer be in session
            assert detached_goal not in session
            assert detached_goal.description == "Test goal"

    def test_detach_object_with_none(self):
        """Test _detach_object with None value."""
        result = _detach_object(None)
        assert result is None

    def test_detach_objects_with_list(self, clean_database):
        """Test _detach_objects with a list of model instances."""
        with managed_session() as session:
            goals = [Goal(description="Goal 1"), Goal(description="Goal 2"), Goal(description="Goal 3")]
            for goal in goals:
                session.add(goal)
            session.flush()

            # All objects should be attached to session
            for goal in goals:
                assert goal in session

            # Detach all objects
            detached_goals = _detach_objects(goals)

            # Objects should no longer be in session
            for i, goal in enumerate(detached_goals):
                assert goal not in session
                assert goal.description == f"Goal {i + 1}"

    def test_detach_objects_with_mixed_list(self):
        """Test _detach_objects with mixed list containing None values."""
        mock_goal = MagicMock()
        mock_goal.__table__ = "mock_table"

        mixed_list = [mock_goal, None, mock_goal]

        with patch("goaly_mcp.database_session._detach_object") as mock_detach:
            mock_detach.side_effect = lambda x: x  # Return as-is

            result = _detach_objects(mixed_list)

            assert len(result) == 3
            assert mock_detach.call_count == 3


class TestWithSessionDecorator:
    """Test the @with_session decorator."""

    def test_with_session_single_object_return(self, clean_database):
        """Test @with_session decorator with single object return."""
        repo = TestRepository()

        # Create a goal
        goal = repo.create_goal("Test goal for single return")

        # Verify goal is returned and detached
        assert goal is not None
        assert goal.description == "Test goal for single return"
        assert goal.id is not None

        # Verify we can access attributes (object is detached)
        assert goal.description == "Test goal for single return"

    def test_with_session_none_return(self, clean_database):
        """Test @with_session decorator when method returns None."""
        repo = TestRepository()

        # Try to get non-existent goal
        goal = repo.get_goal_by_id(99999)

        # Should return None without errors
        assert goal is None

    def test_with_session_retrieval(self, clean_database):
        """Test @with_session decorator for object retrieval."""
        repo = TestRepository()

        # First create a goal
        created_goal = repo.create_goal("Test goal for retrieval")
        goal_id = created_goal.id

        # Retrieve the goal
        retrieved_goal = repo.get_goal_by_id(goal_id)

        # Verify retrieval and detachment
        assert retrieved_goal is not None
        assert retrieved_goal.id == goal_id
        assert retrieved_goal.description == "Test goal for retrieval"


class TestWithSessionListDecorator:
    """Test the @with_session_list decorator."""

    def test_with_session_list_multiple_objects(self, clean_database):
        """Test @with_session_list decorator with multiple objects."""
        repo = TestRepository()

        # Create multiple goals
        descriptions = ["Goal 1", "Goal 2", "Goal 3"]
        created_goals = []
        for desc in descriptions:
            goal = repo.create_goal(desc)
            created_goals.append(goal)

        # List all goals
        all_goals = repo.list_goals()

        # Verify all goals are returned and detached
        assert len(all_goals) >= 3  # May have other goals from other tests

        # Find our created goals
        our_goals = [g for g in all_goals if g.description in descriptions]
        assert len(our_goals) == 3

        # Verify each goal is accessible (detached)
        for goal in our_goals:
            assert goal.description in descriptions
            assert goal.id is not None

    def test_with_session_list_empty_list(self, clean_database):
        """Test @with_session_list decorator with empty results."""
        # Database is already clean due to clean_database fixture

        repo = TestRepository()

        # List goals (should be empty)
        goals = repo.list_goals()

        # Should return empty list
        assert goals == []

    def test_with_session_list_with_none_values(self, clean_database):
        """Test @with_session_list decorator handles None values in list."""
        repo = TestRepository()

        # Create a goal first to ensure list is not empty
        repo.create_goal("Test goal")

        goals = repo.list_goals()

        # All returned objects should be valid (no None values)
        assert all(goal is not None for goal in goals)
        assert all(hasattr(goal, "description") for goal in goals)


class TestWithSessionRawDecorator:
    """Test the @with_session_raw decorator."""

    def test_with_session_raw_boolean_return(self, clean_database):
        """Test @with_session_raw decorator with boolean return."""
        repo = TestRepository()

        # Create a goal to delete
        goal = repo.create_goal("Goal to delete")
        goal_id = goal.id

        # Delete the goal
        deleted = repo.delete_goal(goal_id)

        # Should return True
        assert deleted is True

        # Verify goal is actually deleted
        retrieved_goal = repo.get_goal_by_id(goal_id)
        assert retrieved_goal is None

    def test_with_session_raw_false_return(self, clean_database):
        """Test @with_session_raw decorator returns False for non-existent item."""
        repo = TestRepository()

        # Try to delete non-existent goal
        deleted = repo.delete_goal(99999)

        # Should return False
        assert deleted is False

    def test_with_session_raw_integer_return(self, clean_database):
        """Test @with_session_raw decorator with integer return."""
        repo = TestRepository()

        # Create some goals
        repo.create_goal("Goal 1")
        repo.create_goal("Goal 2")

        # Count goals
        count = repo.count_goals()

        # Should return integer count
        assert isinstance(count, int)
        assert count >= 2  # At least the 2 we created


class TestSessionDecoratorIntegration:
    """Integration tests for session decorators working together."""

    def test_full_crud_cycle(self, clean_database):
        """Test complete CRUD cycle using different decorators."""
        repo = TestRepository()

        # Create (with_session)
        goal = repo.create_goal("Integration test goal")
        assert goal is not None
        goal_id = goal.id

        # Read single (with_session)
        retrieved_goal = repo.get_goal_by_id(goal_id)
        assert retrieved_goal is not None
        assert retrieved_goal.description == "Integration test goal"

        # Read list (with_session_list)
        all_goals = repo.list_goals()
        our_goal = next((g for g in all_goals if g.id == goal_id), None)
        assert our_goal is not None
        assert our_goal.description == "Integration test goal"

        # Count (with_session_raw)
        count_before = repo.count_goals()
        assert count_before >= 1

        # Delete (with_session_raw)
        deleted = repo.delete_goal(goal_id)
        assert deleted is True

        # Verify deletion (with_session)
        deleted_goal = repo.get_goal_by_id(goal_id)
        assert deleted_goal is None

        # Verify count decreased (with_session_raw)
        count_after = repo.count_goals()
        assert count_after == count_before - 1

    def test_session_isolation_between_calls(self, clean_database):
        """Test that different decorator calls use separate sessions."""
        repo = TestRepository()

        # Create goal in one session
        goal1 = repo.create_goal("Session test goal 1")

        # Create another goal in different session
        goal2 = repo.create_goal("Session test goal 2")

        # Both should be successfully created with different IDs
        assert goal1.id != goal2.id
        assert goal1.description == "Session test goal 1"
        assert goal2.description == "Session test goal 2"

        # Both should be retrievable
        retrieved_goal1 = repo.get_goal_by_id(goal1.id)
        retrieved_goal2 = repo.get_goal_by_id(goal2.id)

        assert retrieved_goal1.description == "Session test goal 1"
        assert retrieved_goal2.description == "Session test goal 2"


# Removed test_db fixture - using clean_database from conftest.py instead
