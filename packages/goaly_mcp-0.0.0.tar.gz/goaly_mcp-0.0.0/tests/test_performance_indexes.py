"""
Tests for database performance indexes added in migration 884fc5465d57.
Validates that indexes are created and being used by common queries.
"""

import os
import sqlite3
from urllib.parse import urlparse

import pytest

from goaly_mcp.config import settings
from goaly_mcp.models import Goal, Task, TaskStatus


def get_database_path():
    """Get the SQLite database path from configuration."""
    # Extract database path from DATABASE_URL or use settings
    database_url = os.getenv("DATABASE_URL") or settings.database_url

    if database_url.startswith("sqlite+aiosqlite:"):
        # Remove the async prefix and extract the path
        path = database_url.replace("sqlite+aiosqlite://", "")
    elif database_url.startswith("sqlite:"):
        # Extract path from sync URL
        parsed = urlparse(database_url)
        path = parsed.path.lstrip("/")
    else:
        # Fallback to goaly.db if not SQLite
        path = "goaly.db"

    # Check if configured path exists and has tables
    if os.path.exists(path):
        try:
            conn = sqlite3.connect(path)
            if check_database_initialized(conn):
                conn.close()
                return path
            conn.close()
        except sqlite3.OperationalError:
            pass

    # Fallback: try goaly.db if it exists and has tables
    if os.path.exists("goaly.db"):
        try:
            conn = sqlite3.connect("goaly.db")
            if check_database_initialized(conn):
                conn.close()
                return "goaly.db"
            conn.close()
        except sqlite3.OperationalError:
            pass

    # Return configured path as final fallback
    return path


def check_database_initialized(conn):
    """Check if the database has the required tables and indexes."""
    cursor = conn.cursor()
    try:
        # Check if main tables exist
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('tasks', 'goals', 'task_dependencies')"
        )
        tables = [row[0] for row in cursor.fetchall()]
        return len(tables) >= 3  # All three tables should exist
    except sqlite3.OperationalError:
        return False


@pytest.fixture
def db_connection():
    """Get direct SQLite connection for testing index usage."""
    db_path = get_database_path()

    # Skip tests if database file doesn't exist or is not initialized
    if not os.path.exists(db_path):
        pytest.skip(f"Database file {db_path} does not exist. Run migrations first.")

    conn = sqlite3.connect(db_path)

    if not check_database_initialized(conn):
        conn.close()
        pytest.skip("Database not properly initialized. Run migrations first.")

    yield conn
    conn.close()


def test_indexes_exist(db_connection):
    """Test that all performance indexes exist in the database."""
    cursor = db_connection.cursor()

    # Get all indexes
    cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%' ORDER BY name")
    indexes = [row[0] for row in cursor.fetchall()]

    expected_indexes = [
        "idx_dependency_dependent",
        "idx_dependency_task",
        "idx_goal_complete",
        "idx_task_goal_status",
        "idx_task_goal_status_created",
        "idx_task_owner",
        "idx_task_status",
    ]

    for index in expected_indexes:
        assert index in indexes, f"Index {index} not found in database"


def test_task_status_index_usage(db_connection):
    """Test that queries filtering by task status use the idx_task_status index."""
    cursor = db_connection.cursor()

    query = "SELECT * FROM tasks WHERE status = ?"
    cursor.execute(f"EXPLAIN QUERY PLAN {query}", ("AVAILABLE",))
    plan = cursor.fetchall()

    plan_text = " ".join(str(row) for row in plan)
    assert "idx_task_status" in plan_text, f"Index not used in query plan: {plan}"


def test_task_owner_index_usage(db_connection):
    """Test that queries filtering by task owner use the idx_task_owner index."""
    cursor = db_connection.cursor()

    query = "SELECT * FROM tasks WHERE owner = ?"
    cursor.execute(f"EXPLAIN QUERY PLAN {query}", ("test_owner",))
    plan = cursor.fetchall()

    plan_text = " ".join(str(row) for row in plan)
    assert "idx_task_owner" in plan_text, f"Index not used in query plan: {plan}"


def test_composite_index_usage(db_connection):
    """Test that composite queries use the idx_task_goal_status or idx_task_goal_status_created index."""
    cursor = db_connection.cursor()

    query = "SELECT * FROM tasks WHERE goal_id = ? AND status = ?"
    cursor.execute(f"EXPLAIN QUERY PLAN {query}", (1, "AVAILABLE"))
    plan = cursor.fetchall()

    plan_text = " ".join(str(row) for row in plan)
    assert "idx_task_goal_status" in plan_text or "idx_task_goal_status_created" in plan_text, (
        f"Composite index not used: {plan}"
    )


def test_goal_completion_index_usage(db_connection):
    """Test that queries filtering by goal completion use the idx_goal_complete index."""
    cursor = db_connection.cursor()

    query = "SELECT * FROM goals WHERE is_complete = ?"
    cursor.execute(f"EXPLAIN QUERY PLAN {query}", (0,))
    plan = cursor.fetchall()

    plan_text = " ".join(str(row) for row in plan)
    assert "idx_goal_complete" in plan_text, f"Index not used in query plan: {plan}"


def test_dependency_indexes_usage(db_connection):
    """Test that dependency queries use the appropriate dependency indexes."""
    cursor = db_connection.cursor()

    # Test dependent task index
    query = "SELECT * FROM task_dependencies WHERE dependent_task_id = ?"
    cursor.execute(f"EXPLAIN QUERY PLAN {query}", (1,))
    plan = cursor.fetchall()
    plan_text = " ".join(str(row) for row in plan)
    assert "idx_dependency_dependent" in plan_text, f"Dependent index not used: {plan}"

    # Test dependency task index
    query = "SELECT * FROM task_dependencies WHERE dependency_task_id = ?"
    cursor.execute(f"EXPLAIN QUERY PLAN {query}", (1,))
    plan = cursor.fetchall()
    plan_text = " ".join(str(row) for row in plan)
    assert "idx_dependency_task" in plan_text, f"Dependency index not used: {plan}"


def test_index_coverage():
    """Test that all required indexes from Task 2.1.1 are covered."""
    required_indexes = {
        "idx_task_status": "Task status index",
        "idx_task_owner": "Task owner index",
        "idx_task_goal_status": "Composite goal+status index",
        "idx_task_goal_status_created": "Composite goal+status+created index",
        "idx_goal_complete": "Goal completion index",
        "idx_dependency_dependent": "Dependency dependent task index",
        "idx_dependency_task": "Dependency task index",
    }

    db_path = get_database_path()

    # Skip tests if database file doesn't exist or is not initialized
    if not os.path.exists(db_path):
        pytest.skip(f"Database file {db_path} does not exist. Run migrations first.")

    conn = sqlite3.connect(db_path)

    if not check_database_initialized(conn):
        conn.close()
        pytest.skip("Database not properly initialized. Run migrations first.")

    cursor = conn.cursor()

    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'")
        existing_indexes = {row[0] for row in cursor.fetchall()}

        for index_name, description in required_indexes.items():
            assert index_name in existing_indexes, f"Missing required index: {index_name} ({description})"

    finally:
        conn.close()


@pytest.mark.performance
def test_query_performance_improvement():
    """
    Basic performance test to ensure queries benefit from indexes.
    This is a smoke test - detailed performance testing would require larger datasets.
    """
    from goaly_mcp.database import SessionLocal

    with SessionLocal() as session:
        # Test that basic queries execute quickly (smoke test)
        import time

        start = time.time()
        session.query(Task).filter(Task.status == TaskStatus.AVAILABLE).limit(10).all()
        status_query_time = time.time() - start

        start = time.time()
        session.query(Goal).filter(Goal.is_complete == False).limit(10).all()
        goal_query_time = time.time() - start

        # These should be very fast with indexes (< 10ms even on slow systems)
        assert status_query_time < 0.01, f"Status query too slow: {status_query_time}s"
        assert goal_query_time < 0.01, f"Goal query too slow: {goal_query_time}s"
