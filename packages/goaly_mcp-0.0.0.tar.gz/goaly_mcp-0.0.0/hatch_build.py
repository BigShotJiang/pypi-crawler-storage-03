"""
Custom hatchling build hook for frontend asset bundling.

This hook automatically builds the React frontend and copies the built assets
to the src/frontend_assets/ directory so they can be included in the wheel.
"""

import os
import shutil
from pathlib import Path
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class FrontendBuildHook(BuildHookInterface):
    """Build hook that compiles frontend assets before wheel creation."""

    PLUGIN_NAME = "frontend-build"

    def initialize(self, version: str, build_data: dict[str, Any]) -> None:
        """Initialize the build hook."""
        # Skip frontend build if explicitly requested
        if os.getenv("SKIP_FRONTEND_BUILD") == "true":
            print("ℹ️  Skipping frontend build (SKIP_FRONTEND_BUILD=true)")
            return

        # Frontend directory structure
        self.frontend_dir = Path(self.root) / "frontend"
        self.build_dir = self.frontend_dir / "build"
        self.target_dir = Path(self.root) / "src" / "goaly_mcp" / "frontend_assets"

        # Also check for frontend_build directory (from MANIFEST.in)
        self.alt_build_dir = Path(self.root) / "frontend_build"

        # Prompts directories
        self.prompts_source = Path(self.root) / "prompts"
        self.prompts_target = Path(self.root) / "src" / "goaly_mcp" / "prompts" / "data"

        # Only process assets for wheel builds
        if self.target_name != "wheel":
            print(f"ℹ️  Skipping asset processing for {self.target_name} build")
            return

        self._build_frontend()
        self._copy_prompts()

    def _build_frontend(self) -> None:
        """Copy existing frontend build assets to package location."""
        print("🔨 Processing frontend assets...")

        # Check if assets are already in the target location (pre-staged by CI)
        if self.target_dir.exists() and (self.target_dir / "index.html").exists():
            print("✅ Frontend assets already in package location")
            return

        # Check different possible locations for frontend build
        build_source = None

        if self.build_dir.exists():
            build_source = self.build_dir
            print("📁 Found frontend build in frontend/build/")
        elif self.alt_build_dir.exists():
            build_source = self.alt_build_dir
            print("📁 Found frontend build in frontend_build/")

        if build_source:
            try:
                self._copy_frontend_assets(build_source)
                print("✅ Frontend assets copied successfully")
                return
            except Exception as e:
                print(f"❌ Failed to copy frontend assets: {e}")
                # In CI, this should be a hard failure
                if os.getenv("CI") == "true":
                    raise RuntimeError(f"Frontend asset copy failed in CI: {e}")
                print("⚠️  Continuing without frontend assets...")
                return

        # In CI, the frontend should have been built in the same job
        if os.getenv("CI") == "true":
            print("❌ Error: Frontend build directory not found in CI!")
            print(f"Expected frontend build in: {self.build_dir}")
            print("The CI workflow should build frontend before building the wheel.")
            raise RuntimeError("Frontend build is required in CI")

        print("⚠️  Frontend build directory not found")
        print("💡 To include frontend assets:")
        print("   1. Run 'cd frontend && pnpm install && pnpm run build'")
        print("   2. Then rebuild the wheel with 'uv build'")
        print("⚠️  Continuing without frontend assets...")

    def _copy_frontend_assets(self, build_source: Path) -> None:
        """Copy built frontend assets to the package location."""
        # Save the original __init__.py content if it exists
        original_init_content = None
        init_file = self.target_dir / "__init__.py"
        if init_file.exists():
            original_init_content = init_file.read_text()

        # Remove existing target directory except __init__.py
        if self.target_dir.exists():
            for item in self.target_dir.iterdir():
                if item.name != "__init__.py":
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
        else:
            # Create target directory
            self.target_dir.mkdir(parents=True, exist_ok=True)

        # Restore or create __init__.py
        if original_init_content:
            init_file.write_text(original_init_content)
        elif not init_file.exists():
            init_file.write_text('"""Frontend assets for Goaly MCP dashboard."""\n')

        # Copy all build contents to target directory
        for item in build_source.iterdir():
            target_path = self.target_dir / item.name
            if item.is_file():
                shutil.copy2(item, target_path)
            elif item.is_dir():
                shutil.copytree(item, target_path)

        # Validate critical files exist
        critical_files = ["index.html", "static"]
        missing_files = [f for f in critical_files if not (self.target_dir / f).exists()]

        if missing_files:
            print(f"⚠️  Missing critical frontend files: {missing_files}")
        else:
            print(f"📁 Copied frontend assets to {self.target_dir}")

    def _copy_prompts(self) -> None:
        """Copy prompt templates to package location."""
        print("📝 Processing prompt templates...")

        if not self.prompts_source.exists():
            print("⚠️  Prompts directory not found at root level")
            return

        # Ensure target directory exists
        self.prompts_target.mkdir(parents=True, exist_ok=True)

        # Copy all .txt files from prompts/ to package location
        prompt_files = list(self.prompts_source.glob("*.txt"))

        if not prompt_files:
            print("⚠️  No .txt files found in prompts directory")
            return

        for prompt_file in prompt_files:
            target_file = self.prompts_target / prompt_file.name
            shutil.copy2(prompt_file, target_file)
            print(f"  ✅ Copied {prompt_file.name}")

        print(f"📁 Copied {len(prompt_files)} prompt templates to {self.prompts_target}")
