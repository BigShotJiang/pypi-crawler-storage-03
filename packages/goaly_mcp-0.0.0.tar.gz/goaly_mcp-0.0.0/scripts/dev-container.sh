#!/bin/bash
# Wrapper script for DevContainer CLI commands
# Provides a simple interface for common DevContainer operations

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Functions
log_info() { echo -e "${BLUE}ℹ️  $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }

# Check if devcontainer CLI is installed
check_cli() {
    if ! command -v devcontainer &> /dev/null; then
        log_error "DevContainer CLI not installed"
        echo "Install with: npm install -g @devcontainers/cli"
        echo "Or use npx: npx @devcontainers/cli"
        exit 1
    fi
}

# Show usage
usage() {
    cat << EOF
Usage: $0 [command] [options]

Commands:
    up              Start DevContainer
    exec [cmd]      Execute command in DevContainer (default: bash)
    logs            Show container logs
    stop            Stop DevContainer
    rebuild         Rebuild DevContainer
    status          Show DevContainer status
    help            Show this help message

Examples:
    $0 up                    # Start DevContainer
    $0 exec                  # Open bash shell
    $0 exec pytest          # Run tests
    $0 logs                 # Show logs
    $0 rebuild              # Rebuild container

EOF
}

# Get container status
get_status() {
    if docker ps --format "{{.Names}}" | grep -q "goaly-devcontainer"; then
        echo "running"
    else
        echo "stopped"
    fi
}

# Main command handling
case "${1:-help}" in
    up|start)
        check_cli
        log_info "Starting DevContainer..."
        export DEVCONTAINER_CLI=true
        if devcontainer up --workspace-folder . --remove-existing-container; then
            log_success "DevContainer started successfully"
            log_info "Access with: $0 exec"
        else
            log_error "Failed to start DevContainer"
            exit 1
        fi
        ;;

    exec)
        check_cli
        shift
        cmd="${*:-bash}"
        if [ "$(get_status)" != "running" ]; then
            log_error "DevContainer is not running"
            log_info "Start with: $0 up"
            exit 1
        fi
        devcontainer exec --workspace-folder . $cmd
        ;;

    logs)
        if [ "$(get_status)" != "running" ]; then
            log_warn "DevContainer is not running"
        fi
        docker logs goaly-devcontainer --tail 50 2>&1 || log_error "Container not found"
        ;;

    stop)
        log_info "Stopping DevContainer..."
        if docker stop goaly-devcontainer 2>/dev/null; then
            log_success "DevContainer stopped"
        else
            log_warn "DevContainer was not running"
        fi
        ;;

    rebuild)
        check_cli
        log_info "Rebuilding DevContainer..."
        export DEVCONTAINER_CLI=true
        if devcontainer up --workspace-folder . --remove-existing-container --build-no-cache; then
            log_success "DevContainer rebuilt successfully"
        else
            log_error "Failed to rebuild DevContainer"
            exit 1
        fi
        ;;

    status)
        check_cli
        log_info "DevContainer Status"
        echo "CLI Version: $(devcontainer --version 2>/dev/null || echo 'Not installed')"
        echo "Container: $(get_status)"
        if [ "$(get_status)" = "running" ]; then
            docker ps --filter "name=goaly-devcontainer" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
        fi
        ;;

    help|--help|-h)
        usage
        ;;

    *)
        log_error "Unknown command: $1"
        usage
        exit 1
        ;;
esac
