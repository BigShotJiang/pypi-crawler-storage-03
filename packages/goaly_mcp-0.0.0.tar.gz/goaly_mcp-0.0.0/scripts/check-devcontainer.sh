#!/bin/bash
# Script to check DevContainer CLI installation and environment

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Functions
log_info() { echo -e "${BLUE}ℹ️  $1${NC}"; }
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; }

echo -e "${BLUE}🔍 DevContainer Environment Check${NC}"
echo ""

# Check Node.js
echo -n "Node.js: "
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✅ Installed ($NODE_VERSION)${NC}"
else
    echo -e "${RED}❌ Not installed${NC}"
    echo "  Install from: https://nodejs.org/"
fi

# Check npm
echo -n "npm: "
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    echo -e "${GREEN}✅ Installed (v$NPM_VERSION)${NC}"
else
    echo -e "${RED}❌ Not installed${NC}"
fi

# Check DevContainer CLI
echo -n "DevContainer CLI: "
if command -v devcontainer &> /dev/null; then
    DC_VERSION=$(devcontainer --version)
    echo -e "${GREEN}✅ Installed (v$DC_VERSION)${NC}"
else
    echo -e "${YELLOW}⚠️  Not installed${NC}"
    echo ""
    echo "Install options:"
    echo "  1. Global install: npm install -g @devcontainers/cli"
    echo "  2. Use npx: npx @devcontainers/cli [command]"
    echo "  3. Add to project: npm install --save-dev @devcontainers/cli"
fi

# Check Docker
echo -n "Docker: "
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version | cut -d' ' -f3 | tr -d ',')
    echo -e "${GREEN}✅ Installed (v$DOCKER_VERSION)${NC}"

    # Check if Docker daemon is running
    echo -n "Docker daemon: "
    if docker info &> /dev/null; then
        echo -e "${GREEN}✅ Running${NC}"
    else
        echo -e "${RED}❌ Not running${NC}"
        echo "  Start Docker Desktop or Docker daemon"
    fi
else
    echo -e "${RED}❌ Not installed${NC}"
    echo "  Install from: https://docs.docker.com/get-docker/"
fi

# Check VS Code (optional)
echo -n "VS Code: "
if command -v code &> /dev/null; then
    echo -e "${GREEN}✅ Installed${NC}"

    # Check for Dev Containers extension
    echo -n "Dev Containers extension: "
    if code --list-extensions 2>/dev/null | grep -q "ms-vscode-remote.remote-containers"; then
        echo -e "${GREEN}✅ Installed${NC}"
    else
        echo -e "${YELLOW}⚠️  Not installed${NC}"
        echo "  Install with: code --install-extension ms-vscode-remote.remote-containers"
    fi
else
    echo -e "${YELLOW}⚠️  Not installed (optional)${NC}"
fi

# Check project files
echo ""
echo -e "${BLUE}📁 Project Files Check${NC}"

echo -n ".devcontainer/devcontainer.json: "
if [ -f ".devcontainer/devcontainer.json" ]; then
    echo -e "${GREEN}✅ Found${NC}"
else
    echo -e "${RED}❌ Not found${NC}"
fi

echo -n "Dockerfile.development: "
if [ -f "Dockerfile.development" ]; then
    echo -e "${GREEN}✅ Found${NC}"
else
    echo -e "${RED}❌ Not found${NC}"
fi

echo -n ".devcontainer/docker-entrypoint-dev.sh: "
if [ -f ".devcontainer/docker-entrypoint-dev.sh" ]; then
    echo -e "${GREEN}✅ Found${NC}"
else
    echo -e "${RED}❌ Not found${NC}"
fi

# Summary
echo ""
echo -e "${BLUE}📊 Summary${NC}"

if command -v devcontainer &> /dev/null && docker info &> /dev/null && [ -f ".devcontainer/devcontainer.json" ]; then
    echo -e "${GREEN}✅ Ready to use DevContainer CLI${NC}"
    echo ""
    echo "Quick start:"
    echo "  devcontainer up --workspace-folder ."
    echo "  devcontainer exec --workspace-folder . bash"
else
    echo -e "${YELLOW}⚠️  Some requirements are missing${NC}"
    echo "Fix the issues above before using DevContainer CLI"
fi
