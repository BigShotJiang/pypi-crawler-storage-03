# Docker Deployment Guide

This guide covers building and deploying Goaly MCP using Docker with multi-architecture support.

## Prerequisites

- Docker 20.10+ with BuildKit enabled
- Docker Buildx plugin

## Quick Start

### 1. Setup Docker Buildx (one-time setup)

```bash
just docker-setup-buildx
```

### 2. Build and Run Locally

```bash
# Build local image (single architecture, fast)
just docker-bake-local

# Run in HTTP transport mode on port 8000
just docker-run
```

Your Goaly MCP server will be available at:

- **Dashboard**: http://localhost:8000/dashboard
- **API**: http://localhost:8000/api/v1/
- **MCP Endpoint**: http://localhost:8000/mcp
- **API Docs**: http://localhost:8000/docs

## Build Commands

### Local Development

```bash
# Fast single-platform build for local development
just docker-bake-local

# Build with development dependencies
just docker-bake-dev
```

### Production Builds

```bash
# Build multi-platform image (AMD64 + ARM64)
just docker-bake

# Build and push to registry
just docker-bake-push

# Build specific version
VERSION=1.0.0 just docker-bake-version
```

### Run Commands

```bash
# Run with default settings
just docker-run

# Run with custom environment file
just docker-run-env .env.production
```

## Multi-Architecture Support

The Docker Bake configuration supports building for:

- `linux/amd64` (Intel/AMD x86_64)
- `linux/arm64` (Apple Silicon, ARM servers)

## Environment Variables

The Docker image supports these environment variables:

| Variable                   | Default                               | Description                    |
| -------------------------- | ------------------------------------- | ------------------------------ |
| `GOALY_HOST`               | `0.0.0.0`                             | Server bind address            |
| `GOALY_PORT`               | `8000`                                | Server port                    |
| `GOALY_DEBUG`              | `false`                               | Enable debug mode              |
| `DATABASE_URL`             | `sqlite+aiosqlite:///./data/goaly.db` | Database connection string     |
| `GOALY_MCP_SERVER_API_KEY` | `""`                                  | MCP API key for authentication |

## Docker Compose

For production deployments with external services:

```bash
# Start all services
just docker-up

# View logs
just docker-logs

# Stop services
just docker-down
```

## Registry Configuration

By default, images are built for GitHub Container Registry. To use a different registry:

```bash
# Build for Docker Hub
REGISTRY=docker.io NAMESPACE=yourusername just docker-bake-push

# Build for private registry
REGISTRY=registry.company.com NAMESPACE=myteam just docker-bake-push
```

## Advanced Usage

### Custom Build Platforms

```bash
# Build for specific platforms
PLATFORMS=linux/amd64,linux/arm64,linux/arm/v7 just docker-bake
```

### Using Docker Bake Directly

```bash
# View available targets
docker buildx bake --print

# Build specific target
docker buildx bake production

# Build with custom variables
docker buildx bake --set="*.args.VERSION=1.2.3" production
```

## Troubleshooting

### BuildKit Not Enabled

```bash
export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1
```

### Multi-platform Build Issues

```bash
# Recreate buildx instance
docker buildx rm goaly-builder
just docker-setup-buildx
```

### Permission Issues

The container runs as a non-root user (`goaly:goaly`). Ensure mounted volumes have appropriate permissions:

```bash
# Create data directory with correct permissions
mkdir -p data
chmod 755 data
```
