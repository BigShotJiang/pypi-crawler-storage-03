#!/bin/bash
set -e

# Enhanced Docker entrypoint script for Goaly MCP
# Handles database migrations, environment validation, and application startup

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}ℹ️  [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

log_warn() {
    echo -e "${YELLOW}⚠️  [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

log_error() {
    echo -e "${RED}❌ [$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

# Signal handlers for graceful shutdown
shutdown() {
    log_info "Received shutdown signal, cleaning up..."
    if [ -n "$APP_PID" ]; then
        kill -TERM "$APP_PID" 2>/dev/null || true
        wait "$APP_PID" 2>/dev/null || true
    fi
    log_success "Shutdown complete"
    exit 0
}

trap shutdown SIGTERM SIGINT

log_info "Starting Goaly MCP Server..."
log_info "Environment: ${GOALY_DEBUG:-false} debug mode, Python $(python --version | cut -d' ' -f2)"

# Environment validation
log_info "Validating environment..."

# Check required environment variables
if [ -z "$DATABASE_URL" ]; then
    log_error "DATABASE_URL environment variable is required"
    exit 1
fi

# Check if we're in development mode
if [ "${GOALY_DEV_MODE:-false}" = "true" ]; then
    log_info "Running in development mode"
    SKIP_MIGRATIONS=${SKIP_MIGRATIONS:-false}
else
    log_info "Running in production mode"
    SKIP_MIGRATIONS=${SKIP_MIGRATIONS:-false}
fi

# Database connectivity check removed - migrations will fail if DB is not accessible
# This simplifies the entrypoint and avoids issues with async driver detection

# Run database migrations
if [ "${SKIP_MIGRATIONS:-false}" != "true" ]; then
    log_info "Running database migrations..."
    # In Docker, we use the virtual environment directly without uv run
    if goaly-db-upgrade; then
        log_success "Database migrations completed"
    else
        log_error "Database migrations failed"
        exit 1
    fi
else
    log_info "Database migrations skipped"
fi

# Application startup
log_info "Starting Goaly MCP application..."
log_info "Server will be available at ${GOALY_HOST:-0.0.0.0}:${GOALY_PORT:-8000}"

# Development vs Production startup
if [ "${GOALY_DEV_MODE:-false}" = "true" ] && [ "${UVICORN_RELOAD:-false}" = "true" ]; then
    log_info "Starting in development mode with auto-reload"
    exec uvicorn goaly_mcp.main:app \
        --host "${GOALY_HOST:-0.0.0.0}" \
        --port "${GOALY_PORT:-8000}" \
        --reload \
        --reload-dir /app/src \
        --log-level "${LOG_LEVEL:-debug}" &
    APP_PID=$!
else
    log_info "Starting in production mode"
    # In Docker, we use the virtual environment directly without uv run
    exec goaly-server &
    APP_PID=$!
fi

# Wait for the application process
wait $APP_PID
