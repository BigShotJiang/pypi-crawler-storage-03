# GitHub Container Registry (GHCR) Permissions Setup

This document provides step-by-step instructions for configuring repository permissions and settings to enable GitHub Container Registry publishing for the `toolprint/goaly-mcp` project.

## Overview

The repository is configured to automatically build and publish Docker images to GitHub Container Registry (`ghcr.io`) using GitHub Actions. This requires specific permissions and settings to be configured in the GitHub repository.

## Prerequisites

- Repository owner or admin access to `toolprint/goaly-mcp`
- GitHub Actions enabled on the repository
- Understanding of container registry security implications

## Required Repository Settings

### 1. Actions Permissions

Navigate to: **Settings → Actions → General**

#### Workflow permissions

- **✅ REQUIRED**: Select "Read and write permissions"
- **Alternative**: Select "Read repository contents and packages permissions" (minimum required)
- **✅ REQUIRED**: Check "Allow GitHub Actions to create and approve pull requests" (if using automated PRs)

#### Actions permissions

- **✅ REQUIRED**: Allow all actions and reusable workflows
- **Alternative**: Allow select actions (if using restricted policy, ensure the following actions are allowed):
  - `actions/checkout@v4`
  - `docker/setup-buildx-action@v3`
  - `docker/login-action@v3`
  - `docker/metadata-action@v5`
  - `docker/bake-action@v4`
  - `aquasecurity/trivy-action@master`
  - `github/codeql-action/upload-sarif@v2`

### 2. Package Permissions

Navigate to: **Settings → Packages**

#### Package creation

- **✅ REQUIRED**: Enable "Public" packages (recommended for open source)
- **Alternative**: Enable "Private" packages (for internal use only)

#### Package permissions inheritance

- **✅ REQUIRED**: Check "Inherit access from source repository"
- This ensures that repository collaborators can manage packages

### 3. Security Settings

Navigate to: **Settings → Security & analysis**

#### Dependency graph

- **✅ RECOMMENDED**: Enable "Dependency graph"

#### Dependabot alerts

- **✅ RECOMMENDED**: Enable "Dependabot alerts"

#### Code scanning

- **✅ RECOMMENDED**: Enable "Code scanning" (automated via workflow)

#### Secret scanning

- **✅ RECOMMENDED**: Enable "Secret scanning"

## GitHub Actions Secrets Configuration

### Repository Secrets (if needed)

Navigate to: **Settings → Secrets and variables → Actions**

The current workflow uses `GITHUB_TOKEN` which is automatically provided. However, you may need additional secrets for:

#### Optional secrets:

- `DOCKER_HUB_TOKEN` - If also publishing to Docker Hub
- `SNYK_TOKEN` - For additional security scanning
- `SLACK_WEBHOOK` - For deployment notifications

**Note**: The current workflow does NOT require additional secrets beyond `GITHUB_TOKEN`.

## Environment Configuration

### Production Environment (Optional but Recommended)

Navigate to: **Settings → Environments**

1. Create environment named `production`
1. Configure protection rules:
   - **✅ RECOMMENDED**: Require reviewers (1-2 reviewers)
   - **✅ RECOMMENDED**: Wait timer: 0 minutes
   - **✅ RECOMMENDED**: Restrict to protected branches: `main`

## Package Visibility Settings

### After First Package Publication

Once the first package is published, configure visibility:

1. Navigate to: **Package → goaly-mcp** (from repository main page)
1. Click "Package settings"
1. Under "Danger Zone":
   - **✅ RECOMMENDED**: Set visibility to "Public" (for open source)
   - **Alternative**: Keep "Private" (for internal projects)

### Package Access Control

Configure who can access the package:

1. In package settings, scroll to "Manage Actions access"
1. **✅ REQUIRED**: Ensure the repository `toolprint/goaly-mcp` has "Write" access
1. **✅ RECOMMENDED**: Add team/organization access as needed

## Branch Protection Rules

Navigate to: **Settings → Branches**

### Main Branch Protection

Configure protection for `main` branch:

- **✅ RECOMMENDED**: Require a pull request before merging
- **✅ RECOMMENDED**: Require status checks to pass before merging:
  - `build` (Docker build job)
  - `security-scan` (Trivy security scan)
  - `test-image` (Container startup test)
- **✅ RECOMMENDED**: Require branches to be up to date before merging
- **✅ RECOMMENDED**: Require conversation resolution before merging
- **Optional**: Require signed commits

## Verification Steps

After configuring the above settings, verify the setup:

### 1. Test Manual Workflow Trigger

1. Navigate to: **Actions → Build and Publish Docker Images**
1. Click "Run workflow"
1. Select branch: `main`
1. Enable "Push images to registry": `true`
1. Build target: `production`
1. Click "Run workflow"

### 2. Verify Permissions in Workflow Run

Check the workflow run logs for:

- ✅ Successful checkout
- ✅ Successful Docker login to `ghcr.io`
- ✅ Successful image build
- ✅ Successful image push
- ✅ Successful security scan
- ✅ Successful container test

### 3. Verify Package Publication

1. Navigate to repository main page
1. Check "Packages" section in right sidebar
1. Verify `goaly-mcp` package is listed
1. Click on package to verify:
   - Multiple tags are available (`latest`, version tags, SHA tags)
   - Package is publicly accessible (if configured)
   - Installation instructions are correct

### 4. Test Image Pull

Run locally to verify public access:

```bash
# Test pulling the published image
docker pull ghcr.io/toolprint/goaly-mcp:latest

# Test running the image
docker run --rm ghcr.io/toolprint/goaly-mcp:latest --version
```

## Troubleshooting Common Issues

### Permission Denied During Docker Push

**Symptoms**: `denied: permission_denied` error during push
**Solution**:

1. Verify "Read and write permissions" is enabled in Actions settings
1. Ensure package permissions inheritance is enabled
1. Check that GITHUB_TOKEN has packages:write scope

### Package Not Visible

**Symptoms**: Package exists but not visible publicly
**Solution**:

1. Navigate to package settings
1. Change visibility from "Private" to "Public"
1. Ensure "Inherit access from source repository" is enabled

### Security Scan Failures

**Symptoms**: Trivy scan fails or reports vulnerabilities
**Solution**:

1. Review security scan results in the Security tab
1. Update base image or dependencies to address vulnerabilities
1. Consider adding vulnerability allowlist if needed

### Build Cache Issues

**Symptoms**: Slow builds or cache misses
**Solution**:

1. Verify GitHub Actions cache is enabled
1. Check cache scope configuration in workflow
1. Consider increasing cache retention period

## Security Considerations

### Container Image Security

1. **Base Image**: Use minimal, security-hardened base images
1. **Scanning**: Automated Trivy scanning is configured
1. **Updates**: Regularly update dependencies and base images
1. **Secrets**: Never include secrets in container images

### Access Control

1. **Least Privilege**: Grant minimum required permissions
1. **Review Access**: Regularly review who has package access
1. **Audit Logs**: Monitor package access logs
1. **Branch Protection**: Protect main branch to prevent unauthorized changes

### Package Management

1. **Versioning**: Use semantic versioning for releases
1. **Retention**: Configure package retention policies
1. **Cleanup**: Remove old/unused package versions periodically
1. **Documentation**: Keep package documentation up-to-date

## Monitoring and Maintenance

### Regular Tasks

1. **Weekly**: Review failed workflow runs
1. **Monthly**: Update workflow dependencies (actions versions)
1. **Quarterly**: Review and update security scanning configuration
1. **As needed**: Update base images and dependencies

### Alerts and Notifications

Consider setting up:

1. GitHub notifications for failed workflows
1. Security alerts for vulnerability discoveries
1. Package download monitoring
1. Dependabot alerts for dependency updates

## Additional Resources

- [GitHub Container Registry Documentation](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry)
- [GitHub Actions Permissions](https://docs.github.com/en/actions/security-guides/automatic-token-authentication)
- [Docker Build and Push Action](https://github.com/docker/build-push-action)
- [Trivy Security Scanner](https://aquasecurity.github.io/trivy/)

______________________________________________________________________

**Note**: This documentation is specific to the `toolprint/goaly-mcp` repository configuration. Adjust settings based on your organization's security policies and requirements.
