# Docker Infrastructure Improvements

## Overview

This document outlines the comprehensive Docker infrastructure improvements for the Goaly MCP project, inspired by patterns from the documount Node.js project. The improvements focus on development experience, production reliability, and workflow simplification.

## Current State Analysis

### Existing Docker Setup

- **Dockerfile**: Production runtime container using pre-built wheels
- **Dockerfile.development**: Development container with hot-reload capabilities
- **docker-compose.dev.yml**: Development setup with SQLite and hot-reload
- **docker-compose.yml**: Production setup with PostgreSQL and Nginx

### Identified Gaps

1. **Development Experience**: No hot-reload, limited debugging support
1. **Production Hardening**: Missing tini init system, basic health checks
1. **Workflow Complexity**: Overly complex justfile commands
1. **Environment Inconsistency**: Poor dev/prod parity

## Implementation Plan

### Phase 1: Core Development Experience

#### 1.1 Development Dockerfile (`Dockerfile.development`)

**Purpose**: Enable hot-reload development with debugging capabilities

**Key Features**:

- Python 3.12 base with development dependencies
- Source code volume mounting for hot-reload
- Python debugger port (5678) exposure
- FastAPI auto-reload mode enabled
- uv for fast dependency management

**Ports Exposed**:

- 8000: FastAPI application
- 5678: Python debugger (debugpy)

#### 1.2 Development Compose (`docker-compose.dev.yml`)

**Purpose**: Streamlined development environment with volume mounts

**Key Features**:

- Source code volume mounts for hot-reload
- Debug port exposure
- Interactive terminals (stdin_open, tty)
- Development environment variables
- SQLite for simplified development

**Volume Strategy**:

- Mount `./src:/app/src:ro` for source code
- Mount `./tests:/app/tests:ro` for tests
- Exclude node_modules equivalent patterns

#### 1.3 Enhanced Development Workflow

**Commands Added**:

- `just docker-dev`: Start development environment
- `just docker-debug`: Start with debugger attached
- `just docker-logs-dev`: View development logs
- `just docker-shell-dev`: Interactive shell access

### Phase 2: Production Hardening

#### 2.1 Tini Init System Integration

**Implementation**: Add tini to all production Dockerfiles

```dockerfile
# Install tini for proper signal handling
RUN apt-get update && apt-get install -y tini && rm -rf /var/lib/apt/lists/*

# Use tini as entrypoint
ENTRYPOINT ["/usr/bin/tini", "--"]
```

#### 2.2 Enhanced Health Checks

**Current**: Basic curl to health endpoint
**Improved**: Multi-layer health validation

```dockerfile
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD curl -f http://localhost:8000/health && \
        python -c "import sys; sys.exit(0 if __import__('psutil').cpu_percent() < 90 else 1)"
```

#### 2.3 Resource Management

**docker-compose.yml improvements**:

- CPU limits and reservations
- Memory limits and reservations
- Restart policies
- Dependency health checks

```yaml
deploy:
  resources:
    limits:
      cpus: '2'
      memory: 1G
    reservations:
      cpus: '0.5'
      memory: 256M
```

### Phase 3: Workflow Optimization

#### 3.1 Justfile Command Standardization

**Pattern**: Match documount's streamlined approach

**Before**:

```bash
just docker-build-goaly && just docker-run-goaly-dev
```

**After**:

```bash
just docker-dev
```

#### 3.2 Build Process Optimization

**Multi-stage improvements**:

- Better layer caching for Python dependencies
- Optimized wheel building strategy
- Reduced image sizes through layer consolidation

### Phase 4: Advanced Features

#### 4.1 Monitoring and Observability

- Metrics endpoint exposure (port 9090)
- Structured logging configuration
- Performance monitoring integration

#### 4.2 Security Enhancements

- Non-root user validation
- Minimal attack surface
- Security scanning integration

## File Modifications Required

### New Files

1. `Dockerfile.development` - Hot-reload development container
1. `docker-compose.dev.yml` - Enhanced development environment

### Modified Files

1. `Dockerfile` - Add tini, enhance health checks
1. `docker-compose.yml` - Resource limits, health checks
1. `just/docker.just` - Streamlined commands
1. `docker-entrypoint.sh` - Enhanced startup sequence

## Migration Strategy

### Step 1: Parallel Development Environment

- Create new development files alongside existing ones
- Test new workflow without disrupting current setup
- Validate hot-reload and debugging functionality

### Step 2: Production Hardening

- Update production Dockerfiles incrementally
- Add tini and enhanced health checks
- Test in staging environment

### Step 3: Workflow Migration

- Update justfile commands
- Document new workflows
- Train team on new processes

### Step 4: Cleanup

- Remove deprecated files and commands
- Update CI/CD pipelines
- Complete documentation

## Testing Strategy

### Development Environment Validation

1. Source code changes trigger container reload
1. Python debugger attachment works correctly
1. Database migrations run successfully
1. Frontend assets are served properly

### Production Environment Validation

1. Health checks function correctly
1. Resource limits are enforced
1. Signal handling works properly
1. Container restarts gracefully

### Workflow Testing

1. New justfile commands work as expected
1. Build times are improved
1. Developer onboarding is simplified
1. CI/CD integration functions properly

## Success Metrics

### Development Experience

- **Hot-reload time**: \< 2 seconds for code changes
- **Debug setup time**: \< 30 seconds to attach debugger
- **Container startup**: \< 10 seconds for development environment

### Production Reliability

- **Health check response**: \< 1 second average
- **Container restart time**: \< 30 seconds
- **Resource utilization**: Within defined limits

### Workflow Efficiency

- **Build time reduction**: 20-30% improvement
- **Command simplification**: 50% fewer steps for common tasks
- **Documentation clarity**: Single source of truth

## Rollback Plan

### Development Environment

- Keep existing docker-compose.dev.yml as fallback
- Maintain current Dockerfile until validation complete
- Document rollback procedures

### Production Environment

- Blue-green deployment strategy
- Database migration rollback procedures
- Container image versioning strategy

## Future Enhancements

### Advanced Development Features

- Multi-service debugging
- Hot-reload for configuration changes
- Integrated testing environment

### Production Optimizations

- Auto-scaling configuration
- Advanced monitoring integration
- Performance optimization automation

### Workflow Improvements

- IDE integration for debugging
- Automated testing pipelines
- Container security scanning

## Conclusion

These Docker improvements will significantly enhance both development experience and production reliability. The phased approach ensures minimal disruption while delivering immediate benefits. The standardized workflow patterns borrowed from documount will improve consistency and reduce cognitive load for developers.

The implementation prioritizes high-impact, low-risk changes first, allowing for iterative improvement and validation at each step.
