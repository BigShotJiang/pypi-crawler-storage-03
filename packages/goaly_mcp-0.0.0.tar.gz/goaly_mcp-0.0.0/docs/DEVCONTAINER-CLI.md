# DevContainer CLI Guide

This guide covers using the DevContainer CLI for the primary development environment of Goaly MCP.

## Overview

DevContainer CLI provides a standardized way to create and manage development containers, offering better IDE integration and consistency across different development environments.

## Prerequisites

### Required

- Docker Desktop or Docker Engine
- Node.js and npm (for installing DevContainer CLI)

### Optional

- VS Code with Dev Containers extension
- Just command runner

### Installation

```bash
# Install DevContainer CLI globally
npm install -g @devcontainers/cli

# Verify installation
devcontainer --version

# Check all prerequisites
./scripts/check-devcontainer.sh
```

## Basic Usage

### Starting DevContainer

```bash
# Using just commands (recommended)
just dc-up

# Using DevContainer CLI directly
devcontainer up --workspace-folder .

# Using wrapper script
./scripts/dev-container.sh up
```

### Accessing DevContainer

```bash
# Open shell (using just)
just dc-exec

# Open shell (using CLI)
devcontainer exec --workspace-folder . bash

# Run specific command
just dc-run pytest
devcontainer exec --workspace-folder . pytest
```

### Stopping DevContainer

```bash
# Stop container
just dc-stop
docker stop goaly-devcontainer

# Stop and remove container
just dc-down
```

## Common Workflows

### Development Workflow

```bash
# 1. Start DevContainer
just dc-up

# 2. Open shell for development
just dc-exec

# 3. Run tests as needed
just dc-test

# 4. Check logs if issues arise
just dc-logs
```

### Debugging Workflow

```bash
# 1. Start DevContainer
just dc-up

# 2. In VS Code, attach to running container
# Use "Python: Remote Attach" configuration

# 3. Set breakpoints and debug
```

### Database Management

```bash
# Run migrations
just dc-migrate

# Create new migration
just dc-migration "add user preferences"

# Access database shell (if using PostgreSQL)
just dc-run psql -U goaly -d goaly_db
```

## Advanced Usage

### Rebuilding Container

```bash
# Rebuild with cache
just dc-rebuild

# Rebuild without cache
devcontainer up --workspace-folder . --remove-existing-container --build-no-cache
```

### Using with Docker Compose

You can configure DevContainer to use docker-compose by uncommenting lines in `.devcontainer/devcontainer.json`:

```json
// Uncomment these lines to use docker-compose
"dockerComposeFile": "../docker-compose.dev.yml",
"service": "goaly-mcp-dev",
"shutdownAction": "stopCompose",
```

### Environment Variables

Set environment variables for DevContainer:

```bash
# Set for current session
export DEBUGPY_ENABLED=true
just dc-up

# Or modify .devcontainer/devcontainer.json
"containerEnv": {
    "DEBUGPY_ENABLED": "true"
}
```

## Comparison with Docker Compose

### DevContainer CLI Advantages

- **Standardized**: Uses devcontainer.json specification
- **IDE Integration**: Better support for VS Code and other IDEs
- **Simpler Commands**: Cleaner interface for common tasks
- **Cloud Ready**: Works with GitHub Codespaces, etc.
- **Post-Create Scripts**: Reliable setup automation

### Docker Compose Advantages

- **Multi-Service**: Better for complex service orchestration
- **Production-Like**: Closer to production environment
- **Flexibility**: More control over networking and volumes
- **Standard Docker**: No additional tools needed

## Troubleshooting

### Container Won't Start

```bash
# Check logs
docker logs goaly-devcontainer

# Remove and rebuild
just dc-down
just dc-rebuild
```

### Module Not Found Errors

```bash
# Reinstall package in editable mode
just dc-install

# Verify installation
just dc-pyinfo
```

### Permission Issues

```bash
# Check file ownership
just dc-run ls -la /app/src

# Fix permissions (if needed)
just dc-run chown -R goaly:goaly /app/src
```

### Port Already in Use

```bash
# Find process using port
lsof -i :8000

# Kill process or use different port
GOALY_PORT=8001 just dc-up
```

## Tips and Best Practices

1. **Use Just Commands**: The just recipes provide a consistent interface
1. **Check Status First**: Run `just dc-info` before starting
1. **Clean Rebuilds**: Use `just dc-rebuild` when adding dependencies
1. **Switch Environments**: Use `./scripts/switch-dev-env.sh` to switch cleanly
1. **Volume Management**: Be careful with `just dc-clean` - it removes data

## Integration with CI/CD

DevContainer CLI can be used in CI/CD pipelines:

```yaml
# Example GitHub Actions workflow
- name: Build and test in DevContainer
  run: |
    npm install -g @devcontainers/cli
    devcontainer up --workspace-folder .
    devcontainer exec --workspace-folder . pytest
```

## Available Commands Reference

Run `just dc-help` to see all available DevContainer commands:

- **Management**: dc-up, dc-stop, dc-down, dc-rebuild
- **Development**: dc-exec, dc-run, dc-test, dc-lint
- **Database**: dc-migrate, dc-migration
- **Utilities**: dc-logs, dc-info, dc-pyinfo, dc-clean

## Further Reading

- [DevContainer Specification](https://containers.dev/)
- [DevContainer CLI Documentation](https://github.com/devcontainers/cli)
- [VS Code Dev Containers](https://code.visualstudio.com/docs/devcontainers/containers)
