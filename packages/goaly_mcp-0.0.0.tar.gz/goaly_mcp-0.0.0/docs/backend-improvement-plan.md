# TaskMaster MCP Backend Improvement Plan

## Executive Summary

**Project:** TaskMaster MCP - Hierarchical Goal and Task Management System
**Timeline:** 6 weeks (August 7 - September 18, 2025)
**Total Effort:** ~120-150 hours across 3 phases
**Target:** Production-ready backend with improved performance, maintainability, and reliability

### Priority Overview

| Phase       | Focus Area              | Timeline  | Effort      | Impact |
| ----------- | ----------------------- | --------- | ----------- | ------ |
| **Phase 1** | Critical Fixes          | Weeks 1-2 | 40-50 hours | HIGH   |
| **Phase 2** | Performance & Quality   | Weeks 3-4 | 40-50 hours | MEDIUM |
| **Phase 3** | Testing & Documentation | Weeks 5-6 | 40-50 hours | MEDIUM |

### Success Metrics

- **Phase 1:** Zero SQLAlchemy session errors, consistent async patterns
- **Phase 2:** >50% query performance improvement, \<90% code duplication
- **Phase 3:** >90% test coverage, comprehensive documentation

______________________________________________________________________

## Phase 1: Critical Fixes (Weeks 1-2)

### 1.1 Session Management Issues (Priority: CRITICAL)

**Problem:** SQLAlchemy detached instance errors throughout the application causing data corruption and connection leaks.

**Files Affected:**

- `/Users/brian/workspace/onegrep/taskmaster-mcp/src/repositories/goals.py`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/src/repositories/tasks.py`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/src/api/tasks.py`

**Issues Identified:**

1. **Detached Object Returns** (Lines 15-22 in goals.py)
1. **Inconsistent Session Patterns** (Lines 93-147 in tasks.py)
1. **Manual Session Management** scattered across repositories

**Implementation Tasks:**

#### Task 1.1.1: Create Session Management Decorator (8 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/database_session.py`

```python
from contextlib import contextmanager
from functools import wraps
from typing import Any, Callable, Generator, TypeVar
from sqlalchemy.orm import Session
from .database import SessionLocal

F = TypeVar('F', bound=Callable[..., Any])

@contextmanager
def managed_session() -> Generator[Session, None, None]:
    """Context manager for database sessions with automatic cleanup"""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

def with_session(func: F) -> F:
    """Decorator to inject database session and handle session lifecycle"""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        with managed_session() as session:
            # Inject session as first argument after self
            result = func(self, session, *args, **kwargs)

            # If result is a SQLAlchemy object, detach it from session
            if hasattr(result, '_sa_instance_state'):
                session.expunge(result)
            elif isinstance(result, list):
                for item in result:
                    if hasattr(item, '_sa_instance_state'):
                        session.expunge(item)

            return result
    return wrapper

def with_session_list(func: F) -> F:
    """Decorator for functions returning lists of SQLAlchemy objects"""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        with managed_session() as session:
            result = func(self, session, *args, **kwargs)

            # Detach all objects from session
            if isinstance(result, list):
                for item in result:
                    if hasattr(item, '_sa_instance_state'):
                        session.expunge(item)

            return result
    return wrapper
```

#### Task 1.1.2: Refactor GoalRepository (4 hours)

**File:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/repositories/goals.py`

**Before (Lines 15-22):**

```python
def create(self, description: str) -> Goal:
    """Create a new goal"""
    with SessionLocal() as session:
        goal = Goal(description=description)
        session.add(goal)
        session.commit()
        session.refresh(goal)
        return goal  # ❌ Session-bound object
```

**After:**

```python
from ..database_session import with_session

@with_session
def create(self, session: Session, description: str) -> Goal:
    """Create a new goal"""
    goal = Goal(description=description)
    session.add(goal)
    session.flush()  # Get ID without committing
    session.refresh(goal)
    return goal  # ✅ Will be detached by decorator

@with_session
def get_by_id(self, session: Session, goal_id: int) -> Goal | None:
    """Get goal by ID"""
    result = session.execute(select(Goal).where(Goal.id == goal_id))
    return result.scalars().first()

@with_session_list
def list_all(self, session: Session, completed_only: bool = False, incomplete_only: bool = False) -> list[Goal]:
    """List all goals with optional filtering"""
    query = select(Goal).options(selectinload(Goal.tasks))

    if completed_only:
        query = query.where(Goal.is_complete == True)
    elif incomplete_only:
        query = query.where(Goal.is_complete == False)

    result = session.execute(query.order_by(Goal.created_at.desc()))
    return list(result.scalars().all())

@with_session
def update(self, session: Session, goal_id: int, **kwargs) -> Goal | None:
    """Update goal by ID"""
    result = session.execute(select(Goal).where(Goal.id == goal_id))
    goal = result.scalars().first()

    if not goal:
        return None

    for key, value in kwargs.items():
        if hasattr(goal, key):
            setattr(goal, key, value)

    session.flush()
    session.refresh(goal)
    return goal

@with_session
def delete(self, session: Session, goal_id: int) -> bool:
    """Delete goal by ID"""
    result = session.execute(select(Goal).where(Goal.id == goal_id))
    goal = result.scalars().first()

    if not goal:
        return False

    session.delete(goal)
    return True
```

#### Task 1.1.3: Refactor TaskRepository (6 hours)

**File:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/repositories/tasks.py`

**Key Changes:**

1. Remove manual session management (lines 24-34, 95-147)
1. Apply `@with_session` decorator to all methods
1. Remove manual `session.expunge()` calls (lines 144-146)
1. Fix the problematic update method that manually manages session state

**Critical Fix for Update Method:**

```python
@with_session
def update(self, session: Session, task_id: int, **kwargs) -> Task | None:
    """Update task by ID"""
    result = session.execute(select(Task).where(Task.id == task_id))
    task = result.scalars().first()

    if not task:
        return None

    # Handle status updates with validation
    if "status" in kwargs:
        try:
            new_status = TaskStatus(kwargs["status"])

            # Validate owner requirements
            if new_status in [TaskStatus.OWNED, TaskStatus.COMPLETED]:
                if not task.owner and "owner" not in kwargs:
                    raise ValueError(f"Owner is required for status {kwargs['status']}")
            elif new_status not in [TaskStatus.OWNED, TaskStatus.COMPLETED]:
                kwargs["owner"] = None  # Clear owner for other statuses

            kwargs["status"] = new_status
        except ValueError as ve:
            raise ValueError(
                f"Invalid status: {kwargs['status']}. Valid statuses: {[s.value for s in TaskStatus]}"
            ) from ve

    for key, value in kwargs.items():
        if hasattr(task, key):
            setattr(task, key, value)

    session.flush()
    session.refresh(task)

    # Update blocking status for dependent tasks if status changed
    if "status" in kwargs:
        self._update_task_blocking_status(session, task_id)

    return task  # ✅ Will be detached by decorator

def _update_task_blocking_status(self, session: Session, task_id: int):
    """Update the blocking status of all task dependencies for a given task"""
    dependencies = session.execute(select(TaskDependency).where(TaskDependency.dependency_task_id == task_id))

    task_result = session.execute(select(Task).where(Task.id == task_id))
    task = task_result.scalars().first()

    if not task:
        return

    is_blocking = task.status not in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]

    for dependency in dependencies.scalars().all():
        dependency.is_blocked = is_blocking
```

**Effort:** 4 days (32 hours)
**Dependencies:** None
**Testing:** Unit tests for each repository method

### 1.2 Async/Sync Consistency (Priority: HIGH)

**Problem:** Mixed async/sync patterns causing runtime errors and poor performance.

**Files Affected:**

- `/Users/brian/workspace/onegrep/taskmaster-mcp/src/mcp_tools.py`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/src/api/sse.py`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/src/database.py`

#### Task 1.2.1: Fix SSE Notification Pattern (6 hours)

**File:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/mcp_tools.py`

**Problem (Lines 17-35):** Complex event loop handling for SSE notifications.

**Before:**

```python
def send_sse_notification(coro):
    """Send SSE notification from sync context"""
    try:
        # Try to get existing event loop
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If loop is already running, schedule as task
            task = asyncio.create_task(coro)
            # Store reference to prevent garbage collection
            task.add_done_callback(lambda t: None)
        else:
            # Run in new loop
            loop.run_until_complete(coro)
    except RuntimeError:
        # No event loop, create new one
        asyncio.run(coro)
    except Exception as e:
        print(f"Failed to send SSE notification: {e}")
```

**After:**

```python
import threading
from concurrent.futures import ThreadPoolExecutor
from queue import Queue
import logging

logger = logging.getLogger(__name__)

class SSENotificationQueue:
    """Thread-safe queue for SSE notifications from sync context"""

    def __init__(self):
        self.queue = Queue()
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="sse-notifier")
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker, daemon=True)
        self._worker_thread.start()

    def _worker(self):
        """Background worker to process SSE notifications"""
        while self._running:
            try:
                coro = self.queue.get(timeout=1.0)
                if coro is None:  # Shutdown signal
                    break
                asyncio.run(coro)
            except Exception as e:
                logger.error(f"Failed to send SSE notification: {e}")

    def notify(self, coro):
        """Queue an SSE notification coroutine"""
        if self._running:
            self.queue.put(coro)

    def shutdown(self):
        """Shutdown the notification worker"""
        self._running = False
        self.queue.put(None)
        self._worker_thread.join()

# Global notification queue
sse_queue = SSENotificationQueue()

def send_sse_notification(coro):
    """Send SSE notification from sync context"""
    sse_queue.notify(coro)
```

#### Task 1.2.2: Standardize Database Operations (4 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/database_async.py`

```python
"""
Async database utilities for future async endpoints
"""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from .config import settings
import os

# Convert sync DATABASE_URL to async
RAW_DATABASE_URL = os.getenv("DATABASE_URL")

if not RAW_DATABASE_URL:
    ASYNC_DATABASE_URL = "sqlite+aiosqlite:///./taskmaster.db"
elif RAW_DATABASE_URL.startswith("sqlite"):
    if not RAW_DATABASE_URL.startswith("sqlite+aiosqlite:"):
        ASYNC_DATABASE_URL = RAW_DATABASE_URL.replace("sqlite:", "sqlite+aiosqlite:", 1)
    else:
        ASYNC_DATABASE_URL = RAW_DATABASE_URL
elif RAW_DATABASE_URL.startswith("postgresql://"):
    ASYNC_DATABASE_URL = RAW_DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://", 1)
elif RAW_DATABASE_URL.startswith("postgres://"):
    ASYNC_DATABASE_URL = RAW_DATABASE_URL.replace("postgres://", "postgresql+asyncpg://", 1)
else:
    ASYNC_DATABASE_URL = RAW_DATABASE_URL

# Create async engine
async_engine = create_async_engine(ASYNC_DATABASE_URL)

# Create async session factory
AsyncSessionLocal = async_sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False
)

async def get_async_db():
    """Dependency to get async database session"""
    async with AsyncSessionLocal() as session:
        yield session
```

**Effort:** 2 days (16 hours)
**Dependencies:** Session management fixes
**Testing:** Integration tests for SSE notifications

______________________________________________________________________

## Phase 2: Performance & Quality (Weeks 3-4)

### 2.1 Database Optimization (Priority: HIGH)

#### Task 2.1.1: Add Database Indexes (4 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/alembic/versions/add_performance_indexes.py`

```python
"""Add performance indexes

Revision ID: perf_001
Revises: df08353f6236
Create Date: 2025-08-XX XX:XX:XX.XXXXXX
"""
from alembic import op
import sqlalchemy as sa

# revision identifiers
revision = 'perf_001'
down_revision = 'df08353f6236'

def upgrade():
    """Add performance indexes"""

    # Task indexes for frequent queries
    op.create_index('idx_task_status', 'tasks', ['status'])
    op.create_index('idx_task_owner', 'tasks', ['owner'])
    op.create_index('idx_task_goal_status', 'tasks', ['goal_id', 'status'])
    op.create_index('idx_task_created_at', 'tasks', ['created_at'])
    op.create_index('idx_task_updated_at', 'tasks', ['updated_at'])

    # Goal indexes
    op.create_index('idx_goal_complete', 'goals', ['is_complete'])
    op.create_index('idx_goal_created_at', 'goals', ['created_at'])

    # Task dependency indexes
    op.create_index('idx_dependency_dependent', 'task_dependencies', ['dependent_task_id'])
    op.create_index('idx_dependency_task', 'task_dependencies', ['dependency_task_id'])
    op.create_index('idx_dependency_blocked', 'task_dependencies', ['is_blocked'])

    # Composite indexes for complex queries
    op.create_index('idx_task_goal_status_created', 'tasks', ['goal_id', 'status', 'created_at'])

def downgrade():
    """Remove performance indexes"""
    op.drop_index('idx_task_goal_status_created', 'tasks')
    op.drop_index('idx_dependency_blocked', 'task_dependencies')
    op.drop_index('idx_dependency_task', 'task_dependencies')
    op.drop_index('idx_dependency_dependent', 'task_dependencies')
    op.drop_index('idx_goal_created_at', 'goals')
    op.drop_index('idx_goal_complete', 'goals')
    op.drop_index('idx_task_updated_at', 'tasks')
    op.drop_index('idx_task_created_at', 'tasks')
    op.drop_index('idx_task_goal_status', 'tasks')
    op.drop_index('idx_task_owner', 'tasks')
    op.drop_index('idx_task_status', 'tasks')
```

#### Task 2.1.2: Optimize N+1 Query Problems (6 hours)

**File:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/api/tasks.py`

**Problem (Lines 78-102):** Calculating importance for each task individually.

**Before:**

```python
tasks_data = []
with SessionLocal() as db_session:
    for task in tasks:
        importance = calculate_task_importance(db_session, task.id)  # ❌ N queries

        deps_result = db_session.execute(
            select(func.count(TaskDependencyModel.id)).where(TaskDependencyModel.dependent_task_id == task.id)
        )
        dependency_count = deps_result.scalar() or 0  # ❌ Another N queries
```

**After:**

```python
@with_session
def get_tasks_with_metadata(self, session: Session, tasks: list[Task]) -> list[dict]:
    """Get tasks with calculated metadata in batch"""
    if not tasks:
        return []

    task_ids = [task.id for task in tasks]

    # Batch query for importance (how many tasks depend on each task)
    importance_query = (
        select(
            TaskDependencyModel.dependency_task_id,
            func.count().label('importance')
        )
        .where(TaskDependencyModel.dependency_task_id.in_(task_ids))
        .group_by(TaskDependencyModel.dependency_task_id)
    )
    importance_results = session.execute(importance_query)
    importance_map = dict(importance_results)

    # Batch query for dependency count (how many tasks each task depends on)
    dependency_query = (
        select(
            TaskDependencyModel.dependent_task_id,
            func.count().label('dependency_count')
        )
        .where(TaskDependencyModel.dependent_task_id.in_(task_ids))
        .group_by(TaskDependencyModel.dependent_task_id)
    )
    dependency_results = session.execute(dependency_query)
    dependency_map = dict(dependency_results)

    # Build results
    tasks_data = []
    for task in tasks:
        importance = importance_map.get(task.id, 0)
        dependency_count = dependency_map.get(task.id, 0)

        tasks_data.append({
            "id": task.id,
            "goal_id": task.goal_id,
            "name": task.name,
            "instructions": task.instructions,
            "status": task.status.value,
            "owner": task.owner,
            "importance": importance,
            "dependency_count": dependency_count,
            "is_leaf_node": dependency_count == 0,
            "created_at": task.created_at.isoformat(),
            "updated_at": task.updated_at.isoformat(),
        })

    return tasks_data

# Update the list_tasks endpoint
async def list_tasks(...):
    """List tasks with optional filtering"""
    try:
        tasks = task_repo.search(goal_id=goal_id, status=status, owner=owner, available_only=available_only)
        tasks_data = task_repo.get_tasks_with_metadata(tasks)  # ✅ Single batch query

        return APIResponse(message="Tasks retrieved successfully", data={"tasks": tasks_data, "total": len(tasks_data)})
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list tasks: {e!s}") from e
```

#### Task 2.1.3: Implement Query Result Caching (8 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/cache.py`

```python
"""
Simple in-memory cache for database query results
"""
import hashlib
import json
import time
from typing import Any, Dict, Optional
from functools import wraps

class SimpleCache:
    """Thread-safe in-memory cache with TTL support"""

    def __init__(self, default_ttl: int = 300):  # 5 minutes default
        self._cache: Dict[str, Dict[str, Any]] = {}
        self.default_ttl = default_ttl

    def _make_key(self, *args, **kwargs) -> str:
        """Create cache key from arguments"""
        key_data = {
            'args': args,
            'kwargs': {k: v for k, v in sorted(kwargs.items())}
        }
        key_str = json.dumps(key_data, sort_keys=True, default=str)
        return hashlib.md5(key_str.encode()).hexdigest()

    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        if key not in self._cache:
            return None

        entry = self._cache[key]
        if time.time() > entry['expires_at']:
            del self._cache[key]
            return None

        return entry['value']

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache"""
        expires_at = time.time() + (ttl or self.default_ttl)
        self._cache[key] = {
            'value': value,
            'expires_at': expires_at
        }

    def delete(self, key: str) -> None:
        """Delete key from cache"""
        self._cache.pop(key, None)

    def clear(self) -> None:
        """Clear entire cache"""
        self._cache.clear()

# Global cache instance
cache = SimpleCache()

def cached(ttl: int = 300, key_prefix: str = ""):
    """Decorator to cache function results"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key
            cache_key = f"{key_prefix}:{func.__name__}:" + cache._make_key(*args, **kwargs)

            # Try to get from cache
            result = cache.get(cache_key)
            if result is not None:
                return result

            # Calculate result and cache it
            result = func(*args, **kwargs)
            cache.set(cache_key, result, ttl)
            return result

        # Add cache invalidation method
        def invalidate_cache(*args, **kwargs):
            cache_key = f"{key_prefix}:{func.__name__}:" + cache._make_key(*args, **kwargs)
            cache.delete(cache_key)

        wrapper.invalidate_cache = invalidate_cache
        wrapper.clear_all_cache = lambda: cache.clear()

        return wrapper
    return decorator

# Cache invalidation on updates
def invalidate_related_cache(goal_id: Optional[int] = None, task_id: Optional[int] = None):
    """Invalidate caches related to goals/tasks"""
    # Simple approach: clear all cache on any update
    # In production, implement more granular cache invalidation
    cache.clear()
```

**Apply caching to frequently called methods:**

```python
# In repositories/goals.py
@cached(ttl=180, key_prefix="goal")
@with_session_list
def list_all(self, session: Session, completed_only: bool = False, incomplete_only: bool = False) -> list[Goal]:
    """List all goals with optional filtering (cached)"""
    # ... existing implementation

# In repositories/tasks.py
@cached(ttl=60, key_prefix="task")
@with_session_list
def search(self, session: Session, goal_id: int | None = None, status: str | None = None, owner: str | None = None, available_only: bool = False) -> list[Task]:
    """Search tasks with filters (cached)"""
    # ... existing implementation

# Update methods to invalidate cache
@with_session
def update(self, session: Session, task_id: int, **kwargs) -> Task | None:
    """Update task by ID"""
    result = # ... existing implementation

    # Invalidate related caches
    invalidate_related_cache(task_id=task_id)

    return result
```

**Effort:** 3 days (24 hours)
**Dependencies:** Database indexes
**Testing:** Performance tests showing query improvement

### 2.2 Code Quality Improvements (Priority: MEDIUM)

#### Task 2.2.1: Add Comprehensive Type Hints (6 hours)

**File:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/mcp_tools.py`

**Problem (Line 68):** Missing return type annotations.

**Fix:**

```python
from typing import Dict, List, Any, Optional
from sqlalchemy.orm import Session

def register_mcp_tools(mcp_server) -> None:  # ✅ Added return type
    """Register all MCP tools with the server"""

def calculate_task_importance(db_session: Session, task_id: int) -> int:  # ✅ Added param types
    """Calculate task importance based on how many other tasks depend on it."""

def update_task_blocking_status(db_session: Session, task_id: int) -> None:  # ✅ Added return type
    """Update the blocking status of all task dependencies for a given task."""

# Add type hints to all MCP tool functions
@mcp_server.tool(name="create_goal", description="Create a new goal with a description.")
def create_goal(description: str) -> Dict[str, Any]:  # ✅ Added return type
    """Create a new goal with the given description."""

@mcp_server.tool(name="list_goals", description="List all goals, optionally filtering by completion status.")
def list_goals(completed_only: bool = False, incomplete_only: bool = False) -> Dict[str, Any]:  # ✅ Added types
    """List all goals with optional filtering."""

@mcp_server.tool(name="update_goal", description="Update an existing goal.")
def update_goal(goal_id: int, description: Optional[str] = None, is_complete: Optional[bool] = None) -> Dict[str, Any]:  # ✅ Added types
    """Update an existing goal."""
```

#### Task 2.2.2: Implement Structured Logging (8 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/logging_config.py`

```python
"""
Centralized logging configuration
"""
import logging
import sys
from typing import Any, Dict
from datetime import datetime
import json

class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging"""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        # Add any extra fields
        for key, value in record.__dict__.items():
            if key not in {'name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 'filename',
                          'module', 'lineno', 'funcName', 'created', 'msecs', 'relativeCreated',
                          'thread', 'threadName', 'processName', 'process', 'exc_info', 'exc_text',
                          'stack_info'}:
                log_entry[key] = value

        return json.dumps(log_entry)

def setup_logging(level: str = "INFO", format_json: bool = True):
    """Setup application logging"""

    # Configure root logger
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, level.upper()))

    # Remove existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Create console handler
    handler = logging.StreamHandler(sys.stdout)

    if format_json:
        formatter = JSONFormatter()
    else:
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

    handler.setFormatter(formatter)
    logger.addHandler(handler)

def get_logger(name: str) -> logging.Logger:
    """Get a logger instance"""
    return logging.getLogger(name)

class LoggerMixin:
    """Mixin to add structured logging to classes"""

    @property
    def logger(self) -> logging.Logger:
        return get_logger(self.__class__.__module__ + "." + self.__class__.__name__)

    def log_operation(self, operation: str, **kwargs: Any) -> None:
        """Log an operation with structured data"""
        self.logger.info(f"Operation: {operation}", operation=operation, **kwargs)

    def log_error(self, operation: str, error: Exception, **kwargs: Any) -> None:
        """Log an error with structured data"""
        self.logger.error(
            f"Operation failed: {operation}",
            operation=operation,
            error_type=error.__class__.__name__,
            error_message=str(error),
            **kwargs,
            exc_info=True
        )
```

**Update repositories to use structured logging:**

```python
# In repositories/goals.py
from ..logging_config import LoggerMixin

class GoalRepository(LoggerMixin):
    """Repository for Goal database operations"""

    @with_session
    def create(self, session: Session, description: str) -> Goal:
        """Create a new goal"""
        self.log_operation("create_goal", description_length=len(description))

        try:
            goal = Goal(description=description)
            session.add(goal)
            session.flush()
            session.refresh(goal)

            self.log_operation("goal_created", goal_id=goal.id, description=description)
            return goal
        except Exception as e:
            self.log_error("create_goal", e, description=description)
            raise

    @with_session
    def update(self, session: Session, goal_id: int, **kwargs) -> Goal | None:
        """Update goal by ID"""
        self.log_operation("update_goal", goal_id=goal_id, updates=list(kwargs.keys()))

        try:
            result = session.execute(select(Goal).where(Goal.id == goal_id))
            goal = result.scalars().first()

            if not goal:
                self.logger.warning("Goal not found for update", goal_id=goal_id)
                return None

            for key, value in kwargs.items():
                if hasattr(goal, key):
                    old_value = getattr(goal, key)
                    setattr(goal, key, value)
                    self.logger.debug("Goal field updated",
                                    goal_id=goal_id, field=key,
                                    old_value=old_value, new_value=value)

            session.flush()
            session.refresh(goal)

            self.log_operation("goal_updated", goal_id=goal.id, updates=list(kwargs.keys()))
            return goal
        except Exception as e:
            self.log_error("update_goal", e, goal_id=goal_id, updates=kwargs)
            raise
```

#### Task 2.2.3: Reduce Code Duplication (10 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/src/repositories/base.py`

```python
"""
Base repository with common CRUD operations
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar
from sqlalchemy.orm import Session
from sqlalchemy import select
from ..database_session import with_session, with_session_list
from ..logging_config import LoggerMixin

ModelType = TypeVar('ModelType')
CreateSchemaType = TypeVar('CreateSchemaType')
UpdateSchemaType = TypeVar('UpdateSchemaType')

class BaseRepository(Generic[ModelType], LoggerMixin, ABC):
    """Base repository with common CRUD operations"""

    def __init__(self, model: Type[ModelType]):
        self.model = model

    @abstractmethod
    def _create_model(self, session: Session, **kwargs) -> ModelType:
        """Create model instance - must be implemented by subclasses"""
        pass

    @abstractmethod
    def _update_model(self, session: Session, db_obj: ModelType, **kwargs) -> ModelType:
        """Update model instance - must be implemented by subclasses"""
        pass

    @with_session
    def create(self, session: Session, **kwargs) -> ModelType:
        """Create a new object"""
        operation = f"create_{self.model.__name__.lower()}"
        self.log_operation(operation, **{k: v for k, v in kwargs.items() if k != 'password'})

        try:
            db_obj = self._create_model(session, **kwargs)
            session.add(db_obj)
            session.flush()
            session.refresh(db_obj)

            self.log_operation(f"{self.model.__name__.lower()}_created",
                             object_id=getattr(db_obj, 'id', None))
            return db_obj
        except Exception as e:
            self.log_error(operation, e, **kwargs)
            raise

    @with_session
    def get_by_id(self, session: Session, object_id: int) -> Optional[ModelType]:
        """Get object by ID"""
        try:
            result = session.execute(select(self.model).where(self.model.id == object_id))
            return result.scalars().first()
        except Exception as e:
            self.log_error("get_by_id", e, object_id=object_id, model=self.model.__name__)
            raise

    @with_session_list
    def get_multi(self, session: Session, skip: int = 0, limit: int = 100) -> List[ModelType]:
        """Get multiple objects"""
        try:
            result = session.execute(
                select(self.model).offset(skip).limit(limit)
            )
            return list(result.scalars().all())
        except Exception as e:
            self.log_error("get_multi", e, skip=skip, limit=limit, model=self.model.__name__)
            raise

    @with_session
    def update(self, session: Session, object_id: int, **kwargs) -> Optional[ModelType]:
        """Update object by ID"""
        operation = f"update_{self.model.__name__.lower()}"
        self.log_operation(operation, object_id=object_id, updates=list(kwargs.keys()))

        try:
            result = session.execute(select(self.model).where(self.model.id == object_id))
            db_obj = result.scalars().first()

            if not db_obj:
                self.logger.warning(f"{self.model.__name__} not found for update", object_id=object_id)
                return None

            updated_obj = self._update_model(session, db_obj, **kwargs)
            session.flush()
            session.refresh(updated_obj)

            self.log_operation(f"{self.model.__name__.lower()}_updated",
                             object_id=object_id, updates=list(kwargs.keys()))
            return updated_obj
        except Exception as e:
            self.log_error(operation, e, object_id=object_id, updates=kwargs)
            raise

    @with_session
    def delete(self, session: Session, object_id: int) -> bool:
        """Delete object by ID"""
        operation = f"delete_{self.model.__name__.lower()}"
        self.log_operation(operation, object_id=object_id)

        try:
            result = session.execute(select(self.model).where(self.model.id == object_id))
            db_obj = result.scalars().first()

            if not db_obj:
                self.logger.warning(f"{self.model.__name__} not found for deletion", object_id=object_id)
                return False

            session.delete(db_obj)

            self.log_operation(f"{self.model.__name__.lower()}_deleted", object_id=object_id)
            return True
        except Exception as e:
            self.log_error(operation, e, object_id=object_id)
            raise
```

**Refactor GoalRepository to inherit from BaseRepository:**

```python
from .base import BaseRepository
from ..models import Goal

class GoalRepository(BaseRepository[Goal]):
    """Repository for Goal database operations"""

    def __init__(self):
        super().__init__(Goal)

    def _create_model(self, session: Session, **kwargs) -> Goal:
        """Create Goal model instance"""
        return Goal(**kwargs)

    def _update_model(self, session: Session, db_obj: Goal, **kwargs) -> Goal:
        """Update Goal model instance"""
        for key, value in kwargs.items():
            if hasattr(db_obj, key):
                setattr(db_obj, key, value)
        return db_obj

    # Keep only goal-specific methods
    @cached(ttl=180, key_prefix="goal")
    @with_session_list
    def list_all(self, session: Session, completed_only: bool = False, incomplete_only: bool = False) -> list[Goal]:
        """List all goals with optional filtering"""
        query = select(Goal).options(selectinload(Goal.tasks))

        if completed_only:
            query = query.where(Goal.is_complete == True)
        elif incomplete_only:
            query = query.where(Goal.is_complete == False)

        result = session.execute(query.order_by(Goal.created_at.desc()))
        return list(result.scalars().all())
```

**Effort:** 4 days (32 hours)
**Dependencies:** Session management fixes
**Testing:** Refactored code maintains all existing functionality

______________________________________________________________________

## Phase 3: Testing & Documentation (Weeks 5-6)

### 3.1 Comprehensive Testing Infrastructure (Priority: HIGH)

#### Task 3.1.1: Setup Testing Framework (6 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/tests/conftest.py`

```python
"""
Pytest configuration and fixtures
"""
import pytest
import os
import tempfile
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from src.models import Base
from src.database import get_db
from src.app import app
from src.repositories import GoalRepository, TaskRepository

@pytest.fixture(scope="session")
def test_db():
    """Create a test database"""
    # Use in-memory SQLite for tests
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_file:
        test_db_url = f"sqlite:///{tmp_file.name}"

    engine = create_engine(test_db_url, connect_args={"check_same_thread": False})
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    # Create tables
    Base.metadata.create_all(bind=engine)

    yield TestingSessionLocal

    # Cleanup
    Base.metadata.drop_all(bind=engine)
    os.unlink(tmp_file.name)

@pytest.fixture
def db_session(test_db):
    """Create a database session for a test"""
    session = test_db()
    try:
        yield session
    finally:
        session.close()

@pytest.fixture
def client(test_db):
    """Create a test client with test database"""
    def override_get_db():
        session = test_db()
        try:
            yield session
        finally:
            session.close()

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()

@pytest.fixture
def goal_repo():
    """Goal repository fixture"""
    return GoalRepository()

@pytest.fixture
def task_repo():
    """Task repository fixture"""
    return TaskRepository()

@pytest.fixture
def sample_goal(db_session, goal_repo):
    """Create a sample goal for testing"""
    return goal_repo.create(description="Test Goal")

@pytest.fixture
def sample_task(db_session, task_repo, sample_goal):
    """Create a sample task for testing"""
    return task_repo.create(
        goal_id=sample_goal.id,
        name="Test Task",
        instructions="Test instructions"
    )

# Test data factories
class TestDataFactory:
    """Factory for creating test data"""

    @staticmethod
    def goal_data(description: str = "Test Goal", is_complete: bool = False) -> dict:
        return {
            "description": description,
            "is_complete": is_complete
        }

    @staticmethod
    def task_data(goal_id: int, name: str = "Test Task", instructions: str = "Test instructions") -> dict:
        return {
            "goal_id": goal_id,
            "name": name,
            "instructions": instructions
        }

    @staticmethod
    def dependency_data(dependent_task_id: int, dependency_task_id: int, required_data: str = None) -> dict:
        return {
            "dependent_task_id": dependent_task_id,
            "dependency_task_id": dependency_task_id,
            "required_data": required_data
        }

@pytest.fixture
def test_data_factory():
    """Test data factory fixture"""
    return TestDataFactory()
```

#### Task 3.1.2: Repository Integration Tests (12 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/tests/test_repositories_integration.py`

```python
"""
Integration tests for repository layer
"""
import pytest
from sqlalchemy.exc import IntegrityError

from src.models import TaskStatus
from src.repositories import GoalRepository, TaskRepository

class TestGoalRepositoryIntegration:
    """Integration tests for GoalRepository"""

    def test_create_goal_success(self, goal_repo, test_data_factory):
        """Test successful goal creation"""
        goal_data = test_data_factory.goal_data("Integration Test Goal")
        goal = goal_repo.create(**goal_data)

        assert goal.id is not None
        assert goal.description == "Integration Test Goal"
        assert goal.is_complete is False
        assert goal.created_at is not None
        assert goal.updated_at is not None

    def test_get_goal_by_id(self, goal_repo, sample_goal):
        """Test getting goal by ID"""
        retrieved_goal = goal_repo.get_by_id(sample_goal.id)

        assert retrieved_goal is not None
        assert retrieved_goal.id == sample_goal.id
        assert retrieved_goal.description == sample_goal.description

    def test_get_nonexistent_goal(self, goal_repo):
        """Test getting non-existent goal returns None"""
        retrieved_goal = goal_repo.get_by_id(99999)
        assert retrieved_goal is None

    def test_list_goals_filtering(self, goal_repo, test_data_factory):
        """Test goal listing with filters"""
        # Create completed and incomplete goals
        complete_goal = goal_repo.create(**test_data_factory.goal_data("Complete Goal", is_complete=True))
        incomplete_goal = goal_repo.create(**test_data_factory.goal_data("Incomplete Goal", is_complete=False))

        # Test completed only
        completed_goals = goal_repo.list_all(completed_only=True)
        completed_ids = [g.id for g in completed_goals]
        assert complete_goal.id in completed_ids
        assert incomplete_goal.id not in completed_ids

        # Test incomplete only
        incomplete_goals = goal_repo.list_all(incomplete_only=True)
        incomplete_ids = [g.id for g in incomplete_goals]
        assert incomplete_goal.id in incomplete_ids
        assert complete_goal.id not in incomplete_ids

    def test_update_goal(self, goal_repo, sample_goal):
        """Test goal update"""
        updated_goal = goal_repo.update(
            sample_goal.id,
            description="Updated Description",
            is_complete=True
        )

        assert updated_goal is not None
        assert updated_goal.id == sample_goal.id
        assert updated_goal.description == "Updated Description"
        assert updated_goal.is_complete is True

    def test_delete_goal(self, goal_repo, sample_goal):
        """Test goal deletion"""
        success = goal_repo.delete(sample_goal.id)
        assert success is True

        # Verify goal is deleted
        retrieved_goal = goal_repo.get_by_id(sample_goal.id)
        assert retrieved_goal is None

class TestTaskRepositoryIntegration:
    """Integration tests for TaskRepository"""

    def test_create_task_success(self, task_repo, sample_goal, test_data_factory):
        """Test successful task creation"""
        task_data = test_data_factory.task_data(sample_goal.id, "Integration Test Task")
        task = task_repo.create(**task_data)

        assert task.id is not None
        assert task.goal_id == sample_goal.id
        assert task.name == "Integration Test Task"
        assert task.status == TaskStatus.AVAILABLE

    def test_create_task_invalid_goal(self, task_repo, test_data_factory):
        """Test task creation with invalid goal ID"""
        task_data = test_data_factory.task_data(99999, "Invalid Task")

        with pytest.raises(ValueError, match="Goal with ID 99999 not found"):
            task_repo.create(**task_data)

    def test_task_status_updates(self, task_repo, sample_task):
        """Test task status update logic"""
        # Update to owned status (should require owner)
        with pytest.raises(ValueError, match="Owner is required"):
            task_repo.update(sample_task.id, status="owned")

        # Update with owner
        updated_task = task_repo.update(sample_task.id, status="owned", owner="test_agent")
        assert updated_task.status == TaskStatus.OWNED
        assert updated_task.owner == "test_agent"

        # Update to available (should clear owner)
        updated_task = task_repo.update(sample_task.id, status="available")
        assert updated_task.status == TaskStatus.AVAILABLE
        assert updated_task.owner is None

    def test_task_dependency_management(self, task_repo, sample_goal, test_data_factory):
        """Test task dependency creation and management"""
        # Create two tasks
        task1_data = test_data_factory.task_data(sample_goal.id, "Task 1")
        task2_data = test_data_factory.task_data(sample_goal.id, "Task 2")

        task1 = task_repo.create(**task1_data)
        task2 = task_repo.create(**task2_data)

        # Create dependency (task2 depends on task1)
        dependency = task_repo.add_dependency(
            dependent_task_id=task2.id,
            dependency_task_id=task1.id,
            required_data="output from task 1"
        )

        assert dependency.dependent_task_id == task2.id
        assert dependency.dependency_task_id == task1.id
        assert dependency.required_data == "output from task 1"
        assert dependency.is_blocked is True  # task1 is not completed

        # Complete task1 - should unblock task2
        task_repo.update(task1.id, status="completed", owner="test_agent")

        # Verify dependency is no longer blocked
        updated_task2 = task_repo.get_by_id(task2.id)
        # Should check dependency status through repository method
        # This tests the _update_task_blocking_status method

    def test_circular_dependency_prevention(self, task_repo, sample_goal, test_data_factory):
        """Test prevention of circular dependencies"""
        # Create two tasks
        task1_data = test_data_factory.task_data(sample_goal.id, "Task 1")
        task2_data = test_data_factory.task_data(sample_goal.id, "Task 2")

        task1 = task_repo.create(**task1_data)
        task2 = task_repo.create(**task2_data)

        # Create dependency (task2 depends on task1)
        task_repo.add_dependency(task2.id, task1.id)

        # Try to create reverse dependency (should be allowed but creates complexity)
        # In future versions, might want to add circular dependency detection
        reverse_dependency = task_repo.add_dependency(task1.id, task2.id)
        assert reverse_dependency is not None

    def test_task_search_functionality(self, task_repo, sample_goal, test_data_factory):
        """Test task search with various filters"""
        # Create tasks with different statuses and owners
        available_task = task_repo.create(**test_data_factory.task_data(sample_goal.id, "Available Task"))
        owned_task = task_repo.create(
            goal_id=sample_goal.id,
            name="Owned Task",
            instructions="Instructions",
            status=TaskStatus.OWNED,
            owner="agent1"
        )
        completed_task = task_repo.create(**test_data_factory.task_data(sample_goal.id, "Completed Task"))
        task_repo.update(completed_task.id, status="completed", owner="agent2")

        # Test status filtering
        available_tasks = task_repo.search(status="available")
        available_ids = [t.id for t in available_tasks]
        assert available_task.id in available_ids
        assert owned_task.id not in available_ids

        # Test owner filtering
        agent1_tasks = task_repo.search(owner="agent1")
        agent1_ids = [t.id for t in agent1_tasks]
        assert owned_task.id in agent1_ids
        assert available_task.id not in agent1_ids

        # Test goal filtering
        goal_tasks = task_repo.search(goal_id=sample_goal.id)
        goal_ids = [t.id for t in goal_tasks]
        assert available_task.id in goal_ids
        assert owned_task.id in goal_ids
        assert completed_task.id in goal_ids

        # Test available_only filtering
        available_only_tasks = task_repo.search(available_only=True)
        available_only_ids = [t.id for t in available_only_tasks]
        # Should include tasks that are AVAILABLE and not blocked by dependencies
        assert available_task.id in available_only_ids

class TestRepositoryErrorHandling:
    """Test error handling in repositories"""

    def test_database_constraint_violations(self, task_repo, sample_goal, test_data_factory):
        """Test handling of database constraint violations"""
        task1 = task_repo.create(**test_data_factory.task_data(sample_goal.id, "Task 1"))
        task2 = task_repo.create(**test_data_factory.task_data(sample_goal.id, "Task 2"))

        # Create dependency
        task_repo.add_dependency(task2.id, task1.id)

        # Try to create duplicate dependency
        with pytest.raises(ValueError, match="Dependency already exists"):
            task_repo.add_dependency(task2.id, task1.id)

    def test_repository_transaction_rollback(self, db_session, goal_repo):
        """Test that failed transactions are properly rolled back"""
        initial_count = len(goal_repo.list_all())

        # This should fail and rollback
        with pytest.raises(Exception):
            # Mock a database error during goal creation
            with patch.object(db_session, 'commit', side_effect=IntegrityError("", "", "")):
                goal_repo.create(description="This should fail")

        # Verify rollback - count should be unchanged
        final_count = len(goal_repo.list_all())
        assert final_count == initial_count
```

#### Task 3.1.3: API Integration Tests (10 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/tests/test_api_integration.py`

```python
"""
Integration tests for API endpoints
"""
import pytest
import json
from fastapi.testclient import TestClient

class TestGoalAPIIntegration:
    """Integration tests for Goal API endpoints"""

    def test_create_goal_flow(self, client, test_data_factory):
        """Test complete goal creation flow"""
        goal_data = test_data_factory.goal_data("API Integration Goal")

        response = client.post("/api/v1/goals/", json=goal_data)

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["data"]["description"] == "API Integration Goal"
        assert "id" in data["data"]

        goal_id = data["data"]["id"]

        # Verify goal can be retrieved
        get_response = client.get(f"/api/v1/goals/{goal_id}")
        assert get_response.status_code == 200
        get_data = get_response.json()
        assert get_data["data"]["id"] == goal_id
        assert get_data["data"]["description"] == "API Integration Goal"

    def test_goal_task_hierarchy(self, client, test_data_factory):
        """Test goal-task hierarchy endpoint"""
        # Create goal
        goal_data = test_data_factory.goal_data("Hierarchy Test Goal")
        goal_response = client.post("/api/v1/goals/", json=goal_data)
        goal_id = goal_response.json()["data"]["id"]

        # Create multiple tasks for the goal
        task1_data = test_data_factory.task_data(goal_id, "Task 1")
        task2_data = test_data_factory.task_data(goal_id, "Task 2")

        task1_response = client.post("/api/v1/tasks/", json=task1_data)
        task2_response = client.post("/api/v1/tasks/", json=task2_data)

        task1_id = task1_response.json()["data"]["id"]
        task2_id = task2_response.json()["data"]["id"]

        # Get hierarchy
        hierarchy_response = client.get(f"/api/v1/goals/{goal_id}/hierarchy")
        assert hierarchy_response.status_code == 200

        hierarchy_data = hierarchy_response.json()["data"]
        assert hierarchy_data["goal"]["id"] == goal_id
        assert len(hierarchy_data["tasks"]) == 2
        assert hierarchy_data["summary"]["total_tasks"] == 2
        assert hierarchy_data["summary"]["available_tasks"] == 2
        assert hierarchy_data["summary"]["completed_tasks"] == 0

        # Task IDs should be in the hierarchy
        task_ids = [task["id"] for task in hierarchy_data["tasks"]]
        assert task1_id in task_ids
        assert task2_id in task_ids

    def test_goal_filtering(self, client, test_data_factory):
        """Test goal listing with filters"""
        # Create completed and incomplete goals
        complete_goal_data = test_data_factory.goal_data("Complete Goal", is_complete=True)
        incomplete_goal_data = test_data_factory.goal_data("Incomplete Goal", is_complete=False)

        complete_response = client.post("/api/v1/goals/", json=complete_goal_data)
        incomplete_response = client.post("/api/v1/goals/", json=incomplete_goal_data)

        complete_id = complete_response.json()["data"]["id"]
        incomplete_id = incomplete_response.json()["data"]["id"]

        # Test completed_only filter
        completed_response = client.get("/api/v1/goals/?completed_only=true")
        completed_goals = completed_response.json()["data"]["goals"]
        completed_ids = [g["id"] for g in completed_goals]
        assert complete_id in completed_ids
        assert incomplete_id not in completed_ids

        # Test incomplete_only filter
        incomplete_response = client.get("/api/v1/goals/?incomplete_only=true")
        incomplete_goals = incomplete_response.json()["data"]["goals"]
        incomplete_ids = [g["id"] for g in incomplete_goals]
        assert incomplete_id in incomplete_ids
        assert complete_id not in incomplete_ids

class TestTaskAPIIntegration:
    """Integration tests for Task API endpoints"""

    def test_task_lifecycle(self, client, test_data_factory):
        """Test complete task lifecycle"""
        # Create goal first
        goal_data = test_data_factory.goal_data("Task Lifecycle Goal")
        goal_response = client.post("/api/v1/goals/", json=goal_data)
        goal_id = goal_response.json()["data"]["id"]

        # Create task
        task_data = test_data_factory.task_data(goal_id, "Lifecycle Task", "Test instructions")
        create_response = client.post("/api/v1/tasks/", json=task_data)

        assert create_response.status_code == 200
        task_id = create_response.json()["data"]["id"]

        # Get task details
        get_response = client.get(f"/api/v1/tasks/{task_id}")
        assert get_response.status_code == 200
        task_details = get_response.json()["data"]
        assert task_details["name"] == "Lifecycle Task"
        assert task_details["status"] == "available"

        # Update task to owned
        update_data = {"status": "owned", "owner": "test_agent"}
        update_response = client.put(f"/api/v1/tasks/{task_id}", json=update_data)
        assert update_response.status_code == 200
        assert update_response.json()["data"]["status"] == "owned"
        assert update_response.json()["data"]["owner"] == "test_agent"

        # Complete task
        complete_data = {"status": "completed"}
        complete_response = client.put(f"/api/v1/tasks/{task_id}", json=complete_data)
        assert complete_response.status_code == 200
        assert complete_response.json()["data"]["status"] == "completed"

        # Delete task
        delete_response = client.delete(f"/api/v1/tasks/{task_id}")
        assert delete_response.status_code == 200

        # Verify task is deleted
        get_deleted_response = client.get(f"/api/v1/tasks/{task_id}")
        assert get_deleted_response.status_code == 404

    def test_task_dependency_workflow(self, client, test_data_factory):
        """Test task dependency creation and management"""
        # Create goal
        goal_data = test_data_factory.goal_data("Dependency Test Goal")
        goal_response = client.post("/api/v1/goals/", json=goal_data)
        goal_id = goal_response.json()["data"]["id"]

        # Create two tasks
        task1_data = test_data_factory.task_data(goal_id, "Dependency Task", "Must complete first")
        task2_data = test_data_factory.task_data(goal_id, "Dependent Task", "Depends on first task")

        task1_response = client.post("/api/v1/tasks/", json=task1_data)
        task2_response = client.post("/api/v1/tasks/", json=task2_data)

        task1_id = task1_response.json()["data"]["id"]
        task2_id = task2_response.json()["data"]["id"]

        # Create dependency (task2 depends on task1)
        dependency_data = test_data_factory.dependency_data(
            task2_id, task1_id, "Output from task 1"
        )

        dep_response = client.post("/api/v1/tasks/dependencies", json=dependency_data)
        assert dep_response.status_code == 200

        dependency_id = dep_response.json()["data"]["id"]
        assert dep_response.json()["data"]["is_blocked"] is True

        # Get dependency graph
        graph_response = client.get(f"/api/v1/tasks/dependencies/graph?goal_id={goal_id}")
        assert graph_response.status_code == 200

        graph_data = graph_response.json()["data"]
        assert len(graph_data["nodes"]) == 2
        assert len(graph_data["edges"]) == 1
        assert graph_data["summary"]["blocked_dependencies"] == 1

        # Complete dependency task
        complete_response = client.put(f"/api/v1/tasks/{task1_id}", json={"status": "completed", "owner": "agent"})
        assert complete_response.status_code == 200

        # Check that dependency is no longer blocked
        updated_graph_response = client.get(f"/api/v1/tasks/dependencies/graph?goal_id={goal_id}")
        updated_graph_data = updated_graph_response.json()["data"]
        assert updated_graph_data["summary"]["blocked_dependencies"] == 0

    def test_task_search_and_filtering(self, client, test_data_factory):
        """Test task search and filtering functionality"""
        # Create goal
        goal_data = test_data_factory.goal_data("Search Test Goal")
        goal_response = client.post("/api/v1/goals/", json=goal_data)
        goal_id = goal_response.json()["data"]["id"]

        # Create tasks with different statuses and owners
        tasks_data = [
            {**test_data_factory.task_data(goal_id, "Available Task 1"), "owner": None},
            {**test_data_factory.task_data(goal_id, "Available Task 2"), "owner": None},
            {**test_data_factory.task_data(goal_id, "Owned Task 1"), "owner": "agent1"},
            {**test_data_factory.task_data(goal_id, "Owned Task 2"), "owner": "agent2"},
        ]

        created_tasks = []
        for task_data in tasks_data:
            response = client.post("/api/v1/tasks/", json=task_data)
            created_tasks.append(response.json()["data"])

        # Complete one task
        client.put(f"/api/v1/tasks/{created_tasks[0]['id']}", json={"status": "completed", "owner": "agent1"})

        # Test filtering by goal
        goal_tasks_response = client.get(f"/api/v1/tasks/?goal_id={goal_id}")
        goal_tasks = goal_tasks_response.json()["data"]["tasks"]
        assert len(goal_tasks) == 4

        # Test filtering by status
        available_response = client.get("/api/v1/tasks/?status=available")
        available_tasks = available_response.json()["data"]["tasks"]
        available_names = [t["name"] for t in available_tasks]
        assert "Available Task 2" in available_names

        # Test filtering by owner
        agent1_response = client.get("/api/v1/tasks/?owner=agent1")
        agent1_tasks = agent1_response.json()["data"]["tasks"]
        # Should include both owned and completed tasks by agent1
        assert len(agent1_tasks) >= 1

        # Test available_only filter
        available_only_response = client.get("/api/v1/tasks/?available_only=true")
        available_only_tasks = available_only_response.json()["data"]["tasks"]
        # Should only include tasks that are available and not blocked
        for task in available_only_tasks:
            assert task["status"] == "available"

class TestSSEIntegration:
    """Integration tests for Server-Sent Events"""

    @pytest.mark.asyncio
    async def test_sse_connection(self, client):
        """Test SSE endpoint connection"""
        response = client.get("/api/v1/sse/events")
        assert response.status_code == 200
        assert "text/event-stream" in response.headers["content-type"]

    def test_sse_notification_endpoint(self, client):
        """Test SSE notification sending"""
        notification_data = {
            "event_type": "test_event",
            "data": {"message": "Test notification"},
            "goal_id": 1
        }

        response = client.post("/api/v1/sse/notify", json=notification_data)
        assert response.status_code == 200

        response_data = response.json()
        assert response_data["success"] is True
        assert "recipients" in response_data["data"]

class TestErrorHandling:
    """Test API error handling"""

    def test_invalid_goal_id(self, client):
        """Test handling of invalid goal ID"""
        response = client.get("/api/v1/goals/99999")
        assert response.status_code == 404
        assert "Goal not found" in response.json()["detail"]

    def test_invalid_task_id(self, client):
        """Test handling of invalid task ID"""
        response = client.get("/api/v1/tasks/99999")
        assert response.status_code == 404
        assert "Task not found" in response.json()["detail"]

    def test_invalid_task_creation(self, client):
        """Test task creation with invalid goal ID"""
        task_data = {"goal_id": 99999, "name": "Invalid Task"}
        response = client.post("/api/v1/tasks/", json=task_data)
        assert response.status_code == 500
        assert "Goal with ID 99999 not found" in response.json()["detail"]

    def test_invalid_status_update(self, client, test_data_factory):
        """Test task update with invalid status"""
        # Create a valid task first
        goal_data = test_data_factory.goal_data("Error Test Goal")
        goal_response = client.post("/api/v1/goals/", json=goal_data)
        goal_id = goal_response.json()["data"]["id"]

        task_data = test_data_factory.task_data(goal_id, "Error Test Task")
        task_response = client.post("/api/v1/tasks/", json=task_data)
        task_id = task_response.json()["data"]["id"]

        # Try invalid status
        update_data = {"status": "invalid_status"}
        response = client.put(f"/api/v1/tasks/{task_id}", json=update_data)
        assert response.status_code == 500
        assert "Invalid status" in response.json()["detail"]

    def test_missing_owner_for_owned_status(self, client, test_data_factory):
        """Test task update to owned status without owner"""
        # Create a valid task first
        goal_data = test_data_factory.goal_data("Owner Test Goal")
        goal_response = client.post("/api/v1/goals/", json=goal_data)
        goal_id = goal_response.json()["data"]["id"]

        task_data = test_data_factory.task_data(goal_id, "Owner Test Task")
        task_response = client.post("/api/v1/tasks/", json=task_data)
        task_id = task_response.json()["data"]["id"]

        # Try to set owned status without owner
        update_data = {"status": "owned"}
        response = client.put(f"/api/v1/tasks/{task_id}", json=update_data)
        assert response.status_code == 500
        assert "Owner is required" in response.json()["detail"]
```

#### Task 3.1.4: Performance Tests (8 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/tests/test_performance.py`

```python
"""
Performance tests for database operations
"""
import pytest
import time
from concurrent.futures import ThreadPoolExecutor
from typing import List

from src.repositories import GoalRepository, TaskRepository
from src.models import TaskStatus

class TestDatabasePerformance:
    """Performance tests for database operations"""

    def test_batch_goal_creation_performance(self, goal_repo, test_data_factory):
        """Test performance of batch goal creation"""
        goal_count = 100
        start_time = time.time()

        goals = []
        for i in range(goal_count):
            goal_data = test_data_factory.goal_data(f"Performance Goal {i}")
            goal = goal_repo.create(**goal_data)
            goals.append(goal)

        end_time = time.time()
        duration = end_time - start_time

        # Should complete within reasonable time (adjust based on hardware)
        assert duration < 5.0, f"Goal creation took too long: {duration:.2f} seconds"
        assert len(goals) == goal_count

        # Verify all goals were created correctly
        assert all(goal.id is not None for goal in goals)
        assert all(goal.description.startswith("Performance Goal") for goal in goals)

    def test_batch_task_operations_performance(self, task_repo, goal_repo, test_data_factory):
        """Test performance of batch task operations"""
        # Create a goal first
        goal = goal_repo.create(**test_data_factory.goal_data("Performance Test Goal"))

        task_count = 200
        start_time = time.time()

        # Create tasks
        tasks = []
        for i in range(task_count):
            task_data = test_data_factory.task_data(goal.id, f"Performance Task {i}")
            task = task_repo.create(**task_data)
            tasks.append(task)

        creation_time = time.time()
        creation_duration = creation_time - start_time

        # Search operations
        search_start = time.time()

        # Test different search patterns
        all_tasks = task_repo.search()
        goal_tasks = task_repo.search(goal_id=goal.id)
        available_tasks = task_repo.search(status="available")
        available_only = task_repo.search(available_only=True)

        search_time = time.time()
        search_duration = search_time - search_start

        # Update operations
        update_start = time.time()

        # Update every 10th task to owned status
        for i in range(0, len(tasks), 10):
            task_repo.update(tasks[i].id, status="owned", owner=f"agent_{i}")

        update_time = time.time()
        update_duration = update_time - update_start

        # Performance assertions (adjust thresholds based on hardware)
        assert creation_duration < 10.0, f"Task creation took too long: {creation_duration:.2f}s"
        assert search_duration < 2.0, f"Search operations took too long: {search_duration:.2f}s"
        assert update_duration < 3.0, f"Update operations took too long: {update_duration:.2f}s"

        # Correctness assertions
        assert len(all_tasks) >= task_count
        assert len(goal_tasks) == task_count
        assert len(available_tasks) >= task_count - (task_count // 10)

        print(f"Performance Results:")
        print(f"  Created {task_count} tasks in {creation_duration:.2f}s ({task_count/creation_duration:.1f} tasks/s)")
        print(f"  Completed search operations in {search_duration:.2f}s")
        print(f"  Updated {task_count//10} tasks in {update_duration:.2f}s")

    def test_dependency_graph_performance(self, task_repo, goal_repo, test_data_factory):
        """Test performance of dependency operations"""
        # Create goal and tasks
        goal = goal_repo.create(**test_data_factory.goal_data("Dependency Performance Goal"))

        task_count = 50
        tasks = []
        for i in range(task_count):
            task_data = test_data_factory.task_data(goal.id, f"Dep Task {i}")
            task = task_repo.create(**task_data)
            tasks.append(task)

        # Create dependencies (each task depends on previous)
        start_time = time.time()

        dependencies = []
        for i in range(1, task_count):
            dependency = task_repo.add_dependency(
                dependent_task_id=tasks[i].id,
                dependency_task_id=tasks[i-1].id,
                required_data=f"Output from task {i-1}"
            )
            dependencies.append(dependency)

        dependency_creation_time = time.time()
        dependency_duration = dependency_creation_time - start_time

        # Test task retrieval with dependencies
        retrieval_start = time.time()

        # Get tasks with dependency information
        retrieved_tasks = []
        for task in tasks[:10]:  # Test first 10 tasks
            retrieved_task = task_repo.get_by_id(task.id)
            retrieved_tasks.append(retrieved_task)

        retrieval_time = time.time()
        retrieval_duration = retrieval_time - retrieval_start

        # Performance assertions
        assert dependency_duration < 5.0, f"Dependency creation took too long: {dependency_duration:.2f}s"
        assert retrieval_duration < 2.0, f"Task retrieval took too long: {retrieval_duration:.2f}s"

        # Correctness assertions
        assert len(dependencies) == task_count - 1
        assert all(dep.is_blocked for dep in dependencies)
        assert all(task.id is not None for task in retrieved_tasks)

        print(f"Dependency Performance Results:")
        print(f"  Created {len(dependencies)} dependencies in {dependency_duration:.2f}s")
        print(f"  Retrieved {len(retrieved_tasks)} tasks with deps in {retrieval_duration:.2f}s")

    def test_concurrent_operations(self, goal_repo, task_repo, test_data_factory):
        """Test performance under concurrent load"""
        # Create a goal for concurrent operations
        goal = goal_repo.create(**test_data_factory.goal_data("Concurrency Test Goal"))

        def create_tasks_batch(batch_id: int) -> List[int]:
            """Create a batch of tasks"""
            task_ids = []
            for i in range(10):
                task_data = test_data_factory.task_data(goal.id, f"Concurrent Task {batch_id}-{i}")
                task = task_repo.create(**task_data)
                task_ids.append(task.id)
            return task_ids

        def update_tasks_batch(task_ids: List[int], batch_id: int) -> int:
            """Update a batch of tasks"""
            updated_count = 0
            for task_id in task_ids:
                try:
                    task_repo.update(task_id, status="owned", owner=f"agent_{batch_id}")
                    updated_count += 1
                except Exception as e:
                    print(f"Update failed for task {task_id}: {e}")
            return updated_count

        start_time = time.time()

        # Run concurrent operations
        with ThreadPoolExecutor(max_workers=5) as executor:
            # Create tasks concurrently
            create_futures = [executor.submit(create_tasks_batch, i) for i in range(5)]
            batch_task_ids = [future.result() for future in create_futures]

            # Update tasks concurrently
            update_futures = [
                executor.submit(update_tasks_batch, task_ids, i)
                for i, task_ids in enumerate(batch_task_ids)
            ]
            update_results = [future.result() for future in update_futures]

        end_time = time.time()
        total_duration = end_time - start_time

        # Verify results
        total_created = sum(len(batch) for batch in batch_task_ids)
        total_updated = sum(update_results)

        assert total_created == 50  # 5 batches * 10 tasks each
        assert total_updated == 50  # All tasks should be updated
        assert total_duration < 10.0, f"Concurrent operations took too long: {total_duration:.2f}s"

        print(f"Concurrency Performance Results:")
        print(f"  Created and updated {total_created} tasks in {total_duration:.2f}s")
        print(f"  Throughput: {total_created/total_duration:.1f} operations/s")

    @pytest.mark.skip("Run only for comprehensive performance analysis")
    def test_large_dataset_performance(self, goal_repo, task_repo, test_data_factory):
        """Test performance with large datasets"""
        # Create multiple goals
        goals = []
        for i in range(10):
            goal = goal_repo.create(**test_data_factory.goal_data(f"Large Dataset Goal {i}"))
            goals.append(goal)

        # Create many tasks per goal
        tasks_per_goal = 100
        total_tasks = 0

        start_time = time.time()

        for goal in goals:
            for j in range(tasks_per_goal):
                task_data = test_data_factory.task_data(goal.id, f"Large Dataset Task {goal.id}-{j}")
                task_repo.create(**task_data)
                total_tasks += 1

        creation_time = time.time()

        # Test search performance with large dataset
        search_start = time.time()

        all_tasks = task_repo.search()
        available_tasks = task_repo.search(status="available")

        for goal in goals:
            goal_tasks = task_repo.search(goal_id=goal.id)
            assert len(goal_tasks) == tasks_per_goal

        search_end = time.time()

        creation_duration = creation_time - start_time
        search_duration = search_end - search_start

        print(f"Large Dataset Performance Results:")
        print(f"  Created {total_tasks} tasks in {creation_duration:.2f}s")
        print(f"  Searched {len(all_tasks)} tasks in {search_duration:.2f}s")
        print(f"  Creation rate: {total_tasks/creation_duration:.1f} tasks/s")

        # These thresholds may need adjustment based on hardware
        assert creation_duration < 60.0, "Large dataset creation too slow"
        assert search_duration < 10.0, "Large dataset search too slow"
        assert len(all_tasks) >= total_tasks
        assert len(available_tasks) == total_tasks  # All should be available initially
```

**Effort:** 5 days (40 hours)
**Dependencies:** Session management and performance optimizations
**Testing:** Comprehensive test suite with >90% coverage

### 3.2 Database Schema Optimization (Priority: MEDIUM)

#### Task 3.2.1: Add Missing Fields and Constraints (4 hours)

**Create:** `/Users/brian/workspace/onegrep/taskmaster-mcp/alembic/versions/schema_improvements.py`

```python
"""Add schema improvements and missing fields

Revision ID: schema_001
Revises: perf_001
Create Date: 2025-08-XX XX:XX:XX.XXXXXX
"""
from alembic import op
import sqlalchemy as sa

revision = 'schema_001'
down_revision = 'perf_001'

def upgrade():
    """Add schema improvements"""

    # Add importance field to tasks (referenced in code but missing from model)
    op.add_column('tasks', sa.Column('importance', sa.Integer, nullable=False, default=0))

    # Add soft delete support
    op.add_column('goals', sa.Column('deleted_at', sa.DateTime, nullable=True))
    op.add_column('tasks', sa.Column('deleted_at', sa.DateTime, nullable=True))

    # Add task priority field
    op.add_column('tasks', sa.Column('priority', sa.Integer, nullable=False, default=3))

    # Add estimated effort field
    op.add_column('tasks', sa.Column('estimated_hours', sa.Float, nullable=True))
    op.add_column('tasks', sa.Column('actual_hours', sa.Float, nullable=True))

    # Add goal metadata
    op.add_column('goals', sa.Column('target_completion_date', sa.Date, nullable=True))
    op.add_column('goals', sa.Column('completion_percentage', sa.Float, nullable=False, default=0.0))

    # Add better constraints
    op.create_check_constraint('ck_task_priority', 'tasks', 'priority BETWEEN 1 AND 5')
    op.create_check_constraint('ck_estimated_hours_positive', 'tasks', 'estimated_hours > 0')
    op.create_check_constraint('ck_actual_hours_positive', 'tasks', 'actual_hours > 0')
    op.create_check_constraint('ck_completion_percentage', 'goals', 'completion_percentage BETWEEN 0.0 AND 100.0')

def downgrade():
    """Remove schema improvements"""
    op.drop_constraint('ck_completion_percentage', 'goals')
    op.drop_constraint('ck_actual_hours_positive', 'tasks')
    op.drop_constraint('ck_estimated_hours_positive', 'tasks')
    op.drop_constraint('ck_task_priority', 'tasks')

    op.drop_column('goals', 'completion_percentage')
    op.drop_column('goals', 'target_completion_date')
    op.drop_column('tasks', 'actual_hours')
    op.drop_column('tasks', 'estimated_hours')
    op.drop_column('tasks', 'priority')
    op.drop_column('tasks', 'deleted_at')
    op.drop_column('goals', 'deleted_at')
    op.drop_column('tasks', 'importance')
```

**Update models to reflect new fields:**

```python
# In src/models.py
class Goal(Base):
    __tablename__ = "goals"

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, index=True, autoincrement=True)
    description = sqlalchemy.Column(sqlalchemy.Text, nullable=False)
    is_complete = sqlalchemy.Column(sqlalchemy.Boolean, default=False, nullable=False)
    target_completion_date = sqlalchemy.Column(sqlalchemy.Date, nullable=True)  # ✅ New field
    completion_percentage = sqlalchemy.Column(sqlalchemy.Float, default=0.0, nullable=False)  # ✅ New field
    created_at = sqlalchemy.Column(DateTime, default=func.now(), nullable=False)
    updated_at = sqlalchemy.Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    deleted_at = sqlalchemy.Column(DateTime, nullable=True)  # ✅ Soft delete support

    # Relationship to tasks
    tasks = relationship("Task", back_populates="goal", cascade="all, delete-orphan")

    # Add constraint
    __table_args__ = (
        sqlalchemy.CheckConstraint('completion_percentage BETWEEN 0.0 AND 100.0', name='ck_completion_percentage'),
    )

class Task(Base):
    __tablename__ = "tasks"

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, index=True, autoincrement=True)
    goal_id = sqlalchemy.Column(sqlalchemy.Integer, ForeignKey("goals.id"), nullable=False)
    name = sqlalchemy.Column(sqlalchemy.String(255), nullable=False)
    instructions = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    status = sqlalchemy.Column(sqlalchemy.Enum(TaskStatus), default=TaskStatus.AVAILABLE, nullable=False, index=True)
    owner = sqlalchemy.Column(sqlalchemy.String(255), nullable=True, index=True)
    priority = sqlalchemy.Column(sqlalchemy.Integer, default=3, nullable=False)  # ✅ New field (1-5 scale)
    importance = sqlalchemy.Column(sqlalchemy.Integer, default=0, nullable=False)  # ✅ Calculated field
    estimated_hours = sqlalchemy.Column(sqlalchemy.Float, nullable=True)  # ✅ New field
    actual_hours = sqlalchemy.Column(sqlalchemy.Float, nullable=True)  # ✅ New field
    created_at = sqlalchemy.Column(DateTime, default=func.now(), nullable=False, index=True)
    updated_at = sqlalchemy.Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    deleted_at = sqlalchemy.Column(DateTime, nullable=True)  # ✅ Soft delete support

    # Relationships
    goal = relationship("Goal", back_populates="tasks")
    dependencies = relationship(
        "TaskDependency", foreign_keys="TaskDependency.dependent_task_id", back_populates="dependent_task"
    )
    dependents = relationship(
        "TaskDependency", foreign_keys="TaskDependency.dependency_task_id", back_populates="dependency_task"
    )

    # Add constraints
    __table_args__ = (
        sqlalchemy.CheckConstraint('priority BETWEEN 1 AND 5', name='ck_task_priority'),
        sqlalchemy.CheckConstraint('estimated_hours > 0', name='ck_estimated_hours_positive'),
        sqlalchemy.CheckConstraint('actual_hours > 0', name='ck_actual_hours_positive'),
        sqlalchemy.Index('idx_task_goal_status', 'goal_id', 'status'),
        sqlalchemy.Index('idx_task_priority_status', 'priority', 'status'),
    )
```

**Effort:** 1 day (8 hours)
**Dependencies:** Performance improvements
**Testing:** Migration tests and model validation tests

______________________________________________________________________

## Implementation Timeline

### Week 1 (August 7-13)

- **Days 1-2:** Session management decorator and GoalRepository refactor
- **Days 3-4:** TaskRepository refactor and session fixes
- **Day 5:** Testing session management fixes

### Week 2 (August 14-20)

- **Days 1-2:** SSE notification queue and async/sync patterns
- **Day 3:** Database async utilities
- **Days 4-5:** Integration testing for Phase 1 fixes

### Week 3 (August 21-27)

- **Day 1:** Database indexes migration
- **Days 2-3:** N+1 query optimization and batch operations
- **Days 4-5:** Query result caching implementation

### Week 4 (August 28-September 3)

- **Days 1-2:** Type hints and structured logging
- **Days 3-4:** Base repository and code deduplication
- **Day 5:** Code quality validation

### Week 5 (September 4-10)

- **Days 1-2:** Testing framework setup and fixtures
- **Days 3-5:** Repository and API integration tests

### Week 6 (September 11-18)

- **Days 1-2:** Performance tests and benchmarks
- **Day 3:** Database schema improvements
- **Days 4-5:** Final validation and documentation

## Success Metrics

### Phase 1 Success Criteria

- [ ] Zero SQLAlchemy detached instance errors
- [ ] All repository methods use session decorators
- [ ] SSE notifications work reliably from sync context
- [ ] Memory leaks eliminated in session management
- [ ] All existing functionality preserved

### Phase 2 Success Criteria

- [ ] >50% improvement in query performance (measured via benchmarks)
- [ ] Database indexes implemented and validated
- [ ] N+1 queries eliminated in critical paths
- [ ] Code duplication reduced by >80%
- [ ] 100% type hint coverage
- [ ] Structured logging throughout application

### Phase 3 Success Criteria

- [ ] >90% test coverage across all modules
- [ ] Performance tests demonstrating scalability
- [ ] All edge cases covered in integration tests
- [ ] Database schema properly normalized
- [ ] Documentation complete and up-to-date

## Risk Mitigation

### High-Risk Items

1. **Session Management Changes:** Could break existing functionality

   - **Mitigation:** Extensive testing at each step, maintain backward compatibility

1. **Performance Optimizations:** May introduce bugs in complex queries

   - **Mitigation:** Performance tests validate both speed and correctness

1. **Database Schema Changes:** Could cause data loss

   - **Mitigation:** Thorough migration testing, backup procedures

### Dependencies

- All Phase 1 tasks must complete before Phase 2 begins
- Database performance improvements needed before comprehensive testing
- Session management fixes are prerequisite for all other improvements

## Resource Requirements

### Development Time

- **Phase 1:** 48 hours (2 weeks, 1 developer)
- **Phase 2:** 56 hours (2 weeks, 1 developer)
- **Phase 3:** 48 hours (2 weeks, 1 developer)
- **Total:** 152 hours over 6 weeks

### Testing Infrastructure

- Automated test suite with CI/CD integration
- Performance benchmarking tools
- Database migration testing environment
- Load testing capabilities for concurrent operations

### Monitoring & Validation

- Structured logging for debugging
- Performance metrics collection
- Error tracking and reporting
- Database query performance monitoring

This comprehensive plan addresses all critical technical issues while maintaining focus on local usage requirements. The phased approach ensures steady progress with validation at each step, minimizing risk while maximizing improvement impact.
