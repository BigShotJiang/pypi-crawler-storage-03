# Redesigned Slash Commands for Goal-Oriented Task Management

## Executive Summary

This proposal presents a completely redesigned slash command structure based on user feedback. The new design:

- Separates **Resource Management** (CRUD operations) from **Lifecycle Commands** (workflow phases)
- Eliminates ambiguity by tying each command to a specific purpose and phase
- Uses natural language for all arguments (no IDs, structured parameters, or technical syntax)
- Maps clearly to project lifecycle phases that users naturally understand

## Command Categories

### 1. Resource Management Commands

These commands handle clear CRUD (Create, Read, Update, Delete) operations on goals and tasks.

#### `/manage-goals` - Complete Goal Resource Management

**Purpose**: Single command for all goal CRUD operations with natural language understanding

**Natural Language Arguments**:

- **Create**: "create a new goal for launching the mobile app"
- **List**: "show all goals" | "show active goals" | "show completed goals"
- **Update**: "mark mobile app launch as complete" | "rename product launch to Q2 product launch"
- **Delete**: "delete the old prototype goal" | "archive completed goals from last quarter"

**MCP Tool Mapping**:

- Intent detection: create/new/add → `create_goal`
- Intent detection: show/list/display → `list_goals`
- Intent detection: complete/finish/done → `update_goal_status`
- Intent detection: rename/change → `update_goal` (if available)
- Intent detection: delete/remove/archive → `delete_goal` (if available)

**Expected Result**:

- Create: "✅ Created goal: 'Launch mobile app' (Goal #42)"
- List: Formatted table with columns \[ID, Description, Status, Tasks, Progress\]
- Update: "✅ Goal 'Mobile app launch' marked as complete"
- Delete: "✅ Archived goal 'Old prototype' and its 5 completed tasks"

**Example Usage**:

```
/manage-goals create a goal for Q2 infrastructure improvements
/manage-goals show me what we're working on
/manage-goals complete the infrastructure goal
/manage-goals archive all completed goals
```

#### `/manage-tasks` - Complete Task Resource Management

**Purpose**: Single command for all task CRUD operations within goals

**Natural Language Arguments**:

- **Create**: "add task 'design user interface' to mobile app goal"
- **List**: "show all tasks" | "show tasks for mobile app" | "show my tasks"
- **Update**: "mark user interface design as complete" | "assign database setup to alice"
- **Delete**: "remove the old mockup task" | "cancel all blocked tasks"
- **Move**: "move API design from backend goal to frontend goal"

**MCP Tool Mapping**:

- Create with goal detection → `search_goals` + `create_task`
- List with filters → `search_tasks` with appropriate parameters
- Update status/owner → `update_task`
- Delete → `delete_task` (if available) or `update_task` with cancelled status
- Move between goals → `update_task` with new goal_id

**Expected Result**:

- Create: "✅ Added task 'Design user interface' to 'Mobile app' goal"
- List: Formatted table \[Task, Goal, Status, Owner, Dependencies, Importance\]
- Update: "✅ Task 'User interface design' completed - 2 tasks now unblocked!"
- Delete: "✅ Cancelled task 'Old mockup task'"

**Example Usage**:

```
/manage-tasks add 'implement payment gateway' to the ecommerce project
/manage-tasks show what needs to be done for mobile app
/manage-tasks assign all frontend tasks to bob
/manage-tasks complete the database migration
```

### 2. Goal Planning and Task Execution Lifecycle Commands

These commands map to specific phases of project work, making their purpose crystal clear.

#### `/setup` - Initial Project Configuration

**Purpose**: Initialize project structure, establish working environment, and configure team settings

**Natural Language Arguments**:

- "initialize a new software project with standard goals"
- "set up goals for website redesign with frontend and backend sections"
- "configure team with alice as frontend lead and bob as backend lead"
- "import goals from our project template"

**MCP Tool Mapping**:

- Create initial goal structure → multiple `create_goal` calls
- Set up team assignments → store team configuration
- Apply templates → predefined goal/task structures

**Expected Result**:

- "✅ Project initialized with 3 goals: Frontend Development, Backend Development, Testing & QA"
- "✅ Team configured: Alice (Frontend Lead), Bob (Backend Lead)"
- Shows initial project structure visually

**Example Usage**:

```
/setup create a new mobile app project with ios and android goals
/setup initialize ecommerce project with standard phases
/setup configure alice and bob as project leads
```

#### `/plan` - Strategic Goal Planning

**Purpose**: High-level objective setting and goal creation for project phases

**Natural Language Arguments**:

- "plan a three-phase product launch for Q2"
- "outline goals for migrating to microservices"
- "create quarterly objectives for the engineering team"
- "establish milestones for the website redesign"

**MCP Tool Mapping**:

- Parse phases/objectives → multiple `create_goal` calls
- Intelligent goal naming and structuring
- Set completion criteria (stored in goal descriptions)

**Expected Result**:

- "✅ Created 3-phase launch plan:"
  - "Phase 1: Core Development (0/0 tasks)"
  - "Phase 2: Beta Testing (0/0 tasks)"
  - "Phase 3: Production Release (0/0 tasks)"
- Visual timeline or roadmap representation

**Example Usage**:

```
/plan create goals for a complete system redesign
/plan outline quarterly objectives for Q2
/plan establish phases for cloud migration project
```

#### `/breakdown` - Task Decomposition

**Purpose**: Break down goals into concrete, actionable tasks with clear deliverables

**Natural Language Arguments**:

- "break down the frontend development goal"
- "decompose user authentication into implementation tasks"
- "create detailed tasks for the payment processing feature"
- "split the mobile app goal into ios and android tasks"

**MCP Tool Mapping**:

- Goal name resolution → `list_goals` for ID
- Intelligent task generation → multiple `create_task` calls
- Automatic dependency creation → `add_task_dependency`
- Domain-specific templates (frontend, backend, mobile, etc.)

**Expected Result**:

- "✅ Created 6 tasks for 'Frontend Development':"
  - "□ Design component architecture"
  - "□ Implement navigation system"
  - "□ Create reusable UI components"
  - "□ Set up state management"
  - "□ Implement responsive layouts"
  - "□ Add accessibility features"
- Shows dependency relationships if created

**Example Usage**:

```
/breakdown decompose the authentication system implementation
/breakdown create tasks for the mobile app UI
/breakdown split payment processing into frontend and backend tasks
```

#### `/generate` - AI-Assisted Task Creation

**Purpose**: Use AI to intelligently generate tasks based on requirements or descriptions

**Natural Language Arguments**:

- "generate tasks from the PRD document for user management"
- "create test scenarios for the payment system"
- "suggest tasks for improving application performance"
- "generate security audit tasks for the API"

**MCP Tool Mapping**:

- AI analysis of requirements → structured task generation
- Bulk task creation → multiple `create_task` calls
- Smart dependency inference → `add_task_dependency`
- Category-based task templates

**Expected Result**:

- "✅ Generated 8 tasks from PRD analysis:"
  - "□ Implement user registration endpoint"
  - "□ Create password reset functionality"
  - "□ Add email verification system"
  - (... more tasks with dependencies)
- "📊 Dependency graph created based on technical requirements"

**Example Usage**:

```
/generate create tasks from the feature specification
/generate suggest testing tasks for the new api endpoints
/generate create deployment checklist for production release
```

#### `/work` - Find and Start Available Work

**Purpose**: Discover what can be worked on right now, considering dependencies and priorities

**Natural Language Arguments**:

- "what should I work on next?"
- "show me quick wins I can complete today"
- "find available backend tasks"
- "what's ready in the mobile app project?"

**MCP Tool Mapping**:

- Default → `search_tasks` with `available_only=true`, `sort_by=importance`
- Quick wins → filter for leaf nodes (no dependents)
- Category filtering → parse domain keywords
- Smart recommendations based on importance scores

**Expected Result**:

- "🎯 Recommended next task: 'Set up database schema'"
  - "Why: Blocks 4 other tasks, highest importance score"
  - "Goal: Backend Development"
  - "Estimated effort: 2 hours"
- "✨ Quick wins available: 3 tasks with no dependencies"

**Example Usage**:

```
/work what's the most impactful task I can do?
/work show me simple tasks to warm up
/work find something in the frontend goal
/work what can alice work on?
```

#### `/status` - Check Progress and Project Health

**Purpose**: Monitor progress at task, goal, and project levels

**Natural Language Arguments**:

- "how's the mobile app goal progressing?"
- "show me what's blocking progress"
- "give me a project health summary"
- "what's at risk of falling behind?"

**MCP Tool Mapping**:

- Progress calculation → `list_goals` + `search_tasks`
- Bottleneck analysis → importance scores + blocked tasks
- Risk identification → long dependency chains
- Velocity tracking → completion rates over time

**Expected Result**:

- "📊 Mobile App Progress: 65% complete (13/20 tasks)"
  - "✅ Completed this week: 5 tasks"
  - "🚧 In progress: 3 tasks"
  - "⚠️ Blocked: 2 tasks (waiting on API design)"
  - "📈 On track for Q2 deadline"

**Example Usage**:

```
/status show overall project health
/status what's blocking the frontend team?
/status how are we tracking against Q2 goals?
/status identify bottlenecks in the workflow
```

#### `/analyze` - Deep Dive into Dependencies and Complexity

**Purpose**: Understand task relationships, critical paths, and complexity

**Natural Language Arguments**:

- "analyze dependencies for the payment feature"
- "show me the critical path to launch"
- "what happens if database setup is delayed?"
- "find circular dependencies"

**MCP Tool Mapping**:

- Dependency traversal → `get_task_details_with_dependencies`
- Critical path calculation → recursive dependency analysis
- Impact analysis → dependent task counting
- Complexity scoring → multiple metrics

**Expected Result**:

- "🔍 Payment Feature Analysis:"
  - "Critical path: Database → User Auth → Payment Gateway → Testing"
  - "Total duration: ~8 days"
  - "Risk: User Auth blocks 6 downstream tasks"
  - "Suggestion: Parallelize Payment UI with backend work"

**Example Usage**:

```
/analyze show critical path for mobile app launch
/analyze what depends on the authentication system?
/analyze find the longest dependency chain
/analyze assess complexity of the backend goal
```

#### `/verify` - Confirm Completion and Quality

**Purpose**: Verify task and goal completion, ensure nothing is missed

**Natural Language Arguments**:

- "verify all tasks are complete for frontend goal"
- "check if we're ready to mark mobile app as done"
- "confirm all dependencies are resolved"
- "validate the payment feature is fully implemented"

**MCP Tool Mapping**:

- Completion check → `list_goals` + `search_tasks`
- Dependency validation → check all blocked statuses
- Checklist verification → task completion analysis
- Missing task detection → pattern analysis

**Expected Result**:

- "✅ Frontend Goal Verification:"
  - "All 15 tasks completed"
  - "No blocked dependencies"
  - "Ready to mark goal as complete"
- "⚠️ Missing common tasks: No documentation task found"

**Example Usage**:

```
/verify check if backend development is complete
/verify validate all tests have been written
/verify confirm mobile app is ready for release
```

#### `/enhance` - Optimize and Improve Workflow

**Purpose**: Suggest optimizations, reorder tasks, improve efficiency

**Natural Language Arguments**:

- "optimize task order to reduce blocking"
- "suggest parallel work opportunities"
- "find ways to speed up the project"
- "recommend task reassignments for better flow"

**MCP Tool Mapping**:

- Workflow analysis → full task graph analysis
- Parallelization opportunities → dependency analysis
- Resource optimization → owner workload analysis
- Reordering suggestions → importance vs dependency balance

**Expected Result**:

- "💡 Optimization Suggestions:"
  - "Parallelize: 'UI Design' and 'API Development' can run simultaneously"
  - "Reorder: Complete 'Database schema' first (unblocks 5 tasks)"
  - "Reassign: Move 2 tasks from Alice to Bob for better balance"
  - "Estimated time savings: 3 days"

**Example Usage**:

```
/enhance optimize the development workflow
/enhance find ways to unblock the team
/enhance suggest task reordering for efficiency
/enhance balance workload across team members
```

## Implementation Priority

### Phase 1: Core Commands (Week 1-2)

1. `/manage-goals` - Basic goal CRUD
1. `/manage-tasks` - Basic task CRUD
1. `/work` - Find available work
1. `/status` - Basic progress tracking

### Phase 2: Planning Commands (Week 3-4)

1. `/plan` - Goal planning
1. `/breakdown` - Task decomposition
1. `/setup` - Project initialization

### Phase 3: Advanced Commands (Week 5-6)

1. `/analyze` - Dependency analysis
1. `/verify` - Completion verification
1. `/generate` - AI-assisted generation
1. `/enhance` - Workflow optimization

## Key Improvements Over Previous Design

1. **Clear Separation**: Resource management vs lifecycle commands removes ambiguity
1. **Purpose-Driven**: Each command has a specific, well-defined purpose
1. **Lifecycle Mapping**: Commands follow natural project phases
1. **Natural Language**: No technical parameters or IDs needed
1. **Intelligent Context**: Commands understand project state and make smart suggestions
1. **Progressive Disclosure**: Simple commands for common tasks, advanced for power users

## Success Criteria

1. **Clarity**: Users immediately understand what each command does
1. **Efficiency**: Common workflows require 50% fewer commands
1. **Discoverability**: Users can guess command names based on intent
1. **Error Recovery**: Helpful suggestions when commands fail
1. **Adoption**: 80% of users prefer new commands over direct MCP tools

## Technical Notes

1. **Natural Language Processing**:

   - Intent classification using keyword patterns
   - Entity extraction for goals, tasks, and people
   - Fuzzy matching with Levenshtein distance
   - Context preservation across commands

1. **Caching Strategy**:

   - In-memory cache of goal/task names to IDs
   - Refresh on any update operation
   - LRU eviction for large projects

1. **Error Handling**:

   - Ambiguous matches: Show options with selection
   - No matches: Suggest similar items or commands
   - Validation: Prevent invalid operations with clear messages

1. **Response Formatting**:

   - Emoji indicators for quick status recognition
   - Tabular data for lists with smart column selection
   - Progress bars and percentages for visual feedback
   - Actionable suggestions in responses
