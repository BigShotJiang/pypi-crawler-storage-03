# Goaly MCP Development Guide

This guide describes the streamlined development environment for Goaly MCP:

- **DevContainer**: Primary development environment with hot-reload
- **Docker**: Production testing environment only

## Quick Start

### DevContainer Development (Recommended)

```bash
# 1. Check prerequisites
./scripts/check-devcontainer.sh

# 2. Install DevContainer CLI if needed
npm install -g @devcontainers/cli

# 3. Start development environment
just dc-up

# 4. Open development shell
just dc-exec
```

### VS Code Integration

1. Install the "Dev Containers" extension
1. Open command palette (Ctrl/Cmd+Shift+P)
1. Select "Dev Containers: Reopen in Container"
1. VS Code builds and starts the container automatically

## DevContainer Features

The DevContainer provides the complete development environment:

- **Hot-reload development** - Code changes trigger automatic reloads
- **Full VS Code integration** - Debugging, IntelliSense, extensions
- **Isolated environment** - All dependencies pre-installed
- **Editable package install** - Changes reflected immediately
- **Database persistence** - SQLite database persists across restarts
- **Debugging support** - Python debugger pre-configured

### Configuration

- **Source code**: Mounted as volume and installed as editable package
- **Database**: SQLite persists in Docker volume
- **Ports**:
  - `8000` - FastAPI server
  - `5678` - Python debugger (when enabled)
- **Environment**: Development tools and VS Code extensions pre-configured

## Production Testing

Docker Compose is used only for production-like testing, not development.

```bash
# Build production image
just docker-build

# Test production environment
just docker-test-prod

# Run production container
just docker-run
```

## Common Tasks

### Development Workflow

```bash
# One-time setup
just quickstart

# Start development
just dc-up
just dc-exec    # Open shell in DevContainer

# The FastAPI server starts automatically with hot-reload
# Make code changes - they're reflected immediately

# Run tests
just dc-test

# Code quality checks
just pre-commit
```

### Database Management

```bash
# Local operations
just db-init        # Initialize database
just db-migrate     # Run migrations
just db-reset       # Reset database (DESTRUCTIVE)

# In DevContainer
just dc-exec
goaly-migrate revision --autogenerate -m "description"
goaly-migrate upgrade head
```

### Testing

```bash
# Local testing
just test           # All tests
just test-fast      # Fast tests only
just test-integration # Integration tests

# DevContainer testing
just dc-test        # Run tests in DevContainer

# Manual testing in DevContainer
just dc-exec
pytest
pytest tests/test_api.py
pytest --cov=goaly_mcp
```

### Debugging

#### DevContainer Debugging (Recommended)

- **VS Code**: Debugging works automatically with Dev Containers extension
- **Breakpoints**: Set breakpoints directly in VS Code
- **Debug Console**: Full Python REPL available

#### Manual debugpy (if needed)

```bash
# In DevContainer
export DEBUGPY_ENABLED=true
export DEBUGPY_WAIT_FOR_CLIENT=true
# Connect debugger to localhost:5678
```

## Troubleshooting

### DevContainer Issues

```bash
# Check environment
./scripts/check-devcontainer.sh

# Rebuild DevContainer
just dc-down && just dc-up

# View logs
just dc-logs

# Clean rebuild
just dc-clean && just dc-up
```

### Database Issues

```bash
# Reset and reinitialize
just db-reset
just db-init

# Check logs
just dc-logs
```

### Hot-reload Issues

1. Ensure using DevContainer (`just dc-up`)
1. Check package installed as editable
1. Restart FastAPI server inside container

## Directory Structure

```
goaly-mcp/
├── .devcontainer/                  # DevContainer configuration
│   ├── devcontainer.json           # DevContainer settings
│   ├── post-create.sh              # Setup script
│   ├── entrypoint.sh               # DevContainer entrypoint
│   └── docker-entrypoint-dev.sh    # Development entrypoint
├── just/                           # Task runner modules
│   ├── devcontainer.just           # DevContainer commands
│   ├── docker.just                 # Production Docker commands
│   └── *.just                      # Other task modules
├── scripts/                        # Utility scripts
│   └── check-devcontainer.sh       # Environment checker
├── src/goaly_mcp/                  # Python source code
├── tests/                          # Test suite
├── docker-compose.yml              # Production testing only
├── Dockerfile                      # Production image
├── Dockerfile.development          # DevContainer image
├── justfile                        # Main task runner
└── pyproject.toml                  # Python configuration
```

## Environment Variables

### Development (.env file)

```bash
GOALY_DEBUG=true                    # Enable debug mode
GOALY_HOST=0.0.0.0                  # Server host
GOALY_PORT=8000                     # Server port
DATABASE_URL=sqlite:///./data/goaly.db

# DevContainer debugging (optional)
DEBUGPY_ENABLED=false               # Python debugger
DEBUGPY_PORT=5678                   # Debugger port
```

### Production Testing

```bash
POSTGRES_PASSWORD=secure-password   # Required for production testing
POSTGRES_DB=goaly
POSTGRES_USER=goaly
```

## Key Commands

### DevContainer Commands

```bash
just dc-up          # Start DevContainer
just dc-exec        # Open shell
just dc-test        # Run tests
just dc-logs        # View logs
just dc-stop        # Stop container
just dc-down        # Stop and remove
just dc-clean       # Clean volumes
just dc-help        # Show all commands
```

### Production Testing Commands

```bash
just docker-build     # Build production image
just docker-test-prod # Start production testing
just docker-run       # Run production container
just docker-logs      # View production logs
just docker-down      # Stop production containers
```

### Code Quality Commands

```bash
just format         # Format all code
just lint           # Lint all code
just type-check     # Type checking
just pre-commit     # All quality checks
```

## Tips

- **Primary development**: Always use DevContainer (`just dc-up`)
- **Production testing**: Use Docker commands for production-like testing
- **Local development**: Available but DevContainer is recommended
- **VS Code users**: Use "Dev Containers: Reopen in Container" for best experience
- **Command discovery**: Use `just --list` to see all available commands
