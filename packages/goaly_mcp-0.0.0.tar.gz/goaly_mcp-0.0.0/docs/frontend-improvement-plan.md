# TaskMaster MCP Frontend Improvement Plan

## Executive Summary

This comprehensive plan addresses the critical findings from the frontend code review and provides a structured approach to improving the TaskMaster MCP React/TypeScript dashboard application. The plan prioritizes technical debt resolution, type safety improvements, and performance optimization while maintaining the existing functionality and architecture strengths.

### Timeline & Effort Overview

- **Total Duration**: 6 weeks
- **Estimated Effort**: 62 hours
- **Team Size**: 1-2 developers
- **Priority**: High impact fixes first, progressive enhancement after

### Key Priorities

1. **Foundation Fixes** (Week 1-2): File extensions, API client, critical type safety
1. **Architecture Improvements** (Week 3-4): Component refactoring, performance optimization
1. **Polish & Enhancement** (Week 5-6): UI/UX improvements, accessibility, testing

## Phase 1: Foundation Fixes (Week 1-2)

### Critical Issues Resolution

**Duration**: 2 weeks | **Effort**: 18 hours

#### 1.1 File Extension Consistency (8 hours)

**Priority**: Critical | **Impact**: Type safety, IDE support, maintainability

**Files to Convert:**

- `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/index.js` → `index.tsx`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/ConnectionStatus.js` → `ConnectionStatus.tsx`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/DashboardStats.js` → `DashboardStats.tsx`
- `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/GoalHierarchyTree.js` → `GoalHierarchyTree.tsx`

**Implementation Steps:**

1. **Convert `index.js` to `index.tsx`** (1 hour)

   ```typescript
   // Before: index.js
   import React from 'react';
   import ReactDOM from 'react-dom/client';

   // After: index.tsx
   import React from 'react';
   import ReactDOM from 'react-dom/client';
   import './index.css';
   import App from './App';

   const root = ReactDOM.createRoot(
     document.getElementById('root') as HTMLElement
   );
   root.render(
     <React.StrictMode>
       <App />
     </React.StrictMode>
   );
   ```

1. **Convert `ConnectionStatus.js` to `ConnectionStatus.tsx`** (2 hours)

   ```typescript
   // Add proper TypeScript interfaces
   interface ConnectionStatusProps {
     status: 'connected' | 'connecting' | 'disconnected';
     onReconnect: () => void;
   }

   interface StatusConfig {
     label: string;
     color: 'success' | 'warning' | 'error';
     icon: React.ReactNode;
   }

   const ConnectionStatus: React.FC<ConnectionStatusProps> = ({
     status,
     onReconnect
   }) => {
     const getStatusProps = (): StatusConfig => {
       switch (status) {
         case "connected":
           return {
             label: "Connected",
             color: "success",
             icon: <CircleIcon sx={{ fontSize: 12 }} />,
           };
         // ... other cases with proper typing
       }
     };
   ```

1. **Convert `DashboardStats.js` to `DashboardStats.tsx`** (2 hours)

   ```typescript
   interface StatsData {
     total_goals: number;
     completed_goals: number;
     total_tasks: number;
     completed_tasks: number;
   }

   interface DashboardStatsProps {
     stats: StatsData;
     loading: boolean;
   }

   const DashboardStats: React.FC<DashboardStatsProps> = ({
     stats,
     loading
   }) => {
     if (loading) {
       return <CircularProgress />;
     }

     const completionRate = stats.total_goals > 0
       ? (stats.completed_goals / stats.total_goals) * 100
       : 0;
   ```

1. **Convert `GoalHierarchyTree.js` to `GoalHierarchyTree.tsx`** (3 hours)

   ```typescript
   interface Goal {
     id: number;
     description: string;
     is_complete: boolean;
     children?: Goal[];
   }

   interface GoalHierarchyData {
     goals: Goal[];
     summary: Record<string, any>;
   }

   interface GoalHierarchyTreeProps {
     data: GoalHierarchyData;
     loading: boolean;
     selectedGoalId?: number | string;
     onGoalSelect?: (goalId: number | string) => void;
   }

   const GoalHierarchyTree: React.FC<GoalHierarchyTreeProps> = ({
     data,
     loading,
     selectedGoalId,
     onGoalSelect
   }) => {
     // Add D3 type definitions for better type safety
     const svgRef = useRef<SVGSVGElement>(null);
   ```

#### 1.2 API Client Resolution (4 hours)

**Priority**: Critical | **Impact**: Build success, runtime stability

**Option A: Generate Missing Client (1 hour)**

```bash
cd frontend
pnpm run generate-client:local
```

**Option B: Manual Service Implementation (4 hours)**
Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/services/api.ts`:

```typescript
// Core API Types
export interface Goal {
  id: number;
  description: string;
  is_complete: boolean;
  created_at: string;
  updated_at: string;
  importance?: number;
  owner?: string;
  children?: Goal[];
}

export interface Task {
  id: number;
  description: string;
  status: 'completed' | 'owned' | 'available' | 'blocked' | 'cancelled';
  goal_id: number;
  owner?: string;
  created_at: string;
  updated_at: string;
}

export interface APIResponse<T> {
  success: boolean;
  data: T;
  error?: string;
  message?: string;
}

export interface GoalHierarchy {
  goals: Goal[];
  summary: Record<string, any>;
}

export interface DependencyGraph {
  nodes: Array<{
    id: string;
    label: string;
    status: string;
    goal_id: number;
    goal_description: string;
  }>;
  edges: Array<{
    source: string;
    target: string;
    type: string;
  }>;
  stats: Record<string, any>;
}

// API Service Layer
const API_BASE_URL = process.env.NODE_ENV === 'development'
  ? 'http://localhost:8000/api/v1'
  : '/api/v1';

class APIClient {
  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<APIResponse<T>> {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      return {
        success: false,
        data: {} as T,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  // Goals API
  async listGoals(): Promise<APIResponse<{ goals: Goal[] }>> {
    return this.request<{ goals: Goal[] }>('/goals');
  }

  async getGoalHierarchy(): Promise<APIResponse<GoalHierarchy>> {
    return this.request<GoalHierarchy>('/goals/hierarchy');
  }

  // Tasks API
  async listTasks(): Promise<APIResponse<{ tasks: Task[] }>> {
    return this.request<{ tasks: Task[] }>('/tasks');
  }

  async getDependencyGraph(goalIds?: number[]): Promise<APIResponse<DependencyGraph>> {
    const params = goalIds?.length
      ? `?goal_ids=${goalIds.join(',')}`
      : '';
    return this.request<DependencyGraph>(`/tasks/dependency-graph${params}`);
  }
}

// Export service instances
export const GoalsService = new APIClient();
export const TasksService = new APIClient();
export { APIClient };
```

**Update import paths in affected files:**

```typescript
// Before: useGoalData.ts
import { GoalsService, TasksService } from "../client";
import type { APIResponse } from "../client";

// After: useGoalData.ts
import { GoalsService, TasksService } from "../services/api";
import type { APIResponse, Goal, Task, GoalHierarchy, DependencyGraph } from "../services/api";
```

#### 1.3 Critical Type Safety Fixes (6 hours)

**Priority**: High | **Impact**: Runtime reliability, debugging

**Update `useGoalData.ts`** (3 hours):

```typescript
// Replace 'any' types with proper interfaces
export const useGoalData = (lastEvent: SSEEvent | null) => {
  const [goalHierarchy, setGoalHierarchy] = useState<GoalHierarchy>({
    goals: [],
    summary: {}
  });
  const [dependencyGraph, setDependencyGraph] = useState<DependencyGraph>({
    nodes: [],
    edges: [],
    stats: {}
  });
  const [stats, setStats] = useState<StatsData>({
    total_goals: 0,
    completed_goals: 0,
    total_tasks: 0,
    completed_tasks: 0,
  });

  const refreshData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      await fetchGoalHierarchy();
      const goalsResponse = await GoalsService.listGoals();
      if (goalsResponse.success) {
        // Remove 'as any' casting
        const goalsData = goalsResponse.data;
        await fetchDependencyGraph(goalsData.goals);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  }, [fetchGoalHierarchy, fetchDependencyGraph]);
```

**Update `TaskDependencyGraph.tsx` interfaces** (2 hours):

```typescript
// Strengthen existing interfaces
interface TaskNodeData {
  label: string;
  status: 'completed' | 'owned' | 'available' | 'blocked' | 'cancelled';
  owner?: string;
  goal_id: number;
  goal_description: string;
  importance: number;
  layoutDirection?: "TB" | "LR";
}

interface GraphStats {
  total_tasks: number;
  completed_tasks: number;
  blocked_tasks: number;
  available_tasks: number;
}

interface DependencyGraphProps {
  data: {
    nodes: TaskNodeData[];
    edges: Array<{
      source: string;
      target: string;
      type: string;
    }>;
    stats: GraphStats;
  };
  loading: boolean;
  selectedGoalId: number | string;
}
```

**Add type definitions file** (1 hour):
Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/types/index.ts`:

```typescript
// Shared type definitions
export type ConnectionStatus = 'connected' | 'connecting' | 'disconnected';
export type TaskStatus = 'completed' | 'owned' | 'available' | 'blocked' | 'cancelled';
export type LayoutDirection = 'TB' | 'LR';

export interface SSEEvent {
  event_type: string;
  data: Record<string, any>;
  timestamp: string;
}

export interface NotificationState {
  open: boolean;
  message: string;
  severity: 'error' | 'warning' | 'info' | 'success';
  autoHideDuration: number;
}
```

### Testing Strategy for Phase 1

**Duration**: Integrated into development | **Effort**: 2 hours

1. **Type Checking Verification**

   ```bash
   cd frontend
   pnpm run type-check
   # Should pass without errors after conversions
   ```

1. **Build Validation**

   ```bash
   pnpm run build
   # Should complete successfully with generated API client
   ```

1. **Runtime Testing**

   - Verify all converted components render correctly
   - Test SSE connection functionality
   - Validate API service calls work as expected

## Phase 2: Component Architecture Improvements (Week 3-4)

### Component Optimization & Performance

**Duration**: 2 weeks | **Effort**: 22 hours

#### 2.1 Split Large Components (12 hours)

**Priority**: Medium | **Impact**: Maintainability, reusability

**TaskDependencyGraph.tsx Refactoring** (8 hours):

1. **Extract TaskNode Component** (3 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/TaskDependencyGraph/TaskNode.tsx`:

   ```typescript
   interface TaskNodeProps {
     data: TaskNodeData;
     selected?: boolean;
   }

   const TaskNode: React.FC<TaskNodeProps> = ({ data, selected }) => {
     const getStatusColor = (status: TaskStatus): string => {
       const statusColors = {
         completed: "#4caf50",
         owned: "#2196f3",
         available: "#ff9800",
         blocked: "#f44336",
         cancelled: "#9e9e9e"
       } as const;
       return statusColors[status] || "#9e9e9e";
     };

     const getImportanceSize = (importance: number): number => {
       return Math.max(40, Math.min(80, 40 + (importance * 4)));
     };

     return (
       <Paper
         elevation={selected ? 8 : 2}
         sx={{
           padding: 1,
           backgroundColor: selected ? "#e3f2fd" : "white",
           border: selected ? "2px solid #2196f3" : "1px solid #e0e0e0",
           borderRadius: 2,
           minWidth: getImportanceSize(data.importance),
           minHeight: getImportanceSize(data.importance),
         }}
       >
         <Handle type="target" position={Position.Left} />
         <Handle type="source" position={Position.Right} />

         <Box display="flex" flexDirection="column" alignItems="center">
           <Typography variant="caption" sx={{ fontWeight: "bold", textAlign: "center" }}>
             {data.label}
           </Typography>

           <Chip
             label={data.status}
             size="small"
             sx={{
               backgroundColor: getStatusColor(data.status),
               color: "white",
               fontSize: "0.7rem",
               mt: 0.5,
             }}
           />

           {data.owner && (
             <Typography variant="caption" color="textSecondary" sx={{ mt: 0.5 }}>
               {data.owner}
             </Typography>
           )}
         </Box>
       </Paper>
     );
   };

   export default React.memo(TaskNode);
   ```

1. **Extract CustomDependencyEdge Component** (2 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/TaskDependencyGraph/CustomDependencyEdge.tsx`:

   ```typescript
   import React from 'react';
   import { BaseEdge, EdgeProps, getBezierPath } from 'reactflow';
   import { Tooltip } from '@mui/material';

   const CustomDependencyEdge: React.FC<EdgeProps> = ({
     sourceX,
     sourceY,
     targetX,
     targetY,
     sourcePosition,
     targetPosition,
     data,
   }) => {
     const [edgePath] = getBezierPath({
       sourceX,
       sourceY,
       sourcePosition,
       targetX,
       targetY,
       targetPosition,
     });

     return (
       <Tooltip title={data?.label || 'Dependency'}>
         <BaseEdge
           path={edgePath}
           style={{
             stroke: '#666',
             strokeWidth: 2,
             strokeDasharray: data?.type === 'soft' ? '5,5' : undefined,
           }}
         />
       </Tooltip>
     );
   };

   export default React.memo(CustomDependencyEdge);
   ```

1. **Extract GoalHeaderNode Component** (2 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/TaskDependencyGraph/GoalHeaderNode.tsx`:

   ```typescript
   interface GoalHeaderNodeProps {
     data: {
       label: string;
       goal_id: number;
       total_tasks: number;
       completed_tasks: number;
     };
   }

   const GoalHeaderNode: React.FC<GoalHeaderNodeProps> = ({ data }) => {
     const completionRate = data.total_tasks > 0
       ? (data.completed_tasks / data.total_tasks) * 100
       : 0;

     return (
       <Paper
         elevation={4}
         sx={{
           padding: 2,
           backgroundColor: "#1976d2",
           color: "white",
           borderRadius: 3,
           minWidth: 200,
         }}
       >
         <Typography variant="h6" sx={{ fontWeight: "bold", mb: 1 }}>
           {data.label}
         </Typography>

         <Typography variant="body2" sx={{ mb: 1 }}>
           Tasks: {data.completed_tasks}/{data.total_tasks}
         </Typography>

         <LinearProgress
           variant="determinate"
           value={completionRate}
           sx={{
             height: 8,
             borderRadius: 4,
             backgroundColor: 'rgba(255,255,255,0.3)',
             '& .MuiLinearProgress-bar': {
               backgroundColor: '#4caf50'
             }
           }}
         />
       </Paper>
     );
   };

   export default React.memo(GoalHeaderNode);
   ```

1. **Refactor Main TaskDependencyGraph Component** (1 hour)

   ```typescript
   // Simplified main component with extracted sub-components
   import TaskNode from './TaskNode';
   import CustomDependencyEdge from './CustomDependencyEdge';
   import GoalHeaderNode from './GoalHeaderNode';

   const nodeTypes = {
     custom: TaskNode,
     goalHeader: GoalHeaderNode,
   };

   const edgeTypes = {
     customDependency: CustomDependencyEdge,
   };

   const TaskDependencyGraph: React.FC<DependencyGraphProps> = ({
     data,
     loading,
     selectedGoalId
   }) => {
     // Component logic using extracted components
     return (
       <ReactFlow
         nodes={nodes}
         edges={edges}
         nodeTypes={nodeTypes}
         edgeTypes={edgeTypes}
         // ... other props
       >
         <Background />
         <Controls />
         <MiniMap />
       </ReactFlow>
     );
   };
   ```

**GoalHierarchyTree Component Refactoring** (4 hours):

1. **Extract D3 Tree Logic** (2 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/hooks/useD3Tree.ts`:

   ```typescript
   interface UseD3TreeProps {
     data: GoalHierarchy;
     dimensions: { width: number; height: number };
     selectedGoalId?: number | string;
     onGoalSelect?: (goalId: number | string) => void;
   }

   export const useD3Tree = ({
     data,
     dimensions,
     selectedGoalId,
     onGoalSelect
   }: UseD3TreeProps) => {
     const svgRef = useRef<SVGSVGElement>(null);

     const renderTree = useCallback(() => {
       if (!data.goals || dimensions.width === 0) return;

       const svg = d3.select(svgRef.current);
       svg.selectAll("*").remove();

       // D3 tree rendering logic
       const margin = { top: 20, right: 120, bottom: 20, left: 120 };
       const innerWidth = dimensions.width - margin.left - margin.right;
       const innerHeight = dimensions.height - margin.top - margin.bottom;

       const g = svg
         .attr("width", dimensions.width)
         .attr("height", dimensions.height)
         .append("g")
         .attr("transform", `translate(${margin.left},${margin.top})`);

       // Tree layout and rendering
       // ... D3 implementation
     }, [data, dimensions, selectedGoalId, onGoalSelect]);

     useEffect(() => {
       renderTree();
     }, [renderTree]);

     return { svgRef };
   };
   ```

1. **Simplify Main Component** (2 hours)

   ```typescript
   const GoalHierarchyTree: React.FC<GoalHierarchyTreeProps> = ({
     data,
     loading,
     selectedGoalId,
     onGoalSelect
   }) => {
     const containerRef = useRef<HTMLDivElement>(null);
     const dimensions = useElementDimensions(containerRef);
     const { svgRef } = useD3Tree({
       data,
       dimensions,
       selectedGoalId,
       onGoalSelect
     });

     if (loading) {
       return (
         <Box display="flex" justifyContent="center" alignItems="center" height="100%">
           <CircularProgress />
         </Box>
       );
     }

     return (
       <Box ref={containerRef} sx={{ width: '100%', height: '100%' }}>
         <svg ref={svgRef} />
       </Box>
     );
   };
   ```

#### 2.2 Performance Optimizations (6 hours)

**Priority**: Medium | **Impact**: Render performance, user experience

1. **Implement React.memo for Expensive Components** (2 hours)

   ```typescript
   // TaskDependencyGraph optimization
   const TaskDependencyGraph = React.memo<DependencyGraphProps>(({
     data,
     loading,
     selectedGoalId
   }) => {
     // Component implementation
   }, (prevProps, nextProps) => {
     // Custom comparison for complex objects
     return (
       prevProps.loading === nextProps.loading &&
       prevProps.selectedGoalId === nextProps.selectedGoalId &&
       JSON.stringify(prevProps.data) === JSON.stringify(nextProps.data)
     );
   });
   ```

1. **Optimize D3 Calculations with useMemo** (2 hours)

   ```typescript
   // In GoalHierarchyTree
   const hierarchicalData = useMemo(() => {
     if (!data.goals) return null;

     return buildHierarchy(data.goals);
   }, [data.goals]);

   const treeLayout = useMemo(() => {
     return d3.tree().size([innerHeight, innerWidth]);
   }, [innerHeight, innerWidth]);
   ```

1. **Bundle Size Optimization** (2 hours)

   - Remove unused `recharts` dependency
   - Replace full D3 import with specific modules
   - Update package.json:

   ```json
   {
     "dependencies": {
       "d3-selection": "^3.0.0",
       "d3-hierarchy": "^3.1.0",
       "d3-shape": "^3.2.0",
       "d3-scale": "^4.0.2"
       // Remove: "d3": "^7.8.5",
       // Remove: "recharts": "^2.7.2"
     }
   }
   ```

#### 2.3 Error Handling Improvements (4 hours)

**Priority**: Medium | **Impact**: User experience, debugging

1. **Implement Error Boundary Component** (2 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/ErrorBoundary.tsx`:

   ```typescript
   interface ErrorBoundaryState {
     hasError: boolean;
     error?: Error;
     errorInfo?: ErrorInfo;
   }

   class ErrorBoundary extends Component<
     React.PropsWithChildren<{}>,
     ErrorBoundaryState
   > {
     constructor(props: React.PropsWithChildren<{}>) {
       super(props);
       this.state = { hasError: false };
     }

     static getDerivedStateFromError(error: Error): ErrorBoundaryState {
       return { hasError: true, error };
     }

     componentDidCatch(error: Error, errorInfo: ErrorInfo) {
       console.error('ErrorBoundary caught an error:', error, errorInfo);
       this.setState({ error, errorInfo });
     }

     render() {
       if (this.state.hasError) {
         return (
           <Paper sx={{ p: 3, m: 2, textAlign: 'center' }}>
             <Typography variant="h6" color="error" gutterBottom>
               Something went wrong
             </Typography>
             <Typography variant="body2" color="textSecondary" paragraph>
               {this.state.error?.message}
             </Typography>
             <Button
               variant="outlined"
               onClick={() => window.location.reload()}
             >
               Refresh Page
             </Button>
           </Paper>
         );
       }

       return this.props.children;
     }
   }
   ```

1. **Enhanced API Error Handling** (2 hours)

   ```typescript
   // In API service
   class APIClient {
     private async request<T>(endpoint: string, options: RequestInit = {}) {
       try {
         const response = await fetch(`${API_BASE_URL}${endpoint}`, options);

         if (!response.ok) {
           const errorData = await response.json().catch(() => ({}));
           throw new APIError(
             errorData.message || `HTTP ${response.status}`,
             response.status,
             errorData
           );
         }

         return await response.json();
       } catch (error) {
         if (error instanceof APIError) throw error;
         throw new APIError(
           'Network request failed',
           0,
           { originalError: error }
         );
       }
     }
   }

   class APIError extends Error {
     constructor(
       message: string,
       public status: number,
       public data?: any
     ) {
       super(message);
       this.name = 'APIError';
     }
   }
   ```

### Testing Strategy for Phase 2

**Duration**: Integrated | **Effort**: 3 hours

1. **Component Testing**

   - Unit tests for extracted components
   - Performance regression testing
   - Error boundary validation

1. **Integration Testing**

   - End-to-end user flows
   - SSE connection resilience
   - API error handling scenarios

## Phase 3: Polish & Enhancement (Week 5-6)

### UI/UX Improvements & Accessibility

**Duration**: 2 weeks | **Effort**: 22 hours

#### 3.1 Accessibility Improvements (8 hours)

**Priority**: Medium | **Impact**: User experience, compliance

1. **ARIA Labels and Semantic HTML** (3 hours)

   ```typescript
   // TaskNode accessibility improvements
   const TaskNode: React.FC<TaskNodeProps> = ({ data, selected }) => {
     return (
       <Paper
         role="button"
         tabIndex={0}
         aria-label={`Task: ${data.label}, Status: ${data.status}${data.owner ? `, Owner: ${data.owner}` : ''}`}
         aria-selected={selected}
         onKeyDown={(e) => {
           if (e.key === 'Enter' || e.key === ' ') {
             e.preventDefault();
             // Handle selection
           }
         }}
         sx={{
           '&:focus': {
             outline: '2px solid #2196f3',
             outlineOffset: '2px',
           }
         }}
       >
         {/* Component content */}
       </Paper>
     );
   };
   ```

1. **Keyboard Navigation** (3 hours)

   ```typescript
   // D3 graph keyboard navigation
   const useKeyboardNavigation = (nodes: Node[], onNodeSelect: (id: string) => void) => {
     const [focusedNodeIndex, setFocusedNodeIndex] = useState(0);

     useEffect(() => {
       const handleKeyDown = (e: KeyboardEvent) => {
         switch (e.key) {
           case 'ArrowDown':
           case 'ArrowRight':
             e.preventDefault();
             setFocusedNodeIndex((prev) =>
               Math.min(prev + 1, nodes.length - 1)
             );
             break;
           case 'ArrowUp':
           case 'ArrowLeft':
             e.preventDefault();
             setFocusedNodeIndex((prev) => Math.max(prev - 1, 0));
             break;
           case 'Enter':
           case ' ':
             e.preventDefault();
             if (nodes[focusedNodeIndex]) {
               onNodeSelect(nodes[focusedNodeIndex].id);
             }
             break;
         }
       };

       document.addEventListener('keydown', handleKeyDown);
       return () => document.removeEventListener('keydown', handleKeyDown);
     }, [nodes, focusedNodeIndex, onNodeSelect]);

     return focusedNodeIndex;
   };
   ```

1. **Screen Reader Support** (2 hours)

   ```typescript
   // Add live region for dynamic updates
   const LiveRegion: React.FC<{ message: string }> = ({ message }) => (
     <div
       aria-live="polite"
       aria-atomic="true"
       style={{
         position: 'absolute',
         left: '-10000px',
         width: '1px',
         height: '1px',
         overflow: 'hidden',
       }}
     >
       {message}
     </div>
   );

   // Usage in TaskDependencyGraph
   const [announceMessage, setAnnounceMessage] = useState('');

   useEffect(() => {
     if (lastEvent) {
       setAnnounceMessage(
         `Data updated: ${lastEvent.event_type.replace('_', ' ')}`
       );
     }
   }, [lastEvent]);
   ```

#### 3.2 Responsive Design Enhancements (6 hours)

**Priority**: Medium | **Impact**: Mobile experience

1. **Mobile-First Layout** (3 hours)

   ```typescript
   // Update App.tsx for better mobile support
   const useResponsiveLayout = () => {
     const theme = useTheme();
     const isMobile = useMediaQuery(theme.breakpoints.down('md'));
     const isTablet = useMediaQuery(theme.breakpoints.down('lg'));

     return {
       isMobile,
       isTablet,
       gridSpacing: isMobile ? 2 : 3,
       paperPadding: isMobile ? 1 : 2,
       chartHeight: isMobile ? 400 : 600,
     };
   };

   const AppContent: React.FC = () => {
     const { isMobile, isTablet, gridSpacing, paperPadding, chartHeight } =
       useResponsiveLayout();

     return (
       <Container maxWidth="xl">
         <Grid container spacing={gridSpacing}>
           <Grid item xs={12} lg={6}>
             <Paper sx={{ p: paperPadding, height: chartHeight }}>
               <GoalHierarchyTree />
             </Paper>
           </Grid>

           <Grid item xs={12} lg={6}>
             <Paper sx={{ p: paperPadding, height: chartHeight }}>
               <TaskDependencyGraph />
             </Paper>
           </Grid>

           {isMobile && (
             <Grid item xs={12}>
               <DashboardStats />
             </Grid>
           )}
         </Grid>
       </Container>
     );
   };
   ```

1. **Touch-Friendly Interactions** (2 hours)

   ```typescript
   // Enhanced touch support for D3 graphs
   const addTouchSupport = (svg: d3.Selection<SVGSVGElement, unknown, null, undefined>) => {
     let touchStartTime: number;

     svg.on('touchstart', function(event) {
       touchStartTime = Date.now();
       event.preventDefault();
     })
     .on('touchend', function(event) {
       const touchDuration = Date.now() - touchStartTime;

       if (touchDuration < 500) { // Short tap
         const touch = event.changedTouches[0];
         const element = document.elementFromPoint(touch.clientX, touch.clientY);
         // Handle tap interaction
       }

       event.preventDefault();
     });
   };
   ```

1. **Adaptive Component Sizing** (1 hour)

   ```typescript
   // Responsive task node sizing
   const getResponsiveNodeSize = (importance: number, isMobile: boolean) => {
     const baseSize = isMobile ? 30 : 40;
     const maxSize = isMobile ? 60 : 80;
     return Math.max(baseSize, Math.min(maxSize, baseSize + (importance * (isMobile ? 2 : 4))));
   };
   ```

#### 3.3 Performance Monitoring & Analytics (4 hours)

**Priority**: Low | **Impact**: Performance insights

1. **Web Vitals Integration** (2 hours)

   ```typescript
   // Add to index.tsx
   import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

   const sendToAnalytics = (metric: any) => {
     // In development, log to console
     if (process.env.NODE_ENV === 'development') {
       console.log('Web Vital:', metric);
     }

     // In production, you might send to monitoring service
     // analytics.track('web-vital', metric);
   };

   getCLS(sendToAnalytics);
   getFID(sendToAnalytics);
   getFCP(sendToAnalytics);
   getLCP(sendToAnalytics);
   getTTFB(sendToAnalytics);
   ```

1. **Performance Profiling Hook** (2 hours)

   ```typescript
   // Custom hook for performance monitoring
   export const usePerformanceProfiler = (componentName: string) => {
     const renderStart = useRef<number>();
     const [renderTime, setRenderTime] = useState<number>(0);

     useEffect(() => {
       renderStart.current = performance.now();
     });

     useLayoutEffect(() => {
       if (renderStart.current) {
         const duration = performance.now() - renderStart.current;
         setRenderTime(duration);

         if (process.env.NODE_ENV === 'development' && duration > 16) {
           console.warn(
             `${componentName} render took ${duration.toFixed(2)}ms (>16ms threshold)`
           );
         }
       }
     });

     return renderTime;
   };
   ```

#### 3.4 Advanced Testing Implementation (4 hours)

**Priority**: Medium | **Impact**: Code quality, regression prevention

1. **Component Unit Tests** (2 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/components/__tests__/TaskNode.test.tsx`:

   ```typescript
   import { render, screen, fireEvent } from '@testing-library/react';
   import TaskNode from '../TaskDependencyGraph/TaskNode';
   import { TaskNodeData } from '../../types';

   const mockNodeData: TaskNodeData = {
     label: 'Test Task',
     status: 'available',
     owner: 'John Doe',
     goal_id: 1,
     goal_description: 'Test Goal',
     importance: 5,
   };

   describe('TaskNode', () => {
     it('renders task information correctly', () => {
       render(<TaskNode data={mockNodeData} />);

       expect(screen.getByText('Test Task')).toBeInTheDocument();
       expect(screen.getByText('available')).toBeInTheDocument();
       expect(screen.getByText('John Doe')).toBeInTheDocument();
     });

     it('handles keyboard navigation', () => {
       const onSelect = jest.fn();
       render(<TaskNode data={mockNodeData} onSelect={onSelect} />);

       const taskNode = screen.getByRole('button');
       fireEvent.keyDown(taskNode, { key: 'Enter' });

       expect(onSelect).toHaveBeenCalledWith(mockNodeData);
     });
   });
   ```

1. **Integration Tests** (2 hours)
   Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/src/__tests__/App.integration.test.tsx`:

   ```typescript
   import { render, screen, waitFor } from '@testing-library/react';
   import { BrowserRouter } from 'react-router-dom';
   import App from '../App';

   // Mock API responses
   jest.mock('../services/api', () => ({
     GoalsService: {
       listGoals: () => Promise.resolve({
         success: true,
         data: { goals: [] }
       }),
       getGoalHierarchy: () => Promise.resolve({
         success: true,
         data: { goals: [], summary: {} }
       })
     }
   }));

   describe('App Integration', () => {
     it('loads dashboard components successfully', async () => {
       render(
         <BrowserRouter>
           <App />
         </BrowserRouter>
       );

       await waitFor(() => {
         expect(screen.getByText('Goal Task Manager Dashboard')).toBeInTheDocument();
       });

       expect(screen.getByRole('button', { name: /connected/i })).toBeInTheDocument();
     });
   });
   ```

### Configuration Updates

**Duration**: Integrated | **Effort**: 1 hour

**Enhanced TypeScript Configuration:**

```json
{
  "compilerOptions": {
    // ... existing options
    "noImplicitReturns": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "exactOptionalPropertyTypes": true,
    "noUncheckedIndexedAccess": true
  },
  "include": [
    "src/**/*",
    "src/**/*.test.*"
  ]
}
```

**ESLint Configuration Enhancement:**
Create `/Users/brian/workspace/onegrep/taskmaster-mcp/frontend/.eslintrc.js`:

```javascript
module.exports = {
  extends: [
    'react-app',
    'react-app/jest',
    '@typescript-eslint/recommended'
  ],
  rules: {
    '@typescript-eslint/no-unused-vars': 'error',
    '@typescript-eslint/no-explicit-any': 'warn',
    'react-hooks/exhaustive-deps': 'warn',
    'react/jsx-key': 'error'
  }
};
```

## Success Metrics & Validation

### Phase 1 Success Criteria

- [ ] All `.js` files converted to `.tsx` with proper TypeScript interfaces
- [ ] Zero TypeScript compilation errors (`pnpm run type-check`)
- [ ] Successful build without API client errors (`pnpm run build`)
- [ ] All components render without runtime errors
- [ ] SSE connection maintains functionality

### Phase 2 Success Criteria

- [ ] TaskDependencyGraph.tsx split into \< 300 lines per component
- [ ] React DevTools Profiler shows \< 16ms render times for large datasets
- [ ] Bundle size reduced by > 15% (remove unused dependencies)
- [ ] Error boundary catches and displays errors gracefully
- [ ] Memory usage stable during prolonged usage

### Phase 3 Success Criteria

- [ ] WCAG 2.1 AA compliance (lighthouse accessibility score > 90)
- [ ] Responsive design works on mobile devices (320px - 1920px)
- [ ] Keyboard navigation works for all interactive elements
- [ ] Test coverage > 70% for critical components
- [ ] Web Vitals scores in "Good" range (LCP \< 2.5s, FID \< 100ms, CLS \< 0.1)

## Maintenance & Future Considerations

### Ongoing Tasks

1. **Monthly Dependency Updates**: Keep packages current for security
1. **Performance Monitoring**: Track Web Vitals in production
1. **Accessibility Testing**: Regular screen reader validation
1. **Bundle Size Monitoring**: Prevent regression with new features

### Future Enhancements

1. **Advanced Features**:

   - Real-time collaboration indicators
   - Advanced filtering and search capabilities
   - Drag-and-drop task reorganization
   - Export/import functionality

1. **Technical Improvements**:

   - Service Worker implementation for offline support
   - Advanced caching strategies
   - GraphQL migration for more efficient data fetching
   - Component library extraction for reusability

1. **Developer Experience**:

   - Storybook integration for component development
   - Automated visual regression testing
   - CI/CD pipeline optimization
   - Advanced debugging tools integration

## Risk Assessment & Mitigation

### High Risk Items

1. **API Client Generation Failure**

   - *Mitigation*: Implement manual service layer as fallback
   - *Timeline Impact*: +2 hours if generation fails

1. **D3.js TypeScript Conversion Complexity**

   - *Mitigation*: Incremental conversion with proper type definitions
   - *Timeline Impact*: +4 hours for complex visualizations

1. **Large Component Refactoring Bugs**

   - *Mitigation*: Comprehensive testing at each refactoring step
   - *Timeline Impact*: +3 hours for debugging and fixes

### Medium Risk Items

1. **Performance Regression**

   - *Mitigation*: Before/after performance benchmarks
   - *Timeline Impact*: +2 hours for optimization tweaks

1. **Mobile Responsiveness Issues**

   - *Mitigation*: Progressive enhancement approach
   - *Timeline Impact*: +3 hours for cross-device testing

## Conclusion

This comprehensive improvement plan transforms the TaskMaster MCP frontend from a mixed JavaScript/TypeScript codebase with critical dependencies issues into a robust, type-safe, performant React application. The phased approach ensures minimal disruption to functionality while systematically addressing technical debt and enhancing user experience.

The plan emphasizes:

- **Foundation First**: Critical issues resolved before enhancements
- **Progressive Enhancement**: Each phase builds upon the previous
- **Measurable Success**: Clear metrics for each phase completion
- **Risk Mitigation**: Identified risks with concrete mitigation strategies

Upon completion, the codebase will be significantly more maintainable, performant, and accessible while preserving the solid architectural foundation already in place.
