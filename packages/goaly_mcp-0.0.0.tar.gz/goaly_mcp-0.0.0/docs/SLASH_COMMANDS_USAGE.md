# Goaly MCP Slash Commands - Usage Guide

This document explains how to use the newly implemented high-level slash commands with Claude Code.

## Overview

The Goaly MCP server now provides 11 natural language slash commands that can be used directly in Claude Code. These commands are automatically available when the Goaly MCP server is connected.

## Available Commands

### Resource Management Commands

#### `/goaly:manage_goals`

**Purpose**: Complete goal resource management (create, list, update, delete)

**Example Usage**:

```
/goaly:manage_goals create a new goal for website redesign
/goaly:manage_goals show all active goals
/goaly:manage_goals mark website redesign as complete
/goaly:manage_goals show completed goals
```

#### `/goaly:manage_tasks`

**Purpose**: Complete task resource management within goals

**Example Usage**:

```
/goaly:manage_tasks add implement payment gateway to the ecommerce project
/goaly:manage_tasks show tasks for website redesign
/goaly:manage_tasks assign frontend tasks to alice
/goaly:manage_tasks complete the database setup task
```

### Lifecycle Commands

#### `/goaly:setup`

**Purpose**: Initialize project structure and environment

**Example Usage**:

```
/goaly:setup create a new mobile app project
/goaly:setup initialize ecommerce project with standard phases
```

#### `/goaly:plan`

**Purpose**: Strategic goal planning and objective setting

**Example Usage**:

```
/goaly:plan create goals for Q2 product launch
/goaly:plan outline quarterly objectives for engineering team
```

#### `/goaly:breakdown`

**Purpose**: Break down goals into concrete, actionable tasks

**Example Usage**:

```
/goaly:breakdown decompose the frontend development goal
/goaly:breakdown create tasks for user authentication system
```

#### `/goaly:generate`

**Purpose**: AI-assisted task generation from requirements

**Example Usage**:

```
/goaly:generate create tasks from the API specification
/goaly:generate suggest testing tasks for payment system
```

#### `/goaly:work`

**Purpose**: Find and start available work

**Example Usage**:

```
/goaly:work what should I work on next?
/goaly:work show me quick wins I can complete today
/goaly:work find available backend tasks
```

#### `/goaly:status`

**Purpose**: Check progress and project health

**Example Usage**:

```
/goaly:status how's the mobile app project progressing?
/goaly:status show me what's blocking progress
/goaly:status give me overall project health
```

#### `/goaly:analyze`

**Purpose**: Deep analysis of dependencies and complexity

**Example Usage**:

```
/goaly:analyze show critical path for launch
/goaly:analyze what depends on the authentication system?
/goaly:analyze find bottlenecks in the workflow
```

#### `/goaly:verify`

**Purpose**: Verify completion and ensure quality

**Example Usage**:

```
/goaly:verify check if frontend development is complete
/goaly:verify confirm mobile app is ready for release
```

#### `/goaly:enhance`

**Purpose**: Optimize and improve workflow

**Example Usage**:

```
/goaly:enhance optimize the development workflow
/goaly:enhance find ways to unblock the team
/goaly:enhance balance workload across team members
```

## How It Works

1. **Natural Language**: All commands accept plain English descriptions - no need for IDs or technical syntax
1. **Context Aware**: Commands understand project state and make intelligent suggestions
1. **Tool Integration**: Each command can call multiple MCP tools to accomplish complex workflows
1. **Smart Matching**: Commands use fuzzy matching to find goals and tasks by description

## Setup Requirements

1. **Start the Goaly MCP Server** (in a separate terminal):

   ```bash
   # In the project directory
   just serve
   ```

   This will start the server with packaged frontend listening on `http://localhost:8000/mcp`

1. **Connect Claude Code to the MCP Server** (example .mcp.json):

   ```json
   {
     "mcpServers": {
       "goaly": {
         "type": "http",
         "url": "http://localhost:8000/mcp"
       }
     }
   }
   ```

1. **Use Commands in Claude Code**:

   - Commands will be automatically discovered as `/goaly:<command>`
   - Use natural language arguments
   - No technical parameters required

**Note**: A Docker solution for easier deployment is coming soon.

## Tips for Best Results

- **Be Descriptive**: Use clear, descriptive language for goals and tasks
- **Context Matters**: Commands work better when you provide context about what you're trying to accomplish
- **Workflow Oriented**: Use the lifecycle commands in sequence for best results (setup → plan → breakdown → work → status)
- **Natural Language**: Don't worry about exact syntax - the commands understand conversational input

## Troubleshooting

- **Commands Not Available**: Ensure the Goaly MCP server is running and connected
- **Connection Issues**: Check the MCP server logs for connection errors
- **Template Errors**: Verify all prompt files exist in the `prompts/` directory
