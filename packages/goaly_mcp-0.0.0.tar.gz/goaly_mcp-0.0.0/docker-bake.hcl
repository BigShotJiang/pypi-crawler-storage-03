# Docker Bake configuration for multi-platform builds
# Use: docker buildx bake --push

variable "REGISTRY" {
  default = "ghcr.io"
}

variable "NAMESPACE" {
  default = "toolprint"
}

variable "IMAGE_NAME" {
  default = "goaly-mcp"
}

variable "VERSION" {
  default = "latest"
}

variable "GITHUB_SHA" {
  default = ""
}

# Build platforms
variable "PLATFORMS" {
  default = "linux/amd64,linux/arm64"
}

# Build tags
function "tags" {
  params = [suffix]
  result = [
    "${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${suffix}",
    suffix == "latest" ? "${REGISTRY}/${NAMESPACE}/${IMAGE_NAME}:${VERSION}" : "",
  ]
}

# Base target configuration
target "base" {
  context = "."
  dockerfile = "docker/production/Dockerfile"
  platforms = split(",", PLATFORMS)
  pull = true

  labels = {
    "org.opencontainers.image.title" = "Goaly MCP Server"
    "org.opencontainers.image.description" = "Goal and Task Management with Model Context Protocol"
    "org.opencontainers.image.vendor" = "Toolprint"
    "org.opencontainers.image.licenses" = "MIT"
    "org.opencontainers.image.source" = "https://github.com/toolprint/goaly-mcp"
    "org.opencontainers.image.documentation" = "https://github.com/toolprint/goaly-mcp/blob/main/README.md"
    "org.opencontainers.image.created" = "${timestamp()}"
    "org.opencontainers.image.revision" = "${GITHUB_SHA}"
    "org.opencontainers.image.version" = "${VERSION}"
  }

  args = {
    BUILDKIT_INLINE_CACHE = "1"
  }
}

# Production build (uses wheel-based build for efficiency)
target "production" {
  inherits = ["base"]
  dockerfile = "docker/production/Dockerfile"
  tags = tags("latest")

  cache-from = [
    "type=gha,scope=goaly-mcp-prod"
  ]
  cache-to = [
    "type=gha,scope=goaly-mcp-prod,mode=max"
  ]
}

# Development build (includes dev dependencies)
target "development" {
  inherits = ["base"]
  tags = tags("dev")
  target = "runtime"

  args = {
    INSTALL_DEV = "true"
  }

  cache-from = [
    "type=gha,scope=goaly-mcp-dev"
  ]
  cache-to = [
    "type=gha,scope=goaly-mcp-dev,mode=max"
  ]
}

# Tagged version build
target "version" {
  inherits = ["production"]
  tags = tags(VERSION)
}

# Wheel-based build (uses pre-built wheel with frontend assets)
target "wheel" {
  inherits = ["base"]
  dockerfile = "docker/production/Dockerfile"
  tags = tags("wheel")

  cache-from = [
    "type=gha,scope=goaly-mcp-wheel"
  ]
  cache-to = [
    "type=gha,scope=goaly-mcp-wheel,mode=max"
  ]
}

# Local development build (uses pre-built wheel - preferred method)
target "local" {
  inherits = ["base"]
  dockerfile = "docker/production/Dockerfile"
  tags = ["goaly-mcp:local"]
  platforms = ["linux/amd64"]
  output = ["type=docker"]

  cache-from = [
    "type=local,src=.buildx-cache"
  ]
  cache-to = [
    "type=local,dest=.buildx-cache,mode=max"
  ]
}

# Alternative local build (for testing different configurations)
target "local-legacy" {
  inherits = ["base"]
  dockerfile = "docker/production/Dockerfile"
  tags = ["goaly-mcp:local-legacy"]
  platforms = ["linux/amd64"]
  output = ["type=docker"]

  cache-from = [
    "type=local,src=.buildx-cache-legacy"
  ]
  cache-to = [
    "type=local,dest=.buildx-cache-legacy,mode=max"
  ]
}

# Build all targets
group "all" {
  targets = ["production", "development"]
}

# Default target
group "default" {
  targets = ["production"]
}
