"""Provide a barebones setup.py for `pip install -e` to work."""

from setuptools import setup

setup()
