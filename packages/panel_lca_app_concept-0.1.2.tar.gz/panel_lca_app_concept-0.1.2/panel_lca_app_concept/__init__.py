"""panel_lca_app_concept."""

__all__ = (
    "__version__",
    # Add functions and variables you want exposed in `panel_lca_app_concept.` namespace here
)

__version__ = "0.1.2"
