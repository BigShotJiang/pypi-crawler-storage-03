
string_navbar_items = [
            "Admin",
            "Dashboard",           
        ]