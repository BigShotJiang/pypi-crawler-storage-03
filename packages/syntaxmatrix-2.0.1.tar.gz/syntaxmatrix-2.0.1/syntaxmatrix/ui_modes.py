UI_MODES = {
    "default": {  #1
       
    },
    "bubble": {  #2
        
    },
    "card": {  #3

    },
    "smx": {  #4

    },
}
