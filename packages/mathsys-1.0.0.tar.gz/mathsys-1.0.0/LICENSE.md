© 2025 alejandro-vaz. All rights reserved. No part of this work may be copied,
modified, or distributed in any form without my prior written permission.
License terms to follow.