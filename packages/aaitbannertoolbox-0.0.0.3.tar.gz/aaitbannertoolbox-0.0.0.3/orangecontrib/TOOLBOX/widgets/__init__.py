"""
Widgets from Development workflow category

"""
# ID = "orangecontrib.AAIT"

NAME = "AAIT - TOOLBOX"

# Category icon show in the menu
ICON = "icons/tools.png"

BACKGROUND = "light-orange"

DESCRIPTION = ("AAIT - Toolobx  is a package meant to develop and enable advanced AI "
               "functionalities in Orange Data Mining.")



# PRIORITY = 6