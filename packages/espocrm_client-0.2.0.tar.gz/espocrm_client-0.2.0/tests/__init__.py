"""
EspoCRM Client Tests Package

Gerçek EspoCRM sunucusuna bağlanan CRUD testleri.
"""
