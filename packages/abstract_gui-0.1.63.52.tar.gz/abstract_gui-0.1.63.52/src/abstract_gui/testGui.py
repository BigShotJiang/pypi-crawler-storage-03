from WindowManagerApp import start_window_info_gui
start_window_info_gui()

