""" Macaulay2 Kernel for Jupyter
"""

__version__ = '0.6.7.2'

from .kernel import M2Kernel
from .kernel import M2Interp