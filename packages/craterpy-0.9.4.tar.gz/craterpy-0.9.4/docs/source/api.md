# Craterpy API Documentation

## The CraterDatabase

```{eval-rst}
.. autoclass:: craterpy.classes.CraterDatabase
    :members:
```
<!-- TODO: update plotting and helper docs
## Plotting module

```{eval-rst}
.. automodule:: craterpy.plotting
    :members:
    :undoc-members:
```

## Helper functions

```{eval-rst}
.. automodule:: craterpy.helper
    :members:
    :undoc-members:
``` -->
