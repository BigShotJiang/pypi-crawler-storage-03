1.  Go to Invoicing \> Customers \> Customer Payment Returns, and create
    a new record, register on each line a paid (reconciled) receivable
    journal item, and input the amount that is going to be returned.

    Another option to fill info is setting references and click match
    button to find matches with invoices, move lines or moves. This
    functionality is extended by other modules as
    *account_payment_return_import_sepa_pain*

2.  It's possible to add bank charges amount on each line.

3.  Next, press button "Confirm" to create a new move line that removes
    the balance from the bank journal and reconcile items together to
    show payment history through it.

4.  After confirmation you can access from the payment form view to the
    move created.
