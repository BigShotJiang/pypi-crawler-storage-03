# Copyright (c) Alibaba, Inc. and its affiliates.

from evalscope.third_party.thinkbench.eval import run_task
