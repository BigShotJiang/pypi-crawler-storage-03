# Copyright (c) Alibaba, Inc. and its affiliates.

from evalscope.third_party.longbench_write.longbench_write import run_task
