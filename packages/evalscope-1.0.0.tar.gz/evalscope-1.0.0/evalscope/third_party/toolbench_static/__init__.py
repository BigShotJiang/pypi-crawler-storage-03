# Copyright (c) Alibaba, Inc. and its affiliates.

from evalscope.third_party.toolbench_static.toolbench_static import run_task
