# Copyright (c) Alibaba, Inc. and its affiliates.

__version__ = '1.0.0'
__release_datetime__ = '2025-08-25 12:00:00'
