from .usecaseresult import UseCaseResult
from .usecaseresult import Failure
from .usecaseresult import AccessDenied
from .usecaseresult import NoResult
from .usecaseresult import Success
