# GenAI Colosseum

A CLI to list and generate starter GenAI projects like chatbots, summarizers, etc.

## Usage

```bash
# List available templates
genai-colosseum list

# Install a template
genai-colosseum install chatbot
```
