"""Values for async API client for SEKO Pooldose."""
