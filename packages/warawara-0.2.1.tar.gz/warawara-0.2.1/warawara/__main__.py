from . import bin

bin.warawara.main()
