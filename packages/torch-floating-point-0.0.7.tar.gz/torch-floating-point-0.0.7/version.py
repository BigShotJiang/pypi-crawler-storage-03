#!/usr/bin/env python3
"""
Centralized version management for torch-floating-point project.
"""

__version__ = "0.0.7"

if __name__ == "__main__":
    print(__version__)
