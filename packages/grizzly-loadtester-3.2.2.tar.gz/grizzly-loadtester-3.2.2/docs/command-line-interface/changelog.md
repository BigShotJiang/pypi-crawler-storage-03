---
title: Changelog
---
# Changelog

@shell cd ../../ && script/docs-generate.bash cli --changelog
