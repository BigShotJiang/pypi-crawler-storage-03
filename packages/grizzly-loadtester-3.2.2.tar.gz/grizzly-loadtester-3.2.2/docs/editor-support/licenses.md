---
title: Licenses
---
# Licenses

@shell cd ../../ && script/docs-generate.bash lsp --licenses
