---
title: Visual Studio Code
---
@shell curl -L https://raw.githubusercontent.com/Biometria-se/grizzly-lsp/main/client/vscode/README.md
