# Changelog

## 0.1.3
- Include source code in pypi distribution.

## 0.1.2
- First public release on crates.io and pypi.
