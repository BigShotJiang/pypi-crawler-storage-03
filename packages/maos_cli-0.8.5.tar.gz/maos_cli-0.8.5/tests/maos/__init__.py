"""
Test suite for MAOS orchestration system.
"""