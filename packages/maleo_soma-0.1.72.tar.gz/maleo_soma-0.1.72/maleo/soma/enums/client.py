from enum import StrEnum


class ClientCategory(StrEnum):
    GOOGLE = "google"
    MALEO = "maleo"
