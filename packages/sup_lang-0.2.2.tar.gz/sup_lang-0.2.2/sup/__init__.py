"""Sup Language package."""

from .cli import main as cli_main  # re-export

__all__ = ["cli_main"]

