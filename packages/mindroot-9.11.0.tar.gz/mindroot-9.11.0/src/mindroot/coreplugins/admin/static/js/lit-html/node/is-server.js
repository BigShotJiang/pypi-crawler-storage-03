/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const o=!0;export{o as isServer};
//# sourceMappingURL=is-server.js.map
