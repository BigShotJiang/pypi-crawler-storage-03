Go to the membership product, and check "Prorate" in it. When you create
invoices that includes a membership product by hand or pressing the
button "Buy Membership" from members form.
