When you have a periodical fee (like a yearly fee), maybe you want to
have membership only for the selected period, but don't charge the
customer the full fee, only the proportional part. With this module you
can do it.
