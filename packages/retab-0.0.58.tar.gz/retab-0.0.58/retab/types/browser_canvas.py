from typing import Literal

BrowserCanvas = Literal["A3", "A4", "A5"]
