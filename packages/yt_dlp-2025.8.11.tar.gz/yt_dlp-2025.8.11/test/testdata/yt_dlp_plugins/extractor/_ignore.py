from yt_dlp.extractor.common import InfoExtractor


class IgnorePluginIE(InfoExtractor):
    pass
