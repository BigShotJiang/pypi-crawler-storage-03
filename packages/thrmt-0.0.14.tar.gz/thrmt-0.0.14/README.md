# 🔥🎲 `ThRMT`

*Torched* Random Matrix Theory
