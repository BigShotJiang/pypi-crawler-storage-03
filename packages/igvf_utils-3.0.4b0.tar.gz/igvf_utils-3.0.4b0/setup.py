###
# © 2018 The Board of Trustees of the Leland Stanford Junior University
# Nathaniel Watson
# nathankw@stanford.edu
###

# This setup.py is maintained for backward compatibility.
# Modern packaging configuration is in pyproject.toml

from setuptools import setup

# All configuration is now in pyproject.toml
setup()
