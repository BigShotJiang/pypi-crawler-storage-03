import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const stepPlugin: JupyterFrontEndPlugin<void>;
export default stepPlugin;
