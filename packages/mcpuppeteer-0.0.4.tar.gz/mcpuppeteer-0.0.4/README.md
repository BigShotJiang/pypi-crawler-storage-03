# PyMcPuppeteer

A work in progress python library for controlling minecraft. I have not documented **ANYTHING** yet. All can still change at **ANY** moment.
