"""
Tests (run with `python3 -m pytest -rxPXs | tee results.txt`)
"""
