import time
from masque.file.gdsii_arrow import readfile, _read_to_arrow

#time.sleep(5)
lib, props = readfile('/home/jan/Downloads/sg13g2_io.gds')
#arr = _read_to_arrow('/home/jan/Downloads/sg13g2_io.gds')
