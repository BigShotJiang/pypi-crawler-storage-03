# My Common Python Utils

[![Python application](https://github.com/droneshire/my-py-utils/actions/workflows/python-app.yml/badge.svg)](https://github.com/droneshire/my-py-utils/actions/workflows/python-app.yml)
[![Upload Python Package](https://github.com/droneshire/my-py-utils/actions/workflows/python-publish.yml/badge.svg)](https://github.com/droneshire/my-py-utils/actions/workflows/python-publish.yml)

A collection of util files that I've built over time for various projects that I've built
