class TelegramAPIError(Exception):
    pass