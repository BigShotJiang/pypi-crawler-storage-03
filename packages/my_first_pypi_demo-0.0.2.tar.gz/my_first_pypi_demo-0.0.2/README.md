# my-first-pypi-demo

A simple Python package to practice publishing to PyPI.

## Usage

```python
from my_first_pypi_demo import say_hello

print(say_hello())
````

