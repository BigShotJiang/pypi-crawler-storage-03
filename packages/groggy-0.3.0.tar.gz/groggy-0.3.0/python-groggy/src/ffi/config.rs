//! FFI Configuration
//!
//! This module provides Python bindings for Groggy configuration.

// Placeholder for configuration FFI
// We'll implement this as needed during modularization
