"""
Groggy Test Suite

This package contains validation tests for Groggy functionality.
"""