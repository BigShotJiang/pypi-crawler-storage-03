"""Devento SDK tests."""
