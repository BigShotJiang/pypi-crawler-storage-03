# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause


class EmptyDatasetError(Exception):
    """Raised when a dataset is empty."""
