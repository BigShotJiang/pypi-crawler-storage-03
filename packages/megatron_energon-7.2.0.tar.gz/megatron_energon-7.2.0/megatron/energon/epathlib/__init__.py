# Copyright (c) 2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: BSD-3-Clause

from megatron.energon.epathlib.epath import EPath

__all__ = ["EPath"]
