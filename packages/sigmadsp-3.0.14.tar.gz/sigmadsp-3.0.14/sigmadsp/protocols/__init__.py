"""This module exposes protocols that are used for DSP control (SPI, I2C)."""
