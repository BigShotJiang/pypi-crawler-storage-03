"""This module provides DSP specific implementations for controlling different chipsets."""
