"""Helper functionality, e.g. conversion functions and configuration file parsers."""
