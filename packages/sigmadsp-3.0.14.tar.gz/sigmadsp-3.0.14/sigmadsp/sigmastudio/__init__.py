"""Modules that are used for communication with SigmaStudio."""
