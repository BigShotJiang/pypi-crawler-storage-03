"""A module, which contains only generated files."""
