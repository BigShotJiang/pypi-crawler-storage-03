"""Metadata for examexam."""

__all__ = ["__title__", "__version__", "__description__", "__requires_python__"]

__title__ = "examexam"
__version__ = "0.1.1"
__description__ = "Let LLM generate tests, validate test, and then you take them. Useful for certs."
__requires_python__ = ">=3.11"
