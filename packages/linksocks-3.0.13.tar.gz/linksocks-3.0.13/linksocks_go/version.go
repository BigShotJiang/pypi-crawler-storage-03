package linksocks

import "runtime"

var (
	Version  = "v3.0.13"
	Platform = runtime.GOOS + "/" + runtime.GOARCH
)
