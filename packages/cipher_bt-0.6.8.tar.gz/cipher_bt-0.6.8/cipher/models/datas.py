class Datas(list):
    @property
    def df(self):
        return self[0]
