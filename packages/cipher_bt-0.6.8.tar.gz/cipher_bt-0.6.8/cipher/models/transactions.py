class Transactions(list):
    pass
