from enum import Enum


class Template(str, Enum):
    default = "default"
