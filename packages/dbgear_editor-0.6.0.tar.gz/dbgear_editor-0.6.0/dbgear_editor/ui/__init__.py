"""UI components for DBGear Editor."""
