# Testing

How to run and structure tests for pyngb.

```bash
uv run pytest -q
```
