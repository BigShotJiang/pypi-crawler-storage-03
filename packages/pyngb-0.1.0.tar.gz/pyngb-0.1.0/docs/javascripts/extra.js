// Custom JS (placeholder)
(function(){
  console.debug('pyngb docs loaded');
})();
