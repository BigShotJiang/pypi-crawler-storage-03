# Batch Processing

::: pyngb.BatchProcessor
    options:
      show_source: true

::: pyngb.NGBDataset
    options:
      show_source: true

::: pyngb.process_directory

::: pyngb.process_files
