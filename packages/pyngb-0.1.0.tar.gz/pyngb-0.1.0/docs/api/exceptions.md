# Exceptions

::: pyngb.NGBParseError

::: pyngb.NGBCorruptedFileError

::: pyngb.NGBUnsupportedVersionError

::: pyngb.NGBDataTypeError

::: pyngb.NGBStreamNotFoundError
