#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# vim: set tabstop=2 shiftwidth=2 textwidth=80 expandtab :
#
#
"""
fkin_anfu init

@author: cyhfvg
@date: 2025/05/17
"""
__version__ = "0.4.3"
