import sys

from src.main import main

sys.exit(main())
