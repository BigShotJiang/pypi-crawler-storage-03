from mcp.server.fastmcp import FastMCP

app = FastMCP("mcp-apache-airflow")
