import os

dist_path = os.path.join(os.path.dirname(__file__), "dist")