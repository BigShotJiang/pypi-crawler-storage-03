"""Concrete Sre Event implementation"""

from logprep.ng.abc.event import ExtraDataEvent


class FilteredEvent(ExtraDataEvent):
    """Concrete Sre event class."""
