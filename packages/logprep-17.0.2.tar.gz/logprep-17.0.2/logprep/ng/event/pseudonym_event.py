"""Concrete Pseudonym Event implementation"""

from logprep.ng.abc.event import ExtraDataEvent


class PseudonymEvent(ExtraDataEvent):
    """Concrete Pseudonym event class."""
