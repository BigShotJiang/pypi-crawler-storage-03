.. _getters:

Getters
=======

.. autoclass:: logprep.util.getter.FileGetter
.. autoclass:: logprep.util.getter.HttpGetter
