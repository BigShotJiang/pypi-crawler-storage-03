## needed setup to generate documentation

* install pandoc with `apt-get install pandoc`
* install requirements with `pip install .[doc]` in project root
