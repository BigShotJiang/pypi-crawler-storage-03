"""
URL configuration for todos app.
"""

from django.urls import path

urlpatterns = []
