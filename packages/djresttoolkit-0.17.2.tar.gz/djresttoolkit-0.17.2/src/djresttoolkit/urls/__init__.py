from ._build_absolute_uri import build_absolute_uri

__all__ = ["build_absolute_uri"]
