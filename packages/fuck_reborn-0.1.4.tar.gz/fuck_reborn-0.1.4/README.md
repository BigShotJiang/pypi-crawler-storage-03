# fuck-reborn 🚀

**AI-powered command fixer**, inspired by [`thefuck`](https://github.com/nvbn/thefuck), but powered by **Google Gemini AI** for smarter, context-aware corrections.

---

## ✨ Features
- 🧠 Uses **Gemini AI** to understand and correct failed commands
- 🖥️ Detects command errors automatically
- 🤝 Interactive mode: approve or reject suggested fixes
- 🔑 `.env` support for storing your **Google API Key**
- 📦 Lightweight & cross-platform

---

## 🔧 Installation

### From PyPI (Recommended)
```bash
pip install fuck-reborn
```

### From Source (Development)
```bash
git clone https://github.com/blackXploit-404/fuck-reborn.git
cd fuck-reborn
python -m venv venv
source venv/bin/activate   # Linux/macOS
venv\Scripts\activate      # Windows
pip install -e .
```

---

## ⚙️ Configuration

fuck-reborn requires a **Google Gemini API Key**.
You can set it in two ways:

1. **`.env` file** (recommended):
   Create a `.env` file in your home or project directory:
   ```env
   GEMINI_API_KEY=your_api_key_here
   ```

2. **Environment variable**:
   ```bash
   export GEMINI_API_KEY="your_api_key_here"
   ```

> 🔑 Get your API key from [Google AI Studio](https://makersuite.google.com/).

---

## 🚀 Usage

Just run `fuck-reborn` after a failed command:
```bash
$ gti status
/bin/sh: gti: command not found
$ fuck-reborn gti status
Gemini suggests: git status
Run it? (y/n): y
```

---

## 🛠 Development

1. Clone the repo and install dependencies:
   ```bash
   git clone https://github.com/blackXploit-404/fuck-reborn.git
   cd fuck-reborn
   python -m venv venv
   source venv/bin/activate
   pip install -e ".[dev]"
   ```

2. Run tests:
   ```bash
   pytest
   ```

---

## 🐛 Troubleshooting

### **1. Missing API Key**
- **Error**: `GEMINI_API_KEY not found`
- **Fix**: Ensure the key is set in `.env` or exported in your shell.

### **2. Command Not Found**
- **Error**: `fuck-reborn: command not found`
- **Fix**: Ensure the package is installed and your `PATH` includes the Python `bin` directory.

### **3. PyPI Version Issues**
- **Error**: `ERROR: Could not find a version that satisfies the requirement`
- **Fix**: Upgrade pip and try again:
  ```bash
  pip install --upgrade pip
  pip install fuck-reborn
  ```

---


## 📄 License
[MIT License](LICENSE)

---

## 🙏 Credits
- Inspired by [`thefuck`](https://github.com/nvbn/thefuck)
- Powered by **Google Gemini AI**
```

