"""Functions for creating custom artifacts for use in openSAMPL"""
