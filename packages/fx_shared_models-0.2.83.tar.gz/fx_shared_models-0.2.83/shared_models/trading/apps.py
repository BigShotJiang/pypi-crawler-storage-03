from django.apps import AppConfig

class TradingConfig(AppConfig):
    name = 'shared_models.trading'
    verbose_name = 'Trading' 