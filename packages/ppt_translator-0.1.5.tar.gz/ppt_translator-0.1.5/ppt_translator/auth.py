"""
Authentication and authorization module for PPT-Translator
"""

import os
import hashlib
import time
import json
from typing import Optional, Dict, Any, Tuple
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Authentication related errors"""

    pass


class AuthorizationError(Exception):
    """Authorization related errors"""

    pass


class UsageLimitError(Exception):
    """Usage limit exceeded errors"""

    pass


class AuthManager:
    """Manages authentication and usage limits for PPT-Translator"""

    def __init__(self):
        self.config_dir = Path.home() / ".ppt-translator"
        self.config_dir.mkdir(exist_ok=True)
        self.usage_file = self.config_dir / "usage.json"
        self.auth_file = self.config_dir / "auth.json"

        # Default limits (can be overridden by environment variables)
        self.daily_limit = int(os.getenv("PPT_TRANSLATOR_DAILY_LIMIT", "10"))
        self.monthly_limit = int(os.getenv("PPT_TRANSLATOR_MONTHLY_LIMIT", "100"))
        self.max_file_size_mb = int(os.getenv("PPT_TRANSLATOR_MAX_FILE_SIZE_MB", "50"))

        # Authentication requirements
        self.require_auth = (
            os.getenv("PPT_TRANSLATOR_REQUIRE_AUTH", "true").lower() == "true"
        )
        self.api_key = os.getenv("PPT_TRANSLATOR_API_KEY")

    def check_authentication(self) -> bool:
        """Check if user is authenticated to use the service"""
        if not self.require_auth:
            return True

        if not self.api_key:
            raise AuthenticationError(
                "PPT-Translator requires authentication. Please set PPT_TRANSLATOR_API_KEY environment variable.\n"
                "To get an API key, visit: https://github.com/your-org/ppt-translator#authentication"
            )

        # Validate API key format (simple validation)
        if len(self.api_key) < 32:
            raise AuthenticationError("Invalid API key format")

        return True

    def check_aws_credentials(self) -> Tuple[bool, str]:
        """Check if AWS credentials are properly configured"""
        try:
            import boto3
            from botocore.exceptions import NoCredentialsError, PartialCredentialsError

            # Check if credentials exist
            session = boto3.Session()
            credentials = session.get_credentials()

            if credentials is None:
                return False, (
                    "❌ AWS credentials not found.\n"
                    "Please configure your AWS credentials using one of these methods:\n"
                    "1. Run 'aws configure' to set up credentials\n"
                    "2. Set environment variables: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY\n"
                    "3. Use IAM roles (if running on EC2)\n"
                    "4. Configure AWS profiles\n\n"
                    "⚠️  WARNING: Using PPT-Translator will incur AWS Bedrock charges on your account.\n"
                    "Make sure you understand the pricing: https://aws.amazon.com/bedrock/pricing/"
                )

            # Test credentials bymaking a simple call
            sts = session.client("sts")
            identity = sts.get_caller_identity()
            account_id = identity.get("Account", "Unknown")
            user_arn = identity.get("Arn", "Unknown")

            return True, (
                f"✅ AWS credentials verified.\n"
                f"Account: {account_id}\n"
                f"User: {user_arn}\n\n"
                f"⚠️  IMPORTANT: All AWS Bedrock charges will be billed to this account.\n"
                f"Daily limit: {self.daily_limit} translations\n"
                f"Monthly limit: {self.monthly_limit} translations"
            )

        except NoCredentialsError:
            return False, "❌ No AWS credentials found. Please run 'aws configure'."
        except PartialCredentialsError:
            return False, "❌ Incomplete AWS credentials. Please run 'aws configure'."
        except Exception as e:
            return False, f"❌ AWS credential verification failed: {str(e)}"

    def check_usage_limits(self, operation: str = "translate") -> bool:
        """Check if user has exceeded usage limits"""
        usage_data = self._load_usage_data()
        current_time = time.time()
        current_date = time.strftime("%Y-%m-%d", time.localtime(current_time))
        current_month = time.strftime("%Y-%m", time.localtime(current_time))

        # Initialize usage data if not exists
        if "daily" not in usage_data:
            usage_data["daily"] = {}
        if "monthly" not in usage_data:
            usage_data["monthly"] = {}

        # Check daily limit
        daily_usage = usage_data["daily"].get(current_date, 0)
        if daily_usage >= self.daily_limit:
            raise UsageLimitError(
                f"Daily usage limit exceeded ({daily_usage}/{self.daily_limit}). "
                f"Please try again tomorrow or contact support for higher limits."
            )

        # Check monthly limit
        monthly_usage = usage_data["monthly"].get(current_month, 0)
        if monthly_usage >= self.monthly_limit:
            raise UsageLimitError(
                f"Monthly usage limit exceeded ({monthly_usage}/{self.monthly_limit}). "
                f"Please try again next month or contact support for higher limits."
            )

        return True

    def record_usage(
        self, operation: str = "translate", details: Dict[str, Any] = None
    ):
        """Record usage for rate limiting"""
        usage_data = self._load_usage_data()
        current_time = time.time()
        current_date = time.strftime("%Y-%m-%d", time.localtime(current_time))
        current_month = time.strftime("%Y-%m", time.localtime(current_time))

        # Initialize if not exists
        if "daily" not in usage_data:
            usage_data["daily"] = {}
        if "monthly" not in usage_data:
            usage_data["monthly"] = {}
        if "history" not in usage_data:
            usage_data["history"] = []

        # Update counters
        usage_data["daily"][current_date] = usage_data["daily"].get(current_date, 0) + 1
        usage_data["monthly"][current_month] = (
            usage_data["monthly"].get(current_month, 0) + 1
        )

        # Record detailed history
        usage_data["history"].append(
            {
                "timestamp": current_time,
                "date": current_date,
                "operation": operation,
                "details": details or {},
            }
        )

        # Keep only last 1000 history entries
        if len(usage_data["history"]) > 1000:
            usage_data["history"] = usage_data["history"][-1000:]

        # Clean old daily data (keep last 30 days)
        cutoff_date = time.time() - (30 * 24 * 60 * 60)
        usage_data["daily"] = {
            date: count
            for date, count in usage_data["daily"].items()
            if time.mktime(time.strptime(date, "%Y-%m-%d")) > cutoff_date
        }

        self._save_usage_data(usage_data)

    def get_usage_stats(self) -> Dict[str, Any]:
        """Get current usage statistics"""
        usage_data = self._load_usage_data()
        current_date = time.strftime("%Y-%m-%d")
        current_month = time.strftime("%Y-%m")

        daily_usage = usage_data.get("daily", {}).get(current_date, 0)
        monthly_usage = usage_data.get("monthly", {}).get(current_month, 0)

        return {
            "daily": {
                "used": daily_usage,
                "limit": self.daily_limit,
                "remaining": max(0, self.daily_limit - daily_usage),
            },
            "monthly": {
                "used": monthly_usage,
                "limit": self.monthly_limit,
                "remaining": max(0, self.monthly_limit - monthly_usage),
            },
        }

    def validate_file_size(self, file_path: str) -> bool:
        """Validate file size is within limits"""
        if not os.path.exists(file_path):
            raise ValueError(f"File not found: {file_path}")

        file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
        if file_size_mb > self.max_file_size_mb:
            raise UsageLimitError(
                f"File size ({file_size_mb:.1f}MB) exceeds maximum allowed size ({self.max_file_size_mb}MB)"
            )

        return True

    def _load_usage_data(self) -> Dict[str, Any]:
        """Load usage data from file"""
        if not self.usage_file.exists():
            return {}

        try:
            with open(self.usage_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            logger.warning(f"Failed to load usage data: {e}")
            return {}

    def _save_usage_data(self, data: Dict[str, Any]):
        """Save usage data to file"""
        try:
            with open(self.usage_file, "w") as f:
                json.dump(data, f, indent=2)
        except IOError as e:
            logger.error(f"Failed to save usage data: {e}")

    def show_cost_warning(self):
        """Show cost warning to user"""
        print("\n" + "=" * 60)
        print("⚠️  AWS BEDROCK COST WARNING")
        print("=" * 60)
        print("This tool uses AWS Bedrock AI models which incur charges.")
        print("Costs will be billed directly to your AWS account.")
        print("")
        print("Estimated costs per translation:")
        print("• Small presentation (1-5 slides): $0.01 - $0.05")
        print("• Medium presentation (6-20 slides): $0.05 - $0.20")
        print("• Large presentation (21+ slides): $0.20 - $1.00+")
        print("")
        print("Your current limits:")
        stats = self.get_usage_stats()
        print(
            f"• Daily: {stats['daily']['remaining']}/{stats['daily']['limit']} remaining"
        )
        print(
            f"• Monthly: {stats['monthly']['remaining']}/{stats['monthly']['limit']} remaining"
        )
        print("")
        print("For exact pricing, visit: https://aws.amazon.com/bedrock/pricing/")
        print("=" * 60)

        response = input("Do you want to continue? (y/N): ").strip().lower()
        if response not in ["y", "yes"]:
            raise AuthorizationError("Operation cancelled by user")


def require_auth(func):
    """Decorator to require authentication for functions"""

    def wrapper(*args, **kwargs):
        auth_manager = AuthManager()

        # Check authentication
        auth_manager.check_authentication()

        # Check AWS credentials
        aws_ok, aws_msg = auth_manager.check_aws_credentials()
        if not aws_ok:
            raise AuthenticationError(aws_msg)

        # Check usage limits
        auth_manager.check_usage_limits()

        # Show cost warning for first-time users or if explicitly requested
        if os.getenv("PPT_TRANSLATOR_SHOW_WARNING", "true").lower() == "true":
            auth_manager.show_cost_warning()

        # Execute function
        result = func(*args, **kwargs)

        # Record usage
        auth_manager.record_usage(
            "translate",
            {
                "function": func.__name__,
                "args_count": len(args),
                "kwargs_keys": list(kwargs.keys()),
            },
        )

        return result

    return wrapper
