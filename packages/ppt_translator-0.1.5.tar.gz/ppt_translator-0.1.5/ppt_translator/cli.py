#!/usr/bin/env python3
"""
Command-line interface for PPT-Translator.

This module provides the main CLI entry point for the ppt-translator package.
"""

import sys
import os
from pathlib import Path


def main():
    """Main CLI entry point."""
    import argparse
    from .ppt_handler import PowerPointTranslator
    from .config import Config
    from .auth import (
        AuthManager,
        AuthenticationError,
        AuthorizationError,
        UsageLimitError,
    )

    parser = argparse.ArgumentParser(
        description="🎯 PPT-Translator: AI-powered PowerPoint presentation translator using Amazon Bedrock"
    )

    # Mode selection
    parser.add_argument(
        "--translate", action="store_true", help="Translate entire presentation"
    )
    parser.add_argument(
        "--translate-slides", help='Translate specific slides (e.g., "1,3,5" or "2-4")'
    )
    parser.add_argument(
        "--slide-info", action="store_true", help="Show slide information and previews"
    )
    parser.add_argument("--mcp", action="store_true", help="Start FastMCP server")
    parser.add_argument("--web", action="store_true", help="Start web server")
    parser.add_argument("--test", action="store_true", help="Run tests")

    # File options
    parser.add_argument("-i", "--input-file", help="Input PowerPoint file path")
    parser.add_argument("-o", "--output-file", help="Output PowerPoint file path")

    # Translation options
    parser.add_argument(
        "-t",
        "--target-language",
        help="Target language code (e.g., ko, ja, es, fr, de, zh, pt, it, ru)",
    )
    parser.add_argument(
        "-m",
        "--model-id",
        help="Bedrock model ID (default: us.anthropic.claude-3-7-sonnet-20250219-v1:0)",
    )

    # Debug options
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")

    args = parser.parse_args()

    # Show examples if no arguments
    if len(sys.argv) == 1:
        parser.print_help()
        print("\nExamples:")
        print("  ppt-translator --translate -i input.pptx -t ko")
        print('  ppt-translator --translate-slides "1,3,5" -i input.pptx -t ja')
        print("  ppt-translator --slide-info -i input.pptx")
        print("  ppt-translator --web")
        print("  ppt-translator --mcp")
        return

    # Handle different modes
    if args.web:
        from . import web_server

        web_server.main()
    elif args.mcp:
        from . import fastmcp_server

        fastmcp_server.main()
    elif args.test:
        print("Running tests...")
        # Add test functionality here
    elif args.slide_info:
        if not args.input_file:
            print("Error: --input-file is required for --slide-info")
            sys.exit(1)
        # Add slide info functionality here
        print(f"Showing slide info for: {args.input_file}")
    elif args.translate or args.translate_slides:
        if not args.input_file or not args.target_language:
            print(
                "Error: --input-file and --target-language are required for translation"
            )
            sys.exit(1)

        try:
            # Initialize authentication manager
            auth_manager = AuthManager()

            # Check authentication and AWS credentials
            auth_manager.check_authentication()
            aws_ok, aws_msg = auth_manager.check_aws_credentials()

            if not aws_ok:
                print(aws_msg)
                sys.exit(1)
            else:
                print(aws_msg)

            # Validate file size
            auth_manager.validate_file_size(args.input_file)

            # Check usage limits
            auth_manager.check_usage_limits()

            # Show cost warning
            if not args.debug:  # Skip warning in debug mode
                auth_manager.show_cost_warning()

            # Set up translator
            config = Config()
            translator = PowerPointTranslator(config)

            # Perform translation
            output_file = args.output_file or args.input_file.replace(
                ".pptx", f"_translated_{args.target_language}.pptx"
            )

            result = translator.translate_presentation(
                args.input_file, output_file, args.target_language
            )

            # Record usage
            auth_manager.record_usage(
                "translate",
                {
                    "input_file": args.input_file,
                    "target_language": args.target_language,
                    "translated_count": result.translated_count,
                },
            )

            print(
                f"✅ Translation completed: {result.translated_count} texts translated"
            )
            print(f"📁 Output saved to: {output_file}")

            # Show remaining usage
            stats = auth_manager.get_usage_stats()
            print(
                f"📊 Remaining usage - Daily: {stats['daily']['remaining']}/{stats['daily']['limit']}, Monthly: {stats['monthly']['remaining']}/{stats['monthly']['limit']}"
            )

        except (AuthenticationError, AuthorizationError, UsageLimitError) as e:
            print(f"❌ {e}")
            sys.exit(1)
        except Exception as e:
            print(f"❌ Translation failed: {e}")
            sys.exit(1)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
