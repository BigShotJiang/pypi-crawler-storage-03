mcp\_long\_context\_reader package
==================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mcp_long_context_reader.strategies

Submodules
----------

mcp\_long\_context\_reader.context module
-----------------------------------------

.. automodule:: mcp_long_context_reader.context
   :members:
   :undoc-members:
   :show-inheritance:

mcp\_long\_context\_reader.server module
----------------------------------------

.. automodule:: mcp_long_context_reader.server
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mcp_long_context_reader
   :members:
   :undoc-members:
   :show-inheritance:
