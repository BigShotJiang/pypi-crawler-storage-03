"""
MCP Long Context Reader
"""

__version__ = "0.9.0"
__author__ = "Yuping Lin, Zitao Li"
__email__ = "linyupin@msu.edu, zitao.l@alibaba-inc.com"

from mcp_long_context_reader.server import main

__all__ = ["main"]