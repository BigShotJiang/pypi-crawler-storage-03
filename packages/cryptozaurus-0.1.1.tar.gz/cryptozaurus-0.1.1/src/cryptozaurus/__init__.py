from .main import is_timestamp_valid

__all__ = [
    "is_timestamp_valid",
]

__version__ = "0.1.0"


def main() -> None:
    print("cryptozaurus", __version__)
