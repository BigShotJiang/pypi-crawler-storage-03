# pjdev-pydantic

[![PyPI - Version](https://img.shields.io/pypi/v/pjdev-pydantic.svg)](https://pypi.org/project/pjdev-pydantic)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pjdev-pydantic.svg)](https://pypi.org/project/pjdev-pydantic)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pjdev-pydantic
```

## License

`pjdev-pydantic` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
