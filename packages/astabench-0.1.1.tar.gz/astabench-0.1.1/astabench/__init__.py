from importlib.metadata import version as get_version

from . import evals, solvers

__version__ = get_version("astabench")
