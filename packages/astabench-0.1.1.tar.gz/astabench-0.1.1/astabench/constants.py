ASTA_BENCH_DATASET_REPO = "allenai/asta-bench"
ASTA_BENCH_DATASET_REVISION = "e0a5d51f16d3af2aa6dd51c53bdb292df3ee1803"

# For large-ish data used by solvers (e.g. cached results, fewshot examples)
ASTA_SOLVER_DATA_REPO = "allenai/asta-bench-solver-data"
ASTA_SOLVER_DATA_REVISION = "112f457ad94b05fd377234feae363ae794550049"
