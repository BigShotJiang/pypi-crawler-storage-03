export type MenuNames = 'download' | 'help' | 'information' | 'jupyter' | null

export type DataType = 'csv' | 'geotiff' | null
