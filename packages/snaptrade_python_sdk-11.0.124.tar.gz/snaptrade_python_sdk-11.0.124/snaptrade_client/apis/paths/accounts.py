from snaptrade_client.paths.accounts.get import ApiForget


class Accounts(
    ApiForget,
):
    pass
