from snaptrade_client.paths.accounts_account_id_holdings.get import ApiForget


class AccountsAccountIdHoldings(
    ApiForget,
):
    pass
