def main():
    print("Hello from brdeapp!")


if __name__ == "__main__":
    main()
