class InvalidDateFormat(Exception):
    """Raised when the date format is invalid"""
    pass
