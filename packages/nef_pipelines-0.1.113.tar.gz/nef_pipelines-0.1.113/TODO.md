lines marked with '!x' are current priorities
* patch cis and charges and subtypes -  not done

* offset shifts -needed now?
* assign -useful goes with nef2mars - wait

* nmrview output - to do  '!1'
* nmrpipe output -to do -wait
* Xplor xplor just xplor violations to nef - do '!2'
* Aria - needs dedicated time -soon but not immediate
* nmrstar -peaks sequence - wait
* Translator -do '!3'

* Xplor shifts export? - can wait
* missing frame update bug - important '!4'
* add pipe functions '!5' - started
* update merging and replacement of save frames and support of empty save frames
* make tools update meta data
* test on ubuntu latest

* Missing tests -done
* mars - nef2mars - done
* renumber chains -  done
* test hannah's problems - done
* Fasta export - done
* xEasy shifts - done
release - done
test_filter not committed
