A purchase blanket order is a pre-agreement to purchase a certain number
of quantities of products at a specific price. From a confirmed blanket
order, the users can create new purchase orders at such price, until the
blanket order expires due to reaching the validity date.
