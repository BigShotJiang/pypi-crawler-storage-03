from pathlib import Path

import nonebot
import toml

from amrita.config import get_amrita_config


def load_plugins():
    nonebot.logger.info("Loading built-in plugins...")
    config = get_amrita_config()
    for name in (Path(__file__).parent.parent / "plugins").iterdir():
        if name in config.disabled_builtin_plugins:
            continue
        nonebot.logger.info(f"Loading plugin {name.name}...")
        nonebot.load_plugin(f"amrita.plugins.{name.name}")
    nonebot.logger.info("Loading plugins......")
    from amrita.cmds.cli import PyprojectFile

    meta = PyprojectFile.model_validate(toml.load("pyproject.toml"))
    for plugin in meta.tool.amrita.plugins:
        nonebot.logger.info(f"Loading plugin {plugin}...")
        try:
            nonebot.load_plugin(plugin)
        except Exception as e:
            nonebot.logger.error(f"Failed to load plugin {plugin}: {e}")
