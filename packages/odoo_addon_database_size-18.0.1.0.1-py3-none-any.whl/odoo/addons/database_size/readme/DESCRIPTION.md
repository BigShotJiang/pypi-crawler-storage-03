Monitor the size of your Odoo instance.
