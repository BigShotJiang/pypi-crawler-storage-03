__title__ = "DynamicForms"
__version__ = "0.80.10"
__author__ = "Jure Erznožnik"
__email__ = "jure.erznoznik@gmail.com"
__license__ = "BSD 3-Clause"
__copyright__ = "Copyright 2017-present Jure Erznožnik"

VERSION = __version__
