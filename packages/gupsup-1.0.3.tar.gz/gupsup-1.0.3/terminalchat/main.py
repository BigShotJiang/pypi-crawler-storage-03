def main():
    from .client import run_client
    run_client()