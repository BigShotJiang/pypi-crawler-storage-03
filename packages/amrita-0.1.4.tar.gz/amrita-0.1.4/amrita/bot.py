import amrita

amrita.init()
amrita.load_plugins()


def main():
    amrita.run()


if __name__ == "__main__":
    main()
