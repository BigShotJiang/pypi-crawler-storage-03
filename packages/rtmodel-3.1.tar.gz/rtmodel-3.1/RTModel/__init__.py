__version__ = "3.0"
__author__ = 'Valerio Bozza'
__credits__ = 'University of Salerno, Italy'

from .RTModel import RTModel
