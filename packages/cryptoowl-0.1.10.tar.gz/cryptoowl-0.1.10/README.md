# cryptoowl-common
A library, that stores commonly used code for different modules in the CryptoOwl application.
Never store username-password in this repository.

## Useful links for python packaging: 
[Link-1](https://medium.com/@joel.barmettler/how-to-upload-your-python-package-to-pypi-65edc5fe9c56)
[Link-2](https://www.section.io/engineering-education/setting-up-cicd-for-python-packages-using-github-actions/)
