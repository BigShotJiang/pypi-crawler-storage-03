def get_emoji(position):
    if position == 1:
        return "🥇"  # Gold
    elif position == 2:
        return "🥈"  # Silver
    elif position == 3:
        return "🥉"  # Bronze
    elif position == 4:
        return "️4️⃣"  # Medal
    elif position == 5:
        return "5️⃣"  # Medal
    elif position == 6:
        return "6️⃣"  # Medal
    elif position == 7:
        return "7️⃣"  # Medal
    elif position == 8:
        return "8️⃣"  # Medal
    elif position == 9:
        return "9️⃣"  # Medal
    elif position == 10:
        return "🔟"  # Medal
    else:
        return ""  # No emoji