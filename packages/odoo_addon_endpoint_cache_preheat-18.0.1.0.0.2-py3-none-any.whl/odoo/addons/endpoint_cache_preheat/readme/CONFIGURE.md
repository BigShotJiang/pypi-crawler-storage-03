Go to an endpoint form and tick Automatic cache pre-heat option.
