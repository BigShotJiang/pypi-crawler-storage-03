# th-helpers
Helper library for Trainer Hill

## Upload to PyPi

```bash
python -m build
python -m twine upload --repository <pypi-config> dist/*
```
