.. _changelog:

CHANGELOG
============

.. include:: ../../CHANGELOG.md
   :parser: myst_parser.sphinx_

