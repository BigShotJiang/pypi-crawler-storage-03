# Ethereum Flashbots plug-in

Ethereum Flashbots plug-in for the AEA framework.

## Install

``` bash
python setup.py install
```

## Run tests

``` bash
python setup.py test
```
