from influxio.util.common import get_version

__appname__ = "influxio"
__version__ = get_version(__appname__)
