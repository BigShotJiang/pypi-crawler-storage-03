# TODO better name to represent what it means?
SourceHash = str
