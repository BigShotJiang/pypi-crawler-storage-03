VERSION = "1.0.8"
# Windows executables will use this version.
VERSION_ID = "1.0.8"
