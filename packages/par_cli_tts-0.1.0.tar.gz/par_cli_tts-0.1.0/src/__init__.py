"""PAR CLI TTS - Command line text-to-speech tool using ElevenLabs."""

__version__ = "0.1.0"
