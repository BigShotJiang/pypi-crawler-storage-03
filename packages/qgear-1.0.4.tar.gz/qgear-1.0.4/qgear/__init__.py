__version__ = "1.0.2"
import sys
import qgear.toolbox
sys.modules['toolbox'] = qgear.toolbox