Module title
============

.. container:: regression

   .. lua:autoobject:: module_title
      :members:
      :title: Custom title
      :no-index:

      Title
      -----

   .. lua:autoobject:: module_title
      :title: Custom title
      :no-index:

      Title when empty
      ----------------

   .. lua:autoobject:: module_title
      :members:
      :title: Custom title
      :member-order: groupwise
      :no-index:

      Title when ordering is groupwise
      --------------------------------
