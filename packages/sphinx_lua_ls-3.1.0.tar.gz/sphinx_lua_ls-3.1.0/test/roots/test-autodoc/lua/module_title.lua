--- @meta

--- Description
--- !doctype module
--- @class module_title
local module_title = {}

--- Description.
function module_title.foo() end
