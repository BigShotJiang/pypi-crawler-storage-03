# -*- coding: utf-8 -*-
"""
This module contains utility functions for managing image attachments in reports.
"""
