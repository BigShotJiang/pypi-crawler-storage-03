This module is the display timeline view of the Field Service
application in Odoo.
