- Restore person proposals & filters same as we had in v14. See v14➔v16
  migration PR.
