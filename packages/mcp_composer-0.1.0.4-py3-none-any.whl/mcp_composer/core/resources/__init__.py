"""Resource management module for MCP Composer."""

from .resource_manager import MCPResourceManager

__all__ = ["MCPResourceManager"]
