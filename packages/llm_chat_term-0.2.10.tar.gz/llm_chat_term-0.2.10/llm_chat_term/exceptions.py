class FileReadError(Exception):
    pass


class UrlReadError(Exception):
    pass


class ConfigurationError(Exception):
    pass
