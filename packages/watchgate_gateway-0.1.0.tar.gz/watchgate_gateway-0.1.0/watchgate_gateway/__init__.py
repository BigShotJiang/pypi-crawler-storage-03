"""Watchgate Gateway - Core MCP gateway without TUI"""
__version__ = "0.1.0"