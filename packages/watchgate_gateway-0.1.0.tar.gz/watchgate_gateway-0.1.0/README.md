# watchgate-gateway

Secure MCP gateway with auditing and access control - core gateway functionality without TUI components.

This is the lightweight version of watchgate that includes only the core gateway functionality.

For the full version with TUI, see: `watchgate`

## Installation

```bash
pip install watchgate-gateway
```

## Usage

```bash
watchgate-gateway --config config.yaml
```