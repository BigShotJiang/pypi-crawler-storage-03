from .oai.modules import oauth_module_types as oauth

__all__ = [
    "oauth",
]
