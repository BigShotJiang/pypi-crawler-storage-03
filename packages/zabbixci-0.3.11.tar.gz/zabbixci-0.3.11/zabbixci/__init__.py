from .zabbixci import ZabbixCI

__all__ = ["ZabbixCI"]
