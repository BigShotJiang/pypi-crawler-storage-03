from abc import ABCMeta


class Asset(object, metaclass=ABCMeta):
    pass
