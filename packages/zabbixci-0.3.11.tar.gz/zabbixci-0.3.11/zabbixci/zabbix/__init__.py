from .zabbix import Zabbix

__all__ = ["Zabbix"]
