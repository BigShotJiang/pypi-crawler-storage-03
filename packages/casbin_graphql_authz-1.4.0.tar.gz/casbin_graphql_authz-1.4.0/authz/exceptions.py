class PermissionInsufficientError(Exception):
    pass
