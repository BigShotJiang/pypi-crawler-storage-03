# verysimplemoduleyl89/add.py
from typing import Any

def add(a: Any, b: Any):
    """Return a + b."""
    return a + b

