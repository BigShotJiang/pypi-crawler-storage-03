# verysimplemoduleyl89/subtract.py
from typing import Any

def subtract(a: Any, b: Any):
    """Return a - b."""
    return a - b

