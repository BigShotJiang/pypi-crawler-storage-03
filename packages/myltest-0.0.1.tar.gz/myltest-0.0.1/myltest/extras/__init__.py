# verysimplemoduleyl89/extras/__init__.py
from .multiply import multiply
from .divide import divide

__all__ = ["multiply", "divide"]
