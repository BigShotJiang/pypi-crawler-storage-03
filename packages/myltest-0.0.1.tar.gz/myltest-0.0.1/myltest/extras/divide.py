# verysimplemoduleyl89/extras/divide.py
from typing import Union

Number = Union[int, float]

def divide(a: Number, b: Number) -> float:
    """Return a / b. Raise ZeroDivisionError if b == 0."""
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b

