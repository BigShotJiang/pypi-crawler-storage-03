# verysimplemoduleyl89/extras/multiply.py
from typing import Any

def multiply(a: Any, b: Any):
    """Return a * b."""
    return a * b

