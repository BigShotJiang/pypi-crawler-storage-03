# pdf operations

::: tinyvdiff.pdf
    options:
      members:
        - get_pdf_page_count
      show_root_heading: true
      show_source: false
