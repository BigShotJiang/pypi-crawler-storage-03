from .base_populatable import BasePopulatable


class BaseComponent(BasePopulatable):
    """Strapi component."""
