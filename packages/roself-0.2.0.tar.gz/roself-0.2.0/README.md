rm -rf dist build *.egg-info
python3 -m build
python3 -m twine upload dist/*
