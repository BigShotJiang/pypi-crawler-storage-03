# qelrix-cli

A command-line interface for interacting with Gemini AI.

## Installation

```bash
pip install qelrix-cli
```

## Usage

```bash
qelrix start
```

When prompted, enter your Gemini API key.


