from .extended_property import ExtendedProperty

__all__ = ["ExtendedProperty"]
