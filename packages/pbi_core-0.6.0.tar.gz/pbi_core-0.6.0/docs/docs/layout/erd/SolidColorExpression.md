```mermaid
---
title: SolidColorExpression
---
graph 
SolidColorExpression[<a href='/layout/erd/SolidColorExpression'>SolidColorExpression</a>]
SolidExpression[<a href='/layout/erd/SolidExpression'>SolidExpression</a>]
style SolidExpression stroke:#ff0000,stroke-width:1px
SolidColorExpression ---> SolidExpression
```