```mermaid
---
title: LiteralSource
---
graph 
LiteralSource[<a href='/layout/erd/LiteralSource'>LiteralSource</a>]
_LiteralSourceHelper[_LiteralSourceHelper]
LiteralSource --->|Literal| _LiteralSourceHelper
```