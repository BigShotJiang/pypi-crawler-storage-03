# Local SSAS Server
    
::: pbi_core.ssas.server.server.LocalServer
