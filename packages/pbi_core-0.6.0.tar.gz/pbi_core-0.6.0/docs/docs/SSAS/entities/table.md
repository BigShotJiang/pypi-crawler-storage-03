# Table


::: pbi_core.ssas.model_tables.table.Table