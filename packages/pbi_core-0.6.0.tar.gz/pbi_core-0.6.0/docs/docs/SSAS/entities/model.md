# Model


::: pbi_core.ssas.model_tables.model.Model