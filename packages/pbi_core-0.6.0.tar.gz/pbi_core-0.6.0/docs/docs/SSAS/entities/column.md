# Column

::: pbi_core.ssas.model_tables.column.Column
