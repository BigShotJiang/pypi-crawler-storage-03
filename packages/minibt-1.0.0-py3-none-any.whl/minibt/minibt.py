def minibt():
    print("minibt")