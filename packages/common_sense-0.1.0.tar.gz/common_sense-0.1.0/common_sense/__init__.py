"""common-sense: Obvious helpers and witty tools."""

from .dates import *
from .debug import *
from .philosophy import *
from .strings import *
from .numbers import *
from .life import *
from .utils import *
