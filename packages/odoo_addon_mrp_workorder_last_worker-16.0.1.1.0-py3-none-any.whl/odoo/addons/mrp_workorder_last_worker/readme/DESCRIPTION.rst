This module adds a new field to the workorder to store the last worker who
worked on it, no matter if they are currently working on it or not.

