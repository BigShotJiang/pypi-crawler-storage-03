﻿# Hugging Face ZeusDB

Open-source RAG with any model: Hugging Face embeddings + ZeusDB vector storage with local deployment and GPU optimization.