from django.apps import AppConfig


class FundorUtilitiesConfig(AppConfig):
    name = "fundor_utilities"
