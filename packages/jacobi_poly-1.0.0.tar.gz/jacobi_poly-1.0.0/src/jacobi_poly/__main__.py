"""Make the CLI runnable using python -m jacobi_poly."""

from .cli import app

app(prog_name="jacobi-poly")
