"""`nuke` project information."""

from . import dirtree, nuke, utils

__author__ = "Varun Agrawal"
__copyright__ = "Copyright 2017."
__license__ = "MIT"
__version__ = "2.6.2"
__maintainer__ = "Varun Agrawal"
__email__ = "varagrawal@gmail.com"
__status__ = "Production"
