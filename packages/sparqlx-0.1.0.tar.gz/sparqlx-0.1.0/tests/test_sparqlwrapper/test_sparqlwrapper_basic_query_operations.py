"""Pytest entry point for basic SPARQLWrapper Query Operation tests."""

from sparqlx import SPARQLWrapper
