from sparqlx.wrappers import SPARQLWrapper
