#!/usr/bin/env python
"""Entry point for running dbt-mcp as a module"""

if __name__ == "__main__":
    from dbt_mcp.main import main
    main()