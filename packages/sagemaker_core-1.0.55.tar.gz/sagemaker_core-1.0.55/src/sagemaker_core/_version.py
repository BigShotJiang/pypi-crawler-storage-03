import importlib.metadata

__version__ = importlib.metadata.version("sagemaker_core")
