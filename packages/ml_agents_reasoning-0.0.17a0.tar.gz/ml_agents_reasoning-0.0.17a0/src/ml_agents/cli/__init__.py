"""CLI interface for ML Agents reasoning research platform."""

__version__ = "0.1.0"
