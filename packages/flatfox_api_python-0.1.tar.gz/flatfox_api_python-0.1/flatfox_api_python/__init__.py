print("Flatfox API placeholder PoC package")
