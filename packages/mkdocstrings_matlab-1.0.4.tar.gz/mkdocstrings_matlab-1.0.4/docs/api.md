
::: mkdocstrings_handlers.matlab
    handler: python
    options:
      show_root_toc_entry: true
      show_submodules: true
      heading_level: 1
      separate_signature: true
      show_signature_annotations: true
      signature_crossrefs: true
      members:
        - handler
        - config

