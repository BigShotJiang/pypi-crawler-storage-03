% This is the namespace docstring.
