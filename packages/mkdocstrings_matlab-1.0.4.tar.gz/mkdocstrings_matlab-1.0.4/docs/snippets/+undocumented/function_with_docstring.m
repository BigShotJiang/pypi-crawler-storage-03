function function_with_docstring()
    % Hello
end