classdef myClass < myParent
    % Docstring of myClass.
end
