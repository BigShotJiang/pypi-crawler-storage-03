function do_something()
% Do something.
end
