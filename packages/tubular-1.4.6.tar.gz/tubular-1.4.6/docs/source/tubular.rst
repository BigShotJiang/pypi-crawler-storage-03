tubular package
===============

Submodules
----------

tubular.base module
-------------------

.. automodule:: tubular.base
   :members:
   :undoc-members:
   :show-inheritance:

tubular.capping module
----------------------

.. automodule:: tubular.capping
   :members:
   :undoc-members:
   :show-inheritance:

tubular.comparison module
-------------------------

.. automodule:: tubular.comparison
   :members:
   :undoc-members:
   :show-inheritance:

tubular.dates module
--------------------

.. automodule:: tubular.dates
   :members:
   :undoc-members:
   :show-inheritance:

tubular.imputers module
-----------------------

.. automodule:: tubular.imputers
   :members:
   :undoc-members:
   :show-inheritance:

tubular.mapping module
----------------------

.. automodule:: tubular.mapping
   :members:
   :undoc-members:
   :show-inheritance:

tubular.misc module
-------------------

.. automodule:: tubular.misc
   :members:
   :undoc-members:
   :show-inheritance:

tubular.mixins module
---------------------

.. automodule:: tubular.mixins
   :members:
   :undoc-members:
   :show-inheritance:

tubular.nominal module
----------------------

.. automodule:: tubular.nominal
   :members:
   :undoc-members:
   :show-inheritance:

tubular.numeric module
----------------------

.. automodule:: tubular.numeric
   :members:
   :undoc-members:
   :show-inheritance:

tubular.strings module
----------------------

.. automodule:: tubular.strings
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tubular
   :members:
   :undoc-members:
   :show-inheritance: