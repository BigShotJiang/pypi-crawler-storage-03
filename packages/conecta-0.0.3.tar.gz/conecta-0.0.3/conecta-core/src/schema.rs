use arrow::datatypes::{DataType, Field, Schema as ArrowSchema};
use std::sync::Arc;

#[derive(Debug, Clone, PartialEq)]
pub enum NativeType {
    // Primitive types
    Bool,
    Char,

    // Signed
    I8,
    I16,
    I32,
    I64,
    I128,

    // Unsigned
    UI8,
    UI16,
    UI32,
    UI64,
    UI128,

    // Float
    F16,
    F32,
    F64,

    // String types
    String,

    // Time
    Date32,
    Date64,
    TimestampWithoutTimeZone,
    Time,

    // Vectors
    VecBool,
    VecChar,

    VecI8,
    VecI16,
    VecI32,
    VecI64,

    VecF16,
    VecF32,
    VecF64,

    VecString,
}

impl NativeType {
    /// Returns the `arrow` datatype equivalent.
    pub(crate) fn to_arrow(&self) -> DataType {
        match self {
            // Integers
            NativeType::I16 => DataType::Int16,
            NativeType::I32 => DataType::Int32,
            NativeType::I64 => DataType::Int64,

            // Floats
            NativeType::F64 => DataType::Float64,

            //Logical
            NativeType::Bool => DataType::Boolean,

            // Text
            NativeType::String => DataType::Utf8,

            // Time
            NativeType::Date32 => DataType::Date32,
            NativeType::TimestampWithoutTimeZone => {
                DataType::Timestamp(arrow::datatypes::TimeUnit::Microsecond, None)
            }
            NativeType::Time => DataType::Time64(arrow::datatypes::TimeUnit::Microsecond),

            NativeType::VecI32 => DataType::List(Arc::new(Field::new("_", DataType::Int32, true))),
            _ => {
                panic!(
                    "Native type to arrow is not implemented. NativeType {:?}",
                    self
                )
            }
        }
    }
}

#[derive(Debug, Clone)]
pub struct Schema {
    pub columns: Vec<Column>,
}

// let field_a = Field::new("a", DataType::Int64, false);
impl Schema {
    pub fn to_arrow(self) -> ArrowSchema {
        ArrowSchema::new(
            self.columns
                .into_iter()
                .map(|column| Field::new(column.name, column.data_type.to_arrow(), true))
                .collect::<Vec<_>>(),
        )
    }
}

#[derive(Debug, Clone)]
pub struct Column {
    pub name: String,
    pub data_type: NativeType,
    pub original_type_repr: String,
}
