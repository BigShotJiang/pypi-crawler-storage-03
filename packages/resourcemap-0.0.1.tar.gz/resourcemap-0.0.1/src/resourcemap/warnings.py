from resourcemap.core.locate import (
    UnneededAppAuthorWarning,
)
