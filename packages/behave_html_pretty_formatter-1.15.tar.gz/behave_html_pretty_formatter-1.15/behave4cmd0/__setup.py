"""
Constants
"""

import os.path

HERE = os.path.dirname(__file__)
TOP = os.path.join(HERE, "..")
TOPA = os.path.abspath(TOP)
