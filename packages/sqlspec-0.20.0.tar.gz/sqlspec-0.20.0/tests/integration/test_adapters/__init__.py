"""Integration tests for database adapters."""
