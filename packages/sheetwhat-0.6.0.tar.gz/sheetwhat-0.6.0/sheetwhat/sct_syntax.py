from sheetwhat.sct_context import SCT_CTX

# Used by backend
assert SCT_CTX
