from bmcs_matmod.version import __version__

__all__ = ['__version__']

# This file makes bmcs_matmod a Python package

