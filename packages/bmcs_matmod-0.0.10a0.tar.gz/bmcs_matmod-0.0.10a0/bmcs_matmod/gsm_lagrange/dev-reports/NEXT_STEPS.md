
# Next steps

I am able to run the calculation in the notebook using aiida profile. Currently, the profile is constructed using verdi presto. Clarify the understanding of profiles - in view of the connection to the database.