"""
CLI Tests for GSM Lagrange Framework

This package contains test scripts for validating the GSM CLI functionality.
"""
