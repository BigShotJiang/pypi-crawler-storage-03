"""
CLI Examples for GSM Lagrange Framework

This package contains example scripts and configurations demonstrating
how to use the GSM CLI for various simulation scenarios.
"""
