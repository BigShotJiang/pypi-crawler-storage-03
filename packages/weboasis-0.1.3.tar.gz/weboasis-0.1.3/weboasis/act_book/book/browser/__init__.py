"""
Browser operations package
""" 