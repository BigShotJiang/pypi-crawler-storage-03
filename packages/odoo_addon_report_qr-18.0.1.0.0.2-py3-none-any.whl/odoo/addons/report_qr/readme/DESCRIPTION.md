This module allows to print QR in better structure than the standard
odoo.

The original image looks like the following

![](static/description/old_qr.png)

With the new generator, it looks like:

![](static/description/new_qr.png)
