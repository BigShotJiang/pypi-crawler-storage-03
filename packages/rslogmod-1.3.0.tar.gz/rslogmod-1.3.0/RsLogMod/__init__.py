from RsLogMod.rlog import rlog
from RsLogMod.bin.rslogmod import Configure, RsConfig
