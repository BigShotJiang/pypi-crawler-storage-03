These tools were taken verbatim from matscipy. See:

https://github.com/libAtoms/matscipy