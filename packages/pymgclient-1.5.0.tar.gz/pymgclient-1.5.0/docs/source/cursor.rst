===============================
:class:`Cursor` class
===============================

.. py:module:: mgclient

.. autoclass:: mgclient.Cursor
   :members:

#####################
:class:`Column` class
#####################

:attr:`Cursor.description` list consists of instances of :class:`Column` class.

.. autoclass:: mgclient.Column
   :members:
