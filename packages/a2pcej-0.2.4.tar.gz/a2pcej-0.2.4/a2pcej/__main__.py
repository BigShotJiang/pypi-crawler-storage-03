import sys

from a2pcej import main

if __name__ == "__main__":
    sys.exit(main())
