# flake8: noqa

# import apis into api package
from binoauth.tenant.api.authentication_api import AuthenticationApi
from binoauth.tenant.api.external_auth_api import ExternalAuthApi
from binoauth.tenant.api.o_auth2_api import OAuth2Api
from binoauth.tenant.api.system_api import SystemApi
from binoauth.tenant.api.user_profile_api import UserProfileApi
from binoauth.tenant.api.authentication_api import AuthenticationApi
from binoauth.tenant.api.openid_api import OpenidApi
