# -*- coding: utf-8 -*-

"""这里是lobby的一些接口
"""


def SetCityMode(isCityMode):
	# type: (bool) -> None
	"""
	【废弃】设置游戏为主城模式：包括有无法改变地形，不切换日夜，不改变天气，不刷新生物等限制

	Args:
		isCityMode     bool           是否为主城模式

	"""
	pass

