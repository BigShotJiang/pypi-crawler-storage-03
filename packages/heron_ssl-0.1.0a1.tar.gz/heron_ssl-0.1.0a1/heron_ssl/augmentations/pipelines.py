import tensorflow as tf


def simclr_augmentations(image: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    raise NotImplementedError
