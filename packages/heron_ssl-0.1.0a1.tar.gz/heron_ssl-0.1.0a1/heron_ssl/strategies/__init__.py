from .simclr import SimCLR

__all__ = ["SimCLR"]
