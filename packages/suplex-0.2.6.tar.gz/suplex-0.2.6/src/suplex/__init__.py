"""
Suplex: A Python library for interacting with Supabase REST API in Reflex applications.
"""

from .suplex import Suplex
