"""laGPy: Python implementation of local approximate GP"""
