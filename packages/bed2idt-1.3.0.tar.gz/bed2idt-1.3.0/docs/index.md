# bed2idt 

[![CI](https://github.com/ChrisgKent/bed2idt/actions/workflows/pytest.yml/badge.svg)](https://github.com/ChrisgKent/bed2idt/actions/workflows/pytest.yml)

![bed2idt](https://chrisgkent.github.io/bed2idt/assets/cli.png)

---

**Documentation**: <a href="https://chrisgkent.github.io/bed2idt/" target="_blank">https://chrisgkent.github.io/bed2idt/</a>

**Source Code**: <a href="https://github.com/ChrisgKent/bed2idt" target="_blank">https://github.com/ChrisgKent/bed2idt</a>

---


bed2idt is a commandline tool for converting .bed files, such as the primer.bed files into a formated used by IDT.
