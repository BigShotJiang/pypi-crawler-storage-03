---
title: Jupyter Agent
emoji: 🏃
colorFrom: red
colorTo: purple
sdk: gradio
sdk_version: 5.8.0
app_file: app.py
pinned: false
thumbnail: cloudops-agent.png
---


# Task-Specialized Agents for automation, by focusing on well-defined problems with clear success metrics

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
