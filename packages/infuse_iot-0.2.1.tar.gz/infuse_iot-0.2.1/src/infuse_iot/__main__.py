#!/usr/bin/env python3

from infuse_iot.app.main import main

main()
