def main():
    print("Hello from design!")


if __name__ == "__main__":
    main()
