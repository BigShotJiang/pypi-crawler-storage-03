# AI设计工具 - MCP 服务器

## 📋 项目概述

这是一个基于 FastMCP 的 AI 设计工具，实现了 SSE 流式响应处理，集成了 RAG 增强检索召回设计文档模版功能。结合 Agent 可实现沉浸式设计，支持多次交互后自动化输出 JoySpace 设计文档。

### 核心特性
- 🚀 **SSE 流式响应处理**：支持实时接收和处理流式数据
- 📄 **智能文档生成**：自动创建 JoySpace 设计文档
- 🎯 **RAG 增强检索**：支持设计文档模版召回
- 🔧 **双模式运行**：支持交互式模式和 MCP 服务器模式
- ⚡ **响应优化**：只保留最后一次成功响应，提升性能
- 🛡️ **完善错误处理**：包含网络超时、参数验证等异常处理

## 🚀 快速开始

### 环境要求
- Python 3.10 或更高版本

### 安装依赖
```bash
# 确保已安装 uv 包管理器
pip install uv

# 安装项目依赖
uv sync
```

### 启动方式

#### 1. 交互式模式（默认）
```bash
uv run design.py
```
提供友好的命令行交互界面，支持：
- AI 搜索查询
- 参数配置
- 实时结果展示

#### 2. MCP 服务器模式
```bash
uv run design.py --mcp
```
启动 MCP 服务器，等待客户端连接

#### 3. 查看帮助
```bash
uv run design.py --help
```

## 🔧 MCP 客户端本地配置

### Claude Desktop 配置
在 Claude Desktop 的 MCP 配置文件中添加：
```json
{
  "mcpServers": {
    "design": {
      "command": "uv",
      "args": ["run", "design.py", "--mcp"],
      "cwd": "/path/to/your/design/project"
    }
  }
}
```

### JoyCode 配置
```json
{
  "mcpServers": {
    "design": {
      "command": "uv",
      "args": [
        "--directory",
        "/Users/zhouyiru/Documents/work/design",
        "run",
        "design.py",
        "--mcp"
      ],
      "env": {
        "erp": "zhouyiru", 
        "joySpaceId": "CXhEKMPNaDMigxHyGSVp",
        "joyFolderId": "rMnu22BMXrCep8HwfZCt",
        "templateName": "6.0研发设计文档模版"
      },
      "disabled": false,
      "autoApprove": [
        "ai_design"
      ],
      "timeout": 180,
      "transportType": "stdio"
    }
  }
}
```
### 搭配设计Agent指令

```bash
你是一名资深系统架构师，负责将业务需求任务转化为技术设计文档，生成流程图一定要用markdown格式的或者slate json来画图，千万不要用mermaid格式。
1、首先要通过design mcp传入“【设计文档模版】”，获取研发设计文档模版作为你设计内容的参照，读取本地代码库源码分析设计方案。
2、你的设计方案过程中需要与我交流沟通，有任何疑问和思考需要让我决策。
3、最终方案完备后让我选择输入“设计完毕”指令，（仅此一次）使用design mcp工具传入最终设计文档内容，提示词是：标题：你输出的设计文档标题，内容：你输出的设计文档内容 。
输入：接收需求描述和故事点（如PRD文档、用户故事、原型图）。
输出：生成符合JoySpace标准的Markdown格式设计文档。
风格：语言简洁、逻辑严谨，兼顾技术深度与可读性，避免冗余。
```



## 🛠️ 可用工具

### `ai_design`
AI 设计工具的核心功能，支持 SSE 流式响应处理

**参数说明**：
- `erp` (必须配置): 用户ERP，可通过环境变量 `erp` 设置
- `joySpaceId` (必须配置): JoySpace 空间ID
- `joyFolderId` (必须配置): JoySpace 文件夹ID
- `templateName`（可选）：参照的设计文档模版名称

### 特殊功能：设计文档模版
- 当关键词包含 `【设计文档模版】` 时，系统会自动切换到模版获取模式：
- 需要设置环境变量 `templateName` 指定模版名称，联系 zhouyiru 进行知识库投喂更多个性化模版


## 📝 开发说明

### 核心架构
```
design.py
├── call_autobots_sse_api()     # 核心 API 调用函数
├── ai_design()                 # MCP 工具接口
├── interactive_mode()          # 交互式模式
├── search_interactive()        # 交互式搜索
└── main_sync()                 # 主程序入口
```

### 关键函数说明

#### `call_autobots_sse_api()`
- **功能**：调用 Autobots API 并处理 SSE 流式响应
- **优化**：只保留最后一次响应，提升性能
- **错误处理**：完善的网络异常处理机制

#### `_process_sse_response()`
- **功能**：处理 SSE 流式响应数据
- **优化**：`response_content` 使用字符串覆盖模式
- **监控**：实时输出接收状态和数据

#### `_validate_required_params()`
- **功能**：验证必需参数的有效性
- **检查**：空值、空字符串检测
- **返回**：友好的错误信息

### 依赖项
- `httpx`: 异步HTTP客户端，支持SSE流式响应
- `fastmcp`: FastMCP服务器框架
- `uuid`: 生成唯一追踪ID
- `json`: JSON数据处理
---

**项目状态**: ✅ 正常运行  
**最后更新**: 2025-01-12  
**版本**: 3.0.0  
**维护者**: zhouyiru