This folder has the original code copied verbatim to calculate the micro f-1 score.

These utils are developed for [NL4OPT @ NeurIPS'22 competition](https://nl4opt.github.io/)

Please find the original code here - [Original utils developed for the competition](https://github.com/nl4opt/nl4opt-subtask1-baseline/tree/main/baseline/utils)
