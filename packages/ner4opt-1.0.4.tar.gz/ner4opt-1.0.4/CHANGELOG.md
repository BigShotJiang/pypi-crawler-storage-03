# Changelog

| Date         | Notes                               |
|------------- |-------------------------------------|
| Mar 12, 2024 | **Preprocessing Routine**: Implemented a new preprocessing routine before entity extraction. This update addresses the issue highlighted in [issue #4](https://github.com/skadio/ner4opt/issues/4) on our GitHub repository. Special thanks to @kostis-init for bringing this to our attention. |
| May 3, 2023  | Initial release of Ner4Opt library. |
