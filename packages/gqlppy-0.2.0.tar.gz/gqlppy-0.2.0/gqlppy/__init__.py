"""An ISO GQL parser and checker
"""
__version__=(0,2,0)
__author__='Alex Miłowski'
__author_email__='alex@milowski.com'

from .parser import Parser