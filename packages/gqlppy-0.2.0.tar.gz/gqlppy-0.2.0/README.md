# gqlppy
ISO GQL Parser and Checker
