Para configurar este módulo, você precisa definir um certificado digital
na empresa e também definir o processador edoc da empresa.
