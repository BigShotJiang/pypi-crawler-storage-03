def hello():
    print("CodeChest çalışıyor!")
