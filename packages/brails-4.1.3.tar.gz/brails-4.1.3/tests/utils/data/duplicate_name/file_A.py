"""
Testing file A.
"""


class SomeClass:
    """
    Defines first instance of SomeClass
    """
