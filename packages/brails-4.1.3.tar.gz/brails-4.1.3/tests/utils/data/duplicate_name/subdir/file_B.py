"""
Testing file B.
"""


class SomeClass:
    """
    Defines second instance of SomeClass
    """
