"""
Testing file B.
"""


class ClassB:
    """
    Defines ClassB
    """
