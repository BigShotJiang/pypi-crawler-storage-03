"""
Testing file A.
"""

from abc import ABC


class ClassABC(ABC):
    """
    Defines ClassA
    """


class ClassA(ClassABC):
    """
    Defines ClassA
    """
