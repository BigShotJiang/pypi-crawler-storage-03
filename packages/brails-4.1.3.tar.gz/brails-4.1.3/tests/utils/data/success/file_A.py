"""
Testing file A.
"""


class ClassA:
    """
    Defines ClassA
    """

    def __init__(self, some_data):
        """
        Initializes a ClassA object and stores `some_data` its
        attributes.
        """
        self.some_data = some_data
