#pragma once

#ifndef uint
typedef unsigned int uint;
#endif