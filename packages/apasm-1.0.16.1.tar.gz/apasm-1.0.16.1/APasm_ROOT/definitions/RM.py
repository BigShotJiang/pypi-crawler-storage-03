RM = {
    "[bx+si]": 0b000,
    "[bx+di]": 0b001,
    "[bp+si]": 0b010,
    "[bp+di]": 0b011,
    "[si]":    0b100,
    "[di]":    0b101,
    "[bp]":    0b110,  # Special: if mod=00, requires disp16
    "[bx]":    0b111
}