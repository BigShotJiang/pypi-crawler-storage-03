"""
A file that prevent name confusion from the original main loader name: `AvalonPasm.py`
"""
from AvalonPasm import *