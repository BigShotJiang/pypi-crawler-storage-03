"""
figpack - A Python package for creating shareable, interactive visualizations in the browser
"""

__version__ = "0.1.7"
