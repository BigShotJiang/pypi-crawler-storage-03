Bondzai iDetect 4.0 interface
=============================

Description
~~~~~~~~~~~

Bondzai iDetect 4.0 interface provides python library to communicate with one product instance via socket

Installation
~~~~~~~~~~~~

.. code:: bash

   pip install bondzai.idetect40-interface

Usage
~~~~~

.. code:: python

   from bondzai.idetect40_interface import socket