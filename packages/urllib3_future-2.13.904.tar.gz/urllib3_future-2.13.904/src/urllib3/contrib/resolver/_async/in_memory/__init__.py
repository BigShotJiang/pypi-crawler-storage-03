from __future__ import annotations

from ._dict import InMemoryResolver

__all__ = ("InMemoryResolver",)
