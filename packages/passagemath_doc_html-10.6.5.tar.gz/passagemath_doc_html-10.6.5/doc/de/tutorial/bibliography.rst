********************
Literaturverzeichnis
********************

..  [Cyt] Cython, http://www.cython.org

..  [GAP] The GAP Group, GAP - Groups, Algorithms, and
    Programming, Version 4.4; 2005, https://www.gap-system.org

..  [GAPkg] GAP Packages,
    http://www.gap-system.org/Packages/packages.html

..  [GP] PARI/GP, https://pari.math.u-bordeaux.fr/

..  [Mag] Magma, http://magma.maths.usyd.edu.au/magma/

..  [Max] Maxima, http://maxima.sf.net/

..  [NagleEtAl2004] Nagle, Saff, and Snider.
    *Fundamentals of Differential Equations*. 6th edition, Addison-Wesley,
    2004.

..  [Py] The Python language, http://www.python.org/

..  [PyB] The Python Beginner's Guide,
    https://wiki.python.org/moin/BeginnersGuide

..  [PyDev] Python Developer's Guide,
    https://docs.python.org/devguide/

..  [PyLR] Python Library Reference,
    https://docs.python.org/3/library/index.html

..  [Pyr] Pyrex,
    http://www.cosc.canterbury.ac.nz/~greg/python/Pyrex/

..  [PyT] The Python Tutorial,
    https://docs.python.org/3/tutorial/

..  [SA] Sage web site, https://www.sagemath.org/

..  [Si] \G.-M. Greuel, G. Pfister, and H. Schönemann. Singular
    3.0. A Computer Algebra System for Polynomial Computations. Center
    for Computer Algebra, University of Kaiserslautern (2005).
    https://www.singular.uni-kl.de

..  [SJ] William Stein, David Joyner, Sage: System for Algebra and
    Geometry Experimentation, Comm. Computer Algebra {39} (2005) 61-64.

..  [ThreeJS] three.js, http://threejs.org
