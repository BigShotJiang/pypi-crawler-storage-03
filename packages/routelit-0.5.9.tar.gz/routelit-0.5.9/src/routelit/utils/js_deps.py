DEFAULT_JS_DEPENDENCIES = {
    "react": "https://esm.sh/react@19.0.0/",
    "react/jsx-runtime": "https://esm.sh/react@19.0.0/jsx-runtime",
    "react-dom": "https://esm.sh/react-dom@19.0.0/",
    "routelit-client": "https://esm.sh/routelit-client@0.5.4?external=react&external=react-dom",
}
