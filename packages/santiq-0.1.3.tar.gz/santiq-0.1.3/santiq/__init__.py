"""SANTIQ - A lightweight, modular, plugin-first ETL platform."""

__version__ = "0.1.3"
__author__ = "Dhritikrishna Tripathi"
__email__ = "dhritikrishnat@gmail.com"
