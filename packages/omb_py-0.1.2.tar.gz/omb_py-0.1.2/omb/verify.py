from __future__ import annotations

"""Verification helpers.

These routines perform structural verification (recomputing CIDs) and bundle
signature checks. Record-level signature validation requires the caller to
know or supply the correct tenant public key(s) and is intentionally minimal
here to keep the core surface small.
"""
import hashlib
from typing import Any

from .meter import canonical_json
from .signing import verify as ed25519_verify


def verify_sur(sur: dict[str, Any]) -> bool:
    """
    Return True if the SUR's CID recomputes correctly.

    This does NOT verify ``sur_sig`` (public key unknown in isolation).
    """
    base = {
        k: sur[k]
        for k in [
            "tenant_id",
            "resource",
            "quantity",
            "unit",
            "ts",
            "trace_id",
            "metadata",
        ]
        if k in sur
    }
    cid = "sha256:" + hashlib.sha256(canonical_json(base)).hexdigest()
    return cid == sur.get("sur_cid")

def verify_bundle(bundle: dict[str, Any], pub_b64: str) -> dict[str, Any]:
    """
    Verify bundle CID & signature.

    Returns dict with ``cid_ok`` and ``sig_ok`` booleans.
    """
    computed_cid = "sha256:" + hashlib.sha256(canonical_json({
        "tenant_id": bundle.get("tenant_id"),
        "exported_at": bundle.get("exported_at"),
        "records": bundle.get("records", []),
    })).hexdigest()
    cid_ok = computed_cid == bundle.get("bundle_cid")
    msg = f"{bundle['bundle_cid']}|{bundle['tenant_id']}|{bundle['exported_at']}".encode()
    try:
        sig_ok = ed25519_verify(pub_b64, msg, bundle.get("bundle_sig", ""))
    except Exception:  # pragma: no cover
        sig_ok = False
    return {"cid_ok": cid_ok, "sig_ok": sig_ok}

__all__ = ["verify_sur", "verify_bundle"]
