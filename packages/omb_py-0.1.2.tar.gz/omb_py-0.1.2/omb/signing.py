from __future__ import annotations

"""Low-level Ed25519 signing helpers used by OMB.

The signature protocol MUST remain stable:
    - Keys: Raw 32-byte Ed25519 private/public keys (no DER wrapping) encoded
        with URL-safe base64 *without* padding.
    - Message format for per-record signatures: f"{cid}|{tenant_id}|{ts}" (utf-8 bytes)
    - Message format for bundle signatures: f"{bundle_cid}|{tenant_id}|{exported_at}" (utf-8 bytes)
    - Signatures: raw 64-byte Ed25519 signature encoded base64url without padding.

Do NOT change these formats; any alteration breaks verification across systems.
"""
import base64
import hashlib
from dataclasses import dataclass
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


def b64u(b: bytes) -> str:
    """
    Return URL-safe base64 encoding of ``b`` without padding (= chars).

    This matches RFC 9068/JWT base64url behavior without padding and is
    required for deterministic canonical representations.
    """
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")

def b64u_decode(s: str) -> bytes:
    """
    Decode an unpadded base64url string.

    Adds required padding before decoding. Raises ``ValueError`` if input
    contains non-base64 characters (strict validation).
    """
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    try:
        # Use strict validation so unexpected bytes are rejected instead of
        # being silently discarded (the default behavior of urlsafe_b64decode).
        return base64.b64decode(s + pad, altchars=b"-_", validate=True)
    except Exception as e:  # pragma: no cover - defensive
        raise ValueError(f"Invalid base64url: {s!r}") from e

def jwk_from_pub(pub_raw: bytes, kid: str) -> dict[str, Any]:
    """Return a minimal JWK (OKP/Ed25519) for the raw 32-byte public key."""
    return {"kty": "OKP", "crv": "Ed25519", "x": b64u(pub_raw), "kid": kid}

def kid_for_pub(pub_raw: bytes) -> str:
    """
    Derive a deterministic key identifier from the first 16 hex chars
    of the SHA-256 digest of the raw public key.
    """
    return "ed25519-" + hashlib.sha256(pub_raw).hexdigest()[:16]

@dataclass
class Ed25519Signer:
    """
    In-memory Ed25519 signer.

    Parameters
    ----------
    priv_b64: str
        Base64url (unpadded) private key bytes (32 bytes when decoded).
    kid: str
        Application-chosen key identifier; typically ``kid_for_pub(pub_raw)``.

    """

    priv_b64: str
    kid: str

    def __post_init__(self) -> None:
        raw = b64u_decode(self.priv_b64)
        if len(raw) != 32:
            raise ValueError("Ed25519 private key must decode to 32 bytes")
        self._priv = Ed25519PrivateKey.from_private_bytes(raw)
        self._pub = self._priv.public_key()

    @property
    def pub_raw(self) -> bytes:
        """Return raw 32-byte public key."""
        return self._pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    @property
    def pub_b64(self) -> str:
        """Return base64url (unpadded) representation of the public key."""
        return b64u(self.pub_raw)

    @property
    def jwks(self) -> dict[str, Any]:
        """Return a JWKS document containing this signer's public key."""
        return {"keys": [jwk_from_pub(self.pub_raw, self.kid)]}

    def sign(self, message: bytes) -> str:
        """Sign ``message`` and return base64url signature (unpadded)."""
        sig = self._priv.sign(message)
        return b64u(sig)

def verify(pub_b64: str, message: bytes, sig_b64: str) -> bool:
    """
    Verify a signature.

    Returns ``True`` if valid, else ``False``. Any decoding / cryptographic
    failure yields ``False`` (no exceptions escape) making the helper safe for
    validation pipelines.
    """
    try:
        pub = Ed25519PublicKey.from_public_bytes(b64u_decode(pub_b64))
        pub.verify(b64u_decode(sig_b64), message)
        return True
    except Exception:  # pragma: no cover - intentionally broad
        return False

__all__ = [
    "Ed25519Signer",
    "b64u",
    "b64u_decode",
    "kid_for_pub",
    "jwk_from_pub",
    "verify",
]
