from __future__ import annotations

"""Usage metering primitives.

This module provides:
    - ``UsageIn``: user-supplied usage event (may omit timestamp)
    - ``SignedUsageRecord``: canonical, signed record persisted to storage
    - ``JSONLMeter``: simple JSONL-backed append-only store with optional
        retention trimming.

Signature protocol invariants (do NOT change):
    - CID = sha256(canonical_json(base_record_without_sig_fields)) prefixed with ``sha256:``
    - Signature message = ``f"{cid}|{tenant_id}|{ts}"`` (utf-8)
    - Signer returns base64url (unpadded) Ed25519 signature
"""
import datetime
import hashlib
import json
import logging
import os
import sqlite3
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

__all__ = []

def canonical_json(obj: Any) -> bytes:
    """Return deterministic UTF-8 JSON bytes (sorted keys, tight separators)."""
    return json.dumps(
        obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()

def sha256_cid(obj: Any) -> str:
    """Content identifier for object using SHA-256 over canonical JSON."""
    return "sha256:" + hashlib.sha256(canonical_json(obj)).hexdigest()

class UsageIn(BaseModel):
    """
    Inbound (unsigned) usage event.

    ``ts`` may be omitted; server time inserted at persistence.
    ``quantity`` must be finite; validated implicitly by pydantic (NaN/inf rejected).
    """

    tenant_id: str
    resource: str
    quantity: float = 1.0
    unit: str = "count"
    ts: str | None = None
    trace_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

class SignedUsageRecord(BaseModel):
    """Canonical persisted record with CID and signature."""

    tenant_id: str
    resource: str
    quantity: float
    unit: str
    ts: str
    trace_id: str | None = None
    metadata: dict[str, Any]
    sur_cid: str
    sur_sig: str

class JSONLMeter:
    """
    Append-only JSONL meter.

    Environment variables:
        OMB_LOCAL_SUR_PATH: override file path (default ./data/usage.jsonl)
        OMB_RETENTION_MAX_AGE_SECONDS: if set, trim records older than this age
            in seconds on each write.
    """

    def __init__(self, signer: Any, path: str | None = None):
        self.signer = signer
        env_path = os.getenv("OMB_LOCAL_SUR_PATH")
        resolved: str = (
            path
            if path is not None
            else (env_path if env_path is not None else "./data/usage.jsonl")
        )
        self.path = resolved
        os.makedirs(os.path.dirname(self.path), exist_ok=True)

    def _now_iso(self) -> str:
        return datetime.datetime.now(datetime.timezone.utc).isoformat()

    def _apply_retention(self, lines: list[str]) -> list[str]:
        max_age = os.getenv("OMB_RETENTION_MAX_AGE_SECONDS")
        if not max_age:
            return lines
        try:
            cutoff_seconds = int(max_age)
        except Exception:
            return lines
        cutoff = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(
            seconds=cutoff_seconds
        )
        kept: list[str] = []
        for line in lines:
            try:
                j = json.loads(line)
                ts = datetime.datetime.fromisoformat(j["ts"])
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=datetime.timezone.utc)
                if ts >= cutoff:
                    kept.append(line)
            except Exception:
                # Keep unparseable lines for forensic review; log at debug.
                logger.debug("Retention could not parse line", exc_info=True)
                kept.append(line)
        return kept

    def record(self, usage: UsageIn) -> SignedUsageRecord:
        # Fill ts if missing
        ts = usage.ts or self._now_iso()
        base = {
            "tenant_id": usage.tenant_id,
            "resource": usage.resource,
            "quantity": usage.quantity,
            "unit": usage.unit,
            "ts": ts,
            "trace_id": usage.trace_id,
            "metadata": usage.metadata or {},
        }
        # CID/sign over the "base" (no sig fields)
        cid = sha256_cid(base)
        msg = f"{cid}|{usage.tenant_id}|{ts}".encode()
        sig = self.signer.sign(msg)
        sur = dict(base)
        sur["sur_cid"] = cid
        sur["sur_sig"] = sig

        # Append to JSONL with retention
        try:
            existing = []
            if os.path.exists(self.path):
                with open(self.path, encoding="utf-8") as f:
                    existing = [ln for ln in f.read().splitlines() if ln.strip()]
            existing = self._apply_retention(existing)
            existing.append(json.dumps(sur, separators=(",", ":"), ensure_ascii=False))
            with open(self.path, "w", encoding="utf-8") as f:
                f.write("\n".join(existing) + "\n")
        except Exception:  # pragma: no cover - disk persistence errors ignored
            # Best-effort durability: return record even if persistence failed.
            logger.warning("Failed to persist SUR to JSONL store", exc_info=True)

        return SignedUsageRecord.model_validate(sur)

    def list_for_tenant(
        self,
        tenant_id: str,
        since_iso: str | None = None,
        until_iso: str | None = None,
    ) -> list[SignedUsageRecord]:
        """
        Return signed usage for a tenant, optionally bounded by ISO timestamps.

        Records are returned sorted ascending by timestamp.
        """
        items: list[SignedUsageRecord] = []
        if os.path.exists(self.path):
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    try:
                        j = json.loads(line)
                    except Exception:  # malformed line retained but skipped
                        logger.debug("Skipping malformed JSONL line during read", exc_info=True)
                        continue
                    if j.get("tenant_id") != tenant_id:
                        continue
                    ts = datetime.datetime.fromisoformat(j["ts"])
                    if since_iso and ts < datetime.datetime.fromisoformat(since_iso):
                        continue
                    if until_iso and ts > datetime.datetime.fromisoformat(until_iso):
                        continue
                    items.append(SignedUsageRecord.model_validate(j))
        items.sort(key=lambda r: r.ts)
        return items

class SQLiteMeter:
    """
    SQLite-backed meter (experimental behind OMB_STORE=sqlite).

    Schema (table ``sur``):
      tenant_id TEXT, ts TEXT, cid TEXT, sig TEXT, resource TEXT, qty REAL, unit TEXT,
      trace_id TEXT, metadata TEXT (canonical JSON)
    """

    def __init__(self, signer: Any, path: str | None = None):
        self.signer = signer
        env_path = os.getenv("OMB_SQLITE_PATH")
        resolved: str = (
            path
            if path is not None
            else (env_path if env_path is not None else "./data/usage.sqlite")
        )
        self.path = resolved
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._init()

    def _init(self) -> None:
        con = sqlite3.connect(self.path)
        try:
            con.execute(
                """CREATE TABLE IF NOT EXISTS sur (
                tenant_id TEXT NOT NULL,
                ts TEXT NOT NULL,
                cid TEXT NOT NULL,
                sig TEXT NOT NULL,
                resource TEXT NOT NULL,
                qty REAL NOT NULL,
                unit TEXT NOT NULL,
                trace_id TEXT,
                metadata TEXT NOT NULL
                )"""
            )
            con.execute("CREATE INDEX IF NOT EXISTS idx_sur_tenant_ts ON sur(tenant_id, ts)")
            con.commit()
        finally:
            con.close()

    def _now_iso(self) -> str:
        return datetime.datetime.now(datetime.timezone.utc).isoformat()

    def record(self, usage: UsageIn) -> SignedUsageRecord:
        ts = usage.ts or self._now_iso()
        base = {
            "tenant_id": usage.tenant_id,
            "resource": usage.resource,
            "quantity": usage.quantity,
            "unit": usage.unit,
            "ts": ts,
            "trace_id": usage.trace_id,
            "metadata": usage.metadata or {},
        }
        cid = sha256_cid(base)
        msg = f"{cid}|{usage.tenant_id}|{ts}".encode()
        sig = self.signer.sign(msg)
        con = sqlite3.connect(self.path)
        try:
            sql_insert = (
                "INSERT INTO sur (tenant_id, ts, cid, sig, resource, "
                "qty, unit, trace_id, metadata) VALUES (?,?,?,?,?,?,?,?,?)"
            )
            con.execute(
                sql_insert,
                (
                    usage.tenant_id,
                    ts,
                    cid,
                    sig,
                    usage.resource,
                    usage.quantity,
                    usage.unit,
                    usage.trace_id,
                    json.dumps(
                        base["metadata"], separators=(",", ":"), ensure_ascii=False
                    ),
                ),
            )
            con.commit()
        finally:
            con.close()
        sur = dict(base)
        sur["sur_cid"] = cid
        sur["sur_sig"] = sig
        return SignedUsageRecord.model_validate(sur)

    def list_for_tenant(
        self,
        tenant_id: str,
        since_iso: str | None = None,
        until_iso: str | None = None,
    ) -> list[SignedUsageRecord]:
        q = (
            "SELECT tenant_id, resource, qty, unit, ts, trace_id, metadata, cid, sig "
            "FROM sur WHERE tenant_id=?"
        )
        params: list[Any] = [tenant_id]
        if since_iso:
            q += " AND ts >= ?"
            params.append(since_iso)
        if until_iso:
            q += " AND ts <= ?"
            params.append(until_iso)
        q += " ORDER BY ts ASC"
        con = sqlite3.connect(self.path)
        rows: list[SignedUsageRecord] = []
        try:
            for row in con.execute(q, params):
                (tenant_id, resource, qty, unit, ts, trace_id, metadata_json, cid, sig) = row
                record = SignedUsageRecord(
                    tenant_id=tenant_id,
                    resource=resource,
                    quantity=qty,
                    unit=unit,
                    ts=ts,
                    trace_id=trace_id,
                    metadata=json.loads(metadata_json) if metadata_json else {},
                    sur_cid=cid,
                    sur_sig=sig,
                )
                rows.append(record)
        finally:
            con.close()
        return rows

def meter_for_env(signer: Any) -> JSONLMeter | SQLiteMeter:
    """Factory returning the correct meter based on OMB_STORE env (jsonl|sqlite)."""
    store = os.getenv("OMB_STORE", "jsonl").lower()
    if store == "sqlite":
        return SQLiteMeter(signer=signer)
    return JSONLMeter(signer=signer)

__all__ += [
    "UsageIn",
    "SignedUsageRecord",
    "JSONLMeter",
    "SQLiteMeter",
    "meter_for_env",
    "canonical_json",
    "sha256_cid",
]
