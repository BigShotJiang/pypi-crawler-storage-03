from __future__ import annotations

import argparse
import json
import os
import sys

from .export import bundle_for
from .meter import JSONLMeter, UsageIn
from .signing import Ed25519Signer
from .verify import verify_bundle


def _signer_from_env() -> Ed25519Signer:
    priv = os.getenv("OMB_PRIVATE_KEY_B64")
    kid = os.getenv("OMB_KID")
    if not priv or not kid:
        print("ERROR: set OMB_PRIVATE_KEY_B64 and OMB_KID", file=sys.stderr)
        sys.exit(1)
    return Ed25519Signer(priv_b64=priv, kid=kid)

def cmd_record(args):
    signer = _signer_from_env()
    meter = JSONLMeter(signer=signer)
    payload = UsageIn(
        tenant_id=args.tenant,
        resource=args.resource,
        quantity=args.quantity,
        unit=args.unit,
        trace_id=args.trace_id,
        metadata=json.loads(args.metadata) if args.metadata else {},
    )
    sur = meter.record(payload)
    print(json.dumps(sur.model_dump(), indent=2))

def cmd_export(args):
    signer = _signer_from_env()
    meter = JSONLMeter(signer=signer)
    since = None
    until = None
    if args.since:
        since = args.since
    if args.until:
        until = args.until
    items = meter.list_for_tenant(args.tenant, since, until)
    bundle = bundle_for(items, args.tenant, signer)
    print(json.dumps(bundle, indent=2))

def cmd_verify(args):
    signer = _signer_from_env()
    data = json.load(sys.stdin)
    result = verify_bundle(data, signer.pub_b64)
    ok = result.get("cid_ok") and result.get("sig_ok")
    print(json.dumps({"ok": ok, **result}, indent=2))
    if not ok:
        sys.exit(1)

def main():
    ap = argparse.ArgumentParser(prog="omb-cli", description="OMB — Signed usage & export")
    sub = ap.add_subparsers(dest="cmd", required=True)

    ap_rec = sub.add_parser("record", help="Record usage (creates SUR)")
    ap_rec.add_argument("--tenant", required=True)
    ap_rec.add_argument("--resource", required=True)
    ap_rec.add_argument("--quantity", type=float, default=1.0)
    ap_rec.add_argument("--unit", default="count")
    ap_rec.add_argument("--trace-id")
    ap_rec.add_argument("--metadata", help="JSON string")
    ap_rec.set_defaults(func=cmd_record)

    ap_exp = sub.add_parser("export", help="Export signed bundle for tenant")
    ap_exp.add_argument("--tenant", required=True)
    ap_exp.add_argument("--since", help="ISO timestamp (optional)")
    ap_exp.add_argument("--until", help="ISO timestamp (optional)")
    ap_exp.set_defaults(func=cmd_export)

    ap_ver = sub.add_parser("verify", help="Verify an export bundle from stdin")
    ap_ver.set_defaults(func=cmd_verify)

    args = ap.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
