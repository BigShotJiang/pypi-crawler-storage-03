from __future__ import annotations

"""Bundle export utilities.

Exports a set of Signed Usage Records (SURs) for a tenant into a bundle with
its own CID and signature. The signature protocol is fixed:
    message = f"{bundle_cid}|{tenant_id}|{exported_at}" (utf-8)
"""
import datetime
import hashlib
from typing import Any

from .meter import SignedUsageRecord, canonical_json
from .signing import Ed25519Signer


def bundle_for(
    records: list[SignedUsageRecord],
    tenant_id: str,
    signer: Ed25519Signer,
) -> dict[str, Any]:
    """
    Create a signed export bundle for a tenant.

    The bundle includes a deterministic CID over tenant id, export timestamp,
    and all record dicts. Records list order is preserved as supplied.
    """
    exported_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    records_raw = [r.model_dump() if hasattr(r, "model_dump") else dict(r) for r in records]
    bundle = {
        "tenant_id": tenant_id,
        "exported_at": exported_at,
        "records": records_raw,
    }
    bundle_cid = "sha256:" + hashlib.sha256(canonical_json(bundle)).hexdigest()
    msg = f"{bundle_cid}|{tenant_id}|{exported_at}".encode()
    sig = signer.sign(msg)
    return {
        "tenant_id": tenant_id,
        "exported_at": exported_at,
        "bundle_cid": bundle_cid,
        "bundle_sig": sig,
        "records": records_raw,
    }

__all__ = ["bundle_for"]
