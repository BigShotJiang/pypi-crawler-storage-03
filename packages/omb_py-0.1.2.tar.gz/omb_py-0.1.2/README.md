# omb-py

Lightweight library for **Signed Usage Records (SUR)** and **signed export bundles**.

- `omb.signing` — Ed25519 key handling, base64url helpers, JWKS
- `omb.meter` — record usage into JSONL or SQLite (set `OMB_STORE=sqlite`), compute SUR (cid + signature)
- `omb.export` — build signed bundles; verify bundle & SURs
- `omb.verify` — helpers for verification
- `omb.cli` — minimal CLI (record/export/verify)

Install (editable):
```bash
pip install -e packages/omb_py
```

Environment flags:
- `OMB_STORE=sqlite|jsonl` (default jsonl)
- `OMB_LOCAL_SUR_PATH` / `OMB_SQLITE_PATH`
- `OMB_RETENTION_MAX_AGE_SECONDS`

Stripe monetization features are exposed in the FastAPI service (see `services/omb_api`).

License: Apache-2.0
