"""
FastAPI Extensions
"""