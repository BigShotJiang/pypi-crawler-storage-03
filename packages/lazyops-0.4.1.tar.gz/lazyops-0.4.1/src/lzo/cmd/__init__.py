"""
Lazyops Commands
"""

