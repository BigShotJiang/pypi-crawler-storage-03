"""
Stateful Configurations and Utilities
"""