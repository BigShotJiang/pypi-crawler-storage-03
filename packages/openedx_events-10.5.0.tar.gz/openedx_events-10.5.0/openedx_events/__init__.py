"""
Package where Open edX Events and the necessary tooling are implemented.

These definitions are part of the Hooks Extension Framework, see OEP-50 for
more information about the project.
"""

__version__ = "10.5.0"
