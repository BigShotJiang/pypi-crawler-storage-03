"""
Package where events related to the learning subdomain are implemented.

The learning subdomain corresponds to {Architecture Subdomain} defined in
the OEP-41.
"""
