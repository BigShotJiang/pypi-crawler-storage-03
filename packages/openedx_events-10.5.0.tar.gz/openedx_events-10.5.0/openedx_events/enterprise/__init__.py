"""
Package where events related to the enterprise subdomain are implemented.

The enterprise subdomain corresponds to {Architecture Subdomain} defined in
the OEP-41.
"""
