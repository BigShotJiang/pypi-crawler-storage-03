"""
Package where events related to the analytics subdomain are implemented.

The analytics subdomain corresponds to {Architecture Subdomain} defined in
the OEP-41.
"""
