=======
Credits
=======

Development Lead
----------------

* Javi Palanca <https://github.com/javipalanca>

Contributors
------------

* Manel Soler <https://github.com/sosanzma>
* Aaron Raya <https://github.com/dinothor>
