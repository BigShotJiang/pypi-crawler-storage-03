=======
History
=======

0.3.1 (2025-08-22)
------------------
* Fixed compatibility with SPADE 4.1.2
* Fixed tests

0.3.0 (2025-07-16)
------------------
* Updated to SPADE 4.1

0.2.1 (2024-09-16)
------------------

* Fixed requirements versions.

0.2.0 (2024-09-16)
------------------

* Added reader for CSV.
* Added reader for SQL.
* Added reader for MongoDB.
* Added reader for API.

0.1.2 (2023-04-12)
------------------

* Added abstract class.

0.1.1 (2021-07-05)
------------------

* Fixed documentation style.

0.1.0 (2021-07-05)
------------------

* First release on PyPI.
