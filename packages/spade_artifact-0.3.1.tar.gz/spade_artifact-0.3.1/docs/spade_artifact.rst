spade\_artifact package
=======================

Submodules
----------

spade\_artifact.agent module
----------------------------

.. automodule:: spade_artifact.agent
   :members:
   :undoc-members:
   :show-inheritance:

spade\_artifact.artifact module
-------------------------------

.. automodule:: spade_artifact.artifact
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: spade_artifact
   :members:
   :undoc-members:
   :show-inheritance:
