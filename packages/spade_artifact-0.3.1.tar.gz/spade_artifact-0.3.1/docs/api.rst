API Documentation
=================

.. toctree::
   :maxdepth: 4

   spade_artifact
