
# Import the main client implementation
from .client import XplainableClient

# Create alias for backward compatibility
Client = XplainableClient




