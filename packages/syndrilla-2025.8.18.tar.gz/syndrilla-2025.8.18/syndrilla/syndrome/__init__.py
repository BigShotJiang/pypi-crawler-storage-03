from .syndrome import create_syndrome
