"""
Module for the connection issues of the client.
"""
