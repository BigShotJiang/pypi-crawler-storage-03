class Data:
    pass

class Feature:
    def init(self):
        pass
    def execute(self):
        pass

