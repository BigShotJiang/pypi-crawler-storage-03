# encoding:utf-8
from maths_add.decode import *
from maths_add.complex import *
from maths_add.fraction import *
from maths_add.advanced_computation import *
from maths_add.computation import *
from maths_add.geometry import *


__version__ = 2.2
__modelName__ = "maths_add"
