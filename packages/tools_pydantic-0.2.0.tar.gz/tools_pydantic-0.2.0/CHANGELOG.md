# Release Notes

## [v0.w.0] (2025-08-14)

* Rename to ToolsPydantic

## [v0.1.0] (2025-08-14)

* Initializing project