# __main__.py

import sys

def main():
    print("indie command says hello")

if __name__ == "__main__":
    main()

