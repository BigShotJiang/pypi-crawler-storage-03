try:
    import orjson
except ImportError:
    orjson = None
try:
    import rapidjson
except ImportError:
    rapidjson = None
try:
    import granian
except ImportError:
    granian = None
