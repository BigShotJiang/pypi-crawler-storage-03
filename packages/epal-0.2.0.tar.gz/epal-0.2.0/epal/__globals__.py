VERSION = "0.0.2"
VERSION_NAME = "winterburrow"

__application__ = None
__window__ = None