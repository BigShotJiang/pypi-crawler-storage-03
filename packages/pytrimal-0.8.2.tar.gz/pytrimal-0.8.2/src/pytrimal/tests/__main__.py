import unittest

from . import __name__

unittest.main(__name__)
