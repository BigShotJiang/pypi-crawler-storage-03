#ifndef HAVE_PYINTERPRETERSTATE_GETID
#define HAVE_PYINTERPRETERSTATE_GETID

#include <Python.h>

#ifndef PyInterpreterState_GetID
#define PyInterpreterState_GetID(x) (0)

#endif
#endif