The fcio-py documentation
================================

.. toctree::
  :maxdepth: 4
  :caption: Contents:

  readme
  fcio

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
