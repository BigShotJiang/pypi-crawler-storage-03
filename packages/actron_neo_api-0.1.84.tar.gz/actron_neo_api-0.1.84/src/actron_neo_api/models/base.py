from typing import Dict, List, Optional, Union, Any, Literal
from pydantic import BaseModel, Field
"""Base models and functionality for Actron Neo API"""
