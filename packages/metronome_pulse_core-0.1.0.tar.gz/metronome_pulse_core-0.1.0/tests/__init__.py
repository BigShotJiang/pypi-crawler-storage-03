# Tests for core datapulse



