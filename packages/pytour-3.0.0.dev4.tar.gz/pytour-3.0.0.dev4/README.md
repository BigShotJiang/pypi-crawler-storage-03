# tour
A framework for boosting the implementation of stimulus-response research code in the field of cognitive science and neuroscience 
