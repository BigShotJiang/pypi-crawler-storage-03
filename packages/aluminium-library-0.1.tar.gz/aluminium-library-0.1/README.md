Aluminium Library is a cross-platform computer vision library.

# Install

On macOS:

    pip install libal
