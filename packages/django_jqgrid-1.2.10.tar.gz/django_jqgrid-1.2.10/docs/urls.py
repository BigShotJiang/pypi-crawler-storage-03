# Minimal URL configuration for documentation building
from django.urls import path

urlpatterns = [
    # Empty URL configuration for docs
]