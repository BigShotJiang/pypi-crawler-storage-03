from starconsumers.cli.main import main

main()