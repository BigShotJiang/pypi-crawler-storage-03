# from refidxdb.file.dat import DAT
# from refidxdb.handler import Handler
# from refidxdb.refidxdb import RefIdxDB
# from refidxdb.url.aria import Aria
# from refidxdb.url.refidx import RefIdx

# databases = {
#     item.__name__.lower(): item
#     for item in [
#         Aria,
#         RefIdx,
#     ]
# }

# files = {
#     item.__name__.lower(): item
#     for item in [
#         DAT,
#     ]
# }

__version__ = "0.1.0"
