# Misc functions
import time


def get_datetime():
    """get_datetime."""
    return time.strftime("%Y%m%d_%H%M")
