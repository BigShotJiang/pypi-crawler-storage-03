# src/easyclimate/version.py
__version__ = "2025.9.0"
