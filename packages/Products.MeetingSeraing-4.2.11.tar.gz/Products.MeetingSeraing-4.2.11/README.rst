========================
Products.MeetingSeraing
========================

'Products.MeetingSeraing' is a custom profile for 'Products.MeetingCommunes'.
