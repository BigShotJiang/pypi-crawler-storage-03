from duckdb.experimental.spark.sql.column import Column

PairCol = tuple[Column, str]
