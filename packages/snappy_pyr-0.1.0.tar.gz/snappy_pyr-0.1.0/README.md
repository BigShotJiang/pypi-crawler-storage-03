# snappy# ⚡ Snappy

[![PyPI version](https://img.shields.io/pypi/v/snappy.svg)](https://pypi.org/project/snappy/)
[![Python versions](https://img.shields.io/pypi/pyversions/snappy.svg)](https://pypi.org/project/snappy/)
[![License](https://img.shields.io/pypi/l/snappy.svg)](LICENSE)
[![Downloads](https://static.pepy.tech/badge/snappy)](https://pepy.tech/project/snappy)

Run Python scripts the **snappy way** with a short and clean command:

```bash
pyr script.py
