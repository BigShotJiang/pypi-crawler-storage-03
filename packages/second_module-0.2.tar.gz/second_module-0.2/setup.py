from setuptools import setup,Extension,find_packages

setup(
    name="second_module",
    version="0.2",
    packages=find_packages(),
    description="My second module for practice",
)