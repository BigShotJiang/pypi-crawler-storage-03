# Metadata Hook Example

An example project of `uv-dynamic-versioning`'s metadata hook.

```bash
pip install uv
uv build
```
