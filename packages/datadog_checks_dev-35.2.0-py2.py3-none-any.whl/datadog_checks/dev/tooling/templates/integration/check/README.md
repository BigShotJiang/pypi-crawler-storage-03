# Python Agent Check

Also known as an "Agent integration", choose this template type if you need to write Python code to collect data (such as metrics, events, and logs) and submit it to Datadog through the Agent.

It creates a Python package that can be installed on the Agent.
The changelog is managed with towncrier in integrations-core and manually in other repositories.
