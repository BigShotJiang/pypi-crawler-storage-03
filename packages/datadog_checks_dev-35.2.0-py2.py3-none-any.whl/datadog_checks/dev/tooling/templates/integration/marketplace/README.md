# {integration_name}

## Overview
Include a high level overview of what this integration does:
- What does your product do (in 1-2 sentences)?
- What will customers get from this integration, and why is it valuable to them?
- What specific data will your integration monitor, and what's the value of that data?

Screenshots should be absent for this section, instead put them in the media carousel with captions.

All `###` headers are optional to showcase what this integration includes:

### Metrics

### Events

### Monitors

### Dashboards

## Setup
Specific step-by-step configuration instructions for this integration.

Screenshots are okay for this section, if they help demonstrate configuration steps.

## Uninstallation
Specific step-by-step uninstallation instructions for this integration.

## Support
Information about how and where to go for support for this integration.
