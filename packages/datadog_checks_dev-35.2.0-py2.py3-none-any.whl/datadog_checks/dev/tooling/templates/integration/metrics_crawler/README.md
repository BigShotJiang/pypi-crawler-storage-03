# Crawler-based Integration

Use this integration type for crawlers that run on Datadog's internal infrastructure.

This type is similar to the `tile` type, but includes boilerplate that's specific to crawlers.
There is no Python package for this type of integration, it essentially contains a manifest and assets.
