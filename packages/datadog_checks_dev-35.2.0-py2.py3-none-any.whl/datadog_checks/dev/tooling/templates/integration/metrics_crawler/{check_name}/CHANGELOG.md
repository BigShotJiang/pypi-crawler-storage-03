# CHANGELOG - {integration_name}

## 1.0.0 / {today}

***Added***:

* Initial Release
