# CHANGELOG - {integration_name}

## 1.0.0 / YYYY-MM-DD

***Added:***
* Initial Release