---
title: Visualizr
emoji: 👁️
colorFrom: gray
colorTo: pink
sdk: docker
app_port: 7860
---

## **Visualizr**: Video Generator part of the Chatacter Backend
