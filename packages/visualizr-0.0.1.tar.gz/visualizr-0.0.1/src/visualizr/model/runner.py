from visualizr.model.builder import Model
from visualizr.settings import Settings

settings: Settings = Settings()
model: Model = Model(settings)
