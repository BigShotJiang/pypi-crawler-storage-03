# PythonRus

Библиотека для рисования в консоли с русскоязычными командами.

## Установка

```bash
pip install pythonrus
