from iolanta.facets.foaf_person_title.facet import FOAFPersonTitle
