from iolanta.facets.wikibase_statement_title.facets import (
    WikibaseStatementTitle,
)
