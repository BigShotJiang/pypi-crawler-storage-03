"""Version information for mdllama"""

__version__ = "4.2.4"
