# pywellfast: Geothermal- well fast model 

This repository  

In  `examples` it  holds the following:
- `doc_example`: example  script for using a Dc1dwell model and `Geothermal_economics` cost engineering model for multiple realisations of subsurface properties


In  `tests` it holds the following:
- `input`: input files for the tests
- `test_benchmark_aem`: test for comparison of analytical and Analytical element model for vertical wells
- `test_dc1d_simple`: test on V1.5 DC1D example file well productivity for a `Dc1dwell` class in 
- `test_dc1d_stochastic`: test on V1.5 DC1D  example file well productivity for a `Dc1dwell` class in
- 
