"""
Wellcostmodel computes multilateral well costs 
based on well trajectory and well construction
"""

import matplotlib.pyplot as plt
import pywellgeo.well_data.water_properties as watprop
from pyfastwell import WellFastModel
from pywellgeo.well_data.names_constants import Constants
from pywellgeo.well_tree.well_tree_tno import WellTreeTNO
from pyfastwell.wellflow.wi_tno import WiTNO
from pyfastwell.plot.plotwells import plot_wells
import numpy as np

import unittest

def thiems(x, xw, rw, qw, mu=1e-3, h=100, k=100):
    r = abs(x-xw)
    rmin = rw + r*0
    r = np.maximum(r,rmin)
    kH = k*h* Constants.DARCY * 1e-3  # convert to mD*m
    dp = qw* mu * np.log(r/rw)/ (2 * np.pi * kH)
    return dp/1e5




class MyTestCase(unittest.TestCase):

    def test_benchmark_aem(self):

        well1 = WellTreeTNO.from_vertical(-650, 0, -2450, 0.1)
        well2 = WellTreeTNO.from_vertical(650,0,-2450, 0.1)
        wells = [well1, well2]
        production_temperature = 2350*0.031 + 10
        injection_temperature  = 50
        salinity = 140000
        flowrate = 135
        topres = [2300, 2300]
        botres = [2400, 2400]
        print('AHD INJ1 ', wells[0].cumulative_ahd())
        print('AHD PROD1 ', wells[1].cumulative_ahd())

        muprod = watprop.viscosity( production_temperature, salinity * 1e-6)
        muinj = watprop.viscosity(injection_temperature, salinity * 1e-6)

        k = 100
        H = 100
        kxx, kyy, kzz = k, k, k*0.1
        wi = WiTNO(wells[0], wells[1], -topres[0], -botres[0], kxx, kyy,kzz, muinj=muinj, muprod=muprod,  segmentlength=10)
        res,ii, pi = wi.setupmatrix(n=0)

        print ('q/m segments res ', res)
        print ('II m3/s /bar ', ii)
        print ('PI m3/s /bar ', pi)



        outdir = 'output/benchmark_aem'
        plotname = outdir + '/verticalwellWI'
        wells = [well1, well2]
        plot_wells(wells, plotname)

        xw = np.asarray([ -650, 650])
        q = flowrate/3600
        qw = np.asarray([q, -q])
        xmu = np.asarray([ muinj, muprod])
        x = np.arange(-1000,1000,1)
        #x= np.asarray(xw)
        dp = x*0
        rw = xw * 0
        rw = rw +0.1


        for i,xwell in enumerate(xw):
                dp = dp + thiems(x, xw[i], rw[i], qw[i], mu=np.flip(xmu)[i], h=100, k=100)

        dpw_dc1d = xw*0.0
        L = xw[1]-xw[0]
        for i, xwell in enumerate(xw):
            dpw_dc1d[i] = qw[i] / WellFastModel.pi_dc1d(L, rw[i], k*H, xmu[i], 0.0)

        ii_pi = [ ii, pi]
        dpw_aem = xw* 0.0
        for i, xwell in enumerate(xw):
            dpw_aem[i] = qw[i]/ ii_pi[i]

        fig, axes = plt.subplots(1, 1, figsize=(10,10))
        plt.xlabel('distance [m]')
        plt.ylabel('dp [bar]')
        plt.title (f"kH: 10 Dm, L: 1300, rw: 0.1, flowrate: {flowrate} m3/h, DP: {dpw_aem[0]-dpw_aem[1]} bar")
        plt.plot(x, -dp,  color='red', marker='x', label='Thiem solution')
        plt.scatter(xw, dpw_dc1d, color='green', marker='o', facecolors='none', label='DC1D solution')
        plt.scatter(xw, dpw_aem, color='magenta',  marker='o', facecolors='none', label='AEM solution')
        plt.legend()

        plotname = outdir + '/benchmark_DC1D_AEM_THIEMS'
        plt.savefig(plotname + '.png', dpi=300)

if __name__ == '__main__':
    unittest.main()