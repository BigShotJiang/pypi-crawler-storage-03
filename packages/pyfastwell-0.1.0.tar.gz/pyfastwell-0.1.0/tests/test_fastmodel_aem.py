import unittest
import matplotlib.pyplot as plt
from pywellgeo.well_data.dc1dwell import *
from pyfastwell.wellflow.well_fastmodel import WellFastModel
from pythermonomics.geothermal_economics import GeothermalEconomics
import os
import sys
sys.setrecursionlimit(3000)

class MyTestCase(unittest.TestCase):





    def test_skins_varyingdip(self):
        import numpy as np
        deviations = np.array([0, 10, 20, 30, 40, 50, 60, 70])

        khkvs = [1,3,5,10]


        xoff = 650
        L_dc1d = 2* xoff
        topdepth = 2300
        H = 100  # m
        botdepth = topdepth + H
        k =100 # mD
        rw = 0.1

        for i, khkv in enumerate( khkvs):
            skin_fastmodel = []
            skin_rogers = []
            skin_cinco = []
            skin_besson = []
            for deviation in deviations:
                output_dir = 'output/skin_dip/dip' + str(deviation)
                trajectoryfile = os.path.join(output_dir, 'inputdip.yml')
                if (i==0):
                    # create well trajectories with varying deviation
                    perforation_L = H/np.cos(np.radians(deviation))
                    perforation_X = perforation_L * np.sin(np.radians(deviation))
                    xi1,xi2 = xoff -0.5* perforation_X, xoff +0.5* perforation_X
                    xp1,xp2 = -xi1, -xi2
                    xyz_inj = np.array([
                        [0, 0, 0],
                        [0, 0, 0.5*topdepth],
                        [xi1, 0,topdepth],
                        [xi2, 0, botdepth],
                    ])
                    xyz_prd = np.array([
                        [0, 0, 0],
                        [0, 0, 0.5*topdepth],
                        [xp1, 0, topdepth],
                        [xp2, 0, botdepth],
                    ])
                    data = {
                        # "format": DoubleQuotedScalarString("XYZGENERIC"),
                        "format": 'XYZGENERIC',
                        "reservoir": {
                            "basic": {
                                "top_reservoir_depth_TVD": topdepth,
                                "bottom_reservoir_depth_TVD": botdepth
                            }
                        },
                        "well_trajectories": {
                            "INJ1": {
                                "main_wellbore": {
                                    "xyz": xyz_inj.tolist(),
                                    "radius": rw,
                                    "mindist": 25
                                }
                            },
                            "PRD1": {
                                "main_wellbore": {
                                    "xyz": xyz_prd.tolist(),
                                    "radius": rw,
                                    "mindist": 25
                                }
                            }
                        }
                    }
                    os.makedirs(output_dir, exist_ok=True)
                    with open(trajectoryfile, 'w') as f:
                        yaml.dump(data, f, default_flow_style=False)

                minimal_settings = './input/npv_thermogis2024.yml'
                economics = GeothermalEconomics.from_trajectory(minimal_settings, trajectoryfile=trajectoryfile)
                npv, lcoe_val, cashflow, *_ = economics.compute_economics()
                fastmodel = WellFastModel(economics,k=k, khkv=khkv, segmentlength=25)
                npv, lcoe_val, cashflow, simdata, wells, well_results, cop, power,  Tsurface, DT_eff, DP_eff = fastmodel.compute_economics()
                fastmodel.plot_trajectories(outdir=output_dir)
                if deviation>0:
                   skin_cinco.append (fastmodel.skin_from_deviation(H, rw, khkv, deviation=deviation, type='cinco'))
                   skin_rogers.append(fastmodel.skin_from_deviation(H, rw, khkv, deviation=deviation, type='rogers'))
                   skin_besson.append(fastmodel.skin_from_deviation(H, rw, khkv, deviation=deviation, type='besson'))
                   skin_fastmodel.append(fastmodel.getSkinFactors_dc1d(L_dc1d,rw)[1])
                else:
                    skin_cinco.append(0.0)
                    skin_rogers.append(0.0)
                    skin_besson.append(0.0)
                    skin_fastmodel.append(fastmodel.getSkinFactors_dc1d(L_dc1d,rw)[1])
            plt.plot(deviations, skin_cinco, label='Cinco et al.,1975', marker='o',markerfacecolor='none')
            plt.plot(deviations, skin_rogers, label='Rogers and Economides, 1996', marker='s',markerfacecolor='none')
            plt.plot(deviations, skin_besson, label='Besson, 1990', marker='^',markerfacecolor='none')
            plt.plot(deviations, skin_fastmodel, label='pyfastwell-AEM')

            plt.xlabel('Deviation (degrees)')
            plt.ylabel('Skin Factor')
            plt.title('Skin Factor vs. Deviation for khkv=' + str(khkv))
            plt.legend()
            plt.grid(True)
            plt.savefig ('output/skin_dip/skin_vs_deviation'+ str(khkv)+ '.png')
            plt.close()




    def test_DC1D(self):
        dc1dsettings = './input/dc1dwell_skin0.yml'
        settingfile = './input/npv_thermogis2024_138.yml'
        dc1dwell = Dc1dwell.from_configfile(dc1dsettings)
        dc1dwell.qvol =   -125/3600
        dc1dwell.dp = 30
        dc1dwell.calculateDP_qvol()
        economics = GeothermalEconomics.from_dc1d(settingfile, dc1dsettings, dc1dwell)
        # reference economics call (not using pyfastwell)

        fastmodel = WellFastModel(economics, k=500, khkv=1, segmentlength=50)
        # check if pyfastwell solution gives same result with flowrate set to same as in economics
        fastmodel.set_flowrate(135.6)
        npv, lcoe_val, cashflow, simdata, wells, well_results, cop, power, Tsurface, DT_eff, DP_eff  = fastmodel.compute_economics()
        # check for
        assert Tsurface  == pytest.approx(55.6, abs=1e-2)
        assert DT_eff == pytest.approx(35.2, abs=1e-3)
        assert DP_eff  == pytest.approx(30, abs=1e-2)
        assert power == pytest.approx(3.68, abs=0.01)









if __name__ == '__main__':
    unittest.main()