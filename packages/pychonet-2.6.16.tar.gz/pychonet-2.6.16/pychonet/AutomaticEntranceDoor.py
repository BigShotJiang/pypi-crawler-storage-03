from .ElectricBlind import ElectricBlind

"""Class for Automatically operated entrance door/sliding door Objects"""


class AutomaticEntranceDoor(ElectricBlind):
    EOJCC = 0x66
