"""Deprecated module for backwards compatibility."""

# TODO remove in a future release - deprecated in favor of MobileVersion
from mozilla_version.mobile import MobileVersion as FenixVersion  # noqa
