import nest_asyncio  # type: ignore

nest_asyncio.apply()  # type: ignore
