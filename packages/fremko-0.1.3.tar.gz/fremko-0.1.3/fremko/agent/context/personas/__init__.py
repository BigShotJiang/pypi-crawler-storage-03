from .default import DEFAULT

__all__ = [
    'DEFAULT'
    ]