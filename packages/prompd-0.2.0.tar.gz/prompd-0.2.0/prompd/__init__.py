"""Prompd CLI - A tool for working with structured prompt definitions (.prompd files)."""

__version__ = "0.1.0"