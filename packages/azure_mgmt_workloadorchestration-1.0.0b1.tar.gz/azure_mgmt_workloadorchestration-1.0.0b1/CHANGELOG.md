# Release History

## 1.0.0b1 (2025-08-18)

### Other Changes

  - Initial version
