REMOVED: This file and directory are now obsolete. All model code is in lgram/models/.
