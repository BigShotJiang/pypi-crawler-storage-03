[![documentation](https://github.com/WardDeb/linkapy/actions/workflows/docs.yml/badge.svg)](https://github.com/WardDeb/linkapy/actions/workflows/docs.yml)
[![installation](https://github.com/WardDeb/linkapy/actions/workflows/pip.yml/badge.svg)](https://github.com/WardDeb/linkapy/actions/workflows/pip.yml)
[![lint](https://github.com/WardDeb/linkapy/actions/workflows/lint.yml/badge.svg)](https://github.com/WardDeb/linkapy/actions/workflows/lint.yml)
[![tests](https://github.com/WardDeb/linkapy/actions/workflows/test.yml/badge.svg)](https://github.com/WardDeb/linkapy/actions/workflows/test.yml)
[![PyPI version](https://img.shields.io/pypi/v/linkapy)](https://pypi.org/project/linkapy/)

# linkapy
A framework to process and analyse multi-modal single-cell data.
Linkapy is mainly used to process single-cell methylation data, and is focused on creating an integrated (muData) object of multimodal single-cell data. In this context it means that multiple modalities (e.g. accessibility, DNA methylation, RNA expression) are available from the same cell. 

# Documentation

Note that this package is still in development and is prone to change without notice. 
A rudimentary [documentation](https://linkapy.readthedocs.io/en/latest/) is available.

# Quickstart

  > pip install linkapy  
  > linkapy --help
