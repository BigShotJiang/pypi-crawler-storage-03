# Development

## Setting up

For an example of a basic plugin template, please visit [Meggie Simple Plugin](https://github.com/cibr-jyu/meggie_simpleplugin) on GitHub.

Actions, pipelines, and datatypes function identically, regardless of whether they originate from a plugin or from the core of Meggie. Therefore, examining the implementations within the Meggie repository is advisable for understanding their integration and usage.
