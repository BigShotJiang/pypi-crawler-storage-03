# Meggie

Meggie is an open-source software designed for intuitive MEG and EEG analysis. With its user-friendly graphical interface, Meggie brings the powerful analysis methods of MNE-Python to researchers without requiring programming skills.

![Main Interface](./docs/images/meggie_ui.png)

## Documentation

See https://cibr-jyu.github.io/meggie for installation and usage.

## License

This project is licensed under the BSD license.

[//]: # (Hello)

## Acknowledgements

Great thanks to the *excellent* MNE-python and all the people who have helped.
