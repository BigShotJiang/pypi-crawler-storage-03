"""pymongo_aggregate module"""

from pymongo_aggregate.version import __version__
