from .init_matplotlib import init_matplotlib

init_matplotlib()
