{% macro select_distinct() %}
    SELECT DISTINCT 
{% endmacro %}