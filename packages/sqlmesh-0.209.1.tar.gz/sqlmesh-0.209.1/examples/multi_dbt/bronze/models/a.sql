SELECT
  1 AS col_a,
  'b' AS col_b
