import os

DB_PATH = os.path.join(os.path.dirname(__file__), "data/local.duckdb")
