"""Add 'partition_by_time_column' property to the IncrementalByTimeRange model kind
(default: True to keep the original behaviour)"""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
