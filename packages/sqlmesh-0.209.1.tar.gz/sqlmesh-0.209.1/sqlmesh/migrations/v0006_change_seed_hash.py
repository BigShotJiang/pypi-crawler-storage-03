"""Seed hashes moved from to_string to to_json for performance."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
