"""Seed metadata hashes now correctly include the batch_size."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
