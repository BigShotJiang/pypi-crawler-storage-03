"""Add the physical_version model attribute."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
