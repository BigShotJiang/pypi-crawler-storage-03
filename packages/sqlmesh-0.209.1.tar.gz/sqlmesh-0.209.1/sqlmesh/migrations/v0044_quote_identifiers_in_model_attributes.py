"""Quoted identifiers in model SQL attributes."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
