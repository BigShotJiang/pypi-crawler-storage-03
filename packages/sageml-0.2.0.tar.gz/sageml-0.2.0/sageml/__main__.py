from .interface import welcome


def main():
    welcome()


if __name__ == '__main__':
    main()
