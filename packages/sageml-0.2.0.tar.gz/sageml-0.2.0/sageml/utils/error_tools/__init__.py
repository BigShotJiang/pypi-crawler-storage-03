from .exceptions import WrongDataTypeException, WrongShapeException
