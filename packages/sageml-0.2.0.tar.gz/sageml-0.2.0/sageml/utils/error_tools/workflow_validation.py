class WorkflowValidator:
    def add_workflow(self, workflow):
        pass

    def validate(self):
        pass


class DumbWorkflowValidator(WorkflowValidator):
    pass
