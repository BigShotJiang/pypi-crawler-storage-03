"""
Module containing the tutorials for the SageML interface.
"""
# TODO: Implement tutorials
TUTORIAL_1 = """
test









"""
TUTORIAL_2 = """
test_2









"""
TUTORIAL_3 = """
test_3









"""
TUTORIAL_4 = """
test_4









"""
TUTORIAL_5 = """
test_5









"""

TUTORIAL_NAMES = {
    1: 'What is SageML ',
    2: 'How to load a dataset ',
    3: 'How does this program work',
    4: 'How to train a model',
    5: 'How to test a model ',
}
# TODO: Consider other tutorials

TUTORIAL_DICT = {
    1: TUTORIAL_1,
    2: TUTORIAL_2,
    3: TUTORIAL_3,
    4: TUTORIAL_4,
    5: TUTORIAL_5,
}
