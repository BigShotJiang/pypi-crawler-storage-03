"""
Interface version 1 sub-package for sageml.
The module contains functions to introduce user to library in interactive command line interface.
"""
from sageml.interface.welcome import welcome
