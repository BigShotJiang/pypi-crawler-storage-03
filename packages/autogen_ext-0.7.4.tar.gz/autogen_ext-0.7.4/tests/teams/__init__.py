"""Init file for teams tests."""
