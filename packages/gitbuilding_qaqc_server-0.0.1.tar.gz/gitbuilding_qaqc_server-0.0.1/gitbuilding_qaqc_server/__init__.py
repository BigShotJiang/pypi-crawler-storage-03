"""GitBuilding QAQC server.

Run with:

    gitbuilding-qaqc-server
"""
