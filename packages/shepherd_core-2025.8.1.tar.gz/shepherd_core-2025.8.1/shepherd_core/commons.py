"""Container for commonly shared constants."""

from .config import config

# TODO: deprecated - replace with config in subprojects and then remove here
SAMPLERATE_SPS_DEFAULT: int = config.SAMPLERATE_SPS
