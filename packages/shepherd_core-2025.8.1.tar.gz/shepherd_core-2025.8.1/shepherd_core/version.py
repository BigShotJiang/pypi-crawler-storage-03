"""Separated string avoids circular imports."""

version: str = "2025.08.1"
