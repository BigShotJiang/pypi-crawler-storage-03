"""Module for lowest hierarchy of data-models.

these models import externally from: None
"""
