import pytest


@pytest.mark.usefixtures("_file_cleanup")
def test_vsource_cleanup() -> None:
    pass
