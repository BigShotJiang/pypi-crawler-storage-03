from .cli_app import cli_app

if __name__ == "__main__":
    raise SystemExit(cli_app())