class UniswapV3Liquidity:
    def __init__(self):
        pass
