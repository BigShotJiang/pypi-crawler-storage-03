# cyhperinios

Gelişmiş, çok katmanlı bir şifreleme kütüphanesi. Scrypt ile anahtar türetimi ve AEAD (AES-256-GCM, ChaCha20-Poly1305) katmanlarıyla güçlü koruma sağlar.

## Kurulum

Not: Yerel olarak modülü kullanmak için proje klasörünüzdeyken import edebilirsiniz. Paketlemek için:

```
pip install build
python -m build
pip install dist/cyhperinios-0.1.0-py3-none-any.whl
```

## Kullanım

```python
import cyhperinios

enc = cyhperinios.AdvancedEncryption("parola")
sifreli = enc.encrypt("merhaba")
cozulmus = enc.decrypt(sifreli)
print(sifreli)
print(cozulmus)
```

## Uyarılar
- Kısa parolalar zayıftır; 12+ karakter önerilir.
- Çok katmanlı yapı performans maliyeti doğurur.
- Aynı metin her çalıştırmada farklı şifreli çıktılar üretir (salt/nonce rastgele).
