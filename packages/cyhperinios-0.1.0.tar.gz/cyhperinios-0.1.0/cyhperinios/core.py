import base64
import os
import secrets
import struct
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, hmac

class AdvancedEncryption:
    """
    Gelişmiş katmanlı şifreleme kütüphanesi.
    
    Özellikler:
    - Scrypt (bellek-zor) ile anahtar türetme ve içeriğe gömülü KDF parametreleri
    - Her katmanda ayrı anahtar/nonce/AAD
    - Katman sırası: özel katman -> 10 katman (AES-GCM / ChaCha20-Poly1305 dönüşümlü) -> özel katman
    - Global HMAC-SHA256 ile kapsayıcı bütünlük ve taahhüt (commitment)
    - Çıktı: base64-URL-safe
    """

    def __init__(self, password: str, n: int = 2**14, r: int = 8, p: int = 2):
        if not password or len(password) < 1:
            raise ValueError("Parola boş olamaz")
        self.password = password.encode()
        self.n = n
        self.r = r
        self.p = p
        # Kapsayıcı sürüm etiketi
        self._container_hdr = b"APv1"

    def _derive_key(self, salt: bytes) -> bytes:
        """Scrypt ile 64 bayt master anahtar türetir."""
        kdf = Scrypt(salt=salt, length=64, n=self.n, r=self.r, p=self.p)
        return kdf.derive(self.password)

    def _split_keys(self, master: bytes) -> tuple[bytes, bytes]:
        """HKDF ile (katman_taban_anahtari, mac_anahtari) türetir."""
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=64,
            salt=None,
            info=b"APv1-master-split",
        )
        okm = hkdf.derive(master)
        return okm[:32], okm[32:64]

    def _hmac(self, key: bytes, data: bytes) -> bytes:
        h = hmac.HMAC(key, hashes.SHA256())
        h.update(data)
        return h.finalize()

    def _layer_key(self, base: bytes, idx: int, alg_id: int) -> bytes:
        """Katman başına 32 bayt anahtar türetimi (HKDF+domain separation)."""
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"APv1-layer-" + struct.pack(">I", idx) + bytes([alg_id]),
        )
        return hkdf.derive(base)

    def _default_layers(self, inner_count: int = 10) -> list[int]:
        """Varsayılan boru hattı: custom(1) -> [AESGCM(2), ChaCha(3)] x inner_count -> custom(1)."""
        layers = [1]
        for i in range(inner_count):
            layers.append(2 if i % 2 == 0 else 3)
        layers.append(1)
        return layers

    def encrypt(self, plaintext: str) -> str:
        """
        Katmanlı şifreleme kapsayıcısı üretir.
        Dönüş: base64(container_hdr | kdf_params | salt | layer_count | layer_ids | katmanlı_payload | mac)
        """
        if not plaintext:
            return ""

        data = plaintext.encode()
        # Scrypt parametreleri: lgN (1), r (4), p (4)
        lgN = (self.n.bit_length() - 1)
        if 1 << lgN != self.n:
            raise ValueError("Scrypt n parametresi 2'nin kuvveti olmalıdır")
        params = struct.pack(
            ">BII", lgN, self.r, self.p
        )
        salt = os.urandom(32)
        master = self._derive_key(salt)
        layer_base, mac_key = self._split_keys(master)
        layers = self._default_layers(10)
        if len(layers) > 255:
            raise ValueError("Katman sayısı çok fazla")
        layer_count = len(layers)
        header = self._container_hdr + params + salt + bytes([layer_count]) + bytes(layers)
        payload = data
        for idx, alg_id in enumerate(layers):
            key = self._layer_key(layer_base, idx, alg_id)
            if alg_id in (1, 2):
                aead = AESGCM(key)
                nonce = os.urandom(12)
                aad = self._container_hdr + params + bytes([layer_count]) + bytes(layers) + struct.pack(">I", idx)
                ct = aead.encrypt(nonce, payload, aad)
            elif alg_id == 3:
                aead = ChaCha20Poly1305(key)
                nonce = os.urandom(12)
                aad = self._container_hdr + params + bytes([layer_count]) + bytes(layers) + struct.pack(">I", idx)
                ct = aead.encrypt(nonce, payload, aad)
            else:
                raise ValueError("Bilinmeyen algoritma kimliği")
            payload = (
                struct.pack(">I", len(nonce)) + nonce +
                struct.pack(">I", len(ct)) + ct
            )
        body = header + payload
        mac = self._hmac(mac_key, body)
        combined = body + mac
        return base64.urlsafe_b64encode(combined).decode()

    def decrypt(self, encrypted_data: str) -> str:
        """
        Katmanlı kapsayıcıyı tersten çözer.
        """
        if not encrypted_data:
            return ""

        try:
            combined = base64.urlsafe_b64decode(encrypted_data.encode())
            if len(combined) < 4 + 9 + 32 + 1 + 1 + 32:
                raise ValueError("Şifreli veri çok kısa veya bozuk")
            off = 0
            hdr = combined[off:off+4]; off += 4
            if hdr != self._container_hdr:
                raise ValueError("Desteklenmeyen veya bozuk şifreli veri biçimi")
            params = combined[off:off+9]; off += 9
            lgN, r, p = struct.unpack(">BII", params)
            n = 1 << lgN
            salt = combined[off:off+32]; off += 32
            layer_count = combined[off]; off += 1
            if layer_count == 0:
                raise ValueError("Geçersiz katman sayısı")
            layers = list(combined[off:off+layer_count]); off += layer_count
            payload_and_mac = combined[off:]
            if len(payload_and_mac) < 32:
                raise ValueError("MAC eksik")
            body = combined[: -32]
            mac = combined[-32:]
            master = Scrypt(salt=salt, length=64, n=n, r=r, p=p).derive(self.password)
            layer_base, mac_key = self._split_keys(master)
            # MAC doğrulama
            try:
                h = hmac.HMAC(mac_key, hashes.SHA256())
                h.update(body)
                h.verify(mac)
            except Exception:
                raise ValueError("Doğrulama başarısız (MAC)")
            # Katmanları tersten çöz
            payload = body[len(hdr) + len(params) + 32 + 1 + layer_count:]
            for idx in reversed(range(layer_count)):
                alg_id = layers[idx]
                if len(payload) < 4:
                    raise ValueError("Eksik veri (nonce uzunluğu)")
                nlen = struct.unpack(">I", payload[:4])[0]
                payload = payload[4:]
                if len(payload) < nlen + 4:
                    raise ValueError("Eksik veri (nonce veya şifreli uzunluk)")
                nonce = payload[:nlen]
                payload = payload[nlen:]
                ctlen = struct.unpack(">I", payload[:4])[0]
                payload = payload[4:]
                if len(payload) < ctlen:
                    raise ValueError("Eksik veri (şifreli içerik)")
                ct = payload[:ctlen]
                payload = payload[ctlen:]
                key = self._layer_key(layer_base, idx, alg_id)
                aad = hdr + params + bytes([layer_count]) + bytes(layers) + struct.pack(">I", idx)
                if alg_id in (1, 2):
                    aead = AESGCM(key)
                    pt = aead.decrypt(nonce, ct, aad)
                elif alg_id == 3:
                    aead = ChaCha20Poly1305(key)
                    pt = aead.decrypt(nonce, ct, aad)
                else:
                    raise ValueError("Bilinmeyen algoritma kimliği")
                payload = pt
            return payload.decode()
        except Exception as e:
            raise ValueError("Çözme başarısız. Veri bozuk olabilir veya parola yanlış.") from e


def generate_strong_password(length=32):
    """Güçlü rastgele parola üretir."""
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?"
    return ''.join(secrets.choice(alphabet) for _ in range(length))
