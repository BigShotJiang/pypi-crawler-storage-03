This module could be used either for:
1. Smooth transition from migrate tool to alembic
2. As standalone alembic tool

Core points:
1. Upgrade/downgrade database with usage of alembic/migrate migrations
or both
2. Compatibility with oslo.config
3. The way to autogenerate new revisions or stamps
