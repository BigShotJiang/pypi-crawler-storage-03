# hjy-aimanager-v2

Hjy aimanager package version 2.0.0.

## Installation

```bash
pip install hjy-aimanager-v2
```

## Usage

```python
import hjy_aimanager_v2
print(hjy_aimanager_v2.__version__)
```
