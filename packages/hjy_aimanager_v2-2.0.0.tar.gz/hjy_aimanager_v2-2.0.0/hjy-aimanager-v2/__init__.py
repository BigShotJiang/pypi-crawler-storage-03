"""
hjy-aimanager-v2 - Version 2.0.0
"""

__version__ = "2.0.0"
