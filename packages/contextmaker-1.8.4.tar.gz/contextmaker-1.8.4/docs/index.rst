.. toctree::
   :maxdepth: 3
   :caption: Contents:

   introduction
   usage
   examples
   api
   modules
   contextmaker
