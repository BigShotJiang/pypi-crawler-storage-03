
harpiamm is a Python library for the microscopy module of the [HARPIA](https://lightcon.com/products/spectroscopy-systems/) transient absorption spectrometer developed by [LIGHT CONVERSION](https://lightcon.com).

## Install
harpiamm is available via [PyPI](https://pypi.python.org/pypi/harpiamm/).
Install using `pip`:
```
  python -m pip install harpiamm
 ```
Copyright 2019-2024 Light Conversion

Contact: support@lightcon.com
