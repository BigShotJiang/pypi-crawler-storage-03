default_app_config = "weni.grpc.core.apps.GrpcCentralConfig"
