from django.apps import AppConfig


class OrgGrpcConfig(AppConfig):
    name = "weni.grpc.org"
