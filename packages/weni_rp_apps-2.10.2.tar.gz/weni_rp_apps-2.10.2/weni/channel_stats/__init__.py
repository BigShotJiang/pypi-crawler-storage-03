default_app_config = "weni.channel_stats.apps.ChannelStatsConfig"
