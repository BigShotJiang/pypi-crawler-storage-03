from django_tex.models import TeXTemplateFile


class TemplateFile(TeXTemplateFile):
    pass
