"""Video MCP 模块主入口

支持使用 python -m aigroup_video_mcp.video_mcp 启动服务器
"""

from .cli import main

if __name__ == "__main__":
    main()