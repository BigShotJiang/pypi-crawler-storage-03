from KunQuant.Op import ReductionOp

class ReduceAdd(ReductionOp):
    pass

class ReduceMul(ReductionOp):
    pass

class ReduceMin(ReductionOp):
    pass

class ReduceMax(ReductionOp):
    pass

class ReduceArgMax(ReductionOp):
    pass

class ReduceArgMin(ReductionOp):
    pass

class ReduceRank(ReductionOp):
    pass

class ReduceDecayLinear(ReductionOp):
    pass