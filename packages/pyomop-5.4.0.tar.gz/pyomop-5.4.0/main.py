#!/usr/bin/env python
# -*- coding: utf-8 -*-


from src.pyomop import main


if __name__ == '__main__':
    main.main_routine()