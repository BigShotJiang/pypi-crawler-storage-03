## Other useful libraries

* [cui-cdm](https://github.com/E-Health/cui-cdm) - CUI to Concept mapping
* [cui-embed](https://github.com/dermatologist/cui-embed) - CUI embeddings (Word2Vec) for similarity search.
* [Hephaestus](https://github.com/dermatologist/hephaestus) - For ETL
