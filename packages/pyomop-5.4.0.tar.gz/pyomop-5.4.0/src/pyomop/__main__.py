from .main import main_routine

main_routine()
# This file is the entry point for the pyomop package.
# It imports the main function from the main module and calls it.
# This allows the package to be run as a script using `python -m pyomop`.
