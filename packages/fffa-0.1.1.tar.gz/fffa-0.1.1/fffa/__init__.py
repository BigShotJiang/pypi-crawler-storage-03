from .fff import fff

__all__ = ["FoodFindingFoxes"]
__version__ = "0.1.0"
