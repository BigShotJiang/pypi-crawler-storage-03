class SectionApi:
    get_mine_all_section = "/tp/section/mine/all"
    create_section_label = "/tp/section/label/create"
    create_section = "/tp/section/create"