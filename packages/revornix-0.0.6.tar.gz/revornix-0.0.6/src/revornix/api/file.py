class FileApi:
    upload_file = "/tp/file/upload"