class DocumentApi:
    create_document = "/tp/document/create"
    get_mine_all_document_labels = "/tp/document/label/list"
    create_document_label = "/tp/document/label/create"