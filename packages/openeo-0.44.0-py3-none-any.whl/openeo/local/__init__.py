from openeo.local.connection import LocalConnection

__all__ = ["LocalConnection"]
