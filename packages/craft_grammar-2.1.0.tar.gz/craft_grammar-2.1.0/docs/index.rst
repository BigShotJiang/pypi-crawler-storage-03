=========================================
Welcome to Craft Grammar's documentation!
=========================================

.. toctree::
   :caption: Getting started
   :maxdepth: 2

.. toctree::
   :caption: Reference:
   :maxdepth: 2

   craft_grammar

.. toctree::
   :caption: About the project

   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
