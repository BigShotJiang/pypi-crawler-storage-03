# vtds-provider-mock

A mock Provider layer for the vTDS suite to be used in testing other
layers and in testing the vTDS Core.
