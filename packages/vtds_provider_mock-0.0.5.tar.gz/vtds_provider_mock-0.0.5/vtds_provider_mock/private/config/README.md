# Common Cluster Layer Base Configuration

Base configuration supplied by the Common Cluster Layer implementation

