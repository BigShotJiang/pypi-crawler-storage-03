from .netcdf import EbasNetcdf, EbasNetcdf1
