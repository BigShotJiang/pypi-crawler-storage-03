# EBAS IO

ebas-io - higher level file I/O for ebas

ebas-io can read EBAS Nasa Ames files
The standard file IO format for the EBAS database (EBAS NASA Ames) is based on
the NASA Ames 1001 definition. 
Please mind, that EBAS NASA Ames is an extention to NASA Ames 1001 and
provides a lot more standardized metadata.

Author: Paul Eckhardt, NILU


> For more information, please vistsi the [Wiki pages](https://git.nilu.no/ebas/ebas-io/-/wikis/home).

