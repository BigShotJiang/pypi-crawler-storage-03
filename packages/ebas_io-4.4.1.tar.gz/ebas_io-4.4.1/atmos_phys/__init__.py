"""Moule atmos_phys

Support module for calculations in atmosperic physics.
"""

__version__ = 'V.1.08.00-next-devel'
