"""Tests for Carleton University integration."""
