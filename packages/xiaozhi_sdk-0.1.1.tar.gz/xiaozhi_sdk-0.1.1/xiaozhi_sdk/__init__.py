__version__ = "0.1.1"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
