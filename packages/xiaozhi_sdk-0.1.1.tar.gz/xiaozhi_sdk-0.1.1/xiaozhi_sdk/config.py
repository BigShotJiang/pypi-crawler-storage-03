INPUT_SERVER_AUDIO_SAMPLE_RATE = 16000

OTA_URL = "https://api.tenclass.net/xiaozhi/ota"
