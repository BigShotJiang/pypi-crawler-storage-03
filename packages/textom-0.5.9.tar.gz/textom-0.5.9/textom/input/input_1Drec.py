## Input 
pattern = 'integrate_1d.h5'
subdir_data = 'data_integrated_1d'
flip_fov = True
sirt_max_iter = 100
save_sinogram = True
####