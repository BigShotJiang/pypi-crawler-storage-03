import json
import logging
from typing import Tuple, Dict, Any

from ray import serve

from folder_classifier.dto import FolderClassificationRequest, FolderClassification
from folder_classifier.util import build_folder, render_tree

SYSTEM_PROMPT = """
You are a strict text classifier.
Output MUST be a single JSON object with exactly two keys: "category" and "reasoning".
- "category" ∈ {"matter","other"} (lowercase).
- "reasoning" ≤ 30 words, citing rule IDs (e.g., RC+R7 or R1+R3) and up to two brief evidence tokens.
- Do not include any double-quote (") characters inside the value of "reasoning"; use single quotes ' instead.
- No backticks, no code fences, no extra text. Return one JSON object only.
No step-by-step thinking. No extra keys. If unsure, choose "other".
""".strip()

USER_PROMPT_TEMPLATE = """
Classify the FOLDER TREE as "matter" or "other".

Definitions
- matter: The FOLDER TREE represents exactly one legal matter/container (one client/case/matter) AND includes at least one legal-work indicator.
- other: Anything else, including:
  (a) the FOLDER TREE appears to contain multiple distinct matters (a container of matters), or
  (b) the ROOT NAME is a common subfolder/stage/type (e.g., "Correspondence", "Drafts", "Pleadings", "Court Documents", "Billing", "Evidence"), or
  (c) legal-work indicators are absent, or
  (d) there are zero files with extensions anywhere in the tree, or
  (e) contents are exclusively non-legal domains (finance/accounting/IT/admin) with no legal-work indicators, or
  (f) the ROOT NAME is non-matter-specific, including either:
      (f1) system/provenance roots (e.g., “CORTO Generated”, “Exports”, “Uploads”, “Dropbox Shared”, “OneDrive”, “SharePoint”,
           “Archive”, “Backup”, “Temp”, “Incoming”, “Outbox”, “Bulk Import”), or
      (f2) informal/placeholder roots lacking client/company/matter cues (e.g., “hello”, “test”, “misc”, “docs”, “files”,
           “images”, “photos”, “scans”, “new folder”, “untitled”, “random”; very short single tokens with no digits).

Decision Rules (apply in order; case-insensitive)
RC_container: Any indication the FOLDER TREE holds more than one distinct matter → category=other.
  • Signals include: ≥2 top-level subfolders whose names match matter-like patterns (e.g., “<number> - <id>”, “<client> - <topic>”), even if those subfolders are empty.
  • Repetitive top-level “matter-number” patterns also indicate a container.
R0_subfolder: ROOT NAME equals a common matter subfolder/stage/type (e.g., Correspondence/Emails, File Notes/Attendance Notes, Searches/Certificates, Court Documents/Pleadings/Evidence/Disclosure/Discovery, Drafts/Final/Signed/Executed, Billing/Invoices/Time Records) → category=other.
R7_files_present: Must contain ≥1 file with an extension (e.g., .pdf, .docx) anywhere in the tree; if none → category=other.
R8_nonlegal_only: If the tree shows strong non-legal domain signals and NO legal-work indicators (R2–R4 or R6), classify as other.
  • Finance/Accounting examples: BAS/IAS/GST/Tax Return, PAYG, payroll/timesheets/payslips, superannuation, Xero/MYOB/QuickBooks exports, GL/Trial Balance/Journals, bank statements, invoices/receipts, reconciliations, aged AR/AP, debtor/creditor lists, debtor collection schedules, AR “demand/reminder” letters in collections context.
  • IT/Systems examples: backups, logs, source code, Git/DevOps, server/network/VPN, mailboxes, workspace/365 admin.
  • Admin-only examples: generic receipts/vendor invoices/expenses without legal context.
R9_non_matter_specific_rootname: ROOT NAME is non-matter-specific → category=other.
  • R9a_system_provenance: matches system/provenance roots (generated/export/import/shared/archive/backup/temp/uploads/
                           downloads/platform names like Dropbox/OneDrive/SharePoint).
  • R9b_placeholder_informal: matches informal/placeholder roots with no client/company/matter cues (single common words,
                              “new folder”, “untitled”, short tokens without digits).
R1_rootname: ROOT NAME resembles a single matter/container (matter/case/file number; client/surname/company; or a combination like “12345 Smith”, “Smith – Contract Dispute”, “Brown – Lease Review”).
R2_initial_docs: Early-stage matter docs (cost agreement/disclosure, retainer/engagement, intake/onboarding).
R3_legal_docs: Legal document types (agreement, contract, deed, will, affidavit, statement, advice, brief, pleadings, court forms, subpoena, orders, judgment, undertaking, notice of appeal, docket/case forms).
R4_legal_subfolders: Typical legal subfolders (correspondence/emails, file notes/attendance notes, searches/certificates, court documents/evidence/disclosure/discovery, drafts/final/signed/executed, billing/invoices/time records).
R5_support_filename_patterns: Supportive only (not decisive): versioning (v1/v2/v3), “final”, “executed”, “signed”, eight-digit dates (YYYYMMDD/DDMMYYYY).
R6_jurisdiction: Court/jurisdiction/case references (generic court acronyms, registry references, docket patterns).

Decision
- If RC_container → category=other (stop).
- Else if R0_subfolder → category=other (stop).
- Else if NOT R7_files_present → category=other (stop).
- Else if R8_nonlegal_only → category=other (stop).
- Else if R9_generic_rootname → category=other (stop).
- Else if R10_weak_rootname → category=other (stop).
- Else if R1_rootname AND any of {R2, R3, R4, R6} AND no multi-matter signal → category=matter.
  (R5 is supportive only and cannot justify "matter" by itself.)
- Else → category=other.

Normalization
- “File with extension”: period + 1–5 char alphanumeric extension (e.g., .pdf, .docx). Ignore leading/trailing periods.
- Treat hyphens/underscores as separators. Ignore extensions for semantic matching beyond presence. Tolerate minor typos.

Output (JSON only; no prose before/after):
{"category": "<matter|other>", "reasoning": "<≤30 words citing R# and 1–2 evidence tokens>"}

FOLDER TREE:
{folder_tree}
""".strip()


FOLDER_CLASSIFICATION_SCHEMA = FolderClassification.model_json_schema()


class FolderClassifier:
    def __init__(self, app_name: str, deployment: str, model: str):
        self.logger = logging.getLogger(__name__)
        self.model_handle = serve.get_deployment_handle(app_name=app_name, deployment_name=deployment)
        self.model = model
        self.logger.info(f"Successfully initialized Folder Classifier with remote Ray model: {self.model}")

    async def predict(self, request: FolderClassificationRequest) -> Tuple[str, str]:
        content = ""
        try:
            chat_completion_request = self._to_chat_completion_request(request)
            response = await self.model_handle.create_chat_completion_internal.remote(chat_completion_request)
            response_dict = json.loads(response.body)
            content = response_dict["choices"][0]["message"]["content"]
            result = FolderClassification.model_validate_json(content)
        except Exception as ex:
            self.logger.warning(f"Failed to parse response: {content}\n{ex}")
            if '"category": "matter"' in content:
                result = FolderClassification(category="matter", reasoning="NA")
            else:
                result = FolderClassification(category="other", reasoning="NA")
        return result.category, result.reasoning

    def _to_chat_completion_request(self, request: FolderClassificationRequest) -> Dict[str, Any]:
        input_paths = request.items
        folder = build_folder(input_paths)
        folder_tree = render_tree(folder)
        chat_completion_request = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": USER_PROMPT_TEMPLATE.replace("{folder_tree}", folder_tree)}
            ],
            "max_tokens": 1024,
            "temperature": 0.7,
            "top_p": 0.8,
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "FolderClassification",
                    "schema": FOLDER_CLASSIFICATION_SCHEMA,
                    "strict": True,
                },
            }
        }
        return chat_completion_request





