# Use of this module is deprecated. Please use `ezmsg.learn.model` or `ezmsg.learn.process` instead.
