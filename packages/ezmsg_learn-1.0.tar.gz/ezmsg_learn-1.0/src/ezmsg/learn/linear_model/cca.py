from ..model.cca import IncrementalCCA as IncrementalCCA
