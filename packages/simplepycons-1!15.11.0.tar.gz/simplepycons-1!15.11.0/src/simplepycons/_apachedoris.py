#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class ApacheDorisIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "apachedoris"

    @property
    def original_file_name(self) -> "str":
        return "apachedoris.svg"

    @property
    def title(self) -> "str":
        return "Apache Doris"

    @property
    def primary_color(self) -> "str":
        return "#444FD9"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Apache Doris</title>
     <path
 d="M8.666.0001c-.5355-.004-1.068.1072-1.5241.3384-.207.1048-.5749.3802-.8177.6118-1.0278.9803-1.2876
 2.5138-.6553 3.8679.205.439.5068.7694 2.8476 3.1166 2.4527 2.4594
 2.6352 2.6255 2.8852 2.6258.2446.0003.3647-.099
 1.4408-1.19.9367-.9496 1.2306-1.2992
 1.4536-1.7286.5966-1.149.6487-2.0513.174-3.014-.2264-.459-.4816-.7514-1.9012-2.176-.9018-.9052-1.7907-1.7496-1.9751-1.8765C10.0488.2005
 9.3548.0052 8.666 0ZM3.5518
 5.5737c-.2176.0031-.6097.085-.6097.3285v12.0904l.1642.175c.1123.1194.2498.1748.4342.1748.2545
 0 .4436-.1738 3.349-3.0786 2.6868-2.6862 3.079-2.909
 3.0791-3.305.0002-.3961-.3924-.6194-3.0784-3.306-2.8612-2.8619-3.0968-3.079-3.3384-3.079Zm13.0967.861c-.0481.0184-.112.1636-.1418.3225-.0756.403-.3719
 1.109-.6572 1.5663-.1407.2253-2.2392 2.3955-5.049 5.2212-2.7513
 2.7667-4.9104 4.9985-5.0468 5.2165-.4552.7275-.5967 1.3905-.4684
 2.1964.222 1.3947 1.3263 2.6812 2.5486 2.9693.4667.11 1.618.0927
 2.0329-.0305.2084-.062.526-.2112.7055-.3318.5023-.3373 9.341-9.0562
 9.6463-9.5154.449-.6753.8356-1.0716.8395-1.9762-.0056-.5935-.1305-1.1138-1.0715-2.306-.5094-.6523-3.2341-3.3723-3.338-3.3324Z"
 />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
