#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class AcerIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "acer"

    @property
    def original_file_name(self) -> "str":
        return "acer.svg"

    @property
    def title(self) -> "str":
        return "Acer"

    @property
    def primary_color(self) -> "str":
        return "#83B81A"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Acer</title>
     <path d="M23.943 9.364c-.085-.113-.17-.198-.595-.226-.113
 0-.453-.029-1.048-.029-1.56 0-2.636.482-3.175
 1.417.142-.935-.765-1.417-2.749-1.417-2.324 0-3.798.935-4.393
 2.834-.226.709-.226 1.276-.056
 1.73h-.567c-.425.027-.992.056-1.36.056-.85
 0-1.39-.142-1.588-.425-.17-.255-.17-.737.057-1.446.368-1.162
 1.247-1.672 2.664-1.672.737 0 1.445.085 1.445.085.085 0
 .142-.113.142-.198l-.028-.085-.057-.397c-.028-.255-.227-.397-.567-.453-.311-.029-.567-.029-.907-.029h-.028c-1.842
 0-3.146.624-3.854 1.814.255-1.219-.596-1.814-2.551-1.814-1.105
 0-1.9.029-2.353.085-.368.057-.595.199-.68.454l-.17.51c-.028.085.029.142.142.142.085
 0 .425-.057.992-.086a24.816 24.816 0 0 1 1.672-.085c1.077 0 1.559.284
 1.389.822-.029.114-.114.199-.255.227-1.02.17-1.842.284-2.438.369-1.7.226-2.692.736-2.947
 1.587-.369 1.162.538 1.728 2.72 1.728 1.078 0 2.013-.056
 2.75-.198.425-.085.652-.17.737-.453l.396-1.304c-.028 1.304.85 1.955
 2.721 1.955.794 0 1.559-.028
 1.927-.085.369-.056.567-.141.652-.425l.085-.396c.397.623 1.276.935
 2.608.935 1.417 0 2.239-.029 2.465-.114a.523.523 0 0 0
 .369-.311l.028-.085.17-.539c.029-.085-.028-.142-.142-.142l-.906.057c-.596.029-1.077.057-1.418.057-.651
 0-1.076-.057-1.332-.142-.368-.142-.538-.397-.51-.822l2.863-.368c1.275-.17
 2.154-.567 2.579-1.19l-.992 3.315c-.028.057 0
 .114.028.142.029.028.085.057.199.057h1.19c.198 0
 .283-.114.312-.199l1.048-3.656c.142-.481.567-.708 1.36-.708.71 0 1.22
 0 1.56.028h.028c.057 0 .17-.028.255-.17l.17-.51c0-.085
 0-.17-.057-.227zM4.841 13.73c-.368.057-.907.085-1.587.085-1.219
 0-1.729-.255-1.587-.737.113-.34.425-.567.935-.624l2.75-.368zm12.669-2.95c-.114.369-.652.624-1.616.766l-2.295.311.056-.198c.199-.624.454-1.02.794-1.247.34-.227.907-.34
 1.7-.34 1.05.028 1.503.255 1.36.708Z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = ''''''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return ''''''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
