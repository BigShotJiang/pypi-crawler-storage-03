#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Carsten Igel.
#
# This file is part of simplepycons
# (see https://github.com/carstencodes/simplepycons).
#
# This file is published using the MIT license.
# Refer to LICENSE for more information
#
""""""
# pylint: disable=C0302
# Justification: Code is generated

from typing import TYPE_CHECKING

from .base_icon import Icon

if TYPE_CHECKING:
    from collections.abc import Iterable


class ActiveloopIcon(Icon):
    """"""
    @property
    def name(self) -> "str":
        return "activeloop"

    @property
    def original_file_name(self) -> "str":
        return "activeloop.svg"

    @property
    def title(self) -> "str":
        return "Activeloop"

    @property
    def primary_color(self) -> "str":
        return "#FFB746"

    @property
    def raw_svg(self) -> "str":
        return ''' <svg xmlns="http://www.w3.org/2000/svg"
 role="img" viewBox="0 0 24 24">
    <title>Activeloop</title>
     <path d="M13.7361.0003a8.5022 8.5022 0 0
 0-2.7609.4702c-.3783.1325-1.2203.4447-1.5419.6056.0128 0-.008 0
 .0401-.0006.0935-.0238.8998-.151
 1.1045-.151.0834-.002.166-.004.2481-.004 1.2312-.004 2.3252.2387
 3.469 1.0638 1.6364 1.1735 2.7617 3.1987 3.1116 5.1009.2968
 1.8754.058 3.8578-.539 5.7067-.8609 2.328-2.459 4.1353-4.3602
 5.1857a.6094.6094 0 0 1-.038.0188c1.6566-.1906 3.3363-.8961
 4.7763-2.0437.804-.6435 1.542-1.429 2.1756-2.347.5676-.8328
 1.0025-1.7034
 1.3145-2.593.792-2.2732.7474-4.64-.0864-6.5953-.003-.007-.004-.0114-.008-.02-.5296-1.2397-1.3621-2.309-2.5066-3.0945C16.8462.4216
 15.2953-.005 13.736 0zM9.46 1.0828c-1.6656.1448-3.1906.971-3.914
 1.4507-1.3998.9275-2.5442 2.1104-3.3955 3.4447-2.4213 3.7855-2.5442
 8.7916.0946 12.7757 3.5659 5.3848 10.8204 6.8706 16.2116 3.3029
 5.3818-3.5677 6.867-10.8262 3.3011-16.211a11.3559 11.3559 0 0
 0-1.1047-1.4241l.1494.3073c.8323 1.959.8229 4.5048.0378
 6.776-.3122.8897-.7473 1.7603-1.3148 2.593-.6338.918-1.3998
 1.6563-2.2322 2.2714-2.743 2.0157-5.467 1.6655-5.4576
 1.675-.8876-.0283-1.6979-.2138-2.4495-.4167-2.7807-.8422-4.5871-2.9052-4.502-5.5455.104-3.2555
 3.282-5.801 7.1033-5.678.7093.0189 1.3809.1419 2.024.3217 1.2296.3501
 2.5916 1.2017 3.424
 2.2048l.0469.0548c-.0003-.4859-.017-1.0982-.1797-1.8623-.4068-1.8928-1.4659-3.596-3.1306-4.7411-1.239-.8517-2.6578-1.2492-4.086-1.3154-.209-.008-.4173-.0008-.626.016zm2.389
 5.4591c-3.561.0366-6.4667 2.4597-6.5675 5.531-.0795 2.4028 1.5808
 4.5078 4.0022 5.447a4.8728 4.8728 0 0
 1-.1594-.2c-1.7566-2.3467-1.2053-6.0692 1.3878-8.6636 1.21-1.2118
 2.4454-1.7402 3.0135-1.9512 0
 0-.6286-.1413-1.3301-.159-.1326-.006-.3466-.004-.3466-.004z" />
</svg>'''

    @property
    def guidelines_url(self) -> "str | None":
        _value: "str" = '''https://www.figma.com/design/BkHRpmCiMOqY1iJM'''
        if len(_value) > 0:
            return _value
        return None

    @property
    def source(self) -> "str":
        return '''https://github.com/simple-icons/simple-icons/'''

    @property
    def license(self) -> "tuple[str | None, str | None]":
        _type: "str | None" = ''''''
        _url: "str | None" = ''''''

        if _type is not None and len(_type) == 0:
            _type = None

        if _url is not None and len(_url) == 0:
            _url = None

        return _type, _url

    @property
    def aliases(self) -> "Iterable[str]":
        yield from []
