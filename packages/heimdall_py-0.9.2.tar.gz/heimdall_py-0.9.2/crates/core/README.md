# heimdall-core

This crate is the core of the Heimdall library. It contains all module implementations, such as decompilation, disassembly, decoding, etc.
