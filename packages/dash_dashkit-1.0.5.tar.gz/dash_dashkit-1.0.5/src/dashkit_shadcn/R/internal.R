.dashkitShadcn_js_metadata <- function() {
deps_metadata <- list(`dashkit_shadcn` = structure(list(name = "dashkit_shadcn",
version = "1.0.0", src = list(href = NULL,
file = "deps"), meta = NULL,
script = 'dashkit_shadcn.js',
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashkitShadcn",
all_files = FALSE, async = FALSE), class = "html_dependency"),
`dashkit_shadcn` = structure(list(name = "dashkit_shadcn",
version = "1.0.0", src = list(href = NULL,
file = "deps"), meta = NULL,
script = 'proptypes.js',
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashkitShadcn",
all_files = FALSE, async = FALSE), class = "html_dependency"))
return(deps_metadata)
}
