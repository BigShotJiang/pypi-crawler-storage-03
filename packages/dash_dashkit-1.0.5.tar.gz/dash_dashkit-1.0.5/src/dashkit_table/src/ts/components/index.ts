/**
 * Barrel exports for Dashkit Table components.
 * Exports the DashkitTable React component for Dash integration.
 */
export { default as DashkitTable } from "./DashkitTable";
