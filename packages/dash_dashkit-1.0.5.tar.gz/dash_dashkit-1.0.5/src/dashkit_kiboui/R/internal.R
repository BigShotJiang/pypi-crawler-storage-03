.dashkitKiboui_js_metadata <- function() {
deps_metadata <- list(`dashkit_kiboui` = structure(list(name = "dashkit_kiboui",
version = "1.0.0", src = list(href = NULL,
file = "deps"), meta = NULL,
script = 'dashkit_kiboui.js',
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashkitKiboui",
all_files = FALSE), class = "html_dependency"))
return(deps_metadata)
}
