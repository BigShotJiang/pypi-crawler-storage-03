# Container configuration for P24
CONTAINER_CONFIG = {"icon": "home", "order": 1}
