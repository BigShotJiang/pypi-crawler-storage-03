# Container configuration for Duplex
CONTAINER_CONFIG = {"icon": "building", "order": 1}
