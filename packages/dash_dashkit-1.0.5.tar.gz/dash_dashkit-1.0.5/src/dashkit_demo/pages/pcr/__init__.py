# Container configuration for PCR
CONTAINER_CONFIG = {"icon": "activity", "order": 1}
