"""Demo application showcasing Dashkit Components."""
