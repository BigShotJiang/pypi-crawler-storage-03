# Hakware-py

HakObserver Linux is a Python package that allows endpoints to connect to the Hakware solution

## Installation

To install HakObserverLinuxpy, ensure you have Python installed (version 3.6 or higher), then use pip to install the package:

```bash
pip install HakObserverLinuxpy
