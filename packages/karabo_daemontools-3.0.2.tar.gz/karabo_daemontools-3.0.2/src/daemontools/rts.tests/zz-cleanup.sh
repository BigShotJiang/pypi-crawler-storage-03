cd ..
rm -rf rts-tmp
