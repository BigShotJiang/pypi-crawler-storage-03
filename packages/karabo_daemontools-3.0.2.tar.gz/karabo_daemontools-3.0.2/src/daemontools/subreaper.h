/* Public domain. */

#ifndef SUBREAPER_H
#define SUBREAPER_H

extern int set_subreaper(void);

#endif
