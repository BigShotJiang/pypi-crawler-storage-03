Attributions
============

Copyright 2015, David Åse
https://github.com/tipsy/isometric-tiles
* iso.tmx
* 256_base.png
* 256_decor.png
