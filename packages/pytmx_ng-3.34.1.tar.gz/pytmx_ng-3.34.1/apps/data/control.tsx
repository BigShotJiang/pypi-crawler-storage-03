<?xml version="1.0" encoding="UTF-8"?>
<tileset name="control" tilewidth="70" tileheight="70">
 <image source="control.png" trans="ff00ff" width="210" height="70"/>
 <tile id="0">
  <properties>
   <property name="block" value="1"/>
   <property name="slope" value="backward"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="block" value="1"/>
   <property name="slope" value="level"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="block" value="1"/>
   <property name="slope" value="forward"/>
  </properties>
 </tile>
</tileset>
