"""Groq CLI Agent - Interactive command-line interface for Groq API."""

__version__ = "0.1.3"
__author__ = "tmnabeel30"
__description__ = "Advanced AI coding assistant with enhanced capabilities, semantic search, and intelligent code operations"
