"""Tests for Groq CLI Agent."""


