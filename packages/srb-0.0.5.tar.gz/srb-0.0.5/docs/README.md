# Documentation

<a href="https://AndrejOrsula.github.io/space_robotics_bench"><img alt="Documentation" src="https://github.com/user-attachments/assets/e4f6c735-9831-43c3-9d7e-fb6a5245e762" width="96" height="96"></a>

## Local Preview

We use [mdBook](https://rust-lang.github.io/mdBook) to generate a static site from Markdown files found in the [src](src) directory. To build and preview the site locally, you can [install mdBook](https://rust-lang.github.io/mdBookguide/installation.html) and run the following command:

```bash
mdbook serve --open
```
