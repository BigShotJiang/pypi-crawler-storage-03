<div class="warning">

### This page is under construction. Images will be added soon.

</div>

# Mobile Manipulators

The Space Robotics Bench provides mobile manipulator robots that combine locomotion with manipulation capabilities.

## Combined Systems

#### Aerial Manipulator (Combination)

#### Ground Manipulator (Combination)

#### Orbital Manipulator (Combination)

## Humanoids

#### Humanoid 21 DOF (`humanoid21`)

#### Humanoid 28 DOF (`humanoid28`)

#### Unitree H1 (`unitree_h1`)

#### Unitree G1 (`unitree_g1`)
