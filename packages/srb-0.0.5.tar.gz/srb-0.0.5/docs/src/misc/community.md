# Community [![Discord](https://img.shields.io/badge/Discord-Space%20Robotics%20Bench-5865F2?logo=discord)](https://discord.gg/p9gZAPWa65)

We encourage you to join our Discord community to discuss the Space Robotics Bench, share your projects, ask questions, and collaborate with other researchers and developers. We are excited to see what you create with SRB!

Invite Link: <https://discord.gg/p9gZAPWa65>

## Guidelines

Please adhere to the following guidelines when participating in the community:

- Be respectful and considerate to all members
- Keep your discussions relevant

We look forward to interacting with you in the community!
