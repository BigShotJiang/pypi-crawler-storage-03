# Citation

If you use this project in your research, please cite the following publication:

```bibtex
@inproceedings{orsula2024towards,
    title     = {{Towards Benchmarking Robotic Manipulation in Space}},
    author    = {Orsula, Andrej and Richard, Antoine and Geist, Matthieu and Olivares-Mendez, Miguel and Martinez, Carol},
    booktitle = {Conference on Robot Learning (CoRL) Workshop on Mastering Robot Manipulation in a World of Abundant Data},
    year      = {2024},
}
```
