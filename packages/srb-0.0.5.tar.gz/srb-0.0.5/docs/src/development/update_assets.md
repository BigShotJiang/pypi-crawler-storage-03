# Development Utilities — Update Assets

You can update static assets distributed via Git submodules such as [srb_assets](https://github.com/AndrejOrsula/srb_assets) by running the included [script](https://github.com/AndrejOrsula/space_robotics_bench/blob/main/assets/update.bash):

```bash
./space_robotics_bench/assets/update.bash
```
