//! Python extension module for the Space Robotics Bench
