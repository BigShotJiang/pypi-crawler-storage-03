//! FFI for the Space Robotics Bench
