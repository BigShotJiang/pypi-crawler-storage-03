//! Space Robotics Bench
