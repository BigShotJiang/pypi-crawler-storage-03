This demo uses 3D Systems Touch, a haptic device that controls the robot and provides you with a sense of touch through force feedback. **Grab the pen and try it yourself!**
