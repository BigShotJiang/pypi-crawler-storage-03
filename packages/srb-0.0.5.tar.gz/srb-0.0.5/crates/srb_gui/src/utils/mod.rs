#![allow(unused)]

pub use enums::Difficulty;

pub mod egui;
mod enums;
