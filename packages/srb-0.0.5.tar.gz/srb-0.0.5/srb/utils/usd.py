from isaaclab.sim.utils import safe_set_attribute_on_usd_prim  # noqa: F401
