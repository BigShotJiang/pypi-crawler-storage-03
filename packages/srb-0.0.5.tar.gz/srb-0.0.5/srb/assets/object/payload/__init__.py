from .cargo_bay import CargoBay  # noqa: F401
