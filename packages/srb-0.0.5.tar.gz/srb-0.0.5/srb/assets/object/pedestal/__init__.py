from .industrial import (  # noqa: F401
    IndustrialPedestal25,
    IndustrialPedestal50,
    IndustrialPedestal100,
)
