from .extras.cfg import ArrowCfg, PinnedArrowCfg, PinnedSphereCfg  # noqa: F401
from .multi_shape.cfg import MultiShapeSpawnerCfg  # noqa: F401
