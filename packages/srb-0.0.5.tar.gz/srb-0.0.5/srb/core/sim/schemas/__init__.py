from simforge.integrations.isaaclab.schemas import (  # noqa: F401
    MeshCollisionPropertiesCfg,
)
