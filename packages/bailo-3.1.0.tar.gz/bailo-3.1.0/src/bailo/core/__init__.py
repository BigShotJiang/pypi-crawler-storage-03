"""Endpoints and underlying utilities for Bailo's Python Client.

.. note:: Primary usage for the Python client should be through the helper package
"""
