from openai.types.model import Model as OpenAIModel

Model = OpenAIModel
