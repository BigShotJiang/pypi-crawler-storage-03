from enum import Enum


class ResourceType(str, Enum):
    INFERENCE_SERVICE = "InferenceService"
