from .base import MLServerProperties


class XGBoostProperties(MLServerProperties): ...
