from .base import MLServerProperties


class SKLearnProperties(MLServerProperties): ...
