drop table if exists a
