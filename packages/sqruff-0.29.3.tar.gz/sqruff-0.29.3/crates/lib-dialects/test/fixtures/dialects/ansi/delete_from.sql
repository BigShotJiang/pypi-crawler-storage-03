DELETE FROM table_name
WHERE a > 0;
