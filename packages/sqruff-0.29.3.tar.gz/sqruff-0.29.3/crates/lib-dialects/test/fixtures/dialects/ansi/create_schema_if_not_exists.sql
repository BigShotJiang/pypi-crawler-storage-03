create schema if not exists my_schema
