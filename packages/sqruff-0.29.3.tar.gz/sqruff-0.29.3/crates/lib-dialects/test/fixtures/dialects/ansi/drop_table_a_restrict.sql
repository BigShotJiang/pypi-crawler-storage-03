drop table a restrict
