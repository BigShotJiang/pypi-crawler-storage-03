select a,b, c from sch."blah"
