-- Snowflake Double-Dot Notation
-- https://docs.snowflake.com/en/sql-reference/name-resolution.html#resolution-when-schema-omitted-double-dot-notation
SELECT *
FROM my_database..my_table
