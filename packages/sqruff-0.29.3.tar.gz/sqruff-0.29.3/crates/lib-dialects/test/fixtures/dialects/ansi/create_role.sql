CREATE ROLE foo_role
