-- A valid identifier is alphanumeric and contains at least one letter.
select "a" as 0_is_a_legal_identifier;
select "a" as 00_is_a_legal_identifier;
select 123_is_a_legal_identifier.456_is_a_legal_identifier;
select "a" as 0is_a_legal_identifier;
select _s00.45_is_a_legal_identifier from sdf9_._234awdf;
select "a" as is_a_legal_identifier0;
