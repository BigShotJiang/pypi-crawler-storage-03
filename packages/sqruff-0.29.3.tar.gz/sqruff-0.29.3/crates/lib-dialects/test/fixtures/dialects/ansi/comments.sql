-- This is a comment

/* So is this */

/* This is a
    multiple line comment */
