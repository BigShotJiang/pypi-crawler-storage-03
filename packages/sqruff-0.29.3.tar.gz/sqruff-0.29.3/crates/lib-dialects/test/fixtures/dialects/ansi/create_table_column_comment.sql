CREATE TABLE a (
    id VARCHAR(100) COMMENT 'Column comment'
)
