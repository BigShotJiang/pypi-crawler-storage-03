drop schema my_schema;
drop schema my_schema cascade;
drop schema my_schema restrict;
drop schema if exists my_schema;
drop schema if exists my_schema cascade;
drop schema if exists my_schema restrict;
