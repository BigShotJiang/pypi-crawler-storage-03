create table table1 (c1 SMALLINT, c2 DATE)
