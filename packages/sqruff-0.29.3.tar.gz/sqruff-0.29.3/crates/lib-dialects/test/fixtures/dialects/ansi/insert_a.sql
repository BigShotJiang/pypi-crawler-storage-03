INSERT into tbl_b (col1) values (123);

INSERT INTO tbl_c (
    SELECT *
    FROM table1
);
