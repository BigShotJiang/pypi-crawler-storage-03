revoke select on table a from group b
