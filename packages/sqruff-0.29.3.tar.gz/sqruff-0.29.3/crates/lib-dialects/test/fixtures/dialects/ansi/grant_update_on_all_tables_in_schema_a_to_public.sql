grant update on all tables in schema a to public
