SELECT
    a.id,
    /* Block comment with ending */ a.something,
    a.name,
    /*
    Block comment on newlines
    */
/* Some block comments
go over multiple
lines */
FROM tbl as a
