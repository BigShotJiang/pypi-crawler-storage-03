SELECT
    a.id,  -- This is an inline comment
    -- Sometimes they're on a new line
    a.name
FROM tbl as a
