SELECT
    a.id,
    a.name
FROM tbl as a
