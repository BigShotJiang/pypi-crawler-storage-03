SELECT
   a.id, -- 3 Spaces
	  a.name, -- tabs and spaces, 2 spaces
	    a.trailing_spaces,   
	a.tabs_alone_after_spaces
FROM tbl as a