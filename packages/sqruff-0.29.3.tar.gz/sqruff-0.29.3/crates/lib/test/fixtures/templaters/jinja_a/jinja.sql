SELECT 56 FROM {{ testing_schema }}.{{ testing_table }}
