# Need to add this dir to PYTHONPATH, or else the imports in generated code won't work
import os
import sys

sys.path.append(os.path.abspath(os.path.dirname(__file__)))
