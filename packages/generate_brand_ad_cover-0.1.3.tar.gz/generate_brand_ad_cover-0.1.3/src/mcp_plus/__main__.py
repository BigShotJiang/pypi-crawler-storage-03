#!/usr/bin/env python3
"""
MCP Plus - 品牌广告封面生成工具
作者: chloexiaoer <934679045@qq.com>
"""

from . import main

if __name__ == "__main__":
    main()
