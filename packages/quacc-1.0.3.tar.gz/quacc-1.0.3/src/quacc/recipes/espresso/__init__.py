"""Recipes for Quantum Espresso."""
