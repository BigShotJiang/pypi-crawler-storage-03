from gui_frontend.clipitGui import startClipit
startClipit()
