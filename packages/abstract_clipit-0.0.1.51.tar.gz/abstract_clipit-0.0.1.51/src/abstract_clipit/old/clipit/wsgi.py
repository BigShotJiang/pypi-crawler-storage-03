from flask import abstract_clip_app
app = abstract_clip_app()

