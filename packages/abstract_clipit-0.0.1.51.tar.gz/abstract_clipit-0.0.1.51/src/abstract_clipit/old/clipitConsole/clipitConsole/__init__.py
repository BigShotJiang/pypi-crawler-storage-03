from .main import clipitConsole
