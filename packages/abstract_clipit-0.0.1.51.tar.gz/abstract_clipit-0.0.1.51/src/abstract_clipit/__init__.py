from .clipit import clipitTab,startClipitConsole
