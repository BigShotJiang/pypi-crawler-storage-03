from typing import Any, Dict, List

TDataPage = List[Dict[str, Any]]
