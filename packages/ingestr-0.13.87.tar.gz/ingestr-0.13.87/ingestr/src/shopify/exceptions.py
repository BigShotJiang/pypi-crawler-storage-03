class ShopifyPartnerApiError(Exception):
    pass
