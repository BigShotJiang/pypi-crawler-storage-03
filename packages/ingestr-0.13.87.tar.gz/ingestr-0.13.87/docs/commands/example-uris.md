# `ingestr example-uris`

This command serves as a guide for the user to understand the various URI formats that `ingestr` supports. The command provides a list of supported sources and destinations, along with the URI format for each of them.

For the detailed documentation, please refer to the Sources & Destinations section on the sidebar.
