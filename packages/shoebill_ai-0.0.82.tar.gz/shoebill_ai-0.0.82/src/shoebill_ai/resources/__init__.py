"""
Resources for the shoebill_ai package.

This package contains resource files such as JSON configurations and templates.
"""