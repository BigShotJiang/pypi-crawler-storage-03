-- simple
drop subscription s;

-- full
drop subscription if exists a cascade;
drop subscription if exists a restrict;

