class ConfigurationError(Exception):
    pass
