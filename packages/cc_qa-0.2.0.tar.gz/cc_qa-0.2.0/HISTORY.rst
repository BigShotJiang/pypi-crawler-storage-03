0.2.0 (2025-08-20)
------------------

New Features
^^^^^^^^^^^^

* Now supporting ESGF-QC and EERIE checkers.
* Added `-C` command line argument to additionally run consistency and time checks when not running the 'mip' or 'cc6' checkers.

Bug Fixes
^^^^^^^^^
* Fixed check for consistent time-span of datasets failing when filename timestamp is not a time range.

0.1.2 (2025-06-16)
------------------

New Features
^^^^^^^^^^^^
* Now printing the respective references for consistency checks (commits d7ebfbd17e1926aa7e3e61acd55b5319cd9ce184 & 4ec6ed82fbecf44aca1680f27b48a1351ec481fd).

Bug Fixes
^^^^^^^^^
* Fixed inter-dataset checks not being reset for each dataset (commits d7ebfbd17e1926aa7e3e61acd55b5319cd9ce184 & 4ec6ed82fbecf44aca1680f27b48a1351ec481fd).
* CLI overhaul (commit 7362826ca8c60efc0a4e0f4a81723ec1f49c006e).

0.1.1 (2025-06-13)
------------------

Bug Fixes
^^^^^^^^^
* Fixed cluster example message ending up scrambled at times (commit babb141203a00325a077da158cfd4e16e13b2af1).

0.1.0 (2025-06-12)
-------------------

* First release.
