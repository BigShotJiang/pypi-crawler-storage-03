from chapter_by_chapter.processors.gutenberg.gutenberg_text import GutenbergTextProcessor

__all__ = ['GutenbergTextProcessor']
