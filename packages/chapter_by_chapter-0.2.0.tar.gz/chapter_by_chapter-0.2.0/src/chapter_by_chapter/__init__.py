from chapter_by_chapter.bot import ChapterByChapterBot

plugin_filters: list[str] = []
plugin_bots: list[str] = ['chapter_by_chapter.ChapterByChapterBot']

__all__ = ['ChapterByChapterBot']
