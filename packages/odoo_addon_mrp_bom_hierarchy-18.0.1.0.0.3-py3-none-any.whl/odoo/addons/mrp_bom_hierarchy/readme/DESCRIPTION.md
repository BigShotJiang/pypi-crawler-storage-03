This module extends the functionality of Bill of Materials to support
users to better maintain the BoM hierarchy.

The user can navigate from the tree view to child's BoM or parent's BoM,
or to the product's BoM components with a single click.
