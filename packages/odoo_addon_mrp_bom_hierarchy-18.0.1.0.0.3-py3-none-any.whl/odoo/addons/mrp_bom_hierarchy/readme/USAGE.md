To use this module, you need to go to 'Manufacturing \| Products \| Bill
of Materials'.
