No description provided.
# Parameters
n/a
# Visuals
n/a
# Data Recording
Data is written to **Empty Files**, which contains:
- **metadata.json**

    Metadata for this sequence step.