from ..base_widget import CategoryWidget


class TemperatureCategoryWidget(CategoryWidget):
    def __init__(self):
        CategoryWidget.__init__(self, "Temperature")
