APP_NAME = "Fabrial"
PACKAGE_NAME = "fabrial"
