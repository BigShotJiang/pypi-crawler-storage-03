"""Headers for temperature files."""

TEMPERATURE = "Oven Temperature (degrees C)"
