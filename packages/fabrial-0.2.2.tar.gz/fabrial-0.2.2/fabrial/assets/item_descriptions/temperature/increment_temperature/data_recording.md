- **{{ TEMPERATURE_FILE }}**

    Oven temperatures and their timestamps.

- **{{ GRAPH_FILE }}**

    A graph of the temperatures saved before the process ends.
