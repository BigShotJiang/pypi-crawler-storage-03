- **[POTENTIOSTAT IDENTIFIER].DTA**
    Contains tab-separated measurements in the same format Gamry Framework uses. This file is compatible with Gamry Echem Analyst. Currently, most of the experiment's metadata is not recorded.

- **[POTENTIOSTAT IDENTIFIER].png**
    The potentiostat's magnitude Bode plot recorded at the end of the experiment.
