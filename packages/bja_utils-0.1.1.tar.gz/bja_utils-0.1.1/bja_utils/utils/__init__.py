from .utils import (
    calculate_significance_label,
    significance_size,
    add_suffix_to_dupes
)