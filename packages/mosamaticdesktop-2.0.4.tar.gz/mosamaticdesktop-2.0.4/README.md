# MosamaticDesktop
PySide6 desktop app for running processing tasks on CT images


## Installation
On Windows: 
- pip install mosamaticdesktop

On MacOS: 
- pip install mosamaticdesktop-macos