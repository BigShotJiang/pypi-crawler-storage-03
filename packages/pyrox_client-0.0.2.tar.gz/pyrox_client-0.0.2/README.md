Package to retrieve Hyrox race data programatically.

