import{b as n}from"./_baseUniq-CGK6su7v.js";function o(r){return n(r,4)}export{o as c};
