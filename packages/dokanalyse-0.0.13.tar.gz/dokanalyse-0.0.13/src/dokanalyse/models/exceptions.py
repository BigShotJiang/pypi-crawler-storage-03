class DokAnalysisException(Exception):
    pass
