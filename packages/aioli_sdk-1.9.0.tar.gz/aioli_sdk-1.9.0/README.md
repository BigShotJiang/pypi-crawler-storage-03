HPE Machine Learning Inferencing Software Command Line Interface

This package provides the `aioli` command and the `aiolirest` Python library which enables access to HPE MLIS capabilities that are part of [HPE Private Cloud AI](https://www.hpe.com/us/en/private-cloud-ai.html).

Aioli (**AI** **O**n**L**ine **I**nference) is a platform for deploying models at scale.

