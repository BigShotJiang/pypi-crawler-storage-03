# © Copyright 2023-2024 Hewlett Packard Enterprise Development LP
from aioli.__version__ import __version__
