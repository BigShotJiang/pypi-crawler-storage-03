"""DSMS Semantics Module"""
