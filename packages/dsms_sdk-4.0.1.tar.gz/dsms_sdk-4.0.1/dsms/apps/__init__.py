"""DSMS apps"""

from .config import AppConfig

__all__ = ["AppConfig"]
