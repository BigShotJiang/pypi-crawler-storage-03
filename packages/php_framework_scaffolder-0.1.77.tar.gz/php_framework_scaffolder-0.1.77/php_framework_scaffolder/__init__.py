from __future__ import annotations

from php_framework_scaffolder.frameworks import BaseFrameworkSetup
from php_framework_scaffolder.frameworks import get_framework_handler

__all__ = [
    'BaseFrameworkSetup',
    'get_framework_handler',
]
