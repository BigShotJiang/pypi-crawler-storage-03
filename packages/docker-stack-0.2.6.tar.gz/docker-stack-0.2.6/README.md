Docker Stack
==============
cli utility for stack deployment in docker-swarm.
#### Features
- docker config and secret creation and versioning
- docker stack versioning and config backup for rollback