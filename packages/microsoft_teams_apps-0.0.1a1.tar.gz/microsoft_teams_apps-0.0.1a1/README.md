> [!CAUTION]
> This project is in active development and not ready for production use. It has not been publicly announced yet.

# Microsoft Teams App Framework

High-level framework for building Microsoft Teams bots and applications.
Handles routing, middleware, events, and provides OAuth integration for Teams apps.