"""Core application logic and API clients."""
