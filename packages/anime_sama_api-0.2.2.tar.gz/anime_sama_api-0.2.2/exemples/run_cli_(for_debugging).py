from anime_sama_api import main


if __name__ == "__main__":
    main()
