from anime_sama_api.catalogue import Catalogue


one_piece = Catalogue("https://anime-sama.fr/catalogue/one-piece/")
mha = Catalogue("https://anime-sama.fr/catalogue/my-hero-academia/")
gumball = Catalogue("https://anime-sama.fr/catalogue/le-monde-incroyable-de-gumball/")
