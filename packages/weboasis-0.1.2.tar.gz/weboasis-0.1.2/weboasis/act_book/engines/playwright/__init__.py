"""
Playwright automation engine.
"""

from weboasis.act_book.engines.playwright.playwright_automator import PlaywrightAutomator

__all__ = ['PlaywrightAutomator']
