.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   CHANGELOG
   reference/pyprocessors_opennre
