"""Processor based on Huggingface transformers zero-shot classification pipeline"""
__version__ = "0.5.161"
