# Package initialization
__version__ = "1.1.2"
