from .telemetry import telemetry_allow_list
from .util import normalizeBoolean
