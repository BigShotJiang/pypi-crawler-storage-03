"""
dom.tree unsafe functions
"""
from . import ElementTree  # noqa: F401
