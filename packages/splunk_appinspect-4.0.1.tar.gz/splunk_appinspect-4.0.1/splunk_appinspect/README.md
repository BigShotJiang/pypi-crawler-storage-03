AppInspect is a tool for assessing a Splunk App's 
 compliance with Splunk recommended development practices,
 by using static analysis. AppInspect is open for
 extension, allowing other teams to compose checks that
 meet their domain specific needs for semi- or
 fully-automated analysis and validation of Splunk Apps.