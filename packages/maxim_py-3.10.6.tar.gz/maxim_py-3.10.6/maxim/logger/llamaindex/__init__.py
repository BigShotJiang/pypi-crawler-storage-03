from .client import instrument_llamaindex

__all__ = ["instrument_llamaindex"]