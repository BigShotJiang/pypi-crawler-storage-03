from .base.delete_unverified_users import BaseDeleteUnverifiedUsersCommand


class Command(BaseDeleteUnverifiedUsersCommand):
    pass
