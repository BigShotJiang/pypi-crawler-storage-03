from .base.delete_old_radacct import BaseDeleteOldRadacctCommand


class Command(BaseDeleteOldRadacctCommand):
    pass
