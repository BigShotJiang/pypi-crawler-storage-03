from .base.deactivate_expired_users import BaseDeactivateExpiredUsersCommand


class Command(BaseDeactivateExpiredUsersCommand):
    pass
