"""Centralized version information for nim-mmcif."""

__version__ = "0.0.12"