"""
CLI integration tests
"""
