Changelog
=========

0.0.4 (2025-08-25)
------------------

- `add_logging_level` method no longer requires short and long option flag to be specified together,
  one of them can be omitted (ie None)


0.0.3 (2025-01-14)
------------------

- using underscore in project name now


0.0.2 (2025-01-14)
------------------

- `init_logging` now supports specifying `stream` or `filename` or `handlers` as well as the `log_format`


0.0.1 (2023-11-30)
------------------

- initial release

