"""
Gleitzeit V4 Command Line Interface

Event-native CLI for distributed task execution with dual-mode operation
(local development vs distributed production).
"""

__version__ = "4.0.0"