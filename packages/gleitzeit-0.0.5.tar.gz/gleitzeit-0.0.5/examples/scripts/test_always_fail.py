
raise Exception("This task always fails")
