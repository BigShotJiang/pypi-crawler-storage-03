result = 2 + 2
print(f"Result: {result}")