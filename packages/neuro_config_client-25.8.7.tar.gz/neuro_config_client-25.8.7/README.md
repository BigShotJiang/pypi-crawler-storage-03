# neuro-config-client
Configuration Client for Neu.ro platform
