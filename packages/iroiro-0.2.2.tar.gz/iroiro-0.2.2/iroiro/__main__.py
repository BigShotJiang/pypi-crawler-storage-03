from . import bin

bin.iroiro.main()
