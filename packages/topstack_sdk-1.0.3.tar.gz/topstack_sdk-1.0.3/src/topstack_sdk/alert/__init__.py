"""
TopStack 告警模块
"""

from .alert import AlertApi

__all__ = ["AlertApi"] 