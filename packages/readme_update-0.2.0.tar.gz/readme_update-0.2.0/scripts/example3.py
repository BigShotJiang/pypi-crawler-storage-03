"""Some extra ignored lines.

Link: https://doc.rust-lang.org/book/"""

x = 1 + 1