"""Description: This is an example file that links to my own github.

Link: https://github.com/second-ed
"""

import this