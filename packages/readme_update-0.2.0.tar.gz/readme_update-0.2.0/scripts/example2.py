"""Description: Some other description.

This one has no link
"""

print("Lets rewrite it in rust")