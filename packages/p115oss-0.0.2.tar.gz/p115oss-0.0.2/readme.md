# 115 oss 上传

## 安装

你可以通过 [pypi](https://pypi.org/project/p115oss/) 安装

```console
pip install -U p115oss
```

## 用法

```python
import p115oss
```
