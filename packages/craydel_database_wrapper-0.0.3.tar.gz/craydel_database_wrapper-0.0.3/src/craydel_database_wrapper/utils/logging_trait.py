class CanLog:
    def log_message(self, msg: str) -> None:
        print(msg)
