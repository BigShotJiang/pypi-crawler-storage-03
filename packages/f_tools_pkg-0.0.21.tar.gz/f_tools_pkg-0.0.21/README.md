2022-7-20 V0.0.4  add bmp_scale function

2024-3-27 V0.06  e bu add "type" parameter

2024-4-10 v0.007 des3 key mast 24 Bytes, and 23:16 must not '0'

2024-4-15 v0.008 command with timeout

2024-4-15 v0.009 fix bug

2024-4-15 v0.010 add "e_fu" command

2024-4-18 v0.011 fix "e bu "

2024-6-26 v0.012 add ecc & serial

2024-7-05 v0.013 add ecc (GF(2^m))

2024-7-05 v0.015 add stil analyse

2024-7-05 v0.016 add (GF(2^m))  montgomery pmul

2025-1-02 v0.017 "f_bmp" fix add_point

2025-1-02 v0.018 rm test case

2025-3-12 v0.019 fix stil.get_pattern

2025-3-12 v0.020 fix serial bug

2025-3-12 v0.021 fix e bug
