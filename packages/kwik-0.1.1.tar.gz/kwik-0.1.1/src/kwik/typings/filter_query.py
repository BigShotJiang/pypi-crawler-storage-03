from __future__ import annotations

FilterQuery = dict[str, str]
