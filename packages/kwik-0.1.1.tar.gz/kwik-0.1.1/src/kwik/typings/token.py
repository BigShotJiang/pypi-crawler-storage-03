from __future__ import annotations

from typing import TypedDict


class Token(TypedDict):
    access_token: str
    token_type: str
