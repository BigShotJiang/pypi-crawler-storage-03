Common Documentation of the Project
===================================


Some text...
