Software Detailed Design
========================

.. contents:: Table of Contents
    :depth: 2

Introduction
------------

This is the documentation for the ``Main`` component.

The application will say
{% if config.LANG_DE %}
``Hallo Welt``
{% else %}
``Hello World``
{% endif %}
.
