# Register Terminate ABCI Agent

This agent uses the registration and termination skills to test the termination feature.