# Offend Slash Agent

This agent uses the registration, the offend, the slash, and the reset and pause skills to test the slashing feature.
