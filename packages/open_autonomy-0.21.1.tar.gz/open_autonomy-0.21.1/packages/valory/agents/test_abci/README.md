# Test ABCI Agent

This agent is used to test the `abci` connection.