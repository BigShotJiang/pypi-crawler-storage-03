<a id="packages.valory.skills.abstract_round_abci.io_.paths"></a>

# packages.valory.skills.abstract`_`round`_`abci.io`_`.paths

This module contains all the path related operations of the behaviours.

<a id="packages.valory.skills.abstract_round_abci.io_.paths.create_pathdirs"></a>

#### create`_`pathdirs

```python
def create_pathdirs(path: str) -> None
```

Create the non-existing directories of a given path.

**Arguments**:

- `path`: the given path.

