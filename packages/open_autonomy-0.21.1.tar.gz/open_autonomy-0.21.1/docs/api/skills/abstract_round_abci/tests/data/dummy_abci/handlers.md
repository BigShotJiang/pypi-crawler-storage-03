<a id="packages.valory.skills.abstract_round_abci.tests.data.dummy_abci.handlers"></a>

# packages.valory.skills.abstract`_`round`_`abci.tests.data.dummy`_`abci.handlers

This module contains the handlers for the skill of DummyAbciApp.

