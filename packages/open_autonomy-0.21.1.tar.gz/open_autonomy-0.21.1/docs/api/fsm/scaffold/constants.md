<a id="autonomy.fsm.scaffold.constants"></a>

# autonomy.fsm.scaffold.constants

Constants.

