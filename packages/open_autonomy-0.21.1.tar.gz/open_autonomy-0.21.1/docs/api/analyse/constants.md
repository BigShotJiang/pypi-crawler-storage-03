<a id="autonomy.analyse.constants"></a>

# autonomy.analyse.constants

Constants for analyse module.

