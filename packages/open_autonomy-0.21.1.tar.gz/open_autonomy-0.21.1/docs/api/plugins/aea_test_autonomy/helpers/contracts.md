<a id="plugins.aea-test-autonomy.aea_test_autonomy.helpers.contracts"></a>

# plugins.aea-test-autonomy.aea`_`test`_`autonomy.helpers.contracts

Helpers for contract tests.

<a id="plugins.aea-test-autonomy.aea_test_autonomy.helpers.contracts.get_register_contract"></a>

#### get`_`register`_`contract

```python
def get_register_contract(directory: Path) -> Contract
```

Get and register the erc1155 contract package.

