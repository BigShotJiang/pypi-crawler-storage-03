<a id="plugins.aea-test-autonomy.aea_test_autonomy.configurations"></a>

# plugins.aea-test-autonomy.aea`_`test`_`autonomy.configurations

Test tools configuration.

<a id="plugins.aea-test-autonomy.aea_test_autonomy.configurations.CUR_PATH"></a>

#### CUR`_`PATH

type: ignore

<a id="plugins.aea-test-autonomy.aea_test_autonomy.configurations.ETHEREUM_ENCRYPTION_PASSWORD"></a>

#### ETHEREUM`_`ENCRYPTION`_`PASSWORD

nosec

<a id="plugins.aea-test-autonomy.aea_test_autonomy.configurations.ANY_ADDRESS"></a>

#### ANY`_`ADDRESS

nosec

