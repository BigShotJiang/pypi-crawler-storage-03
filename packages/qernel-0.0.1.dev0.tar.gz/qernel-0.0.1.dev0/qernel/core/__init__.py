# Core Qernel functionality
