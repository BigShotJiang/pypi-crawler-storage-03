""" Testing package for rath.links


This package contains links that are useful for testing.
Like AssertLink, which asserts that the operation is valid.
Or MockLink, which mocks the response of an operation.

"""
