# Reference

Here you can find the reference for the user facing API of Pylette. This consists of
the `extract_colors` function, which is used to extract a color palette from an image,
and the `Palette` and `Color` classes, which are used to work with the extracted color palette.


::: Pylette.extract_colors

::: Pylette.Palette

::: Pylette.Color

::: Pylette.ImageType_T
