from .base import Storage

# Import your concrete backends here if you like:
# from .postgres_storage import PostgresStorage
# from .json_file_storage import JsonFileStorage