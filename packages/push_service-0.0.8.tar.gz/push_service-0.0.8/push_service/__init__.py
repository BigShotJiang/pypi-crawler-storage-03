__version__ = '0.0.8'
__author__ = 'Andrea Esuli'

from . import *
