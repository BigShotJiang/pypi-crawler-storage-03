"""Presets for the Vasp calculator."""
