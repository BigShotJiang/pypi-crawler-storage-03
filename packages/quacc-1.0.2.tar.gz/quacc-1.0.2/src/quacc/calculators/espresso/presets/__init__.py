"""QE presets."""
