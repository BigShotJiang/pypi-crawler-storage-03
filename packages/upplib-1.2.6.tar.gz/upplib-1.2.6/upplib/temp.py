from upplib import *
from upplib.index import *


def do_temp(temp=''):
    print(temp)
