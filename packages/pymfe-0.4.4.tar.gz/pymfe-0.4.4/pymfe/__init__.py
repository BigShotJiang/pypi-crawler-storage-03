"""EXtracts metafeatures from structured datasets.

Todo:
    More information here.
"""

from ._version import __version__  # noqa: ignore
