from django.apps import AppConfig


class RhEmailTemplateConfig(AppConfig):
    name = "rh_email_tpl"
    verbose_name = "RegioHelden Email Templates"
