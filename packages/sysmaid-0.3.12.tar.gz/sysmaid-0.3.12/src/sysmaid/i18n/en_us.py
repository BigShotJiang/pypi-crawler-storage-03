# src/sysmaid/i18n/en_us.py
translations = {
  "init.admin.error.title": "Permission Error",
  "init.admin.error.message": "SysMaid requires administrator privileges to run properly.",
  "init.admin.skip.message": "CI mode activated: UAC check is bypassed. If you are a regular user, please stop and check your environment variables."
}