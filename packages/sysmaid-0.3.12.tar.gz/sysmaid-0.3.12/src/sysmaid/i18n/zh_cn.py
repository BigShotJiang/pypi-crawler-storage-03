# src/sysmaid/i18n/zh_cn.py
translations = {
  "init.admin.error.title": "权限错误",
  "init.admin.error.message": "SysMaid 需要管理员权限才能正常运行。",
  "init.admin.skip.message": "已进入CI模式：UAC检查已被跳过。如果您是普通用户，请立即停止并检查您的环境变量。"
}