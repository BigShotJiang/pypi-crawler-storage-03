from simpletransformers.config.model_args import RetrievalArgs
from simpletransformers.pretrain_retrieval.pretrain_retrieval_model import (
    PretrainRetrievalModel,
)
