import logging

log = logging.getLogger("Thug")


def Play(self):  # pylint:disable=unused-argument
    log.warning("[WindowsMediaPlayer] Play")
