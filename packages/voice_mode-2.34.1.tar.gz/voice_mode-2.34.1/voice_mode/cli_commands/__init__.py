"""
Voice Mode CLI commands.
"""