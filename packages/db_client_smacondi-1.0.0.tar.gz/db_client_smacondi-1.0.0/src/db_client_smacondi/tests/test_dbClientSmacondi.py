import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from db_client_smacondi.db_client_smacondi import _DbClientSupport, close_all_db_clients, db_client_cache


@pytest.fixture(autouse=True)
def reset_db_client_cache():
    db_client_cache.clear()


@pytest.fixture
def conn_string_map():
    return {
        'MAIN': 'mongodb://main',
        'CLUSTER1': 'mongodb://cluster1',
    }


@pytest.fixture
def api_url():
    return 'http://fake-api-url'


@pytest.mark.asyncio
@patch('db_client_smacondi.db_client_smacondi.DbClient')
@patch('db_client_smacondi.db_client_smacondi.requests.get', new_callable=AsyncMock)
async def test_get_db_client_of_account(mock_requests_get, mock_DbClient, api_url, conn_string_map):
    # Mock API response
    mock_response = {'clusterId': 'CLUSTER1', 'dbName': 'telemetry_db'}
    mock_requests_get.return_value = mock_response
    mock_db_client_instance = MagicMock()
    mock_DbClient.return_value = mock_db_client_instance

    db_support = _DbClientSupport(api_url, conn_string_map)
    result = await db_support.get_db_client_of_account('account123')
    assert result['db_client'] == mock_db_client_instance
    assert result['db_name'] == 'telemetry_db'
    mock_DbClient.assert_called_with('mongodb://cluster1', 30000, 30000)
    mock_requests_get.assert_awaited_once()


@pytest.mark.asyncio
@patch('db_client_smacondi.db_client_smacondi.DbClient')
@patch('db_client_smacondi.db_client_smacondi.requests.get', new_callable=AsyncMock)
async def test_get_db_client_of_account_main_cluster(mock_requests_get, mock_DbClient, api_url, conn_string_map):
    mock_response = {'clusterId': None, 'dbName': 'main_db'}
    mock_requests_get.return_value = mock_response
    mock_db_client_instance = MagicMock()
    mock_DbClient.return_value = mock_db_client_instance

    db_support = _DbClientSupport(api_url, conn_string_map)
    result = await db_support.get_db_client_of_account('account456')
    assert result['db_client'] == mock_db_client_instance
    assert result['db_name'] == 'main_db'
    mock_DbClient.assert_any_call('mongodb://main', 30000, 30000)
    mock_requests_get.assert_awaited_once()


@patch('db_client_smacondi.db_client_smacondi.DbClient')
def test_get_db_client_by_cluster_id(mock_DbClient, api_url, conn_string_map):
    mock_db_client_instance = MagicMock()
    mock_DbClient.return_value = mock_db_client_instance
    db_support = _DbClientSupport(api_url, conn_string_map)
    result = db_support.get_db_client_by_cluster_id('MAIN')
    assert result == mock_db_client_instance
    mock_DbClient.assert_called_once_with('mongodb://main', 30000, 30000)


@patch('db_client_smacondi.db_client_smacondi.DbClient')
def test_close_all_db_clients(mock_DbClient, api_url, conn_string_map):
    mock_db_client_instance = MagicMock()
    mock_DbClient.return_value = mock_db_client_instance
    db_support = _DbClientSupport(api_url, conn_string_map)
    db_support.get_db_client_by_cluster_id('MAIN')
    close_all_db_clients()
    mock_db_client_instance.disconnect.assert_called_once()


def test_init_missing_args():
    with pytest.raises(ValueError):
        _DbClientSupport('', {})
    with pytest.raises(ValueError):
        _DbClientSupport('url', {})
    with pytest.raises(ValueError):
        _DbClientSupport('', {'MAIN': 'mongodb://main'})


def test_get_db_client_of_account_missing_args(api_url, conn_string_map):
    db_support = _DbClientSupport(api_url, conn_string_map)
    with pytest.raises(ValueError):
        import asyncio
        asyncio.run(db_support.get_db_client_of_account(''))


def test_get_db_client_by_cluster_id_missing_args(api_url):
    db_support = _DbClientSupport(api_url, {'CLUSTER1': 'mongodb://cluster1'})
    with pytest.raises(ValueError):
        db_support.get_db_client_by_cluster_id('MAIN')


def test_get_db_client_of_account_no_connstr(api_url, conn_string_map):
    from db_client_smacondi.db_client_smacondi import db_client_cache
    db_support = _DbClientSupport(api_url, conn_string_map)
    # Remove cluster from map
    with patch('db_client_smacondi.db_client_smacondi.requests.get', new_callable=AsyncMock) as mock_requests_get:
        mock_requests_get.return_value = {
            'clusterId': 'CLUSTER2', 'dbName': 'db'}
        import asyncio
        with pytest.raises(ValueError):
            asyncio.run(db_support.get_db_client_of_account('account789'))
