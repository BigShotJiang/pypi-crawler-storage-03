from unittest.mock import patch
import pytest
from unittest.mock import patch, MagicMock
from db_client_smacondi.db_client import DbClient

mock_client = MagicMock()
mock_db = MagicMock()
mock_collection = MagicMock()

mock_client.__getitem__.return_value = mock_db
mock_db.__getitem__.return_value = mock_collection
mock_collection.find.return_value = []
mock_collection.insert_one.return_value = MagicMock(inserted_id="mock_id")
mock_collection.update_one.return_value = MagicMock(modified_count=1)
mock_collection.delete_one.return_value = MagicMock(deleted_count=1)


@pytest.fixture
def dbclient():
    with patch("db_client_smacondi.db_client.MongoClient", return_value=mock_client):
        def connect(self):
            self.client = mock_client
            return mock_client
        with patch.object(DbClient, 'connect', connect):
            client = DbClient("mongodb://testuri", 30000, 30000)
            yield client, mock_client, mock_db, mock_collection


def test_connect_called_if_not_connected(dbclient):
    client, mock_client, _, _ = dbclient
    client.client = None

    def fake_connect():
        client.client = mock_client
    with patch.object(client, 'connect', side_effect=fake_connect) as mock_connect:
        client._get_db("testdb")
        mock_connect.assert_called_once()


def test_connect_not_called_if_connected(dbclient):
    client, mock_client, _, _ = dbclient
    client.client = mock_client
    with patch.object(client, 'connect') as mock_connect:
        client._get_db("testdb")
        mock_connect.assert_not_called()


@pytest.mark.parametrize("value,default,expected", [
    ("", 9, 9),
    ("10", 9, 10),
    ("0", 9, 9),
    (0, 9, 9),
    (-1, 9, 9),
    (10, 9, 10),
])
def test_get_timeout(dbclient, value, default, expected):
    client, *_ = dbclient
    assert client._get_timeout(value, default) == expected


def test_add_or_create_default_write_options(dbclient):
    client, *_ = dbclient
    DEFAULT = client.write_timeout
    assert client._add_or_create_default_write_options() == {'write_concern': {
        'wtimeout': DEFAULT}}
    assert client._add_or_create_default_write_options(
        {}) == {'write_concern': {'wtimeout': DEFAULT}}
    assert client._add_or_create_default_write_options({'write_concern': {}}) == {
        'write_concern': {'wtimeout': DEFAULT}}
    assert client._add_or_create_default_write_options(
        {'any': ''}) == {'any': '', 'write_concern': {'wtimeout': DEFAULT}}
    assert client._add_or_create_default_write_options({'any': '1', 'write_concern': {
                                                       'wtimeout': 0}}) == {'any': '1', 'write_concern': {'wtimeout': DEFAULT}}
    assert client._add_or_create_default_write_options({'any': '1', 'write_concern': {
                                                       'wtimeout': 1}}) == {'any': '1', 'write_concern': {'wtimeout': 1}}


def test_add_or_create_default_read_options(dbclient):
    client, *_ = dbclient
    DEFAULT = client.read_timeout
    assert client._add_or_create_default_read_options() == {
        'maxTimeMS': DEFAULT}
    assert client._add_or_create_default_read_options({}) == {
        'maxTimeMS': DEFAULT}
    assert client._add_or_create_default_read_options({'maxTimeMS': 0}) == {
        'maxTimeMS': DEFAULT}
    assert client._add_or_create_default_read_options(
        {'any': '2', 'maxTimeMS': 1}) == {'any': '2', 'maxTimeMS': 1}

    def test_find_one(dbclient):
        client, _, _, collection = dbclient
        collection.find_one.return_value = {'_id': 'mock_id', 'name': 'test'}
        result = client.find_one('testdb', 'testcol', {'name': 'test'})
        assert result == {'_id': 'mock_id', 'name': 'test'}


def test_insert_one(dbclient):
    client, _, _, collection = dbclient
    collection.insert_one.return_value = MagicMock(inserted_id='mock_id')
    result = client.insert_one('testdb', 'testcol', {'name': 'test'})
    assert result.inserted_id == 'mock_id'


def test_update_one(dbclient):
    client, _, _, collection = dbclient
    collection.update_one.return_value = MagicMock(modified_count=1)
    result = client.update_one('testdb', 'testcol', {'name': 'test'}, {
        '$set': {'name': 'updated'}})
    assert result.modified_count == 1


def test_delete_one(dbclient):
    client, _, _, collection = dbclient
    collection.delete_one.return_value = MagicMock(deleted_count=1)
    result = client.delete_one('testdb', 'testcol', {'name': 'test'})
    assert result.deleted_count == 1


def test_get_db_names(dbclient):
    client, mock_client, _, _ = dbclient
    mock_client.list_database_names.return_value = ['testdb', 'otherdb']
    result = client.get_db_names()
    assert 'testdb' in result


def test_exists_db(dbclient):
    client, mock_client, _, _ = dbclient
    mock_client.list_database_names.return_value = ['testdb', 'otherdb']
    assert client.exists_db('testdb') is True
    assert client.exists_db('missingdb') is False


def test_exists_collection(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.list_collection_names.return_value = ['testcol', 'othercol']
    assert client.exists_collection('testdb', 'testcol') is True
    assert client.exists_collection('testdb', 'missingcol') is False


def test_list_collections(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.list_collection_names.return_value = ['testcol', 'othercol']
    result = client.list_collections('testdb')
    assert result == ['testcol', 'othercol']


def test_stats(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.command.return_value = {'dbstats': 'mocked'}
    result = client.stats('testdb')
    assert result == {'dbstats': 'mocked'}


def test_start_session(dbclient):
    client, mock_client, _, _ = dbclient
    mock_client.start_session.return_value = 'session_obj'
    client.client = mock_client
    result = client.start_session()
    assert result == 'session_obj'


def test_find_one_by_id(dbclient):
    client, _, _, collection = dbclient
    collection.find_one.return_value = {'_id': 'mock_id'}
    result = client.find_one_by_id(
        'testdb', 'testcol', '507f1f77bcf86cd799439011')
    assert result == {'_id': 'mock_id'}
    with pytest.raises(ValueError):
        client.find_one_by_id('testdb', 'testcol', None)


def test_find(dbclient):
    client, _, _, collection = dbclient
    collection.find.return_value = [{'_id': 'mock_id'}]
    result = client.find('testdb', 'testcol', {'name': 'test'})
    assert result == [{'_id': 'mock_id'}]


def test_aggregate(dbclient):
    client, _, _, collection = dbclient
    collection.aggregate.return_value = [{'_id': 'mock_id'}]
    result = client.aggregate('testdb', 'testcol', [{}])
    assert result == [{'_id': 'mock_id'}]


def test_replace_one(dbclient):
    client, _, _, collection = dbclient
    collection.replace_one.return_value = MagicMock(modified_count=1)
    result = client.replace_one(
        'testdb', 'testcol', {'name': 'test'}, {'name': 'new'})
    assert result.modified_count == 1


def test_replace_one_by_id(dbclient):
    client, _, _, collection = dbclient
    collection.replace_one.return_value = MagicMock(modified_count=1)
    doc = {'_id': '507f1f77bcf86cd799439011', 'name': 'new'}
    result = client.replace_one_by_id('testdb', 'testcol', doc)
    assert result.modified_count == 1
    with pytest.raises(ValueError):
        client.replace_one_by_id('testdb', 'testcol', {'name': 'noid'})


def test_update_many(dbclient):
    client, _, _, collection = dbclient
    collection.update_many.return_value = MagicMock(modified_count=2)
    result = client.update_many('testdb', 'testcol', {}, {
                                '$set': {'name': 'multi'}})
    assert result.modified_count == 2


def test_insert_many(dbclient):
    client, _, _, collection = dbclient
    collection.insert_many.return_value = MagicMock(
        inserted_ids=['id1', 'id2'])
    result = client.insert_many(
        'testdb', 'testcol', [{'name': 'a'}, {'name': 'b'}])
    assert result.inserted_ids == ['id1', 'id2']


def test_count(dbclient):
    client, _, _, collection = dbclient
    collection.count_documents.return_value = 42
    result = client.count('testdb', 'testcol', {})
    assert result == 42


def test_count_estimated(dbclient):
    client, _, _, collection = dbclient
    collection.estimated_document_count.return_value = 99
    result = client.count_estimated('testdb', 'testcol')
    assert result == 99


def test_distinct(dbclient):
    client, _, _, collection = dbclient
    collection.distinct.return_value = ['a', 'b']
    result = client.distinct('testdb', 'testcol', 'field', {}, {})
    assert result == ['a', 'b']


def test_delete_many(dbclient):
    client, _, _, collection = dbclient
    collection.delete_many.return_value = MagicMock(deleted_count=3)
    result = client.delete_many('testdb', 'testcol', {})
    assert result.deleted_count == 3


def test_delete_one_by_id(dbclient):
    client, _, _, collection = dbclient
    collection.delete_one.return_value = MagicMock(deleted_count=1)
    result = client.delete_one_by_id(
        'testdb', 'testcol', '507f1f77bcf86cd799439011')
    assert result.deleted_count == 1
    with pytest.raises(ValueError):
        client.delete_one_by_id('testdb', 'testcol', None)


def test_create_collection(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.list_collection_names.return_value = []
    mock_db.create_collection.return_value = None
    client.create_collection('testdb', 'newcol')
    mock_db.create_collection.assert_called_once()


def test_drop_collection(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.list_collection_names.return_value = ['col']
    mock_db.drop_collection.return_value = None
    client.drop_collection('testdb', 'col')
    mock_db.drop_collection.assert_called_once()


def test_rename_collection(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.__getitem__.return_value.rename.return_value = None
    client.rename_collection('testdb', 'old', 'new')
    mock_db.__getitem__.return_value.rename.assert_called_once_with('new')


def test_create_index(dbclient):
    client, _, _, collection = dbclient
    collection.create_index.return_value = 'idx'
    result = client.create_index('testdb', 'testcol', 'field')
    assert result == 'idx'


def test_drop_index(dbclient):
    client, _, _, collection = dbclient
    collection.drop_index.return_value = None
    client.drop_index('testdb', 'testcol', 'idx')
    collection.drop_index.assert_called_once()


def test_get_indexes(dbclient):
    client, _, _, collection = dbclient
    collection.list_indexes.return_value = ['idx1', 'idx2']
    result = client.get_indexes('testdb', 'testcol')
    assert result == ['idx1', 'idx2']


def test_run_command(dbclient):
    client, _, mock_db, _ = dbclient
    mock_db.command.return_value = {'ok': 1}
    result = client.run_command('testdb', {'ping': 1})
    assert result == {'ok': 1}
