from typing import TypedDict


class AccountApiResponse(TypedDict):
    clusterId: str
    dbName: str
    _id: str
