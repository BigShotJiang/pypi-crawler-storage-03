import os
from .db_client import DbClient
from .types import AccountApiResponse
import requests

db_client_cache: dict = {}
dbClientSmacondi = None


def get_db_client_smacondi(apiURL: str, conn_string_map: dict, read_timeout=30000, write_timeout=30000):
    global dbClientSmacondi
    if not dbClientSmacondi:
        dbClientSmacondi = _DbClientSupport(
            apiURL, conn_string_map, read_timeout, write_timeout)
    return dbClientSmacondi


class _DbClientSupport:
    def __init__(self, apiURL: str, conn_string_map: dict, read_timeout: int = 30000, write_timeout: int = 30000):
        if not apiURL or not conn_string_map:
            raise ValueError('missing args')
        self.apiURL = apiURL
        self.conn_string_map = conn_string_map
        self.read_timeout = read_timeout
        self.write_timeout = write_timeout

    async def get_db_client_of_account(self, account_id: str):
        if not account_id:
            raise ValueError('missing args')

        account_cluster_info: AccountApiResponse = await requests.get(
            url=self.apiURL,
            params={
                'query': {
                    'accountId': account_id,
                }
            },
            headers=None,
            timeout=30,
        )
        cluster_id = account_cluster_info.get('clusterId')
        telemetry_db = account_cluster_info.get('dbName')
        account_conn_str = self.conn_string_map.get(cluster_id or 'MAIN')
        if not account_conn_str:
            raise ValueError(f"No connstr found for cluster {cluster_id}")
        account_db_client = db_client_cache.get(cluster_id)
        if not account_db_client:
            account_db_client = DbClient(
                account_conn_str, self.read_timeout, self.write_timeout)
            db_client_cache[cluster_id] = account_db_client
        return {'db_client': account_db_client, 'db_name': telemetry_db}

    def get_db_client_by_cluster_id(self, cluster_id: str):
        if not self.conn_string_map:
            raise ValueError('missing args')
        cluster_conn_str = self.conn_string_map.get(cluster_id)
        if not cluster_conn_str:
            raise ValueError(f"No connstr found for cluster {cluster_id}")
        cluster_db_client = db_client_cache.get(cluster_id)
        if not cluster_db_client:
            cluster_db_client = DbClient(
                cluster_conn_str, self.read_timeout, self.write_timeout)
            db_client_cache[cluster_id] = cluster_db_client
        return cluster_db_client


def close_all_db_clients():
    for db_client in db_client_cache.values():
        db_client.disconnect()
