import logging
from pymongo import MongoClient
from bson import ObjectId


logger = logging.getLogger(__name__)


class DbClient:
    def __init__(self, connection_string, read_timeout, write_timeout):
        if not connection_string:
            raise ValueError('No connection string given to DbClient.')
        if not read_timeout:
            raise ValueError('No read timeout given to DbClient.')
        if not write_timeout:
            raise ValueError('No write timeout given to DbClient.')
        self.connection_string = connection_string
        self.read_timeout = read_timeout
        logger.info(
            f"Set default query timeout in DbClient to {self.read_timeout} ms.")
        self.write_timeout = write_timeout
        logger.info(
            f"Set default write timeout in DbClient to {self.write_timeout} ms.")
        self.client = None

    def connect(self):
        self.client = MongoClient(self.connection_string)

    def disconnect(self):
        if self.client:
            self.client.close()
            self.client = None

    def _get_db(self, db_name):
        if not self.client:
            self.connect()
        return self.client[db_name]

    def _get_collection(self, db_name, collection_name):
        db = self._get_db(db_name)
        return db[collection_name]

    def find_one(self, db_name, collection_name, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.find_one(query, self._add_or_create_default_read_options(self, options))

    def find_one_and_delete(self, db_name, collection_name, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.find_one_and_delete(query, self._add_or_create_default_read_options(self, options))

    def find_one_by_id(self, db_name, collection_name, document_id, options=None):
        if not document_id:
            raise ValueError('document_id not given')
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.find_one({'_id': ObjectId(document_id)}, self._add_or_create_default_read_options(options))

    def find(self, db_name, collection_name, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        cursor = collection.find(
            query, self._add_or_create_default_read_options(options))
        return list(cursor)

    def aggregate(self, db_name, collection_name, pipeline, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        cursor = collection.aggregate(
            pipeline, self._add_or_create_default_read_options(options))
        return list(cursor)

    def insert_one(self, db_name, collection_name, document, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.insert_one(document, self._add_or_create_default_write_options(options))

    def update_one(self, db_name, collection_name, filter_, update, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.update_one(filter_, update, self._add_or_create_default_write_options(options))

    def replace_one(self, db_name, collection_name, filter_, document, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.replace_one(filter_, document, self._add_or_create_default_write_options(options))

    def replace_one_by_id(self, db_name, collection_name, document, options=None):
        if '_id' not in document:
            raise ValueError('Document has no _id.')
        document_id = ObjectId(document['_id'])
        doc_copy = document.copy()
        del doc_copy['_id']
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.replace_one({'_id': document_id}, doc_copy, self._add_or_create_default_write_options(options))

    def update_many(self, db_name, collection_name, filter_, update, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.update_many(filter_, update, self._add_or_create_default_write_options(options))

    def insert_many(self, db_name, collection_name, documents, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.insert_many(documents, self._add_or_create_default_write_options(options))

    def count(self, db_name, collection_name, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.count_documents(query, self._add_or_create_default_read_options(options))

    def count_estimated(self, db_name, collection_name, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.estimated_document_count(self._add_or_create_default_read_options(options))

    def distinct(self, db_name, collection_name, key, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.distinct(key, query, self._add_or_create_default_read_options(options))

    def delete_many(self, db_name, collection_name, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.delete_many(query, self._add_or_create_default_write_options(options))

    def delete_one(self, db_name, collection_name, query, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.delete_one(query, self._add_or_create_default_write_options(options))

    def delete_one_by_id(self, db_name, collection_name, document_id, options=None):
        if not document_id:
            raise ValueError('document_id not given')
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.delete_one({'_id': ObjectId(document_id)}, self._add_or_create_default_write_options(options))

    def create_collection(self, db_name, collection_name, options=None):
        if self.exists_collection(db_name, collection_name):
            return
        db = self._get_db(db_name)
        options = options or {}
        db.create_collection(
            collection_name, **self._add_or_create_default_write_options(options))

    def drop_collection(self, db_name, collection_name, options=None):
        if not self.exists_collection(db_name, collection_name):
            return
        db = self._get_db(db_name)
        options = options or {}
        db.drop_collection(collection_name, **
                           self._add_or_create_default_write_options(options))

    def rename_collection(self, db_name, from_collection_name, to_collection_name):
        db = self._get_db(db_name)
        db[from_collection_name].rename(to_collection_name)

    def create_index(self, db_name, collection_name, field, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.create_index(field, **self._add_or_create_default_write_options(options))

    def drop_index(self, db_name, collection_name, index_name, options=None):
        collection = self._get_collection(db_name, collection_name)
        options = options or {}
        return collection.drop_index(index_name, **self._add_or_create_default_write_options(options))

    def get_indexes(self, db_name, collection_name):
        collection = self._get_collection(db_name, collection_name)
        return list(collection.list_indexes())

    def run_command(self, db_name, command):
        db = self._get_db(db_name)
        return db.command(command)

    def get_db_names(self):
        if not self.client:
            self.connect()
        return self.client.list_database_names()

    def exists_db(self, db_name):
        if not db_name:
            raise ValueError('empty argument db_name')
        db_names = self.get_db_names()
        return db_name.lower() in (n.lower() for n in db_names)

    def exists_collection(self, db_name, collection_name):
        if not db_name or not collection_name:
            raise ValueError('empty argument')
        db = self._get_db(db_name)
        collections = db.list_collection_names()
        return collection_name in collections

    def list_collections(self, db_name):
        if not db_name:
            raise ValueError('empty argument db_name')
        db = self._get_db(db_name)
        return db.list_collection_names()

    def stats(self, db_name, options=None):
        if not db_name:
            raise ValueError('empty argument db_name')
        db = self._get_db(db_name)
        options = options or {}
        return db.command('dbstats', **options)

    def start_session(self):
        return self.client.start_session()

    def _get_timeout(self, value, default_timeout):
        try:
            timeout = int(value)
        except (TypeError, ValueError):
            timeout = default_timeout
        return timeout if timeout > 0 else default_timeout

    def _add_or_create_default_write_options(self, options=None):
        if options is None:
            options = {}
        opt = options.copy()
        write_concern = opt.get('write_concern', {})
        if 'wtimeout' not in write_concern or write_concern.get('wtimeout', 0) <= 0:
            write_concern['wtimeout'] = self.write_timeout
        opt['write_concern'] = write_concern
        return opt

    def _add_or_create_default_read_options(self, options=None):
        opt = options.copy() if options else {}
        if 'maxTimeMS' not in opt or opt.get('maxTimeMS', 0) <= 0:
            opt['maxTimeMS'] = self.read_timeout
        return opt
