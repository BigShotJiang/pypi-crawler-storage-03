# Internal Developer README

This document provides instructions for internal developers working on the `db-client-python` project.

## 1. Setting Up the Development Environment

### Install Python
Ensure you have Python 3.8 or newer installed. You can check your version with:

```bash
python3 --version
```

### Install Dependencies
All requirements are managed in a single place - the `Pipfile` (with locking via `Pipfile.lock`). The `pyproject.toml` automatically reads dependencies from the Pipfile.

#### Using Pipenv (recommended)
We use pipenv for dependency management with a lockfile for consistent environments:

```bash
# Install pipenv if you don't have it
pip install pipenv

# Install all dependencies (including dev)
PIPENV_VENV_IN_PROJECT=1 pipenv install --dev

# Activate the pipenv environment
pipenv shell

# Or run commands directly
pipenv run pytest
```

#### Using pip (alternative)
You can still install directly via pip:

```bash
pip install -e .
```

For development dependencies:
```bash
pip install -e '.[dev]'
```

#### Adding New Dependencies
Add new dependencies to the Pipfile only:

```bash
# For runtime dependencies
pipenv install some-package

# For development dependencies
pipenv install some-package --dev

# Lock the dependencies
pipenv lock
```

## 2. Running Tests

Tests are located in the `src/db_client_smacondi/tests/` directory. 

### With Pipenv (recommended)
```bash
# Run all tests
pipenv run pytest src/db_client_smacondi/tests/

# With coverage report
pipenv run pytest --cov=src/db_client_smacondi src/db_client_smacondi/tests/
```

### Directly with pytest
If you've already activated your virtual environment:
```bash
pytest src/db_client_smacondi/tests/

# With coverage report
pytest --cov=src/db_client_smacondi src/db_client_smacondi/tests/
```

## 3. Building the Package

To build the package (wheel and source):

```bash
python3 -m build
```

Artifacts will be created in the `dist/` directory.

## 4. Publishing the Package


To publish the package to TestPyPI:

1. Build the package (see above).
2. Retrieve the API key from Bitwarden:
   - Log in to Bitwarden and search for the `test.pypi.org` entry.
   - Copy the API key.
3. Create a `.pypirc` file in your home directory with the following content (replace `<API_KEY>` with your actual key):

```ini
[testpypi]
username = __token__
password = <API_KEY>
```

4. Upload the package using `twine`:

```bash
python3 -m twine upload --repository testpypi dist/*
```

For more details, see https://test.pypi.org/help/

## 5. Security Auditing

The project includes an audit script to check for security vulnerabilities and license compliance:

```bash
./audit.sh
```

This script:
1. Sets up a Python 3.12 environment with pipenv
2. Installs all required dependencies
3. Runs security checks with pip-audit
4. Verifies license compliance with pip-licenses

## 6. Dependency Management

This project uses a single source of truth for dependencies:

- **Pipfile**: Contains all dependency specifications
- **Pipfile.lock**: Contains exact locked versions for reproducible builds
- **pyproject.toml**: Dynamically reads dependencies from Pipfile using setuptools-pipfile

This approach avoids duplicating dependency information across files and ensures consistency between development and distribution.

### How it Works

1. All dependencies are defined only in the `Pipfile`
2. The `pyproject.toml` includes `dynamic = ["dependencies"]` 
3. The build system is configured with `setuptools-pipfile`
4. When packages are built or installed, dependencies are read from the Pipfile

## 7. Additional Notes
- Dependencies are managed with pipenv - update the Pipfile when adding new dependencies
- We maintain the Pipfile.lock in version control for reproducible builds
- For code style, use `black` and `flake8` (install with `pipenv install --dev`)
- For public documentation, see `PUBLIC_README.md`
- The main module is now `db_client_smacondi` (not `dbClientSmacondi`)
- For questions, contact the project maintainer
