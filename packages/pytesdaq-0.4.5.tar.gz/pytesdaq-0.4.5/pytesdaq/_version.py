# special file for defining the current version of the package
__version__ = "0.4.5"
