from pytest_postgresql import factories

postgresql_external = factories.postgresql("postgresql_noproc")
