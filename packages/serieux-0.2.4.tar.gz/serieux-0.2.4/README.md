# serieux

**WIP**

Very extensible serialization library.

[📋 Documentation](https://serieux.readthedocs.io/en/latest/)
