#!/bin/bash
source .venv/bin/activate
