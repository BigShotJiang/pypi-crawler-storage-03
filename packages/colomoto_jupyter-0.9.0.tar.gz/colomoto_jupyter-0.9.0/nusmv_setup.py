from colomoto.setup_helper import setup
setup({"pkg": "colomoto/nusmv",
        "check_progs": ["NuSMV"]})
