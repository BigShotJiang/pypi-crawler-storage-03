from colomoto.setup_helper import setup
setup({"pkg": "colomoto/espresso-logic-minimizer",
        "check_progs": ["espresso"]})
