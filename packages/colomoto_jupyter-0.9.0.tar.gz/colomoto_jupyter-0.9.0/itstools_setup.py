from colomoto.setup_helper import setup
setup({"pkg": "colomoto/its",
        "check_progs": ["its-reach", "its-ctl"]})
