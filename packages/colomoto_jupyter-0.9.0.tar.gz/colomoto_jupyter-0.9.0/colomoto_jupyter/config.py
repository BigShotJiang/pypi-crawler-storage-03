
auto_persistent = True

