"""Contains core classes and functions for the Haidra ecosystem."""

default_env_files = ("./.env", "./.env.prod")
