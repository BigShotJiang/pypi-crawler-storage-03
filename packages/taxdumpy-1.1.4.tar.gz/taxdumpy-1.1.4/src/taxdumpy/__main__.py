"""Taxdumpy main entry point."""

import sys
from taxdumpy.cli import main

if __name__ == "__main__":
    sys.exit(main())
