# TikExt

TikExt هي مكتبة Python بسيطة لفحص حالة حسابات TikTok.

## التثبيت

```bash
pip install TikExt
```

## الاستخدام

```python
from tikext import TikExt

tik = TikExt()
w = tik.GetStatus("tiktok") # مثال على اسم مستخدم موجود
print(w)

w = tik.GetStatus("nonexistent_tiktok_user_12345") # مثال على اسم مستخدم غير موجود
print(w)
```

## المطور

مصطفى (@PPH9P)


