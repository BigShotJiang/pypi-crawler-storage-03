from setuptools import setup, find_packages

setup(
    name='TikExt',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
    author='Mustafa',
    author_email='PPH9P@example.com',
    description='A simple Python library to check TikTok account status.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/TikExt',  # استبدل هذا برابط مستودعك
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)


