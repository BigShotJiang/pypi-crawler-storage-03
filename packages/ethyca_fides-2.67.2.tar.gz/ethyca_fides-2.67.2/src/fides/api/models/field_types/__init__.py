from .encrypted_large_data import EncryptedLargeDataDescriptor

__all__ = [
    "EncryptedLargeDataDescriptor",
]
