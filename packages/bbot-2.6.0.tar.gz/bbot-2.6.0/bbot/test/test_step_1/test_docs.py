def test_docs():
    from bbot.scripts.docs import update_docs

    update_docs()
