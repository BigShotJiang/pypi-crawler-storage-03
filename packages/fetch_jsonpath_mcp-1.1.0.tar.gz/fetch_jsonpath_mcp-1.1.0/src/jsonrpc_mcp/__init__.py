"""JSONRPC MCP Server - A Model Context Protocol server for JSON data extraction."""

__version__ = "1.0.0"
