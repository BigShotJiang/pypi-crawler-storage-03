Read data polling
-----------------

Ensure your device works reading data in polling.

.. literalinclude:: ../examples/ilps28qsw_read_data_polling.py
    :caption: examples/ilps28qsw_read_data_polling.py
    :linenos:
