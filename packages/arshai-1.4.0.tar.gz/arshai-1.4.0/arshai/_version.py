"""Version information for arshai package."""

__version__ = "1.4.0"
__version_info__ = (1, 4, 0)
__author__ = "Nima Nazarian"
__email__ = "nimunzn@gmail.com"