"""
McSixAI - AI ассистент для программирования
"""

__version__ = "0.1.6"
__author__ = "McSix"