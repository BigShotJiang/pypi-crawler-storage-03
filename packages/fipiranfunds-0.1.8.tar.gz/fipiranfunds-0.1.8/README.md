<html>
<body>
<!--StartFragment--><html><head></head><body><div class="markdown-body" role="textbox" aria-readonly="true"><p drb="true" dir="auto">Below is a ready-to-paste README content. It uses simple HTML tags (lang=“fa” dir=“rtl” align=“right”) for Persian headings/paragraphs so GitHub and PyPI will render those sections right-to-left. Code blocks remain plain Markdown (<code>bash / </code>python) so they render correctly.</p>
<ol drb="true" dir="auto">
<li drb="true" dir="auto">Copy everything from the first line to the last line below.</li>
<li drb="true" dir="auto">Paste into your <a drb="true" href="http://readme.md/" target="_blank" rel="noopener">README.md</a> (Notepad++ → Paste HTML is fine if it inserts raw tags).</li>
<li drb="true" dir="auto">Save as UTF-8 (Encoding → Convert to UTF-8).</li>
<li drb="true" dir="auto">Commit &amp; push or upload to GitHub and preview the repo page.</li>
</ol>
<p drb="true" dir="auto">Ready-to-paste <a drb="true" href="http://readme.md/" target="_blank" rel="noopener">README.md</a>:</p>
<h1 drb="true" dir="auto">FipiranFunds</h1>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">
کتابخانه‌ی پایتون برای دریافت و ذخیره‌سازی داده‌های معاملات و بازدهی صندوق‌ها از API فپیران (Fipiran) و خروجی گرفتن به CSV.  
این README شامل توضیحات به فارسی برای کاربران ایرانی و نمونه‌های کدنویسی کاربردی به انگلیسی است.
</p>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">پیش‌نیازها / Requirements</h2>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">
نسخه‌ی پایتون: 3.8+  
الزامات اصلی:
</p>
<ul drb="true" dir="auto">
<li drb="true" dir="auto">requests &gt;= 2.25</li>
<li drb="true" dir="auto">pandas &gt;= 1.2</li>
<li drb="true" dir="auto">jdatetime &gt;= 3.6</li>
<li drb="true" dir="auto">beautifulsoup4</li>
</ul>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">کتابخانه‌های اختیاری (برای امکانات بیشتر):</p>
<ul style="direction: rtl;" drb="true" dir="auto">
<li style="direction: rtl;" drb="true" dir="rtl">pyodbc — برای اتصال و نوشتن در SQL Server (نیاز به نصب ODBC driver از مایکروسافت روی ویندوز)</li>
<li style="direction: rtl;" drb="true" dir="rtl">pytse-client — در صورتی که بخواهید از داده‌های TSETMC استفاده کنید</li>
<li style="direction: rtl;" drb="true" dir="rtl">tqdm — برای نوار پیشرفت (progress bar)</li>
<li style="direction: rtl;" drb="true" dir="rtl">python-dateutil — کمک در پردازش تاریخ‌ها</li>
</ul>
<p style="direction: rtl;" drb="true" dir="auto">نصب سریع (پیشنهادی برای تمام امکانات):</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">bash</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body bash">pip install fipiranfunds requests pandas jdatetime beautifulsoup4 pyodbc pytse-client tqdm python-dateutil
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<p style="direction: rtl;" drb="true" dir="auto">نکته برای pyodbc روی ویندوز:</p>
<ul style="direction: rtl;" drb="true" dir="auto">
<li style="direction: rtl;" drb="true" dir="rtl">قبل از نصب pyodbc، در صورت نیاز درایور ODBC مایکروسافت را نصب کنید (مثلاً “Microsoft ODBC Driver 17 for SQL Server”).</li>
</ul>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">نصب / Installation</h2>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">برای استفاده ساده:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">bash</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body bash">pip install fipiranfunds
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<p style="direction: rtl;" drb="true" dir="auto">برای توسعه یا نصب آخرین نسخه از گیت‌هاب:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">bash</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body bash">pip install git+https://github.com/Kimiaslhd/fipiranfunds.git
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">شروع سریع / Quick Start</h2>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">
مثال تعاملی: برنامه از شما تاریخ شمسی می‌پرسد و خروجی CSV روی Desktop ذخیره می‌شود.
</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">python</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body python"><span style="direction: rtl;" drb="true" class="hljs-keyword">from</span> fipiranfunds <span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> export_fund_data

export_fund_data()
<span style="direction: rtl;" drb="true" class="hljs-comment"># برنامه از شما تاریخ شروع و پایان به فرمت شمسی YYYY/MM/DD را می‌پرسد</span>
<span style="direction: rtl;" drb="true" class="hljs-comment"># سپس فایل CSV خروجی روی Desktop ذخیره می‌شود</span>
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">خلاصه‌ی قابلیت‌ها / Usage overview</h2>
<ul drb="true" dir="auto" style="direction: rtl;">
<li drb="true" dir="rtl" style="direction: rtl;">export_fund_data(): اجرای تعاملی، دریافت داده‌ها در بازه تاریخی و ذخیره به CSV (Desktop).</li>
<li style="direction: rtl;" drb="true" dir="rtl">core.FundDataFetcher: کلاس برای استفاده‌ی برنامه‌نویسی (برگرداندن pandas.DataFrame).</li>
<li style="direction: rtl;" drb="true" dir="rtl">utils.jalali_to_gregorian(date_str): تبدیل تاریخ شمسی به میلادی.</li>
<li style="direction: rtl;" drb="true" dir="rtl">mapper.*: توابع داخلی برای نگاشت فیلدها از API به نام‌های دوستانه در CSV.</li>
</ul>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">توابع و مثال‌ها / Functions &amp; Examples</h2>
<h3 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">export_fund_data()</h3>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">
تابع راحت و تعاملی: از کاربر تاریخ‌های شروع و پایان شمسی می‌پرسد، آن‌ها را به میلادی تبدیل کرده، داده‌ها را از API فراخوانی می‌کند و CSV را ذخیره می‌کند.
</p>
<p style="direction: rtl;" drb="true" dir="auto">رفتار:</p>
<ul style="direction: rtl;" drb="true" dir="auto">
<li style="direction: rtl;" drb="true" dir="rtl">اعتبارسنجی تاریخ ورودی (Jalali).</li>
<li style="direction: rtl;" drb="true" dir="rtl">تلاش‌های مجدد (retries) در صورت بروز خطاهای موقتی شبکه.</li>
<li style="direction: rtl;" drb="true" dir="rtl">چاپ وضعیت پیشرفت و مسیر نهایی فایل CSV.</li>
</ul>
<p style="direction: rtl;" drb="true" dir="auto">مثال:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">python</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body python"><span style="direction: rtl;" drb="true" class="hljs-keyword">from</span> fipiranfunds <span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> export_fund_data

export_fund_data()
<span style="direction: rtl;" drb="true" class="hljs-comment"># Enter start date (Jalali YYYY/MM/DD): 1403/01/01</span>
<span style="direction: rtl;" drb="true" class="hljs-comment"># Enter end date (Jalali YYYY/MM/DD): 1403/01/05</span>
<span style="direction: rtl;" drb="true" class="hljs-comment"># Data saved to: C:\Users\&lt;You&gt;\Desktop\fipiran_export_2025-01-01_140501.csv</span>
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h3 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">core.FundDataFetcher</h3>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">برای کنترل برنامه‌نویسی و استفاده در ETL یا اسکریپت‌ها استفاده می‌شود. خروجی pandas.DataFrame است.</p>
<p style="direction: rtl;" drb="true" dir="auto">مثال:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" class="code-block-header__toggle-icon" stroke-linejoin="round" stroke-linecap="round" stroke-width="2" stroke="currentColor" fill="none"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">python</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body python"><span style="direction: rtl;" drb="true" class="hljs-keyword">from</span> fipiranfunds.core <span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> FundDataFetcher
<span style="direction: rtl;" drb="true" class="hljs-keyword">from</span> fipiranfunds.utils <span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> jalali_to_gregorian

fetcher = FundDataFetcher()
start = jalali_to_gregorian(<span style="direction: rtl;" drb="true" class="hljs-string">"1403/01/01"</span>)
end = jalali_to_gregorian(<span style="direction: rtl;" drb="true" class="hljs-string">"1403/01/31"</span>)
df = fetcher.fetch_fund_data(start, end)

<span style="direction: rtl;" drb="true" class="hljs-built_in">print</span>(df.head())
df.to_csv(<span style="direction: rtl;" drb="true" class="hljs-string">"funds_local.csv"</span>, index=<span style="direction: rtl;" drb="true" class="hljs-literal">False</span>)
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h3 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">utils.jalali_to_gregorian(date_str)</h3>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">تبدیل رشته تاریخ شمسی "YYYY/MM/DD" به تاریخ میلادی یا رشته ISO "YYYY-MM-DD".</p>
<p style="direction: rtl;" drb="true" dir="auto">مثال:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">python</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body python"><span style="direction: rtl;" drb="true" class="hljs-keyword">from</span> fipiranfunds.utils <span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> jalali_to_gregorian

<span style="direction: rtl;" drb="true" class="hljs-built_in">print</span>(jalali_to_gregorian(<span style="direction: rtl;" drb="true" class="hljs-string">"1403/01/01"</span>))  <span style="direction: rtl;" drb="true" class="hljs-comment"># مثال: "2024-03-21"</span>
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">ساختار CSV خروجی / Output CSV structure</h2>
<p style="direction: rtl;" drb="true" dir="auto">الگوی نام فایل:</p>
<ul drb="true" dir="auto">
<li drb="true" dir="auto">fipiranfunds_export_&lt;YYYYMMDD_HHMMSS&gt;.csv</li>
</ul>
<p style="direction: rtl;" drb="true" dir="auto">ستون‌های نمونه (ممکن است بسته به نسخه تغییر کنند):</p>
<ul drb="true" dir="auto">
<li drb="true" dir="auto">regNo, fundTitle, isCompleted, calcDate, licenseTitle, fundSize, fundType,
initiationDate, dailyEfficiency, weeklyEfficiency, monthlyEfficiency,
quarterlyEfficiency, sixMonthEfficiency, annualEfficiency, statisticalNav,
efficiency, cancelNav, issueNav, dividendPeriodEfficiency, netAsset,
unitBalance, accountsNo, articlesOfAssociationEfficiency</li>
</ul>
<hr drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">اتصال به SQL Server (اختیاری) / SQL Server connection (optional)</h2>
<p style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">در صورتی که می‌خواهید خروجی‌ها را در دیتابیس بنویسید:</p>
<p style="direction: rtl;" drb="true" dir="auto">نمونه‌ی ساده‌ی اتصال و نوشتن pandas DataFrame با pyodbc:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">python</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body python"><span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> pyodbc
<span style="direction: rtl;" drb="true" class="hljs-keyword">import</span> pandas <span style="direction: rtl;" drb="true" class="hljs-keyword">as</span> pd

conn_str = <span style="direction: rtl;" drb="true" class="hljs-string">"DRIVER={ODBC Driver 17 for SQL Server};SERVER=192.168.1.131;DATABASE=LotusibBI;UID=user;PWD=pass"</span>
conn = pyodbc.connect(conn_str)
cursor = conn.cursor()

<span style="direction: rtl;" drb="true" class="hljs-comment"># فرض کنید df دیتا شما است</span>
<span style="direction: rtl;" drb="true" class="hljs-comment"># سریع‌ترین روش: df.to_csv(...) و سپس BULK INSERT یا از pandas.to_sql (با SQLAlchemy) استفاده کنید.</span>
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">نکات خطاها و راهنمایی‌ها / Troubleshooting &amp; tips</h2>
<ul style="direction: rtl;" drb="true" dir="auto">
<li style="direction: rtl;" drb="true" dir="rtl">اگر با خطای تاریخ مواجه شدید، ورودی تاریخ را بررسی کنید؛ فرمت باید YYYY/MM/DD باشد.</li>
<li style="direction: rtl;" drb="true" dir="rtl">اگر درخواست‌ها با خطای 500 یا ip-block مواجه شدند، چند دقیقه صبر کنید و دوباره امتحان کنید — سایت ممکن است شما را موقتاً محدود کند.</li>
<li style="direction: rtl;" drb="true" dir="rtl">اگر از jdatetime استفاده می‌کنید و تداخل نسخه‌ای با سایر پکیج‌ها دارید، سعی کنید نسخه‌ای را انتخاب کنید که با دیگر بسته‌های شما سازگار باشد.</li>
</ul>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">CLI (در صورت وجود) / CLI</h2>
<p style="direction: rtl;" drb="true" dir="auto">اگر پکیج شیوه‌ی خط فرمان را پشتیبانی کند:</p>
<pre class="code-block-wrapper"><pre class="code-block-header">        <span style="direction: rtl;" drb="true" class="code-block-header__toggle" aria-label="Toggle code visibility"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="code-block-header__toggle-icon"><line style="direction: rtl;" drb="true" x1="5" y1="12" x2="19" y2="12" class="toggle-minus"></line><line style="direction: rtl;" drb="true" x1="12" y1="5" x2="12" y2="19" class="toggle-plus"></line></svg></span>
        <span style="direction: rtl;" drb="true" class="code-block-header__lang">bash</span>
        <span style="direction: rtl;" drb="true" class="code-block-header__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
      </pre><code class="hljs code-block-body bash">python -m fipiranfunds.cli
<span style="direction: rtl;" drb="true" class="hljs-comment"># یا اگر console_script تعریف شده:</span>
fipiranfunds
</code><pre class="code-block-footer">    <span style="direction: rtl;" drb="true" class="code-block-footer__copy"><svg style="direction: rtl;" drb="true" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
    <path style="direction: rtl;" drb="true" fill="currentColor" d="M5.503 4.627L5.5 6.75v10.504a3.25 3.25 0 0 0 3.25 3.25h8.616a2.251 2.251 0 0 1-2.122 1.5H8.75A4.75 4.75 0 0 1 4 17.254V6.75c0-.98.627-1.815 1.503-2.123M17.75 2A2.25 2.25 0 0 1 20 4.25v13a2.25 2.25 0 0 1-2.25 2.25h-9a2.25 2.25 0 0 1-2.25-2.25v-13A2.25 2.25 0 0 1 8.75 2zm0 1.5h-9a.75.75 0 0 0-.75.75v13c0 .414.336.75.75.75h9a.75.75 0 0 0 .75-.75v-13a.75.75 0 0 0-.75-.75"></path>
  </svg></span>
  </pre></pre>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">توسعه و مشارکت / Contributing</h2>
<ul style="direction: rtl;" drb="true" dir="auto">
<li style="direction: rtl;" drb="true" dir="rtl">مسائل و درخواست‌ها (issues / PR) را در گیت‌هاب باز کنید: <a style="direction: rtl;" drb="true" href="https://github.com/Kimiaslhd/fipiranfunds" target="_blank" rel="noopener">https://github.com/Kimiaslhd/fipiranfunds</a></li>
<li style="direction: rtl;" drb="true" dir="rtl">لطفاً قبل از ارسال PR، تست‌های محلی را اجرا و سبک کدنویسی را رعایت کنید.</li>
</ul>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">مجوز / License</h2>
<p style="direction: rtl;" drb="true" dir="auto">MIT</p>
<hr style="direction: rtl;" drb="true">
<h2 style="direction: rtl;" drb="true" lang="fa" dir="rtl" align="right">نویسنده / Author &amp; Contact</h2>
<p style="direction: rtl;" drb="true" dir="auto">Kimia Salehi Delarestaghi<br style="direction: rtl;" drb="true">
Email: <a style="direction: rtl;" drb="true" href="mailto:kimiaslhd@gmail.com">kimiaslhd@gmail.com</a><br style="direction: rtl;" drb="true">
LinkedIn: <a style="direction: rtl;" drb="true" href="https://www.linkedin.com/in/kimia-salehy-delarestaghy/">https://www.linkedin.com/in/kimia-salehy-delarestaghy/</a><br style="direction: rtl;" drb="true">
GitHub: <a style="direction: rtl;" drb="true" href="https://github.com/Kimiaslhd/fipiranfunds">https://github.com/Kimiaslhd/fipiranfunds</a><br style="direction: rtl;" drb="true">
PyPI: <a style="direction: rtl;" drb="true" href="https://pypi.org/project/fipiranfunds/">https://pypi.org/project/fipiranfunds/</a></p>
<hr style="direction: rtl;" drb="true">
</ul>
</div></body></html><!--EndFragment-->
</body>
</html>