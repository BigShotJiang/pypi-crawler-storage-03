# sonolus.script.globals

::: sonolus.script.globals
