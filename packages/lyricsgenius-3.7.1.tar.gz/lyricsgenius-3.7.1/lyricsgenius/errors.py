class InvalidStateError(Exception):
    """Exception for non-matching states."""
