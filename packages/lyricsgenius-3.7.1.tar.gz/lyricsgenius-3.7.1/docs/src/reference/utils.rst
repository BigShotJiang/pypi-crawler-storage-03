.. _utils:
.. currentmodule:: lyricsgenius
.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Utils

Utils
=======================

.. automodule:: lyricsgenius.utils
    :members:
    :no-show-inheritance:
