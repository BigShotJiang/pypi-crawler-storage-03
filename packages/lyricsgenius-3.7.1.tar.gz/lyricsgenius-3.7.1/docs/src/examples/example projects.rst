Example projects
==================

-  `Trucks and Beer: A textual analysis of popular country music`_
-  `Neural machine translation: Explaining the Meaning Behind Lyrics`_
-  `What makes some blink-182 songs more popular than others?`_
-  `Sentiment analysis on hip-hop lyrics`_
-  `Does Country Music Drink More Than Other Genres?`_
-  `49 Years of Lyrics: Why So Angry?`_

.. _`Trucks and Beer: A textual analysis of popular country music`: http://www.johnwmillr.com/trucks-and-beer/
.. _`Neural machine translation: Explaining the Meaning Behind Lyrics`: https://github.com/tsandefer/dsi_capstone_3
.. _What makes some blink-182 songs more popular than others?: http://jdaytn.com/posts/download-blink-182-data/
.. _Sentiment analysis on hip-hop lyrics: https://github.com/Hugo-Nattagh/2017-Hip-Hop
.. _Does Country Music Drink More Than Other Genres?: https://towardsdatascience.com/does-country-music-drink-more-than-other-genres-a21db901940b
.. _`49 Years of Lyrics: Why So Angry?`: https://towardsdatascience.com/49-years-of-lyrics-why-so-angry-1adf0a3fa2b4
