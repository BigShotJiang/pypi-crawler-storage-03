# Welcome to Thunder Compute!

You are using the Thunder Compute CLI, your interface with the Thunder Compute network. Find more details at https://www.thundercompute.com/docs

## Usage

Use tnr --help for detailed usage tips
