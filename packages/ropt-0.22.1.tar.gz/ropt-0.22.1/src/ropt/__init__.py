"""The main `ropt` module, a library for ensemble based optimization."""
