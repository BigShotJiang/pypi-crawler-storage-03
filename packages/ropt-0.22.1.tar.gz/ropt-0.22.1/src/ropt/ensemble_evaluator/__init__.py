"""Functionality for the evaluation of ensembles."""

from ._ensemble_evaluator import EnsembleEvaluator

__all__ = [
    "EnsembleEvaluator",
]
