::: ropt.plugins
    options:
        members:
            - PluginManager
            - PluginType
            - Plugin
        group_by_category: false
