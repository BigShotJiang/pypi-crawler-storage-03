::: ropt.plugins.optimizer.scipy.SciPyOptimizer
    options:
        members: False
