::: ropt.ensemble_evaluator.EnsembleEvaluator
::: ropt.evaluator.EvaluatorContext
::: ropt.evaluator.EvaluatorResult
::: ropt.evaluator.EvaluatorCallback
