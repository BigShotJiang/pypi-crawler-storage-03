# FiFiCore
Repo consists of repeatative functionality across different projects which can use
this core library.
