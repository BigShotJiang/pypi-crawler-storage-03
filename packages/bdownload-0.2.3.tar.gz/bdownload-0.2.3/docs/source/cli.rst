:orphan:

.. _example_cli:

``bdownload``'s command-line utility
====================================

Download: :download:`cli.py <../../src/bdownload/cli.py>`

.. literalinclude:: ../../src/bdownload/cli.py
    :language: python
