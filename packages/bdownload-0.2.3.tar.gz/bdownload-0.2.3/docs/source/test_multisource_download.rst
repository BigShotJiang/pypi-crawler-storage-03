:orphan:

.. _test_multisource_download:

Testcase for unittesting multi-source downloading of ``BDownloader``
====================================================================

Download: :download:`test_multisource_download.py <../../tests/test_multisource_download.py>`

.. literalinclude:: ../../tests/test_multisource_download.py
    :language: python
