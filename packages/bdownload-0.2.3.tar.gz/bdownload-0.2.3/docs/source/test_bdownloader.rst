:orphan:

.. _test_bdownloader:

Testcase for unittesting ``BDownloader``
========================================

Download: :download:`test_bdownloader.py <../../tests/test_bdownloader.py>`

.. literalinclude:: ../../tests/test_bdownloader.py
    :language: python
