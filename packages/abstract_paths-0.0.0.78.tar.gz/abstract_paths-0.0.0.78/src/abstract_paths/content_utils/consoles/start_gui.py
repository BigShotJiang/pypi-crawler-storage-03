from finderConsole import *


startReactFinderShell()
