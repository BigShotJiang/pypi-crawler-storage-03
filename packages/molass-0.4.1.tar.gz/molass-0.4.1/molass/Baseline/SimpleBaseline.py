"""
    Baseline.SimleBaseline.py

    Copyright (c) 2024, SAXS Team, KEK-PF
"""

def estimate_baseline_params(curve, debug=False):
    return []