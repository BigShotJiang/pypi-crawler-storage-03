"""
    Trimming.__init__.py
"""