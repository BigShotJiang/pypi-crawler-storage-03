"""
    LowRank.__init__.py
"""