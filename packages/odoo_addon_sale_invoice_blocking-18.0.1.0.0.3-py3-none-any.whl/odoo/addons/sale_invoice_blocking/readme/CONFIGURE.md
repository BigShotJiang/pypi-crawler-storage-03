To configure this module, you need to:

1.  Go to 'Sales \> Configuration \> Sales Orders \> Invoicing block
    reasons'.
2.  Create the different reasons that can lead to block the invoices of
    a sales order.
