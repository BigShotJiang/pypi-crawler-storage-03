This module extends the functionality of sales to allow you to block the
creation of invoices from a sales order and give a reason.
