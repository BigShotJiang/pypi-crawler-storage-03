* Go to 'Invoicing / Configuration / Overdue Terms', and add the terms,
  providing the day from, date to and a name that will be displayed in the
  Payments and due list as column.

* It is recommended to always add a last term '+ X' where the 'to days' value
  is a very big value like 99999.
