* Jordi Ballester Alomar <jordi.ballester@forgeflow.com>
* Holger Brunn <hbrunn@therp.nl>
* `Sygel <https://www.sygel.es>`_:

  * Valentin Vinagre <valentin.vinagre@sygel.es>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
