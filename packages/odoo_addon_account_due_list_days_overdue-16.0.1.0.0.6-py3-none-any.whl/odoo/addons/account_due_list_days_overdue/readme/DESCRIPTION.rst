This module adds to the 'Payments and due list' view the number of days that
an open item is overdue, and classifies the amount due in separate terms
columns  (e.g. 1-30, 31-60, +61).

The terms columns to show in the list and the number of days for within each
term can be configured.
