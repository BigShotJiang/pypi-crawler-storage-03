# ConLAi CIFAR10

## Operating procedure

```shell
# Run 
python run.py ./conf/dsgd_cifar10_mobilenet.yaml
```
