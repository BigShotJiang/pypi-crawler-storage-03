from .max import Max  # noqa: F401
