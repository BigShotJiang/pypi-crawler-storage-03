"""DuckDB provider components for ChunkHound."""

from .connection_manager import DuckDBConnectionManager

__all__ = ["DuckDBConnectionManager"]
