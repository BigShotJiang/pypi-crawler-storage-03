About geoserver-rest!
=====================

What is geoserver-rest?
^^^^^^^^^^^^^^^^^^^^^^^

The geoserver-rest package is useful for the management of geospatial data in `GeoServer <http://geoserver.org/>`_.
This package is useful for creating, updating and deleting geoserver workspaces, stores, layers, and style files.

For a live example of geoserver-rest in action, check out the video tutorial on geoserver-rest below:

.. raw:: html

    <iframe width="560" height="315" src="https://www.youtube.com/embed/nXvzmbGukeE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


Current version
---------------

Current version: v1.5.1
