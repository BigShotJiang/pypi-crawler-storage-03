# Contributing Guidelines

Geoserver-rest is an open source library written in python and contributors are needed to keep this library moving forward. Any kind of contributions are welcome.

# Guidelines

1. Please use the request library for the http request.
2. One feature per pull request.
3. Please add the update about your PR on the [change log documentation](https://github.com/gicait/geoserver-rest/blob/master/docs/source/change_log.rst#master-branch) as well.
