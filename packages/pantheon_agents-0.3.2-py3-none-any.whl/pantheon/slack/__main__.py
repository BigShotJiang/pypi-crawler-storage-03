import fire
from .app import run_app

fire.Fire(run_app)
