#!/usr/bin/env python3
"""Smart Pantheon Generator CLI entry point"""

from .smart_standalone import cli

if __name__ == "__main__":
    cli()