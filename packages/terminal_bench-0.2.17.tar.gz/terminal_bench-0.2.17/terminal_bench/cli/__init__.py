from terminal_bench.cli.wizard import Wizard

__all__ = ["Wizard"]
