# shipsim-cli
Estimate shipping cost using carrier Ship Zones and Rate Cards
