"""Common used exceptions."""

from __future__ import annotations


class StopScenario(Exception):  # noqa: N818
    pass
