---
title: Licenses
---
# Licenses

@shell cd ../../ && python3 script/docs-generate-licenses.py
