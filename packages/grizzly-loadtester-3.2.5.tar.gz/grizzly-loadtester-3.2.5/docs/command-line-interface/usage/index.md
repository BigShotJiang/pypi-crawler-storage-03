---
title: Usage
---
@shell cd ../../../ && script/docs-generate.bash cli --usage
