"""aiwb"""

__version__ = "v1.1.0"
