Users can define membership withdrawal reasons in *Members \>
Configuration \> Membership withdrawal reasons*
