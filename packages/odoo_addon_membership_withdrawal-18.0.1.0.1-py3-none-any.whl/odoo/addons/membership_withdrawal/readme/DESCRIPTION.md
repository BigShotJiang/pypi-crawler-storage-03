This module allows to record membership withdrawal reason and date of
request.
