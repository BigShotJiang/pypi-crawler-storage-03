Then go to any member membership line and set:

- Withdrawal reason: Why member requested withdrawal
- Withdrawal date: When member requested withdrawal
- Date cancel: Date when membership period must finish
