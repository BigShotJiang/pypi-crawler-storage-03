# SMOGN – Imbalanced Regression Toolkit

**SMOGN (Synthetic Minority Oversampling for Regression with Gaussian Noise)** is a Python package for addressing **imbalanced regression problems**.  

Most oversampling techniques focus on classification tasks, but regression datasets often suffer from **rare extreme values** that bias model learning. SMOGN provides tools to **rebalance regression datasets**, compute **relevance (φ) functions**, and evaluate models using **relevance-aware metrics** (SERT & SERA).  

It also includes **nested cross-validation utilities** for robust benchmarking and dataset summarization methods.

---

## 📂 Data

The SMOGN package itself does not ship large datasets.  

- Example datasets (e.g., forestfires.csv) are included in the `examples/` folder.  
- Benchmark experiments in our research used **34 different regression datasets** with varied feature engineering pipelines.  
- For reproducibility, we provide dataset access instructions here:  
  [Dataset Collection (Github link)](https://github.com/Bhavneet345/COOP2025_IMBALANCE_REGRESSION/tree/main/data)  

---

## ✨ Key Features

- **Relevance (φ) Functions**
  - Control-points method: define relevance thresholds manually.
  - Density-based method: compute relevance using statistical distribution.
  - Save/load φ functions for reproducibility.

- **Oversampling for Regression**
  - SMOGN algorithm: generates synthetic rare-value samples using Gaussian noise.
  - SMOTER extensions for regression oversampling.

- **Evaluation Metrics**
  - **SERT (Squared Error Relevance Threshold)**  
  - **SERA (Squared Error Relevance Area)**  
  - Normalized variants: NRMSE, NSSE, Target-based, Hybrid.
  - Combination utilities for comparative analysis.

- **Cross-Validation**
  - Generalized **nested CV pipeline** (`nestedCV.py`) with customizable folds, scoring, and parameter search.

- **Utilities**
  - Dataset summarization (`summarize_datasets.py`)
  - Box plots & distribution analysis
  - KL-Divergence & Fréchet distance table generation

---

## 📦 Installation

### Base Install (works on **Python ≥3.8**, including 3.13+)

```bash
pip install smogn-imbalanced-regression-toolkit
```

### with Deep Learning Extras (for nestedCV with Keras/Scikeras, Python ≤3.12)
```bash
pip install smogn-imbalanced-regression-toolkit[dl]
```