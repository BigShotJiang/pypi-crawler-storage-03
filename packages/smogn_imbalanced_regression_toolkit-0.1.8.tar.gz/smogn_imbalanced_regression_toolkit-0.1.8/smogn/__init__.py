# smogn/__init__.py

__version__ = "0.1.8"

# ----------------------------
# Core relevance functions
# ----------------------------
from .phi import *
from .phi_ctrl_pts import *
from .phi_density_methods import *
from .load_phi_methd_pickle import *
from .box_plot_stats import *
from .dist_metrics import *

# ----------------------------
# Oversampling methods
# ----------------------------
from .smoter import *
from .over_sampling import *

# ----------------------------
# Metrics
# ----------------------------
from .SERT_SERA import *
from .SERT_SERA_normalize_nrmse_nsse import *
from .SERT_SERA_normalize_sert import *
from .SERT_SERA_normalize_target import *
from .SERT_SERA_normalize_target_sert import *
from .combine_Sert_Sera import *

# ----------------------------
# Utilities
# ----------------------------
from .summarize_datasets import *

# ----------------------------
# Cross-validation (optional)
# ----------------------------
try:
    from .nestedCV import *
except ImportError:
    import warnings
    warnings.warn(
        "⚠️ 'nestedCV' requires the [dl] extras (TensorFlow/Keras/Scikeras). "
        "Install with:\n\n   pip install smogn-imbalanced-regression-toolkit[dl]\n",
        ImportWarning,
    )
