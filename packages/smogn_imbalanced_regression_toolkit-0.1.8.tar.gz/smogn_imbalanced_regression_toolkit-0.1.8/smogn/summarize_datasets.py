import os
import glob
import numpy as np
import pandas as pd

def summarize():
    def detect_extreme_type(y: pd.Series):
        """Detect extreme‐value type using standard Tukey fences."""
        q1, q3 = np.percentile(y, [25, 75])
        iqr = q3 - q1
        lower_fence = q1 - 1.5 * iqr
        upper_fence = q3 + 1.5 * iqr
        has_low  = (y < lower_fence).any()
        has_high = (y > upper_fence).any()
        if has_low and has_high:
            return 'B'
        elif has_high:
            return 'U'
        elif has_low:
            return 'L'
        else:
            return 'N'  # no outliers

    # directory with your default‐method phi CSVs
    csv_dir = "CSV_output"
    files   = glob.glob(os.path.join(csv_dir, "*_phi_default.csv"))

    summary_rows = []
    for path in files:
        df      = pd.read_csv(path)
        phi     = df["phi"]
        ds      = os.path.basename(path).replace("_phi_default.csv", "")

        # Table 5 columns computed on your data
        D       = len(df)                         # |D|
        Nom     = len(df.select_dtypes(include=['object','category']).columns.drop('phi', errors='ignore'))
        Num     = len(df.select_dtypes(include=[np.number]).columns.drop('phi', errors='ignore'))
        D1_bar  = int((phi < 1.0).sum())           # |D₁̸|
        D1      = int((phi == 1.0).sum())          # |D₁|
        IR      = D1_bar / D1 if D1 > 0 else np.nan
        target  = df.columns[-2]                   # assume last column before φ is the original target
        Type    = detect_extreme_type(df[target])  # U, L, B, or N

        # your extra φ‐count columns
        phi_075_09 = int(((phi >= 0.75) & (phi <= 0.90)).sum())
        phi_08_1 = int(((phi >= 0.80) & (phi <= 1.00)).sum())
        phi_09_1   = int(((phi >= 0.90) & (phi <= 1.00)).sum())

        # add n_rows and n_cols
        n_rows = df.shape[0]
        n_cols = df.shape[1]

        summary_rows.append({
            "dataset":       ds,
            "n_rows":        n_rows,
            "n_cols":        n_cols,
            "|D|":           D,
            "|D/D₁|":         D1_bar,
            "|D₁|":          D1,
            "IR":            f"{IR:.2f}",
            "Type":          Type,
            "phi_0.75_0.9":  phi_075_09,
            "phi_08_1": phi_08_1,
            "phi_0.9_1":     phi_09_1
        })

    summary = pd.DataFrame(summary_rows).sort_values("dataset")
    # print(summary.to_markdown(index=False))
    summary.to_csv("Table_auto_phi_summary.csv", index=False)
