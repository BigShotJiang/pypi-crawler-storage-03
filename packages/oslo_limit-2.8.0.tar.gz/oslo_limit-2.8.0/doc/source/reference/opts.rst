=====================
Configuration Options
=====================

oslo.limit uses oslo.config to define and manage configuration
options to allow the deployer to control how an application uses the
underlying quota limits and enforcement.

.. show-options:: oslo.limit
