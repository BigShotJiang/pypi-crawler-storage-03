# zipcode features

similar to [uszipcode-project](https://github.com/EricSchles/uszipcode-project)