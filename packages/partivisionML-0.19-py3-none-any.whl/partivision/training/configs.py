class Configs:

    workspace_name = "cv-time"
    project_name = "final-dataset-idfeu"
    version_number = 300

