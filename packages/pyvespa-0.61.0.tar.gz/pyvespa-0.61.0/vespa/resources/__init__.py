import os


def get_resource_path():
    return os.path.dirname(__file__)
