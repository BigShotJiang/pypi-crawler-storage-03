class VespaError(Exception):
    """Vespa returned an error response"""
