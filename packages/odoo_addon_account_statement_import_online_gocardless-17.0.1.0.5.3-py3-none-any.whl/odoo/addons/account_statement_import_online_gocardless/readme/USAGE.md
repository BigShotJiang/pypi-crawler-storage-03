To pull historical bank statements:

1.  Go to *Invoicing \> Configuration \> Accounting \> Journals*.
2.  Select the journal representing your bank account.
3.  Launch *Actions \> Online Bank Statements Pull Wizard*
4.  Configure date interval and click on *Pull*.

If historical data is not needed, then just simply wait for the
scheduled activity "Pull Online Bank Statements" to be executed for
getting new transactions.
