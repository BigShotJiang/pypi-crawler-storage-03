class DH5Error(Exception):
    pass


class DH5Warning(Warning):
    pass
