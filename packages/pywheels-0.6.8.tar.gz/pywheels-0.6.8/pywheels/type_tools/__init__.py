from .basic import is_same_type
from .basic import is_hashable


__all__ = [
    "is_same_type",
    "is_hashable",
]