from setuptools import setup, find_packages
setup(
    name="ghsdjflgshkfglksliurthertgbhwrtgkwherktg",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    author="Cove Allen",
    description="a bunch of functions",
    url="",
    license="MIT",
)

