from functions import hello
def test_hello():
    assert hello("jason") == "hello, jason!"