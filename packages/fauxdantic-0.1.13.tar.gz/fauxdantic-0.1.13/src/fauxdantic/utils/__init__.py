"""Utility functions for fauxdantic."""

from .unique import generate_unique_string, process_unique_value

__all__ = ["generate_unique_string", "process_unique_value"]
