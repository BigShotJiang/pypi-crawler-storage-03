def main() -> None:
    print("Hello from lhs-mcp-demo-lhs!")
