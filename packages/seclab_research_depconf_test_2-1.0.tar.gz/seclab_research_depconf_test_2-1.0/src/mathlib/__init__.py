
def one_plus_one():
    return 1+1