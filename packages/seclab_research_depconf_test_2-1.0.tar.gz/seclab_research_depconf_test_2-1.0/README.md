# Very Useful Math Library

Example code:
```py
import mathlib

print(mathlib.one_plus_one()) # 2
```