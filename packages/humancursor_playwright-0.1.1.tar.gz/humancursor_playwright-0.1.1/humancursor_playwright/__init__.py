from humancursor_playwright.playwright_cursor import PlaywrightCursor

__version__ = "0.1.1"
__author__ = "HumanCursor Playwright Fork"
__description__ = "A Playwright adaptation of HumanCursor for human-like mouse movements"

__all__ = ["PlaywrightCursor"]