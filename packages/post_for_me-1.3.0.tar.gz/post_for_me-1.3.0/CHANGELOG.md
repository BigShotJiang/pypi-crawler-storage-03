# Changelog

## 1.3.0 (2025-08-23)

Full Changelog: [v1.2.0...v1.3.0](https://github.com/DayMoonDevelopment/post-for-me-python/compare/v1.2.0...v1.3.0)

### Features

* **api:** api update ([4df930e](https://github.com/DayMoonDevelopment/post-for-me-python/commit/4df930e52adb15b936da8904ef96cc4bad0eb514))
* **api:** api update ([6ea412d](https://github.com/DayMoonDevelopment/post-for-me-python/commit/6ea412d4d3d1a55b72ad469c8d581022412e51fb))
* **api:** manual updates ([2701154](https://github.com/DayMoonDevelopment/post-for-me-python/commit/2701154f62b4737d3627857402274ae651a4c887))
* **api:** manual updates ([32e52f7](https://github.com/DayMoonDevelopment/post-for-me-python/commit/32e52f7e35b0ab14ac1e7bd0f2b7a17c9cc9e59f))

## 1.2.0 (2025-08-22)

Full Changelog: [v1.1.0...v1.2.0](https://github.com/DayMoonDevelopment/post-for-me-python/compare/v1.1.0...v1.2.0)

### Features

* **api:** api update ([150ee93](https://github.com/DayMoonDevelopment/post-for-me-python/commit/150ee93ecb5e62f045ac04e08aad624c07ae5cf6))


### Chores

* update github action ([ed866c4](https://github.com/DayMoonDevelopment/post-for-me-python/commit/ed866c48e9898609bad238f2d47aa1e4e125a804))

## 1.1.0 (2025-08-18)

Full Changelog: [v1.0.0...v1.1.0](https://github.com/DayMoonDevelopment/post-for-me-python/compare/v1.0.0...v1.1.0)

### Features

* **api:** api update ([9c37a21](https://github.com/DayMoonDevelopment/post-for-me-python/commit/9c37a21cb008f41f2be8dfff0f9bf6e12d4ba865))

## 1.0.0 (2025-08-14)

Full Changelog: [v0.1.0-alpha.2...v1.0.0](https://github.com/DayMoonDevelopment/post-for-me-python/compare/v0.1.0-alpha.2...v1.0.0)

### Chores

* update SDK settings ([b8082a0](https://github.com/DayMoonDevelopment/post-for-me-python/commit/b8082a090eed686047e8cda9fd4dcfaaf3416b23))

## 0.1.0-alpha.2 (2025-08-14)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/DayMoonDevelopment/post-for-me-python/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Features

* **api:** update via SDK Studio ([2331d12](https://github.com/DayMoonDevelopment/post-for-me-python/commit/2331d12316376fdb84e82636557c69817086503f))

## 0.1.0-alpha.1 (2025-08-13)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/DayMoonDevelopment/post-for-me-python/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **mcp:** add logging when environment variable is set ([fa3729c](https://github.com/DayMoonDevelopment/post-for-me-python/commit/fa3729cc7dc412da64ab91400c650fde2029ff77))
* **mcp:** add unix socket option for remote MCP ([ad469be](https://github.com/DayMoonDevelopment/post-for-me-python/commit/ad469bed8e16928a828eb71ba7a4f25f85a25964))
* **mcp:** remote server with passthru auth ([4a1e7fa](https://github.com/DayMoonDevelopment/post-for-me-python/commit/4a1e7fa1254405fb350e3cc5643d7cad6bf7025c))


### Bug Fixes

* **mcp:** avoid sending `jq_filter` to base API ([2ccea1a](https://github.com/DayMoonDevelopment/post-for-me-python/commit/2ccea1a536b05eff112d3c497706b7b5b6f2c5f9))
* **mcp:** fix bug in header handling ([f141333](https://github.com/DayMoonDevelopment/post-for-me-python/commit/f14133320050d375f57364c0b5bb6cfacd6bed06))
* **mcp:** fix tool description of jq_filter ([f485355](https://github.com/DayMoonDevelopment/post-for-me-python/commit/f4853557d14c308bbaa601eb41be0b9958b39db3))
* **mcp:** reverse validJson capability option and limit scope ([4a94629](https://github.com/DayMoonDevelopment/post-for-me-python/commit/4a946292e376954b1ffa7e49ebac76bd1377de11))


### Chores

* configure new SDK language ([31eba50](https://github.com/DayMoonDevelopment/post-for-me-python/commit/31eba503379b0175413bfc7508ef48cef614026b))
* **internal:** codegen related update ([42995ab](https://github.com/DayMoonDevelopment/post-for-me-python/commit/42995ab9247b644c924a7bb50f1b5c4f85b588e4))
* **internal:** move publish config ([146d645](https://github.com/DayMoonDevelopment/post-for-me-python/commit/146d645cfd3ef265d1adcc63486896da68196c3f))
* **internal:** update comment in script ([b70ff74](https://github.com/DayMoonDevelopment/post-for-me-python/commit/b70ff74f4651a5c71a2cf74bf9623c0a93aefb39))
* **mcp:** refactor streamable http transport ([a9f6624](https://github.com/DayMoonDevelopment/post-for-me-python/commit/a9f662465981111532a99a7bc0054c93b1d543e4))
* remove custom code ([2f2e25c](https://github.com/DayMoonDevelopment/post-for-me-python/commit/2f2e25c7d7d1aa0761f0420495fe8748ed6b67f6))
* update @stainless-api/prism-cli to v5.15.0 ([32be444](https://github.com/DayMoonDevelopment/post-for-me-python/commit/32be44479fb81de291c4a2dbc62fc35c64f82bc7))
