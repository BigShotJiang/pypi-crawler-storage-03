knit\_graphs.Course module
==========================

.. automodule:: knit_graphs.Course
   :members:
   :undoc-members:
   :show-inheritance:
