knit\_graphs.artin\_wale\_braids.Wale\_Braid module
===================================================

.. automodule:: knit_graphs.artin_wale_braids.Wale_Braid
   :members:
   :undoc-members:
   :show-inheritance:
