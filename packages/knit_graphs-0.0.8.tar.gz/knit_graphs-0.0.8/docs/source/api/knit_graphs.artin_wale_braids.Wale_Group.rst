knit\_graphs.artin\_wale\_braids.Wale\_Group module
===================================================

.. automodule:: knit_graphs.artin_wale_braids.Wale_Group
   :members:
   :undoc-members:
   :show-inheritance:
