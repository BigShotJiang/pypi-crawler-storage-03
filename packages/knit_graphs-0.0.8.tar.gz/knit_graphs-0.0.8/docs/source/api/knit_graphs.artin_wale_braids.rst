knit\_graphs.artin\_wale\_braids package
========================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   knit_graphs.artin_wale_braids.Crossing_Direction
   knit_graphs.artin_wale_braids.Loop_Braid_Graph
   knit_graphs.artin_wale_braids.Wale
   knit_graphs.artin_wale_braids.Wale_Braid
   knit_graphs.artin_wale_braids.Wale_Braid_Word
   knit_graphs.artin_wale_braids.Wale_Group

Module contents
---------------

.. automodule:: knit_graphs.artin_wale_braids
   :members:
   :undoc-members:
   :show-inheritance:
