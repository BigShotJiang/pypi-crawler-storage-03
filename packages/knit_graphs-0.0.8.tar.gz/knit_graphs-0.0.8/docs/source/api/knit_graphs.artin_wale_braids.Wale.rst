knit\_graphs.artin\_wale\_braids.Wale module
============================================

.. automodule:: knit_graphs.artin_wale_braids.Wale
   :members:
   :undoc-members:
   :show-inheritance:
