knit\_graphs.artin\_wale\_braids.Wale\_Braid\_Word module
=========================================================

.. automodule:: knit_graphs.artin_wale_braids.Wale_Braid_Word
   :members:
   :undoc-members:
   :show-inheritance:
