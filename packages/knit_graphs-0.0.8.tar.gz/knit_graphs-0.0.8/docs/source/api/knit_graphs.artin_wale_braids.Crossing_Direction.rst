knit\_graphs.artin\_wale\_braids.Crossing\_Direction module
===========================================================

.. automodule:: knit_graphs.artin_wale_braids.Crossing_Direction
   :members:
   :undoc-members:
   :show-inheritance:
