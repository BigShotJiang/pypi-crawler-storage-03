Page Explorer
=============
[![CI](https://github.com/MozillaSecurity/page-explorer/actions/workflows/ci.yml/badge.svg)](https://github.com/MozillaSecurity/page-explorer/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/MozillaSecurity/page-explorer/branch/main/graph/badge.svg)](https://codecov.io/gh/MozillaSecurity/page-explorer)
[![Matrix](https://img.shields.io/badge/chat-%23fuzzing-green?logo=matrix)](https://matrix.to/#/#fuzzing:mozilla.org)
[![PyPI](https://img.shields.io/pypi/v/page-explorer)](https://pypi.org/project/page-explorer)

Page Explorer facilitates content interactions via instructions.

See [Site-Scout](//github.com/MozillaSecurity/site-scout) to see it in action.
