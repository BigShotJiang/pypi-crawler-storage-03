# EndpointProbeConnectionScore


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**score** | **float** | A fine-grained score between 0 and 100. | [optional] 
**quality** | [**ApplicationScoreQuality**](ApplicationScoreQuality.md) |  | [optional] 

## Example

```python
from thousandeyes_sdk.endpoint_test_results.models.endpoint_probe_connection_score import EndpointProbeConnectionScore

# TODO update the JSON string below
json = "{}"
# create an instance of EndpointProbeConnectionScore from a JSON string
endpoint_probe_connection_score_instance = EndpointProbeConnectionScore.from_json(json)
# print the JSON string representation of the object
print(EndpointProbeConnectionScore.to_json())

# convert the object into a dict
endpoint_probe_connection_score_dict = endpoint_probe_connection_score_instance.to_dict()
# create an instance of EndpointProbeConnectionScore from a dict
endpoint_probe_connection_score_from_dict = EndpointProbeConnectionScore.from_dict(endpoint_probe_connection_score_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


