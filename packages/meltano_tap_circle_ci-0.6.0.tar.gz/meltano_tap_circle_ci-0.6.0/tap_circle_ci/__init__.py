"""CircleCI Singer tap package."""
