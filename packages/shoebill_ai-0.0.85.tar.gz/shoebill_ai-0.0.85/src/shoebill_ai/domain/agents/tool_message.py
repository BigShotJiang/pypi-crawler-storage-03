
class ToolMessage:
    method_name: str
    method_params: dict