"""
Index module contains components that allow you to group you `Spaces` into indices.
These indices will be saved and allow you to  efficiently search you embedded data.
"""
