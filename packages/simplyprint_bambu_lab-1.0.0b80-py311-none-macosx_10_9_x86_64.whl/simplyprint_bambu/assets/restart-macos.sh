#!/bin/sh
loadctl
