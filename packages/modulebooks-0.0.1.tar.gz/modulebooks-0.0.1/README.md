# modulebooks

A sample Python package for modulebooks.

## Installation

```bash
pip install modulebooks
