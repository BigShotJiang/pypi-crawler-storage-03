> [!NOTE]
> Veuillez [cliquer ici](https://funstory-ai.github.io/BabelDOC/supported_languages/) pour accéder à la page *Langues supportées par BabelDOC*. Les informations présentes s'appliquent également à pdf2zh.

<div align="right"> 
<h6><small>Une partie du contenu de cette page a été traduite par GPT et peut contenir des erreurs.</small></h6>