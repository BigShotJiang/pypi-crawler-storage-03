### Erweiterte Optionen

Dieser Abschnitt richtet sich an fortgeschrittene Benutzer dieser Software. Hier finden Sie:

1. [**Erweiterte Optionen**](./advanced.md)
<br>
In diesem Abschnitt können Sie spezifische Quell-/Zielsprachen erkunden, Übersetzungsdienste wechseln und mehr.

2. [**Sprachcode**](./Language-Codes.md)
<br>
Wenn Sie unsicher sind, welche Codes Sie für die Übersetzung Ihrer Quell-/Zielsprachen verwenden sollen, können Sie diese hier finden.

3. [**Dokumentation der Übersetzungsdienste**](./Documentation-of-Translation-Services.md)
<br>
Wenn Sie die Dokumentation der von Ihnen verwendeten Übersetzungsdienste überprüfen müssen, lesen Sie bitte diese Seite.

<div align="right"> 
<h6><small>Ein Teil des Inhalts dieser Seite wurde von GPT übersetzt und kann Fehler enthalten.</small></h6>