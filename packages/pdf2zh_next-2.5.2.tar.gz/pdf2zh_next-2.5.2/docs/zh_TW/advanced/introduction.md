### 高級選項

本節適用於本軟體的高級用戶。在此您可以找到：

1. [**高級選項**](./advanced.md)
<br>
在本節中，您可以探索指定來源/目標語言、切換翻譯服務等更多選項。

2. [**語言代碼**](./Language-Codes.md)
<br>
如果不確定要使用哪些代碼來翻譯您的源語言/目標語言，可以在這裡找到它們。

3. [**翻譯服務文檔**](./Documentation-of-Translation-Services.md)
<br>
如果您需要查看您所使用的翻譯服務提供的文檔，請參考此頁面。

<div align="right"> 
<h6><small>Some content on this page has been translated by GPT and may contain errors.</small></h6>