[**Opções avançadas**](./introduction.md) > **Documentação dos serviços de tradução** _(atual)_

---

### Visualizando Serviços de Tradução Disponíveis via Linha de comando

Você pode confirmar os serviços de tradução disponíveis e seu uso imprimindo a mensagem de ajuda na linha de comando.

```bash
pdf2zh_next -h
```

No final da mensagem de ajuda, você pode visualizar informações detalhadas sobre os diferentes serviços de tradução.

<div align="right"> 
<h6><small>Parte do conteúdo desta página foi traduzida pelo GPT e pode conter erros.</small></h6>