> [!NOTE]
> Пожалуйста, [нажмите здесь](https://funstory-ai.github.io/BabelDOC/supported_languages/), чтобы перейти на страницу *Поддерживаемые языки BabelDOC*. Информация там также применима к pdf2zh.

<div align="right"> 
<h6><small>Часть содержимого этой страницы была переведена GPT и может содержать ошибки.</small></h6>