"""
This sub-package holds adapters that require heavy optional deps.
Import only what you need, e.g.:

    from pydapter.extras.pandas_ import DataFrameAdapter
"""
