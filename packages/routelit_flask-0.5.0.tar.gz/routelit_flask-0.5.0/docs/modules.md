::: adapter.RouteLitFlaskAdapter
::: adapter.RunMode
::: request.FlaskRLRequest
