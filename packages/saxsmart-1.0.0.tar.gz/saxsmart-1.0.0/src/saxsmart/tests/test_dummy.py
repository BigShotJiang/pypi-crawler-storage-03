def test_import_package():
    import saxsmart  # noqa: F401
