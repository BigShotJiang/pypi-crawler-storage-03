This module allows usage of LLM chatbots inside Odoo.

The logic of the chatbot should be defined in an external system like n8n.
