<!---
################################################################
#                                                              #
#  This file is part of RealityScanMock                        #
#                                                              #
#      https://github.com/basejumpa/RealityScanMock            #
#                                                              #
#  Copyright (c) 2025 Alexander Mann-Wahrenberg (basejumpa)    #
#                                                              #
#  License                                                     #
#                                                              #
#  - MIT for contents used as software                         #
#                                                              #
################################################################
-->

# RealityScanMock

Mock of REST-API of RealityScan Node (fka Reality Capture rc node)

The REST-API is documented at https://rshelp.capturingreality.com/en-US/tools/api.htm

