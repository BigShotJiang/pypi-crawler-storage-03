################################################################
#                                                              #
#  This file is part of RealityScanMock                        #
#                                                              #
#      https://github.com/basejumpa/RealityScanMock            #
#                                                              #
#  Copyright (c) 2025 Alexander Mann-Wahrenberg (basejumpa)    #
#                                                              #
#  License                                                     #
#                                                              #
#  - MIT for contents used as software                         #
#                                                              #
################################################################

print('RealityScanMock')

