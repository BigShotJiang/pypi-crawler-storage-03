"""Groq CLI Agent - Interactive command-line interface for Groq API."""

__version__ = "0.1.2"
__author__ = "tmnabeel30"
__description__ = "Interactive CLI agent for Groq API with chat, model selection, and file diff capabilities"
