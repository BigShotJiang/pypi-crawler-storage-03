from __future__ import annotations


class Ising:
    """TODO: Not implemented yet."""

    # Every entry represents a coefficient of the qubo matrix
    # _Q: dict[int, dict[int, int]]
