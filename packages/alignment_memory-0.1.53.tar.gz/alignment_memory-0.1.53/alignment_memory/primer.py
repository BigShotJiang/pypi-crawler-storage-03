from __future__ import annotations

from typing import Any

PRIMER: dict[str, Any] = {"version": "v1", "ai_compass": {}}
