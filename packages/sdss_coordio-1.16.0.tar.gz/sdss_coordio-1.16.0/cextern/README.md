# External C libraries

The following libraries are included:

- [Standards of Fundamental Astronomy](http://www.iausofa.org/) (SOFA) C library, release 16 (2020-07-21). Only the source files are included to limit the size. The full library, including the PDF manual, can be downloaded [here](http://www.iausofa.org/current_C.html#Downloads).
