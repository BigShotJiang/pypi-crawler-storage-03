import click


@click.command()
def main() -> None:
    """Times the given command.

    TODO: consider ways of making this fancier.
      - Print memory usage?
      - Recurrent?
    """
