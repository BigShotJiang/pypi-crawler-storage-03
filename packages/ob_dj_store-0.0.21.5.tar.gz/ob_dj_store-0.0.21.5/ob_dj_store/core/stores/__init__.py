default_app_config = "ob_dj_store.core.stores.apps.StoresConfig"
