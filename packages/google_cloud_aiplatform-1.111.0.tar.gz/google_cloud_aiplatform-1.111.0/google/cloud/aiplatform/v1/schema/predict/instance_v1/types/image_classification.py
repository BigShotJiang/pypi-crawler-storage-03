# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore


__protobuf__ = proto.module(
    package="google.cloud.aiplatform.v1.schema.predict.instance",
    manifest={
        "ImageClassificationPredictionInstance",
    },
)


class ImageClassificationPredictionInstance(proto.Message):
    r"""Prediction input format for Image Classification.

    Attributes:
        content (str):
            The image bytes or Cloud Storage URI to make
            the prediction on.
        mime_type (str):
            The MIME type of the content of the image.
            Only the images in below listed MIME types are
            supported.
            - image/jpeg
            - image/gif
            - image/png
            - image/webp
            - image/bmp
            - image/tiff
            - image/vnd.microsoft.icon
    """

    content: str = proto.Field(
        proto.STRING,
        number=1,
    )
    mime_type: str = proto.Field(
        proto.STRING,
        number=2,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
