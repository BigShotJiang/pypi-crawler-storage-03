"""Tests that communicate with hugging_face plugin via the v3 API."""
