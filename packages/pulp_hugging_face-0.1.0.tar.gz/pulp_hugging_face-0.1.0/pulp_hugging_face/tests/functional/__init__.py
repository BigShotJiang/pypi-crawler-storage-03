"""Tests for hugging_face plugin."""
