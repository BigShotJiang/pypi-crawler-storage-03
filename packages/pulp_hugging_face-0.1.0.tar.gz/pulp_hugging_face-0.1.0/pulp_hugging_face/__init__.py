default_app_config = "pulp_hugging_face.app.PulpHuggingFacePluginAppConfig"
