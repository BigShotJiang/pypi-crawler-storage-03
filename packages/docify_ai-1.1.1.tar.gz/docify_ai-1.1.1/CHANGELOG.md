## 1.1.1 - 2025-08-20
- fixed project description not visible issue

## 1.1.0 - 2025-08-20
- ✨ Added support for OpenAI + Gemini clients
- 🛠 Added `--key` argument to provide api key, without setting it as environment variable.
- 🔍 Case-insensitive `--client` option

## 1.0.0 - 2025-08-15
- 🚀 Initial release
