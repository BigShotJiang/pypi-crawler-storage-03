# -*- coding:utf-8 -*-
from __future__ import unicode_literals

from django.contrib.contenttypes.fields import GenericForeignKey
from django.db import models
from django.utils.functional import cached_property
from django.contrib.auth.models import User
from six import text_type
from xyz_util import modelutils
from . import choices
from copy import deepcopy

EXAM_MIN_PASS_SCORE = 70


class Paper(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "试卷"
        ordering = ('-is_active', 'order_number', '-create_time',)

    user = models.ForeignKey(User, verbose_name=User._meta.verbose_name, related_name="exam_papers",
                             on_delete=models.PROTECT)
    title = models.CharField("标题", max_length=255, blank=False)
    create_time = models.DateTimeField("创建时间", auto_now_add=True)
    is_active = models.BooleanField("有效", blank=False, default=True)
    questions_count = models.PositiveSmallIntegerField("题数", blank=True, default=0)
    tags = models.CharField('标签', max_length=256, blank=True, default='')
    is_editable = models.BooleanField('可编辑', blank=True, default=True)
    order_number = models.PositiveIntegerField('序号', default=0, blank=True, help_text='按数字从小到大排序')
    owner_type = models.ForeignKey('contenttypes.ContentType', verbose_name='归类', null=True, blank=True,
                                   on_delete=models.PROTECT)
    owner_id = models.PositiveIntegerField(verbose_name='属主编号', null=True, blank=True, db_index=True)
    owner = GenericForeignKey('owner_type', 'owner_id')
    parent_id = models.PositiveIntegerField('父级ID', default=0, blank=True)

    def __str__(self):
        return self.title

    def save(self, **kwargs):
        if not self.title:
            self.title = "试卷"
        return super(Paper, self).save(**kwargs)


class Content(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "内容"

    paper = models.OneToOneField(Paper, on_delete=models.CASCADE)
    source = models.TextField("源文", blank=True, null=True,
                               help_text="编辑指南:\n首行为标题.\n题型用中文数字加点号开头.\n题目用阿拉伯数字加点号开头.\n答案选项用英文字母加点号开头.\n正确答案用'答案:'开头")
    data = modelutils.JSONField("数据", blank=True, null=True, help_text="")

    def __str__(self):
        return text_type(self.paper)


class Stat(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "统计"

    paper = models.OneToOneField(Paper, verbose_name=Paper._meta.verbose_name, related_name="stat",
                                 on_delete=models.PROTECT)
    detail = modelutils.JSONField("详情", help_text="")

    def __str__(self):
        return "统计<%s>" % self.paper

    def add_answer(self, answer):
        d = self.detail or {}
        from . import helper
        questions = d.setdefault('questions', {})
        score_level = str(answer.performance.get('stdScore', 0) / 5 * 5)
        helper.distrib_count(d.setdefault('scores', {}), score_level)
        seconds_level = str((answer.seconds / 30 + 1) * 30)
        helper.distrib_count(d.setdefault('seconds', {}), seconds_level, reverse=True)
        ad = answer.detail
        for a in ad:
            num = str(a.get('number'))
            questions[num] = questions.setdefault(num, 0) + (a.get('right') is False and 1 or 0)
        d['answer_user_count'] = self.paper.answers.values('user').distinct().count()
        self.detail = d


class Answer(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "用户答卷"
        ordering = ('-create_time',)

    user = models.ForeignKey(User, verbose_name=User._meta.verbose_name, related_name="exam_answers",
                             on_delete=models.PROTECT)
    paper = models.ForeignKey(Paper, verbose_name=Paper._meta.verbose_name, related_name="answers",
                              on_delete=models.PROTECT)
    detail = modelutils.JSONField("详情", help_text="")
    grade_detail = modelutils.JSONField("批卷", blank=True, help_text="")
    pictures = modelutils.JSONField("图片", blank=True, default={})
    seconds = models.PositiveIntegerField("用时", default=0, blank=True, null=True, help_text="单位(秒)")
    std_score = models.PositiveSmallIntegerField("分数", default=0, blank=True, null=True)
    performance = modelutils.JSONField("成绩表现", blank=True, null=True, help_text="")
    create_time = models.DateTimeField("创建时间", auto_now_add=True, db_index=True)

    def __str__(self):
        return "%s by %s" % (self.paper, self.user.get_full_name())


    def save(self, **kwargs):
        if not self.grade_detail:
            self.grade_detail = {}
        self.performance = self.cal_performance()
        self.std_score = self.performance.get('stdScore')
        return super(Answer, self).save(**kwargs)

    def get_question_subjective_map(self):
        p = self.paper.content.data
        m = {}
        for g in p['groups']:
            is_subjective = False
            for q in g['questions']:
                if q.get('type') in ['textarea', 'sentence']:
                    is_subjective = True
                    break
            for q in g['questions']:
                m[q['number']] = is_subjective
        return m

    def cal_performance(self):
        wc = 0
        rc = 0
        score = 0
        score_subjective = 0
        score_objective = 0
        fsc = 0

        sm = self.get_question_subjective_map()

        for a in self.detail:
            if a['right'] is True:
                rc += 1
            else:
                wc += 1
            is_subjective = sm.get(a['number'])
            sc = a['userScore']
            if is_subjective:
                score_subjective += sc
            else:
                score_objective += sc
            score += sc
            fsc += a['score']
        stdScore = score * 100 / fsc if fsc > 0 else 0

        ms = self.cal_merge_score()
        format = lambda a: int(round(a))  # float('%.1f' % a)
        return dict(
            wrongCount=wc,
            rightCount=rc,
            fullScore=fsc,
            score=format(score),
            stdScore=format(stdScore),
            scoreSubjective=format(score_subjective),
            scoreObjective=format(score_objective),
            isPassed=stdScore >= EXAM_MIN_PASS_SCORE,
            scoreMerge=format(ms),
            stdScoreMerge=format(ms * 100 / fsc if fsc > 0 else 0)
        )

    def cal_group_score(self):
        p = self.paper.content.data
        m = {}
        d = self.detail
        if not d:
            return m
        ld = len(d)
        for g in p['groups']:
            gs = 0
            for q in g['questions']:
                n = q['number']
                if n>ld:
                    continue
                gs += d[n-1]['userScore']
            m[g['id']] = gs
        return m

    def merge_group_score(self):
        m = self.cal_group_score()
        gm = deepcopy(self.grade_detail)
        for k, v in m.items():
            if k in gm:
                continue
            gm[k] = dict(score=m[k])
        return gm

    def cal_merge_score(self):
        gm = self.merge_group_score()
        return sum([v['score'] for k, v in gm.items()])


class Performance(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "用户成绩"
        unique_together = ('user', 'paper')
        ordering = ('-create_time',)

    user = models.ForeignKey(User, verbose_name=User._meta.verbose_name, related_name="exam_performances",
                             on_delete=models.PROTECT)
    paper = models.ForeignKey(Paper, verbose_name=Paper._meta.verbose_name, related_name="performances",
                              on_delete=models.PROTECT)
    user_name = models.CharField("用户名", max_length=255, null=False, blank=True, default='')
    paper_name = models.CharField("试卷名称", max_length=255, null=False, blank=True, default='')
    score = models.PositiveSmallIntegerField("得分", default=0, blank=True, null=True)
    detail = modelutils.JSONField("详情", blank=True, null=True, help_text="")
    create_time = models.DateTimeField("创建时间", auto_now_add=True)
    update_time = models.DateTimeField("更新时间", auto_now=True)

    def __str__(self):
        return "%s by %s" % (self.paper_name, self.user_name)

    # @cached_property
    # def is_passed(self):
    #     return self.detail.get('maxScore') >= EXAM_MIN_PASS_SCORE if self.paper.is_break_through else True

    def cal_performance(self):
        answers = self.paper.answers.filter(user=self.user)
        scs = [a.performance.get('stdScore', 0) for a in answers]
        lastAnswer = answers.first()
        times = len(scs)
        return dict(
            maxScore=max(scs),
            minScore=min(scs),
            avgScore=sum(scs) / times,
            lastScore=scs[0],
            times=times,
            scores=scs,
            lastTime=lastAnswer and lastAnswer.create_time.isoformat()
        )

    def get_user_info(self):
        u = self.user
        if hasattr(u, 'as_school_student'):
            s = u.as_school_student
            return {'number': s.number, 'group': text_type(s.classes.first())}
        return {}

    def save(self, **kwargs):
        p = self.cal_performance()
        p['userInfo'] = self.get_user_info()
        p['paperInfo'] = {'group': text_type(self.paper.owner)}
        self.paper_name = self.paper.title
        self.user_name = self.user.get_full_name()
        self.detail = p
        self.score = p.get('maxScore', 0)
        return super(Performance, self).save(**kwargs)


class Fault(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "错题"
        unique_together = ('user', 'paper', 'question_id')
        ordering = ('-create_time',)

    user = models.ForeignKey(User, verbose_name=User._meta.verbose_name, related_name="exam_faults",
                             on_delete=models.PROTECT)
    paper = models.ForeignKey(Paper, verbose_name=Paper._meta.verbose_name, related_name="faults",
                              on_delete=models.PROTECT)
    question_id = models.CharField("题号", max_length=16)
    question_type = models.PositiveSmallIntegerField("类别", choices=choices.CHOICES_QUESTION_TYPE,
                                                     default=choices.QUESTION_TYPE_TEXTAREA, db_index=True)
    question = modelutils.JSONField("题目")
    times = models.PositiveSmallIntegerField("次数", default=1)
    detail = modelutils.JSONField("详情")
    correct_straight_times = models.PositiveSmallIntegerField("连续答对次数", default=0)
    corrected = models.BooleanField("已订正", default=False)
    is_active = models.BooleanField("有效", blank=False, default=True)
    create_time = models.DateTimeField("创建时间", auto_now_add=True, db_index=True)
    update_time = models.DateTimeField("更新时间", auto_now=True)

    def __str__(self):
        return "%s@%s by %s" % (self.question_id, self.paper, self.user)

    def save(self, **kwargs):
        from . import helper
        self.correct_straight_times = helper.cal_correct_straight_times(self.detail.get('result_list', []))
        return super(Fault, self).save(**kwargs)


class Exam(models.Model):
    class Meta:
        verbose_name_plural = verbose_name = "考试"
        ordering = ('-is_active', '-begin_time')

    name = models.CharField('名称', max_length=256)
    begin_time = models.DateTimeField('开始时间', db_index=True)
    end_time = models.DateTimeField('结束时间', db_index=True, null=True, blank=True)
    minutes = models.PositiveSmallIntegerField('限时(分钟)', default=60)
    is_active = models.BooleanField("有效", blank=False, default=False)
    target_user_tags = models.TextField('目标人群标签', null=True, blank=True,
                                        help_text="符合标签的人才能填写问卷,留空则所有人均可填写但不会发个人通知.<p>"
                                                  "例子:<p>老师:张三,李四,赵五<p>学生:*<p>学生.年级:大一,大二<p>学生.入学届别:2019届<p>学生.班级:2018级数字媒体201801班,2018级数字媒体201804班")
    target_user_count = models.PositiveIntegerField('目标参与人数', default=0, blank=True)
    actual_user_count = models.PositiveIntegerField('实际参与人数', default=0, blank=True, null=True)
    target_users = models.ManyToManyField(User, verbose_name='参与人', related_name='exams')
    create_time = models.DateTimeField("创建时间", auto_now_add=True)
    update_time = models.DateTimeField("更新时间", auto_now=True)
    tags = models.CharField("标记", max_length=64, blank=True, default="")
    question_filter = modelutils.JSONField("选题条件", default={})
    question_count = models.PositiveSmallIntegerField('题目数', blank=True, default=0)
    types = models.JSONField('题类设置', blank=True, default=dict)
    manual_grade = models.BooleanField("人工评分", blank=True, default=False)
    owner_type = models.ForeignKey('contenttypes.ContentType', verbose_name='归类', null=True, blank=True,
                                   on_delete=models.PROTECT)
    owner_id = models.PositiveIntegerField(verbose_name='属主编号', null=True, blank=True, db_index=True)
    owner = GenericForeignKey('owner_type', 'owner_id')
    user = models.ForeignKey(User, verbose_name='创建人', related_name='create_exams', null=True, on_delete=models.PROTECT)

    def __str__(self):
        return self.name

    def get_target_user_ids(self):
        from xyz_auth.helper import find_user_ids_by_tag
        tags = self.target_user_tags
        if tags:
            return set(find_user_ids_by_tag(tags))
        return set()

    def get_actual_user_ids(self):
        return self.paper and set(self.paper.answers.values_list("user_id", flat=True)) or set()

    @cached_property
    def actual_user_names(self):
        from xyz_auth.helper import get_user_names_by_ids
        ids = self.get_actual_user_ids()
        return get_user_names_by_ids(ids)

    @cached_property
    def target_user_names(self):
        from xyz_auth.helper import get_user_names_by_ids
        ids = self.get_target_user_ids()
        return get_user_names_by_ids(ids)

    @cached_property
    def absent_user_names(self):
        from xyz_auth.helper import get_user_names_by_ids
        tids = self.get_target_user_ids()
        aids = self.get_actual_user_ids()
        return get_user_names_by_ids(set(tids).difference(set(aids)))

    @cached_property
    def paper(self):
        from django.contrib.contenttypes.models import ContentType
        return Paper.objects.filter(owner_type=ContentType.objects.get_for_model(Exam), owner_id=self.id).first()

    def get_not_answer_user_ids(self):
        return self.get_target_user_ids().difference(self.get_actual_user_ids())

    @cached_property
    def answers(self):
        return self.paper.answers.all()

    def performance(self):
        rs = []
        for a in self.answers:
            d = {}
            d.update(a.performance)
            user = a.user
            if hasattr(user, 'as_school_student'):
                student = user.as_school_student
                d['group'] = text_type(student.classes.first())
                d['number'] = student.number
                d['name'] = student.name
            rs.append(d)
        return rs

    def cal_answers_score(self):
        for a in self.paper.answers.all():
            print(a.id)
            a.save()
            print(a.performance)

    def gen_paper(self, questions, **kwargs):
        for i, q in enumerate(questions):
            n = q['number'] = i + 1
            q['id'] = 'g1q%d' % (n)
        from django.contrib.contenttypes.models import ContentType
        paper, created = Paper.objects.update_or_create(
            owner_id=self.pk,
            owner_type=ContentType.objects.get_for_model(self),
            defaults=dict(
                title=self.name,
                questions_count=len(questions),
                tags=self.tags,
                is_editable=False,
                is_active=True,
                **kwargs
            )
        )
        if paper.answers.exists():
            raise RuntimeError("can't modify paper content while paper already got answers")
        content, created = Content.objects.update_or_create(
            paper=paper,
            data=dict(
                groups=[
                    {
                        'title': '选择题',
                        'number': 1,
                        'id': 'g0',
                        'questions': questions
                    }
                ]
            )
        )

    def generate_paper(self, paper_data, **kwargs):
        from django.contrib.contenttypes.models import ContentType
        paper, created = Paper.objects.update_or_create(
            owner_id=self.pk,
            owner_type=ContentType.objects.get_for_model(self),
            defaults=dict(
                title=self.name,
                questions_count=sum([len(g['questions']) for g in paper_data['groups']]),
                tags=self.tags,
                is_editable=False,
                is_active=True,
                **kwargs
            )
        )
        if paper.answers.exists():
            raise RuntimeError("can't modify paper content while paper already got answers")
        content, created = Content.objects.update_or_create(
            paper=paper,
            data=paper_data
        )

    def save(self, **kwargs):
        if not self.minutes:
            self.minutes = 60
        if self.end_time is None:
            from datetime import timedelta
            self.end_time = self.begin_time + timedelta(minutes=self.minutes)
        uids = self.get_target_user_ids()
        self.target_user_count = len(uids)
        if self.actual_user_count is None:
            self.actual_user_count = 0
        super(Exam, self).save(**kwargs)
        self.target_users.set(User.objects.filter(id__in=uids))
        self.actual_user_count = len(self.get_actual_user_ids())
