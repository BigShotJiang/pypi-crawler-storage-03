Example setups for different fields, prior to new config setup
