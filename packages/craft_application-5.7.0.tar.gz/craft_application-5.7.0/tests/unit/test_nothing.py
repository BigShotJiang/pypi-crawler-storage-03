def test_pass():
    """No-op test so unit tests pass"""
