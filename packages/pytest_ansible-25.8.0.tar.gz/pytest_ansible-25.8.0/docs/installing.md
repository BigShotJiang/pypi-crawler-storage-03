# Installing

## Requirements

- Ansible 2.9 or newer
- Pytest

## Installing the latest version

You can install the most recent version of pytest-ansible with the [pip] Python
package manager.

```shell
pip install pytest-ansible
```

Install this plugin using `pip`:

```shell
pip install pytest-ansible
```
