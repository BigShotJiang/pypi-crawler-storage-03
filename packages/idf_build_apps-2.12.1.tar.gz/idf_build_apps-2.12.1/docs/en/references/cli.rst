###############
 CLI Reference
###############

.. note::

   All CLI options could be defined in the config file. For more information, please refer to the :doc:`Config File Reference <./config_file>`.

.. argparse::
   :ref: idf_build_apps.main.get_parser
   :prog: idf-build-apps
