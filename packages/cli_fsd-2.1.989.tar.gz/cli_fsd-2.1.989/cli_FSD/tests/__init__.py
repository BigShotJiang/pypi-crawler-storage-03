"""Test suite for cli-FSD."""
 