from pathlib import Path

import ha_services


CLI_EPILOG = 'Project Homepage: https://github.com/jedie/ha_services'

BASE_PATH = Path(ha_services.__file__).parent
