class amir():
    def chap(self):
            print(type(self))
            print(self)
amir.chap("h")
