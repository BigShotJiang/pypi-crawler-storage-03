from svix.webhooks import (
    Webhook as SvixWebhook,
    WebhookVerificationError as SvixWebhookVerificationError,
)

Webhook = SvixWebhook
WebhookVerificationError = SvixWebhookVerificationError
