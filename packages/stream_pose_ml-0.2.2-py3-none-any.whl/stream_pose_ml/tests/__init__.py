"""Tests for the stream_pose_ml module."""
