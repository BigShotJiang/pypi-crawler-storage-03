"""
Conftest file for module tests.
"""


# The project root directory is already in the Python path via pip install -e .
