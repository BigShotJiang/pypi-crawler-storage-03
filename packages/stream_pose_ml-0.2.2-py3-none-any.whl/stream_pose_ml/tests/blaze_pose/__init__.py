"""Tests for the blaze_pose module."""
