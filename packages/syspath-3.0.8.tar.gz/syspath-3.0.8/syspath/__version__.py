VERSION = (3, 0, 8)

__version__ = '.'.join(map(str, VERSION))
