from .syspath import append_parent_path


path = append_parent_path(index=4)

if __name__ == "__main__":
    print(path)
