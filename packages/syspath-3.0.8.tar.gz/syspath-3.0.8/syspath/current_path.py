from .syspath import append_current_path


path = append_current_path(index=4)

if __name__ == "__main__":
    print(path)
