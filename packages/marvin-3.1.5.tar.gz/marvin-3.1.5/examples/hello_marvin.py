import marvin

poem = marvin.run("Write a short poem about artificial intelligence")

print(poem)
