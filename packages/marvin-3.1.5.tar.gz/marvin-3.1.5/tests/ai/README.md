Tests in this directory use external LLM models. They are used to test the Marvin framework and ensure that it is working as expected.

To run these tests, use the following command:

```bash
pytest tests/ai
```
