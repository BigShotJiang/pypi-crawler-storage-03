Style Commandments
==================

Read the OpenStack Style Commandments https://docs.openstack.org/hacking/latest/

Mistral Specific Commandments
-----------------------------

- [M001] Use LOG.warning(). LOG.warn() is deprecated.
- [M319] Enforce use of assertTrue/assertFalse
- [M320] Enforce use of assertIs/assertIsNot
