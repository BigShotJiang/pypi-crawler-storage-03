============
mistral.conf
============

The following is a sample mistral configuration for adaptation and use. For a
detailed overview of all available configuration options, refer to
:doc:`/admin/configuration/config-reference`.

The sample configuration can also be viewed in :download:`file form
</_static/mistral.conf.sample>`.

.. important::

   The sample configuration file is auto-generated from mistral when this
   documentation is built. You must ensure your version of mistral matches the
   version of this documentation.

.. only:: html

   .. literalinclude:: /_static/mistral.conf.sample

