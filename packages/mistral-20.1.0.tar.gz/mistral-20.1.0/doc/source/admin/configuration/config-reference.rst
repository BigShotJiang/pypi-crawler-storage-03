=======================
Configuration Reference
=======================

The following is an overview of all available configuration options in Mistral.

.. only:: html

    For a sample configuration file, refer to :doc:`config-sample`.

.. show-options::
    :config-file: tools/config/config-generator.mistral.conf
