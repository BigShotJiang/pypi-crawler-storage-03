=================
Mistral Cookbooks
=================

.. toctree::
    :maxdepth: 2

    cloud_cron
