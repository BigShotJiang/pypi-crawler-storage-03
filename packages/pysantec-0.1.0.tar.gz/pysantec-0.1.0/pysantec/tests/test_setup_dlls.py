# -*- coding: utf-8 -*-
# pysantec/tests/test_setup_dlls.py

"""
Test Setup DLLs functionality.
"""

import pysantec


def test_setup_dlls():
    """Test the setup_dlls function."""
    assert pysantec.setup_dlls_result is True
