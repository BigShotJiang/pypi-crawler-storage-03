
from .users import UserServiceClient as UserServiceClient
from .sellers import SellerServiceClient as SellerServiceClient
from .carts import CartServiceClient as CartServiceClient
from .orders import OrderServiceClient as OrderServiceClient
from .delivery import DeliveryServiceClient as DeliveryServiceClient
from .coupon import CouponServiceClient as CouponServiceClient
from .interactions import InteractionServiceClient as InteractionServiceClient
