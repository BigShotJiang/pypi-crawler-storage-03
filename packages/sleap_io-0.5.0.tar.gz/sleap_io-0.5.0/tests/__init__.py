"""Treat the parent directory as a module."""
