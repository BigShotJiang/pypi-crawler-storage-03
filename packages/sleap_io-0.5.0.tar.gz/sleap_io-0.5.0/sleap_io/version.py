"""This module defines the package version."""

# Define package version.
# This is read dynamically by setuptools in pyproject.toml to determine the release
# version.
__version__ = "0.5.0"
