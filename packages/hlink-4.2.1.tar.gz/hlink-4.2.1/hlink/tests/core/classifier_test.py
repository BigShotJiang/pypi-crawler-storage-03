# This file is part of the ISRDI's hlink.
# For copyright and licensing information, see the NOTICE and LICENSE files
# in this project's top-level directory, and also on-line at:
#   https://github.com/ipums/hlink

import pytest

from hlink.linking.core.classifier import choose_classifier
from hlink.tests.markers import requires_lightgbm, requires_xgboost


@requires_lightgbm
def test_choose_classifier_supports_lightgbm() -> None:
    params = {
        "maxDepth": 7,
        "numIterations": 5,
    }

    classifier, _post_transformer = choose_classifier("lightgbm", params, "match")
    assert classifier.getLabelCol() == "match"


@requires_xgboost
def test_choose_classifier_supports_xgboost():
    """
    If the xgboost module is installed, then choose_classifier() supports a model
    type of "xgboost".
    """
    params = {
        "max_depth": 2,
        "eta": 0.5,
    }
    classifier, _post_transformer = choose_classifier("xgboost", params, "match")
    assert classifier.getLabelCol() == "match"


@pytest.mark.parametrize(
    "classifier", ["random_forest", "decision_tree", "gradient_boosted_trees"]
)
def test_choose_classifier_can_set_seed_in_params(spark, classifier) -> None:
    """
    Ensure that you can pass a "seed" parameter to the classifier. This used to
    cause an error because of manual handling of the seed parameter. See GitHub
    Issue #221.
    """
    params = {"seed": 151015}
    classifier, _post_transformer = choose_classifier(classifier, params, "match")
    assert classifier.getSeed() == 151015
