pytest_plugins = (
    "hlink.tests.plugins.datasources",
    "hlink.tests.plugins.external_data_paths",
)
