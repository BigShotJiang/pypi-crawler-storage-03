# Code of Conduct

- [CNOE Code of Conduct](https://github.com/cnoe-io/governance/blob/main/CODE-OF-CONDUCT.md)
- Violations can be reported to [cnoe-steering@googlegroups.com](mailto:cnoe-steering@googlegroups.com). This email address is monitored by the cnoe steering committee and all reports will remain confidential. 