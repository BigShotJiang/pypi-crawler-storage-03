//! Public transit data model, according to the original Microsoft paper

pub(crate) mod data;
pub(crate) mod types;
