from .analysis import AnalysisType, AnalysisError, MaterialAssignment, Simulation, SolidMaterialAssignment, ShellMaterialAssignment
