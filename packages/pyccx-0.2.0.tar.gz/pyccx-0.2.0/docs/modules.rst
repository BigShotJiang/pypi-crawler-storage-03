.. automodapi:: pyccx.analysis
    :no-inheritance-diagram:
    :no-inherited-members:
    :toctree: api

.. automodapi:: pyccx.bc
    :toctree: api
    :no-inheritance-diagram:
    :no-inherited-members:

.. automodapi:: pyccx.core
    :toctree: api
    :no-inheritance-diagram:
    :no-inherited-members:

.. automodapi:: pyccx.loadcase
    :no-inheritance-diagram:
    :no-inherited-members:
    :toctree: api

.. automodapi:: pyccx.material
    :no-inheritance-diagram:
    :no-inherited-members:
    :toctree: api

.. automodapi:: pyccx.results
    :no-inheritance-diagram:
    :no-inherited-members:
    :toctree: api

.. automodapi:: pyccx.mesh
    :no-inheritance-diagram:
    :no-inherited-members:
    :toctree: api
