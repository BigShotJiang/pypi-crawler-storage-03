use debabelizer_core::DebabelizerError;

pub type Result<T> = std::result::Result<T, DebabelizerError>;