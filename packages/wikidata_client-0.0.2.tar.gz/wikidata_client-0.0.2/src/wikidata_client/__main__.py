"""Entrypoint module, in case you use `python -m wikidata_client`."""

from .cli import main

if __name__ == "__main__":
    main()
