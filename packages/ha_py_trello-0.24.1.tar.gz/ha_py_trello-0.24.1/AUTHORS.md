py-trello was created by [Richard Kolkovich](http://www.sigil.org)

A comprehensive list of contributors can be found [at Github](https://github.com/sarumont/py-trello/graphs/contributors)
