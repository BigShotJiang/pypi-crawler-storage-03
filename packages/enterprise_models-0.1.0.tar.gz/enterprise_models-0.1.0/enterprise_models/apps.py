from django.apps import AppConfig

class MyDjangoModelsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "enterprise_models"
