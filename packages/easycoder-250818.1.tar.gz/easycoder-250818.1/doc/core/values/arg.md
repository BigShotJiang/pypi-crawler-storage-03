# arg

## Syntax:
`arg {n}`

## Examples:
`print arg N`  
`print arg 2`

## Description:
Gets the value of the `{n}`th command-line argument. 

Next: [args](args.md)  
Prev: [weekday](weekday.md)

[Back](../../README.md)
