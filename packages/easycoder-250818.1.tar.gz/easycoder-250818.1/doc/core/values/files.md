# files

## Syntax:
`[the] files in/of {path}`

## Examples:
``print the files in `/home/test` ``

## Description:
Gets a list of all the files in a given directory

Next: [float](float.md)  
Prev: [error](error.md)

[Back](../../README.md)
