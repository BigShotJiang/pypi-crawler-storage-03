# hash

## Syntax:
`hash {text}`

## Examples:
`print hash Text`  
``print hash `This is some text` ``

## Description:
Gets the SHA256 hash of a piece of text.

Next: [index](index.md)  
Prev: [from](from.md)

[Back](../../README.md)
