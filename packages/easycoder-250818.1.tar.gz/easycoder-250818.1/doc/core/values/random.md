# random

## Syntax:
`random {value}`

## Examples:
`print random 100`  
`print random N`

## Description:
Returns a random number btween zero and the specfied limit.

Next: [right](right.md)  
Prev: [property](property.md)

[Back](../../README.md)
