# decrement

## Syntax:
`decrement {variable}`
## Examples:
`decrement N`
## Description:
Decrements the value of the variable by 1. See also [increment](increment.md)

Next: [delete](delete.md)  
Prev: [debug](debug.md)

[Back](../../README.md)
