# lock

## Syntax:
`lock {variable}`

## Examples:
`lock Status`

## Description:
Locks a variable to prevent it being modified. See also [unlock](unlock.md).

Next: [log](log.md)
Prev: [load](load.md)

[Back](../../README.md)
