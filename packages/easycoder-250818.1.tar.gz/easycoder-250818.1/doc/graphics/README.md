# The 'graphics' package

**Documentation yet to be written**

The graphics package contains keywords values and conditionals needed for programming graphical applications.

There are three primary components to the language:

 - Keywords
 - Values
 - Conditions

The core keywords are:



The core values are:



The core conditions are:


[Back](../README.md)
