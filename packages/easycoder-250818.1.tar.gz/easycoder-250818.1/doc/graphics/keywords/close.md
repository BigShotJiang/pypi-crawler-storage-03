## close

## Syntax:
`close window`

## Examples:
`close window`

## Description:
Close the window. This will also terminate the **_EasyCoder_** script.

Next: [create](create.md)  
Prev: [attach](attach.md)

[Back](../../README.md)
