# TorchDire
Feature Rich Library for Building AI Models...

There are many Models and Utils included ,

Python Library :[pypi](https://pypi.org/project/TorchDire/)


Installation :

```bash
pip install TorchDire
```


SWIN_Control_Diff_Seg :[Docs](/TorchDire/models/Swin_Control_diff_seg/README.md)

DDP_Trainer: [Docs](/TorchDire/utils/DDP_Trainer/README.md)
