This module adds the last purchase info of the product. What is shown is the
supplier, date of purchase, and price of the most recently confirmed purchase
order.
