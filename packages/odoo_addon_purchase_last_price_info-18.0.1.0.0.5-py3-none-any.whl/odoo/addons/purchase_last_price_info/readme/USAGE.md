In order to use this module, go to:

- Products -\> Tab Purchase (see screenshot)

![Purchase Last Price Info](../static/description/purchase_last_price.png)
