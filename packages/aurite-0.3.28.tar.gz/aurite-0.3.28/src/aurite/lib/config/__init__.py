"""
Initialization file for the aurite.lib.config package.
"""

from .config_manager import ConfigManager

__all__ = [
    "ConfigManager",
]
