from ..DepthTensor import Tensor, differentiate, random

a = random.uniform(0, 1, (3,))
print(a)