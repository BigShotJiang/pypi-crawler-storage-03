# Generic Metaprompt v2.5
