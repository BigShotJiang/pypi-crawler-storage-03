# this file is @generated

from .common import BaseModel


class PollingEndpointConsumerSeekOut(BaseModel):
    iterator: str
