# this file is @generated

from .common import BaseModel


class SlackConfigOut(BaseModel):
    pass
