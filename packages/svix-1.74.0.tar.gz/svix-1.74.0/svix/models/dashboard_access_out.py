# this file is @generated

from .common import BaseModel


class DashboardAccessOut(BaseModel):
    token: str

    url: str
