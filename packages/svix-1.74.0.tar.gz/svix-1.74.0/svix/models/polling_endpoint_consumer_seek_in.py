# this file is @generated
from datetime import datetime

from .common import BaseModel


class PollingEndpointConsumerSeekIn(BaseModel):
    after: datetime
