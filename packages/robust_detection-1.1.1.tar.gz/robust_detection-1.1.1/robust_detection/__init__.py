print("you have been hacked.")
