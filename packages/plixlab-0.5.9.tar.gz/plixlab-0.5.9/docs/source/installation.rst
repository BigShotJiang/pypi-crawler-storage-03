Installing PlixLab
===================

   
PlixLab can be installed as a PIP package

.. code-block:: bash

   pip install plixlab


Test:

.. code-block:: bash

   python -c 'import plixlab as px; px.Slide().text(r"Welcome to PlixLab!").show()'




