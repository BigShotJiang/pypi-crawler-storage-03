Server Components
=================

Web server components for serving PlixLab presentations.

.. automodule:: plixlab.server
   :members:
