Slide Class
===========

Slide creation with various component types.

.. autoclass:: plixlab.Slide
   :members:
   :show-inheritance:
