from .main import diffParserTab,startDiffGUI
