# Datasets

For training a TTS model, you need a dataset with speech recordings and
transcriptions. See the following pages for more information on:

```{toctree}
:maxdepth: 1

formatting_your_dataset
what_makes_a_good_dataset
tts_datasets
```
