__version__ = '0.4.1'
__author__ = 'Silvia Barbiero, Michael Stadler, Charlotte Soneson'
