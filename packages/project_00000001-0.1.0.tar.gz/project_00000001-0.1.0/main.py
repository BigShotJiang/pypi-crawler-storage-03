def main():
    print("Hello from test-package!")


if __name__ == "__main__":
    main()
