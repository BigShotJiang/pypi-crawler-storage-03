"""
Setup file for statistics-toolkit-cli.

This file is maintained for backwards compatibility.
The main configuration is in pyproject.toml.
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
