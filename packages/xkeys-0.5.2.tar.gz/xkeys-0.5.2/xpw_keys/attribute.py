# coding:utf-8

__project__ = "xkeys"
__version__ = "0.5.2"
__urlhome__ = "https://github.com/bondbox/xkeys/"
__description__ = "Key and Certificate Management"

# author
__author__ = "Mingzhe Zou"
__author_email__ = "zoumingzhe@outlook.com"
