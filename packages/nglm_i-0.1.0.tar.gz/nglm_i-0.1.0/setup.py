from setuptools import setup, find_packages

setup(
        name='nglm-i',
        version='0.1.0',
        description='nglm base build',
        author='Ra K',
        author_email='your.email@example.com',
        packages=find_packages(),
        install_requires=[
            # List any dependencies here, e.g., 'requests>=2.20.0'
        ],
    )