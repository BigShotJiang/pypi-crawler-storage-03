"""
MCP tool registration for Versionator
"""

from .registry_tools import register_versionator_tools

__all__ = ["register_versionator_tools"]
