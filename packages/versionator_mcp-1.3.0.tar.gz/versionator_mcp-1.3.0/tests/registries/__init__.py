"""
Registry-specific tests for Versionator MCP Server
"""
