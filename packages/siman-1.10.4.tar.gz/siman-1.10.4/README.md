Manager for first-principles calculations.  
For manual see wiki tab at [github](https://github.com/dimonaks/siman/wiki) and our [wiki](https://wiki.storion.ru/soft/siman)

If you use this package please cite:  
Aksyonov et. al, *Understanding migration barriers for monovalent ion insertion in transition metal oxide and phosphate based cathode materials: A DFT study*, [Comp. Mat. Sci. 154, 449-458, 2018](https://doi.org/10.1016/j.commatsci.2018.07.057)  

Developers:
 - Dmitry Aksenov
 - Anton Boev
 - Arseniy Burov
 - Nikita Davydov
 - Marina Titarenko

