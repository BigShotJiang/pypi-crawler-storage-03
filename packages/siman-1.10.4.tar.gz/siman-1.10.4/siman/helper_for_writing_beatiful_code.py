#Author: Aksyonov D.A.
"""
Template for doc using markdown markup language [https://daringfireball.net/projects/markdown/]:

Function description;

###INPUT:
    
    - parameter 1 (type) - description
    - parameter 2 (type) - description


###RETURN:
    
    None

###DEPENDS:


"""