from pygdsm import download_map_data

def test_download_map_data():
    download_map_data()

if __name__ == "__main__":
    download_map_data()