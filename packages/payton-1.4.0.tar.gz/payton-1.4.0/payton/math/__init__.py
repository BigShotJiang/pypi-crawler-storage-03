"""
Payton math library

Payton is designed with minimum requirements in mind. So, to reduce the number
of requirements, instead of using 3rd party mathematical libraries, I created
my simple functions here.

This math module has no requirements, so it can be used separately in other
projects.
"""
