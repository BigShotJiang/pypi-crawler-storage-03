from typing import List

Vector3D = List[float]
Vector2D = List[float]
