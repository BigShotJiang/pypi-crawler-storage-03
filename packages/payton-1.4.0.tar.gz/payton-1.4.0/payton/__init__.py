"""
# Payton Library

.. include:: ../README.md
"""

import OpenGL

# OpenGL Error Checking has a great over-head to render cycle
OpenGL.ERROR_CHECKING = False
OpenGL.ERROR_LOGGING = False
