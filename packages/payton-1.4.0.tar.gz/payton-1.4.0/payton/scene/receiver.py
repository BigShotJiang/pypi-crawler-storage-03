class Receiver:
    def __str__(self) -> str:
        return "Scene"
