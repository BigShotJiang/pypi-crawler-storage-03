# inmanta-module-podman

[![pypi version](https://img.shields.io/pypi/v/inmanta-module-podman.svg)](https://pypi.python.org/pypi/inmanta-module-podman/)
[![build status](https://img.shields.io/github/actions/workflow/status/edvgui/inmanta-module-podman/continuous-integration.yml)](https://github.com/edvgui/inmanta-module-podman/actions)

This package is an adapter that is meant to be used with the inmanta orchestrator: https://docs.inmanta.com
