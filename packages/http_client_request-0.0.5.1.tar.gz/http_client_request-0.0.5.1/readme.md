# http.client request extension.

## Installation

You can install via [pypi](https://pypi.org/project/http_client_request/)

```console
pip install -U http_client_request
```

## Usage

```python
from http_client_request import request
```
