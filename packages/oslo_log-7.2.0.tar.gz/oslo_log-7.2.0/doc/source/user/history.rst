.. Add a fake link so that the reference to "assert_" in one of the
   changelog messages that looks like a reST link but isn't has
   something to resolve to.

.. _assert: https://docs.python.org/2/library/unittest.html#unittest.TestCase.assertTrue

.. include:: ../../../ChangeLog
