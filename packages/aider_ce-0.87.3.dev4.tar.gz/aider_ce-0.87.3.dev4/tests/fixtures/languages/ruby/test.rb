def greet(name)
  puts "Hello, #{name}!"
end
