"""Protocol buffer definitions for FootsiesGym."""

# Import the generated protobuf classes for easier access
from .footsies_service_pb2 import *
from .footsies_service_pb2_grpc import *
