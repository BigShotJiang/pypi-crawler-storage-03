from .main import logPaneTab
from ..startConsole import startConsole
def startLogPaneTabConsole():
    startConsole(logPaneTab)
