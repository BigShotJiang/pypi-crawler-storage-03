from .main import launcherWindowTab
from ..startConsole import startConsole
def startLauncherWindowConsole():
    startConsole(launcherWindowTab)
