.. _examples-mass-univariate-statistics:

^^^^^^^^^^^^^^^^^^^^^^^^^^
Mass-Univariate Statistics
^^^^^^^^^^^^^^^^^^^^^^^^^^

With :class:`NDVar` ("n-dimensional variables"), mass-univariate statistics
can be evaluated analogous to univariate statistics.
