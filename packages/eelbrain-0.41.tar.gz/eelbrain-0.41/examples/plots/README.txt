^^^^^^^^
Plotting
^^^^^^^^

Examples illustrating the use of the :mod:`plot` functionality.
