.. -*- mode: rst -*-

Multistream Queries
===================

Refer to :ref:`ArrowMultistreamDocs`.
