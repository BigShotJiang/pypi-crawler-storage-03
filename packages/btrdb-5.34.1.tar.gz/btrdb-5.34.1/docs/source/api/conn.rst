btrdb.conn
=============

.. _Conn info:
.. automodule:: btrdb.conn

.. autoclass:: BTrDB
    :members:
