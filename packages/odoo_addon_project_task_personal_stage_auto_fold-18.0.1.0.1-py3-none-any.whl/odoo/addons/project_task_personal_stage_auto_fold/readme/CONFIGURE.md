The task stages "Done" and "Cancelled" must match the same name as the
equivalent personal stages.

The checkbox “Folded in Kanban” must be checked in the stage configuration.
