When you close a task, its personal stage will change as well.

This module simplifies to close or to cancel a task from the project
stage and the personal stage.

In the case a task is assigned to more than one user, only the personal
task stage of the user will be updated.

Notice: This module don't change the project task stage from the
personal task stage. It is intended so no change about this
functionality is desired or required. Furthermore, also is intended that
only the personal stage of the user who finish the task with the project
task stage will be update. So the other users assigned to the task have
to update the personal task stage manually when they finish it
