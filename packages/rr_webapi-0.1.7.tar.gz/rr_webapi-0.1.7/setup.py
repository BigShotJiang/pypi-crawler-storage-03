"""
Setup script for RaceResult Web API Python Library
Legacy setup.py - pyproject.toml is the preferred configuration
"""

from setuptools import setup

# Use pyproject.toml for configuration
setup()