import sys  # pragma: no coverage

print(f"exec_prefix={sys.exec_prefix}")  # pragma: no coverage
print(f"executable={sys.executable}")  # pragma: no coverage
