"""Plotting backend for the performance framework."""

from ._plot import plot_run

__all__ = ["plot_run"]
