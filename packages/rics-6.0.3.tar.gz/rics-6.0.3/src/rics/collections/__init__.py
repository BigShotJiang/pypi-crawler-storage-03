"""Collection utilities."""
