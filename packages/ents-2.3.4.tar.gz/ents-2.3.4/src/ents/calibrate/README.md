# Performing calibration

TODO: Write these instructions after merging the calibration and python resources.
