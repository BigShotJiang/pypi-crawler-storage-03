CANON_BASENAME = "codebase.harvest.json"
CANON_EXT = ".harvest.json"  # for coarse ignores