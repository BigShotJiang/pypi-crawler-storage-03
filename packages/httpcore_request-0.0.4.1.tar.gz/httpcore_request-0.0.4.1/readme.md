# httpcore request extension.

## Installation

You can install via [pypi](https://pypi.org/project/httpcore_request/)

```console
pip install -U httpcore_request
```

## Usage

```python
from httpcore_request import request
```
