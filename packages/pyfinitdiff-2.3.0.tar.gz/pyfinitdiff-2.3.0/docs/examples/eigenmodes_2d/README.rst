2-dimensional eigenmodes
~~~~~~~~~~~~~~~~~~~~~~~~