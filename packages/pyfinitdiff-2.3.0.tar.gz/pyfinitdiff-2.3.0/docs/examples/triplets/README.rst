triplets computation
~~~~~~~~~~~~~~~~~~~~