*******************
fleck Documentation
*******************

This is the API documentation for fleck.

Reference/API
=============

.. automodapi:: fleck

.. automodapi:: fleck.jax
