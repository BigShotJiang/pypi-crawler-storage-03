"""
Unit tests for interfaces module
"""
