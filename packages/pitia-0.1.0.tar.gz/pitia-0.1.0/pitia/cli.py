from pitia import AssistenteAvancado

def main():
    print("Iniciando Pítia...")
    assistente = AssistenteAvancado()
    assistente.executar()

if __name__ == "__main__":
    main()