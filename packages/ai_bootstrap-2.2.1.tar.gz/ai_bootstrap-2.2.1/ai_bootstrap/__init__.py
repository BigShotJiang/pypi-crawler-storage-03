"""AI Bootstrap - AI-powered project scaffolding with requirement analysis."""

__version__ = "2.1.1"
__author__ = "Soham Chaudhari"
__description__ = "AI-powered project scaffolding with requirement analysis"
