"""{{ project_name }} - Core LangChain Application."""

__version__ = "0.1.0"
