"""Agent modules for the project."""

from .supervisor import supervisor_node

# List your agent modules here
AGENT_MODULES = [
    # "agent1",
    # "agent2",
    # Add more agent module names as needed
]

for agent_name in AGENT_MODULES:
    module = __import__(f".{agent_name}", globals(), locals(), [f"{agent_name}_node"])
    globals()[f"{agent_name}_node"] = getattr(module, f"{agent_name}_node")

__all__ = ["supervisor_node"] + [f"{name}_node" for name in AGENT_MODULES]
