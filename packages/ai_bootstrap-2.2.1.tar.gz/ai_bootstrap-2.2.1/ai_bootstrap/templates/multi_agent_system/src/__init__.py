"""{{ project_name }} - Multi-Agent System."""

__version__ = "0.1.0"
