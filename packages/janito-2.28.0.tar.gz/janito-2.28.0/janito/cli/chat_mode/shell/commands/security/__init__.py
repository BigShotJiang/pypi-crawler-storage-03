"""Security management commands for chat mode."""
