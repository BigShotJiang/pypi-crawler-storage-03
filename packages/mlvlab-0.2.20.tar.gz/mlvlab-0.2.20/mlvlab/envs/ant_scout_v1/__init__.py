from __future__ import annotations

# Namespace del entorno ant_v1 (vía underscore por convención)
