atmodeller.solubility package
=============================

Submodules
----------

atmodeller.solubility.\_carbon\_species module
----------------------------------------------

.. automodule:: atmodeller.solubility._carbon_species
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

atmodeller.solubility.\_hydrogen\_species module
------------------------------------------------

.. automodule:: atmodeller.solubility._hydrogen_species
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

atmodeller.solubility.\_other\_species module
---------------------------------------------

.. automodule:: atmodeller.solubility._other_species
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

atmodeller.solubility.\_sulfur\_species module
----------------------------------------------

.. automodule:: atmodeller.solubility._sulfur_species
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

atmodeller.solubility.core module
---------------------------------

.. automodule:: atmodeller.solubility.core
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

atmodeller.solubility.library module
------------------------------------

.. automodule:: atmodeller.solubility.library
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: atmodeller.solubility
   :members:
   :private-members:
   :show-inheritance:
   :undoc-members:
