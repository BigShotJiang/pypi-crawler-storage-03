#########
Reference
#########

Commands
========

.. argparse::
    :module: ivpm.__main__
    :func: get_parser
    :prog: ivpm



YAML File Format
================

.. jsonschema:: ../../src/ivpm/share/ivpm.json#/defs/package-def

.. jsonschema:: ../../src/ivpm/share/ivpm.json#/defs/dep-set

.. jsonschema:: ../../src/ivpm/share/ivpm.json#/defs/package-dep

