# -*- coding: utf-8 -*-
import sys

# What are XDGs?

XDGS = ('XDG_CONFIG_DIRS', 'XDG_DATA_HOME',
        'XDG_CONFIG_HOME', 'XDG_DATA_DIRS',
                          'XDG_CACHE_HOME',
                          'XDG_STATE_HOME',
                         'XDG_RUNTIME_DIR')

# Some fuckaround dicts

arbitrary = {
    'yo'    : "dogg",
    'i'     : "heard",
    'you'   : "liked",
    'dict'  : "chains"
}

nested = {
	'body': {
		'declare_i': {
			'id': { 'name': 'i', 'type': 'Identifier' },
            'init': { 'type': 'Literal', 'value': 2 },
			'type': 'VariableDeclarator'
		},
        'kind': 'var',
        'type': 'VariableDeclaration',
        'declare_j': {
			'id': { 'name': 'j', 'type': 'Identifier' },
            'init': { 'type': 'Literal', 'value': 4 },
            'type': 'VariableDeclarator'
		},
        'kind': 'var',
        'type': 'VariableDeclaration',
        'declare_answer': {
			'id': { 'name': 'answer', 'type': 'Identifier' },
            'init': {
				'left': { 'name': 'i', 'type': 'Identifier' },
				'operator': '*',
				'right': { 'name': 'j', 'type': 'Identifier' },
				'type': 'BinaryExpression'
			},
			'type': 'VariableDeclarator'
		},
		'kind': 'var',
		'type': 'VariableDeclaration'
	},
	'type':	'Program'
}

flat = {
	'key0': 'yo',
	'key1': 'dogg',
	'key2': 'i_heard',
	'ns0:key3': 'you_like',
	'ns0:ns1:ns2:key4': 'tree',
	'ns0:ns1:ns2:key5': 'structures'
}

# Greek text

GREEKOUT = {}

GREEKOUT['lorem'] = """
Lorem ipsum dolor sit amet, consectetuer adipiscing elit; Aenean commodo ligula
eget dolor! Aenean massa; Cum sociis natoque penatibus et magnis dis parturient
montes, nascetur ridiculus mus? Donec quam felis, ultricies nec, pellentesque
eu, pretium quis, sem. Nulla consequat massa quis enim! Donec pede justo,
fringilla vel, aliquet nec, vulputate eget, arcu; In enim justo, rhoncus ut,
imperdiet a, venenatis vitae, justo? Nullam dictum felis eu pede mollis pretium.
Integer tincidunt! Cras dapibus; Vivamus elementum semper nisi; Aenean vulputate
eleifend tellus? Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac,
enim? Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus; Phasellus
viverra nulla ut metus varius laoreet; Quisque rutrum! Aenean imperdiet? Etiam
ultricies nisi vel augue? Curabitur ullamcorper ultricies nisi. Nam eget dui!
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula
eget dolor? Aenean massa! Cum sociis natoque penatibus et magnis dis parturient
montes, nascetur ridiculus mus; Donec quam felis, ultricies nec, pellentesque
eu, pretium quis, sem? Nulla consequat massa quis enim! Donec pede justo,
fringilla vel, aliquet nec, vulputate eget, arcu! In enim justo, rhoncus ut,
imperdiet a, venenatis vitae, justo; Nullam dictum felis eu pede mollis pretium?
Integer tincidunt? Cras dapibus? Vivamus elementum semper nisi? Aenean vulputate
eleifend tellus; Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac,
enim; Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus? Phasellus
viverra nulla ut metus varius laoreet? Quisque rutrum. Aenean imperdiet; Etiam
ultricies nisi vel augue! Curabitur ullamcorper ultricies nisi! Nam eget dui?
Lorem ipsum dolor sit amet, consectetuer adipiscing elit? Aenean commodo ligula
eget dolor; Aenean massa? Cum sociis natoque penatibus et magnis dis parturient
montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque
eu, pretium quis, sem; Nulla consequat massa quis enim! Donec pede justo,
fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut,
imperdiet a, venenatis vitae, justo.
"""

GREEKOUT['faust'] = """
Ihr naht euch wieder, schwankende Gestalten; Die früh sich einst dem trüben
Blick gezeigt; Versuch’ ich wohl euch diesmal fest zu halten? Fühl’ ich mein
Herz noch jenem Wahn geneigt? Ihr drängt euch zu; Nun gut, so mögt ihr walten.
Wie ihr aus Dunst und Nebel um mich steigt. Mein Busen fühlt sich jugendlich
erschüttert! Vom Zauberhauch der euren Zug umwittert. Ihr bringt mit euch die
Bilder froher Tage? Und manche liebe Schatten steigen auf Gleich einer alten,
halbverklungnen Sage? Kommt erste Lieb’ und Freundschaft mit herauf Der Schmerz
wird neu, es wiederholt die Klage! Des Lebens labyrinthisch irren Lauf, Und
nennt die Guten, die, um schöne Stunden Vom Glück getäuscht, vor mir
hinweggeschwunden; Ihr naht euch wieder, schwankende Gestalten. Die früh sich
einst dem trüben Blick gezeigt? Versuch’ ich wohl euch diesmal fest zu halten.
Fühl’ ich mein Herz noch jenem Wahn geneigt! Ihr drängt euch zu; Nun gut, so
mögt ihr walten! Wie ihr aus Dunst und Nebel um mich steigt; Mein Busen fühlt
sich jugendlich erschüttert; Vom Zauberhauch der euren Zug umwittert. Ihr bringt
mit euch die Bilder froher Tage! Und manche liebe Schatten steigen auf Gleich
einer alten, halbverklungnen Sage; Kommt erste Lieb’ und Freundschaft mit herauf
Der Schmerz wird neu, es wiederholt die Klage; Des Lebens labyrinthisch irren
Lauf, Und nennt die Guten, die, um schöne Stunden Vom Glück getäuscht, vor mir
hinweggeschwunden? Ihr naht euch wieder, schwankende Gestalten. Die früh sich
einst dem trüben Blick gezeigt! Versuch’ ich wohl euch diesmal fest zu halten!
Fühl’ ich mein Herz noch jenem Wahn geneigt? Ihr drängt euch zu. Nun gut, so
mögt ihr walten? Wie ihr aus Dunst und Nebel um mich steigt! Mein Busen fühlt
sich jugendlich erschüttert; Vom Zauberhauch der euren Zug umwittert? Ihr bringt
mit euch die Bilder froher Tage. Und manche liebe Schatten steigen auf Gleich
einer alten, halbverklungnen Sage. Kommt erste Lieb’ und Freundschaft mit herauf
Der Schmerz wird neu, es wiederholt die Klage? Des Lebens labyrinthisch irren
Lauf, Und nennt die Guten, die, um schöne Stunden Vom Glück getäuscht, vor mir
hinweggeschwunden. Ihr naht euch wieder, schwankende Gestalten! Die früh sich
einst dem trüben Blick gezeigt; Versuch’ ich wohl euch diesmal fest zu halten.
Fühl’ ich mein Herz noch jenem Wahn geneigt. Ihr drängt euch zu; Nun gut, so
mögt ihr walten! Wie ihr aus Dunst und Nebel um mich steigt! Mein Busen fühlt
sich jugendlich erschüttert; Vom Zauberhauch der euren Zug umwittert? Ihr bringt
mit euch die Bilder froher Tage; Und manche liebe Schatten steigen auf Gleich
einer alten, halbverklungnen Sage?
"""

GREEKOUT['thoreau'] = """
I went to the woods because I wished to live deliberately, to front only the
essential facts of life, and see if I could not learn what it had to teach, and
not, when I came to die, discover that I had not lived? I did not wish to live
what was not life, living is so dear; Nor did I wish to practise resignation,
unless it was quite necessary; I wanted to live deep and suck out all the marrow
of life, to live so sturdily and Spartan like as to put to rout all that was not
life, to cut a broad swath and shave close, to drive life into a corner, and
reduce it to its lowest terms, and, if it proved to be mean, why then to get the
whole and genuine meanness of it, and publish its meanness to the world? Or if
it were sublime, to know it by experience, and be able to give a true account of
it in my next excursion; For most men, it appears to me, are in a strange
uncertainty about it, whether it is of the devil or of God, and have somewhat
hastily concluded that it is the chief end of man here to glorify God and enjoy
him forever. Still we live meanly, like ants; Though the fable tells us that we
were long ago changed into men! Like pygmies we fight with cranes? It is error
upon error, and clout upon clout, and our best virtue has for its occasion a
superfluous and evitable wretchedness! Our life is frittered away by detail; An
honest man has hardly need to count more than his ten fingers, or in extreme
cases he may add his ten toes, and lump the rest! Simplicity, simplicity,
simplicity! I say, let your affairs be as two or three, and not a hundred or a
thousand! Instead of a million count half a dozen, and keep your accounts on
your thumbnail. In the midst of this chopping sea of civilized life, such are
the clouds and storms and quicksands and thousand and one items to be allowed
for, that a man has to live, if he would not founder and go to the bottom and
not make his port at all, by dead reckoning, and he must be a great calculator
indeed who succeeds! Simplify, simplify! Instead of three meals a day, if it be
necessary eat but one! Instead of a hundred dishes, five! And reduce other
things in proportion! I went to the woods because I wished to live deliberately,
to front only the essential facts of life, and see if I could not learn what it
had to teach, and not, when I came to die, discover that I had not lived? I did
not wish to live what was not life, living is so dear? Nor did I wish to
practise resignation, unless it was quite necessary. I wanted to live deep and
suck out all the marrow of life, to live so sturdily and Spartan like as to put
to rout all that was not life, to cut a broad swath and shave close, to drive
life into a corner, and reduce it to its lowest terms, and, if it proved to be
mean, why then to get the whole and genuine meanness of it, and publish its
meanness to the world; Or if it were sublime, to know it by experience, and be
able to give a true account of it in my next excursion! For most men, it appears
to me, are in a strange uncertainty about it, whether it is of the devil or of
God, and have somewhat hastily concluded that it is the chief end of man here to
glorify God and enjoy him forever! Still we live meanly, like ants? Though the
fable tells us that we were long ago changed into men; Like pygmies we fight
with cranes; It is error upon error, and clout upon clout, and our best virtue
has for its occasion a superfluous and evitable wretchedness; Our life is
frittered away by detail. An honest man has hardly need to count more than his
ten fingers, or in extreme cases he may add his ten toes, and lump the rest!
Simplicity, simplicity, simplicity! I say, let your affairs be as two or three,
and not a hundred or a thousand! Instead of a million count half a dozen, and
keep your accounts on your thumbnail. In the midst of this chopping sea of
civilized life, such are the clouds and storms and quicksands and thousand and
one items to be allowed for, that a man has to live, if he would not founder and
go to the bottom and not make his port at all, by dead reckoning, and he must be
a great calculator indeed who succeeds? Simplify, simplify; Instead of three
meals a day, if it be necessary eat but one. Instead of a hundred dishes, five?
And reduce other things in proportion. I went to the woods because I wished to
live deliberately, to front only the essential facts of life, and see if I could
not learn what it had to teach, and not, when I came to die, discover that I had
not lived? I did not wish to live what was not life, living is so dear; Nor did
I wish to practise resignation, unless it was quite necessary! I wanted to live
deep and suck out all the marrow of life, to live so sturdily and Spartan like
as to put to rout all that was not life, to cut a broad swath and shave close,
to drive life into a corner, and reduce it to its lowest terms, and, if it
proved to be mean, why then to get the whole and genuine meanness of it, and
publish its meanness to the world. Or if it were sublime, to know it by
experience, and be able to give a true account of it in my next excursion? For
most men, it appears to me, are in a strange uncertainty about it, whether it is
of the devil or of God, and have somewhat hastily concluded that it is the chief
end of man here to glorify God and enjoy him forever; Still we live meanly, like
ants. Though the fable tells us that we were long ago changed into men? Like
pygmies we fight with cranes! It is error upon error, and clout upon clout, and
our best virtue has for its occasion a superfluous and evitable wretchedness.
"""

GREEKOUT['poe'] = """
Once upon a midnight dreary, while I pondered, weak and weary. Over many a
quaint and curious volume of forgotten lore. While I nodded, nearly napping,
suddenly there came a tapping; As of some one gently rapping, rapping at my
chamber door; 'Tis some visiter, I muttered, tapping at my chamber door! Only
this, and nothing more. Ah, distinctly I remember it was in the bleak December;
And each separate dying ember wrought its ghost upon the floor? Eagerly I wished
the morrow? —vainly I had sought to borrow. From my books surcease of
sorrow—sorrow for the lost Lenore? For the rare and radiant maiden whom the
angels name Lenore. Nameless here for evermore; And the silken sad uncertain
rustling of each purple curtain Thrilled me, filled me with fantastic terrors
never felt before; So that now, to still the beating of my heart, I stood
repeating Tis some visiter entreating entrance at my chamber door! Some late
visiter entreating entrance at my chamber door? This it is, and nothing more?
Presently my soul grew stronger? Hesitating then no longer! Sir, said I, or
Madam, truly your forgiveness I implore; But the fact is I was napping, and so
gently you came rapping, And so faintly you came tapping, tapping at my chamber
door! That I scarce was sure I heard you, here I opened wide the door; Darkness
there, and nothing more? Deep into that darkness peering, long I stood there
wondering, fearing! Doubting, dreaming dreams no mortal ever dared to dream
before; But the silence was unbroken, and the darkness gave no token? And the
only word there spoken was the whispered word, Lenore. This I whispered, and an
echo murmured back the word, Lenore! Merely this, and nothing more. Once upon a
midnight dreary, while I pondered, weak and weary? Over many a quaint and
curious volume of forgotten lore. While I nodded, nearly napping, suddenly there
came a tapping. As of some one gently rapping, rapping at my chamber door! 'Tis
some visiter, I muttered, tapping at my chamber door? Only this, and nothing
more. Ah, distinctly I remember it was in the bleak December. And each separate
dying ember wrought its ghost upon the floor. Eagerly I wished the morrow;
—vainly I had sought to borrow. From my books surcease of sorrow—sorrow for the
lost Lenore. For the rare and radiant maiden whom the angels name Lenore!
Nameless here for evermore? And the silken sad uncertain rustling of each purple
curtain Thrilled me, filled me with fantastic terrors never felt before. So that
now, to still the beating of my heart, I stood repeating Tis some visiter
entreating entrance at my chamber door. Some late visiter entreating entrance at
my chamber door. This it is, and nothing more; Presently my soul grew stronger;
Hesitating then no longer? Sir, said I, or Madam, truly your forgiveness I
implore; But the fact is I was napping, and so gently you came rapping, And so
faintly you came tapping, tapping at my chamber door?
"""

# Python version figlet banners – using the figlet “Colossal” typeface:
# $ echo "python3.11" | figlet -w 120 -k -f colossal | pbcopy

banners = {}

banners['python3.x'] = """
                  888    888                         .d8888b.                
                  888    888                        d88P  Y88b               
                  888    888                             .d88P               
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"      888  888  
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.     `Y8bd8P'  
888  888 888  888 888    888  888 888  888 888  888 888    888       X88K    
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b .d8""8b.  
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 888  888  
888           888                                                            
888      Y8b d88P                                                            
888       "Y88P"                                                             
                                                                             
"""

banners['python3.15'] = """
                  888    888                         .d8888b.       d888  888888888  
                  888    888                        d88P  Y88b     d8888  888        
                  888    888                             .d88P       888  888        
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"        888  8888888b.  
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.       888       "Y88b 
888  888 888  888 888    888  888 888  888 888  888 888    888       888         888 
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b   888  Y88b  d88P 
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 8888888 "Y8888P"  
888           888                                                                    
888      Y8b d88P                                                                    
888       "Y88P"                                                                     

"""

banners['python3.14'] = """
                  888    888                         .d8888b.       d888      d8888  
                  888    888                        d88P  Y88b     d8888     d8P888  
                  888    888                             .d88P       888    d8P 888  
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"        888   d8P  888  
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.       888  d88   888  
888  888 888  888 888    888  888 888  888 888  888 888    888       888  8888888888 
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b   888        888  
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 8888888      888  
888           888                                                                    
888      Y8b d88P                                                                    
888       "Y88P"                                                                     

"""

banners['python3.13'] = """
                  888    888                         .d8888b.       d888   .d8888b.  
                  888    888                        d88P  Y88b     d8888  d88P  Y88b 
                  888    888                             .d88P       888       .d88P 
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"        888      8888"  
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.       888       "Y8b. 
888  888 888  888 888    888  888 888  888 888  888 888    888       888  888    888 
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b   888  Y88b  d88P 
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 8888888 "Y8888P"  
888           888                                                                    
888      Y8b d88P                                                                    
888       "Y88P"                                                                     

"""

banners['python3.12'] = """
                  888    888                         .d8888b.       d888    .d8888b.  
                  888    888                        d88P  Y88b     d8888   d88P  Y88b 
                  888    888                             .d88P       888          888 
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"        888        .d88P 
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.       888    .od888P"  
888  888 888  888 888    888  888 888  888 888  888 888    888       888   d88P"      
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b   888   888"       
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 8888888 888888888  
888           888                                                                     
888      Y8b d88P                                                                     
888       "Y88P"                                                                      

"""

banners['python3.11'] = """
                  888    888                         .d8888b.       d888    d888   
                  888    888                        d88P  Y88b     d8888   d8888   
                  888    888                             .d88P       888     888   
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"        888     888   
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.       888     888   
888  888 888  888 888    888  888 888  888 888  888 888    888       888     888   
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b   888     888   
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 8888888 8888888 
888           888                                                                  
888      Y8b d88P                                                                  
888       "Y88P"                                                                   
                                                                              
"""

banners['python3.10'] = """
                  888    888                         .d8888b.       d888    .d8888b.  
                  888    888                        d88P  Y88b     d8888   d88P  Y88b 
                  888    888                             .d88P       888   888    888 
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"        888   888    888 
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.       888   888    888 
888  888 888  888 888    888  888 888  888 888  888 888    888       888   888    888 
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b   888   Y88b  d88P 
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P 8888888  "Y8888P"  
888           888                                                                     
888      Y8b d88P                                                                     
888       "Y88P"                                                                      
                                                                              
"""

banners['python3.9'] = """
                  888    888                         .d8888b.       .d8888b.  
                  888    888                        d88P  Y88b     d88P  Y88b 
                  888    888                             .d88P     888    888 
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"      Y88b. d888 
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.      "Y888P888 
888  888 888  888 888    888  888 888  888 888  888 888    888            888 
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b Y88b  d88P 
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P  "Y8888P"  
888           888                                                             
888      Y8b d88P                                                             
888       "Y88P"                                                              
                                                                              
"""

banners['python3.8'] = """
                  888    888                         .d8888b.       .d8888b.  
                  888    888                        d88P  Y88b     d88P  Y88b 
                  888    888                             .d88P     Y88b .d88P 
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"       "888888"  
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.     .d8Y""Y8b. 
888  888 888  888 888    888  888 888  888 888  888 888    888     888    888 
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b Y88b  d88P 
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P  "Y8888P"  
888           888                                                             
888      Y8b d88P                                                             
888       "Y88P"                                                              
                                                                              
"""

banners['python3.7'] = """
                  888    888                         .d8888b.      8888888888 
                  888    888                        d88P  Y88b           d88P 
                  888    888                             .d88P          d88P  
88888b.  888  888 888888 88888b.   .d88b.  88888b.      8888"          d88P   
888 "88b 888  888 888    888 "88b d88""88b 888 "88b      "Y8b.      88888888  
888  888 888  888 888    888  888 888  888 888  888 888    888       d88P     
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 Y88b  d88P d8b  d88P      
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888  "Y8888P"  Y8P d88P       
888           888                                                             
888      Y8b d88P                                                             
888       "Y88P"                                                              
                                                                              
"""

banners['python2.7'] = """
                  888    888                         .d8888b.      8888888888 
                  888    888                        d88P  Y88b           d88P 
                  888    888                               888          d88P  
88888b.  888  888 888888 88888b.   .d88b.  88888b.       .d88P         d88P   
888 "88b 888  888 888    888 "88b d88""88b 888 "88b  .od888P"       88888888  
888  888 888  888 888    888  888 888  888 888  888 d88P"            d88P     
888 d88P Y88b 888 Y88b.  888  888 Y88..88P 888  888 888"       d8b  d88P      
88888P"   "Y88888  "Y888 888  888  "Y88P"  888  888 888888888  Y8P d88P       
888           888                                                             
888      Y8b d88P                                                             
888       "Y88P"                                                              
                                                                              
"""

banners['pypy3.x'] = """
                                     .d8888b.                                 
                                    d88P  Y88b                                
                                         .d88P                                
88888b.  888  888 88888b.  888  888     8888"      888  888                   
888 "88b 888  888 888 "88b 888  888      "Y8b.     `Y8bd8P'                   
888  888 888  888 888  888 888  888 888    888       X88K                     
888 d88P Y88b 888 888 d88P Y88b 888 Y88b  d88P d8b .d8""8b.                   
88888P"   "Y88888 88888P"   "Y88888  "Y8888P"  Y8P 888  888                   
888           888 888           888                                           
888      Y8b d88P 888      Y8b d88P                                           
888       "Y88P"  888       "Y88P"                                            
                                                                              
"""

banners['pypy3.8'] = """
                                     .d8888b.       .d8888b.                  
                                    d88P  Y88b     d88P  Y88b                 
                                         .d88P     Y88b .d88P                 
88888b.  888  888 88888b.  888  888     8888"       "888888"                  
888 "88b 888  888 888 "88b 888  888      "Y8b.     .d8Y""Y8b.                 
888  888 888  888 888  888 888  888 888    888     888    888                 
888 d88P Y88b 888 888 d88P Y88b 888 Y88b  d88P d8b Y88b  d88P                 
88888P"   "Y88888 88888P"   "Y88888  "Y8888P"  Y8P  "Y8888P"                  
888           888 888           888                                           
888      Y8b d88P 888      Y8b d88P                                           
888       "Y88P"  888       "Y88P"                                            
                                                                              
"""

banners['pypy3.7'] = """
                                     .d8888b.      8888888888                 
                                    d88P  Y88b           d88P                 
                                         .d88P          d88P                  
88888b.  888  888 88888b.  888  888     8888"          d88P                   
888 "88b 888  888 888 "88b 888  888      "Y8b.      88888888                  
888  888 888  888 888  888 888  888 888    888       d88P                     
888 d88P Y88b 888 888 d88P Y88b 888 Y88b  d88P d8b  d88P                      
88888P"   "Y88888 88888P"   "Y88888  "Y8888P"  Y8P d88P                       
888           888 888           888                                           
888      Y8b d88P 888      Y8b d88P                                           
888       "Y88P"  888       "Y88P"                                            
                                                                              
"""

banners['pypy3.6'] = """
                                     .d8888b.       .d8888b.                  
                                    d88P  Y88b     d88P  Y88b                 
                                         .d88P     888                        
88888b.  888  888 88888b.  888  888     8888"      888d888b.                  
888 "88b 888  888 888 "88b 888  888      "Y8b.     888P "Y88b                 
888  888 888  888 888  888 888  888 888    888     888    888                 
888 d88P Y88b 888 888 d88P Y88b 888 Y88b  d88P d8b Y88b  d88P                 
88888P"   "Y88888 88888P"   "Y88888  "Y8888P"  Y8P  "Y8888P"                  
888           888 888           888                                           
888      Y8b d88P 888      Y8b d88P                                           
888       "Y88P"  888       "Y88P"                                            
                                                                              
"""

banners['pypy2.7'] = """
                                     .d8888b.      8888888888                 
                                    d88P  Y88b           d88P                 
                                           888          d88P                  
88888b.  888  888 88888b.  888  888      .d88P         d88P                   
888 "88b 888  888 888 "88b 888  888  .od888P"       88888888                  
888  888 888  888 888  888 888  888 d88P"            d88P                     
888 d88P Y88b 888 888 d88P Y88b 888 888"       d8b  d88P                      
88888P"   "Y88888 88888P"   "Y88888 888888888  Y8P d88P                       
888           888 888           888                                           
888      Y8b d88P 888      Y8b d88P                                           
888       "Y88P"  888       "Y88P"                                            
                                                                              
"""

# Manual all/dir defs:

__all__ = ('arbitrary', 'nested', 'flat',
           'banners',
           'XDGS', 'GREEKOUT')

__dir__ = lambda: __all__

def test():
    from pprint import pprint
    
    print()
    print("ALL TUPLE:")
    pprint(__all__)
    
    print()
    print("DIR FUNCTION:")
    pprint(__dir__())

if __name__ == '__main__':
    sys.exit(test())