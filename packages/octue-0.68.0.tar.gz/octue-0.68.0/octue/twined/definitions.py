VALUES_FILENAME = "values.json"
MANIFEST_FILENAME = "manifest.json"
OUTPUT_STRANDS = ("output_values", "output_manifest")
RUN_STRANDS = ("input_values", "input_manifest", "credentials", "children")
DEFAULT_MAXIMUM_HEARTBEAT_INTERVAL = 360
