from .gen_uuid import gen_uuid

__all__ = ("gen_uuid",)
