import importlib.metadata

GOOGLE_COMPUTE_PROVIDERS = {"GOOGLE_CLOUD_FUNCTION"}
LOCAL_SDK_VERSION = importlib.metadata.version("octue")
