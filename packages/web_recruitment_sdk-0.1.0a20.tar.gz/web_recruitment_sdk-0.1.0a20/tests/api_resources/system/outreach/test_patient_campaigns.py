# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from web_recruitment_sdk import WebRecruitmentSDK, AsyncWebRecruitmentSDK
from web_recruitment_sdk.types.system.outreach import (
    PatientCampaignCreateActionResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPatientCampaigns:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_action_overload_1(self, client: WebRecruitmentSDK) -> None:
        patient_campaign = client.system.outreach.patient_campaigns.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
        )
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_action_with_all_params_overload_1(self, client: WebRecruitmentSDK) -> None:
        patient_campaign = client.system.outreach.patient_campaigns.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
            transcript_url="transcriptUrl",
        )
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_action_overload_1(self, client: WebRecruitmentSDK) -> None:
        response = client.system.outreach.patient_campaigns.with_raw_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        patient_campaign = response.parse()
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_action_overload_1(self, client: WebRecruitmentSDK) -> None:
        with client.system.outreach.patient_campaigns.with_streaming_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            patient_campaign = response.parse()
            assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_create_action_overload_1(self, client: WebRecruitmentSDK) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `tenant_db_name` but received ''"):
            client.system.outreach.patient_campaigns.with_raw_response.create_action(
                patient_campaign_id=0,
                tenant_db_name="",
                caller_phone_number="callerPhoneNumber",
                duration_seconds=0,
                recipient_phone_number="recipientPhoneNumber",
                status="STARTED",
                task_id=0,
                type="PHONE_CALL",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_action_overload_2(self, client: WebRecruitmentSDK) -> None:
        patient_campaign = client.system.outreach.patient_campaigns.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            message="message",
            recipient_phone_number="recipientPhoneNumber",
            sender_phone_number="senderPhoneNumber",
            status="SENT",
            task_id=0,
            type="SMS",
        )
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create_action_overload_2(self, client: WebRecruitmentSDK) -> None:
        response = client.system.outreach.patient_campaigns.with_raw_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            message="message",
            recipient_phone_number="recipientPhoneNumber",
            sender_phone_number="senderPhoneNumber",
            status="SENT",
            task_id=0,
            type="SMS",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        patient_campaign = response.parse()
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create_action_overload_2(self, client: WebRecruitmentSDK) -> None:
        with client.system.outreach.patient_campaigns.with_streaming_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            message="message",
            recipient_phone_number="recipientPhoneNumber",
            sender_phone_number="senderPhoneNumber",
            status="SENT",
            task_id=0,
            type="SMS",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            patient_campaign = response.parse()
            assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_create_action_overload_2(self, client: WebRecruitmentSDK) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `tenant_db_name` but received ''"):
            client.system.outreach.patient_campaigns.with_raw_response.create_action(
                patient_campaign_id=0,
                tenant_db_name="",
                message="message",
                recipient_phone_number="recipientPhoneNumber",
                sender_phone_number="senderPhoneNumber",
                status="SENT",
                task_id=0,
                type="SMS",
            )


class TestAsyncPatientCampaigns:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_action_overload_1(self, async_client: AsyncWebRecruitmentSDK) -> None:
        patient_campaign = await async_client.system.outreach.patient_campaigns.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
        )
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_action_with_all_params_overload_1(self, async_client: AsyncWebRecruitmentSDK) -> None:
        patient_campaign = await async_client.system.outreach.patient_campaigns.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
            transcript_url="transcriptUrl",
        )
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_action_overload_1(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.system.outreach.patient_campaigns.with_raw_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        patient_campaign = await response.parse()
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_action_overload_1(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.system.outreach.patient_campaigns.with_streaming_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            caller_phone_number="callerPhoneNumber",
            duration_seconds=0,
            recipient_phone_number="recipientPhoneNumber",
            status="STARTED",
            task_id=0,
            type="PHONE_CALL",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            patient_campaign = await response.parse()
            assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_create_action_overload_1(self, async_client: AsyncWebRecruitmentSDK) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `tenant_db_name` but received ''"):
            await async_client.system.outreach.patient_campaigns.with_raw_response.create_action(
                patient_campaign_id=0,
                tenant_db_name="",
                caller_phone_number="callerPhoneNumber",
                duration_seconds=0,
                recipient_phone_number="recipientPhoneNumber",
                status="STARTED",
                task_id=0,
                type="PHONE_CALL",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_action_overload_2(self, async_client: AsyncWebRecruitmentSDK) -> None:
        patient_campaign = await async_client.system.outreach.patient_campaigns.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            message="message",
            recipient_phone_number="recipientPhoneNumber",
            sender_phone_number="senderPhoneNumber",
            status="SENT",
            task_id=0,
            type="SMS",
        )
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create_action_overload_2(self, async_client: AsyncWebRecruitmentSDK) -> None:
        response = await async_client.system.outreach.patient_campaigns.with_raw_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            message="message",
            recipient_phone_number="recipientPhoneNumber",
            sender_phone_number="senderPhoneNumber",
            status="SENT",
            task_id=0,
            type="SMS",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        patient_campaign = await response.parse()
        assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create_action_overload_2(self, async_client: AsyncWebRecruitmentSDK) -> None:
        async with async_client.system.outreach.patient_campaigns.with_streaming_response.create_action(
            patient_campaign_id=0,
            tenant_db_name="tenant_db_name",
            message="message",
            recipient_phone_number="recipientPhoneNumber",
            sender_phone_number="senderPhoneNumber",
            status="SENT",
            task_id=0,
            type="SMS",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            patient_campaign = await response.parse()
            assert_matches_type(PatientCampaignCreateActionResponse, patient_campaign, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_create_action_overload_2(self, async_client: AsyncWebRecruitmentSDK) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `tenant_db_name` but received ''"):
            await async_client.system.outreach.patient_campaigns.with_raw_response.create_action(
                patient_campaign_id=0,
                tenant_db_name="",
                message="message",
                recipient_phone_number="recipientPhoneNumber",
                sender_phone_number="senderPhoneNumber",
                status="SENT",
                task_id=0,
                type="SMS",
            )
