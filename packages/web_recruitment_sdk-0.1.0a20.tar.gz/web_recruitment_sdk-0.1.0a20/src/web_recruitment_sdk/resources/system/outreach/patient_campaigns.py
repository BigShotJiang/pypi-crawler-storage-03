# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, Optional, cast
from typing_extensions import Literal, overload

import httpx

from ...._types import NOT_GIVEN, Body, Query, Headers, NotGiven
from ...._utils import required_args, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.system.outreach import patient_campaign_create_action_params
from ....types.system.outreach.patient_campaign_create_action_response import PatientCampaignCreateActionResponse

__all__ = ["PatientCampaignsResource", "AsyncPatientCampaignsResource"]


class PatientCampaignsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PatientCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return PatientCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PatientCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return PatientCampaignsResourceWithStreamingResponse(self)

    @overload
    def create_action(
        self,
        patient_campaign_id: int,
        *,
        tenant_db_name: str,
        caller_phone_number: str,
        duration_seconds: int,
        recipient_phone_number: str,
        status: Literal[
            "STARTED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "DO_NOT_CALL",
            "ENDED",
        ],
        task_id: int,
        type: Literal["PHONE_CALL"],
        transcript_url: Optional[str] | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PatientCampaignCreateActionResponse:
        """
        Create a new outreach action for a patient in a campaign

        Args:
          status: Status values specific to phone call actions

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def create_action(
        self,
        patient_campaign_id: int,
        *,
        tenant_db_name: str,
        message: str,
        recipient_phone_number: str,
        sender_phone_number: str,
        status: Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ],
        task_id: int,
        type: Literal["SMS"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PatientCampaignCreateActionResponse:
        """
        Create a new outreach action for a patient in a campaign

        Args:
          status: Status values specific to SMS actions

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(
        [
            "tenant_db_name",
            "caller_phone_number",
            "duration_seconds",
            "recipient_phone_number",
            "status",
            "task_id",
            "type",
        ],
        ["tenant_db_name", "message", "recipient_phone_number", "sender_phone_number", "status", "task_id", "type"],
    )
    def create_action(
        self,
        patient_campaign_id: int,
        *,
        tenant_db_name: str,
        caller_phone_number: str | NotGiven = NOT_GIVEN,
        duration_seconds: int | NotGiven = NOT_GIVEN,
        recipient_phone_number: str,
        status: Literal[
            "STARTED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "DO_NOT_CALL",
            "ENDED",
        ]
        | Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ],
        task_id: int,
        type: Literal["PHONE_CALL"] | Literal["SMS"],
        transcript_url: Optional[str] | NotGiven = NOT_GIVEN,
        message: str | NotGiven = NOT_GIVEN,
        sender_phone_number: str | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PatientCampaignCreateActionResponse:
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return cast(
            PatientCampaignCreateActionResponse,
            self._post(
                f"/system/{tenant_db_name}/outreach/patient-campaigns/{patient_campaign_id}/actions",
                body=maybe_transform(
                    {
                        "caller_phone_number": caller_phone_number,
                        "duration_seconds": duration_seconds,
                        "recipient_phone_number": recipient_phone_number,
                        "status": status,
                        "task_id": task_id,
                        "type": type,
                        "transcript_url": transcript_url,
                        "message": message,
                        "sender_phone_number": sender_phone_number,
                    },
                    patient_campaign_create_action_params.PatientCampaignCreateActionParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, PatientCampaignCreateActionResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class AsyncPatientCampaignsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPatientCampaignsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncPatientCampaignsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPatientCampaignsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TriallyAI/web-recruitment-sdk#with_streaming_response
        """
        return AsyncPatientCampaignsResourceWithStreamingResponse(self)

    @overload
    async def create_action(
        self,
        patient_campaign_id: int,
        *,
        tenant_db_name: str,
        caller_phone_number: str,
        duration_seconds: int,
        recipient_phone_number: str,
        status: Literal[
            "STARTED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "DO_NOT_CALL",
            "ENDED",
        ],
        task_id: int,
        type: Literal["PHONE_CALL"],
        transcript_url: Optional[str] | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PatientCampaignCreateActionResponse:
        """
        Create a new outreach action for a patient in a campaign

        Args:
          status: Status values specific to phone call actions

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def create_action(
        self,
        patient_campaign_id: int,
        *,
        tenant_db_name: str,
        message: str,
        recipient_phone_number: str,
        sender_phone_number: str,
        status: Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ],
        task_id: int,
        type: Literal["SMS"],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PatientCampaignCreateActionResponse:
        """
        Create a new outreach action for a patient in a campaign

        Args:
          status: Status values specific to SMS actions

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(
        [
            "tenant_db_name",
            "caller_phone_number",
            "duration_seconds",
            "recipient_phone_number",
            "status",
            "task_id",
            "type",
        ],
        ["tenant_db_name", "message", "recipient_phone_number", "sender_phone_number", "status", "task_id", "type"],
    )
    async def create_action(
        self,
        patient_campaign_id: int,
        *,
        tenant_db_name: str,
        caller_phone_number: str | NotGiven = NOT_GIVEN,
        duration_seconds: int | NotGiven = NOT_GIVEN,
        recipient_phone_number: str,
        status: Literal[
            "STARTED",
            "NO_ANSWER",
            "VOICEMAIL_LEFT",
            "WRONG_NUMBER",
            "HANGUP",
            "INTERESTED",
            "NOT_INTERESTED",
            "SCHEDULED",
            "DO_NOT_CALL",
            "ENDED",
        ]
        | Literal[
            "SENT",
            "FAILED_TO_SEND",
            "REPLIED",
            "INTERESTED",
            "NOT_INTERESTED",
            "BOOKING_LINK_SENT",
            "SCHEDULED",
            "DO_NOT_CALL",
        ],
        task_id: int,
        type: Literal["PHONE_CALL"] | Literal["SMS"],
        transcript_url: Optional[str] | NotGiven = NOT_GIVEN,
        message: str | NotGiven = NOT_GIVEN,
        sender_phone_number: str | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> PatientCampaignCreateActionResponse:
        if not tenant_db_name:
            raise ValueError(f"Expected a non-empty value for `tenant_db_name` but received {tenant_db_name!r}")
        return cast(
            PatientCampaignCreateActionResponse,
            await self._post(
                f"/system/{tenant_db_name}/outreach/patient-campaigns/{patient_campaign_id}/actions",
                body=await async_maybe_transform(
                    {
                        "caller_phone_number": caller_phone_number,
                        "duration_seconds": duration_seconds,
                        "recipient_phone_number": recipient_phone_number,
                        "status": status,
                        "task_id": task_id,
                        "type": type,
                        "transcript_url": transcript_url,
                        "message": message,
                        "sender_phone_number": sender_phone_number,
                    },
                    patient_campaign_create_action_params.PatientCampaignCreateActionParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, PatientCampaignCreateActionResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class PatientCampaignsResourceWithRawResponse:
    def __init__(self, patient_campaigns: PatientCampaignsResource) -> None:
        self._patient_campaigns = patient_campaigns

        self.create_action = to_raw_response_wrapper(
            patient_campaigns.create_action,
        )


class AsyncPatientCampaignsResourceWithRawResponse:
    def __init__(self, patient_campaigns: AsyncPatientCampaignsResource) -> None:
        self._patient_campaigns = patient_campaigns

        self.create_action = async_to_raw_response_wrapper(
            patient_campaigns.create_action,
        )


class PatientCampaignsResourceWithStreamingResponse:
    def __init__(self, patient_campaigns: PatientCampaignsResource) -> None:
        self._patient_campaigns = patient_campaigns

        self.create_action = to_streamed_response_wrapper(
            patient_campaigns.create_action,
        )


class AsyncPatientCampaignsResourceWithStreamingResponse:
    def __init__(self, patient_campaigns: AsyncPatientCampaignsResource) -> None:
        self._patient_campaigns = patient_campaigns

        self.create_action = async_to_streamed_response_wrapper(
            patient_campaigns.create_action,
        )
