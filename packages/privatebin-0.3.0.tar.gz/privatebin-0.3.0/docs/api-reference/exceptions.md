::: privatebin.PrivateBinError
