::: privatebin.Compression
    options:
      members: true
::: privatebin.Expiration
    options:
      members: true
::: privatebin.Formatter
    options:
      members: true

