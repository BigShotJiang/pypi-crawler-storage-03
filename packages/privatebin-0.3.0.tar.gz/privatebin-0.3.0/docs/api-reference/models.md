::: privatebin.Attachment
    options:
      inherited_members: true
::: privatebin.Paste
    options:
      inherited_members: true
::: privatebin.PasteReceipt
    options:
      inherited_members: true
::: privatebin.PrivateBinUrl
    options:
      inherited_members: true
