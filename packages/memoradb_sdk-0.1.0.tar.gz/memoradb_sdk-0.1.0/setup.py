from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="memoradb-sdk",
    version="0.1.0",
    author="MemoraDB Team",
    author_email="hello@memoradb.com",
    description="Universal Memory Layer for AI Agents - Python SDK",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/memoradb/memoradb-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.24.0",
        "pydantic>=2.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    keywords="ai, memory, agents, llm, rag, vector-database",
    project_urls={
        "Documentation": "https://docs.memoradb.com",
        "Source": "https://github.com/memoradb/memoradb-python",
        "Tracker": "https://github.com/memoradb/memoradb-python/issues",
    },
)