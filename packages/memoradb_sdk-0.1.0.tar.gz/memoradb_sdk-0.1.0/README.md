# MemoraDB Python SDK

Universal Memory Layer for AI Agents - The S3 + Redis for AI Memory

## Installation

```bash
pip install memoradb
```

## Quick Start

```python
from memoradb import MemoraDB
import asyncio

async def main():
    # Initialize client
    client = MemoraDB(
        api_url="https://api.memoradb.com",
        api_key="your-api-key"
    )
    
    # Store a memory
    result = await client.write(
        namespace_id="your-namespace",
        owner_id="user-123", 
        session_id="session-456",
        text="User prefers dark mode and wants weekly reports",
        kind="preference"
    )
    
    # Retrieve relevant memories
    memories = await client.retrieve(
        namespace_id="your-namespace",
        owner_id="user-123",
        query="user preferences",
        k=5
    )
    
    print(f"Found {len(memories.results)} relevant memories")

asyncio.run(main())
```

## Features

- 🧠 **Persistent Memory**: Store and retrieve memories across sessions
- 🔄 **Portable Memory**: Share context between different AI agents
- 🔍 **Semantic Search**: Find relevant memories using vector similarity
- 📄 **Automatic Summarization**: Compress memories into summaries
- 🛡️ **GDPR Compliant**: Right to forget and data portability
- 🏷️ **Multi-kind Storage**: Support for user messages, agent responses, tool outputs, and notes

## API Reference

### Write Memory
```python
await client.write(
    namespace_id="namespace-uuid",
    owner_id="user-uuid",
    session_id="session-uuid", 
    text="Memory content",
    kind="user_msg",  # user_msg, agent_msg, tool_io, note
    metadata={"key": "value"},
    pii_tags=["email", "phone"]
)
```

### Retrieve Memories  
```python
memories = await client.retrieve(
    namespace_id="namespace-uuid",
    owner_id="user-uuid",
    query="search query",
    k=10,
    use_summaries=True
)
```

### Context Packing
```python
context = await client.context_pack(
    namespace_id="namespace-uuid", 
    owner_id="user-uuid",
    query="context query",
    budget_tokens=1000,
    include_summaries=True
)
```

### Forget Memories (GDPR)
```python
await client.forget(
    namespace_id="namespace-uuid",
    owner_id="user-uuid", 
    reason="user_request"
)
```

## License

MIT License - see LICENSE file for details.