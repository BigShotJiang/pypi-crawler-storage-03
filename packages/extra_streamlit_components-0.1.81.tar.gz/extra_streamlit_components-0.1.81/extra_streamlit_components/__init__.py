IS_RELEASE = True

from .TabBar import tab_bar
from .TabBar import TabBarItemData
from .BouncingImage import bouncing_image
from .StepperBar import stepper_bar
from .CookieManager import CookieManager
from .Router import Router
