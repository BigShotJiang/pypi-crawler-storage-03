"""UVX DateTime MCP Server - A simple MCP server that provides date and time functionality."""

__version__ = "0.2.0"
