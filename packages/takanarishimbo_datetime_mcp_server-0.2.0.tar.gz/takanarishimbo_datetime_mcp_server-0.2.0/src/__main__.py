"""Entry point for the UVX DateTime MCP Server."""

from .server import main

if __name__ == "__main__":
    main()
