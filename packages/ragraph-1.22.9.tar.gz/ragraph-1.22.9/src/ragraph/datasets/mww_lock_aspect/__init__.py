"""Multi-WaterWerk project waterway lock-aspect mapping"""
