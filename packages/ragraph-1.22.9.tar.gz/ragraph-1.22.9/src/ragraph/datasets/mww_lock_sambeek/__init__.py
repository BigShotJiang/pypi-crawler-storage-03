"""Multi-WaterWerk project waterway lock 'Sambeek'"""

edge_weights = [
    "energy",
    "information",
    "location",
    "spatial",
]
