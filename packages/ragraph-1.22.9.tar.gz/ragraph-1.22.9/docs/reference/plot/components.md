::: ragraph.plot.components
