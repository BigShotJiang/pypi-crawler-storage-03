::: ragraph.plot.generic
