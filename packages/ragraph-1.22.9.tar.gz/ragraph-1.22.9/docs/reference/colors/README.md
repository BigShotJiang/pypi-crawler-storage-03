::: ragraph.colors
