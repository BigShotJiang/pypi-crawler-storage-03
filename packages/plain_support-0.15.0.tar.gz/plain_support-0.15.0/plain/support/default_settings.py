SUPPORT_FORMS = {
    "default": "plain.support.forms.SupportForm",
}
SUPPORT_EMAIL: str
