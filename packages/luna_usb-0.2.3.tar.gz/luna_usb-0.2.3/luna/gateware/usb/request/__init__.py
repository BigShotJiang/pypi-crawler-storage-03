#
# This file is part of LUNA.
#
""" USB2 + USB3 common request handling definitions. """

from .interface import SetupPacket
