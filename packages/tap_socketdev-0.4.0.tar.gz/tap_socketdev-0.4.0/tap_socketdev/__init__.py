"""Python package for the tap-socketdev CLI."""

from __future__ import annotations
