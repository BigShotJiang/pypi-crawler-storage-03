"""Tap executable."""

from __future__ import annotations

from tap_socketdev.tap import TapSocketDev

TapSocketDev.cli()
