## 0.7.0.20250822 (2025-08-22)

Add __slots__ to third-party packages using stubdefaulter ([#14619](https://github.com/python/typeshed/pull/14619))

## 0.7.0.20250717 (2025-07-17)

Add pony stubs (#14361)

