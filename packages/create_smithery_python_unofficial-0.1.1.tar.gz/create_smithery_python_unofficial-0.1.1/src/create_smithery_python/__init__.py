"""Create Smithery Python - Scaffold MCP servers for Smithery."""

__version__ = "0.1.0"
