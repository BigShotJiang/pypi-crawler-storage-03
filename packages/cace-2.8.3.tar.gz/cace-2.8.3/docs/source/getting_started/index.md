# Getting Started

```{toctree}
:glob:
:maxdepth: 2

installation_overview
common/nix_installation/index
```
