Command Line Interface
**********************

.. click:: modos.cli:typer_click_object
   :prog: modo
   :nested: full
