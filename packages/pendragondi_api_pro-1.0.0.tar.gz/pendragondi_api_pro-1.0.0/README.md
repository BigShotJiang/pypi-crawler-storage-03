# Pendragon Pro

Context-rich, in-app duplicate detection for Python.

## 🚀 Quickstart (Simple Mode)

```python
from pendragon_pro import duplicate_guard

@duplicate_guard
def call_api(...):
    ...
```

## ⚡️ Advanced Usage

```python
from pendragon_pro import duplicate_guard_pro

@duplicate_guard_pro(window_ms=3000, capture_args=False, rate_limit_per_minute=60)
def call_api(...):
    ...
```

## 🖥 CLI Usage

```bash
pendragon-pro export --output myreport.html --format html
```

## 📂 Examples

- [examples/guard_simple.py](examples/guard_simple.py)
- [examples/guard_advanced.py](examples/guard_advanced.py)

## 🛠 Configuration

- `window_ms`: Deduplication window (ms, default: 2000)
- `capture_args`: Whether to log/redact args (default: True)
- `stack_depth`: How many frames to capture (default: 6)
- `rate_limit_per_minute`: Bucket per-op deduplication (optional)

## 📦 Export Reports

```python
from pendragon_pro import get_event_log, export_html

events = get_event_log().snapshot()
export_html(events, "report.html")
```

## 🔒 Privacy

No telemetry. Redaction for PII by default. See `redact.py` for details.

## 💬 Support/Contact

- Open an issue or email pendragondi@pendragondi.dev

---

## 📜 License

[MIT License](LICENSE)

---

## 🧭 Why PendragonDI?

Pendragon Pro was built to solve the *next layer* of API waste and developer friction—giving you real-time, context-rich duplicate detection, with privacy and speed at the core.

No agents. No data sales. No telemetry. Just the signal you need to debug smarter.

---

## 🤝 Contributing

Contributions are welcome! If you have suggestions for improvements or find a bug, please open an issue or submit a pull request.

When contributing:
- Fork the repository and create your branch from `main`.
- Ensure any new code has appropriate type hints and docstrings.
- Run the test suite and add tests for new functionality.
- Submit a descriptive pull request so changes can be reviewed efficiently.
- Support/Contact: pendragondi@pendragondi.dev

---

## 💖 Support the Project

Pendragon Pro is open-source and free to use.  
If you’ve found it useful and would like to support ongoing development, you can sponsor us on GitHub:  
[![Sponsor on GitHub](https://img.shields.io/badge/Sponsor-💖-pink?style=flat)](https://github.com/sponsors/jinpendragon)
