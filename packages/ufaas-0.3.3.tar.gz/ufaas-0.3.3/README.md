# UFiles-Client

The Ufiles-Client is a SDK for ufiles servers.

## Installation

Install the ufiles client using pip:

```bash
pip install ufiles
```

## Quick Start
Follow the quick start guides in the documentation to integrate ufiles in your application.

## Contributing
Contributions are welcome! See CONTRIBUTING.md for more details on how to get involved.

## License
Distributed under the MIT License. See LICENSE for more information.