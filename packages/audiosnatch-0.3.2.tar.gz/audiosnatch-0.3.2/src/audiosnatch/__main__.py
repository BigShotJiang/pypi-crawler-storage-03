import audiosnatch

audiosnatch.main()
