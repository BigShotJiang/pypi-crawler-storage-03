"""[Developer API] Namespace package for reusable touchtechnology apps.

These apps provide generic administration and content management features
that can be integrated into other Django projects.
"""
