"""[Developer API] Content management utilities."""

default_app_config = "touchtechnology.content.apps.ContentConfig"
