# acryl-datahub-cloud

This package contains additional DataHub models and sources that are specific to Acryl Cloud.

Installing this package will automatically enable the `acryl-datahub` package to make use of this additional functionality.
