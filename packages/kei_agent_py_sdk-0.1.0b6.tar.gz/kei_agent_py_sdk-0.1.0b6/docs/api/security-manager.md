# Security Manager

<!-- API aus Code generieren -->

::: kei_agent.security_manager.SecurityManager

## Authentifizierungstypen

- Bearer Token
- OIDC
- mTLS

Siehe Konfigurationsdetails in `ProtocolTypes`.
