# nim-mmcif

Parser for mmCIF files in Nim

The goal of this repository is to come up with a practical tool while getting up to speed with vibe coding and its limits
