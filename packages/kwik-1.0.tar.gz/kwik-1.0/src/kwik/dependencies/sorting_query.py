"""Sorting query dependency for FastAPI endpoints."""

from __future__ import annotations

import re
from typing import Annotated

from fastapi import Depends

from kwik.typings import ParsedSortingQuery


def _parse_sorting_query(sorting: str | None = None) -> ParsedSortingQuery:
    """
    Sorting query parameter parser, to be used as endpoint dependency.

    The sorting parameter is a comma-separated list of fields to sort by.
    Each field can be postfixed with a colon and a direction ("asc" or "desc").
    If no direction is specified, "asc" is assumed.

    Example:
    >>> _parse_sorting_query("id:desc,created_at")
    [("id", "desc"), ("created_at", "asc")]

    """
    sort = []
    if sorting is not None:
        pattern = r"(\w+)(?::(asc|desc))?"
        for field, direction in re.findall(pattern, sorting):
            if direction and direction not in ("asc", "desc"):
                msg = f"Invalid sorting {direction=} for {field=}"
                raise ValueError(msg)
            sort.append((field, direction or "asc"))
    return sort


SortingQuery = Annotated[ParsedSortingQuery, Depends(_parse_sorting_query)]

__all__ = ["SortingQuery"]
