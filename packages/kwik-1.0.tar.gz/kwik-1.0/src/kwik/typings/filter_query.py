"""Type definitions for query filtering."""

from __future__ import annotations

FilterQuery = dict[str, str]
