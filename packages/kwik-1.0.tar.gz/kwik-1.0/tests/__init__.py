"""
Test suite package for kwik framework.

This package contains the main test suite for the kwik web framework,
including integration tests and endpoint tests.
"""
