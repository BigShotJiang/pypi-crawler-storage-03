# -*- coding: utf-8 -*-

from tuxsuite.cli import main


def run():
    if __name__ == "__main__":
        main()


run()
