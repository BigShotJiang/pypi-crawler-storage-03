import numpy as np

# Pandas dataframe used in this library should have `RangeIndex` as index
TYPE_INDEX = int | np.int64
