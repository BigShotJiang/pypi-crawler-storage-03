MSG_SAFETY_SOURCE_NOT_ADDED = "\nError: Safety Firewall could not be added as a source in your pyproject.toml file. You will not be protected from malicious or insecure packages. Please run `safety init` to fix this."
MSG_SAFETY_SOURCE_ADDED = (
    "\nSafety Firewall has been added as a source to protect this codebase"
)
