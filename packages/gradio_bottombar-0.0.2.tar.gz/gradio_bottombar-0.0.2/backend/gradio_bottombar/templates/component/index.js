var to = Object.defineProperty;
var fi = (r) => {
  throw TypeError(r);
};
var no = (r, e, t) => e in r ? to(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var P = (r, e, t) => no(r, typeof e != "symbol" ? e + "" : e, t), io = (r, e, t) => e.has(r) || fi("Cannot " + t);
var hi = (r, e, t) => e.has(r) ? fi("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t);
var Lt = (r, e, t) => (io(r, e, "access private method"), t);
const {
  SvelteComponent: ao,
  append_hydration: fn,
  attr: qt,
  children: mi,
  claim_element: hn,
  claim_space: oo,
  create_slot: ro,
  detach: mn,
  element: gn,
  get_all_dirty_from_scope: lo,
  get_slot_changes: so,
  get_svelte_dataset: uo,
  init: co,
  insert_hydration: _o,
  listen: po,
  safe_not_equal: fo,
  set_style: gi,
  space: ho,
  toggle_class: He,
  transition_in: mo,
  transition_out: go,
  update_slot_base: Do
} = window.__gradio__svelte__internal, { createEventDispatcher: $o, onMount: vo } = window.__gradio__svelte__internal;
function bo(r) {
  let e, t, n = '<div class="chevron svelte-vfns1t"><span class="chevron-arrow svelte-vfns1t"></span></div>', a, o, i, l, s;
  const u = (
    /*#slots*/
    r[12].default
  ), c = ro(
    u,
    r,
    /*$$scope*/
    r[11],
    null
  );
  return {
    c() {
      e = gn("div"), t = gn("button"), t.innerHTML = n, a = ho(), o = gn("div"), c && c.c(), this.h();
    },
    l(p) {
      e = hn(p, "DIV", { class: !0, style: !0 });
      var m = mi(e);
      t = hn(m, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "data-svelte-h": !0
      }), uo(t) !== "svelte-184z5li" && (t.innerHTML = n), a = oo(m), o = hn(m, "DIV", { class: !0 });
      var D = mi(o);
      c && c.l(D), D.forEach(mn), m.forEach(mn), this.h();
    },
    h() {
      qt(t, "class", "toggle-bottom-button svelte-vfns1t"), qt(t, "aria-label", "Toggle Bottom Bar"), qt(o, "class", "bar-content svelte-vfns1t"), qt(e, "class", "bottom-bar svelte-vfns1t"), gi(
        e,
        "height",
        /*height_css*/
        r[7]
      ), gi(
        e,
        "width",
        /*width_css*/
        r[6]
      ), He(
        e,
        "open",
        /*_open*/
        r[3]
      ), He(
        e,
        "reduce-motion",
        /*prefersReducedMotion*/
        r[4]
      ), He(
        e,
        "on-top",
        /*bring_to_front*/
        r[1]
      ), He(
        e,
        "rounded",
        /*rounded_borders*/
        r[2]
      );
    },
    m(p, m) {
      _o(p, e, m), fn(e, t), fn(e, a), fn(e, o), c && c.m(o, null), i = !0, l || (s = po(
        t,
        "click",
        /*click_handler*/
        r[13]
      ), l = !0);
    },
    p(p, [m]) {
      c && c.p && (!i || m & /*$$scope*/
      2048) && Do(
        c,
        u,
        p,
        /*$$scope*/
        p[11],
        i ? so(
          u,
          /*$$scope*/
          p[11],
          m,
          null
        ) : lo(
          /*$$scope*/
          p[11]
        ),
        null
      ), (!i || m & /*_open*/
      8) && He(
        e,
        "open",
        /*_open*/
        p[3]
      ), (!i || m & /*prefersReducedMotion*/
      16) && He(
        e,
        "reduce-motion",
        /*prefersReducedMotion*/
        p[4]
      ), (!i || m & /*bring_to_front*/
      2) && He(
        e,
        "on-top",
        /*bring_to_front*/
        p[1]
      ), (!i || m & /*rounded_borders*/
      4) && He(
        e,
        "rounded",
        /*rounded_borders*/
        p[2]
      );
    },
    i(p) {
      i || (mo(c, p), i = !0);
    },
    o(p) {
      go(c, p), i = !1;
    },
    d(p) {
      p && mn(e), c && c.d(p), l = !1, s();
    }
  };
}
function yo(r, e, t) {
  let { $$slots: n = {}, $$scope: a } = e;
  const o = $o();
  let { open: i = !0 } = e, { height: l } = e, { width: s } = e, { bring_to_front: u = !1 } = e, { rounded_borders: c = !1 } = e, p = !1, m = !1, D = typeof s == "number" ? `${s}px` : s, g = typeof l == "number" ? `${l}px` : l, b;
  vo(() => {
    t(10, p = !0);
    const k = window.matchMedia("(prefers-reduced-motion: reduce)");
    t(4, b = k.matches);
    const f = (_) => {
      t(4, b = _.matches);
    };
    return k.addEventListener("change", f), () => {
      k.removeEventListener("change", f);
    };
  });
  const $ = () => {
    t(3, m = !m), t(0, i = m), o(m ? "expand" : "collapse");
  };
  return r.$$set = (k) => {
    "open" in k && t(0, i = k.open), "height" in k && t(8, l = k.height), "width" in k && t(9, s = k.width), "bring_to_front" in k && t(1, u = k.bring_to_front), "rounded_borders" in k && t(2, c = k.rounded_borders), "$$scope" in k && t(11, a = k.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*mounted, open*/
    1025 && p && t(3, m = i);
  }, [
    i,
    u,
    c,
    m,
    b,
    o,
    D,
    g,
    l,
    s,
    p,
    a,
    n,
    $
  ];
}
class Fo extends ao {
  constructor(e) {
    super(), co(this, e, yo, bo, fo, {
      open: 0,
      height: 8,
      width: 9,
      bring_to_front: 1,
      rounded_borders: 2
    });
  }
}
function ct(r) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; r > 1e3 && t < e.length - 1; )
    r /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(r) ? r : r.toFixed(1)) + n;
}
function Yt() {
}
const ha = typeof window < "u";
let Di = ha ? () => window.performance.now() : () => Date.now(), ma = ha ? (r) => requestAnimationFrame(r) : Yt;
const _t = /* @__PURE__ */ new Set();
function ga(r) {
  _t.forEach((e) => {
    e.c(r) || (_t.delete(e), e.f());
  }), _t.size !== 0 && ma(ga);
}
function wo(r) {
  let e;
  return _t.size === 0 && ma(ga), { promise: new Promise((t) => {
    _t.add(e = { c: r, f: t });
  }), abort() {
    _t.delete(e);
  } };
}
const st = [];
function Eo(r, e = Yt) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(i) {
    if (s = i, ((l = r) != l ? s == s : l !== s || l && typeof l == "object" || typeof l == "function") && (r = i, t)) {
      const u = !st.length;
      for (const c of n) c[1](), st.push(c, r);
      if (u) {
        for (let c = 0; c < st.length; c += 2) st[c][0](st[c + 1]);
        st.length = 0;
      }
    }
    var l, s;
  }
  function o(i) {
    a(i(r));
  }
  return { set: a, update: o, subscribe: function(i, l = Yt) {
    const s = [i, l];
    return n.add(s), n.size === 1 && (t = e(a, o) || Yt), i(r), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function $i(r) {
  return Object.prototype.toString.call(r) === "[object Date]";
}
function Cn(r, e, t, n) {
  if (typeof t == "number" || $i(t)) {
    const a = n - t, o = (t - e) / (r.dt || 1 / 60), i = (o + (r.opts.stiffness * a - r.opts.damping * o) * r.inv_mass) * r.dt;
    return Math.abs(i) < r.opts.precision && Math.abs(a) < r.opts.precision ? n : (r.settled = !1, $i(t) ? new Date(t.getTime() + i) : t + i);
  }
  if (Array.isArray(t)) return t.map((a, o) => Cn(r, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const a = {};
    for (const o in t) a[o] = Cn(r, e[o], t[o], n[o]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function vi(r, e = {}) {
  const t = Eo(r), { stiffness: n = 0.15, damping: a = 0.8, precision: o = 0.01 } = e;
  let i, l, s, u = r, c = r, p = 1, m = 0, D = !1;
  function g($, k = {}) {
    c = $;
    const f = s = {};
    return r == null || k.hard || b.stiffness >= 1 && b.damping >= 1 ? (D = !0, i = Di(), u = $, t.set(r = c), Promise.resolve()) : (k.soft && (m = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), p = 0), l || (i = Di(), D = !1, l = wo((_) => {
      if (D) return D = !1, l = null, !1;
      p = Math.min(p + m, 1);
      const h = { inv_mass: p, opts: b, settled: !0, dt: 60 * (_ - i) / 1e3 }, v = Cn(h, u, r, c);
      return i = _, u = r, t.set(r = v), h.settled && (l = null), !h.settled;
    })), new Promise((_) => {
      l.promise.then(() => {
        f === s && _();
      });
    }));
  }
  const b = { set: g, update: ($, k) => g($(c, r), k), subscribe: t.subscribe, stiffness: n, damping: a, precision: o };
  return b;
}
const {
  SvelteComponent: ko,
  append_hydration: ge,
  attr: L,
  children: ce,
  claim_element: Ao,
  claim_svg_element: De,
  component_subscribe: bi,
  detach: re,
  element: Co,
  init: So,
  insert_hydration: To,
  noop: yi,
  safe_not_equal: xo,
  set_style: Ot,
  svg_element: $e,
  toggle_class: Fi
} = window.__gradio__svelte__internal, { onMount: Bo } = window.__gradio__svelte__internal;
function Ro(r) {
  let e, t, n, a, o, i, l, s, u, c, p, m;
  return {
    c() {
      e = Co("div"), t = $e("svg"), n = $e("g"), a = $e("path"), o = $e("path"), i = $e("path"), l = $e("path"), s = $e("g"), u = $e("path"), c = $e("path"), p = $e("path"), m = $e("path"), this.h();
    },
    l(D) {
      e = Ao(D, "DIV", { class: !0 });
      var g = ce(e);
      t = De(g, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var b = ce(t);
      n = De(b, "g", { style: !0 });
      var $ = ce(n);
      a = De($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ce(a).forEach(re), o = De($, "path", { d: !0, fill: !0, class: !0 }), ce(o).forEach(re), i = De($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ce(i).forEach(re), l = De($, "path", { d: !0, fill: !0, class: !0 }), ce(l).forEach(re), $.forEach(re), s = De(b, "g", { style: !0 });
      var k = ce(s);
      u = De(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ce(u).forEach(re), c = De(k, "path", { d: !0, fill: !0, class: !0 }), ce(c).forEach(re), p = De(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ce(p).forEach(re), m = De(k, "path", { d: !0, fill: !0, class: !0 }), ce(m).forEach(re), k.forEach(re), b.forEach(re), g.forEach(re), this.h();
    },
    h() {
      L(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), L(a, "fill", "#FF7C00"), L(a, "fill-opacity", "0.4"), L(a, "class", "svelte-43sxxs"), L(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), L(o, "fill", "#FF7C00"), L(o, "class", "svelte-43sxxs"), L(i, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), L(i, "fill", "#FF7C00"), L(i, "fill-opacity", "0.4"), L(i, "class", "svelte-43sxxs"), L(l, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), L(l, "fill", "#FF7C00"), L(l, "class", "svelte-43sxxs"), Ot(n, "transform", "translate(" + /*$top*/
      r[1][0] + "px, " + /*$top*/
      r[1][1] + "px)"), L(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), L(u, "fill", "#FF7C00"), L(u, "fill-opacity", "0.4"), L(u, "class", "svelte-43sxxs"), L(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), L(c, "fill", "#FF7C00"), L(c, "class", "svelte-43sxxs"), L(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), L(p, "fill", "#FF7C00"), L(p, "fill-opacity", "0.4"), L(p, "class", "svelte-43sxxs"), L(m, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), L(m, "fill", "#FF7C00"), L(m, "class", "svelte-43sxxs"), Ot(s, "transform", "translate(" + /*$bottom*/
      r[2][0] + "px, " + /*$bottom*/
      r[2][1] + "px)"), L(t, "viewBox", "-1200 -1200 3000 3000"), L(t, "fill", "none"), L(t, "xmlns", "http://www.w3.org/2000/svg"), L(t, "class", "svelte-43sxxs"), L(e, "class", "svelte-43sxxs"), Fi(
        e,
        "margin",
        /*margin*/
        r[0]
      );
    },
    m(D, g) {
      To(D, e, g), ge(e, t), ge(t, n), ge(n, a), ge(n, o), ge(n, i), ge(n, l), ge(t, s), ge(s, u), ge(s, c), ge(s, p), ge(s, m);
    },
    p(D, [g]) {
      g & /*$top*/
      2 && Ot(n, "transform", "translate(" + /*$top*/
      D[1][0] + "px, " + /*$top*/
      D[1][1] + "px)"), g & /*$bottom*/
      4 && Ot(s, "transform", "translate(" + /*$bottom*/
      D[2][0] + "px, " + /*$bottom*/
      D[2][1] + "px)"), g & /*margin*/
      1 && Fi(
        e,
        "margin",
        /*margin*/
        D[0]
      );
    },
    i: yi,
    o: yi,
    d(D) {
      D && re(e);
    }
  };
}
function Io(r, e, t) {
  let n, a;
  var o = this && this.__awaiter || function(D, g, b, $) {
    function k(f) {
      return f instanceof b ? f : new b(function(_) {
        _(f);
      });
    }
    return new (b || (b = Promise))(function(f, _) {
      function h(E) {
        try {
          F($.next(E));
        } catch (x) {
          _(x);
        }
      }
      function v(E) {
        try {
          F($.throw(E));
        } catch (x) {
          _(x);
        }
      }
      function F(E) {
        E.done ? f(E.value) : k(E.value).then(h, v);
      }
      F(($ = $.apply(D, g || [])).next());
    });
  };
  let { margin: i = !0 } = e;
  const l = vi([0, 0]);
  bi(r, l, (D) => t(1, n = D));
  const s = vi([0, 0]);
  bi(r, s, (D) => t(2, a = D));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 140]), s.set([-125, -140])]), yield Promise.all([l.set([-125, 140]), s.set([125, -140])]), yield Promise.all([l.set([-125, 0]), s.set([125, -0])]), yield Promise.all([l.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function p() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || p();
    });
  }
  function m() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([l.set([125, 0]), s.set([-125, 0])]), p();
    });
  }
  return Bo(() => (m(), () => u = !0)), r.$$set = (D) => {
    "margin" in D && t(0, i = D.margin);
  }, [i, n, a, l, s];
}
class Lo extends ko {
  constructor(e) {
    super(), So(this, e, Io, Ro, xo, { margin: 0 });
  }
}
const {
  SvelteComponent: Is,
  append_hydration: Ls,
  assign: qs,
  attr: Os,
  binding_callbacks: Ms,
  children: Ns,
  claim_element: Ps,
  claim_space: zs,
  claim_svg_element: Us,
  create_slot: Hs,
  detach: Gs,
  element: js,
  empty: Ws,
  get_all_dirty_from_scope: Zs,
  get_slot_changes: Vs,
  get_spread_update: Ys,
  init: Xs,
  insert_hydration: Ks,
  listen: Qs,
  noop: Js,
  safe_not_equal: eu,
  set_dynamic_element_data: tu,
  set_style: nu,
  space: iu,
  svg_element: au,
  toggle_class: ou,
  transition_in: ru,
  transition_out: lu,
  update_slot_base: su
} = window.__gradio__svelte__internal;
function Nn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Qe = Nn();
function Da(r) {
  Qe = r;
}
const $a = /[&<>"']/, qo = new RegExp($a.source, "g"), va = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Oo = new RegExp(va.source, "g"), Mo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, wi = (r) => Mo[r];
function le(r, e) {
  if (e) {
    if ($a.test(r))
      return r.replace(qo, wi);
  } else if (va.test(r))
    return r.replace(Oo, wi);
  return r;
}
const No = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Po(r) {
  return r.replace(No, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const zo = /(^|[^\[])\^/g;
function N(r, e) {
  let t = typeof r == "string" ? r : r.source;
  e = e || "";
  const n = {
    replace: (a, o) => {
      let i = typeof o == "string" ? o : o.source;
      return i = i.replace(zo, "$1"), t = t.replace(a, i), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Ei(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const wt = { exec: () => null };
function ki(r, e) {
  const t = r.replace(/\|/g, (o, i, l) => {
    let s = !1, u = i;
    for (; --u >= 0 && l[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function Mt(r, e, t) {
  const n = r.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && r.charAt(n - a - 1) === e; )
    a++;
  return r.slice(0, n - a);
}
function Uo(r, e) {
  if (r.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < r.length; n++)
    if (r[n] === "\\")
      n++;
    else if (r[n] === e[0])
      t++;
    else if (r[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Ai(r, e, t, n) {
  const a = e.href, o = e.title ? le(e.title) : null, i = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const l = {
      type: "link",
      raw: t,
      href: a,
      title: o,
      text: i,
      tokens: n.inlineTokens(i)
    };
    return n.state.inLink = !1, l;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: o,
    text: le(i)
  };
}
function Ho(r, e) {
  const t = r.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const o = a.match(/^\s+/);
    if (o === null)
      return a;
    const [i] = o;
    return i.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class Jt {
  // set by the lexer
  constructor(e) {
    P(this, "options");
    P(this, "rules");
    // set by the lexer
    P(this, "lexer");
    this.options = e || Qe;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Mt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = Ho(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = Mt(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Mt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const i = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let l = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = i.exec(e)) || this.rules.block.hr.test(e))
          break;
        l = t[0], e = e.substring(l.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), m = e.split(`
`, 1)[0], D = 0;
        this.options.pedantic ? (D = 2, s = p.trimStart()) : (D = t[2].search(/[^ ]/), D = D > 4 ? 1 : D, s = p.slice(D), D += t[1].length);
        let g = !1;
        if (!p && /^ *$/.test(m) && (l += m + `
`, e = e.substring(m.length + 1), c = !0), !c) {
          const k = new RegExp(`^ {0,${Math.min(3, D - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), f = new RegExp(`^ {0,${Math.min(3, D - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, D - 1)}}(?:\`\`\`|~~~)`), h = new RegExp(`^ {0,${Math.min(3, D - 1)}}#`);
          for (; e; ) {
            const v = e.split(`
`, 1)[0];
            if (m = v, this.options.pedantic && (m = m.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(m) || h.test(m) || k.test(m) || f.test(e))
              break;
            if (m.search(/[^ ]/) >= D || !m.trim())
              s += `
` + m.slice(D);
            else {
              if (g || p.search(/[^ ]/) >= 4 || _.test(p) || h.test(p) || f.test(p))
                break;
              s += `
` + m;
            }
            !g && !m.trim() && (g = !0), l += v + `
`, e = e.substring(v.length + 1), p = m.slice(D);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(l) && (u = !0));
        let b = null, $;
        this.options.gfm && (b = /^\[[ xX]\] /.exec(s), b && ($ = b[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: l,
          task: !!b,
          checked: $,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += l;
      }
      o.items[o.items.length - 1].raw = l.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const p = o.items[c].tokens.filter((D) => D.type === "space"), m = p.length > 0 && p.some((D) => /\n.*\n/.test(D.raw));
          o.loose = m;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = ki(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], i = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const l of a)
        /^ *-+: *$/.test(l) ? i.align.push("right") : /^ *:-+: *$/.test(l) ? i.align.push("center") : /^ *:-+ *$/.test(l) ? i.align.push("left") : i.align.push(null);
      for (const l of n)
        i.header.push({
          text: l,
          tokens: this.lexer.inline(l)
        });
      for (const l of o)
        i.rows.push(ki(l, i.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return i;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: le(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const i = Mt(n.slice(0, -1), "\\");
        if ((n.length - i.length) % 2 === 0)
          return;
      } else {
        const i = Uo(t[2], "()");
        if (i > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + i;
          t[2] = t[2].substring(0, i), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], o = "";
      if (this.options.pedantic) {
        const i = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        i && (a = i[1], o = i[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), Ai(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), o = t[a.toLowerCase()];
      if (!o) {
        const i = n[0].charAt(0);
        return {
          type: "text",
          raw: i,
          text: i
        };
      }
      return Ai(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const i = [...a[0]].length - 1;
      let l, s, u = i, c = 0;
      const p = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + i); (a = p.exec(t)) != null; ) {
        if (l = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !l)
          continue;
        if (s = [...l].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && i % 3 && !((i + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const m = [...a[0]][0].length, D = e.slice(0, i + a.index + m + s);
        if (Math.min(i, s) % 2) {
          const b = D.slice(1, -1);
          return {
            type: "em",
            raw: D,
            text: b,
            tokens: this.lexer.inlineTokens(b)
          };
        }
        const g = D.slice(2, -2);
        return {
          type: "strong",
          raw: D,
          text: g,
          tokens: this.lexer.inlineTokens(g)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return a && o && (n = n.substring(1, n.length - 1)), n = le(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = le(t[1]), a = "mailto:" + n) : (n = le(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, o;
      if (t[2] === "@")
        a = le(t[0]), o = "mailto:" + a;
      else {
        let i;
        do
          i = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (i !== t[0]);
        a = le(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: o,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = le(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Go = /^(?: *(?:\n|$))+/, jo = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Wo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, At = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Zo = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, ba = /(?:[*+-]|\d{1,9}[.)])/, ya = N(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, ba).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Pn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Vo = /^[^\n]+/, zn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Yo = N(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", zn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Xo = N(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, ba).getRegex(), an = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Un = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ko = N("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Un).replace("tag", an).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Fa = N(Pn).replace("hr", At).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", an).getRegex(), Qo = N(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Fa).getRegex(), Hn = {
  blockquote: Qo,
  code: jo,
  def: Yo,
  fences: Wo,
  heading: Zo,
  hr: At,
  html: Ko,
  lheading: ya,
  list: Xo,
  newline: Go,
  paragraph: Fa,
  table: wt,
  text: Vo
}, Ci = N("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", At).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", an).getRegex(), Jo = {
  ...Hn,
  table: Ci,
  paragraph: N(Pn).replace("hr", At).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Ci).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", an).getRegex()
}, er = {
  ...Hn,
  html: N(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Un).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: wt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: N(Pn).replace("hr", At).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ya).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, wa = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, tr = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Ea = /^( {2,}|\\)\n(?!\s*$)/, nr = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Ct = "\\p{P}\\p{S}", ir = N(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Ct).getRegex(), ar = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, or = N(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Ct).getRegex(), rr = N("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Ct).getRegex(), lr = N("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Ct).getRegex(), sr = N(/\\([punct])/, "gu").replace(/punct/g, Ct).getRegex(), ur = N(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), cr = N(Un).replace("(?:-->|$)", "-->").getRegex(), _r = N("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", cr).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), en = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, dr = N(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", en).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ka = N(/^!?\[(label)\]\[(ref)\]/).replace("label", en).replace("ref", zn).getRegex(), Aa = N(/^!?\[(ref)\](?:\[\])?/).replace("ref", zn).getRegex(), pr = N("reflink|nolink(?!\\()", "g").replace("reflink", ka).replace("nolink", Aa).getRegex(), Gn = {
  _backpedal: wt,
  // only used for GFM url
  anyPunctuation: sr,
  autolink: ur,
  blockSkip: ar,
  br: Ea,
  code: tr,
  del: wt,
  emStrongLDelim: or,
  emStrongRDelimAst: rr,
  emStrongRDelimUnd: lr,
  escape: wa,
  link: dr,
  nolink: Aa,
  punctuation: ir,
  reflink: ka,
  reflinkSearch: pr,
  tag: _r,
  text: nr,
  url: wt
}, fr = {
  ...Gn,
  link: N(/^!?\[(label)\]\((.*?)\)/).replace("label", en).getRegex(),
  reflink: N(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", en).getRegex()
}, Sn = {
  ...Gn,
  escape: N(wa).replace("])", "~|])").getRegex(),
  url: N(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, hr = {
  ...Sn,
  br: N(Ea).replace("{2,}", "*").getRegex(),
  text: N(Sn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Nt = {
  normal: Hn,
  gfm: Jo,
  pedantic: er
}, mt = {
  normal: Gn,
  gfm: Sn,
  breaks: hr,
  pedantic: fr
};
class Ae {
  constructor(e) {
    P(this, "tokens");
    P(this, "options");
    P(this, "state");
    P(this, "tokenizer");
    P(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Qe, this.options.tokenizer = this.options.tokenizer || new Jt(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Nt.normal,
      inline: mt.normal
    };
    this.options.pedantic ? (t.block = Nt.pedantic, t.inline = mt.pedantic) : this.options.gfm && (t.block = Nt.gfm, this.options.breaks ? t.inline = mt.breaks : t.inline = mt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Nt,
      inline: mt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Ae(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Ae(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (l, s, u) => s + "    ".repeat(u.length));
    let n, a, o, i;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((l) => (n = l.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let l = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (l = Math.min(l, u));
          }), l < 1 / 0 && l >= 0 && (o = e.substring(0, l + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          a = t[t.length - 1], i && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), i = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const l = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(l);
            break;
          } else
            throw new Error(l);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, o, i = e, l, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (l = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; )
          c.includes(l[0].slice(l[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (l = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; )
      i = i.slice(0, l.index) + "[" + "a".repeat(l[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (l = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; )
      i = i.slice(0, l.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, i, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const p = e.slice(1);
          let m;
          this.options.extensions.startInline.forEach((D) => {
            m = D.call({ lexer: this }, p), typeof m == "number" && m >= 0 && (c = Math.min(c, m));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class tn {
  constructor(e) {
    P(this, "options");
    this.options = e || Qe;
  }
  code(e, t, n) {
    var o;
    const a = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + le(a) + '">' + (n ? e : le(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : le(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + o + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = Ei(e);
    if (a === null)
      return n;
    e = a;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const a = Ei(e);
    if (a === null)
      return n;
    e = a;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class jn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Ce {
  constructor(e) {
    P(this, "options");
    P(this, "renderer");
    P(this, "textRenderer");
    this.options = e || Qe, this.options.renderer = this.options.renderer || new tn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new jn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ce(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ce(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const i = o, l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(i.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const i = o;
          n += this.renderer.heading(this.parseInline(i.tokens), i.depth, Po(this.parseInline(i.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const i = o;
          n += this.renderer.code(i.text, i.lang, !!i.escaped);
          continue;
        }
        case "table": {
          const i = o;
          let l = "", s = "";
          for (let c = 0; c < i.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(i.header[c].tokens), { header: !0, align: i.align[c] });
          l += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < i.rows.length; c++) {
            const p = i.rows[c];
            s = "";
            for (let m = 0; m < p.length; m++)
              s += this.renderer.tablecell(this.parseInline(p[m].tokens), { header: !1, align: i.align[m] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(l, u);
          continue;
        }
        case "blockquote": {
          const i = o, l = this.parse(i.tokens);
          n += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          const i = o, l = i.ordered, s = i.start, u = i.loose;
          let c = "";
          for (let p = 0; p < i.items.length; p++) {
            const m = i.items[p], D = m.checked, g = m.task;
            let b = "";
            if (m.task) {
              const $ = this.renderer.checkbox(!!D);
              u ? m.tokens.length > 0 && m.tokens[0].type === "paragraph" ? (m.tokens[0].text = $ + " " + m.tokens[0].text, m.tokens[0].tokens && m.tokens[0].tokens.length > 0 && m.tokens[0].tokens[0].type === "text" && (m.tokens[0].tokens[0].text = $ + " " + m.tokens[0].tokens[0].text)) : m.tokens.unshift({
                type: "text",
                text: $ + " "
              }) : b += $ + " ";
            }
            b += this.parse(m.tokens, u), c += this.renderer.listitem(b, g, !!D);
          }
          n += this.renderer.list(c, l, s);
          continue;
        }
        case "html": {
          const i = o;
          n += this.renderer.html(i.text, i.block);
          continue;
        }
        case "paragraph": {
          const i = o;
          n += this.renderer.paragraph(this.parseInline(i.tokens));
          continue;
        }
        case "text": {
          let i = o, l = i.tokens ? this.parseInline(i.tokens) : i.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            i = e[++a], l += `
` + (i.tokens ? this.parseInline(i.tokens) : i.text);
          n += t ? this.renderer.paragraph(l) : l;
          continue;
        }
        default: {
          const i = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(i), "";
          throw new Error(i);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const i = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (i !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += i || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const i = o;
          n += t.text(i.text);
          break;
        }
        case "html": {
          const i = o;
          n += t.html(i.text);
          break;
        }
        case "link": {
          const i = o;
          n += t.link(i.href, i.title, this.parseInline(i.tokens, t));
          break;
        }
        case "image": {
          const i = o;
          n += t.image(i.href, i.title, i.text);
          break;
        }
        case "strong": {
          const i = o;
          n += t.strong(this.parseInline(i.tokens, t));
          break;
        }
        case "em": {
          const i = o;
          n += t.em(this.parseInline(i.tokens, t));
          break;
        }
        case "codespan": {
          const i = o;
          n += t.codespan(i.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const i = o;
          n += t.del(this.parseInline(i.tokens, t));
          break;
        }
        case "text": {
          const i = o;
          n += t.text(i.text);
          break;
        }
        default: {
          const i = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(i), "";
          throw new Error(i);
        }
      }
    }
    return n;
  }
}
class Et {
  constructor(e) {
    P(this, "options");
    this.options = e || Qe;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
P(Et, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Ke, Tn, Ca;
class mr {
  constructor(...e) {
    hi(this, Ke);
    P(this, "defaults", Nn());
    P(this, "options", this.setOptions);
    P(this, "parse", Lt(this, Ke, Tn).call(this, Ae.lex, Ce.parse));
    P(this, "parseInline", Lt(this, Ke, Tn).call(this, Ae.lexInline, Ce.parseInline));
    P(this, "Parser", Ce);
    P(this, "Renderer", tn);
    P(this, "TextRenderer", jn);
    P(this, "Lexer", Ae);
    P(this, "Tokenizer", Jt);
    P(this, "Hooks", Et);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, o;
    let n = [];
    for (const i of e)
      switch (n = n.concat(t.call(this, i)), i.type) {
        case "table": {
          const l = i;
          for (const s of l.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of l.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const l = i;
          n = n.concat(this.walkTokens(l.items, t));
          break;
        }
        default: {
          const l = i;
          (o = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && o[l.type] ? this.defaults.extensions.childTokens[l.type].forEach((s) => {
            const u = l[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : l.tokens && (n = n.concat(this.walkTokens(l.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const i = t.renderers[o.name];
          i ? t.renderers[o.name] = function(...l) {
            let s = o.renderer.apply(this, l);
            return s === !1 && (s = i.apply(this, l)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const i = t[o.level];
          i ? i.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), a.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new tn(this.defaults);
        for (const i in n.renderer) {
          if (!(i in o))
            throw new Error(`renderer '${i}' does not exist`);
          if (i === "options")
            continue;
          const l = i, s = n.renderer[l], u = o[l];
          o[l] = (...c) => {
            let p = s.apply(o, c);
            return p === !1 && (p = u.apply(o, c)), p || "";
          };
        }
        a.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new Jt(this.defaults);
        for (const i in n.tokenizer) {
          if (!(i in o))
            throw new Error(`tokenizer '${i}' does not exist`);
          if (["options", "rules", "lexer"].includes(i))
            continue;
          const l = i, s = n.tokenizer[l], u = o[l];
          o[l] = (...c) => {
            let p = s.apply(o, c);
            return p === !1 && (p = u.apply(o, c)), p;
          };
        }
        a.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new Et();
        for (const i in n.hooks) {
          if (!(i in o))
            throw new Error(`hook '${i}' does not exist`);
          if (i === "options")
            continue;
          const l = i, s = n.hooks[l], u = o[l];
          Et.passThroughHooks.has(i) ? o[l] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((m) => u.call(o, m));
            const p = s.call(o, c);
            return u.call(o, p);
          } : o[l] = (...c) => {
            let p = s.apply(o, c);
            return p === !1 && (p = u.apply(o, c)), p;
          };
        }
        a.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, i = n.walkTokens;
        a.walkTokens = function(l) {
          let s = [];
          return s.push(i.call(this, l)), o && (s = s.concat(o.call(this, l))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Ae.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ce.parse(e, t ?? this.defaults);
  }
}
Ke = new WeakSet(), Tn = function(e, t) {
  return (n, a) => {
    const o = { ...a }, i = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (i.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), i.async = !0);
    const l = Lt(this, Ke, Ca).call(this, !!i.silent, !!i.async);
    if (typeof n > "u" || n === null)
      return l(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return l(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (i.hooks && (i.hooks.options = i), i.async)
      return Promise.resolve(i.hooks ? i.hooks.preprocess(n) : n).then((s) => e(s, i)).then((s) => i.hooks ? i.hooks.processAllTokens(s) : s).then((s) => i.walkTokens ? Promise.all(this.walkTokens(s, i.walkTokens)).then(() => s) : s).then((s) => t(s, i)).then((s) => i.hooks ? i.hooks.postprocess(s) : s).catch(l);
    try {
      i.hooks && (n = i.hooks.preprocess(n));
      let s = e(n, i);
      i.hooks && (s = i.hooks.processAllTokens(s)), i.walkTokens && this.walkTokens(s, i.walkTokens);
      let u = t(s, i);
      return i.hooks && (u = i.hooks.postprocess(u)), u;
    } catch (s) {
      return l(s);
    }
  };
}, Ca = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + le(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Xe = new mr();
function M(r, e) {
  return Xe.parse(r, e);
}
M.options = M.setOptions = function(r) {
  return Xe.setOptions(r), M.defaults = Xe.defaults, Da(M.defaults), M;
};
M.getDefaults = Nn;
M.defaults = Qe;
M.use = function(...r) {
  return Xe.use(...r), M.defaults = Xe.defaults, Da(M.defaults), M;
};
M.walkTokens = function(r, e) {
  return Xe.walkTokens(r, e);
};
M.parseInline = Xe.parseInline;
M.Parser = Ce;
M.parser = Ce.parse;
M.Renderer = tn;
M.TextRenderer = jn;
M.Lexer = Ae;
M.lexer = Ae.lex;
M.Tokenizer = Jt;
M.Hooks = Et;
M.parse = M;
M.options;
M.setOptions;
M.use;
M.walkTokens;
M.parseInline;
Ce.parse;
Ae.lex;
const gr = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Dr = Object.hasOwnProperty;
class Sa {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = $r(e, t === !0);
    const o = a;
    for (; Dr.call(n.occurrences, a); )
      n.occurrences[o]++, a = o + "-" + n.occurrences[o];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function $r(r, e) {
  return typeof r != "string" ? "" : (e || (r = r.toLowerCase()), r.replace(gr, "").replace(/ /g, "-"));
}
new Sa();
var Si = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, vr = { exports: {} };
(function(r) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, i = {}, l = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function f(_) {
          return _ instanceof s ? new s(_.type, f(_.content), _.alias) : Array.isArray(_) ? _.map(f) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(f) {
          return Object.prototype.toString.call(f).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(f) {
          return f.__id || Object.defineProperty(f, "__id", { value: ++o }), f.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function f(_, h) {
          h = h || {};
          var v, F;
          switch (l.util.type(_)) {
            case "Object":
              if (F = l.util.objId(_), h[F])
                return h[F];
              v = /** @type {Record<string, any>} */
              {}, h[F] = v;
              for (var E in _)
                _.hasOwnProperty(E) && (v[E] = f(_[E], h));
              return (
                /** @type {any} */
                v
              );
            case "Array":
              return F = l.util.objId(_), h[F] ? h[F] : (v = [], h[F] = v, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(x, C) {
                v[C] = f(x, h);
              }), /** @type {any} */
              v);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(f) {
          for (; f; ) {
            var _ = a.exec(f.className);
            if (_)
              return _[1].toLowerCase();
            f = f.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(f, _) {
          f.className = f.className.replace(RegExp(a, "gi"), ""), f.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (v) {
            var f = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(v.stack) || [])[1];
            if (f) {
              var _ = document.getElementsByTagName("script");
              for (var h in _)
                if (_[h].src == f)
                  return _[h];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(f, _, h) {
          for (var v = "no-" + _; f; ) {
            var F = f.classList;
            if (F.contains(_))
              return !0;
            if (F.contains(v))
              return !1;
            f = f.parentElement;
          }
          return !!h;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: i,
        plaintext: i,
        text: i,
        txt: i,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(f, _) {
          var h = l.util.clone(l.languages[f]);
          for (var v in _)
            h[v] = _[v];
          return h;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(f, _, h, v) {
          v = v || /** @type {any} */
          l.languages;
          var F = v[f], E = {};
          for (var x in F)
            if (F.hasOwnProperty(x)) {
              if (x == _)
                for (var C in h)
                  h.hasOwnProperty(C) && (E[C] = h[C]);
              h.hasOwnProperty(x) || (E[x] = F[x]);
            }
          var q = v[f];
          return v[f] = E, l.languages.DFS(l.languages, function(R, W) {
            W === q && R != f && (this[R] = E);
          }), E;
        },
        // Traverse a language definition with Depth First Search
        DFS: function f(_, h, v, F) {
          F = F || {};
          var E = l.util.objId;
          for (var x in _)
            if (_.hasOwnProperty(x)) {
              h.call(_, x, _[x], v || x);
              var C = _[x], q = l.util.type(C);
              q === "Object" && !F[E(C)] ? (F[E(C)] = !0, f(C, h, null, F)) : q === "Array" && !F[E(C)] && (F[E(C)] = !0, f(C, h, x, F));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(f, _) {
        l.highlightAllUnder(document, f, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(f, _, h) {
        var v = {
          callback: h,
          container: f,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        l.hooks.run("before-highlightall", v), v.elements = Array.prototype.slice.apply(v.container.querySelectorAll(v.selector)), l.hooks.run("before-all-elements-highlight", v);
        for (var F = 0, E; E = v.elements[F++]; )
          l.highlightElement(E, _ === !0, v.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(f, _, h) {
        var v = l.util.getLanguage(f), F = l.languages[v];
        l.util.setLanguage(f, v);
        var E = f.parentElement;
        E && E.nodeName.toLowerCase() === "pre" && l.util.setLanguage(E, v);
        var x = f.textContent, C = {
          element: f,
          language: v,
          grammar: F,
          code: x
        };
        function q(W) {
          C.highlightedCode = W, l.hooks.run("before-insert", C), C.element.innerHTML = C.highlightedCode, l.hooks.run("after-highlight", C), l.hooks.run("complete", C), h && h.call(C.element);
        }
        if (l.hooks.run("before-sanity-check", C), E = C.element.parentElement, E && E.nodeName.toLowerCase() === "pre" && !E.hasAttribute("tabindex") && E.setAttribute("tabindex", "0"), !C.code) {
          l.hooks.run("complete", C), h && h.call(C.element);
          return;
        }
        if (l.hooks.run("before-highlight", C), !C.grammar) {
          q(l.util.encode(C.code));
          return;
        }
        if (_ && n.Worker) {
          var R = new Worker(l.filename);
          R.onmessage = function(W) {
            q(W.data);
          }, R.postMessage(JSON.stringify({
            language: C.language,
            code: C.code,
            immediateClose: !0
          }));
        } else
          q(l.highlight(C.code, C.grammar, C.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(f, _, h) {
        var v = {
          code: f,
          grammar: _,
          language: h
        };
        if (l.hooks.run("before-tokenize", v), !v.grammar)
          throw new Error('The language "' + v.language + '" has no grammar.');
        return v.tokens = l.tokenize(v.code, v.grammar), l.hooks.run("after-tokenize", v), s.stringify(l.util.encode(v.tokens), v.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(f, _) {
        var h = _.rest;
        if (h) {
          for (var v in h)
            _[v] = h[v];
          delete _.rest;
        }
        var F = new p();
        return m(F, F.head, f), c(f, F, _, F.head, 0), g(F);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(f, _) {
          var h = l.hooks.all;
          h[f] = h[f] || [], h[f].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(f, _) {
          var h = l.hooks.all[f];
          if (!(!h || !h.length))
            for (var v = 0, F; F = h[v++]; )
              F(_);
        }
      },
      Token: s
    };
    n.Prism = l;
    function s(f, _, h, v) {
      this.type = f, this.content = _, this.alias = h, this.length = (v || "").length | 0;
    }
    s.stringify = function f(_, h) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var v = "";
        return _.forEach(function(q) {
          v += f(q, h);
        }), v;
      }
      var F = {
        type: _.type,
        content: f(_.content, h),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: h
      }, E = _.alias;
      E && (Array.isArray(E) ? Array.prototype.push.apply(F.classes, E) : F.classes.push(E)), l.hooks.run("wrap", F);
      var x = "";
      for (var C in F.attributes)
        x += " " + C + '="' + (F.attributes[C] || "").replace(/"/g, "&quot;") + '"';
      return "<" + F.tag + ' class="' + F.classes.join(" ") + '"' + x + ">" + F.content + "</" + F.tag + ">";
    };
    function u(f, _, h, v) {
      f.lastIndex = _;
      var F = f.exec(h);
      if (F && v && F[1]) {
        var E = F[1].length;
        F.index += E, F[0] = F[0].slice(E);
      }
      return F;
    }
    function c(f, _, h, v, F, E) {
      for (var x in h)
        if (!(!h.hasOwnProperty(x) || !h[x])) {
          var C = h[x];
          C = Array.isArray(C) ? C : [C];
          for (var q = 0; q < C.length; ++q) {
            if (E && E.cause == x + "," + q)
              return;
            var R = C[q], W = R.inside, Re = !!R.lookbehind, ie = !!R.greedy, Ie = R.alias;
            if (ie && !R.pattern.global) {
              var se = R.pattern.toString().match(/[imsuy]*$/)[0];
              R.pattern = RegExp(R.pattern.source, se + "g");
            }
            for (var je = R.pattern || R, G = v.next, J = F; G !== _.tail && !(E && J >= E.reach); J += G.value.length, G = G.next) {
              var ue = G.value;
              if (_.length > f.length)
                return;
              if (!(ue instanceof s)) {
                var O = 1, Y;
                if (ie) {
                  if (Y = u(je, J, f, Re), !Y || Y.index >= f.length)
                    break;
                  var we = Y.index, j = Y.index + Y[0].length, oe = J;
                  for (oe += G.value.length; we >= oe; )
                    G = G.next, oe += G.value.length;
                  if (oe -= G.value.length, J = oe, G.value instanceof s)
                    continue;
                  for (var w = G; w !== _.tail && (oe < j || typeof w.value == "string"); w = w.next)
                    O++, oe += w.value.length;
                  O--, ue = f.slice(J, oe), Y.index -= J;
                } else if (Y = u(je, 0, ue, Re), !Y)
                  continue;
                var we = Y.index, Pe = Y[0], Je = ue.slice(0, we), et = ue.slice(we + Pe.length), tt = J + ue.length;
                E && tt > E.reach && (E.reach = tt);
                var We = G.prev;
                Je && (We = m(_, We, Je), J += Je.length), D(_, We, O);
                var ze = new s(x, W ? l.tokenize(Pe, W) : Pe, Ie, Pe);
                if (G = m(_, We, ze), et && m(_, G, et), O > 1) {
                  var Ue = {
                    cause: x + "," + q,
                    reach: tt
                  };
                  c(f, _, h, G.prev, J, Ue), E && Ue.reach > E.reach && (E.reach = Ue.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var f = { value: null, prev: null, next: null }, _ = { value: null, prev: f, next: null };
      f.next = _, this.head = f, this.tail = _, this.length = 0;
    }
    function m(f, _, h) {
      var v = _.next, F = { value: h, prev: _, next: v };
      return _.next = F, v.prev = F, f.length++, F;
    }
    function D(f, _, h) {
      for (var v = _.next, F = 0; F < h && v !== f.tail; F++)
        v = v.next;
      _.next = v, v.prev = _, f.length -= F;
    }
    function g(f) {
      for (var _ = [], h = f.head.next; h !== f.tail; )
        _.push(h.value), h = h.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (l.disableWorkerMessageHandler || n.addEventListener("message", function(f) {
        var _ = JSON.parse(f.data), h = _.language, v = _.code, F = _.immediateClose;
        n.postMessage(l.highlight(v, l.languages[h], h)), F && n.close();
      }, !1)), l;
    var b = l.util.currentScript();
    b && (l.filename = b.src, b.hasAttribute("data-manual") && (l.manual = !0));
    function $() {
      l.manual || l.highlightAll();
    }
    if (!l.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && b && b.defer ? document.addEventListener("DOMContentLoaded", $) : window.requestAnimationFrame ? window.requestAnimationFrame($) : window.setTimeout($, 16);
    }
    return l;
  }(e);
  r.exports && (r.exports = t), typeof Si < "u" && (Si.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, o) {
      var i = {};
      i["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, i.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var l = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: i
        }
      };
      l["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: l
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(b, $) {
      return "✖ Error " + b + " while fetching file: " + $;
    }, o = "✖ Error: File does not exist or is empty", i = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, l = "data-src-status", s = "loading", u = "loaded", c = "failed", p = "pre[data-src]:not([" + l + '="' + u + '"]):not([' + l + '="' + s + '"])';
    function m(b, $, k) {
      var f = new XMLHttpRequest();
      f.open("GET", b, !0), f.onreadystatechange = function() {
        f.readyState == 4 && (f.status < 400 && f.responseText ? $(f.responseText) : f.status >= 400 ? k(a(f.status, f.statusText)) : k(o));
      }, f.send(null);
    }
    function D(b) {
      var $ = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(b || "");
      if ($) {
        var k = Number($[1]), f = $[2], _ = $[3];
        return f ? _ ? [k, Number(_)] : [k, void 0] : [k, k];
      }
    }
    t.hooks.add("before-highlightall", function(b) {
      b.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(b) {
      var $ = (
        /** @type {HTMLPreElement} */
        b.element
      );
      if ($.matches(p)) {
        b.code = "", $.setAttribute(l, s);
        var k = $.appendChild(document.createElement("CODE"));
        k.textContent = n;
        var f = $.getAttribute("data-src"), _ = b.language;
        if (_ === "none") {
          var h = (/\.(\w+)$/.exec(f) || [, "none"])[1];
          _ = i[h] || h;
        }
        t.util.setLanguage(k, _), t.util.setLanguage($, _);
        var v = t.plugins.autoloader;
        v && v.loadLanguages(_), m(
          f,
          function(F) {
            $.setAttribute(l, u);
            var E = D($.getAttribute("data-range"));
            if (E) {
              var x = F.split(/\r\n?|\n/g), C = E[0], q = E[1] == null ? x.length : E[1];
              C < 0 && (C += x.length), C = Math.max(0, Math.min(C - 1, x.length)), q < 0 && (q += x.length), q = Math.max(0, Math.min(q, x.length)), F = x.slice(C, q).join(`
`), $.hasAttribute("data-start") || $.setAttribute("data-start", String(C + 1));
            }
            k.textContent = F, t.highlightElement(k);
          },
          function(F) {
            $.setAttribute(l, c), k.textContent = F;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function($) {
        for (var k = ($ || document).querySelectorAll(p), f = 0, _; _ = k[f++]; )
          t.highlightElement(_);
      }
    };
    var g = !1;
    t.fileHighlight = function() {
      g || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), g = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(vr);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = r.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, i = 0; i < a.length; i++)
    o[a[i]] = r.languages.bash[a[i]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
new Sa();
const br = (r) => {
  const e = {};
  for (let t = 0, n = r.length; t < n; t++) {
    const a = r[t];
    for (const o in a)
      e[o] ? e[o] = e[o].concat(a[o]) : e[o] = a[o];
  }
  return e;
}, yr = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Fr = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], wr = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
br([
  Object.fromEntries(yr.map((r) => [r, ["*"]])),
  Object.fromEntries(Fr.map((r) => [r, ["svg:*"]])),
  Object.fromEntries(wr.map((r) => [r, ["math:*"]]))
]);
const {
  HtmlTagHydration: uu,
  SvelteComponent: cu,
  attr: _u,
  binding_callbacks: du,
  children: pu,
  claim_element: fu,
  claim_html_tag: hu,
  detach: mu,
  element: gu,
  init: Du,
  insert_hydration: $u,
  noop: vu,
  safe_not_equal: bu,
  toggle_class: yu
} = window.__gradio__svelte__internal, { afterUpdate: Fu, tick: wu, onMount: Eu } = window.__gradio__svelte__internal, {
  SvelteComponent: ku,
  attr: Au,
  children: Cu,
  claim_component: Su,
  claim_element: Tu,
  create_component: xu,
  destroy_component: Bu,
  detach: Ru,
  element: Iu,
  init: Lu,
  insert_hydration: qu,
  mount_component: Ou,
  safe_not_equal: Mu,
  transition_in: Nu,
  transition_out: Pu
} = window.__gradio__svelte__internal, {
  SvelteComponent: zu,
  attr: Uu,
  check_outros: Hu,
  children: Gu,
  claim_component: ju,
  claim_element: Wu,
  claim_space: Zu,
  create_component: Vu,
  create_slot: Yu,
  destroy_component: Xu,
  detach: Ku,
  element: Qu,
  empty: Ju,
  get_all_dirty_from_scope: ec,
  get_slot_changes: tc,
  group_outros: nc,
  init: ic,
  insert_hydration: ac,
  mount_component: oc,
  safe_not_equal: rc,
  space: lc,
  toggle_class: sc,
  transition_in: uc,
  transition_out: cc,
  update_slot_base: _c
} = window.__gradio__svelte__internal, {
  SvelteComponent: dc,
  append_hydration: pc,
  attr: fc,
  children: hc,
  claim_component: mc,
  claim_element: gc,
  claim_space: Dc,
  claim_text: $c,
  create_component: vc,
  destroy_component: bc,
  detach: yc,
  element: Fc,
  init: wc,
  insert_hydration: Ec,
  mount_component: kc,
  safe_not_equal: Ac,
  set_data: Cc,
  space: Sc,
  text: Tc,
  toggle_class: xc,
  transition_in: Bc,
  transition_out: Rc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Er,
  append_hydration: Xt,
  attr: Me,
  bubble: kr,
  check_outros: Ar,
  children: xn,
  claim_component: Cr,
  claim_element: Bn,
  claim_space: Ti,
  claim_text: Sr,
  construct_svelte_component: xi,
  create_component: Bi,
  create_slot: Tr,
  destroy_component: Ri,
  detach: kt,
  element: Rn,
  get_all_dirty_from_scope: xr,
  get_slot_changes: Br,
  group_outros: Rr,
  init: Ir,
  insert_hydration: Ta,
  listen: Lr,
  mount_component: Ii,
  safe_not_equal: qr,
  set_data: Or,
  set_style: Pt,
  space: Li,
  text: Mr,
  toggle_class: Q,
  transition_in: Dn,
  transition_out: $n,
  update_slot_base: Nr
} = window.__gradio__svelte__internal;
function qi(r) {
  let e, t;
  return {
    c() {
      e = Rn("span"), t = Mr(
        /*label*/
        r[1]
      ), this.h();
    },
    l(n) {
      e = Bn(n, "SPAN", { class: !0 });
      var a = xn(e);
      t = Sr(
        a,
        /*label*/
        r[1]
      ), a.forEach(kt), this.h();
    },
    h() {
      Me(e, "class", "svelte-qgco6m");
    },
    m(n, a) {
      Ta(n, e, a), Xt(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && Or(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && kt(e);
    }
  };
}
function Pr(r) {
  let e, t, n, a, o, i, l, s, u = (
    /*show_label*/
    r[2] && qi(r)
  );
  var c = (
    /*Icon*/
    r[0]
  );
  function p(g, b) {
    return {};
  }
  c && (a = xi(c, p()));
  const m = (
    /*#slots*/
    r[14].default
  ), D = Tr(
    m,
    r,
    /*$$scope*/
    r[13],
    null
  );
  return {
    c() {
      e = Rn("button"), u && u.c(), t = Li(), n = Rn("div"), a && Bi(a.$$.fragment), o = Li(), D && D.c(), this.h();
    },
    l(g) {
      e = Bn(g, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var b = xn(e);
      u && u.l(b), t = Ti(b), n = Bn(b, "DIV", { class: !0 });
      var $ = xn(n);
      a && Cr(a.$$.fragment, $), o = Ti($), D && D.l($), $.forEach(kt), b.forEach(kt), this.h();
    },
    h() {
      Me(n, "class", "svelte-qgco6m"), Q(
        n,
        "x-small",
        /*size*/
        r[4] === "x-small"
      ), Q(
        n,
        "small",
        /*size*/
        r[4] === "small"
      ), Q(
        n,
        "large",
        /*size*/
        r[4] === "large"
      ), Q(
        n,
        "medium",
        /*size*/
        r[4] === "medium"
      ), e.disabled = /*disabled*/
      r[7], Me(
        e,
        "aria-label",
        /*label*/
        r[1]
      ), Me(
        e,
        "aria-haspopup",
        /*hasPopup*/
        r[8]
      ), Me(
        e,
        "title",
        /*label*/
        r[1]
      ), Me(e, "class", "svelte-qgco6m"), Q(
        e,
        "pending",
        /*pending*/
        r[3]
      ), Q(
        e,
        "padded",
        /*padded*/
        r[5]
      ), Q(
        e,
        "highlight",
        /*highlight*/
        r[6]
      ), Q(
        e,
        "transparent",
        /*transparent*/
        r[9]
      ), Pt(e, "color", !/*disabled*/
      r[7] && /*_color*/
      r[11] ? (
        /*_color*/
        r[11]
      ) : "var(--block-label-text-color)"), Pt(e, "--bg-color", /*disabled*/
      r[7] ? "auto" : (
        /*background*/
        r[10]
      ));
    },
    m(g, b) {
      Ta(g, e, b), u && u.m(e, null), Xt(e, t), Xt(e, n), a && Ii(a, n, null), Xt(n, o), D && D.m(n, null), i = !0, l || (s = Lr(
        e,
        "click",
        /*click_handler*/
        r[15]
      ), l = !0);
    },
    p(g, [b]) {
      if (/*show_label*/
      g[2] ? u ? u.p(g, b) : (u = qi(g), u.c(), u.m(e, t)) : u && (u.d(1), u = null), b & /*Icon*/
      1 && c !== (c = /*Icon*/
      g[0])) {
        if (a) {
          Rr();
          const $ = a;
          $n($.$$.fragment, 1, 0, () => {
            Ri($, 1);
          }), Ar();
        }
        c ? (a = xi(c, p()), Bi(a.$$.fragment), Dn(a.$$.fragment, 1), Ii(a, n, o)) : a = null;
      }
      D && D.p && (!i || b & /*$$scope*/
      8192) && Nr(
        D,
        m,
        g,
        /*$$scope*/
        g[13],
        i ? Br(
          m,
          /*$$scope*/
          g[13],
          b,
          null
        ) : xr(
          /*$$scope*/
          g[13]
        ),
        null
      ), (!i || b & /*size*/
      16) && Q(
        n,
        "x-small",
        /*size*/
        g[4] === "x-small"
      ), (!i || b & /*size*/
      16) && Q(
        n,
        "small",
        /*size*/
        g[4] === "small"
      ), (!i || b & /*size*/
      16) && Q(
        n,
        "large",
        /*size*/
        g[4] === "large"
      ), (!i || b & /*size*/
      16) && Q(
        n,
        "medium",
        /*size*/
        g[4] === "medium"
      ), (!i || b & /*disabled*/
      128) && (e.disabled = /*disabled*/
      g[7]), (!i || b & /*label*/
      2) && Me(
        e,
        "aria-label",
        /*label*/
        g[1]
      ), (!i || b & /*hasPopup*/
      256) && Me(
        e,
        "aria-haspopup",
        /*hasPopup*/
        g[8]
      ), (!i || b & /*label*/
      2) && Me(
        e,
        "title",
        /*label*/
        g[1]
      ), (!i || b & /*pending*/
      8) && Q(
        e,
        "pending",
        /*pending*/
        g[3]
      ), (!i || b & /*padded*/
      32) && Q(
        e,
        "padded",
        /*padded*/
        g[5]
      ), (!i || b & /*highlight*/
      64) && Q(
        e,
        "highlight",
        /*highlight*/
        g[6]
      ), (!i || b & /*transparent*/
      512) && Q(
        e,
        "transparent",
        /*transparent*/
        g[9]
      ), b & /*disabled, _color*/
      2176 && Pt(e, "color", !/*disabled*/
      g[7] && /*_color*/
      g[11] ? (
        /*_color*/
        g[11]
      ) : "var(--block-label-text-color)"), b & /*disabled, background*/
      1152 && Pt(e, "--bg-color", /*disabled*/
      g[7] ? "auto" : (
        /*background*/
        g[10]
      ));
    },
    i(g) {
      i || (a && Dn(a.$$.fragment, g), Dn(D, g), i = !0);
    },
    o(g) {
      a && $n(a.$$.fragment, g), $n(D, g), i = !1;
    },
    d(g) {
      g && kt(e), u && u.d(), a && Ri(a), D && D.d(g), l = !1, s();
    }
  };
}
function zr(r, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e, { Icon: i } = e, { label: l = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: p = !0 } = e, { highlight: m = !1 } = e, { disabled: D = !1 } = e, { hasPopup: g = !1 } = e, { color: b = "var(--block-label-text-color)" } = e, { transparent: $ = !1 } = e, { background: k = "var(--block-background-fill)" } = e;
  function f(_) {
    kr.call(this, r, _);
  }
  return r.$$set = (_) => {
    "Icon" in _ && t(0, i = _.Icon), "label" in _ && t(1, l = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, p = _.padded), "highlight" in _ && t(6, m = _.highlight), "disabled" in _ && t(7, D = _.disabled), "hasPopup" in _ && t(8, g = _.hasPopup), "color" in _ && t(12, b = _.color), "transparent" in _ && t(9, $ = _.transparent), "background" in _ && t(10, k = _.background), "$$scope" in _ && t(13, o = _.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty & /*highlight, color*/
    4160 && t(11, n = m ? "var(--color-accent)" : b);
  }, [
    i,
    l,
    s,
    u,
    c,
    p,
    m,
    D,
    g,
    $,
    k,
    n,
    b,
    o,
    a,
    f
  ];
}
class Ur extends Er {
  constructor(e) {
    super(), Ir(this, e, zr, Pr, qr, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Ic,
  append_hydration: Lc,
  attr: qc,
  binding_callbacks: Oc,
  children: Mc,
  claim_element: Nc,
  create_slot: Pc,
  detach: zc,
  element: Uc,
  get_all_dirty_from_scope: Hc,
  get_slot_changes: Gc,
  init: jc,
  insert_hydration: Wc,
  safe_not_equal: Zc,
  toggle_class: Vc,
  transition_in: Yc,
  transition_out: Xc,
  update_slot_base: Kc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qc,
  append_hydration: Jc,
  attr: e_,
  children: t_,
  claim_svg_element: n_,
  detach: i_,
  init: a_,
  insert_hydration: o_,
  noop: r_,
  safe_not_equal: l_,
  svg_element: s_
} = window.__gradio__svelte__internal, {
  SvelteComponent: u_,
  append_hydration: c_,
  attr: __,
  children: d_,
  claim_svg_element: p_,
  detach: f_,
  init: h_,
  insert_hydration: m_,
  noop: g_,
  safe_not_equal: D_,
  svg_element: $_
} = window.__gradio__svelte__internal, {
  SvelteComponent: v_,
  append_hydration: b_,
  attr: y_,
  children: F_,
  claim_svg_element: w_,
  detach: E_,
  init: k_,
  insert_hydration: A_,
  noop: C_,
  safe_not_equal: S_,
  svg_element: T_
} = window.__gradio__svelte__internal, {
  SvelteComponent: x_,
  append_hydration: B_,
  attr: R_,
  children: I_,
  claim_svg_element: L_,
  detach: q_,
  init: O_,
  insert_hydration: M_,
  noop: N_,
  safe_not_equal: P_,
  svg_element: z_
} = window.__gradio__svelte__internal, {
  SvelteComponent: U_,
  append_hydration: H_,
  attr: G_,
  children: j_,
  claim_svg_element: W_,
  detach: Z_,
  init: V_,
  insert_hydration: Y_,
  noop: X_,
  safe_not_equal: K_,
  svg_element: Q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: J_,
  append_hydration: ed,
  attr: td,
  children: nd,
  claim_svg_element: id,
  detach: ad,
  init: od,
  insert_hydration: rd,
  noop: ld,
  safe_not_equal: sd,
  svg_element: ud
} = window.__gradio__svelte__internal, {
  SvelteComponent: cd,
  append_hydration: _d,
  attr: dd,
  children: pd,
  claim_svg_element: fd,
  detach: hd,
  init: md,
  insert_hydration: gd,
  noop: Dd,
  safe_not_equal: $d,
  svg_element: vd
} = window.__gradio__svelte__internal, {
  SvelteComponent: bd,
  append_hydration: yd,
  attr: Fd,
  children: wd,
  claim_svg_element: Ed,
  detach: kd,
  init: Ad,
  insert_hydration: Cd,
  noop: Sd,
  safe_not_equal: Td,
  svg_element: xd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bd,
  append_hydration: Rd,
  attr: Id,
  children: Ld,
  claim_svg_element: qd,
  detach: Od,
  init: Md,
  insert_hydration: Nd,
  noop: Pd,
  safe_not_equal: zd,
  svg_element: Ud
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hd,
  append_hydration: Gd,
  attr: jd,
  children: Wd,
  claim_svg_element: Zd,
  detach: Vd,
  init: Yd,
  insert_hydration: Xd,
  noop: Kd,
  safe_not_equal: Qd,
  svg_element: Jd
} = window.__gradio__svelte__internal, {
  SvelteComponent: ep,
  append_hydration: tp,
  attr: np,
  children: ip,
  claim_svg_element: ap,
  detach: op,
  init: rp,
  insert_hydration: lp,
  noop: sp,
  safe_not_equal: up,
  svg_element: cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: _p,
  append_hydration: dp,
  attr: pp,
  children: fp,
  claim_svg_element: hp,
  detach: mp,
  init: gp,
  insert_hydration: Dp,
  noop: $p,
  safe_not_equal: vp,
  svg_element: bp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hr,
  append_hydration: vn,
  attr: ve,
  children: zt,
  claim_svg_element: Ut,
  detach: gt,
  init: Gr,
  insert_hydration: jr,
  noop: bn,
  safe_not_equal: Wr,
  set_style: ke,
  svg_element: Ht
} = window.__gradio__svelte__internal;
function Zr(r) {
  let e, t, n, a;
  return {
    c() {
      e = Ht("svg"), t = Ht("g"), n = Ht("path"), a = Ht("path"), this.h();
    },
    l(o) {
      e = Ut(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var i = zt(e);
      t = Ut(i, "g", { transform: !0 });
      var l = zt(t);
      n = Ut(l, "path", { d: !0, style: !0 }), zt(n).forEach(gt), l.forEach(gt), a = Ut(i, "path", { d: !0, style: !0 }), zt(a).forEach(gt), i.forEach(gt), this.h();
    },
    h() {
      ve(n, "d", "M18,6L6.087,17.913"), ke(n, "fill", "none"), ke(n, "fill-rule", "nonzero"), ke(n, "stroke-width", "2px"), ve(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), ve(a, "d", "M4.364,4.364L19.636,19.636"), ke(a, "fill", "none"), ke(a, "fill-rule", "nonzero"), ke(a, "stroke-width", "2px"), ve(e, "width", "100%"), ve(e, "height", "100%"), ve(e, "viewBox", "0 0 24 24"), ve(e, "version", "1.1"), ve(e, "xmlns", "http://www.w3.org/2000/svg"), ve(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), ve(e, "xml:space", "preserve"), ve(e, "stroke", "currentColor"), ke(e, "fill-rule", "evenodd"), ke(e, "clip-rule", "evenodd"), ke(e, "stroke-linecap", "round"), ke(e, "stroke-linejoin", "round");
    },
    m(o, i) {
      jr(o, e, i), vn(e, t), vn(t, n), vn(e, a);
    },
    p: bn,
    i: bn,
    o: bn,
    d(o) {
      o && gt(e);
    }
  };
}
class Vr extends Hr {
  constructor(e) {
    super(), Gr(this, e, null, Zr, Wr, {});
  }
}
const {
  SvelteComponent: yp,
  append_hydration: Fp,
  attr: wp,
  children: Ep,
  claim_svg_element: kp,
  detach: Ap,
  init: Cp,
  insert_hydration: Sp,
  noop: Tp,
  safe_not_equal: xp,
  svg_element: Bp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rp,
  append_hydration: Ip,
  attr: Lp,
  children: qp,
  claim_svg_element: Op,
  detach: Mp,
  init: Np,
  insert_hydration: Pp,
  noop: zp,
  safe_not_equal: Up,
  svg_element: Hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gp,
  append_hydration: jp,
  attr: Wp,
  children: Zp,
  claim_svg_element: Vp,
  detach: Yp,
  init: Xp,
  insert_hydration: Kp,
  noop: Qp,
  safe_not_equal: Jp,
  svg_element: ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: tf,
  append_hydration: nf,
  attr: af,
  children: of,
  claim_svg_element: rf,
  detach: lf,
  init: sf,
  insert_hydration: uf,
  noop: cf,
  safe_not_equal: _f,
  svg_element: df
} = window.__gradio__svelte__internal, {
  SvelteComponent: pf,
  append_hydration: ff,
  attr: hf,
  children: mf,
  claim_svg_element: gf,
  detach: Df,
  init: $f,
  insert_hydration: vf,
  noop: bf,
  safe_not_equal: yf,
  svg_element: Ff
} = window.__gradio__svelte__internal, {
  SvelteComponent: wf,
  append_hydration: Ef,
  attr: kf,
  children: Af,
  claim_svg_element: Cf,
  detach: Sf,
  init: Tf,
  insert_hydration: xf,
  noop: Bf,
  safe_not_equal: Rf,
  svg_element: If
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lf,
  append_hydration: qf,
  attr: Of,
  children: Mf,
  claim_svg_element: Nf,
  detach: Pf,
  init: zf,
  insert_hydration: Uf,
  noop: Hf,
  safe_not_equal: Gf,
  svg_element: jf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wf,
  append_hydration: Zf,
  attr: Vf,
  children: Yf,
  claim_svg_element: Xf,
  detach: Kf,
  init: Qf,
  insert_hydration: Jf,
  noop: eh,
  safe_not_equal: th,
  svg_element: nh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ih,
  append_hydration: ah,
  attr: oh,
  children: rh,
  claim_svg_element: lh,
  detach: sh,
  init: uh,
  insert_hydration: ch,
  noop: _h,
  safe_not_equal: dh,
  svg_element: ph
} = window.__gradio__svelte__internal, {
  SvelteComponent: fh,
  append_hydration: hh,
  attr: mh,
  children: gh,
  claim_svg_element: Dh,
  detach: $h,
  init: vh,
  insert_hydration: bh,
  noop: yh,
  safe_not_equal: Fh,
  svg_element: wh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eh,
  append_hydration: kh,
  attr: Ah,
  children: Ch,
  claim_svg_element: Sh,
  detach: Th,
  init: xh,
  insert_hydration: Bh,
  noop: Rh,
  safe_not_equal: Ih,
  svg_element: Lh
} = window.__gradio__svelte__internal, {
  SvelteComponent: qh,
  append_hydration: Oh,
  attr: Mh,
  children: Nh,
  claim_svg_element: Ph,
  detach: zh,
  init: Uh,
  insert_hydration: Hh,
  noop: Gh,
  safe_not_equal: jh,
  svg_element: Wh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zh,
  append_hydration: Vh,
  attr: Yh,
  children: Xh,
  claim_svg_element: Kh,
  detach: Qh,
  init: Jh,
  insert_hydration: em,
  noop: tm,
  safe_not_equal: nm,
  svg_element: im
} = window.__gradio__svelte__internal, {
  SvelteComponent: am,
  append_hydration: om,
  attr: rm,
  children: lm,
  claim_svg_element: sm,
  detach: um,
  init: cm,
  insert_hydration: _m,
  noop: dm,
  safe_not_equal: pm,
  svg_element: fm
} = window.__gradio__svelte__internal, {
  SvelteComponent: hm,
  append_hydration: mm,
  attr: gm,
  children: Dm,
  claim_svg_element: $m,
  detach: vm,
  init: bm,
  insert_hydration: ym,
  noop: Fm,
  safe_not_equal: wm,
  svg_element: Em
} = window.__gradio__svelte__internal, {
  SvelteComponent: km,
  append_hydration: Am,
  attr: Cm,
  children: Sm,
  claim_svg_element: Tm,
  detach: xm,
  init: Bm,
  insert_hydration: Rm,
  noop: Im,
  safe_not_equal: Lm,
  svg_element: qm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Om,
  append_hydration: Mm,
  attr: Nm,
  children: Pm,
  claim_svg_element: zm,
  detach: Um,
  init: Hm,
  insert_hydration: Gm,
  noop: jm,
  safe_not_equal: Wm,
  svg_element: Zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vm,
  append_hydration: Ym,
  attr: Xm,
  children: Km,
  claim_svg_element: Qm,
  detach: Jm,
  init: eg,
  insert_hydration: tg,
  noop: ng,
  safe_not_equal: ig,
  svg_element: ag
} = window.__gradio__svelte__internal, {
  SvelteComponent: og,
  append_hydration: rg,
  attr: lg,
  children: sg,
  claim_svg_element: ug,
  detach: cg,
  init: _g,
  insert_hydration: dg,
  noop: pg,
  safe_not_equal: fg,
  svg_element: hg
} = window.__gradio__svelte__internal, {
  SvelteComponent: mg,
  append_hydration: gg,
  attr: Dg,
  children: $g,
  claim_svg_element: vg,
  detach: bg,
  init: yg,
  insert_hydration: Fg,
  noop: wg,
  safe_not_equal: Eg,
  svg_element: kg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ag,
  append_hydration: Cg,
  attr: Sg,
  children: Tg,
  claim_svg_element: xg,
  detach: Bg,
  init: Rg,
  insert_hydration: Ig,
  noop: Lg,
  safe_not_equal: qg,
  svg_element: Og
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mg,
  append_hydration: Ng,
  attr: Pg,
  children: zg,
  claim_svg_element: Ug,
  detach: Hg,
  init: Gg,
  insert_hydration: jg,
  noop: Wg,
  safe_not_equal: Zg,
  svg_element: Vg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yg,
  append_hydration: Xg,
  attr: Kg,
  children: Qg,
  claim_svg_element: Jg,
  detach: e0,
  init: t0,
  insert_hydration: n0,
  noop: i0,
  safe_not_equal: a0,
  svg_element: o0
} = window.__gradio__svelte__internal, {
  SvelteComponent: r0,
  append_hydration: l0,
  attr: s0,
  children: u0,
  claim_svg_element: c0,
  detach: _0,
  init: d0,
  insert_hydration: p0,
  noop: f0,
  safe_not_equal: h0,
  svg_element: m0
} = window.__gradio__svelte__internal, {
  SvelteComponent: g0,
  append_hydration: D0,
  attr: $0,
  children: v0,
  claim_svg_element: b0,
  detach: y0,
  init: F0,
  insert_hydration: w0,
  noop: E0,
  safe_not_equal: k0,
  svg_element: A0
} = window.__gradio__svelte__internal, {
  SvelteComponent: C0,
  append_hydration: S0,
  attr: T0,
  children: x0,
  claim_svg_element: B0,
  detach: R0,
  init: I0,
  insert_hydration: L0,
  noop: q0,
  safe_not_equal: O0,
  svg_element: M0
} = window.__gradio__svelte__internal, {
  SvelteComponent: N0,
  append_hydration: P0,
  attr: z0,
  children: U0,
  claim_svg_element: H0,
  detach: G0,
  init: j0,
  insert_hydration: W0,
  noop: Z0,
  safe_not_equal: V0,
  svg_element: Y0
} = window.__gradio__svelte__internal, {
  SvelteComponent: X0,
  append_hydration: K0,
  attr: Q0,
  children: J0,
  claim_svg_element: e1,
  detach: t1,
  init: n1,
  insert_hydration: i1,
  noop: a1,
  safe_not_equal: o1,
  svg_element: r1
} = window.__gradio__svelte__internal, {
  SvelteComponent: l1,
  append_hydration: s1,
  attr: u1,
  children: c1,
  claim_svg_element: _1,
  detach: d1,
  init: p1,
  insert_hydration: f1,
  noop: h1,
  safe_not_equal: m1,
  svg_element: g1
} = window.__gradio__svelte__internal, {
  SvelteComponent: D1,
  append_hydration: $1,
  attr: v1,
  children: b1,
  claim_svg_element: y1,
  detach: F1,
  init: w1,
  insert_hydration: E1,
  noop: k1,
  safe_not_equal: A1,
  svg_element: C1
} = window.__gradio__svelte__internal, {
  SvelteComponent: S1,
  append_hydration: T1,
  attr: x1,
  children: B1,
  claim_svg_element: R1,
  detach: I1,
  init: L1,
  insert_hydration: q1,
  noop: O1,
  safe_not_equal: M1,
  svg_element: N1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append_hydration: z1,
  attr: U1,
  children: H1,
  claim_svg_element: G1,
  detach: j1,
  init: W1,
  insert_hydration: Z1,
  noop: V1,
  safe_not_equal: Y1,
  svg_element: X1
} = window.__gradio__svelte__internal, {
  SvelteComponent: K1,
  append_hydration: Q1,
  attr: J1,
  children: eD,
  claim_svg_element: tD,
  detach: nD,
  init: iD,
  insert_hydration: aD,
  noop: oD,
  safe_not_equal: rD,
  svg_element: lD
} = window.__gradio__svelte__internal, {
  SvelteComponent: sD,
  append_hydration: uD,
  attr: cD,
  children: _D,
  claim_svg_element: dD,
  detach: pD,
  init: fD,
  insert_hydration: hD,
  noop: mD,
  safe_not_equal: gD,
  svg_element: DD
} = window.__gradio__svelte__internal, {
  SvelteComponent: $D,
  append_hydration: vD,
  attr: bD,
  children: yD,
  claim_svg_element: FD,
  detach: wD,
  init: ED,
  insert_hydration: kD,
  noop: AD,
  safe_not_equal: CD,
  set_style: SD,
  svg_element: TD
} = window.__gradio__svelte__internal, {
  SvelteComponent: xD,
  append_hydration: BD,
  attr: RD,
  children: ID,
  claim_svg_element: LD,
  detach: qD,
  init: OD,
  insert_hydration: MD,
  noop: ND,
  safe_not_equal: PD,
  svg_element: zD
} = window.__gradio__svelte__internal, {
  SvelteComponent: UD,
  append_hydration: HD,
  attr: GD,
  children: jD,
  claim_svg_element: WD,
  detach: ZD,
  init: VD,
  insert_hydration: YD,
  noop: XD,
  safe_not_equal: KD,
  svg_element: QD
} = window.__gradio__svelte__internal, {
  SvelteComponent: JD,
  append_hydration: e$,
  attr: t$,
  children: n$,
  claim_svg_element: i$,
  detach: a$,
  init: o$,
  insert_hydration: r$,
  noop: l$,
  safe_not_equal: s$,
  svg_element: u$
} = window.__gradio__svelte__internal, {
  SvelteComponent: c$,
  append_hydration: _$,
  attr: d$,
  children: p$,
  claim_svg_element: f$,
  detach: h$,
  init: m$,
  insert_hydration: g$,
  noop: D$,
  safe_not_equal: $$,
  svg_element: v$
} = window.__gradio__svelte__internal, {
  SvelteComponent: b$,
  append_hydration: y$,
  attr: F$,
  children: w$,
  claim_svg_element: E$,
  detach: k$,
  init: A$,
  insert_hydration: C$,
  noop: S$,
  safe_not_equal: T$,
  svg_element: x$
} = window.__gradio__svelte__internal, {
  SvelteComponent: B$,
  append_hydration: R$,
  attr: I$,
  children: L$,
  claim_svg_element: q$,
  detach: O$,
  init: M$,
  insert_hydration: N$,
  noop: P$,
  safe_not_equal: z$,
  svg_element: U$
} = window.__gradio__svelte__internal, {
  SvelteComponent: H$,
  append_hydration: G$,
  attr: j$,
  children: W$,
  claim_svg_element: Z$,
  detach: V$,
  init: Y$,
  insert_hydration: X$,
  noop: K$,
  safe_not_equal: Q$,
  svg_element: J$
} = window.__gradio__svelte__internal, {
  SvelteComponent: ev,
  append_hydration: tv,
  attr: nv,
  children: iv,
  claim_svg_element: av,
  detach: ov,
  init: rv,
  insert_hydration: lv,
  noop: sv,
  safe_not_equal: uv,
  svg_element: cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: _v,
  append_hydration: dv,
  attr: pv,
  children: fv,
  claim_svg_element: hv,
  claim_text: mv,
  detach: gv,
  init: Dv,
  insert_hydration: $v,
  noop: vv,
  safe_not_equal: bv,
  svg_element: yv,
  text: Fv
} = window.__gradio__svelte__internal, {
  SvelteComponent: wv,
  append_hydration: Ev,
  attr: kv,
  children: Av,
  claim_svg_element: Cv,
  detach: Sv,
  init: Tv,
  insert_hydration: xv,
  noop: Bv,
  safe_not_equal: Rv,
  svg_element: Iv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lv,
  append_hydration: qv,
  attr: Ov,
  children: Mv,
  claim_svg_element: Nv,
  detach: Pv,
  init: zv,
  insert_hydration: Uv,
  noop: Hv,
  safe_not_equal: Gv,
  svg_element: jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wv,
  append_hydration: Zv,
  attr: Vv,
  children: Yv,
  claim_svg_element: Xv,
  detach: Kv,
  init: Qv,
  insert_hydration: Jv,
  noop: eb,
  safe_not_equal: tb,
  svg_element: nb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ib,
  append_hydration: ab,
  attr: ob,
  children: rb,
  claim_svg_element: lb,
  detach: sb,
  init: ub,
  insert_hydration: cb,
  noop: _b,
  safe_not_equal: db,
  svg_element: pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: fb,
  append_hydration: hb,
  attr: mb,
  children: gb,
  claim_svg_element: Db,
  detach: $b,
  init: vb,
  insert_hydration: bb,
  noop: yb,
  safe_not_equal: Fb,
  svg_element: wb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eb,
  append_hydration: kb,
  attr: Ab,
  children: Cb,
  claim_svg_element: Sb,
  detach: Tb,
  init: xb,
  insert_hydration: Bb,
  noop: Rb,
  safe_not_equal: Ib,
  svg_element: Lb
} = window.__gradio__svelte__internal, {
  SvelteComponent: qb,
  append_hydration: Ob,
  attr: Mb,
  children: Nb,
  claim_svg_element: Pb,
  detach: zb,
  init: Ub,
  insert_hydration: Hb,
  noop: Gb,
  safe_not_equal: jb,
  svg_element: Wb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zb,
  append_hydration: Vb,
  attr: Yb,
  children: Xb,
  claim_svg_element: Kb,
  claim_text: Qb,
  detach: Jb,
  init: ey,
  insert_hydration: ty,
  noop: ny,
  safe_not_equal: iy,
  svg_element: ay,
  text: oy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ry,
  append_hydration: ly,
  attr: sy,
  children: uy,
  claim_svg_element: cy,
  claim_text: _y,
  detach: dy,
  init: py,
  insert_hydration: fy,
  noop: hy,
  safe_not_equal: my,
  svg_element: gy,
  text: Dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: $y,
  append_hydration: vy,
  attr: by,
  children: yy,
  claim_svg_element: Fy,
  claim_text: wy,
  detach: Ey,
  init: ky,
  insert_hydration: Ay,
  noop: Cy,
  safe_not_equal: Sy,
  svg_element: Ty,
  text: xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: By,
  append_hydration: Ry,
  attr: Iy,
  children: Ly,
  claim_svg_element: qy,
  detach: Oy,
  init: My,
  insert_hydration: Ny,
  noop: Py,
  safe_not_equal: zy,
  svg_element: Uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hy,
  append_hydration: Gy,
  attr: jy,
  children: Wy,
  claim_svg_element: Zy,
  detach: Vy,
  init: Yy,
  insert_hydration: Xy,
  noop: Ky,
  safe_not_equal: Qy,
  svg_element: Jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: eF,
  append_hydration: tF,
  attr: nF,
  children: iF,
  claim_svg_element: aF,
  detach: oF,
  init: rF,
  insert_hydration: lF,
  noop: sF,
  safe_not_equal: uF,
  svg_element: cF
} = window.__gradio__svelte__internal, {
  SvelteComponent: _F,
  append_hydration: dF,
  attr: pF,
  children: fF,
  claim_svg_element: hF,
  detach: mF,
  init: gF,
  insert_hydration: DF,
  noop: $F,
  safe_not_equal: vF,
  svg_element: bF
} = window.__gradio__svelte__internal, {
  SvelteComponent: yF,
  append_hydration: FF,
  attr: wF,
  children: EF,
  claim_svg_element: kF,
  detach: AF,
  init: CF,
  insert_hydration: SF,
  noop: TF,
  safe_not_equal: xF,
  svg_element: BF
} = window.__gradio__svelte__internal, {
  SvelteComponent: RF,
  append_hydration: IF,
  attr: LF,
  children: qF,
  claim_svg_element: OF,
  detach: MF,
  init: NF,
  insert_hydration: PF,
  noop: zF,
  safe_not_equal: UF,
  svg_element: HF
} = window.__gradio__svelte__internal, {
  SvelteComponent: GF,
  append_hydration: jF,
  attr: WF,
  children: ZF,
  claim_svg_element: VF,
  detach: YF,
  init: XF,
  insert_hydration: KF,
  noop: QF,
  safe_not_equal: JF,
  svg_element: ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: tw,
  append_hydration: nw,
  attr: iw,
  children: aw,
  claim_svg_element: ow,
  detach: rw,
  init: lw,
  insert_hydration: sw,
  noop: uw,
  safe_not_equal: cw,
  svg_element: _w
} = window.__gradio__svelte__internal, Yr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Oi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Yr.reduce(
  (r, { color: e, primary: t, secondary: n }) => ({
    ...r,
    [e]: {
      primary: Oi[e][t],
      secondary: Oi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: dw,
  claim_component: pw,
  create_component: fw,
  destroy_component: hw,
  init: mw,
  mount_component: gw,
  safe_not_equal: Dw,
  transition_in: $w,
  transition_out: vw
} = window.__gradio__svelte__internal, { createEventDispatcher: bw } = window.__gradio__svelte__internal, {
  SvelteComponent: yw,
  append_hydration: Fw,
  attr: ww,
  check_outros: Ew,
  children: kw,
  claim_component: Aw,
  claim_element: Cw,
  claim_space: Sw,
  claim_text: Tw,
  create_component: xw,
  destroy_component: Bw,
  detach: Rw,
  element: Iw,
  empty: Lw,
  group_outros: qw,
  init: Ow,
  insert_hydration: Mw,
  mount_component: Nw,
  safe_not_equal: Pw,
  set_data: zw,
  space: Uw,
  text: Hw,
  toggle_class: Gw,
  transition_in: jw,
  transition_out: Ww
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zw,
  attr: Vw,
  children: Yw,
  claim_element: Xw,
  create_slot: Kw,
  detach: Qw,
  element: Jw,
  get_all_dirty_from_scope: eE,
  get_slot_changes: tE,
  init: nE,
  insert_hydration: iE,
  safe_not_equal: aE,
  toggle_class: oE,
  transition_in: rE,
  transition_out: lE,
  update_slot_base: sE
} = window.__gradio__svelte__internal, {
  SvelteComponent: uE,
  append_hydration: cE,
  attr: _E,
  check_outros: dE,
  children: pE,
  claim_component: fE,
  claim_element: hE,
  claim_space: mE,
  create_component: gE,
  destroy_component: DE,
  detach: $E,
  element: vE,
  empty: bE,
  group_outros: yE,
  init: FE,
  insert_hydration: wE,
  listen: EE,
  mount_component: kE,
  safe_not_equal: AE,
  space: CE,
  toggle_class: SE,
  transition_in: TE,
  transition_out: xE
} = window.__gradio__svelte__internal, {
  SvelteComponent: BE,
  attr: RE,
  children: IE,
  claim_element: LE,
  create_slot: qE,
  detach: OE,
  element: ME,
  get_all_dirty_from_scope: NE,
  get_slot_changes: PE,
  init: zE,
  insert_hydration: UE,
  null_to_empty: HE,
  safe_not_equal: GE,
  transition_in: jE,
  transition_out: WE,
  update_slot_base: ZE
} = window.__gradio__svelte__internal, {
  SvelteComponent: VE,
  check_outros: YE,
  claim_component: XE,
  create_component: KE,
  destroy_component: QE,
  detach: JE,
  empty: ek,
  group_outros: tk,
  init: nk,
  insert_hydration: ik,
  mount_component: ak,
  noop: ok,
  safe_not_equal: rk,
  transition_in: lk,
  transition_out: sk
} = window.__gradio__svelte__internal, { createEventDispatcher: uk } = window.__gradio__svelte__internal, {
  SvelteComponent: Xr,
  append_hydration: Ve,
  attr: Fe,
  binding_callbacks: Mi,
  check_outros: In,
  children: Se,
  claim_component: xa,
  claim_element: Te,
  claim_space: de,
  claim_text: U,
  create_component: Ba,
  create_slot: Ra,
  destroy_component: Ia,
  destroy_each: La,
  detach: T,
  element: xe,
  empty: fe,
  ensure_array_like: nn,
  get_all_dirty_from_scope: qa,
  get_slot_changes: Oa,
  group_outros: Ln,
  init: Kr,
  insert_hydration: B,
  mount_component: Ma,
  noop: qn,
  safe_not_equal: Qr,
  set_data: he,
  set_style: Ge,
  space: pe,
  text: H,
  toggle_class: _e,
  transition_in: ye,
  transition_out: Be,
  update_slot_base: Na
} = window.__gradio__svelte__internal, { tick: Jr } = window.__gradio__svelte__internal, { onDestroy: el } = window.__gradio__svelte__internal, { createEventDispatcher: tl } = window.__gradio__svelte__internal, nl = (r) => ({}), Ni = (r) => ({}), il = (r) => ({}), Pi = (r) => ({});
function zi(r, e, t) {
  const n = r.slice();
  return n[40] = e[t], n[42] = t, n;
}
function Ui(r, e, t) {
  const n = r.slice();
  return n[40] = e[t], n;
}
function al(r) {
  let e, t, n, a, o = (
    /*i18n*/
    r[1]("common.error") + ""
  ), i, l, s;
  t = new Ur({
    props: {
      Icon: Vr,
      label: (
        /*i18n*/
        r[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    r[32]
  );
  const u = (
    /*#slots*/
    r[30].error
  ), c = Ra(
    u,
    r,
    /*$$scope*/
    r[29],
    Ni
  );
  return {
    c() {
      e = xe("div"), Ba(t.$$.fragment), n = pe(), a = xe("span"), i = H(o), l = pe(), c && c.c(), this.h();
    },
    l(p) {
      e = Te(p, "DIV", { class: !0 });
      var m = Se(e);
      xa(t.$$.fragment, m), m.forEach(T), n = de(p), a = Te(p, "SPAN", { class: !0 });
      var D = Se(a);
      i = U(D, o), D.forEach(T), l = de(p), c && c.l(p), this.h();
    },
    h() {
      Fe(e, "class", "clear-status svelte-17v219f"), Fe(a, "class", "error svelte-17v219f");
    },
    m(p, m) {
      B(p, e, m), Ma(t, e, null), B(p, n, m), B(p, a, m), Ve(a, i), B(p, l, m), c && c.m(p, m), s = !0;
    },
    p(p, m) {
      const D = {};
      m[0] & /*i18n*/
      2 && (D.label = /*i18n*/
      p[1]("common.clear")), t.$set(D), (!s || m[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      p[1]("common.error") + "") && he(i, o), c && c.p && (!s || m[0] & /*$$scope*/
      536870912) && Na(
        c,
        u,
        p,
        /*$$scope*/
        p[29],
        s ? Oa(
          u,
          /*$$scope*/
          p[29],
          m,
          nl
        ) : qa(
          /*$$scope*/
          p[29]
        ),
        Ni
      );
    },
    i(p) {
      s || (ye(t.$$.fragment, p), ye(c, p), s = !0);
    },
    o(p) {
      Be(t.$$.fragment, p), Be(c, p), s = !1;
    },
    d(p) {
      p && (T(e), T(n), T(a), T(l)), Ia(t), c && c.d(p);
    }
  };
}
function ol(r) {
  let e, t, n, a, o, i, l, s, u, c = (
    /*variant*/
    r[8] === "default" && /*show_eta_bar*/
    r[18] && /*show_progress*/
    r[6] === "full" && Hi(r)
  );
  function p(_, h) {
    if (
      /*progress*/
      _[7]
    ) return sl;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return ll;
    if (
      /*queue_position*/
      _[2] === 0
    ) return rl;
  }
  let m = p(r), D = m && m(r), g = (
    /*timer*/
    r[5] && Wi(r)
  );
  const b = [dl, _l], $ = [];
  function k(_, h) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = k(r)) && (i = $[o] = b[o](r));
  let f = !/*timer*/
  r[5] && Ji(r);
  return {
    c() {
      c && c.c(), e = pe(), t = xe("div"), D && D.c(), n = pe(), g && g.c(), a = pe(), i && i.c(), l = pe(), f && f.c(), s = fe(), this.h();
    },
    l(_) {
      c && c.l(_), e = de(_), t = Te(_, "DIV", { class: !0 });
      var h = Se(t);
      D && D.l(h), n = de(h), g && g.l(h), h.forEach(T), a = de(_), i && i.l(_), l = de(_), f && f.l(_), s = fe(), this.h();
    },
    h() {
      Fe(t, "class", "progress-text svelte-17v219f"), _e(
        t,
        "meta-text-center",
        /*variant*/
        r[8] === "center"
      ), _e(
        t,
        "meta-text",
        /*variant*/
        r[8] === "default"
      );
    },
    m(_, h) {
      c && c.m(_, h), B(_, e, h), B(_, t, h), D && D.m(t, null), Ve(t, n), g && g.m(t, null), B(_, a, h), ~o && $[o].m(_, h), B(_, l, h), f && f.m(_, h), B(_, s, h), u = !0;
    },
    p(_, h) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, h) : (c = Hi(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), m === (m = p(_)) && D ? D.p(_, h) : (D && D.d(1), D = m && m(_), D && (D.c(), D.m(t, n))), /*timer*/
      _[5] ? g ? g.p(_, h) : (g = Wi(_), g.c(), g.m(t, null)) : g && (g.d(1), g = null), (!u || h[0] & /*variant*/
      256) && _e(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || h[0] & /*variant*/
      256) && _e(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let v = o;
      o = k(_), o === v ? ~o && $[o].p(_, h) : (i && (Ln(), Be($[v], 1, 1, () => {
        $[v] = null;
      }), In()), ~o ? (i = $[o], i ? i.p(_, h) : (i = $[o] = b[o](_), i.c()), ye(i, 1), i.m(l.parentNode, l)) : i = null), /*timer*/
      _[5] ? f && (Ln(), Be(f, 1, 1, () => {
        f = null;
      }), In()) : f ? (f.p(_, h), h[0] & /*timer*/
      32 && ye(f, 1)) : (f = Ji(_), f.c(), ye(f, 1), f.m(s.parentNode, s));
    },
    i(_) {
      u || (ye(i), ye(f), u = !0);
    },
    o(_) {
      Be(i), Be(f), u = !1;
    },
    d(_) {
      _ && (T(e), T(t), T(a), T(l), T(s)), c && c.d(_), D && D.d(), g && g.d(), ~o && $[o].d(_), f && f.d(_);
    }
  };
}
function Hi(r) {
  let e, t = `translateX(${/*eta_level*/
  (r[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = xe("div"), this.h();
    },
    l(n) {
      e = Te(n, "DIV", { class: !0 }), Se(e).forEach(T), this.h();
    },
    h() {
      Fe(e, "class", "eta-bar svelte-17v219f"), Ge(e, "transform", t);
    },
    m(n, a) {
      B(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ge(e, "transform", t);
    },
    d(n) {
      n && T(e);
    }
  };
}
function rl(r) {
  let e;
  return {
    c() {
      e = H("processing |");
    },
    l(t) {
      e = U(t, "processing |");
    },
    m(t, n) {
      B(t, e, n);
    },
    p: qn,
    d(t) {
      t && T(e);
    }
  };
}
function ll(r) {
  let e, t = (
    /*queue_position*/
    r[2] + 1 + ""
  ), n, a, o, i;
  return {
    c() {
      e = H("queue: "), n = H(t), a = H("/"), o = H(
        /*queue_size*/
        r[3]
      ), i = H(" |");
    },
    l(l) {
      e = U(l, "queue: "), n = U(l, t), a = U(l, "/"), o = U(
        l,
        /*queue_size*/
        r[3]
      ), i = U(l, " |");
    },
    m(l, s) {
      B(l, e, s), B(l, n, s), B(l, a, s), B(l, o, s), B(l, i, s);
    },
    p(l, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      l[2] + 1 + "") && he(n, t), s[0] & /*queue_size*/
      8 && he(
        o,
        /*queue_size*/
        l[3]
      );
    },
    d(l) {
      l && (T(e), T(n), T(a), T(o), T(i));
    }
  };
}
function sl(r) {
  let e, t = nn(
    /*progress*/
    r[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = ji(Ui(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = fe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = fe();
    },
    m(a, o) {
      for (let i = 0; i < n.length; i += 1)
        n[i] && n[i].m(a, o);
      B(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress*/
      128) {
        t = nn(
          /*progress*/
          a[7]
        );
        let i;
        for (i = 0; i < t.length; i += 1) {
          const l = Ui(a, t, i);
          n[i] ? n[i].p(l, o) : (n[i] = ji(l), n[i].c(), n[i].m(e.parentNode, e));
        }
        for (; i < n.length; i += 1)
          n[i].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && T(e), La(n, a);
    }
  };
}
function Gi(r) {
  let e, t = (
    /*p*/
    r[40].unit + ""
  ), n, a, o = " ", i;
  function l(c, p) {
    return (
      /*p*/
      c[40].length != null ? cl : ul
    );
  }
  let s = l(r), u = s(r);
  return {
    c() {
      u.c(), e = pe(), n = H(t), a = H(" | "), i = H(o);
    },
    l(c) {
      u.l(c), e = de(c), n = U(c, t), a = U(c, " | "), i = U(c, o);
    },
    m(c, p) {
      u.m(c, p), B(c, e, p), B(c, n, p), B(c, a, p), B(c, i, p);
    },
    p(c, p) {
      s === (s = l(c)) && u ? u.p(c, p) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), p[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && he(n, t);
    },
    d(c) {
      c && (T(e), T(n), T(a), T(i)), u.d(c);
    }
  };
}
function ul(r) {
  let e = ct(
    /*p*/
    r[40].index || 0
  ) + "", t;
  return {
    c() {
      t = H(e);
    },
    l(n) {
      t = U(n, e);
    },
    m(n, a) {
      B(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = ct(
        /*p*/
        n[40].index || 0
      ) + "") && he(t, e);
    },
    d(n) {
      n && T(t);
    }
  };
}
function cl(r) {
  let e = ct(
    /*p*/
    r[40].index || 0
  ) + "", t, n, a = ct(
    /*p*/
    r[40].length
  ) + "", o;
  return {
    c() {
      t = H(e), n = H("/"), o = H(a);
    },
    l(i) {
      t = U(i, e), n = U(i, "/"), o = U(i, a);
    },
    m(i, l) {
      B(i, t, l), B(i, n, l), B(i, o, l);
    },
    p(i, l) {
      l[0] & /*progress*/
      128 && e !== (e = ct(
        /*p*/
        i[40].index || 0
      ) + "") && he(t, e), l[0] & /*progress*/
      128 && a !== (a = ct(
        /*p*/
        i[40].length
      ) + "") && he(o, a);
    },
    d(i) {
      i && (T(t), T(n), T(o));
    }
  };
}
function ji(r) {
  let e, t = (
    /*p*/
    r[40].index != null && Gi(r)
  );
  return {
    c() {
      t && t.c(), e = fe();
    },
    l(n) {
      t && t.l(n), e = fe();
    },
    m(n, a) {
      t && t.m(n, a), B(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].index != null ? t ? t.p(n, a) : (t = Gi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && T(e), t && t.d(n);
    }
  };
}
function Wi(r) {
  let e, t = (
    /*eta*/
    r[0] ? `/${/*formatted_eta*/
    r[19]}` : ""
  ), n, a;
  return {
    c() {
      e = H(
        /*formatted_timer*/
        r[20]
      ), n = H(t), a = H("s");
    },
    l(o) {
      e = U(
        o,
        /*formatted_timer*/
        r[20]
      ), n = U(o, t), a = U(o, "s");
    },
    m(o, i) {
      B(o, e, i), B(o, n, i), B(o, a, i);
    },
    p(o, i) {
      i[0] & /*formatted_timer*/
      1048576 && he(
        e,
        /*formatted_timer*/
        o[20]
      ), i[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && he(n, t);
    },
    d(o) {
      o && (T(e), T(n), T(a));
    }
  };
}
function _l(r) {
  let e, t;
  return e = new Lo({
    props: { margin: (
      /*variant*/
      r[8] === "default"
    ) }
  }), {
    c() {
      Ba(e.$$.fragment);
    },
    l(n) {
      xa(e.$$.fragment, n);
    },
    m(n, a) {
      Ma(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Be(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ia(e, n);
    }
  };
}
function dl(r) {
  let e, t, n, a, o, i = `${/*last_progress_level*/
  r[15] * 100}%`, l = (
    /*progress*/
    r[7] != null && Zi(r)
  );
  return {
    c() {
      e = xe("div"), t = xe("div"), l && l.c(), n = pe(), a = xe("div"), o = xe("div"), this.h();
    },
    l(s) {
      e = Te(s, "DIV", { class: !0 });
      var u = Se(e);
      t = Te(u, "DIV", { class: !0 });
      var c = Se(t);
      l && l.l(c), c.forEach(T), n = de(u), a = Te(u, "DIV", { class: !0 });
      var p = Se(a);
      o = Te(p, "DIV", { class: !0 }), Se(o).forEach(T), p.forEach(T), u.forEach(T), this.h();
    },
    h() {
      Fe(t, "class", "progress-level-inner svelte-17v219f"), Fe(o, "class", "progress-bar svelte-17v219f"), Ge(o, "width", i), Fe(a, "class", "progress-bar-wrap svelte-17v219f"), Fe(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      B(s, e, u), Ve(e, t), l && l.m(t, null), Ve(e, n), Ve(e, a), Ve(a, o), r[31](o);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? l ? l.p(s, u) : (l = Zi(s), l.c(), l.m(t, null)) : l && (l.d(1), l = null), u[0] & /*last_progress_level*/
      32768 && i !== (i = `${/*last_progress_level*/
      s[15] * 100}%`) && Ge(o, "width", i);
    },
    i: qn,
    o: qn,
    d(s) {
      s && T(e), l && l.d(), r[31](null);
    }
  };
}
function Zi(r) {
  let e, t = nn(
    /*progress*/
    r[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Qi(zi(r, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = fe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = fe();
    },
    m(a, o) {
      for (let i = 0; i < n.length; i += 1)
        n[i] && n[i].m(a, o);
      B(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = nn(
          /*progress*/
          a[7]
        );
        let i;
        for (i = 0; i < t.length; i += 1) {
          const l = zi(a, t, i);
          n[i] ? n[i].p(l, o) : (n[i] = Qi(l), n[i].c(), n[i].m(e.parentNode, e));
        }
        for (; i < n.length; i += 1)
          n[i].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && T(e), La(n, a);
    }
  };
}
function Vi(r) {
  let e, t, n, a, o = (
    /*i*/
    r[42] !== 0 && pl()
  ), i = (
    /*p*/
    r[40].desc != null && Yi(r)
  ), l = (
    /*p*/
    r[40].desc != null && /*progress_level*/
    r[14] && /*progress_level*/
    r[14][
      /*i*/
      r[42]
    ] != null && Xi()
  ), s = (
    /*progress_level*/
    r[14] != null && Ki(r)
  );
  return {
    c() {
      o && o.c(), e = pe(), i && i.c(), t = pe(), l && l.c(), n = pe(), s && s.c(), a = fe();
    },
    l(u) {
      o && o.l(u), e = de(u), i && i.l(u), t = de(u), l && l.l(u), n = de(u), s && s.l(u), a = fe();
    },
    m(u, c) {
      o && o.m(u, c), B(u, e, c), i && i.m(u, c), B(u, t, c), l && l.m(u, c), B(u, n, c), s && s.m(u, c), B(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? i ? i.p(u, c) : (i = Yi(u), i.c(), i.m(t.parentNode, t)) : i && (i.d(1), i = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? l || (l = Xi(), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Ki(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (T(e), T(t), T(n), T(a)), o && o.d(u), i && i.d(u), l && l.d(u), s && s.d(u);
    }
  };
}
function pl(r) {
  let e;
  return {
    c() {
      e = H(" /");
    },
    l(t) {
      e = U(t, " /");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && T(e);
    }
  };
}
function Yi(r) {
  let e = (
    /*p*/
    r[40].desc + ""
  ), t;
  return {
    c() {
      t = H(e);
    },
    l(n) {
      t = U(n, e);
    },
    m(n, a) {
      B(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && he(t, e);
    },
    d(n) {
      n && T(t);
    }
  };
}
function Xi(r) {
  let e;
  return {
    c() {
      e = H("-");
    },
    l(t) {
      e = U(t, "-");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && T(e);
    }
  };
}
function Ki(r) {
  let e = (100 * /*progress_level*/
  (r[14][
    /*i*/
    r[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = H(e), n = H("%");
    },
    l(a) {
      t = U(a, e), n = U(a, "%");
    },
    m(a, o) {
      B(a, t, o), B(a, n, o);
    },
    p(a, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && he(t, e);
    },
    d(a) {
      a && (T(t), T(n));
    }
  };
}
function Qi(r) {
  let e, t = (
    /*p*/
    (r[40].desc != null || /*progress_level*/
    r[14] && /*progress_level*/
    r[14][
      /*i*/
      r[42]
    ] != null) && Vi(r)
  );
  return {
    c() {
      t && t.c(), e = fe();
    },
    l(n) {
      t && t.l(n), e = fe();
    },
    m(n, a) {
      t && t.m(n, a), B(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, a) : (t = Vi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && T(e), t && t.d(n);
    }
  };
}
function Ji(r) {
  let e, t, n, a;
  const o = (
    /*#slots*/
    r[30]["additional-loading-text"]
  ), i = Ra(
    o,
    r,
    /*$$scope*/
    r[29],
    Pi
  );
  return {
    c() {
      e = xe("p"), t = H(
        /*loading_text*/
        r[9]
      ), n = pe(), i && i.c(), this.h();
    },
    l(l) {
      e = Te(l, "P", { class: !0 });
      var s = Se(e);
      t = U(
        s,
        /*loading_text*/
        r[9]
      ), s.forEach(T), n = de(l), i && i.l(l), this.h();
    },
    h() {
      Fe(e, "class", "loading svelte-17v219f");
    },
    m(l, s) {
      B(l, e, s), Ve(e, t), B(l, n, s), i && i.m(l, s), a = !0;
    },
    p(l, s) {
      (!a || s[0] & /*loading_text*/
      512) && he(
        t,
        /*loading_text*/
        l[9]
      ), i && i.p && (!a || s[0] & /*$$scope*/
      536870912) && Na(
        i,
        o,
        l,
        /*$$scope*/
        l[29],
        a ? Oa(
          o,
          /*$$scope*/
          l[29],
          s,
          il
        ) : qa(
          /*$$scope*/
          l[29]
        ),
        Pi
      );
    },
    i(l) {
      a || (ye(i, l), a = !0);
    },
    o(l) {
      Be(i, l), a = !1;
    },
    d(l) {
      l && (T(e), T(n)), i && i.d(l);
    }
  };
}
function fl(r) {
  let e, t, n, a, o;
  const i = [ol, al], l = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(r)) && (n = l[t] = i[t](r)), {
    c() {
      e = xe("div"), n && n.c(), this.h();
    },
    l(u) {
      e = Te(u, "DIV", { class: !0 });
      var c = Se(e);
      n && n.l(c), c.forEach(T), this.h();
    },
    h() {
      Fe(e, "class", a = "wrap " + /*variant*/
      r[8] + " " + /*show_progress*/
      r[6] + " svelte-17v219f"), _e(e, "hide", !/*status*/
      r[4] || /*status*/
      r[4] === "complete" || /*show_progress*/
      r[6] === "hidden" || /*status*/
      r[4] == "streaming"), _e(
        e,
        "translucent",
        /*variant*/
        r[8] === "center" && /*status*/
        (r[4] === "pending" || /*status*/
        r[4] === "error") || /*translucent*/
        r[11] || /*show_progress*/
        r[6] === "minimal"
      ), _e(
        e,
        "generating",
        /*status*/
        r[4] === "generating" && /*show_progress*/
        r[6] === "full"
      ), _e(
        e,
        "border",
        /*border*/
        r[12]
      ), Ge(
        e,
        "position",
        /*absolute*/
        r[10] ? "absolute" : "static"
      ), Ge(
        e,
        "padding",
        /*absolute*/
        r[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      B(u, e, c), ~t && l[t].m(e, null), r[33](e), o = !0;
    },
    p(u, c) {
      let p = t;
      t = s(u), t === p ? ~t && l[t].p(u, c) : (n && (Ln(), Be(l[p], 1, 1, () => {
        l[p] = null;
      }), In()), ~t ? (n = l[t], n ? n.p(u, c) : (n = l[t] = i[t](u), n.c()), ye(n, 1), n.m(e, null)) : n = null), (!o || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Fe(e, "class", a), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && _e(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && _e(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && _e(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && _e(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Ge(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Ge(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (ye(n), o = !0);
    },
    o(u) {
      Be(n), o = !1;
    },
    d(u) {
      u && T(e), ~t && l[t].d(), r[33](null);
    }
  };
}
var hl = function(r, e, t, n) {
  function a(o) {
    return o instanceof t ? o : new t(function(i) {
      i(o);
    });
  }
  return new (t || (t = Promise))(function(o, i) {
    function l(c) {
      try {
        u(n.next(c));
      } catch (p) {
        i(p);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (p) {
        i(p);
      }
    }
    function u(c) {
      c.done ? o(c.value) : a(c.value).then(l, s);
    }
    u((n = n.apply(r, e || [])).next());
  });
};
let Gt = [], yn = !1;
const ml = typeof window < "u", Pa = ml ? window.requestAnimationFrame : (r) => {
};
function gl(r) {
  return hl(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (Gt.push(e), !yn) yn = !0;
      else return;
      yield Jr(), Pa(() => {
        let n = [0, 0];
        for (let a = 0; a < Gt.length; a++) {
          const i = Gt[a].getBoundingClientRect();
          (a === 0 || i.top + window.scrollY <= n[0]) && (n[0] = i.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), yn = !1, Gt = [];
      });
    }
  });
}
function Dl(r, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e;
  const i = tl();
  let { i18n: l } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: p } = e, { scroll_to_output: m = !1 } = e, { timer: D = !0 } = e, { show_progress: g = "full" } = e, { message: b = null } = e, { progress: $ = null } = e, { variant: k = "default" } = e, { loading_text: f = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: h = !1 } = e, { border: v = !1 } = e, { autoscroll: F } = e, E, x = !1, C = 0, q = 0, R = null, W = null, Re = 0, ie = null, Ie, se = null, je = !0;
  const G = () => {
    t(0, s = t(27, R = t(19, O = null))), t(25, C = performance.now()), t(26, q = 0), x = !0, J();
  };
  function J() {
    Pa(() => {
      t(26, q = (performance.now() - C) / 1e3), x && J();
    });
  }
  function ue() {
    t(26, q = 0), t(0, s = t(27, R = t(19, O = null))), x && (x = !1);
  }
  el(() => {
    x && ue();
  });
  let O = null;
  function Y(w) {
    Mi[w ? "unshift" : "push"](() => {
      se = w, t(16, se), t(7, $), t(14, ie), t(15, Ie);
    });
  }
  const j = () => {
    i("clear_status");
  };
  function oe(w) {
    Mi[w ? "unshift" : "push"](() => {
      E = w, t(13, E);
    });
  }
  return r.$$set = (w) => {
    "i18n" in w && t(1, l = w.i18n), "eta" in w && t(0, s = w.eta), "queue_position" in w && t(2, u = w.queue_position), "queue_size" in w && t(3, c = w.queue_size), "status" in w && t(4, p = w.status), "scroll_to_output" in w && t(22, m = w.scroll_to_output), "timer" in w && t(5, D = w.timer), "show_progress" in w && t(6, g = w.show_progress), "message" in w && t(23, b = w.message), "progress" in w && t(7, $ = w.progress), "variant" in w && t(8, k = w.variant), "loading_text" in w && t(9, f = w.loading_text), "absolute" in w && t(10, _ = w.absolute), "translucent" in w && t(11, h = w.translucent), "border" in w && t(12, v = w.border), "autoscroll" in w && t(24, F = w.autoscroll), "$$scope" in w && t(29, o = w.$$scope);
  }, r.$$.update = () => {
    r.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = R), s != null && R !== s && (t(28, W = (performance.now() - C) / 1e3 + s), t(19, O = W.toFixed(1)), t(27, R = s))), r.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, Re = W === null || W <= 0 || !q ? null : Math.min(q / W, 1)), r.$$.dirty[0] & /*progress*/
    128 && $ != null && t(18, je = !1), r.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && ($ != null ? t(14, ie = $.map((w) => {
      if (w.index != null && w.length != null)
        return w.index / w.length;
      if (w.progress != null)
        return w.progress;
    })) : t(14, ie = null), ie ? (t(15, Ie = ie[ie.length - 1]), se && (Ie === 0 ? t(16, se.style.transition = "0", se) : t(16, se.style.transition = "150ms", se))) : t(15, Ie = void 0)), r.$$.dirty[0] & /*status*/
    16 && (p === "pending" ? G() : ue()), r.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && E && m && (p === "pending" || p === "complete") && gl(E, F), r.$$.dirty[0] & /*status, message*/
    8388624, r.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = q.toFixed(1));
  }, [
    s,
    l,
    u,
    c,
    p,
    D,
    g,
    $,
    k,
    f,
    _,
    h,
    v,
    E,
    ie,
    Ie,
    se,
    Re,
    je,
    O,
    n,
    i,
    m,
    b,
    F,
    C,
    q,
    R,
    W,
    o,
    a,
    Y,
    j,
    oe
  ];
}
class za extends Xr {
  constructor(e) {
    super(), Kr(
      this,
      e,
      Dl,
      fl,
      Qr,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Ua,
  setPrototypeOf: ea,
  isFrozen: $l,
  getPrototypeOf: vl,
  getOwnPropertyDescriptor: bl
} = Object;
let {
  freeze: te,
  seal: me,
  create: Ha
} = Object, {
  apply: On,
  construct: Mn
} = typeof Reflect < "u" && Reflect;
te || (te = function(e) {
  return e;
});
me || (me = function(e) {
  return e;
});
On || (On = function(e, t, n) {
  return e.apply(t, n);
});
Mn || (Mn = function(e, t) {
  return new e(...t);
});
const jt = ne(Array.prototype.forEach), yl = ne(Array.prototype.lastIndexOf), ta = ne(Array.prototype.pop), Dt = ne(Array.prototype.push), Fl = ne(Array.prototype.splice), Kt = ne(String.prototype.toLowerCase), Fn = ne(String.prototype.toString), na = ne(String.prototype.match), $t = ne(String.prototype.replace), wl = ne(String.prototype.indexOf), El = ne(String.prototype.trim), be = ne(Object.prototype.hasOwnProperty), ee = ne(RegExp.prototype.test), vt = kl(TypeError);
function ne(r) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return On(r, e, n);
  };
}
function kl(r) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return Mn(r, t);
  };
}
function I(r, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Kt;
  ea && ea(r, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const o = t(a);
      o !== a && ($l(e) || (e[n] = o), a = o);
    }
    r[a] = !0;
  }
  return r;
}
function Al(r) {
  for (let e = 0; e < r.length; e++)
    be(r, e) || (r[e] = null);
  return r;
}
function Ne(r) {
  const e = Ha(null);
  for (const [t, n] of Ua(r))
    be(r, t) && (Array.isArray(n) ? e[t] = Al(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = Ne(n) : e[t] = n);
  return e;
}
function bt(r, e) {
  for (; r !== null; ) {
    const n = bl(r, e);
    if (n) {
      if (n.get)
        return ne(n.get);
      if (typeof n.value == "function")
        return ne(n.value);
    }
    r = vl(r);
  }
  function t() {
    return null;
  }
  return t;
}
const ia = te(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), wn = te(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), En = te(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Cl = te(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), kn = te(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Sl = te(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), aa = te(["#text"]), oa = te(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), An = te(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), ra = te(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Wt = te(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Tl = me(/\{\{[\w\W]*|[\w\W]*\}\}/gm), xl = me(/<%[\w\W]*|[\w\W]*%>/gm), Bl = me(/\$\{[\w\W]*/gm), Rl = me(/^data-[\-\w.\u00B7-\uFFFF]+$/), Il = me(/^aria-[\-\w]+$/), Ga = me(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Ll = me(/^(?:\w+script|data):/i), ql = me(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), ja = me(/^html$/i), Ol = me(/^[a-z][.\w]*(-[.\w]+)+$/i);
var la = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: Il,
  ATTR_WHITESPACE: ql,
  CUSTOM_ELEMENT: Ol,
  DATA_ATTR: Rl,
  DOCTYPE_NAME: ja,
  ERB_EXPR: xl,
  IS_ALLOWED_URI: Ga,
  IS_SCRIPT_OR_DATA: Ll,
  MUSTACHE_EXPR: Tl,
  TMPLIT_EXPR: Bl
});
const yt = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Ml = function() {
  return typeof window > "u" ? null : window;
}, Nl = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const o = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(o, {
      createHTML(i) {
        return i;
      },
      createScriptURL(i) {
        return i;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + o + " could not be created."), null;
  }
}, sa = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Wa() {
  let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Ml();
  const e = (S) => Wa(S);
  if (e.version = "3.2.6", e.removed = [], !r || !r.document || r.document.nodeType !== yt.document || !r.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = r;
  const n = t, a = n.currentScript, {
    DocumentFragment: o,
    HTMLTemplateElement: i,
    Node: l,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = r.NamedNodeMap || r.MozNamedAttrMap,
    HTMLFormElement: p,
    DOMParser: m,
    trustedTypes: D
  } = r, g = s.prototype, b = bt(g, "cloneNode"), $ = bt(g, "remove"), k = bt(g, "nextSibling"), f = bt(g, "childNodes"), _ = bt(g, "parentNode");
  if (typeof i == "function") {
    const S = t.createElement("template");
    S.content && S.content.ownerDocument && (t = S.content.ownerDocument);
  }
  let h, v = "";
  const {
    implementation: F,
    createNodeIterator: E,
    createDocumentFragment: x,
    getElementsByTagName: C
  } = t, {
    importNode: q
  } = n;
  let R = sa();
  e.isSupported = typeof Ua == "function" && typeof _ == "function" && F && F.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: W,
    ERB_EXPR: Re,
    TMPLIT_EXPR: ie,
    DATA_ATTR: Ie,
    ARIA_ATTR: se,
    IS_SCRIPT_OR_DATA: je,
    ATTR_WHITESPACE: G,
    CUSTOM_ELEMENT: J
  } = la;
  let {
    IS_ALLOWED_URI: ue
  } = la, O = null;
  const Y = I({}, [...ia, ...wn, ...En, ...kn, ...aa]);
  let j = null;
  const oe = I({}, [...oa, ...An, ...ra, ...Wt]);
  let w = Object.seal(Ha(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), we = null, Pe = null, Je = !0, et = !0, tt = !1, We = !0, ze = !1, Ue = !0, Ze = !1, on = !1, rn = !1, nt = !1, St = !1, Tt = !1, Xn = !0, Kn = !1;
  const Za = "user-content-";
  let ln = !0, pt = !1, it = {}, at = null;
  const Qn = I({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Jn = null;
  const ei = I({}, ["audio", "video", "img", "source", "image", "track"]);
  let sn = null;
  const ti = I({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), xt = "http://www.w3.org/1998/Math/MathML", Bt = "http://www.w3.org/2000/svg", Le = "http://www.w3.org/1999/xhtml";
  let ot = Le, un = !1, cn = null;
  const Va = I({}, [xt, Bt, Le], Fn);
  let Rt = I({}, ["mi", "mo", "mn", "ms", "mtext"]), It = I({}, ["annotation-xml"]);
  const Ya = I({}, ["title", "style", "font", "a", "script"]);
  let ft = null;
  const Xa = ["application/xhtml+xml", "text/html"], Ka = "text/html";
  let V = null, rt = null;
  const Qa = t.createElement("form"), ni = function(d) {
    return d instanceof RegExp || d instanceof Function;
  }, _n = function() {
    let d = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(rt && rt === d)) {
      if ((!d || typeof d != "object") && (d = {}), d = Ne(d), ft = // eslint-disable-next-line unicorn/prefer-includes
      Xa.indexOf(d.PARSER_MEDIA_TYPE) === -1 ? Ka : d.PARSER_MEDIA_TYPE, V = ft === "application/xhtml+xml" ? Fn : Kt, O = be(d, "ALLOWED_TAGS") ? I({}, d.ALLOWED_TAGS, V) : Y, j = be(d, "ALLOWED_ATTR") ? I({}, d.ALLOWED_ATTR, V) : oe, cn = be(d, "ALLOWED_NAMESPACES") ? I({}, d.ALLOWED_NAMESPACES, Fn) : Va, sn = be(d, "ADD_URI_SAFE_ATTR") ? I(Ne(ti), d.ADD_URI_SAFE_ATTR, V) : ti, Jn = be(d, "ADD_DATA_URI_TAGS") ? I(Ne(ei), d.ADD_DATA_URI_TAGS, V) : ei, at = be(d, "FORBID_CONTENTS") ? I({}, d.FORBID_CONTENTS, V) : Qn, we = be(d, "FORBID_TAGS") ? I({}, d.FORBID_TAGS, V) : Ne({}), Pe = be(d, "FORBID_ATTR") ? I({}, d.FORBID_ATTR, V) : Ne({}), it = be(d, "USE_PROFILES") ? d.USE_PROFILES : !1, Je = d.ALLOW_ARIA_ATTR !== !1, et = d.ALLOW_DATA_ATTR !== !1, tt = d.ALLOW_UNKNOWN_PROTOCOLS || !1, We = d.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ze = d.SAFE_FOR_TEMPLATES || !1, Ue = d.SAFE_FOR_XML !== !1, Ze = d.WHOLE_DOCUMENT || !1, nt = d.RETURN_DOM || !1, St = d.RETURN_DOM_FRAGMENT || !1, Tt = d.RETURN_TRUSTED_TYPE || !1, rn = d.FORCE_BODY || !1, Xn = d.SANITIZE_DOM !== !1, Kn = d.SANITIZE_NAMED_PROPS || !1, ln = d.KEEP_CONTENT !== !1, pt = d.IN_PLACE || !1, ue = d.ALLOWED_URI_REGEXP || Ga, ot = d.NAMESPACE || Le, Rt = d.MATHML_TEXT_INTEGRATION_POINTS || Rt, It = d.HTML_INTEGRATION_POINTS || It, w = d.CUSTOM_ELEMENT_HANDLING || {}, d.CUSTOM_ELEMENT_HANDLING && ni(d.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (w.tagNameCheck = d.CUSTOM_ELEMENT_HANDLING.tagNameCheck), d.CUSTOM_ELEMENT_HANDLING && ni(d.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (w.attributeNameCheck = d.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), d.CUSTOM_ELEMENT_HANDLING && typeof d.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (w.allowCustomizedBuiltInElements = d.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ze && (et = !1), St && (nt = !0), it && (O = I({}, aa), j = [], it.html === !0 && (I(O, ia), I(j, oa)), it.svg === !0 && (I(O, wn), I(j, An), I(j, Wt)), it.svgFilters === !0 && (I(O, En), I(j, An), I(j, Wt)), it.mathMl === !0 && (I(O, kn), I(j, ra), I(j, Wt))), d.ADD_TAGS && (O === Y && (O = Ne(O)), I(O, d.ADD_TAGS, V)), d.ADD_ATTR && (j === oe && (j = Ne(j)), I(j, d.ADD_ATTR, V)), d.ADD_URI_SAFE_ATTR && I(sn, d.ADD_URI_SAFE_ATTR, V), d.FORBID_CONTENTS && (at === Qn && (at = Ne(at)), I(at, d.FORBID_CONTENTS, V)), ln && (O["#text"] = !0), Ze && I(O, ["html", "head", "body"]), O.table && (I(O, ["tbody"]), delete we.tbody), d.TRUSTED_TYPES_POLICY) {
        if (typeof d.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw vt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof d.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw vt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        h = d.TRUSTED_TYPES_POLICY, v = h.createHTML("");
      } else
        h === void 0 && (h = Nl(D, a)), h !== null && typeof v == "string" && (v = h.createHTML(""));
      te && te(d), rt = d;
    }
  }, ii = I({}, [...wn, ...En, ...Cl]), ai = I({}, [...kn, ...Sl]), Ja = function(d) {
    let y = _(d);
    (!y || !y.tagName) && (y = {
      namespaceURI: ot,
      tagName: "template"
    });
    const A = Kt(d.tagName), z = Kt(y.tagName);
    return cn[d.namespaceURI] ? d.namespaceURI === Bt ? y.namespaceURI === Le ? A === "svg" : y.namespaceURI === xt ? A === "svg" && (z === "annotation-xml" || Rt[z]) : !!ii[A] : d.namespaceURI === xt ? y.namespaceURI === Le ? A === "math" : y.namespaceURI === Bt ? A === "math" && It[z] : !!ai[A] : d.namespaceURI === Le ? y.namespaceURI === Bt && !It[z] || y.namespaceURI === xt && !Rt[z] ? !1 : !ai[A] && (Ya[A] || !ii[A]) : !!(ft === "application/xhtml+xml" && cn[d.namespaceURI]) : !1;
  }, Ee = function(d) {
    Dt(e.removed, {
      element: d
    });
    try {
      _(d).removeChild(d);
    } catch {
      $(d);
    }
  }, lt = function(d, y) {
    try {
      Dt(e.removed, {
        attribute: y.getAttributeNode(d),
        from: y
      });
    } catch {
      Dt(e.removed, {
        attribute: null,
        from: y
      });
    }
    if (y.removeAttribute(d), d === "is")
      if (nt || St)
        try {
          Ee(y);
        } catch {
        }
      else
        try {
          y.setAttribute(d, "");
        } catch {
        }
  }, oi = function(d) {
    let y = null, A = null;
    if (rn)
      d = "<remove></remove>" + d;
    else {
      const Z = na(d, /^[\r\n\t ]+/);
      A = Z && Z[0];
    }
    ft === "application/xhtml+xml" && ot === Le && (d = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + d + "</body></html>");
    const z = h ? h.createHTML(d) : d;
    if (ot === Le)
      try {
        y = new m().parseFromString(z, ft);
      } catch {
      }
    if (!y || !y.documentElement) {
      y = F.createDocument(ot, "template", null);
      try {
        y.documentElement.innerHTML = un ? v : z;
      } catch {
      }
    }
    const X = y.body || y.documentElement;
    return d && A && X.insertBefore(t.createTextNode(A), X.childNodes[0] || null), ot === Le ? C.call(y, Ze ? "html" : "body")[0] : Ze ? y.documentElement : X;
  }, ri = function(d) {
    return E.call(
      d.ownerDocument || d,
      d,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, dn = function(d) {
    return d instanceof p && (typeof d.nodeName != "string" || typeof d.textContent != "string" || typeof d.removeChild != "function" || !(d.attributes instanceof c) || typeof d.removeAttribute != "function" || typeof d.setAttribute != "function" || typeof d.namespaceURI != "string" || typeof d.insertBefore != "function" || typeof d.hasChildNodes != "function");
  }, li = function(d) {
    return typeof l == "function" && d instanceof l;
  };
  function qe(S, d, y) {
    jt(S, (A) => {
      A.call(e, d, y, rt);
    });
  }
  const si = function(d) {
    let y = null;
    if (qe(R.beforeSanitizeElements, d, null), dn(d))
      return Ee(d), !0;
    const A = V(d.nodeName);
    if (qe(R.uponSanitizeElement, d, {
      tagName: A,
      allowedTags: O
    }), Ue && d.hasChildNodes() && !li(d.firstElementChild) && ee(/<[/\w!]/g, d.innerHTML) && ee(/<[/\w!]/g, d.textContent) || d.nodeType === yt.progressingInstruction || Ue && d.nodeType === yt.comment && ee(/<[/\w]/g, d.data))
      return Ee(d), !0;
    if (!O[A] || we[A]) {
      if (!we[A] && ci(A) && (w.tagNameCheck instanceof RegExp && ee(w.tagNameCheck, A) || w.tagNameCheck instanceof Function && w.tagNameCheck(A)))
        return !1;
      if (ln && !at[A]) {
        const z = _(d) || d.parentNode, X = f(d) || d.childNodes;
        if (X && z) {
          const Z = X.length;
          for (let ae = Z - 1; ae >= 0; --ae) {
            const Oe = b(X[ae], !0);
            Oe.__removalCount = (d.__removalCount || 0) + 1, z.insertBefore(Oe, k(d));
          }
        }
      }
      return Ee(d), !0;
    }
    return d instanceof s && !Ja(d) || (A === "noscript" || A === "noembed" || A === "noframes") && ee(/<\/no(script|embed|frames)/i, d.innerHTML) ? (Ee(d), !0) : (ze && d.nodeType === yt.text && (y = d.textContent, jt([W, Re, ie], (z) => {
      y = $t(y, z, " ");
    }), d.textContent !== y && (Dt(e.removed, {
      element: d.cloneNode()
    }), d.textContent = y)), qe(R.afterSanitizeElements, d, null), !1);
  }, ui = function(d, y, A) {
    if (Xn && (y === "id" || y === "name") && (A in t || A in Qa))
      return !1;
    if (!(et && !Pe[y] && ee(Ie, y))) {
      if (!(Je && ee(se, y))) {
        if (!j[y] || Pe[y]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(ci(d) && (w.tagNameCheck instanceof RegExp && ee(w.tagNameCheck, d) || w.tagNameCheck instanceof Function && w.tagNameCheck(d)) && (w.attributeNameCheck instanceof RegExp && ee(w.attributeNameCheck, y) || w.attributeNameCheck instanceof Function && w.attributeNameCheck(y)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            y === "is" && w.allowCustomizedBuiltInElements && (w.tagNameCheck instanceof RegExp && ee(w.tagNameCheck, A) || w.tagNameCheck instanceof Function && w.tagNameCheck(A)))
          ) return !1;
        } else if (!sn[y]) {
          if (!ee(ue, $t(A, G, ""))) {
            if (!((y === "src" || y === "xlink:href" || y === "href") && d !== "script" && wl(A, "data:") === 0 && Jn[d])) {
              if (!(tt && !ee(je, $t(A, G, "")))) {
                if (A)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, ci = function(d) {
    return d !== "annotation-xml" && na(d, J);
  }, _i = function(d) {
    qe(R.beforeSanitizeAttributes, d, null);
    const {
      attributes: y
    } = d;
    if (!y || dn(d))
      return;
    const A = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: j,
      forceKeepAttr: void 0
    };
    let z = y.length;
    for (; z--; ) {
      const X = y[z], {
        name: Z,
        namespaceURI: ae,
        value: Oe
      } = X, ht = V(Z), pn = Oe;
      let K = Z === "value" ? pn : El(pn);
      if (A.attrName = ht, A.attrValue = K, A.keepAttr = !0, A.forceKeepAttr = void 0, qe(R.uponSanitizeAttribute, d, A), K = A.attrValue, Kn && (ht === "id" || ht === "name") && (lt(Z, d), K = Za + K), Ue && ee(/((--!?|])>)|<\/(style|title)/i, K)) {
        lt(Z, d);
        continue;
      }
      if (A.forceKeepAttr)
        continue;
      if (!A.keepAttr) {
        lt(Z, d);
        continue;
      }
      if (!We && ee(/\/>/i, K)) {
        lt(Z, d);
        continue;
      }
      ze && jt([W, Re, ie], (pi) => {
        K = $t(K, pi, " ");
      });
      const di = V(d.nodeName);
      if (!ui(di, ht, K)) {
        lt(Z, d);
        continue;
      }
      if (h && typeof D == "object" && typeof D.getAttributeType == "function" && !ae)
        switch (D.getAttributeType(di, ht)) {
          case "TrustedHTML": {
            K = h.createHTML(K);
            break;
          }
          case "TrustedScriptURL": {
            K = h.createScriptURL(K);
            break;
          }
        }
      if (K !== pn)
        try {
          ae ? d.setAttributeNS(ae, Z, K) : d.setAttribute(Z, K), dn(d) ? Ee(d) : ta(e.removed);
        } catch {
          lt(Z, d);
        }
    }
    qe(R.afterSanitizeAttributes, d, null);
  }, eo = function S(d) {
    let y = null;
    const A = ri(d);
    for (qe(R.beforeSanitizeShadowDOM, d, null); y = A.nextNode(); )
      qe(R.uponSanitizeShadowNode, y, null), si(y), _i(y), y.content instanceof o && S(y.content);
    qe(R.afterSanitizeShadowDOM, d, null);
  };
  return e.sanitize = function(S) {
    let d = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, y = null, A = null, z = null, X = null;
    if (un = !S, un && (S = "<!-->"), typeof S != "string" && !li(S))
      if (typeof S.toString == "function") {
        if (S = S.toString(), typeof S != "string")
          throw vt("dirty is not a string, aborting");
      } else
        throw vt("toString is not a function");
    if (!e.isSupported)
      return S;
    if (on || _n(d), e.removed = [], typeof S == "string" && (pt = !1), pt) {
      if (S.nodeName) {
        const Oe = V(S.nodeName);
        if (!O[Oe] || we[Oe])
          throw vt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (S instanceof l)
      y = oi("<!---->"), A = y.ownerDocument.importNode(S, !0), A.nodeType === yt.element && A.nodeName === "BODY" || A.nodeName === "HTML" ? y = A : y.appendChild(A);
    else {
      if (!nt && !ze && !Ze && // eslint-disable-next-line unicorn/prefer-includes
      S.indexOf("<") === -1)
        return h && Tt ? h.createHTML(S) : S;
      if (y = oi(S), !y)
        return nt ? null : Tt ? v : "";
    }
    y && rn && Ee(y.firstChild);
    const Z = ri(pt ? S : y);
    for (; z = Z.nextNode(); )
      si(z), _i(z), z.content instanceof o && eo(z.content);
    if (pt)
      return S;
    if (nt) {
      if (St)
        for (X = x.call(y.ownerDocument); y.firstChild; )
          X.appendChild(y.firstChild);
      else
        X = y;
      return (j.shadowroot || j.shadowrootmode) && (X = q.call(n, X, !0)), X;
    }
    let ae = Ze ? y.outerHTML : y.innerHTML;
    return Ze && O["!doctype"] && y.ownerDocument && y.ownerDocument.doctype && y.ownerDocument.doctype.name && ee(ja, y.ownerDocument.doctype.name) && (ae = "<!DOCTYPE " + y.ownerDocument.doctype.name + `>
` + ae), ze && jt([W, Re, ie], (Oe) => {
      ae = $t(ae, Oe, " ");
    }), h && Tt ? h.createHTML(ae) : ae;
  }, e.setConfig = function() {
    let S = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    _n(S), on = !0;
  }, e.clearConfig = function() {
    rt = null, on = !1;
  }, e.isValidAttribute = function(S, d, y) {
    rt || _n({});
    const A = V(S), z = V(d);
    return ui(A, z, y);
  }, e.addHook = function(S, d) {
    typeof d == "function" && Dt(R[S], d);
  }, e.removeHook = function(S, d) {
    if (d !== void 0) {
      const y = yl(R[S], d);
      return y === -1 ? void 0 : Fl(R[S], y, 1)[0];
    }
    return ta(R[S]);
  }, e.removeHooks = function(S) {
    R[S] = [];
  }, e.removeAllHooks = function() {
    R = sa();
  }, e;
}
Wa();
const {
  HtmlTagHydration: ck,
  SvelteComponent: _k,
  add_render_callback: dk,
  append_hydration: pk,
  attr: fk,
  bubble: hk,
  check_outros: mk,
  children: gk,
  claim_component: Dk,
  claim_element: $k,
  claim_html_tag: vk,
  claim_space: bk,
  claim_text: yk,
  create_component: Fk,
  create_in_transition: wk,
  create_out_transition: Ek,
  destroy_component: kk,
  detach: Ak,
  element: Ck,
  get_svelte_dataset: Sk,
  group_outros: Tk,
  init: xk,
  insert_hydration: Bk,
  listen: Rk,
  mount_component: Ik,
  run_all: Lk,
  safe_not_equal: qk,
  set_data: Ok,
  space: Mk,
  stop_propagation: Nk,
  text: Pk,
  toggle_class: zk,
  transition_in: Uk,
  transition_out: Hk
} = window.__gradio__svelte__internal, { createEventDispatcher: Gk, onMount: jk } = window.__gradio__svelte__internal, {
  SvelteComponent: Wk,
  append_hydration: Zk,
  attr: Vk,
  bubble: Yk,
  check_outros: Xk,
  children: Kk,
  claim_component: Qk,
  claim_element: Jk,
  claim_space: eA,
  create_animation: tA,
  create_component: nA,
  destroy_component: iA,
  detach: aA,
  element: oA,
  ensure_array_like: rA,
  fix_and_outro_and_destroy_block: lA,
  fix_position: sA,
  group_outros: uA,
  init: cA,
  insert_hydration: _A,
  mount_component: dA,
  noop: pA,
  safe_not_equal: fA,
  set_style: hA,
  space: mA,
  transition_in: gA,
  transition_out: DA,
  update_keyed_each: $A
} = window.__gradio__svelte__internal, {
  SvelteComponent: vA,
  attr: bA,
  children: yA,
  claim_element: FA,
  detach: wA,
  element: EA,
  empty: kA,
  init: AA,
  insert_hydration: CA,
  noop: SA,
  safe_not_equal: TA,
  set_style: xA
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pl,
  append_hydration: zl,
  assign: Ul,
  attr: Zt,
  check_outros: Hl,
  children: Gl,
  claim_component: jl,
  claim_element: Wl,
  claim_space: Zl,
  create_component: Vl,
  create_slot: Yl,
  destroy_component: Xl,
  detach: ua,
  element: Kl,
  get_all_dirty_from_scope: Ql,
  get_slot_changes: Jl,
  get_spread_object: es,
  get_spread_update: ts,
  group_outros: ns,
  init: is,
  insert_hydration: as,
  mount_component: os,
  safe_not_equal: rs,
  set_style: Vt,
  space: ls,
  toggle_class: ut,
  transition_in: Ft,
  transition_out: Qt,
  update_slot_base: ss
} = window.__gradio__svelte__internal;
function ca(r) {
  let e, t;
  const n = [
    { autoscroll: (
      /*gradio*/
      r[7].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      r[7].i18n
    ) },
    /*loading_status*/
    r[6],
    {
      status: (
        /*loading_status*/
        r[6] ? (
          /*loading_status*/
          r[6].status == "pending" ? "generating" : (
            /*loading_status*/
            r[6].status
          )
        ) : null
      )
    }
  ];
  let a = {};
  for (let o = 0; o < n.length; o += 1)
    a = Ul(a, n[o]);
  return e = new za({ props: a }), {
    c() {
      Vl(e.$$.fragment);
    },
    l(o) {
      jl(e.$$.fragment, o);
    },
    m(o, i) {
      os(e, o, i), t = !0;
    },
    p(o, i) {
      const l = i & /*gradio, loading_status*/
      192 ? ts(n, [
        i & /*gradio*/
        128 && { autoscroll: (
          /*gradio*/
          o[7].autoscroll
        ) },
        i & /*gradio*/
        128 && { i18n: (
          /*gradio*/
          o[7].i18n
        ) },
        i & /*loading_status*/
        64 && es(
          /*loading_status*/
          o[6]
        ),
        i & /*loading_status*/
        64 && {
          status: (
            /*loading_status*/
            o[6] ? (
              /*loading_status*/
              o[6].status == "pending" ? "generating" : (
                /*loading_status*/
                o[6].status
              )
            ) : null
          )
        }
      ]) : {};
      e.$set(l);
    },
    i(o) {
      t || (Ft(e.$$.fragment, o), t = !0);
    },
    o(o) {
      Qt(e.$$.fragment, o), t = !1;
    },
    d(o) {
      Xl(e, o);
    }
  };
}
function us(r) {
  let e, t, n, a = `calc(min(${/*min_width*/
  r[1]}px, 100%))`, o, i = (
    /*loading_status*/
    r[6] && /*show_progress*/
    r[8] && /*gradio*/
    r[7] && ca(r)
  );
  const l = (
    /*#slots*/
    r[10].default
  ), s = Yl(
    l,
    r,
    /*$$scope*/
    r[9],
    null
  );
  return {
    c() {
      e = Kl("div"), i && i.c(), t = ls(), s && s.c(), this.h();
    },
    l(u) {
      e = Wl(u, "DIV", { id: !0, class: !0 });
      var c = Gl(e);
      i && i.l(c), t = Zl(c), s && s.l(c), c.forEach(ua), this.h();
    },
    h() {
      Zt(
        e,
        "id",
        /*elem_id*/
        r[2]
      ), Zt(e, "class", n = "column " + /*elem_classes*/
      r[3].join(" ") + " svelte-y3tjew"), ut(
        e,
        "compact",
        /*variant*/
        r[5] === "compact"
      ), ut(
        e,
        "panel",
        /*variant*/
        r[5] === "panel"
      ), ut(e, "hide", !/*visible*/
      r[4]), Vt(
        e,
        "flex-grow",
        /*scale*/
        r[0]
      ), Vt(e, "min-width", a);
    },
    m(u, c) {
      as(u, e, c), i && i.m(e, null), zl(e, t), s && s.m(e, null), o = !0;
    },
    p(u, [c]) {
      /*loading_status*/
      u[6] && /*show_progress*/
      u[8] && /*gradio*/
      u[7] ? i ? (i.p(u, c), c & /*loading_status, show_progress, gradio*/
      448 && Ft(i, 1)) : (i = ca(u), i.c(), Ft(i, 1), i.m(e, t)) : i && (ns(), Qt(i, 1, 1, () => {
        i = null;
      }), Hl()), s && s.p && (!o || c & /*$$scope*/
      512) && ss(
        s,
        l,
        u,
        /*$$scope*/
        u[9],
        o ? Jl(
          l,
          /*$$scope*/
          u[9],
          c,
          null
        ) : Ql(
          /*$$scope*/
          u[9]
        ),
        null
      ), (!o || c & /*elem_id*/
      4) && Zt(
        e,
        "id",
        /*elem_id*/
        u[2]
      ), (!o || c & /*elem_classes*/
      8 && n !== (n = "column " + /*elem_classes*/
      u[3].join(" ") + " svelte-y3tjew")) && Zt(e, "class", n), (!o || c & /*elem_classes, variant*/
      40) && ut(
        e,
        "compact",
        /*variant*/
        u[5] === "compact"
      ), (!o || c & /*elem_classes, variant*/
      40) && ut(
        e,
        "panel",
        /*variant*/
        u[5] === "panel"
      ), (!o || c & /*elem_classes, visible*/
      24) && ut(e, "hide", !/*visible*/
      u[4]), c & /*scale*/
      1 && Vt(
        e,
        "flex-grow",
        /*scale*/
        u[0]
      ), c & /*min_width*/
      2 && a !== (a = `calc(min(${/*min_width*/
      u[1]}px, 100%))`) && Vt(e, "min-width", a);
    },
    i(u) {
      o || (Ft(i), Ft(s, u), o = !0);
    },
    o(u) {
      Qt(i), Qt(s, u), o = !1;
    },
    d(u) {
      u && ua(e), i && i.d(), s && s.d(u);
    }
  };
}
function cs(r, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { scale: o = null } = e, { min_width: i = 0 } = e, { elem_id: l = "" } = e, { elem_classes: s = [] } = e, { visible: u = !0 } = e, { variant: c = "default" } = e, { loading_status: p = void 0 } = e, { gradio: m = void 0 } = e, { show_progress: D = !1 } = e;
  return r.$$set = (g) => {
    "scale" in g && t(0, o = g.scale), "min_width" in g && t(1, i = g.min_width), "elem_id" in g && t(2, l = g.elem_id), "elem_classes" in g && t(3, s = g.elem_classes), "visible" in g && t(4, u = g.visible), "variant" in g && t(5, c = g.variant), "loading_status" in g && t(6, p = g.loading_status), "gradio" in g && t(7, m = g.gradio), "show_progress" in g && t(8, D = g.show_progress), "$$scope" in g && t(9, a = g.$$scope);
  }, [
    o,
    i,
    l,
    s,
    u,
    c,
    p,
    m,
    D,
    a,
    n
  ];
}
let _s = class extends Pl {
  constructor(e) {
    super(), is(this, e, cs, us, rs, {
      scale: 0,
      min_width: 1,
      elem_id: 2,
      elem_classes: 3,
      visible: 4,
      variant: 5,
      loading_status: 6,
      gradio: 7,
      show_progress: 8
    });
  }
};
const {
  SvelteComponent: ds,
  add_flush_callback: ps,
  assign: fs,
  bind: hs,
  binding_callbacks: ms,
  check_outros: gs,
  claim_component: Wn,
  claim_space: Ds,
  create_component: Zn,
  create_slot: $s,
  destroy_component: Vn,
  detach: _a,
  empty: da,
  get_all_dirty_from_scope: vs,
  get_slot_changes: bs,
  get_spread_object: ys,
  get_spread_update: Fs,
  group_outros: ws,
  init: Es,
  insert_hydration: pa,
  mount_component: Yn,
  safe_not_equal: ks,
  space: As,
  transition_in: Ye,
  transition_out: dt,
  update_slot_base: Cs
} = window.__gradio__svelte__internal;
function fa(r) {
  let e, t, n;
  function a(i) {
    r[9](i);
  }
  let o = {
    height: (
      /*height*/
      r[3]
    ),
    width: (
      /*width*/
      r[4]
    ),
    bring_to_front: (
      /*bring_to_front*/
      r[6]
    ),
    rounded_borders: (
      /*rounded_borders*/
      r[7]
    ),
    $$slots: { default: [Ts] },
    $$scope: { ctx: r }
  };
  return (
    /*open*/
    r[0] !== void 0 && (o.open = /*open*/
    r[0]), e = new Fo({ props: o }), ms.push(() => hs(e, "open", a)), e.$on(
      "expand",
      /*expand_handler*/
      r[10]
    ), e.$on(
      "collapse",
      /*collapse_handler*/
      r[11]
    ), {
      c() {
        Zn(e.$$.fragment);
      },
      l(i) {
        Wn(e.$$.fragment, i);
      },
      m(i, l) {
        Yn(e, i, l), n = !0;
      },
      p(i, l) {
        const s = {};
        l & /*height*/
        8 && (s.height = /*height*/
        i[3]), l & /*width*/
        16 && (s.width = /*width*/
        i[4]), l & /*bring_to_front*/
        64 && (s.bring_to_front = /*bring_to_front*/
        i[6]), l & /*rounded_borders*/
        128 && (s.rounded_borders = /*rounded_borders*/
        i[7]), l & /*$$scope*/
        4096 && (s.$$scope = { dirty: l, ctx: i }), !t && l & /*open*/
        1 && (t = !0, s.open = /*open*/
        i[0], ps(() => t = !1)), e.$set(s);
      },
      i(i) {
        n || (Ye(e.$$.fragment, i), n = !0);
      },
      o(i) {
        dt(e.$$.fragment, i), n = !1;
      },
      d(i) {
        Vn(e, i);
      }
    }
  );
}
function Ss(r) {
  let e;
  const t = (
    /*#slots*/
    r[8].default
  ), n = $s(
    t,
    r,
    /*$$scope*/
    r[12],
    null
  );
  return {
    c() {
      n && n.c();
    },
    l(a) {
      n && n.l(a);
    },
    m(a, o) {
      n && n.m(a, o), e = !0;
    },
    p(a, o) {
      n && n.p && (!e || o & /*$$scope*/
      4096) && Cs(
        n,
        t,
        a,
        /*$$scope*/
        a[12],
        e ? bs(
          t,
          /*$$scope*/
          a[12],
          o,
          null
        ) : vs(
          /*$$scope*/
          a[12]
        ),
        null
      );
    },
    i(a) {
      e || (Ye(n, a), e = !0);
    },
    o(a) {
      dt(n, a), e = !1;
    },
    d(a) {
      n && n.d(a);
    }
  };
}
function Ts(r) {
  let e, t;
  return e = new _s({
    props: {
      $$slots: { default: [Ss] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      Zn(e.$$.fragment);
    },
    l(n) {
      Wn(e.$$.fragment, n);
    },
    m(n, a) {
      Yn(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a & /*$$scope*/
      4096 && (o.$$scope = { dirty: a, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (Ye(e.$$.fragment, n), t = !0);
    },
    o(n) {
      dt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Vn(e, n);
    }
  };
}
function xs(r) {
  let e, t, n, a;
  const o = [
    { autoscroll: (
      /*gradio*/
      r[2].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      r[2].i18n
    ) },
    /*loading_status*/
    r[1]
  ];
  let i = {};
  for (let s = 0; s < o.length; s += 1)
    i = fs(i, o[s]);
  e = new za({ props: i });
  let l = (
    /*visible*/
    r[5] && fa(r)
  );
  return {
    c() {
      Zn(e.$$.fragment), t = As(), l && l.c(), n = da();
    },
    l(s) {
      Wn(e.$$.fragment, s), t = Ds(s), l && l.l(s), n = da();
    },
    m(s, u) {
      Yn(e, s, u), pa(s, t, u), l && l.m(s, u), pa(s, n, u), a = !0;
    },
    p(s, [u]) {
      const c = u & /*gradio, loading_status*/
      6 ? Fs(o, [
        u & /*gradio*/
        4 && { autoscroll: (
          /*gradio*/
          s[2].autoscroll
        ) },
        u & /*gradio*/
        4 && { i18n: (
          /*gradio*/
          s[2].i18n
        ) },
        u & /*loading_status*/
        2 && ys(
          /*loading_status*/
          s[1]
        )
      ]) : {};
      e.$set(c), /*visible*/
      s[5] ? l ? (l.p(s, u), u & /*visible*/
      32 && Ye(l, 1)) : (l = fa(s), l.c(), Ye(l, 1), l.m(n.parentNode, n)) : l && (ws(), dt(l, 1, 1, () => {
        l = null;
      }), gs());
    },
    i(s) {
      a || (Ye(e.$$.fragment, s), Ye(l), a = !0);
    },
    o(s) {
      dt(e.$$.fragment, s), dt(l), a = !1;
    },
    d(s) {
      s && (_a(t), _a(n)), Vn(e, s), l && l.d(s);
    }
  };
}
function Bs(r, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { open: o = !0 } = e, { loading_status: i } = e, { gradio: l } = e, { height: s } = e, { width: u } = e, { visible: c = !0 } = e, { bring_to_front: p = !1 } = e, { rounded_borders: m = !1 } = e;
  function D($) {
    o = $, t(0, o);
  }
  const g = () => l.dispatch("expand"), b = () => l.dispatch("collapse");
  return r.$$set = ($) => {
    "open" in $ && t(0, o = $.open), "loading_status" in $ && t(1, i = $.loading_status), "gradio" in $ && t(2, l = $.gradio), "height" in $ && t(3, s = $.height), "width" in $ && t(4, u = $.width), "visible" in $ && t(5, c = $.visible), "bring_to_front" in $ && t(6, p = $.bring_to_front), "rounded_borders" in $ && t(7, m = $.rounded_borders), "$$scope" in $ && t(12, a = $.$$scope);
  }, [
    o,
    i,
    l,
    s,
    u,
    c,
    p,
    m,
    n,
    D,
    g,
    b,
    a
  ];
}
class RA extends ds {
  constructor(e) {
    super(), Es(this, e, Bs, xs, ks, {
      open: 0,
      loading_status: 1,
      gradio: 2,
      height: 3,
      width: 4,
      visible: 5,
      bring_to_front: 6,
      rounded_borders: 7
    });
  }
}
export {
  RA as default
};
