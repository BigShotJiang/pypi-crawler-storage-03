"""Tests for OpenTelemetry integration."""
