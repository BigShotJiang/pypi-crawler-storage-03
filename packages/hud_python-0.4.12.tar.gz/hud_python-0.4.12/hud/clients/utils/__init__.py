"""HUD MCP client utilities."""
