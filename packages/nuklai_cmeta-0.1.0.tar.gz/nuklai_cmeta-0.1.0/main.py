def main():
    print("Hello from cmeta!")


if __name__ == "__main__":
    main()
