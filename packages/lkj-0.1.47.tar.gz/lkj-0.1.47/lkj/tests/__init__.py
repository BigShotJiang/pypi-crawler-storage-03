"""Tests for lkj"""
