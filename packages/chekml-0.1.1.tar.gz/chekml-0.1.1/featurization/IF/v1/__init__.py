from .inequality_based_featurization import InequalityFeaturizer
__all__ = ["InequalityFeaturizer"]
