from .speakers import Artur
def main():
    Artur().print_name()

if __name__ == "__main__":
    main()