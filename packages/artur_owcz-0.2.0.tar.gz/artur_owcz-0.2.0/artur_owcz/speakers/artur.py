from artur_owcz import Speaker

class Artur(Speaker):
    name = "Artur Owczarek"
