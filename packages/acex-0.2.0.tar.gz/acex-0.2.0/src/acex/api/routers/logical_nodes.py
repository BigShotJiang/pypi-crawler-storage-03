import inspect
from typing import get_type_hints
from pydantic import BaseModel
from fastapi import APIRouter
from acex.constants import BASE_URL


def get_response_model(func):
    sig = inspect.signature(func)
    return_annotation = sig.return_annotation
    if return_annotation is inspect.Signature.empty:
        return None
    return return_annotation


def create_router(automation_engine):
    router = APIRouter(prefix=f"{BASE_URL}/inventory")
    tags = ["Inventory"]

    plug = getattr(automation_engine.inventory, "logical_nodes")
    for cap in plug.capabilities:
        print(cap)
        func = getattr(plug, cap)
        path = plug.path(cap)
        method = plug.http_verb(cap)
        response_model = get_response_model(func)

        # Nu behöver vi inte längre wrappa här - kompileringen sker i adaptern
        endpoint = func

        router.add_api_route(
            f"/logical_nodes{path}",
            endpoint,
            methods=[method],
            response_model=response_model,
            tags=["Logical Nodes"]
        )
    return router
