Bibliography
============

Functions for processing and formatting bibliographic citations from BibTeX files.

.. automodule:: plixlab.Bibliography
   :members:
