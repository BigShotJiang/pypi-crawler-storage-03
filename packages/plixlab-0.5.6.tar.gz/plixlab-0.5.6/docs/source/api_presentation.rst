Presentation Class
==================

The main container class for creating multi-slide presentations.

.. autoclass:: plixlab.Presentation
   :members:
   :show-inheritance:
