#include "./d1.hpp"

int f1()
{
    return 42;
};
