//#CFLAGS=-std=gnu99

int main(int argc, char** argv)
{
    for (int pass = 0; pass < 1000; pass++)    
    {
      //nop
    }    
    return 0;
}

