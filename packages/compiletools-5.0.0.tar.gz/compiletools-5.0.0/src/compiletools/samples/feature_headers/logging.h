// Logging functionality header
#ifndef LOGGING_H  
#define LOGGING_H

void init_logging(void);
void log_message(const char* msg);

#endif