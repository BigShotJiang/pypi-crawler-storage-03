// Database functionality header
#ifndef DATABASE_H
#define DATABASE_H

void init_database(void);
void close_database(void);

#endif