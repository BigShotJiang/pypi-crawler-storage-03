#ifndef CPPFLAGS_FEATURE_HPP
#define CPPFLAGS_FEATURE_HPP
// Feature enabled via CPPFLAGS macro
#endif