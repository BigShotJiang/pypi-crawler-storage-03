#ifndef VERSION2_FEATURE_HPP
#define VERSION2_FEATURE_HPP
// Version 2 specific feature
#endif