#ifndef INTEL_FEATURE_HPP
#define INTEL_FEATURE_HPP
// Intel compiler specific feature
#endif