#ifndef RISCV_FEATURE_HPP
#define RISCV_FEATURE_HPP
// RISC-V architecture-specific feature
#endif