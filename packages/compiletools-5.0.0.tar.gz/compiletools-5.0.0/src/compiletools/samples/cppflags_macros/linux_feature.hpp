#ifndef LINUX_FEATURE_HPP
#define LINUX_FEATURE_HPP
// Linux platform-specific feature
#endif