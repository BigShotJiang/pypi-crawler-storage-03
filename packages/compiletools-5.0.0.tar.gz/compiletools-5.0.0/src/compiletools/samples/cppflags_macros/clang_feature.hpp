#ifndef CLANG_FEATURE_HPP
#define CLANG_FEATURE_HPP
// Clang-specific feature
#endif