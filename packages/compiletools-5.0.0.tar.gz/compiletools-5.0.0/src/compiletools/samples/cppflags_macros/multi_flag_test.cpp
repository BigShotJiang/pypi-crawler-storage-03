#include "multi_flag_header.hpp"

int main() {
    return 0;
}