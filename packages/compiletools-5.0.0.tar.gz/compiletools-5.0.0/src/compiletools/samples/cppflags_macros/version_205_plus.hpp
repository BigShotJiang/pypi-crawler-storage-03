#ifndef VERSION_205_PLUS_HPP
#define VERSION_205_PLUS_HPP
// Feature for version 2.05 and above
#endif