#ifndef TEMP_STILL_DEFINED_HPP
#define TEMP_STILL_DEFINED_HPP
// Should NOT be included after #undef TEMP_MACRO
#endif