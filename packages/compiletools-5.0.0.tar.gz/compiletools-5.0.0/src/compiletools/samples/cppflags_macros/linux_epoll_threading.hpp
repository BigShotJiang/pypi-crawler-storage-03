#ifndef LINUX_EPOLL_THREADING_HPP
#define LINUX_EPOLL_THREADING_HPP
// Linux epoll with threading support
class EpollThreading {
public:
    void setup_epoll_threads();
};
#endif