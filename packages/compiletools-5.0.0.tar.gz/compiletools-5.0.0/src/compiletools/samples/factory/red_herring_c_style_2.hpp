/* This file should never actually be included.  
 * It only exists so that test_headerdeps.py will fail if for some reason
 * the commented out #include in samples/factory/test_factory.cpp 
 * is erroneously picked up and used.
 */
