int func()
{
    return 666;
}
