#ifndef DEBUG_H
#define DEBUG_H
// Debug features
void debug_log(const char* msg);
#endif