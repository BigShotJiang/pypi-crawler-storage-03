#pragma once

constexpr const char* filename = "/tmp/serialise_test.txt";
