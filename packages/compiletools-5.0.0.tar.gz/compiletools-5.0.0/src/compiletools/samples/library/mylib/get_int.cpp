#include "get_int.hpp"
int get_int(void){ return 1;}
