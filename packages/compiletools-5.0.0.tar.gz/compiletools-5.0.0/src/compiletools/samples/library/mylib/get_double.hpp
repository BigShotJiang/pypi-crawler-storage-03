#pragma once
double get_double(void);
