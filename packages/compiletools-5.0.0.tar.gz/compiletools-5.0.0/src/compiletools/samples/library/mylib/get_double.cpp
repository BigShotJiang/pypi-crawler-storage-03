#include "get_double.hpp"
double get_double(void) { return 2.0; }
