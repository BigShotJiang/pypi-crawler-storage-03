==============
ct-commandline
==============

---------------------------------------------------------------------------------------
This document describes the command line arguments that are common across ct-* programs
---------------------------------------------------------------------------------------

:Author: drgeoffathome@gmail.com
:Date:   2017-07-06
:Copyright: Copyright (C) 2011-2016 Zomojo Pty Ltd
:Version: 5.0.0
:Manual section: 1
:Manual group: developers

SYNOPSIS
========
    ct-* [args]

DESCRIPTION
===========
