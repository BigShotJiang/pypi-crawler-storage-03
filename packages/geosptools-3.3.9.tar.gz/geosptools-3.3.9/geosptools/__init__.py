#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# geosptools/__init__.py

__version__ = "3.3.9"

# Define what should be available when using 'from geosptools import *'
__all__ = [
    'raster_tools'
]