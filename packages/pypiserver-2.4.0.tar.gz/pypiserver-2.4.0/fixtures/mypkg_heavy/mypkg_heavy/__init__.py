"""
This imitates a a heavy package.

- The ~1.4MB `generated_placehoder.py` is generated using the root `Makefile`.
"""


def pkg_name() -> None:
    """Print the package name."""
    print("mypkg_heavy")
