"""A simple setup file for the 'HEAVY' test package."""

from setuptools import setup

setup(
    name="pypiserver_mypkg_heavy",
    description="Heavy test pkg",
    version="1.0.0",
    packages=["mypkg_heavy"],
)
