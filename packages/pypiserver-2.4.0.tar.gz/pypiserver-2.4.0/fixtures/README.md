# Testing Fixtures

This directory contains various 'fixture' test data.

> [!IMPORTANT]
>
> Dynamic and static test data should be placed in this folder.
