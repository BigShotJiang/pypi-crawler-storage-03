from .stores import EC2ParameterStore
from .version import __version__

__all__ = ['EC2ParameterStore', '__version__']
