from topasio.generic_classes.space import Space

Is = Space()
Is["_name"] = "Is"
Is["_modified"] = []  # Track modified attributes
