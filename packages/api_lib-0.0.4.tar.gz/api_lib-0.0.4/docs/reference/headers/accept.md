# `api_lib.headers.accept`

::: api_lib.headers.accept
