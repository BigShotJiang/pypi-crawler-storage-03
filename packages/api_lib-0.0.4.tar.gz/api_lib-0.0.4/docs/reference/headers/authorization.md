# `api_lib.headers.authorization`

::: api_lib.headers.authorization
