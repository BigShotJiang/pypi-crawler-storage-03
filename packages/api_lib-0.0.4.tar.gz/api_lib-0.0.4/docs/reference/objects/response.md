# `api_lib.objects.response`

::: api_lib.objects.response
