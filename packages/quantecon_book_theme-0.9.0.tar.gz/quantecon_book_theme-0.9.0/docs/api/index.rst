.. _api/main:

Python API
==========

.. autodata:: quantecon_book_theme.__version__

.. autofunction:: quantecon_book_theme.add_to_context

.. autofunction:: quantecon_book_theme.launch.add_hub_urls
