Development Lead:
-----------------

1. Dickson Owuor <owuordickson@gmail.com>

Credits:
--------

1. Nicholas Kotov <kotov@umich.edu>
2. Drew A. Vecchio <vecdrew@umich.edu>
3. Kody Whisnant <kgwhis@umich.edu>
4. Alain Kadar <alaink@umich.edu>
5. Xiong Ye Xiao <xiongyex@usc.edu>


Contributors:
-------------
Feel free to add yourself:

1. Raymond Cao <caor@umich.edu>