__version__ = "74.20250825"
GIT_REF = "81d7024"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/81d7024"