from pathlib import Path
import sys
sys.path.append((Path(__file__).parent.parent / "bondzai").as_posix())