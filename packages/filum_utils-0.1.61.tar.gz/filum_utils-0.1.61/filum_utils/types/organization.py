from typing import TypedDict


class Organization(TypedDict):
    id: str
    slug: str
