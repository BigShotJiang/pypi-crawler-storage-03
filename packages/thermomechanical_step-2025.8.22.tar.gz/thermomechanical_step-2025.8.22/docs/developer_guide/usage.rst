=====
Usage
=====

To use the QuickMin Step in a project::

    import quickmin_step
