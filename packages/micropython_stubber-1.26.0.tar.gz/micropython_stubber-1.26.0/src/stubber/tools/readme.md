tools vendored from micropython 

- manifestfile.py 
  - Micropython manifest file parser 
  - https://github.com/micropython/micropython/blob/master/tools/manifestfile.py
  - v1.23.0 
    - https://raw.githubusercontent.com/micropython/micropython/v1.23.0/tools/manifestfile.py