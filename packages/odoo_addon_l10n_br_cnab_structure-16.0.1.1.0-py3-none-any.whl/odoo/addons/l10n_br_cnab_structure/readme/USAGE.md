Configuration and usability: <https://youtu.be/ljommELunlA>
