This module adds functionality for implementing brazilian banking
automation by CNAB file exchange.
