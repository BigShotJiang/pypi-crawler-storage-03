from .FileInput import FileInput


class ImageInput(FileInput):
    type = "image-input"
