from gpt2giga import main

main()