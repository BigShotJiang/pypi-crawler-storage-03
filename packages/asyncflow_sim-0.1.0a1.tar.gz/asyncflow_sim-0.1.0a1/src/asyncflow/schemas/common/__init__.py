"""Shared, reusable primitives for schema modules (e.g., RVConfig)."""
