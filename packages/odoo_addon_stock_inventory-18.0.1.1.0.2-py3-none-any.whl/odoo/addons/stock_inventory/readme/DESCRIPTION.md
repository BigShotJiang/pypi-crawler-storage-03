This module allows to group Inventory Adjustments and have a group
traceability (like before Odoo 15.0).
