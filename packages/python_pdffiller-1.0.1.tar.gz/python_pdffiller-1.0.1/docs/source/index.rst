.. include:: ../../README.rst


.. toctree::
   :maxdepth: 2
   :caption: Basics
   :hidden:

   cli-usage
   cli-commands
   changelog

.. toctree::
   :hidden:
   :caption: Development

   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
