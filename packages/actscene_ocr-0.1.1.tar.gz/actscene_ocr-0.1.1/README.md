# actscene-ocr

日本語の各種書類向けに最適化した OCR ライブラリ

## インストール

```
pip install actscene-ocr
```

## 使い方

```python
from actscene_ocr import ActsceneOCR

ocr = ActsceneOCR()

# 基本的な使い方（画像パス + max_segment_pixels のみ）
result = ocr.shaken("/path/to/image.jpg")

# 全メソッド一覧
res1 = ocr.shaken_kiroku("/path/to/image.jpg")
# -> {"所有者の氏名又は名称": "", "所有者の住所": "", "自動車登録番号又は車両番号": "",
#     "初度登録年月": "", "有効期限の満了する日": "", "車台番号": ""}

res2 = ocr.shaken("/path/to/image.jpg")
# -> {"使用者の氏名又は名称": "", "自動車登録番号又は車両番号": "",
#     "初度登録年月": "", "車台番号": ""}

res3 = ocr.recycle("/path/to/image.jpg")
# -> {"預託金額合計": "", "車台番号": ""}

res4 = ocr.jouto("/path/to/image.jpg")
# -> {"譲渡人及び譲受人の氏名又は名称及び住所": ""}

res5 = ocr.jibaiseki("/path/to/image.jpg")
# -> {"車台番号": "", "保険期間至": ""}

res6 = ocr.inkan("/path/to/image.jpg")
# -> {"氏名": "", "住所": ""}

res7 = ocr.inin("/path/to/image.jpg")
# -> {"委任人の氏名又は名称及び住所": ""}
```

### 共通引数

- `image`: 画像パス、`numpy.ndarray`、`PIL.Image.Image` のいずれか
- `max_segment_pixels`: セグメントの最大ピクセル数（既定 1,000,000）
- `debug_dir`: デバッグ画像の出力先ディレクトリ（省略可）

## ライセンス

MIT
