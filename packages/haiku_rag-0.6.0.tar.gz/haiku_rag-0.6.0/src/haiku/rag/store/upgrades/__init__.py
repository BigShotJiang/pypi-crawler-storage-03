from haiku.rag.store.upgrades.v0_3_4 import upgrades as v0_3_4_upgrades

upgrades = v0_3_4_upgrades
