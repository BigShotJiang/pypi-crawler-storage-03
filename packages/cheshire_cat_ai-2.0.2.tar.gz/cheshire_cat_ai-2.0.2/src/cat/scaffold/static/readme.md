In this folder will be stored static files that the Cat may serve to clients.
Plugins must store their static files here to.

TODO: provide links and brief instructions