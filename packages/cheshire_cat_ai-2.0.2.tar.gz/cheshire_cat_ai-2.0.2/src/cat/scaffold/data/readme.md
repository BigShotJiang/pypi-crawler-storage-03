In this folder will be stored all the data (settings, users, etc.).
Plugins must store their data here to.

TODO: provide links and brief instructions