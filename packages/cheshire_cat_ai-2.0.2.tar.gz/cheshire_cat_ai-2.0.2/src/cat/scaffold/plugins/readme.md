# How to write a plugin

Please refer to [this documentation](https://cheshire-cat-ai.github.io/docs/plugins/plugins/)
