**2.0.6 - 8/20/2025**

  - Validate arguments passed to reusable_pipeline.groovy

**2.0.5 - 8/8/2025**

  - Create pipeline to clean up Jenkins build directories

**2.0.4 - 8/6/2025**

  - Revert v2.0.3

**2.0.3 - 8/5/2025**

  - Use Jenkins node /tmp/ dir (reversion from v2.0.2) until permissions get resolved

**2.0.2 - 8/4/2025**

  - Create all Jenkins build envs in shared team folder

**2.0.1 - 7/25/2025**

  - Bugfix: fix broken doc stages in Jenkins pipeline

**2.0.0 - 7/24/2025**

  - Clean up and better document Make files

**1.1.2 - 7/16/2025**

  - Bugfix: typo in extra-index-url

**1.1.1 - 7/16/2025**

  - Bugfix: fix broken pip install --dry-run call in get_vbu_version.py

**1.1.0 - 7/15/2025**

  - Allow for pinning in other repos

**1.0.0 - 7/8/2025**

  - Initial major release

**0.1.0 - 7/8/2025**

  - Initial rc release
