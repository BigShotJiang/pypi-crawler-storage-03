# 适配器模块
# 用于连接 MCP 服务端和现有的 FastAPI 服务 