"""
Tests for the nl2cmd package.
"""

import pytest
from nl2cmd import NL2Cmd, NL2CmdResult


class TestNL2Cmd:
    """Test cases for the NL2Cmd class."""
    
    def test_init_default_os(self):
        """Test initialization with default OS detection."""
        translator = NL2Cmd()
        assert translator.os in ["linux", "macOS", "windows"]
    
    def test_init_forced_os(self):
        """Test initialization with forced OS."""
        translator = NL2Cmd(forced_os="linux")
        assert translator.os == "linux"
    
    def test_translate_basic_command(self):
        """Test basic command translation."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("show current directory")
        
        assert isinstance(result, NL2CmdResult)
        assert result.input == "show current directory"
        assert result.os == "linux"
        assert result.command == "pwd"
        assert not result.clarification_required
        assert not result.error
    
    def test_translate_windows_command(self):
        """Test command translation for Windows."""
        translator = NL2Cmd(forced_os="windows")
        result = translator.translate("list files")
        
        assert isinstance(result, NL2CmdResult)
        assert result.os == "windows"
        assert result.command == "dir"
        assert not result.clarification_required
    
    def test_translate_macos_command(self):
        """Test command translation for macOS."""
        translator = NL2Cmd(forced_os="macOS")
        result = translator.translate("list files")
        
        assert isinstance(result, NL2CmdResult)
        assert result.os == "macOS"
        assert result.command == "ls"
        assert not result.clarification_required
    
    def test_translate_unknown_intent(self):
        """Test translation with unknown intent."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("do something completely unknown")
        
        assert isinstance(result, NL2CmdResult)
        assert result.clarification_required
        assert result.error == "Could not determine intent from input"
    
    def test_translate_empty_input(self):
        """Test translation with empty input."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("")
        
        assert isinstance(result, NL2CmdResult)
        assert result.clarification_required
    
    def test_translate_whitespace_input(self):
        """Test translation with whitespace-only input."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("   \n\t   ")
        
        assert isinstance(result, NL2CmdResult)
        assert result.clarification_required
    
    def test_command_breakdown(self):
        """Test command breakdown functionality."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("show current directory")
        
        assert result.command_breakdown is not None
        assert "command" in result.command_breakdown
        assert result.command_breakdown["command"] == "pwd"
    
    def test_alternatives_generation(self):
        """Test alternatives generation."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("show current directory")
        
        assert isinstance(result.alternatives, list)
        assert len(result.alternatives) > 0


class TestNL2CmdResult:
    """Test cases for the NL2CmdResult dataclass."""
    
    def test_result_creation(self):
        """Test creating a result object."""
        result = NL2CmdResult(
            input="test input",
            os="linux",
            command="test command",
            alternatives=["alt1", "alt2"],
            clarification_required=False,
            error="",
            explanation="test explanation",
            command_breakdown={"cmd": "test"}
        )
        
        assert result.input == "test input"
        assert result.os == "linux"
        assert result.command == "test command"
        assert result.alternatives == ["alt1", "alt2"]
        assert not result.clarification_required
        assert result.error == ""
        assert result.explanation == "test explanation"
        assert result.command_breakdown == {"cmd": "test"}
    
    def test_result_defaults(self):
        """Test result object with default values."""
        result = NL2CmdResult(
            input="test",
            os="linux",
            command="test",
            alternatives=[],
            clarification_required=False,
            error=""
        )
        
        assert result.explanation == ""
        assert result.command_breakdown is None


if __name__ == "__main__":
    pytest.main([__file__])
