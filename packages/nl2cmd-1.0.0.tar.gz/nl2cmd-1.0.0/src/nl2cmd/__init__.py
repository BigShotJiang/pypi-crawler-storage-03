"""
Natural language to terminal command translation tool.

This package provides the NL2Cmd class for translating natural language
descriptions into appropriate terminal commands based on the detected OS.
"""

from .core import NL2Cmd, NL2CmdResult

__version__ = "0.1.0"
__all__ = ["NL2Cmd", "NL2CmdResult"]
