#!/usr/bin/env python3
import json
import platform
import re
import shlex
from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple, Dict


# ---------------------------
# Data model for the response
# ---------------------------
@dataclass
class NL2CmdResult:
    input: str
    os: str
    command: str
    alternatives: List[str]
    clarification_required: bool
    error: str
    # Additional, non-breaking fields to give users more usage info:
    explanation: str = ""  # What the command does in plain English
    command_breakdown: Dict[str, str] = None  # Key parts of the command explained


# ---------------------------
# Translator core
# ---------------------------
class NL2Cmd:
    def __init__(self, forced_os: Optional[str] = None):
        """
        forced_os: Optional override ("linux", "macOS", "windows") for testing.
        Otherwise, OS is detected from the runtime environment.
        """
        self.os = forced_os or self._detect_os()

        # Canonical intents and synonyms for lightweight semantic matching
        self.intent_synonyms = {
            "pwd": ["pwd", "current directory", "current working directory", "where am i", "print working dir"],
            "ls": ["list", "show files", "display files", "ls", "list directory", "list contents"],
            "cd": ["cd", "change dir", "go to", "navigate to", "move to"],
            "mkdir": ["mkdir", "make directory", "create folder", "create directory"],
            "rm": ["rm", "remove", "delete", "erase", "trash"],
            "cp": ["cp", "copy", "duplicate"],
            "mv": ["mv", "move", "rename"],
            "find_files": ["find files", "locate files", "search files by name", "where is file"],
            "grep_text": ["search text", "grep", "find in files", "search in files", "look for text"],
            "ps_list": ["processes", "running processes", "list processes", "tasks"],
            "kill_proc": ["kill", "terminate process", "end process", "stop process", "pkill"],
            "list_ports": ["listening ports", "open ports", "network sockets", "ports"],
            "ip_addr": ["ip", "ip address", "network address"],
            "disk_usage": ["disk usage", "disk space", "free space", "space left", "storage"],
            "memory_usage": ["memory", "ram usage", "free memory", "mem usage"],
            "cpu_usage": ["cpu usage", "load", "system load", "cpu"],
            "compress": ["compress", "archive", "zip", "tar", "gzip"],
            "decompress": ["extract", "unzip", "untar", "decompress"],
            "update_packages": ["update packages", "upgrade packages", "refresh packages", "system update"],
            "install_pkg": ["install", "add package", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco",
                            "scoop"],
            "git_status": ["git status"],
            "git_pull": ["git pull"],
            "git_push": ["git push"],
            "git_clone": ["git clone"],
            "git_commit": ["git commit"],
            "git_branch_list": ["git branch list", "list branches", "branches"],
            "git_branch_create": ["create branch", "new branch"],
            "git_log": ["git log", "commit history"],
            "git_diff": ["git diff"],
            "docker_ps": ["docker ps", "list containers", "containers"],
            "docker_images": ["docker images", "list images"],
            "docker_run": ["docker run", "run container"],
            "docker_build": ["docker build"],
            "docker_logs": ["docker logs", "container logs"],
            "cat_file": ["cat", "show file", "display file", "view file", "read file"],
            "head_file": ["head"],
            "tail_file": ["tail"],
            "chmod": ["chmod", "change permission"],
            "chown": ["chown", "change owner"],
            # Generic data wrangling intents (composition):
            "count_matches": ["count matches", "how many lines", "count lines matching", "number of occurrences"],
            "sort_by_size": ["sort by size", "largest files", "biggest files"],
            "sort_by_time": ["newest files", "oldest files", "sort by time"],
        }

        # Lightweight patterns to inform parsing and synthesis
        self.boolean_flags = {
            "recursive": ["recursive", "recursively", "subfolders", "subdirectories", "sub-folders", "sub dirs", "-r",
                          "--recursive", "all subfolders"],
            "hidden": ["hidden", "dotfiles", "including hidden", "-a", "--all"],
            "long": ["long", "detailed", "attributes", "permissions", "metadata", "human readable", "human-readable",
                     "-l", "--long"],
            "case_insensitive": ["case-insensitive", "case insensitive", "ignore case", "-i", "--ignore-case"],
            "exact": ["exact", "exactly", "whole word", "-w", "--word-regexp"],
            "force": ["force", "forcefully", "-f", "--force"]
        }

    @staticmethod
    def _detect_os() -> str:
        sys = platform.system().lower()
        if "linux" in sys:
            return "linux"
        elif "darwin" in sys:
            return "macOS"
        elif "windows" in sys:
            return "windows"
        else:
            return "linux"  # Default fallback

    def translate(self, natural_language_input: str) -> NL2CmdResult:
        """
        Main translation method that takes natural language and returns a command result.
        """
        try:
            # Normalize input
            input_text = natural_language_input.strip().lower()
            
            # Detect intent
            intent = self._detect_intent(input_text)
            
            if not intent:
                return NL2CmdResult(
                    input=natural_language_input,
                    os=self.os,
                    command="",
                    alternatives=[],
                    clarification_required=True,
                    error="Could not determine intent from input",
                    explanation="Please provide a clearer description of what you want to do"
                )
            
            # Generate command
            command, explanation = self._generate_command(intent, input_text)
            
            # Generate alternatives
            alternatives = self._generate_alternatives(intent, input_text)
            
            return NL2CmdResult(
                input=natural_language_input,
                os=self.os,
                command=command,
                alternatives=alternatives,
                clarification_required=False,
                error="",
                explanation=explanation,
                command_breakdown=self._breakdown_command(command)
            )
            
        except Exception as e:
            return NL2CmdResult(
                input=natural_language_input,
                os=self.os,
                command="",
                alternatives=[],
                clarification_required=True,
                error=str(e),
                explanation="An error occurred while processing your request"
            )

    def _detect_intent(self, input_text: str) -> Optional[str]:
        """Detect the primary intent from the input text."""
        best_match = None
        best_score = 0
        
        for intent, synonyms in self.intent_synonyms.items():
            for synonym in synonyms:
                if synonym in input_text:
                    score = len(synonym)  # Longer matches are better
                    if score > best_score:
                        best_score = score
                        best_match = intent
        
        return best_match

    def _generate_command(self, intent: str, input_text: str) -> Tuple[str, str]:
        """Generate the appropriate command based on intent and OS."""
        commands = {
            "pwd": {
                "linux": "pwd",
                "macOS": "pwd",
                "windows": "cd"
            },
            "ls": {
                "linux": "ls",
                "macOS": "ls",
                "windows": "dir"
            },
            "cd": {
                "linux": "cd",
                "macOS": "cd",
                "windows": "cd"
            },
            "mkdir": {
                "linux": "mkdir",
                "macOS": "mkdir",
                "windows": "mkdir"
            },
            "rm": {
                "linux": "rm",
                "macOS": "rm",
                "windows": "del"
            },
            "cp": {
                "linux": "cp",
                "macOS": "cp",
                "windows": "copy"
            },
            "mv": {
                "linux": "mv",
                "macOS": "mv",
                "windows": "move"
            }
        }
        
        if intent in commands:
            command = commands[intent][self.os]
            explanation = f"Command to {intent.replace('_', ' ')} on {self.os}"
            return command, explanation
        
        # Default fallback
        return "echo 'Command not implemented'", "Command not yet implemented for this intent"

    def _generate_alternatives(self, intent: str, input_text: str) -> List[str]:
        """Generate alternative commands or approaches."""
        alternatives = []
        
        # Add OS-specific alternatives
        if self.os == "linux":
            alternatives.extend(["man", "help", "--help"])
        elif self.os == "macOS":
            alternatives.extend(["man", "help", "--help"])
        elif self.os == "windows":
            alternatives.extend(["help", "/?", "help"])
        
        return alternatives

    def _breakdown_command(self, command: str) -> Dict[str, str]:
        """Break down a command into its components for explanation."""
        if not command:
            return {}
        
        parts = command.split()
        breakdown = {}
        
        if parts:
            breakdown["command"] = parts[0]
            if len(parts) > 1:
                breakdown["arguments"] = " ".join(parts[1:])
        
        return breakdown
