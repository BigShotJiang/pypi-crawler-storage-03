

print("Hello world!")