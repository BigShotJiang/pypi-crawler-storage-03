# Changelog

## 0.1.1 (2025-08-22)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/evrimai/fleet-client/compare/v0.1.0...v0.1.1)

### Chores

* update github action ([c381e7b](https://github.com/evrimai/fleet-client/commit/c381e7bf6e43d386fba8b6a0b97c640fc546252d))

## 0.1.0 (2025-08-12)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/evrimai/fleet-client/compare/v0.0.1...v0.1.0)

### Chores

* update SDK settings ([cdf80fa](https://github.com/evrimai/fleet-client/commit/cdf80fa800399b84a4be3220a6700d29f6e63acf))
* update SDK settings ([7eb1ac3](https://github.com/evrimai/fleet-client/commit/7eb1ac32ce6ee54bffea2c5fdb51d7fdd3d760f1))
