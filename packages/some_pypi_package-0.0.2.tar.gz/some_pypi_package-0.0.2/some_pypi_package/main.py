import numpy as np

def hello():
    message = np.array(list('Hello from some pypi package'))
    print(*message)
    