"""
CLI commands for cuti.
"""