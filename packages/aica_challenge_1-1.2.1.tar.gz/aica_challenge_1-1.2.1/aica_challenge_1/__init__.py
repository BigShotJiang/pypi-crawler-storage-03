from aica_challenge_1.challenge import Challenge
from aica_challenge_1.execution_manager import RunSpecification

__all__ = ["Challenge", "RunSpecification"]
