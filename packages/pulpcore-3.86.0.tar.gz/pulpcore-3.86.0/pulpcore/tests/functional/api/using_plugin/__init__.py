"""Tests for core functionality that require plugin involvement to exercise."""
