import pyo3_test


def test_add():
    assert pyo3_test.add(23, 42) == 65
