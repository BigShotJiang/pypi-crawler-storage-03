"""
In order to check
uv run python -m plabic
"""
#pylint:disable=unused-import
import plabic

if __name__ == "__main__":
    print("Plabic imports successfully")
