"""
test for BCFW cells, glued as kaleidoscopes of butterflies
"""
#pylint:disable=unused-import
from plabic import ButterflyData, BCFWCell
