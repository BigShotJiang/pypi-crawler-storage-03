"""
test for framed circles
"""
#pylint:disable=unused-import
from plabic import FramedDiskConfig
