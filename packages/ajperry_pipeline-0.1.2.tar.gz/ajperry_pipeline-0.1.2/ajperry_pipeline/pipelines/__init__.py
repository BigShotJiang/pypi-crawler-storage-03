# Overly verbose, but will be nice 
# when I have more than one pipeline for a project
from .hello import hello_world as hello_world
from .nuscenes import download_nuscene as download_nuscene
