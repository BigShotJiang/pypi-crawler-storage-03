"""Backport CPython changes from main to maintenance branches."""

from __future__ import annotations

from ._version import __version__

__all__ = ["__version__"]
