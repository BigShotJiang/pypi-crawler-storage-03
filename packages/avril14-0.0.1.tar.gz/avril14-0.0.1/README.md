# Avril 14 #
## What is this? ##
avril 14 - is a library for creating and training neural networks
## Functions ##
lin_layer() - create linear layer, which is recorded as

![equation](https://latex.codecogs.com/svg.image?&space;Wx&plus;b), where
![equation](https://latex.codecogs.com/svg.image?W) - weights of layer

![equation](https://latex.codecogs.com/svg.image?b) - biases of layer

relu() - activation function

backprop() - start process of neural network learning

## Guide 1: approximation of cos function ##
