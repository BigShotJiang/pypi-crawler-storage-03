def relu_derivative(z,n):
  if z<=n:
    return 0
  else:
    return 1