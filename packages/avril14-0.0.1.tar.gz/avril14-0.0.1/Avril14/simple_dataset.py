import math
def simple_dataset(n):
  X = []
  y = []
  for i in range(n):
    X.append(i+1)
    y.append(math.cos(i+1))
  return X,y
