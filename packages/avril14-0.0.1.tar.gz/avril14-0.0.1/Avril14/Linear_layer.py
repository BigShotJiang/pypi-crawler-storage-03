import numpy as np
class lin_layer():
  def __init__(self,n,m,funcy):
    self.w = np.random.rand(m,n)
    self.b = np.random.rand(m,1)
    if funcy == func:
      self.func = funcy
  def forward(self,x):
      z = x @ self.w
      z = z + self.b
      y = self.func(z)
      return z,y