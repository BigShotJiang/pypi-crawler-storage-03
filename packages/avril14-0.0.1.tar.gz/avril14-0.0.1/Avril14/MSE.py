def MSE(n,y_k,y):
    y_k = y_k
    n = n
    z = []
    z2 = []
    for i,m in y_k,y:
      m1 = i - m
      z.append(m1)
    for u in z:
      m2 = u**2
      z2.append(m2)
    m3 = sum(z2)
    m4 = m3/n
    return m4