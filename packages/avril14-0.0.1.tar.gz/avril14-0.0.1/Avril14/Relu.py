import numpy as np
def relu(x,n):
    x = np.array(x)
    z = np.zeros_like(x)
    for i in range(x.shape[0]):
        for j in range(x.shape[1]):
            z[i][j] = max(n, x[i][j])
    return z
