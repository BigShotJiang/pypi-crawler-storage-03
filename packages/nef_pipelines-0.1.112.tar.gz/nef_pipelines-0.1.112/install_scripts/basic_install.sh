
export NEF_PIPELINES_AUTO_INSTALL=yes
  curl -sL https://raw.githubusercontent.com/varioustoxins/NEF-Pipelines/refs/heads/master/install_scripts/install.sh \
| bash
