# Tutorials

```{toctree}
auto_examples/index
tutorials/getting-started
tutorials/sklearn
```
