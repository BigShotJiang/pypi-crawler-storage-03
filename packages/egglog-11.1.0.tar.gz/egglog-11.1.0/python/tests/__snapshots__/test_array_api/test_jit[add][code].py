def __fn(x, y):
    _0 = x + y
    return _0
