"""cmem-plugin-base"""
