debug_prefix = "Debug: "
debug_description_prefix = "This debugging session opens one by one all the examples "
