from .slice import QueryBasedSliceFunction

__all__ = ["QueryBasedSliceFunction"]
