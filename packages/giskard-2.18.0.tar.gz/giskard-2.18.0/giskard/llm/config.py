class LLMConfigurationError(ValueError):
    """Raised when the LLM client is not configured properly."""
