from .spurious_correlation_detector import SpuriousCorrelationDetector

__all__ = ["SpuriousCorrelationDetector"]
