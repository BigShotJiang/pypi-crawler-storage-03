"""Test utilities for Switch E2E testing

This module contains utilities and helpers specifically designed for testing Switch.
These are NOT intended for production use - they are internal testing tools only.
"""