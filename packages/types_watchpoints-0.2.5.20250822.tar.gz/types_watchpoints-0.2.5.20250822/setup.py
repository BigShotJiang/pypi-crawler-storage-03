
from setuptools import setup

setup(package_data={'watchpoints-stubs': ['__init__.pyi', 'ast_monkey.pyi', 'util.pyi', 'watch.pyi', 'watch_element.pyi', 'watch_print.pyi', 'METADATA.toml', 'py.typed']})
