## 0.2.5.20250822 (2025-08-22)

Add missing defaults to third-party stubs ([#14617](https://github.com/python/typeshed/pull/14617))

## 0.2.5.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 0.2.5.20250304 (2025-03-04)

Add stubs for watchpoints (#13248)

