package org.starcraft.hello;

import org.starcraft.subsubmod.Speaker;

public class HelloWorld {
  public static void main(String[] args) {
    System.out.println(Speaker.hello());
  }
}
