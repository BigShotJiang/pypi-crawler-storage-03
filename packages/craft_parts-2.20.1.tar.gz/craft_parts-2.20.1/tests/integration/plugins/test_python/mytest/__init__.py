def main():
    print("it works!")
