import sys

import test_poetry  # type: ignore[import-not-found]

sys.exit(test_poetry.main())
