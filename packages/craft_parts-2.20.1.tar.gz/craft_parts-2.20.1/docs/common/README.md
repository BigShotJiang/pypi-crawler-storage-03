 This directory contains documentation files that are meant to
 be shared and reused by applications using craft-parts.
 