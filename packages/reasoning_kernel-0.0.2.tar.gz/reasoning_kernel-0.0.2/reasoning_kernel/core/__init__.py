"""
Core configuration and setup modules
"""
