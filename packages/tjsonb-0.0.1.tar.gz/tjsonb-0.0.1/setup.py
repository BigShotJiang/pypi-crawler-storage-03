from setuptools import setup

setup(
    name="tjsonb",
    version="0.0.1",
    description="Python bindings for tjsonb PostgreSQL extension",
    packages=["tjsonb"],
    python_requires=">=3.7",
)
