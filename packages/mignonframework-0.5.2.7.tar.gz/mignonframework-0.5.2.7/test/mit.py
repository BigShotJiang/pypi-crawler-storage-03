import requests
import json

# 由 Mignon Rex 的 MignonFramework.CurlToRequestsConverter 生成
# Have a good Request

headers = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7,zh-HK;q=0.6,zh-TW;q=0.5",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Content-Type": "application/json;charset=UTF-8",
    "Origin": "http://10.16.129.72:12000",
    "Pragma": "no-cache",
    "Referer": "http://10.16.129.72:12000/maritimeLawEnforcement/login?redirect=/combatCrime/marineActivityMonitoring",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
}

json_data = {
    "userName": "admin",
    "password": "1cf79a0e5ef31d03084ef172f804c4bd87fe40db027e888efb112541a1b41079566a56c1c7fbbdf5233a43fa650088de3f9efc4c58741217f35b2670c0b8a31366166532c50b0267538cfb1ab171572c4685632acd01fcf7e896164b46b22d955e1d3fe18708"
}

url = "http://10.16.129.72:12000/auth-api/login/password"

response = requests.post(
    url,
    headers=headers,
    json=json_data,
    verify=False
)

# The following print statements are for debugging and are not part of the core request logic.
print(f"状态码: {response.status_code}")
try:
    print("响应 JSON:", response.json())
except json.JSONDecodeError:
    print("响应文本:", response.text)