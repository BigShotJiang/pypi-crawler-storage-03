from whitespace_correction.api import *  # noqa
from whitespace_correction.version import __version__  # noqa
