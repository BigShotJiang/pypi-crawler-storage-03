Betelgeuse
==========

.. image:: https://codecov.io/gh/SatelliteQE/betelgeuse/branch/master/graph/badge.svg
    :target: https://codecov.io/gh/SatelliteQE/betelgeuse

.. image:: https://readthedocs.org/projects/betelgeuse/badge/?version=latest
    :target: http://betelgeuse.readthedocs.org/en/latest/?badge=latest
    :alt: Documentation Status

Betelgeuse reads standard Python test cases and generates XML files that are
suited to be imported by Polarion importers. Possible generated XML files are:

* Requirement Importer XML
* Test Case Importer XML
* Test Run Importer XML

The `full documentation <http://betelgeuse.readthedocs.org/en/latest/>`_ is
available on ReadTheDocs.
