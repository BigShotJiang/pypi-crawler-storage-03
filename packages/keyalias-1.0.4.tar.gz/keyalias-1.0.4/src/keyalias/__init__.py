from keyalias.core import *
from keyalias.tests import test

keyalias = getdecorator  # legacy
