# API 参考

> API文档由代码自动生成，不提供翻译

- [ptcmd.argument](argument.md)
- [ptcmd.info](info.md)
- [ptcmd.command](command.md)
- [ptcmd.completer](completer.md)
- [ptcmd.core](core.md)
