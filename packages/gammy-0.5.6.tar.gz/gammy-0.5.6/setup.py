"""Minimal setup.py to allow editable install with

    pip install -e .

"""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
