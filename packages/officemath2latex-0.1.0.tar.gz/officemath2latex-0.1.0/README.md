# OfficeMath to Latex Python

This small tool converts office math xml string to LaTeX string. Translated from Javascript script [officemath2latex.js](https://github.com/555555555a555/officemath2latex.js).

To use from PyPI:

```sh
pip install officemath2latex
```
