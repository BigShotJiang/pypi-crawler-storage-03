"""Tools for development, testing and releasing of Darker, Graylint and Darkgraylib."""

__version__ = "0.3.0"
