# pylibsrcml
Python bindings for libsrcml. V1.1.0 August 2025

All of libsrcml is supported (and tested). To install:

Make sure the latest version of [srcML v1.1.0](https://github.com/srcML/srcML) is installed. Then run:

`pip install pylibsrcml`

pylibsrcml supports Python 3.10 and later.
