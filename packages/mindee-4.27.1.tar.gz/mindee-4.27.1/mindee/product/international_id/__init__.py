from mindee.product.international_id.international_id_v2 import InternationalIdV2
from mindee.product.international_id.international_id_v2_document import (
    InternationalIdV2Document,
)
