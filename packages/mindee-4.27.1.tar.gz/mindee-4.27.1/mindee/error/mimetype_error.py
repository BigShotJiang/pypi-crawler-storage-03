class MimeTypeError(AssertionError):
    """The MIME Type is not valid."""
