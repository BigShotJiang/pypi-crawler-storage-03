from mindee.parsing.common.ocr.ocr import Ocr
