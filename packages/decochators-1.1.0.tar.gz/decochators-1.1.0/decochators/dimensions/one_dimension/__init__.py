from .attach_chaos_1d import attach_chaos_tests_1d

__all__ = ["attach_chaos_tests_1d"]