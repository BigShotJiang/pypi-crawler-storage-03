class PathValidateError(Exception):
    pass
