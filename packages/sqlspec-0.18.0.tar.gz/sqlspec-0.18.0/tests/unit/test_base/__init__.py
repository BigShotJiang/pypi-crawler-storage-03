"""Unit tests for the SQLSpec base class and core functionality."""
