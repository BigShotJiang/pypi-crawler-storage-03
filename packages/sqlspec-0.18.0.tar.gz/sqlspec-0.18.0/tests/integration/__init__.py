"""Integration tests for SQLSpec with CORE_ROUND_3 architecture."""
