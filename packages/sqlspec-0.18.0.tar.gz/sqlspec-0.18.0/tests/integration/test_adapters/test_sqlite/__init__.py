"""Integration tests for SQLite adapter with CORE_ROUND_3 architecture."""
