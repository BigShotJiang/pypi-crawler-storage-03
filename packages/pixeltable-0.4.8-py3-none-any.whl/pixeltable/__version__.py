# These version placeholders will be replaced during build.
__version__ = '0.0.0'
__version_tuple__ = (0, 0, 0)
