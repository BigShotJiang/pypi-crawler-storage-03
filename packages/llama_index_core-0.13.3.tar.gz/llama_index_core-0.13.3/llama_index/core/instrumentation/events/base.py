from llama_index_instrumentation.base import BaseEvent  # noqa
