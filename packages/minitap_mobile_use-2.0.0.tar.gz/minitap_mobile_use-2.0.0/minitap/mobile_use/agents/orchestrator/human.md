Here is your input.

---

**Initial goal** : {{ initial_goal }}

**Subgoal plan**
{{ subgoal_plan }}

**Current subgoal** : {{ current_subgoal }}

**Agent thoughts**
{{ agent_thoughts }}