def upload(self):
    # 上传功能待定
    # 需要申请公司钉钉云盘权限，才能开发
    None
