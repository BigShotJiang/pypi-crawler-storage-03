# dasende

**just something useless to install**

## Installation

```bash
pip install dasende
```

## Usage

```python
from dasende import useless_function

print(useless_function())
# Output: This function does absolutely nothing useful, enjoy!
```