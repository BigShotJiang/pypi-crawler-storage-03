"""
dasende - just something useless to install
"""

from .core import useless_function

__all__ = ["useless_function"]