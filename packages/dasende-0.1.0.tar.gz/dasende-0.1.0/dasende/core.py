def useless_function():
    return "This function does absolutely nothing useful, enjoy!"

if __name__ == "__main__":
    print(useless_function())