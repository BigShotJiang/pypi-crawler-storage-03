from setuptools import setup, find_packages

setup(
    name="dasende",
    version="0.1.0",
    description="just something useless to install",
    author="DasEnde",
    author_email="osintdynamics@cybersecurity.com",
    url="https://pypi.org/project/dasende/",
    packages=find_packages(),
    python_requires=">=3.8",
)