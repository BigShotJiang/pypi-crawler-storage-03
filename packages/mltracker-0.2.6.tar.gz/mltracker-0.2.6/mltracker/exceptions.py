class Conflict(Exception):
    """
    An object with a given attribute already exists.
    """ 