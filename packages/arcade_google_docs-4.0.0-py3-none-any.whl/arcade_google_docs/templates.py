optional_file_picker_instructions_template = (
    "Ensure the user knows that they have the option to select and grant access permissions to "
    "additional documents via the Google Drive File Picker. "
    "The user can pick additional documents via the following link: {url}"
)
