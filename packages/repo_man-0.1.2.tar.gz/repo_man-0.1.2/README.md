# repo-man

Manage repositories of a variety of different types.
Read [the full documentation](https://repo-man.readthedocs.org) to learn more.

## Installation

```shell
$ python -m pip install repo-man
```
