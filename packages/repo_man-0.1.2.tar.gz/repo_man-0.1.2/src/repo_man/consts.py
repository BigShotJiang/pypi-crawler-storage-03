from importlib import metadata

REPO_TYPES_CFG = "repo-man.cfg"
DISTRIBUTION_NAME = "repo-man"
RELEASE_VERSION = metadata.version(DISTRIBUTION_NAME)
