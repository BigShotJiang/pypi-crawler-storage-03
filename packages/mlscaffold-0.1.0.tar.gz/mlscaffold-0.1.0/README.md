# mlscaffold

A tiny CLI to bootstrap Machine Learning projects:

```bash
pip install mlscaffold
mlscaffold my-new-project
