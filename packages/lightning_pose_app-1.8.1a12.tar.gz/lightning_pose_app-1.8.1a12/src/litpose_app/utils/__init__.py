# Utility package for helper functions used across routes and app lifecycle.
