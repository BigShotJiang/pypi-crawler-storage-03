=======
CHANGES
=======

.. towncrier release notes start

0.0.2 (2025-08-23)
==================

- Added support for query argument validation.
- Added `tags` parameter to decorators to allow grouping of endpoints.

0.0.1 (2024-08-15)
==================

- Initial release with schema generation and request body validation.
