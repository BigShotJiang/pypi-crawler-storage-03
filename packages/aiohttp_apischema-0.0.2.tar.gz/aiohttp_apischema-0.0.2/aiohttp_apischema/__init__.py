from aiohttp_apischema.generator import SchemaGenerator as SchemaGenerator
from aiohttp_apischema.response import APIResponse as APIResponse

__version__ = "0.0.2"
