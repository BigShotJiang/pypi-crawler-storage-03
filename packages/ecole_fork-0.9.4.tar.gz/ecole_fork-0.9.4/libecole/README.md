# The C++ Ecole library

The C++ library contains the complete set of Ecole features.
