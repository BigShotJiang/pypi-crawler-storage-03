# The Python bindings of the C++ library

None of the features of Ecole are implemented here.
These directories contain only the logic to create proper bindings.
