.. _information-reference:

Informations
============

Interface
---------
.. autoclass:: ecole.typing.InformationFunction


Listing
-------
The list of information functions relevant to users is given below.

Nothing
^^^^^^^
.. autoclass:: ecole.information.Nothing
