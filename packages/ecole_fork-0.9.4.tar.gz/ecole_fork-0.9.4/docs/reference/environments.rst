Environments
============

Interface
---------
.. autoclass:: ecole.environment.Environment

Protocol
--------
.. autoclass:: ecole.typing.Dynamics

Listing
-------
Branching
^^^^^^^^^
.. autoclass:: ecole.environment.Branching
.. autoclass:: ecole.dynamics.BranchingDynamics

Configuring
^^^^^^^^^^^
.. autoclass:: ecole.environment.Configuring
.. autoclass:: ecole.dynamics.ConfiguringDynamics

PrimalSearch
^^^^^^^^^^^^
.. autoclass:: ecole.environment.PrimalSearch
.. autoclass:: ecole.dynamics.PrimalSearchDynamics
