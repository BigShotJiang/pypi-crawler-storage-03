#pragma once

#include "ecole/data/abstract.hpp"

namespace ecole::reward {

using Reward = double;

}  // namespace ecole::reward
