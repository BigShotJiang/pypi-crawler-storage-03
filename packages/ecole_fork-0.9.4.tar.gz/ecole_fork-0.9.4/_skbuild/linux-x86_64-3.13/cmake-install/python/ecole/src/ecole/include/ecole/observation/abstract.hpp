#pragma once

#include "ecole/data/abstract.hpp"
