- Go to Customer Payment and print the "Receipt" Report
- Go to Statement Operations (bank statement lines) and print the
  "Payment Disposal / Collection" Report
