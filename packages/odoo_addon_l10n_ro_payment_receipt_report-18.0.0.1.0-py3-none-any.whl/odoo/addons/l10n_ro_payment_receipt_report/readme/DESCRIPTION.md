This module allows you to print cash reports for:  
- receipt
- payment disposal
- payment collection
