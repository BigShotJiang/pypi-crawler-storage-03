# Changelog

## [0.1.0] - 2025-01-18

### Added
- Initial release of CloudWatch Application Signals MCP Server
- `list_monitored_services` tool for listing all monitored services
- `get_service_detail` tool for detailed service information
- Support for AWS Application Signals monitoring
- Integration with Claude Desktop and Amazon Q
