from .service import ApiLotacaoService
