"""Models for vid-cleaner app."""

from .video_file import VideoFile

__all__ = ["VideoFile"]
