"""Controllers for the VidCleaner application."""

from .temp_files import TempFile

__all__ = ["TempFile"]
