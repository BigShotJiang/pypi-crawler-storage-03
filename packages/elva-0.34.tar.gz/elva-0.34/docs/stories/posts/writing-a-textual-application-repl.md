---
date: 2025-03-11
author:
  - Jakob Zahn
draft: true
---

# Writing a Textual App REPL

- do not forget `can_focus=True`, otherwise `on_key` of widget is not called and no characters are fed into REPL
