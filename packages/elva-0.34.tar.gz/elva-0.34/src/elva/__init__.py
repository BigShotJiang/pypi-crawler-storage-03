"""
ELVA

This package includes library modules and subpackages for building real-time synchronization apps alongside ready-to-use terminal applications.
"""
