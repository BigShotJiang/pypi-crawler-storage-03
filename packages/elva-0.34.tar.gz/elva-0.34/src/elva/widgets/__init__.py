"""
Subpackage containing widgets for [`Textual`](https://textual.textualize.io/) apps.
"""
