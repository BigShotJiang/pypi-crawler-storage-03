"""
Real-time collaboration text editor.
"""

from .cli import cli

__all__ = [cli]
