"""
Additions to rich and some forking/customizations needed for kash.
"""
