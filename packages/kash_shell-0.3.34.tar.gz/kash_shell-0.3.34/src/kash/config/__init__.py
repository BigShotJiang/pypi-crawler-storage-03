"""
App specific setup, settings, and configs. Should have no dependencies outside
this module except for a very few things in the util module.
"""
