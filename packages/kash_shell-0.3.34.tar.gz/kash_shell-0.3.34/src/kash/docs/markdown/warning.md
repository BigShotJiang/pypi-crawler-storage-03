**Important:** This is a shell.
Commands can be destructive.
Review commands carefully!
