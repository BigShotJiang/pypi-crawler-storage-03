import numpy as np
from typing import Optional, List, Literal
from numpy.typing import NDArray
from dataclasses import dataclass, field
from .hota_errors import (
    InvalidIDAlignmentMethodError,
    InvalidSimilarityMetricError,
    EmptyIOUThresholdsError,
    InvalidIOUThresholdsRangeError
)


@dataclass
class HOTAConfig:
    """
    Configuration for HOTA calculation.
    
    This class defines all parameters needed for computing HOTA metrics,
    including alignment methods, similarity metrics, and filtering options.
    """
    
    class_ids: Optional[List[int]] = None
    """List of class IDs to evaluate. If None, all classes are evaluated."""
    
    gids: Optional[List[int]] = None  
    """Ground truth IDs to use for evaluation. If provided, all other IDs are ignored."""
    
    id_alignment_method: Literal['global', 'per_video', 'per_frame'] = 'global'
    """Method for aligning IDs between reference and comparison data:
    - 'global': Align IDs across all videos globally
    - 'per_video': Align IDs separately for each video  
    - 'per_frame': Align IDs separately for each frame
    """
    
    track_fp_fn_tp_box_hashes: bool = False
    """Whether to track box hashes for detailed FP/FN/TP analysis."""
    
    reference_contains_dense_annotations: bool = False
    """Whether the reference data dataframes contain dense annotations. If False, non-matched comparison IDs are removed to reduce FP counts to only those global ids which have a match in the reference data. The non-matching comparison ids are counted in an UnmatchedFP field in the HOTA data.
    Consider the case where only 2 objects are tracked in a crowded ground truth video file. The comparison results will likely have many more boxes for the confuser objects for which GT data is missing (this is non-dense ground truth). In other words, this flag is useful when the reference/ground truth data which does not have full dense annotations of all objects in the video. 
    """
    
    iou_thresholds: NDArray[np.float64] = field(default_factory=lambda: np.arange(0.1, 0.99, 0.1))
    """Array of IoU thresholds to evaluate at."""
    
    similarity_metric: Literal['iou', 'latlon', 'latlonalt'] = 'iou'
    """Similarity metric to use:
    - 'iou': Intersection over Union for bounding boxes
    - 'latlon': L2 distance for lat/lon coordinates
    - 'latlonalt': L2 distance for lat/lon/alt coordinates
    """

    suppress_print_statements: bool = False
    """Whether to suppress print statements. This is useful for running the evaluator within a larger context."""

    def validate(self) -> None:
        """Validate configuration parameters."""
        ID_ALIGNMENT_METHODS = ['global','per_video','per_frame']
        SIMILARITY_METRICS = ['iou', 'latlon', 'latlonalt']

        if self.id_alignment_method not in ID_ALIGNMENT_METHODS:
            raise InvalidIDAlignmentMethodError(self.id_alignment_method, ID_ALIGNMENT_METHODS)
        if self.similarity_metric not in SIMILARITY_METRICS:
            raise InvalidSimilarityMetricError(self.similarity_metric, SIMILARITY_METRICS)
        if len(self.iou_thresholds) == 0:
            raise EmptyIOUThresholdsError()
        if not np.all((self.iou_thresholds >= 0) & (self.iou_thresholds <= 1)):
            raise InvalidIOUThresholdsRangeError(self.iou_thresholds)