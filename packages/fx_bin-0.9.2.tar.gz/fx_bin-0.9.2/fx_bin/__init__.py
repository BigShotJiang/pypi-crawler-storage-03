# -*- coding: utf-8 -*-

"""Top-level package for Python FX bin."""

__author__ = """Frank Xu"""
__email__ = 'frank@frankxu.me'
__version__ = '0.7.1'
