"""FastAPI Template CLI - A tool for scaffolding FastAPI projects."""

__version__ = "0.1.0"
__author__ = "FastAPI Template CLI"
__email__ = "sohailahmed34290@gmail.com"