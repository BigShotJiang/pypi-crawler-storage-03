from __future__ import annotations
from pydantic import BaseModel, Field
from typing import List, Any, Optional

class CandidateLocation(BaseModel):
    x: float
    y: float
    spatial_reference: int = Field(4326, alias="wkid")

class Candidate(BaseModel):
    address: str = Field(alias="address")
    score: float
    x: float
    y: float
    attributes: dict[str, Any] | None = None

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> "Candidate":
        loc = raw.get("location") or {}
        return cls(
            address=raw.get("address") or raw.get("Address") or "",
            score=raw.get("score") or 0,
            x=loc.get("x"),
            y=loc.get("y"),
            attributes=raw.get("attributes") or {},
        )

class GeocodeResult(BaseModel):
    spatial_reference: int = 4326
    candidates: List[Candidate]
    raw: dict[str, Any]
