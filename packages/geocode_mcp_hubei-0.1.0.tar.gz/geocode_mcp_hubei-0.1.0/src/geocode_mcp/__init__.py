__all__ = ["geocode", "GeocodeResult"]
from .models import GeocodeResult
from .client import geocode
