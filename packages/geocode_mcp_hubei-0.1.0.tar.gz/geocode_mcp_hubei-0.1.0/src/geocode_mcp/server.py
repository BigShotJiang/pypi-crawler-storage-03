from __future__ import annotations
import json
import sys
from typing import Any, Dict
from .client import geocode

TOOL_NAME = "geocode_poi"

# A very lightweight MCP-like stdin/stdout loop (simplified) for demonstration.

def handle_request(req: Dict[str, Any]) -> Dict[str, Any]:
    method = req.get("method")
    if method == "tools/list":
        return {
            "id": req.get("id"),
            "result": {
                "tools": [
                    {
                        "name": TOOL_NAME,
                        "description": "Geocode address using 湖北 POI locator (returns up to 8 candidates)",
                        "input_schema": {
                            "type": "object",
                            "properties": {"address": {"type": "string"}},
                            "required": ["address"],
                        },
                    }
                ]
            },
        }
    if method == "tools/call":
        params = req.get("params") or {}
        name = params.get("name")
        if name != TOOL_NAME:
            return {"id": req.get("id"), "error": {"code": 404, "message": "Unknown tool"}}
        args = params.get("arguments") or {}
        address = args.get("address")
        if not address:
            return {"id": req.get("id"), "error": {"code": 400, "message": "address required"}}
        try:
            result = geocode(address)
            if not result.candidates:
                if not result.candidates:
                    return {
                        "id": req.get("id"),
                        "error": {
                            "code": 204,  # No Content semantic
                            "message": "未找到候选结果，请尝试提供更具体的地址描述"
                        }
                    }
                return {"id": req.get("id"), "error": {"code": 404, "message": f"未找到匹配结果: {address}"}}
            simplified = [
                {
                    "address": c.address,
                    "score": c.score,
                    "x": c.x,
                    "y": c.y,
                }
                for c in result.candidates
            ]
            return {
                "id": req.get("id"),
                "result": {
                    "content": [
                        {
                            "type": "application/json",
                            "data": {
                                "spatial_reference": result.spatial_reference,
                                "candidates": simplified,
                            },
                        }
                    ]
                },
            }
        except Exception as e:  # noqa
            return {"id": req.get("id"), "error": {"code": 500, "message": str(e)}}
    return {"id": req.get("id"), "error": {"code": 400, "message": "Unsupported method"}}


def run_server():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            resp = {"error": {"code": -32700, "message": "Parse error"}}
            print(json.dumps(resp), flush=True)
            continue
        resp = handle_request(req)
        print(json.dumps(resp, ensure_ascii=False), flush=True)


def main():
    run_server()

if __name__ == "__main__":
    main()
