from __future__ import annotations
import httpx
from .models import GeocodeResult, Candidate

GEOCODE_ENDPOINT = "https://geosc41.aakle.cn/server/rest/services/湖北POI_要素定位器/GeocodeServer/findAddressCandidates"

DEFAULT_PARAMS = {
    "outFields": "*",
    "outSR": 4326,
    "f": "pjson",
    "maxLocations": 8,
}

def geocode(address: str) -> GeocodeResult:
    """同步地理编码调用。

    参数:
        address: 地址字符串，对应远程服务 SingleLine。
    返回:
        GeocodeResult 模型。
    """
    params = DEFAULT_PARAMS | {"SingleLine": address}
    with httpx.Client(timeout=10) as client:
        r = client.get(GEOCODE_ENDPOINT, params=params)
        r.raise_for_status()
        data = r.json()
    spatial_ref = (data.get("spatialReference") or {}).get("wkid", 4326)
    raw_candidates = data.get("candidates") or []
    candidates = [Candidate.from_raw(c) for c in raw_candidates]
    return GeocodeResult(spatial_reference=spatial_ref, candidates=candidates, raw=data)
