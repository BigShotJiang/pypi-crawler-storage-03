TODO: small tutorial

