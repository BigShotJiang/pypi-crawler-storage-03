import asyncio

from cuery.actors import topics

asyncio.run(topics.main())
