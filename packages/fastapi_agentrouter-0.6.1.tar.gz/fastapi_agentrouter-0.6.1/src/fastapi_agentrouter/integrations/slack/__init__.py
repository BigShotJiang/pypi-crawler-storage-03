"""Slack integration for FastAPI AgentRouter."""

from .router import router

__all__ = ["router"]
