"""
s3 (through boto3) with a simple (dict-like or list-like) interface
"""

from s3dol.base import S3Dol
from s3dol.store import S3Store
