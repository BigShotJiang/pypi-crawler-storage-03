"""
Splitwise Plugin for Lunchmoney
"""
