from . import AlignSubs

def main():
    AlignSubs.run()

if __name__ == "__main__":
    main()
