class ParseException(Exception):
    pass


class InconsistentAnnotation(Exception):
    pass
