# -*- coding: utf-8 -*-

from mlgidGUI import main


if __name__ == '__main__':
    main()