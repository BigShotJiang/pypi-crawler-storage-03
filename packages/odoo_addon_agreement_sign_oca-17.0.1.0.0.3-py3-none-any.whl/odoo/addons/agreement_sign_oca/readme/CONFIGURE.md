1. Go to company settings and set "Signed Agreements Stage"
