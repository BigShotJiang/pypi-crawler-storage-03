Sign Request Creation Process
1. Navigate to an existing Agreement.
2. Click the "Request Signature" button to generate a new sign request.
3. From the new Sign Request, click the "Configure Document" smart button to set the position for signatures and other dynamic fields.
4. Once configured, return to the request and click the "Send" button.
5. After the document is fully signed, the related Agreement will be automatically moved to the stage defined in the company settings.
