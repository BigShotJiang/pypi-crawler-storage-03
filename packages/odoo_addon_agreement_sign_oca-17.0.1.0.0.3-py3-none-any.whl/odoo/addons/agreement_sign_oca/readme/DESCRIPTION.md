Create signature request from any agreement.
When full signed agreement will be moved automatically to defined stage attaching a copy of the signed document.
Also a smart-button will be displayed on the agreement's form view showing the
linked Sign Requests.
