chip_size = (256, 256)
