=========================================
Welcome to python project template docs!
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   README

=========================================
Indices and tables
=========================================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
