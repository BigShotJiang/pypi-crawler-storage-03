"""This is a script that use the package as a module."""
#!/usr/bin/env python
