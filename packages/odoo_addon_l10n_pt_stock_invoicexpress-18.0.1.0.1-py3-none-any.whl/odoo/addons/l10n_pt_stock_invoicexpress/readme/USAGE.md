On Delivery Orders and Internal Transfer documents, validating the
transfer automatically generates an InvoiceXpress "Guia de Transporte"
for the Done quantities.

The "Email InvoiceXpress" requests the InvoiceXpress service to send an
email with a copy of the legal document. The content of this email can
be configure in Odoo.
