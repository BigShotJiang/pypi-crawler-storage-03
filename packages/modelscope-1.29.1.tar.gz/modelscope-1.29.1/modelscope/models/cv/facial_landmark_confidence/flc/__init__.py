# Copyright (c) Alibaba, Inc. and its affiliates.
from .facial_landmark_confidence import FacialLandmarkConfidence
