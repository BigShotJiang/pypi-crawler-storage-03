# Copyright (c) Alibaba, Inc. and its affiliates.
from .beit_v2 import BEiTv2
from .nextvit import NextViT
