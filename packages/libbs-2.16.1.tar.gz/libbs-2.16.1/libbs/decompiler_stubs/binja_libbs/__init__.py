try:
    from libbs.decompilers.binja import *
except ImportError:
    print("[!] libbs is not installed, please `pip install libbs` for THIS python interpreter")
