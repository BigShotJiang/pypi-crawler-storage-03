"""
Core functionality for emailer-simple-tool application.
"""
