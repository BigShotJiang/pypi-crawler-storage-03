# Firehound Firebase Security Scanner

**Firebase security scanner for iOS apps - Now available on PyPI!**

[![PyPI version](https://badge.fury.io/py/firehound-scanner.svg)](https://badge.fury.io/py/firehound-scanner)

Firehound automatically downloads iOS applications from the App Store, extracts their Firebase configurations, and systematically tests for security misconfigurations.

**Command transformation: 151 → 29 characters (80% reduction!)**
- Before: `VERBOSE=1 python3 firehound.py --search rizz --limit 1 --keychain-passphrase 1 --apple-id-password 'pass' --email user@example.com --timeout 60`
- After: `firehound --search rizz -l 1`

## 🚀 Quick Start

### Installation
```bash
# Install from PyPI  
pip install firehound-scanner

# Or with pipx (recommended)
pipx install firehound-scanner
```

### Prerequisites
Install ipatool (required for App Store downloads):
```bash
# macOS
brew install majd/repo/ipatool

# Linux - download from GitHub releases
# https://github.com/majd/ipatool/releases
```

### First-time Setup
```bash
# Interactive login with 2FA
ipatool auth login --email your@email.com

# Set environment variables (one-time)
export FIREHOUND_EMAIL='your@email.com'
export FIREHOUND_KEYCHAIN_PASSPHRASE='your_passphrase'
export FIREHOUND_APPLE_ID_PASSWORD='your_password'
```

### Usage Examples
```bash
# Search and scan apps
firehound --search "banking apps" -l 3

# Scan specific app
firehound --bundle-id com.example.app

# Batch scan from file  
firehound --ids-file app-list.txt

# Scan extracted app directory
firehound --directory /path/to/extracted/app
```

## Executive Summary

Firehound is a sophisticated Firebase security scanner that:
1. **Downloads iOS applications** from the App Store using `ipatool`
2. **Extracts Firebase configuration** from iOS app bundles
3. **Systematically tests Firebase services** for misconfigurations
4. **Performs authenticated testing** when possible
5. **Generates detailed vulnerability reports** with evidence

## Core Architecture Overview

```mermaid
graph TD
    A["App Store Search"] --> B["IPA Download"]
    B --> C["Configuration Extraction"]
    C --> D["Firebase Service Discovery"]
    D --> E["Unauthenticated Testing"]
    E --> F["Authentication Attempt"]
    F --> G["Authenticated Testing"]
    G --> H["Vulnerability Classification"]
    H --> I["Report Generation"]
    
    subgraph Services["Firebase Services Tested"]
        J["Realtime Database"]
        K["Firestore"]
        L["Storage Buckets"]
        M["Cloud Functions"]
        N["Firebase Hosting"]
    end
    
    E --> J
    E --> K
    E --> L
    E --> M
    E --> N
    
    G --> J
    G --> K
    G --> L
```

## Phase 1: iOS Application Acquisition

### App Store Search Process

When using `--search`, Firehound performs intelligent App Store discovery:

```python
# Search execution flow
ipatool_search(term="banking", limit=10) ->
    1. Execute: ipatool search --format json "banking" --limit 10
    2. Parse JSON response for bundle IDs
    3. Fallback to text parsing if JSON fails
    4. Return deduplicated bundle ID list
```

**Key Implementation Details:**
- **Multiple command formats**: Tries different argument orders for compatibility
- **Robust parsing**: Handles both JSON and text responses
- **Deduplication**: Ensures unique bundle IDs
- **Error handling**: Graceful fallback mechanisms

### IPA Download & Extraction

For each discovered bundle ID, Firehound performs a complex download process:

#### 1. Authentication Management
```python
# Auto-authentication flow
run_ipatool_download(bundle_id) ->
    1. Check existing auth: ipatool auth info
    2. Auto-login if needed: ipatool auth login
    3. Acquire license: ipatool purchase --bundle-identifier
    4. Download by bundle: ipatool download --bundle-identifier
    5. Fallback to app ID if bundle fails
```

#### 2. IPA Processing
```python
# Extraction workflow
process_bundle_id() ->
    1. Create output directory: /path/bundle_id/
    2. Download IPA to: bundle_id.ipa
    3. Extract critical files:
       - Info.plist (app metadata)
       - GoogleService-Info.plist (Firebase config)
    4. Convert binary plists to XML
    5. Delete IPA file (save space)
    6. Proceed to security analysis
```

**Critical Files Extracted:**
- **`Info.plist`**: Contains app metadata, display name, version
- **`GoogleService-Info.plist`**: Firebase project configuration

## Phase 2: Firebase Configuration Analysis

### Configuration Parsing

The heart of Firehound's analysis begins with parsing `GoogleService-Info.plist`:

```python
# Configuration extraction
with open("GoogleService-Info.plist", "rb") as f:
    cfg = plistlib.load(f)

# Key configuration values extracted:
{
    "PROJECT_ID": "quitvaping-8cfeb",           # Firebase project identifier
    "DATABASE_URL": "https://quitvaping-8cfeb.firebaseio.com",  # Realtime DB URL
    "STORAGE_BUCKET": "quitvaping-8cfeb.appspot.com",           # Storage bucket
    "API_KEY": "AIzaSyC-qKpFx1mL_I--rpzWjdWScPItg-OjhEw",      # Client API key
    "CLIENT_ID": ["123456789-abc.apps.googleusercontent.com"],  # OAuth client
}
```

### Service URL Construction

From this configuration, Firehound constructs service endpoints:

```python
# Service endpoint mapping
realtime_db = f"{DATABASE_URL}/path/.json"
firestore = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents"
storage = f"https://firebasestorage.googleapis.com/v0/b/{STORAGE_BUCKET}/o"
functions = f"https://{region}-{PROJECT_ID}.cloudfunctions.net/{function_name}"
hosting = [f"https://{PROJECT_ID}.web.app/", f"https://{PROJECT_ID}.firebaseapp.com/"]
```

## Phase 3: Systematic Security Testing

### 3.1 Realtime Database Testing (`fuzz_rtdb`)

Firehound performs comprehensive Realtime Database security assessment:

#### Security Rules Exposure Test
```python
# Check if security rules are publicly readable
rules_url = f"{DATABASE_URL}/.rules.json"
response = http_request(rules_url)
if response.status == 200:
    return "CRITICAL: Security rules are publicly readable"
```

#### Data Access Pattern Testing
```python
# Test common database paths
rtdb_roots = ["users", "public", "profiles", "data", "messages", "config", 
              "settings", "dev", "prod", "staging", "test", "logs", "info", 
              "private", "admin"]

for root in rtdb_roots:
    url = f"{DATABASE_URL}/{root}/.json?shallow=true&limitToFirst=1"
    response = http_request(url)
    if response.status == 200:
        discovered_paths.append(root)
```

#### Write Access Testing
```python
# Test for public write access
write_data = {"f3tcher_probe": {"timestamp": time.time(), "probe": True}}
write_url = f"{DATABASE_URL}/probes/.json"
response = http_request(write_url, method="PATCH", body=json.dumps(write_data))

if response.status == 200:
    # Clean up test data
    http_request(write_url, method="DELETE")
    return "CRITICAL: Database is publicly writable"
```

**Vulnerability Classification:**
- **CRITICAL**: Public read AND write access
- **OPEN**: Public read access only
- **CLOSED**: Requires authentication

### 3.2 Firestore Testing (`fuzz_firestore`)

Firestore testing uses the REST API with structured queries:

#### Datastore Mode Detection
```python
# Check if project uses Firestore in Datastore mode
response = http_request(f"{base_url}:runQuery?key={API_KEY}", 
                       method="POST", 
                       body='{"structuredQuery":{"limit":1}}')

if "datastore mode" in response.snippet.lower():
    return "NOT_APPLICABLE: Firestore is in Datastore mode"
```

#### Collection Discovery
```python
# Test common collection names
collections = ["users", "profiles", "posts", "messages", "items", "orders", 
               "products", "carts", "config", "settings", "notifications", 
               "chats", "groups", "events", "feedback", "logs", "private", 
               "public", "admin"]

for collection in collections:
    query = {"structuredQuery": {"from": [{"collectionId": collection}], "limit": 1}}
    response = http_request(f"{base_url}:runQuery?key={API_KEY}", 
                           method="POST", 
                           body=json.dumps(query))
    if response.status == 200:
        accessible_collections.append(collection)
```

#### Write Access Testing
```python
# Test document creation without authentication
write_collection = "f3tcher_probes"
write_doc_id = f"probe-{int(time.time())}"
write_url = f"{base_url}/{write_collection}/{write_doc_id}?key={API_KEY}"
write_body = {
    "fields": {
        "probe": {"stringValue": "true"}, 
        "timestamp": {"integerValue": str(int(time.time()))}
    }
}

response = http_request(write_url, method="PATCH", body=json.dumps(write_body))
if response.status == 200:
    # Clean up
    http_request(write_url, method="DELETE")
    return "CRITICAL: Public write access allowed"
```

### 3.3 Storage Bucket Testing (`fuzz_storage`)

Storage testing focuses on object listing and upload capabilities:

#### Directory Enumeration
```python
# Test common storage prefixes
prefixes = ["", "users/", "images/", "uploads/", "public/", "private/"]

for prefix in prefixes:
    encoded_prefix = urllib.parse.quote(prefix)
    url = f"https://firebasestorage.googleapis.com/v0/b/{STORAGE_BUCKET}/o"
    url += f"?maxResults=10&delimiter=/&prefix={encoded_prefix}"
    
    response = http_request(url)
    if response.status == 200:
        accessible_prefixes.append(prefix or "root")
```

#### Upload Testing
```python
# Test file upload without authentication
if accessible_prefixes:
    test_filename = f"probes/test-{int(time.time())}.txt"
    encoded_name = urllib.parse.quote(test_filename, safe="")
    upload_url = f"https://firebasestorage.googleapis.com/v0/b/{STORAGE_BUCKET}/o"
    upload_url += f"?uploadType=media&name={encoded_name}"
    
    response = http_request(upload_url, 
                           method="POST", 
                           body="f3tcher test file - safe to delete",
                           headers={"Content-Type": "text/plain"})
    
    if response.status == 200:
        # Parse response to get object name for cleanup
        data = json.loads(response.snippet)
        object_name = data.get("name", "")
        if object_name:
            delete_url = f"https://firebasestorage.googleapis.com/v0/b/{STORAGE_BUCKET}/o/{urllib.parse.quote(object_name, safe='')}"
            http_request(delete_url, method="DELETE")
        
        return "CRITICAL: Public upload access detected"
```

### 3.4 Cloud Functions Testing (`fuzz_functions`)

Functions testing performs systematic endpoint discovery:

#### Regional Endpoint Testing
```python
# Test all Google Cloud regions
regions = ["us-central1", "us-east1", "us-east4", "us-west1", "us-west2", 
           "us-west3", "us-west4", "europe-west1", "europe-west2", 
           "europe-west3", "europe-central2", "asia-northeast1", 
           "asia-northeast2", "asia-east2", "asia-southeast1", 
           "asia-southeast2", "australia-southeast1", "southamerica-east1"]

functions = ["api", "status", "v1"]  # Common function names

for region in regions:
    for function_name in functions:
        url = f"https://{region}-{PROJECT_ID}.cloudfunctions.net/{function_name}"
        
        # Test GET request
        response = http_request(url)
        if response.status == 200:
            discovered.append(f"{region}->{function_name}")
        elif response.status == 405:  # Method not allowed
            # Try POST request
            post_response = http_request(url, method="POST", 
                                       body="{}", 
                                       headers={"Content-Type": "application/json"})
            if post_response.status == 200:
                discovered.append(f"{region}->{function_name} (POST)")
```

### 3.5 Firebase Hosting Testing (`fuzz_hosting`)

Hosting tests check for accessible web applications:

```python
# Test both hosting domains
hosting_urls = [
    f"https://{PROJECT_ID}.web.app/",
    f"https://{PROJECT_ID}.firebaseapp.com/"
]

for url in hosting_urls:
    response = http_request(url)
    if response.status == 200:
        # Also check for Firebase initialization config
        init_response = http_request(url + "__/firebase/init.json")
        # This can reveal additional configuration
```

## Phase 4: Authentication & Escalation Testing

### 4.1 Token Acquisition Strategy

Firehound attempts to obtain authentication tokens using two methods:

#### Anonymous Authentication
```python
def get_anonymous_token(api_key):
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={api_key}"
    payload = {"returnSecureToken": True}
    
    response = http_request(url, method="POST", 
                           body=json.dumps(payload),
                           headers={"Content-Type": "application/json"})
    
    if response.status == 200:
        data = json.loads(response.snippet)
        return data.get("idToken")  # JWT token for authenticated requests
```

#### Email/Password Authentication
```python
def get_email_token(api_key):
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={api_key}"
    email = f"probe+{int(time.time())}@example.com"  # Unique test email
    payload = {
        "returnSecureToken": True,
        "email": email,
        "password": "testpassword123"
    }
    
    response = http_request(url, method="POST", 
                           body=json.dumps(payload),
                           headers={"Content-Type": "application/json"})
    
    if response.status == 200:
        data = json.loads(response.snippet)
        return data.get("idToken")
```

### 4.2 Authenticated Testing Phase

If authentication succeeds, Firehound re-tests all services with the token:

#### Authenticated Realtime Database Testing
```python
def fuzz_rtdb_auth(cfg, token, wl):
    # Test the same paths but with authentication
    for root in rtdb_roots:
        url = f"{DATABASE_URL}/{root}/.json?shallow=true&limitToFirst=1&auth={token}"
        response = http_request(url)
        # Determines if "auth != null" rules are too permissive
```

#### Authenticated Firestore Testing
```python
def fuzz_firestore_auth(cfg, token, wl):
    headers = {"Authorization": f"Bearer {token}"}
    # Re-test collections with Bearer token
    # Identifies overly broad "auth != null" rules
```

#### Authenticated Storage Testing
```python
def fuzz_storage_auth(cfg, token):
    headers = {"Authorization": f"Bearer {token}"}
    # Test storage access with authentication
    # Reveals if any authenticated user can access all data
```

## Phase 5: Vulnerability Classification System

### Classification Logic

Firehound uses a sophisticated classification system in the `classify()` function:

```python
def classify(url, status, method):
    # Service identification by URL patterns
    if "firebasedatabase.app" in url or "firebaseio.com" in url:
        if status in (200, 201):
            if "_probes" in url:
                return "Realtime DB", "CRITICAL: Public write access detected"
            else:
                return "Realtime DB", "OPEN: Public read access detected"
        return "Realtime DB", f"Status: {status}"
    
    if "firestore.googleapis" in url:
        if status in (200, 201):
            return "Firestore", "OPEN: Collection accessible without auth"
        return "Firestore", f"Status: {status}"
    
    if "firebasestorage" in url:
        if status in (200, 201):
            if "uploadType=media" in url:
                return "Storage", "CRITICAL: Public write access detected"
            else:
                return "Storage", "OPEN: Public list access detected"
        return "Storage", f"Status: {status}"
```

### Severity Levels

**CRITICAL Vulnerabilities:**
- Public write access to any service
- Security rules publicly readable
- Admin endpoints accessible

**OPEN Vulnerabilities:**
- Public read access to data
- Directory listing enabled
- Unauthenticated function access

**CLOSED (Secure):**
- Proper authentication required
- Access denied responses (401, 403)

## Phase 6: Evidence Collection & Logging

### Multi-Layer Logging System

Firehound implements comprehensive logging at multiple levels:

#### 1. Terminal Output (User-Friendly)
```python
# Condensed, colorized status messages
vprint("200 | GET | realtime-db | quitvaping-8cfeb | shallow=true", GREY)
vprint("Download complete | OK | app.ipa", GREEN)
vprint("CRITICAL: Public write access detected", RED)
```

#### 2. Detailed File Logging
```python
# Complete operation logging
log_detailed("HTTP_REQUEST: GET https://firestore.googleapis.com/v1/...", "DEBUG")
log_detailed("HTTP_HEADERS: {'User-Agent': 'f3tcher/1.1', ...}", "DEBUG")
log_detailed("HTTP_RESPONSE: 200 in 0.43s, 1024 bytes", "DEBUG")
log_detailed("HTTP_SNIPPET: {\"error\": \"Permission denied\"}", "DEBUG")
```

#### 3. Evidence Collection
```python
# Each HTTP request generates evidence
evidence_entry = {
    "url": "https://firestore.googleapis.com/v1/projects/...",
    "method": "POST",
    "status": 200,
    "snippet": "{\"readTime\": \"2025-08-22T15:05:04.036867Z\"}",
    "evidence": "Successful access",
    "service": "Firestore",
    "vuln": "OPEN: Collection accessible without auth"
}
```

## Phase 7: Vulnerability Report Generation

### Report Structure

Firehound generates structured JSON reports with complete vulnerability details:

```json
{
  "appName": "Quit Vaping",
  "bundleId": "com.jonathankopp.quitvaping",
  "vulnerabilities": [
    {
      "service": "Firestore",
      "method": "PATCH",
      "url": "https://firestore.googleapis.com/v1/projects/quitvaping-8cfeb/databases/(default)/documents/f3tcher_probes/probe-1755875104?key=AIzaSyC-qKpFx1mL_I--rpzWjdWScPItg-OjhEw",
      "details": "OPEN: Collection accessible without auth",
      "preview": "{\n  \"name\": \"projects/quitvaping-8cfeb/databases/(default)/documents/f3tcher_probes/probe-1755875104\",\n  \"fields\": {\n    \"timestamp\": {\n      \"integerValue\": \"1755875104\"\n    },\n    \"probe\": {\n      \"stringValue\": \"true\"\n    }\n  },\n  \"createTime\": \"2025-08-22T15:05:05.330819Z\",\n  \"updateTime\": \"2025-08-22T15:05:05.330819Z\"\n}\n",
      "status": 200
    }
  ]
}
```

### Vulnerability Deduplication

```python
def build_vulnerabilities(all_evidence):
    vulnerabilities = []
    seen = set()
    
    for entry in all_evidence:
        # Only include successful access attempts
        if entry.status in (200, 201, 204):
            key = (entry.service, entry.method, entry.url)
            if key not in seen:
                seen.add(key)
                vulnerabilities.append(entry)
    
    return sorted(vulnerabilities)
```

## Real-World Example: Quit Vaping App Analysis

### Configuration Discovered
From the log analysis, the Quit Vaping app revealed:

```python
{
    "PROJECT_ID": "quitvaping-8cfeb",
    "DATABASE_URL": "https://quitvaping-8cfeb.firebaseio.com",
    "STORAGE_BUCKET": "quitvaping-8cfeb.appspot.com",
    "API_KEY": "AIzaSyC-qKpFx1mL_I--rpzWjdWScPItg-OjhEw"
}
```

### Vulnerabilities Found

#### 1. Realtime Database Exposure
- **Public read access** to `/users/` path
- **Public read access** to `/admin/` path containing `{"superusers": true}`
- **No write access** (properly secured)

#### 2. Firestore Misconfigurations
- **Public document creation** in any collection
- **Public query access** via REST API
- **Successful authentication** with email/password signup

#### 3. Storage Bucket Issues
- **Public listing** of all storage prefixes
- **Public file upload** capability
- **9 exposed files** including logos and assets

### Security Impact Assessment

**Critical Issues (Immediate Risk):**
- Storage bucket allows public file uploads → Data pollution, malware hosting
- Firestore allows document creation → Data manipulation, spam injection

**High Issues (Data Exposure):**
- Realtime Database `/admin/` path exposed → Admin user identification
- Realtime Database `/users/` path exposed → User enumeration
- Storage bucket listing enabled → Asset enumeration

**Medium Issues (Information Disclosure):**
- Email/password authentication enabled → Account creation possible
- Multiple service endpoints discoverable → Attack surface mapping

## Advanced Technical Details

### HTTP Request Flow

Every HTTP request follows this pattern:

```python
# Request lifecycle
1. Log request details (URL, method, headers, body)
2. Execute request with timeout and retries
3. Log response (status, duration, size, snippet)
4. Classify service and vulnerability
5. Store evidence for reporting
6. Display condensed terminal output
```

### Error Handling Strategy

```python
# Retry logic for network requests
for attempt in range(MAX_RETRIES + 1):
    try:
        response = urllib.request.urlopen(request, timeout=HTTP_TIMEOUT)
        # Success path
    except urllib.error.HTTPError as e:
        # HTTP error (400, 401, 403, 404, etc.) - still valuable data
        return process_http_error(e)
    except Exception as e:
        # Network/timeout error - retry with exponential backoff
        if attempt < MAX_RETRIES:
            time.sleep(2 ** attempt)  # 1s, 2s, 4s delays
            continue
        return failure_response(e)
```

### Security Considerations

#### Responsible Testing
- **Read-only probes** when possible
- **Immediate cleanup** of test data
- **Non-destructive testing** methods
- **Minimal data footprint**

#### Authentication Safety
- **Temporary accounts** for testing (`probe+timestamp@example.com`)
- **No persistent authentication**
- **Token cleanup** after testing
- **Masked logging** of sensitive data

## Performance Characteristics

### Network Efficiency
- **Concurrent testing** of different services
- **Intelligent retry logic** with exponential backoff
- **Request deduplication** to avoid redundant tests
- **Timeout management** to prevent hanging

### Resource Management
- **IPA cleanup** after extraction (saves disk space)
- **Optional plist retention** via `KEEP_PLISTS` environment variable
- **Automatic directory cleanup** for apps with no findings
- **Memory-efficient** streaming of large responses

## Integration Points

### Command Line Interface
```bash
# Multiple input methods supported
python3 test.py --search "banking"                    # Search App Store
python3 test.py --ids-file bundles.txt               # Batch processing
python3 test.py --bundle-id com.example.app          # Single app
python3 test.py --directory /path/to/extracted/app   # Pre-extracted app
```

### Environment Configuration
```bash
# Performance tuning
export VERBOSE=1           # Enable detailed terminal output
export RESCAN=1           # Force re-analysis of existing reports
export KEEP_PLISTS=1      # Retain configuration files
export NO_COLOR=1         # Disable colored output
```

### Output Structure
```
/output/directory/
├── logs/
│   └── firehound_scan_20250822_150448.log    # Detailed execution log
├── com.example.app/
│   ├── Info.plist                            # App metadata
│   ├── GoogleService-Info.plist              # Firebase config
│   └── App Name__com.example.app_audit.json  # Vulnerability report
└── scan_index.json                           # Scan summary
```

## Conclusion

Firehound represents a sophisticated approach to automated Firebase security testing. Its strength lies in:

1. **Comprehensive Coverage**: Tests all major Firebase services systematically
2. **Intelligent Discovery**: Uses real iOS app configurations for realistic testing
3. **Evidence-Based Reporting**: Provides complete proof of vulnerabilities
4. **Responsible Testing**: Minimizes impact while maximizing coverage
5. **Detailed Logging**: Enables deep analysis and debugging

The tool's architecture allows security researchers to quickly identify Firebase misconfigurations at scale while maintaining detailed audit trails for compliance and further analysis.

Understanding this architecture enables users to:
- **Customize testing strategies** for specific environments
- **Interpret results accurately** with full context
- **Extend functionality** for additional security checks
- **Integrate with other tools** in security workflows

This deep understanding transforms Firehound from a black box tool into a transparent, extensible security testing platform.
