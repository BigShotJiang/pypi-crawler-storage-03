"""ZerisFetch - A neofetch-like system information tool"""
__version__ = "1.0.0"
__author__ = "Zeris"
__email__ = "Zerisfetch@gmail.com"
