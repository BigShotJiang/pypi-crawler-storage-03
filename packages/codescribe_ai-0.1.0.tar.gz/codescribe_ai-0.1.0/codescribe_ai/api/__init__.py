from flask import Blueprint

api = Blueprint("api", __name__)

from api import routes  # registers routes
