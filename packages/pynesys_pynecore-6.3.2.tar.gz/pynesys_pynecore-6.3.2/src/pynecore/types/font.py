from ..types.base import IntEnum


class FontFamilyEnum(IntEnum):
    ...
