from ..types.base import IntEnum


class Currency(IntEnum):
    ...
