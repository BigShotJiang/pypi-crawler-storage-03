from .base import IntEnum


class Size(IntEnum):
    ...
