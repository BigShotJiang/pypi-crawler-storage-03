from .base import IntEnum


class Position(IntEnum):
    ...