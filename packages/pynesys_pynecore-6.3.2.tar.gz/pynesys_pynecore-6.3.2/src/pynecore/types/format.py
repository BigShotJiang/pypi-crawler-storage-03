from ..types.base import StrLiteral


class Format(StrLiteral):
    ...
