from .base import IntEnum


class AlertEnum(IntEnum):
    ...
