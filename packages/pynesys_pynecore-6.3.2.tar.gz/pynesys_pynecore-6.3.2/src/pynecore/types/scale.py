from ..types.base import IntEnum


class Scale(IntEnum):
    ...
