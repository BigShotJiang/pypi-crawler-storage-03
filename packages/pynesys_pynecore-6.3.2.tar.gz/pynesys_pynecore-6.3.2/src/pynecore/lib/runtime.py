def error(message: str):
    """
    Stop running script with an error message
    """
    raise RuntimeError(message)
