from ...types.strategy import Oca

#
# Constants
#

cancel = Oca("cancel")
reduce = Oca("reduce")
none = Oca("none")
