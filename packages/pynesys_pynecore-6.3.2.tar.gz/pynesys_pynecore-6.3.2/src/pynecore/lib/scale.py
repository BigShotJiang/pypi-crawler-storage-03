from ..types.scale import Scale

#
# Constants
#

left = Scale()
none = Scale()
right = Scale()
