"""fnb — Fetch'n'Backup

A two-step backup tool powered by rsync.
"""

__version__ = "0.10.0"
