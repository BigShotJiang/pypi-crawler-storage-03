from gen_epix.common.domain.policy.permission import (
    NO_RBAC_PERMISSIONS as NO_RBAC_PERMISSIONS,
)
from gen_epix.common.domain.policy.rbac import (
    BaseIsPermissionSubsetNewRolePolicy as BaseIsPermissionSubsetNewRolePolicy,
)
from gen_epix.common.domain.policy.system import (
    BaseHasSystemOutagePolicy as BaseHasSystemOutagePolicy,
)
