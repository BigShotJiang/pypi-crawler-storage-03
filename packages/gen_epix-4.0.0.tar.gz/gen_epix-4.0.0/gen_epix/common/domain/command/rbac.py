from gen_epix.common.domain.command.base import Command

# Non-CRUD commands


class RetrieveOwnPermissionsCommand(Command):
    pass


# CRUD commands
