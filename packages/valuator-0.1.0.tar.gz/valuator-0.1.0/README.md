Valuator
A lightweight Python library to fetch AI model pricing data and perform searches to retrieve input and output costs per token for matching models.
Installation
pip install valuator

Usage
import asyncio
from valuator import Valuator

async def main():
    valuator = Valuator()
    try:
        # Search with regex pattern
        costs = valuator.get_model_costs("claude.*haiku")
        print(costs)

        # Search with partial name
        costs = valuator.get_model_costs("gpt-4")
        print(costs)
    finally:
        await valuator.close()

asyncio.run(main())

Features

Fetches model pricing data from a specified URL or local cache.
Performs regex-based searches on model names for flexible matching.
Returns only input_cost_per_token and output_cost_per_token for matched models.
Optimized for low memory usage with efficient data structures (sets, cached regex).
Asynchronous HTTP requests for fast data retrieval.

Requirements

Python 3.8+
aiohttp

License
MIT License