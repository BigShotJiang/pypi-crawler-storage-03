def main(argv):
    if argv:
        print(f"Arguments received by test_addon: {argv}")
    else:
        print("No arguments received by test_addon.")