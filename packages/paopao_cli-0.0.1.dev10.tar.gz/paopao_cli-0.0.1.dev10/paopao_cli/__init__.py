class ppc_core:
    def get_version():
        return "0.0.1.dev10"