#!/usr/bin/env python3
"""
Minigun package entry point.
"""

from minigun.cli import main

if __name__ == "__main__":
    main()
