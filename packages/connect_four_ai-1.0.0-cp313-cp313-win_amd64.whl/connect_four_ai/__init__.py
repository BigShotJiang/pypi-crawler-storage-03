from .connect_four_ai import *

__doc__ = connect_four_ai.__doc__
if hasattr(connect_four_ai, "__all__"):
    __all__ = connect_four_ai.__all__