# 客户端运行指南

## 配置开发环境

创建一个 python 虚拟环境（python 版本>3.9）

```shell
  uv sync
```
