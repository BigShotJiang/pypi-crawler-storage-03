#ifndef _9_H
#define _9_H

// Test CodeLOC.
typedef struct {
    char *name;
} Test;

#endif
