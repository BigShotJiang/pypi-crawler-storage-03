# Test LocCount is working

 echo $SHELL
 