/* 
* Test CodeLoc
*/

Console.WriteLine("Hello Sephera Project!");
