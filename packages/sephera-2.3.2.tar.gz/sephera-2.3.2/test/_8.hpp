#ifndef _8_HPP
#define _8_HPP
/* Test CodeLoc */

namespace TestCodeLoc {
    class Test {
        public:
            int Sephera = 1;
    };
}

#endif
