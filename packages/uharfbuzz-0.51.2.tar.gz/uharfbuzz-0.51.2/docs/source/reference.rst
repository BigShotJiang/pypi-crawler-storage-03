API Reference
=============

.. automodule:: uharfbuzz
    :members:
    :undoc-members:
    :show-inheritance: