# pytest_rmysql
## description
### This is a plugin which is able to connet MySQL easyly.
### However, this project is not done yet :)