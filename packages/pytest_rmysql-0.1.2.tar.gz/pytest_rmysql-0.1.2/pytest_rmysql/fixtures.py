import pymysql
import pytest

from pytest_rmysql.config import parse_config



