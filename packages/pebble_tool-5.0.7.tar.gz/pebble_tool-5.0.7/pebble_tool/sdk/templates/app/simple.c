#include <pebble.h>

int main(void) {
  app_event_loop();
}
