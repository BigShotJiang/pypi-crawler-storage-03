from __future__ import annotations
from hypothesis_jsonschema import from_schema
from typing import TYPE_CHECKING, Sequence, Any
from pathlib import Path

from adaptive_sdk.graphql_client.fragments import JobData
from adaptive_sdk.graphql_client.input_types import JobInput

from .base_resource import SyncAPIResource, AsyncAPIResource, UseCaseResource
from adaptive_sdk.graphql_client import (
    CustomRecipeData,
    CustomRecipeFilterInput,
    CreateRecipeInput,
    UpdateRecipeInput,
    LabelInput,
    Upload,
)

if TYPE_CHECKING:
    from adaptive_sdk.client import Adaptive, AsyncAdaptive
import mimetypes


def _count_keys_recursively(data: Any) -> int:
    """Recursively counts the total number of keys in dictionaries within the data."""
    count = 0
    if isinstance(data, dict):
        count += len(data)
        for value in data.values():
            count += _count_keys_recursively(value)
    elif isinstance(data, list):
        for item in data:
            count += _count_keys_recursively(item)
    return count


class Recipes(SyncAPIResource, UseCaseResource):  # type: ignore[misc]
    """
    Resource to interact with custom scripts.
    """

    def __init__(self, client: Adaptive) -> None:
        SyncAPIResource.__init__(self, client)
        UseCaseResource.__init__(self, client)

    def list(self, use_case: str | None = None) -> Sequence[CustomRecipeData]:
        filter = CustomRecipeFilterInput()
        return self._gql_client.list_custom_recipes(use_case=self.use_case_key(use_case), filter=filter).custom_recipes

    def upload(
        self,
        file_path: str,
        recipe_key: str,
        name: str | None = None,
        description: str | None = None,
        labels: dict[str, str] | None = None,
        use_case: str | None = None,
    ) -> CustomRecipeData:
        filename = Path(file_path).stem
        label_inputs = [LabelInput(key=k, value=v) for k, v in labels.items()] if labels else None
        input = CreateRecipeInput(
            key=recipe_key,
            name=name or filename,
            description=description,
            labels=label_inputs,
        )
        content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
        with open(file_path, "rb") as f:
            file_upload = Upload(filename=filename, content=f, content_type=content_type)
            return self._gql_client.create_custom_recipe(
                use_case=self.use_case_key(use_case), input=input, file=file_upload
            ).create_custom_recipe

    def run(
        self,
        recipe_key: str,
        num_gpus: int,
        input_args: dict | None = None,
        name: str | None = None,
        use_case: str | None = None,
        compute_pool: str | None = None,
    ) -> JobData:
        input = JobInput(
            recipe=recipe_key,
            useCase=self.use_case_key(use_case),
            args=input_args or {},
            name=name,
            computePool=compute_pool,
            numGpus=num_gpus,
        )
        return self._gql_client.create_job(input).create_job

    def get(
        self,
        recipe_key: str,
        use_case: str | None = None,
    ) -> CustomRecipeData:
        return self._gql_client.get_custom_recipe(
            id_or_key=recipe_key, use_case=self.use_case_key(use_case)
        ).custom_recipe

    def update(
        self,
        recipe_key: str,
        file_path: str | None = None,
        name: str | None = None,
        description: str | None = None,
        labels: Sequence[tuple[str, str]] | None = None,
        use_case: str | None = None,
    ) -> CustomRecipeData:
        label_inputs = [LabelInput(key=k, value=v) for k, v in labels] if labels else None
        input = UpdateRecipeInput(
            name=name,
            description=description,
            labels=label_inputs,
        )

        file_upload = None
        if file_path:
            filename = Path(file_path).stem
            content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
            with open(file_path, "rb") as f:
                file_upload = Upload(filename=filename, content=f, content_type=content_type)

        return self._gql_client.update_custom_recipe(
            use_case=self.use_case_key(use_case),
            id=recipe_key,
            input=input,
            file=file_upload,
        ).update_custom_recipe

    def delete(
        self,
        recipe_key: str,
        use_case: str | None = None,
    ) -> bool:
        return self._gql_client.delete_custom_recipe(
            use_case=self.use_case_key(use_case), id=recipe_key
        ).delete_custom_recipe

    def generate_sample_input(self, recipe_key: str, use_case: str | None = None) -> dict:
        recipe_details = self.get(recipe_key=recipe_key, use_case=self.use_case_key(use_case))
        strategy = from_schema(recipe_details.json_schema)

        best_example = None
        max_key_count = -1

        for _ in range(10):
            try:
                example = strategy.example()
                current_key_count = _count_keys_recursively(example)

                if current_key_count > max_key_count:
                    max_key_count = current_key_count
                    best_example = example
            except Exception as e:
                print(f"Warning: Failed to generate an example due to: {e}")
                # Continue to next iteration even if one example fails

        if best_example is None:
            print("A valid sample could not be generated. Returning an empty dict.")
            best_example = {}
        return dict(best_example)  # type: ignore


class AsyncRecipes(AsyncAPIResource, UseCaseResource):  # type: ignore[misc]
    """
    Resource to interact with custom scripts.
    """

    def __init__(self, client: AsyncAdaptive) -> None:
        AsyncAPIResource.__init__(self, client)
        UseCaseResource.__init__(self, client)

    async def list(self, use_case: str | None = None) -> Sequence[CustomRecipeData]:
        filter = CustomRecipeFilterInput()
        return (
            await self._gql_client.list_custom_recipes(use_case=self.use_case_key(use_case), filter=filter)
        ).custom_recipes

    async def upload(
        self,
        file_path: str,
        recipe_key: str,
        name: str | None = None,
        description: str | None = None,
        labels: Sequence[tuple[str, str]] | None = None,
        use_case: str | None = None,
    ) -> CustomRecipeData:
        filename = Path(file_path).stem
        label_inputs = [LabelInput(key=k, value=v) for k, v in labels] if labels else None
        input = CreateRecipeInput(
            key=recipe_key,
            name=name or filename,
            description=description,
            labels=label_inputs,
        )
        content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
        with open(file_path, "rb") as f:
            file_upload = Upload(filename=filename, content=f, content_type=content_type)
            return (
                await self._gql_client.create_custom_recipe(
                    use_case=self.use_case_key(use_case), input=input, file=file_upload
                )
            ).create_custom_recipe

    async def run(
        self,
        recipe_key: str,
        num_gpus: int,
        input_args: dict | None = None,
        name: str | None = None,
        use_case: str | None = None,
        compute_pool: str | None = None,
    ) -> JobData:
        input = JobInput(
            recipe=recipe_key,
            useCase=self.use_case_key(use_case),
            args=input_args,
            name=name,
            computePool=compute_pool,
            numGpus=num_gpus,
        )
        return (await self._gql_client.create_job(input)).create_job

    async def get(
        self,
        recipe_key: str,
        use_case: str | None = None,
    ) -> CustomRecipeData:
        return (
            await self._gql_client.get_custom_recipe(id_or_key=recipe_key, use_case=self.use_case_key(use_case))
        ).custom_recipe

    async def update(
        self,
        recipe_key: str,
        file_path: str | None = None,
        name: str | None = None,
        description: str | None = None,
        labels: Sequence[tuple[str, str]] | None = None,
        use_case: str | None = None,
    ) -> CustomRecipeData:
        label_inputs = [LabelInput(key=k, value=v) for k, v in labels] if labels else None
        input = UpdateRecipeInput(
            name=name,
            description=description,
            labels=label_inputs,
        )

        file_upload = None
        if file_path:
            filename = Path(file_path).stem
            content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
            with open(file_path, "rb") as f:
                file_upload = Upload(filename=filename, content=f, content_type=content_type)

        return (
            await self._gql_client.update_custom_recipe(
                use_case=self.use_case_key(use_case),
                id=recipe_key,
                input=input,
                file=file_upload,
            )
        ).update_custom_recipe

    async def delete(
        self,
        recipe_key: str,
        use_case: str | None = None,
    ) -> bool:
        return (
            await self._gql_client.delete_custom_recipe(use_case=self.use_case_key(use_case), id=recipe_key)
        ).delete_custom_recipe

    async def generate_sample_input(self, recipe_key: str, use_case: str | None = None) -> dict:
        recipe_details = await self.get(recipe_key=recipe_key, use_case=self.use_case_key(use_case))
        strategy = from_schema(recipe_details.json_schema)

        best_example = None
        max_key_count = -1

        for _ in range(10):
            try:
                example = strategy.example()
                current_key_count = _count_keys_recursively(example)

                if current_key_count > max_key_count:
                    max_key_count = current_key_count
                    best_example = example
            except Exception as e:
                print(f"Warning: Failed to generate an example due to: {e}")
                # Continue to next iteration even if one example fails

        if best_example is None:
            print("A valid sample could not be generated. Returning an empty dict.")
            best_example = {}
        return dict(best_example)  # type: ignore
