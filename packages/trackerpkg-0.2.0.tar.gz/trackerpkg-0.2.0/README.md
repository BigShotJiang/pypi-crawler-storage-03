# yourpkg

TokenTracker and resource tracking decorators to monitor OpenAI API usage and process resource consumption, with logging to PostgreSQL.

## Installation

```bash
pip install yourpkg
