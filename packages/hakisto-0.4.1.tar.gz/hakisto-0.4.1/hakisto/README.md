# hakisto_ Python sources

This (sub-)module contains the Python only. To get the whole project use

```
git clone --recurse-submodules git@gitlab.com:hakisto/hakisto.git
```

