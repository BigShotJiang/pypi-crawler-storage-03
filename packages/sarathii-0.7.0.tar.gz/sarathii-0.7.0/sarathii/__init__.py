from .main import full_name
from .main import dob
from .main import degree
from .main import age
from .main import fan