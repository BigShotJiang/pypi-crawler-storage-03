from datetime import date
def age():

    # Enter your birth year
    birth_year = 2004  # change this to your year of        birth

    # Get the current year
    current_year = date.today().year

    # Calculate age
    age = current_year - birth_year

    print(f"AGE : {age}")
    

def full_name():
	print("NAME : VIJAYASARATHI.A")
def dob():
	print("DOB : 02/MAY/2004")
def degree():
	print("DEGREE : B.TECH-AI&DS")
def fan():
	print("FAN : THALAPATHI VIJAY")
