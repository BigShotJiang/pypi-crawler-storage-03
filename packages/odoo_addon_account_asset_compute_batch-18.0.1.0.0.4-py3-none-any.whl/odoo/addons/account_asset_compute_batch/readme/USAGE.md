There are 2 ways to create "Compute Asset Batch"

1.  On the Compute Assets wizards, choose "Create Batch" option,  
    1.1 Type in batch name and description. 1.2 Select asset profiles,
    to limit only some profiles to get computed. 1.3 Option to "Delay
    Compute Asset", will only create Batch record for user to execute it
    later.

2.  Create Compute Asset Batch directly  
    2.1 Select date for depreciation 2.2 Type in batch name and
    descripton 2.3 Select asset profiles, to limit only some profiles to
    get computed. 2.4 Option to "Auto Compute" if you want to compute
    this batch by cron job. 2.4 Option to "Delay Post" if you want to
    post journal entry by cron job. 2.5 Click "Compute" button to
    compute asset.
