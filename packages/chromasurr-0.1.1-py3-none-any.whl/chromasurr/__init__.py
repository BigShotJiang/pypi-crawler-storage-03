# src/chromasurr/__init__.py

from importlib.metadata import version

__version__ = version("chromasurr")


# core functions
# from chromasurr. import
# from chromasurr. import
