try:
    from ._version import __version__
except ImportError:
    pass
