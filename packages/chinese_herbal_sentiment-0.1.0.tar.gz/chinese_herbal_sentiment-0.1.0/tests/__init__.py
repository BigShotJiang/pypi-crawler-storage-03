"""
Test suite for Chinese Herbal Medicine Sentiment Analysis System.
"""
