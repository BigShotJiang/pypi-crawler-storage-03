#!/usr/bin/python

import setuptools

with open("README.md", "r") as fh:
    LONG_DESCRIPTION = fh.read()

KEYWORDS = ('public ip dns http google akamai opendns cloudflare')

setuptools.setup(
    name="publicaddr",
    version="0.18.0",
    author="Denis MACHARD",
    author_email="d.machard@gmail.com",
    description="Getting your public IP v4 and v6",
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    url="https://github.com/dmachard/python-publicaddr",
    packages=['publicaddr', 'tests'],
    include_package_data=True,
    platforms='any',
    keywords=KEYWORDS,
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
    ],
    install_requires=[
        "requests",
        "dnspython",
        "pyyaml",
        "aiostun",
        "checkifvalid",
    ]
)