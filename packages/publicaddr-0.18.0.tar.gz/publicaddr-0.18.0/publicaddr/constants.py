# Use IPv4 or IPv6 protocols to reach the provider
IPv4=4
IPv6=6

# Providers by type
ALL = "all"
DNS = "dns"
HTTPS = "https"
STUN = "stun"
