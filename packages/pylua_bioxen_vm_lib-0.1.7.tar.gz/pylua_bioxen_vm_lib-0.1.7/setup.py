#!/usr/bin/env python3
"""
Minimal setup.py for pylua_bioxen_vm_lib.
All configuration is in setup.cfg.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()