__version__ = "3.7.2"
dependencies = ["falcon==4.0.2",
                "portalocker==2.10.1",
                "huckle>=5.5.6,<6.0.0",
                "hcli_problem_details>=0.2.0,<1.0.0"]
