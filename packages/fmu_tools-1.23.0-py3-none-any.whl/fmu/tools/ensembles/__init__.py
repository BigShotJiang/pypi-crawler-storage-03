"""For analysis/checks across ensembles."""

from fmu.tools.ensembles import ensemble_well_props

__all__ = [
    "ensemble_well_props",
]
