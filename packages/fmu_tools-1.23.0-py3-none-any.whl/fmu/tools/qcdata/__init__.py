from .qcdata import QCData

__all__ = [
    "QCData",
]
