from .sample_attributes import sample_attributes_for_sim2seis

__all__ = [
    "sample_attributes_for_sim2seis",
]
