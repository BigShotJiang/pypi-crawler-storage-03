<template>
  <view class="container">
    <view class="success-message">支付成功！</view>
  </view>
</template>

<script>
export default {
  // 你可以在这个页面添加更多的成功信息或操作按钮
};
</script>

<style scoped>
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f0f0f0;
}
.success-message {
  font-size: 24px;
  color: #1AAD19;
}
</style>
