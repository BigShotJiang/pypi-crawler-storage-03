def main():
    """

    Ensure YS binary is installed.

    """
    from fmtr.tools import yaml
    yaml.install()
