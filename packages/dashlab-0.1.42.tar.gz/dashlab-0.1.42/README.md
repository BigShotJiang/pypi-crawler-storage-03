This is going to replace einteract and should be minimal dependency package, 
such as ipython Markdown instead of ipyslides markdown and not having fancy formatting 
for random python objects, just str to Markdown and widgets only.
