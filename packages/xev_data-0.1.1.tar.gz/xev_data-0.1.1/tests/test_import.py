#!/usr/bin/env python3

######## Functions ########

def test_import():
    from xdata import Database

######## Main ########
def main():
    test_import()

######## Execution ########
if __name__ == "__main__":
    main()
