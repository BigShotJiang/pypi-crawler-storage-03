To use this module, you need to:

1.  Go to Invoicing \> Customers \> Customers Contracts and select or create a new
    contract.
2.  Check *Generate recurring invoices automatically*.
3.  Mark the check "Invoice Pending Sales Orders".
4.  On each invoicing, the system will check if there are any pending Sales
    Orders with the same Analytic Account on the lines and will append it to the
    invoice being generated.
