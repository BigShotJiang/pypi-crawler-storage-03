from setuptools import setup

setup(
    version="0.0.4",
    name="emzed-spyder-kernels",
    py_modules=["emzed_spyder_kernels"],
    install_requires=["spyder-kernels==2.5.2"],
    include_package_data=True,
)
