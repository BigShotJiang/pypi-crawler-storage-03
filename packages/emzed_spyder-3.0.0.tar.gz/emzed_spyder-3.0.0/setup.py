import sys

from setuptools import Extension, find_packages, setup

v = sys.version_info

install_requires = [line.strip() for line in open("requirements.txt")]

long_description = """
LCMS data analysis made easy

emzed is an open source toolbox for rapid and interactive development of LCMS data
analysis workflows in Python and makes experimenting with new analysis strategies for
LCMS data as easy as possible.
"""

# enforce binary wheel on windows
ext_modules = [Extension(name="module", sources=[])] if sys.platform == "win32" else []

setup(
    name="emzed-spyder",
    version="3.0.0",
    description="emzed IDE, see also https://emzed.ethz.ch",
    long_description=long_description,
    url="https://emzed.ethz.ch",
    author="Uwe Schmitt",
    author_email="uwe.schmitt@id.ethz.ch",
    license="MIT",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    zip_safe=False,
    python_requires=">= 3.10, < 3.13",
    install_requires=install_requires,
    entry_points={
        "console_scripts": ["emzed.spyder.debug = emzed_spyder.start:main"],
        "gui_scripts": ["emzed.spyder = emzed_spyder.start:main"],
    },
    include_package_data=True,
    # ext_modules=ext_modules,
)
