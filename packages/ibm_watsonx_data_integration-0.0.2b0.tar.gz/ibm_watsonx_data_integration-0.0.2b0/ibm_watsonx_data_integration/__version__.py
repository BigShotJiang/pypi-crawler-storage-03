#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"""This module is used to set the version of the package."""

__version__ = "0.0.2b"
