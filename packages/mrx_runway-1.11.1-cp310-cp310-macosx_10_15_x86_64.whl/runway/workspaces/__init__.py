from runway.workspaces.methods import get_joined_workspaces, set_joined_workspace

__all__ = [
    "get_joined_workspaces",
    "set_joined_workspace",
]
