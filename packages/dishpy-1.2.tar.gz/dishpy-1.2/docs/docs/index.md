{{ external_markdown('https://raw.githubusercontent.com/aadishv/dishpy/refs/heads/main/README.md', '') }}

[This page was mirrored from the README of our GitHub repository.]
