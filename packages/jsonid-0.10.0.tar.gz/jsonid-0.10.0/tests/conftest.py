"""Configure testing."""

from src.jsonid import jsonid

jsonid.init_logging(True)
