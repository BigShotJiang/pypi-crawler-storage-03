from __future__ import annotations

from ...tools.web_search import SearchResults, search, get_search_message