"""
Akshare MCP Server - 中国金融数据接口MCP服务器

提供中国股票、期货、基金等金融数据的MCP服务器。
Provides Chinese stock, futures, fund and other financial data via MCP server.
"""

__version__ = "0.1.0"
__author__ = "Akshare MCP Team"