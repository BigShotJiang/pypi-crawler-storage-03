# Expose classes to be imported from the package
from .widgets import FilteringWidget

__all__ = ["FilteringWidget"]
