# Expose classes to be imported from the package
from .widgets import PeakVisualizationWidget

__all__ = ["PeakVisualizationWidget"]
