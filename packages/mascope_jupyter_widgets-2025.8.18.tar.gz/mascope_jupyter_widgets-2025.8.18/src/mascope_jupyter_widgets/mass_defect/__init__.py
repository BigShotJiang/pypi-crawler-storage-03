# Expose classes to be imported from the package
from .widgets import MassDefectWidget

__all__ = ["MassDefectWidget"]
