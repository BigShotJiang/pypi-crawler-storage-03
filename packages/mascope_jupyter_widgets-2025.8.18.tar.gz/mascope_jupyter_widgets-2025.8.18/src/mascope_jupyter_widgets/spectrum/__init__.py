# Expose classes to be imported from the package
from .widgets import SpectrumWidget

__all__ = ["SpectrumWidget"]
