# Expose classes to be imported from the package
from .widgets import BinningWidget

__all__ = ["BinningWidget"]
