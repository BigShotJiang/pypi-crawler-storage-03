from .hierarchical_clustering import HierarchicalClusterer, ClusteringResult
from .tree_nodes import ClusterNode, NodeManager
from .distance_matrix import DistanceCalculator
from .docs_reordering import DocReorderer

__all__ = [
    'HierarchicalClusterer',
    'ClusteringResult', 
    'ClusterNode',
    'NodeManager',
    'DistanceCalculator',
    'DocReorderer'
]

def cluster_prompts(prompts, similarity_method="sharp", linkage_method="average", use_triton=True):
    """Convenience function for clustering prompts."""
    clusterer = HierarchicalClusterer(
        similarity_method=similarity_method,
        linkage_method=linkage_method,
        use_triton=use_triton
    )
    return clusterer.fit_transform(prompts)