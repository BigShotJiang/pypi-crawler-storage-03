from cumulusci.core.exceptions import CumulusCIException


class LastReleaseTagNotFoundError(CumulusCIException):
    pass
