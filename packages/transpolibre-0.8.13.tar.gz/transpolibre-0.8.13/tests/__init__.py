"""
TranspoLibre test suite.

This package contains all tests for the transpolibre translation tool.
"""
