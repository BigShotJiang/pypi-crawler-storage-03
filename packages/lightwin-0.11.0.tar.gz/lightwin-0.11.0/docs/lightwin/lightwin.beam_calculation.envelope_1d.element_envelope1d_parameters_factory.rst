element\_envelope1d\_parameters\_factory module
=======================================================================================

.. automodule:: lightwin.beam_calculation.envelope_1d.element_envelope1d_parameters_factory
   :members:
   :undoc-members:
   :show-inheritance:
