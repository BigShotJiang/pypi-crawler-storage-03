factory module
=============================================

.. automodule:: lightwin.core.beam_parameters.factory
   :members:
   :undoc-members:
   :show-inheritance:
