presets module
====================================================

.. automodule:: lightwin.evaluator.simulation_output.presets
   :members:
   :undoc-members:
   :show-inheritance:
