element\_parameters\_factory module
===============================================================================

.. automodule:: lightwin.beam_calculation.cy_envelope_1d.element_parameters_factory
   :members:
   :undoc-members:
   :show-inheritance:
