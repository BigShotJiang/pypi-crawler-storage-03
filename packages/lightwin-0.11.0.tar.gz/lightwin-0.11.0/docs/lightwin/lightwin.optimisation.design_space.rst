design\_space package
===========================================

.. automodule:: lightwin.optimisation.design_space
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.optimisation.design_space.constraint
   lightwin.optimisation.design_space.design_space
   lightwin.optimisation.design_space.design_space_parameter
   lightwin.optimisation.design_space.factory
   lightwin.optimisation.design_space.helper
   lightwin.optimisation.design_space.variable
