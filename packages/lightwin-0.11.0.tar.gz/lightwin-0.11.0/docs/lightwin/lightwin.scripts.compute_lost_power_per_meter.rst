compute\_lost\_power\_per\_meter module
========================================================

.. automodule:: lightwin.scripts.compute_lost_power_per_meter
   :members:
   :undoc-members:
   :show-inheritance:
