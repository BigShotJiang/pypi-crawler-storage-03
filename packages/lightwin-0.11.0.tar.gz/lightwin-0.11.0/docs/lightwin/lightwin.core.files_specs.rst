files\_specs module
=================================

.. automodule:: lightwin.core.files_specs
   :members:
   :undoc-members:
   :show-inheritance:
