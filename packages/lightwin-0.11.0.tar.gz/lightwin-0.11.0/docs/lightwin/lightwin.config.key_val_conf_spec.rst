key\_val\_conf\_spec module
===========================================

.. automodule:: lightwin.config.key_val_conf_spec
   :members:
   :undoc-members:
   :show-inheritance:
