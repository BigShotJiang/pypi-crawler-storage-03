specs module
===================================

.. automodule:: lightwin.visualization.specs
   :members:
   :undoc-members:
   :show-inheritance:
