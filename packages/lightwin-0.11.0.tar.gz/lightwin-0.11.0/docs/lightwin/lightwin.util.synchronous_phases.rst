synchronous\_phases module
========================================

.. automodule:: lightwin.util.synchronous_phases
   :members:
   :undoc-members:
   :show-inheritance:
