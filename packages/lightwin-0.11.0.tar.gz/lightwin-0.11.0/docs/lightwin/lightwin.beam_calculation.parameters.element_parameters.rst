element\_parameters module
================================================================

.. automodule:: lightwin.beam_calculation.parameters.element_parameters
   :members:
   :undoc-members:
   :show-inheritance:
