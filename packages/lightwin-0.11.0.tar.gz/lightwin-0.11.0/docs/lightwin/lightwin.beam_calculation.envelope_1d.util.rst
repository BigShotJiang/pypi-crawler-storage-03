util module
===================================================

.. automodule:: lightwin.beam_calculation.envelope_1d.util
   :members:
   :undoc-members:
   :show-inheritance:
