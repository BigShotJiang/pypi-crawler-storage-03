strategy module
=================================

.. automodule:: lightwin.failures.strategy
   :members:
   :undoc-members:
   :show-inheritance:
