config\_manager module
======================================

.. automodule:: lightwin.config.config_manager
   :members:
   :undoc-members:
   :show-inheritance:
