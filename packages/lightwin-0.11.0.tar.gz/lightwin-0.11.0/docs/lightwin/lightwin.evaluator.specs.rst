specs module
===============================

.. automodule:: lightwin.evaluator.specs
   :members:
   :undoc-members:
   :show-inheritance:
