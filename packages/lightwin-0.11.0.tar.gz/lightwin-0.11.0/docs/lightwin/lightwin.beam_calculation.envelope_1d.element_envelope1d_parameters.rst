element\_envelope1d\_parameters module
==============================================================================

.. automodule:: lightwin.beam_calculation.envelope_1d.element_envelope1d_parameters
   :members:
   :undoc-members:
   :show-inheritance:
