``plots`` section (mandatory)
*****************************
.. toctree::
   :maxdepth: 5

This section defines what quantities will be plotted at the end of the simulation.

.. csv-table::
   :file: configuration_entries/plots.csv
   :widths: 30, 5, 50, 10, 5
   :header-rows: 1

.. warning::
   Plot of transfer matrix currently not working.

