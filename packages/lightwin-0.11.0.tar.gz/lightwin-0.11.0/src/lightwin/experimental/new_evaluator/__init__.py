"""Define objects to easily evaluate the quality of settings."""
