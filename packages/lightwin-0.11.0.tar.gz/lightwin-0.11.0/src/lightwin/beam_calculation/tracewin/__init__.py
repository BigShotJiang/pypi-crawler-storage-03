"""
This subpackage holds all the modules for :class:`.TraceWin` beam calculator.

It is a 3d envelope or multiparticle calculator. It requires TraceWin to be
installed on your machine.

"""
