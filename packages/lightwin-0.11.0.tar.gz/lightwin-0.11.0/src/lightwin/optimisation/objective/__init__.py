"""We define the objects to parametrize the optimisation objectives."""
