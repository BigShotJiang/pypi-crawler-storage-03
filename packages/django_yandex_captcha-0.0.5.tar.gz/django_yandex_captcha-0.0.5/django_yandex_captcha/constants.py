DEFAULT_YANDEX_CAPTCHA_DOMAIN = "smartcaptcha.yandexcloud.net"
