class CleanTalkException(Exception):
    pass
