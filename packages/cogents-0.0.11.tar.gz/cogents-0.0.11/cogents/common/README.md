# cogents.common

We designed shared and independent modules for specific functionalities, ensuring each one is self-contained and can be composed in a flexible way.