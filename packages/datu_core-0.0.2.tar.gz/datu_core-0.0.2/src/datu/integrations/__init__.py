# create some base and factory class here
# every integration should have schema extraction
# profile builder should be there to work with dbt
