# python-taiga
# Copyright 2015 Nephila
# See LICENSE for details.

"""
Taiga Python API library
"""
__version__ = "1.3.3"
__author__ = "Nephila"
__license__ = "MIT"
__all__ = ["TaigaAPI"]

from .client import TaigaAPI
