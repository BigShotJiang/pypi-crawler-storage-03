# This file moved to aicodeprep_gui/pro/multi_state_level_delegate.py as part of Pro features.
# Keeping a stub here to help developers find the new location if imported accidentally.
raise ImportError(
    "MultiStateLevelDelegate has moved to aicodeprep_gui/pro/multi_state_level_delegate.py")
