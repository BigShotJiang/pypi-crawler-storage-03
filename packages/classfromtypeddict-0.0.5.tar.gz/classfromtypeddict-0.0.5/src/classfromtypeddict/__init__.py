from .classfromtypeddict import ClassFromTypedDict

__all__ = ["ClassFromTypedDict"]
