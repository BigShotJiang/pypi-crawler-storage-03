# View Collections
## Output Format
LIST

___

# Don't Create Collection
## Name
A generic collection
## Description
This is a generic collection

___

#  Don't Create Data Sharing 
## Name
Leak to fox

## Description
Leak sensitive personal data only to the conservative media.

## Status
PROPOSED

___

# Don't View Data Sharing Agreements
## Output Format
LIST

___

# Don't View Data Sharing Agreements
## Output Format
REPORT
___
#  View Collections
## Output Format
LIST
