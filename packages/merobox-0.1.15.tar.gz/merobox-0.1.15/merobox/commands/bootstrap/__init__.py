"""
Bootstrap module - Workflow orchestration and execution.
"""

from merobox.commands.bootstrap.bootstrap import bootstrap

__all__ = ["bootstrap"]
