"""
General Python tools used by several EduLinq projects.
"""

__version__ = '0.0.5'
