# Django User Status

A simple Django package to track and display a user's online/offline status and last seen time using Django's caching framework.

## Installation

1. Install the package:
   `pip install django-user-status`

2. Add the middleware to your `settings.py`:
   ```python
   MIDDLEWARE = [
       # ... other middleware
       'django_user_status.middleware.UserStatusMiddleware',
   ]
   ```

redis example in settings.py (if you are using redis)

```
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": "redis://user:password@localhost:6379",
        "OPTIONS": {

            "CLIENT_CLASS": "django_redis.client.DefaultClient",
        },
    }
}

```

Load the template tags in your templates:

```
{% load user_status_tags %}
```

to use the template tags you need to add "django_user_status" to your INSTALLED_APPS

```
django_user_status
```

Configuration (Optional)
You can customize the package's behavior by adding the following settings to your settings.py file.

- USER_STATUS_CACHE_DURATION: The time in seconds that a user is considered "online" after their last request. Defaults to 300 (5 minutes).
- USER_STATUS_CACHE_KEY_PREFIX: The prefix for the cache key. Useful to avoid key collisions. Defaults to 'last_seen'.
  Example settings.py:

# Set the user to be "online" for 10 minutes

USER_STATUS_CACHE_DURATION = 600

# Use a different cache key prefix

USER_STATUS_CACHE_KEY_PREFIX = 'user_activity'

Usage
In your templates:
To show a user's status:

```
{% get_user_status user %}
```

To show the last seen time:

```
{% get_last_seen user %}
```

What's New in Version 0.1.2

- Bug Fix: Resolved a TypeError related to timezone-aware and naive datetimes. The package now correctly uses timezone-aware datetimes for all cache and status checks, ensuring reliability.

- Added Unit Tests: Comprehensive unit tests have been added to ensure the reliability and correctness of the middleware and template tags.
