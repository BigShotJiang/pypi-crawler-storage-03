# django_user_status/urls.py
from django.urls import path

urlpatterns = [
    # This file is empty because this is a reusable app.
    # It only exists to satisfy the test runner.
]
