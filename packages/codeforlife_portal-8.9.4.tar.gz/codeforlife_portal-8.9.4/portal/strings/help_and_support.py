HELP_BANNER = {
    "title": "Help and support",
    "subtitle": "",
    "text": "If you’ve run into problems, please look at our FAQs "
    "below for advice to commonly asked questions. If you still can’t find the "
    "answers, please contact us. One of the Code for Life team "
    "will get back to you and resolve your issues.",
    "image_class": "banner--picture--help",
}
