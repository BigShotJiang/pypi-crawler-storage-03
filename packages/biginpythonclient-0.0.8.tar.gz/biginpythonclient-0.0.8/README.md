 # BiginPythonClient

[![PyPI version](https://badge.fury.io/py/EllucianEthosPythonClient.svg)](https://badge.fury.io/py/EllucianEthosPythonClient)

Python Client Library for interfacing with Bigin rest API.
