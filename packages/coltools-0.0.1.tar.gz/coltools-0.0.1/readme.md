# Python collection operations.

## Installation

You can install from [pypi](https://pypi.org/project/coltools/)

```console
pip install -U coltools
```

## Usage

```python
import coltools
```
