
CMR = 'Centre for Microbiome Research, School of Biomedical Sciences, \
Faculty of Health, Queensland University of Technology'

BEN_NAME_AND_CENTRE = 'Ben J. Woodcroft, '+CMR
BEN_NAME_AND_CENTRE_AND_EMAIL = 'Ben J. Woodcroft, '+CMR+\
    ' <benjwoodcroft near gmail.com>'