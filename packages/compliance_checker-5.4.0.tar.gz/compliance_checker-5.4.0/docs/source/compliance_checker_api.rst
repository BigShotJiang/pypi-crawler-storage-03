.. _api-index:

###############
API
###############

.. currentmodule:: compliance_checker

.. autosummary::
   :toctree: generated/

   compliance_checker.cf
   compliance_checker.protocols
   compliance_checker.acdd
   compliance_checker.base
   compliance_checker.cfutil
   compliance_checker.ioos
   compliance_checker.runner
   compliance_checker.suite
   compliance_checker.util


* :ref:`modindex`
* :ref:`genindex`
