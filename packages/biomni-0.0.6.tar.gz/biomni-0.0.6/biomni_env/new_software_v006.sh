# Biomni v0.0.6 - Incremental Software Installation
# Add any new packages/software introduced in version 0.0.6 below
pip install transformers sentencepiece langchain-google-genai langchain_ollama mcp
