from lino_xl.lib.cal.fixtures.demo import objects
