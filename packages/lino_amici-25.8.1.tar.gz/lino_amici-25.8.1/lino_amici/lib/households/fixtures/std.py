from lino_xl.lib.households.fixtures.std import objects
