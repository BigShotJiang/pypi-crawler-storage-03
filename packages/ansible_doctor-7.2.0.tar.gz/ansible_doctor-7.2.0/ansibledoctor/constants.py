#!/usr/bin/env python3
"""Global constants."""

DOCTOR_CONF_FILE = "doctor.conf.yaml"
YAML_EXTENSIONS = ["yaml", "yml"]
