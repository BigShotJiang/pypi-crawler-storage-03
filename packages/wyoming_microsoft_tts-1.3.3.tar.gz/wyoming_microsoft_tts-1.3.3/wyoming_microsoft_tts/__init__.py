"""Wyoming server for Microsoft TTS."""
