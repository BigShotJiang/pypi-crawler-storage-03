# I think I can get rid of this class

# Condition represents one possible "total condition" 
# pass in metaconditions to construct Condition, 
# along with constraints on the condition
class ExperimentCondition():
    # argv consists of Variable types
    def __init__(self, label):
        self.label = label


    

