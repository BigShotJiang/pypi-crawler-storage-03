# auto_garch/__init__.py
__version__ = "0.1.0a0"

from .auto_garch import AutoGarch, Config

__all__ = ["AutoGarch", "Config"]
