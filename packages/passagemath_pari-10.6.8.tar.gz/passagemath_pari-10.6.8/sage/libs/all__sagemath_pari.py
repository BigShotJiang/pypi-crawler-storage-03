# sage_setup: distribution = sagemath-pari
from sage.libs.pari.all import pari, pari_gen, PariError
