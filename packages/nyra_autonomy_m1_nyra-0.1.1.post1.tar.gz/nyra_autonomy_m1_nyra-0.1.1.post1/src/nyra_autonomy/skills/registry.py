from __future__ import annotations
import importlib
import sys
import inspect
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Optional
import yaml
from jsonschema import validate, validators

MANIFEST_NAME = "manifest.yaml"

@dataclass
class Skill:
    name: str
    version: str
    entrypoint: str
    description: str = ""
    tags: list[str] = field(default_factory=list)
    inputs_schema: dict[str, Any] = field(default_factory=dict)
    module: Optional[Any] = None
    func: Optional[Callable[..., Any]] = None
    root: Optional[Path] = None

class SkillsRegistry:
    def __init__(self, search_dir: Path):
        self.search_dir = Path(search_dir)
        self.skills: dict[str, Skill] = {}

    def load_all(self) -> None:
        self.skills.clear()
        for manifest in self.search_dir.rglob(MANIFEST_NAME):
            try:
                skill = self._load_manifest(manifest)
                self.skills[skill.name] = skill
            except Exception as e:
                print(f"[SkillsRegistry] Fehler beim Laden {manifest}: {e}")

    def _load_manifest(self, manifest_path: Path) -> Skill:
        data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
        name = data["name"]
        ep = data["entrypoint"]
        mod_name, func_name = ep.split(":")
        root = manifest_path.parent
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        root = manifest_path.parent
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        module = importlib.import_module(mod_name)
        func = getattr(module, func_name)
        if not callable(func):
            raise TypeError(f"Entrypoint {ep} ist nicht aufrufbar")

        # Optional: Schema validieren
        schema = data.get("inputs_schema", {"type": "object"})
        validators.validator_for(schema).check_schema(schema)  # nur Schema prüfen

        return Skill(
            name=name,
            version=str(data.get("version", "0.0.0")),
            entrypoint=ep,
            description=data.get("description", ""),
            tags=data.get("tags", []),
            inputs_schema=schema,
            module=module,
            func=func,
            root=manifest_path.parent
        )

    def call(self, name: str, **inputs):
        skill = self.skills.get(name)
        if not skill:
            raise KeyError(f"Skill '{name}' nicht gefunden")
        # Schema prüfen
        if skill.inputs_schema:
            validate(inputs, skill.inputs_schema)
        sig = inspect.signature(skill.func)
        return skill.func(**{k: v for k, v in inputs.items() if k in sig.parameters})

    def catalog(self) -> dict[str, dict[str, Any]]:
        return {
            s.name: {
                "version": s.version,
                "tags": s.tags,
                "description": s.description,
                "entrypoint": s.entrypoint,
                "root": str(s.root) if s.root else None,
            }
            for s in self.skills.values()
        }
