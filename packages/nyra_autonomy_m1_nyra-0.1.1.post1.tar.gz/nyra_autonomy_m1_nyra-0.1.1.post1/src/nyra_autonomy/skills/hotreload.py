from __future__ import annotations
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from .registry import SkillsRegistry, MANIFEST_NAME

class _Handler(FileSystemEventHandler):
    def __init__(self, registry: SkillsRegistry):
        self.registry = registry

    def on_any_event(self, event):
        # Bei jeglicher Änderung neu laden (einfach & robust)
        self.registry.load_all()
        print("[SkillsWatcher] Skills neu geladen. Verfügbar:", ", ".join(self.registry.skills.keys()))

class SkillsWatcher:
    def __init__(self, directory: Path, registry: SkillsRegistry):
        self.directory = Path(directory)
        self.registry = registry
        self.observer = Observer()

    def start(self):
        self.registry.load_all()
        handler = _Handler(self.registry)
        self.observer.schedule(handler, str(self.directory), recursive=True)
        self.observer.start()
        print(f"[SkillsWatcher] Beobachte {self.directory} (Hot-Reload aktiv).")

    def stop(self):
        self.observer.stop()
        self.observer.join()
