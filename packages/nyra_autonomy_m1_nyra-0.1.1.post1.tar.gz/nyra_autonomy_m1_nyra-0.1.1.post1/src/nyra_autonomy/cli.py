from __future__ import annotations
import json
from pathlib import Path
import click
from rich.console import Console
from .skills import SkillsRegistry, SkillsWatcher
from .planner import make_simple_plan
from .reasoner import explain_plan
from .change.model import ChangeProposal, ChangeItem, save_proposal, load_proposal, new_id
from .change.diffing import unified_diff, file_sha256, read_file_or_empty
from .executor import apply as exec_apply, list_transactions, rollback as exec_rollback

console = Console()

@click.group()
def main():
    """Nyra Autonomy – M1 CLI"""

@main.group()
def skills():
    """Skills-Registry Befehle"""

@skills.command("list")
@click.option("--dir", "skills_dir", default="./skills", help="Skill-Verzeichnis")
def skills_list(skills_dir):
    reg = SkillsRegistry(Path(skills_dir))
    reg.load_all()
    catalog = reg.catalog()
    for name, meta in catalog.items():
        console.print(f"[bold]{name}[/bold] v{meta['version']} – tags={meta['tags']} – {meta['description']}")

@skills.command("watch")
@click.option("--dir", "skills_dir", default="./skills", help="Skill-Verzeichnis")
def skills_watch(skills_dir):
    reg = SkillsRegistry(Path(skills_dir))
    watcher = SkillsWatcher(skills_dir, reg)
    watcher.start()
    try:
        while True:
            pass
    except KeyboardInterrupt:
        watcher.stop()

@main.command()
@click.option("--goal", required=True, help="Zielbeschreibung")
@click.option("--plan", "plan_hint", default="", help="Plan-Hinweis (optional)" )
@click.option("--file", "target_file", required=True, type=click.Path(path_type=Path), help="Zieldatei (bestehende)" )
@click.option("--with-file", "new_file", required=True, type=click.Path(path_type=Path), help="Datei mit gewünschtem neuen Inhalt" )
@click.option("--out", "out_path", type=click.Path(path_type=Path), default=Path("proposal.json"), help="Wohin speichern" )
def propose(goal, plan_hint, target_file, new_file, out_path):
    before = read_file_or_empty(target_file)
    after = Path(new_file).read_text(encoding="utf-8")
    diff = unified_diff(before, after, str(target_file))
    change = ChangeItem(
        path=str(target_file),
        before=before,
        after=after,
        before_sha256=file_sha256(before),
        after_sha256=file_sha256(after),
        diff=diff
    )
    plan = [{"hint": plan_hint}] if plan_hint else []
    prop = ChangeProposal(id=new_id(), goal=goal, plan=plan, changes=[change])
    save_proposal(prop, out_path)
    console.print(f"Proposal gespeichert: {out_path}")
    console.print(diff or "(keine Änderungen)")

@main.command()
@click.argument("proposal", type=click.Path(path_type=Path))
@click.option("--dry-run/--apply", default=True, help="Standard: Dry-Run mit Diff")
def apply(proposal, dry_run):
    prop = load_proposal(proposal)
    from pathlib import Path as _P
    tx_id = exec_apply(prop, dry_run=dry_run,
                        tx_root=_P(proposal).resolve().parent / '.nyra/transactions')
    if dry_run:
        console.print(f"[cyan]Dry-Run abgeschlossen (TX: {tx_id}).[/cyan]")
    else:
        console.print(f"[green]Angewendet (TX: {tx_id}).[/green]")

@main.group("tx")
def tx():
    """Transaktionen verwalten"""

@tx.command("list")
def tx_list():
    for meta in list_transactions():
        console.print(json.dumps(meta, indent=2))

@tx.command("rollback")
@click.argument("tx_id")
def tx_rollback(tx_id):
    exec_rollback(tx_id)
