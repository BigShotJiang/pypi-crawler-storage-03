from __future__ import annotations
from pathlib import Path
from difflib import unified_diff as _udiff
import hashlib

def unified_diff(before: str, after: str, path: str) -> str:
    before_lines = before.splitlines(keepends=True)
    after_lines = after.splitlines(keepends=True)
    diff = _udiff(before_lines, after_lines, fromfile=f"a/{path}", tofile=f"b/{path}")
    return "".join(diff)

def file_sha256(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()

def read_file_or_empty(p: Path) -> str:
    try:
        return Path(p).read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""
