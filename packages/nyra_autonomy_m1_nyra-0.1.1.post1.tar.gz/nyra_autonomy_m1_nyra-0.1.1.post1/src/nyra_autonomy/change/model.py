from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any
from pathlib import Path
import json
import uuid

@dataclass
class ChangeItem:
    path: str
    before: str
    after: str
    before_sha256: str
    after_sha256: str
    diff: str

@dataclass
class ChangeProposal:
    id: str
    goal: str
    plan: List[Dict[str, Any]]
    tests: List[str] = field(default_factory=list)
    changes: List[ChangeItem] = field(default_factory=list)

def save_proposal(prop: ChangeProposal, out_path: Path) -> None:
    data = asdict(prop)
    Path(out_path).write_text(json.dumps(data, indent=2), encoding="utf-8")

def load_proposal(path: Path) -> ChangeProposal:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    items = [ChangeItem(**ci) for ci in data.get("changes", [])]
    return ChangeProposal(
        id=data["id"],
        goal=data["goal"],
        plan=data.get("plan", []),
        tests=data.get("tests", []),
        changes=items,
    )

def new_id() -> str:
    return str(uuid.uuid4())
