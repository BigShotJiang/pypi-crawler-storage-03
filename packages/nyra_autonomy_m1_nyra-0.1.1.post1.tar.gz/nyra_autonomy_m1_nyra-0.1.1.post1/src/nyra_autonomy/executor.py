from pathlib import Path
from dataclasses import asdict
import json, subprocess, shutil, datetime
from typing import List
from rich.console import Console
from rich.panel import Panel
from .change.model import ChangeProposal

console = Console()
NYRA_DIR = Path(".nyra")
TX_DIR = NYRA_DIR / "transactions"

def ensure_dirs(root: Path = None):
    (root or TX_DIR).mkdir(parents=True, exist_ok=True)

def _write(p: Path, c: str):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(c, encoding="utf-8")

def _backup(p: Path, d: Path):
    """Sichert Dateien; absolute Pfade unter backup_abs/<voller/pfad>, relative unter backup_rel/<relativ>."""
    if not p.exists():
        return
    base = d / ("backup_abs" if p.is_absolute() else "backup_rel")
    rel = Path(p.as_posix().lstrip("/")) if p.is_absolute() else p
    dest = base / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)

def _restore_backup(d: Path):
    """Stellt Backups aus backup_abs/ und backup_rel/ wieder her."""
    abs_base = d / "backup_abs"
    rel_base = d / "backup_rel"
    if abs_base.exists():
        for s in abs_base.rglob("*"):
            if s.is_file():
                rel = s.relative_to(abs_base)
                t = Path("/" + rel.as_posix())
                t.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, t)
    if rel_base.exists():
        for s in rel_base.rglob("*"):
            if s.is_file():
                rel = s.relative_to(rel_base)
                t = Path(rel)
                t.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, t)

def apply(prop: ChangeProposal, dry_run: bool = True, tx_root: Path | None = None) -> str:
    tx_base = tx_root or TX_DIR
    ensure_dirs(tx_base)
    tx_id = prop.id
    tx = tx_base / tx_id
    tx.mkdir(parents=True, exist_ok=True)

    meta = {
        "id": tx_id,
        "goal": prop.goal,
        "plan": prop.plan,
        "tests": prop.tests,
        "created_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "status": "dry-run" if dry_run else "applied",
    }

    (tx / "proposal.json").write_text(json.dumps(asdict(prop), indent=2), encoding="utf-8")

    # Diffs anzeigen
    for ch in prop.changes:
        console.print(Panel.fit(ch.diff or "(keine Änderungen)", title=f"Diff: {ch.path}"))

    if dry_run:
        (tx / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        return tx_id

    # Änderungen anwenden + Backups erstellen
    for ch in prop.changes:
        p = Path(ch.path)
        _backup(p, tx)
        _write(p, ch.after)

    # Tests ausführen
    results: List[dict] = []
    for cmd in prop.tests:
        try:
            cp = subprocess.run(cmd, shell=True, check=False, capture_output=True, text=True)
            results.append({"cmd": cmd, "returncode": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr})
        except Exception as e:
            results.append({"cmd": cmd, "error": str(e)})

    (tx / "test_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    (tx / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    console.print(f"[green]Transaktion {tx_id} angewendet.[/green]")
    return tx_id

def list_transactions() -> list[dict]:
    ensure_dirs()
    out = []
    for d in TX_DIR.iterdir():
        if d.is_dir() and (d / "meta.json").exists():
            out.append(json.loads((d / "meta.json").read_text(encoding="utf-8")))
    return sorted(out, key=lambda m: m.get("created_at", ""))

def rollback(tx_id: str) -> None:
    ensure_dirs()
    tx = TX_DIR / tx_id
    if not tx.exists():
        raise FileNotFoundError(f"Transaktion {tx_id} nicht gefunden")
    _restore_backup(tx)
    mp = tx / "meta.json"
    meta = json.loads(mp.read_text(encoding="utf-8"))
    meta["status"] = "rolled-back"
    meta["rolled_back_at"] = datetime.datetime.now(datetime.UTC).isoformat()
    mp.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    console.print(f"[yellow]Rollback für {tx_id} durchgeführt.[/yellow]")
