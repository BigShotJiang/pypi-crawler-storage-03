from __future__ import annotations
from typing import Any, Dict, List

def explain_plan(goal: str, plan_steps: List[Any]) -> str:
    lines = [f"Ziel: {goal}", "Geplanter Ablauf:"]
    for i, st in enumerate(plan_steps, 1):
        lines.append(f"  {i}. Skill '{st.skill}' mit Inputs {st.inputs}")
    return "\n".join(lines)
