from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any

@dataclass
class PlanStep:
    skill: str
    inputs: Dict[str, Any]

@dataclass
class Plan:
    goal: str
    steps: List[PlanStep]

def make_simple_plan(goal: str, skill_catalog: Dict[str, Dict[str, Any]]) -> Plan:
    """Sehr einfache Planner-Heuristik:
    - Wenn ein Skill den Tag 'text' hat und im Goal Text vorkommt, nutze ihn.
    - Fallback: nimm den ersten Skill überhaupt.
    """
    chosen = None
    for name, meta in skill_catalog.items():
        tags = set(meta.get("tags", []))
        if "text" in tags and any(k in goal.lower() for k in ["text", "echo", "print"]):
            chosen = name
            break
    if not chosen and skill_catalog:
        chosen = next(iter(skill_catalog.keys()))
    steps = [PlanStep(skill=chosen, inputs={"text": goal})] if chosen else []
    return Plan(goal=goal, steps=steps)
