from pathlib import Path
from nyra_autonomy.skills import SkillsRegistry

def test_registry_loads(sample_skills_path: Path = Path("skills")):
    reg = SkillsRegistry(sample_skills_path)
    reg.load_all()
    cat = reg.catalog()
    assert "echo_skill" in cat
    out = reg.call("echo_skill", text="hi")
    assert out == "hi"
