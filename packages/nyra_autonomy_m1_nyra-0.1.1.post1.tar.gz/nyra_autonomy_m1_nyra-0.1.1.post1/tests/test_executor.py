from pathlib import Path
from nyra_autonomy.change.model import ChangeProposal, ChangeItem
from nyra_autonomy.change.diffing import unified_diff, file_sha256
from nyra_autonomy.executor import apply, rollback, list_transactions

def test_apply_and_rollback(tmp_path: Path, monkeypatch):
    # Arbeitsverzeichnis wechseln
    monkeypatch.chdir(tmp_path)
    # Ausgangsdatei
    target = Path("demo.txt")
    target.write_text("hello\nworld\n", encoding="utf-8")
    before = target.read_text(encoding="utf-8")
    after = "hello\nnyra\n"
    ci = ChangeItem(
        path=str(target),
        before=before, after=after,
        before_sha256=file_sha256(before),
        after_sha256=file_sha256(after),
        diff=unified_diff(before, after, str(target))
    )
    prop = ChangeProposal(id="test-tx", goal="rename world to nyra", plan=[{"hint":"string replace"}], changes=[ci])

    # Dry-Run
    tx_id = apply(prop, dry_run=True)
    assert tx_id == "test-tx"

    # Apply
    tx_id = apply(prop, dry_run=False)
    assert Path(".nyra/transactions/test-tx/meta.json").exists()
    assert target.read_text(encoding="utf-8") == after

    # Rollback
    rollback(tx_id)
    assert target.read_text(encoding="utf-8") == before
    metas = list_transactions()
    assert any(m.get("status") in ("dry-run","applied","rolled-back") for m in metas)
