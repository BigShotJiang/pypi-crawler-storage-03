from pathlib import Path
from nyra_autonomy.change.model import ChangeProposal, ChangeItem
from nyra_autonomy.change.diffing import unified_diff, file_sha256

def test_diff_and_hash(tmp_path: Path):
    before = "hello\nworld\n"
    after = "hello\nnyra\n"
    diff = unified_diff(before, after, "demo.txt")
    assert "-world" in diff and "+nyra" in diff
    assert file_sha256(before) != file_sha256(after)
