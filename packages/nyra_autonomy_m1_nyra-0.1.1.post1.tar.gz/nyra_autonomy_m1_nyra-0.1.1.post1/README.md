# Nyra Autonomy M1

Implementiert die ersten Meilensteine für **Autonomie 1–2**:
- Planner/Reasoner (einfaches, regelbasiertes Planen auf Basis von Skill-Tags)
- Skills-Registry mit Manifesten und **Hot-Reload**
- Change-Proposals (Ziel, Plan, Diff, Tests, Rollback)
- **Dry-Run + Diff** ist Standard
- **Rollback gesichert**: pro Transaktion wird ein Backup + Metadaten abgelegt
- Stabiler **Executor** + Tests

## Installation (entweder Systemweit oder im Projekt)
```bash
# VSCodium-Terminal
pip install -e .
```

## CLI – Kurzüberblick
```bash
# Skills anzeigen & Hot-Reload starten
nyra-autonomy skills list
nyra-autonomy skills watch --dir ./skills

# Ein Change-Proposal erstellen (von Datei A zu Datei B)
nyra-autonomy propose --goal "Demo" --plan "use echo_skill" --file demo.txt --with-file new.txt --out proposal.json

# Dry-Run (Standard) – Diff anzeigen
nyra-autonomy apply proposal.json --dry-run

# Anwenden + Rollback-Bundle erzeugen
nyra-autonomy apply proposal.json --apply

# Transaktionen anzeigen
nyra-autonomy tx list

# Rollback einer Transaktion
nyra-autonomy tx rollback <TX_ID>
```

## Beispiel-Skill
Unter `skills/echo_skill` liegt ein sehr einfaches Beispiel mit Manifest + Python-Entry-Point.
