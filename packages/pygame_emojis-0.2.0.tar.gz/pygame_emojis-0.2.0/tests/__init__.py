"""Test package for pygame_emojis."""
