# NovaCordpy

Eine Python-Bibliothek für Discord-Integration.

## Installation
```bash
pip install NovaCordpy
```

## Beispiel
```python
from novacordpy import NovaClient

client = NovaClient("DEIN_DISCORD_TOKEN")
client.run()
```
