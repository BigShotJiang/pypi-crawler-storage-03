@coqtop %*
