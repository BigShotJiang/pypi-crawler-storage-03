"""
Tests for Option monad implementation.
"""