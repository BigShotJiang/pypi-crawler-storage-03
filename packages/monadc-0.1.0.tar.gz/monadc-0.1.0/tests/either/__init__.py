"""
Tests for Either monad implementation.
"""