"""
Tests for Result monad implementation.
"""