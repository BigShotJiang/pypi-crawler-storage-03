"""
Tests for Try monad implementation.
"""