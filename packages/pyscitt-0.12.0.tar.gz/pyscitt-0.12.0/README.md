# pyscitt: Python CLI tools for SCITT CCF Ledger

Tools to sign claims and interact with a SCITT CCF Ledger.

For more information, please find the `scitt-ccf-ledger` repository at https://github.com/microsoft/scitt-ccf-ledger.

Package sources are available at https://github.com/microsoft/scitt-ccf-ledger/tree/main/pyscitt.
