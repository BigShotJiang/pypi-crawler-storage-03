"""Version information for mindzie-api package."""

__version__ = "1.0.1"
__author__ = "Mindzie"
__email__ = "support@mindzie.com"
__license__ = "MIT"