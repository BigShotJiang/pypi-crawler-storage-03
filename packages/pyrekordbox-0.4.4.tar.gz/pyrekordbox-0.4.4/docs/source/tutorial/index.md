# Tutorial

```{attention}
Please make sure to back up your Rekordbox collection before making
any changes with pyrekordbox or developing/testing new features.

The backup dialog can be found under "File" > "Library" > "Backup Library"
```

````{toctree}
---
maxdepth: 3
---

configuration
db6
xml
anlz
mysetting
````
