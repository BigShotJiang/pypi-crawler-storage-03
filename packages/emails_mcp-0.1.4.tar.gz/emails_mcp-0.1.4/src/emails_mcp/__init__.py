def main() -> None:
    print("Hello from emails-mcp!")
