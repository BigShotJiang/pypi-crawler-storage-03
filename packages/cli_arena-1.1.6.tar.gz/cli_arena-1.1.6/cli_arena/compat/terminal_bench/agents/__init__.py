from cli_arena.agents.base_agent import AgentResult, FailureMode


