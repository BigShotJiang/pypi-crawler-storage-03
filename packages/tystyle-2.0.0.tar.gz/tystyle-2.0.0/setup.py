from setuptools import setup

setup(
    name='tystyle',
    version='2.0.0',
    py_modules=['tystyle'],
    install_requires=['rich'],
)
