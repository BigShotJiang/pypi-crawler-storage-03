from . import psxexeinfo as psxexeinfo
