VERSION = "0.2.4"

# this will be templated during the build
GIT_COMMIT = "d9a2df31b1ff1ea6796a25558771ed1a38e6d1f9"
