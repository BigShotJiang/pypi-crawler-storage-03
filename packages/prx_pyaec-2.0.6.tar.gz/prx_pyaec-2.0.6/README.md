# prx_pyaec

PRX Acoustic echo cancellation

Python bindings to https://github.com/wnm3/prx_aec  
(forked from https://github.com/thewh1teagle/aec)  

## Initial project setup ##
After cloning this repository, run the following command:  
git submodule init && git submodule update
