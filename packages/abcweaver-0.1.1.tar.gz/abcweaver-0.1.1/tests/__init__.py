"""
📡 Caelus Test Suite

Comprehensive testing for all caelus functionality.
"""