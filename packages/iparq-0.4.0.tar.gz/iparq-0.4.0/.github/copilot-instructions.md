# Copilot instructions

## Package management

Use UV for package management.

## Python

Since this is a CLI tool, use typer for the CLI interface.

Use pydantic for data validation and settings management.
Use pytest for testing.
