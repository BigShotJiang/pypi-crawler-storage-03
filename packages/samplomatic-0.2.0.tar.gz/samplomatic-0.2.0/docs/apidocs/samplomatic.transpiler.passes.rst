samplomatic.transpiler.passes package
=====================================

.. automodule:: samplomatic.transpiler.passes
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   samplomatic.transpiler.passes.insert_noops

Submodules
----------

samplomatic.transpiler.passes.add\_inject\_noise module
-------------------------------------------------------

.. automodule:: samplomatic.transpiler.passes.add_inject_noise
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.transpiler.passes.add\_terminal\_right\_dressed\_boxes module
-------------------------------------------------------------------------

.. automodule:: samplomatic.transpiler.passes.add_terminal_right_dressed_boxes
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.transpiler.passes.group\_gates\_into\_boxes module
--------------------------------------------------------------

.. automodule:: samplomatic.transpiler.passes.group_gates_into_boxes
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.transpiler.passes.group\_meas\_into\_boxes module
-------------------------------------------------------------

.. automodule:: samplomatic.transpiler.passes.group_meas_into_boxes
   :members:
   :show-inheritance:
   :undoc-members:

samplomatic.transpiler.passes.utils module
------------------------------------------

.. automodule:: samplomatic.transpiler.passes.utils
   :members:
   :show-inheritance:
   :undoc-members:
