TRUTHY = {"true", "1", "t", "y", "yes", "on", "enable", "enabled"}
