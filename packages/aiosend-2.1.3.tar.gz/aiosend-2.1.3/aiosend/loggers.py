import logging

webhook = logging.getLogger("aiosend.webhook")
polling = logging.getLogger("aiosend.polling")
invoice_polling = logging.getLogger("aiosend.polling.invoice")
check_polling = logging.getLogger("aiosend.polling.check")
client = logging.getLogger("aiosend.client")
