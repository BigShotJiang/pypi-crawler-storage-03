=====
Types
=====

`Crypto Pay API <https://help.crypt.bot/crypto-pay-api>`_ types implementation.

.. automodule:: aiosend.types
    :members:
    :undoc-members:
    :exclude-members: model_config, model_fields, model_computed_fields, model_post_init, qr, get_image, update, delete, poll