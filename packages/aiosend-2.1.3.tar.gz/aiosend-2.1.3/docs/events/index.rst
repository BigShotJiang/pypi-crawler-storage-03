======
Events
======

* **Webhook** - updates handling via webhook.
* **Invoice polling** - invoice updates handling via polling.
* **Check polling** - check updates handling via polling.
* **Polling config** - configuration for update requests

.. toctree::

    webhook
    invoice_polling
    check_polling
    filters
    polling_config