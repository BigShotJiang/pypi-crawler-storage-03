========
Telethon
========

Usage example with `Telethon <https://docs.telethon.dev/en/stable/>`_
---------------------------------------------------------------------

.. literalinclude:: ../../examples/telethon_example.py

Preview
-------

.. image:: ../_static/payment_handle_example.png