===================
python-telegram-bot
===================

Usage example with `python-telegram-bot <https://docs.python-telegram-bot.org/en/latest/>`_
-------------------------------------------------------------------------------------------

.. literalinclude:: ../../examples/ptb.py

Preview
-------

.. image:: ../_static/payment_handle_example.png