===========
aiogram 3.x
===========

Usage example with `aiogram 3.x <https://aiogram.dev/>`_
--------------------------------------------------------

.. literalinclude:: ../../examples/aiogram3.py

Preview
-------

.. image:: ../_static/payment_handle_example.png