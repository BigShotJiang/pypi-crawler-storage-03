========
Pyrogram
========

Usage example with `Pyrogram <https://docs.pyrogram.org/>`_
-----------------------------------------------------------

.. literalinclude:: ../../examples/pyro.py

Preview
-------

.. image:: ../_static/payment_handle_example.png