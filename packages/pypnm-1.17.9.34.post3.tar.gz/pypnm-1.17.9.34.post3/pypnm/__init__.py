"""PNM (PPM and PGM) image files I/O for Python >= 3.4, 9 May 2025 "Victory" build. Type `from pypnm import pnmlpnm` to get access to functions."""
