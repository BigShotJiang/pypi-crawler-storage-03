# prism
AI-powered ETL/ELT automation. Generate, orchestrate, and monitor pipelines automatically from plain-language workflow descriptions. Features real-time monitoring, Dockerized execution, and Airflow orchestration.
