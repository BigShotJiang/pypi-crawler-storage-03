from setuptools import setup, find_packages

requirements = [
    
]

setup(
    name="fbusl",
    version='0.05.20',
    packages=find_packages(),
    license="MIT",
    author="Oliver Morrison",
    long_description_content_type="text/markdown",
    install_requires=requirements
)