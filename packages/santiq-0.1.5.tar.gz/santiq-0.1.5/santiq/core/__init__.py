"""Core Santiq modules for ETL operations."""

__version__ = "0.1.5"
