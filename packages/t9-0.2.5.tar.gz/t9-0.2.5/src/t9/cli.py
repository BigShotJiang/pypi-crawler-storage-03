"""Command-line interface for PY9 T9 text input system."""

import argparse
import sys
from pathlib import Path

from importlib.metadata import version

from . import maket9
from .demo import run_demo as demo_function
from .corpus.cli import add_corpus_commands


def run_demo(dict_file=None, language=None, region=None):
    """Run the T9 demo application."""
    return demo_function(dict_file, language, region)


def generate_dict(wordlist, output, language="Unknown", comment=""):
    """
    Generate a T9 dictionary from a wordlist file.
    """
    if not Path(wordlist).exists():
        print(f"Wordlist file not found: {wordlist}")
        return 1

    print(f"Generating dictionary from {wordlist}...")
    print(f"Output: {output}")
    print(f"Language: {language}")
    print(f"Comment: {comment}")

    try:
        # Call the generation function
        maket9.makedict(wordlist, output, language, comment)
        print(f"Dictionary successfully created: {output}")
        return 0

    except Exception as e:
        print(f"Dictionary generation failed: {e}")
        return 1


def main():
    """
    Main CLI entry point.
    """
    parser = argparse.ArgumentParser(description="PY9 T9 predictive text system", prog="py9")

    parser.add_argument("--version", action="version", version=f"%(prog)s {version('t9')}")
    parser.add_argument("--locale", help="Locale to use (e.g., en-GB, en-US)")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Generate command
    gen_parser = subparsers.add_parser("generate", aliases=["gen"], help="Generate T9 dictionary from wordlist")
    gen_parser.add_argument("wordlist", help="Path to wordlist file (one word per line)")
    gen_parser.add_argument("-o", "--output", required=True, help="Output dictionary file path")
    gen_parser.add_argument("-l", "--language", default="Unknown", help="Language name for dictionary metadata")
    gen_parser.add_argument("-c", "--comment", default="", help="Comment for dictionary metadata")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run T9 demo application")
    demo_parser.add_argument("dictionary", nargs="?", help="Path to dictionary file (optional)")

    # Corpus commands
    add_corpus_commands(subparsers)

    args = parser.parse_args()

    # Parse locale if provided
    language = region = None
    if args.locale:
        if "-" in args.locale:
            language, region = args.locale.split("-", 1)
        else:
            language = args.locale

    # If no command specified, run demo by default
    if args.command is None:
        print("No command specified, running demo...")
        return run_demo(None, language, region)

    if args.command in ("generate", "gen"):
        return generate_dict(args.wordlist, args.output, args.language, args.comment)
    elif args.command == "demo":
        return run_demo(args.dictionary, language, region)
    elif args.command == "corpus":
        # Handle corpus subcommands
        if hasattr(args, "func"):
            return args.func(args)
        else:
            print("No corpus subcommand specified. Use 'py9 corpus -h' for help.")
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
