class MissingEnvironmentVariable(Exception):
    pass


class ErroneousEnvironmentVariable(Exception):
    pass
