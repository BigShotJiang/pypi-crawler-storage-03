class PassException(Exception):
    pass
