# -*- coding: utf-8 -*-

"""\
Caelus CLI
----------

This module provides a command-line interface to several utilities available in
the Python library.

"""
