# -*- coding: utf-8 -*-

"""\
OpenFOAM finite-volume mesh interface
--------------------------------------
"""

from .fvmesh import FVMesh
