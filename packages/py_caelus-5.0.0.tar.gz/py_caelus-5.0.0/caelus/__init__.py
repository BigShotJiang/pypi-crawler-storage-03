# -*- coding: utf-8 -*-

"""\
Caelus Python
=============

This package provides a python-based interface to Caelus Computational
Mechanics Library.

"""

from .config import get_config
