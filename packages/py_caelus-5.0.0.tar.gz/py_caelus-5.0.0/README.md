
# Caelus Python Library (CPL)

[![Build status](https://github.com/sayerhs/cpl/actions/workflows/ci.yml/badge.svg)](https://github.com/sayerhs/cpl/actions/workflows/ci.yml)
[![Coverage Status](https://coveralls.io/repos/github/sayerhs/cpl/badge.svg?branch=dev)](https://coveralls.io/github/sayerhs/cpl?branch=main)

Caelus Python Library (CPL) is a python package for interacting with Caelus CML
software. The software is distributed under Apache License, Version 2.0 (see
LICENSE.txt) for details.

## Documentation

Please see [online documentation](https://sayerhs.github.io/cpl) for th installation instructions, user manual, as well as the API reference manual.  
