# -*- coding: utf-8 -*-

"""Caelus Python Library

This python package provides a scriptable interface to Caelus Computational
Mechanics Library (CML).
"""

from setuptools import setup

setup()
