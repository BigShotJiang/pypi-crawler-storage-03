# mirrai

A Multimodal AI agent for desktop automation via screenshots and tool use.
