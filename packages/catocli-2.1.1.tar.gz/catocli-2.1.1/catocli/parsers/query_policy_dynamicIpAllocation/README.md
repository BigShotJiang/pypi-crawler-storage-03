
## CATO-CLI - query.policy.dynamicIpAllocation:
[Click here](https://api.catonetworks.com/documentation/#query-dynamicIpAllocation) for documentation on this operation.

### Usage for query.policy.dynamicIpAllocation:

`catocli query policy dynamicIpAllocation -h`
