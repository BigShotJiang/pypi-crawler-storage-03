
## CATO-CLI - query.xdr:
[Click here](https://api.catonetworks.com/documentation/#query-xdr) for documentation on this operation.

### Usage for query.xdr:

`catocli query xdr -h`
