"""Skalds: An event-driven, modular distributed task scheduling and execution system."""
from skalds.skalds import Skalds


__version__ = "0.1.0"