"""Components for hierarchical SOMs."""
