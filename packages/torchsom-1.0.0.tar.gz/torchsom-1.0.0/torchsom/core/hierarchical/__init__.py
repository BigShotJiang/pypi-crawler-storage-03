"""Hierarchical SOM module for torchsom."""
