"""Configuration module for torchsom."""

from torchsom.configs.som_config import SOMConfig

__all__ = ["SOMConfig"]
