"""Python unit tests for jupy_sqlite_extension."""
