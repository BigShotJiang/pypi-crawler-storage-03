---
name: Bug, front-end
about: The interface isn't working correctly, before downloading results.
title: ''
labels:
    - 'req: Python Shiny'
type: 'Bug'
assignees: ''

---

Please provide relevant environment details, a minimal reproducer for the bug, and the expected behavior.
