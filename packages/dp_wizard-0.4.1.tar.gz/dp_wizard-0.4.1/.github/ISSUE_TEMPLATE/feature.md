---
name: Feature
about: New functionality
title: ''
type: 'Feature'
assignees: ''

---

Besides simply describing a new feature, it may help to include who would use this feature, and what problem they're trying to solve.
