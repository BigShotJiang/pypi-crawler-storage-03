---
name: Bug, back-end
about: There's an error downloading the results, or the results are incorrect.
title: ''
labels:
    - 'req: OpenDP API'
type: 'Bug'
assignees: ''

---

Please provide relevant environment details, a minimal reproducer for the bug, and the expected behavior.
