Strings of ALL CAPS are replaced in these templates.
Keeping them in a format which can actually be parsed as python
makes some things easier, but it is also reinventing the wheel.
We may revisit this.
