print(
    f"DP counts for COLUMN_NAME "
    f"assuming {contributions} contributions per individual"
)

if groups:
    print(f"(grouped by {'/'.join(groups)})")

print(STATS_NAME)
