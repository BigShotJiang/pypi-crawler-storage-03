NAME: {
    "histogram": dict(zip(*df_to_columns(IDENTIFIER_STATS))),
    "accuracy": IDENTIFIER_ACCURACY,
    "confidence": CONFIDENCE,
}
