In `conf.json` we specify `"base_template": "lab"` instead of taking the default template.
When the notebooks generated with the default template are printed to PDF,
codeblocks are shifted to the next page instead of being split across pages.
The Jupyter Lab format looks better, and does not add unnecessary white space.
