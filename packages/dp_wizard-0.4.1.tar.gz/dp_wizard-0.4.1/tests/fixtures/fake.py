# +
# %pip install pytest
# -

# Introduction

print(2 + 2)

# # Coda
# Conclusion

print("goodbye!")
