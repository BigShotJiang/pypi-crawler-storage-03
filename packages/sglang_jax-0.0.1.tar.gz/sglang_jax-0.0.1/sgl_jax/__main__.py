"""
Main entry point for sgl_jax module.
"""

from sgl_jax.launch_server import main

if __name__ == "__main__":
    main()
