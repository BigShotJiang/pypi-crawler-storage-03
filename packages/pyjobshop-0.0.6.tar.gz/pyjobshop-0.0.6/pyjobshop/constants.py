MAX_VALUE = 2**42
"""int: Maximum allowed value, equal to 2^42.
"""
