"not implemented"


def not_implemented():
    "not implemented"
    raise NotImplementedError
