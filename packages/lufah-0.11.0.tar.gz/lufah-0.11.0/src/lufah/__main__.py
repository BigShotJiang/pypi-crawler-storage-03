""" lufah __main__ """

from lufah.cli_typer import main

main()
