"""
[DEPRECATED] All authentication logic has been modularized into submodules:
- auth_models.py
- auth_utils.py
- auth_session.py
- auth_constants.py

This file is kept for reference only.
""" 