from enum import Enum
 
class FileExists(Enum):
    FILE_EXIST = 1
    FILE_NOT_EXIST = 2
