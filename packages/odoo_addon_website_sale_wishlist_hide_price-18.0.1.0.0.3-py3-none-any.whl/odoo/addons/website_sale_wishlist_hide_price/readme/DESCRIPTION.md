This module extends the base of website_sale_hide_price to hide prices
in the wishlist views as well.
