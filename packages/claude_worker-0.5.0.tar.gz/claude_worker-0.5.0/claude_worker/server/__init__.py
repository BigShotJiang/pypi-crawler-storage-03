"""Server module for claude-worker."""
