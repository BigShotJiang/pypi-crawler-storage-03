"""Default entrypoint for the cwltest module."""

from . import main

main.main()
