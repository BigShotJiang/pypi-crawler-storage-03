.. include:: ../README.rst

********************
Command Line Options
********************

.. autoprogram:: cwltest.argparser:arg_parser()
   :prog: cwltest

.. toctree::
   :maxdepth: 2

   pytest
   autoapi/index

******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
