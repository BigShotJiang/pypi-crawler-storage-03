from pydantic_marshals.sqlalchemy.models import MappedModel

__all__ = ("MappedModel",)
