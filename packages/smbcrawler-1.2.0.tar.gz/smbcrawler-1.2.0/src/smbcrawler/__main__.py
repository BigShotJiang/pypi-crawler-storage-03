def main(*args, **kwargs):
    from smbcrawler.clickargs import cli

    cli(*args, **kwargs)


if __name__ == "__main__":
    main()
