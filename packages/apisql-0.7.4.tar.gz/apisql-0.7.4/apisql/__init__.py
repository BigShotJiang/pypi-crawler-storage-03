from .blueprint import APISQLBlueprint as apisql_blueprint
