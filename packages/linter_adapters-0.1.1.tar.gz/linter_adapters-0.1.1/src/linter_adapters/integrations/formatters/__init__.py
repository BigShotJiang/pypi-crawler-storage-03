"""
Contains bridges between Flake8 and other tools.
"""
