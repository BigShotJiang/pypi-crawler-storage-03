"""Image Convertor MCP - Model Context Protocol Server for Image Processing."""

__version__ = "0.1.1"
__author__ = "Beta"
