# JTools: simple tools, easy life


## Building

```cmd

python setup.py sdist bdist_wheel
twine upload dist/*
```