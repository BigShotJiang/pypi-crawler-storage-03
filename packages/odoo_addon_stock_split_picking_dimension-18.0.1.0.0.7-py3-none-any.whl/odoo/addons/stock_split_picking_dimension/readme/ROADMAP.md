- The split by dimension only split at the move level. In other words, if a move has 10
  units of a product with a weight of 1kg, the wizard will not split the move in
  different pickings even if a weight of 5kg is requested as max weight by picking.
