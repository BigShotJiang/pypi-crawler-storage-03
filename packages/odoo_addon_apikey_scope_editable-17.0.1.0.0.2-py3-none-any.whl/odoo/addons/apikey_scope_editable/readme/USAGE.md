To use this module, you need to:

1. Click on your user icon and then "Preferences"
2. Go to the "Account Security" tab, and then click the "New Api Key" button.
3. Fill the data, a new field will appear to set the key scope.
