default_app_config = "wagtail_trash.apps.TrashCanAppConfig"
