def function_b():
    print("Entering modules.function_b")
