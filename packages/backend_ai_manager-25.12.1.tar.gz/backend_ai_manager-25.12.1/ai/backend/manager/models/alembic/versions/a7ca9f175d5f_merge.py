"""merge

Revision ID: a7ca9f175d5f
Revises: d59ff89e7514, 11146ba02235
Create Date: 2022-03-28 15:25:22.965843

"""

# revision identifiers, used by Alembic.
revision = "a7ca9f175d5f"
down_revision = ("d59ff89e7514", "11146ba02235")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
