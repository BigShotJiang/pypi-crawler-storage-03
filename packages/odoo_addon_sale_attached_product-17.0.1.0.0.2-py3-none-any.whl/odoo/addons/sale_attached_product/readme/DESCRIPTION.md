This module allows to define a set of products which will be added
automatically to the sales order whenever that product is present on it.
