To configure attached products:

1.  Go to *Sales \> Products \> Products* and choose on you want to
    attach products to.
2.  Go to the *Sales* tab and then to the *Attached products* section.
3.  Add as many products as you want to.

If you want to autoupdate the products when they are added, set this
config parameter:

> - sale_attached_product.auto_update_attached_lines

Otherwise, the lines will be added, but they can be modified, deleted,
etc.
