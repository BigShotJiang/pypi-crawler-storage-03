from . import product_template
from . import sale_attached_product_mixin
from . import sale_order
