from . import test_sale_attached_product
