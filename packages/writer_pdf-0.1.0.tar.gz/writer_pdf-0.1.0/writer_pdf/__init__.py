# encoding: utf-8
# @File  : __init__.py.py
# @Author: ronin.G
# @Date  : 2025/08/21/16:28
from .writer_pdf import SimplePDFDocument
__version__ = "0.1.0"