This module adds an option to the reception scenario. When activated.
Before setting the quantity for the reception, if there is product
packaging related to the product received with missing information, the
user will be presented with a screen (for each packaging) proposing to
update the missing information.
