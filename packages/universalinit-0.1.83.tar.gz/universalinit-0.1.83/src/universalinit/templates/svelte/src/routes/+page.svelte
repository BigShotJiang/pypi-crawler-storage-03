<svelte:head>
    <title>{KAVIA_TEMPLATE_PROJECT_NAME}</title>
</svelte:head>

<div class="container">
    <p>{KAVIA_TEMPLATE_PROJECT_NAME} is being generated</p>
</div>

<style>
    .container {
        text-align: center;
    }

    p {
        margin: 0;
        font-size: 2rem;
        color: var(--color-text-primary);
    }
</style>
