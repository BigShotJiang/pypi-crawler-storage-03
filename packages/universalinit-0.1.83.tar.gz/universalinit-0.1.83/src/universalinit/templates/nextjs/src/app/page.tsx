export default function Home() {
  return (
    <main className="min-h-screen bg-white flex items-center justify-center">
      <h1 className="text-black text-4xl font-light">
        {KAVIA_TEMPLATE_PROJECT_NAME} is being generated
      </h1>
    </main>
  );
}
