"""Configuration settings for the PEM application."""

DATABASE_URL = "sqlite+aiosqlite:///pem.db"
