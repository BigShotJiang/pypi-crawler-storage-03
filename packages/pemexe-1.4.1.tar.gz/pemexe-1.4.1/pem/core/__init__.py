"""Core functionality for the Python Execution Manager (PEM)."""
