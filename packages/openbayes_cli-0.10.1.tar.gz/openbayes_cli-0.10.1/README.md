# openbayes python cli

## 环境依赖

1. python >= 3.8
2. [poetry](https://python-poetry.org/)

安装好 poetry 后，可以使用以下命令安装依赖：

```bash
poetry install
```

## 使用

通过命令：

```sh
python main.py --help
```

使用命令行。

