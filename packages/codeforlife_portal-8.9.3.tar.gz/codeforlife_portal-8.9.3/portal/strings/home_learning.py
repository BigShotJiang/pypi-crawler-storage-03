HOME_LEARNING_BANNER = {
    "title": "Home learning",
    "subtitle": "Whether you're a parent, a caregiver, or a curious student — our Rapid Router game is easy to use "
    "and free – forever.",
    "text": "",
    "image_class": "banner--picture--homelearning",
}
