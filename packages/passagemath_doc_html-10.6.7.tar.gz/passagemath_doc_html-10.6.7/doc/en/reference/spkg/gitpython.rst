.. _spkg_gitpython:

gitpython: GitPython is a python library used to interact with Git repositories
===============================================================================

Description
-----------

GitPython is a python library used to interact with Git repositories

License
-------

BSD

Upstream Contact
----------------

https://pypi.org/project/GitPython/



Type
----

optional


Dependencies
------------

- $(PYTHON)
- $(PYTHON_TOOLCHAIN)

Version Information
-------------------

requirements.txt::

    GitPython

Equivalent System Packages
--------------------------

(none known)
