# wagtail-newsletter-django-backend

A wagtail-newsletter backend that just uses Django models, views, and mail functionality for everything it needs