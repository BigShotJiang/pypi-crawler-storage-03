"""Metadata for Workflow Linter."""

__version__ = "1.3.4"
