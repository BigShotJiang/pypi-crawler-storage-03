from typing import TypeAlias


Res: TypeAlias = tuple[float, float]
