This is a (possibly incomplete) list of all the contributors to python-networkdays, initially generated from the git author metadata.

The details of their specific contributions can be found in the git history.


If you are not on this list and believe you should be, or you *are* on this list and your information is inaccurate, please open an issue at https://github.com/cadu-leite/networkdays

Contributors (alphabetical order)
=================================


- Carlos Leite (https://github.com/cadu-leite)
- Renzo Nuccitelli (https://github.com/renzon)


