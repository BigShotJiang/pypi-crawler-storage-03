from setuptools import setup

setup(
    name="jailite",
    version="0.0.0a0"
)
