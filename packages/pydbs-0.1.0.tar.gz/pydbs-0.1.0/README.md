# pydb
Basic database methods relying on pandas and scipy (for sparsity). 
