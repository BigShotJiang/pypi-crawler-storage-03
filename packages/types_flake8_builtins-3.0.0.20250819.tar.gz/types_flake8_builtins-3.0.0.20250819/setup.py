
from setuptools import setup

setup(package_data={'flake8_builtins-stubs': ['__init__.pyi', 'METADATA.toml', 'py.typed']})
