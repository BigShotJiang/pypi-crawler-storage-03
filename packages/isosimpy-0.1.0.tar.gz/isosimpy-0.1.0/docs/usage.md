# Usage

1. Start `ISOSIMpy-gui`.
2. Tab **Input**: select CSVs for input and target time series (two columns: date, value). Choose monthly or yearly; choose tracer (Tritium / C-14).
3. Tab **Model Design**: check EPM/PM.
4. Tab **Parameters**: edit bounds, initial values, fixed flags, and unit mixes; steady state and warmup.
5. Tab **Simulation**: run simulation or calibration, view plot and results.
