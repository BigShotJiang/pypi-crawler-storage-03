# ISOSIMpy

A GUI for groundwater age simlations using lumped parameter models.

- **Run**: `ISOSIMpy-gui`
- **Model**: EPM + PM units mixed by fractions; solved with SciPy differential evolution.
