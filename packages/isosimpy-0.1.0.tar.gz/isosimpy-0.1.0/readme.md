# ISOSIMpy

Lumped parameter groundwater age simulations with a simple user interface - in Python
