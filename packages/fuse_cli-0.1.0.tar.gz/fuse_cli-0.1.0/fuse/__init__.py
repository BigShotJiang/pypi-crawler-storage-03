from .__version__ import __version__

__description__ = "Customizable wordlist generator with advanced pattern."
__author__ = "Ryan R."
__name__ = "ravien"
__url__ = "https://github.com/pwnfo/ravien"
