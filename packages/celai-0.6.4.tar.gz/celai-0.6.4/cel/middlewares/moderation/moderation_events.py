class ModMiddlewareEvents:
    on_message_flagged = "on_message_flagged"