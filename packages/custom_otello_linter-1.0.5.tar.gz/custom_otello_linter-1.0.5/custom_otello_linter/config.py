class Config:
    def __init__(self):
        pass


class DefaultConfig(Config):
    def __init__(self):
        super().__init__()
