from .dodgem import Dodgem, EVALMAP
