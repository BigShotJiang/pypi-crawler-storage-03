"""
interfaces to non-existing hardware
"""
