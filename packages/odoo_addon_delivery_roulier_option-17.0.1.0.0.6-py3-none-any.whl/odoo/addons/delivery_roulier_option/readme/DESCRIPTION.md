Manage options for the delivery method. Like insurance or cash on
delivery
