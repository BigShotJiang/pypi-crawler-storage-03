from enum import StrEnum


class DataUpdateType(StrEnum):
    FULL = "full"
    PARTIAL = "partial"
