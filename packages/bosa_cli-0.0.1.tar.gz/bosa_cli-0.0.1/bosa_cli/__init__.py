"""BOSA CLI module for managing integrations and authentication."""

from bosa_cli.main import main

__all__ = ["main"]
