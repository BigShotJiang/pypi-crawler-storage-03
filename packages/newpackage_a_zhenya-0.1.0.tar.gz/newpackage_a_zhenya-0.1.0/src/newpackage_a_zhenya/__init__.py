def main() -> None:
    print("Hello from newpackage!")
