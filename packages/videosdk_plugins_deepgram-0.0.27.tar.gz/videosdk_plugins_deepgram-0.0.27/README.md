# VideoSDK Deepgram Plugin

Agent Framework plugin for STT services from Deepgram.

## Installation

```bash
pip install videosdk-plugins-deepgram
```