This is trex core library project
