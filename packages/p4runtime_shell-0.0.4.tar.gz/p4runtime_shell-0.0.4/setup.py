# Copyright 2021 Yi Tseng
# SPDX-License-Identifier: Apache-2.0

import setuptools

if __name__ == "__main__":
    setuptools.setup()
