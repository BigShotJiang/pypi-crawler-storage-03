"""Base class for document parsers."""

from pdf2markdown.core.interfaces import DocumentParser

__all__ = ["DocumentParser"]
