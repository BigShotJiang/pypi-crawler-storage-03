"""Base class for page parsers."""

from pdf2markdown.core.interfaces import PageParser

__all__ = ["PageParser"]
