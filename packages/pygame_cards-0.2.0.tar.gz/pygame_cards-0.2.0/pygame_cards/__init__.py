"""An object-oriented package for helping using cards in pygame.

Every class has an object class and a graphics class.
The graphics are handled by a manager.
"""
