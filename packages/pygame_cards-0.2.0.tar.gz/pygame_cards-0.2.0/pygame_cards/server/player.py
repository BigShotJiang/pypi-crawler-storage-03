class Player:
    player_id: int
    is_ready: bool
