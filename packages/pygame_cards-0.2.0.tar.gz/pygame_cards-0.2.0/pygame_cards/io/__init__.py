"""Module for input output operation of files.

Each submodule should correspond to one type of file.
"""
