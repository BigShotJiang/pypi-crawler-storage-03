# Pygame Cards

A simple card games for pygame.

Handles graphics and interaction with the mouse and pygame events.

You can check [our official documentation](https://pygame-cards.readthedocs.io)

[![Documentation Status](https://readthedocs.org/projects/pygame-cards/badge/?version=latest)](https://pygame-cards.readthedocs.io/en/latest/?badge=latest)
