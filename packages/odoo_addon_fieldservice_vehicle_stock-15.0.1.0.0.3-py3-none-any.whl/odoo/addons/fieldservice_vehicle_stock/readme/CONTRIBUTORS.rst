* Brian McMaster <brian@mcmpest.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* `APSL-Nagarro <https://www.apsl.tech>`_:
  * Patryk Pyczko <ppyczko@apsl.net>
