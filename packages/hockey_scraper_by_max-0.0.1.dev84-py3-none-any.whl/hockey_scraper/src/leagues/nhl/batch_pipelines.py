# BATCH PIPELINES
# Description: This module contains batch pipelines for the NHL league.
# It includes pipelines for scraping game data, player stats, and team stats in bulk.
