"""MCP Fetch Server test suite."""
