# Principles

- all classes in actions in this "file" section should be the ones that have a dependency of file__config : Schema__Memory_FS__File__Config
- 
# Questions:
 - should this section be renamed to file_fs?
 - is File_FS__* is a better name for the actions, instead of  Memory_FS__File__* 
 