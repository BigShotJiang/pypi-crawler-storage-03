from enum import Enum

class Enum__Memory_FS__File__Exists_Strategy(Enum):
    ALL  : str = 'all'
    ANY  : str = 'any'
    FIRST: str = 'first'
