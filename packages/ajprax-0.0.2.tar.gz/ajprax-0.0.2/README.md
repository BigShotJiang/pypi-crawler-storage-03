## Pure-python utilities with no required dependencies.

### Optional dependencies add functionality when available

* `crcmod`
* `tqdm`
