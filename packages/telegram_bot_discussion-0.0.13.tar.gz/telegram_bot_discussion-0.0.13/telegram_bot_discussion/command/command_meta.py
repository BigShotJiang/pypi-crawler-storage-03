ACTION: str = "action"
TITLE: str = "title"


class CommandMeta:
    action: str
    title: str
