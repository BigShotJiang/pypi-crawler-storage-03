"""
Stash MCP Server for issue analysis and task management.
"""

__version__ = "0.1.4"
__author__ = "Lamberson"
__email__ = "lambersonistaken@gmail.com"

from .main import main

__all__ = ["main"]
