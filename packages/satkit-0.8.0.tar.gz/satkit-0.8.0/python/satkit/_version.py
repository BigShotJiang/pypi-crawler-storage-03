# This file is auto-generated. Update the version here to match pyproject.toml.
__version__ = "0.8.0"
