# rag_orchestrator/batching/__init__.py
# """Batching primitives."""
# from .microbatch import AsyncMicroBatcher
# __all__ = ["AsyncMicroBatcher"]
