from .cmd import anilist

__all__ = ["anilist"]
