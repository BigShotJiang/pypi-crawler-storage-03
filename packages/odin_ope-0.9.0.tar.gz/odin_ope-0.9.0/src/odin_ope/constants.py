"""Protocol constants."""
MESSAGE_FORMAT_VERSION = 1  # increment if core signing string changes incompatibly