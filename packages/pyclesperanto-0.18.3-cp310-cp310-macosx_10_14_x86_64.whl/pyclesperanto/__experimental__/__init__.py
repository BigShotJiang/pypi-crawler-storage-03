from .clahe import clahe  # we keep this import for example purposes
