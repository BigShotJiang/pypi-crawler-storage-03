# Battlenet Client

![Pipeline Status](https://gitlab.com/battlenet-client/api/battlenet-client/badges/main/pipeline.svg)
![Release](https://gitlab.com/battlenet-client/api/battlenet-client/-/badges/release.svg?order_by=release_at)
![coverage](https://gitlab.com/battlenet-client/api/battlenet-client/badges/<branch>/coverage.svg?job=coverage)


## Usage:
[Battlenet Client Documents](https://battlenet-0d8928.gitlab.io/) for full documentation
