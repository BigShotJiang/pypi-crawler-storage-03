:orphan:

.. _theory:

Theoretical background
======================

