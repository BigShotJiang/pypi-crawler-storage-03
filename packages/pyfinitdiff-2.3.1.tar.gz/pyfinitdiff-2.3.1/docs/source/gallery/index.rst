Coding examples
===============


.. toctree::
    :maxdepth: 2
    :hidden:

    triplets/index.rst
    eigenmodes_1d/index.rst
    eigenmodes_2d/index.rst
    extras/index.rst