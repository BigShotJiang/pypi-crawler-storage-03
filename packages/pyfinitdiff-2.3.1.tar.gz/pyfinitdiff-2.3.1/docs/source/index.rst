**Date**: |today|, **Version**: |version|


.. include:: ../../README.rst
    :start-line: 0

.. toctree::
    :maxdepth: 2
    :hidden:

    theory
    code
    gallery/index.rst
    references