1-dimensional
~~~~~~~~~~~~~