.. _examples_gallery:

Examples
========

A gallery of examples and that showcase how PyFinitDiff can be used. Some examples demonstrate the use of the API in general and some demonstrate specific applications in tutorial form.