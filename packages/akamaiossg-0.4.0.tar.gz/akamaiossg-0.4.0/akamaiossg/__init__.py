# sentiebl/__init__.py

from .main import main
from .config import config