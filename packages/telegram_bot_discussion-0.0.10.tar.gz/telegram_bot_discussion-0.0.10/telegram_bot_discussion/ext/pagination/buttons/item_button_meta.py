from ....button import ButtonMeta


class ItemButtonMeta(ButtonMeta):
    action: str = "view"
