#!/usr/bin/env python

"""Tests for `whispywyser` package."""


import unittest

import whispywyser


class TestWhispywyser(unittest.TestCase):
    """Tests for `whispywyser` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
