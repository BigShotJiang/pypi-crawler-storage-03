"""Wyoming server for WhispyWyser."""
__version__ = "0.0.20"
__all__ = ["__version__"]
