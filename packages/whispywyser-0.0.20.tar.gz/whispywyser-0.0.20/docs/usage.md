# Usage

To use WhispyWyser in a project:

```
import whispywyser
```
