# Welcome to whispywyser


[![image](https://img.shields.io/pypi/v/whispywyser.svg)](https://pypi.python.org/pypi/whispywyser)


**The WhispyWyser project is designed to provide a flexible and efficient implementation of Voice Assistant for Home Assistant based on Faster Whisper and Wyoming protocol. This project supports both CPU and CUDA architectures, allowing for optimized performance based on the available hardware.**


-   Free software: MIT License
-   Documentation: <https://cociweb.github.io/whispywyser>
    

## Features

-   TODO
