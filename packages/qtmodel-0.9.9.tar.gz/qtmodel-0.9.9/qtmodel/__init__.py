from .qt_mdb import *
from .qt_odb import *

mdb = Mdb
odb = Odb
