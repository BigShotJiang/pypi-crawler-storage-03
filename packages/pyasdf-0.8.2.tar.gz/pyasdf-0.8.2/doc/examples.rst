Examples
========

This page collect useful examples on how to to some things with ``pyasdf``.

* :doc:`examples/create_observed_asdf_file`
* :doc:`examples/process_observed`
* :doc:`examples/parallel_pyflex`

.. toctree::
    :maxdepth: 1
    :hidden:

    examples/create_observed_asdf_file
    examples/process_observed
    examples/parallel_pyflex
    examples/source_receiver_geometry

