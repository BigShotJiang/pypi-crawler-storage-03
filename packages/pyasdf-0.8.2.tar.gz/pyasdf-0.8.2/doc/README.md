# pyasdf Documentation

**This is the source code of the documentation. For a rendered
view of the documentation go [here](http://seismicdata.github.io/pyasdf/).**
