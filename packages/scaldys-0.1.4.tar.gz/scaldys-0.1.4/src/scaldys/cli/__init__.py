# -*- coding: utf-8 -*-
# cython: language_level=3

from scaldys.cli.commands import *
