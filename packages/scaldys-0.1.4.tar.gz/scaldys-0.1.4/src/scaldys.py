# -*- coding: utf-8 -*-
# cython: language_level=3

from scaldys.cli.cli import app


if __name__ == "__main__":
    app()
