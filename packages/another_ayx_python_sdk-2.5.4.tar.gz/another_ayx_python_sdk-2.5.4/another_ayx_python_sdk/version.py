"""FILE GENERATED FROM SETUP.PY."""
short_version = "2.5.4"
version = "2.5.4"
full_version = "2.5.4"
release = True

if not release:
    version = full_version
