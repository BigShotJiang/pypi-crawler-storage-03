from io import BufferedReader
from struct import unpack
from typing import (
    Any,
    Union,
)
from zlib import (
    crc32,
    decompress,
)

from lz4.frame import LZ4FrameFile
from pandas import DataFrame as PdFrame
from pgcopylib import (
    PGCopy,
    PGDataType,
)
from polars import DataFrame as PlFrame

from .compressor import pgcopy_compressor
from .errors import (
    PGCryptHeaderError,
    PGCryptMetadataCrcError,
)
from .enums import CompressionMethod
from .header import HEADER
from .metadata import metadata_reader
from .offset import OffsetOpener
from .zstdstream import ZstdDecompressionReader


class PGCryptReader:
    """Class for read PGCrypt format."""

    fileobj: BufferedReader
    columns: list[str]
    dtypes: list[PGDataType]
    pgcopy: PGCopy

    header: bytes
    metadata_crc: int
    metadata_length: int
    metadata_zlib: bytes
    compression_method: CompressionMethod
    pgcopy_compressed_length: int
    pgcopy_data_length: int
    offset_opener: OffsetOpener
    pgcopy_compressor: Union[
        OffsetOpener,
        LZ4FrameFile,
        ZstdDecompressionReader,
    ]

    def __init__(
        self,
        fileobj: BufferedReader,
    ) -> None:
        """Class initialization."""

        self.fileobj: BufferedReader = fileobj
        self.header: bytes = self.fileobj.read(8)

        if self.header != HEADER:
            raise PGCryptHeaderError()

        self.metadata_crc, self.metadata_length = unpack(
            "!2L",
            self.fileobj.read(8),
        )
        self.metadata_zlib: bytes = self.fileobj.read(self.metadata_length)

        if crc32(self.metadata_zlib) != self.metadata_crc:
            raise PGCryptMetadataCrcError()

        self.columns, self.dtypes = metadata_reader(
            decompress(self.metadata_zlib)
        )
        (
            compression_method,
            self.pgcopy_compressed_length,
            self.pgcopy_data_length,
        ) = unpack(
            "!B2Q",
            self.fileobj.read(17),
        )

        self.compression_method = CompressionMethod(compression_method)
        self.offset_opener = OffsetOpener(self.fileobj)
        self.pgcopy_compressor = pgcopy_compressor(
            self.offset_opener,
            self.compression_method,
        )
        self.pgcopy = PGCopy(
            self.pgcopy_compressor,
            self.columns,
            self.dtypes,
        )

    def __repr__(self) -> str:
        """String representation in interpreter."""

        return self.__str__()

    def __str__(self) -> str:
        """String representation of PGCryptReader."""

        return f"""<PostgreSQL/GreenPlum encrypted dump>
 -----------
| Dump info |
 -----------
Total columns: {self.pgcopy.num_columns}
Total raws: {self.pgcopy.num_rows}
Compression method: {self.compression_method.name}
Unpacked size: {self.pgcopy_data_length} bytes
Compressed size: {self.pgcopy_compressed_length} bytes
Compression rate: {round(
    (self.pgcopy_compressed_length / self.pgcopy_data_length) * 100, 2
)} %"""

    def to_python(self) -> list[Any]:
        """Convert to python objects."""

        return self.pgcopy.read()

    def to_pandas(self) -> PdFrame:
        """Convert to pandas.DataFrame."""

        return PdFrame(
            data=self.to_python(),
            columns=self.columns,
        )

    def to_polars(self) -> PlFrame:
        """Convert to polars.DataFrame."""

        return PlFrame(
            data=self.to_python(),
            schema=self.columns,
            orient="row",
        )

    def to_bytes(self) -> bytes:
        """Get raw unpacked data."""

        self.pgcopy_compressor.seek(0)

        return self.pgcopy_compressor.read()
