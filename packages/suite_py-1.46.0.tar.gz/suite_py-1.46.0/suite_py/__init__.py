# -*- encoding: utf-8 -*-
from suite_py.__version__ import __version__

if __version__:
    version = __version__
else:
    version = "0.0.1"
