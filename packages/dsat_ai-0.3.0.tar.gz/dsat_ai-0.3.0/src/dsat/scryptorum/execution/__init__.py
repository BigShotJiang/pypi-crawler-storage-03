"""Execution engine components."""
