# sage_setup: distribution = sagemath-eclib
from sage.libs.eclib.constructor import CremonaModularSymbols
from sage.libs.eclib.interface import mwrank_EllipticCurve, mwrank_MordellWeil
from sage.libs.eclib.mwrank import get_precision, set_precision
from sage.libs.eclib.mwrank import initprimes as mwrank_initprimes
