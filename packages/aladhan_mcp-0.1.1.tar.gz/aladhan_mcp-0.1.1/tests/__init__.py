# Tests package for Aladhan MCP server
