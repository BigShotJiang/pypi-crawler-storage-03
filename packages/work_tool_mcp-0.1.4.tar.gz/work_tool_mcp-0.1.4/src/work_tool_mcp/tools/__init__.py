"""Work tool handlers for various file types and operations."""
