"""Constants used throughout the work tool MCP server."""
