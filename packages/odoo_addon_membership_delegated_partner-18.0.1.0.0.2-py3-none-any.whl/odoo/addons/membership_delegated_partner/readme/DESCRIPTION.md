This module allows to delegate a membership line to a partner
independently of the invoicing partner.
