In *Settings \> Users \> \<your_user\>* set *Delegated partner in
membership* permission on.
