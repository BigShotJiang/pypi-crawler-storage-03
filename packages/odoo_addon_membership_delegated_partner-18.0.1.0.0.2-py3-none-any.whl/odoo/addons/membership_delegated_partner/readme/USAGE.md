1.  In an invoice with membership lines, choose a delegated partner.
2.  The membership line will go to the delegated partner.
