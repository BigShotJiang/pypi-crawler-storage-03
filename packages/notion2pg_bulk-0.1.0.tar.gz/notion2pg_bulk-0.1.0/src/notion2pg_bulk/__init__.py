"""
Notion Workspace to PostgreSQL Migration Tool
"""
from .migrator import NotionMigrator

__all__ = ["NotionMigrator"]
