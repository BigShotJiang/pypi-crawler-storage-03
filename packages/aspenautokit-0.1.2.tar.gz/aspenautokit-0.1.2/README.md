This is a generalized automation methodology developed for Aspen Plus simulations.
[GitHub-flavored Markdown](https://github.com/BaileyLadd01/AspenAutoKit)


Issues and requests can be posed via GitHub in the AspenAutoKit repo.