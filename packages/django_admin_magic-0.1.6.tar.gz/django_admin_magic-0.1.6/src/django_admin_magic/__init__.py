default_app_config = "django_admin_magic.apps.DjangoAutoAdminConfig"
