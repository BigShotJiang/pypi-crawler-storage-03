# utils

::: django_admin_magic.utils
