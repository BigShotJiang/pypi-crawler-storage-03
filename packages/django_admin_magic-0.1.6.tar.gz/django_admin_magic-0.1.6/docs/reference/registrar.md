# registrar

::: django_admin_magic.registrar
