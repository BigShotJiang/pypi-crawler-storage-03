# mixins

::: django_admin_magic.mixins
