# EverCode Package

EverCode Python пакет, содержащий данные из файла `test.txt`.

## Установка

```bash
pip install evercode
```

## Использование

```python
from stack import data

# Получить содержимое test.txt
print(data.get_content())
```

## Лицензия

MIT License 