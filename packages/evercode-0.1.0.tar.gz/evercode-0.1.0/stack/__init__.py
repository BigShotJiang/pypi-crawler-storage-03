"""
Stack Package

Тестовый пакет с содержимым из test.txt
"""

__version__ = "0.1.0"
__author__ = "Vladimir"

from .data import get_content

__all__ = ["get_content"] 