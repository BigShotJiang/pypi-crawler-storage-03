########
Citation
########

The preferred citations can be found in the `CITATION`_ file in the project root repository. The contents of this file
are included below for reference.

.. literalinclude:: CITATION.bib
   :lineno-match:
