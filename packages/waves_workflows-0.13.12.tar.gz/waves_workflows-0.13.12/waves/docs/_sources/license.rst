.. _license:

#######
LICENSE
#######

.. include:: README.txt
   :start-after: copyright-start-do-not-remove
   :end-before: copyright-end-do-not-remove

.. include:: LICENSE.txt
