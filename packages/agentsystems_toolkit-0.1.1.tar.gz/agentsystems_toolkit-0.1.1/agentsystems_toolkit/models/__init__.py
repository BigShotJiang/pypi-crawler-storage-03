"""Model routing utilities for AgentSystems agents."""

from .router import get_model

__all__ = ["get_model"]
