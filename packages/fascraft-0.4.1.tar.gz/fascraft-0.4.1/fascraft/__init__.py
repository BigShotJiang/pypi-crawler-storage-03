"""FasCraft - A CLI tool for generating modular FastAPI projects with environment and dependency management."""

__version__ = "0.3.2"
__author__ = "Lutor Iyornumbe"
__email__ = "biggestluey@gmail.com"
