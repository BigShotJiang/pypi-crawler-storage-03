"""
Middleware for MCP authorization.
"""
