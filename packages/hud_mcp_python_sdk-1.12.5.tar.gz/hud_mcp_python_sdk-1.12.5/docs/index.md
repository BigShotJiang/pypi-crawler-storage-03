# MCP Server

This is the MCP Server implementation in Python.

It only contains the [API Reference](api.md) for the time being.
