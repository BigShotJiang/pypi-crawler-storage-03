from os import getcwd
from os.path import join

TEST_RESOURCES = join(getcwd(), "resources")
