"""
Add legacy artifact and its subtypes here.
"""
