"""Premium models"""
