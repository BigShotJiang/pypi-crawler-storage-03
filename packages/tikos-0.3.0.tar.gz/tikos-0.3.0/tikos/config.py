BASE_URL_API="https://api.tikos.tech"
VER="0.3.0"