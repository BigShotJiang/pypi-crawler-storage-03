class DatabaseError(Exception):
    """Database error"""
