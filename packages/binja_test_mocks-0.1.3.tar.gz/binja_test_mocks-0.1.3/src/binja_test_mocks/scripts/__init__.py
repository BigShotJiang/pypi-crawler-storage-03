"""Helper scripts for binja-test-mocks."""
