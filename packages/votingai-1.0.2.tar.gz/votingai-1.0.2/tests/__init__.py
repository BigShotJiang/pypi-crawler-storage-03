"""Tests for votingai."""
