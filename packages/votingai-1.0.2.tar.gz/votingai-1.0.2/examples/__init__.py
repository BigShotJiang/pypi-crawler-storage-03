"""Examples for AutoGen Voting Extension."""
