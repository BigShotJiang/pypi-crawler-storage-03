"""Configuration settings for autogen-voting."""

# Default model (users should provide their own model_client)
DEFAULT_MODEL = "gpt-4o-mini"
MODEL = DEFAULT_MODEL  # Alias for backward compatibility
