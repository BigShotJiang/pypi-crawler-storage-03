2024-05-30 Version: 3.0.21
- Update API AddFaceVideoTemplate: update response param.


2024-03-13 Version: 3.0.20
- Update API QueryFaceVideoTemplate: add param PageNo.
- Update API QueryFaceVideoTemplate: add param PageSize.
- Update API QueryFaceVideoTemplate: update response param.


2023-10-10 Version: 3.0.19
- Generated python 2020-03-20 for videoenhan.

2023-09-14 Version: 3.0.18
- Generated python 2020-03-20 for videoenhan.

2023-08-31 Version: 3.0.17
- Generated python 2020-03-20 for videoenhan.

2023-08-10 Version: 3.0.16
- Generated python 2020-03-20 for videoenhan.

2023-06-12 Version: 3.0.15
- Update AddFaceVideoTemplate and MergeVideoModelFace.

2023-03-28 Version: 3.0.14
- Release ReduceVideoNoise and EnhancePortraitVideo. 

2023-03-03 Version: 3.0.13
- Release GenerateHumanAnimeStyleVideo.

2023-02-22 Version: 3.0.12
- Release GenerateHumanAnimeStyleVideo.

2023-01-13 Version: 3.0.11
- Update sdk.

2023-01-12 Version: 3.0.10
- Update sdk.

2023-01-11 Version: 3.0.9
- Update sdk.

2022-12-16 Version: 3.0.8
- Release MergeVideoModelFace.

2022-12-14 Version: 3.0.7
- Release MergeVideoModelFace.

2022-12-02 Version: 3.0.6
- Release MergeVideoModelFace.

2022-11-30 Version: 3.0.5
- Release MergeVideoModelFace.

2022-11-10 Version: 3.0.4
- Release MergeVideoModelFace.

2022-10-17 Version: 3.0.3
- Release MergeVideoModelFace.

2022-09-29 Version: 3.0.2
- Release MergeVideoModelFace.

2021-04-13 Version: 3.0.1
- Release AddFaceVideoTemplate DeleteFaceVideoTemplate QueryFaceVideoTemplate MergeVideoModelFace.

2020-12-30 Version: 3.0.0
- AMP Version Change.

2020-12-29 Version: 2.0.1
- Release InterpolateVideoFrame ToneSdrVideo ConvertHdrVideo.

2020-12-25 Version: 2.0.0
- Release InterpolateVideoFrame ToneSdrVideo ConvertHdrVideo.

2020-12-25 Version: 1.0.4
- Release InterpolateVideoFrame ToneSdrVideo ConvertHdrVideo.

2020-12-22 Version: 1.0.5
- Release InterpolateVideoFrame ToneSdrVideo ConvertHdrVideo.

2020-12-22 Version: 1.0.4
- Release InterpolateVideoFrame ToneSdrVideo ConvertHdrVideo.

2020-12-02 Version: 1.0.3
- Release MergeVideoFace EnhanceVideoQuality.

