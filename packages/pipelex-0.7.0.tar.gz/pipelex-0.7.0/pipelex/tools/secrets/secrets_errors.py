from pipelex.tools.exceptions import ToolException


class SecretNotFoundError(ToolException):
    pass
