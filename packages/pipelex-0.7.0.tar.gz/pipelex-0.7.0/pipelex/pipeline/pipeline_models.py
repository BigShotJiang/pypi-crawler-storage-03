from pipelex.types import StrEnum


class SpecialPipelineId(StrEnum):
    UNTITLED = "untitled"
