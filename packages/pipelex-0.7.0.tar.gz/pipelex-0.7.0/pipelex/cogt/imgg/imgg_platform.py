from pipelex.types import StrEnum


class ImggPlatform(StrEnum):
    FAL_AI = "fal-ai"
    OPENAI = "openai"
