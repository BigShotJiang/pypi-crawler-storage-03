from snaptrade_client.paths.brokerages_brokerage_id_instruments.get import ApiForget


class BrokeragesBrokerageIdInstruments(
    ApiForget,
):
    pass
