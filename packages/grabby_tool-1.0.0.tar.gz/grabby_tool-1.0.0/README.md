# Grabby CLI

Grabby is a simple command-line tool to download YouTube or Instagram media.  
It supports video downloads up to 1440p (fallback 1080p, 720p) and audio in MP3 (320kbps fallback).

## Installation
```bash
pip install grabby-tool

