"""Views for the VidCleaner application."""

from .tables import stream_table

__all__ = ["stream_table"]
