"""Tests for vidcleaner."""
