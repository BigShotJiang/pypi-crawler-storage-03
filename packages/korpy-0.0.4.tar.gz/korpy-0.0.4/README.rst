korpy
======
korpy is a toolkit for korean texts