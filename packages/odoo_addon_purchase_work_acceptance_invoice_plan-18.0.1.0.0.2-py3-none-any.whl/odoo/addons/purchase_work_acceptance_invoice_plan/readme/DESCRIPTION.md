This module add ability to create Work Acceptance based on the
predefined invoice plan, one by one.

**Note:**

Because WA is now based on invoice plan, the option "Create Bill by
Plan" will be removed.

User will be left with only option "Create Bill" (and to choose WA), the
chosen WA is now used to control the quantity in invoice instead of the
invoice plan.
