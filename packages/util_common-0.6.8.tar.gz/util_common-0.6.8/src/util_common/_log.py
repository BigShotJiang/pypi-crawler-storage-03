import logging

from util_common._cfg import APP_NAME

log = logging.getLogger(APP_NAME)
