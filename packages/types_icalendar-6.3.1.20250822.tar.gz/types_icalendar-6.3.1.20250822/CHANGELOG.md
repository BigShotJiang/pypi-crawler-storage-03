## 6.3.1.20250822 (2025-08-22)

Add missing defaults to third-party stubs ([#14617](https://github.com/python/typeshed/pull/14617))

## 6.3.1.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 6.3.1.20250521 (2025-05-21)

[icalendar] Update to 6.3.1 (#14105)

## 6.3.0.20250517 (2025-05-17)

Bump icalendar to 6.3.* (#14078)

## 6.2.0.20250514 (2025-05-14)

Bump icalendar to 6.2.* (#13963)

## 6.1.3.20250403 (2025-04-03)

Remove Python 3.8 exclusive branches (#13772)

## 6.1.3.20250329 (2025-03-29)

icalendar: update (#13737)

Fixes #13735

## 6.1.2.20250321 (2025-03-21)

[icalendar] Update to 6.1.2 (#13672)

Finish icalendar.prop annotations

## 6.1.0.20250301 (2025-03-01)

Fix conflicting imports (#13561)

## 6.1.0.20250119 (2025-01-19)

icalendar: fix arg name (#13407)

Fixes #13406

## 6.1.0.20250111 (2025-01-11)

Officially drop Python 3.8 support (#13386)

## 6.1.0.20241128 (2024-11-28)

[icalendar] Update to 6.1.* (#13109)

## 6.0.1.20241022 (2024-10-22)

Use compatible version marker for icalendar (#12831)

## 6.0.0.20241015 (2024-10-15)

Bump icalendar to 6.0.1 (#12802)

## 6.0.0.20241003 (2024-10-03)

[icalendar] Update to 6.0.0 (#12706)

## 5.0.0.20240806 (2024-08-06)

Bump mypy to 1.11.1 (#12463)

## 5.0.0.20240409 (2024-04-09)

Add icalendar stubs (#11733)

