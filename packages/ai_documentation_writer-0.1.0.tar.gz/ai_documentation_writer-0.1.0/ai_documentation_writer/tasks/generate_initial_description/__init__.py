"""Tasks for generating initial project description."""

from .generate_initial_description import generate_initial_description_task

__all__ = [
    "generate_initial_description_task",
]
