from .auto_process import slowdown, main

__all__ = ["slowdown", "main"]
