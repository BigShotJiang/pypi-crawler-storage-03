from binsync import create_plugin
create_plugin()
