from os import environ


base_path = environ.get("BASE_PATH", "")
