"""Unit test package for adam."""
