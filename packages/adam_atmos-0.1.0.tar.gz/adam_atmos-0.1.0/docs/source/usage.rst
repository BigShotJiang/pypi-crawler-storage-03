=====
Usage
=====

To use ATMOS Analogue Digital Twin in a project::

    import adam
