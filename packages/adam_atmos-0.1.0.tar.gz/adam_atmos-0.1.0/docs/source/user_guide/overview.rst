Overview
=============================

Within this user guide, we will go into detail on how to infer the lake breeze location from KLOT radar data.
   
     * Loading and preprocessing the data
     * Conducting and visualizing the inference
     