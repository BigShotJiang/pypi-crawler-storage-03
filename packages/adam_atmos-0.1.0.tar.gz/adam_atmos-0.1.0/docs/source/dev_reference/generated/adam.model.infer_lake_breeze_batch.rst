﻿adam.model.infer\_lake\_breeze\_batch
=====================================

.. currentmodule:: adam.model

.. autofunction:: infer_lake_breeze_batch