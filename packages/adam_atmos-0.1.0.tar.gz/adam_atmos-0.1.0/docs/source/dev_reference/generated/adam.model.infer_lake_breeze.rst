﻿adam.model.infer\_lake\_breeze
==============================

.. currentmodule:: adam.model

.. autofunction:: infer_lake_breeze