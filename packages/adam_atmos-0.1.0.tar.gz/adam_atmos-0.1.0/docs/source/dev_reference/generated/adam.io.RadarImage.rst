﻿adam.io.RadarImage
==================

.. currentmodule:: adam.io

.. autoclass:: RadarImage

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RadarImage.__init__
      ~RadarImage.aggregate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~RadarImage.aggregated_mask
      ~RadarImage.grid_lat
      ~RadarImage.grid_lon
      ~RadarImage.lakebreeze_mask
      ~RadarImage.lat_range
      ~RadarImage.lon_range
      ~RadarImage.pyart_object
      ~RadarImage.pytorch_image
      ~RadarImage.times
   
   