# ApiAggregateProperty

Defines the property by which to aggregate the metric. Metrics are grouped based on unique values of the chosen property. Selecting `ALL` aggregates the data into a single group.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


