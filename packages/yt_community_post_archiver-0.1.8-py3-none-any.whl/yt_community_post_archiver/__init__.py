from yt_community_post_archiver.archiver import main

if __name__ == "__main__":
    main()
