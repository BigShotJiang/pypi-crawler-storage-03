"""
MCP Server capabilities package
Contains handlers for different MCP operations
"""
