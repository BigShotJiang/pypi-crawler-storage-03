"""Tests for NDP MCP server."""
