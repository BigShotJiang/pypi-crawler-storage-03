"""
National Data Platform (NDP) MCP Server

This package provides an MCP server for searching and discovering datasets
across multiple CKAN instances in the National Data Platform.
"""

__version__ = "1.0.0"
