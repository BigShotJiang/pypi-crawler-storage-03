"""Lmod MCP server package for environment module management."""

__version__ = "0.1.0"
