"""
ArXiv MCP capabilities.
"""
