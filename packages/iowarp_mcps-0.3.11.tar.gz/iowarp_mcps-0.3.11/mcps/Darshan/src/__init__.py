"""Darshan MCP server package for I/O profiling analysis."""

__version__ = "0.1.0"
