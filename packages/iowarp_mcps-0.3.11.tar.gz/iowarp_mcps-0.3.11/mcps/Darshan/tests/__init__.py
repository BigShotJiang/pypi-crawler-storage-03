"""Tests for darshan-mcp."""
