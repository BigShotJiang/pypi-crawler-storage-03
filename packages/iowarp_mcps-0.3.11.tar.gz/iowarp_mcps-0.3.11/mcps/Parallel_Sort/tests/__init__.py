"""
Test package for Parallel Sort MCP server.
"""
