"""
Capabilities for the Parallel Sort MCP server.
"""
