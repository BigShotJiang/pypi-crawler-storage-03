"""
Parallel Sort MCP server package.
Provides log sorting capabilities via Model Context Protocol.
"""

__version__ = "0.1.0"
