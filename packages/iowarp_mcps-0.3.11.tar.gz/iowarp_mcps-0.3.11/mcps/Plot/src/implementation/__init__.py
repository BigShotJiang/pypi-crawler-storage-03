"""
Plot capabilities package.
"""
