"""
Hardware capabilities package for Node Hardware MCP Server.
"""
