"""
MCP Server test package
Contains test cases for all MCP capabilities
"""
