# Compression capabilities
