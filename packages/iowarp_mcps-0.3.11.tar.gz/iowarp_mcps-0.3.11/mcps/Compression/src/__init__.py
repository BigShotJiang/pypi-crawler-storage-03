"""
Compression MCP Server
A Model Context Protocol server for file compression capabilities.
"""
