"""
Console management package for Proxmox MCP.
"""
from .manager import VMConsoleManager

__all__ = ['VMConsoleManager']
