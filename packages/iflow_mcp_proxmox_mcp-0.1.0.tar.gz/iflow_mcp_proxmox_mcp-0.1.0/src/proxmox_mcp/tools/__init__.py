"""
MCP tools for interacting with Proxmox hypervisors.
"""

__all__ = []
