"""Main module."""

from .mail import send_mail  # noqa
