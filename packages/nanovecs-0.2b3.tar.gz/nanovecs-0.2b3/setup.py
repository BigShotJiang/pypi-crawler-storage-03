from setuptools import setup, find_packages

setup(
    name="nanovecs",
    version="0.2b3",  # etiqueta "ultimate" en el README, la versión en PyPI debe ser PEP440
    description="Mini biblioteca didáctica de embeddings con NumPy + negative sampling",
    author="TuNombre",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.24,<2.0",   # sigue en 1.x, más nueva que 1.20.0
        "tqdm>=4.66",
        "regex>=2023.8.8",
         "micrograd>=0.1.0",
    ],
    entry_points={
        "console_scripts": [
            "nanovecs=nanovecs.nano7_cli:main",
        ]
    },
    include_package_data=True,
)
