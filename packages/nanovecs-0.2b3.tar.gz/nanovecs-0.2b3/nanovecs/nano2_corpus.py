import os, json, csv, random
from tqdm import tqdm

class CorpusLoader:
    """
    Carga corpus con streaming y barajado opcional.
    """
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def load_folder(self, folder, shuffle=False, limit_tokens=None):
        files = [os.path.join(folder, f) for f in os.listdir(folder) if f.endswith(".txt")]
        if shuffle:
            random.shuffle(files)
        tokens, n = [], 0
        for path in tqdm(files, desc="📂 Leyendo TXT"):
            with open(path, "r", encoding="utf-8") as f:
                ts = self.tokenizer.tokenize(f.read())
                for t in ts:
                    tokens.append(t)
                    n += 1
                    if limit_tokens and n >= limit_tokens:
                        return tokens
        return tokens

    def load_csv(self, path, column=0, limit_tokens=None):
        tokens, n = [], 0
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in tqdm(reader, desc="📂 Leyendo CSV"):
                if not row:
                    continue
                for t in self.tokenizer.tokenize(row[column]):
                    tokens.append(t); n += 1
                    if limit_tokens and n >= limit_tokens:
                        return tokens
        return tokens

    def load_jsonl(self, path, key, limit_tokens=None):
        tokens, n = [], 0
        with open(path, "r", encoding="utf-8") as f:
            for line in tqdm(f, desc="📂 Leyendo JSONL"):
                data = json.loads(line)
                if key in data:
                    for t in self.tokenizer.tokenize(data[key]):
                        tokens.append(t); n += 1
                        if limit_tokens and n >= limit_tokens:
                            return tokens
        return tokens
