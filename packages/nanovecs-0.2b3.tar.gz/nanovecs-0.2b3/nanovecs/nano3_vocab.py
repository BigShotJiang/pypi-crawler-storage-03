import json
from collections import Counter

SPECIAL_TOKENS = ["<unk>"]

class Vocab:
    """
    Vocab con min_freq, tokens especiales y congelamiento.
    """
    def __init__(self, max_size=None, min_freq=1, add_specials=True):
        self.word2idx = {}
        self.idx2word = {}
        self.max_size = max_size
        self.min_freq = int(min_freq)
        self.add_specials = bool(add_specials)
        self.frozen = False

    def build(self, tokens):
        counter = Counter(tokens)
        items = [(w, c) for w, c in counter.items() if c >= self.min_freq]
        items.sort(key=lambda x: (-x[1], x[0]))
        if self.max_size:
            items = items[: self.max_size]
        i = 0
        if self.add_specials:
            for sp in SPECIAL_TOKENS:
                self.word2idx[sp] = i; i += 1
        for w, _ in items:
            if w not in self.word2idx:
                self.word2idx[w] = i; i += 1
        self.idx2word = {i: w for w, i in self.word2idx.items()}
        self.frozen = True
        return self

    def encode(self, w: str) -> int:
        if w in self.word2idx:
            return self.word2idx[w]
        return self.word2idx.get("<unk>", None)

    def decode(self, idx: int) -> str:
        return self.idx2word.get(idx, "<unk>")

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"word2idx": self.word2idx,
                       "min_freq": self.min_freq,
                       "max_size": self.max_size,
                       "add_specials": self.add_specials}, f, ensure_ascii=False)

    def load(self, path):
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        self.word2idx = obj["word2idx"]
        self.idx2word = {i: w for w, i in self.word2idx.items()}
        self.min_freq = obj.get("min_freq", 1)
        self.max_size = obj.get("max_size", None)
        self.add_specials = obj.get("add_specials", True)
        self.frozen = True
        return self
