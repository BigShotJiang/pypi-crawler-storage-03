import numpy as np

class Search:
    def __init__(self, embeddings, vocab):
        self.emb = embeddings
        self.vocab = vocab

    def _cosine_all(self, vec):
        A = self.emb.vectors
        denom = (np.linalg.norm(A, axis=1) * (np.linalg.norm(vec) + 1e-9)) + 1e-9
        return np.dot(A, vec) / denom

    def most_similar(self, word, topn=10, exclude=None):
        idx = self.vocab.encode(word)
        if idx is None:
            return []
        if exclude is None:
            exclude = set()
        exclude = set(exclude)
        sims = self._cosine_all(self.emb.vectors[idx])
        order = np.argsort(-sims)
        out = []
        for i in order:
            if i == idx or self.vocab.decode(i) in exclude:
                continue
            out.append((self.vocab.decode(i), float(sims[i])))
            if len(out) >= topn:
                break
        return out

    def analogy(self, a, b, c, topn=10, exclude=None):
        # a : b :: c : ?
        ia, ib, ic = self.vocab.encode(a), self.vocab.encode(b), self.vocab.encode(c)
        if None in (ia, ib, ic):
            return []
        vec = self.emb.vectors[ib] - self.emb.vectors[ia] + self.emb.vectors[ic]
        sims = self._cosine_all(vec)
        order = np.argsort(-sims)
        ex = set(exclude or []) | {a, b, c}
        out = []
        for i in order:
            w = self.vocab.decode(i)
            if w in ex:
                continue
            out.append((w, float(sims[i])))
            if len(out) >= topn:
                break
        return out
