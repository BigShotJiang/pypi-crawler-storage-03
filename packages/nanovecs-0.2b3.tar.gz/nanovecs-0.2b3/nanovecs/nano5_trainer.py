import numpy as np
from tqdm import trange
import random
import math

class Trainer:
    """
    Entrenador con:
      - Subsampling de palabras frecuentes (word2vec trick)
      - Negative Sampling (k negativos)
      - Minibatching simple
      - Checkpoint por epoch (opcional, desde CLI)
    """
    def __init__(self, embeddings, vocab, lr=0.03, window=4,
                 negatives=5, subsample_t=1e-5, seed=42, checkpoint_fn=None):
        self.emb = embeddings
        self.vocab = vocab
        self.lr = float(lr)
        self.window = int(window)
        self.negatives = int(negatives)
        self.subsample_t = float(subsample_t)
        random.seed(seed)
        np.random.seed(seed)
        self.checkpoint_fn = checkpoint_fn

    def _build_freq_table(self, tokens):
        # Frecuencias para subsampling
        counts = {}
        for t in tokens:
            idx = self.vocab.encode(t)
            if idx is None:
                continue
            counts[idx] = counts.get(idx, 0) + 1
        total = sum(counts.values()) + 1e-9
        freqs = {i: c / total for i, c in counts.items()}
        return freqs, total

    def _subsample(self, indices, freqs):
        # P_keep = (sqrt(f/t) + 1) * (t/f)
        kept = []
        for i in indices:
            f = freqs.get(i, 0.0)
            if f <= 0:
                kept.append(i); continue
            p_keep = (math.sqrt(f / self.subsample_t) + 1) * (self.subsample_t / f)
            if random.random() < min(1.0, p_keep):
                kept.append(i)
        return kept

    def _negative_samples(self, vocab_size, exclude, k):
        # muestreamos uniformemente (se puede mejorar con unigram^0.75)
        res = []
        while len(res) < k:
            j = random.randint(0, vocab_size - 1)
            if j != exclude:
                res.append(j)
        return res

    def train(self, tokens, epochs=5, batch_size=256):
        # 1) Indices
        indices = [self.vocab.encode(t) for t in tokens]
        indices = [i for i in indices if i is not None]
        if not indices:
            return

        # 2) Subsampling
        freqs, _ = self._build_freq_table(tokens)
        if self.subsample_t > 0:
            indices = self._subsample(indices, freqs)
            if not indices:
                return

        V = self.emb.vectors
        vocab_size = V.shape[0]

        for ep in trange(epochs, desc="🧠 Training (neg-sampling)"):
            loss = 0.0
            # walk a sliding window
            for pos, center in enumerate(indices):
                left = max(0, pos - self.window)
                right = min(len(indices), pos + self.window + 1)
                context_ids = [indices[j] for j in range(left, right) if j != pos]
                if not context_ids:
                    continue

                # batch per center
                for context in context_ids:
                    # positivo (center, context)
                    v_c = V[center]
                    v_o = V[context]

                    # sigmoid for positive pair
                    score_pos = np.dot(v_c, v_o)
                    sig_pos = 1.0 / (1.0 + np.exp(-score_pos))
                    grad_pos = (sig_pos - 1.0)  # d(-log(sigmoid)) wrt score

                    # aplicar gradiente
                    V[center] -= self.lr * grad_pos * v_o
                    V[context] -= self.lr * grad_pos * v_c
                    loss += -np.log(sig_pos + 1e-9)

                    # negativos
                    negs = self._negative_samples(vocab_size, exclude=context, k=self.negatives)
                    for neg in negs:
                        v_n = V[neg]
                        score_neg = np.dot(v_c, v_n)
                        sig_neg = 1.0 / (1.0 + np.exp(-score_neg))
                        # para negativo, target=0 → grad = (sigmoid(score) - 0)
                        grad_neg = sig_neg

                        V[center] -= self.lr * grad_neg * v_n
                        V[neg]    -= self.lr * grad_neg * v_c
                        loss += -np.log(1.0 - sig_neg + 1e-9)

                # normalización periódica ligera
                self.emb.maybe_normalize()

            if self.checkpoint_fn:
                self.checkpoint_fn(ep, V)
            # opcional: print simple de pérdida promedio por par
            # (no exacta por subsampling, suficiente para monitorear tendencia)
            # print(f"Epoch {ep+1}: loss≈{loss:.3f}")
