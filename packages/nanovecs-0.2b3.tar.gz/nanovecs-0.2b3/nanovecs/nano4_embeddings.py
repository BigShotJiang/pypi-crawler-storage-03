import numpy as np

def xavier_uniform(shape):
    fan_in, fan_out = shape[0], shape[1]
    limit = np.sqrt(6.0 / (fan_in + fan_out))
    return np.random.uniform(-limit, limit, shape).astype(np.float32)

class Embeddings:
    """
    Embeddings con init Xavier y soporte dtype/normalización periódica.
    """
    def __init__(self, vocab_size, dim=64, normalize_every=None, dtype="float32"):
        self.vocab_size = int(vocab_size)
        self.dim = int(dim)
        self.dtype = np.float16 if str(dtype) == "float16" else np.float32
        self.vectors = xavier_uniform((self.vocab_size, self.dim)).astype(self.dtype)
        self._normalize_every = normalize_every
        self._steps = 0

    def maybe_normalize(self):
        if self._normalize_every is None:
            return
        self._steps += 1
        if self._steps % self._normalize_every == 0:
            norms = np.linalg.norm(self.vectors, axis=1, keepdims=True) + 1e-9
            self.vectors = (self.vectors / norms).astype(self.dtype)

    def save(self, path_npz):
        np.savez_compressed(path_npz, vectors=self.vectors)

    def load(self, path_npz):
        data = np.load(path_npz)
        self.vectors = data["vectors"]
        self.vocab_size, self.dim = self.vectors.shape
        self.dtype = self.vectors.dtype
        return self
