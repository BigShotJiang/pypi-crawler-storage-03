import regex as re
import unicodedata

class Tokenizer:
    """
    Tokenizador flexible con perfiles y filtros.
    """
    def __init__(self, lowercase=True, stopwords=None, min_len=1,
                 drop_numbers=True, normalize_nfkc=True, profile="words"):
        self.lowercase = lowercase
        self.stopwords = set(stopwords or [])
        self.min_len = int(min_len)
        self.drop_numbers = bool(drop_numbers)
        self.normalize_nfkc = bool(normalize_nfkc)
        # perfiles: "words" (solo letras) o "alnum" (letras y números)
        self.profile = profile
        self._pat_words = re.compile(r"\p{L}+", flags=re.UNICODE)
        self._pat_alnum = re.compile(r"\p{L}+\p{N}*|\p{N}+", flags=re.UNICODE)

    def _normalize(self, text: str) -> str:
        if self.normalize_nfkc:
            text = unicodedata.normalize("NFKC", text)
        if self.lowercase:
            text = text.lower()
        return text

    def tokenize(self, text: str):
        text = self._normalize(text)
        pat = self._pat_alnum if self.profile == "alnum" else self._pat_words
        toks = pat.findall(text)
        out = []
        for t in toks:
            if self.drop_numbers and t.isnumeric():
                continue
            if len(t) < self.min_len:
                continue
            if t in self.stopwords:
                continue
            out.append(t)
        return out
