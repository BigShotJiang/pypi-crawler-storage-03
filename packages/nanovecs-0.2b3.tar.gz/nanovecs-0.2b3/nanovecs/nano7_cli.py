import argparse, os
from .nano1_tokenizer import Tokenizer
from .nano2_corpus import CorpusLoader
from .nano3_vocab import Vocab
from .nano4_embeddings import Embeddings
from .nano5_trainer import Trainer
from .nano6_search import Search

def save_ckpt_factory(outdir, vocab):
    os.makedirs(outdir, exist_ok=True)
    def _fn(epoch, V):
        path = os.path.join(outdir, f"emb_epoch{epoch+1}.npz")
        import numpy as np
        np.savez_compressed(path, vectors=V)
    return _fn

def main():
    parser = argparse.ArgumentParser("nanovecs")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_train = sub.add_parser("train")
    p_train.add_argument("--corpus_dir", type=str, default="examples")
    p_train.add_argument("--epochs", type=int, default=10)
    p_train.add_argument("--dim", type=int, default=64)
    p_train.add_argument("--window", type=int, default=4)
    p_train.add_argument("--lr", type=float, default=0.03)
    p_train.add_argument("--negatives", type=int, default=5)
    p_train.add_argument("--subsample_t", type=float, default=1e-5)
    p_train.add_argument("--normalize_every", type=int, default=5000)
    p_train.add_argument("--dtype", type=str, default="float32", choices=["float32", "float16"])
    p_train.add_argument("--limit_tokens", type=int, default=None)
    p_train.add_argument("--outdir", type=str, default="checkpoints_b3")

    p_sim = sub.add_parser("similar")
    p_sim.add_argument("--model", type=str, required=True)
    p_sim.add_argument("--vocab", type=str, required=True)
    p_sim.add_argument("--word", type=str, required=True)
    p_sim.add_argument("--topn", type=int, default=10)

    p_ana = sub.add_parser("analogy")
    p_ana.add_argument("--model", type=str, required=True)
    p_ana.add_argument("--vocab", type=str, required=True)
    p_ana.add_argument("--a", type=str, required=True)
    p_ana.add_argument("--b", type=str, required=True)
    p_ana.add_argument("--c", type=str, required=True)
    p_ana.add_argument("--topn", type=int, default=10)

    p_info = sub.add_parser("info")
    p_info.add_argument("--model", type=str, required=True)

    args = parser.parse_args()

    if args.cmd == "train":
        tok = Tokenizer(lowercase=True, min_len=2)
        loader = CorpusLoader(tok)
        tokens = loader.load_folder(args.corpus_dir, shuffle=True, limit_tokens=args.limit_tokens)
        print(f"🔤 tokens: {len(tokens)}")

        vocab = Vocab(min_freq=2, add_specials=True).build(tokens)
        print(f"📘 vocab: {len(vocab.word2idx)}")

        emb = Embeddings(len(vocab.word2idx), dim=args.dim,
                         normalize_every=args.normalize_every, dtype=args.dtype)

        trainer = Trainer(
            emb, vocab, lr=args.lr, window=args.window,
            negatives=args.negatives, subsample_t=args.subsample_t,
            checkpoint_fn=save_ckpt_factory(args.outdir, vocab)
        )
        trainer.train(tokens, epochs=args.epochs)

        vocab_path = os.path.join(args.outdir, "vocab.json")
        model_path = os.path.join(args.outdir, "emb_final.npz")
        vocab.save(vocab_path)
        emb.save(model_path)
        print(f"✅ guardado en {args.outdir}")

    elif args.cmd == "similar":
        from .nano3_vocab import Vocab
        from .nano4_embeddings import Embeddings
        v = Vocab().load(args.vocab)
        e = Embeddings(1,1).load(args.model)
        s = Search(e, v)
        out = s.most_similar(args.word, topn=args.topn)
        for w, sc in out:
            print(f"{w}\t{sc:.3f}")

    elif args.cmd == "analogy":
        from .nano3_vocab import Vocab
        from .nano4_embeddings import Embeddings
        v = Vocab().load(args.vocab)
        e = Embeddings(1,1).load(args.model)
        s = Search(e, v)
        out = s.analogy(args.a, args.b, args.c, topn=args.topn)
        for w, sc in out:
            print(f"{w}\t{sc:.3f}")

    elif args.cmd == "info":
        from .nano4_embeddings import Embeddings
        e = Embeddings(1,1).load(args.model)
        print(f"Embeddings: shape={e.vectors.shape}, dtype={e.vectors.dtype}")
