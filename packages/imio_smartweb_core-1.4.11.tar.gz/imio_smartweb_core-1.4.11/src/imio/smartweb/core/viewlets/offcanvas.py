# -*- coding: utf-8 -*-
from imio.smartweb.core.browser.search.search import Search


class OffCanvasViewlet(Search):
    """"""
