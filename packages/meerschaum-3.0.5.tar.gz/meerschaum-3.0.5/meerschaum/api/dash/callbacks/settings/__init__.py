#! /usr/bin/env python3
# vim:fenc=utf-8

"""
Define the callbacks for the settings pages.
"""

import meerschaum.api.dash.callbacks.settings.password_reset
