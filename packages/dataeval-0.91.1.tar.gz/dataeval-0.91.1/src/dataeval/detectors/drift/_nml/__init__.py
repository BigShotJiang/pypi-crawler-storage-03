"""
Source code derived from NannyML 0.13.0
https://github.com/NannyML/nannyml/

Licensed under Apache Software License (Apache 2.0)
"""
