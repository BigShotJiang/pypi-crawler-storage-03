__version__ = "20.85"
proto_sha1 = "7345fcc54b3417b811b442641635da6a41b1690b"
proto_conan_version = "v20"
