def test_readonly_simple() -> bool:
    """Basic smoke test: prints and returns True."""
    print("Read-only test")
    return True
