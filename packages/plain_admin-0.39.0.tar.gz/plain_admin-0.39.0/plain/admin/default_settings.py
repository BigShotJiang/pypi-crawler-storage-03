ADMIN_TOOLBAR_CLASS = "plain.admin.toolbar.Toolbar"
ADMIN_TOOLBAR_VERSION: str = "dev"
