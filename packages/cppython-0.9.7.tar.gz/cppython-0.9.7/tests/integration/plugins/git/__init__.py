"""Git plugin integration tests"""
