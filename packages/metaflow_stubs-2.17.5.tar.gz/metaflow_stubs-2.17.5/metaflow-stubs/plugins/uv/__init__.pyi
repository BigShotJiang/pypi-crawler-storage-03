######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.5                                                                                 #
# Generated on 2025-08-25T21:01:36.434340                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

