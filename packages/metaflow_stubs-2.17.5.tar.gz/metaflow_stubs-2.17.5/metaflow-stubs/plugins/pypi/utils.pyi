######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.5                                                                                 #
# Generated on 2025-08-25T21:01:36.455393                                                            #
######################################################################################################

from __future__ import annotations


from ..._vendor.packaging import tags as tags
from ...exception import MetaflowException as MetaflowException

MICROMAMBA_URL: str

MICROMAMBA_MIRROR_URL: str

def conda_platform():
    ...

def wheel_tags(wheel):
    ...

def pip_tags(python_version, mamba_platform):
    ...

def parse_filename_from_url(url):
    ...

