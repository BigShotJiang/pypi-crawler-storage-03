######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.5                                                                                 #
# Generated on 2025-08-25T21:01:36.424893                                                            #
######################################################################################################

from __future__ import annotations



def copy_tree(src, dst, update = False):
    ...

def sync_local_metadata_to_datastore(metadata_local_dir, task_ds):
    ...

def sync_local_metadata_from_datastore(metadata_local_dir, task_ds):
    ...

