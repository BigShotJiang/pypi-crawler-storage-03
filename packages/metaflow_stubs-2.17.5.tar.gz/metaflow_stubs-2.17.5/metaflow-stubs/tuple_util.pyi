######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.5                                                                                 #
# Generated on 2025-08-25T21:01:36.396911                                                            #
######################################################################################################

from __future__ import annotations



def namedtuple_with_defaults(typename, field_descr, defaults = ()):
    ...

foreach_frame_field_list: list

