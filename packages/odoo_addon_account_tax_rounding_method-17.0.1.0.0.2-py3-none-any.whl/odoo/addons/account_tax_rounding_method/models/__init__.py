from . import account_move
from . import account_tax
from . import res_company
from . import res_config_settings
from . import res_currency
from . import res_partner
