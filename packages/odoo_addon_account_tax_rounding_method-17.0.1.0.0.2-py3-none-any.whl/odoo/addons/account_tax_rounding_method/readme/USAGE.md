With the tax rounding method set to "Half-up", if you create an invoice in JPY with the
following line:

- Quantity: 1
- Unit Price: 15
- Tax: 10% (excluded)

the calculated tax amount will be 2.

With the tax rounding method set to "Round-up", if you create an invoice in JPY with the
following line:

- Quantity: 1
- Unit Price: 13
- Tax: 10% (excluded)

the calculated tax amount will be 2.

With the tax rounding method set to "Round-down", if you create an invoice in JPY with the
following line:

- Quantity: 1
- Unit Price: 15
- Tax: 10% (excluded)

the calculated tax amount will be 1.
