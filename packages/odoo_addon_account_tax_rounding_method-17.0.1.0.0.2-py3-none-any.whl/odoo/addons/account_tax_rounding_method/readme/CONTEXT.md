By default, Odoo uses the "HALF-UP" method to round tax amounts. However, in some
regions, such as Japan, some industries have a common practice of rounding down instead.
This module accommodates various regional practices by providing configurable tax rounding
options: Half-up, Round-up, and Round-down.
