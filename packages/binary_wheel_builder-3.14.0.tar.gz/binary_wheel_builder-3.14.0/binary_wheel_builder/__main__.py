if __name__ == "__main__":
    from binary_wheel_builder.cli.main import main

    main()
