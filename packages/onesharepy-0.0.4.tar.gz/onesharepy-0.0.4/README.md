# onesharepy
Download personal onedrive files.

## Installation

```bash
pip install git+https://github.com/xiongzhen/onesharepy.git
```

## Usage
```bash
python -m onesharepy
```
