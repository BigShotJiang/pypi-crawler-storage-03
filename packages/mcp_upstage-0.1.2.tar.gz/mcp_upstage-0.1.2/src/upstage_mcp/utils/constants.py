"""Constants for Upstage MCP server."""

# Common constants used across modules
MB = 1024 * 1024  # 1MB in bytes
MINUTE = 60
