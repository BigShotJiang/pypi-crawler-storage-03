AMBER
=====

## Quick Installation

For the latest published version install through

```
python -m pip AMBER-ds4ms
```

For the latest nighly version

```
python -m pip install git+https://gitea.psi.ch/lass_j/AMBER.git@main
```



## Documentation and Tutorials

Further details are found in our [documentation](https://amber-ds4ms.readthedocs.io/) 


