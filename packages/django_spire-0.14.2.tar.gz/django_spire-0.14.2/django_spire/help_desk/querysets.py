from django_spire.history.querysets import HistoryQuerySet

class HelpDeskTicketQuerySet(HistoryQuerySet):
    pass