class DjangoSpireException(Exception):
    pass
