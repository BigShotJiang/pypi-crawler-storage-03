from django.test import TestCase


class SpireChildAppViewTestCase(TestCase):
    def setUp(self):
        super().setUp()
