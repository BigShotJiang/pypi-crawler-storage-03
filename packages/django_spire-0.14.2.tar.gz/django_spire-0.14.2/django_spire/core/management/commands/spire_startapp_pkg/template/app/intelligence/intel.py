from __future__ import annotations

from dandy.intel import BaseIntel


class SpireChildAppIntel(BaseIntel):
    data: dict
