class SemanticResolutionError(Exception):
    """Raised when there's an error during semantic resolution."""

    pass
