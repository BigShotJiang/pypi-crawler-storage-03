from binance.client import Client
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from itertools import product
import requests
import time


class Sirifi_C_Backtester:
    def __init__(self, symbol: str, intervals=None, days: int = 30,
                 fee: float = 0.001, slippage_pct: float = 0.0005):
        """
        symbol: trading pair symbol like 'BTCUSDC'
        intervals: list of intervals to test e.g. ['5m','15m','1h','4h']
        days: how many days of historical data to fetch
        fee: trading fee percentage (e.g. 0.001 for 0.1%)
        slippage_pct: slippage percentage on entry/exit prices
        """
        if intervals is None:
            intervals = ['15m', '1h', '4h']

        assert isinstance(symbol, str) and symbol.endswith("USDC"), "Symbol must be a valid USDC pair string"
        assert all(i in ['1m','3m','5m','15m','30m','1h','2h','4h','6h','8h','12h','1d'] for i in intervals), \
            "Intervals must be valid Binance intervals"
        assert days > 0, "Days must be positive"
        assert 0 <= fee <= 0.01, "Fee must be small float (0 <= fee <= 0.01)"
        assert 0 <= slippage_pct <= 0.01, "Slippage must be small float (0 <= slippage_pct <= 0.01)"

        self.symbol = symbol  # Trading symbol like BTCUSDC
        self.intervals = intervals  # List of intervals to optimize over
        self.days = days  # Historical days to fetch
        self.fee = fee  # Trading fee per trade (fraction)
        self.slippage_pct = slippage_pct  # Slippage fraction applied to entry/exit

        self.client = Client()  # Binance Client instance
        self.best_result = None
        self.best_interval = None
        self.best_result_df = None

    def _fetch_data(self, interval):
        # Fetch historical klines for symbol and interval
        start_time = (datetime.utcnow() - timedelta(days=self.days)).strftime('%d %b %Y %H:%M:%S')
        klines = self.client.get_historical_klines(self.symbol, interval, start_time)
        df = pd.DataFrame(klines, columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_asset_volume', 'number_of_trades',
            'taker_buy_base', 'taker_buy_quote', 'ignore'
        ])
        df = df[['timestamp', 'open', 'high', 'low', 'close']]
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)
        for col in ['open', 'high', 'low', 'close']:
            df[col] = df[col].astype(float)
        df['Returns'] = df['close'].pct_change()
        return df.dropna()

    def _compute_indicators(self, df, fast, slow, signal, rsi_period):
        # MACD calculation: difference of fast and slow EMA of close price
        ema_fast = df['close'].ewm(span=fast, adjust=False).mean()
        ema_slow = df['close'].ewm(span=slow, adjust=False).mean()
        macd = ema_fast - ema_slow
        signal_line = macd.ewm(span=signal, adjust=False).mean()

        # RSI calculation: relative strength index over rsi_period
        delta = df['close'].diff()
        gain = delta.clip(lower=0).rolling(window=rsi_period).mean()
        loss = -delta.clip(upper=0).rolling(window=rsi_period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))

        df['MACD'] = macd
        df['Signal'] = signal_line
        df['RSI'] = rsi
        return df.dropna()

    def _apply_strategy(self, df, rsi_oversold, rsi_overbought, stop_loss_pct, take_profit_pct):
        position = 0
        entry_price = 0
        returns = []

        for i in range(1, len(df)):
            price = df['close'].iloc[i]
            prev_price = df['close'].iloc[i - 1]
            macd_val = df['MACD'].iloc[i]
            signal_val = df['Signal'].iloc[i]
            rsi_val = df['RSI'].iloc[i]

            ret = 0

            if position == 0:
                # Entry condition: MACD crosses above signal and RSI below oversold threshold
                if macd_val > signal_val and rsi_val < rsi_oversold:
                    position = 1
                    entry_price = price * (1 + self.slippage_pct)  # account for slippage on entry
                    ret -= self.fee  # pay trading fee
            elif position == 1:
                # Calculate profit/loss
                pl = (price - entry_price) / entry_price

                # Exit conditions: stop loss or take profit reached
                if pl <= -stop_loss_pct or pl >= take_profit_pct:
                    exit_price = price * (1 - self.slippage_pct)  # slippage on exit
                    trade_return = (exit_price - entry_price) / entry_price
                    trade_return -= self.fee  # pay fee on exit
                    ret += trade_return
                    position = 0
                    entry_price = 0
                else:
                    # Hold position: accumulate return from price movement
                    ret += (price - prev_price) / prev_price

            returns.append(ret)

        df = df.iloc[1:].copy()
        df['Strategy_Returns'] = returns
        df['Cumulative'] = (1 + df['Strategy_Returns']).cumprod()

        total_return = df['Cumulative'].iloc[-1] - 1
        max_drawdown = (df['Cumulative'] / df['Cumulative'].cummax() - 1).min()
        std = df['Strategy_Returns'].std()
        sharpe = df['Strategy_Returns'].mean() / std * np.sqrt(24 * 365) if std > 0 else np.nan  # annualized Sharpe
        trades = (df['Strategy_Returns'] != 0).sum()
        buy_hold_return = df['close'].iloc[-1] / df['close'].iloc[0] - 1

        metrics = {
            'Total Return': total_return,
            'Max Drawdown': max_drawdown,
            'Sharpe Ratio': sharpe,
            'Buy & Hold Return': buy_hold_return,
            'Trades': trades
        }

        return metrics, df

    def _optimize(self):
        # Parameter ranges with some wider range for thorough search
        fast_vals = [8, 12, 16, 20]         # Short-term EMA
        slow_vals = [26, 35, 50]            # Long-term EMA
        signal_vals = [6, 9, 12]            # Signal line EMA
        rsi_periods = [10, 14, 20]          # RSI lookback period
        rsi_oversold_vals = [25, 30, 35]    # Buy threshold
        rsi_overbought_vals = [60, 65, 70]  # Sell threshold (not used in MACD logic here)
        stop_loss_vals = [0.01, 0.02, 0.03] # Stop-loss % per trade
        take_profit_vals = [0.03, 0.05, 0.07] # Take-profit % per trade

        best_result = None
        best_df = None
        best_sharpe = -np.inf
        best_interval = None

        for interval in self.intervals:
            try:
                df_raw = self._fetch_data(interval)
            except Exception as e:
                print(f"Error fetching data for {self.symbol} interval {interval}: {e}")
                continue

            # Iterate all parameter combinations
            for params in product(fast_vals, slow_vals, signal_vals, rsi_periods,
                                  rsi_oversold_vals, rsi_overbought_vals,
                                  stop_loss_vals, take_profit_vals):
                fast, slow, signal, rsi_p, rsi_oversold, rsi_overbought, sl, tp = params
                if fast >= slow or rsi_oversold >= rsi_overbought:
                    continue
                try:
                    df = self._compute_indicators(df_raw.copy(), fast, slow, signal, rsi_p)
                    metrics, result_df = self._apply_strategy(df, rsi_oversold, rsi_overbought, sl, tp)
                    if metrics['Sharpe Ratio'] > best_sharpe:
                        best_sharpe = metrics['Sharpe Ratio']
                        best_result = {
                            'Symbol': self.symbol,
                            'Interval': interval,
                            'MACD Fast': fast,
                            'MACD Slow': slow,
                            'MACD Signal': signal,
                            'RSI Period': rsi_p,
                            'RSI Oversold': rsi_oversold,
                            'RSI Overbought': rsi_overbought,
                            'Stop Loss %': sl,
                            'Take Profit %': tp,
                            **metrics
                        }
                        best_df = result_df
                        best_interval = interval
                except Exception:
                    continue

        self.best_result = best_result
        self.best_interval = best_interval
        self.best_result_df = best_df
        return best_result, best_df


import pandas as pd
import numpy as np
import requests
from binance.client import Client
from binance.enums import SIDE_BUY, SIDE_SELL, ORDER_TYPE_MARKET
from datetime import datetime


class Sirifi_C_TradingBot:
    def __init__(self, symbol: str, interval: str, params: dict,
                 api_key: str = None, api_secret: str = None,
                 fee: float = 0.001, slippage_pct: float = 0.0005,
                 enable_telegram: bool = False,
                 telegram_token: str = None, telegram_chat_id: str = None):
        """
        :param symbol: Trading pair like 'BTCUSDC'
        :param interval: Binance interval like '1h', '15m'
        :param params: Strategy parameters (dict)
        :param api_key: Binance API Key
        :param api_secret: Binance Secret Key
        :param fee: Trading fee (e.g., 0.001 for 0.1%)
        :param slippage_pct: Slippage percent (e.g., 0.0005 = 0.05%)
        :param enable_telegram: Enable Telegram alerts
        :param telegram_token: Telegram bot token
        :param telegram_chat_id: Telegram chat ID
        """
        assert symbol.endswith('USDC'), "Only USDC pairs are supported"
        self.symbol = symbol
        self.interval = interval
        self.params = params
        self.fee = fee
        self.slippage_pct = slippage_pct

        self.client = Client(api_key, api_secret)
        self.enable_telegram = enable_telegram
        self.telegram_token = telegram_token
        self.telegram_chat_id = telegram_chat_id

        self.position = 0
        self.entry_price = None

    def fetch_ohlcv(self, lookback: int = 100):
        klines = self.client.get_klines(symbol=self.symbol, interval=self.interval, limit=lookback)
        df = pd.DataFrame(klines, columns=[
            'open_time', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_asset_volume', 'number_of_trades',
            'taker_buy_base', 'taker_buy_quote', 'ignore'
        ])
        df['close'] = df['close'].astype(float)
        df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
        df.set_index('open_time', inplace=True)
        return df

    def compute_indicators(self, df):
        # MACD calculation
        ema_fast = df['close'].ewm(span=self.params['macd_fast'], adjust=False).mean()
        ema_slow = df['close'].ewm(span=self.params['macd_slow'], adjust=False).mean()
        macd = ema_fast - ema_slow
        signal = macd.ewm(span=self.params['macd_signal'], adjust=False).mean()

        # RSI calculation
        delta = df['close'].diff()
        gain = delta.clip(lower=0).rolling(window=self.params['rsi_period']).mean()
        loss = -delta.clip(upper=0).rolling(window=self.params['rsi_period']).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))

        df['MACD'] = macd
        df['Signal'] = signal
        df['RSI'] = rsi
        return df.dropna()

    def notify(self, message: str):
        if not self.enable_telegram:
            print("[Telegram Disabled] " + message)
            return
        url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        payload = {
            'chat_id': self.telegram_chat_id,
            'text': message,
            'parse_mode': 'Markdown'
        }
        try:
            response = requests.post(url, data=payload)
            if response.status_code != 200:
                print(f"Telegram error: {response.text}")
        except Exception as e:
            print(f"Failed to send Telegram message: {e}")

    def get_balance(self, asset: str) -> float:
        balances = self.client.get_account()['balances']
        for b in balances:
            if b['asset'] == asset:
                return float(b['free'])
        return 0

    def place_order(self, side: str, quantity: float):
        try:
            order = self.client.create_order(
                symbol=self.symbol,
                side=side,
                type=ORDER_TYPE_MARKET,
                quantity=quantity
            )
            return order
        except Exception as e:
            self.notify(f"⚠️ Order error: {e}")
            return None

    def get_price(self) -> float:
        ticker = self.client.get_symbol_ticker(symbol=self.symbol)
        return float(ticker['price'])

    def get_portfolio_value(self) -> float:
        usdc = self.get_balance('USDC')
        coin = self.get_balance(self.symbol.replace('USDC', ''))
        coin_price = self.get_price()
        return usdc + coin * coin_price

    def run_once(self):
        df = self.fetch_ohlcv()
        df = self.compute_indicators(df)
        macd = df['MACD'].iloc[-1]
        signal = df['Signal'].iloc[-1]
        rsi = df['RSI'].iloc[-1]
        close = df['close'].iloc[-1]

        print(f"{self.symbol} - MACD: {macd:.4f}, Signal: {signal:.4f}, RSI: {rsi:.2f}, Price: {close:.4f}")

        if self.position == 0:
            if macd > signal and rsi < self.params['rsi_oversold']:
                usdc = self.get_balance('USDC')
                amount = usdc * 0.10  # risk 10% of portfolio
                qty = round(amount / close, 5)
                if qty > 0:
                    order = self.place_order(SIDE_BUY, qty)
                    if order:
                        self.position = 1
                        self.entry_price = close * (1 + self.slippage_pct)
                        port_val = self.get_portfolio_value()
                        self.notify(f"✅ Bought {qty} {self.symbol} at approx {self.entry_price:.4f}\n"
                                    f"Portfolio value: ${port_val:.2f}")
        elif self.position == 1:
            pnl = (close - self.entry_price) / self.entry_price
            if pnl <= -self.params['stop_loss']:
                self._sell(close, reason="🛑 Stop Loss")
            elif pnl >= self.params['take_profit']:
                self._sell(close, reason="🎯 Take Profit")

    def _sell(self, price, reason):
        asset = self.symbol.replace('USDC', '')
        qty = round(self.get_balance(asset), 5)
        if qty > 0:
            order = self.place_order(SIDE_SELL, qty)
            if order:
                self.position = 0
                self.entry_price = None
                port_val = self.get_portfolio_value()
                self.notify(f"{reason} - Sold {qty} {self.symbol} at approx {price:.4f}\n"
                            f"Portfolio value: ${port_val:.2f}")

    def run_loop(self, sleep_sec=3600):
        import time
        self.notify(f"🤖 Started trading bot on {self.symbol}")
        while True:
            try:
                self.run_once()
            except Exception as e:
                self.notify(f"⚠️ Error: {e}")
            time.sleep(sleep_sec)

