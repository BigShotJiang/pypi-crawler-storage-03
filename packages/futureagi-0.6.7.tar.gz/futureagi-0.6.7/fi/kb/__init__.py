from fi.kb.client import KnowledgeBase
from fi.kb.types import KnowledgeBaseConfig

__all__ = ["KnowledgeBaseConfig", "KnowledgeBase"]