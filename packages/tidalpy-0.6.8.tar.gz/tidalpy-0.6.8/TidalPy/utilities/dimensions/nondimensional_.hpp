#pragma once

class NonDimensionalScalesCC
{
public:
    double second2_conversion;
    double second_conversion;
    double length_conversion;
    double length3_conversion;
    double density_conversion;
    double mass_conversion;
    double pascal_conversion;
};
