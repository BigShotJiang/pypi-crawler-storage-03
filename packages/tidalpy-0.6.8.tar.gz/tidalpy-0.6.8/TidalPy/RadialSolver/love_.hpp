#pragma once


void find_love_cf(
    double* complex_love_numbers_ptr,  // These are double pointers that pointer to a double complex array.
    double* surface_solutions_ptr,     // Same as above
    double surface_gravity);
