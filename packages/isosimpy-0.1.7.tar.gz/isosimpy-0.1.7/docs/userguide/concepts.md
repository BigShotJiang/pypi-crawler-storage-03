# Concepts

ISOSIMpy uses the convolution integral as a central concept.
