from django.apps import AppConfig

class AsyncFrameworkConfig(AppConfig):
    name = 'async_framework'
    verbose_name = "Django Async Framework"
