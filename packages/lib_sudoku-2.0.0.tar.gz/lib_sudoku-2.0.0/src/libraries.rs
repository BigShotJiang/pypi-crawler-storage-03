pub mod puzzle_reader;
pub mod puzzle_solver;
pub mod speedtest;
pub mod puzzle_generator;
