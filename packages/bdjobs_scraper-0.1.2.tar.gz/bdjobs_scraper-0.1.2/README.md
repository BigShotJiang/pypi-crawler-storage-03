# bdjobs-scraper

A Python package to scrape job details from bdjobs.com.

## Installation

```bash
pip install bdjobs-scraper
```
## Usage
```python
from bdjobs_scraper import scrape_by_url

scrape_by_url("<BDJOBS_JOBLINK>") #e.g. https://jobs.bdjobs.com/jobdetails/?id=112233
```
