from enum import Enum

class ColumnMappingEnum(Enum):
    CATEGORY = "category"
    VARIABLE_NAME = "variable_name"