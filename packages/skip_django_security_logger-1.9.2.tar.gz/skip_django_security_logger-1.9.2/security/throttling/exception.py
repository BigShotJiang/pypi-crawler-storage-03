class ThrottlingException(Exception):
    pass
