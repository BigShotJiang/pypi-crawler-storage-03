VERSION = (1, 9, 2)


def get_version():
    return '.'.join(map(str, VERSION))
