# %%
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R
from scipy.spatial.transform import Slerp


def get_lidar_files(path: Path) -> list[Path]:
    """Get all .bin files in the given directory."""
    return sorted(path.glob("*.bin"))


# %%
def read_lidar(file_path: Path) -> np.ndarray:
    """Read a .bin file and return the point cloud as a numpy array."""
    raw = np.fromfile(
        file_path,
        dtype=[
            ("x", np.uint16),
            ("y", np.uint16),
            ("z", np.uint16),
            ("i", np.uint8),
            ("l", np.uint8),
        ],
    )
    points = np.empty((raw.shape[0], 5), dtype=np.float32)
    points[:, 0] = raw["x"].astype(np.float32) * 0.005 - 100.0
    points[:, 1] = raw["y"].astype(np.float32) * 0.005 - 100.0
    points[:, 2] = raw["z"].astype(np.float32) * 0.005 - 100.0
    points[:, 3] = raw["i"].astype(np.float32)
    points[:, 4] = raw["l"].astype(np.float32)
    return points


# %%
def load_global_poses(file_path: Path) -> tuple[np.ndarray, np.ndarray]:
    """
    Load global poses from a text file.
    Args:
        file_path (Path): Path to the text file containing the poses.
    Returns:
        tuple[np.ndarray, np.ndarray]: A tuple containing:
            - An array of shape (N,) containing the timestamps.
            - An array of shape (N, 6) containing the poses (x, y, z, roll, pitch, yaw).
    """
    data = []
    for row in np.loadtxt(file_path, delimiter=","):
        if np.any(np.isnan(row)):
            continue
        data.append(row)
    data = np.array(data)
    return data[:, 0].astype(int), data[:, 1:]


# %%
def transform_point_cloud(points: np.ndarray, T: np.ndarray) -> np.ndarray:
    """
    Transforms a point cloud using a transformation matrix.
    Args:
        points (np.ndarray): A numpy array of shape (N, 3) containing the points.
        T (np.ndarray): A 4x4 transformation matrix.
    Returns:
        np.ndarray: A numpy array of shape (N, 3) containing the transformed points.
    """
    assert points.shape[1] == 3, "Points should be of shape (N, 3)."
    assert T.shape == (4, 4), "Transformation matrix should be of shape (4, 4)."
    num = points.shape[0]
    points_homogeneous = np.hstack((points, np.ones((num, 1))))
    return (T @ points_homogeneous.T).T[:, :3]


def interpolate_pose(stamp: int, gstamps: np.ndarray, gposes: np.ndarray) -> np.ndarray:
    """
    Interpolates the pose for a given timestamp using linear interpolation.
    Args:
        stamp (int): The timestamp for which to interpolate the pose.
        gstamps (np.ndarray(N,)): An array of timestamps corresponding to the global poses.
        gposes (np.ndarray(N,4,4)): An array of 4x4 transformation matrices representing the global poses.
    Returns:
        np.ndarray: A 4x4 numpy array representing the interpolated pose.
    """
    assert gstamps.ndim == 1 and gposes.ndim == 2
    assert gstamps.shape[0] == gposes.shape[0]
    assert gposes.shape[1] == 6

    pose = np.eye(4)
    pose[0, 3] = np.interp(stamp, gstamps, gposes[:, 0])
    pose[1, 3] = np.interp(stamp, gstamps, gposes[:, 1])
    pose[2, 3] = np.interp(stamp, gstamps, gposes[:, 2])
    roll = np.interp(stamp, gstamps, gposes[:, 3])
    pitch = np.interp(stamp, gstamps, gposes[:, 4])
    yaw = np.interp(stamp, gstamps, gposes[:, 5])
    r = R.from_euler("XYZ", [roll, pitch, yaw])
    pose[:3, :3] = r.as_matrix()
    return pose


# %% 调试用代码


def _debug_read_all():
    from pypcd4.pypcd4 import PointCloud
    import matplotlib.pyplot as plt

    files = get_lidar_files(Path("/ws/data/nclt/2012-05-26/velodyne_sync"))
    gstamps, gposes = load_global_poses(
        Path("/ws/data/nclt/groundtruth_2012-05-26.csv")
    )
    clds = []
    poses = []
    T_frd_flu = np.array([[0, 1, 0, 0], [1, 0, 0, 0], [0, 0, -1, 0], [0, 0, 0, 1]])
    T_world_p0 = np.eye(4)
    T_world_p0[:3, 3] = gposes[0, :3]
    T_world_p0[:3, :3] = R.from_euler("XYZ", gposes[0, 3:]).as_matrix()
    T_world_p0 = np.linalg.inv(T_world_p0)
    for file in files[::10]:
        stamp = int(file.stem)
        points = read_lidar(file)
        pose = interpolate_pose(stamp, gstamps, gposes)
        points_ned = transform_point_cloud(points[:, :3], pose)
        points_map = transform_point_cloud(points_ned, T_frd_flu @ T_world_p0)
        points_map = np.hstack((points_map, points[:, 3:]))
        clds.append(points_map)
        poses.append(pose)

    poses = np.array(poses)
    plt.scatter(poses[:, 0, 3], poses[:, 1, 3])
    plt.axis("equal")

    clds = np.concatenate(clds, axis=0)
    clds = clds[np.random.choice(clds.shape[0], size=int(1e6), replace=False)]
    pc = PointCloud.from_xyzil_points(clds)
    pc.save(open("/ws/nclt-dataloader/nclt.pcd", "wb"))


if __name__ == "__main__":
    _debug_read_all()
