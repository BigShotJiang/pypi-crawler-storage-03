# %%
from collections.abc import Iterator
from enum import Enum, auto
from pathlib import Path
from typing import overload
from scipy.spatial.transform import Rotation as R

import numpy as np

from .basic import (
    get_lidar_files,
    load_global_poses,
    read_lidar,
    transform_point_cloud,
    interpolate_pose,
)

VLP_DIR = "velodyne_sync"


class FrameID(Enum):
    BASE_LINK = auto()
    MAP = auto()
    MAP_FRD = auto()
    WORLD = auto()
    WORLD_NED = auto()

    @classmethod
    def help(cls) -> str:
        names = [f"FrameID.{e.name}: {e.__doc__}" for e in FrameID]
        return f"Valid frame_id choices:\n\t{'\n\t'.join(names)}"


FrameID.BASE_LINK.__doc__ = "Vehicle frame"
FrameID.MAP.__doc__ = "Map frame (origin at first lidar scan in FLU)"
FrameID.MAP_FRD.__doc__ = "Map frame (origin at first lidar scan in FRD)"
FrameID.WORLD.__doc__ = "World frame (ground truth poses but in ENU)"
FrameID.WORLD_NED.__doc__ = "World frame (original NED frame from dataset)"

T_FRD_FLU = np.array(
    [
        [0, 1, 0, 0],
        [1, 0, 0, 0],
        [0, 0, -1, 0],
        [0, 0, 0, 1],
    ]
)


# %%
class PointCloudLoader:
    def __init__(self, root_dir: str, frame_id: FrameID = FrameID.MAP):
        # 处理输入参数
        if not isinstance(frame_id, FrameID):
            raise TypeError(
                f"frame_id must be an instance of FrameID, got {type(frame_id)}\n"
                f"{FrameID.help()}"
            )
        self._frame_id = frame_id
        self.data_dir = Path(root_dir) / VLP_DIR
        assert self.data_dir.exists(), f"data_dir {root_dir} does not exist"
        seq = Path(root_dir).stem
        ground_truth_path = Path(root_dir).parent / f"groundtruth_{seq}.csv"
        assert ground_truth_path.exists(), (
            f"Ground truth file {ground_truth_path} does not exist"
        )

        # 加载点云文件和位姿
        self.lidar_files = get_lidar_files(self.data_dir)
        self.gstamps, self.gposes = load_global_poses(ground_truth_path)

        # 计算变换矩阵
        T = np.eye(4)
        T[:3, 3] = self.gposes[0, :3]
        T[:3, :3] = R.from_euler("XYZ", self.gposes[0, 3:]).as_matrix()
        self.T_world_map_frd = np.linalg.inv(T)

    def __len__(self) -> int:
        return len(self.lidar_files)

    @property
    def frame_id(self) -> FrameID:
        return self._frame_id

    @frame_id.setter
    def frame_id(self, value: FrameID) -> None:
        if not isinstance(value, FrameID):
            raise TypeError(
                f"frame_id must be an instance of FrameID, got {type(value)}\n"
                f"{FrameID.help()}"
            )
        self._frame_id = value

    def __get_one(self, idx: int) -> tuple[np.ndarray, np.ndarray]:
        if idx < 0 or idx >= len(self):
            raise IndexError(f"Index {idx} out of range [0, {len(self)})")

        lidar_path = self.lidar_files[idx]
        stamp = int(lidar_path.stem)
        cld = read_lidar(lidar_path)  # (N, 5)
        mtx = np.eye(4)
        if self.frame_id == FrameID.BASE_LINK:
            pass
        else:
            pose = interpolate_pose(stamp, self.gstamps, self.gposes)
            if self.frame_id == FrameID.MAP:
                mtx = T_FRD_FLU @ self.T_world_map_frd @ pose
            elif self.frame_id == FrameID.MAP_FRD:
                mtx = self.T_world_map_frd @ pose
            elif self.frame_id == FrameID.WORLD:
                mtx = T_FRD_FLU @ pose
            elif self.frame_id == FrameID.WORLD_NED:
                mtx = pose
            else:
                raise ValueError(f"Unsupported frame_id {self.frame_id}")
        cld_t = transform_point_cloud(cld[:, :3], mtx)
        return np.hstack((cld_t, cld[:, 3:])), mtx

    @overload
    def __getitem__(self, idx: int) -> tuple[np.ndarray, np.ndarray]:
        """
        Returns the LiDAR point cloud and transformation matrix for a single index.
        Args:
            idx (int): The index of the LiDAR data to retrieve.
        Returns:
            tuple[np.ndarray, np.ndarray]: A tuple containing the point cloud and transformation matrix.
        """
        ...

    @overload
    def __getitem__(self, idx: slice) -> list[tuple[np.ndarray, np.ndarray]]:
        """
        Returns the LiDAR point clouds and transformation matrices for a slice of indices.
        Args:
            idx (slice): A slice object specifying the range of indices to retrieve.
        Returns:
            Iterator[tuple[np.ndarray, np.ndarray]]: An iterator of tuples, each containing a point cloud and transformation matrix.
        """
        ...

    @overload
    def __getitem__(self, idx: np.ndarray) -> list[tuple[np.ndarray, np.ndarray]]:
        """
        Returns the LiDAR point clouds and transformation matrices for an array of indices.
        Args:
            idx (np.ndarray): A numpy array of indices to retrieve.
        Returns:
            Iterator[tuple[np.ndarray, np.ndarray]]: An iterator of tuples, each containing a point cloud and transformation matrix.
        """
        ...

    def __getitem__(
        self, idx: int | slice | np.ndarray
    ) -> tuple[np.ndarray, np.ndarray] | list[tuple[np.ndarray, np.ndarray]]:
        if isinstance(idx, int):
            ret = self.__get_one(idx)
        elif isinstance(idx, slice):
            start, stop, step = idx.indices(len(self))
            ret = list(map(self.__get_one, range(start, stop, step)))
        elif isinstance(idx, np.ndarray):
            if idx.dtype == np.int_:
                ret = list(map(self.__get_one, idx))
            else:
                raise TypeError("Index array must be of integer type.")
        else:
            raise TypeError(
                "Index must be an integer, slice, or numpy array of integers."
            )
        return ret

    def __iter__(self) -> Iterator[tuple[np.ndarray, np.ndarray]]:
        return map(self.__get_one, range(len(self)))


# %% 测试用代码
def _debug_read_all(frame_id: FrameID):
    from pypcd4.pypcd4 import PointCloud

    loader = PointCloudLoader("/ws/data/nclt/2012-05-26", frame_id=frame_id)
    clds = []
    for cld, _ in loader[::10]:
        clds.append(cld)
    clds = np.concatenate(clds, axis=0)
    clds = clds[np.random.choice(clds.shape[0], size=int(1e6), replace=False)]
    pc = PointCloud.from_xyzil_points(clds)
    pc.save(open("/ws/nclt-dataloader/nclt.pcd", "wb"))


if __name__ == "__main__":
    _debug_read_all(FrameID.WORLD_NED)
