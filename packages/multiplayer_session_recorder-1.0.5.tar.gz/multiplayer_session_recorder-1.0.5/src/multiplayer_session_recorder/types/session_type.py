from enum import Enum

class SessionType(Enum):
    PLAIN = 'PLAIN'
    CONTINUOUS = 'CONTINUOUS'
