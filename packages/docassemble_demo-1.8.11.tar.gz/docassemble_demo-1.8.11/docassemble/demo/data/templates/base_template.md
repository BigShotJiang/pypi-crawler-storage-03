This is my favorite way to begin a document.

Thus beginneth the document.

