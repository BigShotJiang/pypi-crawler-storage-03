"""
Tests package for PyPackHelper.
"""

# This allows the tests to be run as a package
