from .DRİVE import Control
from .DRİVE import give
from .DRİVE import info
from .DRİVE import delete
from .DRİVE import get