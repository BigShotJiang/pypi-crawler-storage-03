# 🚀 Google Colab MCP Server

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![MCP Compatible](https://img.shields.io/badge/MCP-Compatible-green.svg)](https://modelcontextprotocol.io/)

A comprehensive **Model Context Protocol (MCP)** server that seamlessly integrates Google Colab with AI assistants like Claude, ChatGPT, and other MCP-compatible tools.

## ✨ Features

- 🔐 **Automatic OAuth2 Authentication** - One-time setup with Google
- 📚 **Complete Notebook Management** - Create, read, update, and list notebooks
- 🤖 **Code Execution** - Run Python code directly in Colab environments
- 📦 **Package Management** - Install Python packages in Colab
- 📁 **File Operations** - Upload files to Colab environments
- 🔄 **Session Management** - Handle Colab runtime sessions
- 🛡️ **Error Handling** - Robust error handling and user-friendly messages

## 🎯 Use Cases

- **AI-Powered Data Science**: Let AI assistants create and run data analysis notebooks
- **Automated ML Workflows**: Build machine learning pipelines through natural language
- **Educational Tools**: Create interactive coding tutorials and examples
- **Research Automation**: Automate repetitive research tasks in Colab
- **Code Generation**: Generate and test code snippets in a cloud environment

## 🚀 Quick Start

### 1. Installation

```bash
pip install mcp-colab-server
```

Or install from source:
```bash
git clone https://github.com/inkbytefo/mcp-colab-server.git
cd mcp-colab-server
pip install -e .
```

### 2. Google Cloud Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the **Google Drive API**
4. Create **OAuth 2.0 credentials** (Desktop Application)
5. Download `credentials.json` and place it in the `config/` folder

### 3. Authentication Setup

Run the automatic setup script:

```bash
mcp-colab-setup
```

This will:
- ✅ Validate your credentials file
- 🌐 Open browser for Google authentication
- 💾 Save authentication tokens for future use
- ✨ Test the connection

### 4. MCP Integration

Add to your MCP configuration (`.kiro/settings/mcp.json` or similar):

```json
{
  "mcpServers": {
    "mcp-colab-server": {
      "command": "mcp-colab-server",
      "args": [],
      "env": {
        "MCP_COLAB_LOG_LEVEL": "INFO"
      }
    }
  }
}
```

## 🛠️ Available Tools

| Tool | Description | Example Usage |
|------|-------------|---------------|
| `create_colab_notebook` | Create a new Colab notebook | "Create a notebook called 'Data Analysis'" |
| `list_notebooks` | List all your Colab notebooks | "Show me my Colab notebooks" |
| `get_notebook_content` | Get notebook content | "Show me the content of my latest notebook" |
| `run_code_cell` | Execute Python code in Colab | "Run this code: import pandas as pd" |
| `install_package` | Install Python packages | "Install matplotlib in my notebook" |
| `upload_file_to_colab` | Upload files to Colab | "Upload data.csv to my notebook" |
| `get_runtime_info` | Get runtime information | "What's the status of my Colab runtime?" |
| `get_session_info` | Get session details | "Show me my current Colab session" |

## 💬 Example Conversations

**With Claude/ChatGPT:**

> **You:** "Create a new Colab notebook for analyzing sales data"
> 
> **AI:** Creates notebook and responds with notebook URL and ID

> **You:** "Install pandas and matplotlib, then create a simple plot"
> 
> **AI:** Installs packages and generates plotting code in your Colab

> **You:** "List all my notebooks and show me the most recent one"
> 
> **AI:** Lists notebooks and displays the content of the latest one

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   AI Assistant  │◄──►│  MCP Server      │◄──►│  Google Colab   │
│  (Claude, etc.) │    │  (This Project)  │    │   Notebooks     │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              ▼
                       ┌──────────────────┐
                       │  Google Drive    │
                       │      API         │
                       └──────────────────┘
```

The server acts as a bridge between AI assistants and Google Colab, using:
- **Google Drive API** for notebook management
- **Selenium WebDriver** for code execution
- **MCP Protocol** for AI assistant communication

## 🔧 Configuration

### Server Configuration (`config/server_config.json`)

```json
{
  "selenium": {
    "browser": "chrome",
    "headless": true,
    "timeout": 30
  },
  "colab": {
    "execution_timeout": 300,
    "max_retries": 3
  },
  "logging": {
    "level": "INFO"
  }
}
```

### MCP Configuration Options

```json
{
  "mcpServers": {
    "mcp-colab-server": {
      "command": "mcp-colab-server",
      "args": [],
      "env": {
        "MCP_COLAB_LOG_LEVEL": "INFO",
        "MCP_COLAB_HEADLESS": "true"
      },
      "autoApprove": [
        "list_notebooks",
        "get_notebook_content"
      ]
    }
  }
}
```

## 🐛 Troubleshooting

### Common Issues

**Authentication Failed**
```bash
# Re-run the setup script
mcp-colab-setup

# Or manually delete token and re-authenticate
rm config/token.json
```

**Selenium WebDriver Issues**
```bash
# Update Chrome/Firefox to latest version
# Or install specific WebDriver version
pip install webdriver-manager --upgrade
```

**MCP Connection Failed**
```bash
# Check if server starts manually
mcp-colab-server

# Verify MCP configuration
# Ensure package is installed correctly
pip show mcp-colab-server
```

### Debug Mode

Enable detailed logging:

```json
{
  "env": {
    "MCP_COLAB_LOG_LEVEL": "DEBUG",
    "MCP_COLAB_HEADLESS": "false"
  }
}
```

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Model Context Protocol](https://modelcontextprotocol.io/) for the amazing protocol
- [Google Colab](https://colab.research.google.com/) for the fantastic platform
- [Anthropic](https://www.anthropic.com/) for Claude and MCP development

## 📞 Support

- 📖 [Documentation](docs/)
- 🐛 [Issue Tracker](https://github.com/inkbytefo/mcp-colab-server/issues)
- 💬 [Discussions](https://github.com/inkbytefo/mcp-colab-server/discussions)

---

**Author:** inkbytefo  
**Made with ❤️ for the AI and Data Science community**