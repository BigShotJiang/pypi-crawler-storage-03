"""Selenium automation for direct Google Colab interaction."""

import logging
import time
import re
from typing import Dict, List, Optional, Any, Tuple
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException, 
    WebDriverException,
    StaleElementReferenceException
)
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

from .session_manager import SessionManager, SessionStatus, RuntimeType
from .utils import retry_with_backoff, format_execution_time


class ColabSeleniumManager:
    """Manages Selenium automation for Google Colab."""
    
    def __init__(self, config: Dict[str, Any], session_manager: SessionManager):
        """Initialize the Selenium manager."""
        self.config = config
        self.selenium_config = config.get("selenium", {})
        self.colab_config = config.get("colab", {})
        self.session_manager = session_manager
        self.logger = logging.getLogger(__name__)
        
        # Configuration
        self.browser_type = self.selenium_config.get("browser", "chrome").lower()
        self.headless = self.selenium_config.get("headless", False)
        self.timeout = self.selenium_config.get("timeout", 30)
        self.implicit_wait = self.selenium_config.get("implicit_wait", 10)
        self.page_load_timeout = self.selenium_config.get("page_load_timeout", 30)
        self.execution_timeout = self.colab_config.get("execution_timeout", 300)
        
        # Colab URLs
        self.base_url = self.colab_config.get("base_url", "https://colab.research.google.com")
        
        # WebDriver instance
        self.driver: Optional[webdriver.Remote] = None
        self.current_notebook_id: Optional[str] = None
    
    def _create_driver(self) -> webdriver.Remote:
        """Create and configure WebDriver instance."""
        try:
            if self.browser_type == "chrome":
                options = webdriver.ChromeOptions()
                if self.headless:
                    options.add_argument("--headless")
                options.add_argument("--no-sandbox")
                options.add_argument("--disable-dev-shm-usage")
                options.add_argument("--disable-gpu")
                options.add_argument("--window-size=1920,1080")
                
                service = ChromeService(ChromeDriverManager().install())
                driver = webdriver.Chrome(service=service, options=options)
                
            elif self.browser_type == "firefox":
                options = webdriver.FirefoxOptions()
                if self.headless:
                    options.add_argument("--headless")
                
                service = FirefoxService(GeckoDriverManager().install())
                driver = webdriver.Firefox(service=service, options=options)
                
            else:
                raise ValueError(f"Unsupported browser type: {self.browser_type}")
            
            # Configure timeouts
            driver.implicitly_wait(self.implicit_wait)
            driver.set_page_load_timeout(self.page_load_timeout)
            
            self.logger.info(f"Created {self.browser_type} WebDriver instance")
            return driver
            
        except Exception as e:
            self.logger.error(f"Failed to create WebDriver: {e}")
            raise
    
    def _ensure_driver(self) -> None:
        """Ensure WebDriver is available and functional."""
        if self.driver is None:
            self.driver = self._create_driver()
        else:
            try:
                # Test if driver is still responsive
                self.driver.current_url
            except WebDriverException:
                self.logger.warning("WebDriver became unresponsive, creating new instance")
                self._close_driver()
                self.driver = self._create_driver()
    
    def _close_driver(self) -> None:
        """Close WebDriver instance."""
        if self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                self.logger.warning(f"Error closing WebDriver: {e}")
            finally:
                self.driver = None
    
    @retry_with_backoff(max_retries=3, delay=2.0)
    def open_notebook(self, notebook_id: str) -> bool:
        """Open a Colab notebook in the browser."""
        try:
            self._ensure_driver()
            
            # Construct Colab URL
            notebook_url = f"{self.base_url}/drive/{notebook_id}"
            
            self.logger.info(f"Opening notebook: {notebook_url}")
            self.driver.get(notebook_url)
            
            # Wait for page to load
            WebDriverWait(self.driver, self.timeout).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Check if we need to sign in
            if "accounts.google.com" in self.driver.current_url:
                self.logger.warning("Google sign-in required - please authenticate manually")
                return False
            
            # Wait for Colab interface to load
            self._wait_for_colab_interface()
            
            self.current_notebook_id = notebook_id
            self.session_manager.update_session_status(notebook_id, SessionStatus.CONNECTED)
            
            self.logger.info(f"Successfully opened notebook: {notebook_id}")
            return True
            
        except TimeoutException:
            self.logger.error("Timeout waiting for notebook to load")
            self.session_manager.update_session_status(notebook_id, SessionStatus.ERROR, "Timeout loading notebook")
            return False
        except Exception as e:
            self.logger.error(f"Error opening notebook: {e}")
            self.session_manager.update_session_status(notebook_id, SessionStatus.ERROR, str(e))
            return False
    
    def _wait_for_colab_interface(self) -> None:
        """Wait for Colab interface elements to load."""
        # Wait for the main content area
        WebDriverWait(self.driver, self.timeout).until(
            EC.any_of(
                EC.presence_of_element_located((By.CSS_SELECTOR, "[data-testid='notebook-container']")),
                EC.presence_of_element_located((By.CSS_SELECTOR, ".notebook-container")),
                EC.presence_of_element_located((By.CSS_SELECTOR, "#main-content"))
            )
        )
        
        # Additional wait for dynamic content
        time.sleep(2)
    
    def _find_code_cells(self) -> List:
        """Find all code cells in the notebook."""
        try:
            # Try multiple selectors for code cells
            selectors = [
                "[data-testid='code-cell']",
                ".code-cell",
                ".cell.code_cell",
                "div[role='textbox'][contenteditable='true']"
            ]
            
            for selector in selectors:
                cells = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if cells:
                    return cells
            
            return []
            
        except Exception as e:
            self.logger.error(f"Error finding code cells: {e}")
            return []
    
    def _create_new_code_cell(self) -> Optional[Any]:
        """Create a new code cell."""
        try:
            # Try to find and click the "Add code cell" button
            add_cell_selectors = [
                "[data-testid='add-code-cell']",
                "button[aria-label*='Add code']",
                ".add-cell-button",
                "colab-add-cell-button"
            ]
            
            for selector in add_cell_selectors:
                try:
                    add_button = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    add_button.click()
                    time.sleep(1)  # Wait for cell to be created
                    
                    # Return the newly created cell
                    cells = self._find_code_cells()
                    if cells:
                        return cells[-1]  # Return the last cell (newly created)
                    
                except TimeoutException:
                    continue
            
            # Alternative: Use keyboard shortcut
            try:
                self.driver.find_element(By.TAG_NAME, "body").send_keys(Keys.CONTROL + Keys.ALT + "n")
                time.sleep(1)
                cells = self._find_code_cells()
                if cells:
                    return cells[-1]
            except Exception:
                pass
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error creating new code cell: {e}")
            return None
    
    def execute_code(self, notebook_id: str, code: str) -> Dict[str, Any]:
        """Execute code in a Colab notebook."""
        try:
            # Ensure notebook is open
            if self.current_notebook_id != notebook_id:
                if not self.open_notebook(notebook_id):
                    raise Exception("Failed to open notebook")
            
            self.session_manager.update_session_status(notebook_id, SessionStatus.BUSY)
            self.session_manager.mark_session_active(notebook_id)
            
            # Find or create a code cell
            cells = self._find_code_cells()
            if not cells:
                cell = self._create_new_code_cell()
                if not cell:
                    raise Exception("Could not find or create code cell")
            else:
                cell = cells[-1]  # Use the last cell
            
            # Clear existing content and enter new code
            self._enter_code_in_cell(cell, code)
            
            # Execute the cell
            execution_result = self._execute_cell(cell)
            
            self.session_manager.update_session_status(notebook_id, SessionStatus.CONNECTED)
            
            return {
                'success': True,
                'output': execution_result.get('output', ''),
                'error': execution_result.get('error'),
                'execution_time': execution_result.get('execution_time', 0),
                'cell_type': 'code'
            }
            
        except Exception as e:
            self.logger.error(f"Error executing code: {e}")
            self.session_manager.update_session_status(notebook_id, SessionStatus.ERROR, str(e))
            return {
                'success': False,
                'output': '',
                'error': str(e),
                'execution_time': 0,
                'cell_type': 'code'
            }
    
    def _enter_code_in_cell(self, cell, code: str) -> None:
        """Enter code into a cell."""
        try:
            # Click on the cell to focus it
            cell.click()
            time.sleep(0.5)
            
            # Clear existing content
            cell.send_keys(Keys.CONTROL + "a")
            cell.send_keys(Keys.DELETE)
            
            # Enter new code
            cell.send_keys(code)
            
        except Exception as e:
            self.logger.error(f"Error entering code in cell: {e}")
            raise
    
    def _execute_cell(self, cell) -> Dict[str, Any]:
        """Execute a code cell and return results."""
        try:
            start_time = time.time()
            
            # Execute cell using Shift+Enter
            cell.send_keys(Keys.SHIFT + Keys.ENTER)
            
            # Wait for execution to complete
            output, error = self._wait_for_execution_complete()
            
            execution_time = time.time() - start_time
            
            return {
                'output': output,
                'error': error,
                'execution_time': execution_time
            }
            
        except Exception as e:
            self.logger.error(f"Error executing cell: {e}")
            return {
                'output': '',
                'error': str(e),
                'execution_time': 0
            }
    
    def _wait_for_execution_complete(self) -> Tuple[str, Optional[str]]:
        """Wait for cell execution to complete and return output."""
        try:
            # Wait for execution indicators to appear and disappear
            max_wait_time = self.execution_timeout
            start_time = time.time()
            
            # Look for execution indicators
            execution_indicators = [
                "[data-testid='cell-execution-indicator']",
                ".cell-execution-indicator",
                ".running-indicator"
            ]
            
            # Wait for execution to start (indicator appears)
            execution_started = False
            while time.time() - start_time < 10:  # Wait up to 10 seconds for execution to start
                for indicator_selector in execution_indicators:
                    indicators = self.driver.find_elements(By.CSS_SELECTOR, indicator_selector)
                    if indicators:
                        execution_started = True
                        break
                
                if execution_started:
                    break
                
                time.sleep(0.5)
            
            # Wait for execution to complete (indicator disappears)
            if execution_started:
                while time.time() - start_time < max_wait_time:
                    indicators_present = False
                    for indicator_selector in execution_indicators:
                        indicators = self.driver.find_elements(By.CSS_SELECTOR, indicator_selector)
                        if indicators:
                            indicators_present = True
                            break
                    
                    if not indicators_present:
                        break
                    
                    time.sleep(1)
            
            # Extract output and errors
            output = self._extract_cell_output()
            error = self._extract_cell_error()
            
            return output, error
            
        except Exception as e:
            self.logger.error(f"Error waiting for execution: {e}")
            return "", str(e)
    
    def _extract_cell_output(self) -> str:
        """Extract output from the most recent cell execution."""
        try:
            output_selectors = [
                "[data-testid='cell-output']",
                ".cell-output",
                ".output",
                ".output_area"
            ]
            
            for selector in output_selectors:
                outputs = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if outputs:
                    # Get the last output (most recent)
                    return outputs[-1].text
            
            return ""
            
        except Exception as e:
            self.logger.error(f"Error extracting cell output: {e}")
            return ""
    
    def _extract_cell_error(self) -> Optional[str]:
        """Extract error from the most recent cell execution."""
        try:
            error_selectors = [
                "[data-testid='cell-error']",
                ".cell-error",
                ".error",
                ".output_error"
            ]
            
            for selector in error_selectors:
                errors = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if errors:
                    return errors[-1].text
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error extracting cell error: {e}")
            return None
    
    def install_package(self, notebook_id: str, package_name: str) -> Dict[str, Any]:
        """Install a Python package in Colab."""
        install_code = f"!pip install {package_name}"
        return self.execute_code(notebook_id, install_code)
    
    def upload_file(self, notebook_id: str, file_path: str) -> Dict[str, Any]:
        """Upload a file to Colab (using code approach)."""
        upload_code = f"""
from google.colab import files
import os

# Upload file
uploaded = files.upload()

# List uploaded files
for filename in uploaded.keys():
    print(f"Uploaded: {{filename}} ({{len(uploaded[filename])}} bytes)")
"""
        return self.execute_code(notebook_id, upload_code)
    
    def get_runtime_info(self, notebook_id: str) -> Dict[str, Any]:
        """Get runtime information from Colab."""
        info_code = """
import psutil
import platform
import sys

print("System Information:")
print(f"Platform: {platform.platform()}")
print(f"Python version: {sys.version}")
print(f"CPU count: {psutil.cpu_count()}")
print(f"Memory: {psutil.virtual_memory().total / (1024**3):.1f} GB")

# Check for GPU
try:
    import torch
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / (1024**3):.1f} GB")
    else:
        print("GPU: Not available")
except ImportError:
    print("GPU: PyTorch not available")
"""
        return self.execute_code(notebook_id, info_code)
    
    def close(self) -> None:
        """Close the Selenium manager and cleanup resources."""
        self._close_driver()
        self.current_notebook_id = None
        self.logger.info("Selenium manager closed")
    
    def __del__(self):
        """Cleanup on destruction."""
        self.close()