"""Utility functions for the Google Colab MCP server."""

import json
import logging
import os
import time
from typing import Any, Dict, Optional
from pathlib import Path


def load_config(config_path: str = "config/server_config.json") -> Dict[str, Any]:
    """Load configuration from JSON file."""
    try:
        # If path is relative, make it absolute relative to the project root
        if not os.path.isabs(config_path):
            # Get the directory containing this utils.py file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # Go up one level to the project root
            project_root = os.path.dirname(current_dir)
            config_path = os.path.join(project_root, config_path)
        
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error(f"Configuration file not found: {config_path}")
        # Return default configuration
        return {
            "server": {"host": "localhost", "port": 8080, "debug": True},
            "selenium": {"browser": "chrome", "headless": True, "timeout": 30},
            "colab": {"base_url": "https://colab.research.google.com", "execution_timeout": 300},
            "google_api": {"scopes": ["https://www.googleapis.com/auth/drive"]},
            "logging": {"level": "INFO", "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"}
        }
    except json.JSONDecodeError as e:
        logging.error(f"Invalid JSON in configuration file: {e}")
        return {}


def setup_logging(config: Dict[str, Any]) -> None:
    """Set up logging configuration."""
    log_config = config.get("logging", {})
    level = getattr(logging, log_config.get("level", "INFO"))
    format_str = log_config.get("format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    
    # Create logs directory if it doesn't exist
    log_file = log_config.get("file")
    if log_file:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        logging.basicConfig(
            level=level,
            format=format_str,
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
    else:
        logging.basicConfig(level=level, format=format_str)


def retry_with_backoff(max_retries: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """Decorator for retrying functions with exponential backoff."""
    def decorator(func):
        def wrapper(*args, **kwargs):
            retries = 0
            current_delay = delay
            
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    retries += 1
                    if retries >= max_retries:
                        logging.error(f"Function {func.__name__} failed after {max_retries} retries: {e}")
                        raise
                    
                    logging.warning(f"Function {func.__name__} failed (attempt {retries}/{max_retries}): {e}")
                    time.sleep(current_delay)
                    current_delay *= backoff
            
            return None
        return wrapper
    return decorator


def validate_notebook_id(notebook_id: str) -> bool:
    """Validate Google Drive file ID format."""
    if not notebook_id or not isinstance(notebook_id, str):
        return False
    
    # Google Drive file IDs are typically 33-44 characters long
    # and contain alphanumeric characters, hyphens, and underscores
    import re
    pattern = r'^[a-zA-Z0-9_-]{25,50}$'
    return bool(re.match(pattern, notebook_id))


def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe file operations."""
    import re
    # Remove or replace invalid characters
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    # Remove leading/trailing whitespace and dots
    sanitized = sanitized.strip(' .')
    # Ensure it's not empty
    if not sanitized:
        sanitized = "untitled"
    return sanitized


def create_notebook_content(cells: list = None) -> Dict[str, Any]:
    """Create a basic Colab notebook structure."""
    if cells is None:
        cells = []
    
    return {
        "nbformat": 4,
        "nbformat_minor": 0,
        "metadata": {
            "colab": {
                "provenance": [],
                "collapsed_sections": []
            },
            "kernelspec": {
                "name": "python3",
                "display_name": "Python 3"
            },
            "language_info": {
                "name": "python"
            }
        },
        "cells": cells
    }


def create_code_cell(source: str, outputs: list = None) -> Dict[str, Any]:
    """Create a code cell for a notebook."""
    if outputs is None:
        outputs = []
    
    return {
        "cell_type": "code",
        "source": source.split('\n') if isinstance(source, str) else source,
        "metadata": {},
        "execution_count": None,
        "outputs": outputs
    }


def create_text_cell(source: str, cell_type: str = "markdown") -> Dict[str, Any]:
    """Create a text cell (markdown or raw) for a notebook."""
    return {
        "cell_type": cell_type,
        "source": source.split('\n') if isinstance(source, str) else source,
        "metadata": {}
    }


def extract_error_message(error: Exception) -> str:
    """Extract a clean error message from an exception."""
    error_msg = str(error)
    # Remove common prefixes that aren't useful for users
    prefixes_to_remove = [
        "Message: ",
        "selenium.common.exceptions.",
        "googleapiclient.errors.",
    ]
    
    for prefix in prefixes_to_remove:
        if error_msg.startswith(prefix):
            error_msg = error_msg[len(prefix):]
    
    return error_msg


def ensure_directory_exists(path: str) -> None:
    """Ensure a directory exists, creating it if necessary."""
    Path(path).mkdir(parents=True, exist_ok=True)


def is_valid_python_code(code: str) -> bool:
    """Check if the provided string is valid Python code."""
    try:
        compile(code, '<string>', 'exec')
        return True
    except SyntaxError:
        return False


def format_execution_time(seconds: float) -> str:
    """Format execution time in a human-readable format."""
    if seconds < 1:
        return f"{seconds*1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    else:
        minutes = int(seconds // 60)
        remaining_seconds = seconds % 60
        return f"{minutes}m {remaining_seconds:.1f}s"