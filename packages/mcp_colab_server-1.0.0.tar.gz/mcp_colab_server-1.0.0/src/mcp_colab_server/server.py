"""Main MCP server implementation for Google Colab integration."""

import asyncio
import json
import logging
import os
import sys
from typing import Any, Dict, List, Optional

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel,
    ServerCapabilities,
    ToolsCapability
)

from .auth_manager import AuthManager
from .colab_drive import ColabDriveManager
from .colab_selenium import ColabSeleniumManager
from .session_manager import SessionManager, RuntimeType
from .utils import load_config, setup_logging, extract_error_message


class ColabMCPServer:
    """MCP Server for Google Colab integration."""
    
    def __init__(self, config_path: str = None):
        """Initialize the MCP server."""
        if config_path is None:
            # Try to find config file relative to the script location
            script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            config_path = os.path.join(script_dir, "config", "server_config.json")
        
        self.config = load_config(config_path)
        setup_logging(self.config)
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.auth_manager = AuthManager(config_path)
        self.session_manager = SessionManager(self.config)
        self.drive_manager = None
        self.selenium_manager = None
        
        # MCP Server
        self.server = Server("google-colab-mcp")
        self._setup_handlers()
        
        self.logger.info("Colab MCP Server initialized")
    
    def _setup_handlers(self) -> None:
        """Set up MCP server handlers."""
        
        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """List available tools."""
            return [
                Tool(
                    name="create_colab_notebook",
                    description="Create a new Google Colab notebook",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Name of the notebook"
                            },
                            "content": {
                                "type": "string",
                                "description": "Optional initial content (JSON format)"
                            }
                        },
                        "required": ["name"]
                    }
                ),
                Tool(
                    name="run_code_cell",
                    description="Execute Python code in a Colab notebook",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "code": {
                                "type": "string",
                                "description": "Python code to execute"
                            },
                            "notebook_id": {
                                "type": "string",
                                "description": "ID of the notebook"
                            }
                        },
                        "required": ["code", "notebook_id"]
                    }
                ),
                Tool(
                    name="install_package",
                    description="Install a Python package in Colab",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "package_name": {
                                "type": "string",
                                "description": "Name of the package to install"
                            },
                            "notebook_id": {
                                "type": "string",
                                "description": "ID of the notebook"
                            }
                        },
                        "required": ["package_name", "notebook_id"]
                    }
                ),
                Tool(
                    name="get_notebook_content",
                    description="Retrieve the content of a Colab notebook",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "notebook_id": {
                                "type": "string",
                                "description": "ID of the notebook"
                            }
                        },
                        "required": ["notebook_id"]
                    }
                ),
                Tool(
                    name="list_notebooks",
                    description="List user's Colab notebooks",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "max_results": {
                                "type": "integer",
                                "description": "Maximum number of notebooks to return",
                                "default": 50
                            }
                        }
                    }
                ),
                Tool(
                    name="upload_file_to_colab",
                    description="Upload a file to Colab environment",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to the file to upload"
                            },
                            "notebook_id": {
                                "type": "string",
                                "description": "ID of the notebook"
                            }
                        },
                        "required": ["file_path", "notebook_id"]
                    }
                ),
                Tool(
                    name="get_runtime_info",
                    description="Get runtime information for a Colab notebook",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "notebook_id": {
                                "type": "string",
                                "description": "ID of the notebook"
                            }
                        },
                        "required": ["notebook_id"]
                    }
                ),
                Tool(
                    name="get_session_info",
                    description="Get session information for a notebook",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "notebook_id": {
                                "type": "string",
                                "description": "ID of the notebook"
                            }
                        },
                        "required": ["notebook_id"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool calls."""
            try:
                # Ensure authentication
                await self._ensure_authenticated()
                
                if name == "create_colab_notebook":
                    result = await self._create_notebook(arguments)
                elif name == "run_code_cell":
                    result = await self._run_code_cell(arguments)
                elif name == "install_package":
                    result = await self._install_package(arguments)
                elif name == "get_notebook_content":
                    result = await self._get_notebook_content(arguments)
                elif name == "list_notebooks":
                    result = await self._list_notebooks(arguments)
                elif name == "upload_file_to_colab":
                    result = await self._upload_file(arguments)
                elif name == "get_runtime_info":
                    result = await self._get_runtime_info(arguments)
                elif name == "get_session_info":
                    result = await self._get_session_info(arguments)
                else:
                    raise ValueError(f"Unknown tool: {name}")
                
                return [TextContent(type="text", text=json.dumps(result, indent=2))]
                
            except Exception as e:
                error_msg = extract_error_message(e)
                self.logger.error(f"Tool {name} failed: {error_msg}")
                
                # Provide helpful error messages for common issues
                if "authentication failed" in error_msg.lower():
                    error_msg = "🔐 Google authentication required. Please ensure credentials.json is properly configured."
                elif "credentials.json" in error_msg.lower():
                    error_msg = "📄 Missing credentials.json file. Please download it from Google Cloud Console and place it in the config/ folder."
                
                return [TextContent(type="text", text=json.dumps({
                    "success": False,
                    "error": error_msg,
                    "help": "For setup instructions, check the MCP server logs or README.md"
                }, indent=2))]
    
    async def _ensure_authenticated(self) -> None:
        """Ensure Google APIs are authenticated."""
        if not self.auth_manager.is_authenticated():
            self.logger.info("🔐 Authentication required - starting automatic login...")
            success = self.auth_manager.authenticate(auto_open_browser=True)
            if not success:
                raise Exception("❌ Google authentication failed. Please check your credentials.json file.")
        
        # Initialize managers if not already done
        if self.drive_manager is None:
            self.logger.info("📁 Initializing Google Drive manager...")
            self.drive_manager = ColabDriveManager(self.auth_manager)
        
        if self.selenium_manager is None:
            self.logger.info("🤖 Initializing Selenium automation manager...")
            self.selenium_manager = ColabSeleniumManager(self.config, self.session_manager)
    
    async def _create_notebook(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new Colab notebook."""
        name = arguments["name"]
        content_str = arguments.get("content")
        
        content = None
        if content_str:
            try:
                content = json.loads(content_str)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON content provided")
        
        result = self.drive_manager.create_notebook(name, content)
        
        # Create session for the new notebook
        self.session_manager.create_session(result["id"])
        
        return {
            "success": True,
            "notebook": result
        }
    
    async def _run_code_cell(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute code in a Colab notebook."""
        code = arguments["code"]
        notebook_id = arguments["notebook_id"]
        
        # Use Selenium for code execution
        result = self.selenium_manager.execute_code(notebook_id, code)
        
        return result
    
    async def _install_package(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Install a package in Colab."""
        package_name = arguments["package_name"]
        notebook_id = arguments["notebook_id"]
        
        result = self.selenium_manager.install_package(notebook_id, package_name)
        
        return result
    
    async def _get_notebook_content(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Get notebook content."""
        notebook_id = arguments["notebook_id"]
        
        content = self.drive_manager.get_notebook_content(notebook_id)
        
        return {
            "success": True,
            "content": content
        }
    
    async def _list_notebooks(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """List user's notebooks."""
        max_results = arguments.get("max_results", 50)
        
        notebooks = self.drive_manager.list_notebooks(max_results)
        
        return {
            "success": True,
            "notebooks": notebooks,
            "count": len(notebooks)
        }
    
    async def _upload_file(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Upload file to Colab."""
        file_path = arguments["file_path"]
        notebook_id = arguments["notebook_id"]
        
        result = self.selenium_manager.upload_file(notebook_id, file_path)
        
        return result
    
    async def _get_runtime_info(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Get runtime information."""
        notebook_id = arguments["notebook_id"]
        
        result = self.selenium_manager.get_runtime_info(notebook_id)
        
        return result
    
    async def _get_session_info(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Get session information."""
        notebook_id = arguments["notebook_id"]
        
        session_info = self.session_manager.get_session_info(notebook_id)
        
        return {
            "success": True,
            "session": session_info
        }
    
    async def run(self) -> None:
        """Run the MCP server."""
        try:
            self.logger.info("Starting Colab MCP Server...")
            
            # Run the server
            async with stdio_server() as (read_stream, write_stream):
                await self.server.run(
                    read_stream,
                    write_stream,
                    InitializationOptions(
                        server_name="google-colab-mcp",
                        server_version="1.0.0",
                        capabilities=ServerCapabilities(
                            tools=ToolsCapability(listChanged=False)
                        )
                    )
                )
                
        except KeyboardInterrupt:
            self.logger.info("Server interrupted by user")
        except Exception as e:
            import traceback
            self.logger.error(f"Server error: {e}")
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            raise
        finally:
            await self._cleanup()
    
    async def _cleanup(self) -> None:
        """Cleanup resources."""
        try:
            if self.selenium_manager:
                self.selenium_manager.close()
            
            # Cleanup idle sessions
            cleaned = self.session_manager.cleanup_idle_sessions()
            if cleaned > 0:
                self.logger.info(f"Cleaned up {cleaned} idle sessions")
            
            self.logger.info("Server cleanup completed")
            
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")


async def main():
    """Main entry point."""
    try:
        server = ColabMCPServer()
        await server.run()
    except Exception as e:
        logging.error(f"Failed to start server: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())