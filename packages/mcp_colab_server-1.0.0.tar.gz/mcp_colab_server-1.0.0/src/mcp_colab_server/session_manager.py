"""Session management for Google Colab interactions."""

import logging
import time
from typing import Dict, Optional, Any, List
from dataclasses import dataclass
from enum import Enum


class RuntimeType(Enum):
    """Colab runtime types."""
    CPU = "cpu"
    GPU = "gpu"
    TPU = "tpu"


class SessionStatus(Enum):
    """Session status types."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    BUSY = "busy"
    ERROR = "error"


@dataclass
class ColabSession:
    """Represents a Colab session."""
    notebook_id: str
    session_id: Optional[str] = None
    status: SessionStatus = SessionStatus.DISCONNECTED
    runtime_type: RuntimeType = RuntimeType.CPU
    last_activity: float = 0.0
    connection_time: Optional[float] = None
    error_message: Optional[str] = None
    
    def __post_init__(self):
        """Initialize timestamps."""
        if self.last_activity == 0.0:
            self.last_activity = time.time()


class SessionManager:
    """Manages Colab sessions and their lifecycle."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize the session manager."""
        self.config = config
        self.colab_config = config.get("colab", {})
        self.sessions: Dict[str, ColabSession] = {}
        self.logger = logging.getLogger(__name__)
        
        # Configuration
        self.max_idle_time = self.colab_config.get("max_idle_time", 3600)  # 1 hour
        self.connection_timeout = self.colab_config.get("connection_timeout", 60)
        self.max_retries = self.colab_config.get("max_retries", 3)
    
    def create_session(self, notebook_id: str, runtime_type: RuntimeType = RuntimeType.CPU) -> ColabSession:
        """Create a new Colab session."""
        session = ColabSession(
            notebook_id=notebook_id,
            runtime_type=runtime_type,
            status=SessionStatus.DISCONNECTED
        )
        
        self.sessions[notebook_id] = session
        self.logger.info(f"Created session for notebook {notebook_id}")
        
        return session
    
    def get_session(self, notebook_id: str) -> Optional[ColabSession]:
        """Get an existing session."""
        return self.sessions.get(notebook_id)
    
    def get_or_create_session(self, notebook_id: str, runtime_type: RuntimeType = RuntimeType.CPU) -> ColabSession:
        """Get existing session or create a new one."""
        session = self.get_session(notebook_id)
        if session is None:
            session = self.create_session(notebook_id, runtime_type)
        return session
    
    def update_session_status(self, notebook_id: str, status: SessionStatus, error_message: Optional[str] = None) -> None:
        """Update session status."""
        session = self.get_session(notebook_id)
        if session:
            session.status = status
            session.last_activity = time.time()
            
            if status == SessionStatus.CONNECTED and session.connection_time is None:
                session.connection_time = time.time()
            elif status == SessionStatus.ERROR:
                session.error_message = error_message
            
            self.logger.info(f"Session {notebook_id} status updated to {status.value}")
    
    def mark_session_active(self, notebook_id: str) -> None:
        """Mark session as active (update last activity time)."""
        session = self.get_session(notebook_id)
        if session:
            session.last_activity = time.time()
    
    def is_session_idle(self, notebook_id: str) -> bool:
        """Check if session is idle (inactive for too long)."""
        session = self.get_session(notebook_id)
        if not session:
            return True
        
        idle_time = time.time() - session.last_activity
        return idle_time > self.max_idle_time
    
    def is_session_connected(self, notebook_id: str) -> bool:
        """Check if session is connected and active."""
        session = self.get_session(notebook_id)
        if not session:
            return False
        
        return (
            session.status == SessionStatus.CONNECTED and 
            not self.is_session_idle(notebook_id)
        )
    
    def cleanup_idle_sessions(self) -> int:
        """Clean up idle sessions and return count of cleaned sessions."""
        current_time = time.time()
        idle_sessions = []
        
        for notebook_id, session in self.sessions.items():
            idle_time = current_time - session.last_activity
            if idle_time > self.max_idle_time:
                idle_sessions.append(notebook_id)
        
        for notebook_id in idle_sessions:
            self.remove_session(notebook_id)
            self.logger.info(f"Cleaned up idle session: {notebook_id}")
        
        return len(idle_sessions)
    
    def remove_session(self, notebook_id: str) -> bool:
        """Remove a session."""
        if notebook_id in self.sessions:
            del self.sessions[notebook_id]
            self.logger.info(f"Removed session: {notebook_id}")
            return True
        return False
    
    def get_session_info(self, notebook_id: str) -> Optional[Dict[str, Any]]:
        """Get session information."""
        session = self.get_session(notebook_id)
        if not session:
            return None
        
        current_time = time.time()
        idle_time = current_time - session.last_activity
        connection_duration = None
        
        if session.connection_time:
            connection_duration = current_time - session.connection_time
        
        return {
            'notebook_id': session.notebook_id,
            'session_id': session.session_id,
            'status': session.status.value,
            'runtime_type': session.runtime_type.value,
            'idle_time': idle_time,
            'connection_duration': connection_duration,
            'is_idle': self.is_session_idle(notebook_id),
            'is_connected': self.is_session_connected(notebook_id),
            'error_message': session.error_message
        }
    
    def list_sessions(self) -> List[Dict[str, Any]]:
        """List all sessions with their information."""
        sessions_info = []
        for notebook_id in self.sessions:
            info = self.get_session_info(notebook_id)
            if info:
                sessions_info.append(info)
        
        return sessions_info
    
    def get_active_sessions_count(self) -> int:
        """Get count of active (connected) sessions."""
        count = 0
        for notebook_id in self.sessions:
            if self.is_session_connected(notebook_id):
                count += 1
        return count
    
    def set_session_id(self, notebook_id: str, session_id: str) -> None:
        """Set the session ID for a notebook."""
        session = self.get_session(notebook_id)
        if session:
            session.session_id = session_id
            self.logger.info(f"Set session ID for {notebook_id}: {session_id}")
    
    def should_reconnect(self, notebook_id: str) -> bool:
        """Determine if a session should be reconnected."""
        session = self.get_session(notebook_id)
        if not session:
            return False
        
        # Reconnect if disconnected or in error state
        if session.status in [SessionStatus.DISCONNECTED, SessionStatus.ERROR]:
            return True
        
        # Reconnect if idle for too long
        if self.is_session_idle(notebook_id):
            return True
        
        return False
    
    def get_runtime_info(self, notebook_id: str) -> Dict[str, Any]:
        """Get runtime information for a session."""
        session = self.get_session(notebook_id)
        if not session:
            return {}
        
        return {
            'runtime_type': session.runtime_type.value,
            'status': session.status.value,
            'available_types': [rt.value for rt in RuntimeType],
            'recommended_type': RuntimeType.CPU.value  # Default recommendation
        }