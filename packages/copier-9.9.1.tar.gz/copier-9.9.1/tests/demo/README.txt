This is the template README.
