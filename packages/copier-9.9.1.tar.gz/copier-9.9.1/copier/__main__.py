"""Copier CLI entrypoint."""

from ._cli import CopierApp

if __name__ == "__main__":
    CopierApp.run()
