<!--
- SPDX-License-Identifier: Apache-2.0
- Copyright (C) 2024 Jayesh Badwaik <jayesh@ambhora.com>
-->

# docasur

docasur is a document typesetting system.
