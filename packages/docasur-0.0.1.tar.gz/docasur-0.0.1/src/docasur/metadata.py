# --------------------------------------------------------------------------------------------------
# SPDX-License-Identifier: Apache-2.0
# Copyright (C) 2024 Jayesh Badwaik <jayesh@ambhora.com>
# --------------------------------------------------------------------------------------------------

import semver as SemVer
__version__ = "0.0.1"
semver = SemVer.VersionInfo.parse(__version__)
