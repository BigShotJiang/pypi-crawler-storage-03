---
layout: default
title: Kill Running Process
parent: OSB API
nav_order: 14
---