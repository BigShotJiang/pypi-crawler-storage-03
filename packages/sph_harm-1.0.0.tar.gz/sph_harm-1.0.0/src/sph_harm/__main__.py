"""Make the CLI runnable using python -m sph_harm."""

from .cli import app

app(prog_name="sph_harm")
