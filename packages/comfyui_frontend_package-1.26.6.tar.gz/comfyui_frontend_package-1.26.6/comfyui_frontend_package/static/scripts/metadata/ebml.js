// Shim for scripts/metadata/ebml.ts
export const getFromWebmFile = window.comfyAPI.ebml.getFromWebmFile;
