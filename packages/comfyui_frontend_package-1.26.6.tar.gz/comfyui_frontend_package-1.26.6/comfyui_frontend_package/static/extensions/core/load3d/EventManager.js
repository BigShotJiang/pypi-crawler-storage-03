// Shim for extensions/core/load3d/EventManager.ts
export const EventManager = window.comfyAPI.EventManager.EventManager;
