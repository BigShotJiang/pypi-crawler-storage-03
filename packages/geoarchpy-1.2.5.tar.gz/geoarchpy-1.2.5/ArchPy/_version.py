# Version

# major, minor, micro
version_info = (1, 2, 5)

__version__ = '.'.join(map(str, version_info))