class MocketException(Exception):
    pass


class StrictMocketException(MocketException):
    pass
