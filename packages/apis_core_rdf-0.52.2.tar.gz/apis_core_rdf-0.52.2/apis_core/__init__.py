__version__ = "0.52.2"  # x-release-please-version
