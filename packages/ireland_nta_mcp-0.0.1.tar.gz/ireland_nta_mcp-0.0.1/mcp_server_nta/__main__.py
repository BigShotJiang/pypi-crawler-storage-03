from mcp_server_nta import main

if __name__ == "__main__":
    main()