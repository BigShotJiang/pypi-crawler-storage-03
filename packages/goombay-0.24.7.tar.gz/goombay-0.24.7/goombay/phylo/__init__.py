from goombay.phylo import cluster

# Classes from clustering file
NeighborJoining = cluster.NeighborJoining
NewickFormatter = cluster.NewickFormatter
