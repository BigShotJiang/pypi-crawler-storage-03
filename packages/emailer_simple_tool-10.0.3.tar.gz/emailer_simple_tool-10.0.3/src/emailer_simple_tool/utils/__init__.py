"""
Utility modules for emailer-simple-tool application.
"""
