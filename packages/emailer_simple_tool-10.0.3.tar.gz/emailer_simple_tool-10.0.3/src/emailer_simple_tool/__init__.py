"""
Emailer Simple Tool: A personalized email campaign management tool.
"""

__version__ = "10.0.3"
__author__ = "Simple Tool Team"
__description__ = "Send personalized emails to recipients with campaign management and GUI interface"
