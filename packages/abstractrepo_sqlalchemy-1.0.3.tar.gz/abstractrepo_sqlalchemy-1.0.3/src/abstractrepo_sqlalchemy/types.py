from typing import TypeVar

TDbModel = TypeVar('TDbModel')
