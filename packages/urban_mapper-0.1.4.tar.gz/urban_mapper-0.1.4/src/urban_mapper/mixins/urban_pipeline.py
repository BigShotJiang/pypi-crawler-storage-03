from urban_mapper.pipeline import UrbanPipeline


class UrbanPipelineMixin(UrbanPipeline):
    def __init__(self):
        super().__init__()
