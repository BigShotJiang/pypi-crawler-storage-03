"""Midas upgrade module for simbench data simulator."""

import os
from typing import cast

import pandas as pd
from midas.scenario.upgrade_module import ModuleParams
from midas.util.dict_util import set_default_bool
from midas.util.runtime_config import RuntimeConfig
from midas_powerseries.module import PowerSeriesModule
from typing_extensions import override

from . import LOG


class SimbenchDataModule(PowerSeriesModule):
    """Upgrade module for simbench data.

    Other, similar data modules can derive from this class.

    """

    def __init__(self):
        super().__init__(
            module_name="sbdata",
            default_scope_name="sbrural3",
            default_sim_config_name="SimbenchData",
            log=LOG,
        )

        self._filename = "1-LV-rural3--0-sw.csv"

    def check_sim_params(self, mp: ModuleParams):
        """Check the params for a certain simulator instance."""
        self.sim_params.setdefault("filename", self._filename)

        filename = cast(str, self.sim_params["filename"])
        mapping_fn = f"{filename.rsplit('.')[0]}_mapping.csv"
        cm = self.sim_params.setdefault("combined_mapping", "default")
        if isinstance(cm, str) and cm == "default":
            self.sim_params.setdefault("combined_mapping_filename", mapping_fn)
            set_default_bool(
                self.sim_params, "prefer_combined_mapping_from_file", True
            )

        super().check_sim_params(mp)

    def download(self, data_path, tmp_path, force):
        import simbench as sb

        LOG.info("Preparing Simbench datasets...")
        # We allow multiple datasets here
        for config in RuntimeConfig().data["simbench"]:
            output_path = os.path.abspath(
                os.path.join(data_path, config["name"])
            )
            sb_code = output_path.rsplit(os.sep, 1)[1].split(".")[0]
            mapping_path = os.path.join(data_path, f"{sb_code}_mapping.csv")
            if os.path.exists(output_path):
                LOG.debug("Found existing dataset at '%s'.", output_path)
                if force:
                    LOG.debug("Loading profiles anyways ...")
                else:
                    continue
            else:
                LOG.debug(
                    "No dataset found. Start loading '%s' profiles ...",
                    sb_code,
                )

            data = pd.DataFrame()

            grid = sb.get_simbench_net(sb_code)
            profiles = sb.get_absolute_values(grid, True)
            mapping = {}
            for etype in ["load", "sgen", "storage"]:
                for attr in ["p_mw", "q_mvar"]:
                    try:
                        prof = profiles[(etype, attr)]
                    except KeyError:
                        continue

                    new_cols = []
                    for i in prof.columns:
                        name = f"{etype}_{i:03d}"
                        model_name = f"{name}_{attr}"
                        new_cols.append(model_name)

                        entity = grid[etype].loc[i]

                        mapping.setdefault(name, {})
                        mapping[name]["bus"] = int(entity["bus"])
                        mapping[name]["scaling"] = 1.0

                        col = "model_1" if attr == "p_mw" else "model_2"
                        mapping[name][col] = model_name

                    prof.columns = [
                        f"{etype}_{i:03d}_{attr}" for i in prof.columns
                    ]
                    data = cast(pd.DataFrame, pd.concat([data, prof], axis=1))

            data.to_csv(output_path, index=False)

            mapping2 = {"bus": [], "model_1": [], "model_2": [], "scaling": []}
            for m in mapping.values():
                mapping2["bus"].append(m["bus"])
                mapping2["model_1"].append(m.get("model_1", ""))
                mapping2["model_2"].append(m.get("model_2", ""))
                mapping2["scaling"].append(m["scaling"])
            mapping_df = pd.DataFrame(mapping2)
            mapping_df.to_csv(mapping_path, index=False)

    @override
    def analyze(
        self,
        name: str,
        data,
        output_folder: str,
        start: int,
        end: int,
        step_size: int,
        full: bool,
    ):
        # No analysis, yet
        pass
