# MIDAS Simbench Data Simulator

The *sbdata* module, provided by the *midas-sbdata* package, provides a simulator for simbench data sets even outside of simbench networks.

Version: 2.1


## Installation

This package will be installed automatically with `midas-mosaik` if you opt-in the `full` extra. 
It is available on pypi, so you can install it manually with

```bash
pip install midas-sbdata
```

## Usage

The complete documentation is available at https://midas-mosaik.gitlab.io/midas.

### Inside of MIDAS

To use the simulator inside of midas, add `sbdata` to your modules:

```yaml
my_scenario:
  modules:
    - sbdata
    - ...
```

and configure it with:

```yaml
    my_scenario:
      # ...
      sndata_params:
        my_grid_scope:
          is_load: false
          is_sgen: false
          combined_mapping:
            1: [[[load_000_p_mw, load_000_q_mvar], 1.0]]
            3: [[sgen_000_p_mw, 1.0]]
```

### Any mosaik scenario

If you don't use midas, you can add the `sbdata` manually to your [mosaik scenario](https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html) file.
First, the entry in the `sim_config`:


```python
    sim_config: {
      "SimbenchData": {
        "python": "midas_powerseries.simulator:PowerSeriesSimulator",
      }
    }
```

Next, you need to start the simulator (assuming a `step_size` of 900):

```python
    sbdata_sim = world.start(
        "SimbenchData",
        step_size=900,
        is_load=False,
        is_sgen=False,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located",
        filename="1-LV-rural3--0-sw.csv",  # this is default,
    )
```

Then the models can be started:

```python
    load1 = sbdata_sim.CombindTimeSeries(name=["load_000_p_mw", "load_000_q_mvar"], scaling=1.0)
    sgen1 = sbdata_sim.CalculatedQTimeSeries(name="sgen_000_p_mw", scaling=1.0)
```

Finally, the models need to be connected to other entities:

```python
    world.connect(load1, other_entity, "p_mw", "q_mvar")
```

## License

This software is released under the GNU Lesser General Public License (LGPL). See the license file for more information about the details.
