"""
ParquetConv - A command-line tool for converting between Parquet and CSV file formats.
"""

__version__ = "0.2.0"
__author__ = "Sebastian Bassi"
__email__ = "sebastian@toyoko.io"
