class IndslUserWarning(UserWarning):
    """Warning that will be shown to the user."""
