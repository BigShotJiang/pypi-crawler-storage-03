============
Installation
============

At the command line::

    $ pip install octavia-lib

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv octavia-lib
    $ pip install octavia-lib
