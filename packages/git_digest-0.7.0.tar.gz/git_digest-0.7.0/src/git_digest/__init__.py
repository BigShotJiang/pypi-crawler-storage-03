from .cli import app


def main() -> None:
    """Main entry point for git-digest CLI."""
    app()
