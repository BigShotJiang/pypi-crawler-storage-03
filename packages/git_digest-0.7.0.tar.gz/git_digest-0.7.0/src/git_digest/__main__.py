"""Main entry point for git-digest when run as module."""

from git_digest.cli import app

if __name__ == "__main__":
    app()
