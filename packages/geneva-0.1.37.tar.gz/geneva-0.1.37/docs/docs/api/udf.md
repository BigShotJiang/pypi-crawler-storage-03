::: geneva.udf

::: geneva.transformer.UDF
    options:
      members:
       - func
       - name
       - data_type
       - version
       - cuda
       - num_cpus
       - memory


::: geneva.transformer.UDFArgType
    options:
      members: true