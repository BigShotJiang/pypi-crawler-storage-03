# Earnings Analysis

Consensus $ EPS

## Filters

A set of filters that control the analysis is available:

1. **Analysis**: EPS ($)
    - **$ EPS  [default view]**: By default shows an aggregated $ EPS (weighted).

2. **Period**: Common periods (TTM, FTM, FY+1, FY+2) are available with **FTW** set by default.

3. **Show related**: Adds lines for all specified peers if available
