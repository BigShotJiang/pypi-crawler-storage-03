class InvalidAnalyticPortfolio(Exception):
    pass
