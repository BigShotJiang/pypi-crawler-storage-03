__version__ = '1.0.24'  # pragma: no cover
