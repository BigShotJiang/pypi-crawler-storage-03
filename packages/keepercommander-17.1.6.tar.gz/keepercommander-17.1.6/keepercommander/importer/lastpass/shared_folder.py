class LastpassSharedFolder:
    def __init__(self, id, name, members=None, teams=None):
        self.id = id
        self.name = name
        self.members = members
        self.teams = teams
