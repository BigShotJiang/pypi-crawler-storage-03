def c9D10():
    print("We know you, you don't know us, why? Arogance of mankind.\n")
