axis([-5 5 -0.5 1.5])

hold on;
plot([0 0],[-0.5 1.5],'r-','linewidth',2);


shg;
clear afterframe 