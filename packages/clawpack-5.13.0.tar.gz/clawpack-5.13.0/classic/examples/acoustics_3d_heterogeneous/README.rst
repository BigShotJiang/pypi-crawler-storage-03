
.. _classic_examples_acoustics_3d_heterogeneous:

Three-dimensional acoustics 
==============================================================

