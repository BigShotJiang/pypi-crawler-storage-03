# This repository hosts the GeoClaw code.

See the main [clawpack/clawpack repository](https://github.com/clawpack/clawpack)
 README for more links.  

See the [Documentation](https://www.clawpack.org/)
for more details and installation instructions.


**Links**
 - [Documentation for GeoClaw](https://www.clawpack.org/geoclaw.html)
 - [More description of GeoClaw and references](http://www.geoclaw.org)
 - [![Tests](https://github.com/clawpack/geoclaw/actions/workflows/testing.yml/badge.svg)](https://github.com/clawpack/geoclaw/actions/workflows/testing.yml)
