
Scratch directory for data files that are either downloaded from the web or
generated via scripts.  

Running some of the examples will generate large files in this directory.
They can be safely removed after you are done exploring the example.
