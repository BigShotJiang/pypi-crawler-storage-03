
Attempts at regression routines, not yet working.
