"""
Regression tests for 1D acoustics with adjoint flagging.
"""

from pathlib import Path
import sys
import shutil
import unittest

import clawpack.amrclaw.test as test
import clawpack.clawutil.runclaw

from adjoint.test_acoustics_1d_adjoint import Acoustics1DAdjointTest


class Acoustics1DAdjointForwardTest(test.AMRClawRegressionTest):
    r"""Basic test for a 1D acoustics adjoint-flagging forward problem test case"""


    def runTest(self, save=False):
        
        # Run adjoint problem
        try:
            adjoint_run = Acoustics1DAdjointTest()    
            adjoint_run.setUp()
            adjoint_run.runTest()
            
            # Copy output to local directory
            adjoint_output = Path(self.temp_path) / "_adjoint_output"

            if Path(adjoint_output).exists():
                shutil.rmtree(adjoint_output)
            shutil.copytree(adjoint_run.temp_path, adjoint_output)
        finally:
            adjoint_run.tearDown()

        # Write out data files
        self.load_rundata()

        # self.rundata.clawdata.num_output_times = 1
        # self.rundata.clawdata.tfinal = 0.5

        # self.rundata.amrdata.flag2refine_tol = 0.05

        # self.rundata.gaugedata.gauges = []
        # self.rundata.gaugedata.gauges.append([0, -1.0, 0., 1e9])
        # self.rundata.gaugedata.gauges.append([1, -2.5, 0., 1e9])
        # self.rundata.gaugedata.gauges.append([2, -1.75, 0., 1e9])

        # Look for adjoint data
        self.rundata.adjointdata.adjoint_outdir = adjoint_output

        self.write_rundata_objects()

        # Run code
        self.run_code()

        # Perform tests
        self.check_gauges(save=save, gauge_id=0)
        self.check_gauges(save=save, gauge_id=1)
        # self.check_gauges(save=save, gauge_id=2)

        self.success = True



if __name__=="__main__":
    if len(sys.argv) > 1:
        if bool(sys.argv[1]):
            # Fake the setup and save out output
            test = Acoustics1DAdjointForwardTest()
            try:
                test.setUp()
                test.runTest(save=True)
            finally:
                test.tearDown()
            sys.exit(0)
    unittest.main()
