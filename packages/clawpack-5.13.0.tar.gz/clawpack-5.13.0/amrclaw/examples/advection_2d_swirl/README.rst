
.. _amrclaw_examples_advection_2d_swirl:

Two-dimensional advection with a swirling flowfield
===================================================

