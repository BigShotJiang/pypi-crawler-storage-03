

.. _amrclaw_examples_acoustics_2d_radial_1drad:

One-dimensional acoustics with radially symmetric initial data
==============================================================

One-dimensional radially-symmetric solver for the acoustics equations. The
code in this subdirectory should be run to create a fine-grid reference
solution to use in plotting results from the 2d code in the parent directory.

