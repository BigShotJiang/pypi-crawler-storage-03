
.. _amrclaw_examples_advection_2d_square:

Two-dimensional advection of a square pulse 
===========================================

With periodic boundary conditions.
