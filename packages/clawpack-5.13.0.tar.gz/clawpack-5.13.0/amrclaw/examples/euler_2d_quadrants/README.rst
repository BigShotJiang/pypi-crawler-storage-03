
.. _amrclaw_examples_euler_2d_quadrants:

Two-dimensional Euler equations
=================================

With piecewise constant initial data in 4 quadrants.


