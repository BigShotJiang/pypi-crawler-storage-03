
.. _amrclaw_examples_advection_2d_annulus:

Two-dimensional advection around an annulus
===========================================

On a mapped grid, as specified in `mapc2p.f` and `mapc2p.py`.

