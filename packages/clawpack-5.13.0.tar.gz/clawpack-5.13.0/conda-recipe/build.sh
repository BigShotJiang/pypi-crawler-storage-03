#!/bin/bash
python setup.py install
