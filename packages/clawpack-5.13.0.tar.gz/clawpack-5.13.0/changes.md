# Changes in Clawpack 5.0 (after 4.6.3)

See (http://clawpack.github.io/doc/clawpack5.html) for a changes to Classic, AMRClaw, and GeoClaw.

See (http://clawpack.github.io/doc/pyclaw/) for changes to PyClaw.
