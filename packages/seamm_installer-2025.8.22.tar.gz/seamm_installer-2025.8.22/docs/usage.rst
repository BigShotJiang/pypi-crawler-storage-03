=====
Usage
=====

To use the SEAMM Installer Step in a project::

    import seamm_installer
