"""Global module for passing around objects and constants."""

conda = None
development = None
environment = None
logger = None
options = None
pip = None
package_metadata = {}
root = None
