# StockPredictor 📈

A Python library for predicting stock prices using machine learning.

## Installation

```bash
pip install stockpredictor
