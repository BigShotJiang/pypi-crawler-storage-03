class TestDummy:
    def test_pass(self):
        assert True
