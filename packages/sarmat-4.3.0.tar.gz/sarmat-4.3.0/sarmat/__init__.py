"""
Sarmat.
"""
VERSION = "4.3.0"

__version__ = VERSION
