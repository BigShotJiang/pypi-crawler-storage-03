"""Module that stores package version information."""
__version__ = "0.1.2"
