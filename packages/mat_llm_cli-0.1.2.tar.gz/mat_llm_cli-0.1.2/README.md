# mat-llm-cli



<p align="left">
    <a href="https://cookiecutter-data-science.drivendata.org/">
        <img src="https://img.shields.io/badge/CCDS-Project%20template-328F97?logo=cookiecutter" /></a>
    <a href="https://shields.io/community#backers" alt="Package">
        <img src="https://img.shields.io/badge/Version-v0.1.2-orange" /></a>
</p>

Contains useful CLI tools to leverage LLM APIs.
