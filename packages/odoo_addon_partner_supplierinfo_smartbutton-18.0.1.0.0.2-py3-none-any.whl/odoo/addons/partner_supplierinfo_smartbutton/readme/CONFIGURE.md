1.  Go to *Purchase \> Products \> Products*.
2.  Access one of them clicking on it.
3.  Go to "Purchase" tab and add some vendors (Azure Interior for
    example).
