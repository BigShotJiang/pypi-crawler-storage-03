This addon adds a smart-button in the vendors with the supplied
products.
