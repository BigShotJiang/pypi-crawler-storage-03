To use this module, you need to install "contacts" and "purchase"
addons.
