1.  Go to *Contacts* or *Purchase \> Orders \> Vendors*.
2.  Access one of them clicking on it.
3.  If it has supplier products, you will see an smart-button in the top
    part called "Products Supplied".
4.  Clicking on it, you will be see all products supplied.
