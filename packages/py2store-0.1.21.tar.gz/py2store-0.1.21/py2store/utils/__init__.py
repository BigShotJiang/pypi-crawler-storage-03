"""
general utils
"""
