"""XTGeo roxutils package"""

from .roxutils import RoxUtils

__all__ = [
    "RoxUtils",
]
