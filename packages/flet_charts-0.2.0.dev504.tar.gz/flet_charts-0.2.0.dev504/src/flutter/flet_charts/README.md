# flet_charts

A Flet extension for creating interactive charts and graphs.