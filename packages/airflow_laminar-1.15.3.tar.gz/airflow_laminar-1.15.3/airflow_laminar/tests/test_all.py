from airflow_laminar import *  # noqa


def test_all():
    assert True
