# Py Advys

Biblioteca com ferramentas para auxiliar no desenvolvimento de aplicações!

### instalação
```
pip install --upgrade PyAdvys
```
### Inicializa configurações
```
pyadvys-config-ini.exe
```

### Atualiza os caminhos das imagens e diretórios 
```
pyadvys-atualiza-estrutura.exe
```
## Pacotes

* advys_configuracoes
* advys_estrutura
* advys_servicos
* advys_utilitarios
* advys_validadores