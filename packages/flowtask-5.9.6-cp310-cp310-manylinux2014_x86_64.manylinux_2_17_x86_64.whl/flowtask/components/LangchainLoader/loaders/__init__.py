# """
# Langchain Loaders.

# Basic Documents Loaders, adapted to be used in Flowtask Tasks.
# """
# from .docx import MSWordLoader
# from .qa import QAFileLoader
# from .pdfmark import PDFMarkdown
# from .pdftables import PDFTables
# from .pdfblocks import PDFBlocks
# from .txt import TXTLoader
# from .html import HTMLLoader

# __all__ = (
#     "MSWordLoader",
#     "QAFileLoader",
#     "PDFMarkdown",
#     "PDFTables",
#     "TXTLoader",
#     "PDFBlocks",
#     "HTMLLoader",
# )
