# [Agentic] Tracing

This tutorial demonstrates how to implement hierarchical and custom tracing in AgentEx agents using the agentic ACP type.

## Official Documentation

[030 Tracing Base Agentic](https://dev.agentex.scale.com/docs/tutorials/agentic/base/tracing/)