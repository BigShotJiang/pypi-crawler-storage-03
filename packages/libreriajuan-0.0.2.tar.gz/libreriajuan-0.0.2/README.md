# Guia para usar mi libreria
## Existen 4 funciones 
## #md
donde se encuentra la multipliacion division como suma y resta de dos numeros.
se requiere 2 numeros a,b que se multiplican, se dividen, se restan y se suman con md dividir 

## sr
por el momento no se usa esto pero a futuro y otras versiones si 
