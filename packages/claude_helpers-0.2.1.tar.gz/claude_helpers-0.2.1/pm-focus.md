---
datetime: "2025-08-25T19:37:59Z"
increment: "01-models-validation"
component: "01-data-api"
release: "01-pre-alpha"
---

# PM Focus - 01-data-api

## Your Role

You are the Product Manager (PM) orchestrating the implementation of **01-data-api** in release **01-pre-alpha**.

### Key Responsibilities:
- **Coordinate** between owner and development team
- **Ensure** increment objectives are met
- **Manage** workflow transitions between roles (owner → PM → dev → tech-lead)
- **Track** progress and report to owner
- **Make decisions** on implementation approach when needed

### Current Status:
- **Active Increment**: 01-models-validation
- **Component**: 01-data-api
- **Release**: 01-pre-alpha

---

## Product/Release Context

## Product Vision

# Kenoma Product Vision

## 1. Vision (1–2 предложения)
- Kenoma — AI-powered "второй мозг", автоматически превращающий фрагментированную цифровую информацию в actionable intelligence.
- Трансформируем хаос из 10+ цифровых инструментов в единый граф знаний с AI-ассистентом, понимающим ваш полный контекст.

## 2. Почему сейчас
- Взрыв LLM возможностей (GPT-4, Claude) создал спрос на персонализированный AI
- Knowledge workers тратят ~48% времени на поиск информации и переключение контекста
- Раннее большинство готово экспериментировать с AI-native workflows после успеха ChatGPT

## 3. Для кого (аудитория/персоны)
- Персоны: AI-forward knowledge workers (startup founders, архитекторы ПО, product managers)
- Сегменты: B2C → B2B SMB (переход к командам после валидации персонального использования)

## 4. Проблема (Pain Points)
- Критическая информация разбросана по email, Slack, Notion, Docs, Zoom — невозможно держать в голове
- Каждое переключение приложения теряет контекст, ручной copy-paste в ChatGPT неэффективен
- LLM мощные, но не знают вашу историю, предпочтения, стиль коммуникации

## 5. Ценность (Value Proposition)
- Автоматическая агрегация всех цифровых touchpoints в единый граф знаний
- AI-ассистент с полным контекстом: находит связи, напоминает, драфтит в вашем стиле
- 20-25% рост продуктивности, 35% экономия времени на поиск информации

## 6. Что мы строим (Capabilities)
- Коннекторы к источникам данных (email, messengers, docs, meetings)
- Интеллектуальная обработка: NLP, semantic search, knowledge graph
- Персональный AI с контекстом: Q&A, insights, smart drafts, proactive reminders

## 7. Дифференциаторы
- Privacy-by-design: полная изоляция данных, selective encryption
- Платформенный подход: открытые API для кастомных приложений
- Фокус на автоматизации vs ручной организации (Notion, Obsidian)

## 8. Принципы продукта
- Минимум ручной работы — максимум автоматизации сбора и организации
- Данные пользователя священны — encryption, isolation, user control
- AI должен усиливать, не заменять — augmentation over automation

## 9. Глоссарий
- **Knowledge Graph** — семантическая сеть связей между вашими данными
- **Digital Memory** — автоматически собранный и структурированный цифровой контекст
- **Modus Ecosystem** — платформа для AI-augmented knowledge work приложений
- **Connector** — провайдер динамического контекста (сервис, плагин, расширение, IoT), проактивно отправляющий данные в Kenoma (отличие от MCP — push vs pull)
- **Apps** — приложения ценности на базе Kenoma (ассистенты, автоматизации, дашборды), использующие накопленный контекст для решения задач пользователя
- **Memoria** — предыдущее название проекта Kenoma (legacy)
- **MindBank** — альтернативное предыдущее название проекта Kenoma (legacy)

---

## Release: 01-pre-alpha

# Pre-Alpha Requirements Document

## Introduction

Pre-Alpha is a pure technical validation release of Kenoma's core data processing pipeline. This release focuses on proving that we can successfully collect, process, normalize, and provide access to multi-modal data from external sources. No user interface or user-facing features will be built - this is strictly a technical proof-of-concept to validate the foundational architecture.

## Alignment with Product Vision

This release validates the fundamental premise of Kenoma: the ability to automatically aggregate and process fragmented digital information into a unified, queryable format. Pre-Alpha establishes the technical foundation for the "AI-powered second brain" by proving we can:
- Collect data from external sources in real-time
- Process multi-modal content (text, images, audio, video)
- Normalize everything into a unified data model
- Provide intelligent access through semantic search

Without this core pipeline working, the rest of the vision cannot be realized.

## Requirements

### Requirement 1: File System Data Loader

**User Story:** As an engineer, I want to load files from a directory into Kenoma, so that I can test the data processing pipeline with real files

#### Acceptance Criteria

1. The loader SHALL accept a directory path via CLI command
2. The loader SHALL recursively scan and load all files from the specified directory
3. The loader SHALL preserve the directory hierarchy and structure in Kenoma
4. The loader SHALL support various file types (text, images, audio, video, documents)
5. The loader SHALL generate metadata (filepath, filename, file type, size) for each file
6. Subdirectories SHALL be treated as logical groupings (e.g., conversations, topics)
7. The loader SHALL process all files in a single batch operation

### Requirement 2: Multi-Modal Data Processing

**User Story:** As a system, I want to process different content types into normalized text representation, so that all information can be queried uniformly

#### Acceptance Criteria

1. WHEN text content is received THEN the system SHALL store it in searchable format
2. WHEN an image is received THEN the system SHALL generate description using vision AI (OCR/Vision capabilities)
3. WHEN audio/video is received THEN the system SHALL transcribe speech to text using STT services
4. WHEN documents are received THEN the system SHALL extract text content for supported formats:
   - PDF files
   - DOCX/DOC files
   - XLSX/XLS files (Excel)
   - TXT files
   - CSV files
5. The system SHALL store only text representation and metadata, NOT the original multi-modal files
6. All processed content SHALL include metadata about original format and processing details

### Requirement 3: Unified Data Storage

**User Story:** As an engineer, I want all processed data stored in a unified schema, so that I can query across different content types consistently

#### Acceptance Criteria

1. The system SHALL store all content with a common schema including: ID, source, timestamp, content_type, text_content, metadata
2. The system SHALL store ONLY text representations, not original multi-modal data
3. The system SHALL maintain relationships between related messages (replies, threads) where applicable
4. The system SHALL support both full-text search and vector embeddings for semantic search
5. Data SHALL be persisted with support for both structured queries and vector operations
6. The system SHALL generate and store embeddings for all text content for semantic search

### Requirement 4: Data Access API

**User Story:** As a developer, I want to query stored data through an API, so that I can build applications on top of the processed context

#### Acceptance Criteria

1. The API SHALL provide endpoints for filtering data by: date range, source, content type, and custom metadata
2. The API SHALL support semantic search returning results ranked by relevance with scores
3. The API SHALL return data in a unified JSON format regardless of original content type
4. The API SHALL support pagination for large result sets
5. No authentication required between services for pre-alpha

## Non-Functional Requirements

### Performance
- Support parallel processing of messages (up to 20 concurrent threads)
- Handle bulk historical data import efficiently
- No specific latency requirements for individual message processing (depends on external AI services)

### Reliability
- System can be manually restarted without data loss
- All processing errors logged with full context for debugging
- Failed processing attempts retry with exponential backoff
- Graceful handling of malformed or unsupported content

### Security
- No authentication required between internal services for pre-alpha
- Data stored unencrypted for pre-alpha (encryption planned for alpha)
- Single tenant only - no data isolation required yet

## Scope Definition

### In Scope
- File system data loader via CLI command
- Ingest pipeline for multi-modal data processing
- Text extraction from images, audio, video, and documents (PDF, DOCX, XLSX, TXT, CSV)
- Unified text-only storage (no original media storage)
- Basic REST API for data access
- Semantic/vector search capabilities
- Directory hierarchy preservation
- Bulk file import in single operation
- Technical documentation

### Out of Scope
- Any user interface (web or mobile)
- User registration or authentication system
- Real external connectors (Telegram, etc.)
- Multi-tenant data isolation
- Production deployment or hosting
- Automated setup or configuration
- Data encryption
- Storage of original multi-modal files
- Backup and recovery procedures
- Monitoring and alerting

### Dependencies
- File system access for simulator
- AI service for OCR and vision processing
- Speech-to-text service capabilities
- Vector search capability for semantic operations
- Storage solution with flexible schema support

### Assumptions
- Manual configuration via config files is acceptable
- Single tenant/instance for testing
- Test data can be synthetic or from test accounts
- External AI services (OpenAI) can be used for processing
- No high availability requirements

## Success Metrics

### Technical Metrics
- Successfully process 1000+ files from file system without critical errors
- Process all supported content types (text, image, audio, video, documents)
- Parallel processing working with multiple concurrent threads
- Vector search returns relevant results for test queries

### Functional Metrics
- All 4 major requirements fully implemented and tested
- File loader successfully imports entire directory structures
- All supported file types successfully converted to text
- API supports all specified query types (filter, search, pagination)

### Quality Metrics
- No data loss during processing pipeline
- All errors logged with sufficient detail for debugging
- Technical documentation covers setup and API usage
- System can be restarted without losing processed data

## Risks & Mitigations

### Risk: AI Service Dependencies
**Description:** Reliance on external AI services (OpenAI) for processing could cause delays or failures
**Impact:** High
**Mitigation:** Implement fallback providers and graceful degradation for non-critical features

### Risk: Vector Search Performance
**Description:** Vector search might not scale well with data volume
**Impact:** Medium
**Mitigation:** Choose proven vector search solution, implement pagination, test with realistic data volumes

### Risk: File System Performance
**Description:** Large file volumes might impact processing speed
**Impact:** Low
**Mitigation:** Implement batching, parallel processing, and configurable limits

## Deliverables

1. **Ingest Pipeline** - Complete data processing flow for multi-modal content
2. **File System Loader** - CLI tool to import directory contents into Kenoma
3. **Data Storage Layer** - Unified storage with vector search capabilities
4. **REST API** - Documented API with search and filter endpoints
5. **Setup Documentation** - CLI commands and configuration guide
6. **Architecture Documentation** - Technical design and data flow diagrams
7. **Test Results** - Report showing all success metrics achieved

---


---

## Component Specification

```markdown
Component specification not found
```

---

## Decomposition Overview

```markdown
---
datetime: "2025-08-25T19:26:42Z"
---

# Декомпозиция: Data API

**Архитектура:** `/architecture/releases/01-pre-alpha/components/01-data-api.md`
**Initial State:** Есть `/implementation/releases/01-pre-alpha/components/01-data-api/initial-state.md`
**Инкрементов:** 6
**Оценка:** ~32 часа

## Контекст

### Изменения в релизе

Новый компонент в релизе 01-pre-alpha:
- Полная реализация REST API для универсального хранения документов с векторами
- Интеграция с OpenSearch для хранения, поиска и векторных операций
- Поддержка namespaces для изоляции данных
- Универсальные операции: сохранение, получение, удаление, поиск документов
- Три типа поиска: текстовый, векторный, гибридный

### Исходное состояние

Реализовано: 
- Базовая структура Python проекта с конфигурацией через Pydantic
- Система логирования и тестирования
- Makefile с командами разработки

Можно переиспользовать:
- Config класс для расширения настройками API и OpenSearch
- Готовая структура тестов (unit/integration/e2e)
- Система логирования setup_logging()

Технический долг:
- Отсутствует HTTP сервер (FastAPI не настроен)
- Нет моделей данных для API
- Нет интеграции с OpenSearch
- Нужно обновить префиксы конфигурации с SERVICE_NAME_ на DATA_API_

### Фокус декомпозиции

- Реализовать полный REST API согласно спецификации архитектуры
- Интегрировать OpenSearch с поддержкой векторного поиска
- Создать все операции: POST, GET, DELETE, поиск
- Настроить namespace isolation через индексы
- Добавить валидацию, error handling, retry логику

## Стратегия

Bottom-up - начинаем с базовых моделей и протоколов, затем инфраструктура (OpenSearch), потом API endpoints

---

## Инкременты

### 01: Модели и валидация
- **Slug:** `01-models-validation`
- **Описание:** Создаём Pydantic модели для всех request/response, настраиваем валидацию полей согласно ограничениям архитектуры.
- **Покрывает:** Секции 2 (операции), 5 (валидационные правила)
- **Время:** 4ч
- **Зависит от:** -
- **Результат:** Набор Pydantic моделей с полной валидацией для API

### 02: OpenSearch интеграция
- **Slug:** `02-opensearch-integration`
- **Описание:** Реализуем клиент OpenSearch, создание индексов с kNN mapping, базовые операции CRUD и поиск.
- **Покрывает:** Секция 3 (зависимости), секция 4 (сценарии OpenSearch)
- **Время:** 6ч
- **Зависит от:** 01
- **Результат:** Работающая интеграция с OpenSearch с поддержкой векторов

### 03: Storage протокол и сервисы
- **Slug:** `03-storage-protocol`
- **Описание:** Определяем протоколы для хранилища, создаём сервисы для работы с документами, реализуем бизнес-логику.
- **Покрывает:** Секция 4 (сценарии обработки)
- **Время:** 5ч
- **Зависит от:** 02
- **Результат:** Protocol интерфейсы и сервисы для управления документами

### 04: CRUD endpoints
- **Slug:** `04-crud-endpoints`
- **Описание:** Создаём FastAPI endpoints для сохранения, получения и удаления документов по ID.
- **Покрывает:** Секция 2 (операции POST, GET, DELETE)
- **Время:** 6ч
- **Зависит от:** 03
- **Результат:** API endpoints POST, GET, DELETE с валидацией

### 05: Search endpoint
- **Slug:** `05-search-endpoint`
- **Описание:** Реализуем универсальный поиск с фильтрами, текстовым, векторным и гибридным поиском, пагинацией.
- **Покрывает:** Секция 2 (операция POST /search), секция 4 (сценарии поиска)
- **Время:** 7ч
- **Зависит от:** 03
- **Результат:** Работающий POST /search endpoint со всеми типами поиска

### 06: Служебные endpoints и финализация
- **Slug:** `06-service-endpoints`
- **Описание:** Добавляем GET /namespaces, GET /schema, error handling, retry логику, интеграционные тесты.
- **Покрывает:** Секция 2 (служебные операции), секция 5 (требования)
- **Время:** 4ч
- **Зависит от:** 04, 05
- **Результат:** Production-ready сервис с полным API покрытием

---

## Последовательность

```
01 → 02 → 03 → 06 (критический путь)
          ├→ 04
          └→ 05
```

---

## Заметки

- OpenSearch интеграция (02) делается рано из-за технических рисков
- Endpoints (04, 05) можно разрабатывать параллельно после готовности сервисов
- Retry логика и error handling критичны для работы с OpenSearch
```

---

## Current State

```markdown
### Initial State


# Initial State: Data API

**Дата snapshot:** 2025-08-25

---

## Overview реализации

Data API компонент создан на основе python-basic-edit скелетона и представляет собой базовую инфраструктуру для HTTP API сервиса на Python. На данный момент реализована только базовая структура проекта с системой конфигурации, логирования и тестирования.

Компонент предназначен для предоставления REST API интерфейса для доступа к данным системы. В текущем состоянии содержит минимальную инфраструктуру для быстрого старта разработки API endpoints, но не содержит бизнес-логики или конкретных API методов.

Скелетон следует принципам Clean Architecture и предоставляет готовую структуру для разработки микросервисов с упором на тестируемость и качество кода.

---

## Структура реализации

### Организация кода

```
01-data-api/
├── src/
│   ├── __init__.py         # [Инициализация пакета]
│   ├── __main__.py         # [Точка входа для запуска через python -m src]
│   └── config.py           # [Конфигурация сервиса и настройка логирования]
├── tests/
│   ├── __init__.py         # [Инициализация тестового пакета]
│   ├── conftest.py         # [Общие фикстуры pytest]
│   ├── factories/          # [Фабрики тестовых данных (Polyfactory)]
│   │   └── __init__.py
│   ├── unit/               # [Unit тесты с мокированием зависимостей]
│   │   ├── __init__.py
│   │   ├── conftest.py     # [Фикстуры для unit тестов]
│   │   └── test_config.py  # [Тест конфигурации]
│   ├── integration/        # [Интеграционные тесты с реальной инфраструктурой]
│   │   ├── __init__.py
│   │   └── conftest.py     # [Фикстуры для интеграционных тестов]
│   └── e2e/               # [End-to-end тесты полных сценариев]
│       ├── __init__.py
│       └── conftest.py    # [Фикстуры для e2e тестов]
├── pyproject.toml         # [Описание проекта и зависимостей]
├── Makefile              # [Команды для разработки]
└── README.md             # [Документация скелетона]
```

### Основные модули и их назначение

- **src/config.py**: Управление конфигурацией через Pydantic Settings с префиксом переменных окружения
- **src/__main__.py**: Точка входа сервиса с инициализацией логирования и конфигурации
- **tests/**: Полная структура тестирования по принципу Test Pyramid (unit/integration/e2e)
- **pyproject.toml**: Современное описание Python проекта с настройками инструментов качества кода

---

## Технический стек и паттерны

### Технологии

- **Язык**: Python 3.13+
- **Конфигурация**: Pydantic Settings 2.0+
- **Тестирование**: pytest 8.0+ с поддержкой asyncio
- **Качество кода**: Ruff (linting + formatting)
- **Менеджер пакетов**: uv (современная альтернатива pip/poetry)
- **Сборка**: Hatchling

### Архитектурные паттерны

- **Configuration Management**: Централизованная конфигурация через Pydantic с валидацией
  - Пример: Использование переменных окружения с префиксом SERVICE_NAME_
- **Dependency Injection**: Подготовка к использованию DI через кеширование конфигурации
  - Пример: @lru_cache для get_config()
- **Test Pyramid**: Структурированное тестирование на трех уровнях
  - Unit тесты для изолированного тестирования логики
  - Integration тесты для проверки взаимодействия компонентов
  - E2E тесты для проверки полных пользовательских сценариев

### Кодовые соглашения

- **Стиль кода**: Ruff с line-length=120, совместимость с Python 3.13
- **Именование**: Snake_case для переменных, PascalCase для классов
- **Структура модулей**: Плоская структура в src/ с разделением по функциональности

---

## Конфигурация

### Основные конфиги

```yaml
# Базовая структура конфигурации (будет расширена)
service:
  name: "data-api"  # TODO: обновить при создании сервиса
  environment: "development"
  log_level: "INFO"

# Для будущих расширений:
# database:
#   connection: [connection string]
# api:
#   host: "0.0.0.0"
#   port: 8000
```

### Переменные окружения

- `DATA_API_SERVICE_NAME` - Название сервиса (по умолчанию: "data-api")
- `DATA_API_ENVIRONMENT` - Окружение (development/staging/production)
- `DATA_API_LOG_LEVEL` - Уровень логирования (DEBUG/INFO/WARNING/ERROR)

### Важные настройки

- **Префикс переменных**: Все переменные окружения должны начинаться с `DATA_API_`
- **Конфигурационный файл**: Поддержка .env файлов для локальной разработки
- **Кеширование**: Конфигурация кешируется с использованием @lru_cache

---

## Тестирование

### Структура тестов

```
tests/
├── unit/                  # Быстрые изолированные тесты
│   ├── conftest.py       # Фикстуры с мокированием
│   └── test_config.py    # Тестирование конфигурации
├── integration/          # Тесты с реальной инфраструктурой
│   └── conftest.py       # Фикстуры для testcontainers
├── e2e/                  # End-to-end тесты
│   └── conftest.py       # Фикстуры для полных сценариев
└── factories/            # Генерация тестовых данных
    └── __init__.py       # Polyfactory фабрики
```

### Подход к тестированию

- **Unit тесты**: Полная изоляция с мокированием всех внешних зависимостей
- **Integration тесты**: Использование testcontainers для реальной инфраструктуры
- **Fixtures**: Организованы по уровням с переиспользованием базовых фикстур

### Запуск тестов

```bash
# Все тесты
make test

# По типам
make test-unit          # Быстрые unit тесты
make test-integration   # Интеграционные тесты
make test-e2e          # End-to-end тесты

# С покрытием
make test-cov
```

---

## Ключевые компоненты для переиспользования

### Модели и схемы данных
- **Config**: Базовый класс конфигурации готов для расширения дополнительными настройками API

### Сервисы и бизнес-логика
- **setup_logging()**: Готовая функция настройки логирования для сервиса
- **get_config()**: Кеширующий получатель конфигурации

### Интеграции и адаптеры
- Готовая структура для добавления адаптеров к внешним системам
- Подготовленные места для dependency injection

### Утилиты и helpers
- **Makefile**: Полный набор команд для разработки (test/lint/format/run/clean)
- **pyproject.toml**: Настройки инструментов разработки (pytest, ruff)

---

## Известные ограничения и технический долг

### Функциональные ограничения

*Отсутствует вся бизнес-логика API:*

- ❌ HTTP сервер не настроен (нет FastAPI/Flask)
- ❌ API endpoints не реализованы
- ❌ Модели данных отсутствуют
- ❌ Интеграция с базой данных не настроена
- ❌ Аутентификация и авторизация не реализована

### Технический долг

*Скелетон требует адаптации под конкретный сервис:*

- **Конфигурация**: Нужно обновить префиксы SERVICE_NAME_ на DATA_API_
- **Именование**: Заменить "service-name" на "data-api" в pyproject.toml
- **Зависимости**: Добавить FastAPI, SQL/NoSQL драйверы, клиенты внешних API

### Performance и масштабируемость

*Базовая структура не содержит производительных решений:*

- Отсутствует конфигурация пула соединений
- Нет настроек кеширования
- Отсутствуют метрики и мониторинг

---

## Внешние интерфейсы

### API Endpoints
```
# Пока не реализованы, будут добавлены в процессе разработки
# Планируется REST API для работы с данными
```

### События и сообщения
- **Публикует**: Пока не определено
- **Подписан на**: Пока не определено

### CLI команды
```bash
# Базовые команды уже доступны
python -m src           # Запуск сервиса
make run               # Запуск через Makefile
make test              # Запуск тестов
make check             # Проверка качества кода
```

---

## Точки входа и отладка

### Основные точки входа
- **Main**: `src/__main__.py` - инициализация конфигурации и логирования
- **Инициализация**: Выполняется в main() функции с логированием процесса
- **Graceful shutdown**: Пока не реализован, требует добавления signal handlers

### Отладка и мониторинг
- **Логирование**: Стандартный Python logging с конфигурируемым уровнем
- **Метрики**: Не настроены, требуется добавление Prometheus/метрик
- **Health checks**: Не реализованы, потребуются для production

### Локальная разработка
```bash
# Установка зависимостей
uv sync
make install

# Запуск сервиса
python -m src
make run

# Разработка с автоперезагрузкой (требует настройки)
# TODO: добавить hot-reload для разработки
```

---

## Примечания для декомпозиции

*Важная информация для планирования инкрементов:*

### Области готовые к расширению
- Конфигурация легко расширяется добавлением полей в Config класс
- Структура тестов готова для добавления тестов API endpoints
- Makefile подготовлен для добавления новых команд разработки

### Требуют внимания при изменении
- Префикс переменных окружения нужно обновить во всех файлах одновременно
- pyproject.toml требует синхронного обновления name и описания
- Структуру логирования сложно менять после интеграции с внешними системами

### Зависимости для новой функциональности
- HTTP сервер (FastAPI/Flask) должен быть настроен в первую очередь
- Модели данных нужны перед реализацией API endpoints
- База данных должна быть настроена перед реализацией бизнес-логики
- Система мониторинга требуется для production-ready сервиса

### Progress State


# Progress History - 01-data-api


```

---

## Workflow Protocol

### 1. Starting Work
- Review this focus document
- Check current increment status in state
- Add journal entry marking PM session start
- Call dev agent with appropriate context

### 2. Managing Dev Work
- Monitor dev progress through journal entries
- Provide clarifications when requested
- Ensure dev follows increment requirements

### 3. Tech Lead Review
- Once dev completes, call tech-lead for review
- Process tech-lead feedback
- Decide if rework needed or increment complete

### 4. Completion
- Mark increment complete with journal entry
- Generate implementation overview
- Report to owner for next steps

### Available MCP Tools:
- `journal-note` - Add progress entries
- `next-increment` - Move to next increment
- `get-dev-focus` - Get dev agent focus
- `get-tech-lead-focus` - Get tech-lead focus
- `ask-memory-bank` - Query project knowledge

---

## Important Notes

- Always maintain clear journal entries for key decisions
- Ensure all increment requirements are met before moving forward
- Coordinate effectively between all roles
- Keep owner informed of significant issues or blockers