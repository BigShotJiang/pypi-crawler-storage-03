# flake8: noqa

# import apis into api package
from thousandeyes_sdk.event_detection.api.events_api import EventsApi

