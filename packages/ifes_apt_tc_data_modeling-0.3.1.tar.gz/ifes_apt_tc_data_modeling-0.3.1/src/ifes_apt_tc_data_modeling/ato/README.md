## Getting started
GPM/Rouen group ATO file formats. Some details have been communicated via A. London, D. Haley, and A. Ceguerra's libatomprobe
and recently https://zenodo.org/records/8382828