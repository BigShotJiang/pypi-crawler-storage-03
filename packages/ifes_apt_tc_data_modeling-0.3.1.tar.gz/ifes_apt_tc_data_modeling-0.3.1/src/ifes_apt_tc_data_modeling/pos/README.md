## Getting started
The classical POS(isition) file format used in atom probe.