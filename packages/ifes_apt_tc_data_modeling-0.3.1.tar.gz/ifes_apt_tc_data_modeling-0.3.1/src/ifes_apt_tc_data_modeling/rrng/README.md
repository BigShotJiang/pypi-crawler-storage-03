## Getting started
The classical RRNG ranging definitions file format.