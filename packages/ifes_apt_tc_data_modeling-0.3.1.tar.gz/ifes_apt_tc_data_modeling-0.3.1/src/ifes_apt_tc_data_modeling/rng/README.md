## Getting started
The classical RNG ranging definitions file format.