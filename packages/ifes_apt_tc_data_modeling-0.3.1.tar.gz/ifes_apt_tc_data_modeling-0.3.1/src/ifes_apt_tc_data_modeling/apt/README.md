## Getting started
AMETEK/Cameca APT file format used in IVAS/APSuite.
https://github.com/CamecaAPT/cameca-customanalysis-interface/wiki/IonData:-Sections