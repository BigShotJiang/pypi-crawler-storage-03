# DEPRECATED: This project is no longer supported and will be archived end of 2023. Please use [checkov](https://github.com/bridgecrewio/checkov) instead.

# Bridgecrew Python Package
[![build status](https://github.com/bridgecrewio/bridgecrew-py/workflows/release/badge.svg)](https://github.com/bridgecrewio/bridgecrew-py/actions?query=workflow%3Arelease)
[![PyPI](https://img.shields.io/pypi/v/bridgecrew)](https://pypi.org/project/checkov/)

Wraps checkov with a bridgecrew cli (does exactly the same)
