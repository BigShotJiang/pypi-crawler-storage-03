# envanter

[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](LICENSE)

Yet another environment parser.

Documentation available at:
[https://envanter.readthedocs.io/](https://envanter.readthedocs.io/)
