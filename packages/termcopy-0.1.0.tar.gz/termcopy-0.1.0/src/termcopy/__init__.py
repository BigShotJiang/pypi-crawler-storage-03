"""
termcopy - A CLI tool for terminal clipboard operations
"""

__version__ = "0.1.0"
__author__ = "scaryPonens"
__url__ = "https://github.com/scaryPonens/termco-py"
