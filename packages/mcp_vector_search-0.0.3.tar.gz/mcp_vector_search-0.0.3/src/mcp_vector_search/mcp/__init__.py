"""MCP server integration for MCP Vector Search."""
