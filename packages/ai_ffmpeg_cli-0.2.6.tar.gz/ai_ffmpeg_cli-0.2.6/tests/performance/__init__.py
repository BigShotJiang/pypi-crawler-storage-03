"""Performance tests for ai-ffmpeg-cli.

This package contains performance tests that measure speed, memory usage, and scalability.
Performance tests focus on ensuring the application meets performance requirements.
"""
