"""Chaukas Client SDK

Client-side Python SDK for the Chaukas agent audit and explainability platform.
"""

__version__ = "1.0.0"
__author__ = "Chaukas Team"
__license__ = "Apache-2.0"