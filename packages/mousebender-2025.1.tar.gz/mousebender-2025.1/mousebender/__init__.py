"""A package for implementing various Python packaging standards."""
