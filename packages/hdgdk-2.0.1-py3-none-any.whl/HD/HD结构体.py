from .config import Config, ctypes
from .config import auto_encode