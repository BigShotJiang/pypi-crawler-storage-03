from .main import solve

__all__ = ["solve"]
