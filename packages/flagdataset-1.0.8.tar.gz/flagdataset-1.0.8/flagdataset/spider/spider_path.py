import os

default_spider_path = os.path.join(os.path.expanduser("~"), ".sdk_download/tmp")
default_download_path = os.path.join(os.path.expanduser("~"), ".sdk_download/download")
