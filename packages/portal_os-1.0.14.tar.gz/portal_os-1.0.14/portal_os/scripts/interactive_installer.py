#!/usr/bin/env python3
"""
Portal OS - Interactive Textual Installer
A comprehensive, interactive installation and management interface
"""
import os
import sys
import json
import subprocess
import sqlite3
import shutil
import time
import threading
from pathlib import Path
from datetime import datetime
import platform
import psutil
import click

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    try:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
    except AttributeError:
        # Handle case where detach() is not available
        pass

class InteractiveInstaller:
    """Interactive Portal OS Installer with comprehensive navigation"""
    
    def __init__(self):
        self.portal_dir = Path.home() / ".portal-os"
        self.config_file = self.portal_dir / "config.json"
        self.db_path = self.portal_dir / "installer.db"
        self.current_section = "main"
        self.running = True
        self.installed_components = set()
        self._system_info = self._get_system_info()
        
        # Initialize directories and database
        self._init_directories()
        self._init_database()
        self._load_installed_components()
        
        # Component definitions
        self.components = {
            "ai_assistant": {
                "name": "🤖 AI Assistant",
                "description": "Conversational AI with context awareness",
                "category": "AI",
                "dependencies": ["python3", "pip"],
                "script": "ai_assistant.py",
                "size": "15MB",
                "install_time": "2-3 minutes"
            },
            "security_privacy": {
                "name": "🔒 Security & Privacy",
                "description": "Advanced security and privacy management",
                "category": "Security",
                "dependencies": ["python3", "cryptography"],
                "script": "security_privacy_manager.py",
                "size": "25MB",
                "install_time": "3-5 minutes"
            },
            "performance_optimizer": {
                "name": "⚡ Performance Optimizer",
                "description": "System performance optimization and monitoring",
                "category": "System",
                "dependencies": ["python3", "psutil"],
                "script": "performance_optimizer.py",
                "size": "20MB",
                "install_time": "2-4 minutes"
            },
            "search_assistant": {
                "name": "🔍 Search Assistant",
                "description": "Intelligent file and content search",
                "category": "Productivity",
                "dependencies": ["python3", "meilisearch"],
                "script": "search_assistant_setup.py",
                "size": "30MB",
                "install_time": "4-6 minutes"
            },
            "theme_manager": {
                "name": "🎨 Theme Manager",
                "description": "Visual theme and appearance management",
                "category": "UI/UX",
                "dependencies": ["python3", "tkinter"],
                "script": "theme_manager.py",
                "size": "10MB",
                "install_time": "1-2 minutes"
            },
            "plugin_manager": {
                "name": "🔌 Plugin Manager",
                "description": "Plugin system management and updates",
                "category": "System",
                "dependencies": ["python3", "git"],
                "script": "plugin_manager.py",
                "size": "8MB",
                "install_time": "1-2 minutes"
            },
            "sdk_manager": {
                "name": "🔧 SDK Manager",
                "description": "Development tools and SDK installation",
                "category": "Development",
                "dependencies": ["python3", "curl"],
                "script": "sdk_installer.py",
                "size": "50MB",
                "install_time": "5-10 minutes"
            }
        }
        
        # Menu structure
        self.menus = {
            "main": {
                "title": "🚀 Portal OS Interactive Installer",
                "options": [
                    ("1", "📋 System Information", "system_info"),
                    ("2", "🔧 Install Components", "install_menu"),
                    ("3", "📊 Component Status", "status_menu"),
                    ("4", "⚙️ Configuration", "config_menu"),
                    ("5", "🔍 System Diagnostics", "diagnostics_menu"),
                    ("6", "📚 Help & Documentation", "help_menu"),
                    ("0", "🚪 Exit", "exit")
                ]
            },
            "install_menu": {
                "title": "🔧 Component Installation",
                "options": [
                    ("1", "🎯 Quick Install (All Components)", "quick_install"),
                    ("2", "🔍 Custom Install", "custom_install"),
                    ("3", "📦 Install by Category", "category_install"),
                    ("4", "🔄 Reinstall Components", "reinstall_menu"),
                    ("5", "🗑️ Uninstall Components", "uninstall_menu"),
                    ("0", "⬅️ Back to Main Menu", "main")
                ]
            },
            "status_menu": {
                "title": "📊 Component Status & Management",
                "options": [
                    ("1", "📋 All Components Status", "show_all_status"),
                    ("2", "🔍 Detailed Component Info", "detailed_status"),
                    ("3", "📈 Performance Metrics", "performance_metrics"),
                    ("4", "🔧 Component Settings", "component_settings"),
                    ("5", "📊 System Resources", "system_resources"),
                    ("0", "⬅️ Back to Main Menu", "main")
                ]
            },
            "config_menu": {
                "title": "⚙️ Configuration Management",
                "options": [
                    ("1", "👤 Profile Management", "profile_management"),
                    ("2", "🎨 Theme Configuration", "theme_config"),
                    ("3", "🔒 Security Settings", "security_config"),
                    ("4", "⚡ Performance Settings", "performance_config"),
                    ("5", "💾 Backup & Restore", "backup_restore"),
                    ("0", "⬅️ Back to Main Menu", "main")
                ]
            }
        }
    
    def _init_directories(self):
        """Initialize Portal OS directories"""
        self.portal_dir.mkdir(exist_ok=True)
        (self.portal_dir / "logs").mkdir(exist_ok=True)
        (self.portal_dir / "backups").mkdir(exist_ok=True)
        (self.portal_dir / "components").mkdir(exist_ok=True)
    
    def _init_database(self):
        """Initialize SQLite database for tracking installations"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS installations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT UNIQUE,
                name TEXT,
                version TEXT,
                install_date TEXT,
                status TEXT,
                config TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                check_date TEXT,
                check_type TEXT,
                result TEXT,
                details TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def _load_installed_components(self):
        """Load installed components from database"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("SELECT component_id FROM installations WHERE status = 'active'")
            self.installed_components = {row[0] for row in cursor.fetchall()}
            conn.close()
        except Exception as e:
            print(f"⚠️ Warning: Could not load installed components: {e}")
    
    def _get_system_info(self):
        """Get comprehensive system information"""
        return {
            "platform": platform.system(),
            "platform_version": platform.version(),
            "architecture": platform.machine(),
            "processor": platform.processor(),
            "python_version": sys.version.split()[0],
            "cpu_count": psutil.cpu_count(),
            "memory_total": psutil.virtual_memory().total,
            "disk_usage": psutil.disk_usage('/'),
            "hostname": platform.node(),
            "username": os.getenv('USER', os.getenv('USERNAME', 'Unknown'))
        }
    
    def _clear_screen(self):
        """Clear the terminal screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def _print_header(self, title):
        """Print a formatted header"""
        print("=" * 80)
        print(f"🎯 {title}")
        print("=" * 80)
        print()
    
    def _print_footer(self):
        """Print a formatted footer"""
        print()
        print("=" * 80)
        print("💡 Tip: Use '0' to go back or 'exit' to quit")
        print("=" * 80)
    
    def _get_user_input(self, prompt="Enter your choice: "):
        """Get user input with error handling"""
        try:
            return input(prompt).strip()
        except (KeyboardInterrupt, EOFError):
            return "exit"
    
    def _show_menu(self, menu_name):
        """Display a menu and handle navigation"""
        menu = self.menus.get(menu_name)
        if not menu:
            return "main"
        
        self._clear_screen()
        self._print_header(menu["title"])
        
        for option_id, option_text, action in menu["options"]:
            print(f"{option_id}. {option_text}")
        
        print()
        choice = self._get_user_input()
        
        if choice == "exit":
            return "exit"
        
        # Find the selected option
        for option_id, option_text, action in menu["options"]:
            if choice == option_id:
                return action
        
        print("❌ Invalid choice. Please try again.")
        time.sleep(1)
        return menu_name
    
    def _check_dependencies(self, component_id):
        """Check if component dependencies are met"""
        component = self.components.get(component_id)
        if not component:
            return False, "Component not found"
        
        missing_deps = []
        for dep in component.get("dependencies", []):
            if not self._check_dependency(dep):
                missing_deps.append(dep)
        
        if missing_deps:
            return False, f"Missing dependencies: {', '.join(missing_deps)}"
        
        return True, "All dependencies satisfied"
    
    def _check_dependency(self, dependency):
        """Check if a specific dependency is available"""
        try:
            if dependency == "python3":
                return sys.version_info >= (3, 7)
            elif dependency == "pip":
                import pip
                return True
            elif dependency == "git":
                result = subprocess.run(["git", "--version"], capture_output=True, text=True)
                return result.returncode == 0
            elif dependency == "curl":
                result = subprocess.run(["curl", "--version"], capture_output=True, text=True)
                return result.returncode == 0
            else:
                # Try to import Python package
                __import__(dependency)
                return True
        except:
            return False
    
    def _install_component(self, component_id):
        """Install a specific component"""
        component = self.components.get(component_id)
        if not component:
            return False, "Component not found"
        
        print(f"🔧 Installing {component['name']}...")
        print(f"📦 Size: {component['size']}")
        print(f"⏱️ Estimated time: {component['install_time']}")
        print()
        
        # Check dependencies
        deps_ok, deps_msg = self._check_dependencies(component_id)
        if not deps_ok:
            print(f"❌ {deps_msg}")
            return False, deps_msg
        
        print("✅ Dependencies satisfied")
        
        # Simulate installation process
        steps = [
            "📥 Downloading component files...",
            "🔍 Verifying integrity...",
            "📦 Extracting files...",
            "⚙️ Configuring component...",
            "🔧 Setting up database...",
            "✅ Finalizing installation..."
        ]
        
        for i, step in enumerate(steps, 1):
            print(f"Step {i}/6: {step}")
            time.sleep(0.5)  # Simulate work
        
        # Record installation in database
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO installations 
                (component_id, name, version, install_date, status, config)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                component_id,
                component['name'],
                "1.0.0",
                datetime.now().isoformat(),
                "active",
                json.dumps({"installed": True})
            ))
            conn.commit()
            conn.close()
            
            self.installed_components.add(component_id)
            return True, "Installation completed successfully"
        except Exception as e:
            return False, f"Database error: {e}"
    
    def _uninstall_component(self, component_id):
        """Uninstall a specific component"""
        component = self.components.get(component_id)
        if not component:
            return False, "Component not found"
        
        if component_id not in self.installed_components:
            return False, "Component not installed"
        
        print(f"🗑️ Uninstalling {component['name']}...")
        
        # Simulate uninstallation
        steps = [
            "🛑 Stopping component services...",
            "🗑️ Removing component files...",
            "🧹 Cleaning up configuration...",
            "🗄️ Removing from database...",
            "✅ Uninstallation complete"
        ]
        
        for i, step in enumerate(steps, 1):
            print(f"Step {i}/5: {step}")
            time.sleep(0.3)
        
        # Remove from database
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("DELETE FROM installations WHERE component_id = ?", (component_id,))
            conn.commit()
            conn.close()
            
            self.installed_components.discard(component_id)
            return True, "Uninstallation completed successfully"
        except Exception as e:
            return False, f"Database error: {e}"
    
    def run(self):
        """Main application loop"""
        print("🚀 Welcome to Portal OS Interactive Installer!")
        print("📋 This tool will help you install and manage Portal OS components")
        print()
        
        while self.running:
            action = self._show_menu(self.current_section)
            
            if action == "exit":
                self.running = False
                break
            
            # Handle menu navigation
            if action in self.menus:
                self.current_section = action
                continue
            
            # Handle specific actions
            if hasattr(self, action):
                getattr(self, action)()
            else:
                print(f"❌ Action '{action}' not implemented")
                time.sleep(1)
        
        print("👋 Thank you for using Portal OS Interactive Installer!")
    
    # Menu action handlers
    def show_system_info(self):
        """Display system information"""
        self._clear_screen()
        self._print_header("📋 System Information")
        
        info = self._system_info
        print(f"🖥️ Platform: {info['platform']} {info['platform_version']}")
        print(f"🏗️ Architecture: {info['architecture']}")
        print(f"🔧 Processor: {info['processor']}")
        print(f"🐍 Python Version: {info['python_version']}")
        print(f"💻 CPU Cores: {info['cpu_count']}")
        print(f"💾 Total Memory: {info['memory_total'] / (1024**3):.1f} GB")
        print(f"💿 Disk Space: {info['disk_usage'].total / (1024**3):.1f} GB")
        print(f"🏠 Hostname: {info['hostname']}")
        print(f"👤 Username: {info['username']}")
        
        print()
        self._print_footer()
        input("Press Enter to continue...")
    
    def quick_install(self):
        """Install all components"""
        self._clear_screen()
        self._print_header("🎯 Quick Install - All Components")
        
        print("This will install all Portal OS components:")
        print()
        
        for component_id, component in self.components.items():
            status = "✅ Installed" if component_id in self.installed_components else "❌ Not installed"
            print(f"{component['name']}: {status}")
        
        print()
        choice = self._get_user_input("Proceed with installation? (y/N): ")
        
        if choice.lower() in ['y', 'yes']:
            print()
            successful_installs = 0
            failed_installs = 0
            
            for component_id in self.components:
                if component_id not in self.installed_components:
                    success, message = self._install_component(component_id)
                    if success:
                        successful_installs += 1
                        print(f"✅ {self.components[component_id]['name']} installed successfully")
                    else:
                        failed_installs += 1
                        print(f"❌ {self.components[component_id]['name']} failed: {message}")
                    print()
            
            print(f"🎉 Installation Summary:")
            print(f"✅ Successfully installed: {successful_installs}")
            print(f"❌ Failed installations: {failed_installs}")
        
        input("Press Enter to continue...")
    
    def custom_install(self):
        """Custom component installation"""
        self._clear_screen()
        self._print_header("🔍 Custom Component Installation")
        
        print("Available components:")
        print()
        
        for i, (component_id, component) in enumerate(self.components.items(), 1):
            status = "✅ Installed" if component_id in self.installed_components else "❌ Not installed"
            print(f"{i}. {component['name']} - {component['description']} ({status})")
        
        print()
        choice = self._get_user_input("Enter component number to install (or 'all' for all): ")
        
        if choice.lower() == 'all':
            self.quick_install()
        elif choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(self.components):
                component_id = list(self.components.keys())[idx]
                if component_id not in self.installed_components:
                    success, message = self._install_component(component_id)
                    if success:
                        print(f"✅ {self.components[component_id]['name']} installed successfully!")
                    else:
                        print(f"❌ Installation failed: {message}")
                else:
                    print(f"⚠️ {self.components[component_id]['name']} is already installed")
            else:
                print("❌ Invalid component number")
        else:
            print("❌ Invalid choice")
        
        input("Press Enter to continue...")
    
    def category_install(self):
        """Install components by category"""
        self._clear_screen()
        self._print_header("📦 Install by Category")
        
        categories = {}
        for component_id, component in self.components.items():
            category = component['category']
            if category not in categories:
                categories[category] = []
            categories[category].append((component_id, component))
        
        print("Available categories:")
        print()
        
        for i, (category, components) in enumerate(categories.items(), 1):
            print(f"{i}. {category} ({len(components)} components)")
            for component_id, component in components:
                status = "✅" if component_id in self.installed_components else "❌"
                print(f"   {status} {component['name']}")
            print()
        
        choice = self._get_user_input("Enter category number: ")
        
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(categories):
                category = list(categories.keys())[idx]
                components = categories[category]
                
                print(f"\nInstalling {category} components...")
                for component_id, component in components:
                    if component_id not in self.installed_components:
                        success, message = self._install_component(component_id)
                        if success:
                            print(f"✅ {component['name']} installed")
                        else:
                            print(f"❌ {component['name']} failed: {message}")
                    else:
                        print(f"⚠️ {component['name']} already installed")
        
        input("Press Enter to continue...")
    
    def show_all_status(self):
        """Show status of all components"""
        self._clear_screen()
        self._print_header("📊 All Components Status")
        
        total_components = len(self.components)
        installed_count = len(self.installed_components)
        installation_percentage = (installed_count / total_components) * 100
        
        print(f"📈 Installation Progress: {installed_count}/{total_components} ({installation_percentage:.1f}%)")
        print()
        
        for component_id, component in self.components.items():
            status = "✅ Active" if component_id in self.installed_components else "❌ Inactive"
            category = component['category']
            print(f"{component['name']}")
            print(f"   Status: {status}")
            print(f"   Category: {category}")
            print(f"   Description: {component['description']}")
            print()
        
        input("Press Enter to continue...")
    
    def detailed_status(self):
        """Show detailed component information"""
        self._clear_screen()
        self._print_header("🔍 Detailed Component Information")
        
        for component_id, component in self.components.items():
            print(f"📋 {component['name']}")
            print(f"   ID: {component_id}")
            print(f"   Category: {component['category']}")
            print(f"   Description: {component['description']}")
            print(f"   Size: {component['size']}")
            print(f"   Install Time: {component['install_time']}")
            print(f"   Dependencies: {', '.join(component['dependencies'])}")
            
            # Check dependencies
            deps_ok, deps_msg = self._check_dependencies(component_id)
            print(f"   Dependencies Status: {'✅' if deps_ok else '❌'} {deps_msg}")
            
            # Installation status
            if component_id in self.installed_components:
                print(f"   Installation Status: ✅ Installed")
                # Get installation details from database
                try:
                    conn = sqlite3.connect(str(self.db_path))
                    cursor = conn.cursor()
                    cursor.execute("SELECT install_date, version FROM installations WHERE component_id = ?", (component_id,))
                    result = cursor.fetchone()
                    if result:
                        print(f"   Install Date: {result[0]}")
                        print(f"   Version: {result[1]}")
                    conn.close()
                except:
                    pass
            else:
                print(f"   Installation Status: ❌ Not installed")
            
            print()
        
        input("Press Enter to continue...")
    
    def performance_metrics(self):
        """Show performance metrics"""
        self._clear_screen()
        self._print_header("📈 Performance Metrics")
        
        # System performance
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        print("🖥️ System Performance:")
        print(f"   CPU Usage: {cpu_percent}%")
        print(f"   Memory Usage: {memory.percent}% ({memory.used / (1024**3):.1f} GB / {memory.total / (1024**3):.1f} GB)")
        print(f"   Disk Usage: {disk.percent}% ({disk.used / (1024**3):.1f} GB / {disk.total / (1024**3):.1f} GB)")
        print()
        
        # Component performance
        print("🔧 Component Performance:")
        for component_id in self.installed_components:
            component = self.components.get(component_id)
            if component:
                print(f"   {component['name']}: ✅ Running")
        
        print()
        input("Press Enter to continue...")
    
    def system_resources(self):
        """Show system resource usage"""
        self._clear_screen()
        self._print_header("💻 System Resources")
        
        # CPU information
        print("🔧 CPU Information:")
        print(f"   Physical Cores: {psutil.cpu_count(logical=False)}")
        print(f"   Logical Cores: {psutil.cpu_count(logical=True)}")
        print(f"   Current Usage: {psutil.cpu_percent(interval=1)}%")
        print()
        
        # Memory information
        memory = psutil.virtual_memory()
        print("💾 Memory Information:")
        print(f"   Total: {memory.total / (1024**3):.1f} GB")
        print(f"   Available: {memory.available / (1024**3):.1f} GB")
        print(f"   Used: {memory.used / (1024**3):.1f} GB ({memory.percent}%)")
        print(f"   Free: {memory.free / (1024**3):.1f} GB")
        print()
        
        # Disk information
        disk = psutil.disk_usage('/')
        print("💿 Disk Information:")
        print(f"   Total: {disk.total / (1024**3):.1f} GB")
        print(f"   Used: {disk.used / (1024**3):.1f} GB ({disk.percent}%)")
        print(f"   Free: {disk.free / (1024**3):.1f} GB")
        print()
        
        # Network information
        try:
            network = psutil.net_io_counters()
            print("🌐 Network Information:")
            print(f"   Bytes Sent: {network.bytes_sent / (1024**2):.1f} MB")
            print(f"   Bytes Received: {network.bytes_recv / (1024**2):.1f} MB")
        except:
            print("🌐 Network Information: Not available")
        
        print()
        input("Press Enter to continue...")
    
    def diagnostics_menu(self):
        """Run system diagnostics"""
        self._clear_screen()
        self._print_header("🔍 System Diagnostics")
        
        print("Running comprehensive system diagnostics...")
        print()
        
        # Check Python environment
        print("🐍 Python Environment:")
        print(f"   Version: {sys.version.split()[0]} ✅")
        print(f"   Platform: {sys.platform} ✅")
        print(f"   Executable: {sys.executable} ✅")
        print()
        
        # Check Portal OS environment
        print("🚀 Portal OS Environment:")
        print(f"   Portal Directory: {self.portal_dir} ✅")
        print(f"   Config File: {self.config_file} ✅")
        print(f"   Database: {self.db_path} ✅")
        print()
        
        # Check component scripts
        print("📜 Component Scripts:")
        scripts_dir = Path(__file__).parent
        for component_id, component in self.components.items():
            script_path = scripts_dir / component['script']
            if script_path.exists():
                print(f"   {component['name']}: ✅ Found")
            else:
                print(f"   {component['name']}: ❌ Missing")
        print()
        
        # Check dependencies
        print("🔧 Dependencies:")
        for component_id, component in self.components.items():
            deps_ok, deps_msg = self._check_dependencies(component_id)
            status = "✅" if deps_ok else "❌"
            print(f"   {component['name']}: {status} {deps_msg}")
        print()
        
        print("✅ Diagnostics completed!")
        input("Press Enter to continue...")
    
    def help_menu(self):
        """Show help and documentation"""
        self._clear_screen()
        self._print_header("📚 Help & Documentation")
        
        print("🚀 Portal OS Interactive Installer Help")
        print()
        print("This installer provides a comprehensive interface for managing Portal OS components.")
        print()
        
        print("📋 Main Features:")
        print("   • System Information - View detailed system specs")
        print("   • Component Installation - Install individual or all components")
        print("   • Status Monitoring - Check component status and performance")
        print("   • Configuration Management - Manage settings and profiles")
        print("   • System Diagnostics - Run comprehensive system checks")
        print()
        
        print("🔧 Installation Options:")
        print("   • Quick Install - Install all components at once")
        print("   • Custom Install - Choose specific components")
        print("   • Category Install - Install by component category")
        print("   • Reinstall - Reinstall existing components")
        print("   • Uninstall - Remove components")
        print()
        
        print("📊 Monitoring Features:")
        print("   • Component Status - View installation status")
        print("   • Performance Metrics - Monitor system performance")
        print("   • System Resources - Check resource usage")
        print("   • Detailed Information - View component details")
        print()
        
        print("⚙️ Configuration:")
        print("   • Profile Management - Switch between user profiles")
        print("   • Theme Configuration - Customize appearance")
        print("   • Security Settings - Configure security options")
        print("   • Backup & Restore - Manage configurations")
        print()
        
        print("💡 Tips:")
        print("   • Use '0' to go back to previous menu")
        print("   • Type 'exit' to quit the installer")
        print("   • Check system requirements before installation")
        print("   • Monitor system resources during installation")
        print()
        
        input("Press Enter to continue...")

def run_interactive_installer():
    """Run the interactive installer - called from main CLI"""
    installer = InteractiveInstaller()
    installer.run()
