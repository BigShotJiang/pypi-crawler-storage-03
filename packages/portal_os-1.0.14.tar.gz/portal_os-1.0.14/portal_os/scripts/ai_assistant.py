#!/usr/bin/env python3
"""
Portal OS - AI Assistant
Conversational AI assistant with context awareness and multiple AI backends
"""
import click
import sys
import codecs
import json
import os
import sqlite3
import requests
import subprocess
import platform
from pathlib import Path
from datetime import datetime
import threading
import time
import asyncio
from typing import Dict, List, Optional, Any

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

class AIBackend:
    """Abstract base class for AI backends"""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.is_available = False
    
    def check_availability(self) -> bool:
        """Check if the backend is available"""
        raise NotImplementedError
    
    def generate_response(self, prompt: str, context: List[Dict] = None) -> str:
        """Generate a response from the AI backend"""
        raise NotImplementedError
    
    def get_models(self) -> List[str]:
        """Get available models for this backend"""
        raise NotImplementedError

class OllamaBackend(AIBackend):
    """Ollama local AI backend"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__("ollama", config)
        self.endpoint = config.get("endpoint", "http://localhost:11434")
        self.model = config.get("model", "llama2")
        self.timeout = config.get("timeout", 30)
    
    def check_availability(self) -> bool:
        """Check if Ollama is running and available"""
        try:
            response = requests.get(f"{self.endpoint}/api/tags", timeout=5)
            self.is_available = response.status_code == 200
            return self.is_available
        except Exception:
            self.is_available = False
            return False
    
    def get_models(self) -> List[str]:
        """Get available Ollama models"""
        try:
            response = requests.get(f"{self.endpoint}/api/tags", timeout=5)
            if response.status_code == 200:
                data = response.json()
                return [model["name"] for model in data.get("models", [])]
        except Exception:
            pass
        return []
    
    def generate_response(self, prompt: str, context: List[Dict] = None) -> str:
        """Generate response using Ollama"""
        if not self.is_available:
            return "❌ Ollama is not available. Please start Ollama or check your configuration."
        
        try:
            # Prepare the conversation
            messages = []
            
            # Add system context
            system_prompt = """You are Portal OS AI Assistant, a helpful AI assistant for developers. 
You help with coding, system administration, file operations, and general questions.
Be concise, helpful, and developer-focused."""
            messages.append({"role": "system", "content": system_prompt})
            
            # Add conversation context
            if context:
                for msg in context[-5:]:  # Last 5 messages for context
                    messages.append({"role": "user", "content": msg.get("user", "")})
                    messages.append({"role": "assistant", "content": msg.get("assistant", "")})
            
            # Add current prompt
            messages.append({"role": "user", "content": prompt})
            
            # Make request to Ollama
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": False,
                "options": {
                    "temperature": self.config.get("temperature", 0.7),
                    "top_p": self.config.get("top_p", 0.9),
                    "max_tokens": self.config.get("max_tokens", 2048)
                }
            }
            
            response = requests.post(
                f"{self.endpoint}/api/chat",
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get("message", {}).get("content", "No response generated")
            else:
                return f"❌ Error: {response.status_code} - {response.text}"
                
        except Exception as e:
            return f"❌ Error generating response: {str(e)}"

class GeminiBackend(AIBackend):
    """Google Gemini API backend"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__("gemini", config)
        self.api_key = config.get("api_key", "")
        self.model = config.get("model", "gemini-pro")
        self.endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
    
    def check_availability(self) -> bool:
        """Check if Gemini API is available"""
        self.is_available = bool(self.api_key)
        return self.is_available
    
    def get_models(self) -> List[str]:
        """Get available Gemini models"""
        return ["gemini-pro", "gemini-pro-vision"]
    
    def generate_response(self, prompt: str, context: List[Dict] = None) -> str:
        """Generate response using Gemini API"""
        if not self.is_available:
            return "❌ Gemini API key not configured. Please set your API key in the configuration."
        
        try:
            # Prepare the request
            headers = {
                "Content-Type": "application/json",
            }
            
            # Build context from conversation history
            context_text = ""
            if context:
                context_text = "\n".join([
                    f"User: {msg.get('user', '')}\nAssistant: {msg.get('assistant', '')}"
                    for msg in context[-3:]  # Last 3 messages for context
                ])
            
            full_prompt = f"""You are Portal OS AI Assistant, a helpful AI assistant for developers.

Previous conversation context:
{context_text}

Current user question: {prompt}

Please provide a helpful, developer-focused response."""

            payload = {
                "contents": [{
                    "parts": [{
                        "text": full_prompt
                    }]
                }],
                "generationConfig": {
                    "temperature": self.config.get("temperature", 0.7),
                    "topP": self.config.get("top_p", 0.9),
                    "maxOutputTokens": self.config.get("max_tokens", 2048)
                }
            }
            
            response = requests.post(
                f"{self.endpoint}?key={self.api_key}",
                json=payload,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                candidates = data.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    if parts:
                        return parts[0].get("text", "No response generated")
                return "No response generated"
            else:
                return f"❌ Error: {response.status_code} - {response.text}"
                
        except Exception as e:
            return f"❌ Error generating response: {str(e)}"

class AIAssistant:
    def __init__(self):
        self.conversation_history = []
        self.context = {}
        self.is_running = False
        self.db_path = Path.home() / ".portal-os" / "ai_assistant.db"
        self.db_path.parent.mkdir(exist_ok=True)
        self._init_database()
        self._load_config()
        self._init_backends()
    
    def _load_config(self):
        """Load AI assistant configuration"""
        config_file = Path.home() / ".portal-os" / "config" / "ai_assistant.json"
        config_file.parent.mkdir(exist_ok=True)
        
        if config_file.exists():
            try:
                with open(config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
            except Exception:
                self.config = self._get_default_config()
        else:
            self.config = self._get_default_config()
            self._save_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "default_backend": "ollama",
            "backends": {
                "ollama": {
                    "enabled": True,
                    "endpoint": "http://localhost:11434",
                    "model": "llama2",
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "max_tokens": 2048,
                    "timeout": 30
                },
                "gemini": {
                    "enabled": False,
                    "api_key": "",
                    "model": "gemini-pro",
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "max_tokens": 2048
                }
            },
            "features": {
                "context_awareness": True,
                "conversation_history": True,
                "system_integration": True,
                "code_analysis": True
            }
        }
    
    def _save_config(self):
        """Save configuration to file"""
        config_file = Path.home() / ".portal-os" / "config" / "ai_assistant.json"
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)
    
    def _init_backends(self):
        """Initialize AI backends"""
        self.backends = {}
        
        # Initialize Ollama backend
        if self.config["backends"]["ollama"]["enabled"]:
            self.backends["ollama"] = OllamaBackend(self.config["backends"]["ollama"])
        
        # Initialize Gemini backend
        if self.config["backends"]["gemini"]["enabled"]:
            self.backends["gemini"] = GeminiBackend(self.config["backends"]["gemini"])
        
        # Check availability
        for backend in self.backends.values():
            backend.check_availability()
    
    def _init_database(self):
        """Initialize SQLite database for conversation history"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                user_input TEXT,
                ai_response TEXT,
                backend TEXT,
                model TEXT,
                context TEXT
            )
        ''')
        conn.commit()
        conn.close()
    
    def start(self):
        """Start the AI assistant service"""
        self.is_running = True
        print("🤖 AI Assistant started successfully!")
        print("💬 Ready for conversations")
        print("📝 Type 'exit' to stop the assistant")
        
        # Show available backends
        available_backends = [name for name, backend in self.backends.items() if backend.is_available]
        if available_backends:
            print(f"🔧 Available AI backends: {', '.join(available_backends)}")
        else:
            print("⚠️ No AI backends available. Please check your configuration.")
        
        # Start conversation loop
        self._conversation_loop()
    
    def stop(self):
        """Stop the AI assistant service"""
        self.is_running = False
        print("🛑 AI Assistant stopped")
    
    def _conversation_loop(self):
        """Main conversation loop"""
        while self.is_running:
            try:
                user_input = input("👤 You: ").strip()
                if user_input.lower() in ['exit', 'quit', 'stop']:
                    self.stop()
                    break
                
                if user_input:
                    response = self._process_input(user_input)
                    print(f"🤖 Assistant: {response}")
                    self._save_conversation(user_input, response)
            except KeyboardInterrupt:
                self.stop()
                break
            except EOFError:
                self.stop()
                break
    
    def _process_input(self, user_input: str) -> str:
        """Process user input and generate response"""
        # Check for special commands
        if user_input.startswith('/'):
            return self._handle_special_command(user_input)
        
        # Get the default backend
        default_backend = self.config["default_backend"]
        backend = self.backends.get(default_backend)
        
        if not backend or not backend.is_available:
            # Fallback to rule-based responses
            return self._rule_based_response(user_input)
        
        # Generate AI response
        try:
            response = backend.generate_response(user_input, self.conversation_history)
            return response
        except Exception as e:
            return f"❌ Error: {str(e)}"
    
    def _handle_special_command(self, command: str) -> str:
        """Handle special commands"""
        cmd_parts = command[1:].split()
        cmd = cmd_parts[0].lower()
        
        if cmd == "help":
            return """Available commands:
/help - Show this help
/status - Show system status
/backends - List available backends
/models - List available models
/config - Show configuration
/clear - Clear conversation history
/switch <backend> - Switch AI backend"""
        
        elif cmd == "status":
            return self._get_system_status()
        
        elif cmd == "backends":
            return self._list_backends()
        
        elif cmd == "models":
            return self._list_models()
        
        elif cmd == "config":
            return self._show_config()
        
        elif cmd == "clear":
            self.conversation_history.clear()
            return "🗑️ Conversation history cleared"
        
        elif cmd == "switch" and len(cmd_parts) > 1:
            backend_name = cmd_parts[1]
            if backend_name in self.backends:
                self.config["default_backend"] = backend_name
                self._save_config()
                return f"✅ Switched to {backend_name} backend"
            else:
                return f"❌ Backend '{backend_name}' not found"
        
        else:
            return f"❌ Unknown command: {cmd}. Type /help for available commands."
    
    def _rule_based_response(self, user_input: str) -> str:
        """Fallback rule-based responses"""
        user_input_lower = user_input.lower()
        
        if "hello" in user_input_lower or "hi" in user_input_lower:
            return "Hello! I'm your Portal OS AI assistant. How can I help you today?"
        
        elif "time" in user_input_lower:
            current_time = datetime.now().strftime("%H:%M:%S")
            return f"The current time is {current_time}"
        
        elif "date" in user_input_lower:
            current_date = datetime.now().strftime("%Y-%m-%d")
            return f"Today's date is {current_date}"
        
        elif "help" in user_input_lower:
            return """I can help you with:
• System information (time, date, status)
• File operations and search
• System monitoring
• Code analysis and suggestions
• General questions and conversation
Just ask me anything!"""
        
        else:
            return "I'm here to help! What would you like to know or do?"
    
    def _get_system_status(self) -> str:
        """Get system status"""
        status_lines = []
        status_lines.append("🤖 AI Assistant Status:")
        status_lines.append(f"   Running: {'✅ Yes' if self.is_running else '❌ No'}")
        status_lines.append(f"   Conversations: {len(self.conversation_history)}")
        
        for name, backend in self.backends.items():
            status = "✅ Available" if backend.is_available else "❌ Unavailable"
            status_lines.append(f"   {name.capitalize()}: {status}")
        
        return "\n".join(status_lines)
    
    def _list_backends(self) -> str:
        """List available backends"""
        lines = ["🔧 Available AI Backends:"]
        for name, backend in self.backends.items():
            status = "✅ Available" if backend.is_available else "❌ Unavailable"
            lines.append(f"   {name.capitalize()}: {status}")
        return "\n".join(lines)
    
    def _list_models(self) -> str:
        """List available models"""
        lines = ["📦 Available Models:"]
        for name, backend in self.backends.items():
            if backend.is_available:
                models = backend.get_models()
                if models:
                    lines.append(f"   {name.capitalize()}: {', '.join(models)}")
                else:
                    lines.append(f"   {name.capitalize()}: No models found")
        return "\n".join(lines)
    
    def _show_config(self) -> str:
        """Show current configuration"""
        config_str = json.dumps(self.config, indent=2, ensure_ascii=False)
        return f"⚙️ Current Configuration:\n{config_str}"
    
    def _save_conversation(self, user_input: str, ai_response: str):
        """Save conversation to database"""
        backend = self.backends.get(self.config["default_backend"])
        backend_name = backend.name if backend else "unknown"
        model_name = backend.config.get("model", "unknown") if backend else "unknown"
        
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO conversations (timestamp, user_input, ai_response, backend, model, context)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (datetime.now().isoformat(), user_input, ai_response, backend_name, model_name, json.dumps(self.context)))
        conn.commit()
        conn.close()
        
        # Keep in memory for context
        self.conversation_history.append({
            'user': user_input,
            'assistant': ai_response,
            'timestamp': datetime.now()
        })
        
        # Limit history to last 20 conversations
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-20:]
    
    def get_status(self):
        """Get AI assistant status"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM conversations')
        conversation_count = cursor.fetchone()[0]
        conn.close()
        
        available_backends = [name for name, backend in self.backends.items() if backend.is_available]
        
        return {
            'running': self.is_running,
            'conversation_count': conversation_count,
            'context_size': len(self.context),
            'available_backends': available_backends,
            'default_backend': self.config["default_backend"]
        }

# Global AI assistant instance
ai_assistant = AIAssistant()

@click.group()
def cli():
    """AI Assistant - Conversational AI assistant with context awareness"""
    pass

@cli.command()
def start():
    """Start the AI assistant service"""
    if ai_assistant.is_running:
        print("🤖 AI Assistant is already running")
        return
    
    print("🤖 Starting AI Assistant...")
    ai_assistant.start()

@cli.command()
def stop():
    """Stop the AI assistant service"""
    if not ai_assistant.is_running:
        print("🤖 AI Assistant is not running")
        return
    
    print("🛑 Stopping AI Assistant...")
    ai_assistant.stop()

@cli.command()
def status():
    """Check AI assistant status"""
    status_info = ai_assistant.get_status()
    print("🤖 AI Assistant Status:")
    print(f"   Running: {'✅ Yes' if status_info['running'] else '❌ No'}")
    print(f"   Conversations: {status_info['conversation_count']}")
    print(f"   Context Size: {status_info['context_size']} items")
    print(f"   Default Backend: {status_info['default_backend']}")
    print(f"   Available Backends: {', '.join(status_info['available_backends'])}")

@cli.command()
def chat():
    """Start an interactive chat session"""
    if ai_assistant.is_running:
        print("🤖 AI Assistant is already running in another session")
        return
    
    print("💬 Starting chat session...")
    print("Type 'exit' to end the session")
    print("Type '/help' for available commands")
    ai_assistant.start()

@cli.command()
def history():
    """Show conversation history"""
    conn = sqlite3.connect(str(ai_assistant.db_path))
    cursor = conn.cursor()
    cursor.execute('SELECT timestamp, user_input, ai_response, backend, model FROM conversations ORDER BY timestamp DESC LIMIT 10')
    conversations = cursor.fetchall()
    conn.close()
    
    if not conversations:
        print("📝 No conversation history found")
        return
    
    print("📝 Recent Conversations:")
    print("-" * 60)
    for timestamp, user_input, ai_response, backend, model in conversations:
        dt = datetime.fromisoformat(timestamp)
        print(f"🕐 {dt.strftime('%Y-%m-%d %H:%M:%S')} ({backend}/{model})")
        print(f"👤 You: {user_input}")
        print(f"🤖 Assistant: {ai_response}")
        print("-" * 60)

@cli.command()
def backends():
    """List and test AI backends"""
    print("🔧 AI Backend Status:")
    print("-" * 40)
    
    for name, backend in ai_assistant.backends.items():
        status = "✅ Available" if backend.is_available else "❌ Unavailable"
        print(f"{name.capitalize()}: {status}")
        
        if backend.is_available:
            models = backend.get_models()
            if models:
                print(f"  Models: {', '.join(models[:3])}{'...' if len(models) > 3 else ''}")
    
    print(f"\nDefault backend: {ai_assistant.config['default_backend']}")

@cli.command()
@click.option('--backend', '-b', help='Backend to test (ollama, gemini)')
def test(backend):
    """Test AI backend with a simple prompt"""
    if backend:
        if backend not in ai_assistant.backends:
            print(f"❌ Backend '{backend}' not found")
            return
        test_backend = ai_assistant.backends[backend]
    else:
        test_backend = ai_assistant.backends.get(ai_assistant.config["default_backend"])
    
    if not test_backend:
        print("❌ No backend available for testing")
        return
    
    if not test_backend.is_available:
        print(f"❌ Backend '{test_backend.name}' is not available")
        return
    
    print(f"🧪 Testing {test_backend.name} backend...")
    test_prompt = "Hello! Can you tell me a short joke?"
    response = test_backend.generate_response(test_prompt)
    print(f"🤖 Response: {response}")

@cli.command()
def install():
    """Install AI assistant dependencies"""
    print("📦 Installing AI Assistant dependencies...")
    
    # Create necessary directories
    db_dir = ai_assistant.db_path.parent
    db_dir.mkdir(exist_ok=True)
    
    # Initialize database
    ai_assistant._init_database()
    
    # Check for Ollama
    print("🔍 Checking for Ollama...")
    try:
        result = subprocess.run(['ollama', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Ollama is installed")
        else:
            print("⚠️ Ollama not found. Install from https://ollama.ai")
    except FileNotFoundError:
        print("⚠️ Ollama not found. Install from https://ollama.ai")
    
    print("✅ AI Assistant dependencies installed successfully!")
    print(f"📁 Database location: {ai_assistant.db_path}")

@cli.command()
def configure():
    """Configure AI assistant settings"""
    print("⚙️ AI Assistant Configuration")
    print("=" * 40)
    
    # Get current config
    config = ai_assistant.config
    
    # Configure Ollama
    print("\n🔧 Ollama Configuration:")
    ollama_config = config["backends"]["ollama"]
    ollama_config["enabled"] = click.confirm("Enable Ollama backend?", default=ollama_config["enabled"])
    
    if ollama_config["enabled"]:
        ollama_config["endpoint"] = click.prompt(
            "Ollama endpoint", 
            default=ollama_config["endpoint"]
        )
        ollama_config["model"] = click.prompt(
            "Default model", 
            default=ollama_config["model"]
        )
        ollama_config["temperature"] = click.prompt(
            "Temperature (0.0-1.0)", 
            default=ollama_config["temperature"],
            type=float
        )
    
    # Configure Gemini
    print("\n🔧 Gemini Configuration:")
    gemini_config = config["backends"]["gemini"]
    gemini_config["enabled"] = click.confirm("Enable Gemini backend?", default=gemini_config["enabled"])
    
    if gemini_config["enabled"]:
        gemini_config["api_key"] = click.prompt(
            "Gemini API key", 
            default=gemini_config["api_key"],
            hide_input=True
        )
        gemini_config["model"] = click.prompt(
            "Model", 
            default=gemini_config["model"]
        )
    
    # Set default backend
    available_backends = [name for name, backend in config["backends"].items() if backend["enabled"]]
    if available_backends:
        config["default_backend"] = click.prompt(
            "Default backend",
            type=click.Choice(available_backends),
            default=config["default_backend"] if config["default_backend"] in available_backends else available_backends[0]
        )
    
    # Save configuration
    ai_assistant.config = config
    ai_assistant._save_config()
    ai_assistant._init_backends()
    
    print("\n✅ Configuration saved successfully!")
    print("🔄 Backends reinitialized")

if __name__ == "__main__":
    cli()
