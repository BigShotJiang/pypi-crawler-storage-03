import React, { useState, useEffect, useRef } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { open } from '@tauri-apps/api/shell';
import { register } from '@tauri-apps/api/globalShortcut';
import { Search, File, Folder, Code, Image, Video, Music, Document, Star, Clock, Settings } from 'lucide-react';
import './App.css';

interface SearchResult {
  id: number;
  file_path: string;
  file_name: string;
  file_type: string;
  file_size: number;
  last_modified: string;
  relevance: number;
  context?: string;
}

interface SearchHistory {
  id: number;
  query: string;
  results_count: number;
  timestamp: string;
}

function App() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [history, setHistory] = useState<SearchHistory[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState<'search' | 'history' | 'settings'>('search');
  const [indexStats, setIndexStats] = useState({ totalFiles: 0, lastIndexed: '' });
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Register global shortcut (Cmd+Space / Ctrl+Space)
    register('CommandOrControl+Space', () => {
      // Focus the search input
      searchInputRef.current?.focus();
    });

    // Load search history
    loadSearchHistory();
    loadIndexStats();

    // Focus search input on mount
    searchInputRef.current?.focus();
  }, []);

  const loadSearchHistory = async () => {
    try {
      const historyData = await invoke('get_search_history');
      setHistory(historyData as SearchHistory[]);
    } catch (error) {
      console.error('Failed to load search history:', error);
    }
  };

  const loadIndexStats = async () => {
    try {
      const stats = await invoke('get_index_stats');
      setIndexStats(stats as { totalFiles: number; lastIndexed: string });
    } catch (error) {
      console.error('Failed to load index stats:', error);
    }
  };

  const performSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const searchResults = await invoke('search_files', { query: searchQuery });
      setResults(searchResults as SearchResult[]);
    } catch (error) {
      console.error('Search failed:', error);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(query);
  };

  const handleQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuery = e.target.value;
    setQuery(newQuery);
    
    // Debounced search
    const timeoutId = setTimeout(() => {
      if (newQuery.trim()) {
        performSearch(newQuery);
      } else {
        setResults([]);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  };

  const openFile = async (filePath: string) => {
    try {
      await open(filePath);
    } catch (error) {
      console.error('Failed to open file:', error);
    }
  };

  const openFileLocation = async (filePath: string) => {
    try {
      // Extract directory path
      const pathParts = filePath.split(/[/\\]/);
      const fileName = pathParts.pop();
      const directory = pathParts.join('/');
      await open(directory);
    } catch (error) {
      console.error('Failed to open file location:', error);
    }
  };

  const getFileIcon = (fileType: string) => {
    const extension = fileType.toLowerCase();
    
    if (['.py', '.js', '.ts', '.java', '.cpp', '.c', '.go', '.rs'].includes(extension)) {
      return <Code className="w-4 h-4" />;
    } else if (['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg'].includes(extension)) {
      return <Image className="w-4 h-4" />;
    } else if (['.mp4', '.avi', '.mov', '.mkv', '.webm'].includes(extension)) {
      return <Video className="w-4 h-4" />;
    } else if (['.mp3', '.wav', '.flac', '.aac', '.ogg'].includes(extension)) {
      return <Music className="w-4 h-4" />;
    } else if (['.pdf', '.doc', '.docx', '.txt', '.md'].includes(extension)) {
      return <Document className="w-4 h-4" />;
    } else {
      return <File className="w-4 h-4" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <div className="app">
      <div className="header">
        <div className="logo">
          <Search className="w-6 h-6" />
          <h1>Portal OS Search</h1>
        </div>
        
        <div className="tabs">
          <button 
            className={`tab ${activeTab === 'search' ? 'active' : ''}`}
            onClick={() => setActiveTab('search')}
          >
            <Search className="w-4 h-4" />
            Search
          </button>
          <button 
            className={`tab ${activeTab === 'history' ? 'active' : ''}`}
            onClick={() => setActiveTab('history')}
          >
            <Clock className="w-4 h-4" />
            History
          </button>
          <button 
            className={`tab ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>
      </div>

      <div className="content">
        {activeTab === 'search' && (
          <div className="search-tab">
            <form onSubmit={handleSearch} className="search-form">
              <div className="search-input-container">
                <Search className="search-icon" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={query}
                  onChange={handleQueryChange}
                  placeholder="Search files, content, or use natural language..."
                  className="search-input"
                />
                {isSearching && <div className="loading-spinner" />}
              </div>
            </form>

            <div className="search-stats">
              <span>{results.length} results</span>
              <span>•</span>
              <span>{indexStats.totalFiles} files indexed</span>
              <span>•</span>
              <span>Last indexed: {indexStats.lastIndexed}</span>
            </div>

            <div className="results-container">
              {results.map((result) => (
                <div key={result.id} className="result-item">
                  <div className="result-icon">
                    {getFileIcon(result.file_type)}
                  </div>
                  <div className="result-content">
                    <div className="result-header">
                      <h3 className="result-title" onClick={() => openFile(result.file_path)}>
                        {result.file_name}
                      </h3>
                      <div className="result-actions">
                        <button 
                          className="action-btn"
                          onClick={() => openFile(result.file_path)}
                          title="Open file"
                        >
                          Open
                        </button>
                        <button 
                          className="action-btn"
                          onClick={() => openFileLocation(result.file_path)}
                          title="Show in folder"
                        >
                          <Folder className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                    <p className="result-path">{result.file_path}</p>
                    <div className="result-meta">
                      <span>{formatFileSize(result.file_size)}</span>
                      <span>•</span>
                      <span>{formatDate(result.last_modified)}</span>
                      <span>•</span>
                      <span>{Math.round(result.relevance * 100)}% match</span>
                    </div>
                    {result.context && (
                      <p className="result-context">"{result.context}"</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="history-tab">
            <h2>Search History</h2>
            <div className="history-list">
              {history.map((item) => (
                <div key={item.id} className="history-item" onClick={() => setQuery(item.query)}>
                  <div className="history-query">{item.query}</div>
                  <div className="history-meta">
                    <span>{item.results_count} results</span>
                    <span>•</span>
                    <span>{formatDate(item.timestamp)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="settings-tab">
            <h2>Search Settings</h2>
            <div className="settings-section">
              <h3>Index Settings</h3>
              <div className="setting-item">
                <label>Indexed Files:</label>
                <span>{indexStats.totalFiles}</span>
              </div>
              <div className="setting-item">
                <label>Last Indexed:</label>
                <span>{indexStats.lastIndexed}</span>
              </div>
              <button className="btn-primary">Reindex Files</button>
            </div>
            
            <div className="settings-section">
              <h3>Search Settings</h3>
              <div className="setting-item">
                <label>Global Shortcut:</label>
                <span>Cmd+Space (Mac) / Ctrl+Space (Windows/Linux)</span>
              </div>
              <div className="setting-item">
                <label>Search Depth:</label>
                <select defaultValue="deep">
                  <option value="quick">Quick Search</option>
                  <option value="deep">Deep Search</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
