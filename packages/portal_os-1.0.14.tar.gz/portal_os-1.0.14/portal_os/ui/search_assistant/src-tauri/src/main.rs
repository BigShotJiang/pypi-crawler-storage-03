// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::State;
use rusqlite::{Connection, Result as SqliteResult};

#[derive(Debug, Serialize, Deserialize)]
struct SearchResult {
    id: i32,
    file_path: String,
    file_name: String,
    file_type: String,
    file_size: i64,
    last_modified: String,
    relevance: f64,
    context: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct SearchHistory {
    id: i32,
    query: String,
    results_count: i32,
    timestamp: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct IndexStats {
    total_files: i32,
    last_indexed: String,
}

struct SearchDatabase {
    conn: Mutex<Connection>,
}

impl SearchDatabase {
    fn new() -> SqliteResult<Self> {
        let home_dir = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
        let db_path = home_dir.join(".portal-os").join("search").join("search_index.db");
        
        // Ensure directory exists
        if let Some(parent) = db_path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        
        let conn = Connection::open(&db_path)?;
        
        // Create tables if they don't exist
        conn.execute(
            "CREATE TABLE IF NOT EXISTS indexed_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT UNIQUE,
                file_name TEXT,
                file_size INTEGER,
                file_type TEXT,
                last_modified TEXT,
                content_hash TEXT,
                indexed_at TEXT
            )",
            [],
        )?;
        
        conn.execute(
            "CREATE TABLE IF NOT EXISTS search_index (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_id INTEGER,
                word TEXT,
                position INTEGER,
                context TEXT,
                FOREIGN KEY (file_id) REFERENCES indexed_files (id)
            )",
            [],
        )?;
        
        conn.execute(
            "CREATE TABLE IF NOT EXISTS search_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT,
                results_count INTEGER,
                timestamp TEXT
            )",
            [],
        )?;
        
        Ok(SearchDatabase {
            conn: Mutex::new(conn),
        })
    }
}

#[tauri::command]
async fn search_files(
    query: String,
    db: State<'_, SearchDatabase>,
) -> Result<Vec<SearchResult>, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    // Simple search implementation - in a real app, you'd use a proper search engine
    let mut stmt = conn.prepare(
        "SELECT DISTINCT 
            f.id, f.file_path, f.file_name, f.file_type, f.file_size, f.last_modified
         FROM indexed_files f
         WHERE f.file_name LIKE ? OR f.file_path LIKE ?
         ORDER BY f.last_modified DESC
         LIMIT 50"
    ).map_err(|e| format!("Database error: {}", e))?;
    
    let search_pattern = format!("%{}%", query);
    let rows = stmt.query_map([&search_pattern, &search_pattern], |row| {
        Ok(SearchResult {
            id: row.get(0)?,
            file_path: row.get(1)?,
            file_name: row.get(2)?,
            file_type: row.get(3)?,
            file_size: row.get(4)?,
            last_modified: row.get(5)?,
            relevance: 0.8, // Placeholder relevance score
            context: None,
        })
    }).map_err(|e| format!("Query error: {}", e))?;
    
    let results: Vec<SearchResult> = rows
        .filter_map(|r| r.ok())
        .collect();
    
    // Save search history
    let _ = conn.execute(
        "INSERT INTO search_history (query, results_count, timestamp) VALUES (?, ?, ?)",
        [
            &query,
            &results.len().to_string(),
            &chrono::Utc::now().to_rfc3339(),
        ],
    );
    
    Ok(results)
}

#[tauri::command]
async fn get_search_history(
    db: State<'_, SearchDatabase>,
) -> Result<Vec<SearchHistory>, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    let mut stmt = conn.prepare(
        "SELECT id, query, results_count, timestamp 
         FROM search_history 
         ORDER BY timestamp DESC 
         LIMIT 20"
    ).map_err(|e| format!("Database error: {}", e))?;
    
    let rows = stmt.query_map([], |row| {
        Ok(SearchHistory {
            id: row.get(0)?,
            query: row.get(1)?,
            results_count: row.get(2)?,
            timestamp: row.get(3)?,
        })
    }).map_err(|e| format!("Query error: {}", e))?;
    
    let history: Vec<SearchHistory> = rows
        .filter_map(|r| r.ok())
        .collect();
    
    Ok(history)
}

#[tauri::command]
async fn get_index_stats(
    db: State<'_, SearchDatabase>,
) -> Result<IndexStats, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    let total_files: i32 = conn
        .query_row("SELECT COUNT(*) FROM indexed_files", [], |row| row.get(0))
        .map_err(|e| format!("Database error: {}", e))?;
    
    let last_indexed: String = conn
        .query_row(
            "SELECT MAX(indexed_at) FROM indexed_files",
            [],
            |row| row.get(0),
        )
        .unwrap_or_else(|_| "Never".to_string());
    
    Ok(IndexStats {
        total_files,
        last_indexed,
    })
}

#[tauri::command]
async fn reindex_files(
    db: State<'_, SearchDatabase>,
) -> Result<String, String> {
    // This would trigger a reindex of all files
    // For now, just return a success message
    Ok("Reindexing started in background".to_string())
}

fn main() {
    let search_db = SearchDatabase::new()
        .expect("Failed to initialize search database");
    
    tauri::Builder::default()
        .manage(search_db)
        .invoke_handler(tauri::generate_handler![
            search_files,
            get_search_history,
            get_index_stats,
            reindex_files,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
