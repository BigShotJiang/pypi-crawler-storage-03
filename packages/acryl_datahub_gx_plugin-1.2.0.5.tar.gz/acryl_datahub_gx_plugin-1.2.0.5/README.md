# Datahub GX Plugin

See the [DataHub GX docs](https://docs.datahub.com/docs/metadata-ingestion/integration_docs/great-expectations) for details.
