"""
twitch.types

Typings for the Twitch API

:copyright: (c) 2025-present mrsnifo
:license: MIT, see LICENSE for more details.
"""