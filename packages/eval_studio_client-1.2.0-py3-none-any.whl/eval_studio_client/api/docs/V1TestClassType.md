# V1TestClassType

 - TEST_CLASS_TYPE_UNSPECIFIED: Unspecified TestClass type.  - TEST_CLASS_TYPE_STANDARD: TestClass type corresponding to a certain standard.  - TEST_CLASS_TYPE_ROLE: TestClass type corresponding to a certain role.  - TEST_CLASS_TYPE_PROBLEM: TestClass type corresponding to a certain problem.  - TEST_CLASS_TYPE_PURPOSE: TestClass type corresponding to a certain purpose.  - TEST_CLASS_TYPE_METHOD: TestClass type corresponding to a certain method.  - TEST_CLASS_TYPE_METHOD_TYPE: TestClass type corresponding to a certain method type.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


