# V1Role

Roles are used to define the access level of a user to a specific resource.   - ROLE_UNSPECIFIED: Unspecified role. This is used when the role is not set or not applicable.  - ROLE_READER: Reader role. This role allows read-only access to the resource.  - ROLE_WRITER: Writer role. This role allows read and write access to the resource. This does not allow to manage access to the resource or to delete it.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


