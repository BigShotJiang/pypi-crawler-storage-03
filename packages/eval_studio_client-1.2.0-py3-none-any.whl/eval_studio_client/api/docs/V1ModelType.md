# V1ModelType

 - MODEL_TYPE_UNSPECIFIED: Unspecified type.  - MODEL_TYPE_H2OGPTE_RAG: h2oGPTe RAG.  - MODEL_TYPE_OPENAI_RAG: OpenAI Assistant RAG.  - MODEL_TYPE_H2OGPTE_LLM: h2oGPTe LLM.  - MODEL_TYPE_H2OGPT_LLM: h2oGPT LLM.  - MODEL_TYPE_OPENAI_CHAT: OpenAI chat.  - MODEL_TYPE_AZURE_OPENAI_CHAT: Microsoft Azure hosted OpenAI Chat.  - MODEL_TYPE_OPENAI_API_CHAT: OpenAI API chat.  - MODEL_TYPE_H2OLLMOPS: H2O LLMOps.  - MODEL_TYPE_OLLAMA: Ollama.  - MODEL_TYPE_AMAZON_BEDROCK: Amazon Bedrock.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


