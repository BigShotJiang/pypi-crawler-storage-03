# V1WorkflowResultArtifactType

WorkflowResultArtifactType enum representing the types of artifacts that can be produced by a Workflow result.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


