# V1WorkflowNodeStatus

WorkflowNodeStatus represents the status of a WorkflowNode.   - WORKFLOW_NODE_STATUS_UNSPECIFIED: Unspecified status.  - WORKFLOW_NODE_STATUS_PENDING: WorkflowNode is pending.  - WORKFLOW_NODE_STATUS_RUNNING: WorkflowNode is running.  - WORKFLOW_NODE_STATUS_COMPLETED: WorkflowNode is completed successfully.  - WORKFLOW_NODE_STATUS_FAILED: WorkflowNode failed.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


