# V1WorkflowEdgeType

WorkflowEdgeType represents the type of a WorkflowEdge.   - WORKFLOW_EDGE_TYPE_UNSPECIFIED: Unspecified type.  - WORKFLOW_EDGE_TYPE_DEPENDENCY: A required dependency type of edge. This edge type defines that the \"to\" node depends on the outputs of the \"from\" node.  - WORKFLOW_EDGE_TYPE_OPTIONAL_DEPENDENCY: Optional dependency edge, which indicates that the outputs of the \"from\" node can be used in case they exist, but the \"to\" node does not rely on them.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


