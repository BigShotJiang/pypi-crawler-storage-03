# V1LeaderboardStatus

 - LEADERBOARD_STATUS_UNSPECIFIED: Unspecified status.  - LEADERBOARD_STATUS_PROCESSING: Leaderboard is being processed. See the Operation for details.  - LEADERBOARD_STATUS_COMPLETED: Leaderboard is completed successfully.  - LEADERBOARD_STATUS_FAILED: Leaderboard failed. See the Operation for details.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


