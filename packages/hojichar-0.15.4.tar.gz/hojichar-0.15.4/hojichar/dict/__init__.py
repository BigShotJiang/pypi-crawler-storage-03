"""
This `dict` module is a dictionary of inappropriate words, etc.
and does not contain Python source code.
It will be removed in the future.
"""
