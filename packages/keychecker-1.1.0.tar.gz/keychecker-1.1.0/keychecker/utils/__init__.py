"""
Utility functions and helpers.
"""
