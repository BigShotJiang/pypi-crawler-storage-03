"""
Core functionality for SSH key analysis and validation.
"""
