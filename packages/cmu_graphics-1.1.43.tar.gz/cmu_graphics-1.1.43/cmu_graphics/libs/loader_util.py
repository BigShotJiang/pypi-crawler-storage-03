
import platform
import os

min_minor_version = 9
max_minor_version = 13



def verify_support():
    python_major, python_minor, _ = platform.python_version_tuple()
    

    if python_major != '3':
        print("""\
It looks like you're running a version of Python 2. Since Python 2 is no
longer maintaned as of January 1 2020, CMU Graphics does not support Python 2.
We recommend installing Python 3.%(max_minor_version)d from python.org"""
% {'max_minor_version': max_minor_version})
        os._exit(1)

    

    if int(python_minor) < min_minor_version:
        print("""\
It looks like you're running Python 3.%(minor)s. Python 3.%(minor)s is not currently
supported by CMU Graphics. We support Python 3.%(min_minor_version)d and higher. We recommend 
installing Python 3.%(max_minor_version)d from python.org""" %
{"minor": python_minor, 'max_minor_version': max_minor_version, 'min_minor_version': min_minor_version})
        os._exit(1)
