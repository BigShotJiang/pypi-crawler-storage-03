# appdomain

A Python package implementing various Applicability Domain (AD) methods such as
kNN, LOF, OneClassSVM, and ensemble consensus for outlier detection.

## Installation

```bash
pip install appdomain
