__command__ = "ct"
__description__ = "Common scripts"
__order__ = "\x1f100-common"
