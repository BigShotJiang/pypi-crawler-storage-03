# region License
# Copyright (c) .NET Foundation and contributors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# The latest version of this file can be found at https://github.com/p-hzamora/FluentValidation
# endregion

from enum import Enum, auto
from typing import Callable


class CascadeMode(Enum):
    Continue = auto()
    Stop = auto()


class ApplyConditionTo(Enum):
    AllValidators = auto()
    CurrentValidator = auto()


class Severity(Enum):
    Error = auto()
    Warning = auto()
    Info = auto()


def ordinal(x: str, y: str):
    return x == y


def ordinal_ignore_case(x: str, y: str):
    return x.lower() == y.lower()


# COMMENT: Replicated StringComparer C# enum
class StringComparer(Enum):
    Ordinal: Callable[[str, str], bool] = ordinal
    OrdinalIgnoreCase: Callable[[str, str], bool] = ordinal_ignore_case
