:::{include} ../../README.md
:::

:::{toctree}
:hidden:
user_guides/user_guide
build_docs
license
apidocs/index
genindex
:::
