#### Reason for change


#### Description of change


#### Steps to Test

**review**:
@Arelle/arelle
@paulwarren-wk
