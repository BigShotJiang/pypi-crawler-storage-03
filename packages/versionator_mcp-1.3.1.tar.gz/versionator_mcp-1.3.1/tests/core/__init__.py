# Core tests module
