"""Used to single sourcing metadata about emeis."""

__title__ = "emeis"
__description__ = "user management"
__version__ = "2.2.3"
