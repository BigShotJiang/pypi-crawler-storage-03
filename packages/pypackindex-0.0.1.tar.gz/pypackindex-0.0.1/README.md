# PyIndex

This is a reserved package name for the upcoming **PyIndex** project.

👉 Visit [pyindex.com](https://pyindex.com) for updates.
👉 Source: [github.com/filipchristiansen/pyindex](https://github.com/filipchristiansen/pyindex)

Development status: **Planning phase**
