"""
Neighborhood Explorer

"""

import urllib.parse

import requests

from . import trapi, translator_node

def neighborhood_finder():
    """
    """
