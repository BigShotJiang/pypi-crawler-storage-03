TCT.node_normalizer
===================
.. automodule:: TCT.node_normalizer
   :members:
