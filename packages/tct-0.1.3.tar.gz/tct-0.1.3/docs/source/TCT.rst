TCT utility functions
===========================
.. automodule:: TCT.TCT
   :members:
