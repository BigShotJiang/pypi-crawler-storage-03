TCT.name_resolver
=================
.. automodule:: TCT.name_resolver
   :members:
