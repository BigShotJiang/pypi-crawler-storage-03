class Device:
    STM32 = 0
    W5500 = 1
