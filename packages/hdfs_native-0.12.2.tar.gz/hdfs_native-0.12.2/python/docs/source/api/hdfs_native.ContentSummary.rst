ContentSummary
==============

.. currentmodule:: hdfs_native

.. autoclass:: ContentSummary
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~ContentSummary.directory_count
      ~ContentSummary.file_count
      ~ContentSummary.length
      ~ContentSummary.quota
      ~ContentSummary.space_consumed
      ~ContentSummary.space_quota

   .. rubric:: Attributes Documentation

   .. autoattribute:: directory_count
   .. autoattribute:: file_count
   .. autoattribute:: length
   .. autoattribute:: quota
   .. autoattribute:: space_consumed
   .. autoattribute:: space_quota
