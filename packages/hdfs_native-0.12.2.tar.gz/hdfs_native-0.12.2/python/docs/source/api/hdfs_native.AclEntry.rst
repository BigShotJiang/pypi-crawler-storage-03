AclEntry
========

.. currentmodule:: hdfs_native

.. autoclass:: AclEntry
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~AclEntry.name
      ~AclEntry.permissions
      ~AclEntry.scope
      ~AclEntry.type

   .. rubric:: Attributes Documentation

   .. autoattribute:: name
   .. autoattribute:: permissions
   .. autoattribute:: scope
   .. autoattribute:: type
