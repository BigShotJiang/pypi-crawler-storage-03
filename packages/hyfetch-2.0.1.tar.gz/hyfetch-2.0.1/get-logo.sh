#!/usr/bin/env bash
cd /ws/Others/hyfetch
python3 -m hyfetch --print-font-logo
