#!/bin/sh

python /agent/environment_launcher.py
