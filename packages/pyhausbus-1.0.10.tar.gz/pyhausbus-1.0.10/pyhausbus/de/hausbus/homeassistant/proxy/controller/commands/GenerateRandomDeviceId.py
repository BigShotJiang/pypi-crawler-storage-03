import pyhausbus.HausBusUtils as HausBusUtils

class GenerateRandomDeviceId:
  CLASS_ID = 0
  FUNCTION_ID = 0

  @staticmethod
  def _fromBytes(dataIn:bytearray, offset):
    return GenerateRandomDeviceId()

  def __str__(self):
    return f"GenerateRandomDeviceId()"



