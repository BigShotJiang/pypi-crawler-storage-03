# color palettes

default_palette = ['#3E96A1', '#EC4E20', '#FF9505', '#713E5A', '#D62828', '#5F0F40']

histo_palette = ['#B35681', '#DC4141', '#f77f00', '#fcbf49', '#eae2b7', '#AFD0BF', '#A4BBDF']
