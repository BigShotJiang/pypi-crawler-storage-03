The files in this directory were originally cloned from

jsonschema 4.17.3

https://github.com/python-jsonschema/jsonschema/releases/tag/v4.17.3

See COPYING for use restrictions
