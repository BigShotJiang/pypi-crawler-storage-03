class BlockIndexError(Exception):
    """
    An error occurred while reading or parsing an ASDF block index
    """
