<!--
Thank you for opening an issue for asdf!

Your feedback is crucial to maintaining this open source project.

If this is a feature request or discussion question please add to
or create a new discussion:

https://github.com/asdf-format/asdf/discussions
-->

# Description of the problem

<!-- If an Exception, Warning or some other error occurred please include
the error message and full traceback -->

# Example of the problem

<!-- Please include an example that reproduces the problem or describe why
an example isn't provided. -->

# System information

asdf version:
python version:
operating system:
