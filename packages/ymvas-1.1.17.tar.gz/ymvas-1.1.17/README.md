Ymvas - handle your life like a developer!

Installation:
```bash
pip3 install ymvas
```

Installation system base:
```bash
curl -sL http://docs.ymvas.com/vas/ymvas/install-unix.bash | bash
```


Usage:

```bash
Usage :
    ym {command}   |  info,clone,config,compile
    ym --{command} |  Is not allowed!

File based commands placed like this:
    ~/repo/.ymvas/commands/install.bash
    ~/repo/.ymvas/commands/install.py
    ~/repo/.ymvas/commands/install.sh

Can be easly executed like this:
    ym install

```
