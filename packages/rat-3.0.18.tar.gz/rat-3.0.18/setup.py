from setuptools import setup, find_packages


setup(
    name = "rat",
    version = "v3.0.18",
    license = "GPL-3.0",
    package_dir = {"": "src"}
)
