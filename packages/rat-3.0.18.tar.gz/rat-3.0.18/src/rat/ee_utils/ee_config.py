# Required credentials to authorize earth engine #
service_account = "Enter your service account"
key_file= "Enter the path to your private json key file"
