import pytest

def test_imports():
    import rat