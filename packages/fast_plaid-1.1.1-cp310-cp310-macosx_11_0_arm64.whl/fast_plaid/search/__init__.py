from .fast_plaid import FastPlaid

__all__ = ["FastPlaid"]
