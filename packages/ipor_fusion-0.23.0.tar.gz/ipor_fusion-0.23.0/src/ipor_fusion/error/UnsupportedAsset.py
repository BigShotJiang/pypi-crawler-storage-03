class UnsupportedAsset(Exception):
    pass
