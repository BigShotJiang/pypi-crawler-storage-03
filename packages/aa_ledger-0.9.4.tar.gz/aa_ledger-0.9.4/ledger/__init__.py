"""Initialize the app"""

__version__ = "0.9.4"
__title__ = "Ledger"

__package_name__ = "aa-ledger"

__app_name_useragent__ = "AA-Ledger"
__github_url__ = f"https://github.com/Geuthur/{__package_name__}"
