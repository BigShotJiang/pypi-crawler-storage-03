from django.apps import AppConfig


class DjangoldpBecknldBppConfig(AppConfig):
    name = "djangoldp_becknld_bpp"
