__version__ = "0.0.0"
name = "djangoldp_becknld_bap"
