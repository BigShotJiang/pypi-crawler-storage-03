from django.apps import AppConfig


class DjangoldpBecknldConfig(AppConfig):
    name = "djangoldp_becknld"
