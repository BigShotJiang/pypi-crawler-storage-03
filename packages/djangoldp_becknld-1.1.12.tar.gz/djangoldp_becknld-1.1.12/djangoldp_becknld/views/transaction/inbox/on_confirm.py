def handle_on_confirm_activity(activity):
    print("received on_confirm activity")
    print(activity)
