def handle_on_init_activity(activity):
    print("received on_init activity")
    print(activity)
