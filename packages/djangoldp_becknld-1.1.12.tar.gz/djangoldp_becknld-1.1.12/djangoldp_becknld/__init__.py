__version__ = "1.1.12"
name = "djangoldp_becknld"
