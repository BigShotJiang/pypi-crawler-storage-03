# Database Tools

Database wrapper for hdf5 through h5py.

I use this wrapper for file I/O because it saves me from writing the same code over and over again, and it is tested.

## Installation:

pip3 install xev-data

## Contributing

We are open to pull requests.

If you would like to make a contribution, please explain what changes you are making and why.

## License

[MIT](https://choosealicense.com/licenses/mit)
