# The flexmeasures.data package

This package holds all data models, db configuration and code that works on data.