"""merge

Revision ID: 919dc9f1dc1f
Revises: db00b66be82c, 5d39829d91af
Create Date: 2018-07-15 22:49:59.184453

"""

# revision identifiers, used by Alembic.
revision = "919dc9f1dc1f"
down_revision = ("db00b66be82c", "5d39829d91af")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
