"""merge

Revision ID: d814c0688ae0
Revises: 75f53d2dbfae, c41beee0c904
Create Date: 2022-12-12 15:31:41.509921

"""

# revision identifiers, used by Alembic.
revision = "d814c0688ae0"
down_revision = ("75f53d2dbfae", "c41beee0c904")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
