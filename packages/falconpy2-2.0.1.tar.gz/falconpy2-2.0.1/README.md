# FalconPy

“It's FalconPy!”

## Quick start

```bash
pip install FalconPy2
```

Helper import:
```python
from falconpy import APIHarnessV2
```

Global hook:
```python
import falconpy
falconpy.install("numpy", "requests")

import numpy as np
np.arange(3)  # -> prints the line
```
