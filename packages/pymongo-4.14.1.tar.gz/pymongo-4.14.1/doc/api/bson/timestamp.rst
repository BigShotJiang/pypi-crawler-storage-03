:mod:`timestamp` -- Tools for representing MongoDB internal Timestamps
======================================================================
.. automodule:: bson.timestamp
   :synopsis: Tools for representing MongoDB internal Timestamps
   :members:
