:mod:`errors` -- Exceptions raised by the :mod:`bson` package
=============================================================

.. automodule:: bson.errors
   :synopsis: Exceptions raised by the bson package
   :members:
