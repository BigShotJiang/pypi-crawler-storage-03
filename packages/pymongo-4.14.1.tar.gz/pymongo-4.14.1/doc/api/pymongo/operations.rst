:mod:`operations` -- Operation class definitions
================================================

.. automodule:: pymongo.operations
   :synopsis: Operation class definitions
   :members:
