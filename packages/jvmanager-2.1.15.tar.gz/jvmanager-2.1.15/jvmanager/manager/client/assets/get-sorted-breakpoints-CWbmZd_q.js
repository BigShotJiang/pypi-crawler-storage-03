import{p as o}from"./px-CiO0pVtX.js";function u(t,r){return t in r?o(r[t]):o(t)}function s(t,r){const n=t.map(e=>({value:e,px:u(e,r)}));return n.sort((e,p)=>e.px-p.px),n}export{s as a,u as g};
