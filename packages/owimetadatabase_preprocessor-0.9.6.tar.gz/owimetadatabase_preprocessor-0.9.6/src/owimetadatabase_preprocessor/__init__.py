"""A package to preprocess the data from owimetadatabase."""

__version__ = "0.9.6"
