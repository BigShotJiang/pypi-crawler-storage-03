from importlib.metadata import version

VERSION: str = version("wormhole-proxy")
