# fileprinter/__init__.py

from .fileprinter import FilePrinter
