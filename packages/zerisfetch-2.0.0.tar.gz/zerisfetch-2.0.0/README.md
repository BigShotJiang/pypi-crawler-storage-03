# ZerisFetch

A lightweight, fast system information display tool inspired by neofetch.

## Features

- ?? Fast and lightweight
- ?? Beautiful ASCII art for different Linux distributions
- ?? Shows essential system information
- ?? Easy to install and use
- ?? Supports Debian, Ubuntu, Arch Linux and more

## Installation

```bash
pip install zerisfetch
