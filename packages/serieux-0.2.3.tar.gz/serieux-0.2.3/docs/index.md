# Serieux documentation

[Repository](https://github.com/breuleux/serieux)

```python
pip install serieux
```
