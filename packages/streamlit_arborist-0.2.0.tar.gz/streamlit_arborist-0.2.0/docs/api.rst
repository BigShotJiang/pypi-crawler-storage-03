.. _api:

=============
Reference API
=============

.. autofunction:: streamlit_arborist.tree_view
