#!/usr/bin/env python3
"""
Test Script for Smart Gateway Fix
This script tests the fixed smart_blog_gateway function to ensure API credentials are properly passed
"""

import sys
import os
from datetime import datetime

# Add the parent directory to sys.path to import ghost_blog_smart
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_smart_gateway_with_debug():
    """Test smart_blog_gateway with debug information"""
    print("🔧 TESTING SMART GATEWAY FIX")
    print("=" * 60)
    
    try:
        from ghost_blog_smart import smart_blog_gateway
        
        # Use real Gemini API key from environment or parameter
        real_gemini_key = os.getenv('GEMINI_API_KEY') or 'AIzaSyATjMBDU_0M1jb0aBeoSQgZxAWYg2z9Dx8'
        
        # Test credentials (using real Gemini key)
        test_config = {
            'ghost_api_url': 'https://test-ghost-blog.com',
            'ghost_admin_api_key': 'test_key_id:746869732d69732d612d74657374',  # "this-is-a-test" in hex
            'gemini_api_key': real_gemini_key,
            'is_test': True  # CRITICAL: This prevents actual Ghost API calls
        }
        
        print("📝 Test configuration:")
        for key, value in test_config.items():
            if 'key' in key.lower():
                print(f"   {key}: {'*' * 20} (hidden)")
            else:
                print(f"   {key}: {value}")
        
        print("\n🧪 Test Case 1: Simple content that should trigger rewrite path")
        print("-" * 50)
        
        test_content = """
        AI benefits in healthcare:
        - Better diagnosis
        - Personalized medicine 
        - Drug discovery
        
        Write a blog post about this
        """
        
        print(f"Input content: {test_content.strip()}")
        print("\n🚀 Calling smart_blog_gateway...")
        
        result = smart_blog_gateway(
            user_input=test_content,
            status='draft',
            **test_config
        )
        
        print("\n📊 RESULT:")
        print(f"Success: {result['success']}")
        print(f"Response: {result['response']}")
        
        # Check if we have debug information
        if 'debug_result' in result:
            print(f"\n🔍 Debug Result: {result['debug_result']}")
        
        # Test the class-based approach as well
        print("\n🏛️ Test Case 2: Class-based approach")
        print("-" * 50)
        
        from ghost_blog_smart import GhostBlogSmart
        
        client = GhostBlogSmart(
            ghost_url=test_config['ghost_api_url'],
            ghost_api_key=test_config['ghost_admin_api_key'],
            gemini_api_key=test_config['gemini_api_key']
        )
        
        class_result = client.smart_create_post(
            test_content,
            status='draft',
            is_test=True
        )
        
        print(f"Class result success: {class_result['success']}")
        print(f"Class result response: {class_result['response']}")
        
        # Comparison
        print("\n📋 COMPARISON:")
        print("-" * 50)
        print(f"Function approach: {'✅ Success' if result['success'] else '❌ Failed'}")
        print(f"Class approach:    {'✅ Success' if class_result['success'] else '❌ Failed'}")
        
        if result['success'] and class_result['success']:
            print("🎉 Both approaches now working correctly!")
        elif result['success'] or class_result['success']:
            print("⚠️ One approach working, investigating the other...")
        else:
            print("❌ Both approaches still failing, need further investigation")
        
        return result, class_result
        
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def test_credential_passing():
    """Test that credentials are properly passed through the chain"""
    print("\n🔐 TESTING CREDENTIAL PASSING")
    print("=" * 60)
    
    try:
        from ghost_blog_smart.smart_gateway import rewrite_and_publish_blog
        
        # Use real Gemini API key
        real_gemini_key = os.getenv('GEMINI_API_KEY') or 'AIzaSyATjMBDU_0M1jb0aBeoSQgZxAWYg2z9Dx8'
        
        # Test the internal function directly
        test_kwargs = {
            'raw_content': 'Test content for credential checking',
            'ghost_api_url': 'https://test.com',
            'ghost_admin_api_key': 'test:key',
            'gemini_api_key': real_gemini_key,
            'is_test': True,
            'status': 'draft'
        }
        
        print("📝 Testing rewrite_and_publish_blog directly...")
        print(f"Input kwargs keys: {list(test_kwargs.keys())}")
        
        # This should show our debug output
        result = rewrite_and_publish_blog(**test_kwargs)
        
        print(f"Direct test result: {result['success']}")
        print(f"Response: {result.get('response', 'No response')}")
        
        return result
        
    except Exception as e:
        print(f"❌ Credential test failed: {e}")
        import traceback
        traceback.print_exc()
        return None


def test_error_messages():
    """Test that we get better error messages now"""
    print("\n💬 TESTING ERROR MESSAGES")
    print("=" * 60)
    
    try:
        from ghost_blog_smart import smart_blog_gateway
        
        # Test with missing credentials to see better error messages
        print("📝 Testing with missing credentials...")
        
        result = smart_blog_gateway(
            user_input="Test content",
            # Deliberately not providing credentials
            is_test=True  # Still use test mode to avoid real API calls
        )
        
        print(f"Result: {result['success']}")
        print(f"Message: {result.get('response', 'No message')}")
        
        if 'Debug:' in result.get('response', ''):
            print("✅ Enhanced error messages working!")
        else:
            print("⚠️ Error messages could be more detailed")
        
        return result
        
    except Exception as e:
        print(f"❌ Error message test failed: {e}")
        return None


if __name__ == "__main__":
    print("🚀 SMART GATEWAY FIX TEST SUITE")
    print("=" * 80)
    
    # Run all tests
    result1, result2 = test_smart_gateway_with_debug()
    result3 = test_credential_passing()
    result4 = test_error_messages()
    
    # Summary
    print("\n" + "=" * 80)
    print("📊 TEST SUMMARY")
    print("=" * 80)
    
    tests_passed = 0
    total_tests = 4
    
    if result1 and result1['success']:
        print("✅ Smart gateway function test - PASSED")
        tests_passed += 1
    else:
        print("❌ Smart gateway function test - FAILED")
    
    if result2 and result2['success']:
        print("✅ Smart gateway class test - PASSED")
        tests_passed += 1
    else:
        print("❌ Smart gateway class test - FAILED")
    
    if result3 and result3['success']:
        print("✅ Credential passing test - PASSED")
        tests_passed += 1
    else:
        print("❌ Credential passing test - FAILED")
    
    if result4:
        print("✅ Error message test - COMPLETED")
        tests_passed += 1
    else:
        print("❌ Error message test - FAILED")
    
    print(f"\n🎯 OVERALL RESULT: {tests_passed}/{total_tests} tests passed")
    
    if tests_passed == total_tests:
        print("🎉 ALL TESTS PASSED! Smart gateway fix is working correctly!")
    elif tests_passed > total_tests // 2:
        print("⚠️ Most tests passed, but some issues remain.")
    else:
        print("❌ Major issues still exist, further fixes needed.")
    
    print("\n💡 Next steps:")
    print("   - If tests pass: Ready for production testing")
    print("   - If tests fail: Check the debug output above for clues")
    print("   - Test with real credentials in a safe environment")