#!/usr/bin/env python3
"""
Test Script for Ghost Blog Smart - Both Approaches
Tests both the new class-based approach and the existing function-based approach
"""

import sys
import os
from datetime import datetime

# Add the parent directory to sys.path to import ghost_blog_smart
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_import_patterns():
    """Test different import patterns and error messages"""
    print("🔍 Testing Import Patterns")
    print("=" * 50)
    
    # Test 1: Correct class-based import
    try:
        from ghost_blog_smart import GhostBlogSmart
        print("✅ Class import works: from ghost_blog_smart import GhostBlogSmart")
    except Exception as e:
        print(f"❌ Class import failed: {e}")
    
    # Test 2: Correct function-based import
    try:
        from ghost_blog_smart import create_ghost_blog_post
        print("✅ Function import works: from ghost_blog_smart import create_ghost_blog_post")
    except Exception as e:
        print(f"❌ Function import failed: {e}")
    
    # Test 3: Test error messages for common mistakes
    error_tests = [
        'GhostBlogSmartClient',
        'GhostClient', 
        'Client',
        'GhostBlog',
        'Ghost',
        'BlogSmart',
        'NonExistentClass'
    ]
    
    print("\n🚨 Testing Error Messages for Common Mistakes:")
    for mistake in error_tests:
        try:
            exec(f"from ghost_blog_smart import {mistake}")
            print(f"❌ Expected error for '{mistake}' but it worked")
        except (ImportError, AttributeError) as e:
            error_msg = str(e).split('\n')[0]
            print(f"✅ Good error message for '{mistake}': {error_msg}")
        except Exception as e:
            print(f"⚠️ Unexpected error for '{mistake}': {e}")


def test_class_based_approach():
    """Test the new class-based approach"""
    print("\n🏛️ Testing Class-Based Approach")
    print("=" * 50)
    
    try:
        from ghost_blog_smart import GhostBlogSmart
        
        # Test 1: Create client without credentials (should work with env vars)
        print("1. Creating client with environment variables...")
        try:
            client = GhostBlogSmart()
            print(f"✅ Client created: {client}")
            print(f"   - Configured: {client.is_configured}")
            print(f"   - AI Features: {client.has_ai_features}")
        except Exception as e:
            print(f"⚠️ Client creation with env vars failed: {e}")
            print("   This is expected if environment variables are not set")
        
        # Test 2: Create client with explicit credentials (test mode)
        print("\n2. Creating client with explicit test credentials...")
        try:
            client = GhostBlogSmart(
                ghost_url="https://test-ghost-site.com",
                ghost_api_key="test_key_id:746869732d69732d612d74657374",  # "this-is-a-test" in hex
                gemini_api_key="test_gemini_key"
            )
            print(f"✅ Test client created: {client}")
            print(f"   - Configured: {client.is_configured}")
            print(f"   - AI Features: {client.has_ai_features}")
            
            # Test client methods (in test mode)
            print("\n3. Testing client methods...")
            
            # Test create_post method
            print("   Testing create_post method...")
            result = client.create_post(
                title=f"Test Post - Class Based - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                content="This is test content created using the class-based approach.",
                tags=["Test", "Class-Based"],
                is_test=True  # Important: Test mode
            )
            print(f"   Result: {result['success']} - {result.get('message', 'No message')}")
            
            # Test get_posts method
            print("   Testing get_posts method...")
            # Note: This will fail in test mode, but we can test the method call
            try:
                posts_result = client.get_posts(limit=1, is_test=True)
                print(f"   Posts result: {posts_result.get('success', 'Unknown')}")
            except Exception as e:
                print(f"   Expected failure (test credentials): {str(e)[:100]}...")
            
            # Test smart_create_post method  
            print("   Testing smart_create_post method...")
            smart_result = client.smart_create_post(
                "Write a blog post about testing Python libraries with both class and function approaches.",
                status="draft",
                is_test=True
            )
            print(f"   Smart result: {smart_result['success']} - {smart_result.get('message', 'No message')[:100]}...")
            
        except Exception as e:
            print(f"❌ Test client creation failed: {e}")
    
    except ImportError as e:
        print(f"❌ Import failed: {e}")


def test_function_based_approach():
    """Test the existing function-based approach"""
    print("\n⚙️ Testing Function-Based Approach")
    print("=" * 50)
    
    try:
        from ghost_blog_smart import create_ghost_blog_post, get_ghost_posts, smart_blog_gateway
        
        print("1. Testing create_ghost_blog_post function...")
        result = create_ghost_blog_post(
            title=f"Test Post - Function Based - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            content="This is test content created using the function-based approach.",
            tags=["Test", "Function-Based"],
            ghost_api_url="https://test-ghost-site.com",
            ghost_admin_api_key="test_key_id:746869732d69732d612d74657374",
            is_test=True  # Important: Test mode
        )
        print(f"   Result: {result['success']} - {result.get('message', 'No message')}")
        
        print("\n2. Testing smart_blog_gateway function...")
        smart_result = smart_blog_gateway(
            "Create a blog post about the benefits of using both class-based and function-based APIs in Python libraries.",
            status="draft",
            ghost_api_url="https://test-ghost-site.com", 
            ghost_admin_api_key="test_key_id:746869732d69732d612d74657374",
            is_test=True
        )
        print(f"   Smart result: {smart_result['success']} - {smart_result.get('message', 'No message')[:100]}...")
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
    except Exception as e:
        print(f"❌ Function test failed: {e}")


def test_compatibility():
    """Test that both approaches produce similar results"""
    print("\n🔄 Testing Compatibility Between Approaches")
    print("=" * 50)
    
    try:
        from ghost_blog_smart import GhostBlogSmart, create_ghost_blog_post
        
        # Test data
        test_params = {
            "title": f"Compatibility Test - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "content": "Testing that both approaches produce similar results.",
            "tags": ["Compatibility", "Test"],
            "status": "draft",
            "ghost_api_url": "https://test-ghost-site.com",
            "ghost_admin_api_key": "test_key_id:746869732d69732d612d74657374",
            "is_test": True
        }
        
        # Class-based approach
        print("1. Testing with class-based approach...")
        client = GhostBlogSmart(
            ghost_url=test_params["ghost_api_url"],
            ghost_api_key=test_params["ghost_admin_api_key"]
        )
        class_result = client.create_post(**{k: v for k, v in test_params.items() 
                                           if k not in ['ghost_api_url', 'ghost_admin_api_key']})
        
        # Function-based approach
        print("2. Testing with function-based approach...")
        function_result = create_ghost_blog_post(**test_params)
        
        # Compare results
        print("\n3. Comparing results...")
        print(f"   Class result success: {class_result['success']}")
        print(f"   Function result success: {function_result['success']}")
        
        if class_result['success'] == function_result['success']:
            print("✅ Both approaches returned same success status")
        else:
            print("⚠️ Different success status between approaches")
            
        # Check URL structure (both should generate URLs in test mode)
        if 'url' in class_result and 'url' in function_result:
            class_url_base = class_result['url'].split('/test-post-')[0]
            function_url_base = function_result['url'].split('/test-post-')[0]
            if class_url_base == function_url_base:
                print("✅ Both approaches generate URLs with same base")
            else:
                print("⚠️ Different URL bases")
        
    except Exception as e:
        print(f"❌ Compatibility test failed: {e}")


def test_edge_cases():
    """Test edge cases and error handling"""
    print("\n🔬 Testing Edge Cases")
    print("=" * 50)
    
    try:
        from ghost_blog_smart import GhostBlogSmart
        
        print("1. Testing client creation without credentials...")
        try:
            # This should fail gracefully
            client = GhostBlogSmart(
                ghost_url=None,
                ghost_api_key=None
            )
            print("❌ Expected error for missing credentials but client was created")
        except ValueError as e:
            print(f"✅ Proper error for missing credentials: {str(e)[:80]}...")
        except Exception as e:
            print(f"⚠️ Unexpected error type: {e}")
        
        print("\n2. Testing invalid API key format...")
        try:
            client = GhostBlogSmart(
                ghost_url="https://test.com",
                ghost_api_key="invalid_key_format"
            )
            # Try to use it
            result = client.create_post(
                title="Test",
                content="Test content",
                is_test=False  # This should trigger real API call and fail
            )
            print(f"   Result: {result['success']} - {result.get('message', '')[:80]}...")
        except Exception as e:
            print(f"   Expected API error: {str(e)[:80]}...")
        
    except Exception as e:
        print(f"❌ Edge case testing failed: {e}")


if __name__ == "__main__":
    print("🚀 Ghost Blog Smart - Both Approaches Test")
    print("=" * 80)
    
    # Run all tests
    test_import_patterns()
    test_class_based_approach() 
    test_function_based_approach()
    test_compatibility()
    test_edge_cases()
    
    print("\n" + "=" * 80)
    print("🎉 Testing Complete!")
    print("\n💡 Summary:")
    print("   - Both class-based and function-based approaches are now supported")
    print("   - Code assistants can use the familiar class pattern")
    print("   - Existing code continues to work unchanged")
    print("   - Helpful error messages guide users to correct usage")
    print("\n📚 Usage Examples:")
    print("   Class-based:  client = GhostBlogSmart(); client.create_post(...)")
    print("   Function-based: create_ghost_blog_post(...)")