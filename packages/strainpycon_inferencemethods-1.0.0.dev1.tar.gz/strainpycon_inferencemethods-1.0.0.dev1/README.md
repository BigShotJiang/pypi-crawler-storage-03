# Introduction

The Strain Inference Methods (SIM)(strainpycon_inferencemethods) are a fork of the 
Python 3 strainpycon package used to disambiguate multiple strains in mixed samples of DNA. 
SIM builds upon strainpycon with methods to:
-disambiguate samples with many genetic markers (tested up to 2461 markers)
-fix a particular strain within a sample reconstruction
-compare samples for shared strains
-detect the presence or absence of particular strains in samples


# Contacts

Please direct questions to:
Gary Vestal, mojihaka@protonmail.com

# Strainpycon

This library was forked from strainpycon 
by Ymir Vigfusson, Lars Ruthotto, Rebecca M. Mitchell, Lauri Mustonen, and Xiangxi Gao, 
under the MIT License.

Please refer to the full documentation of StrainPycon at:
https://www.ymsir.com/strainpycon/