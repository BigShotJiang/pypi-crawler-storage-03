class GraphError(Exception):
    """Base exception for graph-related errors."""
