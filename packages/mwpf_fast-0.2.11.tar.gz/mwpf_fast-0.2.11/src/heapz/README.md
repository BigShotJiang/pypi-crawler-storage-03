# Heapz

A collection of heap/priority queue implementations

### Heap types

- [Pairing Heap](https://en.wikipedia.org/wiki/Pairing_heap)
- [Ranked Paring Heap](https://skycocoo.github.io/Rank-Pairing-Heap/)
