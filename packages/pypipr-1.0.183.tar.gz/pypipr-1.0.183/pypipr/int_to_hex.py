def int_to_hex(n):
    """
    Fungsi ini sama seperti fungsi hex().
    fungsi ini dibuat hanya untuk keperluan pembuatan module semata.

    ```python
    print(int_to_hex(7777))
    ```
    """
    return hex(n)
