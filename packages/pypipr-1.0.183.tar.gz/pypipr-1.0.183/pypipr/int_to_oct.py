def int_to_oct(n):
    """
    Fungsi ini sama seperti fungsi oct().
    fungsi ini dibuat hanya untuk keperluan pembuatan module semata.

    ```python
    print(int_to_oct(7777))
    ```
    """
    return oct(n)
