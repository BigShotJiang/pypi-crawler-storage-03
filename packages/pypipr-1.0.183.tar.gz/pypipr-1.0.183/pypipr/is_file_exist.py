import os


def is_file_exist(path):
    return os.path.exists(path)
