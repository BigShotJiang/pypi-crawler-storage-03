
from .console_run import console_run


def pip_update_pypipr():
    console_run("pip install -U pypipr")
    console_run("pip install -U pypipr")
