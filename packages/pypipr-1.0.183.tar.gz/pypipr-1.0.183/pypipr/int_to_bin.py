def int_to_bin(n):
    """
    Fungsi ini sama seperti fungsi bin().
    fungsi ini dibuat hanya untuk keperluan pembuatan module semata.

    ```python
    print(int_to_bin(7777))
    ```
    """
    return bin(n)
