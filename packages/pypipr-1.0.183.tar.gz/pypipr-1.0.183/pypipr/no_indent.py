from textwrap import dedent


def no_indent(teks):
    return dedent(teks)
