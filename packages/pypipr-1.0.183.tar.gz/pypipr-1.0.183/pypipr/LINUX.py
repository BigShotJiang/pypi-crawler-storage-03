import platform

"""
True on linux
"""
LINUX = platform.system() == "Linux"

