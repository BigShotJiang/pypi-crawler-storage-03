def oct_to_int(n):
    """
    Fungsi ini berguna untuk mengubah angka octal 
    menjadi angka integer.

    ```python
    print(oct_to_int(oct(244)))
    ```
    """
    return int(n, 8)


