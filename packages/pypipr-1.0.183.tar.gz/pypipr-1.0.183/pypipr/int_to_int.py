def int_to_int(n):
    """
    Fungsi ini sama seperti fungsi int().
    fungsi ini dibuat hanya untuk keperluan pembuatan module semata.

    ```python
    print(int_to_int(7777))
    ```
    """
    return int(n)
