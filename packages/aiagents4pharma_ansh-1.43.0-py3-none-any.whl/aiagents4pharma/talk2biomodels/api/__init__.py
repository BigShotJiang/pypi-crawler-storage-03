"""
This file is used to import the modules in the package.
"""

from . import kegg, ols, uniprot
