from setuptools import setup, find_packages

setup(
    name="hello_package_madhulika",   # this is what shows in pip list
    version="0.1.0",
    description="A simple hello-world pip package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Madhulika",
    author_email="you@example.com",
    packages=find_packages(),
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "hello=hello_package.__main__:main",
        ],
    },
)
