from hello_package_madhulika import say_hello

def main():
    name = input("Enter your name: ")
    print(say_hello(name))

if __name__ == "__main__":
    main()