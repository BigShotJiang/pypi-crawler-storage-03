# hello-package

A simple pip package that says hello 👋

## Installation
```bash
pip install hello-package