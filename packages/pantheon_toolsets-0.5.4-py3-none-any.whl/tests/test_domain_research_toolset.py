from executor.engine import Engine, ProcessJob
from pantheon.toolsets.utils.remote import connect_remote
from pantheon.toolsets.domain_research import DomainResearchToolSet


async def test_domain_research_demo_backend():
    toolset = DomainResearchToolSet("domain_research")

    async def start():
        await toolset.run()

    with Engine() as engine:
        job = ProcessJob(start)
        engine.submit(job)
        await job.wait_until_status("running")
        s = await connect_remote(toolset.service_id)
        resp = await s.invoke("run_research", {"query": "PBMC annotation best practices", "backend": "demo"})
        assert resp["used_demo"] is True
        assert "PBMC annotation best practices" in resp["report"]
        await job.cancel()
        await engine.wait_async()

