from ..utils.toolset import toolset_cli
from .core import DomainResearchToolSet


def main():
    toolset_cli(DomainResearchToolSet, "domain_research")


if __name__ == "__main__":
    main()

