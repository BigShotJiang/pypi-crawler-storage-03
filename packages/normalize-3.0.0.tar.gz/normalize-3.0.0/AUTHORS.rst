Developed and maintained by `Hearsay Social, Inc.
<http://hearsaysocial.com>`_.

Contributors
============
| `Sam Vilain <http://github.com/samv>`_
| `Robert MacCloy <http://github.com/rbm>`_
| `Akshay Shah <http://github.com/akshayjshah>`_
| `John Lynn <http://github.com/jlynn>`_
| `Ofer Goldstein <http://github.com/tulioz>`_
