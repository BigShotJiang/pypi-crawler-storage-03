from txt2stix.txt2stix import main

main()