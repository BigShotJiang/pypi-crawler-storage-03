"""Report generation system for pipen"""

from .versions import __version__
