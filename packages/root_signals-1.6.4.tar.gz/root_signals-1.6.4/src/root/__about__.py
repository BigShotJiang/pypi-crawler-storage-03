# SPDX-FileCopyrightText: 2024-present juho.ylikyla <juho.ylikyla@rootsignals.ai>
#
# SPDX-License-Identifier: MIT
__version__ = "1.6.4"
