default_app_config = "pulp_rpm_webhook.app.PulpRpmWebhookPluginAppConfig"
