# Key for the page status code cached into page header.
QE_STATUS_CODE = 'QE-Status-Code'
