import sthali_crud


class Config(sthali_crud.Config):
    ...
