# Translation Task

::: openaivec.task.nlp.translation
