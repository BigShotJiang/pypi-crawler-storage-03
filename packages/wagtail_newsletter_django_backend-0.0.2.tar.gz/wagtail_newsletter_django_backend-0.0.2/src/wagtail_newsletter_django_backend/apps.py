from django.apps import AppConfig


class WagtailNewsletterDjangoBackendConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wagtail_newsletter_django_backend'
