Docs: https://github.com/canonical/charm-refresh
<!--- TODO update link after charm-refresh docs published -->
