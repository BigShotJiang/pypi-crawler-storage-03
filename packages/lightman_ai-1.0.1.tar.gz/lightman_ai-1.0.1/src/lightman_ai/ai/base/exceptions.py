from lightman_ai.core.exceptions import BaseLightmanError


class BaseAgentError(BaseLightmanError): ...
