# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import test_l10n_es_facturae_32
from . import test_l10n_es_facturae_321
from . import test_l10n_es_facturae_322
