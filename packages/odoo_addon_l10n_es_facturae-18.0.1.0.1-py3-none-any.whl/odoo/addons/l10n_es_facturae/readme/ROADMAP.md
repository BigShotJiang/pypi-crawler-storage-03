- No está soportada la exportación de facturas rectificativas. Fallan
  las series.
- El certificado y la contraseña de acceso al certificado no se guardan
  cifrados en la base de datos.
- Ver la posibilidad de exportar varias facturas juntas.
- Las facturas con recargo de equivalencia no generan un formato
  correcto.
- Debido a un cambio de certificados, mal hechos desde Camerfirma, se ha
  eliminado el cálculo automático del hash del método de firma.
