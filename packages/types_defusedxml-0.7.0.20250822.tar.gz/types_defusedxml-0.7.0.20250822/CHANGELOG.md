## 0.7.0.20250822 (2025-08-22)

Add __slots__ to third-party packages using stubdefaulter ([#14619](https://github.com/python/typeshed/pull/14619))

Add missing defaults to third-party stubs ([#14617](https://github.com/python/typeshed/pull/14617))

## 0.7.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs (#14545)

## 0.7.0.20250708 (2025-07-08)

[defusedxml] Add missing stubs (#14265)

## 0.7.0.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs (#14063)

## 0.7.0.20240218 (2024-02-18)

defusedxml.ElementTree: use`Element` from ElementTree instead of minidom (#11305)

## 0.7.0.20240117 (2024-01-17)

`defusedxml`: Add xml.dom.minidom.Document return type annotation (#11279)

## 0.7.0.20240115 (2024-01-15)

Add types for defusedxml (#11179)

