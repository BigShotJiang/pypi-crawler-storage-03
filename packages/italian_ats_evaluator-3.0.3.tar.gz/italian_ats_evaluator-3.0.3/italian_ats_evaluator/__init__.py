from .SimplificationAnalyzer import SimplificationAnalyzer
from .TextAnalyzer import TextAnalyzer
