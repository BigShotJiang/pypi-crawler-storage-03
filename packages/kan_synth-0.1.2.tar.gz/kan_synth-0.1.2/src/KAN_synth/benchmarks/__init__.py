# benchmarks/__init__.py
"""
Benchmarking modules for synthetic data efficacy.
"""