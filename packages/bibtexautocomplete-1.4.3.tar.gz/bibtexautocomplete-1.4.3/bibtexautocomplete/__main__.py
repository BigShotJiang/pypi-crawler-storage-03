#!/usr/bin/env python3
# PYTHON_ARGCOMPLETE_OK
from .core.main import main

if __name__ == "__main__":
    main()
