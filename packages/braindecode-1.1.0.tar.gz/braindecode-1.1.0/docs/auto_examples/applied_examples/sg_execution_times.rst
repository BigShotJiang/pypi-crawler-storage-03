
:orphan:

.. _sphx_glr_auto_examples_applied_examples_sg_execution_times:


Computation times
=================
**01:54.289** total execution time for 5 files **from auto_examples/applied_examples**:

.. container::

  .. raw:: html

    <style scoped>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
    </style>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" class="init">
    $(document).ready( function () {
        $('table.sg-datatable').DataTable({order: [[1, 'desc']]});
    } );
    </script>

  .. list-table::
   :header-rows: 1
   :class: table table-striped sg-datatable

   * - Example
     - Time
     - Mem (MB)
   * - :ref:`sphx_glr_auto_examples_applied_examples_plot_sleep_staging_usleep.py` (``plot_sleep_staging_usleep.py``)
     - 00:51.196
     - 955.2
   * - :ref:`sphx_glr_auto_examples_applied_examples_plot_sleep_staging_eldele2021.py` (``plot_sleep_staging_eldele2021.py``)
     - 00:43.871
     - 1112.4
   * - :ref:`sphx_glr_auto_examples_applied_examples_plot_tuh_eeg_corpus.py` (``plot_tuh_eeg_corpus.py``)
     - 00:19.221
     - 510.2
   * - :ref:`sphx_glr_auto_examples_applied_examples_bcic_iv_4_ecog_trial.py` (``bcic_iv_4_ecog_trial.py``)
     - 00:00.000
     - 0.0
   * - :ref:`sphx_glr_auto_examples_applied_examples_plot_sleep_staging_chambon2018.py` (``plot_sleep_staging_chambon2018.py``)
     - 00:00.000
     - 0.0
