﻿braindecode.datasets.MOABBDataset
=================================

.. currentmodule:: braindecode.datasets

.. autoclass:: MOABBDataset
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.MOABBDataset.examples

.. raw:: html

    <div style='clear:both'></div>