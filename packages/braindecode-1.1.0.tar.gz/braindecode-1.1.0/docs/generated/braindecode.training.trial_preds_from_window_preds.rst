﻿braindecode.training.trial_preds_from_window_preds
==================================================

.. currentmodule:: braindecode.training

.. autofunction:: trial_preds_from_window_preds

.. include:: braindecode.training.trial_preds_from_window_preds.examples

.. raw:: html

    <div style='clear:both'></div>