﻿braindecode.samplers.RecordingSampler
=====================================

.. currentmodule:: braindecode.samplers

.. autoclass:: RecordingSampler
   
   
   
   
      
   
      
         
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: sample_recording

   
   .. automethod:: sample_window

   
   
   

.. include:: braindecode.samplers.RecordingSampler.examples

.. raw:: html

    <div style='clear:both'></div>