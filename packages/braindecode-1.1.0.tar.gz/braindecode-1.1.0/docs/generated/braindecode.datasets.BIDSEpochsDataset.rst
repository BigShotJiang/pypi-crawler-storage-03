﻿braindecode.datasets.BIDSEpochsDataset
======================================

.. currentmodule:: braindecode.datasets

.. autoclass:: BIDSEpochsDataset
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
   
   

.. include:: braindecode.datasets.BIDSEpochsDataset.examples

.. raw:: html

    <div style='clear:both'></div>