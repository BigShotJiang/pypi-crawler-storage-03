﻿braindecode.datasets.WindowsDataset
===================================

.. currentmodule:: braindecode.datasets

.. autoclass:: WindowsDataset
   
   
   
   
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: set_description

   
   
   

.. include:: braindecode.datasets.WindowsDataset.examples

.. raw:: html

    <div style='clear:both'></div>