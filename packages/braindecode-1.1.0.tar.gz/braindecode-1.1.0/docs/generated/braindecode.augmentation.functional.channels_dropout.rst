﻿braindecode.augmentation.functional.channels_dropout
====================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: channels_dropout

.. include:: braindecode.augmentation.functional.channels_dropout.examples

.. raw:: html

    <div style='clear:both'></div>