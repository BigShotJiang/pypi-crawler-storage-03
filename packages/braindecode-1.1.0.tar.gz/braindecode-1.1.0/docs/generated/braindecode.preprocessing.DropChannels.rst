﻿braindecode.preprocessing.DropChannels
======================================

.. currentmodule:: braindecode.preprocessing

.. autoclass:: DropChannels
   
   
   
   
      
   
      
   
   

.. include:: braindecode.preprocessing.DropChannels.examples

.. raw:: html

    <div style='clear:both'></div>