﻿braindecode.augmentation.functional.sign_flip
=============================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: sign_flip

.. include:: braindecode.augmentation.functional.sign_flip.examples

.. raw:: html

    <div style='clear:both'></div>