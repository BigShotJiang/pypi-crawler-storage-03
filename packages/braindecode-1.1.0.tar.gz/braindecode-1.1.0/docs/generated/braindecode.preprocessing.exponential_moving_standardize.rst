﻿braindecode.preprocessing.exponential_moving_standardize
========================================================

.. currentmodule:: braindecode.preprocessing

.. autofunction:: exponential_moving_standardize

.. include:: braindecode.preprocessing.exponential_moving_standardize.examples

.. raw:: html

    <div style='clear:both'></div>