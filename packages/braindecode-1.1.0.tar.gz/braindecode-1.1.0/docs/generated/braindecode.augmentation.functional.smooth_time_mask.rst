﻿braindecode.augmentation.functional.smooth_time_mask
====================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: smooth_time_mask

.. include:: braindecode.augmentation.functional.smooth_time_mask.examples

.. raw:: html

    <div style='clear:both'></div>