﻿braindecode.samplers.DistributedRecordingSampler
================================================

.. currentmodule:: braindecode.samplers

.. autoclass:: DistributedRecordingSampler
   
   
   
   
      
   
      
         
      
   
      
         
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: sample_recording

   
   .. automethod:: sample_window

   
   
   

.. include:: braindecode.samplers.DistributedRecordingSampler.examples

.. raw:: html

    <div style='clear:both'></div>