﻿braindecode.training.CroppedTrialEpochScoring
=============================================

.. currentmodule:: braindecode.training

.. autoclass:: CroppedTrialEpochScoring
   
   
   
   
      
   
      
   
      
   
      
   
      
   
      
         
      
   
      
   
      
         
      
   
      
   
      
   
      
   
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: on_batch_end

   
   .. automethod:: on_epoch_end

   
   
   

.. include:: braindecode.training.CroppedTrialEpochScoring.examples

.. raw:: html

    <div style='clear:both'></div>