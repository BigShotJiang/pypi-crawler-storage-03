﻿braindecode.datasets.create_from_mne_epochs
===========================================

.. currentmodule:: braindecode.datasets

.. autofunction:: create_from_mne_epochs

.. include:: braindecode.datasets.create_from_mne_epochs.examples

.. raw:: html

    <div style='clear:both'></div>