﻿braindecode.util.set_random_seeds
=================================

.. currentmodule:: braindecode.util

.. autofunction:: set_random_seeds

.. include:: braindecode.util.set_random_seeds.examples

.. raw:: html

    <div style='clear:both'></div>