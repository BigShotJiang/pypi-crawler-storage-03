﻿braindecode.functional.safe_log
===============================

.. currentmodule:: braindecode.functional

.. autofunction:: safe_log

.. include:: braindecode.functional.safe_log.examples

.. raw:: html

    <div style='clear:both'></div>