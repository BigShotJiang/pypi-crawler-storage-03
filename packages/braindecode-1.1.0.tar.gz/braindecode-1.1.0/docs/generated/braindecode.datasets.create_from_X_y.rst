﻿braindecode.datasets.create_from_X_y
====================================

.. currentmodule:: braindecode.datasets

.. autofunction:: create_from_X_y

.. include:: braindecode.datasets.create_from_X_y.examples

.. raw:: html

    <div style='clear:both'></div>