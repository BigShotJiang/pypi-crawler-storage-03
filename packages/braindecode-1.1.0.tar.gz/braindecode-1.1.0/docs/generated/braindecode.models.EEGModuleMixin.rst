﻿braindecode.models.EEGModuleMixin
=================================

.. currentmodule:: braindecode.models

.. autoclass:: EEGModuleMixin
   
   
   
   
      
   
      
         
      
   
      
         
      
   
      
         
      
   
      
         
      
   
   
   
   .. rubric:: Methods

   
   .. automethod:: get_output_shape

   
   .. automethod:: get_torchinfo_statistics

   
   .. automethod:: load_state_dict

   
   .. automethod:: to_dense_prediction_model

   
   
   

.. include:: braindecode.models.EEGModuleMixin.examples

.. raw:: html

    <div style='clear:both'></div>