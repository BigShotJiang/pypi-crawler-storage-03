﻿braindecode.modules.MaxLayer
============================

.. currentmodule:: braindecode.modules

.. autodata:: MaxLayer