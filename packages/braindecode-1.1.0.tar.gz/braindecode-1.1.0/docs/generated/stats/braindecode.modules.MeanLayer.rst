﻿braindecode.modules.MeanLayer
=============================

.. currentmodule:: braindecode.modules

.. autodata:: MeanLayer