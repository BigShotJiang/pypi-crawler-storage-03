﻿braindecode.training.predict_trials
===================================

.. currentmodule:: braindecode.training

.. autofunction:: predict_trials

.. include:: braindecode.training.predict_trials.examples

.. raw:: html

    <div style='clear:both'></div>