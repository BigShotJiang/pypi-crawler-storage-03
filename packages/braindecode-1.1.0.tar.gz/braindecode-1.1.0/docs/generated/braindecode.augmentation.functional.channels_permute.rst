﻿braindecode.augmentation.functional.channels_permute
====================================================

.. currentmodule:: braindecode.augmentation.functional

.. autofunction:: channels_permute

.. include:: braindecode.augmentation.functional.channels_permute.examples

.. raw:: html

    <div style='clear:both'></div>