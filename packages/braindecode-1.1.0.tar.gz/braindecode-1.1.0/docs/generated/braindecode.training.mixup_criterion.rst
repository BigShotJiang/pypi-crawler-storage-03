﻿braindecode.training.mixup_criterion
====================================

.. currentmodule:: braindecode.training

.. autofunction:: mixup_criterion

.. include:: braindecode.training.mixup_criterion.examples

.. raw:: html

    <div style='clear:both'></div>