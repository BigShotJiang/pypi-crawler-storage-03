from wmsdump.dumper import OGCServiceDumper as OGCServiceDumper
