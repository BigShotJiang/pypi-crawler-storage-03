class RelayCounter:
    def __init__(self):
        self.count = 0

    def reset(self):
        self.count = 0
