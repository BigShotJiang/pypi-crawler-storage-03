"""
Byte conversion constants
"""

ENDIAN_TYPE = "little"
