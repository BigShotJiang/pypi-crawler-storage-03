# Frequenz Electricity Trading API Release Notes

## Summary

This version relaxes the dependency on `frequenz-api-common` to support up to version 1.0.0, as this repository now guarantees backwards compatibility between v0.x releases.
