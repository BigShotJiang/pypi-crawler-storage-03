from .connection import Connection
from .node import Node

conn = Connection()
node = Node()
