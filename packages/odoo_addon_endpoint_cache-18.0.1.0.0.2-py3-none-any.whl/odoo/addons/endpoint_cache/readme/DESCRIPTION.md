Technical module provide basic caching configuration and utils for
endpoints.
