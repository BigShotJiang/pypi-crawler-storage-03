class Undefined:
  pass
