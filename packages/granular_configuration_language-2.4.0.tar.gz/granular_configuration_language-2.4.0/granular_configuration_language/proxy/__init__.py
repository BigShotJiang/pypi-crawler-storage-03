from __future__ import annotations

from granular_configuration_language.proxy._proxy import (
    EagerIOConfigurationProxy,
    SafeConfigurationProxy,
)
