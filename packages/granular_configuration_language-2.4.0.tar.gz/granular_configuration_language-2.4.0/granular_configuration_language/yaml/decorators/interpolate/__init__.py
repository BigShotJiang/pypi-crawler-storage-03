from __future__ import annotations

from granular_configuration_language.yaml.decorators.interpolate._interpolate import (
    interpolate_value_eager_io,
    interpolate_value_with_ref,
    interpolate_value_without_ref,
    interpolation_needs_ref_condition,
)
