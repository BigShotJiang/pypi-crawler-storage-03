from __future__ import annotations

from granular_configuration_language.yaml.decorators.ref._ref import resolve_json_ref
