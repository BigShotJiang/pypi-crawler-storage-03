from __future__ import annotations

from granular_configuration_language.yaml.file_ops.yaml._yaml import load_from_file, safe_load_from_file
