from __future__ import annotations

from granular_configuration_language.yaml.file_ops.text._text import EagerIOTextFile, load_text_file, read_text_data
