from __future__ import annotations

from granular_configuration_language.yaml.file_ops.environment_variable._environment_variable import (
    ENV_VAR_FILE_EXTENSION,
    _EagerIOEnvariableVariable,
    load_as_file,
)
