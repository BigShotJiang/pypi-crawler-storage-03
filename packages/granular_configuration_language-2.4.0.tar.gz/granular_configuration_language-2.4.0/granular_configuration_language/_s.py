from __future__ import annotations

setter_secret = object()
