from typing import Final

DAG_FILENAME_PREFIX: Final[str] = "dag"
VARIABLE_FILENAME: Final[str] = "variable"
ASSET_DIR: Final[str] = "assets"
