Protos needed for `predibase` SDK.

### Generation

Generate by following step by step version installs as laid out in
.github/workflows/generate_commit_protos.yaml
