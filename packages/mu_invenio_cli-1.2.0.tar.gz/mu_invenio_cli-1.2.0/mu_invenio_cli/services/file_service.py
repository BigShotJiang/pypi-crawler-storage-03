#
# Copyright (C) 2025 Masaryk University
#
# MU-INVENIO-CLI is free software; you can redistribute it and/or
# modify it under the terms of the MIT License; see LICENSE file for more
# details.
#
"""File service for handling file uploads in the MU Invenio CLI application."""

import os

import requests

from mu_invenio_cli.file_selector import FileSelector
from mu_invenio_cli.uploaders.file_uploader import FileUploader
from mu_invenio_cli.uploaders.multipart_uploader import MultipartUploader


class FileService:
    def __init__(self, context):
        self.context = context
        self.base_api_model_url = f"{self.context.config['BASE_API_URL']}/{self.context.config['MODEL']}"
        self.headers = {
            "Authorization": f"Bearer {self.context.config['API_TOKEN']}",
            "Content-Type": "application/json"
        }

    def upload_single_file(self):
        file_path = FileSelector().select_file_path()
        if not file_path:
            print("No file selected.")
            return
        if not os.path.isfile(file_path):
            print("File does not exist.")
            return

        file_size = os.path.getsize(file_path)
        uploaded = 0
        if file_size <= 100 * 1024 * 1024:  # 100MB threshold
            uploaded = FileUploader(self.context).upload(file_path)
        else:
            uploaded = MultipartUploader(self.context).upload(file_path)
        if uploaded < 0:
            print("File upload failed.")
            deleted = self.delete_file(file_path)
            if not deleted:
                print("Failed to clean up after upload failure. Please check the server.")

    def upload_multiple_files(self):
        print("Not implemented yet.")

    def delete_file(self, file_path):
        file_name = file_path.split("/")[-1]
        delete_url = f"{self.base_api_model_url}/{self.context.selected_id}/draft/files/{file_name}"
        try:
            response = requests.delete(delete_url, headers=self.headers, verify=False)
            if response.status_code != 204:
                print(f"Error deleting file {file_name}: {response.status_code}")
                return False
            print(f"File {file_name} deleted successfully.")
            return True
        except requests.exceptions.RequestException as e:
            print(f"Error deleting file {file_name}: {e}")
            return False