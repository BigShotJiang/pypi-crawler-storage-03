
PyRanges objects
----------------

The main object in pyranges is the PyRanges object.
It is a pandas DataFrame with additional methods for genomic operations.


.. autoclass:: pyranges.PyRanges
   :members:
