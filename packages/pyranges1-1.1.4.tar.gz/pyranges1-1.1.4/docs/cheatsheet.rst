
Cheatsheet
~~~~~~~~~~
Here's a cheatsheet for Pyranges, summarizing the most common operations.

.. image:: https://raw.githubusercontent.com/pyranges/pyranges_plot/for_pyranges1_1/images/pyranges_cheatsheet.png
   :alt: PyRanges cheatsheet
   :target: https://raw.githubusercontent.com/pyranges/pyranges_plot/for_pyranges1_1/images/pyranges_cheatsheet.png
