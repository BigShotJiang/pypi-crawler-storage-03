How-to pages
============

These pages explain pyranges functionalities grouped by topic:

.. toctree::
   :maxdepth: 3

   how_to_create
   how_to_write
   how_to_inspect
   how_to_rows
   how_to_columns
   how_to_sequences
   how_to_genomic_ops
   how_to_overlap
   how_to_map
