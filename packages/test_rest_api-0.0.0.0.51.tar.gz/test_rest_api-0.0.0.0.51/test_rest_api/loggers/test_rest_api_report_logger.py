import logging

# Create custom logger for test rest api report logging
test_rest_api_report_logger: logging.Logger = logging.getLogger(name="test_rest_api_report")
