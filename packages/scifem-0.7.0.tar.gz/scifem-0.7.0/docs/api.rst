#############
API reference
#############

.. automodule:: scifem
    :members:
