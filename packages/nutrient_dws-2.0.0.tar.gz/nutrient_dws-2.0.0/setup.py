"""Minimal setup.py for compatibility with tools that require it."""

from setuptools import setup

setup()
