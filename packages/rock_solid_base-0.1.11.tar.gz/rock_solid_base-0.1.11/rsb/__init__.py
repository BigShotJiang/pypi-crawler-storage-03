"""Rock Solid Base - An utility package for Python."""
