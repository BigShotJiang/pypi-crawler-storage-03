from pydantic.networks import AnyUrl as _AU


class AnyUrl(_AU):
    """Alias for pydantic.AnyUrl."""

    pass
