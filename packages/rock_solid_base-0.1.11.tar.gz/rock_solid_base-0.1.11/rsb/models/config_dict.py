from pydantic.config import ConfigDict as _CD


class ConfigDict(_CD):
    """Alias for pydantic.ConfigDict."""

    pass
