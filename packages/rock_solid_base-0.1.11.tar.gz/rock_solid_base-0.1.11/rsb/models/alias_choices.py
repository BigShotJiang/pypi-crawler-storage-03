from pydantic import AliasChoices as _AliasChoices


class AliasChoices(_AliasChoices):
    """Alias for pydantic.AliasChoices."""

    pass
