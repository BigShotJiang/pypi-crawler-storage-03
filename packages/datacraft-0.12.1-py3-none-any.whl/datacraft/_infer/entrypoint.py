"""datacraft.custom_type_loader entrypoint for inference functions"""


def load_custom():
    """entry point for loading internally registered types"""
    # registered types inherited from __init__.py, nothing to see here, move along
