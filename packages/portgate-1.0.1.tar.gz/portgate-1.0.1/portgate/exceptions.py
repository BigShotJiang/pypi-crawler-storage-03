class PortGateError(Exception):
    pass