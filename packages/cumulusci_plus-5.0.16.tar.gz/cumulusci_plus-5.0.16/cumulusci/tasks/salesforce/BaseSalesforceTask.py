# This moved to prevent an import cycle.
from cumulusci.core.tasks import BaseSalesforceTask

__all__ = ("BaseSalesforceTask",)
