from cumulusci.plugins.plugin_base import PluginBase

__all__ = ("PluginBase",)
