from mosamaticdesktop.ui.dialogs.dialog import Dialog


class HelpDialog(Dialog):
    def clear(self):
        pass

    def set_text(self, text):
        pass