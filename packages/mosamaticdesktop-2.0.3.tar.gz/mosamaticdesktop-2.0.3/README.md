# MosamaticDesktop
PySide6 desktop app for running processing tasks on CT images