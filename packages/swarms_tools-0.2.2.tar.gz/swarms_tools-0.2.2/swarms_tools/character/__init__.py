from swarms_tools.character.synthesia_tool import synthesia_api

__all__ = ["synthesia_api"]
