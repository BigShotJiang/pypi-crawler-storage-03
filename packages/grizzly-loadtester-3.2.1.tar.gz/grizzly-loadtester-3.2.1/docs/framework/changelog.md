---
title: Changelog
---
# Changelog

@shell cd ../../ && python3 script/docs-generate-changelog.py
