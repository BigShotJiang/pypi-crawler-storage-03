import { render } from "./components/App";render();
