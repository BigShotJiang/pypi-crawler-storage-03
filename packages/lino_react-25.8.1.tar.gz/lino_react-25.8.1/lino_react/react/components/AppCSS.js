import(/* webpackChunkName: "prRhea_AppCSS" */'primereact/resources/themes/rhea/theme.css');
// import 'primereact/resources/themes/rhea/theme.css';
// import 'primereact/resources/themes/saga-green/theme.css';
// import 'primereact/resources/themes/luna-green/theme.css';
// import(/* webpackChunkName: "prCommon_AppCSS" */'primereact/resources/primereact.min.css');
import 'primereact/resources/primereact.min.css';
// import(/* webpackChunkName: "prIcons_AppCSS" */'primeicons/primeicons.css');
import 'primeicons/primeicons.css';
import(/* webpackChunkName: "prFlex_AppCSS" */'primeflex/primeflex.css');
// import 'primeflex/primeflex.css';

// import(/* webpackChunkName: "layout_AppCSS" */'./layout/layout.css');
import './layout/layout.css';
import './App.css';
