=========
Changelog
=========

The changes in this repository are documented on
https://www.lino-framework.org/changes/

The source code for above page is also available at
https://gitlab.com/lino-framework/book/-/blob/master/docs/changes/index.rst
