"""
Spike sorting views for figpack
"""

from . import views
