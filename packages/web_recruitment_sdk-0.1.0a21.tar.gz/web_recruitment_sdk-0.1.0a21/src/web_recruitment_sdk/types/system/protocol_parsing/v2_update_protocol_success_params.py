# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Required, Annotated, TypedDict

from ...._utils import PropertyInfo
from ...custom_searches.criteria_create_param import CriteriaCreateParam

__all__ = ["V2UpdateProtocolSuccessParams"]


class V2UpdateProtocolSuccessParams(TypedDict, total=False):
    path_tenant_db_name: Required[Annotated[str, PropertyInfo(alias="tenant_db_name")]]

    criteria_create: Required[Annotated[Iterable[CriteriaCreateParam], PropertyInfo(alias="criteriaCreate")]]

    external_protocol_id: Required[Annotated[str, PropertyInfo(alias="externalProtocolId")]]

    task_id: Required[Annotated[int, PropertyInfo(alias="taskId")]]
    """The ID of the task as it exists in the database"""

    task_name: Required[Annotated[str, PropertyInfo(alias="taskName")]]
    """The name of the task"""

    body_tenant_db_name: Required[Annotated[str, PropertyInfo(alias="tenantDbName")]]
