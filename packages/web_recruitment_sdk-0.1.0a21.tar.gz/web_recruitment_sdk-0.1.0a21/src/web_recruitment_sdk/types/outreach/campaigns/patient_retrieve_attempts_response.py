# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["PatientRetrieveAttemptsResponse", "PatientRetrieveAttemptsResponseItem"]


class PatientRetrieveAttemptsResponseItem(BaseModel):
    id: int

    attempt_type: Literal["PHONE_CALL", "SMS"] = FieldInfo(alias="attemptType")

    patient_campaign_id: int = FieldInfo(alias="patientCampaignId")

    task_id: int = FieldInfo(alias="taskId")


PatientRetrieveAttemptsResponse: TypeAlias = List[PatientRetrieveAttemptsResponseItem]
