# GraphQL HTTP Server

Minimal adapter to respond to HTTP requests with a GraphQL schema.
