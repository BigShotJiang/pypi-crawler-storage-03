
class TooManyRequests(Exception):
    pass

class LlmError(Exception):
    pass

class ParseError(Exception):
    pass

class RequestError(Exception):
    pass

