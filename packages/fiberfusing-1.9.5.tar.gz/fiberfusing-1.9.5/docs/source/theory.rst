.. _theory:

Theoretical background
======================

