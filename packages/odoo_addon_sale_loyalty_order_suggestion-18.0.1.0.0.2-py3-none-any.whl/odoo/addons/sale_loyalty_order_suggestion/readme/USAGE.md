To use this module:

- Configure or create a promotion and set in its rules products and a
  required quantity.
- Create a sales order and add to the order lines one of the products
  that were part of the promotion rules. This line will then be marked
  with an icon (🎁) which will appear at the end on the right.
- Click on the icon and the wizard will open with the available
  promotions of which the product is part of its rules.
- Select the promotion and the products needed to apply it.
