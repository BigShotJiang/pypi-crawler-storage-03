HOST = "https://api.electricitymaps.com/v3"
