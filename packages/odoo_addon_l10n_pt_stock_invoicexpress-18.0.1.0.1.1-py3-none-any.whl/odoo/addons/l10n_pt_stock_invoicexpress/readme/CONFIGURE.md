This feature depends on the InvoiceXpress Incoice generation feature.
See
<https://github.com/OCA/l10n-portugal/blob/14.0/l10n_pt_account_invoicexpress/README.rst>
for configuration details.

An additional "InvoiceXpress Delivery Email" option is available, to
configure the email template preparing the details for the emailto be
sent by the InvoiceXpress service.
