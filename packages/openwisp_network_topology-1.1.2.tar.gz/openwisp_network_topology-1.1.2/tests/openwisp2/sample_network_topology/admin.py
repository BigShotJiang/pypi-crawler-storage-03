from openwisp_network_topology import admin  # noqa
