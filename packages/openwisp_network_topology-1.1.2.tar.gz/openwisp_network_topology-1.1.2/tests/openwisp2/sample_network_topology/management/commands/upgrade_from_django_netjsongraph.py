from openwisp_network_topology.management.commands.upgrade_from_django_netjsongraph import (
    Command as BaseCommand,
)


class Command(BaseCommand):
    pass
