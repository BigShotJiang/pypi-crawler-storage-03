from openwisp_network_topology.management.commands import BaseUpdateCommand


class Command(BaseUpdateCommand):
    pass
