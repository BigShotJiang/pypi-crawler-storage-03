from openwisp_network_topology.management.commands import BaseSaveSnapshotCommand


class Command(BaseSaveSnapshotCommand):
    pass
