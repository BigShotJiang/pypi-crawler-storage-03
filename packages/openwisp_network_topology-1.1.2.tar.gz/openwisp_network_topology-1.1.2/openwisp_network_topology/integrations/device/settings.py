from ...settings import get_settings_value

WIFI_MESH_INTEGRATION = get_settings_value('WIFI_MESH_INTEGRATION', False)
