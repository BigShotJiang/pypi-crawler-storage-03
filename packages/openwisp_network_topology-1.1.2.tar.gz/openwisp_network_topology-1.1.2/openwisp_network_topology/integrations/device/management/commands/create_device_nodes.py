from . import BaseCreateDeviceNodeCommand


class Command(BaseCreateDeviceNodeCommand):
    pass
