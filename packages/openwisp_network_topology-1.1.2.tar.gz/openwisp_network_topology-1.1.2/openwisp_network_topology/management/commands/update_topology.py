from . import BaseUpdateCommand


class Command(BaseUpdateCommand):
    pass
