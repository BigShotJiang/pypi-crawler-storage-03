from . import BaseSaveSnapshotCommand


class Command(BaseSaveSnapshotCommand):
    pass
