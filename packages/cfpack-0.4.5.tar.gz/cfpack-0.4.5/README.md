# Python tools written by Christoph Federrath #

### Copyright notes ###

See LICENSE file.

### Main contact ###

* Christoph Federrath (christoph.federrath@anu.edu.au)

### Website ###

* https://www.mso.anu.edu.au/~chfeder/codes/cfpack/cfpack.html

### Disclaimer ###

This software is provided "as is", with use at your own risk. No warranties as to performance, fitness for a particular purpose, or any other warranties are made, whether expressed or implied.
