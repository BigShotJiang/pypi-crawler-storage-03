"""Modules related to encryption both local and messaging."""
