"""Algorithm plugins in this package."""

from __future__ import annotations
