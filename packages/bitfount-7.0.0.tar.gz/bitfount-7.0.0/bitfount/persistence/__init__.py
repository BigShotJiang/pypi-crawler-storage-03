"""Modules related to generic persistence/caching capabilities."""
