"""Packages and modules related to EHR system interactions."""
