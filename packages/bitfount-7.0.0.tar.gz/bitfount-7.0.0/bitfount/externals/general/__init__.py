"""Packages and modules containing general utilities for external services."""
