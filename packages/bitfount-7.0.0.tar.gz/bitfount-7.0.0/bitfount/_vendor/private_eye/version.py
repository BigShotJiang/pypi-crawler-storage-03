separated_version = (5, 1, 1)
version = ".".join(str(elem) for elem in separated_version)
