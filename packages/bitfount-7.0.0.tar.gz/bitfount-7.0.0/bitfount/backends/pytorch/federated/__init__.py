"""Federated components for the PyTorch backend."""

from __future__ import annotations
