#!/usr/bin/env python3
"""
Portal OS Component Installer
Handles graceful installation of all Portal OS components
"""
import os
import sys
import subprocess
import platform
from pathlib import Path
from typing import Dict, Any, List, Optional
from .base_component import BaseComponent, ProgressMixin, ConfigMixin
from datetime import datetime


class ComponentInstaller(BaseComponent, DatabaseMixin, ProgressMixin, ConfigMixin):
    """Portal OS Component Installer - Handles graceful installation of all components"""
    
    def __init__(self):
        super().__init__(
            component_id="component_installer",
            name="🔧 Component Installer",
            description="Manages installation of all Portal OS components"
        )
        
        self.system = platform.system().lower()
        self.is_linux = self.system == "linux"
        self.is_windows = self.system == "windows"
        self.is_macos = self.system == "darwin"
        
        # Define all components
        self.components = self._define_components()
    
    def _define_components(self) -> Dict[str, Dict[str, Any]]:
        """Define all Portal OS components"""
        return {
            "ai_assistant": {
                "name": "🤖 AI Assistant",
                "description": "Conversational AI assistant with context awareness",
                "script": "ai_assistant.py",
                "category": "ai",
                "dependencies": ["ollama"]
            },
            "security_privacy": {
                "name": "🔒 Security & Privacy",
                "description": "Advanced security and privacy management",
                "script": "security_privacy_manager.py",
                "category": "system",
                "dependencies": []
            },
            "performance_optimizer": {
                "name": "⚡ Performance Optimizer",
                "description": "System performance optimization and monitoring",
                "script": "performance_optimizer.py",
                "category": "system",
                "dependencies": []
            },
            "search_assistant": {
                "name": "🔍 Search Assistant",
                "description": "Intelligent file and content search",
                "script": "search_assistant_setup.py",
                "category": "productivity",
                "dependencies": ["meilisearch"]
            },
            "voice_interaction": {
                "name": "🎤 Voice Interaction",
                "description": "Speech-to-text and text-to-speech capabilities",
                "script": "voice_interaction.py",
                "category": "ai",
                "dependencies": ["pyttsx3", "SpeechRecognition"]
            },
            "advanced_ai": {
                "name": "🧠 Advanced AI",
                "description": "AI-powered workspace management and code intelligence",
                "script": "advanced_ai_features.py",
                "category": "ai",
                "dependencies": ["ollama"]
            },
            "theme_manager": {
                "name": "🎨 Theme Manager",
                "description": "Visual theme and appearance management",
                "script": "theme_manager.py",
                "category": "ui",
                "dependencies": []
            },
            "plugin_manager": {
                "name": "🔌 Plugin Manager",
                "description": "Plugin system management and updates",
                "script": "plugin_manager.py",
                "category": "system",
                "dependencies": []
            },
            "ui_ux_manager": {
                "name": "🖥️ UI/UX Manager",
                "description": "User interface and experience management",
                "script": "ui_ux_manager.py",
                "category": "ui",
                "dependencies": []
            },
            "sdk_manager": {
                "name": "🔧 SDK Manager",
                "description": "Development tools and SDK installations",
                "script": "sdk_installer.py",
                "category": "development",
                "dependencies": []
            }
        }
    
    def _create_tables(self):
        """Create component installer database tables"""
        queries = [
            """
            CREATE TABLE IF NOT EXISTS installed_components (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                version TEXT,
                install_date TEXT NOT NULL,
                status TEXT DEFAULT 'installed',
                script_path TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS installation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT,
                timestamp TEXT NOT NULL
            )
            """
        ]
        
        for query in queries:
            self.execute_query(query)
    
    def check_component_exists(self, component_id: str) -> bool:
        """Check if a component is already installed"""
        query = "SELECT component_id FROM installed_components WHERE component_id = ?"
        result = self.execute_query(query, (component_id,))
        return result is not None and len(result) > 0
    
    def check_script_exists(self, script_name: str) -> bool:
        """Check if a component script exists"""
        script_path = Path(__file__).parent.parent / "scripts" / script_name
        return script_path.exists()
    
    def log_installation(self, component_id: str, action: str, status: str, message: str = ""):
        """Log installation activity"""
        timestamp = datetime.now().isoformat()
        query = """
        INSERT INTO installation_logs (component_id, action, status, message, timestamp)
        VALUES (?, ?, ?, ?, ?)
        """
        self.execute_query(query, (component_id, action, status, message, timestamp))
    
    def get_installed_components(self) -> List[Dict[str, Any]]:
        """Get list of installed components"""
        query = "SELECT component_id, name, version, install_date, status FROM installed_components"
        results = self.execute_query(query)
        
        if not results:
            return []
        
        return [
            {
                "component_id": row[0],
                "name": row[1],
                "version": row[2],
                "install_date": row[3],
                "status": row[4]
            }
            for row in results
        ]
    
    def install_component(self, component_id: str) -> bool:
        """Install a specific component gracefully"""
        if component_id not in self.components:
            self.log(f"Component {component_id} not found", "ERROR")
            return False
        
        component = self.components[component_id]
        
        # Check if already installed
        if self.check_component_exists(component_id):
            self.log(f"Component {component_id} already installed", "INFO")
            return True
        
        # Check if script exists
        if not self.check_script_exists(component["script"]):
            self.log(f"Script for {component_id} not found: {component['script']}", "ERROR")
            return False
        
        # Install the component
        self.log(f"Installing {component_id}", "INFO")
        self.log_installation(component_id, "install", "started")
        
        try:
            # Run the component's install script
            script_path = Path(__file__).parent.parent / "scripts" / component["script"]
            result = self.run_command([sys.executable, str(script_path), "install"], 
                                    capture_output=False, check=False)
            
            if result and result.returncode == 0:
                self.log_installation(component_id, "install", "completed")
                self._record_installed_component(component_id, component["name"], str(script_path))
                return True
            else:
                self.log_installation(component_id, "install", "failed")
                return False
        except Exception as e:
            self.log(f"Error installing {component_id}: {e}", "ERROR")
            self.log_installation(component_id, "install", "failed", str(e))
            return False
    
    def _record_installed_component(self, component_id: str, name: str, script_path: str):
        """Record an installed component in the database"""
        timestamp = datetime.now().isoformat()
        query = """
        INSERT OR REPLACE INTO installed_components (component_id, name, install_date, status, script_path)
        VALUES (?, ?, ?, ?, ?)
        """
        self.execute_query(query, (component_id, name, timestamp, "installed", script_path))
    
    def install(self) -> bool:
        """Install all Portal OS components gracefully"""
        self.show_step("🚀 Starting Portal OS component installation", "info")
        
        # Group components by category
        ai_components = [k for k, v in self.components.items() if v["category"] == "ai"]
        system_components = [k for k, v in self.components.items() if v["category"] == "system"]
        productivity_components = [k for k, v in self.components.items() if v["category"] == "productivity"]
        ui_components = [k for k, v in self.components.items() if v["category"] == "ui"]
        dev_components = [k for k, v in self.components.items() if v["category"] == "development"]
        
        all_components = ai_components + system_components + productivity_components + ui_components + dev_components
        total_components = len(all_components)
        
        # Install AI Components first
        self.show_step("🤖 Installing AI Components...", "info")
        for i, component_id in enumerate(ai_components, 1):
            self.show_progress(i, len(ai_components), f"Installing {self.components[component_id]['name']}")
            success = self.install_component(component_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {component_id}", "warning")
        
        # Install System Components
        self.show_step("⚙️ Installing System Components...", "info")
        for i, component_id in enumerate(system_components, 1):
            self.show_progress(i, len(system_components), f"Installing {self.components[component_id]['name']}")
            success = self.install_component(component_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {component_id}", "warning")
        
        # Install Productivity Components
        self.show_step("📈 Installing Productivity Components...", "info")
        for i, component_id in enumerate(productivity_components, 1):
            self.show_progress(i, len(productivity_components), f"Installing {self.components[component_id]['name']}")
            success = self.install_component(component_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {component_id}", "warning")
        
        # Install UI Components
        self.show_step("🎨 Installing UI Components...", "info")
        for i, component_id in enumerate(ui_components, 1):
            self.show_progress(i, len(ui_components), f"Installing {self.components[component_id]['name']}")
            success = self.install_component(component_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {component_id}", "warning")
        
        # Install Development Components
        self.show_step("🔧 Installing Development Components...", "info")
        for i, component_id in enumerate(dev_components, 1):
            self.show_progress(i, len(dev_components), f"Installing {self.components[component_id]['name']}")
            success = self.install_component(component_id)
            if not success:
                self.show_step(f"⚠️ Failed to install {component_id}", "warning")
        
        self.show_step("🎉 Component installation complete!", "success")
        return True
    
    def start(self) -> bool:
        """Start all installed components"""
        self.show_step("▶️ Starting all Portal OS components", "info")
        
        installed_components = self.get_installed_components()
        total_components = len(installed_components)
        
        for i, component in enumerate(installed_components, 1):
            component_id = component["component_id"]
            if component_id in self.components:
                self.show_progress(i, total_components, f"Starting {self.components[component_id]['name']}")
                
                try:
                    script_path = Path(__file__).parent.parent / "scripts" / self.components[component_id]["script"]
                    result = self.run_command([sys.executable, str(script_path), "start"], 
                                            capture_output=False, check=False)
                    
                    if result and result.returncode == 0:
                        self.show_step(f"✅ Started {component_id}", "success")
                    else:
                        self.show_step(f"⚠️ Failed to start {component_id}", "warning")
                except Exception as e:
                    self.show_step(f"❌ Error starting {component_id}: {e}", "error")
        
        self.is_running = True
        return True
    
    def stop(self) -> bool:
        """Stop all running components"""
        self.show_step("⏹️ Stopping all Portal OS components", "info")
        
        installed_components = self.get_installed_components()
        total_components = len(installed_components)
        
        for i, component in enumerate(installed_components, 1):
            component_id = component["component_id"]
            if component_id in self.components:
                self.show_progress(i, total_components, f"Stopping {self.components[component_id]['name']}")
                
                try:
                    script_path = Path(__file__).parent.parent / "scripts" / self.components[component_id]["script"]
                    result = self.run_command([sys.executable, str(script_path), "stop"], 
                                            capture_output=False, check=False)
                    
                    if result and result.returncode == 0:
                        self.show_step(f"✅ Stopped {component_id}", "success")
                    else:
                        self.show_step(f"⚠️ Failed to stop {component_id}", "warning")
                except Exception as e:
                    self.show_step(f"❌ Error stopping {component_id}: {e}", "error")
        
        self.is_running = False
        return True
    
    def status(self) -> Dict[str, Any]:
        """Get detailed component installer status"""
        installed_components = self.get_installed_components()
        
        # Check current status of all components
        component_status = {}
        for component_id, component_info in self.components.items():
            is_installed = self.check_component_exists(component_id)
            script_exists = self.check_script_exists(component_info["script"])
            
            component_status[component_id] = {
                "name": component_info["name"],
                "category": component_info["category"],
                "installed": is_installed,
                "script_exists": script_exists,
                "script": component_info["script"]
            }
        
        return {
            **self.get_status(),
            "installed_components": installed_components,
            "component_status": component_status,
            "platform": self.system,
            "total_components": len(self.components),
            "installed_count": len([c for c in component_status.values() if c["installed"]]),
            "scripts_found": len([c for c in component_status.values() if c["script_exists"]])
        }
