#!/usr/bin/env python3
"""
Portal OS - AI-Native Developer Operating System
A revolutionary operating system that combines Ubuntu's stability with AI-first design principles.
"""

__version__ = "1.0.5"
__author__ = "Portal OS Team"
__email__ = "team@portal-os.dev"
__description__ = "AI-Native Developer Operating System based on Ubuntu"

# Import key functions for easy access
from .config import get_config, get_component_config, apply_profile
from .cli import main

__all__ = [
    "__version__",
    "__author__", 
    "__email__",
    "__description__",
    "get_config",
    "get_component_config", 
    "apply_profile",
    "main"
]
