# [qilowatt](<https://qilowatt.eu>) Python Module


  - connecting to qilowatt MQTT server to send status, state and state0.
  - Receives BACKLOG commands
  - see example.py for usage