from .api import zodchy_endpoint

__all__ = ['zodchy_endpoint']