#Aplicacion de ventas

Este paquete proporciona funcionalidades para gestionar ventas, iincluyendo calculos de precios, impuestos y descuentós

##Instalacion
Instalar el paquete usando:
'''bash
pip install .
"