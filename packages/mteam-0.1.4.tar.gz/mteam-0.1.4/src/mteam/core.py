def example_function():
    """示例函数"""
    return "Hello from mteam!" 