# If you have cloned the source code repository, use editable install to link the package catalog to the repository directory:
# $ pip install -e . --config-settings editable_mode=compat

from setuptools import setup

if __name__ == "__main__":
    setup()
