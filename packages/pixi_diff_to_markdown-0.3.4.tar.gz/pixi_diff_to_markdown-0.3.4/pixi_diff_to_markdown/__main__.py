from pixi_diff_to_markdown.cli import app

if __name__ == "__main__":
    app()
