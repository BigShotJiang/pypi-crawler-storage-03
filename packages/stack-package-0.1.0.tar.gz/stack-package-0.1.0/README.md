# Stack Package

Stack Python пакет, содержащий данные из файла `test.txt`.

## Установка

```bash
pip install stack-package
```

## Использование

```python
from stack import data

# Получить содержимое test.txt
print(data.get_content())
```

## Лицензия

MIT License 