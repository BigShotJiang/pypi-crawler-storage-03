"""Utils module for Climatrix."""
