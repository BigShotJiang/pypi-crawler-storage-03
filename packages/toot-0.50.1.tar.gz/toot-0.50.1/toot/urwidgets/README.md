urwidgets vendored from:
https://github.com/AnonymouX47/urwidgets

Licensed under the MIT license:
https://github.com/AnonymouX47/urwidgets/blob/main/LICENSE

This was done to be able to upgrade to urwid version 3, since urwidgets are
limited to urwid < 3.
