"""Tests for websnap."""
