def main():
    print("Hey, that is my username!")


if __name__ == "__main__":
    main()
