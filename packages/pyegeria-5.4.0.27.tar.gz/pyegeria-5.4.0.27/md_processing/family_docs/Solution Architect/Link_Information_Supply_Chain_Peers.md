# **Link Information Supply Chain Peers**
>	This command can be used to link or unlink information supply chain segments.

## **Segment1**
>	**Input Required**: True

>	**Description**: The  first segment to link.

>	**Alternative Labels**: Segment 1; Information Supply Chain Segment 1; Info Supply Chain Segment 1


## **Segment2**
>	**Input Required**: True

>	**Description**: The  second segment to link.

>	**Alternative Labels**: Segment 2; Information Supply Chain Segment 2; Info Supply Chain Segment 2


## **Link Label**
>	**Input Required**: False

>	**Description**: Labels the link between two information supply chain segments.

>	**Alternative Labels**: Label


## **Description**
>	**Input Required**: False

>	**Description**: A description of the data structure.

