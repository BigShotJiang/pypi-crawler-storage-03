
# hypetext

Hypetext performs HTML generation based on template strings.
