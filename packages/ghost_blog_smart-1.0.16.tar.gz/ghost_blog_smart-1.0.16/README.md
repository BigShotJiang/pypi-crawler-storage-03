# Ghost Blog Smart API

🚀 A powerful Python API for creating and managing Ghost CMS blog posts with AI-powered features including automatic image generation, content formatting, and comprehensive blog management.

[![PyPI version](https://badge.fury.io/py/ghost-blog-smart.svg)](https://badge.fury.io/py/ghost-blog-smart)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/release/python-380/)

## 📥 Installation

```bash
pip install ghost-blog-smart
```

## ✨ Features

### 🤖 Smart Gateway
- **Intelligent Routing** - Automatically determines if content needs rewriting or can be published directly
- **Structured Output** - Uses Gemini's structured output for consistent blog formatting
- **Function Calling** - Leverages Gemini function calling for smart decision making
- **Auto Enhancement** - Transforms scattered ideas into complete, well-structured blog posts
- **Missing Component Detection** - Automatically generates titles, excerpts, and tags when missing

### 🎨 Dual AI Image Generation
- **🔥 Replicate Flux-dev**: Ultra-fast generation (3-7 seconds), photorealistic images, WebP format
- **🏔️ Google Imagen-4**: Professional quality, advanced prompt understanding, PNG format
- **Automatic Fallback System**: Intelligent provider switching for maximum reliability
- **Provider Selection**: Choose your preferred provider or let the system decide
- **Multiple Aspect Ratios**: 16:9, 1:1, 9:16, 4:3, 3:2 support

### Content Creation & Management
- 📝 **Smart Content Formatting** - Auto-format plain text to beautiful Markdown with Gemini AI
- 🔗 **YouTube-Style Slugs** - Generate 11-character slugs like YouTube video IDs
- 🎬 **YouTube Video Embedding** - Seamlessly embed YouTube videos in posts
- 🌏 **Multi-language Support** - Chinese to Pinyin conversion for slugs
- 🌐 **Language Translation** - Auto-translate content to any target language
- 🖼️ **Flexible Image Handling** - Support for URLs, local files, base64 data

### Blog Management
- 📋 **Advanced Listing** - Get posts with powerful filtering options
- 🔍 **Search & Query** - Full-text search across all posts
- 📅 **Date Range Filtering** - Find posts by publication/creation date
- 📊 **Detailed Post Info** - Get complete post details including content
- ✏️ **Update Posts** - Modify any post property (title, content, dates, etc.)
- ⭐ **Featured Control** - Set posts as featured or unfeatured
- 👁️ **Visibility Management** - Control post visibility (public/members/paid)
- 🔄 **Status Toggle** - Publish/unpublish posts instantly
- 🖼️ **Image Updates** - Replace, generate, or remove feature images
- 📆 **Date Management** - Update published dates for content organization
- 🗑️ **Post Deletion** - Remove posts from Ghost CMS
- ⚡ **Batch Operations** - Process multiple posts efficiently

## 📋 Prerequisites

- Python 3.8+
- Ghost CMS instance with Admin API access
- **Image Generation** (choose one or both):
  - Google Gemini API key (for Imagen-4 generation)
  - Replicate API token (for Flux-dev generation)

## 🚀 Quick Start

### 1. Installation

```bash
pip install ghost-blog-smart
```

### 2. Configuration

Create a `.env` file in your project root:

```env
# Ghost CMS Configuration
GHOST_ADMIN_API_KEY=your_admin_api_key_id:your_secret_key_here
GHOST_API_URL=https://your-ghost-site.com

# Google AI Configuration (for Imagen generation)
GEMINI_API_KEY=your_gemini_api_key_here

# Replicate Configuration (for Flux generation)
REPLICATE_API_TOKEN=r8_your_replicate_api_token_here
```

**Important Notes:**
- `GHOST_ADMIN_API_KEY` format: `key_id:secret_key` (colon-separated)
- `GHOST_API_URL` must include `https://`
- `REPLICATE_API_TOKEN` format: `r8_xxxxxxxxxxxxxx` (get from [Replicate Account](https://replicate.com/account))
- All API keys can be provided either through environment variables OR as function parameters

### 3. Basic Usage

#### Smart Gateway Method (Recommended)
```python
from ghost_blog_smart import smart_blog_gateway

# Transform scattered ideas into a complete blog post
result = smart_blog_gateway(
    "AI healthcare benefits: faster diagnosis, better accuracy, cost reduction. Challenges: privacy, regulation.",
    status="published"
)

# The AI will automatically:
# - Analyze input complexity and completeness
# - Route through optimal processing path
# - Generate missing title, excerpt, tags
# - Structure content professionally
# - Generate feature image with Flux/Imagen
# - Publish to Ghost CMS
```

#### Traditional Method
```python
from ghost_blog_smart import create_ghost_blog_post

# Create a simple blog post
result = create_ghost_blog_post(
    title="My First Post",
    content="This is the content of my blog post.",
    excerpt="A brief summary",
    tags=["Tutorial", "Getting Started"],
    status="published"
)

if result['success']:
    print(f"Post created: {result['url']}")
```

## 🎯 Image Generation Examples

### Replicate Flux (Ultra-Fast)
```python
result = create_ghost_blog_post(
    title="AI Revolution in Photography",
    content="Artificial intelligence is transforming photography...",
    use_generated_feature_image=True,
    prefer_flux=True,  # 3-7 second generation time
    replicate_api_key="r8_your_token_here",
    image_aspect_ratio="16:9"
)
```

### Google Imagen (Professional Quality)
```python
result = create_ghost_blog_post(
    title="Digital Art Mastery Guide", 
    content="Digital art has evolved tremendously...",
    use_generated_feature_image=True,
    prefer_imagen=True,  # Professional quality
    gemini_api_key="your_gemini_key",
    image_aspect_ratio="16:9"
)
```

### Auto-Fallback System
```python
# Set both API keys - system will try Flux first, fallback to Imagen if needed
result = create_ghost_blog_post(
    title="Tech Innovation Landscape",
    content="Today's technology landscape is dynamic...",
    use_generated_feature_image=True,
    replicate_api_key="r8_your_token_here",
    gemini_api_key="your_gemini_key",
    # No preference specified - auto-fallback enabled
    image_aspect_ratio="16:9"
)
```

## 📚 API Reference

### Smart Gateway

#### `smart_blog_gateway(user_input, **kwargs)`

Intelligent gateway that automatically routes blog creation through the optimal path.

**Parameters:**
- `user_input` (str): Your blog content, ideas, or request
- `status` (str): 'published' or 'draft' (default: 'published')
- `preferred_language` (str): Target language for output (optional)
- `replicate_api_key` (str): Replicate API token for Flux generation
- `gemini_api_key` (str): Google Gemini API key for Imagen generation

**Returns:**
```python
{
    'success': bool,
    'response': str,           # Human-readable status message
    'url': str,               # Ghost post URL (if successful)
    'post_id': str,           # Ghost post ID (if successful)
    'generated_title': str,   # AI-generated title
    'generated_excerpt': str, # AI-generated excerpt
    'generated_tags': list,   # AI-generated tags
    'rewritten_data': dict    # Rewritten content details (if applicable)
}
```

### Content Creation

#### `create_ghost_blog_post(**kwargs)`

Main function to create Ghost blog posts.

**Required Parameters:**
- `title` (str): Blog post title
- `content` (str): Blog post content (Markdown or plain text)

**Image Generation Parameters:**
- `use_generated_feature_image` (bool): Generate AI image (default: False)
- `prefer_flux` (bool): Prefer Replicate Flux over Google Imagen
- `prefer_imagen` (bool): Prefer Google Imagen over Replicate Flux
- `replicate_api_key` (str): Replicate API token for Flux generation
- `gemini_api_key` (str): Google Gemini API key for Imagen generation
- `image_generation_prompt` (str): Custom prompt for image generation
- `image_aspect_ratio` (str): '16:9', '1:1', '9:16', '4:3', '3:2' (default: '16:9')

**Other Parameters:**
- `excerpt` (str): Post excerpt/summary
- `tags` (list): List of tags (default: ['Blog'])
- `status` (str): 'published' or 'draft' (default: 'published')
- `visibility` (str): 'public', 'members', 'paid', or 'tiers' (default: 'public')
- `target_language` (str): Target language for content translation
- `auto_format` (bool): Auto-format plain text with AI (default: True)
- `is_test` (bool): Test mode without posting (default: False)

## 🎨 Image Generation Comparison

| Feature | Replicate Flux-dev | Google Imagen-4 |
|---------|-------------------|-----------------| 
| **Speed** | ⚡ Ultra-fast (3-7s) | 🐢 Moderate (10-15s) |
| **Quality** | 🔥 Photorealistic | 🏔️ Professional |
| **Format** | 📁 WebP (smaller) | 📁 PNG (lossless) |
| **Cost** | 💰 Pay-per-use | 💰 API quota based |
| **Best For** | Realistic scenes, portraits | Abstract concepts, artistic |

**Supported Aspect Ratios:**
- `16:9` - Widescreen (1920x1080) - **Default**, ideal for most blogs
- `1:1` - Square (1024x1024) - Great for social media
- `9:16` - Portrait (1080x1920) - Mobile-optimized vertical
- `4:3` - Traditional (1024x768) - Classic photo ratio
- `3:2` - DSLR (1536x1024) - Professional photography ratio

## 🛠️ Advanced Examples

### Language Translation
```python
# Translate Chinese to English
result = create_ghost_blog_post(
    title="科技未来", 
    content="人工智能正在改变世界。医疗诊断更准确。",
    target_language="English",  # Auto-translates content
    status="published"
)
```

### YouTube Video Post
```python
result = create_ghost_blog_post(
    title="Amazing AI Tutorial",
    content="Check out this incredible tutorial...",
    youtube_video_id="dQw4w9WgXcQ",  # Becomes the post slug
    use_generated_feature_image=True,
    tags=["Video", "Tutorial"],
    status="draft"
)
```

### Blog Management
```python
from ghost_blog_smart import (
    get_ghost_posts,
    update_ghost_post,
    update_ghost_post_image,
    delete_ghost_post
)

# Get posts
posts = get_ghost_posts(limit=5, status='published')

# Update post
result = update_ghost_post(
    post_id="your_post_id",
    featured=True,
    tags=["Updated", "Featured"]
)

# Update feature image
result = update_ghost_post_image(
    post_id="your_post_id",
    use_generated_feature_image=True,
    prefer_flux=True
)

# Delete post
result = delete_ghost_post(post_id="your_post_id")
```

## 📁 Project Structure

```
ghost-blog-smart/
├── ghost_blog_smart/             # Main package directory
│   ├── __init__.py              # Package initialization and exports
│   ├── main_functions.py        # Core API functions
│   ├── post_management.py       # Advanced post management
│   ├── smart_gateway.py         # AI-powered intelligent routing
│   ├── clean_imagen_generator.py # Hybrid image generation
│   ├── replicate_flux_generator.py # Replicate Flux integration
│   └── client.py               # Class-based interface
├── example_usage.py             # Complete usage examples
├── requirements.txt             # Python dependencies
├── setup.py                    # Package setup and configuration
└── README.md                   # This documentation
```

## 🧪 Testing

Set `is_test=True` to test without actually posting:

```python
result = create_ghost_blog_post(
    title="Test Post",
    content="Test content",
    is_test=True  # Won't actually post
)
```

## 📊 Token Optimization

The API optimizes token usage by:
- Using only title, excerpt, and first paragraph for image generation
- Caching generated images locally
- Batch processing when possible
- Intelligent content analysis to minimize AI calls

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

- Ghost CMS for the excellent blogging platform
- Google Gemini & Imagen for AI capabilities  
- Replicate for ultra-fast Flux generation
- The open-source community

## 📞 Support

For issues or questions, please open an issue on GitHub.

---

Made with ❤️ for the Ghost CMS community