/**
 * @author Kariedar
 */
$.paramquery.pqGrid.regional['it'] = {
    strLoading: "Caricamento",
    strAdd: "Aggiungi",
    strEdit: "Modifica",
    strDelete: "Cancella",
    strSearch: "Cerca",
    strNothingFound: "Nessun risultato trovato",
    strSelectedmatches: "Selezionato {0} di {1} risultato(i)",
    strPrevResult: "Risultato precedente",
    strNextResult: "Risultato successivo",
    strNoRows: "Nessun file da visualizzare."        
};
$.paramquery.pqPager.regional['it'] = {
    strPage: "Pagina {0} di {1}",
    strFirstPage: "Prima Pagina",
    strPrevPage: "Pagina precedente",
    strNextPage: "Pagina successiva",
    strLastPage: "Ultima pagina",
    strRefresh: "Aggiorna",
    strRpp: "Risultati per pagina: {0}",
    strDisplay: "Visualizzazione {0} a {1} di {2} risultati."
};
