from oakvar.gui.consts import *
