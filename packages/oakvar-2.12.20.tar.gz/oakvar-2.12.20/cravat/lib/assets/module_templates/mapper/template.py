from oakvar.lib.assets.module_templates.mapper.template import *
