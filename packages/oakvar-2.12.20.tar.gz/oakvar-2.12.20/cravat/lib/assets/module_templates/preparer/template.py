from oakvar.lib.assets.module_templates.preparer.template import *
