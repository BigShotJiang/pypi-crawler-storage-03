import numbers

from kirin.ir.attrs.types import PyClass

NumberType = PyClass(numbers.Number)
