# Example QASM2 programs

This directory contains a number of example QASM2 programs. The programs are
adopted from unit tests of [qiskit-qasm2 (deprecated)](https://github.com/jakelishman/qiskit-qasm2/) except:

- para.qasm
- main.qasm
