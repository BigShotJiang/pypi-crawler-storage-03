from .benchmark_commands import parse_benchmark_command

def run_benchmarks():
    parse_benchmark_command()