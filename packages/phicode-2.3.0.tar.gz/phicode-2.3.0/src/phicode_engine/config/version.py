from .config import PHICODE_VERSION

__version__ = PHICODE_VERSION