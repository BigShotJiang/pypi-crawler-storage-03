__version__ = "0.0.42"
# Either use a branch name or a tag name for EquivalentCircuits.jl
__equivalent_circuits_jl_version__ = "master"  # "0.3.1"
