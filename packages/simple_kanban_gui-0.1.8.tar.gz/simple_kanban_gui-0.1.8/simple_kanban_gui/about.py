# about.py

__version__ = "0.1.8"
__package__ = "simple_kanban_gui"
__program_name__ = "simple-kanban-gui"
__manager_name__ = "simple-kanban-manager"
__author__ = "Fernando Pujaico Rivera" 
__email__  = "fernando.pujaico.rivera@gmail.com"
__description__ = "A simple kanban graphic user interface"
__url_source__  = "https://github.com/trucomanx/SimpleKanbanGUI"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_doc__  = "https://github.com/trucomanx/SimpleKanbanGUI/tree/main/doc"
__url_bugs__    = "https://github.com/trucomanx/SimpleKanbanGUI/issues"
