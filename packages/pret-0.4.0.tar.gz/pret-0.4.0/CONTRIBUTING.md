# Contributing

## Installation

To install in development mode, ensure that you have installed :

- jupyterlab
- python
- nodejs
