declare module '*.py';
declare module '@pret-globals';