Add amount information to Delivery Slip report. You can select at
partner level if picking list report must be valued or not. If the
picking is done it's valued with quantity done, otherwise the picking is
valued with reserved quantity.
