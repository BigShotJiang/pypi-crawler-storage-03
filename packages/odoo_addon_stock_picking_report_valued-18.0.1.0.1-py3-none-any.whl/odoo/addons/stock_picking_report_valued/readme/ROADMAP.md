- If the picking is not reserved, values aren't computed.

Changelog
=========

This module includes the features from the module *stock_picking_report_valued_delivery*: https://github.com/OCA/stock-logistics-reporting/pull/285
