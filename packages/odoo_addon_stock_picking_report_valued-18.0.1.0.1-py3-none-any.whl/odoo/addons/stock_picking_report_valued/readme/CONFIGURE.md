1.  Go to *Sales \> Orders \> Customers \> (select one of your choice) \> Sales &
    Purchases*.
2.  Set *Valued picking* field on.
