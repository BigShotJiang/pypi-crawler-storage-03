To get the stock picking valued report:

1.  Create a Sales Order with storable products a *Valued picking* able
    customer.
2.  Confirm the Sale Order.
3.  Click on *Delivery* stat button.
4.  Go to *Print \> Delivery Slip*.
