# bfabric-scripts

## Useful commands

### List not available analysis workunits

```bash
bfabric-cli workunit not-available
```
