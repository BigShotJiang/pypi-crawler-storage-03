"""Composer Kit MCP Server - A Model Context Protocol server for Composer Kit UI."""

__version__ = "0.1.0"
__author__ = "viral-sangani"
__email__ = "viral.sangani2011@gmail.com"

from .server import main

__all__ = [
    "main",
]
