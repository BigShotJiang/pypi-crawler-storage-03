from .setting_otlp import setting_otlp

__all__ = ("setting_otlp",)
