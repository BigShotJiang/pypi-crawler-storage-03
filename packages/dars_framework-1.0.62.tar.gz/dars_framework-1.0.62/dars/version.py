__version__ = "1.0.62"
__release_url__ = "https://github.com/ZtaMDev/Dars-Framework/releases/tag/1.0.6"
