# Data Processor API Reference

The `EliaDataProcessor` class provides high-level data processing capabilities for working with Elia OpenData datasets.

::: elia_opendata.data_processor.EliaDataProcessor
