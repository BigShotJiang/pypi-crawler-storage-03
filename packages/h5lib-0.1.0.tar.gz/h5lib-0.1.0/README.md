# h5lib
An object-oriented and statically-typed reader for HDF5 files in python.
