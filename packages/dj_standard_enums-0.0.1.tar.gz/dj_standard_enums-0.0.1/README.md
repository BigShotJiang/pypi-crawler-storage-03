# django_enums
A standard way to use enums in Django and expose them via API so that they can be used in the Front End thereby reducing the code duplication.
