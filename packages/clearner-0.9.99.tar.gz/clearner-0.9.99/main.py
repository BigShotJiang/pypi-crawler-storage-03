#! /usr/bin/env python

# Copyright (C) Prizmi, LLC - All Rights Reserved
# Unauthorized copying or use of this file is strictly prohibited and subject to prosecution under applicable laws
# Proprietary and confidential

from learner.setup.main import main

if __name__ == '__main__':
    main()
