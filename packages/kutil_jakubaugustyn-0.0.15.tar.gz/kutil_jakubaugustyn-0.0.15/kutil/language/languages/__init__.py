#  -*- coding: utf-8 -*-
__author__ = "kubik.augustyn@post.cz"

from kutil.language.languages.BrainFuck import BrainFuck
from kutil.language.languages.paint_tryhard.PaintTryhard import PaintTryhard
from kutil.language.languages.javascript.Javascript import Javascript
