#  -*- coding: utf-8 -*-
__author__ = "kubik.augustyn@post.cz"

from kutil.webscraper.WebScraperServer import WebScraperServer
from kutil.webscraper.MapyCZServer import MapyCZServer
