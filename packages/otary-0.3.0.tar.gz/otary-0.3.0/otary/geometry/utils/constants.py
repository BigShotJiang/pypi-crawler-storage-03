"""
Geometric Constants
"""

import math

DEFAULT_MARGIN_ANGLE_ERROR = math.pi / 50
