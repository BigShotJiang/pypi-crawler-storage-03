

## Telethon-Utils

Some useful functions to speed up the development of bots using telethon.