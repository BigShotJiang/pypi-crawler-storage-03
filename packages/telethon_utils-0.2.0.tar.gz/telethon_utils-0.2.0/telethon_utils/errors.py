class JoinFailed(Exception):
    pass
