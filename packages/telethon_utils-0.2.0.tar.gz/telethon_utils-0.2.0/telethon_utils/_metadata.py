CONTACT_INFO = "Telegram: @rehmanali1337 / @bots1337_official"
NAME = "telethon_utils"

MAJOR = "0"
MINOR = "1"
PATCH = "3"

VERSION = f"{MAJOR}.{MINOR}.{PATCH}"
