# mck

[![PyPI - Version](https://img.shields.io/pypi/v/mck.svg)](https://pypi.org/project/mck)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mck.svg)](https://pypi.org/project/mck)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install mck
```

## License

`mck` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
