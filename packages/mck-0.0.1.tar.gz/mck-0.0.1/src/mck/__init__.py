# SPDX-FileCopyrightText: 2025-present Maaruuuf <abc.maruf12@gmail.com>
#
# SPDX-License-Identifier: MIT
from .add_numbers import add_num

__all__ = ["add_num"]