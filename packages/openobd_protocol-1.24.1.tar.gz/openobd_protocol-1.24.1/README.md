openOBD Protocol by Jifeline Networks for Python 3

# Release notes:
- **1.18.x : 2025-01**
  *Feature*: Session transfer
    - Passing the openOBD session to another function executor 
- **1.17.x : 2024-12**  
  *Feature*: ISO14230 K-line support with Slow/Fast initialization
    - Supported bitrates are 9600, 10k4 and 15k6
    - Supported protocol is KWP2000
- **1.16.x : 2024-09**  
  First production release
- **1.11.x** :  
  Beta release  
  - Lock grpcio dependencies to 1.60.1


---------------------------------------------------------------


