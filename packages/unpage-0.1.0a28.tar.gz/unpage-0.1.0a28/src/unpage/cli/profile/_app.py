from cyclopts import App

profile_app = App(help="Manage profiles for configuration and graph storage")
