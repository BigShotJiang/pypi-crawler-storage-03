from unpage.plugins.aptible.nodes.base import AptibleNode


class AptibleDeployment(AptibleNode):
    pass
