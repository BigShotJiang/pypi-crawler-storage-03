from maleo.soma.mixins.timestamp import Duration


class GenerateRecommendationMetadataSchema(Duration):
    pass
