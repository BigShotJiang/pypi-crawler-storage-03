class ClientControllerType:
    HTTP = "http"
