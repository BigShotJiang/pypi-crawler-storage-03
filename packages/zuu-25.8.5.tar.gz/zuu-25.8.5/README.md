# zuu

A lightweight Python utilities package providing essential tools for everyday development tasks.

## Install
```
pip install zuu
```

for testpypi
```
pip install --index-url https://test.pypi.org/simple/ zuu
```