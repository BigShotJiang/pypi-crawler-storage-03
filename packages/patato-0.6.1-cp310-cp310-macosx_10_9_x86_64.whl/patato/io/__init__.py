#  Copyright (c) Thomas Else 2023-25.
#  License: MIT

"""
Input/output module
==========================

I/O module for patato. Provides interfaces to HDF5 format, simpa and iThera.
"""
