#  Copyright (c) Thomas Else 2023-25.
#  License: MIT

"""
PATATO command line interfaces
==============================

A series of convenience scripts for running the patato package in the command line.
"""
