#  Copyright (c) Thomas Else 2023-25.
#  License: MIT
