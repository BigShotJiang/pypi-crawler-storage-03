from enum import Enum


class Sentinel(Enum):
    """Just a sentinel."""
