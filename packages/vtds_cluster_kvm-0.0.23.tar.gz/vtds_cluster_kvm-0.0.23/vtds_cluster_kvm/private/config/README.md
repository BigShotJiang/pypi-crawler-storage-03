# KVM Cluster Layer Base Configuration

Base configuration supplied by the KVM Cluster Layer implementation

