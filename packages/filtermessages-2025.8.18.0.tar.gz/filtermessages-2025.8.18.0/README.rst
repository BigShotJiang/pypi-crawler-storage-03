filtermessages
==============

Here be dragons.
