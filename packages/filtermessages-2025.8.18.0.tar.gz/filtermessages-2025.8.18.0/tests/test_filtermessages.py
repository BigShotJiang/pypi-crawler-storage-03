#!/usr/bin/env --split-string=python -m pytest --verbose

import pytest

import filtermessages
