from abc import ABC

class FExecutionContext(ABC):
    pass