DEFAULT_JUDGE_INFERENCE_PARAMS = {
    "seed": 42,
    "temperature": 0,
}
