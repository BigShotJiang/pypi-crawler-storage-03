dividing_factors_dict = {
    'second': 1.0,
    'minute': 60.0,
    'hour': 60.0*60.0,
    'day': 60.0*60.0*24.0,
    'year': 60.0*60.0*24.0*365.0
}