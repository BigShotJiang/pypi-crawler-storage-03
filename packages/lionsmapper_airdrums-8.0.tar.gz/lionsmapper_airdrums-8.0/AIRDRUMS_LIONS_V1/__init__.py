#python
#airdrum_songwriter.py
from lionsmapper import *
from playsound import playsound
import threading
import time

_type='FALSE' 
_source=0
_frame_rate = 12
drums_set = {"hihats":{"x":0,"y":0},"crash_cymbal":{"x":0,"y":0},"ride_cymbal":{"x":0,"y":0},"snare_drum":{"x":0,"y":0},"high_tom":{"x":0,"y":0},"mid_tom":{"x":0,"y":0},"floor_tom":{"x":0,"y":0},"bass_drum":{"x":0,"y":0}}
drums_set_wav = {"hihats":"hihats.wav","crash_cymbal":"crash_cymbal.wav","ride_cymbal":"ride_cymbal.wav","snare_drum":"snare_drum.wav","high_tom":"high_tom.wav","mid_tom":"mid_tom.wav","floor_tom":"floor_tom.wav","bass_drum":"bass_drum.wav"}

def set_webcam(webcam_src=0, _rate=12):
	_source=0
	_frame_rate = _rate

def set_type(src_type):
	_type == src_type
	
def set_dataglove(side='LEFT',rgb='255,255,255'):
	g_l = rgb

def set_dataglove(side='RIGHT',rgb='0,0,0'):
	g_r = rgb
	
def set_foot_glove(side='LEFT',rgb='110,110,110'):
	f_l = rgb
	
def set_foot_glove(side='RIGHT',rgb='80,80,80'):
	f_r = rgb

def set_drums_axis(_hihats,_crash_cymbal,_ride_cymbal,_snare_drum,_high_tom,_mid_tom,_floor_tom,_bass_drum):
	_drums_set = {"hihats":_hihats,"crash_cymbal":_crash_cymbal,"ride_cymbal":_ride_cymbal,"snare_drum":_snare_drum,"high_tom":_high_tom,"mid_tom":_mid_tom,"floor_tom":_floor_tom,"bass_drum":_bass_drum}

def set_drums_wav(wav_hihats = 'wav_hihats.wav',wav_crash_cymbal = 'wav_crash_cymbal.wav',wav_ride_cymbal = 'wav_ride_cymbal.wav',wav_snare_drum = 'wav_snare_drum.wav',wav_high_tom = 'wav_high_tom.wav',wav_mid_tom = 'wav_mid_tom.wav',wav_floor_tom = 'wav_floor_tom.wav',wav_bass_drum = 'wav_bass_drum.wav'):
	drums_set_wav = {"hihats":wav_hihats,"crash_cymbal":wav_crash_cymbal,"ride_cymbal":wav_ride_cymbal,"snare_drum":wav_snare_drum,"high_tom":wav_high_tom,"mid_tom":wav_mid_tom,"floor_tom":wav_floor_tom,"bass_drum":wav_bass_drum}

def play_drums(index,lenght_time):
	start_webcam(video_source=0, max_frame_rate = 12)
	for _t_x in _t:
		_t_x.start()

def get_play(step_time=2):
	_f_mv = get_frame_png(_f_mv)
	get_play_box(_data_glove_left_axis)
	get_move(_f_mv, g_l,_update=0)
	_data_glove_left_axis = get_axis()
	get_play_box(_data_glove_right_axis)
	get_move(_f_mv, g_r,_update=0)
	_data_glove_right_axis = get_axis()
	get_move(_f_mv, g_r)
	_data_glove_right_axis = get_axis()
	get_play_box(_data_glove_right_axis)
	get_move(_f_mv, f_l)
	_data_foot_left_axis = get_axis()
	get_play_box(_data_foot_left_axis)
	get_move(_f_mv, f_r)
	_data_foot_right_axis = get_axis()
	get_play_box(_data_foot_right_axis)
	get_move(_f_mv, f_r)
	if(step_time == -1):
		for _t_x_0 in _t:
			_t_x_0.join()
	time.sleep(step_time)
	return get_play(step_time)

def get_play_box(_data_axis,type):
	for _dr_set in _drums_set:
		if(_data_axys == dr_set["_x"] and _data_axys == dr_set["_y"]):
			_x = list(_drums_set.values()).index(_data_axys)
			_c = _list(drums_set_wav.values())[_x]
			playsound(_c)
			return 'TRUE'
	return 'FALSE'

_t_l = []
_t = threading.Thread(target=get_play,kwargs={"step_time":10})
_t_l.append(_t)