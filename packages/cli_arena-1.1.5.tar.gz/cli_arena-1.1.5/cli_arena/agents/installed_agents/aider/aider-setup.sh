#!/bin/bash

apt-get update
apt-get install -y curl

curl -LsSf https://aider.chat/install.sh | sh
source $HOME/.local/bin/env
