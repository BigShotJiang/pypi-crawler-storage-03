from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict

from a2a.server.events import Event
from .logger import handle_error as _emit_error, log as _emit_log
from ..core.database import record_event, save_task_result


def _event_to_dict(event: Event) -> Dict[str, Any]:
	try:
		if hasattr(event, "__dict__"):
			return {k: v for k, v in event.__dict__.items() if not k.startswith("_")}
		return {"event": str(event)}
	except Exception as e:
		_emit_error("event dict 변환 실패", e, raise_error=False)
		return {"event": str(event)}


async def route_event(todo: Dict[str, Any], event: Event) -> None:
	"""이벤트(dict)와 출력(output)을 구분해 처리.

	- "event": CrewAI 등에서 발생한 실행 이벤트 → events 테이블 저장
	- "output": 실행 결과 → save_task_result를 통해 중간/최종 여부에 따라 저장
	"""
	try:
		data = _event_to_dict(event)

		# output 이벤트 처리
		if data.get("type") == "output" or data.get("event_type") == "output":
			payload = data.get("data") or data.get("payload") or {}
			is_final = bool(payload.get("final") or payload.get("is_final"))
			content = payload.get("content") if isinstance(payload, dict) else payload
			await save_task_result(str(todo.get("id")), content, final=is_final)
			return

		# 일반 event 처리 (원형 + 타임스탬프)
		normalized = {
			"id": str(uuid.uuid4()),
			"timestamp": datetime.now(timezone.utc).isoformat(),
			**data,
		}
		await record_event(todo, normalized, event_type=str(data.get("type") or data.get("event_type") or "event"))
	except Exception as e:
		_emit_error("route_event 처리 실패", e, raise_error=False)
