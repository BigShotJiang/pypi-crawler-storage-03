pytest-asdf-plugin
==================

pytest plugin for testing ASDF schemas.

License
-------

ASDF is licensed under a BSD 3-clause style license. See `LICENSE.rst <LICENSE.rst>`_
for the `licenses folder <licenses>`_ for
licenses for any included software.

Contributing
------------

We welcome feedback and contributions to the project. Contributions of
code, documentation, or general feedback are all appreciated. Please
follow the `contributing guidelines <CONTRIBUTING.rst>`__ to submit an
issue or a pull request.

We strive to provide a welcoming community to all of our users by
abiding to the `Code of Conduct <CODE_OF_CONDUCT.md>`__.
