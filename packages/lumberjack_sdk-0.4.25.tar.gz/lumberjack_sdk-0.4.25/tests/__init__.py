"""
Test suite for the lumberjack library.
"""
