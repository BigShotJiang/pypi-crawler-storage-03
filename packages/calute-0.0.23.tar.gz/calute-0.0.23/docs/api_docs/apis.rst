Calute APIs 🔮
====

.. toctree::
   :maxdepth: 2

   basics
   calute
   client
   cortex
   executors
   memory
   multimodal
   types
   utils
   