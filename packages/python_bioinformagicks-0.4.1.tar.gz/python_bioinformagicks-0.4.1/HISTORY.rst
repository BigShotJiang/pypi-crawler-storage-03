=======
History
=======

v0.4.1 (2025-08-20)
-------------------

* Fixed bim.tl.do_profiler_analysis to deal with highlight-ordered query override.

v0.4.0 (2025-06-26)
--------------------

* Added bim.pl.plot_gprofiler_analysis.
* Refactored bim.tl.do_gprofiler_analysis to use requests instead of outdated gProfiler package.
* Changed bim.tl.call_scSNP to allow setting cb_tag as a parameter.

v0.3.0 (2024-12-08)
--------------------

* Added bim.util submodule
* Moved bim.tl.in_ignore_list to bim.util
* Added bim.pl.plot_grouped_proportions (stacked barplot)
* Added bim.util.get_proportions
* Added bim.util.make_combined_categorical_column


v0.2.0 (2024-12-18)
-------------------

* Added basic tests; first release to pypi.

v0.1.0 (2024-12-17)
-------------------

* First release on github.