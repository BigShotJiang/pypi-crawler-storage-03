Welcome to python bioinformagicks's documentation!
==================================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   readme
   installation
   usage
   modules
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
