=====
Usage
=====

To use python bioinformagicks in a project::

    import python_bioinformagicks as bim