python\_bioinformagicks package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   python_bioinformagicks.plotting
   python_bioinformagicks.tools
   python_bioinformagicks.utilities

Module contents
---------------

.. automodule:: python_bioinformagicks
   :members:
   :undoc-members:
   :show-inheritance:
