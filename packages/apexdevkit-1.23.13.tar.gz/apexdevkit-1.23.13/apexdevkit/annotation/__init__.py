from apexdevkit.annotation.deprecate import deprecated

__all__ = ["deprecated"]
