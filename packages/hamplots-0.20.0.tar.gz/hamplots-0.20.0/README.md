### Hamplots

Realtime plots for ham radio band conditions.  
Displays SNR, reports, and other statistics from your data sources.  

Installation:

```
pip install hamplots
```

currently building for running example plots in this repo
