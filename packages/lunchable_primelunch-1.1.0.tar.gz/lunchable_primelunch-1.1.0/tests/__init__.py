"""
Test suite for the lunchable-primelunch package
"""
