"""
lunchable-primelunch info file
"""

from importlib.metadata import version

__application__ = "lunchable-primelunch"
__version__ = version(__application__)
