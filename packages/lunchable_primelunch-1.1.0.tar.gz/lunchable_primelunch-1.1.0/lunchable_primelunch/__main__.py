"""
lunchable_primelunch.__main__
"""

from lunchable_primelunch.cli import primelunch

if __name__ == "__main__":
    primelunch()
