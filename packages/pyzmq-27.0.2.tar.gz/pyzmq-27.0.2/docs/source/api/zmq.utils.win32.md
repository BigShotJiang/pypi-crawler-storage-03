# utils.win32

## Module: {mod}`zmq.utils.win32`

```{eval-rst}
.. automodule:: zmq.utils.win32
```

```{currentmodule} zmq.utils.win32
```

## {class}`allow_interrupt`

```{eval-rst}
.. autoclass:: allow_interrupt
```
