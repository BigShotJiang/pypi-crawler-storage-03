# auth.asyncio

## Module: {mod}`zmq.auth.asyncio`

```{eval-rst}
.. automodule:: zmq.auth.asyncio
```

```{currentmodule} zmq.auth.asyncio
```

## Classes

### {class}`AsyncioAuthenticator`

```{eval-rst}
.. autoclass:: AsyncioAuthenticator
  :members:
  :undoc-members:
  :inherited-members:
```
