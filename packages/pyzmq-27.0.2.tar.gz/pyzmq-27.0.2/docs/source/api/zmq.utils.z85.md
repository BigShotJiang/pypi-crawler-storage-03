% AUTO-GENERATED FILE -- DO NOT EDIT!

# utils.z85

## Module: {mod}`zmq.utils.z85`

```{eval-rst}
.. automodule:: zmq.utils.z85
```

```{currentmodule} zmq.utils.z85
```

## Functions

```{eval-rst}
.. autofunction:: zmq.utils.z85.decode

```

```{eval-rst}
.. autofunction:: zmq.utils.z85.encode
```
