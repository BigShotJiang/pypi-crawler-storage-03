from mignonFramework import start



start()