#!/usr/bin/env python

dependencies = {
    't0': {
        'packages': ['T0+', 
                     'T0Component+'],
        'modules': [],
        'systems': [],
        'statics': ['bin+',
                    'etc+']
    }
}
