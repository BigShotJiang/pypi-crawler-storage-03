"""
_T0_

Core libraries for Workload Management Packages

"""
__version__ = '3.5.2'
__all__ = []
