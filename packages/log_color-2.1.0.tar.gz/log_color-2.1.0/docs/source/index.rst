.. logcolor documentation master file, created by
   sphinx-quickstart on Tue Jan 27 12:04:31 2015.

Welcome to Log Color's documentation!
=====================================
The ``log_color`` module provides Python logging formatters with a basic markup syntax for nicely colored log outputs.

Contents:

.. toctree::
   :maxdepth: 2

   topics/introduction
   topics/usage
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
