import asyncio
import logging
import typing as t

P = t.ParamSpec('P')
TargetFunction = t.Callable[..., t.Awaitable]
CallbackFunction = t.Callable[..., t.Any] | t.Awaitable[t.Any]
Intervals = t.Tuple[int | float, ...]

log = logging.getLogger('retry_decorator')


def retry(
        tries: int,
        allowed_exceptions: t.Tuple[t.Type[Exception], ...] = (),
        intervals: Intervals = (1,),
        fail_cb: CallbackFunction | None = None,
        logger: logging.Logger = log,
) -> t.Callable[[TargetFunction], TargetFunction]:
    def wrapper(fn: TargetFunction) -> TargetFunction | CallbackFunction:
        async def wrapped(*args: P.args, **kwargs: P.kwargs) -> t.Any:
            for try_idx in range(tries):
                if try_idx > 0:
                    logger.info(f'Try to run {fn.__name__} for the {try_idx} retry.')

                try:
                    result = await fn(*args, **kwargs)
                    if try_idx > 0:
                        logger.debug(f'Got result from the {try_idx} retry.')
                    return result
                except allowed_exceptions:
                    pass

                try:
                    interval = intervals[try_idx]
                except IndexError:
                    interval = intervals[-1]

                if try_idx > 0:
                    logger.debug(f'Sleep {interval} seconds before retry.')
                await asyncio.sleep(interval)

            if fail_cb:
                logger.info(
                    f'Failed to get result for the callable {fn.__name__}. '
                    f'Call a callback {fail_cb.__name__} and return.'
                )
                if asyncio.iscoroutinefunction(fail_cb):
                    return await fail_cb(*args, **kwargs)
                return fail_cb(*args, **kwargs)
            else:
                logger.info('All retry attempts failed. Stop trying.')

        return wrapped

    return wrapper
