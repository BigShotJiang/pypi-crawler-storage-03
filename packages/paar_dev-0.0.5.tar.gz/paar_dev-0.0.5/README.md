# paar_dev

Biblioteca Python de exemplo chamada **paar_dev**.

## Instalação
```bash
pip install paar-dev
