from .main import apiTab
from abstract_gui import startConsole
def startApiConsole():
    startConsole(apiTab)
