#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
from importlib.metadata import version

__version__ = version("sports2d")
VERSION = __version__