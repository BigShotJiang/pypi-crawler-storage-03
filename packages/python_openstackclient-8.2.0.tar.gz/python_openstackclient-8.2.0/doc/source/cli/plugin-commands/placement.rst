placement
---------

.. autoprogram-cliff:: openstack.placement.v1
