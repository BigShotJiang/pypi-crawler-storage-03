ironic
------

.. autoprogram-cliff:: openstack.baremetal.v1
