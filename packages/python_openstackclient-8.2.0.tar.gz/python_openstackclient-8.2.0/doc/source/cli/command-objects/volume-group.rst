============
volume group
============

Block Storage v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume group create

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume group delete

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume group list

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume group failover

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume group set

.. autoprogram-cliff:: openstack.volume.v3
   :command: volume group show
