========
versions
========

Get a list of every version of every service in a given cloud.

.. autoprogram-cliff:: openstack.common
   :command: versions show
