==========================
consistency group snapshot
==========================

Block Storage v2, v3

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group snapshot create

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group snapshot delete

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group snapshot list

.. autoprogram-cliff:: openstack.volume.v3
   :command: consistency group snapshot show
