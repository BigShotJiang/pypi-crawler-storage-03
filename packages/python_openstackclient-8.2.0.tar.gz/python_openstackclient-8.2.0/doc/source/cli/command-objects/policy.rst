======
policy
======

A **policy** is an arbitrarily serialized policy engine rule set to be consumed
by a remote service. Applies to Identity v3.

.. autoprogram-cliff:: openstack.identity.v3
   :command: policy *
