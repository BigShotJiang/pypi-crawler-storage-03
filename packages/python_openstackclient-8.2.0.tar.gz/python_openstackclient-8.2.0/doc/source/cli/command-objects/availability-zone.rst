=================
availability zone
=================

An **availability zone** is a logical partition of cloud block storage,
compute and network services.

Block Storage v2, Compute v2, Network v2

.. autoprogram-cliff:: openstack.common
   :command: availability zone list
