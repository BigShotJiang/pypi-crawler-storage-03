======
router
======

A **router** is a logical component that forwards data packets between
networks. It also provides Layer 3 and NAT forwarding to provide external
network access for servers on project networks.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: router *
