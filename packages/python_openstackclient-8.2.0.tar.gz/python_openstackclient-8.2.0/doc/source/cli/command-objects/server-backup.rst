=============
server backup
=============

A server backup is a disk image created in the Image store from a running server
instance. The backup command manages the number of archival copies to retain.

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: server backup create
