===========
console log
===========

Server console text dump

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: console log *
