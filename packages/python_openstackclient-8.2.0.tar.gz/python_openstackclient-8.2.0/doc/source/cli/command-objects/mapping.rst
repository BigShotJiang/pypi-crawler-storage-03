=======
mapping
=======

A **mapping** is used by the Identity service's OS-FEDERATION
extension. It is used by **federation protocols** and **identity providers**.
Applicable to Identity v3.

.. autoprogram-cliff:: openstack.identity.v3
   :command: mapping *