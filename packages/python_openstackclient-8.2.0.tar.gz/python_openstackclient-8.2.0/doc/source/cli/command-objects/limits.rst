======
limits
======

The Compute and Block Storage APIs have resource usage limits.

Block Storage v2, v3; Compute v2


.. autoprogram-cliff:: openstack.common
   :command: limits *
