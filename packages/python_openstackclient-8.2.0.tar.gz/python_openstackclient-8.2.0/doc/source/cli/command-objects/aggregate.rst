=========
aggregate
=========

Host aggregates provide a mechanism to group hosts according to certain
criteria.

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: aggregate *
