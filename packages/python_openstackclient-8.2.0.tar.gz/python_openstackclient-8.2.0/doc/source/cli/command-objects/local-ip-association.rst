=============================================
Local IP Associations (local_ip_associations)
=============================================

The resource lets users assign Local IPs to user Ports.
This is a sub-resource of the Local IP resource.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: local ip association *
