====
host
====

Compute v2

The physical computer running a hypervisor.

.. autoprogram-cliff:: openstack.compute.v2
   :command: host *
