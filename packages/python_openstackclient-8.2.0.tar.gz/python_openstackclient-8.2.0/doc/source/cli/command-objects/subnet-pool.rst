===========
subnet pool
===========

A **subnet pool** contains a collection of prefixes in CIDR notation
that are available for IP address allocation.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: subnet pool *
