=====
image
=====

Image v2

.. autoprogram-cliff:: openstack.image.v2
   :command: image create

.. autoprogram-cliff:: openstack.image.v2
   :command: image delete

.. autoprogram-cliff:: openstack.image.v2
   :command: image list

.. autoprogram-cliff:: openstack.image.v2
   :command: image save

.. autoprogram-cliff:: openstack.image.v2
   :command: image set

.. autoprogram-cliff:: openstack.image.v2
   :command: image unset

.. autoprogram-cliff:: openstack.image.v2
   :command: image show

.. autoprogram-cliff:: openstack.image.v2
   :command: image stage

.. autoprogram-cliff:: openstack.image.v2
   :command: image import
