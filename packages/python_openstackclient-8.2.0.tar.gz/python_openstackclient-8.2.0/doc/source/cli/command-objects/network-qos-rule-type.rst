=====================
network qos rule type
=====================

A **Network QoS rule type** is a specific Network QoS rule type available to be
used.

Network v2

.. autoprogram-cliff:: openstack.network.v2
   :command: network qos rule type *
