"""
LLM Client implementations for different providers
"""