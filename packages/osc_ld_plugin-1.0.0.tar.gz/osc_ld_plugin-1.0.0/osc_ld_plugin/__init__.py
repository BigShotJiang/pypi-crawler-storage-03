from .plugin import LogDetective
