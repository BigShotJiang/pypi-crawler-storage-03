from enum import Enum


class Category(Enum):
    MODEL = "model"
    VIEW = "view"
    API = "api"
