[**Opciones avanzadas**](./introduction.md) > **Documentación de servicios de traducción** _(actual)_

---

### Visualización de servicios de traducción disponibles mediante la Línea de comandos

Puedes confirmar los servicios de traducción disponibles y su uso imprimiendo el mensaje de ayuda en la línea de comandos.

```bash
pdf2zh_next -h
```

Al final del mensaje de ayuda, puedes ver información detallada sobre los diferentes servicios de traducción.

<div align="right"> 
<h6><small>Parte del contenido de esta página ha sido traducido por GPT y puede contener errores.</small></h6>