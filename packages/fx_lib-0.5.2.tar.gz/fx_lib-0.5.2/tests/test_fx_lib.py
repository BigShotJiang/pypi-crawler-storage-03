#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `fx_lib` package."""


import unittest

from fx_lib import fx_lib


class TestFx_lib(unittest.TestCase):
    """Tests for `fx_lib` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
