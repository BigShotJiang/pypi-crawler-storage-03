=====
Usage
=====

To use fx-lib in a project::

    import fx_lib
