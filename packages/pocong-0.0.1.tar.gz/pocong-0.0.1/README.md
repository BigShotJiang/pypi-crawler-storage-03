<p align="center">
  <img src="https://i.ibb.co.com/35P4Nq9x/Screenshot-2025-08-22-at-18-40-11.png?width=128" alt="POCONG Logo" width="128"/>
</p>

# POCONG 🪦
**Python Oriented Crawling ON Going**

POCONG is a lightweight web crawling framework built in Python.

## Installation
```bash
pip install pocong
