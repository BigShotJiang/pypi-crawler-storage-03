__version__ = "0.0.10"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
