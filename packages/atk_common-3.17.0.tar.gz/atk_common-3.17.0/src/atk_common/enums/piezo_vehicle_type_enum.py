from enum import Enum
 
class PiezoVehicleType(Enum):
    FRONT = 1
    VEHICLE = 2
