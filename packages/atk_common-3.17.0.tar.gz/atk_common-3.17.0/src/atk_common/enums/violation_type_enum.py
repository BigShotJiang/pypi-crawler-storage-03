from enum import Enum
 
class ViolationType(Enum):
    POINT = 1
    SECTION = 2
