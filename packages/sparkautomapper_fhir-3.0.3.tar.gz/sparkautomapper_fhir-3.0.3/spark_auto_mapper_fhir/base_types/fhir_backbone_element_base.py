from spark_auto_mapper.data_types.complex.complex_base import (
    AutoMapperDataTypeComplexBase,
)


class FhirBackboneElementBase(AutoMapperDataTypeComplexBase):
    pass
