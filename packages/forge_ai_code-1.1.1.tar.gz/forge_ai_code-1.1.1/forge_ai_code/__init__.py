"""Forge AI Code - 智能AI编程助手"""
__version__ = "1.1.1"
from .main import main
__all__ = ["main"]
