# https://peps.python.org/pep-3101/
# https://stackoverflow.com/questions/19864302/add-custom-conversion-types-for-string-formatting

from .formatter.formatter import Formatter
