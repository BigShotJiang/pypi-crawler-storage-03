==========================================
Stein Series (1.7.0 - 1.8.x) Release Notes
==========================================

.. release-notes::
   :branch: stable/stein
