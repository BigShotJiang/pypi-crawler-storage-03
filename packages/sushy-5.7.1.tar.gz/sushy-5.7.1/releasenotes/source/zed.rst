========================================
Zed Series (4.2.0 - 4.3.x) Release Notes
========================================

.. release-notes::
   :branch: unmaintained/zed
