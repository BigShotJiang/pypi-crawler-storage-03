===========================================
Queens Series (1.2.0 - 1.3.x) Release Notes
===========================================

.. release-notes::
   :branch: stable/queens
