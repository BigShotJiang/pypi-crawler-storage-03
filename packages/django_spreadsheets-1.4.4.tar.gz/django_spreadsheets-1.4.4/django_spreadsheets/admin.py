# Django
from django.apps import AppConfig


class SpreadsheetAppConfig(AppConfig):
    name = "django_spreadsheets"
