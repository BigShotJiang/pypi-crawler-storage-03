======
unique
======

.. automodule:: advanced_alchemy.mixins.unique
    :members:
