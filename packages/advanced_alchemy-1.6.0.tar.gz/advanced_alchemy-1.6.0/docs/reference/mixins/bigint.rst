======
bigint
======

.. automodule:: advanced_alchemy.mixins.bigint
    :members:
