====
slug
====

.. automodule:: advanced_alchemy.mixins.slug
    :members:
