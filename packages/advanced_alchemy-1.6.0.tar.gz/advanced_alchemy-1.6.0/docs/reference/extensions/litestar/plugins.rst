======
plugin
======

.. automodule:: advanced_alchemy.extensions.litestar.plugins
    :members:
    :exclude-members:
    :no-index: EngineConfig, SQLAlchemyAsyncConfig, SQLAlchemySyncConfig
