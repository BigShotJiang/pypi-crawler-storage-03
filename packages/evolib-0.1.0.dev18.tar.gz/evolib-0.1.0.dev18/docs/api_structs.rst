Enums
===================

.. automodule:: evolib.interfaces.structs
   :members:
   :undoc-members:
   :show-inheritance:
