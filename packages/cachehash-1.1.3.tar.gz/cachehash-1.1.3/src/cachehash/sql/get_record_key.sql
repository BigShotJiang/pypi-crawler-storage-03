select * 
    from <table_name> 
    where key=:key
    order by rowid desc
    limit 1
