delete from <table_name>
where key=:key