update <table_name> set val = :value where key = :key and hash = :hash
