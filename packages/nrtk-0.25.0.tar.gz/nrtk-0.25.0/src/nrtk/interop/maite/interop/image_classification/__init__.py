"""Image Classification."""
