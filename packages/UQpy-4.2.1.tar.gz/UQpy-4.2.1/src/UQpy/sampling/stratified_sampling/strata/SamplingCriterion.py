from enum import Enum


class SamplingCriterion(Enum):
    RANDOM = 1
    CENTERED = 2
