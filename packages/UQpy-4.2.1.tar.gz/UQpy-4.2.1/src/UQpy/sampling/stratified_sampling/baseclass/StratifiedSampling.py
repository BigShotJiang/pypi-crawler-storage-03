from abc import ABC


class StratifiedSampling(ABC):
    pass
