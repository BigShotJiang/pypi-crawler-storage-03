SKLEARN_STRING = "<class 'sklearn.gaussian_process._gpr.GaussianProcessRegressor'>"
