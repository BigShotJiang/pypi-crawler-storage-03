import jua.weather._xarray_patches  # noqa: F401
