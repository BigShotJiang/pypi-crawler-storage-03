from agentle.vector_stores.filters.datetime_range import DatetimeRange
from agentle.vector_stores.filters.range import Range


RangeInterface = Range | DatetimeRange
