# Finally, define the complete Condition type for your type hints
from agentle.vector_stores.filters.field_condition import FieldCondition


type Condition = FieldCondition
