from typing import Literal


Distance = Literal["COSINE", "EUCLID", "DOT", "MANHATTAN"]
