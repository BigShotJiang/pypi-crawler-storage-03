# Changelog

## 1.0.0 - 2023-02-15

### Added

-   Initial release

### Changed

### Deprecated

### Removed

### Fixed

### Security
