"""Models package for the LangGraph OpenAI compatible API."""
