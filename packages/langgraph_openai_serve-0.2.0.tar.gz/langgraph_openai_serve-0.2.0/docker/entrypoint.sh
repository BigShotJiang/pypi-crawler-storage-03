#!/bin/sh

# Start the main application
exec "$@"
