# API Reference

This page provides detailed information about the LangGraph OpenAI Serve API endpoints and schemas.

::: langgraph_openai_serve
