---
tags:
  - Utilities
---


# Memory

<class>`class` versionhq.memory.model.<bold>Memory<bold></class>

A Pydantic class to store `Memory` of the agent.
