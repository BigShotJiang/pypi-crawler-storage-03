---
tags:
  - Utilities
---


# Knowledge

<class>`class` versionhq.knowledge.model.<bold>Knowledge<bold></class>

A Pydantic class to store `Knowledge` of the agent.
