white = "#fafafa"
black = "#191b1b"
darkgrey = "#363636"
grey = "#414141"
primary = "#B9005B"
orange = "#ffb713"
lightgreen = "#b8fff5"
green = "#00d1b2"
darkgreen = "#169d87"
darkergreen = "#026b5d"


# $black: #191b1b;
# $true-white: #ffffff;
# $white: #fafafa;
# $grey: #414141;
# $light-grey: #f9f9f9;
# $border-color: #dedede;
# $primary: #B9005B;
# $primary-hovered: #9D034F;
# $gradient-main: linear-gradient(to right $black $primary);
# $linkedin-blue: #0077B5;
# $bulma-primary: #00d1b2;
# $bluma-primary-dark: #169d87;
# $bulma-grey-light: hsl(0 0%, 71%);
# $bulma-grey: hsl(0, 0%, 48%);
# $bulma-dark: hsl(0, 0%, 21%); //#363636
# $bulma-white-ter: #F5F5F5;
