MY_AMAZING_PROMPT = """amazing prompt with {variable}"""
