To configure this module, you need to 'Inventory \> Configuration \>
Settings' and enable 'Sell and purchase products in different units of
measure' option.
