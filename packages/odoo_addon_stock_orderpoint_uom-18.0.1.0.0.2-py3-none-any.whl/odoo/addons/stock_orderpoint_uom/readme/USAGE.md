Go to 'Inventory \> Products \> Products' and indicate both the unit of
measure and the procurement unit of measure for the chosen product.
