"""TUI (Terminal User Interface) module for Codegen CLI."""
