if __name__ == "__main__":
  print("hello world it's waka wka e! whehehe")
