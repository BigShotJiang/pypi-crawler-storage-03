"""
Action Test Package

A GitHub Actions workflow automation test project.
"""

__version__ = "1.1.0"
__author__ = "jonathanw16"
__email__ = "jonathanw16@users.noreply.github.com"

def hello():
    """Simple hello world function for testing."""
    return "Hello from action-test package!"