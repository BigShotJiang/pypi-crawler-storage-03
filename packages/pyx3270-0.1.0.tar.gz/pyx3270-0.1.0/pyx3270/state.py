from multiprocessing import Process

command_process: Process = None
