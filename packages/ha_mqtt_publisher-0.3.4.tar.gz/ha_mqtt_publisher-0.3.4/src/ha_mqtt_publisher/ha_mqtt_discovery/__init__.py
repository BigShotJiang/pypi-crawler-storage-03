"""Home Assistant MQTT Discovery package."""

# Ensure this is the main module and does not conflict with the test module.
# ...existing code...
