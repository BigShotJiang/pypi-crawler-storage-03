# Compatibility shim: Loads the real config from pyproject.toml
from setuptools import setup

setup()
