from . import account_payment_method
from . import account_payment_method_line
from . import account_move
from . import res_partner
from . import res_partner_bank
from . import res_bank
