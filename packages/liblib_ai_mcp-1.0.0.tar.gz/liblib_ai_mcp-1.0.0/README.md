# LiblibAI AI图片生成MCP工具

一个基于LiblibAI API的AI图片生成工具，支持各种风格的图片创作，通过MCP协议与Claude Desktop等AI客户端集成。

## 🎨 主要功能

- **create_image**: 根据提示词生成AI图片
- **check_image_status**: 查询图片生成状态  
- **generate_and_wait**: 一站式生成并等待完成
- **health_check**: 系统健康检查

## 📦 安装

```bash
pip install liblib-ai-mcp
```

## 🚀 快速开始

### 1. 获取API密钥

首先需要在LiblibAI官网获取您的AccessKey和SecretKey。

### 2. 设置环境变量

```bash
# Windows
set LIBLIB_ACCESS_KEY=your-access-key
set LIBLIB_SECRET_KEY=your-secret-key

# Linux/Mac
export LIBLIB_ACCESS_KEY=your-access-key
export LIBLIB_SECRET_KEY=your-secret-key
```

### 3. 启动MCP服务器

```bash
liblib-ai-mcp
```

### 4. 配置Claude Desktop

在Claude Desktop配置文件中添加：

```json
{
  "mcpServers": {
    "liblib-ai-picture": {
      "command": "liblib-ai-mcp",
      "env": {
        "LIBLIB_ACCESS_KEY": "your-access-key",
        "LIBLIB_SECRET_KEY": "your-secret-key"
      }
    }
  }
}
```

## 🎯 使用方法

### 在Claude中直接使用

```
请生成一张美丽的风景画
```

### 指定参数

```
使用 create_image("一只可爱的小猫", 1024, 1024) 生成图片
```

### 查询生成状态

```
使用 check_image_status("任务ID") 查询生成进度
```

### 一站式生成

```
使用 generate_and_wait("夕阳下的城市天际线") 生成并等待完成
```

## 🛠️ API接口说明

### create_image(prompt, width=768, height=768)
生成AI图片
- `prompt`: 图片描述（必须）
- `width`: 图片宽度，256-2048像素
- `height`: 图片高度，256-2048像素

### check_image_status(task_id)  
查询图片生成状态
- `task_id`: 生成任务的ID

### generate_and_wait(prompt, width=768, height=768, max_wait=120)
一站式生成并等待完成
- `prompt`: 图片描述（必须）  
- `width`: 图片宽度
- `height`: 图片高度
- `max_wait`: 最大等待时间（秒）

### health_check()
系统健康检查

## 📝 生成示例

### 风景类
- "山水风景画，中国水墨画风格"
- "sunset over ocean waves, dramatic lighting"
- "春天的花海，蓝天白云"

### 人物类
- "可爱的小女孩，动漫风格"  
- "portrait of an elderly man, realistic style"
- "古代武士，中国风格"

### 动物类
- "一只橙色的小猫在花园里"
- "majestic lion in savanna, wildlife photography"
- "中国龙，传统艺术风格"

## ⚙️ 技术特性

- 🎨 支持各种风格的AI图片生成
- 🚀 快速响应的MCP集成
- 📊 实时生成进度查询
- 💰 账户积分余额显示
- 🔄 一站式生成等待服务
- 🛡️ 完善的错误处理机制
- 🔐 HMAC-SHA1签名验证

## 💡 使用提示

1. 首次使用建议先运行 `health_check()` 确认服务正常
2. 生成图片通常需要10-60秒时间
3. 可以使用 `generate_and_wait()` 获得一站式体验
4. 每次生成会消耗一定积分，请注意账户余额
5. 支持中英文混合描述，英文提示词通常效果更好

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📞 支持

如有问题，请访问：
- 项目主页：https://github.com/yourusername/liblib-ai-mcp
- LiblibAI官网：https://www.liblibai.cloud