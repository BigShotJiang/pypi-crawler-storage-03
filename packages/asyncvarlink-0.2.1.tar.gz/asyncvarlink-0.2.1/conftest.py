# The only purpose of this file is allowing pytest to import asyncvarlink.
