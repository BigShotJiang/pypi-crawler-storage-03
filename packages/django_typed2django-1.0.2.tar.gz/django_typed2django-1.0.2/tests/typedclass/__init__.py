# tests for typedclass conversion
