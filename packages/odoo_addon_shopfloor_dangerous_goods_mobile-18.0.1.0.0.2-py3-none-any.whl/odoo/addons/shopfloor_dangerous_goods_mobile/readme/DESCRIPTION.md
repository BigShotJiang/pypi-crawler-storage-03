This module aims to display the limited quantity label on
stock_move_lines and stock_quant_packages that contains such dangerous
products.
