# robodog/__init__.py
__version__ = "2.6.5"