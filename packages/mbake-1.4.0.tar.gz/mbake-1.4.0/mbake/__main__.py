"""Entry point for running bake as a module with python -m bake."""

from .cli import main

if __name__ == "__main__":
    main()
