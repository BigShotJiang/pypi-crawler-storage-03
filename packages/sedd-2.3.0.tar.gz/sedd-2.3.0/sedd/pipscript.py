def main():
    from . import main
