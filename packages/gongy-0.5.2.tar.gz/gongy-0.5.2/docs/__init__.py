"""Documentation for gongy."""
