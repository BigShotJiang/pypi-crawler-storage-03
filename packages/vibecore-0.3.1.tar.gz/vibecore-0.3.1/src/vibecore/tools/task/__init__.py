"""Task tool for spawning sub-agents to execute specific tasks."""

from .tools import task

__all__ = ["task"]
