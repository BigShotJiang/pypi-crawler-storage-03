Select one of the Profit & Loss (US) or Balance Sheet (US) templates in
a new MIS report.

For details, refer to the [MIS Builder
documentation](https://github.com/OCA/mis-builder/tree/16.0/mis_builder#usage)
