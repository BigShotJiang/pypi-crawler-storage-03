This addon provides MIS builder templates to generate generic (US)
Profit & Loss and Balance Sheet reports based on account types.
