"""Test suite for noteparser."""
