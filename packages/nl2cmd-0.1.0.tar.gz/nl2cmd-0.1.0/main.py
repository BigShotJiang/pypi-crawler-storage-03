#!/usr/bin/env python3
import json
import platform
import re
import shlex
from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple, Dict


# ---------------------------
# Data model for the response
# ---------------------------
@dataclass
class NL2CmdResult:
    input: str
    os: str
    command: str
    alternatives: List[str]
    clarification_required: bool
    error: str
    # Additional, non-breaking fields to give users more usage info:
    explanation: str = ""  # What the command does in plain English
    command_breakdown: Dict[str, str] = None  # Key parts of the command explained


# ---------------------------
# Translator core
# ---------------------------
class NL2Cmd:
    def __init__(self, forced_os: Optional[str] = None):
        """
        forced_os: Optional override ("linux", "macOS", "windows") for testing.
        Otherwise, OS is detected from the runtime environment.
        """
        self.os = forced_os or self._detect_os()

        # Canonical intents and synonyms for lightweight semantic matching
        self.intent_synonyms = {
            "pwd": ["pwd", "current directory", "current working directory", "where am i", "print working dir"],
            "ls": ["list", "show files", "display files", "ls", "list directory", "list contents"],
            "cd": ["cd", "change dir", "go to", "navigate to", "move to"],
            "mkdir": ["mkdir", "make directory", "create folder", "create directory"],
            "rm": ["rm", "remove", "delete", "erase", "trash"],
            "cp": ["cp", "copy", "duplicate"],
            "mv": ["mv", "move", "rename"],
            "find_files": ["find files", "locate files", "search files by name", "where is file"],
            "grep_text": ["search text", "grep", "find in files", "search in files", "look for text"],
            "ps_list": ["processes", "running processes", "list processes", "tasks"],
            "kill_proc": ["kill", "terminate process", "end process", "stop process", "pkill"],
            "list_ports": ["listening ports", "open ports", "network sockets", "ports"],
            "ip_addr": ["ip", "ip address", "network address"],
            "disk_usage": ["disk usage", "disk space", "free space", "space left", "storage"],
            "memory_usage": ["memory", "ram usage", "free memory", "mem usage"],
            "cpu_usage": ["cpu usage", "load", "system load", "cpu"],
            "compress": ["compress", "archive", "zip", "tar", "gzip"],
            "decompress": ["extract", "unzip", "untar", "decompress"],
            "update_packages": ["update packages", "upgrade packages", "refresh packages", "system update"],
            "install_pkg": ["install", "add package", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco",
                            "scoop"],
            "git_status": ["git status"],
            "git_pull": ["git pull"],
            "git_push": ["git push"],
            "git_clone": ["git clone"],
            "git_commit": ["git commit"],
            "git_branch_list": ["git branch list", "list branches", "branches"],
            "git_branch_create": ["create branch", "new branch"],
            "git_log": ["git log", "commit history"],
            "git_diff": ["git diff"],
            "docker_ps": ["docker ps", "list containers", "containers"],
            "docker_images": ["docker images", "list images"],
            "docker_run": ["docker run", "run container"],
            "docker_build": ["docker build"],
            "docker_logs": ["docker logs", "container logs"],
            "cat_file": ["cat", "show file", "display file", "view file", "read file"],
            "head_file": ["head"],
            "tail_file": ["tail"],
            "chmod": ["chmod", "change permission"],
            "chown": ["chown", "change owner"],
            # Generic data wrangling intents (composition):
            "count_matches": ["count matches", "how many lines", "count lines matching", "number of occurrences"],
            "sort_by_size": ["sort by size", "largest files", "biggest files"],
            "sort_by_time": ["newest files", "oldest files", "sort by time"],
        }

        # Lightweight patterns to inform parsing and synthesis
        self.boolean_flags = {
            "recursive": ["recursive", "recursively", "subfolders", "subdirectories", "sub-folders", "sub dirs", "-r",
                          "--recursive", "all subfolders"],
            "hidden": ["hidden", "dotfiles", "including hidden", "-a", "--all"],
            "long": ["long", "detailed", "attributes", "permissions", "metadata", "human readable", "human-readable",
                     "-l", "--long"],
            "case_insensitive": ["case-insensitive", "case insensitive", "ignore case", "-i", "--ignore-case"],
            "exact": ["exact", "exactly", "whole word", "-w", "--word-regexp"],
            "force": ["force", "forcefully", "-f", "--force"]
        }

    @staticmethod
    def _detect_os() -> str:
        sys = platform.system().lower()
        if "linux" in sys:
            return "linux"
        if "darwin" in sys:
            return "macos"
        if "windows" in sys:
            return "windows"
        return "linux"

    # ---------------------------
    # Public API
    # ---------------------------
    def translate(self, text: str) -> NL2CmdResult:
        original = text
        normalized = " ".join(text.strip().split())
        low = normalized.lower()

        if not normalized:
            return self._result(original, "", [], True,
                                "Please provide an instruction to translate into a command.",
                                "", {})

        # 1) Handle chaining expressions early
        chained = self._handle_chaining(normalized)
        if chained:
            return chained

        # 2) Infer intent and context
        intent, ctx = self._infer_intent(low, normalized)

        # 3) Generate command (with explanations)
        cmd, alts, risky, clarify_msg, explanation, breakdown = self._generate_commands(intent, ctx)

        # 4) Risk/ambiguity handling and validation
        clarification_required = ctx.get("clarification_required", False) or risky or (cmd == "")
        error_msg = clarify_msg or ctx.get("clarification_message", "")

        valid, validation_msg = self._validate(intent, ctx, cmd)
        if not valid:
            clarification_required = True
            error_msg = (error_msg + " " + validation_msg).strip()

        # 5) If still empty, synthesize a best-effort command rather than saying not implemented
        if not cmd:
            cmd, alts, explanation, breakdown, synth_msg = self._synthesize_best_effort(normalized, ctx)
            if cmd:
                clarification_required = True  # propose, but ask to confirm
                error_msg = (error_msg + (" " if error_msg else "") + synth_msg).strip()

        return self._result(original, cmd, alts, clarification_required, error_msg, explanation, breakdown)

    # ---------------------------
    # Chaining detection
    # ---------------------------
    def _handle_chaining(self, text: str) -> Optional[NL2CmdResult]:
        """
        Recognize chaining phrases and compose with operators:
        - "X then Y" or "X and then Y" -> &&
        - "X or (if that fails) Y" -> ||
        - "X and Y" ->;
        - "pipe X into Y" or "X and pipe into Y" -> |
        """
        low = text.lower()

        # Piping in natural language
        pipe_match = re.search(r'(.+?)\s+(?:pipe|piped\||)\s*(?:into|to)\s+(.+)', low)
        if pipe_match:
            left = text[:pipe_match.start(2)].strip()
            right = text[pipe_match.start(2):].strip()
            a = self.translate(left)
            b = self.translate(right)
            if a.command and b.command:
                # Use RHS as a command without its input source; prefer grep/awk/cut where possible
                rhs = b.command
                # If RHS begins with a verb like grep/awk/sed/sort/uniq/wc, keep as-is; else give a generic filter
                pipe_cmd = f"{a.command} | {rhs}"
                explanation = f"Run the first command and feed its output into the second command via a pipeline"
                breakdown = {"operator": "|",
                             "operator_meaning": "Pipe output of left command to input of right command"}
                return self._result(text, pipe_cmd, [], False, "", explanation, breakdown)

        # Then => &&
        then_match = re.search(r'(.+?)\s+(?:and\s+)?then\s+(.+)', low)
        if then_match:
            left = text[:then_match.start(2)].strip()
            right = text[then_match.start(2):].strip()
            a = self.translate(left)
            b = self.translate(right)
            if a.command and b.command:
                cmd = f"{a.command} && {b.command}"
                explanation = "Execute the first command, and only if it succeeds, execute the second command"
                breakdown = {"operator": "&&", "operator_meaning": "Right runs only if left succeeds"}
                return self._result(text, cmd, [f"{a.command}; {b.command}"], False, "", explanation, breakdown)

        # "or" / "if that fails" => ||
        or_match = re.search(r'(.+?)\s+or\s+(?:if\s+(?:that\s+)?fails?\s+)?(.+)', low)
        if or_match:
            left = text[:or_match.start(2)].strip()
            right = text[or_match.start(2):].strip()
            a = self.translate(left)
            b = self.translate(right)
            if a.command and b.command:
                cmd = f"{a.command} || {b.command}"
                explanation = "Execute the first command, or if it fails, execute the second command as a fallback"
                breakdown = {"operator": "||", "operator_meaning": "Right runs only if left fails"}
                return self._result(text, cmd, [], False, "", explanation, breakdown)

        # "and" (sequential regardless) => ;
        and_match = re.search(r'(.+?)\s+and\s+(.+)', low)
        if and_match and "then" not in low and "pipe" not in low:
            left = text[:and_match.start(2)].strip()
            right = text[and_match.start(2):].strip()
            # Avoid false positives like "files and directories"
            if not any(phrase in low for phrase in ["files and directories", "read and write", "input and output"]):
                a = self.translate(left)
                b = self.translate(right)
                if a.command and b.command:
                    cmd = f"{a.command}; {b.command}"
                    explanation = "Execute two commands sequentially, regardless of success or failure of the first"
                    breakdown = {"operator": ";", "operator_meaning": "Always run right after left"}
                    return self._result(text, cmd, [f"{a.command} && {b.command}"], False, "", explanation, breakdown)

        return None

    # ---------------------------
    # Intent inference
    # ---------------------------
    def _infer_intent(self, low: str, original: str) -> Tuple[str, dict]:
        # Flags
        flags = {k: any(tok in low for tok in toks) for k, toks in self.boolean_flags.items()}

        # Context
        path = self._extract_path(original)
        pattern = self._extract_pattern(original)
        quoted = self._extract_quoted_text(original)
        number = self._extract_number(original)

        # Obvious, high-precision matches
        if re.search(r"\b(pwd|current\s+(?:working\s+)?directory|where\s+am\s+i|print\s+working\s+dir)\b", low):
            return "pwd", {}

        if re.search(r"\b(list|show|display|ls)\b.*\b(files?|contents?|items?|directories|directory|folder)\b", low) or \
                (re.search(r"\b(list|ls)\b", low) and not re.search(r"\b(processes|ports|users)\b", low)):
            return "ls", {"path": path or ".", "hidden": flags["hidden"], "long": flags["long"],
                          "recursive": flags["recursive"]}

        if re.search(r"\b(cd|change\s+(?:to\s+)?(?:directory|dir|folder)?|go\s+to|navigate\s+to|move\s+to)\b", low):
            ctx = {"path": path}
            if not path:
                ctx["clarification_required"] = True
                ctx["clarification_message"] = "Please specify the destination path for changing directory."
            return "cd", ctx

        if re.search(r"\b(mkdir|make\s+(?:directory|dir|folder)|create\s+(?:directory|dir|folder))\b", low):
            ctx = {"path": path, "parents": flags["recursive"]}
            if not path:
                ctx["clarification_required"] = True
                ctx["clarification_message"] = "Please provide the directory name or path to create."
            return "mkdir", ctx

        if re.search(r"\b(remove|delete|rm|del|erase|trash)\b", low):
            target = path or pattern
            ctx = {"path": target, "recursive": flags["recursive"], "force": flags["force"]}
            if not target:
                ctx["clarification_required"] = True
                ctx["clarification_message"] = "Please specify the exact file or directory you want to delete."
            return "rm", ctx

        if re.search(r"\b(copy|cp|duplicate)\b", low):
            src, dst = self._extract_src_dst(original)
            ctx = {"src": src, "dst": dst, "recursive": flags["recursive"]}
            if not src or not dst:
                ctx["clarification_required"] = True
                ctx[
                    "clarification_message"] = "Please specify both source and destination for copy (e.g., copy ./a to ./b)."
            return "cp", ctx

        if re.search(r"\b(move|mv|rename)\b", low):
            src, dst = self._extract_src_dst(original)
            ctx = {"src": src, "dst": dst}
            if not src or not dst:
                ctx["clarification_required"] = True
                ctx["clarification_message"] = "Please specify both source and destination for move/rename."
            return "mv", ctx

        if re.search(r"\b(find|search|locate)\b.*\b(file|files)\b", low) and not re.search(
                r"\b(text|in\s+files|content|contents|string)\b", low):
            base = path or "."
            patt = pattern or quoted or ""
            ctx = {"path": base, "pattern": patt}
            if not patt:
                ctx["clarification_required"] = True
                ctx[
                    "clarification_message"] = "Please specify a filename or pattern to search for (e.g., *.log or \"report.txt\")."
            return "find_files", ctx

        if re.search(r"\b(search|grep|find)\b.*\b(text|in\s+files|content|contents|string)\b", low):
            base = path or "."
            query = quoted or pattern or ""
            ctx = {"path": base, "query": query, "recursive": True, "case_insensitive": flags["case_insensitive"],
                   "exact": flags["exact"], "line_numbers": True}
            if not query:
                ctx["clarification_required"] = True
                ctx[
                    "clarification_message"] = "Please provide the text to search for (e.g., search text \"ERROR\" in ./logs)."
            return "grep_text", ctx

        # System/Network/Processes
        if any(w in low for w in ["processes", "running processes", "tasks"]) and "kill" not in low:
            return "ps_list", {"format": "detailed" if flags["long"] else "simple"}

        if any(w in low for w in ["kill", "terminate process", "end process", "stop process", "pkill"]):
            pid = self._extract_number(original)
            name = self._extract_process_name(original)
            ctx = {"pid": pid, "name": name, "force": flags["force"]}
            if not pid and not name:
                ctx["clarification_required"] = True
                ctx["clarification_message"] = "Please specify a PID or process name to terminate."
            return "kill_proc", ctx

        if any(w in low for w in ["ports", "listening", "open ports", "network sockets"]):
            return "list_ports", {}

        if any(w in low for w in ["ip", "ip address", "network address"]):
            return "ip_addr", {}

        if any(w in low for w in ["disk usage", "disk space", "free space", "space left", "storage"]):
            return "disk_usage", {"path": path, "human_readable": True}

        if any(w in low for w in ["memory", "ram usage", "free memory", "mem usage"]):
            return "memory_usage", {"human_readable": True}

        if any(w in low for w in ["cpu usage", "system load", "cpu load", "cpu"]):
            return "cpu_usage", {"realtime": True}

        # File viewing / head / tail
        if re.search(r"\b(cat|show|display|view|read)\b.*\b(file|content)\b", low):
            file_path = path or self._extract_filename(original)
            return "cat_file", {"file": file_path}

        if "head" in low or "tail" in low:
            file_path = path or self._extract_filename(original)
            lines = self._extract_number(original) or 10
            if "tail" in low:
                return "tail_file", {"file": file_path, "lines": lines}
            else:
                return "head_file", {"file": file_path, "lines": lines}

        # Permissions/Ownership
        if "chmod" in low or "change permission" in low:
            file_path = path or self._extract_filename(original)
            permissions = self._extract_permissions(original)
            return "chmod", {"file": file_path, "permissions": permissions}

        if "chown" in low or "change owner" in low:
            file_path = path or self._extract_filename(original)
            owner = self._extract_word_after(original, ["chown", "owner"])
            return "chown", {"file": file_path, "owner": owner}

        # Compression
        if any(w in low for w in ["compress", "archive", "zip", "tar", "gzip"]):
            files = self._extract_file_list(original)
            archive_name = self._extract_archive_name(original)
            return "compress", {"files": files, "archive_name": archive_name or "archive.tar.gz"}

        if any(w in low for w in ["extract", "unzip", "untar", "decompress"]):
            archive = path or self._extract_archive_name(original)
            return "decompress", {"archive": archive}

        # Package management
        if any(w in low for w in ["update packages", "upgrade packages", "refresh packages", "system update"]):
            return "update_packages", {}

        if any(w in low for w in
               ["install", "add package", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco", "scoop"]):
            pkg = self._extract_word_after(original,
                                           ["install", "add", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco",
                                            "scoop"])
            ctx = dict(package=pkg)
            ctx["clarification_required"] = True
            ctx["clarification_message"] = self._package_manager_message(pkg)
            return "install_pkg", ctx

        # Git
        if "git" in low:
            if "clone" in low:
                url = self._extract_url(original)
                ctx = {"url": url}
                if not url:
                    ctx["clarification_required"] = True
                    ctx["clarification_message"] = "Please provide the repository URL to clone."
                return "git_clone", ctx
            if "status" in low:
                return "git_status", {}
            if "pull" in low:
                return "git_pull", {}
            if "push" in low:
                return "git_push", {"dry_run": True}
            if "commit" in low:
                message = self._extract_quoted_text(original) or ""
                ctx = {"message": message}
                if not message:
                    ctx["clarification_required"] = True
                    ctx["clarification_message"] = "Please provide a commit message in quotes."
                return "git_commit", ctx
            if "branch" in low:
                if "list" in low:
                    return "git_branch_list", {}
                branch_name = self._extract_word_after(original, ["branch"])
                return "git_branch_create", {"branch": branch_name}
            if "log" in low:
                return "git_log", {}
            if "diff" in low:
                return "git_diff", {}

        # Docker
        if "docker" in low or "container" in low:
            if "ps" in low or "list" in low:
                return "docker_ps", {}
            if "images" in low:
                return "docker_images", {}
            if "run" in low:
                image = self._extract_word_after(original, ["run"])
                return "docker_run", {"image": image}
            if "build" in low:
                return "docker_build", {"path": path or "."}
            if "logs" in low:
                container = self._extract_word_after(original, ["logs"])
                return "docker_logs", {"container": container}

        # Generic compositional intents (count/sort/time/size)
        if any(w in low for w in ["count matches", "how many lines", "count lines matching", "number of occurrences"]):
            text = self._extract_quoted_text(original) or pattern or ""
            base = path or "."
            return "count_matches", {"query": text, "path": base}

        if any(w in low for w in ["largest files", "biggest files", "sort by size"]):
            base = path or "."
            return "sort_by_size", {"path": base}

        if any(w in low for w in ["newest files", "oldest files", "sort by time"]):
            base = path or "."
            order = "newest" if "newest" in low else "oldest" if "oldest" in low else "newest"
            return "sort_by_time", {"path": base, "order": order}

        # Fallback: pick the closest matching intent by token overlap, then rely on synthesis to propose a command
        best_intent = self._closest_intent_by_overlap(low)
        return best_intent, {"_fallback": True}

    # ---------------------------
    # Command generation
    # ---------------------------
    def _generate_commands(self, intent: str, ctx: dict) -> Tuple[str, List[str], bool, str, str, Dict[str, str]]:
        os = self.os
        risky = False
        clarify_msg = ""
        explanation = ""
        breakdown = {}

        def q(s: str) -> str:
            return shlex.quote(s) if s else s

        # PWD
        if intent == "pwd":
            if os in ("linux", "macos"):
                return "pwd", [], False, "", "Print the current working directory path", {"command": "pwd",
                                                                                          "purpose": "Display current directory"}
            else:
                return "cd", ['echo %cd%',
                              'powershell -NoProfile -Command "Get-Location"'], False, "", "Show the current directory (Windows)", {
                    "command": "cd", "purpose": "Display current directory on Windows"}

        # LS
        if intent == "ls":
            path = ctx.get("path") or "."
            if os in ("linux", "macos"):
                flags = []
                if ctx.get("long"):
                    flags.append("-l")
                if ctx.get("hidden"):
                    flags.append("-a")
                if ctx.get("recursive"):
                    flags.append("-R")
                flag_str = ("-" + "".join([f.lstrip("-") for f in flags]) + " ") if flags else ""
                cmd = f"ls {flag_str}{q(path)}".strip()
                explanation = f"List files and directories in {path}" + (f" ({' '.join(flags)})" if flags else "")
                alts = [f"ls -al {q(path)}", f"ls -lh {q(path)}"] if not flags else []
                return cmd, alts, False, "", explanation, {"command": "ls", "flags": flag_str.strip(), "path": path}
            else:
                base = "dir"
                if ctx.get("hidden"):
                    base += " /a"
                if ctx.get("recursive"):
                    base += " /s"
                cmd = f"{base} {path}"
                explanation = f"List files in {path}" + (
                    " (include hidden, recurse)" if ctx.get("hidden") or ctx.get("recursive") else "")
                alts = ['powershell -NoProfile -Command "Get-ChildItem {} {} {}"'.format(
                    "-Force" if ctx.get("hidden") else "",
                    "-Recurse" if ctx.get("recursive") else "",
                    q(path)
                ).replace("  ", " ").strip()]
                return cmd, alts, False, "", explanation, {"command": "dir", "flags": base.replace('dir', '').strip(),
                                                           "path": path}

        # CD
        if intent == "cd":
            path = ctx.get("path")
            if not path:
                return "", [], False, ctx.get("clarification_message", "Please specify a path."), "", {}
            if os in ("linux", "macos"):
                cmd = f"cd {q(path)}"
            else:
                cmd = f"cd /d {path}"
            return cmd, [], False, "", f"Change current directory to {path}", {"command": "cd", "path": path}

        # MKDIR
        if intent == "mkdir":
            path = ctx.get("path")
            if not path:
                return "", [], False, ctx.get("clarification_message",
                                              "Please provide a directory name or path."), "", {}
            if os in ("linux", "macos"):
                pflag = "-p " if ctx.get("parents") else ""
                cmd = f"mkdir {pflag}{q(path)}".strip()
                alts = [f"install -d {q(path)}"]
                explanation = f"Create directory {path}" + (" (create parents as needed)" if pflag else "")
                return cmd, alts, False, "", explanation, {"command": "mkdir", "flags": pflag.strip(), "path": path}
            else:
                return f"mkdir {path}", [], False, "", f"Create directory {path}", {"command": "mkdir", "path": path}

        # RM (risky)
        if intent == "rm":
            target = ctx.get("path")
            if not target:
                return "", [], False, ctx.get("clarification_message",
                                              "Please specify a file or directory to delete."), "", {}
            risky = True
            if os in ("linux", "macos"):
                flags = []
                if ctx.get("recursive"):
                    flags.append("-r")
                if ctx.get("force"):
                    flags.append("-f")
                flag_str = (" " + " ".join(flags)) if flags else ""
                cmd = f"rm{flag_str} {q(target)}"
                alts = [f"trash {q(target)}", f"mv {q(target)} {q(target)}.bak"]
                explanation = f"Delete {target}" + (" recursively" if ctx.get("recursive") else "") + (
                    " forcefully without prompts" if ctx.get("force") else "")
                clarify_msg = "Deletion permanently removes data. Confirm the exact path and options."
                return cmd, alts, True, clarify_msg, explanation, {"command": "rm", "flags": flag_str.strip(),
                                                                   "target": target}
            else:
                if ctx.get("recursive"):
                    cmd = f'rmdir /s "{target}"'
                    explanation = f"Remove directory {target} and all contents"
                else:
                    cmd = f'del "{target}"'
                    explanation = f"Delete file {target}"
                clarify_msg = "Deletion permanently removes data. Confirm the exact path."
                return cmd, [], True, clarify_msg, explanation, {"command": "del/rmdir", "target": target}

        # CP
        if intent == "cp":
            src, dst = ctx.get("src"), ctx.get("dst")
            if not src or not dst:
                return "", [], False, ctx.get("clarification_message",
                                              "Please provide both source and destination."), "", {}
            if os in ("linux", "macos"):
                flag = "-R " if ctx.get("recursive") else ""
                cmd = f"cp {flag}{q(src)} {q(dst)}".strip()
                alts = [f"rsync -a {q(src)}/ {q(dst)}/"] if ctx.get("recursive") else [f"install -D {q(src)} {q(dst)}"]
                return cmd, alts, False, "", f"Copy from {src} to {dst}" + (" recursively" if flag else ""), {
                    "command": "cp", "flags": flag.strip(), "src": src, "dst": dst}
            else:
                if ctx.get("recursive"):
                    cmd = f'robocopy "{src}" "{dst}" /E'
                    alts = [f'xcopy "{src}" "{dst}" /E /I /H']
                else:
                    cmd = f'copy "{src}" "{dst}"'
                    alts = [f'robocopy "{src}" "{dst}"']
                return cmd, alts, False, "", f"Copy from {src} to {dst}" + (
                    " recursively" if ctx.get("recursive") else ""), {"command": "copy/robocopy", "src": src,
                                                                      "dst": dst}

        # MV
        if intent == "mv":
            src, dst = ctx.get("src"), ctx.get("dst")
            if not src or not dst:
                return "", [], False, ctx.get("clarification_message",
                                              "Please provide both source and destination."), "", {}
            if os in ("linux", "macos"):
                return f"mv {q(src)} {q(dst)}", [], False, "", f"Move/rename {src} to {dst}", {"command": "mv",
                                                                                               "src": src, "dst": dst}
            else:
                return f'move "{src}" "{dst}"', [], False, "", f"Move/rename {src} to {dst}", {"command": "move",
                                                                                               "src": src, "dst": dst}

        # FIND FILES
        if intent == "find_files":
            base = ctx.get("path") or "."
            patt = ctx.get("pattern") or ""
            if not patt:
                return "", [], False, ctx.get("clarification_message", "Please specify a filename or pattern."), "", {}
            if os in ("linux", "macos"):
                cmd = f'find {q(base)} -name {q(patt)}'
                alts = [f'fd {q(patt)} {q(base)}', f'ls {q(base)} | grep {q(patt)}']
                return cmd, alts, False, "", f"Find files under {base} matching name pattern {patt}", {
                    "command": "find", "path": base, "pattern": patt}
            else:
                cmd = f'dir {base} /s /b {patt}'
                alts = [
                    f'powershell -NoProfile -Command "Get-ChildItem -Recurse -Filter {patt} {q(base)} | Select-Object -ExpandProperty FullName"']
                return cmd, alts, False, "", f"Find files under {base} matching name pattern {patt}", {
                    "command": "dir /s /b", "path": base, "pattern": patt}

        # GREP TEXT
        if intent == "grep_text":
            base = ctx.get("path") or "."
            query = ctx.get("query") or ""
            if not query:
                return "", [], False, ctx.get("clarification_message", "Please provide the text to search for."), "", {}
            if os in ("linux", "macos"):
                flags = ["-R", "-n"]
                if ctx.get("case_insensitive"):
                    flags.append("-i")
                if ctx.get("exact"):
                    flags.append("-w")
                cmd = f'grep {" ".join(flags)} {q(query)} {q(base)}/*' if base != "." else f'grep {" ".join(flags)} {q(query)} *'
                alts = [f'rg -n {"-i " if ctx.get("case_insensitive") else ""}{q(query)} {q(base)}']
                explanation = f"Search for text '{query}' in files within {base}" + (
                    " (case-insensitive)" if ctx.get("case_insensitive") else "")
                return cmd, alts, False, "", explanation, {"command": "grep", "flags": " ".join(flags), "text": query,
                                                           "path": base}
            else:
                flags = "/s /n"
                if ctx.get("case_insensitive"):
                    flags += " /i"
                cmd = f'findstr {flags} /c:{json.dumps(query)} {base}\\*'
                return cmd, [], False, "", f"Search for text '{query}' in files within {base}", {"command": "findstr",
                                                                                                 "flags": flags,
                                                                                                 "text": query,
                                                                                                 "path": base}

        # PROCESSES
        if intent == "ps_list":
            if os in ("linux", "macos"):
                cmd = "ps aux" if ctx.get("format") == "detailed" else "ps"
                alts = ["top", "htop"]
                explanation = "Show running processes" + (
                    " with detailed info" if ctx.get("format") == "detailed" else "")
                return cmd, alts, False, "", explanation, {"command": cmd}
            else:
                return "tasklist", [
                    'powershell -NoProfile -Command "Get-Process"'], False, "", "Show all running processes on Windows", {
                    "command": "tasklist"}

        # KILL (risky)
        if intent == "kill_proc":
            pid = ctx.get("pid")
            name = ctx.get("name")
            risky = True
            if os in ("linux", "macos"):
                if pid:
                    cmd = f"kill -9 {pid}"
                    alts = [f"kill {pid}"]
                elif name:
                    cmd = f"pkill -f {shlex.quote(name)}"
                    alts = [f"killall {shlex.quote(name)}"]
                else:
                    return "", [], False, ctx.get("clarification_message", "Provide a PID or process name."), "", {}
                return cmd, alts, True, "Terminating a process may cause data loss. Confirm PID/name.", "Terminate the specified process", {
                    "command": cmd.split()[0], "target": str(pid or name)}
            else:
                if pid:
                    cmd = f"taskkill /PID {pid} /F"
                    alts = [f"taskkill /PID {pid}"]
                elif name:
                    cmd = f'taskkill /IM "{name}" /F'
                    alts = [f'taskkill /IM "{name}"']
                else:
                    return "", [], False, ctx.get("clarification_message", "Provide a PID or process name."), "", {}
                return cmd, alts, True, "Terminating a process may cause data loss. Confirm PID/name.", "Terminate the specified process", {
                    "command": "taskkill", "target": str(pid or name)}

        # PORTS
        if intent == "list_ports":
            if os in ("linux", "macos"):
                return "lsof -i -P -n | grep LISTEN", ["ss -tuln",
                                                       "netstat -tuln"], False, "", "List listening network sockets/ports", {
                    "command": "lsof|grep LISTEN"}
            else:
                return "netstat -ano | findstr LISTENING", [
                    'powershell -NoProfile -Command "Get-NetTCPConnection -State Listen"'], False, "", "List listening network sockets/ports", {
                    "command": "netstat|findstr"}

        # IP
        if intent == "ip_addr":
            if os == "linux":
                return "ip -brief addr", ["hostname -I",
                                          "ip addr show"], False, "", "Show IP addresses of network interfaces", {
                    "command": "ip -brief addr"}
            if os == "macos":
                return "ifconfig", ["ipconfig getifaddr en0",
                                    "networksetup -listallhardwareports"], False, "", "Show network interface configuration", {
                    "command": "ifconfig"}
            return "ipconfig", [
                'powershell -NoProfile -Command "Get-NetIPAddress | Where-Object {$_.AddressState -eq \'Preferred\'}"'], False, "", "Show network interface configuration", {
                "command": "ipconfig"}

        # DISK/MEM/CPU
        if intent == "disk_usage":
            base = ctx.get("path") or "."
            if os in ("linux", "macos"):
                return f"du -sh {shlex.quote(base)}", [
                    "df -h"], False, "", "Summarize disk usage of a path in human-readable units", {"command": "du -sh",
                                                                                                    "path": base}
            return f'dir "{base}"', ["wmic logicaldisk get caption,freespace,size",
                                     'powershell -NoProfile -Command "Get-PSDrive -PSProvider FileSystem"'], False, "", "Show disk usage details", {
                "command": "dir", "path": base}

        if intent == "memory_usage":
            if os in ("linux", "macos"):
                return "free -h", [
                    "vm_stat" if os == "macos" else "cat /proc/meminfo"], False, "", "Display memory usage in human-readable format", {
                    "command": "free -h"}
            return 'wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /Value', [
                'powershell -NoProfile -Command "Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize"'], False, "", "Display memory usage", {
                "command": "wmic OS get ..."}

        if intent == "cpu_usage":
            if os == "macos":
                return "top -l 1 | head -10", ["vm_stat"], False, "", "Display a snapshot of CPU and system load", {
                    "command": "top -l 1 | head -10"}
            if os == "linux":
                return "top -bn1 | head -10", ["uptime"], False, "", "Display a snapshot of CPU and system load", {
                    "command": "top -bn1 | head -10"}
            return 'wmic cpu get loadpercentage /value', [
                'powershell -NoProfile -Command "Get-Counter \\\\Processor(_Total)\\% Processor Time"'], False, "", "Display CPU load percentage", {
                "command": "wmic cpu get ..."}

        # CAT/HEAD/TAIL
        if intent == "cat_file":
            file_path = ctx.get("file")
            if not file_path:
                return "", [], True, "Please specify a file to view.", "", {}
            return f"cat {shlex.quote(file_path)}", [
                "less " + shlex.quote(file_path)], False, "", f"Print the contents of {file_path}", {"command": "cat",
                                                                                                     "file": file_path}

        if intent == "head_file":
            file_path = ctx.get("file")
            n = ctx.get("lines", 10)
            if not file_path:
                return "", [], True, "Please specify a file to read lines from.", "", {}
            return f"head -n {n} {shlex.quote(file_path)}", [], False, "", f"Show the first {n} lines of {file_path}", {
                "command": "head", "lines": str(n), "file": file_path}

        if intent == "tail_file":
            file_path = ctx.get("file")
            n = ctx.get("lines", 10)
            if not file_path:
                return "", [], True, "Please specify a file to read lines from.", "", {}
            return f"tail -n {n} {shlex.quote(file_path)}", [], False, "", f"Show the last {n} lines of {file_path}", {
                "command": "tail", "lines": str(n), "file": file_path}

        # PERMISSIONS/OWNERSHIP
        if intent == "chmod":
            file_path = ctx.get("file")
            perms = ctx.get("permissions")
            if not file_path or not perms:
                return "", [], True, "Please specify the file and permissions (e.g., 644 or u+x).", "", {}
            return f"chmod {perms} {shlex.quote(file_path)}", [], False, "", f"Change permissions of {file_path} to {perms}", {
                "command": "chmod", "file": file_path, "mode": perms}

        if intent == "chown":
            file_path = ctx.get("file")
            owner = ctx.get("owner")
            if not file_path or not owner:
                return "", [], True, "Please specify a file and owner (e.g., user:group).", "", {}
            return f"chown {owner} {shlex.quote(file_path)}", [], False, "", f"Change ownership of {file_path} to {owner}", {
                "command": "chown", "file": file_path, "owner": owner}

        # COMPRESSION
        if intent == "compress":
            files = ctx.get("files") or []
            archive = ctx.get("archive_name") or "archive.tar.gz"
            if os in ("linux", "macos"):
                # If no files specified, compress the current directory
                src = " ".join(shlex.quote(f) for f in files) if files else "."
                cmd = f"tar -czf {shlex.quote(archive)} {src}"
                return cmd, [
                    f"zip -r {shlex.quote(archive.replace('.tar.gz', '.zip'))} {src}"], False, "", f"Create a compressed archive {archive}", {
                    "command": "tar -czf", "archive": archive, "source": src}
            else:
                # Windows: suggest PowerShell Compress-Archive
                src = files[0] if files else "."
                return f'powershell -NoProfile -Command "Compress-Archive -Path {shlex.quote(src)} -DestinationPath {shlex.quote(archive)}"', [], False, "", f"Create a compressed archive {archive}", {
                    "command": "Compress-Archive", "archive": archive, "source": src}

        if intent == "decompress":
            archive = ctx.get("archive")
            if not archive:
                return "", [], True, "Please specify the archive file to extract.", "", {}
            if os in ("linux", "macos"):
                if archive.endswith(".tar.gz"):
                    return f"tar -xzf {shlex.quote(archive)}", [], False, "", f"Extract the archive {archive}", {
                        "command": "tar -xzf", "archive": archive}
                if archive.endswith(".zip"):
                    return f"unzip {shlex.quote(archive)}", [], False, "", f"Extract the archive {archive}", {
                        "command": "unzip", "archive": archive}
                return f"tar -xf {shlex.quote(archive)}", [], False, "", f"Extract the archive {archive}", {
                    "command": "tar -xf", "archive": archive}
            else:
                return f'powershell -NoProfile -Command "Expand-Archive -Path {shlex.quote(archive)} -DestinationPath ."', [], False, "", f"Extract the archive {archive}", {
                    "command": "Expand-Archive", "archive": archive}

        # PACKAGES
        if intent == "update_packages":
            if os == "linux":
                # Safer to ask distro; propose a common example
                return "", ["sudo apt update && sudo apt upgrade -y", "sudo dnf upgrade -y",
                            "sudo pacman -Syu"], True, "Which Linux distro/package manager do you use (apt, dnf, pacman, etc.)?", "Update system packages", {
                    "note": "distro-specific"}
            if os == "macos":
                return "brew update && brew upgrade", [], False, "", "Update Homebrew and upgrade installed formulae", {
                    "command": "brew update && brew upgrade"}
            return "winget upgrade --all", ["choco upgrade all -y",
                                            "scoop update *"], False, "", "Upgrade installed packages on Windows", {
                "command": "winget upgrade --all"}

        if intent == "install_pkg":
            pkg = ctx.get("package")
            if os == "linux":
                return "", [f"sudo apt install {pkg}", f"sudo dnf install {pkg}",
                            f"sudo pacman -S {pkg}"], True, f"Confirm distro and package manager for installing {pkg}.", f"Install package {pkg}", {
                    "package": pkg}
            if os == "macos":
                return (
                    f"brew install {pkg}" if pkg else ""), [], True, f"Confirm using Homebrew and exact package name for {pkg or '<package>'}.", f"Install package {pkg or ''}", {
                    "package": pkg or ""}
            if os == "windows":
                return "", [f"winget install {pkg}", f"choco install {pkg}",
                            f"scoop install {pkg}"], True, f"Choose a package manager for installing {pkg}.", f"Install package {pkg}", {
                    "package": pkg}

        # GIT
        if intent == "git_clone":
            url = ctx.get("url")
            if not url:
                return "", [], True, "Please provide a repository URL to clone.", "", {}
            return f"git clone {shlex.quote(url)}", [], False, "", f"Clone repository from {url}", {
                "command": "git clone", "url": url}
        if intent == "git_status":
            return "git status", [], False, "", "Show the working tree status", {"command": "git status"}
        if intent == "git_pull":
            return "git pull", [], False, "", "Fetch from and integrate with the remote repository", {
                "command": "git pull"}
        if intent == "git_push":
            dry = ctx.get("dry_run", True)
            if dry:
                return "git push --dry-run", [
                    "git push"], True, "Pushing updates a remote repository. Review branch/remote before removing --dry-run.", "Simulate pushing to remote to verify what would happen", {
                    "command": "git push --dry-run"}
            return "git push", [], True, "Pushing updates a remote repository. Confirm before proceeding.", "Push local commits to remote", {
                "command": "git push"}
        if intent == "git_commit":
            msg = ctx.get("message")
            if not msg:
                return "", [], True, "Provide a commit message in quotes.", "", {}
            return f"git commit -m {json.dumps(msg)}", [], False, "", "Record changes to the repository with a message", {
                "command": "git commit -m", "message": msg}
        if intent == "git_branch_list":
            return "git branch --all", [], False, "", "List local and remote branches", {"command": "git branch --all"}
        if intent == "git_branch_create":
            b = ctx.get("branch")
            if not b:
                return "", [], True, "Please provide a branch name.", "", {}
            return f"git branch {shlex.quote(b)}", [
                f"git checkout -b {shlex.quote(b)}"], False, "", f"Create a new branch named {b}", {
                "command": "git branch", "branch": b}
        if intent == "git_log":
            return "git log --oneline -10", ["git log --graph --oneline",
                                             "git log -p -2"], False, "", "Show recent commit history (last 10)", {
                "command": "git log --oneline -10"}
        if intent == "git_diff":
            return "git diff", [], False, "", "Show changes between commits/working tree", {"command": "git diff"}

        # DOCKER
        if intent == "docker_ps":
            return "docker ps", ["docker ps -a"], False, "", "List running Docker containers", {"command": "docker ps"}
        if intent == "docker_images":
            return "docker images", ["docker image ls"], False, "", "List Docker images", {"command": "docker images"}
        if intent == "docker_run":
            image = ctx.get("image")
            if not image:
                return "", [], True, "Please specify an image to run (e.g., docker run alpine).", "", {}
            return f"docker run --rm -it {shlex.quote(image)}", [], False, "", f"Run a container from {image} interactively and remove it when it exits", {
                "command": "docker run --rm -it", "image": image}
        if intent == "docker_build":
            path = ctx.get("path") or "."
            return f"docker build {shlex.quote(path)} -t myimage:latest", [], False, "", "Build a Docker image and tag it as myimage:latest", {
                "command": "docker build -t myimage:latest", "context": path}
        if intent == "docker_logs":
            container = ctx.get("container")
            if not container:
                return "", [], True, "Please specify a container name or ID for logs.", "", {}
            return f"docker logs -f {shlex.quote(container)}", [], False, "", f"Follow logs for container {container}", {
                "command": "docker logs -f", "container": container}

        # COMPOSITIONAL UTILITIES
        if intent == "count_matches":
            query = ctx.get("query") or ""
            base = ctx.get("path") or "."
            if not query:
                return "", [], True, "Please provide the text to count.", "", {}
            if os in ("linux", "macos"):
                cmd = f'grep -R -n {shlex.quote(query)} {shlex.quote(base)} | wc -l'
                return cmd, [
                    f'rg -n {shlex.quote(query)} {shlex.quote(base)} | wc -l'], False, "", f"Count lines matching '{query}' under {base}", {
                    "command": "grep -R -n | wc -l", "query": query, "path": base}
            else:
                cmd = f'findstr /s /n /c:{json.dumps(query)} {base}\\* | find /c /v ""'
                return cmd, [], False, "", f"Count lines matching '{query}' under {base}", {
                    "command": "findstr | find /c", "query": query, "path": base}

        if intent == "sort_by_size":
            base = ctx.get("path") or "."
            if os in ("linux", "macos"):
                cmd = f'du -sh {shlex.quote(base)}/* | sort -h'
                return cmd, [], False, "", f"List items under {base} sorted by size (human-readable)", {
                    "command": "du -sh * | sort -h", "path": base}
            else:
                cmd = f'powershell -NoProfile -Command "Get-ChildItem {shlex.quote(base)} | Sort-Object Length -Descending | Select-Object Name,Length"'
                return cmd, [], False, "", f"List items under {base} sorted by size", {
                    "command": "Get-ChildItem | Sort Length", "path": base}

        if intent == "sort_by_time":
            base = ctx.get("path") or "."
            order = ctx.get("order", "newest")
            if os in ("linux", "macos"):
                cmd = f'ls -lt {shlex.quote(base)}' if order == "newest" else f'ls -ltr {shlex.quote(base)}'
                return cmd, [], False, "", f"List items under {base} by modification time ({order})", {
                    "command": "ls -lt/-ltr", "path": base, "order": order}
            else:
                cmd = f'powershell -NoProfile -Command "Get-ChildItem {shlex.quote(base)} | Sort-Object LastWriteTime -{"Descending" if order == "newest" else "Ascending"}"'
                return cmd, [], False, "", f"List items under {base} by modification time ({order})", {
                    "command": "Get-ChildItem | Sort LastWriteTime", "path": base}

        # Default: nothing concrete yet; allow synthesizer to propose
        return "", [], True, "", "", {}

    # ---------------------------
    # Validation and safety
    # ---------------------------
    def _validate(self, intent: str, ctx: dict, cmd: str) -> Tuple[bool, str]:
        if not cmd:
            return False, ""
        c = cmd.lower()

        if intent == "ls" and ctx.get("hidden"):
            if self.os in ("linux", "macos") and "-a" not in c:
                return False, "Hidden files requested; add -a."
            if self.os == "windows" and "/a" not in c:
                return False, "Hidden files requested; add /a."

        if ctx.get("recursive") and intent in ("ls", "rm", "cp", "grep_text"):
            if self.os in ("linux", "macos"):
                need = {"ls": ["-r", "-R"], "rm": ["-r", "-R"], "cp": ["-r", "-R"], "grep_text": ["-r", "-R"]}.get(
                    intent, [])
                if need and not any(f in c for f in need):
                    return False, f"Recursive requested; consider {' or '.join(need)}."
            else:
                if intent == "ls" and "/s" not in c:
                    return False, "Recursive requested; add /s."
        if intent == "ls" and ctx.get("long") and self.os in ("linux", "macos") and "-l" not in c:
            return False, "Detailed listing requested; add -l."
        return True, ""

    # ---------------------------
    # Best-effort synthesis when unknown
    # ---------------------------
    def _synthesize_best_effort(self, text: str, ctx: dict) -> Tuple[str, List[str], str, Dict[str, str], str]:
        """
        Try to infer a plausible command using heuristics:
        - Recognize verbs like count/sort/filter/print/top N
        - Map to pipeline patterns with grep/sed/awk/sort/uniq/wc
        - When all else fails, produce a safe 'echo' placeholder demonstrating the intent
        """
        low = text.lower()
        path = self._extract_path(text) or "."
        quoted = self._extract_quoted_text(text)
        pattern = self._extract_pattern(text)
        number = self._extract_number(text)

        # Heuristic: "filter ... by ..." => grep pattern
        if "filter" in low or "only" in low or "containing" in low:
            patt = quoted or pattern or ""
            if patt:
                if self.os in ("linux", "macos"):
                    cmd = f'grep -R -n {shlex.quote(patt)} {shlex.quote(path)}'
                    return cmd, [], f"Search for lines containing '{patt}' under {path}", {"command": "grep -R -n",
                                                                                           "text": patt,
                                                                                           "path": path}, "Proposed a grep-based search; confirm pattern/path."
                else:
                    cmd = f'findstr /s /n /c:{json.dumps(patt)} {path}\\*'
                    return cmd, [], f"Search for lines containing '{patt}' under {path}", {"command": "findstr /s /n",
                                                                                           "text": patt,
                                                                                           "path": path}, "Proposed a findstr-based search; confirm pattern/path."

        # Heuristic: "top N largest" => size pipeline
        if ("largest" in low or "biggest" in low) and (number or "top" in low):
            n = number or 10
            if self.os in ("linux", "macos"):
                cmd = f'du -sh {shlex.quote(path)}/* | sort -h | tail -n {n}'
                return cmd, [], f"Show top {n} largest items under {path}", {
                    "command": "du -sh * | sort -h | tail -n N", "path": path,
                    "n": str(n)}, "Proposed size-based ranking; confirm path/N."
            else:
                cmd = f'powershell -NoProfile -Command "Get-ChildItem {shlex.quote(path)} | Sort-Object Length -Descending | Select-Object -First {n} Name,Length"'
                return cmd, [], f"Show top {n} largest items under {path}", {
                    "command": "Get-ChildItem | Sort Length | Select -First N", "path": path,
                    "n": str(n)}, "Proposed size-based ranking; confirm path/N."

        # Heuristic: "newest"/"oldest" N files
        if ("newest" in low or "oldest" in low) and (number or "top" in low):
            n = number or 10
            newest = "newest" in low
            if self.os in ("linux", "macos"):
                cmd = f'ls -lt {shlex.quote(path)} | head -n {n + 1}' if newest else f'ls -ltr {shlex.quote(path)} | head -n {n + 1}'
                return cmd, [], f"Show {n} {('newest' if newest else 'oldest')} items under {path}", {
                    "command": "ls -lt/-ltr | head -n", "path": path,
                    "n": str(n)}, "Proposed time-based listing; confirm path/N."
            else:
                order = "Descending" if newest else "Ascending"
                cmd = f'powershell -NoProfile -Command "Get-ChildItem {shlex.quote(path)} | Sort-Object LastWriteTime -{order} | Select-Object -First {n} Name,LastWriteTime"'
                return cmd, [], f"Show {n} {('newest' if newest else 'oldest')} items under {path}", {
                    "command": "Get-ChildItem | Sort LastWriteTime | Select -First N", "path": path,
                    "n": str(n)}, "Proposed time-based listing; confirm path/N."

        # Fallback demonstrator: echo the intent outline safely
        safe = f'echo "Requested: {text.strip()}"'
        return safe, [], "Echo the request as a placeholder for further clarification", {"command": "echo",
                                                                                         "note": "placeholder"}, "Could not determine a precise action; provided a safe placeholder for clarification."

    # ---------------------------
    # Helpers: extraction
    # ---------------------------
    def _extract_path(self, text: str) -> Optional[str]:
        quoted = self._extract_quoted_path(text)
        if quoted:
            return quoted
        patterns = [
            r'\b(?:in|to|at|into|under|from)\s+([^\s,;]+)',
            r'\b(?:directory|folder|path|location)\s+([^\s,;]+)',
            r'(\.?/[^\s,;]+)',  # Unix-like
            r'([A-Za-z]:[^\s,;]*)',  # Windows-like
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                return (m.group(1) if m.lastindex else m.group(0)).rstrip('.,!?')
        return None

    def _extract_quoted_path(self, text: str) -> Optional[str]:
        for m in re.finditer(r'(["\'])(.+?)\1', text):
            content = m.group(2)
            if re.search(r'[\\/.~]|^[A-Za-z]:', content):
                return content
        return None

    def _extract_pattern(self, text: str) -> Optional[str]:
        m = re.search(r'\b(?:named|pattern|called)\s+([^\s,]+)', text, re.IGNORECASE)
        if m:
            return m.group(1)
        star = re.search(r'(\*[\w\.\-\?]*|\?[\w\.\-\*]*|[\w\-]*\*[\w\.\-]*)', text)
        return star.group(1) if star else None

    def _extract_quoted_text(self, text: str) -> Optional[str]:
        m = re.search(r'["\'](.+?)["\']', text)
        return m.group(1) if m else None

    def _extract_filename(self, text: str) -> Optional[str]:
        quoted = self._extract_quoted_text(text)
        if quoted and not re.search(r'[\\/]', quoted):
            return quoted
        m = re.search(r'([A-Za-z0-9_\-\.]+\.[A-Za-z0-9]{1,5})', text)
        return m.group(1) if m else None

    def _extract_src_dst(self, text: str) -> Tuple[Optional[str], Optional[str]]:
        m = re.search(r'\b(?:copy|cp|move|mv|rename)\s+(.+?)\s+\bto\b\s+(.+)$', text, re.IGNORECASE)
        if m:
            src = m.group(1).strip().strip(",.")
            dst = m.group(2).strip().strip(",.")
            quotes = re.findall(r'(["\'])(.+?)\1', text)
            if len(quotes) >= 1:
                src = quotes[0][1]
            if len(quotes) >= 2:
                dst = quotes[1][1]
            return src, dst
        quotes = re.findall(r'(["\'])(.+?)\1', text)
        if len(quotes) >= 2:
            return quotes[0][1], quotes[1][1]
        return None, None

    def _extract_number(self, text: str) -> Optional[int]:
        m = re.search(r'\bpid\s*(\d+)', text, re.IGNORECASE)
        if m:
            return int(m.group(1))
        m2 = re.search(r'\b(\d{1,4})\b', text)
        return int(m2.group(1)) if m2 else None

    def _extract_process_name(self, text: str) -> Optional[str]:
        m = re.search(r'\b(?:process|proc|name)\b\s*["\']?([A-Za-z0-9_\-\.]+)["\']?', text, re.IGNORECASE)
        return m.group(1) if m else None

    def _extract_permissions(self, text: str) -> Optional[str]:
        m = re.search(r'\b([0-7]{3,4})\b', text)
        if m:
            return m.group(1)
        m2 = re.search(r'\b([ugo]*[+-=][rwx]+)\b', text)
        return m2.group(1) if m2 else None

    def _extract_file_list(self, text: str) -> List[str]:
        files = []
        for m in re.finditer(r'["\']([^"\']+)["\']', text):
            files.append(m.group(1))
        return files

    def _extract_archive_name(self, text: str) -> Optional[str]:
        m = re.search(r'([A-Za-z0-9_\-\.]+\.(?:zip|tar|gz|bz2|xz|7z))', text)
        return m.group(1) if m else None

    def _extract_url(self, text: str) -> Optional[str]:
        m = re.search(r'(https?://[^\s"\'<>]+)', text)
        return m.group(1) if m else None

    def _extract_word_after(self, text: str, triggers: List[str]) -> Optional[str]:
        for trig in triggers:
            m = re.search(r'\b' + re.escape(trig) + r'\b\s+([A-Za-z0-9_\-\./:]+)', text, re.IGNORECASE)
            if m:
                return m.group(1)
        return None

    def _closest_intent_by_overlap(self, low: str) -> str:
        # Token overlap heuristic against synonyms sets
        tokens = set(re.findall(r"[a-z0-9]+", low))
        best_intent, best_score = "ls", 0  # Safe default
        for intent, synonyms in self.intent_synonyms.items():
            syn_tokens = set()
            for phrase in synonyms:
                syn_tokens.update(re.findall(r"[a-z0-9]+", phrase.lower()))
            score = len(tokens & syn_tokens)
            if score > best_score:
                best_score = score
                best_intent = intent
        return best_intent

    def _package_manager_message(self, pkg: Optional[str]) -> str:
        if self.os == "linux":
            return (f"Which package manager? Examples: 'apt install {pkg}' (Debian/Ubuntu), "
                    f"'dnf install {pkg}' (Fedora), 'yum install {pkg}' (RHEL/CentOS), 'pacman -S {pkg}' (Arch).")
        if self.os == "macos":
            return f"Should I use Homebrew? Example: 'brew install {pkg}'."
        return f"Choose a Windows package manager: winget/choco/scoop. Example: 'winget install {pkg}'."

    # ---------------------------
    # Result helper
    # ---------------------------
    def _result(self, original: str, command: str, alternatives: List[str],
                clarification_required: bool, error: str, explanation: str, breakdown: Dict[str, str]) -> NL2CmdResult:
        alts, seen = [], set()
        for a in alternatives:
            a = a.strip()
            if a and a != command and a not in seen:
                seen.add(a)
                alts.append(a)
        return NL2CmdResult(
            input=original,
            os=self.os,
            command=command.strip(),
            alternatives=alts,
            clarification_required=bool(clarification_required),
            error=error.strip(),
            explanation=explanation.strip(),
            command_breakdown=breakdown or {}
        )


# ---------------------------
# CLI with usage info
# ---------------------------
USAGE = """
Natural Language → Terminal Command (no execution)
--------------------------------------------------
- Type plain English instructions; returns JSON with proposed command(s).
- This tool NEVER executes commands. It only suggests translations.
- Risky/ambiguous requests set clarification_required=true and ask a question.

Chaining supported:
- "X then Y"      -> X && Y
- "X or Y"        -> X || Y (Y runs if X fails)
- "X and Y"       -> X ; Y  (always runs both)
- "pipe X into Y" -> X | Y  (pipe output of X to Y)

Examples:
- "Show all files including hidden ones"
- "Search text 'ERROR 500' in ./logs then count matches"
- "Delete everything under '/tmp/cache'"  (will ask to confirm recursion)
- "Largest 5 files in /var/log"
- "current working directory"
- "copy './a.txt' to './b.txt' and then list files"

Testing/override:
- Set forced_os in NL2Cmd(forced_os="macos"|"linux"|"windows") for testing.

Output JSON fields:
- input, os, command, alternatives[], clarification_required, error
- explanation (what the command does), command_breakdown (flags/parts)
"""


def main():
    import sys
    translator = NL2Cmd()
    print(USAGE.strip())
    print("\nDetected OS:", translator.os)
    print("Enter instructions (type 'exit' or 'quit' to stop):\n")
    for line in sys.stdin:
        instruction = line.strip()
        if not instruction:
            continue
        if instruction.lower() in ("exit", "quit"):
            break
        result = translator.translate(instruction)
        print(json.dumps(asdict(result), ensure_ascii=False))
        # Caller can iterate using the 'error' field when clarification_required is true


if __name__ == "__main__":
    main()
