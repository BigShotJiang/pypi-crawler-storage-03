# -*- coding: utf-8 -*-

"""
Phandas: Simple cryptocurrency data fetching and visualization toolkit.
"""

__author__ = "Phantom Management"
__version__ = "0.0.4"

from .data_manager import fetch_and_prepare_data, plot_price_data, check_data_quality

__all__ = [
    'fetch_and_prepare_data',  # 一鍵下載整理數據
    'plot_price_data',         # 畫圖（線圖/K棒圖）
    'check_data_quality'       # 數據品質檢查
]