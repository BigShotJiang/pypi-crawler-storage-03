import pandas as pd
import ccxt
import time
from datetime import datetime
import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Rectangle
import numpy as np

def fetch_and_prepare_data(symbols, timeframe='1d', start_date_str=None, exchange_name='binance', output_path=None):
    """
    從指定的交易所下載多個幣種的歷史K線數據，並將它們處理成一個對齊的、
    填充過缺失值的 MultiIndex DataFrame。

    這個函數會自動處理以下步驟：
    1. 使用 ccxt 從交易所下載數據。
    2. 將所有幣種的數據合併成一個 DataFrame。
    3. 處理特殊情況（如 MATIC 改名為 POL）。
    4. 找到所有幣種都開始有數據的共同起始日期，並以此對齊所有數據。
    5. 使用前一天的數據向前填充週末或維護期間造成的數據缺失。
    6. （可選）將最終處理好的數據儲存為 CSV 檔案。

    Args:
        symbols (list): 一個包含幣種代碼的列表, e.g., ['BTC', 'ETH', 'SOL']。
                        內部會自動轉換為交易所接受的格式, e.g., 'BTC/USDT'。
                        特殊處理：'MATIC' 會自動合併 MATIC 和 POL 的數據。
        timeframe (str, optional): K線的時間週期，預設為 '1d'。
        start_date_str (str, optional): 數據的起始日期，格式為 'YYYY-MM-DD'。
                                     如果為 None，則會從交易所能提供的最早數據開始。預設為 None。
        exchange_name (str, optional): 要使用的交易所名稱，預設為 'binance'。
        output_path (str, optional): 如果提供此路徑，處理好的數據將會被儲存為 CSV 檔案。
                                   e.g., 'test/data/all_data.csv'。預設為 None。

    Returns:
        pd.DataFrame: 一個 MultiIndex DataFrame，索引為 ('timestamp', 'symbol')，
                      欄位為 ['open', 'high', 'low', 'close', 'volume']。
    """
    try:
        exchange = getattr(ccxt, exchange_name)()
    except AttributeError:
        print(f"錯誤：找不到交易所 '{exchange_name}'。請確認 ccxt 支援此交易所。")
        return pd.DataFrame()

    if exchange.has['fetchOHLCV']:
        since = exchange.parse8601(f'{start_date_str}T00:00:00Z') if start_date_str else None
    else:
        print(f"錯誤：交易所 '{exchange_name}' 不支援 fetchOHLCV。")
        return pd.DataFrame()

    def download_symbol_data(symbol, final_symbol_name):
        """下載單個幣種的數據"""
        try:
            market_symbol = f'{symbol}/USDT'
            print(f"  - 正在下載 {market_symbol}...")
            
            # ccxt 分頁下載數據
            all_ohlcv = []
            limit = 1000
            current_since = since
            
            while True:
                ohlcv = exchange.fetch_ohlcv(market_symbol, timeframe, since=current_since, limit=limit)
                if not ohlcv:
                    break
                all_ohlcv.extend(ohlcv)
                current_since = ohlcv[-1][0] + 1
                time.sleep(exchange.rateLimit / 1000)

            if not all_ohlcv:
                print(f"    警告：未下載到 {market_symbol} 的任何數據。")
                return None

            df = pd.DataFrame(all_ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df['symbol'] = final_symbol_name  # 使用統一的symbol名稱
            return df

        except (ccxt.NetworkError, ccxt.ExchangeError) as e:
            print(f"    下載 {market_symbol} 時發生錯誤: {e}")
            return None

    def merge_renamed_symbols(original_symbol, new_symbol, unified_name):
        """處理改名幣種的通用函數"""
        print(f"  檢測到 {unified_name}，正在處理 {original_symbol}->{new_symbol} 改名情況...")
        
        # 下載原始幣種數據
        original_df = download_symbol_data(original_symbol, unified_name)
        
        # 下載新幣種數據
        new_df = download_symbol_data(new_symbol, unified_name)
        
        if original_df is None and new_df is None:
            print(f"    警告：{original_symbol} 和 {new_symbol} 數據都下載失敗。")
            return None
        elif original_df is None:
            print(f"    {original_symbol} 數據下載失敗，僅使用 {new_symbol} 數據。")
            return new_df
        elif new_df is None:
            print(f"    {new_symbol} 數據下載失敗，僅使用 {original_symbol} 數據。")
            return original_df
        
        # 合併數據並填補缺口
        print(f"    正在合併 {original_symbol} 和 {new_symbol} 數據...")
        
        # 找到數據的分界點
        original_last_date = original_df['timestamp'].max()
        new_first_date = new_df['timestamp'].min()
        
        print(f"    {original_symbol} 最後日期: {original_last_date.strftime('%Y-%m-%d')}")
        print(f"    {new_symbol} 開始日期: {new_first_date.strftime('%Y-%m-%d')}")
        
        # 處理重疊和缺口
        if new_first_date <= original_last_date:
            # 有重疊期間，以新幣種數據為準
            original_filtered = original_df[original_df['timestamp'] < new_first_date].copy()
            combined_df = pd.concat([original_filtered, new_df], ignore_index=True)
            print(f"    檢測到重疊期間，優先使用 {new_symbol} 數據。")
        else:
            # 有缺口，直接合併（缺口會在統一處理階段填充）
            gap_days = (new_first_date - original_last_date).days
            if gap_days > 1:
                print(f"    檢測到 {gap_days-1} 天缺口，將在統一處理階段填充...")
            combined_df = pd.concat([original_df, new_df], ignore_index=True)
        
        # 按時間排序並確保沒有重複
        combined_df = combined_df.sort_values('timestamp').drop_duplicates(subset=['timestamp'], keep='last')
        
        print(f"    成功合併數據，總共 {len(combined_df)} 個數據點。")
        return combined_df

    # 定義改名映射表，便於未來擴展
    # 無論指定 MATIC 還是 POL，都會下載完整的歷史數據
    SYMBOL_RENAME_MAP = {
        'MATIC': ('MATIC', 'POL', 'MATIC'),  # (原名, 新名, 統一輸出名)
        'POL': ('MATIC', 'POL', 'MATIC'),    # POL 也觸發相同的合併邏輯
        # 未來可以在這裡添加其他改名的幣種
        # 'OLD_NAME': ('OLD_NAME', 'NEW_NAME', 'UNIFIED_NAME'),
        # 'NEW_NAME': ('OLD_NAME', 'NEW_NAME', 'UNIFIED_NAME'),
    }

    all_dfs = []
    print(f"開始從 {exchange_name} 下載數據...")

    for symbol in symbols:
        if symbol in SYMBOL_RENAME_MAP:
            # 處理改名的幣種
            original_symbol, new_symbol, unified_name = SYMBOL_RENAME_MAP[symbol]
            merged_df = merge_renamed_symbols(original_symbol, new_symbol, unified_name)
            if merged_df is not None:
                all_dfs.append(merged_df)
        else:
            # 正常處理其他幣種
            df = download_symbol_data(symbol, symbol)
            if df is not None:
                all_dfs.append(df)

    if not all_dfs:
        print("沒有成功下載任何數據，無法繼續處理。")
        return pd.DataFrame()

    print("\n數據下載完成，開始進行整合與處理...")
    # 3. 將所有 DataFrame 合併
    combined_df = pd.concat(all_dfs, ignore_index=True)

    # 4. 數據對齊與填充
    # 使用 pivot_table 來將數據從 long format 轉為 wide format，以 symbol 為 columns
    # 這樣可以輕鬆地對齊和填充
    pivoted_dfs = {}
    ohlcv_columns = ['open', 'high', 'low', 'close', 'volume']
    for col in ohlcv_columns:
        pivoted = combined_df.pivot_table(index='timestamp', columns='symbol', values=col)
        pivoted_dfs[col] = pivoted

    # 找到所有幣種都有數據的共同起始時間
    # 首先，找到每個幣種的第一個有效數據點的時間
    first_valid_indices = {col: pivoted_dfs[col].apply(lambda s: s.first_valid_index()) for col in ohlcv_columns}
    
    # 然後，在所有欄位的所有幣種中，找到最晚的那個起始時間
    # 這樣可以確保從這個時間點開始，所有數據都是存在的
    common_start_date = max(series.max() for series in first_valid_indices.values())
    
    print(f"數據將從共同起始日期 {common_start_date.strftime('%Y-%m-%d')} 開始對齊。")

    # 創建完整的日期序列以處理缺口
    end_date = combined_df['timestamp'].max()
    full_date_range = pd.date_range(start=common_start_date, end=end_date, freq='D')
    print(f"創建完整時間序列：{len(full_date_range)} 個日期點")

    # 對齊並填充
    aligned_filled_dfs = {}
    for col in ohlcv_columns:
        # 從共同起始日期開始切片
        aligned = pivoted_dfs[col][pivoted_dfs[col].index >= common_start_date]
        # 重新索引到完整日期序列，缺失日期會自動填充為 NaN
        aligned = aligned.reindex(full_date_range)
        # 向前填充缺失值
        filled = aligned.ffill()
        # 再次填充，以防第一行就有 NaN
        filled = filled.bfill()
        aligned_filled_dfs[col] = filled

    # 5. 將數據從 wide format 轉回 long format (MultiIndex)
    # 根據 pandas 新版本的建議，使用 future_stack=True 時，必須移除 dropna 參數。
    stacked_series = {col: df.stack(future_stack=True).rename(col) for col, df in aligned_filled_dfs.items()}
    final_df = pd.concat(stacked_series.values(), axis=1)
    
    # 調整索引
    final_df.index.names = ['timestamp', 'symbol']
    final_df = final_df.sort_index()

    print("數據處理完成。")

    # 6. 儲存檔案
    if output_path:
        try:
            # 確保輸出目錄存在
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
            
            final_df.to_csv(output_path)
            print(f"已將處理好的數據儲存至: {output_path}")
        except Exception as e:
            print(f"儲存檔案時發生錯誤: {e}")

    return final_df


def plot_price_data(csv_path, plot_type='line', symbols=None, figsize=(15, 10), save_path=None):
    """
    讀取並繪製價格數據，用於檢查數據品質和視覺化價格走勢。
    
    Args:
        csv_path (str): CSV檔案路徑，應該是包含MultiIndex的格式
        plot_type (str): 繪圖類型，'line' 為線圖，'candlestick' 為K棒圖
        symbols (list, optional): 要繪製的幣種列表，如果為None則繪製所有幣種
        figsize (tuple): 圖片尺寸，預設為(15, 10)
        save_path (str, optional): 如果提供，會將圖片儲存到此路徑
    
    Returns:
        None
    """
    try:
        # 讀取數據
        print(f"正在讀取數據: {csv_path}")
        if not os.path.exists(csv_path):
            print(f"錯誤：檔案不存在 {csv_path}")
            return
            
        # 讀取MultiIndex CSV
        df = pd.read_csv(csv_path, index_col=[0, 1], parse_dates=[0])
        print(f"數據載入成功，形狀: {df.shape}")
        print(f"可用幣種: {list(df.index.get_level_values('symbol').unique())}")
        print(f"時間範圍: {df.index.get_level_values('timestamp').min()} 到 {df.index.get_level_values('timestamp').max()}")
        
        # 檢查缺失值
        missing_info = df.isnull().sum()
        if missing_info.any():
            print("\n缺失值統計:")
            for col, count in missing_info.items():
                if count > 0:
                    print(f"  {col}: {count} 個缺失值")
        else:
            print("\n✅ 沒有發現缺失值")
        
        # 選擇要繪製的幣種
        available_symbols = list(df.index.get_level_values('symbol').unique())
        if symbols is None:
            symbols = available_symbols
        else:
            symbols = [s for s in symbols if s in available_symbols]
            if not symbols:
                print("錯誤：指定的幣種都不在數據中")
                return
        
        print(f"\n準備繪製 {len(symbols)} 個幣種的圖表...")
        
        # 設置matplotlib中文字體
        plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        
        if plot_type == 'line':
            _plot_line_chart(df, symbols, figsize, save_path)
        elif plot_type == 'candlestick':
            _plot_candlestick_chart(df, symbols, figsize, save_path)
        else:
            print(f"錯誤：不支援的繪圖類型 '{plot_type}'。請使用 'line' 或 'candlestick'")
            
    except Exception as e:
        print(f"繪圖過程發生錯誤: {e}")


def _plot_line_chart(df, symbols, figsize, save_path):
    """繪製收盤價格線圖"""
    fig, axes = plt.subplots(len(symbols), 1, figsize=figsize, sharex=True)
    if len(symbols) == 1:
        axes = [axes]
    
    for i, symbol in enumerate(symbols):
        try:
            symbol_data = df.loc[df.index.get_level_values('symbol') == symbol]
            timestamps = symbol_data.index.get_level_values('timestamp')
            close_prices = symbol_data['close']
            
            axes[i].plot(timestamps, close_prices, linewidth=1.5, label=f'{symbol} Close Price')
            axes[i].set_title(f'{symbol} Price Chart', fontsize=12, fontweight='bold')
            axes[i].set_ylabel('Price (USDT)', fontsize=10)
            axes[i].grid(True, alpha=0.3)
            axes[i].legend()
            
            # 格式化x軸日期
            axes[i].xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
            axes[i].xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            
            # 檢查數據中斷
            time_diff = timestamps.to_series().diff()
            normal_interval = time_diff.mode().iloc[0] if not time_diff.mode().empty else pd.Timedelta(days=1)
            gaps = time_diff > normal_interval * 2
            
            if gaps.any():
                gap_dates = timestamps[gaps]
                for gap_date in gap_dates:
                    axes[i].axvline(x=gap_date, color='red', linestyle='--', alpha=0.7, linewidth=1)
                print(f"  {symbol}: 發現 {len(gap_dates)} 個數據中斷點")
            
        except Exception as e:
            print(f"  繪製 {symbol} 時發生錯誤: {e}")
    
    plt.xlabel('Date', fontsize=10)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"圖表已儲存到: {save_path}")
    
    plt.show()


def _plot_candlestick_chart(df, symbols, figsize, save_path):
    """繪製K棒圖（簡化版）"""
    fig, axes = plt.subplots(len(symbols), 1, figsize=figsize, sharex=True)
    if len(symbols) == 1:
        axes = [axes]
    
    for i, symbol in enumerate(symbols):
        try:
            symbol_data = df.loc[df.index.get_level_values('symbol') == symbol]
            timestamps = symbol_data.index.get_level_values('timestamp')
            
            opens = symbol_data['open'].values
            highs = symbol_data['high'].values
            lows = symbol_data['low'].values
            closes = symbol_data['close'].values
            
            # 簡化的K棒圖：使用線條和顏色表示
            for j, (timestamp, o, h, l, c) in enumerate(zip(timestamps, opens, highs, lows, closes)):
                color = 'green' if c >= o else 'red'
                alpha = 0.7
                
                # 畫影線（高低點）
                axes[i].plot([timestamp, timestamp], [l, h], color='black', linewidth=0.5, alpha=0.8)
                
                # 畫實體（開收盤價）
                body_height = abs(c - o)
                bottom = min(o, c)
                
                # 使用矩形表示K棒實體
                width = pd.Timedelta(hours=12)  # K棒寬度
                rect = Rectangle((mdates.date2num(timestamp) - width.total_seconds()/(24*3600)/2, bottom), 
                               width.total_seconds()/(24*3600), body_height, 
                               facecolor=color, alpha=alpha, edgecolor='black', linewidth=0.3)
                axes[i].add_patch(rect)
            
            axes[i].set_title(f'{symbol} Candlestick Chart', fontsize=12, fontweight='bold')
            axes[i].set_ylabel('Price (USDT)', fontsize=10)
            axes[i].grid(True, alpha=0.3)
            
            # 格式化x軸
            axes[i].xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
            axes[i].xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            
        except Exception as e:
            print(f"  繪製 {symbol} K棒圖時發生錯誤: {e}")
    
    plt.xlabel('Date', fontsize=10)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"K棒圖已儲存到: {save_path}")
    
    plt.show()


def check_data_quality(csv_path, detailed=False):
    """
    檢查數據品質，包括缺失值、重複值、異常值等。
    
    Args:
        csv_path (str): CSV檔案路徑
        detailed (bool): 是否顯示詳細統計信息
    
    Returns:
        dict: 包含數據品質報告的字典
    """
    try:
        print(f"正在檢查數據品質: {csv_path}")
        
        if not os.path.exists(csv_path):
            print(f"錯誤：檔案不存在 {csv_path}")
            return {}
        
        df = pd.read_csv(csv_path, index_col=[0, 1], parse_dates=[0])
        
        report = {
            'file_path': csv_path,
            'total_rows': len(df),
            'symbols': list(df.index.get_level_values('symbol').unique()),
            'time_range': {
                'start': df.index.get_level_values('timestamp').min(),
                'end': df.index.get_level_values('timestamp').max()
            },
            'missing_values': {},
            'duplicates': 0,
            'anomalies': {}
        }
        
        print(f"\n=== 數據品質報告 ===")
        print(f"檔案: {csv_path}")
        print(f"總行數: {report['total_rows']:,}")
        print(f"幣種數量: {len(report['symbols'])}")
        print(f"幣種列表: {', '.join(report['symbols'])}")
        print(f"時間範圍: {report['time_range']['start']} 到 {report['time_range']['end']}")
        
        # 檢查缺失值
        missing = df.isnull().sum()
        report['missing_values'] = missing.to_dict()
        
        print(f"\n--- 缺失值檢查 ---")
        if missing.any():
            for col, count in missing.items():
                if count > 0:
                    percentage = (count / len(df)) * 100
                    print(f"  {col}: {count:,} 個 ({percentage:.2f}%)")
                    report['missing_values'][col] = {'count': int(count), 'percentage': percentage}
        else:
            print("  ✅ 沒有發現缺失值")
        
        # 檢查重複值
        duplicates = df.index.duplicated().sum()
        report['duplicates'] = int(duplicates)
        print(f"\n--- 重複值檢查 ---")
        if duplicates > 0:
            print(f"  ⚠️ 發現 {duplicates} 個重複的時間戳")
        else:
            print("  ✅ 沒有發現重複的時間戳")
        
        # 檢查每個幣種的數據異常
        print(f"\n--- 數據異常檢查 ---")
        for symbol in report['symbols']:
            symbol_data = df.loc[df.index.get_level_values('symbol') == symbol]
            anomalies = {}
            
            # 檢查負價格
            negative_prices = (symbol_data[['open', 'high', 'low', 'close']] <= 0).any(axis=1).sum()
            if negative_prices > 0:
                anomalies['negative_prices'] = int(negative_prices)
            
            # 檢查異常高低價關係
            invalid_ohlc = ((symbol_data['high'] < symbol_data['low']) | 
                           (symbol_data['high'] < symbol_data['open']) |
                           (symbol_data['high'] < symbol_data['close']) |
                           (symbol_data['low'] > symbol_data['open']) |
                           (symbol_data['low'] > symbol_data['close'])).sum()
            if invalid_ohlc > 0:
                anomalies['invalid_ohlc'] = int(invalid_ohlc)
            
            # 檢查極端價格變動（日變化超過50%）
            returns = symbol_data['close'].pct_change()
            extreme_moves = (abs(returns) > 0.5).sum()
            if extreme_moves > 0:
                anomalies['extreme_moves'] = int(extreme_moves)
            
            if anomalies:
                report['anomalies'][symbol] = anomalies
                print(f"  {symbol}:")
                for anomaly_type, count in anomalies.items():
                    print(f"    ⚠️ {anomaly_type}: {count} 個")
            else:
                print(f"  {symbol}: ✅ 沒有發現異常")
        
        if detailed:
            print(f"\n--- 詳細統計信息 ---")
            for symbol in report['symbols']:
                symbol_data = df.loc[df.index.get_level_values('symbol') == symbol]
                print(f"\n  {symbol}:")
                print(f"    數據點數: {len(symbol_data):,}")
                print(f"    價格範圍: ${symbol_data['close'].min():.4f} - ${symbol_data['close'].max():.4f}")
                print(f"    平均成交量: {symbol_data['volume'].mean():,.0f}")
        
        return report
        
    except Exception as e:
        print(f"檢查數據品質時發生錯誤: {e}")
        return {}
