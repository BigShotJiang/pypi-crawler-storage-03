import random


def otp_code_generator() -> int:
    return random.randint(1000, 9999)
