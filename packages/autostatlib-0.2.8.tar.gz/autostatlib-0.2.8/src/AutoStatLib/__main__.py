#!/usr/bin/env python
from AutoStatLib.AutoStatLib import StatisticalAnalysis
from AutoStatLib.StatPlots import *
from AutoStatLib._version import __version__

if __name__ == '__main__':
    print('This package works as an imported module only.\nUse "import autostatlib" statement')
