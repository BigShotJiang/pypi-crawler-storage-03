"""
pyPrecipTHR: Python Package for Temporal Hierarchical Reconciliation of Precipitation Forecasts

A comprehensive package for probabilistic temporal hierarchical reconciliation methods
with uncertainty quantification for precipitation forecasting across multiple timescales.

Author: [Your Name]
Version: 1.0.0
"""

from .core import TemporalHierarchicalReconciliation, FlexibleTemporalHierarchicalReconciliation, ModelRegistry
from .models import RandomForestModel, ETSModel, SARIMAModel, BaseModel
from .custom_models import (
    LinearRegressionModel, 
    GradientBoostingModel, 
    SVRModel, 
    NeuralNetworkModel, 
    EnsembleModel, 
    CustomModelExample
)
from .uncertainty import BootstrapUncertainty, QuantileUncertainty
from .reconciliation import MinTReconciliation, OLSReconciliation
from .evaluation import ForecastEvaluator
from .visualization import ForecastVisualizer
from .utils import DataLoader, Preprocessor

__version__ = "1.0.0"
__author__ = "[Your Name]"
__email__ = "[your.email@example.com]"

__all__ = [
    # Core classes
    'TemporalHierarchicalReconciliation',
    'FlexibleTemporalHierarchicalReconciliation',
    'ModelRegistry',
    
    # Built-in models
    'RandomForestModel',
    'ETSModel', 
    'SARIMAModel',
    'BaseModel',
    
    # Custom models
    'LinearRegressionModel',
    'GradientBoostingModel',
    'SVRModel',
    'NeuralNetworkModel',
    'EnsembleModel',
    'CustomModelExample',
    
    # Other components
    'BootstrapUncertainty',
    'QuantileUncertainty',
    'MinTReconciliation',
    'OLSReconciliation',
    'ForecastEvaluator',
    'ForecastVisualizer',
    'DataLoader',
    'Preprocessor'
] 