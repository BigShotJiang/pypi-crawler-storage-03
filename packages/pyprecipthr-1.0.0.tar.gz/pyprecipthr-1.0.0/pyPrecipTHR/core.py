"""
Core module for Temporal Hierarchical Reconciliation (THR)

This module provides the main interface for the pyPrecipTHR package,
integrating data loading, model fitting, uncertainty quantification,
reconciliation, and evaluation.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
import warnings
warnings.filterwarnings('ignore')

from .models import RandomForestModel, ETSModel, SARIMAModel, BaseModel
from .uncertainty import BootstrapUncertainty, QuantileUncertainty
from .reconciliation import MinTReconciliation, OLSReconciliation
from .evaluation import ForecastEvaluator
from .visualization import ForecastVisualizer
from .utils import DataLoader, Preprocessor


class ModelRegistry:
    """
    Registry for managing different forecasting models.
    
    This allows for easy addition of new models and flexible model selection.
    """
    
    def __init__(self):
        self._models = {}
        self._default_model = 'random_forest'
        
        # Register built-in models
        self.register_model('random_forest', RandomForestModel)
        self.register_model('ets', ETSModel)
        self.register_model('sarima', SARIMAModel)
    
    def register_model(self, name: str, model_class: type) -> None:
        """
        Register a new model class.
        
        Parameters:
        -----------
        name : str
            Name identifier for the model
        model_class : type
            Model class that inherits from BaseModel
        """
        if not issubclass(model_class, BaseModel):
            raise ValueError(f"Model class must inherit from BaseModel")
        
        self._models[name] = model_class
        print(f"✅ Registered model: {name}")
    
    def get_model(self, name: str, **kwargs) -> BaseModel:
        """
        Get a model instance by name.
        
        Parameters:
        -----------
        name : str
            Name of the registered model
        **kwargs
            Arguments to pass to the model constructor
            
        Returns:
        --------
        BaseModel
            Model instance
        """
        if name not in self._models:
            available_models = list(self._models.keys())
            raise ValueError(f"Model '{name}' not found. Available models: {available_models}")
        
        model_class = self._models[name]
        return model_class(**kwargs)
    
    def list_models(self) -> List[str]:
        """Get list of available model names."""
        return list(self._models.keys())
    
    def get_default_model(self) -> str:
        """Get the default model name."""
        return self._default_model
    
    def set_default_model(self, name: str) -> None:
        """Set the default model name."""
        if name not in self._models:
            raise ValueError(f"Model '{name}' not registered")
        self._default_model = name


class FlexibleTemporalHierarchicalReconciliation:
    """
    Flexible Temporal Hierarchical Reconciliation system.
    
    This class provides a flexible interface for temporal hierarchical reconciliation
    that can work with any forecasting model that follows the BaseModel interface.
    """
    
    def __init__(self, 
                 model_name: str = None,
                 model_params: Dict[str, Any] = None,
                 n_bootstrap: int = 500,
                 reconciliation_method: str = 'mint',
                 forecast_horizon: int = 12,
                 custom_model: BaseModel = None):
        """
        Initialize the flexible THR system.
        
        Parameters:
        -----------
        model_name : str, optional
            Name of the registered model to use
        model_params : Dict[str, Any], optional
            Parameters to pass to the model constructor
        n_bootstrap : int
            Number of bootstrap samples for uncertainty quantification
        reconciliation_method : str
            Reconciliation method ('mint', 'ols', 'both')
        forecast_horizon : int
            Forecast horizon in months
        custom_model : BaseModel, optional
            Custom model instance (overrides model_name if provided)
        """
        # Initialize model registry
        self.model_registry = ModelRegistry()
        
        # Set up model
        if custom_model is not None:
            if not isinstance(custom_model, BaseModel):
                raise ValueError("Custom model must inherit from BaseModel")
            self.model = custom_model
            self.model_name = "custom"
        else:
            model_name = model_name or self.model_registry.get_default_model()
            model_params = model_params or {}
            model_params.setdefault('n_bootstrap', n_bootstrap)
            
            self.model = self.model_registry.get_model(model_name, **model_params)
            self.model_name = model_name
        
        self.n_bootstrap = n_bootstrap
        self.reconciliation_method = reconciliation_method
        self.forecast_horizon = forecast_horizon
        
        # Initialize components
        self.data_loader = DataLoader()
        self.preprocessor = Preprocessor()
        
        # Initialize uncertainty quantification
        self.uncertainty = BootstrapUncertainty(n_bootstrap=n_bootstrap)
        
        # Initialize reconciliation methods
        self.mint_reconciliation = MinTReconciliation()
        self.ols_reconciliation = OLSReconciliation()
        
        # Initialize evaluation and visualization
        self.evaluator = ForecastEvaluator()
        self.visualizer = ForecastVisualizer()
        
        # Store results
        self.results = {}
        
        print(f"🚀 Initialized Flexible THR with model: {self.model_name}")
    
    def register_custom_model(self, name: str, model_class: type) -> None:
        """
        Register a custom model class.
        
        Parameters:
        -----------
        name : str
            Name for the custom model
        model_class : type
            Model class that inherits from BaseModel
        """
        self.model_registry.register_model(name, model_class)
    
    def get_available_models(self) -> List[str]:
        """Get list of available models."""
        return self.model_registry.list_models()
    
    def switch_model(self, model_name: str, **kwargs) -> None:
        """
        Switch to a different model.
        
        Parameters:
        -----------
        model_name : str
            Name of the model to switch to
        **kwargs
            Additional parameters for the model
        """
        kwargs.setdefault('n_bootstrap', self.n_bootstrap)
        self.model = self.model_registry.get_model(model_name, **kwargs)
        self.model_name = model_name
        print(f"🔄 Switched to model: {model_name}")
    
    def load_data(self, basin_name: str) -> pd.DataFrame:
        """
        Load and preprocess data for a specific basin.
        
        Parameters:
        -----------
        basin_name : str
            Name of the basin to load data for
            
        Returns:
        --------
        pd.DataFrame
            Preprocessed time series data
        """
        print(f"📊 Loading data for basin: {basin_name}")
        
        # Load raw data
        raw_data = self.data_loader.load_precipitation_data()
        
        # Filter for specific basin
        basin_data = self.data_loader.filter_basin(raw_data, basin_name)
        
        if basin_data is None or len(basin_data) == 0:
            raise ValueError(f"No data found for basin: {basin_name}")
        
        # Preprocess data
        processed_data = self.preprocessor.preprocess_basin_data(basin_data)
        
        print(f"✅ Data loaded successfully")
        print(f"   Data points: {len(processed_data)}")
        print(f"   Date range: {processed_data.index[0]} to {processed_data.index[-1]}")
        
        return processed_data
    
    def create_temporal_hierarchy(self, data: pd.Series) -> Dict[str, pd.Series]:
        """
        Create temporal hierarchy at different frequencies.
        
        Parameters:
        -----------
        data : pd.Series
            Monthly time series data
            
        Returns:
        --------
        Dict[str, pd.Series]
            Dictionary with different frequency aggregations
        """
        hierarchy = {
            'monthly': data,
            'bi_monthly': data.resample('2MS').sum(),
            'quarterly': data.resample('QS-DEC').sum(),
            'half_yearly': data.resample('6MS').sum(),
            'annual': data.resample('A-DEC').sum()
        }
        
        return hierarchy
    
    def forecast_with_uncertainty(self, 
                                data: pd.Series,
                                hierarchy: Dict[str, pd.Series]) -> Dict[str, Dict]:
        """
        Generate forecasts with uncertainty quantification using the current model.
        
        Parameters:
        -----------
        data : pd.Series
            Monthly time series data
        hierarchy : Dict[str, pd.Series]
            Temporal hierarchy at different frequencies (not used for forecasting)
            
        Returns:
        --------
        Dict[str, Dict]
            Forecasts with uncertainty for each frequency
        """
        print(f"📈 Generating forecasts with {self.model_name} model...")
        
        # Only forecast on monthly data (like original implementation)
        print(f"   📊 Forecasting monthly frequency...")
        
        try:
            # Generate forecast with uncertainty on monthly data
            monthly_forecast = self.model.forecast_with_uncertainty(
                data, 
                self.forecast_horizon
            )
            
            if monthly_forecast is not None:
                # Create forecasts for other frequencies from monthly forecasts
                monthly_median = monthly_forecast['median']
                
                # Create bi-monthly forecasts
                bi_monthly_forecasts = []
                for i in range(6):
                    bi_monthly_forecasts.append(monthly_median[i*2] + monthly_median[i*2+1])
                
                # Create quarterly forecasts
                quarterly_forecasts = []
                for i in range(4):
                    quarterly_forecasts.append(sum(monthly_median[i*3:(i+1)*3]))
                
                # Create half-yearly forecasts
                half_yearly_forecasts = [
                    sum(monthly_median[:6]),
                    sum(monthly_median[6:])
                ]
                
                # Create annual forecast
                annual_forecast = sum(monthly_median)
                
                # Create forecast results for all frequencies
                forecasts = {
                    'monthly': monthly_forecast,
                    'bi_monthly': {
                        'median': np.array(bi_monthly_forecasts),
                        'lower_80': np.array(bi_monthly_forecasts) * 0.9,  # Placeholder
                        'upper_80': np.array(bi_monthly_forecasts) * 1.1,  # Placeholder
                        'lower_95': np.array(bi_monthly_forecasts) * 0.8,  # Placeholder
                        'upper_95': np.array(bi_monthly_forecasts) * 1.2,  # Placeholder
                        'predictions': np.array([bi_monthly_forecasts] * self.model.n_bootstrap)
                    },
                    'quarterly': {
                        'median': np.array(quarterly_forecasts),
                        'lower_80': np.array(quarterly_forecasts) * 0.9,  # Placeholder
                        'upper_80': np.array(quarterly_forecasts) * 1.1,  # Placeholder
                        'lower_95': np.array(quarterly_forecasts) * 0.8,  # Placeholder
                        'upper_95': np.array(quarterly_forecasts) * 1.2,  # Placeholder
                        'predictions': np.array([quarterly_forecasts] * self.model.n_bootstrap)
                    },
                    'half_yearly': {
                        'median': np.array(half_yearly_forecasts),
                        'lower_80': np.array(half_yearly_forecasts) * 0.9,  # Placeholder
                        'upper_80': np.array(half_yearly_forecasts) * 1.1,  # Placeholder
                        'lower_95': np.array(half_yearly_forecasts) * 0.8,  # Placeholder
                        'upper_95': np.array(half_yearly_forecasts) * 1.2,  # Placeholder
                        'predictions': np.array([half_yearly_forecasts] * self.model.n_bootstrap)
                    },
                    'annual': {
                        'median': np.array([annual_forecast]),
                        'lower_80': np.array([annual_forecast * 0.9]),  # Placeholder
                        'upper_80': np.array([annual_forecast * 1.1]),  # Placeholder
                        'lower_95': np.array([annual_forecast * 0.8]),  # Placeholder
                        'upper_95': np.array([annual_forecast * 1.2]),  # Placeholder
                        'predictions': np.array([[annual_forecast] * self.model.n_bootstrap])
                    }
                }
                
                print(f"   ✅ monthly forecast completed")
                print(f"   ✅ bi_monthly forecast completed")
                print(f"   ✅ quarterly forecast completed")
                print(f"   ✅ half_yearly forecast completed")
                print(f"   ✅ annual forecast completed")
                
                return forecasts
            else:
                print(f"   ❌ monthly forecast failed")
                return {}
                
        except Exception as e:
            print(f"   ❌ Error in forecasting: {e}")
            return {}
    
    def reconcile_forecasts(self, forecasts: Dict[str, Dict]) -> Dict[str, np.ndarray]:
        """
        Apply hierarchical reconciliation to forecasts.
        
        Parameters:
        -----------
        forecasts : Dict[str, Dict]
            Forecasts for different frequencies
            
        Returns:
        --------
        Dict[str, np.ndarray]
            Reconciled forecasts for each method
        """
        print(f"🔄 Applying hierarchical reconciliation...")
        
        if 'monthly' not in forecasts or 'annual' not in forecasts:
            raise ValueError("Monthly and annual forecasts required for reconciliation")
        
        # Prepare forecasts for reconciliation
        monthly_forecasts = forecasts['monthly']['median']
        annual_forecast = forecasts['annual']['median'][0] if len(forecasts['annual']['median']) > 0 else 0
        
        # Create full forecast vector
        full_forecasts = self._create_forecast_vector(monthly_forecasts, annual_forecast)
        
        # Create aggregation matrix
        S = self._create_aggregation_matrix()
        
        reconciliation_results = {}
        
        # Apply reconciliation methods
        if self.reconciliation_method in ['mint', 'both']:
            try:
                mint_reconciled = self.mint_reconciliation.reconcile(full_forecasts, S)
                reconciliation_results['MinT'] = mint_reconciled
                print(f"   ✅ MinT reconciliation completed")
            except Exception as e:
                print(f"   ❌ MinT reconciliation failed: {e}")
        
        if self.reconciliation_method in ['ols', 'both']:
            try:
                ols_reconciled = self.ols_reconciliation.reconcile(full_forecasts, S)
                reconciliation_results['OLS'] = ols_reconciled
                print(f"   ✅ OLS reconciliation completed")
            except Exception as e:
                print(f"   ❌ OLS reconciliation failed: {e}")
        
        return reconciliation_results
    
    def evaluate_forecasts(self, 
                          forecasts: Dict[str, Dict],
                          reconciliation_results: Dict[str, np.ndarray],
                          test_data: Optional[pd.Series] = None) -> Dict:
        """
        Evaluate forecast performance and reconciliation quality.
        
        Parameters:
        -----------
        forecasts : Dict[str, Dict]
            Forecasts for different frequencies
        reconciliation_results : Dict[str, np.ndarray]
            Reconciled forecasts
        test_data : Optional[pd.Series]
            Test data for evaluation
            
        Returns:
        --------
        Dict
            Evaluation results
        """
        print(f"📊 Evaluating forecasts and reconciliation...")
        
        evaluation_results = self.evaluator.evaluate_all(
            forecasts=forecasts,
            reconciliation_results=reconciliation_results,
            test_data=test_data
        )
        
        return evaluation_results
    
    def generate_visualizations(self, 
                               basin_name: str,
                               forecasts: Dict[str, Dict],
                               reconciliation_results: Dict[str, np.ndarray],
                               evaluation_results: Dict) -> None:
        """
        Generate comprehensive visualizations.
        
        Parameters:
        -----------
        basin_name : str
            Name of the basin
        forecasts : Dict[str, Dict]
            Forecasts for different frequencies
        reconciliation_results : Dict[str, np.ndarray]
            Reconciled forecasts
        evaluation_results : Dict
            Evaluation results
        """
        print(f"📊 Generating visualizations...")
        
        self.visualizer.create_comprehensive_dashboard(
            basin_name=basin_name,
            forecasts=forecasts,
            reconciliation_results=reconciliation_results,
            evaluation_results=evaluation_results
        )
    
    def forecast_basin(self, basin_name: str) -> Dict:
        """
        Complete forecasting pipeline for a single basin.
        
        Parameters:
        -----------
        basin_name : str
            Name of the basin to forecast
            
        Returns:
        --------
        Dict
            Complete results including forecasts, reconciliation, and evaluation
        """
        print(f"\n{'='*70}")
        print(f"FLEXIBLE TEMPORAL HIERARCHICAL RECONCILIATION FOR BASIN: {basin_name}")
        print(f"Model: {self.model_name}")
        print(f"{'='*70}")
        
        try:
            # 1. Load and preprocess data
            data = self.load_data(basin_name)
            
            # 2. Create temporal hierarchy
            hierarchy = self.create_temporal_hierarchy(data)
            
            # 3. Generate forecasts with uncertainty
            forecasts = self.forecast_with_uncertainty(data, hierarchy)
            
            if not forecasts:
                raise ValueError("No forecasts generated")
            
            # 4. Apply hierarchical reconciliation
            reconciliation_results = self.reconcile_forecasts(forecasts)
            
            # 5. Evaluate results
            evaluation_results = self.evaluate_forecasts(
                forecasts, 
                reconciliation_results,
                test_data=data[-self.forecast_horizon:] if len(data) >= self.forecast_horizon else None
            )
            
            # 6. Generate visualizations
            self.generate_visualizations(
                basin_name, 
                forecasts, 
                reconciliation_results, 
                evaluation_results
            )
            
            # 7. Compile results
            self.results = {
                'basin_name': basin_name,
                'model_name': self.model_name,
                'forecasts': forecasts,
                'reconciliation_results': reconciliation_results,
                'evaluation_results': evaluation_results,
                'forecast_horizon': self.forecast_horizon
            }
            
            print(f"\n✅ Forecasting completed successfully for {basin_name}!")
            print(f"   Model used: {self.model_name}")
            
            return self.results
            
        except Exception as e:
            print(f"\n❌ Error in forecasting pipeline: {e}")
            return None
    
    def _create_forecast_vector(self, monthly_forecasts: np.ndarray, annual_forecast: float) -> np.ndarray:
        """Create full forecast vector for reconciliation."""
        full_forecasts = np.zeros(25)
        full_forecasts[:12] = monthly_forecasts
        
        # Calculate aggregated forecasts
        bi_monthly_forecasts = []
        for i in range(6):
            bi_monthly_forecasts.append(monthly_forecasts[i*2] + monthly_forecasts[i*2+1])
        full_forecasts[12:18] = bi_monthly_forecasts
        
        quarterly_forecasts = []
        for i in range(4):
            quarterly_forecasts.append(sum(monthly_forecasts[i*3:(i+1)*3]))
        full_forecasts[18:22] = quarterly_forecasts
        
        # Half-yearly
        full_forecasts[22] = sum(monthly_forecasts[:6])
        full_forecasts[23] = sum(monthly_forecasts[6:])
        
        # Annual
        full_forecasts[24] = annual_forecast
        
        return full_forecasts
    
    def _create_aggregation_matrix(self) -> np.ndarray:
        """Create aggregation matrix S for hierarchical reconciliation."""
        S = np.zeros((25, 12))
        
        # Monthly forecasts (identity matrix)
        S[:12, :] = np.eye(12)
        
        # Bi-monthly aggregates
        for i in range(6):
            S[12 + i, i*2:(i+1)*2] = 1
        
        # Quarterly aggregates
        for i in range(4):
            S[18 + i, i*3:(i+1)*3] = 1
        
        # Half-yearly aggregates
        S[22, :6] = 1
        S[23, 6:] = 1
        
        # Annual aggregate
        S[24, :] = 1
        
        return S


# Keep the original class for backward compatibility
class TemporalHierarchicalReconciliation(FlexibleTemporalHierarchicalReconciliation):
    """
    Backward compatibility wrapper for the original TemporalHierarchicalReconciliation class.
    
    This maintains the original interface while providing the new flexible functionality.
    """
    
    def __init__(self, 
                 model_type: str = 'random_forest',
                 n_bootstrap: int = 500,
                 reconciliation_method: str = 'mint',
                 forecast_horizon: int = 12):
        """
        Initialize the THR system (backward compatibility).
        
        Parameters:
        -----------
        model_type : str
            Type of forecasting model ('random_forest', 'ets', 'sarima')
        n_bootstrap : int
            Number of bootstrap samples for uncertainty quantification
        reconciliation_method : str
            Reconciliation method ('mint', 'ols', 'both')
        forecast_horizon : int
            Forecast horizon in months
        """
        super().__init__(
            model_name=model_type,
            n_bootstrap=n_bootstrap,
            reconciliation_method=reconciliation_method,
            forecast_horizon=forecast_horizon
        ) 