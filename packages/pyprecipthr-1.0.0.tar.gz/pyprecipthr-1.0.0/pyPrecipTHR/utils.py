"""
Utilities module for pyPrecipTHR

This module contains data loading and preprocessing utilities for the package.
"""

import pandas as pd
import numpy as np
from typing import Optional, List, Dict
import warnings
warnings.filterwarnings('ignore')


class DataLoader:
    """Data loader for precipitation data."""
    
    def __init__(self):
        self.data_files = [
            'Precip_first500.csv',
            'Precip_second500.csv', 
            'Precip_third500.csv',
            'Precip_fourth.csv'
        ]
    
    def load_precipitation_data(self) -> pd.DataFrame:
        """
        Load and combine all precipitation data files.
        
        Returns:
        --------
        pd.DataFrame
            Combined precipitation data
        """
        try:
            dfs = []
            offsets = [0, 500, 1000, 1500]
            
            for i, (file, offset) in enumerate(zip(self.data_files, offsets)):
                print(f"   📁 Loading {file}...")
                df = pd.read_csv(file)
                df['Band'] += offset
                dfs.append(df)
            
            # Combine all datasets
            full_df = pd.concat(dfs).sort_values('Band')
            
            # Filter valid data
            full_df = full_df[(full_df['Precip'] > 0) & (full_df['area'] > 0)]
            
            # Calculate total precipitation in km³
            full_df['total_precip_km3'] = (full_df['Precip'] * (full_df['area'] * 1e6)) / 1e9
            
            # Create date mapping
            unique_bands = sorted(full_df['Band'].unique())
            start_date = pd.Timestamp('1951-01-01')
            end_date = pd.Timestamp('2023-12-01')  # End in 2023 for 2024 forecasting
            
            # Create date series
            date_series = pd.date_range(start=start_date, end=end_date, freq='MS')
            
            # Truncate if necessary
            if len(unique_bands) > len(date_series):
                unique_bands = unique_bands[:len(date_series)]
                full_df = full_df[full_df['Band'].isin(unique_bands)]
            
            # Map bands to dates
            band_date_map = dict(zip(unique_bands, date_series))
            full_df['date'] = full_df['Band'].map(band_date_map)
            
            # Remove invalid dates
            full_df = full_df.dropna(subset=['date'])
            
            print(f"   ✅ Data loaded successfully")
            print(f"   Total records: {len(full_df)}")
            print(f"   Date range: {full_df['date'].min()} to {full_df['date'].max()}")
            
            return full_df
            
        except Exception as e:
            print(f"   ❌ Error loading data: {e}")
            return None
    
    def filter_basin(self, data: pd.DataFrame, basin_name: str) -> Optional[pd.DataFrame]:
        """
        Filter data for a specific basin.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Full precipitation dataset
        basin_name : str
            Name of the basin to filter for
            
        Returns:
        --------
        Optional[pd.DataFrame]
            Filtered data for the specified basin
        """
        if data is None:
            return None
        
        basin_data = data[data['name'] == basin_name].copy()
        
        if len(basin_data) == 0:
            print(f"   ❌ Basin '{basin_name}' not found!")
            print(f"   Available basins: {data['name'].unique()[:10]}...")
            return None
        
        # Sort by date
        basin_data = basin_data.sort_values('date')
        
        print(f"   ✅ Basin data filtered successfully")
        print(f"   Records for {basin_name}: {len(basin_data)}")
        
        return basin_data
    
    def get_available_basins(self, data: pd.DataFrame) -> List[str]:
        """
        Get list of available basins.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Precipitation dataset
            
        Returns:
        --------
        List[str]
            List of available basin names
        """
        if data is None:
            return []
        
        return sorted(data['name'].unique())


class Preprocessor:
    """Data preprocessing utilities."""
    
    def __init__(self):
        pass
    
    def preprocess_basin_data(self, basin_data: pd.DataFrame) -> pd.Series:
        """
        Preprocess basin data into time series format.
        
        Parameters:
        -----------
        basin_data : pd.DataFrame
            Raw basin data
            
        Returns:
        --------
        pd.Series
            Preprocessed time series with date index
        """
        # Create time series
        ts_data = basin_data.set_index('date')['total_precip_km3']
        
        # Set frequency and sort
        ts_data.index.freq = 'MS'
        ts_data = ts_data.sort_index()
        
        # Handle missing values
        ts_data = ts_data.fillna(method='ffill').fillna(method='bfill')
        
        # Remove outliers (optional)
        ts_data = self._remove_outliers(ts_data)
        
        print(f"   ✅ Data preprocessed successfully")
        print(f"   Final data points: {len(ts_data)}")
        print(f"   Data range: {ts_data.min():.2f} to {ts_data.max():.2f}")
        
        return ts_data
    
    def _remove_outliers(self, series: pd.Series, threshold: float = 3.0) -> pd.Series:
        """
        Remove outliers using z-score method.
        
        Parameters:
        -----------
        series : pd.Series
            Time series data
        threshold : float
            Z-score threshold for outlier detection
            
        Returns:
        --------
        pd.Series
            Series with outliers removed
        """
        z_scores = np.abs((series - series.mean()) / series.std())
        outliers = z_scores > threshold
        
        if outliers.sum() > 0:
            print(f"   ⚠️ Removed {outliers.sum()} outliers")
            series = series[~outliers]
        
        return series
    
    def create_temporal_features(self, series: pd.Series) -> pd.DataFrame:
        """
        Create temporal features for forecasting.
        
        Parameters:
        -----------
        series : pd.Series
            Time series data
            
        Returns:
        --------
        pd.DataFrame
            DataFrame with temporal features
        """
        df = pd.DataFrame({'y': series})
        
        # Add temporal features
        df['month'] = df.index.month
        df['year'] = df.index.year
        df['quarter'] = df.index.quarter
        df['day_of_year'] = df.index.dayofyear
        
        # Add lagged features
        for lag in [1, 2, 3, 6, 12]:
            df[f'lag_{lag}'] = df['y'].shift(lag)
        
        # Add rolling statistics
        df['rolling_mean_12'] = df['y'].rolling(window=12).mean()
        df['rolling_std_12'] = df['y'].rolling(window=12).std()
        
        return df.dropna()
    
    def validate_data_quality(self, series: pd.Series) -> Dict:
        """
        Validate data quality and provide statistics.
        
        Parameters:
        -----------
        series : pd.Series
            Time series data
            
        Returns:
        --------
        Dict
            Data quality statistics
        """
        stats = {
            'length': len(series),
            'date_range': f"{series.index[0]} to {series.index[-1]}",
            'missing_values': series.isnull().sum(),
            'min_value': series.min(),
            'max_value': series.max(),
            'mean_value': series.mean(),
            'std_value': series.std(),
            'zero_values': (series == 0).sum(),
            'negative_values': (series < 0).sum()
        }
        
        # Quality indicators
        quality_issues = []
        
        if stats['missing_values'] > 0:
            quality_issues.append(f"Missing values: {stats['missing_values']}")
        
        if stats['negative_values'] > 0:
            quality_issues.append(f"Negative values: {stats['negative_values']}")
        
        if stats['length'] < 48:
            quality_issues.append("Insufficient data points")
        
        stats['quality_issues'] = quality_issues
        stats['is_suitable'] = len(quality_issues) == 0
        
        return stats 