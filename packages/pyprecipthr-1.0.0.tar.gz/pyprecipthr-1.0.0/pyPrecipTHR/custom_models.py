"""
Custom Models module for pyPrecipTHR

This module demonstrates how to create custom forecasting models
that can be easily integrated into the flexible THR system.
"""

import pandas as pd
import numpy as np
from typing import Dict, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from scipy import stats

from .models import BaseModel


class LinearRegressionModel(BaseModel):
    """
    Linear Regression model for precipitation forecasting.
    
    Simple but interpretable model for baseline comparison.
    """
    
    def __init__(self, n_bootstrap: int = 500, alpha: float = 1.0):
        super().__init__(n_bootstrap)
        self.alpha = alpha  # Ridge regularization parameter
        
    def create_lagged_features(self, series: pd.Series, n_lags: int = 12) -> pd.DataFrame:
        """Create lagged features for forecasting."""
        df = pd.DataFrame({'y': series})
        for lag in range(1, n_lags + 1):
            df[f'lag_{lag}'] = df['y'].shift(lag)
        
        return df.dropna()
    
    def forecast_with_uncertainty(self, series: pd.Series, forecast_horizon: int) -> Optional[Dict]:
        """Generate Linear Regression forecast with bootstrap uncertainty quantification."""
        try:
            # Create lagged features
            df_lagged = self.create_lagged_features(series, n_lags=12)
            
            if len(df_lagged) < 48:
                print(f"   ⚠️ Insufficient data for Linear Regression model")
                return None
            
            # Train/test split
            train = df_lagged.iloc[:-forecast_horizon]
            test = df_lagged.iloc[-forecast_horizon:]
            
            X_train = train.drop('y', axis=1).values
            y_train = train['y'].values
            X_test = test.drop('y', axis=1).values
            y_test = test['y'].values
            
            predictions = []
            
            # Bootstrap uncertainty quantification
            for _ in range(self.n_bootstrap):
                # Sample with replacement
                indices = np.random.choice(len(X_train), len(X_train), replace=True)
                X_boot = X_train[indices]
                y_boot = y_train[indices]
                
                # Train Ridge regression
                model = Ridge(alpha=self.alpha, random_state=np.random.randint(0, 1000))
                model.fit(X_boot, y_boot)
                
                # Predict
                pred = model.predict(X_test)
                
                # Add noise for uncertainty
                residuals = y_train - model.predict(X_train)
                noise_std = np.std(residuals)
                noise = np.random.normal(0, noise_std, len(pred))
                pred_with_noise = pred + noise
                
                # Ensure non-negative predictions
                pred_with_noise = np.maximum(pred_with_noise, 0)
                
                predictions.append(pred_with_noise)
            
            predictions = np.array(predictions)
            
            # Calculate intervals
            lower_80 = np.percentile(predictions, 10, axis=0)
            upper_80 = np.percentile(predictions, 90, axis=0)
            lower_95 = np.percentile(predictions, 2.5, axis=0)
            upper_95 = np.percentile(predictions, 97.5, axis=0)
            
            return {
                'median': np.median(predictions, axis=0),
                'lower_80': lower_80,
                'upper_80': upper_80,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'predictions': predictions
            }
            
        except Exception as e:
            print(f"   ❌ Linear Regression forecast failed: {e}")
            return None


class GradientBoostingModel(BaseModel):
    """
    Gradient Boosting model for precipitation forecasting.
    
    Powerful ensemble method with good performance on complex time series.
    """
    
    def __init__(self, n_bootstrap: int = 500, n_estimators: int = 100, learning_rate: float = 0.1):
        super().__init__(n_bootstrap)
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        
    def create_lagged_features(self, series: pd.Series, n_lags: int = 12) -> pd.DataFrame:
        """Create lagged features for forecasting."""
        df = pd.DataFrame({'y': series})
        for lag in range(1, n_lags + 1):
            df[f'lag_{lag}'] = df['y'].shift(lag)
        
        return df.dropna()
    
    def forecast_with_uncertainty(self, series: pd.Series, forecast_horizon: int) -> Optional[Dict]:
        """Generate Gradient Boosting forecast with bootstrap uncertainty quantification."""
        try:
            # Create lagged features
            df_lagged = self.create_lagged_features(series, n_lags=12)
            
            if len(df_lagged) < 48:
                print(f"   ⚠️ Insufficient data for Gradient Boosting model")
                return None
            
            # Train/test split
            train = df_lagged.iloc[:-forecast_horizon]
            test = df_lagged.iloc[-forecast_horizon:]
            
            X_train = train.drop('y', axis=1).values
            y_train = train['y'].values
            X_test = test.drop('y', axis=1).values
            y_test = test['y'].values
            
            predictions = []
            
            # Bootstrap uncertainty quantification
            for _ in range(self.n_bootstrap):
                # Sample with replacement
                indices = np.random.choice(len(X_train), len(X_train), replace=True)
                X_boot = X_train[indices]
                y_boot = y_train[indices]
                
                # Train Gradient Boosting
                model = GradientBoostingRegressor(
                    n_estimators=np.random.randint(50, self.n_estimators + 50),
                    learning_rate=self.learning_rate,
                    max_depth=np.random.randint(3, 8),
                    random_state=np.random.randint(0, 1000)
                )
                model.fit(X_boot, y_boot)
                
                # Predict
                pred = model.predict(X_test)
                
                # Add noise for uncertainty
                residuals = y_train - model.predict(X_train)
                noise_std = np.std(residuals)
                noise = np.random.normal(0, noise_std, len(pred))
                pred_with_noise = pred + noise
                
                # Ensure non-negative predictions
                pred_with_noise = np.maximum(pred_with_noise, 0)
                
                predictions.append(pred_with_noise)
            
            predictions = np.array(predictions)
            
            # Calculate intervals
            lower_80 = np.percentile(predictions, 10, axis=0)
            upper_80 = np.percentile(predictions, 90, axis=0)
            lower_95 = np.percentile(predictions, 2.5, axis=0)
            upper_95 = np.percentile(predictions, 97.5, axis=0)
            
            return {
                'median': np.median(predictions, axis=0),
                'lower_80': lower_80,
                'upper_80': upper_80,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'predictions': predictions
            }
            
        except Exception as e:
            print(f"   ❌ Gradient Boosting forecast failed: {e}")
            return None


class SVRModel(BaseModel):
    """
    Support Vector Regression model for precipitation forecasting.
    
    Good for capturing non-linear relationships in time series.
    """
    
    def __init__(self, n_bootstrap: int = 500, kernel: str = 'rbf', C: float = 1.0):
        super().__init__(n_bootstrap)
        self.kernel = kernel
        self.C = C
        
    def create_lagged_features(self, series: pd.Series, n_lags: int = 12) -> pd.DataFrame:
        """Create lagged features for forecasting."""
        df = pd.DataFrame({'y': series})
        for lag in range(1, n_lags + 1):
            df[f'lag_{lag}'] = df['y'].shift(lag)
        
        return df.dropna()
    
    def forecast_with_uncertainty(self, series: pd.Series, forecast_horizon: int) -> Optional[Dict]:
        """Generate SVR forecast with bootstrap uncertainty quantification."""
        try:
            # Create lagged features
            df_lagged = self.create_lagged_features(series, n_lags=12)
            
            if len(df_lagged) < 48:
                print(f"   ⚠️ Insufficient data for SVR model")
                return None
            
            # Train/test split
            train = df_lagged.iloc[:-forecast_horizon]
            test = df_lagged.iloc[-forecast_horizon:]
            
            X_train = train.drop('y', axis=1).values
            y_train = train['y'].values
            X_test = test.drop('y', axis=1).values
            y_test = test['y'].values
            
            # Scale features for SVR
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            predictions = []
            
            # Bootstrap uncertainty quantification
            for _ in range(self.n_bootstrap):
                # Sample with replacement
                indices = np.random.choice(len(X_train_scaled), len(X_train_scaled), replace=True)
                X_boot = X_train_scaled[indices]
                y_boot = y_train[indices]
                
                # Train SVR
                model = SVR(
                    kernel=self.kernel,
                    C=np.random.uniform(0.1, self.C * 2),
                    gamma='scale',
                    random_state=np.random.randint(0, 1000)
                )
                model.fit(X_boot, y_boot)
                
                # Predict
                pred = model.predict(X_test_scaled)
                
                # Add noise for uncertainty
                residuals = y_train - model.predict(X_train_scaled)
                noise_std = np.std(residuals)
                noise = np.random.normal(0, noise_std, len(pred))
                pred_with_noise = pred + noise
                
                # Ensure non-negative predictions
                pred_with_noise = np.maximum(pred_with_noise, 0)
                
                predictions.append(pred_with_noise)
            
            predictions = np.array(predictions)
            
            # Calculate intervals
            lower_80 = np.percentile(predictions, 10, axis=0)
            upper_80 = np.percentile(predictions, 90, axis=0)
            lower_95 = np.percentile(predictions, 2.5, axis=0)
            upper_95 = np.percentile(predictions, 97.5, axis=0)
            
            return {
                'median': np.median(predictions, axis=0),
                'lower_80': lower_80,
                'upper_80': upper_80,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'predictions': predictions
            }
            
        except Exception as e:
            print(f"   ❌ SVR forecast failed: {e}")
            return None


class NeuralNetworkModel(BaseModel):
    """
    Neural Network model for precipitation forecasting.
    
    Deep learning approach for complex time series patterns.
    """
    
    def __init__(self, n_bootstrap: int = 500, hidden_layer_sizes: Tuple[int, ...] = (100, 50)):
        super().__init__(n_bootstrap)
        self.hidden_layer_sizes = hidden_layer_sizes
        
    def create_lagged_features(self, series: pd.Series, n_lags: int = 12) -> pd.DataFrame:
        """Create lagged features for forecasting."""
        df = pd.DataFrame({'y': series})
        for lag in range(1, n_lags + 1):
            df[f'lag_{lag}'] = df['y'].shift(lag)
        
        return df.dropna()
    
    def forecast_with_uncertainty(self, series: pd.Series, forecast_horizon: int) -> Optional[Dict]:
        """Generate Neural Network forecast with bootstrap uncertainty quantification."""
        try:
            # Create lagged features
            df_lagged = self.create_lagged_features(series, n_lags=12)
            
            if len(df_lagged) < 48:
                print(f"   ⚠️ Insufficient data for Neural Network model")
                return None
            
            # Train/test split
            train = df_lagged.iloc[:-forecast_horizon]
            test = df_lagged.iloc[-forecast_horizon:]
            
            X_train = train.drop('y', axis=1).values
            y_train = train['y'].values
            X_test = test.drop('y', axis=1).values
            y_test = test['y'].values
            
            # Scale features for neural network
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            predictions = []
            
            # Bootstrap uncertainty quantification
            for _ in range(self.n_bootstrap):
                # Sample with replacement
                indices = np.random.choice(len(X_train_scaled), len(X_train_scaled), replace=True)
                X_boot = X_train_scaled[indices]
                y_boot = y_train[indices]
                
                # Train Neural Network
                model = MLPRegressor(
                    hidden_layer_sizes=self.hidden_layer_sizes,
                    max_iter=500,
                    random_state=np.random.randint(0, 1000),
                    early_stopping=True,
                    validation_fraction=0.1
                )
                model.fit(X_boot, y_boot)
                
                # Predict
                pred = model.predict(X_test_scaled)
                
                # Add noise for uncertainty
                residuals = y_train - model.predict(X_train_scaled)
                noise_std = np.std(residuals)
                noise = np.random.normal(0, noise_std, len(pred))
                pred_with_noise = pred + noise
                
                # Ensure non-negative predictions
                pred_with_noise = np.maximum(pred_with_noise, 0)
                
                predictions.append(pred_with_noise)
            
            predictions = np.array(predictions)
            
            # Calculate intervals
            lower_80 = np.percentile(predictions, 10, axis=0)
            upper_80 = np.percentile(predictions, 90, axis=0)
            lower_95 = np.percentile(predictions, 2.5, axis=0)
            upper_95 = np.percentile(predictions, 97.5, axis=0)
            
            return {
                'median': np.median(predictions, axis=0),
                'lower_80': lower_80,
                'upper_80': upper_80,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'predictions': predictions
            }
            
        except Exception as e:
            print(f"   ❌ Neural Network forecast failed: {e}")
            return None


class EnsembleModel(BaseModel):
    """
    Ensemble model combining multiple forecasting approaches.
    
    Combines predictions from multiple models for improved accuracy.
    """
    
    def __init__(self, n_bootstrap: int = 500, models: Optional[list] = None):
        super().__init__(n_bootstrap)
        self.models = models or [
            RandomForestModel(n_bootstrap=100),
            LinearRegressionModel(n_bootstrap=100),
            GradientBoostingModel(n_bootstrap=100)
        ]
        
    def forecast_with_uncertainty(self, series: pd.Series, forecast_horizon: int) -> Optional[Dict]:
        """Generate ensemble forecast by combining multiple models."""
        try:
            all_predictions = []
            
            # Get predictions from each model
            for i, model in enumerate(self.models):
                print(f"   📊 Running model {i+1}/{len(self.models)}: {type(model).__name__}")
                
                model_pred = model.forecast_with_uncertainty(series, forecast_horizon)
                if model_pred is not None:
                    all_predictions.append(model_pred['predictions'])
                else:
                    print(f"   ⚠️ Model {i+1} failed, skipping")
            
            if not all_predictions:
                print(f"   ❌ All models failed")
                return None
            
            # Combine predictions (simple average)
            combined_predictions = np.mean(all_predictions, axis=0)
            
            # Calculate intervals
            lower_80 = np.percentile(combined_predictions, 10, axis=0)
            upper_80 = np.percentile(combined_predictions, 90, axis=0)
            lower_95 = np.percentile(combined_predictions, 2.5, axis=0)
            upper_95 = np.percentile(combined_predictions, 97.5, axis=0)
            
            return {
                'median': np.median(combined_predictions, axis=0),
                'lower_80': lower_80,
                'upper_80': upper_80,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'predictions': combined_predictions
            }
            
        except Exception as e:
            print(f"   ❌ Ensemble forecast failed: {e}")
            return None


# Example of how to create a completely custom model
class CustomModelExample(BaseModel):
    """
    Example of a completely custom model.
    
    This demonstrates how to create a model from scratch that follows
    the BaseModel interface.
    """
    
    def __init__(self, n_bootstrap: int = 500, window_size: int = 6):
        super().__init__(n_bootstrap)
        self.window_size = window_size
        
    def forecast_with_uncertainty(self, series: pd.Series, forecast_horizon: int) -> Optional[Dict]:
        """
        Custom forecasting method using moving average with trend adjustment.
        
        This is just an example - you can implement any forecasting logic here.
        """
        try:
            predictions = []
            
            # Simple moving average with trend
            for _ in range(self.n_bootstrap):
                # Bootstrap the series
                boot_indices = np.random.choice(len(series), len(series), replace=True)
                boot_series = series.iloc[boot_indices]
                
                # Calculate moving average
                ma = boot_series.rolling(window=self.window_size).mean().iloc[-1]
                
                # Calculate trend
                if len(boot_series) >= 2:
                    trend = (boot_series.iloc[-1] - boot_series.iloc[-2]) / 2
                else:
                    trend = 0
                
                # Generate forecasts
                forecast = []
                current_value = ma
                for _ in range(forecast_horizon):
                    current_value = current_value + trend
                    current_value = max(0, current_value)  # Ensure non-negative
                    forecast.append(current_value)
                
                # Add uncertainty
                noise = np.random.normal(0, np.std(boot_series) * 0.1, forecast_horizon)
                forecast_with_noise = np.array(forecast) + noise
                forecast_with_noise = np.maximum(forecast_with_noise, 0)
                
                predictions.append(forecast_with_noise)
            
            predictions = np.array(predictions)
            
            # Calculate intervals
            lower_80 = np.percentile(predictions, 10, axis=0)
            upper_80 = np.percentile(predictions, 90, axis=0)
            lower_95 = np.percentile(predictions, 2.5, axis=0)
            upper_95 = np.percentile(predictions, 97.5, axis=0)
            
            return {
                'median': np.median(predictions, axis=0),
                'lower_80': lower_80,
                'upper_80': upper_80,
                'lower_95': lower_95,
                'upper_95': upper_95,
                'predictions': predictions
            }
            
        except Exception as e:
            print(f"   ❌ Custom model forecast failed: {e}")
            return None 