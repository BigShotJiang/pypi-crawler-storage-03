"""
Visualization module for pyPrecipTHR

This module provides comprehensive plotting capabilities for
forecast results, uncertainty quantification, and reconciliation.
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.dates import MonthLocator, DateFormatter
from typing import Dict, Optional
import warnings
warnings.filterwarnings('ignore')


class ForecastVisualizer:
    """
    Comprehensive visualizer for forecast results.
    
    This class provides various plotting methods for visualizing
    forecasts, uncertainty, and reconciliation results.
    """
    
    def __init__(self):
        pass
    
    def create_comprehensive_dashboard(self, basin_name: str, forecasts: Dict,
                                    reconciliation_results: Dict, evaluation_results: Dict):
        """
        Create a comprehensive dashboard with all visualizations.
        
        Parameters:
        -----------
        basin_name : str
            Name of the basin
        forecasts : Dict
            Forecast results
        reconciliation_results : Dict
            Reconciliation results
        evaluation_results : Dict
            Evaluation results
        """
        fig, axes = plt.subplots(2, 2, figsize=(20, 12))
        fig.suptitle(f'pyPrecipTHR Dashboard - {basin_name}', fontsize=16, fontweight='bold')
        
        # 1. Forecast with uncertainty (top left)
        self._plot_forecast_with_uncertainty(axes[0, 0], forecasts, basin_name)
        
        # 2. Reconciliation comparison (top right)
        self._plot_reconciliation_comparison(axes[0, 1], reconciliation_results)
        
        # 3. Multi-frequency forecasts (bottom left)
        self._plot_multi_frequency_forecasts(axes[1, 0], forecasts)
        
        # 4. Performance metrics (bottom right)
        self._plot_performance_metrics(axes[1, 1], evaluation_results)
        
        plt.tight_layout()
        
        # Save the plot
        filename = f'pyPrecipTHR_{basin_name.lower()}_dashboard.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"📊 Dashboard saved as: {filename}")
        
        plt.show()
    
    def _plot_forecast_with_uncertainty(self, ax, forecasts: Dict, basin_name: str):
        """Plot forecast with uncertainty bands."""
        if 'monthly' not in forecasts:
            return
        
        monthly_data = forecasts['monthly']
        median = monthly_data.get('median', [])
        
        if len(median) == 0:
            return
        
        # Create forecast dates
        forecast_start = pd.Timestamp('2024-01-01')
        forecast_dates = pd.date_range(start=forecast_start, periods=len(median), freq='MS')
        
        # Plot median forecast
        ax.plot(forecast_dates, median, 'r-', linewidth=2, marker='o', label='Median Forecast')
        
        # Add uncertainty bands if available
        if 'lower_80' in monthly_data and 'upper_80' in monthly_data:
            ax.fill_between(forecast_dates, 
                          monthly_data['lower_80'], 
                          monthly_data['upper_80'],
                          alpha=0.3, color='orange', label='80% Confidence')
        
        if 'lower_95' in monthly_data and 'upper_95' in monthly_data:
            ax.fill_between(forecast_dates, 
                          monthly_data['lower_95'], 
                          monthly_data['upper_95'],
                          alpha=0.2, color='red', label='95% Confidence')
        
        ax.set_title('📊 Forecast with Uncertainty', fontweight='bold', fontsize=14)
        ax.set_xlabel('Time')
        ax.set_ylabel('Precipitation (km³)')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Format x-axis
        ax.xaxis.set_major_locator(MonthLocator(interval=2))
        ax.xaxis.set_major_formatter(DateFormatter('%Y-%m'))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
    
    def _plot_reconciliation_comparison(self, ax, reconciliation_results: Dict):
        """Plot reconciliation comparison."""
        if not reconciliation_results:
            return
        
        methods = list(reconciliation_results.keys())
        
        # Calculate inconsistency metrics
        inconsistencies = []
        for method in methods:
            reconciled = reconciliation_results[method]
            if len(reconciled) >= 12:
                monthly_sum = np.sum(reconciled[:12])
                annual_val = reconciled[24] if len(reconciled) > 24 else monthly_sum
                inconsistency = abs(monthly_sum - annual_val)
                inconsistencies.append(inconsistency)
            else:
                inconsistencies.append(0)
        
        # Create bar plot
        x = np.arange(len(methods))
        bars = ax.bar(x, inconsistencies, color=['#FF6B6B', '#4ECDC4'])
        
        ax.set_title('🔄 Reconciliation Quality', fontweight='bold', fontsize=14)
        ax.set_xlabel('Method')
        ax.set_ylabel('Inconsistency')
        ax.set_xticks(x)
        ax.set_xticklabels(methods)
        ax.grid(True, alpha=0.3)
        
        # Add value labels
        for i, (bar, val) in enumerate(zip(bars, inconsistencies)):
            ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + max(inconsistencies)*0.01,
                   f'{val:.2f}', ha='center', va='bottom', fontsize=10)
    
    def _plot_multi_frequency_forecasts(self, ax, forecasts: Dict):
        """Plot multi-frequency forecasts."""
        frequencies = ['monthly', 'bi_monthly', 'quarterly', 'half_yearly', 'annual']
        colors = ['blue', 'green', 'orange', 'red', 'purple']
        
        forecast_start = pd.Timestamp('2024-01-01')
        
        for i, freq in enumerate(frequencies):
            if freq in forecasts and 'median' in forecasts[freq]:
                median_vals = forecasts[freq]['median']
                
                if len(median_vals) > 0:
                    # Create appropriate index for each frequency
                    if freq == 'monthly':
                        index = pd.date_range(start=forecast_start, periods=len(median_vals), freq='MS')
                    elif freq == 'bi_monthly':
                        periods = min(6, len(median_vals))
                        index = pd.date_range(start=forecast_start, periods=periods, freq='2MS')
                    elif freq == 'quarterly':
                        periods = min(4, len(median_vals))
                        index = pd.date_range(start=forecast_start, periods=periods, freq='QS')
                    elif freq == 'half_yearly':
                        periods = min(2, len(median_vals))
                        index = pd.date_range(start=forecast_start, periods=periods, freq='6MS')
                    elif freq == 'annual':
                        periods = min(1, len(median_vals))
                        index = pd.date_range(start=forecast_start, periods=periods, freq='A')
                    else:
                        index = range(len(median_vals))
                    
                    plot_vals = median_vals[:len(index)]
                    ax.plot(index, plot_vals, 
                           color=colors[i], label=f'{freq.title()} ({len(plot_vals)} periods)', 
                           linewidth=2, marker='o')
        
        ax.set_title('📈 Multi-Frequency Forecasts', fontweight='bold', fontsize=14)
        ax.set_xlabel('Time')
        ax.set_ylabel('Precipitation (km³)')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Format x-axis
        ax.xaxis.set_major_locator(MonthLocator(interval=2))
        ax.xaxis.set_major_formatter(DateFormatter('%Y-%m'))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
    
    def _plot_performance_metrics(self, ax, evaluation_results: Dict):
        """Plot performance metrics."""
        if not evaluation_results:
            return
        
        metrics = []
        values = []
        
        # Extract accuracy metrics
        if 'accuracy' in evaluation_results:
            acc = evaluation_results['accuracy']
            metrics.extend(['MAE', 'RMSE', 'MAPE'])
            values.extend([acc.get('mae', 0), acc.get('rmse', 0), acc.get('mape', 0)])
        
        # Extract uncertainty metrics
        if 'uncertainty' in evaluation_results:
            unc = evaluation_results['uncertainty']
            if 'coverage' in unc:
                metrics.extend(['80% Coverage', '95% Coverage'])
                values.extend([unc['coverage'].get('80%', 0) * 100, 
                             unc['coverage'].get('95%', 0) * 100])
        
        if not metrics:
            return
        
        # Create bar plot
        x = np.arange(len(metrics))
        bars = ax.bar(x, values, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'])
        
        ax.set_title('🎯 Performance Metrics', fontweight='bold', fontsize=14)
        ax.set_xlabel('Metric')
        ax.set_ylabel('Value')
        ax.set_xticks(x)
        ax.set_xticklabels(metrics, rotation=45)
        ax.grid(True, alpha=0.3)
        
        # Add value labels
        for i, (bar, val) in enumerate(zip(bars, values)):
            ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + max(values)*0.01,
                   f'{val:.2f}', ha='center', va='bottom', fontsize=10)
    
    def plot_uncertainty_evolution(self, forecasts: Dict, basin_name: str):
        """Plot uncertainty evolution over forecast horizon."""
        if 'monthly' not in forecasts:
            return
        
        monthly_data = forecasts['monthly']
        if 'predictions' not in monthly_data:
            return
        
        predictions = monthly_data['predictions']
        
        # Calculate uncertainty measures over time
        std_values = np.std(predictions, axis=0)
        iqr_values = np.percentile(predictions, 75, axis=0) - np.percentile(predictions, 25, axis=0)
        
        forecast_start = pd.Timestamp('2024-01-01')
        forecast_dates = pd.date_range(start=forecast_start, periods=len(std_values), freq='MS')
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot standard deviation
        ax1.plot(forecast_dates, std_values, 'b-', linewidth=2, marker='o')
        ax1.set_title('📊 Uncertainty Evolution (Std)', fontweight='bold')
        ax1.set_xlabel('Time')
        ax1.set_ylabel('Standard Deviation')
        ax1.grid(True, alpha=0.3)
        
        # Plot interquartile range
        ax2.plot(forecast_dates, iqr_values, 'r-', linewidth=2, marker='o')
        ax2.set_title('📊 Uncertainty Evolution (IQR)', fontweight='bold')
        ax2.set_xlabel('Time')
        ax2.set_ylabel('Interquartile Range')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
    
    def plot_reconciliation_analysis(self, original_forecasts: np.ndarray,
                                  reconciled_forecasts: Dict, basin_name: str):
        """Plot detailed reconciliation analysis."""
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot original vs reconciled
        forecast_start = pd.Timestamp('2024-01-01')
        forecast_dates = pd.date_range(start=forecast_start, periods=12, freq='MS')
        
        ax1.plot(forecast_dates, original_forecasts[:12], 'b-', linewidth=2, 
                marker='o', label='Original')
        
        colors = ['red', 'green', 'orange']
        for i, (method, reconciled) in enumerate(reconciled_forecasts.items()):
            if len(reconciled) >= 12:
                ax1.plot(forecast_dates, reconciled[:12], color=colors[i], 
                        linewidth=2, marker='s', label=f'{method} Reconciled')
        
        ax1.set_title('🔄 Original vs Reconciled Forecasts', fontweight='bold')
        ax1.set_xlabel('Time')
        ax1.set_ylabel('Precipitation (km³)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Plot forecast changes
        changes = []
        methods = []
        for method, reconciled in reconciled_forecasts.items():
            if len(reconciled) >= 12:
                change = np.mean(np.abs(reconciled[:12] - original_forecasts[:12]))
                changes.append(change)
                methods.append(method)
        
        if changes:
            x = np.arange(len(methods))
            bars = ax2.bar(x, changes, color=['#FF6B6B', '#4ECDC4'])
            ax2.set_title('📊 Average Forecast Changes', fontweight='bold')
            ax2.set_xlabel('Method')
            ax2.set_ylabel('Mean Absolute Change')
            ax2.set_xticks(x)
            ax2.set_xticklabels(methods)
            ax2.grid(True, alpha=0.3)
            
            # Add value labels
            for i, (bar, val) in enumerate(zip(bars, changes)):
                ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height() + max(changes)*0.01,
                        f'{val:.2f}', ha='center', va='bottom', fontsize=10)
        
        plt.tight_layout()
        plt.show() 