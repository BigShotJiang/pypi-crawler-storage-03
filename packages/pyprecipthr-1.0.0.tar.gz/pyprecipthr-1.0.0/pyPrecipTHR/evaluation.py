"""
Evaluation module for pyPrecipTHR

This module provides comprehensive evaluation metrics for forecast
performance and reconciliation quality.
"""

import numpy as np
import pandas as pd
from typing import Dict, Optional
from sklearn.metrics import mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings('ignore')


class ForecastEvaluator:
    """
    Comprehensive forecast evaluator.
    
    This class provides various metrics for evaluating forecast performance,
    uncertainty quantification, and reconciliation quality.
    """
    
    def __init__(self):
        pass
    
    def evaluate_all(self, forecasts: Dict, reconciliation_results: Dict,
                    test_data: Optional[pd.Series] = None) -> Dict:
        """
        Evaluate all aspects of the forecasting system.
        
        Parameters:
        -----------
        forecasts : Dict
            Forecasts for different frequencies
        reconciliation_results : Dict
            Reconciled forecasts
        test_data : Optional[pd.Series]
            Test data for evaluation
            
        Returns:
        --------
        Dict
            Comprehensive evaluation results
        """
        evaluation_results = {}
        
        # Evaluate forecast accuracy
        if test_data is not None and 'monthly' in forecasts:
            accuracy_metrics = self.evaluate_accuracy(
                forecasts['monthly']['median'], 
                test_data.values
            )
            evaluation_results['accuracy'] = accuracy_metrics
        
        # Evaluate uncertainty quantification
        if 'monthly' in forecasts and 'predictions' in forecasts['monthly']:
            uncertainty_metrics = self.evaluate_uncertainty(
                forecasts['monthly']['predictions'],
                test_data.values if test_data is not None else None
            )
            evaluation_results['uncertainty'] = uncertainty_metrics
        
        # Evaluate reconciliation
        if reconciliation_results:
            reconciliation_metrics = self.evaluate_reconciliation(
                forecasts, reconciliation_results
            )
            evaluation_results['reconciliation'] = reconciliation_metrics
        
        return evaluation_results
    
    def evaluate_accuracy(self, predictions: np.ndarray, actual: np.ndarray) -> Dict:
        """
        Evaluate forecast accuracy using various metrics.
        
        Parameters:
        -----------
        predictions : np.ndarray
            Forecast predictions
        actual : np.ndarray
            Actual values
            
        Returns:
        --------
        Dict
            Accuracy metrics
        """
        # Ensure same length
        min_len = min(len(predictions), len(actual))
        pred = predictions[:min_len]
        act = actual[:min_len]
        
        # Calculate metrics
        mae = mean_absolute_error(act, pred)
        rmse = np.sqrt(mean_squared_error(act, pred))
        mape = np.mean(np.abs((act - pred) / (act + 1e-8))) * 100
        
        # Calculate bias
        bias = np.mean(pred - act)
        
        # Calculate correlation
        correlation = np.corrcoef(pred, act)[0, 1]
        
        return {
            'mae': mae,
            'rmse': rmse,
            'mape': mape,
            'bias': bias,
            'correlation': correlation,
            'n_predictions': min_len
        }
    
    def evaluate_uncertainty(self, predictions: np.ndarray, 
                           actual: Optional[np.ndarray] = None) -> Dict:
        """
        Evaluate uncertainty quantification.
        
        Parameters:
        -----------
        predictions : np.ndarray
            Bootstrap predictions
        actual : Optional[np.ndarray]
            Actual values for coverage calculation
            
        Returns:
        --------
        Dict
            Uncertainty evaluation metrics
        """
        # Calculate prediction intervals
        lower_80 = np.percentile(predictions, 10, axis=0)
        upper_80 = np.percentile(predictions, 90, axis=0)
        lower_95 = np.percentile(predictions, 2.5, axis=0)
        upper_95 = np.percentile(predictions, 97.5, axis=0)
        
        uncertainty_metrics = {
            'median': np.median(predictions, axis=0),
            'std': np.std(predictions, axis=0),
            'intervals': {
                '80%': {'lower': lower_80, 'upper': upper_80},
                '95%': {'lower': lower_95, 'upper': upper_95}
            }
        }
        
        # Calculate coverage if actual values available
        if actual is not None:
            min_len = min(len(actual), len(lower_80))
            act = actual[:min_len]
            l80 = lower_80[:min_len]
            u80 = upper_80[:min_len]
            l95 = lower_95[:min_len]
            u95 = upper_95[:min_len]
            
            coverage_80 = np.mean((act >= l80) & (act <= u80))
            coverage_95 = np.mean((act >= l95) & (act <= u95))
            
            uncertainty_metrics['coverage'] = {
                '80%': coverage_80,
                '95%': coverage_95
            }
        
        return uncertainty_metrics
    
    def evaluate_reconciliation(self, forecasts: Dict, 
                              reconciliation_results: Dict) -> Dict:
        """
        Evaluate reconciliation quality.
        
        Parameters:
        -----------
        forecasts : Dict
            Original forecasts
        reconciliation_results : Dict
            Reconciled forecasts
            
        Returns:
        --------
        Dict
            Reconciliation evaluation metrics
        """
        if 'monthly' not in forecasts:
            return {}
        
        monthly_forecasts = forecasts['monthly']['median']
        monthly_sum = np.sum(monthly_forecasts)
        
        reconciliation_metrics = {}
        
        for method_name, reconciled_forecasts in reconciliation_results.items():
            if len(reconciled_forecasts) >= 12:
                reconciled_monthly = reconciled_forecasts[:12]
                reconciled_sum = np.sum(reconciled_monthly)
                
                # Calculate inconsistency reduction
                original_inconsistency = abs(monthly_sum - reconciled_sum)
                
                reconciliation_metrics[method_name] = {
                    'monthly_sum': monthly_sum,
                    'reconciled_sum': reconciled_sum,
                    'inconsistency': original_inconsistency,
                    'improvement': original_inconsistency < 1e-10
                }
        
        return reconciliation_metrics
    
    def calculate_crps(self, predictions: np.ndarray, actual: np.ndarray) -> float:
        """
        Calculate Continuous Ranked Probability Score (CRPS).
        
        Parameters:
        -----------
        predictions : np.ndarray
            Bootstrap predictions
        actual : np.ndarray
            Actual values
            
        Returns:
        --------
        float
            CRPS value
        """
        # Simplified CRPS calculation
        min_len = min(len(actual), len(predictions[0]))
        act = actual[:min_len]
        pred = predictions[:, :min_len]
        
        # Calculate CRPS for each horizon
        crps_scores = []
        for i in range(min_len):
            # CRPS = mean(|pred - actual|) - 0.5 * mean(|pred_i - pred_j|)
            pred_i = pred[:, i]
            act_i = act[i]
            
            term1 = np.mean(np.abs(pred_i - act_i))
            term2 = 0.5 * np.mean(np.abs(pred_i[:, None] - pred_i[None, :]))
            
            crps = term1 - term2
            crps_scores.append(crps)
        
        return np.mean(crps_scores)
    
    def generate_evaluation_report(self, evaluation_results: Dict) -> str:
        """
        Generate a comprehensive evaluation report.
        
        Parameters:
        -----------
        evaluation_results : Dict
            Evaluation results
            
        Returns:
        --------
        str
            Formatted evaluation report
        """
        report = []
        report.append("📊 FORECAST EVALUATION REPORT")
        report.append("=" * 50)
        
        # Accuracy metrics
        if 'accuracy' in evaluation_results:
            acc = evaluation_results['accuracy']
            report.append("\n🎯 ACCURACY METRICS:")
            report.append(f"   MAE:  {acc['mae']:.2f}")
            report.append(f"   RMSE: {acc['rmse']:.2f}")
            report.append(f"   MAPE: {acc['mape']:.2f}%")
            report.append(f"   Bias: {acc['bias']:.2f}")
            report.append(f"   Correlation: {acc['correlation']:.3f}")
        
        # Uncertainty metrics
        if 'uncertainty' in evaluation_results:
            unc = evaluation_results['uncertainty']
            report.append("\n📈 UNCERTAINTY METRICS:")
            if 'coverage' in unc:
                report.append(f"   80% Coverage: {unc['coverage']['80%']:.1%}")
                report.append(f"   95% Coverage: {unc['coverage']['95%']:.1%}")
            report.append(f"   Mean Std: {np.mean(unc['std']):.2f}")
        
        # Reconciliation metrics
        if 'reconciliation' in evaluation_results:
            rec = evaluation_results['reconciliation']
            report.append("\n🔄 RECONCILIATION METRICS:")
            for method, metrics in rec.items():
                status = "✅" if metrics['improvement'] else "⚠️"
                report.append(f"   {method}: {status} Inconsistency: {metrics['inconsistency']:.6f}")
        
        return "\n".join(report) 