"""
Reconciliation module for pyPrecipTHR

This module contains hierarchical reconciliation methods for ensuring
consistency across different temporal scales.
"""

import numpy as np
from typing import Dict, Optional
import warnings
warnings.filterwarnings('ignore')


class MinTReconciliation:
    """
    Minimum Trace (MinT) reconciliation method.
    
    This method minimizes the trace of the covariance matrix of the
    reconciled forecasts while maintaining hierarchical consistency.
    """
    
    def __init__(self):
        pass
    
    def reconcile(self, forecasts: np.ndarray, S: np.ndarray, 
                  covariance_matrix: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Apply MinT reconciliation.
        
        Parameters:
        -----------
        forecasts : np.ndarray
            Vector of forecasts at different frequencies
        S : np.ndarray
            Aggregation matrix
        covariance_matrix : Optional[np.ndarray]
            Covariance matrix of forecasts (identity if None)
            
        Returns:
        --------
        np.ndarray
            Reconciled forecasts
        """
        n_forecasts = len(forecasts)
        
        # Use identity matrix if no covariance matrix provided
        if covariance_matrix is None:
            covariance_matrix = np.eye(n_forecasts)
        
        try:
            # MinT formula: y_reconciled = S * (S^T * W^(-1) * S)^(-1) * S^T * W^(-1) * y
            W_inv = np.linalg.inv(covariance_matrix)
            
            # Calculate reconciliation matrix
            temp = S.T @ W_inv @ S
            temp_inv = np.linalg.inv(temp)
            P = S @ temp_inv @ S.T @ W_inv
            
            # Apply reconciliation
            reconciled_forecasts = P @ forecasts
            
            return reconciled_forecasts
            
        except np.linalg.LinAlgError as e:
            print(f"   ⚠️ MinT reconciliation failed due to singular matrix: {e}")
            return forecasts
    
    def calculate_covariance_matrix(self, forecasts: np.ndarray, 
                                  historical_errors: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Calculate covariance matrix for MinT reconciliation.
        
        Parameters:
        -----------
        forecasts : np.ndarray
            Forecasts at different frequencies
        historical_errors : Optional[np.ndarray]
            Historical forecast errors for covariance estimation
            
        Returns:
        --------
        np.ndarray
            Covariance matrix
        """
        n_forecasts = len(forecasts)
        
        if historical_errors is not None:
            # Use historical errors to estimate covariance
            covariance_matrix = np.cov(historical_errors.T)
        else:
            # Use diagonal matrix with forecast variances
            variances = np.var(forecasts) * np.ones(n_forecasts)
            covariance_matrix = np.diag(variances)
        
        return covariance_matrix


class OLSReconciliation:
    """
    Ordinary Least Squares (OLS) reconciliation method.
    
    This method uses OLS to find reconciled forecasts that minimize
    the sum of squared differences while maintaining consistency.
    """
    
    def __init__(self):
        pass
    
    def reconcile(self, forecasts: np.ndarray, S: np.ndarray) -> np.ndarray:
        """
        Apply OLS reconciliation.
        
        Parameters:
        -----------
        forecasts : np.ndarray
            Vector of forecasts at different frequencies
        S : np.ndarray
            Aggregation matrix
            
        Returns:
        --------
        np.ndarray
            Reconciled forecasts
        """
        try:
            # OLS formula: y_reconciled = S * (S^T * S)^(-1) * S^T * y
            temp = S.T @ S
            temp_inv = np.linalg.inv(temp)
            P = S @ temp_inv @ S.T
            
            # Apply reconciliation
            reconciled_forecasts = P @ forecasts
            
            return reconciled_forecasts
            
        except np.linalg.LinAlgError as e:
            print(f"   ⚠️ OLS reconciliation failed due to singular matrix: {e}")
            return forecasts


class ReconciliationEvaluator:
    """
    Evaluator for reconciliation methods.
    """
    
    def __init__(self):
        pass
    
    def evaluate_reconciliation(self, original_forecasts: np.ndarray,
                              reconciled_forecasts: np.ndarray,
                              S: np.ndarray) -> Dict:
        """
        Evaluate the quality of reconciliation.
        
        Parameters:
        -----------
        original_forecasts : np.ndarray
            Original forecasts before reconciliation
        reconciled_forecasts : np.ndarray
            Reconciled forecasts
        S : np.ndarray
            Aggregation matrix
            
        Returns:
        --------
        Dict
            Evaluation metrics
        """
        # Check hierarchical consistency
        original_inconsistency = self._calculate_inconsistency(original_forecasts, S)
        reconciled_inconsistency = self._calculate_inconsistency(reconciled_forecasts, S)
        
        # Calculate improvement
        improvement = original_inconsistency - reconciled_inconsistency
        
        # Calculate forecast changes
        forecast_changes = np.abs(reconciled_forecasts - original_forecasts)
        mean_change = np.mean(forecast_changes)
        max_change = np.max(forecast_changes)
        
        return {
            'original_inconsistency': original_inconsistency,
            'reconciled_inconsistency': reconciled_inconsistency,
            'improvement': improvement,
            'mean_forecast_change': mean_change,
            'max_forecast_change': max_change,
            'consistency_achieved': reconciled_inconsistency < 1e-10
        }
    
    def _calculate_inconsistency(self, forecasts: np.ndarray, S: np.ndarray) -> float:
        """
        Calculate hierarchical inconsistency.
        
        Parameters:
        -----------
        forecasts : np.ndarray
            Forecasts at different frequencies
        S : np.ndarray
            Aggregation matrix
            
        Returns:
        --------
        float
            Measure of inconsistency
        """
        # Calculate aggregated forecasts
        aggregated = S @ forecasts
        
        # Calculate inconsistency as sum of squared differences
        # between forecasts and their aggregated counterparts
        inconsistency = np.sum((forecasts - aggregated) ** 2)
        
        return inconsistency
    
    def compare_methods(self, forecasts: np.ndarray, S: np.ndarray,
                       mint_result: np.ndarray, ols_result: np.ndarray) -> Dict:
        """
        Compare different reconciliation methods.
        
        Parameters:
        -----------
        forecasts : np.ndarray
            Original forecasts
        S : np.ndarray
            Aggregation matrix
        mint_result : np.ndarray
            MinT reconciled forecasts
        ols_result : np.ndarray
            OLS reconciled forecasts
            
        Returns:
        --------
        Dict
            Comparison results
        """
        # Evaluate each method
        mint_eval = self.evaluate_reconciliation(forecasts, mint_result, S)
        ols_eval = self.evaluate_reconciliation(forecasts, ols_result, S)
        
        # Determine best method
        if mint_eval['reconciled_inconsistency'] < ols_eval['reconciled_inconsistency']:
            best_method = 'MinT'
        else:
            best_method = 'OLS'
        
        return {
            'MinT': mint_eval,
            'OLS': ols_eval,
            'best_method': best_method,
            'comparison': {
                'inconsistency_reduction': {
                    'MinT': mint_eval['improvement'],
                    'OLS': ols_eval['improvement']
                },
                'forecast_stability': {
                    'MinT': mint_eval['mean_forecast_change'],
                    'OLS': ols_eval['mean_forecast_change']
                }
            }
        } 