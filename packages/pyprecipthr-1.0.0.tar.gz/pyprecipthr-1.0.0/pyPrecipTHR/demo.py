"""
Demo module for Flexible pyPrecipTHR Package

This module provides command-line access to demonstrate the package features.
"""

import sys
import argparse
from pyPrecipTHR import (
    FlexibleTemporalHierarchicalReconciliation,
    ModelRegistry,
    RandomForestModel,
    ETSModel,
    SARIMAModel,
    LinearRegressionModel,
    GradientBoostingModel,
    EnsembleModel,
    BaseModel
)


def demo_basic():
    """Run basic demonstration."""
    print("🚀 FLEXIBLE PYPRECIPTHR PACKAGE DEMO")
    print("="*50)
    
    # Show available models
    registry = ModelRegistry()
    print(f"Available models: {registry.list_models()}")
    
    # Initialize with different models
    models = ['random_forest', 'ets', 'sarima']
    
    for model_name in models:
        print(f"\n🔧 Testing {model_name.upper()}:")
        thr = FlexibleTemporalHierarchicalReconciliation(
            model_name=model_name,
            n_bootstrap=100
        )
        print(f"   Model: {thr.model_name}")
        print(f"   Type: {type(thr.model).__name__}")
    
    print("\n✅ Basic demo completed!")


def demo_switching():
    """Run model switching demonstration."""
    print("🔄 MODEL SWITCHING DEMO")
    print("="*50)
    
    thr = FlexibleTemporalHierarchicalReconciliation(model_name='random_forest')
    print(f"Initial model: {thr.model_name}")
    
    # Switch models
    for model_name in ['ets', 'sarima', 'random_forest']:
        thr.switch_model(model_name)
        print(f"Switched to: {thr.model_name}")
    
    print("✅ Model switching demo completed!")


def demo_custom():
    """Run custom model demonstration."""
    print("🔧 CUSTOM MODELS DEMO")
    print("="*50)
    
    # Register custom models
    thr = FlexibleTemporalHierarchicalReconciliation()
    thr.register_custom_model('linear_regression', LinearRegressionModel)
    thr.register_custom_model('gradient_boosting', GradientBoostingModel)
    
    print(f"Available models: {thr.get_available_models()}")
    
    # Use custom model
    thr.switch_model('linear_regression', alpha=0.5)
    print(f"Using custom model: {thr.model_name}")
    
    print("✅ Custom models demo completed!")


def demo_ensemble():
    """Run ensemble model demonstration."""
    print("🏗️ ENSEMBLE MODEL DEMO")
    print("="*50)
    
    # Create ensemble
    ensemble_models = [
        RandomForestModel(n_bootstrap=50),
        LinearRegressionModel(n_bootstrap=50),
        GradientBoostingModel(n_bootstrap=50)
    ]
    
    ensemble = EnsembleModel(n_bootstrap=100, models=ensemble_models)
    
    thr = FlexibleTemporalHierarchicalReconciliation(
        custom_model=ensemble,
        n_bootstrap=100
    )
    
    print(f"Ensemble with {len(ensemble_models)} models")
    print(f"Model type: {type(thr.model).__name__}")
    
    print("✅ Ensemble demo completed!")


def main():
    """Main entry point for command-line demo."""
    parser = argparse.ArgumentParser(
        description="Flexible pyPrecipTHR Package Demo",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pyPrecipTHR-demo basic          # Run basic demo
  pyPrecipTHR-demo switching      # Run model switching demo
  pyPrecipTHR-demo custom         # Run custom models demo
  pyPrecipTHR-demo ensemble       # Run ensemble demo
  pyPrecipTHR-demo all            # Run all demos
        """
    )
    
    parser.add_argument(
        'demo_type',
        choices=['basic', 'switching', 'custom', 'ensemble', 'all'],
        help='Type of demo to run'
    )
    
    args = parser.parse_args()
    
    if args.demo_type == 'basic':
        demo_basic()
    elif args.demo_type == 'switching':
        demo_switching()
    elif args.demo_type == 'custom':
        demo_custom()
    elif args.demo_type == 'ensemble':
        demo_ensemble()
    elif args.demo_type == 'all':
        demo_basic()
        print("\n" + "="*50)
        demo_switching()
        print("\n" + "="*50)
        demo_custom()
        print("\n" + "="*50)
        demo_ensemble()
        print("\n" + "="*50)
        print("🎉 ALL DEMOS COMPLETED!")
    
    print("\n📚 For more information, see README_FLEXIBLE.md")


if __name__ == "__main__":
    main() 