"""
Uncertainty quantification module for pyPrecipTHR

This module provides methods for quantifying forecast uncertainty
through bootstrap and quantile-based approaches.
"""

import numpy as np
from typing import Dict, Optional
import warnings
warnings.filterwarnings('ignore')


class BootstrapUncertainty:
    """
    Bootstrap-based uncertainty quantification.
    
    This class provides robust methods for estimating forecast uncertainty
    through bootstrap sampling and prediction intervals.
    """
    
    def __init__(self, n_bootstrap: int = 500):
        self.n_bootstrap = n_bootstrap
    
    def calculate_prediction_intervals(self, predictions: np.ndarray, 
                                     confidence_levels: list = [0.8, 0.95]) -> Dict:
        """
        Calculate prediction intervals from bootstrap predictions.
        
        Parameters:
        -----------
        predictions : np.ndarray
            Bootstrap predictions (n_bootstrap x n_horizon)
        confidence_levels : list
            List of confidence levels (e.g., [0.8, 0.95])
            
        Returns:
        --------
        Dict
            Prediction intervals for each confidence level
        """
        intervals = {}
        
        for level in confidence_levels:
            alpha = 1 - level
            lower_percentile = (alpha / 2) * 100
            upper_percentile = (1 - alpha / 2) * 100
            
            lower = np.percentile(predictions, lower_percentile, axis=0)
            upper = np.percentile(predictions, upper_percentile, axis=0)
            
            intervals[f'{int(level*100)}%'] = {
                'lower': lower,
                'upper': upper,
                'width': upper - lower
            }
        
        # Add median
        intervals['median'] = np.median(predictions, axis=0)
        
        return intervals
    
    def calculate_coverage(self, intervals: Dict, actual_values: np.ndarray) -> Dict:
        """
        Calculate empirical coverage of prediction intervals.
        
        Parameters:
        -----------
        intervals : Dict
            Prediction intervals
        actual_values : np.ndarray
            Actual values for coverage calculation
            
        Returns:
        --------
        Dict
            Coverage statistics
        """
        coverage_stats = {}
        
        for level_name, interval_data in intervals.items():
            if level_name == 'median':
                continue
                
            lower = interval_data['lower']
            upper = interval_data['upper']
            
            # Calculate coverage
            covered = (actual_values >= lower) & (actual_values <= upper)
            coverage_rate = np.mean(covered)
            
            coverage_stats[level_name] = {
                'coverage_rate': coverage_rate,
                'expected_coverage': float(level_name.replace('%', '')) / 100,
                'calibration_error': abs(coverage_rate - float(level_name.replace('%', '')) / 100)
            }
        
        return coverage_stats


class QuantileUncertainty:
    """
    Quantile-based uncertainty quantification.
    
    This class provides methods for uncertainty quantification based on
    quantile regression and empirical quantiles.
    """
    
    def __init__(self):
        pass
    
    def calculate_quantiles(self, predictions: np.ndarray, 
                           quantiles: list = [0.1, 0.25, 0.5, 0.75, 0.9]) -> Dict:
        """
        Calculate quantiles from bootstrap predictions.
        
        Parameters:
        -----------
        predictions : np.ndarray
            Bootstrap predictions
        quantiles : list
            List of quantiles to calculate
            
        Returns:
        --------
        Dict
            Quantile values for each specified quantile
        """
        quantile_values = {}
        
        for q in quantiles:
            quantile_values[f'q{int(q*100)}'] = np.percentile(predictions, q * 100, axis=0)
        
        return quantile_values
    
    def calculate_uncertainty_measures(self, predictions: np.ndarray) -> Dict:
        """
        Calculate various uncertainty measures.
        
        Parameters:
        -----------
        predictions : np.ndarray
            Bootstrap predictions
            
        Returns:
        --------
        Dict
            Uncertainty measures
        """
        # Calculate basic statistics
        mean_pred = np.mean(predictions, axis=0)
        median_pred = np.median(predictions, axis=0)
        std_pred = np.std(predictions, axis=0)
        
        # Calculate interquartile range
        q25 = np.percentile(predictions, 25, axis=0)
        q75 = np.percentile(predictions, 75, axis=0)
        iqr = q75 - q25
        
        # Calculate coefficient of variation
        cv = std_pred / (mean_pred + 1e-8)  # Add small constant to avoid division by zero
        
        return {
            'mean': mean_pred,
            'median': median_pred,
            'std': std_pred,
            'iqr': iqr,
            'cv': cv,
            'range': np.max(predictions, axis=0) - np.min(predictions, axis=0)
        } 