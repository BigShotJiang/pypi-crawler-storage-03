"""Utility functions for the MontyCloud DAY2 CLI."""

from day2_cli.utils.formatters import format_error

__all__ = ["format_error"]
