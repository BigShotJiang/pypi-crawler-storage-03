import os


def install_windows():
    print(f"\n\nPreparing directory\n\n{os.getcwd()}\n{os.path.realpath(__file__)}\n\n")


install_windows()
