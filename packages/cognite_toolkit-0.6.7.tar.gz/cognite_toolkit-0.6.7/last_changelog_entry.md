## cdf 

### Added

- [alpha] New command `cdf download` and with the subcommand `cdf
download raw`.

## templates

No changes.