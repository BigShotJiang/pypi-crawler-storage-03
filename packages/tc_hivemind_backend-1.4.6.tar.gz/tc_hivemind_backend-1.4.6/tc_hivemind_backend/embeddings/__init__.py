# flake8: noqa
from .cohere import CohereEmbedding
