#  SPDX-FileCopyrightText: Copyright (c) 2022-2024. James J. Johnson <james.x.johnson@gmail.com>
#  SPDX-License-Identifier: BSD-3-Clause
"""dirtyflags __init__.py"""

from .dirtyflags import dirtyflag as dirtyflag
