from deltalake import Field, Schema


payload: Schema = Schema([
  Field('payload', 'string')
])
