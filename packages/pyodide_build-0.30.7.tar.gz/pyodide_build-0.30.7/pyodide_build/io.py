# TODO: Remove me after we release Pyodide 0.28
from pyodide_build.recipe.spec import MetaConfig

__all__ = ["MetaConfig"]
