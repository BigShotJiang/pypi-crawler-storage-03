import { initializeIrvDisplay } from './irvDisplay.js';

document.addEventListener('DOMContentLoaded', () => {
    initializeIrvDisplay();
});

