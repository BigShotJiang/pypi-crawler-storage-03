from mcp.server.fastmcp import FastMCP
import requests
import json
from datetime import datetime, timedelta
import re
from urllib.parse import quote, urlencode
from typing import List, Dict, Any, Optional, Union, Tuple
from pydantic import BaseModel, Field
import time
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create an MCP server
mcp = FastMCP("Enhanced Vulnerability Scanner v2.0")

# API配置
NVD_CPE_API = "https://services.nvd.nist.gov/rest/json/cpes/2.0"
NVD_CVE_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
EPSS_API = "https://api.first.org/data/v1/epss"

# 速率限制配置
RATE_LIMIT_DELAY = 6  # 无API密钥时每6秒一次请求
RATE_LIMIT_WITH_KEY = 0.6  # 有API密钥时每0.6秒一次请求
MAX_BATCH_SIZE = 120  # NVD API单次查询最大天数限制

def resolve_cpe(product: str, version: str = "*") -> str:
    """
    根据 product/version 自动补全 vendor 和 cpe_type，生成 CPE
    改进：添加缓存和更好的错误处理
    """
    params = {"keywordSearch": product}
    try:
        response = requests.get(NVD_CPE_API, params=params, timeout=15)
        response.raise_for_status()
        data = response.json()
        
        cpe_matches = []
        
        for item in data.get("products", []):
            cpe = item.get("cpe", {}).get("cpeName")
            if not cpe:
                continue
                
            parts = cpe.split(":")
            if len(parts) < 6:
                continue

            cpe_type, vendor, prod, ver = parts[2], parts[3], parts[4], parts[5]
            
            # 精确版本匹配优先
            if version != "*" and ver == version:
                result_cpe = f"cpe:2.3:{cpe_type}:{vendor}:{prod}:{version}:*:*:*:*:*:*:*"
                logger.info(f"找到精确CPE匹配: {result_cpe}")
                return result_cpe
                
            cpe_matches.append((cpe_type, vendor, prod, ver))

        # 如果没有精确匹配，使用第一个找到的
        if cpe_matches:
            cpe_type, vendor, prod, ver = cpe_matches[0]
            result_cpe = f"cpe:2.3:{cpe_type}:{vendor}:{prod}:{version}:*:*:*:*:*:*:*"
            logger.info(f"使用模糊CPE匹配: {result_cpe}")
            return result_cpe
            
    except Exception as e:
        logger.warning(f"CPE解析失败: {e}")

    # fallback
    fallback_cpe = f"cpe:2.3:a:*:{product}:{version}:*:*:*:*:*:*:*"
    logger.info(f"使用fallback CPE: {fallback_cpe}")
    return fallback_cpe

class DateRangeManager:
    """日期范围管理器 - 处理长时间范围的分批查询"""
    
    @staticmethod
    def parse_date(date_input: Union[str, datetime]) -> datetime:
        """解析日期输入"""
        if isinstance(date_input, datetime):
            return date_input
        elif isinstance(date_input, str):
            # 支持多种日期格式
            formats = [
                '%Y-%m-%d',
                '%Y/%m/%d', 
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%dT%H:%M:%SZ'
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(date_input, fmt)
                except ValueError:
                    continue
            
            raise ValueError(f"无法解析日期格式: {date_input}")
        else:
            raise TypeError(f"不支持的日期类型: {type(date_input)}")

    @staticmethod
    def format_for_api(dt: datetime) -> str:
        """格式化日期为NVD API格式"""
        return dt.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'

    @staticmethod
    def calculate_batches(start_date: datetime, end_date: datetime, max_days: int = MAX_BATCH_SIZE) -> List[Tuple[datetime, datetime]]:
        """计算需要分批查询的日期范围"""
        batches = []
        current_start = start_date
        
        while current_start <= end_date:
            current_end = min(current_start + timedelta(days=max_days), end_date)
            batches.append((current_start, current_end))
            current_start = current_end + timedelta(days=1)
            
        return batches

    @classmethod
    def create_flexible_date_range(cls, 
                                 start_date: Optional[str] = None,
                                 end_date: Optional[str] = None,
                                 days_back: Optional[int] = None,
                                 months_back: Optional[int] = None,
                                 years_back: Optional[int] = None) -> Tuple[datetime, datetime, List[Tuple[datetime, datetime]]]:
        """
        创建灵活的日期范围，支持长时间跨度的分批处理
        
        Returns:
            Tuple[原始开始时间, 原始结束时间, 分批时间列表]
        """
        now = datetime.now()
        
        # 确定日期范围
        if start_date and end_date:
            start_dt = cls.parse_date(start_date)
            end_dt = cls.parse_date(end_date)
        elif days_back:
            start_dt = now - timedelta(days=days_back)
            end_dt = now
        elif years_back:
            start_dt = now - timedelta(days=years_back * 365)
            end_dt = now
        elif months_back:
            start_dt = now - timedelta(days=months_back * 30)
            end_dt = now

        else:
            # 默认最近3个月
            start_dt = now - timedelta(days=90)
            end_dt = now
        
        # 确保开始时间不晚于结束时间
        if start_dt > end_dt:
            start_dt, end_dt = end_dt, start_dt
            
        # 计算分批
        batches = cls.calculate_batches(start_dt, end_dt)
        
        return start_dt, end_dt, batches

class AdvancedVulnerabilityScanner:
    """增强版漏洞扫描器"""
    
    def __init__(self, api_key=None):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Enhanced-Vuln-Scanner/2.0 (Security Research)',
            'Accept': 'application/json',
            'Accept-Encoding': 'gzip, deflate'
        })
        
        # API密钥配置
        self.api_key = api_key
        self.rate_limit_delay = RATE_LIMIT_WITH_KEY if api_key else RATE_LIMIT_DELAY
        
        if api_key:
            self.session.headers.update({'apiKey': api_key})
            logger.info("使用API密钥，启用高速率限制模式")
        else:
            logger.info("未使用API密钥，使用标准速率限制")
        
        self.base_url = NVD_CVE_API
        self.last_request_time = 0
        
        # 严重程度映射
        self.severity_levels = {
            'LOW': 1,
            'MEDIUM': 2, 
            'HIGH': 3,
            'CRITICAL': 4
        }
        
        # 利用检测关键词
        self.exploit_keywords = [
            'exploit', 'poc', 'proof of concept', 'metasploit', 'nuclei',
            'exploit-db', 'github', 'code execution', 'remote code execution',
            'rce', 'arbitrary code', 'shell', 'payload', 'weaponized',
            'public exploit', 'exploit available', 'exploit code'
        ]

    def _rate_limit(self):
        """实现速率限制"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.rate_limit_delay:
            sleep_time = self.rate_limit_delay - time_since_last
            logger.debug(f"速率限制等待 {sleep_time:.2f} 秒")
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()

    def build_nvd_query_params(self, **kwargs):
        """构建NVD API 2.0查询参数"""
        params = {}
        
        # 基本查询参数
        if kwargs.get('cve_id'):
            params['cveId'] = kwargs['cve_id']
        
        if kwargs.get('cpe_name'):
            params['cpeName'] = kwargs['cpe_name']
        
        if kwargs.get('keyword_search'):
            params['keywordSearch'] = kwargs['keyword_search']
            if kwargs.get('keyword_exact_match'):
                params['keywordExactMatch'] = ''
        
        if kwargs.get('source_identifier'):
            params['sourceIdentifier'] = kwargs['source_identifier']
        
        # CVSS参数
        if kwargs.get('cvss_v3_severity'):
            params['cvssV3Severity'] = kwargs['cvss_v3_severity']
        
        if kwargs.get('cvss_v2_severity'):
            params['cvssV2Severity'] = kwargs['cvss_v2_severity']
        
        # CWE参数
        if kwargs.get('cwe_id'):
            params['cweId'] = kwargs['cwe_id']
        
        # 特殊标志
        if kwargs.get('has_kev'):
            params['hasKev'] = ''
        
        if kwargs.get('no_rejected'):
            params['noRejected'] = ''
        
        # 日期范围参数
        if kwargs.get('pub_start_date') and kwargs.get('pub_end_date'):
            params['pubStartDate'] = kwargs['pub_start_date']
            params['pubEndDate'] = kwargs['pub_end_date']
        
        if kwargs.get('mod_start_date') and kwargs.get('mod_end_date'):
            params['modStartDate'] = kwargs['mod_start_date']
            params['modEndDate'] = kwargs['mod_end_date']
        
        # 分页
        params['resultsPerPage'] = min(kwargs.get('results_per_page', 2000), 2000)
        params['startIndex'] = kwargs.get('start_index', 0)
        
        return params

    def search_nvd_vulnerabilities_single(self, **kwargs):
        """单次NVD漏洞搜索"""
        self._rate_limit()
        params = self.build_nvd_query_params(**kwargs)
        
        try:
            response = self.session.get(self.base_url, params=params, timeout=30)
            logger.debug(f"API请求URL: {response.url}")
            print(f"API请求URL: {response.url}")
            if response.status_code == 200:
                data = response.json()
                vulnerabilities = []
                
                for vuln in data.get('vulnerabilities', []):
                    cve = vuln.get('cve', {})
                    vuln_info = self.extract_vulnerability_info(cve)
                    vulnerabilities.append(vuln_info)
                
                return {
                    'vulnerabilities': vulnerabilities,
                    'total_results': data.get('totalResults', 0),
                    'results_per_page': data.get('resultsPerPage', 0),
                    'start_index': data.get('startIndex', 0),
                    'success': True
                }
            elif response.status_code == 403:
                return {
                    'vulnerabilities': [],
                    'total_results': 0,
                    'error': 'API访问被拒绝，请检查API密钥或降低请求频率',
                    'success': False
                }
            else:
                return {
                    'vulnerabilities': [],
                    'total_results': 0,
                    'error': f'API请求失败，状态码: {response.status_code}',
                    'success': False
                }
                
        except Exception as e:
            logger.error(f"API请求异常: {e}")
            return {
                'vulnerabilities': [],
                'total_results': 0,
                'error': f'请求异常: {str(e)}',
                'success': False
            }

    def search_nvd_vulnerabilities_batch(self, 
                                       date_batches: List[Tuple[datetime, datetime]],
                                       **kwargs) -> Dict[str, Any]:
        """
        分批搜索NVD漏洞，支持长时间范围
        """
        all_vulnerabilities = []
        batch_info = []
        total_found = 0
        
        logger.info(f"开始分批查询，共{len(date_batches)}批")
        
        for i, (start_dt, end_dt) in enumerate(date_batches, 1):
            logger.info(f"执行第{i}/{len(date_batches)}批查询: {start_dt.date()} 到 {end_dt.date()}")
            
            # 准备当前批次的参数
            batch_kwargs = kwargs.copy()
            batch_kwargs['pub_start_date'] = DateRangeManager.format_for_api(start_dt)
            batch_kwargs['pub_end_date'] = DateRangeManager.format_for_api(end_dt)
            
            # 执行单批查询
            batch_result = self.search_nvd_vulnerabilities_single(**batch_kwargs)
            
            if batch_result['success']:
                vulnerabilities = batch_result['vulnerabilities']
                all_vulnerabilities.extend(vulnerabilities)
                
                batch_info.append({
                    'batch_number': i,
                    'start_date': start_dt.isoformat(),
                    'end_date': end_dt.isoformat(),
                    'found_count': len(vulnerabilities),
                    'api_total': batch_result.get('total_results', 0)
                })
                
                logger.info(f"第{i}批完成，找到{len(vulnerabilities)}个漏洞")
            else:
                logger.error(f"第{i}批查询失败: {batch_result.get('error', 'Unknown error')}")
                batch_info.append({
                    'batch_number': i,
                    'start_date': start_dt.isoformat(),
                    'end_date': end_dt.isoformat(),
                    'found_count': 0,
                    'error': batch_result.get('error', 'Unknown error')
                })
        
        # 去重（基于CVE ID）
        unique_vulns = {}
        for vuln in all_vulnerabilities:
            cve_id = vuln.get('id')
            if cve_id and cve_id not in unique_vulns:
                unique_vulns[cve_id] = vuln
        
        final_vulnerabilities = list(unique_vulns.values())
        
        # 按发布日期排序（最新的在前）
        final_vulnerabilities.sort(
            key=lambda x: x.get('published', ''), 
            reverse=True
        )
        
        return {
            'vulnerabilities': final_vulnerabilities,
            'total_results': len(final_vulnerabilities),
            'batch_info': batch_info,
            'query_summary': {
                'total_batches': len(date_batches),
                'successful_batches': len([b for b in batch_info if 'error' not in b]),
                'failed_batches': len([b for b in batch_info if 'error' in b]),
                'unique_vulnerabilities': len(final_vulnerabilities),
                'duplicates_removed': len(all_vulnerabilities) - len(final_vulnerabilities)
            },
            'success': True
        }

    def extract_vulnerability_info(self, cve):
        """提取完整的漏洞信息"""
        vuln_info = {
            'id': cve.get('id', 'N/A'),
            'source_identifier': cve.get('sourceIdentifier', 'N/A'),
            'published': cve.get('published', 'N/A'),
            'last_modified': cve.get('lastModified', 'N/A'),
            'vuln_status': cve.get('vulnStatus', 'N/A'),
        }
        
        # 描述
        descriptions = cve.get('descriptions', [])
        for desc in descriptions:
            if desc.get('lang') == 'en':
                vuln_info['description'] = desc.get('value', 'No description available')
                break
        else:
            vuln_info['description'] = descriptions[0].get('value', 'No description available') if descriptions else 'No description available'
        
        # CVSS信息
        self.extract_cvss_metrics(cve, vuln_info)
        
        # 引用链接
        vuln_info['references'] = self.extract_references(cve)
        
        # CWE信息
        vuln_info['cwe_ids'] = self.extract_cwe_info(cve)
        
        # CISA KEV信息
        self.extract_kev_info(cve, vuln_info)
        
        # 利用检测
        vuln_info['has_exploit'] = self.detect_exploit_indicators(cve, vuln_info['references'])
        vuln_info['exploit_confidence'] = vuln_info['has_exploit']['confidence'] if vuln_info['has_exploit'] else 0
        
        return vuln_info

    def extract_cvss_metrics(self, cve, vuln_info):
        """提取CVSS评分信息"""
        vuln_info['cvss_v2'] = None
        vuln_info['cvss_v3'] = None
        vuln_info['cvss_score'] = 'N/A'
        vuln_info['severity'] = 'N/A'
        
        if 'metrics' in cve:
            metrics = cve['metrics']
            
            # CVSS v3.1/v3.0 (优先)
            if 'cvssMetricV31' in metrics and metrics['cvssMetricV31']:
                cvss31 = metrics['cvssMetricV31'][0]
                vuln_info['cvss_v3'] = cvss31
                cvss_data = cvss31.get('cvssData', {})
                vuln_info['cvss_score'] = cvss_data.get('baseScore', 'N/A')
                vuln_info['severity'] = cvss_data.get('baseSeverity', 'N/A')
            
            elif 'cvssMetricV30' in metrics and metrics['cvssMetricV30']:
                cvss30 = metrics['cvssMetricV30'][0]
                vuln_info['cvss_v3'] = cvss30
                cvss_data = cvss30.get('cvssData', {})
                vuln_info['cvss_score'] = cvss_data.get('baseScore', 'N/A')
                vuln_info['severity'] = cvss_data.get('baseSeverity', 'N/A')
            
            # CVSS v2 作为后备
            elif 'cvssMetricV2' in metrics and metrics['cvssMetricV2']:
                cvss2 = metrics['cvssMetricV2'][0]
                vuln_info['cvss_v2'] = cvss2
                cvss_data = cvss2.get('cvssData', {})
                vuln_info['cvss_score'] = cvss_data.get('baseScore', 'N/A')
                vuln_info['severity'] = cvss2.get('baseSeverity', 'N/A')

    def extract_references(self, cve):
        """提取CVE引用链接"""
        references = []
        try:
            refs = cve.get('references', [])
            for ref in refs:
                ref_info = {
                    'url': ref.get('url', ''),
                    'source': ref.get('source', ''),
                    'tags': ref.get('tags', [])
                }
                references.append(ref_info)
        except:
            pass
        return references

    def extract_cwe_info(self, cve):
        """提取CWE弱点信息"""
        cwe_ids = []
        try:
            weaknesses = cve.get('weaknesses', [])
            for weakness in weaknesses:
                for desc in weakness.get('description', []):
                    cwe_id = desc.get('value', '')
                    if cwe_id.startswith('CWE-') or cwe_id.startswith('NVD-CWE-'):
                        cwe_ids.append(cwe_id)
        except:
            pass
        return list(set(cwe_ids))

    def extract_kev_info(self, cve, vuln_info):
        """提取CISA KEV信息"""
        vuln_info['cisa_exploit_add'] = cve.get('cisaExploitAdd', None)
        vuln_info['cisa_action_due'] = cve.get('cisaActionDue', None)
        vuln_info['cisa_required_action'] = cve.get('cisaRequiredAction', None)
        vuln_info['cisa_vulnerability_name'] = cve.get('cisaVulnerabilityName', None)

    def detect_exploit_indicators(self, cve, references):
        """检测漏洞是否有公开利用代码"""
        exploit_indicators = {
            'found': False,
            'confidence': 0,
            'sources': [],
            'indicators': []
        }
        
        # 检查描述关键词
        descriptions = cve.get('descriptions', [])
        for desc in descriptions:
            if desc.get('lang') == 'en':
                description = desc.get('value', '').lower()
                desc_matches = []
                for keyword in self.exploit_keywords:
                    if keyword in description:
                        desc_matches.append(keyword)
                
                if desc_matches:
                    exploit_indicators['confidence'] += 20
                    exploit_indicators['indicators'].extend(desc_matches)
                break
        
        # 检查引用URL和标签
        exploit_sources = []
        for ref in references:
            url = ref.get('url', '').lower()
            tags = [tag.lower() for tag in ref.get('tags', [])]
            
            # 检查已知利用源
            if any(source in url for source in ['exploit-db', 'github.com', 'metasploit']):
                exploit_indicators['confidence'] += 40
                exploit_sources.append(ref.get('url', ''))
            
            # 检查标签
            if 'exploit' in tags or 'proof-of-concept' in tags:
                exploit_indicators['confidence'] += 30
                exploit_sources.append(ref.get('url', ''))
        
        exploit_indicators['sources'] = list(set(exploit_sources))
        
        # 检查CISA KEV
        if cve.get('cisaExploitAdd'):
            exploit_indicators['confidence'] += 50
            exploit_indicators['indicators'].append('CISA KEV Listed')
        
        exploit_indicators['found'] = exploit_indicators['confidence'] > 30
        
        return exploit_indicators if exploit_indicators['found'] else None

# 全局扫描器实例
scanner = AdvancedVulnerabilityScanner()

# --- 优化后的MCP工具 ---

@mcp.tool()
def search_vulnerabilities_by_product_version(
    product: str, 
    version: str = "*", 
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: Optional[int] = None,
    years_back: Optional[int] = None,
    min_severity: str = "",
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    按产品名和版本查询漏洞 - 支持灵活的时间范围
    
    Args:
        product: 产品名称 (如: tomcat, apache, windows)
        version: 版本号 (默认: "*" 表示所有版本)
        start_date: 开始日期 (格式: YYYY-MM-DD 或 YYYY-MM-DD HH:MM:SS)
        end_date: 结束日期 (格式同上)
        months_back: 向前查询多少个月 (如果未指定start_date/end_date)
        years_back: 向前查询多少年 (如果未指定start_date/end_date和months_back)
        min_severity: 最低严重程度 (LOW, MEDIUM, HIGH, CRITICAL)
        api_key: NVD API密钥 (提高查询速度)
        
    Returns:
        包含漏洞信息和查询统计的字典
        
    示例:
        - search_vulnerabilities_by_product_version("tomcat", "9.0", start_date="2021-02-01", end_date="2021-05-01")
        - search_vulnerabilities_by_product_version("tomcat", "*", years_back=1, min_severity="HIGH")
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 生成CPE
        cpe_name = resolve_cpe(product, version)
        logger.info(f"使用CPE: {cpe_name}")
        
        # 创建灵活的日期范围
        start_dt, end_dt, date_batches = DateRangeManager.create_flexible_date_range(
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            years_back=years_back
        )
        
        # 准备搜索参数
        if min_severity:
            search_params = {
            'cpe_name': cpe_name,
            'cvss_v3_severity': min_severity,
            'no_rejected': True,
            'results_per_page': 2000
        }
        else:
             search_params = {
            'cpe_name': cpe_name,
            'no_rejected': True,
            'results_per_page': 2000
        }           




        
        # 执行分批查询
        if len(date_batches) == 1:
            # 单批查询
            start_batch, end_batch = date_batches[0]
            search_params['pub_start_date'] = DateRangeManager.format_for_api(start_batch)
            search_params['pub_end_date'] = DateRangeManager.format_for_api(end_batch)
            results = scanner.search_nvd_vulnerabilities_single(**search_params)
        else:
            # 多批查询
            results = scanner.search_nvd_vulnerabilities_batch(date_batches, **search_params)
        
        # 添加查询信息和统计
        vulns = results.get('vulnerabilities', [])
        
        query_info = {
            'product': product,
            'version': version,
            'cpe_used': cpe_name,
            'date_range': {
                'start': start_dt.isoformat(),
                'end': end_dt.isoformat(),
                'total_days': (end_dt - start_dt).days,
                'batches_required': len(date_batches)
            },
            'filters': {
                'min_severity': min_severity
            }
        }
        
        stats = {
            'total_found': len(vulns),
            'with_exploits': sum(1 for v in vulns if v.get('has_exploit')),
            'kev_listed': sum(1 for v in vulns if v.get('cisa_exploit_add')),
            'severity_breakdown': {
                'CRITICAL': sum(1 for v in vulns if v.get('severity') == 'CRITICAL'),
                'HIGH': sum(1 for v in vulns if v.get('severity') == 'HIGH'),
                'MEDIUM': sum(1 for v in vulns if v.get('severity') == 'MEDIUM'),
                'LOW': sum(1 for v in vulns if v.get('severity') == 'LOW')
            },
            'year_breakdown': {}
        }
        
        # 按年份统计
        for vuln in vulns:
            pub_date = vuln.get('published', '')
            if pub_date:
                try:
                    year = datetime.fromisoformat(pub_date.replace('Z', '+00:00')).year
                    stats['year_breakdown'][str(year)] = stats['year_breakdown'].get(str(year), 0) + 1
                except:
                    pass
        
        results.update({
            'query_info': query_info,
            'statistics': stats
        })
        
        return results
        
    except Exception as e:
        logger.error(f"查询失败: {e}")
        return {
            'vulnerabilities': [],
            'total_results': 0,
            'error': str(e),
            'success': False
        }

@mcp.tool()
def search_vulnerabilities_by_keyword(
    keyword: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: Optional[int] = 3,
    years_back: Optional[int] = None,
    min_severity: str = "",
    api_key: Optional[str] = None,
    limit: int = 100
) -> Dict[str, Any]:
    """
    按关键词搜索漏洞 - 支持灵活的时间范围和长期查询
    
    Args:
        keyword: 产品名或关键词 (如: "apache", "tomcat", "windows server")
        start_date: 开始日期 (格式: YYYY-MM-DD)
        end_date: 结束日期 (格式: YYYY-MM-DD)
        months_back: 向前查询多少个月 (默认: 3个月)
        years_back: 向前查询多少年
        min_severity: 最低严重程度 (LOW, MEDIUM, HIGH, CRITICAL)
        api_key: NVD API密钥
        limit: 最大结果数量 (默认: 100)
        
    Returns:
        包含漏洞信息和详细统计的字典
        
    示例:
        - search_vulnerabilities_by_keyword("tomcat", start_date="2021-02-01", end_date="2021-05-01")
        - search_vulnerabilities_by_keyword("apache", years_back=1, min_severity="HIGH")
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 创建灵活的日期范围
        start_dt, end_dt, date_batches = DateRangeManager.create_flexible_date_range(
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            years_back=years_back
        )
        
        logger.info(f"查询关键词 '{keyword}' 从 {start_dt.date()} 到 {end_dt.date()}")
        
        # 准备搜索参数
        if min_severity:
            search_params = {
            'keyword_search': keyword,
            'cvss_v3_severity': min_severity,
            'no_rejected': True,
            'results_per_page': min(limit, 2000)
        }
        else:

            search_params = {
                'keyword_search': keyword,
                'no_rejected': True,
                'results_per_page': min(limit, 2000)
            }
        
        # 执行分批查询
        if len(date_batches) == 1:
            # 单批查询
            start_batch, end_batch = date_batches[0]
            search_params['pub_start_date'] = DateRangeManager.format_for_api(start_batch)
            search_params['pub_end_date'] = DateRangeManager.format_for_api(end_batch)
            results = scanner.search_nvd_vulnerabilities_single(**search_params)
        else:
            # 多批查询
            results = scanner.search_nvd_vulnerabilities_batch(date_batches, **search_params)
        
        # 限制结果数量
        vulns = results.get('vulnerabilities', [])[:limit]
        
        # 添加详细统计
        query_info = {
            'keyword': keyword,
            'date_range': {
                'start': start_dt.isoformat(),
                'end': end_dt.isoformat(),
                'total_days': (end_dt - start_dt).days,
                'batches_required': len(date_batches)
            },
            'filters': {
                'min_severity': min_severity,
                'limit': limit
            }
        }
        
        stats = generate_vulnerability_statistics(vulns)
        
        results.update({
            'vulnerabilities': vulns,
            'total_results': len(vulns),
            'query_info': query_info,
            'statistics': stats
        })
        
        return results
        
    except Exception as e:
        logger.error(f"关键词查询失败: {e}")
        return {
            'vulnerabilities': [],
            'total_results': 0,
            'error': str(e),
            'success': False
        }

@mcp.tool()
def search_high_cvss_vulnerabilities(
    keyword: str,
    min_cvss_score: float = 9.0,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: Optional[int] = 6,
    years_back: Optional[int] = None,
    api_key: Optional[str] = None,
    limit: int = 100
) -> Dict[str, Any]:
    """
    搜索高CVSS评分的漏洞 - 支持长期时间范围
    
    Args:
        keyword: 产品名或关键词
        min_cvss_score: 最低CVSS评分 (默认: 9.0)
        start_date: 开始日期 (YYYY-MM-DD)
        end_date: 结束日期 (YYYY-MM-DD)
        months_back: 向前查询月数 (默认: 6个月)
        years_back: 向前查询年数
        api_key: NVD API密钥
        limit: 最大结果数量
        
    Returns:
        高CVSS评分漏洞列表
        
    示例:
        - search_high_cvss_vulnerabilities("tomcat", min_cvss_score=8.5, years_back=1)
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 创建日期范围
        start_dt, end_dt, date_batches = DateRangeManager.create_flexible_date_range(
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            years_back=years_back
        )
        
        # 搜索参数
        search_params = {
            'keyword_search': keyword,
            'no_rejected': True,
            'results_per_page': 2000
        }
        
        # 执行查询
        if len(date_batches) == 1:
            start_batch, end_batch = date_batches[0]
            search_params['pub_start_date'] = DateRangeManager.format_for_api(start_batch)
            search_params['pub_end_date'] = DateRangeManager.format_for_api(end_batch)
            results = scanner.search_nvd_vulnerabilities_single(**search_params)
        else:
            results = scanner.search_nvd_vulnerabilities_batch(date_batches, **search_params)
        
        # 过滤高CVSS评分的漏洞
        high_cvss_vulns = []
        for vuln in results.get('vulnerabilities', []):
            cvss_score = vuln.get('cvss_score')
            if isinstance(cvss_score, (int, float)) and cvss_score >= min_cvss_score:
                high_cvss_vulns.append(vuln)
        
        # 按CVSS评分降序排序
        high_cvss_vulns.sort(
            key=lambda x: x.get('cvss_score', 0) if isinstance(x.get('cvss_score'), (int, float)) else 0,
            reverse=True
        )
        
        # 限制结果数量
        high_cvss_vulns = high_cvss_vulns[:limit]
        
        return {
            'vulnerabilities': high_cvss_vulns,
            'total_results': len(high_cvss_vulns),
            'query_info': {
                'keyword': keyword,
                'min_cvss_score': min_cvss_score,
                'date_range': {
                    'start': start_dt.isoformat(),
                    'end': end_dt.isoformat(),
                    'total_days': (end_dt - start_dt).days
                }
            },
            'statistics': generate_vulnerability_statistics(high_cvss_vulns),
            'success': True
        }
        
    except Exception as e:
        logger.error(f"高CVSS查询失败: {e}")
        return {
            'vulnerabilities': [],
            'total_results': 0,
            'error': str(e),
            'success': False
        }

@mcp.tool()
def search_kev_vulnerabilities(
    keyword: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: Optional[int] = 12,
    years_back: Optional[int] = None,
    api_key: Optional[str] = None,
    limit: int = 100
) -> Dict[str, Any]:
    """
    搜索CISA已知被利用漏洞 (KEV) - 支持长期查询
    
    Args:
        keyword: 产品名或关键词
        start_date: 开始日期
        end_date: 结束日期
        months_back: 向前查询月数 (默认: 12个月)
        years_back: 向前查询年数
        api_key: NVD API密钥
        limit: 最大结果数量
        
    Returns:
        CISA KEV漏洞列表
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 创建日期范围
        start_dt, end_dt, date_batches = DateRangeManager.create_flexible_date_range(
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            years_back=years_back
        )
        
        # 搜索参数
        search_params = {
            'keyword_search': keyword,
            'has_kev': True,
            'no_rejected': True,
            'results_per_page': limit
        }
        
        # 执行查询
        if len(date_batches) == 1:
            start_batch, end_batch = date_batches[0]
            search_params['pub_start_date'] = DateRangeManager.format_for_api(start_batch)
            search_params['pub_end_date'] = DateRangeManager.format_for_api(end_batch)
            results = scanner.search_nvd_vulnerabilities_single(**search_params)
        else:
            results = scanner.search_nvd_vulnerabilities_batch(date_batches, **search_params)
        
        # 添加KEV特定信息
        kev_vulns = results.get('vulnerabilities', [])
        
        return {
            'vulnerabilities': kev_vulns,
            'total_results': len(kev_vulns),
            'query_info': {
                'keyword': keyword,
                'filter': 'CISA KEV Only',
                'date_range': {
                    'start': start_dt.isoformat(),
                    'end': end_dt.isoformat()
                }
            },
            'statistics': generate_vulnerability_statistics(kev_vulns),
            'success': True
        }
        
    except Exception as e:
        logger.error(f"KEV查询失败: {e}")
        return {
            'vulnerabilities': [],
            'total_results': 0,
            'error': str(e),
            'success': False
        }

@mcp.tool()
def search_exploitable_vulnerabilities(
    keyword: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: Optional[int] = 12,
    years_back: Optional[int] = None,
    api_key: Optional[str] = None,
    limit: int = 100
) -> Dict[str, Any]:
    """
    搜索有已知公开利用代码的漏洞 - 支持长期查询
    
    Args:
        keyword: 产品名或关键词
        start_date: 开始日期
        end_date: 结束日期
        months_back: 向前查询月数 (默认: 12个月)
        years_back: 向前查询年数
        api_key: NVD API密钥
        limit: 最大结果数量
        
    Returns:
        有利用代码的漏洞列表
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 创建日期范围
        start_dt, end_dt, date_batches = DateRangeManager.create_flexible_date_range(
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            years_back=years_back
        )
        
        # 搜索参数
        search_params = {
            'keyword_search': keyword,
            'no_rejected': True,
            'results_per_page': 2000
        }
        
        # 执行查询
        if len(date_batches) == 1:
            start_batch, end_batch = date_batches[0]
            search_params['pub_start_date'] = DateRangeManager.format_for_api(start_batch)
            search_params['pub_end_date'] = DateRangeManager.format_for_api(end_batch)
            results = scanner.search_nvd_vulnerabilities_single(**search_params)
        else:
            results = scanner.search_nvd_vulnerabilities_batch(date_batches, **search_params)
        
        # 过滤有利用代码的漏洞
        exploit_vulns = []
        for vuln in results.get('vulnerabilities', []):
            if vuln.get('has_exploit') or vuln.get('cisa_exploit_add'):
                exploit_vulns.append(vuln)
        
        # 按利用置信度排序
        exploit_vulns.sort(
            key=lambda x: x.get('exploit_confidence', 0),
            reverse=True
        )
        
        # 限制结果
        exploit_vulns = exploit_vulns[:limit]
        
        return {
            'vulnerabilities': exploit_vulns,
            'total_results': len(exploit_vulns),
            'query_info': {
                'keyword': keyword,
                'filter': 'Has Exploits',
                'date_range': {
                    'start': start_dt.isoformat(),
                    'end': end_dt.isoformat()
                }
            },
            'statistics': generate_vulnerability_statistics(exploit_vulns),
            'exploit_analysis': analyze_exploit_sources(exploit_vulns),
            'success': True
        }
        
    except Exception as e:
        logger.error(f"利用代码查询失败: {e}")
        return {
            'vulnerabilities': [],
            'total_results': 0,
            'error': str(e),
            'success': False
        }

@mcp.tool()
def get_cve_details(cve_id: str, api_key: Optional[str] = None) -> Dict[str, Any]:
    """
    获取特定CVE的详细信息，包括EPSS评分
    
    Args:
        cve_id: CVE编号 (如: CVE-2021-44228)
        api_key: NVD API密钥
        
    Returns:
        详细的CVE信息
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 从NVD获取CVE详情
        search_params = {
            'cve_id': cve_id,
            'results_per_page': 1
        }
        
        results = scanner.search_nvd_vulnerabilities_single(**search_params)
        
        if not results.get('success') or not results.get('vulnerabilities'):
            return {
                'error': f'CVE {cve_id} 未找到或查询失败',
                'success': False
            }
        
        cve_info = results['vulnerabilities'][0]
        
        # 获取EPSS评分
        try:
            epss_response = requests.get(f"{EPSS_API}?cve={cve_id}", timeout=10)
            if epss_response.status_code == 200:
                epss_data = epss_response.json()
                if epss_data.get('status') == 'OK' and epss_data.get('total', 0) > 0:
                    epss_info = epss_data['data'][0]
                    cve_info['epss_score'] = float(epss_info.get('epss', 0))
                    cve_info['epss_percentile'] = float(epss_info.get('percentile', 0))
        except Exception as e:
            logger.warning(f"获取EPSS评分失败: {e}")
            cve_info['epss_score'] = None
            cve_info['epss_percentile'] = None
        
        # 添加风险评估
        cve_info['risk_assessment'] = assess_vulnerability_risk(cve_info)
        
        return {
            'cve_details': cve_info,
            'success': True
        }
        
    except Exception as e:
        logger.error(f"CVE详情查询失败: {e}")
        return {
            'error': str(e),
            'success': False
        }

# --- 辅助功能函数 ---

def generate_vulnerability_statistics(vulns: List[Dict]) -> Dict[str, Any]:
    """生成漏洞统计信息"""
    stats = {
        'total_found': len(vulns),
        'with_exploits': sum(1 for v in vulns if v.get('has_exploit')),
        'kev_listed': sum(1 for v in vulns if v.get('cisa_exploit_add')),
        'severity_breakdown': {
            'CRITICAL': sum(1 for v in vulns if v.get('severity') == 'CRITICAL'),
            'HIGH': sum(1 for v in vulns if v.get('severity') == 'HIGH'),
            'MEDIUM': sum(1 for v in vulns if v.get('severity') == 'MEDIUM'),
            'LOW': sum(1 for v in vulns if v.get('severity') == 'LOW')
        },
        'cvss_score_ranges': {
            '9.0-10.0': sum(1 for v in vulns if isinstance(v.get('cvss_score'), (int, float)) and 9.0 <= v.get('cvss_score') <= 10.0),
            '7.0-8.9': sum(1 for v in vulns if isinstance(v.get('cvss_score'), (int, float)) and 7.0 <= v.get('cvss_score') < 9.0),
            '4.0-6.9': sum(1 for v in vulns if isinstance(v.get('cvss_score'), (int, float)) and 4.0 <= v.get('cvss_score') < 7.0),
            '0.1-3.9': sum(1 for v in vulns if isinstance(v.get('cvss_score'), (int, float)) and 0.1 <= v.get('cvss_score') < 4.0)
        },
        'year_breakdown': {},
        'top_cwe_types': {}
    }
    
    # 按年份统计
    for vuln in vulns:
        pub_date = vuln.get('published', '')
        if pub_date:
            try:
                year = datetime.fromisoformat(pub_date.replace('Z', '+00:00')).year
                stats['year_breakdown'][str(year)] = stats['year_breakdown'].get(str(year), 0) + 1
            except:
                pass
    
    # CWE类型统计
    cwe_counts = {}
    for vuln in vulns:
        cwe_ids = vuln.get('cwe_ids', [])
        for cwe in cwe_ids:
            cwe_counts[cwe] = cwe_counts.get(cwe, 0) + 1
    
    # 取前10个最常见的CWE
    stats['top_cwe_types'] = dict(sorted(cwe_counts.items(), key=lambda x: x[1], reverse=True)[:10])
    
    return stats

def analyze_exploit_sources(vulns: List[Dict]) -> Dict[str, Any]:
    """分析利用代码来源"""
    exploit_analysis = {
        'total_with_exploits': 0,
        'kev_count': 0,
        'exploit_sources': {},
        'confidence_levels': {
            'high': 0,    # >70
            'medium': 0,  # 40-70
            'low': 0      # <40
        }
    }
    
    for vuln in vulns:
        if vuln.get('has_exploit') or vuln.get('cisa_exploit_add'):
            exploit_analysis['total_with_exploits'] += 1
            
            if vuln.get('cisa_exploit_add'):
                exploit_analysis['kev_count'] += 1
            
            # 分析置信度
            confidence = vuln.get('exploit_confidence', 0)
            if confidence > 70:
                exploit_analysis['confidence_levels']['high'] += 1
            elif confidence >= 40:
                exploit_analysis['confidence_levels']['medium'] += 1
            else:
                exploit_analysis['confidence_levels']['low'] += 1
            
            # 分析来源
            exploit_info = vuln.get('has_exploit')
            if exploit_info and isinstance(exploit_info, dict):
                sources = exploit_info.get('sources', [])
                for source in sources:
                    if 'github.com' in source.lower():
                        exploit_analysis['exploit_sources']['GitHub'] = exploit_analysis['exploit_sources'].get('GitHub', 0) + 1
                    elif 'exploit-db' in source.lower():
                        exploit_analysis['exploit_sources']['ExploitDB'] = exploit_analysis['exploit_sources'].get('ExploitDB', 0) + 1
                    elif 'metasploit' in source.lower():
                        exploit_analysis['exploit_sources']['Metasploit'] = exploit_analysis['exploit_sources'].get('Metasploit', 0) + 1
    
    return exploit_analysis

def assess_vulnerability_risk(vuln_info: Dict) -> Dict[str, Any]:
    """评估漏洞风险"""
    risk_score = 0
    risk_factors = []
    
    # CVSS评分风险
    cvss_score = vuln_info.get('cvss_score')
    if isinstance(cvss_score, (int, float)):
        if cvss_score >= 9.0:
            risk_score += 40
            risk_factors.append(f"极高CVSS评分 ({cvss_score})")
        elif cvss_score >= 7.0:
            risk_score += 25
            risk_factors.append(f"高CVSS评分 ({cvss_score})")
        elif cvss_score >= 4.0:
            risk_score += 10
            risk_factors.append(f"中等CVSS评分 ({cvss_score})")
    
    # EPSS评分风险
    epss_score = vuln_info.get('epss_score')
    if isinstance(epss_score, (int, float)):
        if epss_score >= 0.5:
            risk_score += 30
            risk_factors.append(f"高EPSS评分 ({epss_score:.3f})")
        elif epss_score >= 0.1:
            risk_score += 15
            risk_factors.append(f"中等EPSS评分 ({epss_score:.3f})")
    
    # 利用代码可用性
    if vuln_info.get('cisa_exploit_add'):
        risk_score += 35
        risk_factors.append("CISA KEV列表")
    elif vuln_info.get('has_exploit'):
        confidence = vuln_info.get('exploit_confidence', 0)
        if confidence > 70:
            risk_score += 25
            risk_factors.append("高置信度公开利用代码")
        elif confidence >= 40:
            risk_score += 15
            risk_factors.append("中等置信度公开利用代码")
    
    # 确定风险等级
    if risk_score >= 80:
        risk_level = "CRITICAL"
    elif risk_score >= 60:
        risk_level = "HIGH"
    elif risk_score >= 30:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"
    
    return {
        'risk_level': risk_level,
        'risk_score': risk_score,
        'risk_factors': risk_factors,
        'recommendations': generate_risk_recommendations(risk_level, risk_factors)
    }

def generate_risk_recommendations(risk_level: str, risk_factors: List[str]) -> List[str]:
    """生成风险建议"""
    recommendations = []
    
    if risk_level == "CRITICAL":
        recommendations.extend([
            "立即安装安全补丁或升级到安全版本",
            "考虑临时禁用相关服务直到修补完成",
            "监控相关网络流量和系统日志",
            "评估是否需要应急响应程序"
        ])
    elif risk_level == "HIGH":
        recommendations.extend([
            "优先安装安全补丁",
            "增强监控和日志记录",
            "评估网络隔离措施",
            "制定应急响应计划"
        ])
    elif risk_level == "MEDIUM":
        recommendations.extend([
            "及时安装安全补丁",
            "加强访问控制",
            "定期安全扫描"
        ])
    else:
        recommendations.extend([
            "按正常补丁管理流程处理",
            "保持监控"
        ])
    
    # 针对特定风险因素的建议
    if any("CISA KEV" in factor for factor in risk_factors):
        recommendations.insert(0, "⚠️ 此漏洞已被CISA列为已知被利用漏洞，需要立即处理")
    
    if any("公开利用代码" in factor for factor in risk_factors):
        recommendations.append("加强入侵检测系统监控")
    
    return recommendations

# --- 增强的CVE详情查询类 ---

class CVEDetails(BaseModel):
    cve_id: str
    description: str
    published_date: str
    last_modified_date: str
    cvss_v3_score: Optional[float] = None
    cvss_v3_severity: Optional[str] = None
    cvss_v2_score: Optional[float] = None
    cvss_v2_severity: Optional[str] = None
    epss_score: Optional[float] = None
    epss_percentile: Optional[float] = None
    has_exploit: bool = False
    exploit_sources: List[Dict[str, str]] = Field(default_factory=list)

class EnhancedCVEInfo:
    def __init__(self):
        self.nvd_api_base = NVD_CVE_API
        self.epss_api_base = EPSS_API
        
    def get_cve_details(self, cve_id: str) -> CVEDetails:
        """获取CVE详细信息包括EPSS评分"""
        response = requests.get(f"{self.nvd_api_base}?cveId={cve_id}")
        if response.status_code != 200:
            raise Exception(f"获取CVE详情失败: {response.status_code}")
        
        data = response.json()
        if data.get("totalResults", 0) == 0:
            raise Exception(f"CVE {cve_id} 未找到")
        
        cve_item = data["vulnerabilities"][0]["cve"]
        
        # 提取基本信息
        details = CVEDetails(
            cve_id=cve_id,
            description=self._get_description(cve_item),
            published_date=cve_item.get("published", "Unknown"),
            last_modified_date=cve_item.get("lastModified", "Unknown")
        )
        
        # 提取CVSS评分
        self._extract_cvss_scores(cve_item, details)
        
        # 获取EPSS评分
        self._get_epss_score(cve_id, details)
        
        # 检查利用代码
        self._check_exploit_availability(cve_id, details)
        
        return details
    
    def _get_description(self, cve_item: Dict) -> str:
        """提取CVE描述"""
        if "descriptions" in cve_item:
            for desc in cve_item["descriptions"]:
                if desc.get("lang") == "en":
                    return desc.get("value", "No description available")
        return "No description available"
    
    def _extract_cvss_scores(self, cve_item: Dict, details: CVEDetails) -> None:
        """提取CVSS评分"""
        metrics = cve_item.get("metrics", {})
        
        # CVSS v3
        if "cvssMetricV31" in metrics:
            v3_data = metrics["cvssMetricV31"][0]["cvssData"]
            details.cvss_v3_score = v3_data.get("baseScore")
            details.cvss_v3_severity = v3_data.get("baseSeverity")
        elif "cvssMetricV30" in metrics:
            v3_data = metrics["cvssMetricV30"][0]["cvssData"]
            details.cvss_v3_score = v3_data.get("baseScore")
            details.cvss_v3_severity = v3_data.get("baseSeverity")
            
        # CVSS v2
        if "cvssMetricV2" in metrics:
            v2_data = metrics["cvssMetricV2"][0]["cvssData"]
            details.cvss_v2_score = v2_data.get("baseScore")
            details.cvss_v2_severity = v2_data.get("baseSeverity")
    
    def _get_epss_score(self, cve_id: str, details: CVEDetails) -> None:
        """获取EPSS评分"""
        try:
            response = requests.get(f"{self.epss_api_base}?cve={cve_id}")
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "OK" and data.get("total", 0) > 0:
                    epss_data = data["data"][0]
                    details.epss_score = float(epss_data.get("epss", 0))
                    details.epss_percentile = float(epss_data.get("percentile", 0))
        except Exception:
            pass
    
    def _check_exploit_availability(self, cve_id: str, details: CVEDetails) -> None:
        """检查公开利用代码可用性"""
        # 检查ExploitDB
        exploit_db_url = f"https://www.exploit-db.com/search?cve={cve_id}"
        try:
            response = requests.get(exploit_db_url, timeout=10)
            if response.status_code == 200 and "No results" not in response.text:
                details.has_exploit = True
                details.exploit_sources.append({
                    "source": "ExploitDB",
                    "url": exploit_db_url,
                    "description": "Potential exploits found in ExploitDB"
                })
        except Exception:
            pass
        
        # 检查GitHub
        try:
            headers = {"Accept": "application/vnd.github.v3+json"}
            response = requests.get(f"https://api.github.com/search/repositories?q={cve_id}+exploit", 
                                  headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data.get("total_count", 0) > 0:
                    details.has_exploit = True
                    github_url = f"https://github.com/search?q={cve_id}+exploit"
                    details.exploit_sources.append({
                        "source": "GitHub",
                        "url": github_url,
                        "description": f"Found {data['total_count']} repositories potentially containing exploits"
                    })
        except Exception:
            pass
        
        # 基于EPSS评分判断
        if details.epss_score and details.epss_score > 0.3:
            details.has_exploit = True
            details.exploit_sources.append({
                "source": "EPSS",
                "url": f"https://epss.cyentia.com/epss_cve-{cve_id}.html",
                "description": f"High EPSS score ({details.epss_score:.4f}) indicates exploit likelihood"
            })

@mcp.tool()
def query_cve_enhanced(cve_id: str) -> Dict[str, Any]:
    """
    获取CVE的增强详细信息，包括EPSS评分和利用代码检测
    
    Args:
        cve_id: CVE编号 (如: CVE-2021-44228)
        
    Returns:
        详细的CVE信息，包括EPSS评分和利用代码可用性
    """
    cve_info = EnhancedCVEInfo()
    try:
        details = cve_info.get_cve_details(cve_id)
        return details.dict()
    except Exception as e:
        return {"error": str(e)}

# --- 批量查询工具 ---

@mcp.tool()
def batch_vulnerability_analysis(
    products: List[str],
    versions: Optional[List[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: int = 6,
    min_severity: str = "",
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    批量分析多个产品的漏洞情况
    
    Args:
        products: 产品列表 (如: ["tomcat", "apache", "nginx"])
        versions: 对应的版本列表 (可选)
        start_date: 开始日期
        end_date: 结束日期
        months_back: 向前查询月数
        min_severity: 最低严重程度
        api_key: NVD API密钥
        
    Returns:
        批量分析结果
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    results = {
        'products_analyzed': len(products),
        'analysis_results': {},
        'summary_statistics': {},
        'cross_product_risks': {},
        'query_info': {
            'date_range': {
                'start': start_date,
                'end': end_date,
                'months_back': months_back
            },
            'filters': {
                'min_severity': min_severity
            }
        }
    }
    
    all_vulnerabilities = []
    
    try:
        for i, product in enumerate(products):
            version = versions[i] if versions and i < len(versions) else "*"
            
            logger.info(f"分析产品 {i+1}/{len(products)}: {product} {version}")
            
            # 查询单个产品的漏洞
            product_result = search_vulnerabilities_by_product_version(
                product=product,
                version=version,
                start_date=start_date,
                end_date=end_date,
                months_back=months_back,
                min_severity=min_severity,
                api_key=api_key
            )
            
            if product_result.get('success', False):
                results['analysis_results'][f"{product}_{version}"] = product_result
                all_vulnerabilities.extend(product_result.get('vulnerabilities', []))
            else:
                results['analysis_results'][f"{product}_{version}"] = {
                    'error': product_result.get('error', 'Unknown error'),
                    'vulnerabilities': []
                }
        
        # 生成跨产品分析
        results['summary_statistics'] = generate_vulnerability_statistics(all_vulnerabilities)
        results['cross_product_risks'] = analyze_cross_product_risks(results['analysis_results'])
        
        return results
        
    except Exception as e:
        logger.error(f"批量分析失败: {e}")
        return {
            'error': str(e),
            'success': False
        }

def analyze_cross_product_risks(analysis_results: Dict) -> Dict[str, Any]:
    """分析跨产品风险"""
    cross_risks = {
        'common_vulnerabilities': {},
        'shared_cwe_types': {},
        'coordinated_attacks_potential': [],
        'risk_correlation': {}
    }
    
    # 收集所有CVE ID
    all_cves = {}
    for product, result in analysis_results.items():
        if 'vulnerabilities' in result:
            for vuln in result['vulnerabilities']:
                cve_id = vuln.get('id')
                if cve_id:
                    if cve_id not in all_cves:
                        all_cves[cve_id] = {'products': [], 'vuln_info': vuln}
                    all_cves[cve_id]['products'].append(product)
    
    # 找出影响多个产品的漏洞
    for cve_id, info in all_cves.items():
        if len(info['products']) > 1:
            cross_risks['common_vulnerabilities'][cve_id] = {
                'affected_products': info['products'],
                'severity': info['vuln_info'].get('severity', 'UNKNOWN'),
                'cvss_score': info['vuln_info'].get('cvss_score', 'N/A'),
                'has_exploit': info['vuln_info'].get('has_exploit') is not None
            }
    
    return cross_risks

# --- 趋势分析工具 ---

@mcp.tool()
def vulnerability_trend_analysis(
    keyword: str,
    years_back: int = 2,
    api_key: Optional[str] = None,
    severity: Optional[str] = "",
) -> Dict[str, Any]:
    """
    分析漏洞趋势 - 长期趋势分析
    
    Args:
        keyword: 产品关键词
        years_back: 分析的年数
        api_key: NVD API密钥
        severity:对于漏洞等级,可选LOW、MEDIUM、HIGH、CRITICAL

    Returns:
        趋势分析结果
    """
    global scanner
    
    if api_key:
        scanner = AdvancedVulnerabilityScanner(api_key)
    
    try:
        # 查询长期数据
        result = search_vulnerabilities_by_keyword(
            keyword=keyword,
            years_back=years_back,
            min_severity=severity,
            api_key=api_key,
            limit=5000
        )
        
        if not result.get('success'):
            return {'error': result.get('error', 'Unknown error'), 'success': False}
        
        vulnerabilities = result.get('vulnerabilities', [])
        
        # 趋势分析
        trend_analysis = {
            'keyword': keyword,
            'analysis_period': f"{years_back} years",
            'total_vulnerabilities': len(vulnerabilities),
            'yearly_trends': analyze_yearly_trends(vulnerabilities),
            'severity_trends': analyze_severity_trends(vulnerabilities),
            'exploit_trends': analyze_exploit_trends(vulnerabilities),
            'cwe_trends': analyze_cwe_trends(vulnerabilities),
            'recommendations': generate_trend_recommendations(vulnerabilities, years_back)
        }
        
        return trend_analysis
        
    except Exception as e:
        logger.error(f"趋势分析失败: {e}")
        return {'error': str(e), 'success': False}

def analyze_yearly_trends(vulnerabilities: List[Dict]) -> Dict[str, Any]:
    """分析年度趋势"""
    yearly_stats = {}
    
    for vuln in vulnerabilities:
        pub_date = vuln.get('published', '')
        if pub_date:
            try:
                year = datetime.fromisoformat(pub_date.replace('Z', '+00:00')).year
                if year not in yearly_stats:
                    yearly_stats[year] = {
                        'total': 0,
                        'critical': 0,
                        'high': 0,
                        'with_exploits': 0,
                        'kev_listed': 0,
                        'avg_cvss': []
                    }
                
                yearly_stats[year]['total'] += 1
                
                severity = vuln.get('severity', '').upper()
                if severity == 'CRITICAL':
                    yearly_stats[year]['critical'] += 1
                elif severity == 'HIGH':
                    yearly_stats[year]['high'] += 1
                
                if vuln.get('has_exploit'):
                    yearly_stats[year]['with_exploits'] += 1
                
                if vuln.get('cisa_exploit_add'):
                    yearly_stats[year]['kev_listed'] += 1
                
                cvss_score = vuln.get('cvss_score')
                if isinstance(cvss_score, (int, float)):
                    yearly_stats[year]['avg_cvss'].append(cvss_score)
                    
            except:
                pass
    
    # 计算平均CVSS评分
    for year_data in yearly_stats.values():
        if year_data['avg_cvss']:
            year_data['avg_cvss'] = sum(year_data['avg_cvss']) / len(year_data['avg_cvss'])
        else:
            year_data['avg_cvss'] = None
    
    return yearly_stats

def analyze_severity_trends(vulnerabilities: List[Dict]) -> Dict[str, Any]:
    """分析严重程度趋势"""
    severity_by_year = {}
    
    for vuln in vulnerabilities:
        pub_date = vuln.get('published', '')
        severity = vuln.get('severity', 'UNKNOWN')
        
        if pub_date:
            try:
                year = datetime.fromisoformat(pub_date.replace('Z', '+00:00')).year
                if year not in severity_by_year:
                    severity_by_year[year] = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'UNKNOWN': 0}
                
                severity_by_year[year][severity] += 1
            except:
                pass
    
    return severity_by_year

def analyze_exploit_trends(vulnerabilities: List[Dict]) -> Dict[str, Any]:
    """分析利用代码趋势"""
    exploit_by_year = {}
    
    for vuln in vulnerabilities:
        pub_date = vuln.get('published', '')
        
        if pub_date:
            try:
                year = datetime.fromisoformat(pub_date.replace('Z', '+00:00')).year
                if year not in exploit_by_year:
                    exploit_by_year[year] = {'total': 0, 'with_exploits': 0, 'kev_listed': 0, 'exploit_percentage': 0}
                
                exploit_by_year[year]['total'] += 1
                
                if vuln.get('has_exploit'):
                    exploit_by_year[year]['with_exploits'] += 1
                
                if vuln.get('cisa_exploit_add'):
                    exploit_by_year[year]['kev_listed'] += 1
                    
            except:
                pass
    
    # 计算利用代码百分比
    for year_data in exploit_by_year.values():
        if year_data['total'] > 0:
            year_data['exploit_percentage'] = (year_data['with_exploits'] / year_data['total']) * 100
    
    return exploit_by_year

def analyze_cwe_trends(vulnerabilities: List[Dict]) -> Dict[str, Any]:
    """分析CWE类型趋势"""
    cwe_by_year = {}
    
    for vuln in vulnerabilities:
        pub_date = vuln.get('published', '')
        cwe_ids = vuln.get('cwe_ids', [])
        
        if pub_date and cwe_ids:
            try:
                year = datetime.fromisoformat(pub_date.replace('Z', '+00:00')).year
                if year not in cwe_by_year:
                    cwe_by_year[year] = {}
                
                for cwe in cwe_ids:
                    cwe_by_year[year][cwe] = cwe_by_year[year].get(cwe, 0) + 1
            except:
                pass
    
    return cwe_by_year

def generate_trend_recommendations(vulnerabilities: List[Dict], years_back: int) -> List[str]:
    """生成趋势建议"""
    recommendations = []
    
    # 基本统计
    total_vulns = len(vulnerabilities)
    with_exploits = sum(1 for v in vulnerabilities if v.get('has_exploit'))
    kev_count = sum(1 for v in vulnerabilities if v.get('cisa_exploit_add'))
    
    if total_vulns == 0:
        return ["未发现相关漏洞，继续保持监控"]
    
    exploit_rate = (with_exploits / total_vulns) * 100
    kev_rate = (kev_count / total_vulns) * 100
    
    recommendations.append(f"在过去{years_back}年中发现{total_vulns}个漏洞")
    
    if exploit_rate > 20:
        recommendations.append(f"⚠️ 高利用代码比例 ({exploit_rate:.1f}%)，需要加强监控和快速补丁管理")
    elif exploit_rate > 10:
        recommendations.append(f"中等利用代码比例 ({exploit_rate:.1f}%)，建议定期安全评估")
    
    if kev_rate > 5:
        recommendations.append(f"⚠️ 高KEV比例 ({kev_rate:.1f}%)，此产品是攻击者重点目标")
    
    # 年度趋势分析
    yearly_stats = analyze_yearly_trends(vulnerabilities)
    if len(yearly_stats) >= 2:
        years = sorted(yearly_stats.keys())
        recent_year = years[-1]
        prev_year = years[-2]
        
        recent_total = yearly_stats[recent_year]['total']
        prev_total = yearly_stats[prev_year]['total']
        
        if recent_total > prev_total * 1.2:
            recommendations.append("📈 漏洞数量呈上升趋势，建议增加安全投入")
        elif recent_total < prev_total * 0.8:
            recommendations.append("📉 漏洞数量呈下降趋势，安全状况改善")
    
    return recommendations

# --- 导出和报告功能 ---

@mcp.tool()
def generate_security_report(
    keyword: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    months_back: int = 6,
    include_trends: bool = True,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    生成综合安全报告
    
    Args:
        keyword: 产品关键词
        start_date: 开始日期
        end_date: 结束日期
        months_back: 向前查询月数
        include_trends: 是否包含趋势分析
        api_key: NVD API密钥
        
    Returns:
        综合安全报告
    """
    report = {
        'report_metadata': {
            'product': keyword,
            'generated_at': datetime.now().isoformat(),
            'report_type': 'Comprehensive Security Assessment',
            'data_source': 'NVD (National Vulnerability Database)'
        },
        'executive_summary': {},
        'vulnerability_analysis': {},
        'risk_assessment': {},
        'trend_analysis': {},
        'recommendations': [],
        'appendix': {}
    }
    
    try:
        # 基础漏洞分析
        vuln_result = search_vulnerabilities_by_keyword(
            keyword=keyword,
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            min_severity="",
            api_key=api_key,
            limit=1000
        )
        
        if not vuln_result.get('success'):
            return {'error': vuln_result.get('error'), 'success': False}
        
        vulnerabilities = vuln_result.get('vulnerabilities', [])
        report['vulnerability_analysis'] = vuln_result
        
        # 高危漏洞分析
        high_risk_result = search_high_cvss_vulnerabilities(
            keyword=keyword,
            min_cvss_score=7.0,
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            api_key=api_key
        )
        
        # 利用代码分析
        exploit_result = search_exploitable_vulnerabilities(
            keyword=keyword,
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            api_key=api_key
        )
        
        # KEV分析
        kev_result = search_kev_vulnerabilities(
            keyword=keyword,
            start_date=start_date,
            end_date=end_date,
            months_back=months_back,
            api_key=api_key
        )
        
        # 生成执行摘要
        report['executive_summary'] = generate_executive_summary(
            vulnerabilities, 
            high_risk_result.get('vulnerabilities', []),
            exploit_result.get('vulnerabilities', []),
            kev_result.get('vulnerabilities', [])
        )
        
        # 风险评估
        report['risk_assessment'] = generate_risk_assessment(vulnerabilities)
        
        # 趋势分析 (可选)
        if include_trends:
            trend_result = vulnerability_trend_analysis(
                keyword=keyword,
                years_back=2,
                api_key=api_key
            )
            report['trend_analysis'] = trend_result
        
        # 生成建议
        report['recommendations'] = generate_comprehensive_recommendations(
            vulnerabilities,
            high_risk_result.get('vulnerabilities', []),
            exploit_result.get('vulnerabilities', []),
            kev_result.get('vulnerabilities', [])
        )
        
        # 附录
        report['appendix'] = {
            'high_risk_vulnerabilities': high_risk_result.get('vulnerabilities', [])[:10],
            'exploitable_vulnerabilities': exploit_result.get('vulnerabilities', [])[:10],
            'kev_vulnerabilities': kev_result.get('vulnerabilities', [])[:10]
        }
        
        report['success'] = True
        return report
        
    except Exception as e:
        logger.error(f"生成安全报告失败: {e}")
        return {'error': str(e), 'success': False}

def generate_executive_summary(all_vulns, high_risk_vulns, exploit_vulns, kev_vulns) -> Dict[str, Any]:
    """生成执行摘要"""
    return {
        'total_vulnerabilities': len(all_vulns),
        'high_risk_vulnerabilities': len(high_risk_vulns),
        'exploitable_vulnerabilities': len(exploit_vulns),
        'kev_vulnerabilities': len(kev_vulns),
        'risk_level': determine_overall_risk_level(all_vulns, exploit_vulns, kev_vulns),
        'key_findings': generate_key_findings(all_vulns, high_risk_vulns, exploit_vulns, kev_vulns),
        'immediate_actions_required': len(kev_vulns) > 0 or len([v for v in high_risk_vulns if v.get('cvss_score', 0) >= 9.0]) > 0
    }

def determine_overall_risk_level(all_vulns, exploit_vulns, kev_vulns) -> str:
    """确定总体风险等级"""
    if len(kev_vulns) > 0:
        return "CRITICAL"
    elif len(exploit_vulns) > len(all_vulns) * 0.2:
        return "HIGH"
    elif len(exploit_vulns) > 0:
        return "MEDIUM"
    else:
        return "LOW"

def generate_key_findings(all_vulns, high_risk_vulns, exploit_vulns, kev_vulns) -> List[str]:
    """生成关键发现"""
    findings = []
    
    if len(kev_vulns) > 0:
        findings.append(f"发现 {len(kev_vulns)} 个CISA已知被利用漏洞，需要立即处理")
    
    if len(high_risk_vulns) > 0:
        findings.append(f"发现 {len(high_risk_vulns)} 个高风险漏洞 (CVSS ≥ 7.0)")
    
    if len(exploit_vulns) > 0:
        exploit_rate = (len(exploit_vulns) / len(all_vulns)) * 100 if all_vulns else 0
        findings.append(f"发现 {len(exploit_vulns)} 个有公开利用代码的漏洞 ({exploit_rate:.1f}%)")
    
    return findings

def generate_risk_assessment(vulnerabilities) -> Dict[str, Any]:
    """生成风险评估"""
    risk_assessment = {
        'overall_risk_score': 0,
        'risk_factors': [],
        'risk_distribution': {
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0
        },
        'top_risk_vulnerabilities': []
    }
    
    # 计算风险分布和评分
    total_risk_score = 0
    risk_vulnerabilities = []
    
    for vuln in vulnerabilities:
        vuln_risk = assess_vulnerability_risk(vuln)
        risk_level = vuln_risk['risk_level'].lower()
        risk_assessment['risk_distribution'][risk_level] += 1
        
        total_risk_score += vuln_risk['risk_score']
        risk_vulnerabilities.append({
            'cve_id': vuln.get('id'),
            'risk_score': vuln_risk['risk_score'],
            'risk_level': vuln_risk['risk_level'],
            'cvss_score': vuln.get('cvss_score'),
            'has_exploit': vuln.get('has_exploit') is not None
        })
    
    # 平均风险评分
    if vulnerabilities:
        risk_assessment['overall_risk_score'] = total_risk_score / len(vulnerabilities)
    
    # 前10个最高风险漏洞
    risk_vulnerabilities.sort(key=lambda x: x['risk_score'], reverse=True)
    risk_assessment['top_risk_vulnerabilities'] = risk_vulnerabilities[:10]
    
    return risk_assessment

def generate_comprehensive_recommendations(all_vulns, high_risk_vulns, exploit_vulns, kev_vulns) -> List[str]:
    """生成综合建议"""
    recommendations = []
    
    # 立即行动项
    if kev_vulns:
        recommendations.append("🚨 立即行动: 处理CISA KEV列表中的漏洞")
        for vuln in kev_vulns[:3]:
            recommendations.append(f"  - {vuln.get('id')}: {vuln.get('cisa_required_action', 'Apply patches')}")
    
    if high_risk_vulns:
        critical_vulns = [v for v in high_risk_vulns if v.get('cvss_score', 0) >= 9.0]
        if critical_vulns:
            recommendations.append(f"🔴 高优先级: 处理 {len(critical_vulns)} 个关键漏洞 (CVSS ≥ 9.0)")
    
    # 中期建议
    if exploit_vulns:
        recommendations.append(f"🟡 中期计划: 处理 {len(exploit_vulns)} 个有公开利用代码的漏洞")
    
    # 长期建议
    recommendations.extend([
        "📋 建立定期漏洞扫描和评估流程",
        "🔄 实施自动化补丁管理系统",
        "📊 定期进行安全风险评估",
        "🎯 针对高风险组件制定专门的安全监控策略"
    ])
    
    return recommendations


@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"

# --- 启动服务器 ---


def main() -> None:
    mcp.run(transport='stdio')
