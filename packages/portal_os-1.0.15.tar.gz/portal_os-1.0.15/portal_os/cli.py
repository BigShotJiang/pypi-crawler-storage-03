#!/usr/bin/env python3
"""
Portal OS - Central Management Script
Unified CLI wrapper with shared configuration system for all Portal OS components
"""
import os
import sys
import json
import subprocess
from pathlib import Path
import click
from datetime import datetime

# Fix Unicode encoding for Windows
import locale
import codecs
if sys.platform == "win32":
    sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
    sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

# Import Portal OS configuration
from .config import get_config, get_component_config, apply_profile
from .core.installer import ComponentInstaller

__version__ = "1.0.15"

class PortalOSCLI:
    """Portal OS Central CLI Wrapper"""
    
    def __init__(self):
        self.config_manager = get_config()
        self._setup_components()
    
    def _setup_components(self):
        """Setup component paths and configurations"""
        # Get the package directory (where this script is located)
        package_dir = Path(__file__).parent
        
        self.components = {
            "ai_assistant": {
                "name": "🤖 AI Assistant",
                "description": "Conversational AI assistant with context awareness",
                "script": package_dir / "scripts" / "ai_assistant.py"
            },
            "security_privacy": {
                "name": "🔒 Security & Privacy",
                "description": "Advanced security and privacy management",
                "script": package_dir / "scripts" / "security_privacy_manager.py"
            },
            "performance_optimizer": {
                "name": "⚡ Performance Optimizer",
                "description": "System performance optimization and monitoring",
                "script": package_dir / "scripts" / "performance_optimizer.py"
            },
            "voice_interaction": {
                "name": "🎤 Voice Interaction",
                "description": "Speech-to-text and text-to-speech capabilities",
                "script": package_dir / "scripts" / "voice_interaction.py"
            },
            "advanced_ai": {
                "name": "🧠 Advanced AI",
                "description": "AI-powered workspace management and code intelligence",
                "script": package_dir / "scripts" / "advanced_ai_features.py"
            },
            "search_assistant": {
                "name": "🔍 Search Assistant",
                "description": "Intelligent file and content search",
                "script": package_dir / "scripts" / "search_assistant_setup.py"
            },
            "theme_manager": {
                "name": "🎨 Theme Manager",
                "description": "Visual theme and appearance management",
                "script": package_dir / "scripts" / "theme_manager.py"
            },
            "plugin_manager": {
                "name": "🔌 Plugin Manager",
                "description": "Plugin system management and updates",
                "script": package_dir / "scripts" / "plugin_manager.py"
            },
            "ui_ux_manager": {
                "name": "🖥️ UI/UX Manager",
                "description": "User interface and experience management",
                "script": package_dir / "scripts" / "ui_ux_manager.py"
            }
        }
    
    def show_status(self):
        """Show complete system status"""
        print("🚀 Portal OS - Complete System Status")
        print("=" * 60)
        print(f"📋 Version: {__version__}")
        print(f"📁 Portal Directory: {self.config_manager.portal_dir}")
        print(f"📄 Config File: {self.config_manager.config_file}")
        print()
        
        print("🔧 Component Status:")
        print("-" * 40)
        
        for component_id, component in self.components.items():
            status = "✅ Active" if self._check_component_status(component_id) else "❌ Inactive"
            print(f"{status} {component['name']}")
            print(f"   {component['description']}")
            print()
    
    def _check_component_status(self, component_id: str) -> bool:
        """Check if a component is active"""
        try:
            # Check if component is enabled in config
            config = get_component_config(component_id)
            if not config.get("enabled", False):
                return False
            
            # Check if component script exists
            component = self.components.get(component_id)
            if not component:
                return False
            
            script_path = component["script"]  # Already a Path object
            if not script_path.exists():
                return False
            
            return True
        except Exception:
            return False
    
    def run_component(self, component_id: str, args: list = None):
        """Run a specific component"""
        if component_id not in self.components:
            print(f"❌ Component '{component_id}' not found")
            return False
        
        component = self.components[component_id]
        script_path = component["script"]  # Already a Path object
        
        if not script_path.exists():
            print(f"❌ Script not found: {script_path}")
            return False
        
        try:
            cmd = [sys.executable, str(script_path)] + (args or [])
            result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
            
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(result.stderr, file=sys.stderr)
            
            return result.returncode == 0
        except Exception as e:
            print(f"❌ Error running component: {e}")
            return False

# Create CLI instance
cli_instance = PortalOSCLI()

@click.group()
@click.version_option(version=__version__, prog_name="Portal OS")
def cli():
    """Portal OS - AI-Native Developer Operating System
    
    A revolutionary operating system that combines Ubuntu's stability 
    with AI-first design principles, inspired by the OS1 from "Her" 
    and the clean aesthetics of Cutefish OS.
    """
    pass

@cli.command()
def version():
    """Show Portal OS version"""
    print(f"🚀 Portal OS v{__version__}")
    print(f"📅 Built on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🐍 Python: {sys.version.split()[0]}")
    print(f"💻 Platform: {sys.platform}")

@cli.command()
def status():
    """Show complete system status"""
    cli_instance.show_status()

@cli.command()
def components():
    """Show detailed component status and installation info"""
    try:
        installer = ComponentInstaller()
        status_info = installer.status()
        
        print("🔧 Portal OS Component Status")
        print("=" * 50)
        print(f"📋 Total Components: {status_info['total_components']}")
        print(f"✅ Installed: {status_info['installed_count']}")
        print(f"📜 Scripts Found: {status_info['scripts_found']}")
        print(f"💻 Platform: {status_info['platform']}")
        print()
        
        print("📦 Component Details:")
        print("-" * 40)
        
        for component_id, info in status_info['component_status'].items():
            status_icon = "✅" if info['installed'] else "❌"
            script_icon = "📜" if info['script_exists'] else "⚠️"
            print(f"{status_icon} {info['name']} ({component_id})")
            print(f"   Category: {info['category']}")
            print(f"   Script: {script_icon} {info['script']}")
            print()
        
        if status_info['installed_components']:
            print("📋 Installed Components:")
            print("-" * 40)
            for component in status_info['installed_components']:
                print(f"✅ {component['name']} - {component['install_date']}")
        
    except Exception as e:
        print(f"❌ Error getting component status: {e}")

@cli.command()
def config():
    """Show current configuration"""
    config_data = cli_instance.config_manager.config
    print("⚙️ Portal OS System Configuration:")
    print("=" * 40)
    print(json.dumps(config_data, indent=2, ensure_ascii=False))

@cli.command()
def profiles():
    """List available profiles"""
    profiles = cli_instance.config_manager.config.get("profiles", {})
    current_profile = cli_instance.config_manager.get("portal_os.current_profile", "developer")
    
    print("📋 Available Portal OS Profiles:")
    print("=" * 40)
    
    for profile_name, profile_data in profiles.items():
        status = " (CURRENT)" if profile_name == current_profile else ""
        print(f"🎯 {profile_name}{status}")
        print(f"   Description: {profile_data.get('description', 'No description')}")
        print(f"   Components: {', '.join(profile_data.get('components', []))}")
        print()

@cli.command()
@click.argument('profile_name')
def apply_profile_cmd(profile_name):
    """Apply a specific profile"""
    try:
        apply_profile(profile_name)
        print(f"✅ Profile '{profile_name}' applied successfully")
    except ValueError as e:
        print(f"❌ {e}")
        sys.exit(1)

@cli.command()
@click.argument('component', required=False)
@click.argument('args', nargs=-1)
def run(component, args):
    """Run a specific component or launch the Portal OS TUI Application"""
    if not component:
        # Launch Portal App when no component is specified
        try:
            from .scripts.portal_app import run_portal_app
            run_portal_app()
        except Exception as e:
            print(f"❌ Failed to launch Portal App: {e}")
            sys.exit(1)
    else:
        # Run the specified component
        success = cli_instance.run_component(component, list(args))
        if not success:
            sys.exit(1)

@cli.command()
def backup():
    """Create a backup of current configuration"""
    backup_file = cli_instance.config_manager.backup_config()
    if backup_file:
        print(f"✅ Configuration backed up to: {backup_file}")
    else:
        print("❌ Failed to create backup")
        sys.exit(1)

@cli.command()
@click.argument('backup_file')
def restore(backup_file):
    """Restore configuration from backup"""
    success = cli_instance.config_manager.restore_config(backup_file)
    if success:
        print("✅ Configuration restored successfully")
    else:
        print("❌ Failed to restore configuration")
        sys.exit(1)

@cli.command()
def update():
    """Check for updates"""
    print("🔄 Checking for Portal OS updates...")
    print("📦 Current version:", __version__)
    print("ℹ️ Update functionality coming soon!")

@cli.command()
@click.option('--interactive', '-i', is_flag=True, help='Launch interactive installer UI')
def install(interactive):
    """Install and setup all Portal OS components gracefully"""
    if interactive:
        # Launch interactive installer
        try:
            from .ui.installer_app import PortalOSInstallerApp
            app = PortalOSInstallerApp()
            app.run()
        except Exception as e:
            print(f"❌ Failed to launch interactive installer: {e}")
            return
    
    # Standard CLI installation
    print("🚀 Portal OS - Complete Installation")
    print("=" * 50)
    print("This will install the complete Portal OS suite including:")
    print("🤖 AI Components: AI Assistant, Advanced AI, Voice Interaction")
    print("🔒 Security: Security & Privacy Manager")
    print("⚡ Performance: Performance Optimizer")
    print("🔍 Productivity: Search Assistant")
    print("🎨 UI/UX: Theme Manager, UI/UX Manager")
    print("🔌 System: Plugin Manager")
    print("🔧 Development: SDK Manager with all development tools")
    print()
    
    # Apply developer profile (enables all components)
    print("📋 Applying developer profile...")
    try:
        apply_profile("developer")
        print("✅ Developer profile applied successfully!")
    except Exception as e:
        print(f"❌ Error applying profile: {e}")
        return
    
    # Use the ComponentInstaller for graceful installation
    print("\n🔧 Installing components gracefully...")
    try:
        installer = ComponentInstaller()
        
        # Install all components
        success = installer.install()
        if success:
            print("\n🚀 Starting all components...")
            installer.start()
            print("\n🎉 Portal OS installation complete!")
            print("📋 Run 'portal-os status' to check everything")
            print("💡 Run 'portal-os --help' to see available commands")
            print("🔧 Run 'portal-os components' to see detailed component status")
            
            # Show AI setup instructions
            print("\n🤖 AI Assistant Setup:")
            print("1. Run 'portal-os run ai_assistant configure' to set up AI backends")
            print("2. Install Ollama from https://ollama.ai for local AI models")
            print("3. Get a Gemini API key from https://makersuite.google.com/")
            print("4. Run 'portal-os run ai_assistant chat' to start chatting")
            
            # Show search assistant setup instructions
            print("\n🔍 Search Assistant Setup:")
            print("1. Navigate to portal_os/ui/search_assistant/")
            print("2. Run './build.sh' to build the search assistant")
            print("3. Use Cmd+Space (Mac) or Ctrl+Space (Windows/Linux) to launch")
            
            # Show theme manager setup instructions
            print("\n🎨 Theme Manager Setup:")
            print("1. Navigate to portal_os/ui/theme_manager/")
            print("2. Run './build.sh' to build the theme manager")
            print("3. Run 'portal-os run theme_manager' to launch")
        else:
            print("\n⚠️ Installation completed with some issues.")
            print("📋 Run 'portal-os components' to see which components failed")
            print("💡 You can retry failed components individually")
    except Exception as e:
        print(f"❌ Installation error: {e}")
        return

@cli.command()
def ai_setup():
    """Setup AI assistant with backends and configuration"""
    print("🤖 Portal OS AI Assistant Setup")
    print("=" * 40)
    
    try:
        # Run AI assistant configuration
        success = cli_instance.run_component("ai_assistant", ["configure"])
        if success:
            print("\n✅ AI Assistant configured successfully!")
            print("\n📋 Next steps:")
            print("1. Install Ollama: https://ollama.ai")
            print("2. Get Gemini API key: https://makersuite.google.com/")
            print("3. Run 'portal-os run ai_assistant chat' to start")
        else:
            print("❌ AI Assistant configuration failed")
    except Exception as e:
        print(f"❌ Error: {e}")

@cli.command()
def search_setup():
    """Setup search assistant and build GUI application"""
    print("🔍 Portal OS Search Assistant Setup")
    print("=" * 40)
    
    try:
        # Check if search assistant directory exists
        search_dir = Path(__file__).parent / "ui" / "search_assistant"
        if not search_dir.exists():
            print("❌ Search assistant directory not found")
            print("💡 Make sure you're running from the Portal OS root directory")
            return
        
        print("📁 Found search assistant directory")
        print("🔧 Building search assistant...")
        
        # Change to search assistant directory
        import subprocess
        import os
        
        original_dir = os.getcwd()
        os.chdir(search_dir)
        
        try:
            # Check for build script (prefer Windows .bat on Windows)
            if sys.platform == "win32":
                build_script = search_dir / "build.bat"
                build_cmd = ["build.bat"]
            else:
                build_script = search_dir / "build.sh"
                build_cmd = ["./build.sh"]
                if build_script.exists():
                    os.chmod(build_script, 0o755)
            
            if build_script.exists():
                result = subprocess.run(build_cmd, capture_output=True, text=True)
                
                if result.returncode == 0:
                    print("✅ Search assistant built successfully!")
                    print("💡 Use Cmd+Space (Mac) or Ctrl+Space (Windows/Linux) to launch")
                else:
                    print(f"❌ Build failed: {result.stderr}")
            else:
                print("❌ Build script not found")
                print("💡 Please run the build manually:")
                print(f"   cd {search_dir}")
                print("   npm install")
                print("   npm run tauri build")
        finally:
            os.chdir(original_dir)
            
    except Exception as e:
        print(f"❌ Error: {e}")

@cli.command()
def theme_setup():
    """Setup theme manager and build GUI application"""
    print("🎨 Portal OS Theme Manager Setup")
    print("=" * 40)
    
    try:
        # Check if theme manager directory exists
        theme_dir = Path(__file__).parent / "ui" / "theme_manager"
        if not theme_dir.exists():
            print("❌ Theme manager directory not found")
            print("💡 Make sure you're running from the Portal OS root directory")
            return
        
        print("📁 Found theme manager directory")
        print("🔧 Building theme manager...")
        
        # Change to theme manager directory
        import subprocess
        import os
        
        original_dir = os.getcwd()
        os.chdir(theme_dir)
        
        try:
            # Check for build script (prefer Windows .bat on Windows)
            if sys.platform == "win32":
                build_script = theme_dir / "build.bat"
                build_cmd = ["build.bat"]
            else:
                build_script = theme_dir / "build.sh"
                build_cmd = ["./build.sh"]
                if build_script.exists():
                    os.chmod(build_script, 0o755)
            
            if build_script.exists():
                result = subprocess.run(build_cmd, capture_output=True, text=True)
                
                if result.returncode == 0:
                    print("✅ Theme manager built successfully!")
                    print("💡 Run 'portal-os run theme_manager' to launch")
                else:
                    print(f"❌ Build failed: {result.stderr}")
            else:
                print("❌ Build script not found")
                print("💡 Please run the build manually:")
                print(f"   cd {theme_dir}")
                print("   npm install")
                print("   npm run tauri build")
        finally:
            os.chdir(original_dir)
            
    except Exception as e:
        print(f"❌ Error: {e}")

@cli.command()
def doctor():
    """Run system diagnostics"""
    print("🔍 Portal OS System Diagnostics")
    print("=" * 40)
    
    # Check Python version
    print(f"🐍 Python Version: {sys.version.split()[0]} ✅")
    
    # Check configuration
    try:
        config = get_config()
        print(f"⚙️ Configuration: Loaded ✅")
        print(f"📁 Portal Directory: {config.portal_dir} ✅")
    except Exception as e:
        print(f"❌ Configuration Error: {e}")
    
    # Check components
    print("\n🔧 Component Status:")
    for component_id, component in cli_instance.components.items():
        status = "✅" if cli_instance._check_component_status(component_id) else "❌"
        print(f"   {status} {component['name']}")
    
    # Check AI backends
    print("\n🤖 AI Backend Status:")
    try:
        ai_status = cli_instance.run_component("ai_assistant", ["backends"])
        if ai_status:
            print("   ✅ AI Assistant backends checked")
        else:
            print("   ❌ AI Assistant backends failed")
    except Exception as e:
        print(f"   ❌ AI Assistant error: {e}")
    
    # Check search assistant
    print("\n🔍 Search Assistant Status:")
    search_dir = Path(__file__).parent / "ui" / "search_assistant"
    if search_dir.exists():
        print("   ✅ Search assistant directory found")
        
        # Check if built
        build_dir = search_dir / "src-tauri" / "target" / "release"
        if build_dir.exists():
            print("   ✅ Search assistant built")
        else:
            print("   ⚠️ Search assistant not built (run 'portal-os search-setup')")
    else:
        print("   ❌ Search assistant directory not found")
    
    # Check theme manager
    print("\n🎨 Theme Manager Status:")
    theme_dir = Path(__file__).parent / "ui" / "theme_manager"
    if theme_dir.exists():
        print("   ✅ Theme manager directory found")
        
        # Check if built
        build_dir = theme_dir / "src-tauri" / "target" / "release"
        if build_dir.exists():
            print("   ✅ Theme manager built")
        else:
            print("   ⚠️ Theme manager not built (run 'portal-os theme-setup')")
    else:
        print("   ❌ Theme manager directory not found")
    
    print("\n✅ Diagnostics complete!")

def main():
    """Main entry point"""
    cli()

if __name__ == "__main__":
    main()
