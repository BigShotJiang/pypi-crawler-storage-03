@echo off
REM Portal OS Search Assistant Build Script for Windows

echo 🔍 Building Portal OS Search Assistant...

REM Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js is not installed. Please install Node.js first.
    exit /b 1
)

REM Check if npm is installed
npm --version >nul 2>&1
if errorlevel 1 (
    echo ❌ npm is not installed. Please install npm first.
    exit /b 1
)

REM Check if Rust is installed
cargo --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Rust is not installed. Please install Rust first.
    echo Visit: https://rustup.rs/
    exit /b 1
)

REM Check if Tauri CLI is installed
tauri --version >nul 2>&1
if errorlevel 1 (
    echo 📦 Installing Tauri CLI...
    cargo install tauri-cli
)

echo 📦 Installing dependencies...
npm install

echo 🔧 Building frontend...
npm run build

echo 🚀 Building Tauri application...
npm run tauri build

echo ✅ Build completed successfully!
echo 📁 Output location: src-tauri/target/release/

REM Copy to Portal OS directory
if exist "src-tauri\target\release" (
    echo 📋 Copying to Portal OS directory...
    if not exist "%USERPROFILE%\.portal-os\apps" mkdir "%USERPROFILE%\.portal-os\apps"
    xcopy "src-tauri\target\release\*" "%USERPROFILE%\.portal-os\apps\" /E /Y
    echo ✅ Search Assistant installed to %USERPROFILE%\.portal-os\apps\
)

echo 🎉 Portal OS Search Assistant is ready!
echo 💡 Use Ctrl+Space to launch the search assistant

pause
