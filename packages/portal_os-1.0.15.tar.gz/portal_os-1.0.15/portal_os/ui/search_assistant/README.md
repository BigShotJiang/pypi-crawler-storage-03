# Portal OS Search Assistant

A modern, intelligent file and content search application built with Tauri and React.

## Features

- 🔍 **Intelligent Search**: Search files by name, content, and natural language
- ⚡ **Fast Indexing**: Real-time file indexing with SQLite backend
- 🎨 **Modern UI**: Beautiful, responsive interface with dark mode support
- ⌨️ **Global Hotkeys**: Cmd+Space (Mac) / Ctrl+Space (Windows/Linux)
- 📱 **Cross-Platform**: Works on Windows, macOS, and Linux
- 🔄 **Search History**: Track and reuse previous searches
- ⚙️ **Customizable**: Configurable search settings and indexing options

## Quick Start

### Prerequisites

- Node.js 16+ and npm
- Rust and Cargo
- Tauri CLI

### Installation

1. **Install Rust** (if not already installed):
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   ```

2. **Install Tauri CLI**:
   ```bash
   cargo install tauri-cli
   ```

3. **Build the application**:
   ```bash
   chmod +x build.sh
   ./build.sh
   ```

### Development

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start development server**:
   ```bash
   npm run tauri dev
   ```

3. **Build for production**:
   ```bash
   npm run tauri build
   ```

## Usage

### Global Hotkey
- **Mac**: `Cmd + Space`
- **Windows/Linux**: `Ctrl + Space`

### Search Features
- **File Search**: Search by filename or path
- **Content Search**: Search within file contents
- **Natural Language**: Use phrases like "show me Python files"
- **Quick Actions**: Open files or show in folder

### Settings
- **Index Settings**: Configure which directories to index
- **Search Settings**: Adjust search depth and preferences
- **Global Shortcuts**: Customize keyboard shortcuts

## Architecture

### Frontend (React + TypeScript)
- Modern React with hooks and TypeScript
- Lucide React for icons
- Responsive design with CSS Grid and Flexbox
- Dark mode support

### Backend (Rust + Tauri)
- SQLite database for search index
- File system integration
- Global hotkey support
- Cross-platform compatibility

### Database Schema
```sql
-- Indexed files
CREATE TABLE indexed_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT UNIQUE,
    file_name TEXT,
    file_size INTEGER,
    file_type TEXT,
    last_modified TEXT,
    content_hash TEXT,
    indexed_at TEXT
);

-- Search index
CREATE TABLE search_index (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id INTEGER,
    word TEXT,
    position INTEGER,
    context TEXT,
    FOREIGN KEY (file_id) REFERENCES indexed_files (id)
);

-- Search history
CREATE TABLE search_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query TEXT,
    results_count INTEGER,
    timestamp TEXT
);
```

## Configuration

The search assistant stores its configuration and database in:
- **Database**: `~/.portal-os/search/search_index.db`
- **Configuration**: `~/.portal-os/config/search_assistant.json`

## Development

### Project Structure
```
search_assistant/
├── src/                    # React frontend
│   ├── App.tsx            # Main application component
│   ├── App.css            # Styles
│   └── main.tsx           # Entry point
├── src-tauri/             # Rust backend
│   ├── src/
│   │   └── main.rs        # Main Rust application
│   ├── Cargo.toml         # Rust dependencies
│   └── tauri.conf.json    # Tauri configuration
├── package.json           # Node.js dependencies
├── build.sh              # Build script
└── README.md             # This file
```

### Adding Features

1. **Frontend**: Add React components in `src/`
2. **Backend**: Add Rust functions in `src-tauri/src/main.rs`
3. **Database**: Update schema and queries as needed
4. **Configuration**: Add new settings to `tauri.conf.json`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

- **Documentation**: [Portal OS Docs](https://docs.portal-os.com)
- **Issues**: [GitHub Issues](https://github.com/your-org/portal-os/issues)
- **Discord**: [Portal OS Community](https://discord.gg/portal-os)
