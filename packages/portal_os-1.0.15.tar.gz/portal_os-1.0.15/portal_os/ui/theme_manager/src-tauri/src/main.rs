// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::State;
use rusqlite::{Connection, Result as SqliteResult};

#[derive(Debug, Serialize, Deserialize)]
struct Theme {
    id: String,
    name: String,
    description: String,
    category: String,
    preview: String,
    installed: bool,
    active: bool,
    colors: ThemeColors,
}

#[derive(Debug, Serialize, Deserialize)]
struct ThemeColors {
    primary: String,
    secondary: String,
    accent: String,
    background: String,
    surface: String,
    text: String,
    text_secondary: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct Profile {
    id: String,
    name: String,
    description: String,
    theme: String,
    active: bool,
}

struct ThemeDatabase {
    conn: Mutex<Connection>,
}

impl ThemeDatabase {
    fn new() -> SqliteResult<Self> {
        let home_dir = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
        let db_path = home_dir.join(".portal-os").join("themes").join("theme_manager.db");
        
        // Ensure directory exists
        if let Some(parent) = db_path.parent() {
            std::fs::create_dir_all(parent).ok();
        }
        
        let conn = Connection::open(&db_path)?;
        
        // Create tables if they don't exist
        conn.execute(
            "CREATE TABLE IF NOT EXISTS themes (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                category TEXT NOT NULL,
                preview TEXT,
                installed BOOLEAN DEFAULT FALSE,
                active BOOLEAN DEFAULT FALSE,
                colors TEXT
            )",
            [],
        )?;
        
        conn.execute(
            "CREATE TABLE IF NOT EXISTS profiles (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                theme TEXT NOT NULL,
                active BOOLEAN DEFAULT FALSE,
                FOREIGN KEY (theme) REFERENCES themes (id)
            )",
            [],
        )?;
        
        // Insert default themes if they don't exist
        Self::insert_default_themes(&conn)?;
        Self::insert_default_profiles(&conn)?;
        
        Ok(ThemeDatabase {
            conn: Mutex::new(conn),
        })
    }
    
    fn insert_default_themes(conn: &Connection) -> SqliteResult<()> {
        let default_themes = vec![
            (
                "cutefish",
                "Cutefish",
                "Clean and modern design inspired by Cutefish OS",
                "system",
                "cutefish-preview.png",
                true,
                true,
                r#"{"primary":"#667eea","secondary":"#764ba2","accent":"#f093fb","background":"#f8fafc","surface":"#ffffff","text":"#1e293b","text_secondary":"#64748b"}"#
            ),
            (
                "mac-like",
                "Mac-like",
                "Elegant design inspired by macOS",
                "system",
                "mac-preview.png",
                true,
                false,
                r#"{"primary":"#007AFF","secondary":"#5856D6","accent":"#FF2D92","background":"#f5f5f7","surface":"#ffffff","text":"#1d1d1f","text_secondary":"#86868b"}"#
            ),
            (
                "windows-like",
                "Windows-like",
                "Familiar design inspired by Windows 11",
                "system",
                "windows-preview.png",
                true,
                false,
                r#"{"primary":"#0078d4","secondary":"#106ebe","accent":"#ff6b35","background":"#f3f2f1","surface":"#ffffff","text":"#323130","text_secondary":"#605e5c"}"#
            ),
            (
                "minimal",
                "Minimal",
                "Clean and minimal design for productivity",
                "system",
                "minimal-preview.png",
                true,
                false,
                r#"{"primary":"#374151","secondary":"#6b7280","accent":"#10b981","background":"#ffffff","surface":"#f9fafb","text":"#111827","text_secondary":"#6b7280"}"#
            ),
        ];
        
        for (id, name, description, category, preview, installed, active, colors) in default_themes {
            conn.execute(
                "INSERT OR IGNORE INTO themes (id, name, description, category, preview, installed, active, colors) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [id, name, description, category, preview, &installed.to_string(), &active.to_string(), colors],
            )?;
        }
        
        Ok(())
    }
    
    fn insert_default_profiles(conn: &Connection) -> SqliteResult<()> {
        let default_profiles = vec![
            ("developer", "Developer", "Optimized for coding and development", "cutefish", true),
            ("studying", "Studying", "Focused environment for learning", "minimal", false),
            ("watching", "Watching", "Dark theme for media consumption", "mac-like", false),
            ("gaming", "Gaming", "Vibrant theme for gaming sessions", "windows-like", false),
        ];
        
        for (id, name, description, theme, active) in default_profiles {
            conn.execute(
                "INSERT OR IGNORE INTO profiles (id, name, description, theme, active) VALUES (?, ?, ?, ?, ?)",
                [id, name, description, theme, &active.to_string()],
            )?;
        }
        
        Ok(())
    }
}

#[tauri::command]
async fn get_themes(
    db: State<'_, ThemeDatabase>,
) -> Result<Vec<Theme>, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    let mut stmt = conn.prepare(
        "SELECT id, name, description, category, preview, installed, active, colors FROM themes ORDER BY category, name"
    ).map_err(|e| format!("Database error: {}", e))?;
    
    let rows = stmt.query_map([], |row| {
        let colors_json: String = row.get(7)?;
        let colors: ThemeColors = serde_json::from_str(&colors_json)
            .map_err(|_| rusqlite::Error::InvalidParameterName("Invalid colors JSON".to_string()))?;
        
        Ok(Theme {
            id: row.get(0)?,
            name: row.get(1)?,
            description: row.get(2)?,
            category: row.get(3)?,
            preview: row.get(4)?,
            installed: row.get(5)?,
            active: row.get(6)?,
            colors,
        })
    }).map_err(|e| format!("Query error: {}", e))?;
    
    let themes: Vec<Theme> = rows
        .filter_map(|r| r.ok())
        .collect();
    
    Ok(themes)
}

#[tauri::command]
async fn get_profiles(
    db: State<'_, ThemeDatabase>,
) -> Result<Vec<Profile>, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    let mut stmt = conn.prepare(
        "SELECT id, name, description, theme, active FROM profiles ORDER BY name"
    ).map_err(|e| format!("Database error: {}", e))?;
    
    let rows = stmt.query_map([], |row| {
        Ok(Profile {
            id: row.get(0)?,
            name: row.get(1)?,
            description: row.get(2)?,
            theme: row.get(3)?,
            active: row.get(4)?,
        })
    }).map_err(|e| format!("Query error: {}", e))?;
    
    let profiles: Vec<Profile> = rows
        .filter_map(|r| r.ok())
        .collect();
    
    Ok(profiles)
}

#[tauri::command]
async fn apply_theme(
    theme_id: String,
    db: State<'_, ThemeDatabase>,
) -> Result<String, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    // First, deactivate all themes
    conn.execute("UPDATE themes SET active = FALSE", [])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Then activate the selected theme
    conn.execute("UPDATE themes SET active = TRUE WHERE id = ?", [&theme_id])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Apply theme to system (this would integrate with the actual theme system)
    // For now, just return success
    Ok(format!("Theme {} applied successfully", theme_id))
}

#[tauri::command]
async fn apply_profile(
    profile_id: String,
    db: State<'_, ThemeDatabase>,
) -> Result<String, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    // Get the theme for this profile
    let theme: String = conn.query_row(
        "SELECT theme FROM profiles WHERE id = ?",
        [&profile_id],
        |row| row.get(0)
    ).map_err(|e| format!("Profile not found: {}", e))?;
    
    // First, deactivate all profiles
    conn.execute("UPDATE profiles SET active = FALSE", [])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Then activate the selected profile
    conn.execute("UPDATE profiles SET active = TRUE WHERE id = ?", [&profile_id])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Apply the theme for this profile
    conn.execute("UPDATE themes SET active = FALSE", [])
        .map_err(|e| format!("Database error: {}", e))?;
    
    conn.execute("UPDATE themes SET active = TRUE WHERE id = ?", [&theme])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Apply profile to system (this would integrate with the actual profile system)
    // For now, just return success
    Ok(format!("Profile {} applied successfully", profile_id))
}

#[tauri::command]
async fn install_theme(
    theme_id: String,
    db: State<'_, ThemeDatabase>,
) -> Result<String, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    conn.execute("UPDATE themes SET installed = TRUE WHERE id = ?", [&theme_id])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Install theme files (this would copy theme files to the appropriate location)
    // For now, just return success
    Ok(format!("Theme {} installed successfully", theme_id))
}

#[tauri::command]
async fn uninstall_theme(
    theme_id: String,
    db: State<'_, ThemeDatabase>,
) -> Result<String, String> {
    let conn = db.conn.lock().map_err(|_| "Database lock error")?;
    
    // Check if theme is active
    let active: bool = conn.query_row(
        "SELECT active FROM themes WHERE id = ?",
        [&theme_id],
        |row| row.get(0)
    ).unwrap_or(false);
    
    if active {
        return Err("Cannot uninstall active theme".to_string());
    }
    
    conn.execute("UPDATE themes SET installed = FALSE WHERE id = ?", [&theme_id])
        .map_err(|e| format!("Database error: {}", e))?;
    
    // Remove theme files (this would delete theme files from the appropriate location)
    // For now, just return success
    Ok(format!("Theme {} uninstalled successfully", theme_id))
}

fn main() {
    let theme_db = ThemeDatabase::new()
        .expect("Failed to initialize theme database");
    
    tauri::Builder::default()
        .manage(theme_db)
        .invoke_handler(tauri::generate_handler![
            get_themes,
            get_profiles,
            apply_theme,
            apply_profile,
            install_theme,
            uninstall_theme,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
