#!/bin/bash

# Portal OS Theme Manager Build Script

set -e

echo "🎨 Building Portal OS Theme Manager..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

# Check if Rust is installed
if ! command -v cargo &> /dev/null; then
    echo "❌ Rust is not installed. Please install Rust first."
    echo "Visit: https://rustup.rs/"
    exit 1
fi

# Check if Tauri CLI is installed
if ! command -v tauri &> /dev/null; then
    echo "📦 Installing Tauri CLI..."
    cargo install tauri-cli
fi

echo "📦 Installing dependencies..."
npm install

echo "🔧 Building frontend..."
npm run build

echo "🚀 Building Tauri application..."
npm run tauri build

echo "✅ Build completed successfully!"
echo "📁 Output location: src-tauri/target/release/"

# Copy to Portal OS directory
if [ -d "src-tauri/target/release" ]; then
    echo "📋 Copying to Portal OS directory..."
    mkdir -p ~/.portal-os/apps
    cp -r src-tauri/target/release/* ~/.portal-os/apps/
    echo "✅ Theme Manager installed to ~/.portal-os/apps/"
fi

echo "🎉 Portal OS Theme Manager is ready!"
echo "💡 Launch from Portal OS CLI with: portal-os run theme_manager"
