import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { Palette, Monitor, Smartphone, Download, Upload, Settings, Eye, EyeOff, Check, X } from 'lucide-react';
import './App.css';

interface Theme {
  id: string;
  name: string;
  description: string;
  category: 'system' | 'custom' | 'marketplace';
  preview: string;
  installed: boolean;
  active: boolean;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
  };
}

interface Profile {
  id: string;
  name: string;
  description: string;
  theme: string;
  active: boolean;
}

function App() {
  const [themes, setThemes] = useState<Theme[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [activeTab, setActiveTab] = useState<'themes' | 'profiles' | 'marketplace' | 'settings'>('themes');
  const [selectedTheme, setSelectedTheme] = useState<Theme | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadThemes();
    loadProfiles();
  }, []);

  const loadThemes = async () => {
    try {
      const themesData = await invoke('get_themes');
      setThemes(themesData as Theme[]);
    } catch (error) {
      console.error('Failed to load themes:', error);
      // Load default themes if API fails
      setThemes(getDefaultThemes());
    }
  };

  const loadProfiles = async () => {
    try {
      const profilesData = await invoke('get_profiles');
      setProfiles(profilesData as Profile[]);
    } catch (error) {
      console.error('Failed to load profiles:', error);
      // Load default profiles if API fails
      setProfiles(getDefaultProfiles());
    }
  };

  const getDefaultThemes = (): Theme[] => [
    {
      id: 'cutefish',
      name: 'Cutefish',
      description: 'Clean and modern design inspired by Cutefish OS',
      category: 'system',
      preview: 'cutefish-preview.png',
      installed: true,
      active: true,
      colors: {
        primary: '#667eea',
        secondary: '#764ba2',
        accent: '#f093fb',
        background: '#f8fafc',
        surface: '#ffffff',
        text: '#1e293b',
        textSecondary: '#64748b'
      }
    },
    {
      id: 'mac-like',
      name: 'Mac-like',
      description: 'Elegant design inspired by macOS',
      category: 'system',
      preview: 'mac-preview.png',
      installed: true,
      active: false,
      colors: {
        primary: '#007AFF',
        secondary: '#5856D6',
        accent: '#FF2D92',
        background: '#f5f5f7',
        surface: '#ffffff',
        text: '#1d1d1f',
        textSecondary: '#86868b'
      }
    },
    {
      id: 'windows-like',
      name: 'Windows-like',
      description: 'Familiar design inspired by Windows 11',
      category: 'system',
      preview: 'windows-preview.png',
      installed: true,
      active: false,
      colors: {
        primary: '#0078d4',
        secondary: '#106ebe',
        accent: '#ff6b35',
        background: '#f3f2f1',
        surface: '#ffffff',
        text: '#323130',
        textSecondary: '#605e5c'
      }
    },
    {
      id: 'minimal',
      name: 'Minimal',
      description: 'Clean and minimal design for productivity',
      category: 'system',
      preview: 'minimal-preview.png',
      installed: true,
      active: false,
      colors: {
        primary: '#374151',
        secondary: '#6b7280',
        accent: '#10b981',
        background: '#ffffff',
        surface: '#f9fafb',
        text: '#111827',
        textSecondary: '#6b7280'
      }
    }
  ];

  const getDefaultProfiles = (): Profile[] => [
    {
      id: 'developer',
      name: 'Developer',
      description: 'Optimized for coding and development',
      theme: 'cutefish',
      active: true
    },
    {
      id: 'studying',
      name: 'Studying',
      description: 'Focused environment for learning',
      theme: 'minimal',
      active: false
    },
    {
      id: 'watching',
      name: 'Watching',
      description: 'Dark theme for media consumption',
      theme: 'mac-like',
      active: false
    },
    {
      id: 'gaming',
      name: 'Gaming',
      description: 'Vibrant theme for gaming sessions',
      theme: 'windows-like',
      active: false
    }
  ];

  const applyTheme = async (themeId: string) => {
    setLoading(true);
    try {
      await invoke('apply_theme', { themeId });
      
      // Update local state
      setThemes(prev => prev.map(theme => ({
        ...theme,
        active: theme.id === themeId
      })));
      
      console.log(`Theme ${themeId} applied successfully`);
    } catch (error) {
      console.error('Failed to apply theme:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyProfile = async (profileId: string) => {
    setLoading(true);
    try {
      await invoke('apply_profile', { profileId });
      
      // Update local state
      setProfiles(prev => prev.map(profile => ({
        ...profile,
        active: profile.id === profileId
      })));
      
      console.log(`Profile ${profileId} applied successfully`);
    } catch (error) {
      console.error('Failed to apply profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const installTheme = async (themeId: string) => {
    setLoading(true);
    try {
      await invoke('install_theme', { themeId });
      
      // Update local state
      setThemes(prev => prev.map(theme => 
        theme.id === themeId ? { ...theme, installed: true } : theme
      ));
      
      console.log(`Theme ${themeId} installed successfully`);
    } catch (error) {
      console.error('Failed to install theme:', error);
    } finally {
      setLoading(false);
    }
  };

  const uninstallTheme = async (themeId: string) => {
    setLoading(true);
    try {
      await invoke('uninstall_theme', { themeId });
      
      // Update local state
      setThemes(prev => prev.map(theme => 
        theme.id === themeId ? { ...theme, installed: false, active: false } : theme
      ));
      
      console.log(`Theme ${themeId} uninstalled successfully`);
    } catch (error) {
      console.error('Failed to uninstall theme:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'system':
        return <Monitor className="w-4 h-4" />;
      case 'custom':
        return <Palette className="w-4 h-4" />;
      case 'marketplace':
        return <Download className="w-4 h-4" />;
      default:
        return <Palette className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'system':
        return 'bg-blue-100 text-blue-800';
      case 'custom':
        return 'bg-green-100 text-green-800';
      case 'marketplace':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="app">
      <div className="header">
        <div className="logo">
          <Palette className="w-6 h-6" />
          <h1>Portal OS Theme Manager</h1>
        </div>
        
        <div className="tabs">
          <button 
            className={`tab ${activeTab === 'themes' ? 'active' : ''}`}
            onClick={() => setActiveTab('themes')}
          >
            <Palette className="w-4 h-4" />
            Themes
          </button>
          <button 
            className={`tab ${activeTab === 'profiles' ? 'active' : ''}`}
            onClick={() => setActiveTab('profiles')}
          >
            <Settings className="w-4 h-4" />
            Profiles
          </button>
          <button 
            className={`tab ${activeTab === 'marketplace' ? 'active' : ''}`}
            onClick={() => setActiveTab('marketplace')}
          >
            <Download className="w-4 h-4" />
            Marketplace
          </button>
          <button 
            className={`tab ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>
      </div>

      <div className="content">
        {activeTab === 'themes' && (
          <div className="themes-tab">
            <div className="themes-grid">
              {themes.map((theme) => (
                <div key={theme.id} className="theme-card">
                  <div className="theme-preview" style={{ backgroundColor: theme.colors.background }}>
                    <div className="preview-header" style={{ backgroundColor: theme.colors.surface }}>
                      <div className="preview-dots">
                        <div className="dot" style={{ backgroundColor: theme.colors.primary }}></div>
                        <div className="dot" style={{ backgroundColor: theme.colors.secondary }}></div>
                        <div className="dot" style={{ backgroundColor: theme.colors.accent }}></div>
                      </div>
                    </div>
                    <div className="preview-content">
                      <div className="preview-text" style={{ color: theme.colors.text }}>
                        Sample Text
                      </div>
                      <div className="preview-button" style={{ backgroundColor: theme.colors.primary, color: '#ffffff' }}>
                        Button
                      </div>
                    </div>
                  </div>
                  
                  <div className="theme-info">
                    <div className="theme-header">
                      <h3>{theme.name}</h3>
                      <span className={`category-badge ${getCategoryColor(theme.category)}`}>
                        {getCategoryIcon(theme.category)}
                        {theme.category}
                      </span>
                    </div>
                    <p className="theme-description">{theme.description}</p>
                    
                    <div className="theme-actions">
                      {theme.active ? (
                        <button className="btn-active" disabled>
                          <Check className="w-4 h-4" />
                          Active
                        </button>
                      ) : (
                        <button 
                          className="btn-apply"
                          onClick={() => applyTheme(theme.id)}
                          disabled={loading || !theme.installed}
                        >
                          Apply
                        </button>
                      )}
                      
                      {theme.installed ? (
                        <button 
                          className="btn-uninstall"
                          onClick={() => uninstallTheme(theme.id)}
                          disabled={loading || theme.active}
                        >
                          <X className="w-4 h-4" />
                          Uninstall
                        </button>
                      ) : (
                        <button 
                          className="btn-install"
                          onClick={() => installTheme(theme.id)}
                          disabled={loading}
                        >
                          <Download className="w-4 h-4" />
                          Install
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'profiles' && (
          <div className="profiles-tab">
            <div className="profiles-grid">
              {profiles.map((profile) => (
                <div key={profile.id} className="profile-card">
                  <div className="profile-header">
                    <h3>{profile.name}</h3>
                    {profile.active && (
                      <span className="active-badge">
                        <Check className="w-4 h-4" />
                        Active
                      </span>
                    )}
                  </div>
                  <p className="profile-description">{profile.description}</p>
                  
                  <div className="profile-theme">
                    <span>Theme: {themes.find(t => t.id === profile.theme)?.name || profile.theme}</span>
                  </div>
                  
                  <div className="profile-actions">
                    {!profile.active && (
                      <button 
                        className="btn-apply"
                        onClick={() => applyProfile(profile.id)}
                        disabled={loading}
                      >
                        Apply Profile
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'marketplace' && (
          <div className="marketplace-tab">
            <div className="marketplace-header">
              <h2>Theme Marketplace</h2>
              <p>Discover and install new themes from the community</p>
            </div>
            
            <div className="marketplace-filters">
              <input 
                type="text" 
                placeholder="Search themes..." 
                className="search-input"
              />
              <select className="filter-select">
                <option value="">All Categories</option>
                <option value="dark">Dark Themes</option>
                <option value="light">Light Themes</option>
                <option value="colorful">Colorful Themes</option>
                <option value="minimal">Minimal Themes</option>
              </select>
            </div>
            
            <div className="marketplace-content">
              <p className="coming-soon">🎨 Theme Marketplace coming soon!</p>
              <p>Browse and install themes from the Portal OS community.</p>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="settings-tab">
            <h2>Theme Settings</h2>
            
            <div className="settings-section">
              <h3>Auto-Theme Switching</h3>
              <div className="setting-item">
                <label>Enable automatic theme switching based on time:</label>
                <input type="checkbox" />
              </div>
              <div className="setting-item">
                <label>Light theme hours:</label>
                <input type="time" defaultValue="06:00" />
                <span>to</span>
                <input type="time" defaultValue="18:00" />
              </div>
            </div>
            
            <div className="settings-section">
              <h3>Theme Synchronization</h3>
              <div className="setting-item">
                <label>Sync themes across devices:</label>
                <input type="checkbox" />
              </div>
              <div className="setting-item">
                <label>Backup themes to cloud:</label>
                <input type="checkbox" />
              </div>
            </div>
            
            <div className="settings-section">
              <h3>Advanced Options</h3>
              <div className="setting-item">
                <label>Enable theme preview mode:</label>
                <button 
                  className="btn-toggle"
                  onClick={() => setPreviewMode(!previewMode)}
                >
                  {previewMode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  {previewMode ? 'Disable' : 'Enable'}
                </button>
              </div>
              <div className="setting-item">
                <label>Theme cache size:</label>
                <select defaultValue="100">
                  <option value="50">50 MB</option>
                  <option value="100">100 MB</option>
                  <option value="200">200 MB</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
