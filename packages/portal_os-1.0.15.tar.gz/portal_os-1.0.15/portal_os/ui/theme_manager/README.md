# Portal OS Theme Manager

A modern, AI-native theme management system for Portal OS, built with Tauri and React.

## Features

- **Multi-Theme Support**: Browse and apply different visual themes (Cutefish, Mac-like, Windows-like, Minimal)
- **Profile-Based Themes**: Automatically switch themes based on your current activity profile
- **Theme Marketplace**: Discover and install new themes (coming soon)
- **Real-time Preview**: See theme changes instantly
- **Global Hotkeys**: Quick theme switching with keyboard shortcuts
- **Theme Synchronization**: Sync themes across multiple devices
- **Advanced Customization**: Fine-tune theme parameters

## Quick Start

### Prerequisites

- Node.js 18+ and npm
- Rust and Cargo
- Tauri CLI

### Installation

1. **Clone and build**:
   ```bash
   cd portal_os/ui/theme_manager
   chmod +x build.sh
   ./build.sh
   ```

2. **Launch from Portal OS CLI**:
   ```bash
   portal-os run theme_manager
   ```

### Manual Build

```bash
npm install
npm run build
npm run tauri build
```

## Usage

### Basic Theme Management

1. **Browse Themes**: View available themes with color previews
2. **Apply Theme**: Click "Apply" to switch to a theme
3. **Install Themes**: Add new themes from the marketplace
4. **Uninstall**: Remove unwanted themes (except active theme)

### Profile Management

1. **Select Profile**: Choose from Developer, Studying, Watching, Gaming
2. **Auto-Switch**: Enable automatic theme switching based on profile
3. **Custom Profiles**: Create your own activity profiles

### Settings

- **Auto-theme switching**: Enable/disable automatic theme changes
- **Theme synchronization**: Sync themes across devices
- **Advanced options**: Custom theme parameters

## Architecture

### Frontend (React + TypeScript)

- **App.tsx**: Main application component
- **State Management**: React hooks for theme/profile state
- **UI Components**: Modern glassmorphism design
- **Hotkeys**: Global keyboard shortcuts

### Backend (Rust + Tauri)

- **Database**: SQLite for theme and profile storage
- **Commands**: Tauri commands for theme operations
- **File System**: Theme file management
- **System Integration**: Desktop environment integration

### Database Schema

```sql
-- Themes table
CREATE TABLE themes (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    colors TEXT,  -- JSON color palette
    is_active BOOLEAN DEFAULT FALSE,
    is_installed BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Profiles table
CREATE TABLE profiles (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    theme_id INTEGER,
    is_active BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (theme_id) REFERENCES themes(id)
);
```

## Configuration

The theme manager stores configuration in:
- `~/.portal-os/themes/theme_manager.db` - SQLite database
- `~/.portal-os/themes/` - Theme files and assets

## Development

### Project Structure

```
theme_manager/
├── src/
│   ├── App.tsx          # Main React component
│   └── App.css          # Styles
├── src-tauri/
│   ├── src/
│   │   └── main.rs      # Rust backend
│   ├── Cargo.toml       # Rust dependencies
│   └── tauri.conf.json  # Tauri configuration
├── package.json         # Node.js dependencies
├── build.sh            # Build script
└── README.md           # This file
```

### Adding New Themes

1. **Create theme definition** in the database
2. **Add theme assets** (icons, colors, styles)
3. **Update UI** to display the new theme
4. **Test integration** with profile system

### Adding New Profiles

1. **Create profile** in the database
2. **Associate with theme**
3. **Add profile-specific settings**
4. **Update UI** for profile management

## Troubleshooting

### Common Issues

1. **Build fails**: Ensure all prerequisites are installed
2. **Themes not loading**: Check database permissions
3. **Hotkeys not working**: Verify Tauri permissions
4. **Theme not applying**: Check desktop environment compatibility

### Debug Mode

```bash
npm run tauri dev
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

Part of Portal OS - AI-Native Developer Operating System
