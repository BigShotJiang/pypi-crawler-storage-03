#!/usr/bin/env python3
"""
Portal OS - Portal App (TUI Management Interface)
A beautiful, modern text-based user interface for comprehensive Portal OS management
"""
import os
import sys
import json
import subprocess
import sqlite3
import shutil
import time
import threading
from pathlib import Path
from datetime import datetime
import platform
import psutil
from typing import Dict, List, Optional, Tuple

# Textual imports
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Header, Footer, Static, Button, DataTable, ProgressBar, 
    Label, Input, Select, Checkbox, RichLog, Tree
)
from textual.widgets.data_table import RowKey
from textual.reactive import reactive
from textual import work
from textual.binding import Binding
from textual import events
from textual import on

# Fix Unicode encoding for Windows
if sys.platform == "win32":
    try:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
    except AttributeError:
        pass

class ComponentInfo:
    """Component information container"""
    def __init__(self, component_id: str, name: str, description: str, 
                 category: str, dependencies: List[str], script: str, 
                 size: str, install_time: str):
        self.id = component_id
        self.name = name
        self.description = description
        self.category = category
        self.dependencies = dependencies
        self.script = script
        self.size = size
        self.install_time = install_time
        self.installed = False
        self.status = "Not Installed"

class SystemInfo:
    """System information container"""
    def __init__(self):
        self.platform = platform.system()
        self.platform_version = platform.version()
        self.architecture = platform.machine()
        self.processor = platform.processor()
        self.python_version = sys.version.split()[0]
        self.cpu_count = psutil.cpu_count()
        self.memory_total = psutil.virtual_memory().total
        self.disk_usage = psutil.disk_usage('/')
        self.hostname = platform.node()
        self.username = os.getenv('USER', os.getenv('USERNAME', 'Unknown'))

class InstallationManager:
    """Manages component installation and tracking"""
    
    def __init__(self):
        self.portal_dir = Path.home() / ".portal-os"
        self.config_file = self.portal_dir / "config.json"
        self.db_path = self.portal_dir / "installer.db"
        self.installed_components = set()
        
        # Initialize directories and database
        self._init_directories()
        self._init_database()
        self._load_installed_components()
        
        # Component definitions
        self.components = {
            "ai_assistant": ComponentInfo(
                "ai_assistant", "🤖 AI Assistant", 
                "Conversational AI with context awareness", "AI",
                ["python3", "pip"], "ai_assistant.py", "15MB", "2-3 minutes"
            ),
            "security_privacy": ComponentInfo(
                "security_privacy", "🔒 Security & Privacy",
                "Advanced security and privacy management", "Security",
                ["python3", "cryptography"], "security_privacy_manager.py", "25MB", "3-5 minutes"
            ),
            "performance_optimizer": ComponentInfo(
                "performance_optimizer", "⚡ Performance Optimizer",
                "System performance optimization and monitoring", "System",
                ["python3", "psutil"], "performance_optimizer.py", "20MB", "2-4 minutes"
            ),
            "search_assistant": ComponentInfo(
                "search_assistant", "🔍 Search Assistant",
                "Intelligent file and content search", "Productivity",
                ["python3", "meilisearch"], "search_assistant_setup.py", "30MB", "4-6 minutes"
            ),
            "theme_manager": ComponentInfo(
                "theme_manager", "🎨 Theme Manager",
                "Visual theme and appearance management", "UI/UX",
                ["python3", "tkinter"], "theme_manager.py", "10MB", "1-2 minutes"
            ),
            "plugin_manager": ComponentInfo(
                "plugin_manager", "🔌 Plugin Manager",
                "Plugin system management and updates", "System",
                ["python3", "git"], "plugin_manager.py", "8MB", "1-2 minutes"
            ),
            "sdk_manager": ComponentInfo(
                "sdk_manager", "🔧 SDK Manager",
                "Development tools and SDK installation", "Development",
                ["python3", "curl"], "sdk_installer.py", "50MB", "5-10 minutes"
            )
        }
        
        # Update component status
        self._update_component_status()
    
    def _init_directories(self):
        """Initialize Portal OS directories"""
        self.portal_dir.mkdir(exist_ok=True)
        (self.portal_dir / "logs").mkdir(exist_ok=True)
        (self.portal_dir / "backups").mkdir(exist_ok=True)
        (self.portal_dir / "components").mkdir(exist_ok=True)
    
    def _init_database(self):
        """Initialize SQLite database for tracking installations"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS installations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT UNIQUE,
                name TEXT,
                version TEXT,
                install_date TEXT,
                status TEXT,
                config TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def _load_installed_components(self):
        """Load installed components from database"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("SELECT component_id FROM installations WHERE status = 'active'")
            self.installed_components = {row[0] for row in cursor.fetchall()}
            conn.close()
        except Exception as e:
            print(f"⚠️ Warning: Could not load installed components: {e}")
    
    def _update_component_status(self):
        """Update component installation status"""
        for component_id, component in self.components.items():
            component.installed = component_id in self.installed_components
            component.status = "Installed" if component.installed else "Not Installed"
    
    def get_system_info(self) -> SystemInfo:
        """Get system information"""
        return SystemInfo()
    
    def get_components_by_category(self) -> Dict[str, List[ComponentInfo]]:
        """Get components organized by category"""
        categories = {}
        for component in self.components.values():
            if component.category not in categories:
                categories[component.category] = []
            categories[component.category].append(component)
        return categories
    
    def check_dependencies(self, component_id: str) -> Tuple[bool, str]:
        """Check if component dependencies are met"""
        component = self.components.get(component_id)
        if not component:
            return False, "Component not found"
        
        missing_deps = []
        for dep in component.dependencies:
            if not self._check_dependency(dep):
                missing_deps.append(dep)
        
        if missing_deps:
            return False, f"Missing dependencies: {', '.join(missing_deps)}"
        
        return True, "All dependencies satisfied"
    
    def _check_dependency(self, dependency: str) -> bool:
        """Check if a specific dependency is available"""
        try:
            if dependency == "python3":
                return sys.version_info >= (3, 7)
            elif dependency == "pip":
                import pip
                return True
            elif dependency == "git":
                result = subprocess.run(["git", "--version"], capture_output=True, text=True)
                return result.returncode == 0
            elif dependency == "curl":
                result = subprocess.run(["curl", "--version"], capture_output=True, text=True)
                return result.returncode == 0
            else:
                __import__(dependency)
                return True
        except:
            return False
    
    def install_component(self, component_id: str, progress_callback=None) -> Tuple[bool, str]:
        """Install a specific component"""
        component = self.components.get(component_id)
        if not component:
            return False, "Component not found"
        
        if progress_callback:
            progress_callback(f"Installing {component.name}...")
        
        # Check dependencies
        deps_ok, deps_msg = self.check_dependencies(component_id)
        if not deps_ok:
            return False, deps_msg
        
        if progress_callback:
            progress_callback("Dependencies satisfied")
        
        # Simulate installation process
        steps = [
            "Downloading component files...",
            "Verifying integrity...",
            "Extracting files...",
            "Configuring component...",
            "Setting up database...",
            "Finalizing installation..."
        ]
        
        for i, step in enumerate(steps, 1):
            if progress_callback:
                progress_callback(f"Step {i}/6: {step}")
            time.sleep(0.5)  # Simulate work
        
        # Record installation in database
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO installations 
                (component_id, name, version, install_date, status, config)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                component_id,
                component.name,
                "1.0.0",
                datetime.now().isoformat(),
                "active",
                json.dumps({"installed": True})
            ))
            conn.commit()
            conn.close()
            
            self.installed_components.add(component_id)
            self._update_component_status()
            return True, "Installation completed successfully"
        except Exception as e:
            return False, f"Database error: {e}"
    
    def uninstall_component(self, component_id: str, progress_callback=None) -> Tuple[bool, str]:
        """Uninstall a specific component"""
        component = self.components.get(component_id)
        if not component:
            return False, "Component not found"
        
        if component_id not in self.installed_components:
            return False, "Component not installed"
        
        if progress_callback:
            progress_callback(f"Uninstalling {component.name}...")
        
        # Simulate uninstallation
        steps = [
            "Stopping component services...",
            "Removing component files...",
            "Cleaning up configuration...",
            "Removing from database...",
            "Uninstallation complete"
        ]
        
        for i, step in enumerate(steps, 1):
            if progress_callback:
                progress_callback(f"Step {i}/5: {step}")
            time.sleep(0.3)
        
        # Remove from database
        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute("DELETE FROM installations WHERE component_id = ?", (component_id,))
            conn.commit()
            conn.close()
            
            self.installed_components.discard(component_id)
            self._update_component_status()
            return True, "Uninstallation completed successfully"
        except Exception as e:
            return False, f"Database error: {e}"

class SystemInfoWidget(Static):
    """Widget to display system information"""
    
    def __init__(self, system_info: SystemInfo):
        super().__init__()
        self.system_info = system_info
    
    def compose(self) -> ComposeResult:
        yield Label("🖥️ System Information", classes="section-title")
        
        info_container = Vertical(classes="info-container")
        
        # Platform info
        platform_info = Horizontal(classes="info-row")
        platform_info.mount(Label("Platform:", classes="info-label"))
        platform_info.mount(Label(f"{self.system_info.platform} {self.system_info.platform_version}", classes="info-value"))
        info_container.mount(platform_info)
        
        # Architecture
        arch_info = Horizontal(classes="info-row")
        arch_info.mount(Label("Architecture:", classes="info-label"))
        arch_info.mount(Label(self.system_info.architecture, classes="info-value"))
        info_container.mount(arch_info)
        
        # Processor
        cpu_info = Horizontal(classes="info-row")
        cpu_info.mount(Label("Processor:", classes="info-label"))
        cpu_info.mount(Label(self.system_info.processor, classes="info-value"))
        info_container.mount(cpu_info)
        
        # Python version
        python_info = Horizontal(classes="info-row")
        python_info.mount(Label("Python:", classes="info-label"))
        python_info.mount(Label(self.system_info.python_version, classes="info-value"))
        info_container.mount(python_info)
        
        # CPU cores
        cores_info = Horizontal(classes="info-row")
        cores_info.mount(Label("CPU Cores:", classes="info-label"))
        cores_info.mount(Label(str(self.system_info.cpu_count), classes="info-value"))
        info_container.mount(cores_info)
        
        # Memory
        memory_info = Horizontal(classes="info-row")
        memory_info.mount(Label("Total Memory:", classes="info-label"))
        memory_info.mount(Label(f"{self.system_info.memory_total / (1024**3):.1f} GB", classes="info-value"))
        info_container.mount(memory_info)
        
        # Disk space
        disk_info = Horizontal(classes="info-row")
        disk_info.mount(Label("Disk Space:", classes="info-label"))
        disk_info.mount(Label(f"{self.system_info.disk_usage.total / (1024**3):.1f} GB", classes="info-value"))
        info_container.mount(disk_info)
        
        yield info_container

class ComponentTable(DataTable):
    """Data table for displaying components"""
    
    def __init__(self, components: List[ComponentInfo]):
        super().__init__()
        self.components = components
        self.show_header = True
        self.cursor_type = "row"
        
        # Add columns
        self.add_columns("Component", "Category", "Status", "Size", "Install Time")
        
        # Add rows
        for component in components:
            status_icon = "✅" if component.installed else "❌"
            self.add_row(
                component.name,
                component.category,
                f"{status_icon} {component.status}",
                component.size,
                component.install_time,
                key=component.id
            )

class InstallationProgress(Container):
    """Widget to show installation progress"""
    
    progress_text = reactive("")
    progress_percent = reactive(0)
    
    def compose(self) -> ComposeResult:
        yield Label("Installation Progress", classes="section-title")
        yield Label(self.progress_text, classes="progress-text")
        yield ProgressBar(total=100, show_eta=False)
    
    def update_progress(self, text: str, percent: int = None):
        """Update progress display"""
        self.progress_text = text
        if percent is not None:
            self.progress_percent = percent
        self.refresh()

class PortalApp(App):
    """Main Portal OS TUI Application - Comprehensive Portal OS Management Interface"""
    
    CSS = """
    #main {
        layout: horizontal;
        height: 100%;
    }
    
    #sidebar {
        width: 30%;
        border-right: solid green;
        padding: 1;
    }
    
    #content {
        width: 70%;
        padding: 1;
    }
    
    .section-title {
        text-style: bold;
        color: #00ff00;
        margin-bottom: 1;
    }
    
    .info-container {
        height: auto;
    }
    
    .info-row {
        height: 1;
        margin-bottom: 1;
    }
    
    .info-label {
        width: 30%;
        text-style: bold;
        color: #cccccc;
    }
    
    .info-value {
        width: 70%;
        color: #ffffff;
    }
    
    .button-container {
        height: auto;
        margin-top: 2;
    }
    
    .progress-text {
        color: #00ff00;
        margin-bottom: 1;
    }
    
    .status-success {
        color: #00ff00;
    }
    
    .status-error {
        color: #ff0000;
    }
    
    .status-warning {
        color: #ffff00;
    }
    
    #log {
        height: 20%;
        border-top: solid green;
        margin-top: 1;
    }
    """
    
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("1", "show_dashboard", "Dashboard"),
        Binding("2", "show_install", "Install"),
        Binding("3", "show_status", "Status"),
        Binding("4", "show_config", "Config"),
        Binding("5", "show_diagnostics", "Diagnostics"),
        Binding("h", "show_help", "Help"),
    ]
    
    def __init__(self):
        super().__init__()
        self.installer = InstallationManager()
        self.current_view = "dashboard"
        self.log_messages = []
    
    def compose(self) -> ComposeResult:
        """Compose the app layout"""
        yield Header(show_clock=True)
        
        with Container(id="main"):
            with Container(id="sidebar"):
                yield Label("🚀 Portal OS", classes="section-title")
                yield Button("📊 Dashboard", id="btn-dashboard", variant="primary")
                yield Button("🔧 Install Components", id="btn-install", variant="default")
                yield Button("📋 Component Status", id="btn-status", variant="default")
                yield Button("⚙️ Configuration", id="btn-config", variant="default")
                yield Button("🔍 Diagnostics", id="btn-diagnostics", variant="default")
                yield Button("📚 Help", id="btn-help", variant="default")
            
            with Container(id="content"):
                yield Static("Welcome to Portal OS Management Interface", id="content-area")
        
        yield RichLog(id="log", markup=True)
        yield Footer()
    
    def on_mount(self) -> None:
        """Called when the app is mounted"""
        self.show_dashboard()
    
    def show_dashboard(self) -> None:
        """Show the dashboard view"""
        self.current_view = "dashboard"
        content = self.query_one("#content-area", Static)
        
        system_info = self.installer.get_system_info()
        
        dashboard_content = f"""
[bold green]🚀 Portal OS Management Dashboard[/bold green]

[bold]System Information:[/bold]
🖥️ Platform: {system_info.platform} {system_info.platform_version}
🏗️ Architecture: {system_info.architecture}
🔧 Processor: {system_info.processor}
🐍 Python: {system_info.python_version}
💻 CPU Cores: {system_info.cpu_count}
💾 Memory: {system_info.memory_total / (1024**3):.1f} GB
💿 Disk: {system_info.disk_usage.total / (1024**3):.1f} GB

[bold]Quick Actions:[/bold]
• Press [bold]2[/bold] to install components
• Press [bold]3[/bold] to view component status
• Press [bold]4[/bold] to configure settings
• Press [bold]5[/bold] to run diagnostics

[bold]Navigation:[/bold]
• Use number keys (1-5) for quick navigation
• Use Tab to move between elements
• Press [bold]q[/bold] to quit
        """
        
        content.update(dashboard_content)
        self._update_button_states()
    
    def show_install(self) -> None:
        """Show the installation view"""
        self.current_view = "install"
        content = self.query_one("#content-area", Static)
        
        # Get components by category
        categories = self.installer.get_components_by_category()
        
        install_content = "[bold green]🔧 Component Installation[/bold green]\n\n"
        
        for category, components in categories.items():
            install_content += f"[bold]{category} Components:[/bold]\n"
            for component in components:
                status_icon = "✅" if component.installed else "❌"
                install_content += f"  {status_icon} {component.name} - {component.description}\n"
                install_content += f"      Size: {component.size} | Time: {component.install_time}\n"
            install_content += "\n"
        
        install_content += """
[bold]Installation Options:[/bold]
• [bold]Quick Install[/bold]: Install all components
• [bold]Custom Install[/bold]: Choose specific components
• [bold]Category Install[/bold]: Install by category

[bold]Controls:[/bold]
• Use Tab to navigate
• Space to select components
• Enter to start installation
        """
        
        content.update(install_content)
        self._update_button_states()
    
    def show_status(self) -> None:
        """Show the status view"""
        self.current_view = "status"
        content = self.query_one("#content-area", Static)
        
        total_components = len(self.installer.components)
        installed_count = len(self.installer.installed_components)
        installation_percentage = (installed_count / total_components) * 100
        
        status_content = f"""
[bold green]📊 Component Status[/bold green]

[bold]Installation Progress:[/bold]
📈 {installed_count}/{total_components} components installed ({installation_percentage:.1f}%)

[bold]Component Details:[/bold]
"""
        
        for component in self.installer.components.values():
            status_icon = "✅" if component.installed else "❌"
            status_content += f"{status_icon} {component.name}\n"
            status_content += f"   Category: {component.category}\n"
            status_content += f"   Status: {component.status}\n"
            status_content += f"   Description: {component.description}\n\n"
        
        content.update(status_content)
        self._update_button_states()
    
    def show_config(self) -> None:
        """Show the configuration view"""
        self.current_view = "config"
        content = self.query_one("#content-area", Static)
        
        config_content = """
[bold green]⚙️ Configuration Management[/bold green]

[bold]Available Profiles:[/bold]
🎯 Developer Profile
   • All development tools enabled
   • Performance optimization
   • Dark theme by default

📚 Studying Profile
   • Minimal interface
   • Distraction-free mode
   • Reading optimized

🎮 Gaming Profile
   • Performance mode
   • Gaming tools enabled
   • Windows-like interface

📺 Watching Profile
   • Dark mode
   • Media optimized
   • Entertainment focused

[bold]Configuration Options:[/bold]
• Profile Management
• Theme Configuration
• Security Settings
• Performance Settings
• Backup & Restore

[bold]Controls:[/bold]
• Use Tab to navigate
• Enter to select options
• Space to toggle settings
        """
        
        content.update(config_content)
        self._update_button_states()
    
    def show_diagnostics(self) -> None:
        """Show the diagnostics view"""
        self.current_view = "diagnostics"
        content = self.query_one("#content-area", Static)
        
        # Run diagnostics
        diagnostics = self._run_diagnostics()
        
        diagnostics_content = "[bold green]🔍 System Diagnostics[/bold green]\n\n"
        diagnostics_content += diagnostics
        
        content.update(diagnostics_content)
        self._update_button_states()
    
    def show_help(self) -> None:
        """Show the help view"""
        self.current_view = "help"
        content = self.query_one("#content-area", Static)
        
        help_content = """
[bold green]📚 Help & Documentation[/bold green]

[bold]Portal OS TUI Installer[/bold]
This tool provides a comprehensive interface for managing Portal OS components.

[bold]Main Features:[/bold]
• System Information - View detailed system specs
• Component Installation - Install individual or all components
• Status Monitoring - Check component status and performance
• Configuration Management - Manage settings and profiles
• System Diagnostics - Run comprehensive system checks

[bold]Installation Options:[/bold]
• Quick Install - Install all components at once
• Custom Install - Choose specific components
• Category Install - Install by component category
• Reinstall - Reinstall existing components
• Uninstall - Remove components

[bold]Keyboard Shortcuts:[/bold]
• [bold]1[/bold] - Dashboard
• [bold]2[/bold] - Install Components
• [bold]3[/bold] - Component Status
• [bold]4[/bold] - Configuration
• [bold]5[/bold] - Diagnostics
• [bold]h[/bold] - Help
• [bold]q[/bold] - Quit

[bold]Navigation:[/bold]
• Use Tab to move between elements
• Use arrow keys to navigate lists
• Use Space to select items
• Use Enter to confirm actions

[bold]Tips:[/bold]
• Check system requirements before installation
• Monitor system resources during installation
• Use diagnostics to troubleshoot issues
• Backup configuration before making changes
        """
        
        content.update(help_content)
        self._update_button_states()
    
    def _update_button_states(self) -> None:
        """Update button states based on current view"""
        buttons = {
            "btn-dashboard": "dashboard",
            "btn-install": "install",
            "btn-status": "status",
            "btn-config": "config",
            "btn-diagnostics": "diagnostics",
            "btn-help": "help"
        }
        
        for btn_id, view in buttons.items():
            button = self.query_one(f"#{btn_id}", Button)
            if view == self.current_view:
                button.variant = "primary"
            else:
                button.variant = "default"
    
    def _run_diagnostics(self) -> str:
        """Run system diagnostics"""
        diagnostics = []
        
        # Python environment
        diagnostics.append("[bold]🐍 Python Environment:[/bold]")
        diagnostics.append(f"   Version: {sys.version.split()[0]} ✅")
        diagnostics.append(f"   Platform: {sys.platform} ✅")
        diagnostics.append(f"   Executable: {sys.executable} ✅")
        diagnostics.append("")
        
        # Portal OS environment
        diagnostics.append("[bold]🚀 Portal OS Environment:[/bold]")
        diagnostics.append(f"   Portal Directory: {self.installer.portal_dir} ✅")
        diagnostics.append(f"   Config File: {self.installer.config_file} ✅")
        diagnostics.append(f"   Database: {self.installer.db_path} ✅")
        diagnostics.append("")
        
        # Component scripts
        diagnostics.append("[bold]📜 Component Scripts:[/bold]")
        scripts_dir = Path(__file__).parent
        for component in self.installer.components.values():
            script_path = scripts_dir / component.script
            if script_path.exists():
                diagnostics.append(f"   {component.name}: ✅ Found")
            else:
                diagnostics.append(f"   {component.name}: ❌ Missing")
        diagnostics.append("")
        
        # Dependencies
        diagnostics.append("[bold]🔧 Dependencies:[/bold]")
        for component in self.installer.components.values():
            deps_ok, deps_msg = self.installer.check_dependencies(component.id)
            status = "✅" if deps_ok else "❌"
            diagnostics.append(f"   {component.name}: {status} {deps_msg}")
        diagnostics.append("")
        
        diagnostics.append("✅ Diagnostics completed!")
        
        return "\n".join(diagnostics)
    
    def _log_message(self, message: str, level: str = "info") -> None:
        """Add a message to the log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        color = {
            "info": "white",
            "success": "green",
            "error": "red",
            "warning": "yellow"
        }.get(level, "white")
        
        log_entry = f"[{timestamp}] [{color}]{message}[/{color}]"
        self.log_messages.append(log_entry)
        
        # Keep only last 50 messages
        if len(self.log_messages) > 50:
            self.log_messages.pop(0)
        
        # Update log display
        log_widget = self.query_one("#log", RichLog)
        log_widget.clear()
        for msg in self.log_messages:
            log_widget.write(msg)
    
    # Event handlers
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id
        
        if button_id == "btn-dashboard":
            self.show_dashboard()
        elif button_id == "btn-install":
            self.show_install()
        elif button_id == "btn-status":
            self.show_status()
        elif button_id == "btn-config":
            self.show_config()
        elif button_id == "btn-diagnostics":
            self.show_diagnostics()
        elif button_id == "btn-help":
            self.show_help()
    
    # Action handlers
    def action_show_dashboard(self) -> None:
        """Action to show dashboard"""
        self.show_dashboard()
    
    def action_show_install(self) -> None:
        """Action to show install"""
        self.show_install()
    
    def action_show_status(self) -> None:
        """Action to show status"""
        self.show_status()
    
    def action_show_config(self) -> None:
        """Action to show config"""
        self.show_config()
    
    def action_show_diagnostics(self) -> None:
        """Action to show diagnostics"""
        self.show_diagnostics()
    
    def action_show_help(self) -> None:
        """Action to show help"""
        self.show_help()

def run_text_based_interface():
    """Run a text-based interface when TUI is not supported"""
    print("🚀 Portal OS - Text-Based Interface")
    print("=" * 50)
    
    while True:
        print("\n📋 Available Options:")
        print("1. 📊 System Status")
        print("2. 🔧 Component Status")
        print("3. ⚙️ Configuration")
        print("4. 🔍 Diagnostics")
        print("5. 📚 Help")
        print("0. 🚪 Exit")
        
        try:
            choice = input("\n🎯 Select an option (0-5): ").strip()
            
            if choice == "0":
                print("👋 Goodbye!")
                break
            elif choice == "1":
                print("\n📊 System Status:")
                print("-" * 30)
                # Import and run status command
                import subprocess
                import sys
                subprocess.run([sys.executable, "-m", "portal_os.cli", "status"])
            elif choice == "2":
                print("\n🔧 Component Status:")
                print("-" * 30)
                import subprocess
                import sys
                subprocess.run([sys.executable, "-m", "portal_os.cli", "components"])
            elif choice == "3":
                print("\n⚙️ Configuration:")
                print("-" * 30)
                import subprocess
                import sys
                subprocess.run([sys.executable, "-m", "portal_os.cli", "config"])
            elif choice == "4":
                print("\n🔍 Diagnostics:")
                print("-" * 30)
                import subprocess
                import sys
                subprocess.run([sys.executable, "-m", "portal_os.cli", "doctor"])
            elif choice == "5":
                print("\n📚 Help:")
                print("-" * 30)
                print("Portal OS is an AI-Native Developer Operating System")
                print("For more information, visit: https://github.com/your-org/portal-os")
                print("\nAvailable commands:")
                print("  portal-os status     - Show system status")
                print("  portal-os components - Show component details")
                print("  portal-os install    - Install components")
                print("  portal-os doctor     - Run diagnostics")
            else:
                print("❌ Invalid option. Please select 0-5.")
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")

def run_portal_app():
    """Run the Portal OS TUI Application"""
    # Check if terminal supports TUI mode
    import os
    import sys
    
    # Check if we're in a compatible terminal
    term = os.environ.get('TERM', '')
    is_windows = sys.platform == "win32"
    
    # Quick bypass for testing
    if os.environ.get('PORTAL_OS_TEXT_ONLY'):
        print("🚀 Launching text-based interface directly...")
        run_text_based_interface()
        return
    
    # Allow bypassing terminal check with environment variable
    if os.environ.get('PORTAL_OS_FORCE_TUI'):
        print("🚀 Force launching TUI mode...")
        try:
            app = PortalApp()
            app.run()
            return
        except Exception as e:
            print(f"❌ TUI launch failed: {e}")
            return
    
    if is_windows:
        # Windows terminal compatibility check - be more permissive
        # Check if we're in a modern terminal that might support TUI
        modern_terminal = (
            os.environ.get('WT_SESSION') or 
            os.environ.get('TERMINAL_EMULATOR') or
            os.environ.get('WT_PROFILE_ID') or
            'WindowsTerminal' in os.environ.get('PROMPT', '') or
            'WindowsTerminal' in os.environ.get('TERM_PROGRAM', '')
        )
        
        if not modern_terminal:
            print("⚠️ Terminal compatibility uncertain")
            print("💡 Trying to launch TUI anyway...")
            print("   If it fails, use these alternatives:")
            print("   portal-os status")
            print("   portal-os components")
            print("   portal-os install")
            print()
    else:
        # Unix/Linux terminal compatibility check
        if term in ['dumb', 'unknown'] or not term:
            print("❌ Terminal doesn't support TUI mode")
            print("💡 Try using a different terminal or use the interactive installer:")
            print("   portal-os interactive")
            print("\n🔧 Alternative: Use the standard CLI commands:")
            print("   portal-os status")
            print("   portal-os components")
            print("   portal-os install")
            return
    
    try:
        app = PortalApp()
        app.run()
    except Exception as e:
        error_msg = str(e)
        if "Driver must be in application mode" in error_msg or "terminal" in error_msg.lower():
            print("❌ Terminal compatibility issue detected")
            print("💡 This is a known issue with certain terminal configurations")
            print("🔧 Launching text-based interface instead...")
            print()
            run_text_based_interface()
        else:
            print(f"❌ Failed to launch Portal App: {e}")
            print("💡 Try using the standard CLI commands:")
            print("   portal-os status")
            print("   portal-os components")
            print("   portal-os install")

if __name__ == "__main__":
    run_portal_app()
