# Ignore the alembic folder
collect_ignore = ["src/climate_ref_celery/celeryconf"]
