import src.metrics.bot_info_metrics  # noqa
