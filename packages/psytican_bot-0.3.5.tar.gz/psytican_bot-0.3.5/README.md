# Psytican chat helper bot

This bot can help you to book an event, list upcoming events and edit or delete your booking.
