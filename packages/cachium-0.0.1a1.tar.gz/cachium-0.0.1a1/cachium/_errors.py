from __future__ import annotations


class NoKwargsError(Exception):
    pass
