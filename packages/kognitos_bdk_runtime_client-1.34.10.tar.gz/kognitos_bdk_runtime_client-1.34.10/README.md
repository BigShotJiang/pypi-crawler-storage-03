# Kognitos BDK Runtime Client

Python client library for the Kognitos Book Development Kit (BDK) runtime. This package implements the BCI 3 protocol client with a pluggable transport mechanism, supporting AWS Lambda and other runtime environments.

## Contributing

See [CONTRIB.md](CONTRIB.md) for development setup and contribution guidelines.
