#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
The import that talks about some version differences is placed here.
"""
__all__ = []


from . import _requests
