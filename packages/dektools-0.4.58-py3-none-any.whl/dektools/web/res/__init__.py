from pathlib import Path

path_res = Path(__file__).resolve().parent

path_mime_data = path_res / 'mimeData.json'

path_js = path_res / '.js'
