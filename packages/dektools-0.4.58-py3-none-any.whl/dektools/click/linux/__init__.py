import typer

app = typer.Typer(add_completion=False)
