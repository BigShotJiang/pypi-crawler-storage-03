venv_list = ('.venv', 'venv', 'env')

venv_main = venv_list[0]

venv_config_file = 'pyvenv.cfg'

venv_this = 'activate_this.py'
