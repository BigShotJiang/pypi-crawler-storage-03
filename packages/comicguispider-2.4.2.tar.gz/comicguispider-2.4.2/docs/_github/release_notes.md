
> [!Tip]  
> win-绿色包注意：`_pystand_static.int`首行 version 非 `v1` 或没 version 时，需要重新下绿色包解压覆盖以支持后续功能  

## 🎁 Feat

✅ 新增支持 kemono 的 discord 资源下载  
✅ 配置窗口新增 ui语言切换，同时更新了 ui，去重、增加标识改为图标触发按钮，详情查阅 [🔨主配置文档](https://jasoneri.github.io/ComicGUISpider/config)

## 🐞 Fix

✅ 优化 kemono 过滤相关, 增加发送提示  
✅ 修复系统语言非简中时导致卡死在启动界面的情况  
