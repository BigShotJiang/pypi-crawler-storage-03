from setuptools import setup

setup(name = "personalityai",
	version = "0.1.0",
	description = "A Python package for creating AI personalities with multiple personas.",
	author = "Ime Inyang",
	author_email = "alfiinyang@gmail.com",
	packages = ['personality','personality.experiments'])