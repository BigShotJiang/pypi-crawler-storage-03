# personalityai/__init__.py

__version__ = "0.1.0"

# You can optionally import key classes/functions here for easier access
# from .Person import Person
# from .Persona import Persona
from .create import Person
from .create import Persona