2025-02-20 Version: 1.2.1
- Update API SendCustomEvent: add param EventMarkdown.


2025-01-15 Version: 1.2.0
- Support API ConfirmDjbhReport.
- Support API CreateServiceLinkedRole.
- Support API DeleteDjbhReport.
- Support API DescribeServiceLinkedRole.
- Update API CreateServiceWorkOrder: add param IsMilestone.
- Update API GetDocumentDownloadUrl: add param ReportType.
- Update API GetDocumentPage: update response param.


2024-12-19 Version: 1.1.0
- Support API ConfirmDjbhReport.
- Support API CreateServiceLinkedRole.
- Support API DeleteDjbhReport.
- Support API DescribeServiceLinkedRole.
- Update API GetDocumentDownloadUrl: add param ReportType.
- Update API GetDocumentPage: update response param.


2024-12-10 Version: 1.0.0
- Support API GetConsoleScore.


