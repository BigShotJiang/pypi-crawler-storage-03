# Changelog

## 0.1.0-alpha.5 (2025-08-18)

Full Changelog: [v0.1.0-alpha.4...v0.1.0-alpha.5](https://github.com/dedalus-labs/dedalus-sdk-python/compare/v0.1.0-alpha.4...v0.1.0-alpha.5)

### Features

* **api:** api update ([8f0cc6e](https://github.com/dedalus-labs/dedalus-sdk-python/commit/8f0cc6eb025ab9c77959390cf26031383bd07001))
* **api:** chat completions ([8ac1a23](https://github.com/dedalus-labs/dedalus-sdk-python/commit/8ac1a23d9c1c37d4de90073dfad6149c83bba2fa))
* **api:** Config update for dedalus-ai/dev ([628cad2](https://github.com/dedalus-labs/dedalus-sdk-python/commit/628cad286ab5da905070f3b8cfb6745b9d9fa29d))
* **api:** dedalus model update ([5556fa3](https://github.com/dedalus-labs/dedalus-sdk-python/commit/5556fa35efbc79ebca565e2cc343b5352c1b10d7))
* **api:** fixing streaming again ([5941d46](https://github.com/dedalus-labs/dedalus-sdk-python/commit/5941d4689192cd099836d201b386ab1503c1fe2b))
* **api:** logic adj ([a45af92](https://github.com/dedalus-labs/dedalus-sdk-python/commit/a45af925e9dcf78e96759532fefdf107f011177e))
* **api:** manual updates ([c4e5b78](https://github.com/dedalus-labs/dedalus-sdk-python/commit/c4e5b787260c849d231961f5cd22369914f41485))
* **api:** ModelConfig ([984626d](https://github.com/dedalus-labs/dedalus-sdk-python/commit/984626d0bc599656a3cdf9c475f4555d1008983a))
* **api:** polished types ([8630870](https://github.com/dedalus-labs/dedalus-sdk-python/commit/863087056b6ccbdcfd40aaf6d4f4e7f203504e97))
* **api:** spec concise ([a38503a](https://github.com/dedalus-labs/dedalus-sdk-python/commit/a38503a65686e3d621f1824536ec1ab6c81515d3))
* **api:** streaming change ([9a6fd36](https://github.com/dedalus-labs/dedalus-sdk-python/commit/9a6fd36da06e70617706dbd4ca4d5a918eea63bb))
* **api:** to_schema and Model class ([3bd4b91](https://github.com/dedalus-labs/dedalus-sdk-python/commit/3bd4b9173773b28ddda3707dfd0dc2fc408dc0a7))
* **api:** update types ([c4baf45](https://github.com/dedalus-labs/dedalus-sdk-python/commit/c4baf451c36f6148aa9e4ab0bc2e8b47c863a8c4))


### Chores

* **internal:** codegen related update ([11afb95](https://github.com/dedalus-labs/dedalus-sdk-python/commit/11afb95b52fbb39f028b3af9671caf5d3971ecb1))
* **internal:** update comment in script ([9c49fad](https://github.com/dedalus-labs/dedalus-sdk-python/commit/9c49fad176ac16c1b204261229a1e385df62df0f))
* update @stainless-api/prism-cli to v5.15.0 ([ce42854](https://github.com/dedalus-labs/dedalus-sdk-python/commit/ce428545f33a6d02b9b1497a2cd93f4af0cb1740))

## 0.1.0-alpha.4 (2025-08-07)

Full Changelog: [v0.1.0-alpha.3...v0.1.0-alpha.4](https://github.com/dedalus-labs/dedalus-sdk-python/compare/v0.1.0-alpha.3...v0.1.0-alpha.4)

### Features

* **api:** streaming schemas ([4a98e16](https://github.com/dedalus-labs/dedalus-sdk-python/commit/4a98e16c5cb406ecabcc30e262299d2eed3517bf))


### Chores

* **internal:** fix ruff target version ([59fdbfc](https://github.com/dedalus-labs/dedalus-sdk-python/commit/59fdbfc95857204f04c35acd156665a54a7825c6))

## 0.1.0-alpha.3 (2025-08-05)

Full Changelog: [v0.1.0-alpha.2...v0.1.0-alpha.3](https://github.com/dedalus-labs/dedalus-sdk-python/compare/v0.1.0-alpha.2...v0.1.0-alpha.3)

### Features

* **api:** add streaming ([745c331](https://github.com/dedalus-labs/dedalus-sdk-python/commit/745c33166a671b79a978961d576064618cc80bcb))
* **api:** add streaming configuration ([0172ad5](https://github.com/dedalus-labs/dedalus-sdk-python/commit/0172ad5175dd15650252a084f213b16c56b8befc))
* **api:** revert streaming for now ([56d57d5](https://github.com/dedalus-labs/dedalus-sdk-python/commit/56d57d5a19034eec13d5a98a86d133d36ac2830a))
* **client:** support file upload requests ([caadecd](https://github.com/dedalus-labs/dedalus-sdk-python/commit/caadecdf5c75297819cd41fe3adcc5f7af3de772))

## 0.1.0-alpha.2 (2025-07-30)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/dedalus-labs/dedalus-sdk-python/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Features

* **api:** api update ([280a595](https://github.com/dedalus-labs/dedalus-sdk-python/commit/280a595b3d3900625cfdf26be12027a88eff9618))

## 0.1.0-alpha.1 (2025-07-30)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/dedalus-labs/dedalus-sdk-python/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** update via SDK Studio ([9407b44](https://github.com/dedalus-labs/dedalus-sdk-python/commit/9407b44fa8dbd4df7c18c36eab95a5573399810a))
