"""Simulation helpers for failure analyses.

Contains small helpers used to drive simulations in tests and examples. The
main orchestration lives in `manager.py`.
"""

from __future__ import annotations
