from setuptools import setup,Extension,find_packages

setup(
    name="second_module",
    version="0.1",
    packages=find_packages(),
    description="My second module for practice",
)