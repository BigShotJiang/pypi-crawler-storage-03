class second:
    def second_module(self):
        print("Hello from second module")

obj=second()
obj.second_module()
