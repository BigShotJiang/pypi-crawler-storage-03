name = "app_simulator"

__all_ = ("__main__",)
