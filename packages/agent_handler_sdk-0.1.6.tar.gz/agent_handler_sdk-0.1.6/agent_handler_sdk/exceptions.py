class ToolError(Exception):
    """Generic error raised by tool invocation failures."""

    pass
