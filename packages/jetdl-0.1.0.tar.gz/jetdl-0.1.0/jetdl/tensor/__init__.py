from .tensor import Tensor, tensor

__all__ = [
    "Tensor",
    "tensor",
]
