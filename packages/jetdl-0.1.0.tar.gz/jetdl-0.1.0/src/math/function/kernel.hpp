#pragma once

void c_total_sum_cpu(const float* src, float* dest, const int size);
void c_sum_cpu(const float* src, float* dest, const int* dest_idxs, const int size);