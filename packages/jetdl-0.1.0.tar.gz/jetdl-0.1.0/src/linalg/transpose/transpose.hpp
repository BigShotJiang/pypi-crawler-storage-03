#pragma once

#include "../../tensor/tensor.hpp"

Tensor c_transpose(const Tensor& a);
Tensor c_matrix_transpose(const Tensor& a);