"""Allow myrandr to be run as a module with python -m myrandr."""

from myrandr.cli import main

if __name__ == '__main__':
    main()
