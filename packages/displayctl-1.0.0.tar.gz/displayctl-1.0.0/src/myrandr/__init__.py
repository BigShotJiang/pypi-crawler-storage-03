"""MyRandr - Monitor Configuration Manager for GNOME."""

__version__ = "1.0.0"
__author__ = "MyRandr Contributors"
__description__ = "Monitor Configuration Manager for GNOME"
