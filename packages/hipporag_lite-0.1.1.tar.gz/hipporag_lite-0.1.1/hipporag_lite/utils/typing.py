from typing import Dict, Any, List, TypedDict, Tuple

Triple = Tuple[str, str, str]