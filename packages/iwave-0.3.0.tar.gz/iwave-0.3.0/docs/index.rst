.. IWaVE documentation master file, created by
   sphinx-quickstart on Thu Jun  6 15:47:16 2024.

Welcome to IWaVE's documentation!
=================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   installation.rst
   user_guide.rst
   api.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
