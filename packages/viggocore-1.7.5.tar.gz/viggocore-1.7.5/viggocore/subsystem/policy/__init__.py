from viggocore.common import subsystem
from viggocore.subsystem.policy import resource

subsystem = subsystem.Subsystem(resource=resource.Policy)
