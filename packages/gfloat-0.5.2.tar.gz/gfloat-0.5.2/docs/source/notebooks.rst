.. Copyright (c) 2024 Graphcore Ltd. All rights reserved.

Notebooks
=========

Some notebooks to illustrate uses of the library

.. toctree::
   :maxdepth: 1

   01-decode.ipynb
   02-value-stats.ipynb
   03-value-tables.ipynb
   04-benchmark.ipynb
   05-stochastic-rounding.ipynb
