"""typing.

This module define some utilities types used on algorithms.

"""

from typing import Union

from numpy import ndarray

InitCentroid = Union[str, ndarray]
