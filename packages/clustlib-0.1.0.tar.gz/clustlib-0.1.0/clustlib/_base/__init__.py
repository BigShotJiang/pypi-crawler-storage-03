"""Base module for clustering library.

This module provides some clustering algorithms aim to be used in the
internal of the library
"""
