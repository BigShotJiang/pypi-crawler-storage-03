# Copyright 2024 Remy Blank <remy@c-space.org>
# SPDX-License-Identifier: MIT

__project__ = 't-doc-common'
__version__ = '0.59'
