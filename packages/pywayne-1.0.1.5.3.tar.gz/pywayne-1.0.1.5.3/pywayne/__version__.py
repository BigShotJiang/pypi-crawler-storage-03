# author: wangye(Wayne)
# license: Apache Licence
# file: __version__.py
# time: 2023-08-09-14:03:33
# contact: wang121ye@hotmail.com
# site:  wangyendt@github.com
# software: PyCharm
# code is far away from bugs.


__version__ = "1.0.1.5.3"
