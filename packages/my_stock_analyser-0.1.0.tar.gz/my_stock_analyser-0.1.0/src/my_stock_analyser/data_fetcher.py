"""
Data Fetcher Module

This module handles fetching stock market data from various sources.
Primary: Google Finance
Fallback: Yahoo Finance
"""
import os
import time
from datetime import datetime, timedelta
import pandas as pd
import yfinance as yf
from googlefinance import getQuotes
import requests
from bs4 import BeautifulSoup
from typing import Dict, List, Optional, Tuple, Union
import logging
from pathlib import Path

from config.config import DATA_DIR, TOP_BSE_STOCKS, ALPHA_VANTAGE_API_KEY

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'data_fetcher.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DataFetcher:
    """Handles fetching of stock market data from various sources."""
    
    def __init__(self, use_cache: bool = True):
        """
        Initialize the DataFetcher.
        
        Args:
            use_cache: Whether to use cached data if available
        """
        self.use_cache = use_cache
        self.cache_dir = DATA_DIR / 'cache'
        self.cache_dir.mkdir(exist_ok=True)
    
    def _get_cached_data(self, symbol: str, days: int = 365) -> Optional[pd.DataFrame]:
        """Get data from cache if available and not expired."""
        if not self.use_cache:
            return None
            
        cache_file = self.cache_dir / f"{symbol.replace('.', '_')}.pkl"
        if not cache_file.exists():
            return None
            
        # Check if cache is fresh (less than 1 day old for daily data)
        cache_age = datetime.now() - datetime.fromtimestamp(cache_file.stat().st_mtime)
        if cache_age > timedelta(days=1):
            return None
            
        try:
            logger.info(f"Loading cached data for {symbol}")
            return pd.read_pickle(cache_file)
        except Exception as e:
            logger.warning(f"Error loading cached data for {symbol}: {e}")
            return None
    
    def _save_to_cache(self, symbol: str, data: pd.DataFrame):
        """Save data to cache."""
        if not self.use_cache:
            return
            
        try:
            cache_file = self.cache_dir / f"{symbol.replace('.', '_')}.pkl"
            data.to_pickle(cache_file)
        except Exception as e:
            logger.warning(f"Error saving data to cache for {symbol}: {e}")
    
    def fetch_google_finance(self, symbol: str, days: int = 365) -> Optional[pd.DataFrame]:
        """
        Fetch historical data from Google Finance.
        
        Note: The Google Finance API is no longer officially supported.
        This is a basic implementation that may not work reliably.
        
        Args:
            symbol: Stock symbol (e.g., 'RELIANCE.BO')
            days: Number of days of historical data to fetch
            
        Returns:
            DataFrame with historical data or None if failed
        """
        try:
            logger.info(f"Fetching data from Google Finance for {symbol}")
            
            # Get current quotes (limited functionality in current googlefinance)
            quotes = getQuotes(symbol)
            if not quotes:
                logger.warning(f"No data returned from Google Finance for {symbol}")
                return None
                
            # Create a DataFrame with current quote data
            df = pd.DataFrame([quotes[0]])
            
            # Convert timestamp to datetime
            if 'LastTradeDateTime' in df.columns:
                df['Date'] = pd.to_datetime(df['LastTradeDateTime'])
            else:
                df['Date'] = datetime.now()
                
            # Set Date as index
            df.set_index('Date', inplace=True)
            
            # Rename columns to match expected format
            column_mapping = {
                'LastTradePrice': 'Close',
                'LastTradeWithCurrency': 'Close',
                'Open': 'Open',
                'High': 'High',
                'Low': 'Low',
                'Volume': 'Volume'
            }
            
            # Only include columns that exist in the data
            df = df.rename(columns={k: v for k, v in column_mapping.items() if k in df.columns})
            
            # Ensure we have the required columns
            for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
                if col not in df.columns:
                    df[col] = None
                    
            # Select only the columns we need
            df = df[['Open', 'High', 'Low', 'Close', 'Volume']]
            
            # Convert numeric columns to float
            for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
                if df[col].notna().any():
                    df[col] = pd.to_numeric(df[col], errors='coerce')
                    
            # Since we only get current data, duplicate it for the requested period
            # This is a limitation of the current googlefinance package
            if len(df) > 0:
                date_range = pd.date_range(end=datetime.now(), periods=days)
                df = pd.DataFrame(index=date_range, columns=df.columns)
                df.iloc[-1] = df.iloc[0]  # Fill last row with current data
                df = df.ffill()  # Forward fill to fill the rest
                
            return df
            data = get_price_data(param)
            
            if data is None or data.empty:
                logger.warning(f"No data returned from Google Finance for {symbol}")
                return None
                
            # Standardize column names
            data.columns = [col.lower() for col in data.columns]
            
            # Add symbol column
            data['symbol'] = symbol
            
            # Save to cache
            self._save_to_cache(symbol, data)
            
            return data
            
        except Exception as e:
            logger.error(f"Error fetching data from Google Finance for {symbol}: {e}")
            return None
    
    def fetch_yahoo_finance(self, symbol: str, period: str = '1y') -> Optional[pd.DataFrame]:
        """
        Fetch historical data from Yahoo Finance.
        
        Args:
            symbol: Stock symbol (e.g., 'RELIANCE.BO')
            period: Time period to fetch (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
            
        Returns:
            DataFrame with historical data or None if failed
        """
        try:
            logger.info(f"Fetching data from Yahoo Finance for {symbol}")
            
            # Download data using yfinance
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period, interval='1d')
            
            if data is None or data.empty:
                logger.warning(f"No data returned from Yahoo Finance for {symbol}")
                return None
                
            # Standardize column names
            data.columns = [col.lower() for col in data.columns]
            
            # Add symbol column
            data['symbol'] = symbol
            
            # Save to cache
            self._save_to_cache(symbol, data)
            
            return data
            
        except Exception as e:
            logger.error(f"Error fetching data from Yahoo Finance for {symbol}: {e}")
            return None
    
    def fetch_alpha_vantage(self, symbol: str, outputsize: str = 'full') -> Optional[pd.DataFrame]:
        """
        Fetch historical data from Alpha Vantage.
        
        Args:
            symbol: Stock symbol (without exchange suffix)
            outputsize: 'compact' (last 100 data points) or 'full' (up to 20 years)
            
        Returns:
            DataFrame with historical data or None if failed
        """
        if not ALPHA_VANTAGE_API_KEY or ALPHA_VANTAGE_API_KEY == 'YOUR_ALPHA_VANTAGE_API_KEY':
            logger.warning("Alpha Vantage API key not configured")
            return None
            
        try:
            logger.info(f"Fetching data from Alpha Vantage for {symbol}")
            
            # Alpha Vantage API endpoint
            url = (
                'https://www.alphavantage.co/query?'
                'function=TIME_SERIES_DAILY_ADJUSTED&'
                f'symbol={symbol}&'
                f'outputsize={outputsize}&'
                f'datatype=json&'
                f'apikey={ALPHA_VANTAGE_API_KEY}'
            )
            
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            
            # Check for error message
            if 'Error Message' in data:
                logger.error(f"Alpha Vantage API error: {data['Error Message']}")
                return None
                
            # Extract time series data
            time_series = data.get('Time Series (Daily)', {})
            if not time_series:
                logger.warning(f"No time series data found for {symbol}")
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame.from_dict(time_series, orient='index', dtype=float)
            
            # Convert index to datetime
            df.index = pd.to_datetime(df.index)
            
            # Standardize column names
            df.columns = [col.split('. ')[1].lower() for col in df.columns]
            
            # Add symbol column
            df['symbol'] = symbol
            
            # Sort by date
            df = df.sort_index()
            
            # Save to cache
            self._save_to_cache(symbol, df)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data from Alpha Vantage for {symbol}: {e}")
            return None
    
    def fetch_stock_data(self, symbol: str, days: int = 365) -> Optional[pd.DataFrame]:
        """
        Fetch stock data with fallback mechanism.
        
        Args:
            symbol: Stock symbol (e.g., 'RELIANCE.BO')
            days: Number of days of historical data to fetch
            
        Returns:
            DataFrame with historical data or None if all sources fail
        """
        # Try to get data from cache first
        cached_data = self._get_cached_data(symbol, days)
        if cached_data is not None:
            return cached_data
        
        # # Try Google Finance first
        # data = self.fetch_google_finance(symbol, days)
        
        # Fallback to Yahoo Finance
        if data is None or data.empty:
            period = f"{days}d" if days < 365 else f"{days//365}y"
            data = self.fetch_yahoo_finance(symbol, period)
        
        # Fallback to Alpha Vantage (if API key is configured)
        if (data is None or data.empty) and ALPHA_VANTAGE_API_KEY != 'YOUR_ALPHA_VANTAGE_API_KEY':
            # Remove exchange suffix for Alpha Vantage
            base_symbol = symbol.split('.')[0]
            data = self.fetch_alpha_vantage(base_symbol)
        
        return data
    
    def fetch_multiple_stocks(self, symbols: List[str], days: int = 365) -> Dict[str, pd.DataFrame]:
        """
        Fetch data for multiple stocks.
        
        Args:
            symbols: List of stock symbols
            days: Number of days of historical data to fetch
            
        Returns:
            Dictionary mapping symbols to DataFrames
        """
        results = {}
        for symbol in symbols:
            data = self.fetch_stock_data(symbol, days)
            if data is not None and not data.empty:
                results[symbol] = data
            else:
                logger.warning(f"Failed to fetch data for {symbol}")
        return results
        
    # NIFTY 50 sector weights (approximate, should be updated with latest data)
    NIFTY_SECTOR_WEIGHTS = {
        'Financial Services': 37.0,
        'IT': 13.5,
        'Oil & Gas': 12.8,
        'Consumer Goods': 11.2,
        'Automobile': 5.7,
        'Pharma': 4.1,
        'Metals & Mining': 3.8,
        'Construction': 3.5,
        'Power': 2.9,
        'Telecom': 2.8,
        'Cement': 1.7,
        'Others': 0.0  # Will be calculated
    }
    
    # Sample stocks in each sector (for demonstration)
    SECTOR_STOCKS = {
        'Financial Services': ['HDFCBANK.NS', 'ICICIBANK.NS', 'SBIN.NS', 'HDFC.NS', 'KOTAKBANK.NS', 'AXISBANK.NS'],
        'IT': ['TCS.NS', 'INFY.NS', 'HCLTECH.NS', 'TECHM.NS', 'WIPRO.NS'],
        'Oil & Gas': ['RELIANCE.NS', 'ONGC.NS', 'IOC.NS', 'BPCL.NS', 'GAIL.NS'],
        'Consumer Goods': ['HINDUNILVR.NS', 'ITC.NS', 'NESTLEIND.NS', 'BRITANNIA.NS', 'TATACONSUM.NS'],
        'Automobile': ['TATAMOTORS.NS', 'MARUTI.NS', 'M&M.NS', 'BAJAJ-AUTO.NS', 'EICHERMOT.NS'],
        'Pharma': ['SUNPHARMA.NS', 'DRREDDY.NS', 'CIPLA.NS', 'DIVISLAB.NS', 'LUPIN.NS'],
        'Metals & Mining': ['TATASTEEL.NS', 'HINDALCO.NS', 'JSWSTEEL.NS', 'VEDL.NS', 'COALINDIA.NS'],
        'Construction': ['LT.NS', 'ULTRACEMCO.NS', 'GRASIM.NS', 'ADANIPORTS.NS', 'SHREECEM.NS'],
        'Power': ['NTPC.NS', 'POWERGRID.NS', 'TATAPOWER.NS', 'TORNTPHARM.NS'],
        'Telecom': ['BHARTIARTL.NS', 'VODAFONEIDEA.NS'],
        'Cement': ['ULTRACEMCO.NS', 'SHREECEM.NS', 'ACC.NS', 'AMBUJACEM.NS'],
    }
    
    def fetch_nifty50_data(self, days: int = 90, max_retries: int = 3) -> Dict:
        """
        Fetch NIFTY 50 index data and key metrics with improved error handling and retries.
        
        Args:
            days: Number of days of historical data to fetch (reduced from 365 to 90 for performance)
            max_retries: Maximum number of retry attempts
            
        Returns:
            Dictionary with NIFTY 50 data and metrics or empty dict if all retries fail
        """
        import time
        from requests.exceptions import RequestException
        
        # Reduce the data period to minimize timeout risk
        period = '3mo'  # Default to 3 months for better reliability
        if days <= 30:
            period = '1mo'
        elif days <= 90:
            period = '3mo'
        elif days <= 180:
            period = '6mo'
        elif days <= 365:
            period = '1y'
            
        attempt = 0
        while attempt < max_retries:
            try:
                attempt += 1
                logger.info(f"Fetching NIFTY 50 data (attempt {attempt}/{max_retries})...")
                
                # Use a smaller time window and let yfinance handle the period
                nifty_data = yf.download('^NSEI', period=period, progress=False, timeout=10)
                
                if nifty_data.empty:
                    logger.warning(f"No data returned for NIFTY 50 (attempt {attempt})")
                    time.sleep(2)  # Wait before retry
                    continue
                    
                # Calculate key metrics
                latest_close = nifty_data['Close'].iloc[-1]
                prev_close = nifty_data['Close'].iloc[-2] if len(nifty_data) > 1 else latest_close
                change_pct = ((latest_close - prev_close) / prev_close) * 100
                
                # Get PE ratio with error handling
                try:
                    pe_ratio = self._get_nifty_pe_ratio()
                except Exception as pe_error:
                    logger.warning(f"Could not fetch NIFTY 50 PE ratio: {pe_error}")
                    pe_ratio = 20.0  # Default fallback value
                
                # Get sector performance with error handling
                try:
                    sector_performance = self._get_sector_performance()
                except Exception as sp_error:
                    logger.warning(f"Could not fetch sector performance: {sp_error}")
                    sector_performance = []
                
                result = {
                    'symbol': '^NSEI',
                    'name': 'NIFTY 50',
                    'latest_price': latest_close,
                    'change_pct': change_pct,
                    'pe_ratio': pe_ratio,
                    '52_week_high': nifty_data['High'].max(),
                    '52_week_low': nifty_data['Low'].min(),
                    'sector_performance': sector_performance,
                    'data': nifty_data
                }
                
                logger.info("Successfully fetched NIFTY 50 data")
                return result
                
            except RequestException as re:
                logger.warning(f"Network error fetching NIFTY 50 data (attempt {attempt}): {re}")
                if attempt >= max_retries:
                    logger.error("Max retries reached for NIFTY 50 data fetch")
                    break
                time.sleep(2)  # Exponential backoff could be implemented here
                
            except Exception as e:
                logger.error(f"Error fetching NIFTY 50 data (attempt {attempt}): {e}")
                if attempt >= max_retries:
                    break
                time.sleep(1)
        
        logger.warning("Failed to fetch NIFTY 50 data after all retries")
        return {}  # Return empty dict if all retries fail
            
    def _get_sector_performance(self, period: str = '1mo') -> List[Dict]:
        """
        Calculate performance of different sectors in NIFTY 50.
        
        Args:
            period: Time period for performance calculation (1d, 1wk, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
            
        Returns:
            List of dictionaries with sector performance data
        """
        sector_performance = []
        
        for sector, stocks in self.SECTOR_STOCKS.items():
            try:
                # Download data for all stocks in the sector
                data = yf.download(
                    ' '.join(stocks),
                    period=period,
                    group_by='ticker',
                    progress=False
                )
                
                if data.empty:
                    continue
                    
                # Calculate average return for the sector
                returns = []
                for stock in stocks:
                    if stock in data.columns.get_level_values(0).unique():
                        close_prices = data[stock]['Close']
                        if len(close_prices) > 1:
                            ret = (close_prices.iloc[-1] / close_prices.iloc[0] - 1) * 100
                            returns.append(ret)
                
                if returns:
                    avg_return = sum(returns) / len(returns)
                    sector_performance.append({
                        'sector': sector,
                        'weight': self.NIFTY_SECTOR_WEIGHTS.get(sector, 0),
                        'return': avg_return,
                        'stocks_analyzed': len(returns)
                    })
                    
            except Exception as e:
                logger.warning(f"Error analyzing {sector} sector: {e}")
        
        # Sort by weight (descending)
        sector_performance.sort(key=lambda x: x['weight'], reverse=True)
        
        # Calculate 'Others' sector (remaining weight)
        covered_weight = sum(s['weight'] for s in sector_performance)
        others_weight = 100 - covered_weight
        
        if others_weight > 0:
            sector_performance.append({
                'sector': 'Others',
                'weight': others_weight,
                'return': 0,
                'stocks_analyzed': 0
            })
        
        return sector_performance
            
    def _get_nifty_pe_ratio(self) -> float:
        """
        Get NIFTY 50 PE ratio.
        
        Returns:
            PE ratio as float (default: 20.0 if not available)
        """
        try:
            # Try to get PE ratio from yfinance
            nifty = yf.Ticker("^NSEI")
            info = nifty.info
            
            # Try different possible keys for PE ratio
            pe_keys = ['trailingPE', 'forwardPE', 'peRatio', 'pe_ratio']
            for key in pe_keys:
                if key in info and info[key] is not None:
                    return round(float(info[key]), 2)
            
            # If not found, use a default value
            logger.warning("Could not fetch NIFTY 50 PE ratio, using default value")
            return 20.0
            
        except Exception as e:
            logger.warning(f"Could not fetch NIFTY 50 PE ratio: {e}")
            return 20.0


def get_top_bse_stocks() -> List[str]:
    """
    Get a list of top BSE stocks by market capitalization.
    
    Returns:
        List of BSE stock symbols
    """
    # List of top 20 BSE stocks by market cap
    TOP_BSE_STOCKS = [
        'RELIANCE.BO',  # Reliance Industries
        'TCS.BO',       # Tata Consultancy Services
        'HDFCBANK.BO',  # HDFC Bank
        'ICICIBANK.BO', # ICICI Bank
        'HINDUNILVR.BO',# Hindustan Unilever
        'INFY.BO',      # Infosys
        'ITC.BO',       # ITC Limited
        'KOTAKBANK.BO', # Kotak Mahindra Bank
        'HDFC.BO',      # HDFC Limited
        'BHARTIARTL.BO',# Bharti Airtel
        'LT.BO',        # Larsen & Toubro
        'SBIN.BO',      # State Bank of India
        'BAJFINANCE.BO',# Bajaj Finance
        'ASIANPAINT.BO',# Asian Paints
        'HCLTECH.BO',   # HCL Technologies
        'MARUTI.BO',    # Maruti Suzuki
        'TITAN.BO',     # Titan Company
        'SUNPHARMA.BO', # Sun Pharmaceutical
        'BAJAJFINSV.BO',# Bajaj Finserv
        'NTPC.BO'       # NTPC Limited
    ]
    return TOP_BSE_STOCKS.copy()


def validate_stock_symbol(symbol: str) -> bool:
    """
    Validate if a stock symbol is in the correct format.
    
    Args:
        symbol: Stock symbol to validate (can be BSE, NSE, or index symbol)
        
    Returns:
        bool: True if valid, False otherwise
    """
    # Basic validation
    if not isinstance(symbol, str) or not symbol.strip():
        logger.warning("Invalid symbol: empty or not a string")
        return False
    
    # Check if it's a BSE stock (ends with .BO), NSE stock (ends with .NS), or index symbol (starts with ^)
    is_bse = symbol.upper().endswith('.BO')
    is_nse = symbol.upper().endswith('.NS')
    is_index = symbol.startswith('^')
    
    if not (is_bse or is_nse or is_index):
        logger.warning(f"Symbol {symbol} doesn't appear to be in a recognized format. "
                     f"Valid formats: BSE (RELIANCE.BO), NSE (RELIANCE.NS), or Index (^NSEI)")
        return False
    
    # Additional validation for index symbols
    if is_index and len(symbol) < 2:
        logger.warning(f"Invalid index symbol: {symbol}")
        return False
    
    return True


if __name__ == "__main__":
    # Example usage
    fetcher = DataFetcher()
    
    # Fetch data for a single stock
    symbol = "RELIANCE.BO"
    print(f"Fetching data for {symbol}...")
    data = fetcher.fetch_stock_data(symbol, days=30)
    
    if data is not None:
        print(f"Successfully fetched {len(data)} data points for {symbol}")
        print(data.head())
    else:
        print(f"Failed to fetch data for {symbol}")
