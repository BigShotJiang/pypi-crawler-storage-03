# My Stock Analyser

A comprehensive stock analysis tool that provides technical and fundamental analysis of stocks with beautiful visualizations and email reporting capabilities.

## Features

- Fetch historical stock data from multiple sources
- Perform technical analysis (RSI, MACD, Moving Averages, etc.)
- Generate detailed HTML reports with interactive charts
- Email reports with embedded visualizations
- Support for NIFTY 50 index analysis
- Cache system to minimize API calls

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/my_stock_analyser.git
   cd my_stock_analyser
   ```

2. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. Install the package in development mode:
   ```bash
   pip install -e .
   ```

## Configuration

1. Copy the example environment file and update it with your API keys:
   ```bash
   cp .env.example .env
   ```

2. Edit the `.env` file with your configuration:
   ```
   # Alpha Vantage API (https://www.alphavantage.co/support/#api-key)
   ALPHA_VANTAGE_API_KEY=your-api-key-here

   # Email Configuration (Gmail recommended)
   SENDER_EMAIL=your-email@example.com
   SENDER_PASSWORD=your-app-password
   ```

   Note: For Gmail, you may need to generate an "App Password" if 2FA is enabled.

## Usage

### Command Line Interface

```bash
# Analyze top 10 BSE stocks and generate a report
stock-analyzer --top 10

# Analyze specific stocks
stock-analyzer --stocks RELIANCE.NS TCS.NS HDFCBANK.NS

# Analyze NIFTY 50 index
stock-analyzer --stocks ^NSEI

# Send report via email
stock-analyzer --stocks RELIANCE.NS --email your-email@example.com

# Set number of days for analysis (default: 365)
stock-analyzer --stocks RELIANCE.NS --days 180
```

### Python API

```python
from my_stock_analyser.analyzer import StockAnalyzer

# Create an analyzer instance
analyzer = StockAnalyzer()

# Analyze a stock
result = analyzer.analyze_stock("RELIANCE.NS", days=365)

# Generate a report
report_path = analyzer.generate_report([result])

# Send report via email
analyzer.send_report("your-email@example.com", [result])
```

## Project Structure

```
my_stock_analyser/
├── src/                    # Source code
│   ├── my_stock_analyser/  # Main package
│   │   ├── __init__.py
│   │   ├── cli.py         # Command line interface
│   │   ├── data_fetcher.py # Data collection
│   │   ├── analysis.py    # Analysis logic
│   │   ├── visualization.py # Chart generation
│   │   ├── report_generator.py # Report creation
│   │   └── email_sender.py # Email functionality
│   └── tests/             # Unit tests
├── data/                  # Data storage
│   └── cache/             # Cached stock data
├── reports/               # Generated reports
│   └── charts/            # Chart visualizations
├── docs/                  # Documentation
├── .env.example           # Example environment variables
├── .gitignore             # Git ignore file
├── setup.py               # Package installation
└── README.md              # This file
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

Distributed under the MIT License. See `LICENSE` for more information.

## Contact

Pranav Phalnikar - pranavphalnikar@gmail.com

Project Link: [https://github.com/pranavp87/my_stock_analyser](https://github.com/pranavp87/my_stock_analyser)
