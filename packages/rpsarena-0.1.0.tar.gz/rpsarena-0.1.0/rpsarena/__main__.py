"""
RPS Arena module entry point.

This allows running the simulator with:
    python -m rpsarena
"""

from . import main

if __name__ == "__main__":
    main()
