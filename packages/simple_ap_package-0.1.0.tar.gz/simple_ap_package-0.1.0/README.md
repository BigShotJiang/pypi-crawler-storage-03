# simple-ap-package

I generated this thing just for fun and to learn how to package a python package

## Usage

```python
from sap import say_hello

say_hello()
```

### Output
you should be able to see:
```
Hello, World!
```

if you don't I am sorry. /;

#### Thanks for `simple-ap-package`