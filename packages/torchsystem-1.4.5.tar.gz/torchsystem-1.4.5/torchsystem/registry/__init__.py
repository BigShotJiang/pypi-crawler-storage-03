from torchsystem.registry.accessors import register as register
from torchsystem.registry.accessors import Registry as Registry
from torchsystem.registry.accessors import getarguments as getarguments
from torchsystem.registry.accessors import gethash as gethash
from torchsystem.registry.accessors import getname as getname
from torchsystem.registry.accessors import sethash as sethash
from torchsystem.registry.accessors import setname as setname
from torchsystem.registry.accessors import getmetadata as getmetadata