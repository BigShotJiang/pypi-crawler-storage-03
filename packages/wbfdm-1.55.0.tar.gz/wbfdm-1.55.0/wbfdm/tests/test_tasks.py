import pytest


@pytest.mark.django_db
def test_daily_update_of_investable_universe_data(instrument):
    pass
