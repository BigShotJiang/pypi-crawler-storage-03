"""Centralized version information for nim-mmcif."""

from __future__ import annotations

__version__ = "0.0.14"