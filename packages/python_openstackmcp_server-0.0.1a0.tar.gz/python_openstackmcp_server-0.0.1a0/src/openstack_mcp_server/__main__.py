from openstack_mcp_server import main


main()
