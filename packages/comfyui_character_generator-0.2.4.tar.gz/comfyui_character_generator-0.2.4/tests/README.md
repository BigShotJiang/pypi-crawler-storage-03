# Automated ComfyUI Character Generator

To run all tests, use:

```sh
pytest
```
or
```sh
python -m unittest discover -s tests
```

All tests are in the tests/ directory and use unittest, unittest.mock, and pytest features.
