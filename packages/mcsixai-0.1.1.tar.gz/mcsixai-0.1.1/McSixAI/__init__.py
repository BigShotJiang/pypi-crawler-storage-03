"""
McSixAI - AI ассистент для программирования
"""

__version__ = "0.1.1"
__author__ = "McSix"