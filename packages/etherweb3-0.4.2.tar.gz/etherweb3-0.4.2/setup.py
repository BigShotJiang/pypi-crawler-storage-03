from setuptools import setup, find_packages

setup(
    name="etherweb3",
    version="0.4.2",
    packages=find_packages(),
    include_package_data=True,
    description="Ether Web3 JS",
    zip_safe=False,
)
