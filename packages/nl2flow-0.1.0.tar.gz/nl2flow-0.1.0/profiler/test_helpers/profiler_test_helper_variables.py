domain_file_name = "domain.pddl"
problem_file_name = "problem.pddl"
plan_file_name = "plan.txt"
pddl_start_key = "define"
