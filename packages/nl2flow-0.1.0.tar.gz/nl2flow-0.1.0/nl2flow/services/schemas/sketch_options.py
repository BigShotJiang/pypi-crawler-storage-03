from enum import Enum


class SketchOptions(Enum):
    INORDER = "INORDER"
    CAREFUL = "CAREFUL"
    NO_TYPING = "NO_TYPING"
