"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n.city/comm/interaction/gateway/v1/gateway.proto\x12 city.comm.interaction.gateway.v1"s\n\x07Station\x12\x0e\n\x02id\x18\x01 \x01(\x05R\x02id\x12\x16\n\x06status\x18\x02 \x01(\x08R\x06status\x12@\n\x06reason\x18\x03 \x01(\x0e2(.city.comm.interaction.gateway.v1.ReasonR\x06reason*E\n\x06Reason\x12\x16\n\x12REASON_UNSPECIFIED\x10\x00\x12\x0f\n\x0bREASON_RUIN\x10\x01\x12\x12\n\x0eREASON_CASCADE\x10\x02B\xa5\x02\n$com.city.comm.interaction.gateway.v1B\x0cGatewayProtoP\x01ZJgit.fiblab.net/sim/protos/v2/go/city/comm/interaction/gateway/v1;gatewayv1\xa2\x02\x04CCIG\xaa\x02 City.Comm.Interaction.Gateway.V1\xca\x02 City\\Comm\\Interaction\\Gateway\\V1\xe2\x02,City\\Comm\\Interaction\\Gateway\\V1\\GPBMetadata\xea\x02$City::Comm::Interaction::Gateway::V1b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'city.comm.interaction.gateway.v1.gateway_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    _globals['DESCRIPTOR']._options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n$com.city.comm.interaction.gateway.v1B\x0cGatewayProtoP\x01ZJgit.fiblab.net/sim/protos/v2/go/city/comm/interaction/gateway/v1;gatewayv1\xa2\x02\x04CCIG\xaa\x02 City.Comm.Interaction.Gateway.V1\xca\x02 City\\Comm\\Interaction\\Gateway\\V1\xe2\x02,City\\Comm\\Interaction\\Gateway\\V1\\GPBMetadata\xea\x02$City::Comm::Interaction::Gateway::V1'
    _globals['_REASON']._serialized_start = 201
    _globals['_REASON']._serialized_end = 270
    _globals['_STATION']._serialized_start = 84
    _globals['_STATION']._serialized_end = 199