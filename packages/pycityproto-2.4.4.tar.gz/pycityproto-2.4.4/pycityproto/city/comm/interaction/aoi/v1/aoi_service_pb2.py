"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n.city/comm/interaction/aoi/v1/aoi_service.proto\x12\x1ccity.comm.interaction.aoi.v1"\x14\n\x12GetBadAoiIDRequest"\'\n\x13GetBadAoiIDResponse\x12\x10\n\x03ids\x18\x01 \x03(\x05R\x03ids2\x80\x01\n\nAoiService\x12r\n\x0bGetBadAoiID\x120.city.comm.interaction.aoi.v1.GetBadAoiIDRequest\x1a1.city.comm.interaction.aoi.v1.GetBadAoiIDResponseB\x8c\x02\n com.city.comm.interaction.aoi.v1B\x0fAoiServiceProtoP\x01ZBgit.fiblab.net/sim/protos/v2/go/city/comm/interaction/aoi/v1;aoiv1\xa2\x02\x04CCIA\xaa\x02\x1cCity.Comm.Interaction.Aoi.V1\xca\x02\x1cCity\\Comm\\Interaction\\Aoi\\V1\xe2\x02(City\\Comm\\Interaction\\Aoi\\V1\\GPBMetadata\xea\x02 City::Comm::Interaction::Aoi::V1b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'city.comm.interaction.aoi.v1.aoi_service_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    _globals['DESCRIPTOR']._options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n com.city.comm.interaction.aoi.v1B\x0fAoiServiceProtoP\x01ZBgit.fiblab.net/sim/protos/v2/go/city/comm/interaction/aoi/v1;aoiv1\xa2\x02\x04CCIA\xaa\x02\x1cCity.Comm.Interaction.Aoi.V1\xca\x02\x1cCity\\Comm\\Interaction\\Aoi\\V1\xe2\x02(City\\Comm\\Interaction\\Aoi\\V1\\GPBMetadata\xea\x02 City::Comm::Interaction::Aoi::V1'
    _globals['_GETBADAOIIDREQUEST']._serialized_start = 80
    _globals['_GETBADAOIIDREQUEST']._serialized_end = 100
    _globals['_GETBADAOIIDRESPONSE']._serialized_start = 102
    _globals['_GETBADAOIIDRESPONSE']._serialized_end = 141
    _globals['_AOISERVICE']._serialized_start = 144
    _globals['_AOISERVICE']._serialized_end = 272