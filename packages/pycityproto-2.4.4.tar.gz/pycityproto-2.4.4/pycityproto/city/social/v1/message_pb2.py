"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1ccity/social/v1/message.proto\x12\x0ecity.social.v1"`\n\x07Message\x12\x12\n\x04from\x18\x01 \x01(\x05R\x04from\x12\x0e\n\x02to\x18\x02 \x01(\x05R\x02to\x12\x18\n\x07message\x18\x03 \x01(\tR\x07message\x12\x11\n\x01t\x18\x04 \x01(\x01H\x00R\x01t\x88\x01\x01B\x04\n\x02_tB\xb5\x01\n\x12com.city.social.v1B\x0cMessageProtoP\x01Z7git.fiblab.net/sim/protos/v2/go/city/social/v1;socialv1\xa2\x02\x03CSX\xaa\x02\x0eCity.Social.V1\xca\x02\x0eCity\\Social\\V1\xe2\x02\x1aCity\\Social\\V1\\GPBMetadata\xea\x02\x10City::Social::V1b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'city.social.v1.message_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    _globals['DESCRIPTOR']._options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x12com.city.social.v1B\x0cMessageProtoP\x01Z7git.fiblab.net/sim/protos/v2/go/city/social/v1;socialv1\xa2\x02\x03CSX\xaa\x02\x0eCity.Social.V1\xca\x02\x0eCity\\Social\\V1\xe2\x02\x1aCity\\Social\\V1\\GPBMetadata\xea\x02\x10City::Social::V1'
    _globals['_MESSAGE']._serialized_start = 48
    _globals['_MESSAGE']._serialized_end = 144