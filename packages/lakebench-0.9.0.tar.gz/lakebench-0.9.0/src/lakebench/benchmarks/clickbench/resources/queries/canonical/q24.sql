SELECT
    *
FROM
    hits
WHERE
    URL LIKE '%google%'
ORDER BY
    EventTime
LIMIT
    10;