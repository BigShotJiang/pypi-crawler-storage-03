SELECT
    SearchPhrase
FROM
    hits
WHERE
    SearchPhrase <> ''
ORDER BY
    EventTime,
    SearchPhrase
LIMIT
    10;