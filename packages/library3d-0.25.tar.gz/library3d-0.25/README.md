# library3d

Saf Python 3D kütüphanesi (OpenGL kullanmadan)

## Özellikler
- `Engine` sınıfı: canvas oluşturur, çizim yapar
- `Vector3` sınıfı: 3D vektör işlemleri
- `draw_polygon`, `fill_polygon`, `render_line`: yardımcı çizim fonksiyonları
- RGB renk desteği
- PIP ile yüklenebilir
