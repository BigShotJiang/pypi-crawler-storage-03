.. NagaNLP documentation master file, created by
   sphinx-quickstart on Sat Aug  2 2025.

Welcome to NagaNLP's documentation!
==================================

NagaNLP is a comprehensive Natural Language Processing toolkit for the Nagamese language.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   api
   contributing
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
