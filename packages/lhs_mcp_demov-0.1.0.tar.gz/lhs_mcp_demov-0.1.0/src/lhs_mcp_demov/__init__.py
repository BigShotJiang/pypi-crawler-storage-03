def main() -> None:
    print("Hello from lhs-mcp-demov!")
