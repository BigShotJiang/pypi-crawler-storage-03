"""PostgreSQL (psycopg) adapter integration tests."""

__all__ = ()
