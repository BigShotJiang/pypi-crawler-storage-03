"""OracleDB adapter integration tests."""

import pytest

pytestmark = [pytest.mark.oracle, pytest.mark.oracledb]
