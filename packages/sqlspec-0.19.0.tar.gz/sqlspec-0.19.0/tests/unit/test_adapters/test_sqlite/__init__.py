"""Unit tests for SQLite adapter components."""
