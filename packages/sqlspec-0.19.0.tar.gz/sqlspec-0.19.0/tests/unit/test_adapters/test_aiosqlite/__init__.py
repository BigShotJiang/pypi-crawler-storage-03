"""Unit tests for aiosqlite adapter components."""
