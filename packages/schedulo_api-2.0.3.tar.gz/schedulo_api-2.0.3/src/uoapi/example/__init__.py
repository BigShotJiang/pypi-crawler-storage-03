from uoapi.example import example_functions
from uoapi.example.cli import parser, cli
