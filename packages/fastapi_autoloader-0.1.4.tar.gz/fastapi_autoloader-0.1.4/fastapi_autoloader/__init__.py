"""FastAPI Dynamic Router modular autoload for faster development."""

from .autoloader import AutoLoader  # noqa: F401
