
## CATO-CLI - mutation.policy.socketLan.addRule:
[Click here](https://api.catonetworks.com/documentation/#mutation-addRule) for documentation on this operation.

### Usage for mutation.policy.socketLan.addRule:

`catocli mutation policy socketLan addRule -h`

`catocli mutation policy socketLan addRule <json>`

`catocli mutation policy socketLan addRule "$(cat < addRule.json)"`

`catocli mutation policy socketLan addRule '{"socketLanAddRuleInput": {"policyRulePositionInput": {"position": {"position": "enum(PolicyRulePositionEnum)"}, "ref": {"ref": "ID"}}, "socketLanAddRuleDataInput": {"description": {"description": "String"}, "destination": {"floatingSubnet": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "globalIpRange": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "group": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "host": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "ip": {"ip": ["IPAddress"]}, "ipRange": {"from": {"from": "IPAddress"}, "to": {"to": "IPAddress"}}, "networkInterface": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "siteNetworkSubnet": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "subnet": {"subnet": ["NetworkSubnet"]}, "systemGroup": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "vlan": {"vlan": ["Vlan"]}}, "direction": {"direction": "enum(SocketLanDirection)"}, "enabled": {"enabled": "Boolean"}, "name": {"name": "String"}, "nat": {"enabled": {"enabled": "Boolean"}, "natType": {"natType": "enum(SocketLanNatType)"}}, "service": {"custom": {"port": {"port": ["Port"]}, "portRange": {"from": {"from": "Port"}, "to": {"to": "Port"}}, "protocol": {"protocol": "enum(IpProtocol)"}}, "simple": {"name": {"name": "enum(SimpleServiceType)"}}}, "site": {"group": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "site": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}}, "source": {"floatingSubnet": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "globalIpRange": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "group": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "host": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "ip": {"ip": ["IPAddress"]}, "ipRange": {"from": {"from": "IPAddress"}, "to": {"to": "IPAddress"}}, "networkInterface": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "siteNetworkSubnet": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "subnet": {"subnet": ["NetworkSubnet"]}, "systemGroup": {"by": {"by": "enum(ObjectRefBy)"}, "input": {"input": "String"}}, "vlan": {"vlan": ["Vlan"]}}, "transport": {"transport": "enum(SocketLanTransportType)"}}}, "socketLanPolicyMutationInput": {"policyMutationRevisionInput": {"id": {"id": "ID"}}}}'`

#### Operation Arguments for mutation.policy.socketLan.addRule ####
`accountId` [ID] - (required) N/A 
`socketLanAddRuleInput` [SocketLanAddRuleInput] - (required) N/A 
`socketLanPolicyMutationInput` [SocketLanPolicyMutationInput] - (optional) N/A 
