
### Usage:
`cato query -h`
