
## CATO-CLI - query.policy.wanNetwork:
[Click here](https://api.catonetworks.com/documentation/#query-wanNetwork) for documentation on this operation.

### Usage for query.policy.wanNetwork:

`catocli query policy wanNetwork -h`
