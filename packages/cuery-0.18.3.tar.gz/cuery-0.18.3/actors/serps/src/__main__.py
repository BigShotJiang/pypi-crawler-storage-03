import asyncio

from cuery.actors import serps

asyncio.run(serps.main())
