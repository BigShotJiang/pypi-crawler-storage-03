"""Criterion - A Python package for Criterion"""

__version__ = "0.0.1a1"
__author__ = "Criterion Team"
__email__ = "criterion@criterion.org"


def hello():
    """A simple hello function"""
    return f"Hello from Criterion v{__version__}!"
