# MSA Reasoning Engine Results
Exported on: 2025-08-20 20:30:28

## Raw Data

```json
{
  "id": "test-export-session",
  "description": "Test session for export",
  "created_at": "2025-08-20T20:30:28.374893",
  "queries": [
    {
      "query": "Test query for export",
      "timestamp": "2025-08-20T20:30:28.376467",
      "result": {
        "mode": "both",
        "confidence_analysis": {
          "overall_confidence": 0.85
        }
      }
    }
  ],
  "results": [
    {
      "mode": "both",
      "confidence_analysis": {
        "overall_confidence": 0.85
      }
    }
  ]
}
```