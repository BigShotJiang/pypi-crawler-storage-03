# MSA Reasoning Engine Results
Exported on: 2025-08-20 20:30:28

## Session: test-session-123

## Raw Data

```json
{
  "session_id": "test-session-123",
  "description": "Test session for export functionality",
  "created_at": "2025-01-01T12:00:00Z",
  "queries": [
    {
      "query": "Test query 1",
      "timestamp": "2025-01-01T12:01:00Z",
      "result": {
        "mode": "both",
        "confidence_analysis": {
          "overall_confidence": 0.95
        }
      }
    }
  ]
}
```