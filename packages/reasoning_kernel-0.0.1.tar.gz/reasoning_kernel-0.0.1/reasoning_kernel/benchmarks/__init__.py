"""
Benchmarks module for reasoning kernel.
"""
