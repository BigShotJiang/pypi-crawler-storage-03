"""
Security module for reasoning kernel.
"""
