"""
Examples module for reasoning kernel.
"""
