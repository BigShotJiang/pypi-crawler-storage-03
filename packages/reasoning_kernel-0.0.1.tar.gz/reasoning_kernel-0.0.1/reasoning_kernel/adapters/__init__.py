"""
Adapters module for reasoning kernel.
"""
