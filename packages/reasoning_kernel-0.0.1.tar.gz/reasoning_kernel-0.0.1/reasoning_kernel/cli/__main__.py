"""
Main entry point for the MSA Reasoning Engine CLI
"""
from reasoning_kernel.cli.core import main

if __name__ == "__main__":
    main()