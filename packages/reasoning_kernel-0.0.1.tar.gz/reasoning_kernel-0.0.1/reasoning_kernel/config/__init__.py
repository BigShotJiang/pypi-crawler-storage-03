"""
Configuration module for MSA Reasoning Engine
"""