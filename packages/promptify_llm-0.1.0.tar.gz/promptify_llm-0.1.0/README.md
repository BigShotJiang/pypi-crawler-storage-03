# Promptify-LLM

A simple, zero-dependency library to format prompts for various open-source LLMs.

## Installation
```bash
pip install promptify-llm