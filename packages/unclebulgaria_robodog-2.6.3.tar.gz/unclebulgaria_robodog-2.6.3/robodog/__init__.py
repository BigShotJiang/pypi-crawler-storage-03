# robodog/__init__.py
__version__ = "2.5.0"