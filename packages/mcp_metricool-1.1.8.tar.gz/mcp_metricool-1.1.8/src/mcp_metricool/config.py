import os

# Constants
METRICOOL_BASE_URL = "https://app.metricool.com/api"
METRICOOL_USER_TOKEN = os.getenv("METRICOOL_USER_TOKEN")
METRICOOL_USER_ID = os.getenv("METRICOOL_USER_ID")