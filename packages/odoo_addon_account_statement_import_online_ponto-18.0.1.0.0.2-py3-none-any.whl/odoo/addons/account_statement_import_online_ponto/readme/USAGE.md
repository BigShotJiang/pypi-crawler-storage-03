To pull historical bank statements:

1.  Go to *Invoicing \> Configuration \> Bank Accounts*
2.  Select specific bank accounts
3.  Launch *Actions \> Online Bank Statements Pull Wizard*
4.  Configure date interval and click *Pull*

If historical data is not needed, then just simply wait for the
scheduled activity "Pull Online Bank Statements" to be executed for
getting new transactions.
