# filedial

Simple cross-platform GUI file dialogs. Currently using tkinter as backend.
