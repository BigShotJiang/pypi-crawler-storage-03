"""
Dashlab - A Python package for dashboard and data visualization tools.
"""

from .__version__ import __version__

__all__ = ["__version__"]