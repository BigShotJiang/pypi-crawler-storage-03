# VideoSDK Simli

This plugin integrates Simli's Virtual AI Avatar with VideoSDK Agents framework.

## Requirements

- Python 3.12+


## Installation

```bash
pip install videosdk-plugins-simli
```
