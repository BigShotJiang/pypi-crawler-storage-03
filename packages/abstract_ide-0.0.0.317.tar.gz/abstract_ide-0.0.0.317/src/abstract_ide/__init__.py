from .main import abstractIde
from .imports import startConsole

def startAbstractIde():
    startConsole(abstractIde)

