# CLHkidai 🤖✨
Kid-friendly one-line AI for classrooms (ages 9–14). Safe by default. Works online **and** in mock/offline mode.

## Install
```bash
pip install CLHKidAI
