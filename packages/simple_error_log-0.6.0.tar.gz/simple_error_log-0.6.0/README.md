# Simple Error Log

## Description

A set of simple classes for logging errors.

## Installation

```bash
pip install simple_error_log
```

## Building package

Use pip to install build and twine. Use the following commands to build

```python -m build``` 

and upload to pypi.org using the command

```twine upload dist/*``` 
