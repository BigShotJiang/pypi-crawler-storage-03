<!--
SPDX-FileCopyrightText: 2024 Nicco Kunzmann and Open Web Calendar Contributors <https://open-web-calendar.quelltext.eu/>

SPDX-License-Identifier: CC-BY-SA-4.0
-->

Loaders from http://loadingapng.com/
such as http://loadingapng.com/animation.php?image=91&fore_color=000000&back_color=FFFFFF&size=128x128&transparency=1&image_type=1&uncacher=13.887166099220504
