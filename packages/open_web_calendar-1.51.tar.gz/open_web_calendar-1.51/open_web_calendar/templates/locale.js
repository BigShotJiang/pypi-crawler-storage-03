// SPDX-FileCopyrightText: 2024 Nicco Kunzmann and Open Web Calendar Contributors <https://open-web-calendar.quelltext.eu/>
//
// SPDX-License-Identifier: CC-BY-SA-4.0
/* Generated locale from the calendar sources. */

const OWCLocale =  {{ locale }};
