<!--
SPDX-FileCopyrightText: 2024 Nicco Kunzmann and Open Web Calendar Contributors <https://open-web-calendar.quelltext.eu/>

SPDX-License-Identifier: CC-BY-SA-4.0
-->

# Loaders

This is a compatibility directory.
The files here are used and were used before for people to created
an embedded iframe with a loader.
