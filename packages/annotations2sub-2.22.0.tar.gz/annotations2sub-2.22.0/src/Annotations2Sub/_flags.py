# -*- coding: utf-8 -*-


class flags:
    def __init__(self):
        self.verbose = False


Flags = flags()
