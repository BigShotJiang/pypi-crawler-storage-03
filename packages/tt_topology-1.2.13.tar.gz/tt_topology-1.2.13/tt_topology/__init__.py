# SPDX-FileCopyrightText: © 2024 Tenstorrent Inc.
# SPDX-License-Identifier: Apache-2.0

"""
Top-level package for tt_topology.
"""
from .tt_topology import *
