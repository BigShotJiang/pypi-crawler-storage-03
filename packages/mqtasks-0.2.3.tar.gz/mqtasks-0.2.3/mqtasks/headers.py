class MqTaskHeaders:
    TASK: str = "task"
    RESPONSE_TO_MESSAGE_ID: str = "response_to_message_id"
    RESPONSE_TYPE: str = "response_type"
    RESPONSE_STATUS: str = "response_status"
    RESPONSE_ERROR_MESSAGE: str = "response_error_message"
