class MqTaskResponseTypes:
    REQUEST: str = "request"
    DATA: str = "data"
    RESPONSE: str = "response"


