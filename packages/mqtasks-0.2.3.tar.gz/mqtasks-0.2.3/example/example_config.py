CONNECTION = "amqp://guest:guest@127.0.0.1/"
QUEUE_NANE_REQUEST_01 = "channel_request_01"
QUEUE_NANE_REQUEST_02 = "channel_request_02"
QUEUE_NANE_PUBLISH_01 = "channel_publish_01"

