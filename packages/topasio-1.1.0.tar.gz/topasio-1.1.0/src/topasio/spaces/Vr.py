from topasio.generic_classes.space import Space

Vr = Space()
Vr["_name"] = "Vr"
Vr["_modified"] = []  # Track modified attributes
