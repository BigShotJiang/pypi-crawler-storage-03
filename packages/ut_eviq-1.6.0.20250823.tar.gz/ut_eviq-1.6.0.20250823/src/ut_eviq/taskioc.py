"""
This module provides task input output control classes for the management of Sustainability Risk Rating (SRR) processing.
"""

from ut_eviq.taskin import TaskIn
from ut_eviq.xls.taskout import TaskOut as XlsTaskOut

# import pandas as pd
import openpyxl as op

from typing import Any, TypeAlias
TyOpWb: TypeAlias = op.Workbook

TyArr = list[Any]
TyBool = bool
TyDic = dict[Any, Any]
TyAoA = list[TyArr]
TyAoD = list[TyDic]
TyCmd = str
TyPath = str
TyStr = str

TnAoD = None | TyAoD
TnDic = None | TyDic
TnOpWb = None | TyOpWb


class TaskIoc:
    """
    I/O Control Tasks class for EcoVadis IQ upload Excel workbooks
    """
    kwargs_wb = dict(dtype=str, keep_default_na=False, engine='calamine')

    @classmethod
    def evupadm(cls, kwargs: TyDic) -> None:
        """
        Administration processsing for EcoVadis IQ upload Excel workbooks
        """
        XlsTaskOut.evupadm(TaskIn.evupadm(kwargs), kwargs)

    @classmethod
    def evupdel(cls, kwargs: TyDic) -> None:
        """
        Delete processsing for EcoVadis IQ upload Excel workbooks
        """
        XlsTaskOut.evupdel(TaskIn.evupdel(kwargs), kwargs)

    @classmethod
    def evupreg(cls, kwargs: TyDic) -> None:
        """
        Regular processsing for EcoVadis IQ upload Excel workbooks
        Regular Processing (create, update, delete) of partners using
          single Xlsx Workbook with a populated admin- or delete-sheet
          two xlsx Workbooks:
            the first one contains a populated admin-sheet
            the second one contains a populated delete-sheet
        """
        _sw_single_wb: TyBool = kwargs.get('sw_single_wb', True)
        if _sw_single_wb:
            # write single workbook which contains admin and delete worksheets
            XlsTaskOut.evupreg_reg_wb(TaskIn.evupreg(kwargs), kwargs)
        else:
            # write separate workbooks for admin and delete worksheets
            XlsTaskOut.evupreg_adm_del_wb(TaskIn.evupreg(kwargs), kwargs)

    @classmethod
    def evdomap(cls, kwargs: TyDic) -> None:
        """
        EcoVadis Download Processing: Mapping of EcoVadis export xlsx workbook
        """
        XlsTaskOut.evdomap(TaskIn.evdomap(kwargs), kwargs)
