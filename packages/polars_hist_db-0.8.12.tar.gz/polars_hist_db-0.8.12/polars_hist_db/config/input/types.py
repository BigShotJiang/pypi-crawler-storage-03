from typing import Literal

InputDataSourceType = Literal["dsv", "nats-jetstream", "nats-subject"]
