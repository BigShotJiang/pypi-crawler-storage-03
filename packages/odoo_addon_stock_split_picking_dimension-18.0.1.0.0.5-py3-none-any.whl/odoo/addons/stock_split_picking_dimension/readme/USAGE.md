#. Go to **Inventory** dashboard and open any picking.

#. If picking state is **available** you can see an split button.

#. If you click on **Split** button, a wizard will open.

#. The wizard will let you choose the way you want to split the picking.

#. To split by dimension, select **By Dimension** option.

#. Enter the values for **Volume**, **Weight** and **Number of Lines**. (You can leave
any of the fields empty if you don't want to split by that dimension).

#. Click on **Split** button.

#. The current picking will be split into two different pickings. The first picking will
contain the lines that fit the dimensions you entered. The second picking will contain
the remaining lines.
