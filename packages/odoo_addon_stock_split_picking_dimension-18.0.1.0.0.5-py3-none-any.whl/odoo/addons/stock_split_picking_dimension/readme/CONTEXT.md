When dealing with large quantities of products, it could be useful to be able to split
the picking into multiple pickings to simplify the picking process and improve the
efficiency of the warehouse. Some times, the picking you would like to process is too
large to be picked in one go or too heavy to be carried by one person or contains too
many different products to be picked in one go.
