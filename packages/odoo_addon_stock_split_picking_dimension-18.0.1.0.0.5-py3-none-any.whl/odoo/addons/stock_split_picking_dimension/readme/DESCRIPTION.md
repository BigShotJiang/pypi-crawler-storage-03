This module extends the functionality of the stock_split_picking module to allow the
user to split the picking by dimensions to ensure that the contents of the picking to
process will not exceed a certain volume and/or weight and/or number of lines.
