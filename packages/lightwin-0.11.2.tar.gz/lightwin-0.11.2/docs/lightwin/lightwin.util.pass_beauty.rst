pass\_beauty module
=================================

.. automodule:: lightwin.util.pass_beauty
   :members:
   :undoc-members:
   :show-inheritance:
