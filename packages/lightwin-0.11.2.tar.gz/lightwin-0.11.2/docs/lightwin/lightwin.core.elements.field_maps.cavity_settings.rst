cavity\_settings module
==========================================================

.. automodule:: lightwin.core.elements.field_maps.cavity_settings
   :members:
   :undoc-members:
   :show-inheritance:
