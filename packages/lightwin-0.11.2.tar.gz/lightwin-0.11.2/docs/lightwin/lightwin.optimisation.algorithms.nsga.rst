nsga module
============================================

.. automodule:: lightwin.optimisation.algorithms.nsga
   :members:
   :undoc-members:
   :show-inheritance:
