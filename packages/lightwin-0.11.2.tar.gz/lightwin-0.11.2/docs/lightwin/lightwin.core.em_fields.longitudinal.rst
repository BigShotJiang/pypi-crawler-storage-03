longitudinal module
============================================

.. automodule:: lightwin.core.em_fields.longitudinal
   :members:
   :undoc-members:
   :show-inheritance:
