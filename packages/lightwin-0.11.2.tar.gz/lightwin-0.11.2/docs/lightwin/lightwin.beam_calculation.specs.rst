specs module
=======================================

.. automodule:: lightwin.beam_calculation.specs
   :members:
   :undoc-members:
   :show-inheritance:
