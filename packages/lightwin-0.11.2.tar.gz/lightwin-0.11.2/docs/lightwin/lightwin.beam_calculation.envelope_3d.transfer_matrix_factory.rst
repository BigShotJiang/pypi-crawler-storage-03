transfer\_matrix\_factory module
========================================================================

.. automodule:: lightwin.beam_calculation.envelope_3d.transfer_matrix_factory
   :members:
   :undoc-members:
   :show-inheritance:
