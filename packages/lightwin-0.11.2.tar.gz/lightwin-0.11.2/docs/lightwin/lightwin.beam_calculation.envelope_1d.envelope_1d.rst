envelope\_1d module
===========================================================

.. automodule:: lightwin.beam_calculation.envelope_1d.envelope_1d
   :members:
   :undoc-members:
   :show-inheritance:
