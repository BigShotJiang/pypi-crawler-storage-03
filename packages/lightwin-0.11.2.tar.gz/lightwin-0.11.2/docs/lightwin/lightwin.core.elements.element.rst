element module
=====================================

.. automodule:: lightwin.core.elements.element
   :members:
   :undoc-members:
   :show-inheritance:
