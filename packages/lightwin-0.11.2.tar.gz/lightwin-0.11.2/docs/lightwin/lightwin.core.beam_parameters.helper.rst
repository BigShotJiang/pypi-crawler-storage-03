helper module
============================================

.. automodule:: lightwin.core.beam_parameters.helper
   :members:
   :undoc-members:
   :show-inheritance:
