scripts\_shorthands module
===========================================

.. automodule:: lightwin.scripts.scripts_shorthands
   :members:
   :undoc-members:
   :show-inheritance:
