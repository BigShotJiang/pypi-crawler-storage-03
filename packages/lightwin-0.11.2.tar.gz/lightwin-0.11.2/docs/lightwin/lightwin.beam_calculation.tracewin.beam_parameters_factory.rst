beam\_parameters\_factory module
====================================================================

.. automodule:: lightwin.beam_calculation.tracewin.beam_parameters_factory
   :members:
   :undoc-members:
   :show-inheritance:
