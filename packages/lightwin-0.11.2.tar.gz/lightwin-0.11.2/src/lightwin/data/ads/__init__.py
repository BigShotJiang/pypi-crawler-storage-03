"""Define an ADS-like linac: protons, high energy, high acceptance."""
