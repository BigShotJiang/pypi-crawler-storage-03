"""In this package we define the different commands (TraceWin syntax)."""
