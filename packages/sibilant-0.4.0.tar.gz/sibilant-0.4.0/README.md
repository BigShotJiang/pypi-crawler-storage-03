# sibilant

sibilant is a pure python VoIP/SIP/RTP library. It currently supports PCMA, PCMU, and telephone-event.


> **Warning**
> This library is still in early development and is not yet ready for production use.
