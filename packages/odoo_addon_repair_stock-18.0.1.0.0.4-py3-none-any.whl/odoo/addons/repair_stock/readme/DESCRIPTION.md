This module acts as a base for the stock related modules for repairs. It
adds some common features that may be overriding between them, as the
compute for the pickings or the smart button for the transfers.
