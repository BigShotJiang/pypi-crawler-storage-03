from __future__ import annotations

from . import main, constants

__version__ = constants.VERSION


if __name__ == '__main__':
    main.run()
