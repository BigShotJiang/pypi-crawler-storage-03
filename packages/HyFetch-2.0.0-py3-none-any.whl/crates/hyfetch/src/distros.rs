#![allow(non_camel_case_types)]

include!(concat!(env!("OUT_DIR"), "/distros.rs"));
