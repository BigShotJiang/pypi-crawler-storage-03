# Reporting a Vulnerability

If you discover a possible security issue in this project, please notify us via email grottimeireles@gmail.com. Do not create a public issue on GitHub.
