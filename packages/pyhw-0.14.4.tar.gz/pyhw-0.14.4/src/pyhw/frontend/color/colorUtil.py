def colorPrefix(color):
    return f"\033[{color}m"


def colorSuffix():
    return "\033[0m"
