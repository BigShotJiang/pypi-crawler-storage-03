from .nicBase import NICDetect


__all__ = ["NICDetect"]
