from .npuBase import NPUDetect


__all__ = ['NPUDetect']
