"""
Git hooks manager package.
"""
