"""License generator module for DevTools."""

from .generator import generate_license

__all__ = ["generate_license"]
