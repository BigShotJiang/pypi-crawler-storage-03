"""The fmu.* package namespace.

Do not add anything else to this module.
"""

__path__ = __import__("pkgutil").extend_path(__path__, __name__)
