2025-08-08 Version: 3.0.0
- Support API CancelAiCallDetails.
- Support API CreateAiCallTask.
- Support API ImportTaskNumberDatas.
- Support API ListAvailableTts.
- Support API LlmSmartCallEncrypt.
- Support API QueryAiCallDetailPage.
- Support API QueryAiCallTaskDetail.
- Support API QueryAiCallTaskPage.
- Support API QueryConversationDetailInfo.
- Support API StartAiCallTask.
- Support API StopAiCallTask.
- Support API UpdateAiCallTask.
- Update API LlmSmartCall: add request parameters BizParam.
- Update API LlmSmartCall: add request parameters CustomerLineCode.
- Update API LlmSmartCall: add request parameters Extension.
- Update API LlmSmartCall: add request parameters SessionTimeout.
- Update API LlmSmartCall: add request parameters TtsSpeed.
- Update API LlmSmartCall: add request parameters TtsVoiceCode.
- Update API LlmSmartCall: add request parameters TtsVolume.


2025-02-11 Version: 2.1.0
- Support API HangupOperate.


2024-12-20 Version: 2.0.0
- Support API LlmSmartCall.
- Delete API ListOuterOrderedNumbers.


2023-02-07 Version: 1.0.3
- Upgrade SDK.

2021-08-31 Version: 1.0.2
- AMP version.

2021-07-15 Version: 1.0.1
- Generated python 2019-10-15 for aiccs.

2021-05-18 Version: 1.0.0
- Publish multi language sdk.

