class DuplicateColumnWarning(Warning):
    pass
