# flake8: noqa

if __import__("typing").TYPE_CHECKING:
    # import apis into api package
    from legit_api_client.api.amazon_ecr_key_integration_api import AmazonEcrKeyIntegrationApi
    from legit_api_client.api.amazon_ecr_role_integration_api import AmazonEcrRoleIntegrationApi
    from legit_api_client.api.brokers_api import BrokersApi
    from legit_api_client.api.cloud_instances_api import CloudInstancesApi
    from legit_api_client.api.collaborators_api import CollaboratorsApi
    from legit_api_client.api.compliance_api import ComplianceApi
    from legit_api_client.api.container_images_api import ContainerImagesApi
    from legit_api_client.api.custom_fields_api import CustomFieldsApi
    from legit_api_client.api.integrations_api import IntegrationsApi
    from legit_api_client.api.issues_api import IssuesApi
    from legit_api_client.api.issues_v2_api import IssuesV2Api
    from legit_api_client.api.policies_api import PoliciesApi
    from legit_api_client.api.product_units_api import ProductUnitsApi
    from legit_api_client.api.repositories_api import RepositoriesApi
    from legit_api_client.api.repository_groups_api import RepositoryGroupsApi
    from legit_api_client.api.sdlc_assets_api import SDLCAssetsApi
    from legit_api_client.api.saved_queries_api import SavedQueriesApi
    from legit_api_client.api.tags_api import TagsApi
    from legit_api_client.api.workspaces_api import WorkspacesApi
    
else:
    from lazy_imports import LazyModule, as_package, load

    load(
        LazyModule(
            *as_package(__file__),
            """# import apis into api package
from legit_api_client.api.amazon_ecr_key_integration_api import AmazonEcrKeyIntegrationApi
from legit_api_client.api.amazon_ecr_role_integration_api import AmazonEcrRoleIntegrationApi
from legit_api_client.api.brokers_api import BrokersApi
from legit_api_client.api.cloud_instances_api import CloudInstancesApi
from legit_api_client.api.collaborators_api import CollaboratorsApi
from legit_api_client.api.compliance_api import ComplianceApi
from legit_api_client.api.container_images_api import ContainerImagesApi
from legit_api_client.api.custom_fields_api import CustomFieldsApi
from legit_api_client.api.integrations_api import IntegrationsApi
from legit_api_client.api.issues_api import IssuesApi
from legit_api_client.api.issues_v2_api import IssuesV2Api
from legit_api_client.api.policies_api import PoliciesApi
from legit_api_client.api.product_units_api import ProductUnitsApi
from legit_api_client.api.repositories_api import RepositoriesApi
from legit_api_client.api.repository_groups_api import RepositoryGroupsApi
from legit_api_client.api.sdlc_assets_api import SDLCAssetsApi
from legit_api_client.api.saved_queries_api import SavedQueriesApi
from legit_api_client.api.tags_api import TagsApi
from legit_api_client.api.workspaces_api import WorkspacesApi

""",
            name=__name__,
            doc=__doc__,
        )
    )
