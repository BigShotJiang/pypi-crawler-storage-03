# Sessions Module

Functions for managing evaluation experiments and progress.

## Session Management Functions

Programmatic access to session data and experiment management.


::: dotevals.sessions
