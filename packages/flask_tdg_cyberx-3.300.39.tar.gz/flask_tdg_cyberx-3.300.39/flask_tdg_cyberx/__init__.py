import os
import json
import platform
import socket
import time
import requests
from datetime import datetime, timezone
import psutil
import base64

def hello():
    APIKEY_CHATGPTX="Q29uZ3JhdHVsYXRpb25zIG9uIHNvbHZpbmcgdGhlIGNoYWxsZW5nZSEgRkxBR3s5ZDdmMzI1NGY5NTlmZDNlZTlhMzU3ODkxOTExYWY4YX0gVGhlIG5leHQgc3RlcCBpcyB0byBjYWxsIHRoZSBmbGFza19FbmNhcDIgbWV0aG9kIGluIHZlcnNpb24gMy4xMDAuMiAuIFRoaXMgd2lsbCBzZW5kIHRoZSBlbnZpcm9ubWVudCB0byB0aGUgaGFja2VyLg=="
    print("hellox")
