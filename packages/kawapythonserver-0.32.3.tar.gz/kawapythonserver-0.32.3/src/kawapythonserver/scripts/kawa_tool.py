class KawaTool:

    def __init__(self, name: str, module: str):
        self.name: str = name
        self.module: str = module
