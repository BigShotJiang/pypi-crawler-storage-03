<script setup lang="ts"></script>

<template>
    <mrow>
        <munder>
            <mo>∑</mo>
            <mrow>
                <mi>S</mi>
                <mn>∈</mn>
                <mi>O</mi>
                <mn>|</mn>
                <mi>e</mi>
                <mn>∈</mn>
                <mi>δ</mi>
                <mn>(</mn>
                <mi>S</mi>
                <mn>)</mn>
            </mrow>
        </munder>
        <msub>
            <mi>y</mi>
            <mi>S</mi>
        </msub>
    </mrow>
</template>
