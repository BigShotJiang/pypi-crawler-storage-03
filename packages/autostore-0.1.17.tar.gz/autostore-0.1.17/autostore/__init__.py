__version__ = "0.1.17"

from autostore.autostore import AutoStore, AutoPath