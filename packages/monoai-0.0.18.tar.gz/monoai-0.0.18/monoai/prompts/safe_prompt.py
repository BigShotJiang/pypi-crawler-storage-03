# TODO: Implement safe prompt

