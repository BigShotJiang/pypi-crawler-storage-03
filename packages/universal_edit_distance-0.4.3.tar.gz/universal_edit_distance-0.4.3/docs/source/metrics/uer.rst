.. _universal_error_rate:

Universal Error Rate (UER)
==========================


Functions
---------

.. autofunction:: universal_edit_distance.universal_edit_distance_array

.. autofunction:: universal_edit_distance.universal_error_rate_array