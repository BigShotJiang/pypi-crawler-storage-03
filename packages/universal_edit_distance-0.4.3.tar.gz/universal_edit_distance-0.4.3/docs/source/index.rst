.. Universal Edit Distance documentation master file, created by
   sphinx-quickstart on Sat Mar 22 13:33:11 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Universal Edit Distance's documentation!
===================================================



How to install
==============
The library is available from PyPI under the name `universal-edit-distance <https://pypi.org/project/universal-edit-distance/>`_.
The package can therefore be install in various ways including

.. code-block:: bash

   pip install universal-edit-distance

.. code-block:: bash

   uv add universal-edit-distance




Table of Contents
=================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   metrics/index.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
