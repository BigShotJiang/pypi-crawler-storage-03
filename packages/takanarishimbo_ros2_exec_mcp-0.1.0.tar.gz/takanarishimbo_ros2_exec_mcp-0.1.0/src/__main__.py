"""Entry point for the ROS2 Exec MCP Server."""

from .server import main

if __name__ == "__main__":
    main()
