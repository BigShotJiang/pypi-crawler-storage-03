"""ROS2 Exec MCP Server - Execute ROS 2 CLI commands via MCP."""

__version__ = "0.1.0"
