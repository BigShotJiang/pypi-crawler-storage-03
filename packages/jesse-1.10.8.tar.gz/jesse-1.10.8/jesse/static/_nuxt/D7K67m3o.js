import{bH as a,O as e,a1 as t}from"./5gBRjOdc.js";const s=a((r,o)=>{if(e().plan==="free"||e().plan==="guest")return t("/")});export{s as default};
