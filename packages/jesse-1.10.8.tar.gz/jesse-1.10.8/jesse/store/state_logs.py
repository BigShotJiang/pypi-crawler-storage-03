class LogsState:
    def __init__(self) -> None:
        self.errors = []
        self.info = []
