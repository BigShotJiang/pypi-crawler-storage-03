Variational PEPS
================

.. toctree::
   :maxdepth: 2
   :caption: VariPEPS

   general
   design/features
   examples

.. toctree::
   :maxdepth: 2
   :caption: API documentation

   Public API Reference <api/index>
