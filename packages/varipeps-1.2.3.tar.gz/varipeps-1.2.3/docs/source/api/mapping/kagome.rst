.. _varipeps_mapping_kagome:

.. currentmodule:: varipeps.mapping.kagome

Mapping of Kagome structures (:mod:`varipeps.mapping.kagome`)
=============================================================

.. automodule:: varipeps.mapping.kagome
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
