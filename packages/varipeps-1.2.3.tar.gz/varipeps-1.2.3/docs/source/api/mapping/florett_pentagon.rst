.. _varipeps_mapping_florett_pentagon:

.. currentmodule:: varipeps.mapping.florett_pentagon

Mapping of Floret-Pentagon structures (:mod:`varipeps.mapping.florett_pentagon`)
================================================================================

.. automodule:: varipeps.mapping.florett_pentagon
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
