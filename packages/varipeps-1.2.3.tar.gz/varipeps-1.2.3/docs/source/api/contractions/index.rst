.. _varipeps_contractions:

.. py:module:: varipeps.contractions

.. currentmodule:: varipeps.contractions

Contractions definitions and helper methods (:mod:`varipeps.contractions`)
==========================================================================

.. toctree::
   :maxdepth: 2

   definitions
   apply

.. automodule:: varipeps.contractions
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
