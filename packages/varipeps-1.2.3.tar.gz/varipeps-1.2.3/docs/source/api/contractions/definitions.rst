.. _varipeps_contractions_definitions:

.. currentmodule:: varipeps.contractions

Definitions for contractions (:class:`varipeps.contractions.Definitions`)
=========================================================================

.. autoclass:: Definitions
   :members:
   :undoc-members:
   :show-inheritance:
