.. _varipeps_expectation_model:

.. currentmodule:: varipeps.expectation.model

Model of general expectation value calculation
==============================================

.. automodule:: varipeps.expectation.model
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
