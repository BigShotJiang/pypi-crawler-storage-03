.. _varipeps_expectation_two_sites:

.. currentmodule:: varipeps.expectation.two_sites

Calculation of two sites expectation values
===========================================

.. automodule:: varipeps.expectation.two_sites
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
