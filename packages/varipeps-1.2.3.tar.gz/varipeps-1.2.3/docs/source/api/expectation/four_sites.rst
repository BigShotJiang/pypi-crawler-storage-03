.. _varipeps_expectation_four_sites:

.. currentmodule:: varipeps.expectation.four_sites

Calculation of four sites expectation values
============================================

.. automodule:: varipeps.expectation.four_sites
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
