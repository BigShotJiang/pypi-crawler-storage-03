.. _varipeps_utils_projector_dict:

.. currentmodule:: varipeps.utils.projector_dict

CTM projector management helpers (:mod:`varipeps.utils.projector_dict`)
=======================================================================

.. automodule:: varipeps.utils.projector_dict
   :members:
   :undoc-members:
   :show-inheritance:
