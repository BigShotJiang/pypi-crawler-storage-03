.. _varipeps_utils_periodic_indices:

.. currentmodule:: varipeps.utils.periodic_indices

Helper to calculate perodic indices (:mod:`varipeps.utils.periodic_indices`)
============================================================================

.. automodule:: varipeps.utils.periodic_indices
   :members:
   :undoc-members:
   :show-inheritance:
