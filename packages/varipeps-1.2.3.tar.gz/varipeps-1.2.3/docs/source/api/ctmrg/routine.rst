.. _varipeps_ctmrg_routine:

.. currentmodule:: varipeps.ctmrg

Calculate the new converged CTMRG tensors (:func:`varipeps.ctmrg.calc_ctmrg_env` and :func:`varipeps.ctmrg.calc_ctmrg_env_custom_rule`)
=======================================================================================================================================

.. autofunction:: calc_ctmrg_env

.. autofunction:: calc_ctmrg_env_custom_rule
