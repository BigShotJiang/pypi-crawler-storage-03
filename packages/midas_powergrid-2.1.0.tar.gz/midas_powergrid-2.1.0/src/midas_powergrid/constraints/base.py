class GridElementConstraint:
    def step(self, time: int) -> bool:
        return False
