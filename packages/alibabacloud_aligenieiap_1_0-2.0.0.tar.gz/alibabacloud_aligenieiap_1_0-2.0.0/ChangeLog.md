2024-04-18 Version: 1.2.2
- Generated python iap_1.0 for AliGenie.

2024-04-17 Version: 1.2.1
- Generated python iap_1.0 for AliGenie.

2024-04-16 Version: 1.2.0
- Support API CallBackThirdRightSendPlan.
- Support API CheckThirdRightSendPlan.


2024-04-11 Version: 1.1.1
- Update API GetBusAppConfig: update response param.


2024-03-29 Version: 1.1.0
- Support API GetBusAppConfig.


2022-06-23 Version: 1.0.20
- SDK upgrade.

2022-06-09 Version: 1.0.19
- SDK upgrade.

2022-05-12 Version: 1.0.18
- SDK upgrade.

2021-11-24 Version: 1.0.17
- SDK upgrade.

2021-11-18 Version: 1.0.15
- SDK upgrade.

2021-09-17 Version: 0.0.3
- Support PushNotifications.
- Support WakeUpApp.

2021-09-16 Version: 0.0.2
- Support PushNotifications.
- Support WakeUpApp.

