# Mister Webhooks Python SDK

Mister Webhooks is a service to help you consume webhook events without having to host your own webhook-receiver service.

## API Documentation

API documentation is [available online](https://mister-webhooks-client-python.readthedocs.io/en/latest/).

## Get the package

The package is [hosted on PyPI](https://pypi.org/project/mister-webhooks/).
