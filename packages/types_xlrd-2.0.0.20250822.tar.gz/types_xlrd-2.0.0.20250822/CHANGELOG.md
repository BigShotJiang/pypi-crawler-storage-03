## 2.0.0.20250822 (2025-08-22)

Add __slots__ to third-party packages using stubdefaulter ([#14619](https://github.com/python/typeshed/pull/14619))

## 2.0.0.20250326 (2025-03-26)

Add stubs for `xlrd` (#13676)

