
from setuptools import setup

setup(package_data={'xlrd-stubs': ['__init__.pyi', 'biffh.pyi', 'book.pyi', 'compdoc.pyi', 'formatting.pyi', 'formula.pyi', 'info.pyi', 'sheet.pyi', 'timemachine.pyi', 'xldate.pyi', 'METADATA.toml', 'py.typed']})
