__AuthToken__   = ""
__Sender__      = ""
__APIKey__      = ""
__APIVersion__  = "2.04"
__APIURL__      = "https://api.tnz.co.nz/api/v"+__APIVersion__;
__APIHeaders__  = {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "encoding": "utf-8"
}