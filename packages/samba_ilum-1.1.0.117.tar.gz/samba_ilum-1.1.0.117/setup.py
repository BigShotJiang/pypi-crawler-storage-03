from distutils.core import setup
from setuptools import setup, find_packages
from pathlib import Path
from typing import Optional
import json

setup(
    name = "SAMBA_ilum",
    version = "1.1.0.117",
    # Define os pacotes a serem incluídos
    # Isso empacotará tanto samba_ilum quanto samba_ilum.src
    packages=['samba_ilum', 'samba_ilum.src'],
    # A entrada principal para o comando do terminal
    entry_points={'console_scripts': ['samba_ilum = samba_ilum.__main__:main']},
    description = "...",
    author = "Augusto de Lelis Araujo",
    author_email = "augusto-lelis@outlook.com",
    license = "Closed source",
    install_requires=['matplotlib',
                      'pymatgen',
                      'pyfiglet',
                      'requests',
                      'plotly',
                      'scipy',
                      'numpy',
                      'uuid',
                      'vasprocar'],
    # Garante que os arquivos .dat, .png, etc. sejam incluídos
    package_data={'samba_ilum': ['*.dat', '*.png', '*.jpg', '*']},
)

# python3 -m pip install --upgrade twine
# python setup.py sdist
# python -m twine upload dist/*