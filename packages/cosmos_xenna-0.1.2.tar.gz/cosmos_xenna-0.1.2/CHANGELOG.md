# Changelog


## Latest

## [0.1.2]

### Released
- 2025-08-19

### Added
- Add workflow to publish packages to PyPI.

### Fixed
- Fixed bug on queue-size stats when back-pressure kicking in.
- Fixed a possible hang when having a fan-in stage with large stage_batch_size.

## [0.1.1]

### Released
- 2025-08-14

### Added
- Add `over_provision_factor` to `StageSpec` to influence stage worker allocation by autoscaler.
- Allow `StageSpec.num_workers_per_node` to be `float` for greater flexibility.
- Add support to respect `CUDA_VISIBLE_DEVICES` if environment variable `XENNA_RESPECT_CUDA_VISIBLE_DEVICES` is set.

## [0.1.0]

### Released
- 2025-06-11

### Added
- Initial version