# Re-export Pos from primitives for backward compatibility
from validate_actions.domain_model.primitives import Pos

__all__ = ["Pos"]
