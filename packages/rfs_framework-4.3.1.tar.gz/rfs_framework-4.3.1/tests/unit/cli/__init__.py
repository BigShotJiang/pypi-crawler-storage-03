"""
CLI module unit tests
"""