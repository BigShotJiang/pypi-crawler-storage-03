"""
CLI integration tests
"""