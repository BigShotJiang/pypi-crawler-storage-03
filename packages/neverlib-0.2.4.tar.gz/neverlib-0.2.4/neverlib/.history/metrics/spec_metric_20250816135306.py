'''
Author: 凌逆战 | Never
Date: 2025-08-16 13:51:57
Description: 
'''



def mcd(ref_spec, test_spec):
    """
    梅尔倒谱距离 Mel-Cepstral Distance（MCD）
    ref_spec: 参考频谱
    test_spec: 测试频谱
    """
    