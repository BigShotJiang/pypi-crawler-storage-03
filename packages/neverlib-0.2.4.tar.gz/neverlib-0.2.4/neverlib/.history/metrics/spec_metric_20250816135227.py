'''
Author: 凌逆战 | Never
Date: 2025-08-16 13:51:57
Description: 
'''



def mcd(ref_spec, test_spec):
    # 