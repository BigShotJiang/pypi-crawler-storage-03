


def mcd(ref_spec, test_spec):
    # 