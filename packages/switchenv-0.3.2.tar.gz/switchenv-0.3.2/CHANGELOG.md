## Changelog

#### 0.2.0
##### New features
 - Can now create composed profiles
 - Added the sw alias for switchenv at the command-line.

##### Under the hood
 - Changed format of json data store.  It is now versioned.

##### Bug fixes
 - Fixed bug in how bash prompt was mutated
