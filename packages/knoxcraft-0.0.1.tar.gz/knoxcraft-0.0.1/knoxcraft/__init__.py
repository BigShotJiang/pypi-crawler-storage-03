# knoxcraft/__init__.py
from .terp import Terp, TerpBlockType