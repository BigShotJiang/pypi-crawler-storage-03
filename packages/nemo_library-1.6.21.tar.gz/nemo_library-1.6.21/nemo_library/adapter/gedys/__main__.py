from nemo_library.adapter.gedys.flow import gedys_flow

if __name__ == "__main__":
    gedys_flow()
