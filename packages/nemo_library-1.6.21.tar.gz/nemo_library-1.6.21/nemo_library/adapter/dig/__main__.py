
from nemo_library.adapter.dig.flow import dig_flow


if __name__ == "__main__":
    dig_flow()
