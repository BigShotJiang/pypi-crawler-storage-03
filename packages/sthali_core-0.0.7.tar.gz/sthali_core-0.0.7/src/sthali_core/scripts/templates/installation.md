
---

### Instalation

#### Using PYPI

```
pip install {{ project["name"] }}
```

#### Using GitHub repo

```
git clone https://github.com/{{ organization_name }}/{{ project["name"] }}.git
cd {{ project["name"] }}
pip install .
```
