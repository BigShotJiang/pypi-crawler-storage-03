{{ heading_level }} `{{ name }}`

```
{{ docstring }}
```

{% if sub %}{{ sub }}{% endif %}
