# Contributing to Uxarray

Anyone can contribute to and participate in the Uxarray project
at any levels of project development! We conduct all of our work
in the open, and all of our work is Open Source Licensed.

Please see our
[Contributor’s Guide](https://uxarray.readthedocs.io/en/latest/contributing.html)
for detailed information!
