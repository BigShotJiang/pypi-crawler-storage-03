# threshold for number of faces before recompensing rasterization
N_FACE_THRESHOLD = 10000
