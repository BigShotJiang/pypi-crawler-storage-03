"""Core global utilities and types for validate-actions."""
