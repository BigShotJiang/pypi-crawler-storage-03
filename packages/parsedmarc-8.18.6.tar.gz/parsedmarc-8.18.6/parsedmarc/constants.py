__version__ = "8.18.6"
USER_AGENT = f"parsedmarc/{__version__}"
