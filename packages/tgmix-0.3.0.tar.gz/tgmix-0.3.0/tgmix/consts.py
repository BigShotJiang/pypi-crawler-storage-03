MEDIA_KEYS = [
    "photo", "video_file", "voice_message",
    "video_message", "sticker", "file"
]
