from loguru import logger

__all__ = ["logger"]
