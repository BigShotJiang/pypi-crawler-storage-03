from django.apps import AppConfig


class DefaultAppConfig(AppConfig):
    name = "unfold.contrib.inlines"
    label = "unfold_inlines"
