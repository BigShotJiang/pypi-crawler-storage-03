
This module is a WIP and will most likely become its own non-evm-specific library suitable for a wider range of use cases in the future