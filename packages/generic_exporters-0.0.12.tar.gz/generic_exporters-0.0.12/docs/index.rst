.. generic_exporters documentation master file, created by
   sphinx-quickstart on Thu Feb  1 21:29:06 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to generic_exporters's documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   source/modules.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
