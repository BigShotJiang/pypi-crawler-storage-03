"""zephyr
A neural network library on top of JAX allowing for easy and fast neural network designing, creation, and manipulation

Early Stage
"""

from zephyr.building.tracing import trace

__version__ = "0.0.19"
__author__ = "Marko Zolo Gozano Untalan"
