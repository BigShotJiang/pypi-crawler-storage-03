# Changelog

## 0.8.1 (2025-08-27)

Full Changelog: [v0.8.0...v0.8.1](https://github.com/evrimai/cartography-client/compare/v0.8.0...v0.8.1)

### Bug Fixes

* avoid newer type syntax ([2b4c710](https://github.com/evrimai/cartography-client/commit/2b4c710297b5d4b7f233c7e868933d508f47afa2))


### Chores

* **internal:** change ci workflow machines ([b1b2d68](https://github.com/evrimai/cartography-client/commit/b1b2d68da44ce55d83cf66a32c01cbc141d5c5fd))

## 0.8.0 (2025-08-25)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/evrimai/cartography-client/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([1a41dce](https://github.com/evrimai/cartography-client/commit/1a41dce5f3515b85d5e12fa3be3ae24331fb49a3))

## 0.7.0 (2025-08-23)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/evrimai/cartography-client/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([4991942](https://github.com/evrimai/cartography-client/commit/4991942007689cf9ce15a562b7b7346c7c6d4554))


### Chores

* update github action ([5a20e0d](https://github.com/evrimai/cartography-client/commit/5a20e0d72f059a5375b023aa099ad42712ad6468))

## 0.6.0 (2025-08-20)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/evrimai/cartography-client/compare/v0.5.0...v0.6.0)

### Features

* **api:** api update ([463f7cf](https://github.com/evrimai/cartography-client/commit/463f7cf4912d177044712520fb2310c13367912e))

## 0.5.0 (2025-08-12)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/evrimai/cartography-client/compare/v0.4.0...v0.5.0)

### Features

* **api:** api update ([2ec757e](https://github.com/evrimai/cartography-client/commit/2ec757e00ad59797ba75e34be63bb185471a32c2))

## 0.4.0 (2025-08-12)

Full Changelog: [v0.3.1...v0.4.0](https://github.com/evrimai/cartography-client/compare/v0.3.1...v0.4.0)

### Features

* **api:** api update ([153bc19](https://github.com/evrimai/cartography-client/commit/153bc192d14eb79fdfa4f145993aebbf15e5c36d))


### Chores

* **internal:** codegen related update ([b85c126](https://github.com/evrimai/cartography-client/commit/b85c12659f0b39c6199de08fe7056c7e99b1f02c))
* **internal:** update comment in script ([a07f9a0](https://github.com/evrimai/cartography-client/commit/a07f9a0d031cd204b36c9809aa836a41141e1f75))

## 0.3.1 (2025-08-09)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/evrimai/cartography-client/compare/v0.3.0...v0.3.1)

### Chores

* update @stainless-api/prism-cli to v5.15.0 ([5cd60ac](https://github.com/evrimai/cartography-client/commit/5cd60acb8f0654f9b86003f311aaeab26c0a63aa))

## 0.3.0 (2025-08-05)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/evrimai/cartography-client/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([54ce37e](https://github.com/evrimai/cartography-client/commit/54ce37edecc328ec401a24e9ef4c8631086a2e23))

## 0.2.0 (2025-08-05)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/evrimai/cartography-client/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([99f1a13](https://github.com/evrimai/cartography-client/commit/99f1a133c89c4ed7d5fba0836aad152c775d8274))

## 0.1.0 (2025-08-05)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/evrimai/cartography-client/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([d76ab2e](https://github.com/evrimai/cartography-client/commit/d76ab2e066b6aeda4e772d8d56bd06bb934bba20))

## 0.0.1 (2025-08-05)

Full Changelog: [v0.0.1-alpha.0...v0.0.1](https://github.com/evrimai/cartography-client/compare/v0.0.1-alpha.0...v0.0.1)

### Chores

* update SDK settings ([6f6f16f](https://github.com/evrimai/cartography-client/commit/6f6f16ff247068a3c7a634f0846bb8efc7fec0e9))
* update SDK settings ([f1ee3e6](https://github.com/evrimai/cartography-client/commit/f1ee3e6f47aaade030da77c1864e42054adee06c))
