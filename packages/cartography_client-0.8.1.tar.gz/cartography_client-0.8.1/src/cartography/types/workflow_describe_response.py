# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict
from typing_extensions import TypeAlias

__all__ = ["WorkflowDescribeResponse"]

WorkflowDescribeResponse: TypeAlias = Dict[str, object]
