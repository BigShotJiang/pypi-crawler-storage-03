from .hypercube import Hypercube

__all__ = ['Hypercube']