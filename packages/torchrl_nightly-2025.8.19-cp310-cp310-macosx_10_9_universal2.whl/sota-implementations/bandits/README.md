# Bandits example

## Note:
This example is not included in the benchmarked results of the current release (v0.3). The intention is to include it in the
benchmarking of future releases, to ensure that it can be successfully run with the release code and that the
results are consistent. For now, be aware that this additional check has not been performed in the case of this
specific example.
