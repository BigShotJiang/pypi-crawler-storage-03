from .core import DreamRender

dreamrender = DreamRender()  # default model object
