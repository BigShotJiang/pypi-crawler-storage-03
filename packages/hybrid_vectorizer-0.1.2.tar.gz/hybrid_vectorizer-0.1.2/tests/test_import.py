def test_import():
    import hybrid_vectorizer  # noqa: F401
