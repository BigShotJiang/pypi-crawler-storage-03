# Phase 1: Project Setup & Infrastructure - Implementation Decisions

This document captures all architectural decisions made for Phase 1 implementation of the ML Agents project refactoring from Jupyter notebook to production CLI application.

## Overview

Phase 1 establishes the foundational infrastructure needed to support the transition from experimental notebook code to a production-ready CLI application. All decisions prioritize modern Python practices while maintaining compatibility with existing code and the uv package manager.

## Key Architectural Decisions

### 1. Project Structure

**Decision**: Reorganize codebase with clear separation of concerns

**Structure**:
```
ml-agents/
   src/
      __init__.py
      config.py              # Moved from root, enhanced
      core/
         __init__.py
         experiment_config.py
         dataset_loader.py
         reasoning_inference.py
         experiment_runner.py
         results_processor.py
      reasoning/
         __init__.py
         base.py
         [individual reasoning approaches]
      utils/
          __init__.py
          logging_config.py
          api_clients.py
          rate_limiter.py
   tests/
      __init__.py
      conftest.py
      core/
      reasoning/
      utils/
   logs/                      # Log files
   pyproject.toml            # Modern Python packaging
```

**Rationale**:
- Clear separation between source code (`src/`) and tests (`tests/`)
- Logical grouping of functionality (core business logic, reasoning approaches, utilities)
- Follows modern Python packaging standards
- Easier to navigate and maintain as project grows

### 2. Package Management & Dependencies

**Decision**: Replace requirements.txt with pyproject.toml

**Configuration**:
```toml
[build-system]
requires = ["setuptools>=68.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "ml-agents"
version = "0.1.0"
description = "ML Agents Reasoning Research Platform"
dependencies = [
    "transformers>=4.35.0",
    "accelerate>=0.24.0",
    "openai>=1.3.0",
    "cohere>=4.37.0",
    "anthropic>=0.8.0",
    "pandas>=2.1.0",
    "datasets>=2.14.0",
    "python-dotenv>=1.0.0",
    "tqdm>=4.66.0",
    "huggingface_hub>=0.19.0",
    "pyyaml>=6.0.1",
    "torch>=2.1.0",
]

[project.optional-dependencies]
dev = [
    "black>=23.0.0",
    "mypy>=1.5.0",
    "pytest>=7.4.0",
    "pytest-cov>=4.0.0",
    "pytest-mock>=3.11.0",
    "pytest-asyncio>=0.21.0",
    "flake8>=6.0.0",
    "isort>=5.12.0",
    "pre-commit>=3.4.0",
]
```

**Rationale**:
- Modern Python packaging standard
- Better dependency resolution and metadata management
- Supports optional dev dependencies
- Compatible with uv package manager
- Enables `pip install -e .` for development

### 3. Code Quality Standards

**Decision**: Enforce consistent code quality with automated tools

**Standards**:
- **Line length**: 88 characters (black default)
- **Code formatting**: Black with isort for import sorting
- **Type checking**: Mypy in strict mode with gradual adoption
- **Linting**: Flake8 for additional code quality checks
- **Pre-commit hooks**: Automatic formatting and validation

**Configuration files**:
- `.pre-commit-config.yaml`: Automated pre-commit hooks
- `pyproject.toml`: Tool configurations for black, isort, mypy
- `.flake8`: Flake8 configuration

**Rationale**:
- Consistent code style across contributors
- Catch errors early with type checking
- Reduce code review time with automated formatting
- Modern Python development best practices

### 4. Testing Framework

**Decision**: Comprehensive testing with pytest and plugins

**Configuration**:
- **Framework**: pytest with coverage reporting
- **Plugins**: pytest-cov, pytest-mock, pytest-asyncio
- **Coverage threshold**: 80% minimum
- **Structure**: Mirror src/ directory structure in tests/

**pytest.ini**:
```ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts =
    --cov=src
    --cov-report=html
    --cov-report=term-missing
    --cov-fail-under=80
    -v
```

**Rationale**:
- Industry standard testing framework
- Coverage ensures code quality
- Mocking capabilities for API testing
- Async support for future API optimizations

### 5. Logging Configuration

**Decision**: Flexible logging with environment-based configuration

**Features**:
- **Format**: Human-readable by default, JSON option via environment
- **Levels**: DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Output**: Console by default, file output configurable
- **Rotation**: Size-based (10MB), keep 5 files
- **Environment control**: LOG_LEVEL, LOG_FORMAT, LOG_TO_FILE

**Implementation**:
```python
# src/utils/logging_config.py
def setup_logging(
    level: str = "INFO",
    format_type: str = "human",
    log_to_file: bool = False,
    log_dir: str = "logs"
) -> None:
    """Configure logging based on environment variables."""
```

**Rationale**:
- Flexible configuration for different environments
- Structured logging option for production monitoring
- Prevents log files from growing too large
- Easy debugging with appropriate log levels

### 6. Configuration Management

**Decision**: Extend existing config.py with structured classes

**Architecture**:
- **Location**: Move config.py to src/config.py
- **Classes**: Create ExperimentConfig class for structured configuration
- **Validation**: Parameter range validation and type checking
- **File support**: YAML configuration files with environment overrides
- **Backward compatibility**: Preserve existing API key management

**ExperimentConfig class**:
```python
@dataclass
class ExperimentConfig:
    """Experiment configuration with validation."""
    dataset_name: str = "MrLight/bbeh-eval"
    sample_count: int = 50
    provider: str = "openrouter"
    model: str = "openai/gpt-oss-20b:free"
    temperature: float = 0.3
    max_tokens: int = 512
    top_p: float = 0.9
    reasoning_approaches: List[str] = field(default_factory=lambda: ["None"])
    output_dir: str = "./outputs"

    def validate(self) -> None:
        """Validate configuration parameters."""
        # Temperature: 0.0-2.0
        # top_p: 0.0-1.0
        # max_tokens: 1-4096
        # Valid provider/model combinations
```

**Validation Rules**:
- **Temperature**: 0.0 to 2.0
- **top_p**: 0.0 to 1.0
- **max_tokens**: 1 to 4096
- **Provider/model combinations**: Validated against supported models
- **Reasoning approaches**: Must be from supported list

**Rationale**:
- Type safety with dataclasses
- Clear validation rules prevent runtime errors
- YAML support for complex configurations
- Maintains existing environment variable patterns

### 7. Environment Configuration

**Decision**: Enhanced environment variable management

**Files**:
- **`.env.example`**: Template with all required variables
- **`.env`**: Actual values (gitignored)
- **Environment validation**: Check required variables on startup

**Required Variables**:
```bash
# API Keys
ANTHROPIC_API_KEY=your_key_here
COHERE_API_KEY=your_key_here
OPENROUTER_API_KEY=your_key_here
HUGGINGFACE_API_KEY=your_key_here

# Logging Configuration
LOG_LEVEL=INFO
LOG_FORMAT=human  # or json
LOG_TO_FILE=false

# Experiment Defaults
DEFAULT_PROVIDER=openrouter
DEFAULT_MODEL=openai/gpt-oss-20b:free
```

**Rationale**:
- Clear documentation of required configuration
- Prevents runtime failures due to missing keys
- Flexible logging configuration
- Good defaults for quick setup

## Implementation Order

### Priority 1: Foundation (Must complete first)
1. Create directory structure and __init__.py files
2. Set up pyproject.toml with dependencies
3. Move and enhance config.py
4. Configure pytest and create conftest.py

### Priority 2: Development Infrastructure
5. Set up pre-commit hooks
6. Implement logging configuration
7. Create ExperimentConfig class with validation
8. Set up environment validation

### Priority 3: Documentation Updates
9. Update imports in existing files
10. Create development setup documentation
11. Update CLAUDE.md with new structure

## Testing Strategy

### Unit Tests
- Test each class in isolation
- Mock all external dependencies (APIs, file system)
- Validate configuration validation logic
- Test error handling and edge cases

### Integration Tests
- Test configuration loading from files and environment
- Validate logging setup in different modes
- Test pre-commit hooks execution

### Coverage Requirements
- Minimum 80% test coverage
- All public methods must have tests
- Critical validation logic requires 100% coverage

## Migration Plan

### Backward Compatibility
- Keep existing notebook functional during transition
- Maintain existing API key loading functions
- Preserve current command line patterns where possible

### Rollout Approach
1. **Phase 1a**: Set up infrastructure without breaking existing code
2. **Phase 1b**: Migrate configuration gradually
3. **Phase 1c**: Update imports and test everything works
4. **Phase 1d**: Remove deprecated patterns

## Success Criteria

Phase 1 is complete when:
- [ ] All directory structure created with proper __init__.py files
- [ ] pyproject.toml replaces requirements.txt successfully
- [ ] Pre-commit hooks working and passing
- [ ] Logging configuration functional with file and console output
- [ ] ExperimentConfig class validates all parameters correctly
- [ ] Test coverage above 80% for all new code
- [ ] Existing notebook still functional
- [ ] All development tools (black, mypy, pytest) working properly

## Future Considerations

### Extensibility
- Plugin architecture for custom reasoning approaches
- Configuration schema versioning
- Multiple environment support (dev, staging, prod)

### Performance
- Lazy loading of heavy dependencies
- Caching configuration parsing
- Async logging for high-throughput scenarios

### Monitoring
- Structured logging for observability
- Configuration validation metrics
- Development workflow metrics

## Dependencies for Next Phases

Phase 1 provides the foundation for:
- **Phase 2**: Core class implementations can use structured configuration
- **Phase 3**: API integration can leverage logging and rate limiting infrastructure
- **Phase 4**: Reasoning approaches can use the base class architecture
- **Phase 5**: CLI interface can build on configuration management

This infrastructure investment in Phase 1 will pay dividends throughout the remaining phases by providing robust, well-tested foundations for all subsequent development.
