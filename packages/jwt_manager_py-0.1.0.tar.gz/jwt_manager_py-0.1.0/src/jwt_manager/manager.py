import jwt
import datetime
from typing import Optional, Dict


class JWTManager:
    def __init__(self, secret: str, algorithm: str = "HS256",
                 access_ttl: int = 900, refresh_ttl: int = 3600):
        """
        :param secret: Clé secrète pour signer les tokens
        :param algorithm: Algorithme JWT (HS256 par défaut)
        :param access_ttl: Durée de vie access token (secondes)
        :param refresh_ttl: Durée de vie refresh token (secondes)
        """
        self.secret = secret
        self.algorithm = algorithm
        self.access_ttl = access_ttl
        self.refresh_ttl = refresh_ttl
        self.blacklist = set()  # blacklist en mémoire (par défaut)

    def create_access_token(self, payload: Dict) -> str:
        exp = datetime.datetime.now(datetime.UTC) + datetime.timedelta(seconds=self.access_ttl)
        payload = payload.copy()
        payload.update({"exp": exp, "type": "access"})
        return jwt.encode(payload, self.secret, algorithm=self.algorithm)

    def create_refresh_token(self, payload: Dict) -> str:
        exp = datetime.datetime.now(datetime.UTC) + datetime.timedelta(seconds=self.refresh_ttl)

        payload = payload.copy()
        payload.update({"exp": exp, "type": "refresh"})
        return jwt.encode(payload, self.secret, algorithm=self.algorithm)

    def verify_token(self, token: str) -> Dict:
        if token in self.blacklist:
            raise ValueError("Token is revoked")
        try:
            decoded = jwt.decode(token, self.secret, algorithms=[self.algorithm])
            return decoded
        except jwt.ExpiredSignatureError:
            raise ValueError("Token expired")
        except jwt.InvalidTokenError:
            raise ValueError("Invalid token")

    def refresh_access_token(self, refresh_token: str) -> str:
        payload = self.verify_token(refresh_token)
        if payload.get("type") != "refresh":
            raise ValueError("Not a refresh token")
        return self.create_access_token({"user_id": payload["user_id"]})

    def blacklist_token(self, token: str):
        self.blacklist.add(token)

    def is_revoked(self, token: str) -> bool:
        return token in self.blacklist
