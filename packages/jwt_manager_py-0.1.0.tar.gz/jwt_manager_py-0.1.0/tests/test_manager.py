from jwt_manager.manager import JWTManager
import time


def test_jwt_manager():
    jwtm = JWTManager(secret="supersecret", access_ttl=1)

    access = jwtm.create_access_token({"user_id": 123})
    refresh = jwtm.create_refresh_token({"user_id": 123})

    # Vérifier access token
    payload = jwtm.verify_token(access)
    assert payload["user_id"] == 123

    # Tester expiration
    time.sleep(2)
    try:
        jwtm.verify_token(access)
    except ValueError as e:
        assert str(e) == "Token expired"

    # Tester refresh
    new_access = jwtm.refresh_access_token(refresh)
    assert jwtm.verify_token(new_access)["user_id"] == 123

    # Tester blacklist
    jwtm.blacklist_token(refresh)
    assert jwtm.is_revoked(refresh)
