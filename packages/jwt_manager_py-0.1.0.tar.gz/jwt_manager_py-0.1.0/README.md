# 🔑 jwt-manager

Un utilitaire Python pour la **gestion simplifiée des tokens JWT** :  
- Création de **tokens d'accès** et de **refresh tokens**  
- Vérification et décodage sécurisé  
- Rotation de refresh tokens  
- Blacklist / révocation de tokens compromis  

Idéal pour les APIs Python (FastAPI, Flask, Django).

---

## 🚀 Installation

Depuis PyPI (après publication officielle) :

```bash
pip install jwt-manager


from jwt_manager import JWTManager

# Initialiser le gestionnaire
jwtm = JWTManager(secret="ma_cle_super_secrete", access_ttl=900, refresh_ttl=3600)

# Générer des tokens
access = jwtm.create_access_token({"user_id": 42})
refresh = jwtm.create_refresh_token({"user_id": 42})

# Vérifier un access token
payload = jwtm.verify_token(access)
print(payload)  # {'user_id': 42, 'exp': ..., 'type': 'access'}

# Rafraîchir un access token
new_access = jwtm.refresh_access_token(refresh)

# Blacklister un token
jwtm.blacklist_token(access)
print(jwtm.is_revoked(access))  # True
