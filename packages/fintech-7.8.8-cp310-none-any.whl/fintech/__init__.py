
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""The Python Fintech package"""

__version__ = '7.8.8'

__all__ = ['register', 'LicenseManager', 'FintechLicenseError']

def register(name=None, keycode=None, users=None):
    """
    Registers the Fintech package.

    It is required to call this function once before any submodule
    can be imported. Without a valid license the functionality is
    restricted.

    :param name: The name of the licensee.
    :param keycode: The keycode of the licensed version.
    :param users: The licensed EBICS user ids (Teilnehmer-IDs).
        It must be a string or a list of user ids. Not applicable
        if a license is based on subscription.
    """
    ...


class LicenseManager:
    """
    The LicenseManager class

    The LicenseManager is used to dynamically add or remove EBICS users
    to or from the list of licensed users. Please note that the usage
    is not enabled by default. It is activated upon request only.
    Users that are licensed this way are verified remotely on each
    restricted EBICS request. The transfered data is limited to the
    information which is required to uniquely identify the user.
    """

    def __init__(self, password):
        """
        Initializes a LicenseManager instance.

        :param password: The assigned API password.
        """
        ...

    @property
    def licensee(self):
        """The name of the licensee."""
        ...

    @property
    def keycode(self):
        """The license keycode."""
        ...

    @property
    def userids(self):
        """The registered EBICS user ids (client-side)."""
        ...

    @property
    def expiration(self):
        """The expiration date of the license."""
        ...

    def change_password(self, password):
        """
        Changes the password of the LicenseManager API.

        :param password: The new password.
        """
        ...

    def add_ebics_user(self, hostid, partnerid, userid):
        """
        Adds a new EBICS user to the license.

        :param hostid: The HostID of the bank.
        :param partnerid: The PartnerID (Kunden-ID).
        :param userid: The UserID (Teilnehmer-ID).

        :returns: `True` if created, `False` if already existent.
        """
        ...

    def remove_ebics_user(self, hostid, partnerid, userid):
        """
        Removes an existing EBICS user from the license.

        :param hostid: The HostID of the bank.
        :param partnerid: The PartnerID (Kunden-ID).
        :param userid: The UserID (Teilnehmer-ID).

        :returns: The ISO formatted date of final deletion.
        """
        ...

    def count_ebics_users(self):
        """Returns the number of EBICS users that are currently registered."""
        ...

    def list_ebics_users(self):
        """Returns a list of EBICS users that are currently registered (*new in v6.4*)."""
        ...


class FintechLicenseError(Exception):
    """Exception concerning the license"""
    ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzcvXdclEf+OP60LcCyICLNthaUZXcpYtco1lAXVGxYYGEXWMAFt6CSRakuHexiBWPDjr1GMxMvvVx6SO4u5S4x5VI+ySeXmOJvZp7dZSlGzX0///zgxcNTprxn5t3n'
        b'PTOfUD1+3NFfNPozmdFFS6VSWjqV1jKtjI7VcTq6gmmjUwXZVKpQy2q5Skoj0gq0QvRfXCw2i8ziCqqCpqnFlFa0gOIondu6iTSV6k5TxVKtSOee5qEVo6uE3HuSq1Tn'
        b'Xk5rRanuy9zX0Gsot2y5291B7ik5OlnyOnNOgUE2V28w6zJzZIWazDxNts5dzn4uQqB9LkYXI4sunXRYJu3SAvxOZP9vGosuNiqL1qI2VIpL6Gqqgiphit2sdAWC0spU'
        b'UDS1nl7PLHC5J1Cw6kzXbhGivwnorz8ulCNds4CSy9Sd1Pf4c0o+Bsd9noBC/2UfLihS/q3/auozPu+309upPiEkhU3EEDI2ysZmsU4o6YeCMqcnlI7Cu0PJqS2R6B4c'
        b'h+fTF6jgdticAquVi2A1rAufF5MSEwobYL0c1oCb8CKsZ6nZC4XwtBuo1VcGLGZMCpS1/ubsL9O/SM/P+io9RKf8WKWJ0XyV/lKGJc43MycrnzlbHjgxiirLESV4bpQz'
        b'5mEox+Q4eN4jNJeGDQpYA+sTLapQWBvOUEPBOQ6eBjeHmoeiVHBbFKgCdaAJNsWjRKABNIkoqQ+sgsfYIbM9jLhT5WwnEyI3uuHhJhf88q731CxjQbHOIMvi0WNap1Rj'
        b'MumM5rQMiz7frDcwuAvwqEkCpTRHGz0cWdvZTi7LYsjsFKWlGS2GtLROj7S0zHydxmApTEuTsy414Us7bfTE95guSCFBuGBfdPG+I2QYWkjjK0cLf8dXy0j0gR4IDsUr'
        b'k+H+MLUqFNQkOfoX960ySgDbwYGofFx2ypjnk/7K7PSgCm/RvwTo506mCBpxy8zMwdVfeVPpZRn7Yr6daEejD6eTr0GiPPpNhvKWhW544niBjM+y28BSeLwjZmoTrrub'
        b'+JdvhAspCYLztRWr8wesS6cs4RgLdsLWeR7gqBLBUw2bFkTM5/EgJEwVAqvDQ2MTQTusoKnly8QJhdAmpy1DUK6YFbDdA7UmXhW/0D0E1oLT4ChHBYEbHNg128MyGI/4'
        b'erAD1AXCLaApHLUYj6qI8khi4Gb4FGcho717lk/3wYabQR0ecHYIOFQoZy3+KNUUWI9yn4N741XyuEQBJVzA+MFdSstADHwrqA+Oh0fySJfGxqoYygPsZODReRSpYRo4'
        b'vgzWJYErsBTWxiWGwZoEcJyjfEAFC0tHjkY1DMKl1E6zxscqY1UEMz3gNgElhbWsGjbBa5YBKEEU3DsoPhYeHKWMFVAcR4P9sLQ/6QcVPBeIENoMG1HOxFjYII9FxcMt'
        b'LLgaC1tRZ2Hs0Kjhmfgxweoo9D0eNiahQryGsVPAoUUoAQYAnknyiR8DTsDWqNjYRD6FFJ5iI8GVJSgJbkkAqBzsEYMGqRDWwfp43FJfuAc0zmThYQ/Q4mjJzgkItrrV'
        b'iJzVsDFWGSZE/XGOgedApYEksBpAqQIBu7V/Aup1pVwVJ6D6D2HRIJ22WIbjEi6hIYlPKgY2VawCdWpNrDIuPCwmUUgpKQFsATcj+IrOwcvgDKxTToL1CvQ5jKY84AEG'
        b'XoI3Ui0hKIG/T3E8hlSB25McEo/IHXXRqgyEYckqITWLE8JScAS2EQJRwWZoQ6lrkhLmhcQkjEP1NqoTkhbilMrJgjloILZ342uMK/dtJSzdRiOmydo4m8AmtIlsYpub'
        b'zd3mYZPYPG1Sm5fN29bP5mPrb/O1DbD52fxtAbZAW5BtoG2QbbBtiG2oTWYbZhtuG2EbaQu2jbKNtoXY5LZQm8KmtKlsYbZwW4Qt0jbGFmUbaxtnG581wc6YqWoOMWYa'
        b'MWaKMGaaMGPEjhe43CPGnNWTMXvZGUd3xlyptoxC9zp4ErTGK/viFqASbMEcQwmuELQAG0H1OExD4WqVXJWEaKgak5lPOgtOgToFwV64Y0gcrEO4xybDGorZQEfDzVry'
        b'JTx3tgK0K2MQUo/zA5U0rAiB9ZYAXG5TIrQp5KDjCRWsRtgoBMcYBSwvJB9hPQOfwsOlRMPOwUqwLZYGN8zFhFxBI7g5MB4RGv4GSnPdaHDICJv4b3VDRyDeEoNAobgR'
        b'oD6GBufAtUACC7iA2MVFRZicgeVWigEX6dTHovnqnoQd4Gw8OEbHIBoVUsJ8JgQcAtcsgejjKCSmdsTDWoQiTRiYRrhjBA1OBheRCuH1gfAEQUMaofghVGwjnbByKg/M'
        b'ebhdhHA0H95AiKekKeF4xj9vEalSHgOrFHFwG7yGaC0JNT+akcKNcAvJODEX7MZlwm3TFSEqlG8tEwnawvlWNM0ALYjGQ5hhIyjGQE8DV0CLxQ99GQfOg3LU+Dg6cSyC'
        b'Yyc9F3GlC4Q/TINXQWX8BHAKlyrHpC0GNxlg0yzgx68NPolrTFRSj4spxkpPDwFXCZiTwWFwBonxWiXupGpU7Dk6ZSFssWBxNKB/ZLxy/mI1pjuOEgYx7tEyAgni54eW'
        b'wLoYcJKaBbZSTAkCxSYkn+CFlTMQvwyj4b44VFot/TjYi1qN2bn/clgG69xgkxIXqAiLRT2jFlD+OdwYTyvhCQvBFtiG2g42K7BAiMOj7CZkwLZ+YH8m44L8GN+7qztI'
        b'2bHRTnWHqUZKTQmLqIohVMUSSmLWswtc7vuiKvzTW91h1fq6E4M50zT0Qh321pfpL2TcSa/OvoP+c6/XR+9yi4mi9Vkyz2eWKj2WlE3dXhV6pL5eMjj656zmyRelG9OF'
        b'r/hRbwqku7//Ui4yYx5ZkAmu8nILNiTJYUMs0VMQS7xE+QVzrBw2mrFscHsMHnIVb/C6N6/OsENywAnzaJTEgFCinJCvMhEhVE2X0jMUbOKQNDwON8EbXqQ4uBVeTMVp'
        b'kxC6IipDidz9wFHYjEZ91niiPnkDG19lEqY/UDMLYR+ukWWHoYTXzBh7C9QJClVMLJZkYniegXuyQOVQuNmMGQ8io4YhBBzY6JAPPDjBoUhJOyJIAjbQbtfCeuhF5C3R'
        b'ijq5VRpTHtG3pOgiXi+m8a+Udsd6l48jrZzrZLUmcydrMmYacUIjZopypqtIdI9H0ujrKJlk3kA59K2KPvQtjMWjwI1ATC6wUUhxc01KxA9AS//7a9zjeRRkspj/F/o2'
        b'1xcCRr44jTFh3HlnuPrL9OW3Xnu6+fa7T3+jb/7L+eZN/Z6TZn2YT1PRCwUBpiikMONx8okfHw/3jFGGIG4ZTyOOcJxZB5unmDGlRc0e4YpYy3IdeCUH2/i+ZfoeGItZ'
        b'n+9UhKkN3mI0IAOoLkWYLcjI7XsskNrr7xwGnKUaF4N7myqT/tzHQBAWWwa3LlEQtQrx5hSw3UiDm2MndBsJ2v63wAGWFd0i0qbVPOABziZ0tUNqKEgryMiymDI1Zn2B'
        b'oR69+x43i2MsclztbiQU9iFmSvooKU6hUquxelsPm1hKATbrwTkB3AVuej0EINl/CIibAwpdM36HmTlhlrAdHhUhRkqqnjIRE5sPrGDBDXgJbLk/Ik7GiEhjVETGH/eI'
        b'yFjZExlpqi9uKOieyMGLhzrrJ7zYxjnrf1hu3MtExvW790UMrRdG06bZ6MUby14//vGd9K/Sn9PeSU8F7z4b8Ir3S7dAMkiW334u+cVbzyXffvvp5fC1l3RvL3kxGb72'
        b'zE7G93hmSLYy+8OXkFrdLBknCJfTZtzjmSq9CZyMUatCJgsdQ90PNrPgDA3Py2men3A9eVYP+hCkZWryeQLxJgTC+HkjviVG+CwuZX4vDjLl6LPMaTqjscAYNjW/AKU2'
        b'TQsjmRwsjdMYs02dwrw1+L8LKfUyIxkjBts4xElUmLC3dxGVz5d9EBXWecEm2BaLdfjqBAVSD4kdDTfnwytIANUg0aBGOgS4iNSdOtH8Sci2me4GLw2Al/Wt199jTJg8'
        b'9r91Li87Jzs/+9kj6ky1JkGT+9FR3Z30Y5o7yKB3z/owQUTpzghPvbOJb9ND9p2HS9+4spgB7kKjzJlU0ldfGL2dnYBTbnXphH/30Qk4DSgPEtr7YDk86OgGhhoIrnLg'
        b'qH/K/WmslwPo4airF3bjH6YXdnPqFP3t7/vRJmzWvBXvEa/BqkbMypc03OZ6uWx8/53ar9PFqI9ZKvsd4fq1fnKOuEdGgz2INWDJrVaq1EhX2JKGeXo/cJ4FjfA42GFW'
        b'4VZfpLGFjORzmAruY0JC4lRhoDEJ9UOTIhacDAE1ONOSNHEWPBRsDkY5PMOR7UcUgu5pguA2DtaEI/WjBe4iSk0MuBZFipbHJQSBy+rEuASkyhE1Y+QIwWDYGO6KDi4D'
        b'72kxZOZo9AadNk23luh5JgkZeuFQIR46LPSHObLIkYxBqboIo92OXrRxuBMJcOp9XUgg+aQPJMBpLKB+jYKY1DHFQxHJ18cnIkxAXEBIBRcLkvr5dhswBxZgweTgdMRi'
        b'/O85LUf1JfbF6nzcEd8OdxNr51Iy3YZVwlOm95avzB4/7Bm5kCISUpIMbypUsYhaL1DIvj5Ar1oNLsz0It6gff3+x2ukUDmUSf6Q/j3gyailvBcnZillTeMoMVWomf59'
        b'Sh7/cn2Uz6iRVAy6S18+dng2pf+Lv4I2FWDMWnY5XqPVHNUd1X2VXqipvnBC9wWi9S/SDVmhPsc0qbeawfnmfqF/Efu+cULDHPv4uO6U5oTGT/RF6j+Z1yXD0ydXvUfH'
        b'+Mf5nX0rYsB77O2W+UsGBZxpp1840xn1JvOy8m3hsSwJ4RmS/oPPFE5C7BgLStEKeDLe6e0Qg2a5nClIhNf7ZiMPZC5cjsaUQ1BrFEEt8Wgx0ibxL69butPMb5xAYn/i'
        b'fmVKOYFxZBfS8by2ixv3DQXNJyM4iDMfdmFE7/eBg8Q4rQVPLkXGFFI2EQ4kg+sDkL0Lq1Y+wL9L9/DvMn+OCeEuceuFeBK1Bb8AO3KwJwrd7AM3wqlwuG0DwRXJVDQi'
        b's/dwVHR6gnGR3Td4yQOZ5IVFCMp05eTACZRRgHuhj0snnaYPe3EgY8IK4PGKF1QvRbozkd5VH/1n1PNZI4oWLXvCL+lM1ZL3JMMVS+6Uh7z3wqhnYwy55S/6pkU23ftk'
        b'y0h1wJkPq395O+NTpf+6b6qLRofMve4d2VK16b3QhbVHA5sLo5pKfnmn/MW9qZY5x/52LO3fu2uyF6+5V/tO8k9T38zdP0s7LLJg+PD+N0fGbLwwYfjyDZFuw1+8XCL3'
        b'MMsQONIscLm3YYaMMj3FIeUrkiSavxhsNCnlclibEKqKdfihQ5cNFwrATfBUCjG2hHAv2AzPqcFJM9gFjtgTecJSdiy4lkSU8LGgQ2XXwidoXJzV7JARBjPGmnXGeEUY'
        b'rIY1SnoNPEgJQSOjSp9IDK2SOYiz9mX2wQpwkJh+mybBw2bs4kyDHTpFHPbCJMyFx5DF7QE6GATdEbCdgAEqEvXIGleGysOwbV5DUQGy3HRuJdwOKkh7U7QreQmAKgI1'
        b'cCfYQ0xHbDdehMfADWJtRIATMfHK5BHdrI1LM8m31aGgXaFWxSrl8DwtZyiJmBXPBqXdLLU/sAaFhZaMfD0vGEII9TKTpbQ3IibmnpDxRYTE2ekWU65Q4E5L0C8SGqOc'
        b'5fj1WUWAk1hxyitdxOr9XB/EikkbbBsPKxVoQFtDEpGtW5MgRDbwGQaUItWpjFSVKXShLmxtih3U5cNii8BKB1IlwmqRVVhNVTAlIqvINKpYZGVbKauwjS4RL6YMbhxl'
        b'ptcNpCn8u5QyeKxBerJVjPNZhbiEqZSWxjmNpVZBoUJPlQisglamjZpNrUhczpS4lbjj8q1uFYyxhNTEobsUq7CVbSNltHIkraTEo5pF6TysTBarp6zuB+lGmqZWzzUM'
        b'J7kkCD5JtZtVWEEjiN2rxfiugiY5xSSnuEfOTKvEWFQt4XM4YKUJT1kdga+kXA8EzeZqupoqooybETQCLdNG29vlSEObhVkMSneo2oOkO1TN4FJ7pBKiFBerBSQF+t89'
        b'hZZtFWk5raASWZqzqQoa9a6nVtgqsnq2irUirbiNwW+snsZXtW5WTz+qxNMmsnkgzY7VuqNcYiuLc5VIUbulFbRWnMcY/2WVaj3QOEgN3s63nPF7rQTXZZW20X74G6P1'
        b'LJFamWbaGICgpDGU6F6klVpRen/EkLMYlM7LMNxKW5k8Fn3rr/XC9/b3flpvK3/XzyV/sLYfn5984VAaXJuX1UvrMwH/90Rpplql5Oql7W+VWj1xefibQWT1wl8KZ1g9'
        b'8bOZH1PcBm/UBt88DuUyWr1x27QDiij0lMo/oTzZ6E7seF+g5Z/we9TKflo/9Exp/auYQMraj8DvjWoPqPbENeS6W70dMFhxOyvNtNWrgi6nzR78fySQAtUpd0X5yAw3'
        b'qCLvMkpZN7nH2GUfMamxyyYbkdAKQQltpXOpTcxqJN/ccuxqZac4Lc2gWaVLS5MznUxYRCdt7mltu0/N15vMmQWrCqf9hEtkCI0WD8rM0WXmIXuryyTrSniXlRUY79LK'
        b'zzFcd90LsmTmdYU6WbCpF6ACB6XLHIB64OlhKxbOjImpRkBX0N2AdrhaQolYLPoDJmhUosuvDpiHUJ/jSu96aWRFmnyLToagCgk2yYl8vRtg0q226AyZOpnerFslC9bj'
        b'z6ODTaPv9iMv8K3zFUeu/V1SOnLfdZOtspjMsgyd7K6XTm/O0RlRq1FnoOvn3gTwu/Tou/Twu27BpmVhYWEr0Husr97tp5RlF5gd/TQZ/cklnQK9Qatb2+m+CAM8Bxt5'
        b'6BWq1dTJZRYUruvk8nTrkN2Lai7Q6jrdMtaZdRqjUYM+5BboDZ1Co6kwX2/u5Iy6QqMRW6GdbimoAlKS3KfTLbPAYMZGhLGTRSV1chgVOoWke0ydAgyLqVNssmTwdwLy'
        b'Ab/QmzUZ+bpOWt/Jok+dQhOfgM7rFOtNaWZLIfrImU1mYydXhK/sKlM2yo7B6BSsthSYdXLPPpXPR7kgzTHJiaViBzq+jMe7EcsQBns+GVpK5BpzT8yJ7VLP267DSmg/'
        b'9N6dxW/87PIQycfvuXs+3j7ojTftg/58hT7kmx9Kj6WkN80xQvTfBz1JaXdGgn0VjJi8kTLY4xpAI/l6j0Fl+zJ+qERULkMmTuEFcBJgZ31MImxUK7OWxiHVJY2dlAc3'
        b'dXPVYwwWOgjjY3RB4oqxUq0UEUHZSFyxJZyVNXmuFpqR7or/9Ei87WGxULMyVnYqIiBjCBKANGLyIVYkLAKpVgaxSzaQakNCBwkiDokADosL0xgrl02j8jhUdggSWiwW'
        b'JUhIJCIyxMJBoMXlCbQcKoPFT+g/Eoa4nNVjeRFjXKDlClO0WDQLrCJSl9D+XcDXTsphplLkmbM/c1Op1UIrJu1KuUCNKFmNx5MMajK+qJ13+J1cYJyJh5o16cydrEar'
        b'7RRaCrUas86IvVpycacIY+EqTWGnWKvL0ljyzQh58SutPtNsTHQU2CnWrS3UZZp1WuM8/C4BZxY+AN9cvKA4skGb5ih3CG03jzjGm6CbN21HBTLwGGECaG/0DSOTPTKh'
        b'P9iEtE9+8hzUhOO5wER+6k4hSQOXBHD7Yn0vgwMHPWAcIpX1mnal8MRrlofDsrHSC+wTNT0NIqdmpUWXajzQdA2S9blUoRghGcpoDEKI4Yne0FiOVtAeSC8gkgqhBJJ/'
        b'dDVb7YHva3CwDIcAwdW7I3AkWWKn79LNymAUWtCHsx7jNe5I4vq8g4HgrFhloIoXoopZfE/UpVCE8QyqDIFWQedRCCx0Z0WAlLAGDwKeEOH2CHyH3jA0ZehnZcm7cdVY'
        b'oUFUgNWsaiHGebuqhQBHJQ8tYa2kXJR2TrUQ4SqLlBrOIMT36D15snLGxVj4IBoi5Vg5exkTkbLpg5RNzizIYtbl0UiRpKliDnWWAAtnLXpeL8AxVIgyEFVaaZyPYDit'
        b'RmiGFeJOUZHGSDyWbDZCZcRWjXlrjDMwisXxyNjlpMRCnMddLcF9HeLj4odmk11oK0kjDLIQVbzKNAMjbQTGBoywjJRwNsQdEfcKoJlSzDmRNcBwiI8hm/6uj0iMPbH3'
        b'pExxhCYzU1doNnUJfa0us8CoMXd3zXZVhQR1BgYCtwgROAniIS9y8QuPP8v62U4R7kBEx3yRmc6GujkBmkg75sJYLAmGoDYGMe6BxUH3b4NDt9Dg4vLxvfufkksaJzgi'
        b'e2XjaLuvQMZyI8gcOryUBa7FJ7jlq9WqELmQ8ghj4EHQDmp7OTzF9v+mReiio1IRkqUyhAEIHc6MVHarmHdvIHp0yxKQsEBxBZ3KOd9jZiFCTIIPFcTfBDaKo1KFBDlF'
        b'nf3sIX5z9fm6hAKNVme8//QxceQxqEjEiVymLNj/lxPInJpESj2eFGwCJ0NiEsNiE+dhuz4pIVY1H1YnLQhBjBOUJ8eQgBVQDo+6LY0aqi96dSlDJp0LNx/+Mv2r9C/S'
        b'c7JCP5WTWLnnMnwzc0xbs/Izvkp/JSP11gdPb719vnnTJvroxkn7gquG7SyLYqnIZzyWC9LlAmLGg1PI5N8Nz8F6FQ7LWq2iR/BOiSALBzbOGUhmQSwrwfGumcGxoLXL'
        b'KRHC8LPI5bAGbHTOEWd78v5gPEVMg0Zi78+PXKNQcbCya5IYVMLLseZZOPvO/FhQt8YZ2QMOJJGApFh4ge8PUItrD4e1CbAJ1iMoQA1sQqwbaRywxRO2DfOzz5Q8gEsg'
        b'a0Bv0JvT0lwcytQG9xwp0mzc6eKgXigS5sjgnIkx6fKzOoX55OsfzMQgIluN7wsddRux2zQbUwn2MFBlVJlPS2+Hwh+BcH90ncajK4soAItOYZbQibLcn59l642yIjUf'
        b'WNa8CJTZ47Ae80fjBZtZSgqOsd7FmRbMdgdq4WE8URo+Lwa2rEmJ6QrZQghu96FdmE9Ry0NEcOt0uNEShjLFk3g6kiskBOFgjArWgvaUkLhE2KQMi1XFJSIZ6OUGm9SP'
        b'gcaFJBwM7IVn/RaoFsXAejlKdigsAWWw0xBKPRZsF44ER+Fu/V/XV9ImLGrKsrd+mf58xlHdUc2SWzvB5eaOnacr5VXtG2fsaWvpqOmoaF/CPZct7MgLmLzkxYDaf5Za'
        b'twcJI89Yn/7EzSSaJTJFvcFsl26vqn9askdPfXbZ5+Spk4iS8Ih6wH3gMqzDuFkJKxMFFDeEBgcyE3j6aAQ7QYsiCFb28KlxK8GFLBJlkQYrVrvQYWg+PNtFiF5RxPeX'
        b'swo+qQhTxagYSggOLgJ1TMRjsJpMtIyGF8fGh8UlKmNBg9NRKaAWgOvBjwtSwX5Y5phye3hV0DPTqEPqZ9qqAq0lX0dIxtdOMsLVWIRigSomJkPx0N542y23gz4xPSAi'
        b'woKti3gE95c1DE9BJicZGdHF4EpGfpv7IKMHgdOLlpz+7tkOWnIon5iixFluj0hRvfRCXInTGeCkKKmaD7g7jkatzRHaGAuOudDUJHDDMgZnBM1gl52qUuB+ePCPyYoG'
        b'ewhZwfIJCB/+mKzgOXABkdZj2mV/HLug7RZEIac76aye3hTx1HzNqgytZloVbfdLcJRlMYbjkAnYTE6Qu/N3uDkenIxJBI1O1IXbuk08s2N8TGDLfB94EiLCAyfgxn6g'
        b'FF4EJ0n3rZ4BWuwe+npYp4Rt6+3yZz4bCQ+qujVKQLmEJhDGyav5DB5uJ+Nkiazn0DCzZJg5MrTsem6By31fsh5X5bRBXBnnFNwHl8HuafF4cjGMjyZYEKPAQYYLEc2r'
        b'5LAxIXahYyTj4H5EvqBV5w6fgjvgBTKdsj0OR/57r5dEp0suSXMpC3YAPe4d2K1IPtAaKRB8hArq7JNqmlq1wS1g5lg+Qv8Q2L86HjEqeHkuGoPEeSGwZjHPNec5EWkh'
        b'QiPYIYKnQ8EN/RPRoYxJj7Je+8eC4/O/IKFuz2eFfRyqSdDkE21DOf+r9JczXsh4JSNWs1n7XMZJ3Z3oj9+KqKilFiqYhVEVKbaof353NmLrmYVfRI0plSXvOVQxZw89'
        b'crH0zXeebn7+taevV3Y0RSL1xJNa2+D/pSXXHhM3Fuwf2kdM3FXYQWLiwKaVhHfmLIbbXHknrJ1icLBOsHca0XSS4OWV3Rkk2DmQ8EjMIKPnEz5Nl4B6osUoYSWeZOQV'
        b'HU94lg0AmyeQmRGZFthwOCI/+Z0erQhDuq3PehbWF/mQBPAQ3OLvSJEUK4DH4FXKYwIDG4JnkVl5uBdcLbaHlYCt4GT3wJIMeOTRObUUB4ukFRoLzMTwJ6x6iJ1VUxsY'
        b'H2L9YBMdMWyuFM+EEGtnXG8uqVury7TzyC77oXvpPPELeMOky5J70DyofbrU05mBsPMidGnCrCLIzs4RQ/+2j4mWlRhxzxXBNicL2Zv3yFwER9BvngQ7BHPglWhwIRi0'
        b'y6nhcJtvLiwFN/IxPApJAPeDDxX9bf9At7eYi5HP57xGkWlz39AWunCgzouKTh/zgdGrRMe/Vsq/9zpqCudn05fMXn2O0gsXt3Cmg+jbCatbcMIUaXm0r/Xcta9E9QPc'
        b'RN8xf3+aTf+ufHX8sEWvHdp8eeTUga9SNSJLzVu/Pr784AS3k+n5d5oqMoLfTAYeGb9MzrthGr/8pZGn3qroV52Uq3pmVfSPp1Kt5yeZNtQ/5Xk98+dnPnnG3DYn/PbM'
        b'um8kU348t/9/Qhf1/5+LQfrZtik1m5q/vS3aEiTN6D/xzWd0s7a8Mji46M3le9sXxJb9+E7hL/SIr5Xa7xbLPfkVMufhvoIuFR9eyOlS8UH9EmIFpMKt8DI/JyiUdtNg'
        b'9sBthFphM9y+vDsdhjMjYSVPiIgObGbs1DbPGsZbCk51vxoNGBrBIaCK59vjtcIVoA6eN+OQwGJ4MwApPVFudrWHiUBkSwjJAjdF9xxxAWpKDTVwHAfqxkQQ48Kw0tfV'
        b'trifYQEOe/dtWyyFe8wjUDlzihfaWRHKCa+Daj63iBoAy1h4HuwHF3j6L98g5qNpYhKXDORjXaQL2RBkaJ0lllC4Xwy/KoGPyT40DGxl1gYGkk4GleD6HKcdlQAPdBlS'
        b'E+LtQzUQbnIRdlODXWTdVV8zFjzh64bAugSaoieispHyCcu09yFKt0e1/AVOnuPhwipcpmGRbrjeoRu6E58hdre4MxxiPkIvjvZlvBk/unjwH7Kebtqi0P6ui8GIHgZW'
        b'xriW6maArUGXJ1w1x0FVfWiOfwwYqppMM7in2V+kpXVK0tJWWzT5/DQTMfOIkkrq6/TEq740JlOmDrFQuxX5J3wu7XSnm70kVAppjgFddLTdjEVaAcOI/GhGMpy24LV0'
        b'6+BBuLtPdQtuBDsI6k0GN4SgJaO3r8IxW23C1Orwx+hYLa8mUSSKlNGylW7Y/0J8LAIS0ypw+liSNWbUgQbUeepMrkfJTqs1Gl3sWrbd4ZslsqtfXLUIqV8CpH5xRP0S'
        b'EJWLW4/q6bq/n/rVW8sWqMn0RHowuEJ07KLppFOcKvbAEXKGxH6NhRf0XQuMED97SoskOazhqKDZXAyoXsCHCe4A10CNa7osUKMIjRFSQSZu4cRF+jLDPylTLEpZax79'
        b'ZfrSW83Y0Iy5WNlR0VFxpUVPLxDFi/JE78/8NHVj0Mbhn0u3+x4eM1fm+U9d5ITaQVFvRzwT9U4EF3WQisz2oFTN3rJlOjlHeAsDd4xSsDN6G5F18AqxECOBLRUxy/AI'
        b'J7NEzLWesJblg5BWUgfawCnE5UANv/zKR8ciZXprmBl77MCewlQ7Z4IH4B6eOzFri2Y4FJKHoTvXOOYshAJp2NbrZjtSG9yVvhLEF1jsguX+XTywF9aEOXPyFCPsZDPz'
        b'TZ3iLEs+obNOrhCl7RSaNcZsnfmBqgdnLMX3ZfhSji8VTqawgRBXN/0j4O0+2MIfwShn1Nj1jRmDcR2+FBP+SKh1lc6cU6Al1RifcHRP7zldqxOg9ehyhLYbXGKKYYbQ'
        b'FkyHtI+L7tModi7aQ2LlIlm4N0UmBEeQbVdGTIWhS+1LNYvW6galDKV6zbd0J8NuMy5OMqRI6OKfWIiGYXda1E4yDOQ9noEh4KYJqQnnPVZbkAlXDS/BDnMRvOBRBBq8'
        b'CiWj4BWk3lOPwcMCeGYK3GjBRpoFnAZtKE9Ngho2KNQLie3rg1gauqtJUjlWGSNluloZBjrmE5fpeXDVHd5E2P3AZdEsifB4tHjNPt28ffIezDNgazSoU4CjCc4hxBb9'
        b'Zbg7hYV1T8BzhP2A43hh2ZbZmAj5hsJtCtAeQlNBYBNnXL5Kz3y+jjbhGT2D+BUmdUBtR7/SCMkzfx8asrM88/CJD2s3XvNNaP74PfD3rZe3qH32r5CMnFb7yea/+dW9'
        b'vt1/wl9fbjl59dvOiVXvfhFRPbixMfP3Z6/4GHJ+kQuIojVtxAZF2Io4OV74hXjHCSYKPDmGfMkCFSJFDJND+A03gQanisBuwlRGIut0M/EuwFoVxslp4BJFeYEyNnfF'
        b'Uj6S7AbYMxylqAUVyKZqwusNuUk06EBG3BbiONPnLY7n16MgdaraHiWmgucfuCDIQ1NYqEMkiFkBYTB+TgYjmccRt5SYrA7ifikORWwiLV+fqTOYdGlZxoJVaVl6VwvH'
        b'pShHvYRR/IGDl+ZTEKKtQpdXu3MR7zN9WDF4mhdsha2T45NUWM3khzlnvkINGpKIKwD950V1T8vF0Uc14TFkGLRgn/eqaaCWzLWAalAfCKrdFLiDo8YzlADuo8H56et4'
        b'3KuNRwLiHOxYA0+B8iJ4frVEXLhaspqj/Kaw2W7JFhzTjTTYytUmpD13uHkWebpLxfDsGkykq42wXECN9OFKssFlsrAQ0WfNnHgkgvjRFM9BsJ5hwMa4dMtj+PN2E9Lj'
        b'j8MtiK5rEkLjlPA0Mq+Owa1rlCHYy5DgWDWzQGxfDE5T4CA45zFrLeiwYIKkw2O7cnfPCZoG9c68Pd8dVvWHF4ni4wmP4yjIwtWgaQ28CC8hTmNGyvIleAZessAycBI1'
        b'ZgEHysD+x/nO2eM+jEC7AxzDZju2gOoSRJQX3MTOBxVxZO2sFBXWq8w1sEPiDkv7C6mRsRyoLTES5ZgEyYqHIHw/lwZ2IrycQk2BT4GtvOd8K6jIgltS4PUkVSzcDk7H'
        b'xIooyWMM3JdqIp5zcGXGEx7RsFKFl0PGL+Zb3cXxsH8Ps7YVsEwErsMtGguOJoQ3Z4LSBXpwDrHdkdTIHLCPiIBCjRvljSRAYWqJUuphX8KvTBSR1fre/pkJexNHIzWZ'
        b'vFakMERcpE9bk//hbBGf9t9ufFoZtTq/jltFEe/ReGsuNvEUc6ZiD1INcRn1CWMBKBWXgJpQ/dK/5rGmaEQd/85uTEx+TA0jAn6bNkW9ZbxqelVcgrKQGuXnF2qgfDLS'
        b'f3kzbs6xrbPLb68Uz3/5mX5nLq2k5p66Rb/b79kPTZvnbvvXTzeu/+exnydVTbpe3uD/YfNrT9Ket91MHx3ceCtvkGD5kPefk/sEjXrJe/sL5XWWhsUZguNrR8XO/2Fz'
        b'wPkbc5rerAg5HPT+D+9m3n6l8T9BT009fcPtiYLcxMuVrzfsuHvhs/O7g/IPcdlvf7to8OvPeex4vfFZxeWmK5654uKn/nnib6WfplcKFoVfujYg7YOTSU/sNiyqunLp'
        b'pRjV325V1BjKZB8vjH0qySj81y/9fwFXPzk5YsfPzZPHxykm/NNtWp3XX0Z0fvbrq9aTgpvb3T//eVdUxIRFufOGNVz55ZKfuZAL+1/v1wQb3vzqdNtbXkPbfvryevKv'
        b'G0fmfv3eb6oNX7gdjL2T/FHU4XMbDKMskz/9q9yL8Fx4AZQtj8dbXtQpEcu4PBE7jzzgWZYBzSoz1rLAMXBuJGIxU+AWmmKK6Bmp4EmiHsJji+YoYpSg9AknJ8+AdWZM'
        b'1eDabHgkPiE0DLGXvZPwZ498BhkRJ2VENwwPAIjPK9VkhHHs/elRsI4p8VbzIDVO1SqSMDR4BbOtKF6EAHoKL9w/Bg8QLg8botPincsOUaI9mM0HBJK6Rw9NUSBN4CKs'
        b'jlXGElkioLymslmmAN6iroEHIuLxJCmiCblKvRLYkL7jn8BFLxYSi3rGMrBHC6474qL5oOgpkaRiFmwJJJsbgBoBrBNRnAov3NyrJR2VgYpSxCWGmpGxzA2jwV5vcIg4'
        b'AkHpADd7cZgLo+wRgxBO+4OLXMyceFIp4rXg0gzQoQhzkZj9PQjEw0HTqK7w6Uyw06Gow31DHuTWezjr1tUSH9CncCMicTm6MDQvFLm5OFBMQgQjsswZd3dvxgfZ5uiO'
        b'8Wa96QDGESQhIctq3elB9yQk4IvhQ8z+I/HwZjiR5C4JFLvHCSS/Gzc6ZHI784gGukscIy7kdg8l/Gof4jMKI8NxUA9vdJOfRHoCGzzVTYIKqJVmMdgGr06Vs7zcOg03'
        b'YSTGHi4BxSWAfXiGDpTDm3wY91nLaFinBtfngpMJ/AoTD3CBgYdgOzjOL3GvWTZfoYLnQK1aFSpEA97KROUkZbI99D8/hw6IfZa9No+gnNtH0N02kGBsA7L8nLMPgoea'
        b'faiUsx+NROPsLnP5ma/L1pvMOqNJZs7R9dzXKMy9W9pYs0xvkhl1qy16o04rMxfIsKsXZURv8e41eB2srABHjWbosgqMOpnGsE5msmTwvo9uRWVqDDgqVL+qsMBo1mnD'
        b'ZIv1yPKxmGUkHFWvldkRlEDlKBt9MK9DIHQryagzmY167GnuAe1kEnIjwwbgZBneuwnf4ehUXKS9eNTCPrLk6dbhCFI+l/2hR0atrAj1GYKpzwIsJvSRz+5MP2dm7KwF'
        b'5ItMrzXJQlJ0+nyDLmeVzqiKnW2Sdy/H3tuO4FmNDLfRkI0jZzUyHFeMwXGUFSZTF6COKyxEdeFA1F4l6bNILr5D0VhlaDBAaKzQ2JgyjfpCc6+G9HKTSKmepoqHmiwF'
        b'hQ25YNeCcMcE4fzFMUgHXRATJ5g/aVIyMkfk7vDKuklgW/TwSQOwz/eoJBCR2eledODtqGB+dzqg7JRAOymBsXlleT/izFuvkAXMU3pvfqJSo3SE1fSOFewdP2H3Rjmn'
        b'Af+rVdK91+4J7Iu+ce/oB22+KDDhGJF3k1d/ma7KitVEFkuy7qR/nr4q6yvq7Azt5FlRmUELAmdtyhGNiLm+ZVzTlYpxg2PWRFgiSmfvClwRkHE77+m7uQEjA28Vt+wK'
        b'jA+sMwcG3hpVfts/Qsmdyw9w/9fkJf4RYdp07Z10YYv3S7dapFSlYPCGLIGcIZLRRwrOKlQhMSoGbgZnEDvbxahAAzhKPoJLSEZ3KGAj1rCDpJyFRlJwD9z76HNTgrQ1'
        b'Rk1hjykpJI2COToAyREh4037IkbvQ8KTi+VGO/tyCbezI7rLG1yifXcBPsi1S/Q8ALB2ms9A5A4SytRwBJlpkFPuUGV+H/QheXBAmMT6mMJBFKjHznEpPVZGd8mjOT7y'
        b'8DikE8wFR730HqoHBJqxxP3y6Gvje2GdgOrLAyFSW3BQQwzYCZ6Mihg7ZnzkuChwCZwxm41Fqy0mYhqdh2eRYdMBL8BzXmLJOmQUSd08PUATNiwZZJ7BS27w5Gx+pd/b'
        b'o+PxampxxIDtgxlfCW8rbJkVQzUjYyNiQI3/WOlwO44n31nAEB3km6UfDni2rV9phDd369qru1Mo8casO5RHWJTY986GAbNfiJkcfHRvonlP4fbkgxEv1mb+/fbtWWWx'
        b'm5V/+3bKrWcy3xpbFb//kOKTDYsCEkaP9VmTkKrP/8D7H17Hn/Odlqu2o3M0vAHO8iqmomu5mSaLaJjwzGhwg3ghDsNSFy9EifaPgk8eHE5mLDCnZWCD2zGt4MDuKA5h'
        b'tC/BaRyOX6x8KLy2F+eY/nDGb/9xoBlJ0YXVeOOKiJ5Y7fNKH1iNw83hPlgOK7ohNo/WPsl9IzasDQc1SWPGs1QRqPMOG5lNxv8/a+3+RmFtWPmqIRQxTIPVEQi3NsMt'
        b'CBnCqDA0ICTtN9N5uzJi7jsLgwfRPAJtL+F3NYyYqx2eP9OLRyDyJX2qmNixEePL5nxPrbcvTfaP45Fw3Cpl8vy5/Mv3SrwpGUVNjPD7VO+2ejrFbypWmQqPL1gD98IG'
        b'uHXhuAhYy1HC+TQ4AQ4WkVwp04Kosbgo6YeeHcoRfFH1zBm6FAkJWfCna3aumcLvPDIEbvVcAHAxsEFAsTNmpdPT4MFCyzjcjzdn6br8dgtjkJGxMz8EVivjsHcSWy8k'
        b'uAI2KbAtAGoU7vJpE8gccmWgUL2DmYg3xJS8t2TU5KcpssJ749xRYvFSKuJw8JXVbw9eO6Ew+ZXxXy+MoUnPeknABXANXoXnkKRJpBINAwnU0+MmU2bclEnTLCmJ0/im'
        b'qPOnU5UUFUIF1xnftUj4Rr+3YjplRTZJhJ41VDyWyqdcuERJpzOU9y1LlWlnxlvT+JXhAW/T51kq5rVZewt2Sn8t4DcPFM+ltzJUdOGalrydT3w9nM8+bwCNEU8mqS0J'
        b'SFaYyMujVgv1LfpfmFtXtMTjGwGPLT4p9FGGijkzbnS+ISmQr71uTjMdwlIRrYrG7J39N8rJy+rxS6nLWJdwKy9+d3TGRPKybfYIOoGhJr6maSxZYvHna09eM4RCfC7k'
        b'zOPV1iWzAovJy22jEuhW1CLvZZvzdk6NTCMv81P8aSV6eWb9dunN4aP52uVpr9GtLFV4ZvFnot0RfvxLv9jbVDVNyc6Mjc45GhvEv5yosVI/oYoi4h9f378onH9ZbPyA'
        b'ukyj2hNs0xTD7SkXTJZQAThl0VWfF73T+ZcwsZAqRaPWvOGnjK3h9dP17gcW06Zd6I352M2FybGNb0Z7v3Ti5aJww8bbDbt17+5Yxz6+Mnqot8jQJnx+fvz5Td5Hv9De'
        b'Guc/NunMpMLZ34v+/vTAy99SZ+srK+Neea7aPVuXpeycmvrzC+NFBe1H/v6/S6d/4/+b8bPW1umfDms/nPbvsZIThb9/CxcoJ09TZdCL39APu+670j11xsBVr4tmjlfn'
        b'p/9zhGjb2U3lfikjItf9/uXWJQmRp/WJe+O+6A/yvT9LeXrtj7F7K6a1pw5aYo77InjF1CW/H8k7vakg5Hbt1m/TD/wU9EbRx59u7Awbs/xJn4v7Pyr/+/5W33u5sy6f'
        b'UW84FTqz4/DeYwfTCqSfzfPMOvj0xzGjOlY+8f5ReGmnl9T/8e1Lv/oB/OfzjdLP2nP3zBnxt9iky5Uv7pWG5S6fUTXu1IG/CN8p/OijwRMK+z97uer9yxXXxjz/2OnC'
        b'tPG/RF9de8dzyI1jmT9v2/9Xf/eWCf9Oinn8Vf0G7Z1VP/7uv2Dy/DXvrX6OG+px1f/8Z2t8P5v4+U/yG+ZhTZ3Zz3/36aU10/J+CLx0Tv7khpZJn0Dm/KEauWZb/oof'
        b'z76xLK74u7teMR/VvhnoJhcTkz9MENrlY9gwE3sZwBVQSlwr0eApvQJWhyN7G7TRyBAtSwYXxxLfiTYCbkIiCdTHqeJVoWoBJREy8MZwWMHPul0GzRMHYx862W/OIZkm'
        b'hfAemz3rBiKOkRQLTiC2pQXn85nhuijiZFgMT4BWeE6jCJPH8dufCigvWMoWwD0jiVfGG5wGdQp/WOHwzDjdMuDiYBIUNQq2zOEjkcARcCmkeyRSETz6qPEB3o8+s/3Q'
        b'eqTYIS+JsM1xEbaSYRztx3hLGXfHim+pfQ8HvCYiAP360IOQ7BvEcGTfHXe8xo32Yf2QgHanmd8ZRvw7x3IkMgo7P5jfJaw7yssRJwh3rzjo/sKb10IFZAlLp8huWnYK'
        b'iL3oIrX/+9WASNNtwvdkrUyzU9g3oMvgnsI+9KP7qLD9kd63uQ9Z303Sg+0qXogJKGADSPG7Hg1biW8daQql8ACZwcJxMkco3v+rdjpMwsF5AcLKXaCGd6kcTAFbumbt'
        b'SHDqnGnesIodMi+DMMPnCxjqVjYWd+kSN9NinkN6hnHUyJR+iKbSleneQ/iXb5uEFOc/EEmX9PyfFmVR+gvT7tAkzkry/t5x9YnS8mjJ3GXCjRrqO1Hm9VL/b0PC3jqj'
        b'n0hdTvFvjJ1y6bXdqZFhK19fX/LbM14/MpX00BCT+t3CF7abwi7/szb7g283L77+dV7cc1NX3BoY85jx7a+fkZ/cLJjYsuRx//ePr3wmdmDCD2u8p38tCNm767j//FEe'
        b'32kveReyBbMv2J68/NGv8YJrs+91RHWWrQg99OnP77yteuO9xMbgibf2H7hHffdJuKkwzR7PKAM3QI1HaLftioVBXRsW70glfGaIHGyCdelzcTiSw2VJw/OkCK0cXgB1'
        b'UlelDAc0JuA5wn1cwQzEjogD8yw40i0RYg5rDT6hLDgKtkSSPSCiImNxAjx64MY4+/6w4BQ7O8uL6MwsqKJAXbgKMYetc2BtglxIeQ1i0+BVhsRDgR3SGeB4OKhLQroN'
        b'1nOcm6ENBJs48CQ46+8wFv3+n7OFh2YaDsolTEPpwjS4QWKaYUbRkrkkHJJfAsvgWCW8u5AUM4pfjJudpeEVt/L+/9eAb3LSNa5Z1JOux/+nD7rGQ7USRwE46BpcXati'
        b'KK/xbBYHtvU5Q41/TBK6K7hHS6eyWiaV07KpAi2XKkR/IvQnzqZS3dB/963sVk4raOA3kcMRApxWqBWRRVYeOolWrHWrpLTuWo8GJtUTPUvIsyd5lqJnKXn2Is9e6Nmb'
        b'PPcjz96oROIbRWX6aPtXilP7OWujnbX5ageQ2nzQNzH+1fo14A3l8O6K/toA8q1/H98CtUHkm6/9eaB2EKphgP1psHYIevLTcmQh59BOaQLP1BM1Bk22zviRqKdvFfv/'
        b'uqeRkSiPbokelENvwo4+4m3VrjNoVumxz3WdTKPVYm+gUbeqoEjn4lzsXjjKhBJhJ7/decl7Dp1OSZIjTJacr9OYdDJDgRk7XDVmkthiwjvbd/MjmnASmc6AvYxaWcY6'
        b'mX1lcZjdNazJNOuLNGZccGGBgXiKdbhGQ/667u7FhSbe44yq0hhdnKTElbxGs468LdIZ9Vl69BY30qxDjUZl6jSZOffx/9p7wV5rGOlMs1FjMGXpsLtaqzFrMJD5+lV6'
        b'M9+hqJndG2jIKjCuIvs5ytbk6DNzevq7LQY9KhxBotfqDGZ91jp7TyFZ362gu4NzzOZC0+TwcE2hPiy3oMCgN4VpdeH2jeHvjnJ8zkKDmaHJzOudJiwzW6/GW1IUIoxZ'
        b'U2DU3t8tNJWyrz8kC7qyBI+4AjFbzt6t6u1+NujNek2+vliHxrUXUhpMZo0hs+cEAf6xu8AdUPNecPSgzzagPpyRHOv81Nvl/RD7mArVZOYbbkuHzfdZpwKfhGUuS8Ae'
        b'AzvAKRK0EJUELjnUEayLhMQow8IC4GbYFB5HU+PBDuET4uX2vc5ng92gEm8hnaTCSyUakmjKB+xh4QkhLANXh+sVAjFrwovx1/1DideIhWTgq/LTL9Jj7IscwvxCNHEa'
        b'5lygf8SaiHDt8ltnm9u2XKmQ112ouFIRWaequrIj5IP2iuB9j+GllucE1BOX+u0OzUbGA14VD47AZtDqKpJhY5Cr6AZbS/jFYtstoNkhmWE5uOwimicFE9G9Ah5I80Bt'
        b'ljtOPJg5jBoAbJxYGc3bFHvhcR8FbIwZy1EsvEbDy3CjAV6FT/LzqaVgM95FjXQF9pM1M0a4G5ThyWTe6GgF21JhXbxKRI2BjXh76/j+sIbUDK+A03Gk5DHjWEpUTKNB'
        b'Ow93IeumhS97O7iANweETaBqCKxOTBBSSCOk4RXUfsfCgYeYEcRRtD1ieoim70t2zUTC2Y8u9u+Owt2XarbzwcPGHRT1wKUJ7QyfrPtazVrG4bEuc/z6ft9HZOD9wLj/'
        b'UioMn5XKpYjUoTFLcHOYE7p2mgej+7IqowVdWhj7hrRCqleljlVXdwPvOy+GqmG1BZmPApY4zW7QGPfcB6Y9CB7jXnRz19dlbswxxRb2aJVhrqvXmu5b2X5nZUpcmUO1'
        b'62MqLjNfj7i5yoSYuvyRgPBI060t1BuJwLgvHAeccIzAcHTlwBKpZ8d3r97B5cl2kYTL2zfGtQlcuPyf3Ki8235DrvwVe6YjQQ1oWAAb4A6wjcMb41OgCRF9B4lXchcg'
        b'ff04TWWBBqqEKkHsopXElY2FdfNgXSzR7KMYUMYhZlHHxEUx+qDAMbRpGUqyb0jq4LrnPUsjJNyavYUH6aAnq8QH3/zw+ocfjdmjjlz375zzmc8f/Oijl6VVb0Q8t//g'
        b'62ePlGXuCt037ig8+l3Ttos/TX6t/QeVaHDtjcNPL33jxR9m7NgT8o3IOypQtvczuTthnINk4Che1XE/kwdegIcIbwLHwPY47GnFJ2LkgdM40OQag9pd7k9mCEwiuNEe'
        b'g7JyhmM7ugawk9hcYA+sWoTMMtlgPjxATYMzYHcoz04PzZiH3TOLslwDGPfAcvI1Ch6KI7Bhbjcy187v+sFmwkv1YNe8eNj4OGwNx4eZcONpcD21kI+pgTtn8Lum6+BV'
        b'55r4K3Azv2B+Urpjr8thg8hul0wBaIghfhsBEgpbyGb7MQ4u7gMr8RiycCO4vKDbLnoPw3AR9ekMmcZ1hWbCdYnR0cV15e5kNyDec0Km6XoxPXtu14UbD7c9pn3H4i7e'
        b'i/fHPNQH7333YXivHYz/M80qp0/NalaOxpCt4wMuHLqQgw300LOQuvSwKpZBt+ZhNSvc3N6rTjm1XfUBJ2EF3pepJiEGbO6h/pTlZ+t/S7cwJrwdyD/EPw94aZgfiPCd'
        b'/deWX9N2ufs97XN1u7t6YWIKd5h549hwIZ0/7D09vPLZe6P9ngv9x6jwrduS512Z1Zw95adrX3+wswT6PzPY7e+D5k79uPp/fxz53YRLvsZ3pDvcI/9Tc33UfllaBqj8'
        b'yML8dNBv+cuD5W6EPuYOSsPqBDgKLtuVFQPcNYPQs7QAHAZ1SXhtq9gDHFOG0JQUNrC6JfAUv1jqANg2lVCBj7SLDggNGAeQwkeAHU9gF4Yv3AlraYoLp8E51VJySALY'
        b'CirANbxXFT6MAzSEY9URKTMHeN0xArYKJxWB6yT+uQB0wJYUuJFXiYg+hJCMsJwmWL6hS5OCF0E9olNQBq4MIixnBaq4qUtdKohCCtOuILidOFiSPZROvoG5Bqr9OuIc'
        b'CeDio9OvVybBwTQHwvShPLlPlpLor0H3gpjiIT0op0d2vuSW+5KtcZeTXo+iy5k+6PXlPuj1AbXK2U5hToHJrNd2uiGKMBuwPtAp5PWC+y8kIjTNORcRCZyLiAQPu4jo'
        b'o5l0D0sf/8zQarGlhOnQRcHgrUyneL8vMfMN4Uk5Bt3HznawhAyNIa83QTt5gL3dfM5k/hFlDom3GJCNqoqd3UdokUuYkiMntshxtm5hSfK+4DXqzBajwTRZlp5itOjS'
        b'cXQRv1mCVilLn6vJN/HvNPnopXYd0new2mUw/ymexKr1ry+M5Ux4pzLJB0u/TF9567Wn3336zafPNl/Z3lbRVjGprqOlY/+l7R0bI+vaN7Y1DdtTVjOsqkwg3t0SGFge'
        b'KAms1b0QGOh/MzA6wqd6QWnGHj2V8LLnwtcQ8pD1kUhXqF6I1IM9ds7hwjfgbqQoEFl/dS6L2MITapWTK4B2sIt3a7aA5pT4BDY1FtQkJcLahDDQiH2gDCUH9QJwMh5u'
        b'enTqlGq02jRdhj7TRJRcQpw+3YhTGo/nHkbeKx7cg0S65+RtGyEvLtvx5Ri+HO8uaV1P2OBckhU60xLKPYkuN/qg3Ft9LYv8Q7D+z2gTRzg+3hdtziduMkSeBh4fcSyd'
        b'C5G6OMj+/0emOFvsgiQZ79oy854wYndk6Q2afJlWl6/rHQD48AS6+vZYnkCrLvndn0B3p/8xiToJ9HMq4RXPReIKRKAkHuOaHB4BdZG6nuQJ9k8kanEeEs1XQB04MzDc'
        b'hT4rwSYzXmE8eghsVcQhO6YhPB40dFEo7IDVmEqng0aRjxKefnQi7ce7Xh9Ap6l2Ou2h2IX1ysyXfKoHPRpPO8mvA11e6oP8OvogvwfW9oBziGgb5XIO0UPvC383ow/C'
        b'I1hIKMRgWZWBiA0hnou7ussJnGkxGpGcyF/nYqr/WZw8+ixkTPgkgs7YufioozPNbQQbI13EhfSrvrEx+EUXbNRT7/7L48RvpxE2kpULNh/Q1FNU+MGzrG4D2EqERUgq'
        b'vIl1SFgLrxQ5sHF3CTkIIwEemoNUyHBkknaXFqFChIhXJg0XyUwbehw+1SfqZRZYDGaX4TT1gXrijPugXq/MjtDIwvuKBd63QdDwHLq83xsNpQceAg171fx/gIbY5DLc'
        b'Fw27gqcfGgVlIaFYpdMbZEXjw8aG9sGmHw4l9d808Si59sI9J0q+9nMPpHxolHw/wc4gR3mCnQ6M3GN0YZCzwA4+mPEC3IXPdelijzfBZnBOAZ4kHNILXpDw5yhinJwM'
        b'D3VDy4nAJgTn4E5w7CHw0ht37oPQMteOlkN7IEfPvHy55++PiRfR5ZM+MHFXXxt8PaAyuX/P9diitDRtQWZaWieXZjHmd3ria5pjtqbTw7mARq817saZWvHlAL7gIAPi'
        b'Eu4UFxoLCnVG87pOscOvSqIyOkV232Wnu4v/EHsyiHlENC3C7wm1kYb+6a0gXJyRW9DFgjsshuAox3AeHN31K2Z8acZTSDO409i+//twYg9fWiLxpiVSb1oq9RGTLXxB'
        b'Od4PxRm5AS8kIisZGbkMFULFgzLBBrBxcq+5HUz70Q4E6T61zO+U29nfvhzFPnhkn+67sjlr8Rai2H+aideaGA1YmXNR3tTIBu0+mMZLzo7o4Z+9iS5fMs7l86hLaLJL'
        b'FtwCN4PWrgX08IyjbY6zOuIGL3EXIVlwvZ+F7El5Y9Iye7Q03DHvAQHTfUVLW9b3YoYeDjaCx8u+4IDqfrRs1x7Hf3YZOq6otxdYopazJI5mzmAPCnOJwrRh+Uukm5Qk'
        b'BPX1aCE1aMkIjoSgBryoraXycZzR87qpgs8DrmTfmzNQfiUvOe3Y0KN5V5eUh+xS/2Xi2KUNyr1JJ6ccmrxi8BuhBzJ+U95N3OD56UDPkusLz4RUzhoX95l63YyPhgiD'
        b'3Ad9sGRm6ifTro3aM396Ss3graGDJlunX+TSfA4Vnh6akfa+/rxo+MKD6bqJcXkvuf079jGFp3/OEqOgdPins4vcvzAVFYb4vzfnmEeg59UN95B5sbagTEKiHtJ9ECNz'
        b'eKdV4IrdOw1r+NjPpACGeikJ93m65EaYPbboqWgfKiA3Fr+0mgfbj6k5bvWj3mWX4Ngia3OJF8UvNDsAt4hhXaIqDB8a7NgjDTbFi+AmJTIX29fBmjlgmyCYApWj3GBb'
        b'LGwhhXXO5ajXcgbg6KWEX0cu42u4019EKScMxjUk/DIvmt+3Vzv5Lh45+t1Ail67RD/T/BZNzr8JGHYnuKFDCmWS2a/urEy2eB2Nv9d+M7191qWjI5S61feY38fOTWpb'
        b'ai1e8/be5KqwF4rzvr6sWFM98Ifs/xWAwI+H5qTELv7X3Cpt7E8/ffJz8NKBv710ZTPn5vZWu+LUX986sGzCrt9bB78w5cSOTy/pUy5WNWvWvJiTv3Ln0uxlNTAw8388'
        b'vithtleMyv52tpwj+rgRNq50eKLBwdF2VzQ8k0DikUArvFjkDGkSUT3OYF8KTvDxSIdTHlOo4nBEE+pDAbIAqikPeJUhxHSTXyLangcPKmBtqApe8g+jyfq6SWvBod4h'
        b'7392W2XXzQOMJk03lzduS5dQ46zuxNmN3d3ejIywUnxvfNpRDD7gHQcguOhXfxasdtoInQwMV/BjbyEos93nuDLfRFinCFWD+iRwBlztUmMHgr0c3lZyTC8u5OZgDi5b'
        b'XbpwIedWl3/6vNK+56HcHRzoW7E7FTL1cRxcn7/E58dgwoHMcxEHGgvsQfDbYr7hOZB8/p/jQMmUcZ5YlOf76uDvGfiYZKzvxMuRVWOfLSlKnBi8IaT/lJCFa/8LDpQs'
        b'a+Pj2O/E25fND8hOSFEm8rRuGt6fwjL0THDh8roMH8qIRREfD+7GkTUOrUJjvs07jn95JZdfDfHtqJwE1eNq+1GfO5CCV+NkbhxeMp1ImNtxuE//N72ENq3CXTn2C9WL'
        b'HZ4wQsLdOrLy7Mfj93648GzVYtkHB02rFs8sfdXvu8NtsxTUhJE//cc8ZVj1355KCfyl9Ijws/IJ/zny2YC4S9Ofee11b1Punfr8qydrh/xY8w/DkTlvDPrE/cUDJ478'
        b'Fvz7h/8bVHJq56XpoU8OjpUly2liDw0G56XxjvPkxUng4ApGtwzWdtMmHy1suCdZanVdZDmyG1kiwvQS49MnCEFi0pTwMbq08bazIPAnIHjGSX+4HDFrP7Cli/6oskE/'
        b'3O/UyPZUuNtOgjZYGZvooMB0DrTBwzN6rVLEf2T70RhEmtUC/ngAK91KYcJrY0oYcs9qOXTPmmn8fTa1onw5U8KV4CMEBNWUmSEnIY0rFlkFraxW0EaXCBZThjy8cf+6'
        b'sfwpUeQLPj9KsJQyrFyDiNa4meTGORdaWeNMlELQxp8UJSRHb3iiOoQlomraKsIHDGhFDSi9VTgVn//0GMkrQHlNKG86PugCwS1A8AkIfDivuFdeMcqrNQwleYXkjKeH'
        b'z1daLeTTomfKig/T8OUPUyDnLrVZKa1bIOIs9hN13dWIIet0hXONWH1LuSuwmLNUE414rgfh5l/w2OIPRrwFkRFvqCsXGbMxzrnpDJZVOiM+aGMufhbi7fK1uk7JQoMe'
        b'3xAtlc87k0etrk0vu4olBxmQRVh4F3sj3iqjk8591C2zJPiIG9MYfnFwEGvfnknM8qv2pfbjXtD/exw5/gWvLvPFh7wwrvf8HX86h9iBpvBYIh2PMDNWNT4Ub1mAlwOU'
        b'rKRkQzjYAQ7Dw73CJJz7f2PhbEWcXEsvoPARXWQIGOfxF6QzjZMdDcHbApvuY096kualmQvS8gsM2VNYu56Og++l/NkhIYH+PJCgHLYhoxXW8FsuYr2LGgWqBOsiknsd'
        b'suQMKhtLINXSebRRiI0OLWvFR2PRWq6VwocuIbgFflQbbaX9KSzf8BuCPEJ7KzA0d5ngtWT12ecM3xxBcZY+P1/OdNKGTjrnfk3DLcItI02ciZvmToaOP1tHTPO77Jyd'
        b'DI5g4xy1BzTlTibtSyINFlKjhgjWgVKw/wELlek+Fyo/tDOl90JlZ/EuS0a7lt+Njy2kPhw0B1kM6UJzkIZ/2V9xm6pW9cenPbqJo+z7xWgHIknmO5nDSu6+iQJK//K+'
        b'gQw5iOX5f0m+TF9x6wy7qblty4WK9ooLLX+tGrbo4va2jW0VbfUdMecrLHSm5yz3T2YeVr89szFooyDBI7B24bADg5WDXxoneblenuAT7XOACfmLeExw1VJJyMXSSVW6'
        b'YZkRbHYQFTY/MGZ/E9JW8ZYeliUx/KJmSmiB2/Ca5pR8foOTrdRc+5GHyJ7VOY48hOcmkpncOMSrT5IdTmoSYJMydzCNEhxn4Kn1LNFOh00LAMfjyP4mNXj1D9i3nhlO'
        b'gxOPviC636oC7aQJ/CEiaVp9tr6vmAtqg3iehES68WeW+NHGt5zF1D5MhXWOCknG+L5Eml8frmYLPhLY+jgyb+tgQxLoGEv2McYHOuEzgWvgFViG+4emJoIjwvVIw2y/'
        b'P+PAOwDw7ALLtjae1Bh1p0BjytTrkdr7POWQvSO695EoR7c2X5+1biFrj3mTshYSG3lqAGIMdTFw23q81xsaK3CcQ4ZEFQOvsgX3hwTnxcfmENnnjo+awvCU2KEjjIxR'
        b'G9+miDI+xwHVH+0+5mYx2GFMxTCSY39YHCNDtHJ4RAluKmADiU7AcI70IpD2T2ERytWDykfqtCwHcMZ37tdhbhnjx/LHpGlQScb3MCVg4y1FNTV+TFQsMd8Cp2GVzWsY'
        b'OwVuGvdf9FW2E5zOh+opBBovUrMwaB9g0MhE0Hk53IOBI/6YClhLolzhKTaSndMraM554B/eIExLI5aO9STKOMCMGT5bwSAtgiph+SPArIw/OVDMJLQyhUFWGh/Ixe9Q'
        b'qu4cGRE5JmrsuPETJk6aMXPW7DlzH4+JjYtPSFQnJc+bvyBl4aLFS5am8uyfHPVLNAUaKQX6IkS3cq5TyM96dAoyczRGU6cQ770RNZ6X/+KeLY8azw/KKtZ+Vg9ZZ8af'
        b'2fa7hN+X5jGwMTJ+zHjexF4YTsbIn52cB87ef4wkdiTR8qdQEQT50FE5Ykkf94kiUeP5cVjD2vfmd2d5a6MFninCIJDdmA/BnfxIHGQjBsBd/MlupbAtQqEGO+ckki3S'
        b'8Hk+AFnvZ8xrHuDyZ7q5/P+L7TR6H0ciwPFNJArnKDwfzi+pUuFtTcFJ0E55LWaXTbGS8MY5sCUCGU/wMGihqGXUsqWwVa8I3M+asHL4UuiEL9OX8N77jcNG/6uuoyKy'
        b'qmNHZFXsHj6Ke1mMUPRBuZzhpcg+sH8DPlu7EdaFiyi3KAacSgJts0AdiT6YjGh7F96XqxFvQlRtDIe1iYhX9g9n4Tb41FSHsLiPCqE3FaSZ9at0JrNmVWEfrnYiFlhv'
        b'ofEz51CznWKSo/uBGq62GG2846iB5LOyDm9Hmeuv9F4fsgBTALQhm3MzaRNoCpd627s5FtYjSTHKKNgATz8+t1fAXXdXJ2sPuHNxdNpop6vzYQNee235gnvAqxda9FOT'
        b'xfrwycVwfzyS542jQAOs5yhhEONu1hFNRTfbj1JS4gUiWfqgQXmRPKsEW+FxUBM1JmwS6BgTQQ2nRGoa7DaARp4Crk3JiBqDOPplcHEMuMChz2AHDS6ugIf5Tfhahmfi'
        b'jQ7glSF4rwNwXktqapkeSEVQOcu80tMHrZ8fxitKf5fJqWSqcLQkPX34zuBhlAXz/OABfuAcgyhNhrcMHJnHAzoP730QMlaQnp7wdW4Cn31xCt4qIWedJDpdKZCMQENs'
        b'wVFqallafCw4oRRS3KD1s2hwFpyDW0mGnKXRVCk10UAXps/3sGTwpQxciHcAeE7nFpE+5oPUXP7la7OElITKWSGVpUtWpIkpPfPbj4zpDfTl21dPz1G/HMfOkPy+ueW9'
        b'zxsv+Htd/Oajv176Vlb+7GsVVUMWzVC2xIuGLfwhsOgfb27dHvfTzA9/qdv2Tsja0mDFxr9A8IK4rUZ6GxTmzZH9+rxi0AsXTY0jY/a8+15+VN29X5/bPCr3g6Ng+Xsx'
        b'ayHcO+/QvxtWB98OCPv/2vsS8KjKq+G7zZrJJGQPBAhLMEMSFtlk3wMhGzsC6pjkTkLIZBLuTFjiRMSoMwMCrbIIooIoiogLICAgtve2tbW12lq7jHVprbW4tJ91jxW/'
        b'c8577yQhicX+/b+n//98mSf33vfed1/Oe855z/JY2d9/N2bi00MGvn/HmXfTt19c8IOV//h8SNacPxR8teDrrKG/mZ92+uB3j328cMWIN5RPZhafe2Cv/Jjz6SlvKUff'
        b'eerlstYdOUsfXn7wz6VZ50ff8Okf+z30urP89XPPTWz7pH/Zq9N+ubvNZSYhwcnqoTjouPPjDJ7GtYLHWkFIYS/1lLYNkcZz2ncIcTSwxiyZWckJmVOYRri2o9owPKc9'
        b'WcykhiNLxGLY/Z+ZRwLJhjTyvDiCFCOv007FFav3qEc6qHEwJQ71We1hwmVzLdq54qKr1eOo/C2s5qdq+1dcvne8fwebNL4R9jiPGwDTVWNHjCSQNKULSJLidU1p3NfE'
        b'LNjbzLwEyLFABGgS4K9ZRIiSbjUvfK5ciIEvZuMkaq9uUKo8bnJ22Q7F/hXfdILyLsd1tIaCZd3WPcjL/qQbkJfDIMEp9UDe3PyhsOMBGboVTW1vU0+NGDVC4gbzkrpT'
        b'vWsCLdo1fVaVDMKtfwA3QNuinqky1Cvxr5MgFCqsh3l0cRoBYg39UoaRNDUFJSUtaIJ/CfZzUwaXArHSIU5Q2M+TiLK+eYZFWTTStYrMdzXEEpWRYWk/+hEWDwiQM8PP'
        b'pLIuNHLM3yqid+SI2M4o4CBkmE4uMHU3xDVd3BATctP9pkU+iI8Y+EQW15xd6W0AuobJJnXnO5lhVGLU1NTY6FGUOTj+EhHY5qgU8KwPAKKCWfhrmz1Rm9+DIlMBdAy8'
        b'rlYOrFLex/ii7OnqGBkq+Fd8/iA2ex0d63JQ1G2QIzfFSiYA+vHS15KItg3Jyqv2sF19oBhduJczamcL277Vh9WTXH/tXkk7oT0ysQtqGutZHGJETQl55gB5dhAjD12K'
        b'w5Dvx76GHUoWsa+JzScoI2GYBVmCGGJQRFfs6Hm2RcThpBwK4C25QsfvEBu2RNlECJ+5rC130jVT19d7h+VNJSSz1lczeeXAK67NXXkdXPNc+Dxs6NRrpk4hZP0CVpZx'
        b'v57jiH5EOidq9nsqlKpVUVON0tDUGDUh6wlu3oZ1MDg/oTUaFaGUqKURZc0UX9QEnQkJrEah34T7J6JpSkjtNiI/KeoMJUlEkJFCRhYMJi7+mvCkV1Z3jCITj+rjaDRH'
        b'jZSz86cM7TwZ47RwV7nM6m7/2k54R6eTz/tpMAD3F1I4pAYY9aJMRn0fJQmv+/kDnD89KMhALQQ5N2oCCUp/vNKXgUGgINzwP4u71tZCFBHkJqbDsPDcmsEUe2ws9kQW'
        b'm3zMI0+SV0ooxpxYjLLOMWSmdSSVRXl7m5CdTSMDXUmz9zNaFIGKWi8sFMnj9dTDiHjWerzfsBKjjkbFE0AVVuzw74s6S8EhMgtUieSvN5Gepa9TkFT9uokEXk+Wp+Xl'
        b'zitwETGt3s66nNceWMsNUO835Wrb6ntWIkeP6e0n/QCnuBWiRyLvnBx64Nwhrjavtqywwjv0yonvLB7LaptsMULotRNgHKqQW1fY5YE6wRAnO26xrYiLheNlJ4QdugcK'
        b'KWStNskJciKkie/0rpecBO+csTeSnCynwJuETrFS5TR4l0iq49yKXvKgkFjNk3K4bUWSPJhC/eT+EEqWcyCNGWqQLQ+AcAr5u0gln6JDonGzYWg8vsAMoAE7TUWDK7nI'
        b'gLjt7H3yL83JkvFMqxkIU76FpsCFr+GvjZ8AeDuizod1B3gLYmPdYXG5abGSg3t/Y0WV59cxOCw0Z3Wo2rBLI3ZLWFJdcfdFkh+mLeM9kF9fmHA8gt1ARU13WnFRW6O3'
        b'otbnhs9RowoOoTm1YxViMbqULRhlJ3FMHa/BYixP2sz4ssNC1OTGrYEWRrd6ebhs/mAwixLF5sSOZWPSLsMTK9ZBw4MQIObf7jCvxPOYP999SX82SrILXSifGDPaGxt2'
        b'2gB4xoCmM4/BeMbDnD0HRVmoE5TeMvIuhEnoxBlWz1rOP1w2BUW8wxbA4zkOvLGwVGmcEVfm0e25zlmzlrXxw6P80DZh2HAYMjIQjLVRLDh4/A1tphuGtuT4ce/1N3pr'
        b'A1E7EJpKwL+uFvZV3IcNxS0ybI99E+Ube6JV3QBtYGv2kM38d0V9+AwFMbvQm08UhJvsfHNmp4nYMVVZJ5OhYse+62dMQ+q7ADt0EMjFOywbfZQAWmZiy0z+JsAkEInw'
        b'yYbUIzYhao9N+B4OJJQ+kP5THEyJKp/Ed544mOO/p5JKb6ypBTOs8HqVLL5HhKo/fGpDRhm6Xm9OvrQ6kLpbSEM1QoePYZhIYQmxjzBN69UwAbcKVD/eqB/6rg8arLzD'
        b'fNTk89dXNEJVB8SqamYuEXQHnFGLh9Xj8tS3B0IOF0Vdw9YOZAFiW81JHdvCsu+5c0ewpgixpgixpggdm4JdDY2JccGyedpGOzSkFs00BVz6xJiGl0H85SqiD4aYktSh'
        b'JUldWsLy7zIoMX4VqkCEoaZhEVqSakAEJRFxE+Z7vgVag+ghruOAoE8jUV/XeGTTxk9j+IGkpGPD8NyStS7O7QYUqzbgqXe7jb2ihPvntiuVIahVIemnVHYdCUvkm9M7'
        b'Ldf2zHseqes7TrqMb2ofGyuEsrGRHayPLGyFNLKiPrJSx9iwCUllSg5v4K/ZbPioK9DIdofRhv7wG1U2hjxmH/PyhjwX8ukl6Xsh6xk0mM5sDnTunVhR/8RvKttIhbLF'
        b'rJjutlCr213Z0OB1u/sgmo6sxuaUzoWxz4S8L+40GgYRghwLwvnCsFKCXDVivzzit/tgl3mA38YWvFhWCB3zDy6GMW4AoFzrC0QTEE+XPVXeCia/ijr5gQZ2FG3sDJhM'
        b'ycPepuPvSzjMZsWDnpH6G9OK7Cp9DST2151XDItW2G0jaEplxxoh07SRha0SUUg8E4swcCapauRoH2oNMjdLUZtnfZW3yV+71hONx13NDRQnlur/CMc4Gxro808eOJCO'
        b'eQGy5RNMhh3JC1uE0cQR2LqRePmiaxOVYfBhUDs8wLYBptNp08A6dYIGmDBGl/wcLrV0OoG8AMAFhrOG0SYiwewHav4AHrDzmdw1QoupxRw0BYW1UCVaKaZMdMok+F3s'
        b'uYbH+yT9C8AMM4L2Neagmb2HJ261hFIeUFIC5GdpsULJ5qAFSrMErdi1QUs6BzEnQkxLiy1oU1YGef9iIE6XB23wXZzE+YSgDTEWf0VQ8FfIVPvVkLaW12kYdniOC7TN'
        b'NAixLZct6oCVAYRlrVeG4Y5aAg1uubYqQCIUtD/ADhOAuVUZtWFEXEZ+wjIZBRTHEwOI9h57VYPPz3QOo7yMBy+QaZSvUuyYjVAlM6N4hCJ/wPW4sY6F2Lk4dCj+KhG8'
        b'S6ETViet7yRa42aeOSxENwhImnbegPVGHCaUmBaiSygsdPGFrrRLJZSpKWeNpihSrGXxPKO6kZhmqAEiIbTtU7/QlkPgmSCR4sJLAa/PPWpFB09il80N7OBiDOvysqh3'
        b'hJWzioIE1KAkYLPhySkmOhKlFCnFnGROsVjtTskpZZjYQdGZqVl+9Ku6tbTPRm1r3pp5+WUmLnOaVKiFJi528U14oJLbV9vRrqGl3TmaPOVCEkjgMnNXyubF6ln1kHF2'
        b'c79JO12sbU3MKmJReC7uRkE7kqae6SJUiDCCBKeSYvChFvAYHbQZJjzqK+o8Orai9O8GSln0EZ0j6aRKokBny0uv1x6Cxql7tdZYVezqvYK2Rduv3tOFBjaAl38x14EG'
        b'TiTPiCjzDhQv0JYSUK88M5a2wsTUIKtFndo1o8k0iGORHXI83K2yU064BU2usUPfXlHHrKb6+g16fbtHl2mTwZM2RsLA9st3oDP5djqTMR/gKhIjQpKNI1HFFNtYzbxO'
        b'LcBOiYuLSFA2gT+grnMj8u6LIVO0AM3s3aV0EipMlBuQ0sz3g6UFyym1Y4u+na2cGhpfZSbfww5qA1yFVWWJMbJmvjmtU4GxKD2ja/rRKqEh+qwyHJxQm0u7mVIMC0N4'
        b'5nZfLRm0Id+ccUlrY5F6Ln4KDaXMA01oRsk2whwB4itJYeoIJMyxYjDQAjIGlUzCp9orfEtMJCuHocI0kNRrhDBdwX/jcT1BnpUG+sOAoJO4c92357LxH8LOr4yV1d0I'
        b'Wtxur8fndstGFwKqnXJJkRShZx4C5hPgagxBBYIIEm4wPSFd+A0aYswYazdTlGJcRgtRhqSwx9YRIF+NyN08JOwuLUXH7qawfe+SzYScys7G0ZsT2xyK8FIS2yHYaXDP'
        b'w4oWDkokXb7EytlFq9khJopWm1V0iAS3Acod0271uxByq0cDDMwjFNQi2kGun/q0pO02q6d6BoRoPM0AhDvE1eJqaYXJwyTUkNUneaTVFsDf9FCIr+YJSFpXWBlzDgAj'
        b'A5Q2YrLZaTJbo0nllas9VQGyHKj317fkISEdrjh6gBsE2QI4Lk4cl/SupX17/pGS8E3cow1YWCJ8/PZASCnku+KkOCdaME+UJ27u100DvgnyxHQb0Wlxsy3A6RQYYaTL'
        b'oEUS0KQbejOZYoJBYpCOKVoFM7ecfTdtGKfLHPP7zUT9jYA4lnYK8ADP4hptYiH9TL+dsgN0prcxwaP2IqAS1jPpW4JhuACizumENTYFdLncdnr4cgDbTZI+RwQg5B2A'
        b'/yEWmIYCtV/13HE6NRl36aos7YTTMWRvaudFelkuXzEfX/vSbMfEHGKGSM5f1d3TtbB2XDviLtc2zysdhjKKW0pK17SvUW6G+pBlkHVyz6uzd4fVSUgJHSsCoiIyAjva'
        b'x2i/AZVmomnTkoaGuqbGTueaJn3mJMcWnL5fhY1zDZIQGxQDSyaGx0uBDY0e5T58tMU4c93up2YvlbpNMhT58Gjo6+aB31DDYSxJN7qCi2LL8JJ1Mx8+bJF00RErlyiS'
        b'+yPL2oXa8Vg3q0cYIPRvwG5eo20ryh+mnUT5XW37sAIYmZ1r7NpedcuqLidRMf4ISkbDLs4Rv8NJq4tn9F8QD/bwrCgtjBQgFzYjaRvm6NlksBDbvppJ1lhQ2bmqyR9o'
        b'qK9t9sjZXqBms+l4XsnO9QQUjwctwza0z2FXz1ZpKfoEtFpBFm1QW7q2xtegQBntLNPsCp+cjVQ0GtmokOVa5rEre6hOBeW6hmYzuruzBnWHKnQuosLrbVjnJwM6SgV6'
        b'20IDtb4Cw55Mto60+ztnB5QWHVSKV5eWwCpCojwa16EM4kl8W49zS2Dod0s6oLVbmZ9YFLJnsj53qfsT1C3aE9pTvLpd283x2pOcdkx7SNM9oN6lnZmjboFPGIMTtc0J'
        b'Pn6BFtIe7NmX+nUdlp/cfmZlrjbRaZlthUhSUmbYBPGkzAobpERnY6Jska1IPcg22Q7UgbnDCZl1hYW2SivNFGfUoa+LUiCBlLLCLmZZYnMSVZplIJ7CgLnsE1ukGP8u'
        b'CUgEvhblK7kank4pkKgQlFkxjl3/oKB/AfwzkwPCQkIeQVD0j8MnCkuZkDtyJaAtjAMoBIVZKHJggnQmIw5xKMYb3NzVgmwGck5Cci7G97MgA30hrmDi8aEbUYZEtr8b'
        b'3g5jo3Y3cbLdyGOnnQQxJ5duL4di9yUuYaPiqa5d70bZTdLmiAo+/+VbJn1M0jWTBEFAFtBXdpOVzIYjkmwmZnciSbwk8b352DEYDUo7ydMRXli4DpIiqDZeA+NyP/ay'
        b'gFwiHsIo2wo9OJPxiFA4wJ9JfCOJOD6OgBCUUICA6E9OlrZif+cZHKT9EuoIKRMoBcwvNioAlcytMNqUwyB4bwEoXohx2Bf9PcEm1ANqFdibNQ4URKATJ9g3TIvwFCkq'
        b'zvbJUakMvbObllZ4m7oeMsYwJnbIiBwuWVjLdaRZYLFfQ1zd2N7BdydZS2Y4XzRwdgfXXNC5j6safABfAgSm/B2FUJiVVMiUeMLtHOXRRPMiL5Dgks6g8pMrQ8ayQjwD'
        b'oAxtZKLfsyZqalBkj4I8T3+TN0BERn07I+qbhCKcneunGbPJyjPrtnbejvNKIEP0F+1iFir0CEl24a9ScnOfb2hpl7PIGEO1kOYUrlqYFX1aRMDDSJqItMjScJYRh148'
        b'wMZcCooyv5bHtb5fwLf0zjhjQTIHma6AFXtgzK3uai+Khvio1ww2agX2LU4BRf4neFkNfP+jgf4w675J1AvCTVKX1aMX1e1uS3MLFag76NLBNYgtcQTJaf1+xEjFAygt'
        b'Dt/YycNaXBf4JMLT4ABApqCQBnv0zTzJbgAEO8AT1gsrBtbHlcj/9FmNNxgHz2JlE3uCN9CraZwupMPOXgWg7HCetaUt8dX5Gtb52rfZ7IE5/oFt5hty/Hg0a1ZGYZel'
        b'0fRjsEy5Gt9M53Q012C90Exb0ZXCiMa7fSjvhHa+IYP3sGNRypFpgiXy7EAjDcGUkMQ39+7cvR2TdoFQMfZbNdfx4JNmDmIyiNMI7KkWCBIm0KRr+CEUwhSkqRg0ByWC'
        b'/akBiZ12rYZ9AXnZ9/MLOWMPMIQPzIqX16eJ4sELrUc67QH6HY3nA3Ju6cCQshpcZ2UcBm2Mzwwt6rA8u2cR10P8L4ypiD1lFyWB9Vm/roBcL1osg+Vg65Zk98QqTk2o'
        b'70wSXBbO0k4mLIPUjxg4i5VLkxJTE/tbbWlO0jhZpu0q9MfoAe3JUu32sgLhOhvXL11Sz6pPFXVrih3/yD9nDDVJILrcQEmYnwQDIcEvlyIjSEnoqAgJ6SAbkzFDEqPW'
        b'koaqusJar6dM6QVldEJHOolKzOMYP5cRnX57QJB5WoCMrBboGx2IpiEHE6YWXE3ExzQTT9OCmn5uq06AS2VtyegCOVtu8OgeDhDHbLPk+IehRCAOFwkImGv9GI9WV9RS'
        b'UelHsYSolaQG5VolakHZ+oamQNTkrie/PuRZOWpxYwzAsDvIS0QljKGs7YY+x6kQZ9JnFa5D9HZppp+db+5ldFL33FAEbnajn9ArCBMiRTYg6jDauGZrGJcdgCME08s4'
        b'30hSAp7OA5jiueacICwuWagTlX43YyqzkrsMiG8EYjeSMJqeH18nKVcGoB+x3+GdVZZYfkZcn53d1/Hr8FSOen4Rt8ZKPOTFF3oReKtqaPLK1OMVVeRkIRt76p29e/Dv'
        b'8FSXDYhA6FLqpqipvg46WWnCZ0v5IqLnoyaPogAU2oAvHQubfBhd/+L3ejyNOvyLWmDroaxqe1zOUQkLTzXpwr+oPSuQFi2d25ESDqlm3iR8YbZJvPBRc3xsLDBlz+o3'
        b'TM90NaekUk/g3OWNMVDSYTwkYzw6ifvdQjuniRrHJo2p1h/rApNSj8/EorqUHm7yYYWGmPTVz1zUAJ75lSQ0J8QqzWL9M7yLYZR6hYilHu6JpY42kzwA4/JNBqrFNyd2'
        b'mK/0seduGtqhPJywOg9bYDxsOoqAboppcPNIvN+KdVlndJCyPla1S7WZ3G4AxciZHW4ydG0J9zaTgEaHSurRukhE4/8yTse9aDTjDJ4hdg8TCcXDWL6dsQezbz2NVZW3'
        b'AdBE7DhDQkZye9ZXdcNgBtADa3qsKXYSgiSCo/O6Z3GQaYLLqIfNhHqGhiqCl8142Xo5rN9GiGQxGRx9zik57Y5eyP51WOjgK36S9gjaeirXtq0lBdf7tSNFJi5+tWjX'
        b'Nt3YZd+w6HfS7I1xlFBYXQJiNcZVQhHQFZKcGGJeg8SQOWStNhOH1wb7Ry9G3pLfHzz+ssFewszD4SFYR8J2lSspKhXOn1XYBS7GEBI8pgpwOioBuwagEAIjI40RhDvU'
        b'LSysllD/m8IAFQNmFtL3EE4XkGiLm78BC7wye22Ovy0eAroXdQgaLEpmDwzNoDZW1HiiDr8n4G5UGuSmKiAKHJjavXT2wkVF5WXROPxGFnUBisW53bqjcbebibe70UmN'
        b'gdbFTAt804Bi2dONWZ9GYr0I1JrjsdjuKcyeONa6ZEpbr0VQk+z6Ch+ZEkXDNggYdrXPb2ai5lJcE1sWa8NcqBLxtZuTqCKdPpZ1qo6J68B4vrfD6OHqQ2vsQYExyVYL'
        b'yvAwELb4hFLwQJiKQMwCJtDKZObpuUUENF9M51A8m94CbrDfzGRFCDEFgi8MKKZsahW2OwE1lfZbggLb32SYRhLXKjIhspGcf846njGzl3O6YNktiMijDP1HJPWRk7No'
        b'9vzp2R+hjhsToVyveKrthOFHhXWV+hSJmgFzaGwKUC9GTXJTfaOf6RajrCUdrUZN61DyQWeQMohH/UxJhOpVl69WruzDAx6TLpboJCzDQdPCQTJryNyyfw3Y7EXYMuJo'
        b'fFj1ora5Hu9aT6C2qkLBw0em+4qXKoN5hX+okWMzRux6nhFZB1C0i6cxQ/SeRMBhPER9vVH/0zOQVIDyi/glzAdMQF6aUjgUhkXDHyzch4WtsrnFJlta7IwF0RIHcyGO'
        b'hGYDLQ4gHByZXEt80KZUGvGC8TDSVth3S2RbS7wvgcJ2CK+U41rssbKtWPaaqzrXJegIAu6awdVxig/zlh3pXCbX2AA5OYNOZY8cH3QCUbgn6NTL2BJ0KJvwaEOHKZCX'
        b'7AxaMC9ZbLH5nBQTS9+DX1FEnZWEX1FoRrYETcH4oB0wBttqvMatdsi9tpohN7vyKMaCOpoJDiWVXUB1lQvY84sv4Bi/E0r73c8/W/TJ1EJilrSJkydPpuGKim6AJvxi'
        b'RmTy2VF+RtQys6FJqQVgxBe5hKjJ51nnXs9uG1zxTMPATmLA3lqfx8+AVH2FUlPr80eTMVDRFGgg4OauBNhVF7Xiy+oGH2DDSkOTT2ZHL9/FmSpVebzeqHT1/AZ/VCqZ'
        b'Xbg4Ki2n57LZVy92JbDZTRIEEmUgkXKPyR/YANh0HFbAvcpTW7MKsma1sWMEtxeq49GfgRSGIkyKB2oRNVcy5ovN11TvphRMXFnCZ3jrWR+g1//Ug3ccE0Ml4fIVuHjQ'
        b'7DHzIOogDCuRWVLUDalIOoeP6bqhMZYsskDEuBZmOipnS838NZoeJA5GIi22DgV1y6ahfWw913ld0VGak476kS7KkYUIh/paAZHoLtxjrcjSadUtm2Siqgsvm4N8GhO6'
        b'lGQLQrmASWexmjuR2aLOarUSjLO19Z5RoaB+ePaohurxjPVPVir8TfVKEoxzW97lKM8XDMsePDwvpwu+FROBQ/Uf0kCztEBbGBuhk+4Z7DzTuHbts0nd0FSodhY2sNI0'
        b'rrk/dTJWftT47rTOLqD/0jZpaI5/KK2dMqC+3+N0vh7qMskkBh8Voa1RJ830WqDuqxq8DYoOzVnmBs1H537tu3Vnjeu3YvV8AZLeHMO9hBRSjETm1kBeh8IsW3bwLyn7'
        b'sa0xMKwc4HtEB+/idaCv/JDXC+rAW/iW9q/auQzbIJ/JphiXIVGyWjKkFGdaLukY12l35/vjGteInKDert6l7eUHzJiFAoAxxKCMsOSyMkM3X7tNu8eXV6Y9mnqJ5QBp'
        b'AMrNiUx5+pi6T92xdpauSTlKewLTk0byi1bdsfyQraMfsq7kaiuax/P+uwH9mz3zztLFtYuSl6d8kDP4teW/PTUt+/umpt9fffNNA3slR7J/8UTGPtfR5edO7s18bkHm'
        b'cw8eLMtZ8tlU7lPLRfHiy+P/9uG8h3Kdr71z79k3fnTqx7u2bJq5rUS81iVWHUt4/w7ziGGp18/YPK187E3nf7WpaA9/6E9JIwpyri9M2/TaQvHTHw99Yln1ppZjtvd3'
        b'532PX25xPi+++Z1rOOdP7Y2zfOIcT/xdO9/+3oa9W/8+6YXP/mtK4Vt9hz//x4Ltp7JKA+d2pa4YXfTFtldOrhx7b9zoB++756Wbh/00eVPxFX+Rn6t7dUHZmk2lD/3l'
        b'xI33fSdr9KhzP/oku/DlQOHxmfPvMT8rvng8ULamYNyJC4N2PPP7F2df96ek4PPX/KH3b57+/pfTb/v5y7duS/jbjbkz/7rpXfPoVJ+05szc3SeOXnFiRp+xqW898umL'
        b'A1VpqvWOwJ7qxUMe/qVl6cvbFi7Z8ta+GX1nX1f4QK+ff+hsK/tl/gtNk/beufjVrX9c8faBvN1/Pmw9n3vF92449lpg2zUrEv92pGrlvmn7rnzjj/HntVen3/zYSwOH'
        b'jJ+2dHTSmTt2nblY++apgZ+84zx0NvCXhXE3Tpm08c3x/d4cELi2sG/qD34347Wn33p9wVdcwctLXhkwJDXutUeeX5d0Y23J+73d76zJ/Wz+F2NWTL81r95ybdu8Ob+p'
        b'farqF+9Of/SDm4vnu9Qpnyw98/T2mhf2zVnwSdraHff3OVF9aLQvkPmnv4x6pPR1e/BM0dtVpUeKX1xZf3TVp69M+1vqGU/lx6u/HHHk7msfeqTiy9Er/1z0xKla7YmD'
        b'p+1NC3Jm/W5WwZroAxPbxv5xxUbnuqdmjznY79e/39CyfNhrD95w232/+sfyVe+dqD/te+GekdG+0THBwg9PzPnslcmDyme8N++/6l86f+El7YcbZyz56OFP5rQVfbD/'
        b'7dYvH/1b87Z3nr323QlvPGfu98tBR4ve/a37+sMfDjt2seTZu7568Gc/+/Xnwz53Xxi36IX9n36e3q/qx5/c9Zer+2+9deynHzzx07g3no187+AVKdf/ZlP+6LMf+66d'
        b'9MMLrskTTxy8OWVb0vrPfvDgO6FPl726dHzcXx4teva9hpd+saB+yeRHPm+9LvvXcS3jTj45+Gn7T+/7OGnX7oX1bX88WfXEFU9Njly98Rd5v71uQPnCJS/N+/rxm117'
        b'Jsy75cLJB/1Hfj7l4MXpgfk/PJq23r7u73tfv2uPrN6+7/7W1KO/eu1HH89e8qt07u03Pk7b8/rzb1fP88xIHXlw8Ruv9nv3H6HXp39Y1nTT+td+FL01774/5AQ2JN/5'
        b'6pu9H/tscstNf2/NH/PykLSLX87rt/Ej+YMVF49/ze398cl3Tox2xTNfGpuu1R5Tt2i31DIjXuUlRQXqZnW7hUvVNonaCfXQGjIOenX8WDxNLafT9Q1T1G0YpZd6TlTv'
        b'HKvdR+ryzTxa3CgtKFJvHz5XOxCfr0U4Lkm9TVRPQNI9pK2frLWqdwAB+5C2Vbs9r6xgKKrcPyWouwpGk9esErV1IvN2nqtFRgDN28HZubpTvZX5DzmgPqrt0TmpY9SD'
        b'naRc11cwD41HRs5kx8O2uflDG7Sz6HggQX1WdKsPabcEcH9JGzwGakCKq0Xa43bGlcUgNlHdxkyaMRGC4AS7FK/tCqDR2VptvxZqZ+OuKSotzte2ui6VO9D2wUa6sdjO'
        b'aY8UBnBns6gPAKA9rt6JhsO/SUKkxhUYA/GnqE9W+oeRJ6jtTeotUO1YkV1EHNZpe23qSfUQc2GtbZ9U1ZXPrD5VpTOajwhkVGGI9pB60tgptltxo9AezQZU8FttS994'
        b'cY37N2b2/8vFNZAhDv9PXAwWmbehQna7ybpEBo+yWebr0SqDmb/8n/RnZ1+nDQXZBRH/k3jBBhi6JYUXkuA5OZcX5vfmhTQBEC9z/hAhY4YzM8MkTROEDH4sL3iH8EIT'
        b'kMlWPNEfzAuJAp9N1yxe6I+yYoKJrpYMyBeZyIIooLFFU+dnBy9Y2RssfyAvZAl8Gi846LuTrolDeEeDRErYggg1lCDHAf0gZgbvsDgor3681Yl3qNNKgYdajxb4obyj'
        b'TPl57Lgv9L/zv4dLO4mAvXU9pxt9WN+NOwtSaUhen06SPLQ9qRF1e6V6ysI5M8W+vdUHau9943qTvx/MzPcsmwru+Inv1WmO22pOXP36Wy3r3v/B76qe+92OwNmPM5td'
        b'zfnhEzsfLN77qfzOfMvnoVNTbv7q0IOHNt30xfkBszePemnZ7Al3hGYm33Fd3fnECeqxl1LTfvbaLfc25n58a2lF4fo6tf+8q0f94dSOL2tbdizd1bg9SbXsFp4/L48v'
        b'H+8smfbF9s32ppwpo7+/4vEdtl2r/3DxH97D112waQ8GRmvuCVsXjHxhwS+kuL99GLfzqvVLFw9MPTtp3Ec/Prhw2YINf5hUWD7lg0c/6V9/fM/OsV88uO1PxUFvQd7J'
        b'QT/78OnX3vFMTUw7PaDuuwlywYf3vLAzZ/fxIX2frjk6cO3gZ/LWjDn85K+fL3wvqe/yuvA9V9dtvmd5XeSD5XU/jfR9ZO8Xh2a+vnTOa29sfrW45uhvRzpfObP52onr'
        b'tpcXfBksePS5VvnHn8i7t/wknNDU/PfCSWU/uqb009N3vP/R1osb+ySfPzbpzV1vD9hesH396g0/u/anyX+Nu/vDWuVH54/WR+47/lm05oziuW7c3p/8KbMuvXL5T556'
        b'a4Pyk+fP/yby+B11r5f61u/6vTLnr5Vpt/7q2tMbP3lrR8qL3sfP7jz18djPVh7udX7kX5d+9IOSsQ2HP/vY997cV+SP7m1LKm/p1/Jmce6qqxrf7v/3Nwe1csv/9J05'
        b'/OwdT7baH3n4wDbz3lUHtjrP/OXAdv623/7QWvV+Rf/krDcT51z1I1vZmtv8JSM1059P/yD1sTWtK285fcPph/h497G8jRce9zxfc9+vrtj55cWEJSdfkb4+7ZpMuENN'
        b's7pHn0y3a1vycTYNU3fCbFoojhynhgkJ4ecvxig3qocMXKAd2VEPqefIdNAG9bDWih5H1WcKOrgcHdyHzAKNsKn35amP5Zs5QdvEc9qj19+QZ9hi37E8r7hgKOBKgNuo'
        b'W2QZUxdrWyzcgEWmpMGVFK1Eu1PbGTPZXtrktnYy2T5E28pcOe/s7ygeiriUC+PlqcdWmbmEcWKddjaTLEGPVckw2PBr1S1zta1Qx7m8etx2PblMdE+aW6xtyxU4wcdr'
        b'z6oPTVE3qbcw59J7Fmune9fkoS34chNnniY4tb0N9Em97/rFjjXkoyG3gOfM64WRzeoRKou/ahw0w7EQKlMEyJZVfVZQQ/l9KFmG+qD6GCCH+bB1BHn1fu3o1ET1dpbj'
        b'7kw1DNXcjN/U4zzgo4uvG0o5zlAPZdRPJQNhhnUw9aR2lnpYvVU7mU62GyFZC18wuDBxBjVLvX0C5LalfBgP2W3m09Sn5wSWkysg7aS6XT2mHjGVoPkM19C52i7oAETD'
        b'EPfKGW2apR2bRTNgzbLpcYCcFhdoO9U99lwY5MfRM2xv9RlJ3as920SRtJB6/0gyugadgcbWigEFTV+lHROkK7Xb1e1UG+0+9TsrYADmYW3u4tUzMwudYwPIY8lSb2vO'
        b'08LD0Vvlw/zqumXz06lhC7Qw+UzA4RI28o0t06RZNNjTCgToX3UPwUEYGiLTNwnag3HaE8yA/9PaEajolvJrtEfLC4pw+EpNXNJEUT2yRD1KtvGGzlcfL2ZeesvLIIsb'
        b'J5g5543irMplrLZ7tVu0u6G6Zo5ftFHdy2kHCyfRUGintc1jYDJO3djue1e7lxnc00Larkyo2eESbRMZJuGkSl49n6adp6TjYex3qY9oh4sLXPMgrXmRkKYeHU/0QG7j'
        b'+GL1tPYdmsNFOG3i1LsE7eFF2p20XFN7o/f48o3qvnZpXwmIilZRu2kd4PFkxGvPlVcUF+UXFdBS6TcW7SJuFstm1VGTrkpUDxYX+cbkF0GtJV69T22FWY55uxzqA9Ai'
        b'oiZuLy2FDncVQd7anSKMEtAr5L/0+CLtUF6RejTXNXxevna3D333HBTVm7S71RNs+j5jXVucN0XdMbcIlldvXj0An25lhgjPafeo39W2DB0MPb4NCRlpAa+ezVd30QQo'
        b'WajdmTfPxPHFMJO2cNpdoytpGAu1E8OhN5/Szs7FuYUWVKFbgoK2T3tGPcz8MByENGi9EDLei65JpURe3Wv1U39oN2unVxXPAwpmT37ZmFE8Z9HuEMzqiWX0tUW9raD4'
        b'ylG9dYOjhrnRG5IZQDlTrR0vvlJrncNsfsbsffZX91KHFLomFZNharYooZ6wLpzqfnHmYvVhqv4A9ehKeH1a2z63i/1X043U89ptE2vR8up+IWZ8td306lJPYASBhYY6'
        b'BDMFsESGapElMAFhoQIsKy2hTrm9uEB9ROJK1SMWbdMs7THKOABL4M446LZII6YtxgmVou1bUydqh7Q9qxhleBOU+CjU8BYPrtu5pQAo4rT7Be0U0Knn2MCFGqEJo7S9'
        b'2EjYAHChHRe044MWUiflF2j35mnbBk4v0bYX57sKYAyT+4kAse9V9zMCdV9tTnH5kGWwBqGVkaL8ecPR5iWXz5m0PbNzAgMIdKeiv2zaibaWu4BcU7fiNpOWk+qQxGz1'
        b'ASrqGu3+edqWgTws13LaJyxQlWOwQNarN1E2V6lPc8UwM7eVrL1a3U3sOyAqLVymdlxart0F+wQuszFqK19cnjwHXfBBTugkqJcG29mB/jXMR+7j2tPaOTpYvhNVPWEz'
        b'kgp49Wih+gxBTvUp7zqs63DcuPZoh43NCyvcZ7CktkIzNzNzeyfUuwHSn1BPFxeVDi21cGZJsM7UztHkaVHvhwm7RT06RW9yAfSs9iBMDPVI7T87RzMMc477D6CK/uMu'
        b'sTNnotD240OcVbDynX92PlGQTA6yV50F2LXAWwWn/oWdmRgiT7q1CcGuPycKZsxNQM8OKZ3ydNC5C8UXUFdHolh2dsIirBc72yFkP/N4M8845LpMuI3sNDQ1ut3ttgWN'
        b'Y4YX+Y7twwNdohYcn3WlFihGJ2GIePhHiysoiuD/AVwrOZlfDb/I0vBSFGCLXAF3Ae4C3EW4p8FdgvuS8NJaDu728FJUVYz0x/irMSYf4kNLDZG7Fg7F7bxivRRJqDe1'
        b'8PXmFqHe0oLHiRbZ5rXW21okerZ77fVxLSZ6jvM66uNbzPTs8DrrE1oseFQZSITcU+HeC+7JcE+Cez+4J8MdvuNha2RAkAsnwD0hSLaKInFBNMzLRxIhXgrck+CeCncn'
        b'3NPgnoNy4XC3BKXIQNkSSZfFSIYcH8mUnZE+ckIkS06M9JV7tVjlpBabnBzpHRRlLpyJsueRQXJKxCWnRobJaZFyOT1SKmdE5suZkTly70iR3CcyVM6K5Mt9I3lyv0iu'
        b'3D9SKGdHrpQHRCbIAyNT5EGRqfLgyFVyTmS0PCQyRr4iMlnOjUyTXZGx8tDIJDkvMk7Oj0yUCyLj5WGRUfLwyEh5RKRYHhkZLl8ZmSePiiySR0fmymMis+WxkenyuEiB'
        b'fFVkgTw+slCeECkL21u5yGB5YmRGIB2eesmTIiXy5MhMeUpksTw1MkLmI7OCFviSHRaC1qCtGnspJeQMpYf6h0qrJXmaPB3Gzx60Rxwk/tJu+dYZSgilhNIgZkYoM9Q7'
        b'1CfUD9IMCF0RGhYaHhoRmh6aHSoMzQ3NCxWHFoUWh5bAfBggz4jlZw07w9awq1WI2ELMlT3L10E5J4Z6hZJCqXrufSHvgaGc0JCQKzQ0lB+6MjQqNDo0JjQ2NC50VWh8'
        b'aEJoYmhSaHJoSmhqaFpoRmgWlFwUKgmVQ5nD5JmxMk1QponKNEN5rCTMf0goD1LMCRVVx8mzYrHjQyK5J4iHeEmhZL022aHBUJMroCYzoYSy0PzqZHm2kaYlLuwMxlEJ'
        b'QyhtHJQST/2ZAT2UBakHUfpcSJ8XKgiNhPoWUj4LQgurM+XCWOki1FWknKQb7TiOLY5wTtgRHhp2BB3holYBRT3oTT69yWdvbnQE40jYaA7zfUA2Qtp1S3oWcsvmmLl0'
        b'NMzZxCvxAZKOXM0bIuS6YnBbao4/15Vdy+RRK7Irm2q9gVqfS1BuRhjkwoKQZ96jvS13tY8YZSjLdr9JV4xz0IGz8gtDLcYlAbir8QSqFdTDsHrWV5HwDenG4zF6Q3XU'
        b'YYgfkdgRj7ZT6gE+wpMdrYPXNyoevx9CorehBpWnUUxNeQnyvoBNvoClXsDKXcDD6gsomneBM2SxG2QPQFmyYoFy7FGxsaExaofcZU91BWpJWKvd7GyWqWy2W7mIQeao'
        b'uZryicZVNbgrlBpyMYoOUt116xp83g2xV3Z45WOZRR3w7A9U6EZDrRCq9lbU+KMWeKLMbPTg8wf89JWk76mEtRVKewCFezFE6ejBSW8VPwlJ+BooHy8MYEUlS6B4PGvR'
        b'CjwGUAaCAqYqr6dCiZq9FTDAI6NiZW0NyayjOR3mHiRqRwfV7JmJBP1EH+SAUlHlQY+UbjdEr3SzgbTAEwo1RCW34qmOOt1yrb+i0utxV1VUrWLyyDAxZGbtDXGqNiHX'
        b'1cUrIH5FmonZ1hKY3yEUu0LLVGhZFkUGZuGxvEB6ukIr0L5r4oOGKn33gob/1NIUTs5/xGQ0CSdwGJO2Ux1JstWo4wn4GrYApHPAwsrEmgR5gEFCNeprJJCNTY60OMRw'
        b'NgmLSUEpbG/ilOlhR4spKITj6tC6lKPF7EuhECzmsCOOazGFOSZcFraHk+CLE9ruSMe+MIctEO7bKgTN4VQoUfDNDwpKEbzrF06rRhs8xSgOBuUkQznLKHYGpM7C3HwT'
        b'4H3/cC+K5w/3ArhjIZ03R4sVYlrCKRBTgr0C+roV9WkqgxLsIDzlZ4b8vhs2Qxob5doH4uBIOKGFdkivpwva4MmOT+gdKWhbxLG2h3lIfw7SJYTj4wx9OzGcSN/iM9DO'
        b'MJB4MheMw29BASBtfDrHdMDINqqNeUyIid2xnvwZ9L893BvKFbA/gqYU0uOL9cBvqK7pRg/oonLGPHH8Hx1jDPgPYCV/K24zzmazWbeC4DRwVYFpdJnh2Uz6gEkoUUQm'
        b'WR1kkDWN8Fwz4L1pKDkkOoVEIYuwXKuYwkuS9SsA8EKnZdJL33lomfxS0JeJE4bapS+TlI7LBL6KOHxhCXanjE4LB4cvD9JI9IRT3hSU/IGwCSaiOYy/NBh2EaX0ghZl'
        b'etBCijzWIJTGJg8slN6TON/qcJ/woPAQmP6Z1SY0IQVTN7fFHkZZNzvkGhe0h/vAcqyDiZcQx2XilizCsxOfgw5acJBPMA6QwwR9ApPcH/sWtMN0n+cbFx4cjg/3kfnw'
        b'IPgfAv/9w7nVfLgXlhPuj8sqBZBLeN87zIcTw4mIlNVaaFmbcBrDQuoVtEJr4mHCwz0ISyPszOBanOEkQAXwjTOdg2UTTyhCHKQC5EA5S+nhSUa5YjPKTLWYfGvhrTk8'
        b'FHJNCCaEMygOAAOob0I4m0LZemgwhQbroRwK5eihfhTqp4d6GzWlUB8K9dFDgyg0SA8NodAQPZRFoSw9NJBCA/VQXwr11UMDKDRAD/WP9RyGMimUiaHqBNgYChC1D3Lb'
        b'EGQiIIC2hq8Ix0OLE4OJ30ETYRJdLXil2ZKOswXygN6vRkPlemvSOVQzhB5NxlkGuYpkSELCvkfATe/zghLJ4EqGM552I+S9/q+sXdew/wD48T8Po6YijLo9BqOcur0z'
        b'lGE0807yVpbEC5LAs5/0pdVqJ4OuKSQPKXyB1v7xlyKgpKP0ud1B7uYkuzlNsAP8gh/f00/6L0dSopgEsA3PRaWLDpODzK93gm+GZhjBN2Y8EyAYkM1hqw7fzGGuA3wT'
        b'wybazgFhCdsA4Qe4xmTDO21H3WIp/wYXCdSpR826wJwO+EUA8lKXRlmNRp3DRkmwTBD3EAAs21hDWknsU0lGUfVwIloLpfdSkGJCE+PDZtyhoSsSAFDFI9jGEAq9h+3b'
        b'M3jMNS6chMsQO4uAmGgCIBu2jQMUcFIncXefdSTnn91R2B2AIIBTAPii/pwIuZDINvpVovxiFm6+oVOT/2dn9DlzTOgd5rCAV7slizfDICTxWTTH7JfOMXvH4WhGVBPQ'
        b'wnACosGx4ZD04Uih4UgF9Ez0p9EXDKdhmGz4D4R550DVYfpm355EnYfq9ZYM0kbAUDddP7FT1wPCF7ZkotqspJwMiv4yAwXnsTwJEErcnU1KEzrQREgL+5oJdiAY7BZL'
        b'swmZEaT9Z5O4ALeh3sjZx6/jKEUGS+9fQsS5M5QIhHlKKL3aojvhsXYoxYqQX7kzHI9vjNRsTwRMw1Yt1EnKaajLmVjONmSCQJqjkAbewHtbLE3H0u/uqA8nG6r/3Sr2'
        b'xKwAx1xPIqUCjYZuJ8cVaI0CfQehdcyGNMRd1xq2ZwoN3p8QqFT+RGZ6+G9tJCTqrPW7Gyqr3esUFN5WrBadhpF4SbeWS/PPxRMJ/y+5K8n8T9oafm/WlYHZQkLRd4fg'
        b'oI0Bm5t10S5JZJcIvY2ibjRz8CKhz1G79LeMFLvFKiTxDgt+xW0Erv+QfikVSLwrg/EoWrAscvkh+jf4lV/iu5fx8iu8vMLkrNFMkF/5NSkWNHtrK5Xf0GN9RWCV8lvS'
        b'6IYHTwW6k1B+R4oytbIymDIF+j0qVlQC5b+qwo9631GLbvkqavEbDzXehsoKr98V/+/pQNey/wAe/f9e/pVDDZyTdyJrAh0ZCoJV6nyg4RQyTA6e/boeeLCf1M3P0e3b'
        b'f/1n1v/bww5zkihZSkRpjJ2vFqXVdj5blBwjRCnLzk8SpZl2NB9iRXITUDiB2lmGijinOPIb4e7IA3S79RVZX9EIyzKgKDt5pvtL9g3YWcovaN3NXl/laUQzUArKkeDJ'
        b'SlVFk9/jdkdT3G5/UyPxDpHRhmou8DbO3R5QvuhsrKKDkuyk+ga5yetBFQiG8cE+KSWiDd5uT3i4jdZkdhcGouajISkooSp3238DVaLuyg=='
    ))))
