
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
SWIFT module of the Python Fintech package.

This module defines functions to parse SWIFT messages.
"""

__all__ = ['parse_mt940', 'SWIFTParserError']

def parse_mt940(data):
    """
    Parses a SWIFT message of type MT940 or MT942.

    It returns a list of bank account statements which are represented
    as usual dictionaries. Also all SEPA fields are extracted. All
    values are converted to unicode strings.

    A dictionary has the following structure:

    - order_reference: string (Auftragssreferenz)
    - reference: string or ``None`` (Bezugsreferenz)
    - bankcode: string (Bankleitzahl)
    - account: string (Kontonummer)
    - number: string (Auszugsnummer)
    - balance_open: dict (Anfangssaldo)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - balance_close: dict (Endsaldo)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - balance_booked: dict or ``None`` (Valutensaldo gebucht)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - balance_noted: dict or ``None`` (Valutensaldo vorgemerkt)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - date: date (Buchungsdatum)
    - sum_credits: dict or ``None`` (Summe Gutschriften / MT942 only)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - count: int (Anzahl Buchungen)
    - sum_debits: dict or ``None`` (Summe Belastungen / MT942 only)
        - amount: Decimal (Betrag)
        - currency: string (Währung)
        - count: int (Anzahl Buchungen)
    - transactions: list of dictionaries (Auszugsposten)
        - description: string or ``None`` (Beschreibung)
        - valuta: date (Wertstellungsdatum)
        - date: date or ``None`` (Buchungsdatum)
        - amount: Decimal (Betrag)
        - reversal: bool (Rückbuchung)
        - booking_key: string (Buchungsschlüssel)
        - booking_text: string or ``None`` (Buchungstext)
        - reference: string (Kundenreferenz)
        - bank_reference: string or ``None`` (Bankreferenz)
        - gvcode: string (Geschäftsvorfallcode)
        - primanota: string or ``None`` (Primanoten-Nr.)
        - bankcode: string or ``None`` (Bankleitzahl)
        - account: string or ``None`` (Kontonummer)
        - iban: string or ``None`` (IBAN)
        - amount_original: dict or ``None`` (Originalbetrag in Fremdwährung)
            - amount: Decimal (Betrag)
            - currency: string (Währung)
        - charges: dict or ``None`` (Gebühren)
            - amount: Decimal (Betrag)
            - currency: string (Währung)
        - textkey: int or ``None`` (Textschlüssel)
        - name: list of strings (Name)
        - purpose: list of strings (Verwendungszweck)
        - sepa: dictionary of SEPA fields
        - [nn]: Unknown structured fields are added with their numeric ids.

    :param data: The SWIFT message.
    :returns: A list of dictionaries.
    """
    ...


class SWIFTParserError(Exception):
    """SWIFT parser returned an error."""
    ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzVfAlYVEe28L23bzdNs8qiuGG70+zIouCGG7KjgqiIQgONtDQN9gIuKCpqs4ioLIIg7hsCsiguuFZFk8zLNskkccgkmSyTfZJMzGTRJP6n6jaKivln/ve/972nX1+6'
        b'q05Vnf2cqjrdHzFP/BPBKxRe+mnwyGCSmFVMEpvBZnDbmCROJTrEZ4gOszqHDF4lLmbyGf2Q5ZxKkiEuZreyKgsVV8yyTIYknrHMVFjcU8nil0SEJchzcjOMGpU8N1Nu'
        b'yFLJF6wzZOVq5WFqrUGVniXPU6ZnK1epvGWyhCy1vg82Q5Wp1qr08kyjNt2gztXq5YZcANXpVXLznCq9HobpvWXpI/uhL4eXK7ysCAlaeJgYE2viTCITbxKbJCYLk9Rk'
        b'aZKZrEzWJhuTrcnOZG8aZHIwOZqcTM6mwaYhJhfTUNMw03DTCNPITFdKuHSjawlTzGwctd6y0LWYWcIUjipmWGaT66ZR8f3eFxCiRbHp/bnJwmsQvBwJOjzlaDyjkMZq'
        b'pPDea6Qo6EuGvEu1TpyQyRjHwNtFqHE+Lo8LwqVx0QtxCa6IU+CKiMULvCTMxHk8vh46UcEahwFgUkywPkKCLsXgXXhnDN7JMrIIDrVj06J09gl5OvRhkEgYwgJL/i8M'
        b'yXQwE86WiIBwDghnKeEcJZbdxMX3e/+vE75QILxpuoSxZup8OXmq9X2phqGNO71FDM8scAZuaNRWNkLjbT9Lxp65GMynpmq8YqOFxp65PHAtL0QamqqxjNMzpxmNDJpf'
        b'SxrKf+/AhH7ruI59Z+m7MRtWmFiNJXTss6vLHcum2jGhqZP+MumGWwtDm2On3bX7bYTbKG7BX9nflj7YwDG9jNEHOnAXbkb7cDku91no5obLfMLxVc4Ll6HTCW6RMbjS'
        b'0zvCKzKGZbR2ltMX48an2G3RR/cUwm7CaiZT9JCh7L/E0KyBGPpw4ocMtRIY+ou/HTOCYVxC52RpJizmBTIScTvuBip2ekThnbg0emF4hGfE4mB8gpkUFe+MqhNQOaph'
        b'Vokt8EHorzIOJqS34xpU7o8uwAroND41hVkzEbcah5CuNlSFevzROdJ1AJ1BO5hsvH2JkSgXOmGDtvpPIu9q+ZFMenqS0HwA167BVS7osphhvBnv+FCKbfVwK8aJYaRy'
        b'twzrw3MGCUK9b+HIjIO/m0XpyWuXBTBq15UfM3oltHj+pv0y9bPU1ZnRypcyvT9UKMOVX6Q6pGdlxg3TpH2VGql8JVPhEKlU2McqW1Wn2GbHVZ9lRCqXM3vTw5W5qr18'
        b'2fH2k76zl+1UjJAnhtydfTv2hG3Y7ks3rRuHMmFvOneMeVnBGYbDOkP97a2AU4oYo5c7CJ1jnJFpRBovzUKXDEMpA5agzcDPsqGoEVfinaCuwSzqYCYr2F7OTaEQ6YhY'
        b'+j04eNwbPC1Tl7tepZVnCv7OW1+gzjTM6JVRZ5aSoTSoCJzeGh7WY6xZe1bKusFLJ+mbQiHqFecrNUZVr0VKis6oTUnptUpJSdeolFpjXkrKU+sqWB1RFJ2YPMgsY8n8'
        b'wHDG/n0Jx7ESljx5VvIbeRqJt0QXnHG9R7ineyyqiAMtETOD8SlvvIUfihtQT1g6108R+QE0HJzKQw3nqMsQgYZzVMNFVKu5TaL4fu8Hchl9kz+u4ZJYI0EdHUaVoJxV'
        b'YAZeuGs54xWLzxqJg4mUrcdVYHU+uFoNj13ptDUxPABXEaVDDSPh0ROqHvbGQUbvDV0H7q3/MjXpxm5Uh87tPl11urijZOL2S8URjewLmUTLrDP/Gi1iao++eUo6+Ngc'
        b'BUtlj3pWOnhEeuGSiOhYMWMVbY06OHwAbR5pltBAoqcC6LUS5JypyVUaqKCJslu78yBiELLsoZB5KrRecYYqTW3QESAdcVIKrp9gOR0Ja/2kS4Z7PJTu2wNIV06RT1iC'
        b'O9C2PgGDDpfGebLM8Bwe7bHE+6n9pSQ5sgGzv5AwC27k1BVVDKPuYDQqxtV6Q5Avz3B4s0Uag09Mwi0U/oDWmZ2ySCpmfAE+caqGSmladh6BZgG6BZ9SMfh0RBiFDrEZ'
        b'zE4blssweQA96ZrE6EzwakRHxhF4EcPFQZ6Bz+Ctyyj4KbuhbKhsPhB9Y6OL1dfTBBWo3KDUGyYTXND5oVoGNy+SUOhz0mHsXK5bwoQCdExNhJFokIM4mABzAFwxPRfm'
        b'dk0QYs/SkWy4bSjHyG9svBNyfoSRmvZm3IqL9fhcIMF9+kpUDEEA3GMXHXLF35WNdr8nYVJhyNzgZYI77FJ40AFiILZWgbYx+BzaG0wHHJXL2QWz1WLG/sbGpaIVoyhC'
        b'Mauz9Do6Py7xBIRanOZR4L/NGMMmxC5kgPEbXdihcjo7OoMPe+Auox+hVrER/DTuWoFa6QDpyvHs0qRZIuD8xrq8ggBKAdo2E12jAwjFlegEqiUI1YfTIbWuE9nkSfMl'
        b'wP6NS60KplPhbgSvX6fX+1OGVtsWgYOLNytD+EgFm7pyCxjbDX1d1PjZVFxhBnSOrgDiykhF+xl8MXA4Bf/a1Z3NWLQCwG/q62zOxgoknEuOouAWQPH+8aiBwZfmo6N0'
        b'gOdqTzZrxmkxSEzvsipojNEFGtPRdbQfd+mtZUACPoTK8Xk2wAMfpCMWqXxYjcxSxITe1N+xXzFYWKIWnUbbrXSCfp5PQCcYfMFhPB1wPsGXzcsskYCc9XfmikIpCfiK'
        b'Gl2zwh2BZMAiL0iaRIPGUnDb8EmswdbWgpEDCYvZKCEa1qfgOivZJCq0pjRcy1rGoA6h6xwuDrbC3VRAKnwab2fZifOFrmZ8wUqPuwpsgY64Wfgw67EWd1CEx+JqfFRv'
        b'aYPbYUYPA77OBuFLuIYOQ9cdUa3VGiPuZhhu+GzcwY4fjbsFQ+nO99Fb6QwwKBtfx3Ws6zi8n9qEjftQvQGWgx6HdbiC9UCNG+lsBZCuVOptbYCXItyAa8TsdNw4mo6Z'
        b'rMLXoceWhZ7aMEs2VINNdBlZ7lBoX0N4eQjvwRdZb3RimYDABcgkLlnZ5KGdPCMKmTKWDZ1nIRB7PB2dIHoNZqBDzXkMbh2Ht9B18BW/QLDuAAnMV5efCc5Aa6RcCEKH'
        b'8HaieDAGbYZcAqytM3MFVQIfdHSRHnfgLjuix1W4ArexAWp8kXbi46G4QQ+o0F58ai1uZv3Rfl5hJySLkwLZte5BkEDe0C913Cu4Egs+iC0MW2bBpIJgF60RDPT9pGB2'
        b'M3dLAgaqX+ptPYk2ZoVPZbdlBoPVgooNH72BNtqrp7ElK9UsWKe+LvznVMGbxc5kd2buh8abehfdwsm00T0slN3t6saAWerrFnBDaCOaNJutTkqQML6wuu17DrRxvnou'
        b'W8e9z4M16l08XxDRxmifMLYxpA085E390vyrqwRHMiOcPRRJvMeN7Dpv2WJBs6Oj2VNJDmAKN7Jdsv64hDa+J45jWzYdAh94M3tpxJtetPGnogVse9I+EdhAtou01YU2'
        b'fjEtnj03+xw4wJvZdTNuj6KZ2nh8ZbzeSkZ0QpNjzYYudKdyT4UcsNpKZ2sDWjQNdw0CJTq/RhDFeVSdDInyhQI9uAO9K6iyBz6KmqiA56HDMWAA4B5BLxPRblzNjsF1'
        b'WgVPEfgnf5ttdJxjAZQW3In2F2QXYPkieyjFQDx+rovtB9600Vn+B/bYchfIYW7muqz2Gkwb7w16mT1l92dCfm6djYPuqfTbsi+HmMswfZu/RzsdJtPyYSrO/7/tbezN'
        b'r8cTlemxNNiuXY67UXkcbMoqcWlEjPcoUOFSSCYHp/IT0RV0hdIwzpKTNZt3fsHrU4QMOCRQqnufhTlSU60tx81gKCuj7NBZXB0d5ROFd8VBXibF27h11rGCDPZ4gxi6'
        b'0Dnwy62oiWfYZQxqiZpGO1HbIHzVww1S2RJ0ItwHshbrVSI7twQai1AdPrEMdQHuIQwqDgixxy06wjohE5gllnoSAmF7FRYcITT2qiRT8kQwsTxVc3dYBEOzrEKJo7e3'
        b'vy+ZcC+jRPV5RpLB47OO6FwULgMGVJK9aRSq9IlArW6obQ7LyA1iWzE+SrHAJSPmxuMS/wAyQTWTFofqjCMp6m42HrDvotvaieg67MMieMZRIcI7Ldypurpnou3GMeYN'
        b'B5PuhNtps8fwmah8mj/qJFuUg4xGuVqgts0KlyWgDn9/8qGJWTU5hTooGTJpwNPt9veXkASTWY3a/Ok83hIb1DbMP4hyislIRheNZIOAyxxmREVC1CyPxbtG5xJx2OaJ'
        b'pkBaeoWuYzce1wehGv8gsnw9o7JDjXRcIa4KjYqGMT6Q4ezAFR4sY5XEwX7quKeCo5hMTMdncS064x8EuSBE1ky8O4p2WEF4uIqvOfoHERQbmFUZaAv1uzb57rgcdisx'
        b'YiYSNfOuLDqCtnjTMWFFqBPvQ7v9g1iSYzFZ+PgGemKwAmKMB5EELkW1obGolWesp4vsMtEeIb8qRU1rLNL9UTf5cIjRAEvoWrboGCwWHUm2PIuyRPgaixq8bIyxxNZQ'
        b'1xJ9dEREDDmqeLjRdPNWuMd4K7w4GTquQifwCXTMzQ2dHoxq8UkPBarGxzycUPVgZ3xsCDrJMajMyR4dQg3Zmp8ePHjwpULstldQv+i3Z68TUJiFywZ7xHqF87DVxMf4'
        b'UBY1ozZrhRP1UmIrfFVvozOKGMsJEKfZsXg32ketxwK28VW4y5b0YRMu53A3q8hzpgYSCVxowl10HD5C+q5B+DyzQAh4JnTFTw/jWAY3yDhwYKPmJ9IeA2pAp/VrjDKW'
        b'WbGaQz2sfKlZJPPW41YITgX4nJgpXMBBcjEaXQ+keMiS8QVICPA5G5ivlKzVwU5y9hCsuBn20jVWtlaoElhxFO8XJbHL8clIIcOpRNc26g2yAp6gVMyhq+yIQDAT0rcK'
        b'Nw4hXWJwxriew1tYOerBF2g6GItqOdxl0OFzItAn3MCha+xwtBW1CsliLWqD1A93GtBZtYRhwSbAVGvQESERMSET7rGS2sDughwNiCaz4bD9pNG+dI0N5HRrrFlGga5D'
        b'WsdORCcKhWhfidodrGytwftGoTbRVDZiWBBlmGiGN8RrHSRD6ORUkS07GRhQIWRjOwdJoQt3QnhZia6KxrCznNYJ7G9F+zX6NWSd5EgOdbOuk9FeIVM/jC7iQ3oZldo1'
        b'vIfDe4HsrWgnRcIpHh+xon1KVCVyYH1xRbbgAk7iYyCCKrAiTwZVaD0LJwheco8XqkLldrI1+SzD4zZlBosqHPsM4uAGXCqQFIrOE5I25QhSqYb8usysV0YXqlX4hEog'
        b'6irerBXwc/ei2M0E5MioGaNd+tRtJzorqFsT2kGXWmuXata2E3g/VTfFdAUvLNaAj03qkyXeupyK0m+EsAk5incHUTk2RPTJEZVkUa8zAh8SQw59AaKwUczw6DK6DMRt'
        b'wSZ0VlCCJts1qLwAd1ujUh5oL/FHe1lUH1gA4S5WkPYuJS4xK+YEbCJ6acSVgo60gb/ZK2gfuhhPlU9cQElxhT3jUUFlAzdRhV1nr7AVeNPAh1jJLHEnKGXFclEIO38D'
        b'sJr0xG/Cu/WCmXaNhv0UmE6n4BqL0NHVgnHHzaLGjXaG0I4gZJJYSUkHKpskkrHeoFWCTPejLcNxlzXpSiX79DbQ0pOQ41KaqhaPAw22hnDnb8Ph49C1HbJLysy98WDy'
        b'uBvSbNxmweGD7DjUbpYdJMBnURtYtxUoQ1gmhzvZIPBdtM8qD+220oENnucZG3yMCNZbhZqFE7BSSZhgSbq5xI42LqLkBm9C5Vb4vOUaCTPLRjSRDUbd6KDA2N1uEbSH'
        b'ZeaicyI3NgQCfLV5T5gbq0cVeWSDgA/ICF0K3Okp0LwFt+HLgF+enYTZgC9xuJSdsBB2Fl4kquNOC9CEKlSZj6tRBejuPlSGWoMguavBxEHWLmGZsSt5Z9yEj1C056NT'
        b'i3GVBeSyDLo6zxefXE69/ZR56ACA74PoUgJTOaFOmO3hTNXQsRtWgeADy7QDy2rg8z5ksoQd0T58Cp3JWg1O4BI6ZInqN6BdlBOF4M/PmPk63YvyNbFQIGkrDNnSx1il'
        b'YDHeyXEQMolFr56pMXPQax3hoBbvpu2zPR3N/LPANYR/g9KMCUS612F/XGqFK6IgAIbHeNOQ5YErYiK9FuGSuHg375hICHK4IkKRiE0jwyHpWASR/Zx+CaN3JkelrU59'
        b'R6b2qMbBGvR/F42quAtdHffQ1xajJmqgEFE6hWSmCfLftscMMQUcGghsF/hboshueKeLWXJTi6jgfJyASMqDlomFUd5e7pG4YoknuFWesUsUaUZwdGa8DXzNLmDzcRJ2'
        b'K3xoYiHFdRyqsXcTEpateDM6DZljuGfkMHwqzkvCWEWBEeWha1Sj1qBTMrPV1RPFJWa3C7XQsQ6zGY/ImCivSFwZAUyD/NEBNYlQO64NUi9tuibW90Cq8kXp3hUJ0+Oc'
        b'Zzld9e+6/947P5YeuXHkUIlb2Ri3klGv3n7tkN/g7tfeDX1pQt2Pvndeeu65IR/d/mLxhAlOPeMSg7pvR4YUbTkwc8vWP7zu3yWaVVb/5+BPm3p+zJ7c6hmf0jbd71jp'
        b'vOiwO3cHqW9OmlDb8t5H/OBz77rGhwXnxKz5zC87ZfUbn8S9KvP+9Mj91750rnrjo/yXfvBYMun0PO9vg27Kcm95xSd9MvaHrUdnK+tVSfczqnfYtYV43tC/eTfSIjkq'
        b'o2CFx9rWC6fvjggXveBhCpj+eiT6enijqPTO+vK7Tl+PymuK5WOfK677YPKQI+2jtpmu3c27vWGK1cddc3ZMm3Ql5l2fi5WNr91u/6V2zIdNLxv+tPyg6N67n786pKQ1'
        b'teDVMSHt4cMyR1d+nlrSMtHL6BudZPPOiBWF78689eJHow/Xri51Co6beKRIPdVwOKbwj9uiTyR8e+rDnYovdYkflia3uDu6WL7a6XNZlHRp+msfBDkXfDk6f83nN6pD'
        b'LC7zhS8dHf/jb51FD7a87HciYcrfk93LehoGL7073hDyQ9Drf25xik785MXk72+9FekelzVh0PSckqPGodmyL2VvvWnTMWva1ewfs3vERSN7Ph56YdRq7VcBe64f8N1X'
        b'5N0ZGXtib21XSe4Xkd73O+/vXGUUO7d96+W45fQXL0w60Xzm1NtNZ/ZOChyZqTLYr7z55huhb29AAYbio+NCZ9z/6ycOy18claSSzRiePPJw8r3TIwu6zq4dEfz22tqj'
        b'yb1t2tjQyd8Yru8yLDz8zgi+4J3FX06+2FuUvHTpRz0LS27FLhvbMfIvcaXfhE4ub/Sz+lJXsv7DA1Pee/lt4/CpuoaUmhPqpMvb3aNHfbf0Zez62eD173+4/bm31H/6'
        b'UXWzo+79a5/9Iu75bOnZT2+5OHe+X/yp6NqXPz3/wrsPZr3u0PTr+4cmrlU/n/9pU9cD6f37r/x2uvynWVvyX/vjEKfWB6LmilEv5TsqbAyuNCThq8643DMW8lbcVIQr'
        b'PSE5R2fAueJ6dIDeC8wvTPfwjvB0V3hDkrRjkCcuZRgXOb8SHTIYiBWNTIwktwLClYAKH6G3AuuHGogBj3O29/CG1LgUppWAbXVN5bzQDrxLuFAodkJ7UFd8lKdbOJgY'
        b'GC8svA6VhNJpC9AB26iIGPcYC0bCg6Vv56SAUr2BbDLxliR0lRznwsSoygYyqp24UsQ4ThXhBkgZOw0klLCwObwaFeeFD6KLsA/PZyGJxsfo3LgJHbX18FbgMk8G8GrR'
        b'unP+eegURXkOugA+pTzGMwLvgs4AXLOOs8WNzoYR1KPEIlMUuVSKinCHnSmk+8CvDA43LJ9jIN5ww3IIEE2408O9j2zLqRw66Iz3G4jPGoS3TYwCRwV+1wuXo8uR5K7B'
        b'AV8UQXqRorB/8hj9P/tQWP57Yx4d2zsIx/YGnVKrVwo30PT0/q8km58tZSWsE2vNSjkZa8s6wVMmkrIOrBTaoJWV0Zc9/d/3SUrf23Lmz5zEgmMlD6zh82DWnpNyPMtL'
        b'yPXPYJhBQufnNtuygzlbaHNieR76H/4n/X1P+Pudg70tzMnDSFvWlq4Gq3Ou8HTg6AtmIb1kPXtOwrpAjxPpZfnNAAu9tr/JeKBqM7OFv6ez7uOFQtRr3Z8F/e4l/j3O'
        b'KlidTR9v6fRzGPOtxYjrA9xaKKBjJe5EB+iVRegMVOGjgO2nR2y0t6DrHhLIUVosUPVadFjB0jA6JgTviYrwjCC57LmNkAw3TAx/6myIIEGPbaIZejZEbsGZp+/BM20e'
        b'nhFx/9IZ0SqF6J85MLlM3u/fAqJCerny8YoFWgaxLk8lj0kIDvCV5+rom0nejw197EOEQa5TGYw6LZlLo9YbyBRpSm22XJmenmvUGuR6g9KgylFpDXp5QZY6PUuu1Klg'
        b'TJ5OpYdGVcZj0yn1cqPeqNTIM9RUqkqdWqX3ls/S6HPlSo1GHj9vwSx5plqlydDTeVRrQQXSYRYCo3lsKnotKUCl52rzVTqAIoUaRq06PTdDBXjp1NpV+t+hbdYjLNbJ'
        b'swA1UiGSmavR5BbASDKBMR1IV4U8ewov4GGGSpeiU2WqdCptuirEvK7cbZYxE3Bfpdeb+9Yrnhj59BiQR2pqbK5WlZoqd5utWm9c9czBRASEzEfrzYYWjUptWK/M0jwJ'
        b'bZbVI+CoXK0hV2vMyVHpnoSF1jSVrj8deoLIwMBpSo0SKEjJzVNpQyg7YYA2UwmM1ys1GbmPw5uRyRFwmatKV+eAKgClhFEDgaYbdYRD6x5hswQfy9IZtQNCk/vsEPqE'
        b'OY3pWQCmh0/GnGdhna7J1av60J6nzfhfgHJabm62KsOM82P6kgj2YFBpKQ3yVao0mM3wP5sWba7hXyAlP1e3CvyLLvt/KDV6Y05Kuk6VoTboB6IlntiNfL7RoE/P0qkz'
        b'gSy5j+B15blazbr/VprMTkCtpVZKHIXcTJpKOxBZtB7gd6iardIo9QY6/H8HUf3ziZCH4ax/LHro7/Jy9YYnJzBrhkqfrlPnkSHP8txE1ip12jMwJpHLoOxTriUQuWAp'
        b'jeYZGmZe9JE6Pr7Ws1Xz3+a7TgVRFIwuRA5eBiAX4Svp2WnCAgPBE18ExKdkq/qJqg8hYIEGX9HrVZrfG2qAAP8MJprnIRADI/tUxI0yajNU2oEjpnlZiJEDxOrHFwaY'
        b'35tjVf7jcXc+kTY+lmnQg6fKhCSGdA80ME8HAgCfpxx43QXmbpXWK1bn/SzsH1v7KbwHjv9mRXgiB3hs8DPzAWGsGpYeeGDE7Fmxz1a7lFydepVaS1TqaR8SZ+5LowoJ'
        b'BiwP06lyMgqeaev9Z/4XFFoA/zedSZYSos2ALm++Kg1fAbMewCf8NyBGzIDaGfFzj+GVAD2/b2xaZY7qkbcz58Vyt1hoHlBPjbo8mhc9NSJRpStQaTOIWa4vUKVnDzRa'
        b'r8pThvRPrGGCfln9ACOWa7UrQuSLtdna3ALto6w7o/8+QJmRAQ0FakMWSdLVOpKlqnTqdLk64/cy/BDYSStziNsEnBKynqjffnxgiHmfEwL7goEiw+PQj13Kk8NkO+bJ'
        b'S/kEoT7Wc7iIlhb6Trg2bdBCf+FKe3cOKSNm5L75KxYuWeLCGMl1sj/aMpoUfqGyILwbnUc7yel2M6qgJ+ecH25FreSw9OA03CJGh/AudJIemONtaN9UfMYJdcG2eSoz'
        b'VbmeLnE4yoKB3a69b37m3HuOWYxw7V2MavPNd9e41JNJXzpUqBxAzaM8FNjEPbnTHT1KPAwdSFTYGEcD2LoFfrg8PBwdiomO8ELk2AngorwkzKilPD42DddRqDEWHrjc'
        b'J5JA+AjHuBVR9nhzrJjxwxUSj/BV9Ox6Bj40zaOvG/rU44VDXp8x9AwYNa7FZSJ89eGld9+Vd5G9kZ4GnUcm3Gm+2jZfaxeizbgN784UDqCbcacSl3tAWyU9aucYKb7E'
        b'oTLNMiOpSl0AAHuiImfANDsjgIpYVIErfcJxhYgZ5cDjOlzC0JICtB8fRt0EDTMUqa8oJUUN4zzEeDO6Pq0gwugGgPa4FtX0waFruIzC0lKE2BhyaXlFjPZH4BZaas8O'
        b'zu83JcCU+0QA0LhUMarHJ0PxRZVQz7ADBL0Vb8btHt64AubzjowBuSkkzHDcwKOj5OabVtHiszLcaIaJiMFlBGSIsxyf5H3xtlVUxgnDULOHAp3BdQMJOW6F0ZMcyw/H'
        b'7XovP1qFvMiNnPKRKool5DwN/i5egCt4ZomXBarZiKup9qlw+wj/SaTqYB+qS2UyEpcZR9ErD3wGkO4nX3QM7zMf47f4CDet+1EJOuQ/SUwuGiegYiYrCrXR4g5UmZdl'
        b'rTDfAvmKQdFppfBedAm1AEfPPqUU+Hq+oDUHcPv0x5XC3hV04jq+aC53mL0cnfBHncPQsTwJw0YzqC3aQAmZEzgZ2skcTTGuTDa+MI5eg2S6zQQlGjTyMRXCRwsVQh3p'
        b'InQ61t8fbUPn80QMG8WgVrxTuD5Xo0OoGLrOw/LtYoZdxKBzM9BuioQCb2Og64xRB4PiGHQW1awRruAu456x0NOIKnEnDEpkUPcKno5ZiC/j4/7+pK7iCNq9ATDsFDpQ'
        b'Fb5o6e9PuHh0ho7RoGp0mnoAg90QxpN4gE3n7G4nrBHqZvBpX1w7CbfqYaJ5zLzZQRRUPHsQ+frKFN/M162XzNYxChG10dkqEbnfqQWeP3bHM0OomsS7Z4a5hZoviR5e'
        b'EYUFUbSc1/hE0XJudA3t4nkWHZynMcsABH9lhb//iBkPedadIVzSHnGK8ffncfdDjqGOFYIVHtmAGqIigVOnnmGuB/oKWnAjiGObv/+k8X3cDRhCmZs8Dl8A3m7Flx7y'
        b'Vo0uU2eAzqeis8+w8RV48zRUn0yVxGq42CyCCGxislF9sHEiGd6lWtc3msXnBzJ8cOTbBBd8PA+fMosrEJyMxn0YRQGM/Ay6/CyncGZeqJ+1QF496sHdwCVSJGCBzzBZ'
        b'mmxq33NscPFK36gIr1hvsH+3voP54cjEo+Po+FTh5n1P7hyPqDng+3YqvCJ4xtKCQ7vwBVxG1SBhufBdDt8JgXHJcWJGWLDBEjULosyYTwUZHUldcCTavxzUA3X4Pa4d'
        b'aC/eRgFQzTDg9k58zCPSK8rLPZZ8UchulUiFL6ES6jKBy+WoAe9FrY/XbAHjSIXQ8GiezIU3UybjPagYVxHA07j1yQIvllZ3oVKQ53gC24FPpgheAu3yQTvwoX6eyD0d'
        b'+GmHmqmZrkzDu6J8PFL617jh9iTBiR3B7eAg+8rBhFowbMqj5WAzOKpUAS5pffVJ+OpkoUApOYCeIgO6h+Y+vB9FpaCvuCya3NVEoc50woxJaJ8kYqWO2hpqWTpVuC7t'
        b'uystA+Y1BeEjAi+vg0qZK6j6yqes0XU7IPkiWCu90zmyAIKHuTILb1lPK7PwQbRHkHyby3KhJs9ckIePoRo73FNIfesGt3n9KwfNZYOoOp+fiM8lUM+Rb4caUDdusoI0'
        b'I56JTxppvg0PCEFdEPqOmz0KKHqHOdcYMtiKfAkEn56HGyDhMKyi7RJ0Fe8agy8KX6hgvNDmiVT5fDZKSemVr29i17S1vgrGHCO8IWJV4X0WJCpMjGJS1pl9KK5Jc0Rd'
        b'viJoPzUEnWJy00Gi1Cv1cFJcZWeLz+MaC4bnUY2ITYiDyBJP5mvGTaOscAXuLHp0GU9spTIWV8TjEnLf7INLF5Br+XDhTn7hAtTpG78o3HPhY1EQtdjYx4E32icEngt4'
        b'u8SY9KQvxFfROaFCN0T43pHvhBdco9bNZBL6ZLZnBu6I6gtXkhTcjqo5d3TSQHUifRoppcY9T06bOl0I+nsT0GGiYPUQ4B4zQVyOL9CLend0Ah14Ki9IRNd5X6toofrV'
        b'w5oBtrn5hoXklg0aztBhrjyvjRk45VgzxLiU5l+jUKX+MQ4Be8i31ry93EDH3M11efGEuSWeieFEt6j+LnyKk9c3DNLgreDxmvARWocXa2FOjzPHBe5wncRQ/xaH6tDF'
        b'gZR0fzo/MR9V9dUt1BTgJtQVgLfjWhLiF5L4UokOC3UsuxbA+64A1BiUx9II0wauYoeRVGdik40lroKU5Jg4Au+BoFdNK036ykzaxKgzbZEhDZ0PZIHnkmW4aSFV0Y2g'
        b'8ddhzgyvvinReT1V0Y34+HDoSFD14YGapih4OsgdXcSH/YNwj/MaCFKRMMgRnRaCYx0+vsY/gNRc7ovAlxiVC+4WcL9YiKr8AyC4NebDQqEMOg0OQiifz0vCdbDSGBlu'
        b'Z2hk67RC9QrWXEhdBz4ZGHJG7QedYZDgLA8wzoOeJHwZdYExeONqUBjwxT64Mh6326COAL8FD7V/kVfiU8oPbvWgDO8H53/Z/HUavH8O7Ej2ozOAeCFTiE/gXQLWZXgL'
        b'PoHOBOFrYtTBMdxgyMxdwgUTLi5E3agzA52BaLiJ2YQPodNmp4KPTFsAzrdE+CYV443Lvcx1exsiQUitYhIIh/ky6AzqmAljaMZ/Eu1Yi7bxTxlhxVihHKYedeD9JGJd'
        b'c3vcXMbhS4LrKMYHlpNiyW5SLLnfg8MX2ACwbUGxavGZLHOxjAo302oZfBVX0upl41R4AL9QvVVsDK7wSjQbAy5dEh65ODxB4Co6DY4lxss7NhqCKzqJ22Ur89F2iOdX'
        b'1LZpGlb/Jkz1QfLJjYujckfMs2/7uukfr3z1H9nfhLwym3ln3V4LHwtr5ehtLtK6+XK35MblisRzr0tfHTN2wYXdLqNjpnjJJp6b7R++56dBjVPybBvtg0f/w+Lixy+9'
        b'HZhdVWJf0X35XsP+5rNnrn/9csys8SsmL/+45EXFzmFHlX/b+peWN+4kB3+App1Ttk064PrCeRv/v/n6JES4iN4q/5gbvmuXtuC7sMN/vtP+p/QD2tG3827U5Qyb/NFq'
        b'787ApqFfGN5o/n626/Jb52eoIvccH9Pe/H1T96A3ig56fZj1evNPFUaHZYEfNk7pvjkj46dFo/Uj6x3LJ//F5bWl4ws2B25Z8WltRb7byxp+RuuinNXPnbPgp3rsKfrD'
        b'kpqi4SlG+41z2oNvbhIH2X1VOY3r8X5jyeW4bxMOXpz8p/pPr9xYUflJ4E/7h1w5qHhvsl/nF/MKf63K+IvP0CL+LYsfylPtLH+Y3m66+WNtqgV/f/CdsTc2Dflq4c1r'
        b'kh/uLKhcfO9u4IfjTwwv23e87cOaZu/dxVtHOWxY+tWgjvm3gp5zdbx/8c5Hae+krbrVZL9h0VeKjri1PfN++2DixE9O6Pya274/LY3yjXo1etm2N35rSZi+jB87/O5N'
        b'ds3bb3YU+Pl8tHF7y8WQtxLnTzw4bHWqqcPHOPOHjbejRux68/lRZbeHzXglqDBs03pTsuPd29q//zHwnTvlqxOmfnzjlvKbnGyfL8pX3341/MG1Dq+fP2H9NiXWKY4c'
        b'zvh7r/dW297u+nXXTJIj/MqawOcL535yxrk4bUfcnFzJlIDPM/1cHd+d9eOCwq+cD/6y+dfC/M/iXtobeGeZ6KypOXBTW8K37/RcNh4ovJ1/qFn83KnvfT4rylnyYF3q'
        b'1BH3rv64nnv708O3pHesvn01Y39Ko8uVodbhY5Z84/jzXrfusg3rQl9suaL6eGZPwbVt/te3vh/8gavlj8a8IqPpxndjXtn03Kdbsiebhunn7dykSPjHyqXuf/r2vdWf'
        b'v/rF5ZmB12obd72d8c/hR9akXPJxvThh+pWNK75Lie399n37Iv/SG3/f2vrnvza/N/3BK5oCz3uBf8j75k8/xXx+oDjl0wtXZnZ+mJswJS0wcdC9xTfsfs558Zd3f809'
        b'3pMblnJrvvyjlzdoD121/SDBJfjwhOneye0F3/6Ic9ce/Kdv3SsNm1ae+ykgbPq7f/v5yiuyqdMr35X6/+XmkrdW/Hi39sCFFW7Wb2V3xyX1NJXPOHLM8bWJf+/47avc'
        b'eb+92PCg87srM65GHdQVxZwv/eqb6IB7739UsP3MzDi/g8+NPHqhSHSv6ZDV1qbmBS3TPxnf8u7O2p+P/Gix8m7U6J/u5FVY2xROrvjsz8ey1y45rer9dMP97SUVD34e'
        b'8q3zjNDv7ztE7HO7ds+ue8mZW2t9FHYGsutHFbNwp7koB7yp+fBkCGRV+ybw4eB92miJzDL5RA/3OH9zjYzlMg4dB1+4hfZNhm3gtX4lMlHenC3euomWzyBI+Of2r/kx'
        b'RnNeqMWNduLDc0RRnqjZvX/BD64PprU1ThA+yvpKkfrqkFDNXNwWs4jWKjnB/tdc9NO3scDnk2nRD26V0voayCdrcx9WK5lLlTxwNb8SVxtogQ4qwfUxHrEQDg7EeEYS'
        b'/KXoEleQjK5R0qbD7ncPZF9lPl5AWQEuDua8HdFZA03FK2BTeBl14nNRgP3DBex8RavQMVxKi44yhyzql0mhU5Gc+3jgKCX+YhDq6Vd0BJlGPeefKaVFVtMhoPT0+4Yt'
        b'qdstwy34wCYbYe3GYAiPXaTuCLXm9X1Be9oQ1M6LUGu0wvn/d+nQs0tZbP7z8zz19eAcQ3CALy0w2k9KVoqYIqnDo3IfGS0ZktISH461JYVGHCnnkbEcx7ED/5fcldrx'
        b'tBjJmo4cxpJSI/LehRYtSX6Vivt6BQhSCkSqb7gH9hz3Gy/ifuV57hdezN3nLbifeSn3E2/J/cjLuB94K+6fvDX3PW/D3eVtue94O+4fvD33LT+I+4Z34L7mHAkG0i9t'
        b'h8hZCazLs/asC2svsgW8rWGFEbDaiAdOtLTJnpM9kMBfQqM1KxQqkcIomYh+/lUmoT2/8hLS6kJaOUKJA1AgE5PiJcIF8uI5CUBIOAk3jrSIOGFGc8GUjLOmn0YAJk7Q'
        b'P4y1FUqoHnAPZDzw4zcZb035zG/mvpPZkxVICZc1zEfaJbAmz+ns+sSnEPXy5Ey7X0nUf14xFKzOvk816FL/QVSC2BWzZVz3M768HyrCewu15i9340ovkjkyzLA8EWzx'
        b'92566iv2RL9CybT05JD8uAuTxGWwSaIMLp4WMvXa0xN6Wr2km6fT5erujRLO7Kmu6szFSKoMuVIrV5F+71gF3ytNSSGXHCkpvbKUFOFXXOC9dUrKGqNSY+6xSEnJyE1P'
        b'SREM4NGD0kv2tx+z5tN7KSPlhEOnLZClN1nZ4gsGK0tCoxej1Jnt3wcflIjxjgwFG6ZufbWS18+D4avnOE1/7cVY7OskXjA19p2L8SHHbFRNz3OqpsM7Ve7DB/9yYzHf'
        b'/BzXOTttzpg/z0q71b38t6p9Y0ZHzd8U93b5l3Ffth7OOSCbsnb+lbc+mgq52bLvP/nifWv/9z53d5jl82nXg+TXleGXrBP931vYNnblsBkm658silJf3dv1U9bbk3fb'
        b'rr3y64bhx6sTut3Xc0Mz5ng4XIyPGD9dtO7O4Z0vTdzBlb0/Ynx1hIVzp2zfV3MqvnqeCS4ZrXMZ+7Hb7RfWRO+uqhtz0m/OK2m7Gp/nlj0/5tI2VecWZ51z9tLnJUEd'
        b'23O+Sh2y4c7zrO2abRN29fxgVzklNq/Mv/GjI9lhO9LKPIqHfXxqzqz6P/xjXNLFY66WK15Xr/jj0NW6f95SKBaHqRT1J1sOaWbX1BxN9jFl/2Vb4i8e30TvS7K+UNGe'
        b'ZbLOSeHH/HWQqGfVd/8Y0vOmpu1VrYKn3hy3oSuwCSuPhr0OBI6tUxi8KzOHBqMNsMFteOL3MtSwJTHxUnxQRSPteCt0zMqdVHtCtHoINQp18anB+Cw6jE0GclWBW1BP'
        b'qB42iMdwbXis18NDs0F4twi15+JLYBXUOBz+C526hO4gnv2gzhpUXJOrzEhJoZ56Kzy4wRwXwMqJ13hA/ISUs+fspZyEeNGnXsSrPvkiXvbJF/G68JLwMuq9pD+DwxN8'
        b'+v0RUqaIs7Rm3VgSI7ihg1ndkH4eiQPTeuSPBv3XsIrVuTy0WbI4URRayun91QAeigRvxzGwPS8nR4rkV41QKaq0YGyHiubi0yNhV1yuvvTuBE6vAsCO7x1G3vaz3Rpq'
        b'v+OPRZkFNoa0r6u27/js8BW0bfXf3Tr8f76z/K8xfte+2L69+b2k8+98mJJ97ecmVFQQv/TY/pTjnxe9GR8lHRv/2WfB/nk3h17SjfVb86mf3Z6jhZczG6a/+arFrVdc'
        b'uiMLFBZC5XcjvorOk9/C8FbExdETQQvIOzo5fEqBNgsg+0eMIwXUHYB2XJwXx6ShY4PwFRGobiuqoiBoM+izQBs580MVlDYHUajUFZ+dZiDb5RQmPgpSx8t9tdycFO+V'
        b'06QnGR9Fe6IiNk5+9BtOVgoO756Mi2muFogaUas+Yrjhid94WiUy0C+17Rbhao8pikgxOcHHdU64vs9UXP/b0qF/T3f43zUutVZtMBsX0SepjcxcT+0pIurOFPGLdUMf'
        b'qru8V6RRaXt5UkzbKzYY8zSqXp7cGkNgVqfDkxRE9or0Bl2vOG2dQaXv5UlNTa9IrTX0iukPsvSKdUrtKhit1uYZDb2i9CxdryhXl9EryVRrDCr4kKPM6xWtV+f1ipX6'
        b'dLW6V5SlWgsgML1MrVdr9QZSRdcryTOmadTpvRbK9HRVnkHfa00XnCTc2vfaCEmeWp87JcjXr9dKn6XONKTQ0NlrY9SmZynVEE5TVGvTey1TUvQQXvMgWEqMWqNelfHI'
        b'oAWyXXXke8k6P/Igt4U64mp1xJHqyJ2yjhzT64hq6sj5t47EUB35FphuAnmQWw4d+XUoHVEwHdkz6NzJg/w0jo4Yq45cCujIYZyOfLNbR47ydeQr2jo5eZCdio4ory6Q'
        b'PCaTh8dDf0CkY9knv7Cfn/YHFOKetO/HkHrtU1LM782u9d6wzMd/GE6uzTXISZ8qI1Yh1RFvQ/IIpUYDzo5qA7GFXhmIQmfQk/KEXokmN12pASksMmoN6hwVTWJ0wX0s'
        b'fCLx6JVOE9KVGWwf5jzDS6ScoHNOKo6myP8Hy1Fx2Q=='
    ))))
