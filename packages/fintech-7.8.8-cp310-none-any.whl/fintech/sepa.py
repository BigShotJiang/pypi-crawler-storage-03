
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
SEPA module of the Python Fintech package.

This module defines functions and classes to work with SEPA.
"""

__all__ = ['Account', 'Amount', 'SEPATransaction', 'SEPACreditTransfer', 'SEPADirectDebit', 'CAMTDocument', 'Mandate', 'MandateManager']

class Account:
    """Account class"""

    def __init__(self, iban, name, country=None, city=None, postcode=None, street=None):
        """
        Initializes the account instance.

        :param iban: Either the IBAN or a 2-tuple in the form of
            either (IBAN, BIC) or (ACCOUNT_NUMBER, BANK_CODE).
            The latter will be converted to the corresponding
            IBAN automatically. An IBAN is checked for validity.
        :param name: The name of the account holder.
        :param country: The country (ISO-3166 ALPHA 2) of the account
            holder (optional).
        :param city: The city of the account holder (optional).
        :param postcode: The postcode of the account holder (optional).
        :param street: The street of the account holder (optional).
        """
        ...

    @property
    def iban(self):
        """The IBAN of this account (read-only)."""
        ...

    @property
    def bic(self):
        """The BIC of this account (read-only)."""
        ...

    @property
    def name(self):
        """The name of the account holder (read-only)."""
        ...

    @property
    def country(self):
        """The country of the account holder (read-only)."""
        ...

    @property
    def city(self):
        """The city of the account holder (read-only)."""
        ...

    @property
    def postcode(self):
        """The postcode of the account holder (read-only)."""
        ...

    @property
    def street(self):
        """The street of the account holder (read-only)."""
        ...

    @property
    def address(self):
        """Tuple of unstructured address lines (read-only)."""
        ...

    def is_sepa(self):
        """
        Checks if this account seems to be valid
        within the Single Euro Payments Area.
        (added in v6.2.0)
        """
        ...

    def set_ultimate_name(self, name):
        """
        Sets the ultimate name used for SEPA transactions and by
        the :class:`MandateManager`.
        """
        ...

    @property
    def ultimate_name(self):
        """The ultimate name used for SEPA transactions."""
        ...

    def set_originator_id(self, cid=None, cuc=None):
        """
        Sets the originator id of the account holder (new in v6.1.1).

        :param cid: The SEPA creditor id. Required for direct debits
            and in some countries also for credit transfers.
        :param cuc: The CBI unique code (only required in Italy).
        """
        ...

    @property
    def cid(self):
        """The creditor id of the account holder (readonly)."""
        ...

    @property
    def cuc(self):
        """The CBI unique code (CUC) of the account holder (readonly)."""
        ...

    def set_mandate(self, mref, signed, recurrent=False):
        """
        Sets the SEPA mandate for this account.

        :param mref: The mandate reference.
        :param signed: The date of signature. Can be a date object
            or an ISO8601 formatted string.
        :param recurrent: Flag whether this is a recurrent mandate
            or not.
        :returns: A :class:`Mandate` object.
        """
        ...

    @property
    def mandate(self):
        """The assigned mandate (read-only)."""
        ...


class Amount:
    """
    The Amount class with an integrated currency converter.

    Arithmetic operations can be performed directly on this object.
    """

    default_currency = 'EUR'

    exchange_rates = {}

    implicit_conversion = False

    def __init__(self, value, currency=None):
        """
        Initializes the Amount instance.

        :param value: The amount value.
        :param currency: An ISO-4217 currency code. If not specified,
            it is set to the value of the class attribute
            :attr:`default_currency` which is initially set to EUR.
        """
        ...

    @property
    def value(self):
        """The amount value of type ``decimal.Decimal``."""
        ...

    @property
    def currency(self):
        """The ISO-4217 currency code."""
        ...

    @property
    def decimals(self):
        """The number of decimal places (at least 2). Use the built-in ``round`` to adjust the decimal places."""
        ...

    @classmethod
    def update_exchange_rates(cls):
        """
        Updates the exchange rates based on the data provided by the
        European Central Bank and stores it in the class attribute
        :attr:`exchange_rates`. Usually it is not required to call
        this method directly, since it is called automatically by the
        method :func:`convert`.

        :returns: A boolean flag whether updated exchange rates
            were available or not.
        """
        ...

    def convert(self, currency):
        """
        Converts the amount to another currency on the bases of the
        current exchange rates provided by the European Central Bank.
        The exchange rates are automatically updated once a day and
        cached in memory for further usage.

        :param currency: The ISO-4217 code of the target currency.
        :returns: An :class:`Amount` object in the requested currency.
        """
        ...


class SEPATransaction:
    """
    The SEPATransaction class

    This class cannot be instantiated directly. An instance is returned
    by the method :func:`add_transaction` of a SEPA document instance
    or by the iterator of a :class:`CAMTDocument` instance.

    If it is a batch of other transactions, the instance can be treated
    as an iterable over all underlying transactions.
    """

    @property
    def bank_reference(self):
        """The bank reference, used to uniquely identify a transaction."""
        ...

    @property
    def iban(self):
        """The IBAN of the remote account (IBAN)."""
        ...

    @property
    def bic(self):
        """The BIC of the remote account (BIC)."""
        ...

    @property
    def name(self):
        """The name of the remote account holder."""
        ...

    @property
    def country(self):
        """The country of the remote account holder."""
        ...

    @property
    def address(self):
        """A tuple subclass which holds the address of the remote account holder. The tuple values represent the unstructured address. Structured fields can be accessed by the attributes *country*, *city*, *postcode* and *street*."""
        ...

    @property
    def ultimate_name(self):
        """The ultimate name of the remote account (ABWA/ABWE)."""
        ...

    @property
    def originator_id(self):
        """The creditor or debtor id of the remote account (CRED/DEBT)."""
        ...

    @property
    def amount(self):
        """The transaction amount of type :class:`Amount`. Debits are always signed negative."""
        ...

    @property
    def purpose(self):
        """A tuple of the transaction purpose (SVWZ)."""
        ...

    @property
    def date(self):
        """The booking date or appointed due date."""
        ...

    @property
    def valuta(self):
        """The value date."""
        ...

    @property
    def msgid(self):
        """The message id of the physical PAIN file."""
        ...

    @property
    def kref(self):
        """The id of the logical PAIN file (KREF)."""
        ...

    @property
    def eref(self):
        """The end-to-end reference (EREF)."""
        ...

    @property
    def mref(self):
        """The mandate reference (MREF)."""
        ...

    @property
    def purpose_code(self):
        """The external purpose code (PURP)."""
        ...

    @property
    def cheque(self):
        """The cheque number."""
        ...

    @property
    def info(self):
        """The transaction information (BOOKINGTEXT)."""
        ...

    @property
    def classification(self):
        """The transaction classification. For German banks it is a tuple in the form of (SWIFTCODE, GVC, PRIMANOTA, TEXTKEY), for French banks a tuple in the form of (DOMAINCODE, FAMILYCODE, SUBFAMILYCODE, TRANSACTIONCODE), otherwise a plain string."""
        ...

    @property
    def return_info(self):
        """A tuple of return code and reason."""
        ...

    @property
    def status(self):
        """The transaction status. A value of INFO, PDNG or BOOK."""
        ...

    @property
    def reversal(self):
        """The reversal indicator."""
        ...

    @property
    def batch(self):
        """Flag which indicates a batch transaction."""
        ...

    @property
    def camt_reference(self):
        """The reference to a CAMT file."""
        ...

    def get_account(self):
        """Returns an :class:`Account` instance of the remote account."""
        ...


class SEPACreditTransfer:
    """SEPACreditTransfer class"""

    def __init__(self, account, type='NORM', cutoff=14, batch=True, cat_purpose=None, scheme=None, currency=None):
        """
        Initializes the SEPA credit transfer instance.

        Supported pain schemes:

        - pain.001.003.03 (DE)
        - pain.001.001.03
        - pain.001.001.09 (*since v7.6*)
        - pain.001.001.03.ch.02 (CH)
        - pain.001.001.09.ch.03 (CH, *since v7.6*)
        - CBIPaymentRequest.00.04.00 (IT)
        - CBIPaymentRequest.00.04.01 (IT)
        - CBICrossBorderPaymentRequestLogMsg.00.01.01 (IT, *since v7.6*)

        :param account: The local debtor account.
        :param type: The credit transfer priority type (*NORM*, *HIGH*,
            *URGP*, *INST* or *SDVA*). (new in v6.2.0: *INST*,
            new in v7.0.0: *URGP*, new in v7.6.0: *SDVA*)
        :param cutoff: The cut-off time of the debtor's bank.
        :param batch: Flag whether SEPA batch mode is enabled or not.
        :param cat_purpose: The SEPA category purpose code. This code
            is used for special treatments by the local bank and is
            not forwarded to the remote bank. See module attribute
            CATEGORY_PURPOSE_CODES for possible values.
        :param scheme: The PAIN scheme of the document. If not
            specified, the scheme is set to *pain.001.001.03* for
            SEPA payments and *pain.001.001.09* for payments in
            currencies other than EUR.
            In Switzerland it is set to *pain.001.001.03.ch.02*,
            in Italy to *CBIPaymentRequest.00.04.00*.
        :param currency: The ISO-4217 code of the currency to use.
            It must match with the currency of the local account.
            If not specified, it defaults to the currency of the
            country the local IBAN belongs to.
        """
        ...

    @property
    def type(self):
        """The credit transfer priority type (read-only)."""
        ...

    def add_transaction(self, account, amount, purpose, eref=None, ext_purpose=None, due_date=None, charges='SHAR'):
        """
        Adds a transaction to the SEPACreditTransfer document.
        If :attr:`scl_check` is set to ``True``, it is verified that
        the transaction can be routed to the target bank.

        :param account: The remote creditor account.
        :param amount: The transaction amount as floating point number
            or an instance of :class:`Amount`.
        :param purpose: The transaction purpose text. If the value matches
            a valid ISO creditor reference number (starting with "RF..."),
            it is added as a structured reference. For other structured
            references a tuple can be passed in the form of
            (REFERENCE_NUMBER, PURPOSE_TEXT).
        :param eref: The end-to-end reference (optional).
        :param ext_purpose: The SEPA external purpose code (optional).
            This code is forwarded to the remote bank and the account
            holder. See module attribute EXTERNAL_PURPOSE_CODES for
            possible values.
        :param due_date: The due date. If it is an integer or ``None``,
            the next possible date is calculated starting from today
            plus the given number of days (considering holidays and
            the given cut-off time). If it is a date object or an
            ISO8601 formatted string, this date is used without
            further validation.
        :param charges: Specifies which party will bear the charges
            associated with the processing of an international
            transaction. Not applicable for SEPA transactions.
            Can be a value of SHAR (SHA), DEBT (OUR) or CRED (BEN).
            *(new in v7.6)*

        :returns: A :class:`SEPATransaction` instance.
        """
        ...

    def render(self):
        """Renders the SEPACreditTransfer document and returns it as XML."""
        ...

    @property
    def scheme(self):
        """The document scheme version (read-only)."""
        ...

    @property
    def message_id(self):
        """The message id of this document (read-only)."""
        ...

    @property
    def account(self):
        """The local account (read-only)."""
        ...

    @property
    def cutoff(self):
        """The cut-off time of the local bank (read-only)."""
        ...

    @property
    def batch(self):
        """Flag if batch mode is enabled (read-only)."""
        ...

    @property
    def cat_purpose(self):
        """The category purpose (read-only)."""
        ...

    @property
    def currency(self):
        """The ISO-4217 currency code (read-only)."""
        ...

    @property
    def scl_check(self):
        """
        Flag whether remote accounts should be verified against
        the SEPA Clearing Directory or not. The initial value is
        set to ``True`` if the *kontocheck* library is available
        and the local account is originated in Germany, otherwise
        it is set to ``False``.
        """
        ...

    def new_batch(self, kref=None):
        """
        After calling this method additional transactions are added to a new
        batch (``PmtInf`` block). This could be useful if you want to divide
        transactions into different batches with unique KREF ids.

        :param kref: It is possible to set a custom KREF (``PmtInfId``) for
            the new batch (new in v7.2). Be aware that KREF ids should be
            unique over time and that all transactions must be grouped by
            particular SEPA specifications (date, sequence type, etc.) into
            separate batches. This is done automatically if you do not pass
            a custom KREF.
        """
        ...

    def send(self, ebics_client, use_ful=None):
        """
        Sends the SEPA document using the passed EBICS instance.

        :param ebics_client: The :class:`fintech.ebics.EbicsClient` instance.
        :param use_ful: Flag, whether to use the order type
            :func:`fintech.ebics.EbicsClient.FUL` for uploading the document
            or otherwise one of the suitable order types
            :func:`fintech.ebics.EbicsClient.CCT`,
            :func:`fintech.ebics.EbicsClient.CCU`,
            :func:`fintech.ebics.EbicsClient.CIP`,
            :func:`fintech.ebics.EbicsClient.AXZ`,
            :func:`fintech.ebics.EbicsClient.CDD`,
            :func:`fintech.ebics.EbicsClient.CDB`,
            :func:`fintech.ebics.EbicsClient.XE2`,
            :func:`fintech.ebics.EbicsClient.XE3` or
            :func:`fintech.ebics.EbicsClient.XE4`.
            If not specified, *use_ful* is set to ``True`` if the local
            account is originated in France, otherwise it is set to ``False``.
            With EBICS v3.0 the document is always uploaded via
            :func:`fintech.ebics.EbicsClient.BTU`.
        :returns: The EBICS order id.
        """
        ...


class SEPADirectDebit:
    """SEPADirectDebit class"""

    def __init__(self, account, type='CORE', cutoff=36, batch=True, cat_purpose=None, scheme=None, currency=None):
        """
        Initializes the SEPA direct debit instance.

        Supported pain schemes:

        - pain.008.003.02 (DE)
        - pain.008.001.02
        - pain.008.001.08 (*since v7.6*)
        - pain.008.001.02.ch.01 (CH)
        - CBISDDReqLogMsg.00.01.00 (IT)
        - CBISDDReqLogMsg.00.01.01 (IT)

        :param account: The local creditor account with an appointed
            creditor id.
        :param type: The direct debit type (*CORE* or *B2B*).
        :param cutoff: The cut-off time of the creditor's bank.
        :param batch: Flag if SEPA batch mode is enabled or not.
        :param cat_purpose: The SEPA category purpose code. This code
            is used for special treatments by the local bank and is
            not forwarded to the remote bank. See module attribute
            CATEGORY_PURPOSE_CODES for possible values.
        :param scheme: The PAIN scheme of the document. If not
            specified, the scheme is set to *pain.008.001.02*.
            In Switzerland it is set to *pain.008.001.02.ch.01*,
            in Italy to *CBISDDReqLogMsg.00.01.00*.
        :param currency: The ISO-4217 code of the currency to use.
            It must match with the currency of the local account.
            If not specified, it defaults to the currency of the
            country the local IBAN belongs to.
        """
        ...

    @property
    def type(self):
        """The direct debit type (read-only)."""
        ...

    def add_transaction(self, account, amount, purpose, eref=None, ext_purpose=None, due_date=None):
        """
        Adds a transaction to the SEPADirectDebit document.
        If :attr:`scl_check` is set to ``True``, it is verified that
        the transaction can be routed to the target bank.

        :param account: The remote debtor account with a valid mandate.
        :param amount: The transaction amount as floating point number
            or an instance of :class:`Amount`.
        :param purpose: The transaction purpose text. If the value matches
            a valid ISO creditor reference number (starting with "RF..."),
            it is added as a structured reference. For other structured
            references a tuple can be passed in the form of
            (REFERENCE_NUMBER, PURPOSE_TEXT).
        :param eref: The end-to-end reference (optional).
        :param ext_purpose: The SEPA external purpose code (optional).
            This code is forwarded to the remote bank and the account
            holder. See module attribute EXTERNAL_PURPOSE_CODES for
            possible values.
        :param due_date: The due date. If it is an integer or ``None``,
            the next possible date is calculated starting from today
            plus the given number of days (considering holidays, the
            lead time and the given cut-off time). If it is a date object
            or an ISO8601 formatted string, this date is used without
            further validation.

        :returns: A :class:`SEPATransaction` instance.
        """
        ...

    def render(self):
        """Renders the SEPADirectDebit document and returns it as XML."""
        ...

    @property
    def scheme(self):
        """The document scheme version (read-only)."""
        ...

    @property
    def message_id(self):
        """The message id of this document (read-only)."""
        ...

    @property
    def account(self):
        """The local account (read-only)."""
        ...

    @property
    def cutoff(self):
        """The cut-off time of the local bank (read-only)."""
        ...

    @property
    def batch(self):
        """Flag if batch mode is enabled (read-only)."""
        ...

    @property
    def cat_purpose(self):
        """The category purpose (read-only)."""
        ...

    @property
    def currency(self):
        """The ISO-4217 currency code (read-only)."""
        ...

    @property
    def scl_check(self):
        """
        Flag whether remote accounts should be verified against
        the SEPA Clearing Directory or not. The initial value is
        set to ``True`` if the *kontocheck* library is available
        and the local account is originated in Germany, otherwise
        it is set to ``False``.
        """
        ...

    def new_batch(self, kref=None):
        """
        After calling this method additional transactions are added to a new
        batch (``PmtInf`` block). This could be useful if you want to divide
        transactions into different batches with unique KREF ids.

        :param kref: It is possible to set a custom KREF (``PmtInfId``) for
            the new batch (new in v7.2). Be aware that KREF ids should be
            unique over time and that all transactions must be grouped by
            particular SEPA specifications (date, sequence type, etc.) into
            separate batches. This is done automatically if you do not pass
            a custom KREF.
        """
        ...

    def send(self, ebics_client, use_ful=None):
        """
        Sends the SEPA document using the passed EBICS instance.

        :param ebics_client: The :class:`fintech.ebics.EbicsClient` instance.
        :param use_ful: Flag, whether to use the order type
            :func:`fintech.ebics.EbicsClient.FUL` for uploading the document
            or otherwise one of the suitable order types
            :func:`fintech.ebics.EbicsClient.CCT`,
            :func:`fintech.ebics.EbicsClient.CCU`,
            :func:`fintech.ebics.EbicsClient.CIP`,
            :func:`fintech.ebics.EbicsClient.AXZ`,
            :func:`fintech.ebics.EbicsClient.CDD`,
            :func:`fintech.ebics.EbicsClient.CDB`,
            :func:`fintech.ebics.EbicsClient.XE2`,
            :func:`fintech.ebics.EbicsClient.XE3` or
            :func:`fintech.ebics.EbicsClient.XE4`.
            If not specified, *use_ful* is set to ``True`` if the local
            account is originated in France, otherwise it is set to ``False``.
            With EBICS v3.0 the document is always uploaded via
            :func:`fintech.ebics.EbicsClient.BTU`.
        :returns: The EBICS order id.
        """
        ...


class CAMTDocument:
    """
    The CAMTDocument class is used to parse CAMT52, CAMT53 or CAMT54
    documents. An instance can be treated as an iterable over its
    transactions, each represented as an instance of type
    :class:`SEPATransaction`.

    Note: If orders were submitted in batch mode, there are three
    methods to resolve the underlying transactions. Either (A) directly
    within the CAMT52/CAMT53 document, (B) within a separate CAMT54
    document or (C) by a reference to the originally transfered PAIN
    message. The applied method depends on the bank (method B is most
    commonly used).
    """

    def __init__(self, xml, camt54=None):
        """
        Initializes the CAMTDocument instance.

        :param xml: The XML string of a CAMT document to be parsed
            (either CAMT52, CAMT53 or CAMT54).
        :param camt54: In case `xml` is a CAMT52 or CAMT53 document, an
            additional CAMT54 document or a sequence of such documents
            can be passed which are automatically merged with the
            corresponding batch transactions.
        """
        ...

    @property
    def type(self):
        """The CAMT type, eg. *camt.053.001.02* (read-only)."""
        ...

    @property
    def message_id(self):
        """The message id (read-only)."""
        ...

    @property
    def created(self):
        """The date of creation (read-only)."""
        ...

    @property
    def reference_id(self):
        """A unique reference number (read-only)."""
        ...

    @property
    def sequence_id(self):
        """The statement sequence number (read-only)."""
        ...

    @property
    def info(self):
        """Some info text about the document (read-only)."""
        ...

    @property
    def iban(self):
        """The local IBAN (read-only)."""
        ...

    @property
    def bic(self):
        """The local BIC (read-only)."""
        ...

    @property
    def name(self):
        """The name of the account holder (read-only)."""
        ...

    @property
    def currency(self):
        """The currency of the account (read-only)."""
        ...

    @property
    def date_from(self):
        """The start date (read-only)."""
        ...

    @property
    def date_to(self):
        """The end date (read-only)."""
        ...

    @property
    def balance_open(self):
        """The opening balance of type :class:`Amount` (read-only)."""
        ...

    @property
    def balance_close(self):
        """The closing balance of type :class:`Amount` (read-only)."""
        ...


class Mandate:
    """SEPA mandate class."""

    def __init__(self, path):
        """
        Initializes the SEPA mandate instance.

        :param path: The path to a SEPA PDF file.
        """
        ...

    @property
    def mref(self):
        """The mandate reference (read-only)."""
        ...

    @property
    def signed(self):
        """The date of signature (read-only)."""
        ...

    @property
    def b2b(self):
        """Flag if it is a B2B mandate (read-only)."""
        ...

    @property
    def cid(self):
        """The creditor id (read-only)."""
        ...

    @property
    def created(self):
        """The creation date (read-only)."""
        ...

    @property
    def modified(self):
        """The last modification date (read-only)."""
        ...

    @property
    def executed(self):
        """The last execution date (read-only)."""
        ...

    @property
    def closed(self):
        """Flag if the mandate is closed (read-only)."""
        ...

    @property
    def debtor(self):
        """The debtor account (read-only)."""
        ...

    @property
    def creditor(self):
        """The creditor account (read-only)."""
        ...

    @property
    def pdf_path(self):
        """The path to the PDF file (read-only)."""
        ...

    @property
    def recurrent(self):
        """Flag whether this mandate is recurrent or not."""
        ...

    def is_valid(self):
        """Checks if this SEPA mandate is still valid."""
        ...


class MandateManager:
    """
    A MandateManager manages all SEPA mandates that are required
    for SEPA direct debit transactions.

    It stores all mandates as PDF files in a given directory.

    .. warning::

        The MandateManager is still BETA. Don't use for production!
    """

    def __init__(self, path, account):
        """
        Initializes the mandate manager instance.

        :param path: The path to a directory where all mandates
            are stored. If it does not exist it will be created.
        :param account: The creditor account with the full address
            and an appointed creditor id.
        """
        ...

    @property
    def path(self):
        """The path where all mandates are stored (read-only)."""
        ...

    @property
    def account(self):
        """The creditor account (read-only)."""
        ...

    @property
    def scl_check(self):
        """
        Flag whether remote accounts should be verified against
        the SEPA Clearing Directory or not. The initial value is
        set to ``True`` if the *kontocheck* library is available
        and the local account is originated in Germany, otherwise
        it is set to ``False``.
        """
        ...

    def get_mandate(self, mref):
        """
        Get a stored SEPA mandate.

        :param mref: The mandate reference.
        :returns: A :class:`Mandate` object.
        """
        ...

    def get_account(self, mref):
        """
        Get the debtor account of a SEPA mandate.

        :param mref: The mandate reference.
        :returns: A :class:`Account` object.
        """
        ...

    def get_pdf(self, mref, save_as=None):
        """
        Get the PDF document of a SEPA mandate.

        All SEPA meta data is removed from the PDF.

        :param mref: The mandate reference.
        :param save_as: If given, it must be the destination path
            where the PDF file is saved.
        :returns: The raw PDF data.
        """
        ...

    def add_mandate(self, account, mref=None, signature=None, recurrent=True, b2b=False, lang=None):
        """
        Adds a new SEPA mandate and creates the corresponding PDF file.
        If :attr:`scl_check` is set to ``True``, it is verified that
        a direct debit transaction can be routed to the target bank.

        :param account: The debtor account with the full address.
        :param mref: The mandate reference. If not specified, a new
            reference number will be created.
        :param signature: The signature which must be the full name
            of the account holder. If given, the mandate is marked
            as signed. Otherwise the method :func:`sign_mandate`
            must be called before the mandate can be used for a
            direct debit.
        :param recurrent: Flag if it is a recurrent mandate or not.
        :param b2b: Flag if it is a B2B mandate or not.
        :param lang: ISO 639-1 language code of the mandate to create.
            Defaults to the language of the account holder's country.
        :returns: The created or passed mandate reference.
        """
        ...

    def sign_mandate(self, document, mref=None, signed=None):
        """
        Updates a SEPA mandate with a signed document.

        :param document: The path to the signed document, which can
            be an image or PDF file.
        :param mref: The mandate reference. If not specified and
            *document* points to an image, the image is scanned for
            a Code39 barcode which represents the mandate reference.
        :param signed: The date of signature. If not specified, the
            current date is used.
        :returns: The mandate reference.
        """
        ...

    def update_mandate(self, mref, executed=None, closed=None):
        """
        Updates the SEPA meta data of a mandate.

        :param mref: The mandate reference.
        :param executed: The last execution date. Can be a date
            object or an ISO8601 formatted string.
        :param closed: Flag if this mandate is closed.
        """
        ...

    def archive_mandates(self, zipfile):
        """
        Archives all closed SEPA mandates.

        Currently not implemented!

        :param zipfile: The path to a zip file.
        """
        ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJy0vQdgFMe5OD67V6U7FSQhRD+KQCfdnUQvxoAkirqECkVg7k7ak3RwKlxBgOkCTkKIKroxvRmw6cXY4Mz4ueQ5eS55ycv90hznJXac6jSHxOb/zeze6SSdZEjeH6HR'
        b'zu7sfFO++dp88+0nqMs/GfzOhF/XNEgEVI6qUTkncAK/BZXzNtkJuSA7yTljBLlN0YRWIle/xbxNKSiauM2cTWXjmzgOCcoSFFatVz1aFl4yuyhdV1sveBw2XX2Vzl1j'
        b'0xWtdtfU1+nm2OvctsoaXYO1crm12mYKDy+tsbv8ZQVblb3O5tJVeeoq3fb6OpfOWifoKh1Wlwvuuut1jfXO5bpGu7tGR0GYwitHB/UhGX6T4FdD+7EZEi/ycl7eK/PK'
        b'vQqv0qvyqr1h3nCvxqv1RngjvVHeaG8fb4w31hvn7euN9/bzJnj7ewd4B3oHeQd7h3iHenXeYd7h3hHekd5E7yjv6KokNiLqdUnN8ia0Tr8mbG1SE1qA1uqbEIfWJ63X'
        b'lwRdN9LRkBVUBg8zB79j4TeWNlHOhroE6aMKHGq47tMoQ/QeWlWjHb2uAXlGwvVyfJ4cJa2kpTBvHmkmbf0TC/WkLbusyKhEo2fLycOF+Ipe5hkMRcl1fIyczMUHB2Yb'
        b'so2khezIV6BIsl1WgJsmevpCCSfZRm7kwlMFkg8gJ+UcPj7+ec9QeGLQjk9hb+RnkzZ8k2zWZ8tRDNknw6+SjeSInhchXMCH5bljx0GZXLITbyEXCqGqqGGyZ8irY1k9'
        b'ZDO+TO7RItn5ZCdpIntpiUjysmwM3oXPQD0DoRTeNKDUxQrsyCc7OETOk9Ph2Ty+WmjxjKC1nKzJ0JDr0KBtUeSWC7eQOw3k5grcGhWB0KARclVGnJ7z9IeS08l9/AJp'
        b'zcshO2RIhm/g3eQBh49yk+C5nkJqwtvJqVx8JQlGZHvu7FyyA7cUkp2F2bgttcCoV6K5s1VrSctkKJ8A5SfhrdmGOnIDGpZXqECKtRw5g/eRvfB4IBticgVfTMkxGvKN'
        b'Jg7hLfiStq8sHB8gZ6DEICiRAPf2pGQZkklLHu1aAbmnIbt58nIhea2S67LixvlR4RDF1s64iv5dbPUmefXeZG+K1+A1ek3eVG+ad4x3bNU4CYe55jDAYR5wmGM4zDO8'
        b'5dbzJUHXgMM1XXGYNnxgNxxeKuJwVLaqdDmCkdRZHC+teA6xm5sy+CWvcPTKkmfUbBBvtg8LG/W2TAf3LIY9a+PFm2Hz5VP/m48GWmRx/DhnGLqIHOFwe255/4nLwz5N'
        b'ROjj0V/wt8e4Bk/hHGHw4OvkQ9ySQdVRUH7sj5yxinLEbt9e9EXU7tKkoXzRz7ivE3IWfYZ8yGOg8/ci2e+A1dSaOi8piWxPzQKkwBdLk3LyyS6DKduYk8+huqgwp+1Z'
        b'ldIzC15Iw158yuV2rlzhcZE75Cq5CShwm1wjt8iNKLU2PDIsQgOI3Yx3jE0bP3bimAnj8EXyGr6Dr8oRfrA4jFzJqvJk0zXdd3huXk5Bdn4u2QXreAfZDtjfQtqgKUmG'
        b'ZJPemMLjjfgVfAFfLobXr5ODZA/ZT3aTA2QfaV+AUL+0iBi8Ce/vhER0+FXw24/OxWQ/yZNVyaRJ5pthKtfJYJJ5NskyNrH8ellJ0HVPhErebZLlBU46+3bNxqu8awpc'
        b'8f2n5lqXvPH+t67uvnZgmOKdl6wL37gb/c7iN27uPnngZJOdc6kqI0jGOUP87qw0WfUAlHNnqSNiwKFHeoWbEYIDGbDWWmEwdtEFLMcHybEpHL72PGlx0+WIN5PjZEuK'
        b'CUasxcAhJd5Zu443ji9yx9PJfFhJ9qQYk7KMPDw5UhLGG58j98X39k3Gp1OMpC1vjAIpy/HVMI5cseI9bjpQ5H4YjGtr1jxyCV+BPqzj5uDT+JCe8/FJer3MSbsblPCQ'
        b'POo7rcpZv8ZWp6sSGZjJZWuwTvfJPHaBPncpIQnPjOFiOKfS/5Je7gurs9baXMDsbD651Vnt8qnMZqenzmz2aczmSofNWudpMJv1fAc4uKYLwUln1amgCa2PoqIrDpLo'
        b'B0qe55QcTeWc8muaeuiDUeTlshToL4d4fKgON3GZI+xzKvkQuMKmdCrFFZ5hi7xKHsAW2RNhS1UokhDeDVtiCxjTIUc9QEE3ktuuPOgPuYjw+cgk1mZ8kjwg16fhm7nw'
        b'hNMj4t0wlr2CbxSZYYmcJTeABnMKhG+lkHPiK62LppHTxEta6ZPZiOxfMc4TQx+8oN2wEB/WAMvj+iB8X75MLP8CeX15Ld6fQu/Pg7YMwfdZ+cX2olriTTEpEbcY+E8G'
        b'3uGhrcc7V+bNIC+QffMgswbl46tWdp88WIofuNeQfTAbBmQg53GLPszTh75xdmnJmKnPwEiTrfA/cQW7m7YhPK/ieXrzLPwX8FEPxVi8H28049PR+D5UQw7Cf3wVNzMA'
        b'U6xRHnyJsAd34D85ksCGYmYcPouP4dfxfRhkcgz+4xNF7Mn0eUCKHpK9hD15Hf7jU1b2pIpcWkpewHvx/Sh4cgL+1+GTrFnjniPHl04gp3kqJWkGExH282PwIXwe7yuB'
        b'ikaj0fhlfM0DNBjlTZlBWsLJPsCaNJQ2V8P6kNsnGkSSffBzEO7jXcgMVOsme1SycCy54SI3VnJoxCCeXOBGwgwfYySjE9Xig4nLAEiq0Vr0HLCktVwzCJdOfi23h18B'
        b'jChsC1tILLnI+3hTmo+rvMh1rEu2Qnzh0xx2l7uyvrZh+kJaJX2SgDzPwp955Ag+lcvEFYnlZ5F2fAMob0thAdmhx7dlZM/SsWNxay7eC43XkMsIv0Ze1eCr8xvtaMQB'
        b'ztUC1dg81gltz0TitOhZjW8rfx49fdKJcz+Lv5de/umcosyRyef5lu8MTvrN0c1Nn1a9+GKV9vVJ7ozETz+d8skLmvnayz+1RmfuNYzIq//H3nvvTd3c9rEpdt5E87YZ'
        b'nzfOi7l+0/nSrgT3zBWn5sT9ak3awUELJk54ed+Gdxfd+/ivi/r/4VT56ppFj9etjDENXepMmkQOAN2kAwYE8yRuTjHpyXZga0q8B7+IL/PjbOSSSFYPAWJcBzGFNGfn'
        b'FSiQBl/j8c4p5NizQxnlNJMbHtJqADEOpEgleaXPUn5Eltyto8tYWcT4I9kOkhm+APyuBV/OUaDY8TKyFzdViuDPK6nU5Sfb+CZukVOyPdPejXzq5V3paZfJ09jqKusF'
        b'm5kSVEZKh1PsyJJzavgBUve1WibnwuFay6kfR8si4W8C5JzRQWSWc/nC6+rNLlAUamwuJxUBnJQedW8N76SL39knQF1pNdl+6hpzLwR1paMys4Hs6IxFcjSglrxG9sob'
        b'gUNt/AZCy5hyJ0L7f8qWw0TZKykjthhxWXBlGTSzRBKzLq7JisvgdByIWcumR5WjOexuizl67HP8TIQaLIal6yrEoh8/F47myUCDirYYVk6IRIyWrMQ7yYvj0uR0qVfg'
        b'faiC3MDn7V+N2ihzLaKNGP2fn1t+bampyrO+V5X0y882Xj18fdH2L4sPNfWfmhCfZhA+FT6NybYY9iqv938mod/Y+NxMoXhhcUL54ZHphm1x86NzX6CCwj2lwC+eWAIi'
        b'ghLFjOo79kdZet5NZ6TPenKEsfjMUYzJ80ar3M1UkWa8eUqKKduQrDeB7EZglSaQ5qU6+VJydqqeezLc61NZY6tcbq502gS7u95plph5JKUf5RQDIwEBEgDjnLFB2Car'
        b'tAs+VWW9p87tXN07stEuOPsGkI3WsjiAbOdDIBvVYclW0pYBqJYFChLe2YD3FppAPm2BPqaCMrMLWPyz+KiSnLM4uikUAbRjsiAHiNchC3IM6b5Z4N/SFelo09XdkG6W'
        b'iHTfscWgkcgyUIMs045rayX8+lFpH6RDf4iPaLBob0dPQKWMnxRPw6dB5XGQm2gMGpMnVmAG+qRGaWrNTEveLzJqkchum/A9fHWcnGqcl0FjHmubyQoXrOcB/xNGRyKL'
        b'4ccbHIixchCkd+F943iE7y0GlWrcUC0ra5wQAVwgQR9WZNFOLhmHGAMku0r6jlMiYHHb0Hg0Pm8Ba5halTCOQ5PxITQBTagkr7H3b5njUBLK2qCdaZmWntyIxJINq8cp'
        b'0FB8C01EE93kktgF+yA0Gc3MREWWJRHL1oitAu14D7k0DqjjtaFoEpqUlsLKzo3QoZmoRsU3WNY21maItc6dgY+NU6HnB0I1k3myjZV0TU1EWShrfNhMS0bxEp00MMf7'
        b'xuMbCMWTM2gKmoIf4qOsMNeoR0XoQozCYqn4bHW8WHgVOUmZnRz1Ie1oKppKNg5mhcvrDWgh+jRaUWTJeGXiArEwPoP3RsP0AjffgjJQBtk6QBzdNnKf7AOeWkM2o0yU'
        b'qUgUi19dhl8HsXcePg/S6SyYsFNsgNWDyD0Xh9biE2g2ml2F2zxRlH7GksMuBZqsQnPQnAGZTDQDXawFH3fJ0LOkFc1Fc/E54Eqs6nOkFW91qRC+PY6OADnYn7VEg69E'
        b'Euh7+Ayg2Nl4O24VRbwTGnKPQC/JOXIf5aAc8jBarOd8FOXpPOjkF1Auyl2It4sC6T18awK5oUTkFXwX5aE8EMNus4FZo1EhLUoaCdqr4SeaemlgmtLIJnKDQ/Y6lA8S'
        b'4Wv4dVY4YpIGxaEGDsilVj11rFR4R4ON3FBQye4BKkAFc8hdVvjmrFEA6dOpap0lY0EaL03mq6tBwbkBKHJJjwpRoQrfYoXDN6SgUvT+0rBoS8UPEhtEzC1bXkhuqNDi'
        b'xTDPReQ0vsCKxsf1B9msuVprsax9c9ESsaiVnBuioXoOvobmoXkDnmFFBwxUo2jUPAGKOq6aNohF01R4qwYmvWk+KkbF+NgSVtTrjEKD0InJUWmWvOS1fSSE3l5GTmh4'
        b'kD2egfVfQl7IY7j7XAG+qIGxPNkH2lw6NYpVsGHNAFheV6fJoy1rH6TNECuYDgLEOQ2z9pxDZaisIZ6Vbe47FE1Df+AVaZZpHy6bIg5NIWiCDzUg+XvT0Xw0Hx/EO1hh'
        b'T+oIQLdPK4EA8OUyP7V4AFr8To0MkW3YC6RtwYocVvjhoH4grH+p4XWWJe3l2WIr4p34KEwzPkr2wiJYiK+LXX5XlYqWwDri0yz8zSFLJMpykuwIx63Q95c2oEVokSVO'
        b'5KnTxqMa9GW/iJmWscXKiSL3/FPDWCCMaYuA047tOz5bvHl/SBqyQM/DGiwVJcYxwBJE1N9KtpHDuBVw9iqgYDkqXzSDDaaizwLcCoRsYwPwicUZox1fPn78+LeL5EAh'
        b'F87igUIuKHOKNY9wTUIO9P5Urc4SE9snB9lXr3vIuYYBQ1gVHvvs++/myNLjtn78/KXy304eOOHcsQnfvTGn7UaftbJ+wz/9nePN/WN0OX9JDv9twTvfnz38F4PXoqHv'
        b'fXRr97aoV7cf37zv0Kzl4euu7o/+ZU7M1jceHM0a8GH7ecPmP18+mf/3959PH+j7fHvklvFNBT5F7v0PMp//YO4/xsy8kXAmM+HclB3vv1YwpX7ET3c+WvnenU8eHPvD'
        b'bwXfF8f05sJ/rHnrBzeS3p/y3kcKw4eJho/6Xv5wwuWPIhwfGpN+/FakseLg76zHDzTMjFoxa9eK4h8c+Hlc9eTHY41tCuvlV/7jpT9q2j9SLFujb/z74tij/zO1KaMg'
        b'+acFsfaF1Ue3t77QPvL7bxeeL3ih7evHHx6dnPWmYt6r1VNiXv6Hy/jZg/ZWZXHE0vVlH/7+reMzcn/526ijSRVHXKdAhqaWOnxS/hy+sQTk4AJqq9tl4IDCXOLJy3iz'
        b'ltkJTApysMO8gJtBiDYOJ/fcQ+jwT3wW5MEU0M3uk7Z8Yw41qcaQuzLQTDeSh25qmsT7yYsRICTvyM2mZgblZPLyeL4/3l7rHsaI0zjS5MJXsvBmfLvAmESNr2SXDEj1'
        b'bhm+SnYN0ytCCi/yUJJGkEgTKYk0nkozFauZPHMTEq0g56J5OZOp5Rz/+Il+ef7r0L/yznkZ/9UT/cr5f3b8yuFX/U+5kmfyfBwfKVNz0SAPAVy59mv61xkfkLpkIHV5'
        b'KnsTtjhnv4CcFc+EFL/J5MUQchbdN8APyR78MCBoFZrw64p8+EuFfAXSk40KvA+3132DkEVttihIyOL+NSErtGSvEmWkZwdEoNf4NAQChmHqiChJyCpeGV5xDIny+rvl'
        b'jRKVbm9Ip+J6fBSi0rqOXLT/4vo23pUJz/r+Qvm5pfyNq7tP7rvYdLLp4uExW8ccPdk8eqs+4Z1ca4G1xrZ39JvyawnFh9INK7aVb4t8a4DyxNQDjhMDvjsefef3EXv7'
        b'PNRzbsZCX18o71gaY6fxRnL5Gb/U3Qt2DhCx0+V2eirdHhC7zU5blc0JKqCIqVo6FBvUvNYvdycEYYDcBYV7R4H+ARSgL9I9IBfFBbQp+nEIJKA7MaTVow6gQKpJn5xv'
        b'0htz8nFLak5+rjGHtOF2Yy6IqKBibw8nmwbjG9+ID52F7ifDh24mNX/lnfFBKZrU0siLz2qcMnx6PnTgMsKHQZLZznCidMwENFL/PjWgjy0dbERz7Ef/RykDXoFQ257M'
        b'zy1L2Oxfa1oxOoOrDP8k463hX0eei3yr6q24c44Dw78V90vLtkhl9IxDm8YNRpq/a9Rxr4Aixiyq18kBchrmvBLfl6YdJn1vLbMHeOpSOqliVWQ/SgBVrN4pzV3PGJHQ'
        b'RQXrjA/hIj6ExXOUcjkHBGND5Tdiw8AANtAXW4Kw4csQ2EA3Y8irS1EQQehQu/zYQFFhNb5IbpMzYaSZSnnfqPrLuthY/w3VvztCqApK2byvK4oEiQ0lbExtcFQPixZl'
        b'hFERVHBAujdGPG/IM6nFm+MLxF3G3TUOw/ZYM7KvQcs5Vx7c0eajT4RPLb+xvFNxubim6rLtU8sFa1KlYe/vLAvfuLt72Fb9Ue6dqhzrAcunAv+hQTd9dFFZWnRj2vm0'
        b'SeO2j3OPjRvrrEJo2ntRhyvmANZQcowPkJPpSQPwpbx8A2huuRyg0UnymptuFeLz+OxK4L5kZ2phPmkryMaXzXiLHPUrlk98hrQ+qQ4fUWdb5TYLHptZsLpFrIljWMNH'
        b'hXNxkhVJzmsf84+cgwL4I/fJaXFfmMNmFeDN1d9gNaImB+eQAD7RinZ14FPMFyHwaRTt41nyEjCRFvwaaaWbkLilUJ+P2wrZFmwiua4oJzvw3UpZ0DwrglFouohCcrY3'
        b'qPAqq5QSGsmYqV4OaCRjaCRnqCNbLy8Jug61e0erV3ZDI4XIZ+QlY9HPnn0PrizOd2pjRISZxynQkpgYSlLytk9wIzu6dIBzWeHJjQ8fDN5xLWJjmlb+05XFaem+38zK'
        b'Pcyn9zt789L4qtar+vj//uwv513lq6xFhvC9p3/wrZ1z9kVNnLjCJJtnWjVrRcu3jz1f9sWPVhWHbRhZeM3m/EP9qr8+Pjrv6hn72yvXG/Yn/Hju2yCpMaZeg+8yo6QK'
        b'8fgU3k02cmW4HTEDUezktNzsBaSZ7WnTDe1VIH4NZuhF2mHQ6QJu1ctJWyGH1GQHD2r5cbKDVTsb36byWXMBbk4FiibP5/DDCfiKSO6OZpLDpDUfX0aIvnMSb+XmInyo'
        b'N6lM2eOjrjirrbZ1QdkBIqHrrwZUjQSUDQfmx/NqPoYHMUnpHBpAXAVFXMBWios+ZaXHXV8VTAVDrhZAaCpyOnWdkZhWergDieM/DYHE9D0dfmFabqGxE+4OhXnYUyUn'
        b'R0GLb+uZI1JvksCuNqpS/LtcMQJ++3bD3qEi9uZu+E/UztVkRkZb7FcadSL2LoOuz6SD12CZ1j92mnjzoCwMVOGr8zlQhU/lzBJv7s4IB33+xEoF6PMHjYJ4c8fSWDQS'
        b'JXEqZBn0YrJGvPly8mA0Ge0u44os03a7Fog3t9ZOAKVwslIx0+LMHJUk3vTGKZEWrVqg0lkcH89wiTdzhSTQ4XebAXrFf1ctE2+Gu2egtWjykPA0S/G8gkXizbbqaWgV'
        b'ulukKbIU/0mzWLw5ZvVU5EbvlIVHW2I8KxPFm+oN1A5g0SCLZclfUT/x5o/mUztPgjGiyFLx/rIa8ebfJkcjHSoKhwFxvPhcpnjzuax0tBElVWsbLMW/do4Qb2aaKPuw'
        b'lHKw8N+fsE66WadFCegdtxxE0Y8W50qMpmEgqPsnEsOiLYOmr28Qb/YdAJoxmmzmdJaxVWvGize/3zgPnUALp8saLOGGhdLQKV029A76sgAozJziiVHiTUthFXoPXZ0I'
        b'rytvlvYXb85dTzX6u+s1Osva1lXSbJ6KpLyvKBylWfJ+OF5icx8MeR79Ge1eAsJx/GjnbAnQinGAMauKoFcxh2OKxJsrzMPRLDRzfBiyZCgac5H90zs/UzBNOuzw1LI9'
        b'+QUkLXrr29f+9Mmbiflh2csmh9/5tO8c/mJMa2nFhKW2yroPBu2QNWjeeqvt2299/ZPXDv+x5OfjXon/49nXvvh5bNUnWxfMnbxpQZJh8hvaxPSopLklW2faNv3XtF9v'
        b'vngzbVPswq9+//GA+tnPbtx3IfuvMzcfO3Jr+NY2xfT8aUffz49pPPCruQ1Tpu8esMn5S35xwdmvl57dMelm5v88V5Gr2P9R/oLLyb/7wZkVG+b/6T+8f06+EBb/2a93'
        b'DZ8/8rMTwxv/x7h3Weq1cvnoCyMaNb/a8fWwL/cMufajC4XjCk+mfnj1g7vfKUj6aJb37fHWSZPeNtyL/V3sb3+39PmfNP/4TtPy4rc11ZOEl69+0Tj9P//ufc/4x3Vf'
        b'fZH/nbLdi7aic46tDd6Hj779t7A//yO1fs+yvwnH9DK2Z2Qnd3BTECcfQO4CMxc5OblF9jB1uIa04/u5hqQsEKI4BLLTLTVo26sXDWQ7UvhBHn6QAhUk97FwSO7hSEsJ'
        b'3qSP+AaS+s1JLwQ7eCOAEuQKa91yc029w04JLKPKC0WqPEUNqqlaNpKJE9Gcjm1BRTPRIobT8uHycBAxwv0/si5/2ZX8V9pBWnhP+zgcqLoaFHHn8ABNB2F2tc3qDCLj'
        b'vXAZzjkiQMFpFS93UPC4j3rYUVgzeKZIwHMG9Sc7SCveyZxQdpGWPJgogxI9S64pyd3l5EQ3HUQu/XUtg8RGnQJROR/GhXGChu0v8KDq8IJsS1i5zCYX5IJiC2riyhVw'
        b'rZSulXCtkq5VcK2WrtU2OWUNVbwQJoRvUcOdMC+AKw8voWKL1qdKFwSnzeUqqFQGtUeNgjYjMiiJFZ2lAs5TVWqJySib1cBkVMBklIzJqBhjUa5XlQRd9+Tg1F0VVxQw'
        b'W6NpPt5YQhH2dXxrGBoGSL1X9In570X/kLtccHUCJQ3ePobuFct///1rg/uNz/qee22z6v2FZ9q0/3tvc8Vx6+N2zXcurxx/1G1d9h/ClwVl1rXHmldemdq+YsaC6H+c'
        b'/XnLxed2fddt+fbD7/z2l6PShv7+9aKE6Ql7viWcamqd8MzHe9TVVe6X875bcTf371+jY/OHfGBZrA9nQks5eZ2cFZcYadXCKmMrzLiUrb9lEWRvkKcN2eKkO7ZOvIW9'
        b'musipzq2ky+n4HZ+HN5L2kRL2Z7++BXmQwfq8FXcSmsm93ncQpp04uq9SLaSPSkmo6gZnqmew6cNzWCGMnwTX8rFrXgX2WUiB3ONeBfepUKaeJ54yTEHk9Ti1ifh1kJY'
        b'+6QtRY9fkqMofJLsCJO5QcY4wCS1yWSniRUx4ItypFRXzuL798WvMQDV+CK8njqVXCTNqaZs0XgTQ87KyCbcNEzcrj6F2xqgjKkSX9Ln5Bs5pCGtPLljW9hd1Fc/MXXp'
        b'oB4qs7nO1mg2M5oxhNEM+Tpx0zqebSGGA51QSj9ybk2UhNkm6T2RCqh9skqHi+0WgnJrd6/2qRvqqVuDYPMpXW6nzeb2aT11HbaT3jQWpZNauJxUBxH3H6ljrJN6RDqT'
        b'A+QjEZJ/dpCPAVu7k49ube0k63HSL10QLroq16JliHkBcwUXOZ/aLG2SwrXcZXNUdXhziAOnnuaw1lYI1ukRUMuf6H0lWhPth+h/+MQg9ZxPYaYj5zQG4ASAOVMhiYRX'
        b'nWmoiz9KT3VWiXWGmf3z0GO9UU9V7xaxXpVZnNUea40OWWsnAXsiEk1OQEWfTrTuZl+g/3jUlerJCuxXv0qRuygFGel+93PLp5b3KmqqpqRpq34GemLsF/yblsF6jq3S'
        b'JYnkPnWGDFqofP/Z40Xs5kOunAi7K8gYGPCkQxvQhvD4NX39mNCplOgNJHOaaC0dSyAYgDEwjOMhiYHRcyUwFEebIn8XAslDAwKST//pNYDIZurIZzb7ws1m0VcdrrVm'
        b'8wqP1SE+YYsJVqyzvsHmBAxki46twY6VN551mTr+WV2uSpvD4V/6XZfvRYp0YjEowjoyEpK/Icm4oUa8gudiHmv7MJkCNMUEzkOnIDNzjYvuzGXrc4wmJQpfRsns3Zhu'
        b'E62R/rp2cx1cXeDKZe2y9qj2aPiNaI+y81U8XEk/At+mDJOFyQQD5fpBrsnRwHEp3w8DDi63KYDvq7Yg4PJhbTzwfoUQzvIalldBXsvyESyvhnwky0exfBjko1m+D8uH'
        b'Qz6G5WNZXgP5OJbvy/JayMezfD+Wj4CWhcNaSBD6b1GXR9LeCFTCGNDGsTZrQVoZKAxi0kYUvDuYvmuLEobA27LyaNb7KGFoGy8YJYOLTNAJw1jf+kD54QzWCAYrBvIj'
        b'WT6R5WPFt9tV7eoqWbtcGNUmE0xMLhEPHtDRivRGVYUJSYKe1RgHNSSzGlJYDX0FGaMOqSD7VDLS+Wh0uC7on3RXPBHR6Yle6ZPbQYD1ySk6hsK+gkpVEALQdRPpX+0F'
        b'lIiIQlQYHUBpYv2+6JFVkRJxUTGRSg3ERcWIi5oRFNV6dUnQtUhcPv47YHanJtJ/2XV2t93qsK+hxzlqbDqr1CE7sDVrXSU9D9L1lakNVqe1Vkc7N1U32w5vOdmr2Rnp'
        b'Bbp6p86qG2t0exocNqiEPaiqd9bq6qu6VUT/2cT3k+jLBl1GdqaeVpGUnplZWFZQai4oy8+YXQwP0gtyzZmFs2brTSGrKQUwDqvbDVU12h0OXYVNV1lftxIWvk2gx1Ro'
        b'MyrrnUBSGurrBHtddchaWA+sHnd9rdVtr7Q6HKtNuvQ68bbdpWOGcagP+qNbCWMmAGPr3hxpeOisT2Xtolf+Qzf+4QWlBphXjy9LXFp8X8rAGJUUGseNmThRl55XlJWu'
        b'G6vvUmvIPomQdEn1DfT8jtURYgD9QKE7EkS4Ct3iJ6nHz5vFuvy5f70+kSeLtYnX/0Jd3Sz33U2u2gIPZRn48mhyAeTyNoOJHofJXUCac9nBnaFleCM+JcevPYuviYb7'
        b'ip1oEIcSMiZZ6gqmxSIP3W6Kxg9LmZmyiDTTUzmppAWuCkvEWsqy8JVa0pZVkJ+fnc8hehQmjNwmp8hOVuPjRGqdQuj7oy2Of06Lk45IHCl5lu5ap0AFoB/OywoI5lPI'
        b'q3KyV48vopJ0FTmYh0+wWuoq2YZC0g/UlrxNK7SiUeXmEHHroTjdkvc3bp1YdVjE4I6ap+Ed9EQTPbkDrU0tziLb85RoLjmrJNcK8OuiH/hdfAi3u1ZQv/FdaHI23q7D'
        b'O+2/N/+Bd30XHn+c9+3EXc/UkbToWd9effAXv8784fVYXdszx0fMLtj93SvceV3FG/yS9/X/O8ox5050/ZFhH72m+KlBtXDyl0J81OOE9SMPCesjXv355mPjH3xw79eO'
        b'aR8uXnNsybQPJ/2HanV4edKcP/904g+/5CJ+mz5/X+KD04uMP/1x+te1t1t/0nfNL38x47nnDsy+N3vSuHVrr99Jff3Gmx8ZEjd8e90vqmLXTvyj5jtXjEueqZl4VnY0'
        b'd4bm3YHvcAd+tKXi9v7K/33ZGWX93RvPvHvSeTQv2Zjq+WTCO9n//EvUrmFzP750VR/D9JnnE8kVDYyQPt9jTCbbU3nUF3vlk8mLarKZ7GJFBmAvfiXYbwHvw3tE34WF'
        b'5AozyTSQ08m5ppx8QzZuI7vE41ED8E2yD9+S11nIaSawKch1bccuLj+ZnDSCgned+SeoYvFrgZ0wfw19yRZZBDlB7iqw6AaBz8EUHezihqmTz1EsBUXzjJuKaHjbM4Bw'
        b'rdRJL4XQo1fSVmuuMbkaerRTdHuYi6+p8K7+Wqaq6lPwFtFewXAiPUYzjyc7B5N29lReQ/biVn+TFOQIx40ir/aBPjGvi119B+LWeHJTfFdGjnJ4Jz5MbopeowfxNnKe'
        b'vi0uMgV5lYeW3uPIbnKW6bpjpsg6KaP4Dj6PokAZJW0L3JSZkpfJLrwNtEnSpmcn5sQh1uDjYpUp+IaCbJ01jzliQ893k/2g/h7C+6DSPA4adJzDu/HFFUztToWhOAeP'
        b'j+YVmvJpa29z+Ci+HMG6UrwEX6JNzacuJIZsxfCVKLJaNjWhkT3V4kvToaWSqEc3ziIzZXOGkkusGxqyeyp91wAjTb2VZ+EjKBJfkM3aQM77d9Yi/23jWldxHuRkO3B4'
        b'SRPOkiR59Ri56L7NU5uZHDRiLR8POXaPacfR8Kvs8sNzvP/6n+FK0ApF6mvygxAl5zBRDZhBk5nIr+x2kbs7lIQn1u71KrGSvp1rZ3WaAhUzyZwaoYYGqxijPg6hYnRr'
        b'/xNrihepVkvFnx71xIV+PbEDil93fpRYGpCVKBcDucLPxpKcNqtgrK9zrNabAIZMqK98GuVebq6wV/bYpMX+Jj0aSRsAklav8J9uMJiI2xPkpQHIKb2LQ0/fAGoPcKYg'
        b'v4IZArg1ANwULEv9O/DDJfjLOGYX5Qr0PKwzq6iwikjaU2sEv1VFLQ1Gb5LWv9oYZ2FgYfTUjmo6KkV0VFKfREZ7+pZUBbVE31tLlgVaYvxm+e5fQY+LnNiKnhpQG0CQ'
        b'tFKmtADsYJueTppYnYMdhO+xDf83RqAtetmjU92E10yqeLh09i7r1WWz1bJD+KDtMH2k24v0YL6khJWA0gO9m+1x1uuKrKtrbXVuly4detNdVk6CLkPH4cWVE01jTWn6'
        b'3qVp+k+BulvnS/UcO4SWTM6Ql1PYCR1yxiSfyeGXJuM99owvj8tc1OFrf9nYzy3vVWRZk2xJMd7PP7W8U/EbyPMVv4x7K+7c0l9GvrVKqds1jHlAET5s1D8f6uWMl4+c'
        b'uWHN2GCeKjJUkMTOMX+WXHx7CUhMlqndZSZyd0mGeDBrK96Pd/nPq5NNeK+MnVdfTk4ybwY7vroulwkuZtLCL+VSyZa03uxnKmqw8h+cEp2l0IbwlfHAfdZE+XmBVEZ8'
        b'bULXyjpsZQsgaehkK9sd0iDcuVqQJmZC8W9wg6K2BOTlntoNimKotxtClNjcov3A43DbQXuWyLzHJanLLP6E22mtc1mD4khUrO5WEa1jKrOmTLXkQxmoCv5Yq21Oyzco'
        b'dfRfd3Op5Ecjq9ipLZNN5lGaxfRG2XDkof535DR5NadHXQ3fGcLUtS662sxVdsc/4hXMtfDVP6R/bskBvDXE/NryqWVZ1W+EX1vkH+h3/NAwOyNRq5+5MrbozLSLTVNe'
        b'HLOV4q8MjfpC0zi3Us8zkTCVeGM6KxZ15D7VLdTKyaJke0OJX+om2IpSLdleJgq2S8kByYPqm7ZUXTa32T8/jGUzJI2WkBTEQlEoBNFvTX8/TnV7xw+LyVwUz3p302Il'
        b'TAGMpifU1gRjdMy2EBjdM/QnIvs1olgS2aXhPXGAbQEOwFjQk2KwyX+ajCpuPTuMMYcb5mxDLY8Bh5sndRer0ss+BiWlu+EusOLqnfZqe53VDW20Cz1xzjpbo0TPx5jG'
        b'hDCP9GwTEkTDC+u+3ycUAJl0xbYVHrtTGh0BrirdOsFWYXe7Qtqh6HqHFrjqa/1SmB3YqdXhqmcViFWLA1xlc7p6tlJ5KsUWZWZkA6O2r/DQ+kB2SaJMWef0twpgZbut'
        b'lE1/M9no7sWpLvDQicOX3XhHbgHdoWcRKgqM87ICPqjFpDlvnqomS1asxxezdUsrnM719qVhKKM6qtaMr4nOzK8lju1kuzHlOHGTvwLqw7u/DDjYfm4FuaVegPeSrWzX'
        b'gLzyHL5Nbmi5CnyVBnlB+EV8Cu/1UM2GBlDJd0V65mfRndUy0myYzzwHWvHF0iyDuYFC2pGdR7ZzQLHO6FfhAyPJuVIegdZ7R1uEj+HNHiox83jzmOCWNagqA3UWLTDO'
        b'V6GiDUp8Bm8kV+0lD9+UuxrgJcdgs/G9+9S/cPa8Dbjwz+Pz3pBrMRp/YHdSmGHmkbfjr+rnn7hmGPpc5vlhOyJ/smbL/tsrqz95c3Rm3epPY6LfnL3vzfVRo3bvvL78'
        b'5Tl3fm7KH7qz6fkvDXfCfxrz9ge/V/z59//8f0vS131/TuyE/9SMPDYUY7M+jG0XN+AtNChF/kx8SNK8kaaOJ0dnm9yJbJDh+SFNMmkTI+Z4jPg43iZS1KH4hpy8Mhhf'
        b'Z9viBiM+1GFfGUy28kbcOlY0ROwiG3ETDaJzaGFg31sbLetLLpHzTJwgN6aQC5Rek0v4amdjkBo3j2Lmg2dd+Ggg+A0IEqWJkN+PbzEQ1aPx7RRTNmnB1zpbZ5aSK4tF'
        b'aQSmDt9g5g7JMkGOgoSyez3eyEwM5PoY0gaP/aYJ8gK+jY86yauSK+ITedZQotpBNPxHbId3sIFYJSeyAq3EEMScshtj6FSLvwmM2AcIY2/cQRZUrINFLIWkhfN7YG6i'
        b'P3F//SYm0aklT6EbgNIMJK5H1nAywBrGMG2tg/71pqI8pQatZ63w9Ky6nwm04pmQhC+zLLPrVkCI9lCnplqnrcqndNmr62yCLwxItsfpBEVgTqU8qK3UMq71U8QckX11'
        b'xOpCXo3k2qOt0krMTN6sAGamAGYmZ8xMwRiYfL2iJOhalB0/PtwrMxPjlIlyH+MLwQpPz3tRtF8iV/C/Gzi10PO2AhsF8S32CowgvWelap9Jl2mto3qVVXpWsQz4W0jG'
        b'Rne8gNeUFE6emDaG7XXRfSiBqrKgcvUIPjD4U3VzHNZqXWONTdpJgw7TPneU8HeqJ/B19e4QYJw26Eida6ouvatAbZG68wScsbteF17AwjDhOwvxyc6ckTTTABVN5ASl'
        b'0GVZcLtYYpbc2Bi8D+8jN3LJjRyUSM5EkiOVuN3zDFQUsUqWazIm5wDJFWsQ3w7UnJVTliSFzQAhnJydhC8P1pILuA3fYZJ9SWpW9N9kLJxCzjMmA/JQ3dtF9mgDgj3e'
        b'Q7Z0Eu6NOfklwYJ9a0kYeUhaRjOWvxAYwV3SysowE3k25acp6y2UywbvwWQZcvJM2cZkJSKteu0K/CLZxFg+b8D3GGNdP95fmPaIgk4Csg7yu0FvzFGgNeR8GIjzF/Fp'
        b'vYydQc1fRC4ywDIkH+CezuFLjdM9lAgC69+PL6SIL+dTV6/9xeQw/3ydjAU4w1syAFpOvjSKHIo15YyWkaPkMDlt/2rVXhkLmJI4Nmvwd1MiSVq0/P3nNnxi1JhMEcbf'
        b'9V2zMTp3z6Db3w5bdv31zE3rPno5XznNPmfERfS2Ztz8f544U7Fq8CLDKy9VvXSwaMz/++iPXzl/mK+p8L54YOiy9Udi9y6e8Fp23EtfntXP+V/999aqLqn7xjhONtW9'
        b'frNfVZS7rfw3utydMxb/5e0HO/rVZ7099NmvklPVXwFPZ7GiTgPrAj1rZ54GX+MQX8GNiSfN7uGMy+HtMyg7n4G3+Dl6MDcfXsikgrX4SC1MMsOYtWSLXyioxZfYXsoI'
        b'JbDz7PxkELR4pLan4FYeb5owg3HiweRWWZctHR6/Rhk5T+4wvX8V8QpSXL7FeDc9xrCQZ1Bhng+Qh3TjhHrU4iODkNLBD8e78GHxFOlFvI1sZa63hWLQFgNMCL6CN6fK'
        b'yP5Z+DjT/MgBfLY6eCeB7iMMwpemkn2NIh/V/h9tAGgod5ToB+PzpgCfV46n4TTUAS4fLv1q2QEdnln8w79SKtbEBnNaqS6xlUqRbws0sdGkqjPLD3s6z2C5WFNVQCCw'
        b'BfhgDSTnO0sFw/8nhFQQqq1Pw4nVgQ72xI3fCXDjYZR1AGFljCTAeYIthHo59Ve6yBdA1XP08U5Km5zU9OCk5gPqpijUV5rNbMfCScO3sZ0Nn4wa8mfSbIjNE5/Kb2qm'
        b'5iGmUfsiOmu6VIQKkq1q2FudJq7P/9FOU09456ShnvrT+VqPqLVbzsfJlZz8MQ9zNeQxP1HJAgnxsn/tb6RcGx7D8eFiOKJweRzHx3cuESPXcfxQhsFfs7CUwvBUF7k1'
        b'IK9A3EjkUPgaHmT9loHdWF649Nf1dRdPLIEvlwuycoUdlSsFebkKftWCojxMUJaHC6pyTbuiXd0e3c5VydqjBXUbLxSCoKTxRlfJmD819S/S2iIEjaBl3laRbXx5JOSj'
        b'WD6a5aMg34flY1g+uj3S1kcMVQQCGHUBivL2qVILsUIc9ZiCGmPaIwFutNC3jfl+s3J9qqgPVj+pRCzUSb2vqId3HJSh3lgDhIFb1OV9oW2cMEgYDNfxwhBh6BZU3o95'
        b'V6HyBGG4MAL+9pfeGCkkQqkBwihhNNwdyDymUPkgIVlIgb+DvUqoySAYocwQL4Jrk5AK10OFNGEMPNexe2OFcXBvmDBemAD3hks1TxQmwd0RwmRhCtwdKd2dKjwDdxOl'
        b'3DThWciNknLThRmQGy3lZgrpkEtiEDKETLjWs+tZwmy4TmbXc4S5cJ3iDYPrLCEbrg1eNVznCLlwbRSKJOuMTMgXCraElZsEOVMR5vmU6bXM7eulTrISXfjiA9HzS4yA'
        b'C2IgjUVY7bRS+U8U3ipXBxyRurj7dPYjc0IFtTa3vVJH3RWtoo20UpRB4QYVK6FO0cziWK2rrxMFxVCCnJ73Kc0rrQ6PzRdm9rfCJ5tdVlzwaFqN290wNTW1sbHRZKus'
        b'MNk8zvoGK/xJdbmtblcqzVetAuG548ooWO2O1aZVtQ690ifLzCvyybLK5vhk2bOKfbKcokU+WW7xAp+sbO7CORd5n0IErPbD7WQY67RHspbSXt6loPR3Hd/MreWbOIFb'
        b'LnNFreVPcCeRq6+bF/i1fDyiMY2b+bWAzOs4QbaWW4mcxrUcdXGEt7gTMhoJWVD2h3IJKA5NQuu4Ojk8V9GrZkTfW4vMcqhVcRKovVkpqNmmadjH5lC6SFePOGmeOxzi'
        b'ur7Qk4TPRkLUL6xiHexOL5YtccimMp+zkkLj+LFjJgWjkQBqSXYVFfd1rgZbpb3KbhMMIZUCu5uqEMAC/b5vDLJfRxRRFrQUp73C04NaMZU+nmoRbFVW4C0BNLKAnmKv'
        b'rKG128VxAmSU4ACCde/bZ3TOH/W117ENqo7ejE50jfZxJh+X9hllGp89hn+PZKa0tAK9yhfdFSzdVrE6GmqsvvD5tCeznc56p0/hanDY3U56xMOn8DTAMnG6EbMrMOGB'
        b'ch7nBtTraXfGeX/CSV688nAlFydZPHScmg8H+WhNlIgAT+8moOdY03oUJP4ScBLwgwj4CBi7Ig2butUNNp0FpqQSWL3DNEv8a7GYnHPQU/i5X+TYKPXYrC8D8s1A5qkQ'
        b'GhG7geP94KIlcHQNL+M1gaMAMjYhPrXVZWbeoT61bVVDfR3otz025R+cFDsyEj2qZL4DntoK0JFhMKRR0DU4rJV0W9bq1jlsVpdbN1Zv0pW5bAzRKzx2h9tor4NRc8JY'
        b'ChYLxVOrsMwDBWmBzrV039DtfK6JY6EkAqHLA+eaOGbLfyIP/49/F4rklDVQyUwkN7ZVlTXWumqbzsluVVjpBkS9uIcLpay6Bmf9Sjvdn61YTW92q4zu8DbYgHNk0qGF'
        b'zmVY65Yz87vLXQ9yIyMOdU9ECCQi4G+SmTXJQsfXwxa+SGYoPQqY3WF8qeNsiH09GlTe5q6p7+BiBp3LDhRVqoa+Rrfbg91ve+qjVNFUGpZ+qkVisCE2CHu1ilTU19N4'
        b'v7qqYPOLh02F0GUaQpLIRpsTFulK4I7WCuo30IMhppOAyc70o642lcgCD10CyVXkcIoxK9tAdd7cBdREQXZm4WZMQxYVliXlGLKNSlQboyYPEyvEYOp38JEZuLV2HrlK'
        b'bs1LyjHSuMy7UgrwLXKq2EjO8Wj8XEW1E99hMnA5OYFbXab8HLK/sRofV8agKHxQZqoweii9LCWnqoI3BJIKjMm5xmJ/pbkKgEbahGg1vu/GXlYh2bceN7uSpMD2RUYF'
        b'3sVBSw6liJHnL5DW2BLcRtrLSBvZX0bNN5vXqws5chM/IJvnsPDu+CA+SnbSRilQH3xLhg9xeCO+meihzozaCnzElSXaNXLxy3JEbuFjfaDN+LIBtzOH1BVcoiuJBXvC'
        b'r09SrOPIFXwlo9S+Y8QN3vUf8Pxnz/2wb9uzxRlW7ex9vz/4dsm1dW1bP9+4s2/Nb98XvscNeP+DUfYz747de+zIK/f3Pf+7lvmyjLny2m1Hdr77wfWmjfNT2hOmzfZq'
        b'J8VZrub8cN7uP37+9/vz7n08dNnt72Z5uGUvOvp+fubHo1T5Xs/k6ne/d3btxtI590/v/2TIT17ctvWc4ox+VnnqJ3N/5fjbjwbdO/7FX7ZW6QdNqlv8s2VRp9Pv/mby'
        b'1sbYN/+R5f3Oz26++dcPSMxfFw2Y9PKMVV8N/nyw9ufOX34R/tGvZhQfe/jXZxuHxej7MOv/6Giyh4WvIq0qNI08lBs5fAVuXJX2DiaTEylGsp20pGbhfRrSJkPaOTIl'
        b'8Wayt+fgJnwdt6ZCCY5G3LskT+XwDXJeDEDrITvJw5Sc/DwO5ZEd8mEcPkaaxoihhe6OIl5qSclXodkJSjmv7kdeEE8ZvriyMJe1iEPL8XZ5Pw6fqqxhdpAoTV3whoxo'
        b'ZCF3yG3RhFO6mHmrkgPYi3elmPTJfiTCLeRkFLkuW60n+5khZkMMPimaSHBrFosnMSqTbbVULMGnU6S3BuKz8gIOX8UHyEEGPp0jdNnsyjaYcEsqXVO0gnManU5ObgM6'
        b'n3XT4zukJWFgrrjK6ArDbaniEsN7ZyaT1xRk8xrcLtprzk6aJ3Y0m+zIxA9JC4c0Ak83Z0aLY9S8BF/LLTRyCL/Sn1/JpZML+Jbo/roPvz45cMp6rY2dAAXN8zwzdSnJ'
        b'nUG5+bm5+SbSYsj1x3Igl8cn450K/Ap+0If1lZxXmUlrAb5iUCJykRyQz+Lw61nk+lO4T/4rxyj7itTQ3JkBMDPSTErNNog/4ZHRkgGJupXGMddROXMrpcakSE50NhXv'
        b'UodT+pffKOfWDJLknpBg/Aex2InJf8VhlBNfZdJEOySPqTRBZ1M0H6FNA0KEoOq9TVAnFSh7dq1h4WFYADKQErig8DA8+0DJE0UZ+vj7oWSETJHJSad0RNGQCjPAcyjf'
        b'CkhnkqhA5QaXJPB3Z0nSvkIXWaOLZBFakujO4Eq7Sy1Wyhk7MXI/X62nDJ9uqqymIkn3llkra8TN+1pbbb1zNdsDqvI4Rd7sYh+o+WYm31Wf6izHBjk6uq3OalBe/CV7'
        b'3UWpC2yjiBji30XxC1NUBLK5gjX/b5AFQp9qV4sOSy8oaVQPlJQ2f8fQu5HF4hmObTE0zAncLPi6cbamSrz57qLb6GeGvwJKzlyR0Cc3mu0lTB49efA0V0QEjziyEwFT'
        b'PEk2sq9e4E0LyLUgmsekCv9mDWO0E/Ed4LWl1AdgAVBKugVjCPgUAHFaMyR66nB81T5/t1HuugBVrn/4h/w28Xj9374bGc0Pzpg1bfPwXSdOZ+duNQz7+LsZpQe3jX87'
        b'9TfHK45uqyuWr5xwqWxn1pdXr/tUqyOP+focXr35SE3MqJgtJXWXixwx0/Bu+56fffr2rrOV9eRE/pKz12ujGs5NnPhy7AX3j0uHvvCXUUvCw5bGffe/2pbn+CrPTQrL'
        b'XXHx7T4//NWyn7Zfev6K6fHhH1UefPbju8aonJY/he89OG5Xze/Nnk8m1rZ/oI8UAwm1IXLJ7wSgwO00bBpIIZcZEzXg6+QcaavODRI6oubLHPhiA+MYIJuctnVnGeTU'
        b'AiUSWYZhmBhn6yB5Wfcc3t0RJYkrwy+vYcxp/qCcrjR/DfYqkEjzyc4VYg17lPgu5XwTyV4pkhLIVg/ZJsTqKeNLgW/6o3TJkQZf58mlRnxDZBcXOHyCBlICZr8nXwqk'
        b'tAifZAwpE58hL4iMExjmUaiack49eY0dU6mKwHtBhGjrxjwZ56wc4TYyvgkC5i0mqmZD+/GVZXhX0IjwdAOHM6eqAdINC2vRc+R10prCdlwUwPQu1S/jh5AXyQMxMNQm'
        b'rkDajfHg+8FuFeRyMSvxPL4zl9yLTjHkg3wqxb+PwvtkTvwiuRbqrP2TcjiVpDswnjY2iKepJ1JuppSOR8RzMYxv0eAhkYyvie4RkdQlIlLiGFJVnRzkNnRmXr1EEeHF'
        b'sh1+EAcgSeK7sKz474dgWV0a0E01p4SGqeY00ABVzeGXGtEiBM7Nw7WsiYuHAgIfnGOhnh7xifZH8kTT2CroEG2fT2uuqzdLarPLJ7NWuEQ7SwgV3hdtDuyGi/bIHF46'
        b'Tq7lYRT5Nf38ppUu5boZDQPb0DQqXjP7KkUT7xyxlmN9QctlTh3tk7PvWu4E7QM6ya3j6jRumcCtZXlaskommhLhWk6/bMHsIXzBo9EB3llrd0EzKmsY10kEok+tVEx1'
        b'phcwe2wIYu21DQ57pd1tFgfcZa+vY7PlCytd3SDaptigSIYon4KxaJ9atOzWO3twHY40NzipV7DNzMrPo4NFA4iGM9+bSBoyj1OCyMKOx0sD1+mNkBPPho2FX6W2UBgK'
        b'ag1dxlXx0iTDAMSItSXRThrErjrXBSY1snMr1WYzwHSazUt4yTgTF2wjE5/1jIIxrCV+JAxuhYqiGYx6EOgu+KQy01gAZnaYiZ2iiO7AfelRJ8mMXsv9gBMY7p8ATBC4'
        b'k/w6NghrueWivyiA56Zd5J0nkWQ3hGu2Eo+HaIbSbHa4zeYK2gpaPRVt10QE2kGfPXUzOH8z+GnPOilTdV7sAbLNbK6CO85LcCMYqi0E1MD8m4KXTR//gljO10eL8Jdx'
        b'y6mxit2nV8yFVpwI2o4eEBaaY1thNi/jJVf3cCbl84/D+aCG0RLdGhYwFmrZcFCgWr+hUATQQ/froJsN/unvNOx1oQbgm4ZdHpj96b2OejXMqSvEqFf/K3OtCMz19N7n'
        b'GrQOc2MoqLYQKyzg+k6H1L/SA4fDgoh09/VMDWFmM/02kvMqCjJH+5906mEnqXVkyB72o/s5iBFevon3k1ku5aKsY4ExUuqPGXI8cLdL42DFWwXBbF5Pp5wxDhaHMWjV'
        b's8chET8Iv2gDT3Id9u9Xexp0StxYjU0hBsPZHdYTDEZC18EQ8c3ovEuh3gvdaZenwmzeRttwn7YhiMjRBz13N5I1QdPRYbagXuutu6zGVj8t13ai5d2hyVAQVaHqdYCq'
        b'qNyIURDIx3XtMjsNJvNFFtS7s4F32ujhI5vQgQdsGHo6UGM213oACXfy0lZGODug2gkJWIEnRgIxMJET9zYqrMb2UEjQHVYnJJgcPCbR3dFhYGCUBnYdpWqGGKkdiNHD'
        b'iGjMZrfTYxPsK83mg3RhdNDecBAR1sQEGhso9q+3d0CgvQNCtpdP/eYGa4FlOerrnawpx+mgvkUHNTbQzo6n/3pD4wMNje+OfnRgE7+xnSoWSshsPh9oYhCK1Xdd+/Lg'
        b'1nWSS/sEt85N20c3r6ElHddL+HX8OpnUSlkTba9MvKryE0yfEkYEwILkzajmf6Jg0ulXMCjp9Ckaa+odNurQW2u11wm2niTMcLNZrNNsfoWXyEU4U2SiearayB+v6RPo'
        b'sb9kz1IlleVETqNhQx9Y6z1LjywwW7XZfJcO8bnOQ8wePAm08A5o1d8EraHeZTbfDwGNPegZWhyD5hYhcV0omfNIp7noCTYoR2bzA7+0EtOJbVWEgt4TD2djeqsXSPY6'
        b'EES+FSBXHXDYgyeGU9MrnDC2UK1Q4ZsBSNHBa5g+cm5FIeyjgXVCPWzpyliOnGo3aJzMtYMTZIKcso1+0Ix1dEVQLY5v5k+Ka0RaGWy6FQWf0UofDWcbuva6al1DfaO4'
        b'JTwmTXSN8DQ01NO4P4/4NJOPGwMrZbt/unzqFR5rndu+xha8iHwqqKna7gZ91raqwa+69WgzgHFgwM3mt/2Sr5qFIaVfwgsaEanQRcZt6LDoU7s4ADodUn0uR72bBhZr'
        b'pvnIzjZnyFdV2Srd9pVidGogpw6ry20WLao+udnjdDhp1GjnMZp0uBIG8NOnDijsGmbCFLdPmVGcKa7OozRhVOY0Tc7S5CWaXKEJDWjqfIUm12lCP17ivE0TJke9TpOH'
        b'NHmDJoytEprQ7TfnOzT5Nk1ofBjnf9HkfZp8QJOPaPI9mvzIP8b6mP9/XBO7+H2sgOQ9uiFAfSHUSC6TK+S8nOv4iebjOL5vD36ICp4bwvGj1VwCx+vCuUilVqOWwY88'
        b'Uq5W0r9auVamVtDfSJlaGSmLVNMfbZhWJv7Ey0TP7lcn9nORHaQtFZ8iXuaXqE7gPbiF7zns6/90cUv0B1qtkrOwr2oW8o2FfaWB36SQbyzEqxDG8ioWAk7BQsCppJBv'
        b'WpaPYPkwFgJOwULAqaSQb9Es34flNSwEnIKFgFNJId/iWL4vy0ewEHAKFgJOxZwcFUICy/dneRrmbQDLD2T5aMgPYvnBLE/Dug1h+aEsT8O66Vh+GMvHsrBvChb2jebj'
        b'WNg3BQv7RvN9IT+K5UezfDzkk1hez/L9WJA3BQvyRvMJkDewvJHl+0PexPKpLD8A8mksP4blB0J+LMuPY/lBkB/P8hNYfjDkJ7L8JJYXHSKpeyN1iKSOjahcx1waUfkw'
        b'5syIyocLMxnbT/dF0SMwpR3nTD++2nU3yH8cM6iQFH+uSzHqVME8PCqtdZQyVtgkLza3ne3F+P0wWJAzv38bdcUQNz1snbdnpE2hzq4XVCUKOhRroXTYKp7iEeorPVTQ'
        b'D9TcqbZ6p79Cu1u0iomv+vdYMtPzS2dJNVh6cL7rlMmukvxIrLoKZsOD6sStseBDuwYRpL+vkoOl22mjA9KpPquL+XPSxjHvjpVQk9Xh0HmofOVYTTlPp9PAnV7uxHGp'
        b'3kppDvWJcJVzlAE61ZQJ9kfNvIdzav2M0M2Mlye5dTIBmJ5ZTOUsVbBUyVIVS9UsDWNpOIid9K+G5bQsjWBppCCDNIpdR7O0D0tjWBrL0jiW9mVpPEv7sTSBpf1ZOoCl'
        b'A1k6iKWDWTqEpUOBfcvMOoGDdBi7M3wtf2LESTQLPZcCoq58nWKt/ASs0ZOca4sA1/3QOnmdlt1TnuScuwUVsPjEtXJqD1wnd48Cli9v4l1H3aMF9Vq5aLZ1J9G7axVN'
        b'Mg6tWNkM/VoW2QxSoOulHLQZIIs+nQXO/6biwQQR8bstk94XAuMPc3yc2cebzY8U5kRXoutRYtdKaqzU56nDbUq0mOp92mLg+/ZayTlRKe4OilFIZWa74FOYPTa3k4aK'
        b'EY8o+KLEAOeBo2rOWZQz0V06J9UnnDRCmxi8ZDGTCzqfcgS5T9wGhhobPE6QZ20AgskEKmZGd1t9SnOtq5qBXk5P/inMNvEPOwcY4X+NfZcMXqqsoVuYLAqu1e1xgWDi'
        b'tFH7ttVB4x3VVdVDi9m42qvslcxFGWQRkVYEHltr3R0d8sWZHfWVVkfng/g0CnEN3Xh1QfvYWoVq2F8xOrFvkLnLkIMcC+tQKquA61qXLxwa6XS7qOM1k6p8KpgXOie+'
        b'yHT/zIgzoXLZ3PSBXik6BFAjgk+5vJF+/j0ojMF69M0xFNhs/pRKfeWImp/VIcJkqbvd6fGHp2m0FJQ+klk1IiEv59b06zICTx3sGUTOPyLUs5dnDGg6ovNpQldQAS/U'
        b'aaXMkaBuecdpSoMYEMFdL51ApU6AApBoe9VqILxBBPEpnFKZ1pHZW2P7+hv7aFTn4Fl017223t1x7JXFEX2Ks7fOrN7gJgTgdo6Z1R0sDVz6ZFCZxprbG9SBnXsbHC+r'
        b'C1gpiuiTw+01VNaQAFx9iFBZ/wZoNtClvYEeFgD9/9J1YuxYl6dCOlrBHM4pPMn3RYrH1Gu7mJAkVsR2FKlM0wCvUXmEhakJEeHJpCvpuFdlt1GAkoAAtUOBDs+YAO13'
        b'6ZKlcUo2wKXdzf7642kls73DZDGoVfJTDFZ5b4OVFBis8d3jlfSAn+kZC9JTIZn9FJGzgIR80Vs7UgLtmNbpcDwNB2Kr6HxMvmt7Motnz0qdNTuj9KnOyTv/1Ft7TIH2'
        b'FLPZD2LZkr+U34m+iyOPSTeLxS0R3ZYcjdbVLul0uK7OVm2lmvdTjdqfe2vl2EArk/2o7ndGCmqwxJl1SSXzF5Q/3Rj9pTfoEwLQRzPiXl+/nEqy4hl3EHAbGurpESYQ'
        b'iTziqfgnA10jgv5rb6AnB0BHlQZOpDw5CGls/9YbiGc6U7BaWLPWalsQGjbUrHZRhzRdUXp2AaxxxxMClzbRvuwN+PTOQ9sB1FFf3RmmLim3ePacJ5xVaWj/3hvo9ABo'
        b'0RmvTjC6643wp4Nx65JmPx1M6O6j3mDOCsAcHDLugi4p/6k7+Y/eAM4NABwmehyCSFhHz25IS0WMhVFUVlz0FJwYgP6zN6A5AaAxjMYxCVk6hvJUMQgf9wYlv4MmdKVc'
        b'VK6mvjH0OimjsDA3u2Bu6eyFT0o3pYGlz3qEXhSA/vuu0DtL+ybdHKARc23QnjomF7oCKneoeO9AvBZkzymlUdsNurnzMw26ouLs/PSCwtJ0g472IXf2Ir2B+drMoShT'
        b'I9XZU22zCvNhBYnVzUnPz85bJF6XlGUEZ0uL0wtK0jNLswtZWYDAzACNdhd1PG1wWGkUKjE2x9MMIdfbEM4PDOHwIKIuqkYiYlrZYrS6YBSfhph/1RvaLApAndh14kQN'
        b'zqRL7zg+ll0wpxCmYFbBXErpKSo9FeH9ureWLAm0pF8p4/ai2ghTKFDcqX8KQRHWiqK3oTZ30Hgpbgo7jygCsnWYf4J1kacZcb434BWdiV4HsaOe2DpqswrBVPw+IWwD'
        b'ZL4E0DWaOaxp2YYg84RqiKTX4olVuuEBv/ImSM20vII5uLGzsmaWnlBCqjoJWNkxTY+eKRa9lanlKiDjiCJXhw0ttEhm0qudf6DdrKVJl+jNzAZBAw046xHbPe0I8dxl'
        b'j0hDP9smVWmTSVuMSj6BfW6J6rhKbs3Argpn0Ds9zxS1ogmctO1cKoIMNU10Y6JeJu25gSbdTb0NeLX0eIIxQZojp4pu5J5EdOO2umMnDvqv4ugnoahRIqSjmloyWJjp'
        b'h8hYy8WIWqEaIxbsud9xQY0Rg+sKfmcxZuryt0Yh6iE9+M05bHVmc2Nwa0IbGVi5Av2IUBtVzPjBtpZ8kV0MVzMCmNOBNHV+fPFFdLZbKSWzlUri3OxTvj6lZLJSiBYr'
        b'OTNYyam9igUF8Wk7GauUkq1KzuxOkV2sUppgo5RSsmapO4xZoiEpsrOxymngJPRxptKrMZw0iE8UVs35v5B8QC1D30fihlKMhh/7lOEtVD3cl/974TJ6/Kt8snJauTpc'
        b'LdMqPCwm6RFyA7dqVkY0aPU5ZEdKQZ6JtJCN5LL42YDkGgW+SprJoZBBFuk/1yoUvIEl8FsQ+1KhTJAHvlSokK6V7KuF4rVKUAlqKKv28lWc+IXC8jAxmkZ5OAtly9Oo'
        b'GnBXw0pECdFwrRX6CDFQIkKIZbQjzhfbBevz7KCsy4MaKg+mBfSUGqXHZuaqYeboZrSZr6ZxBGRCQDyQM9XAFxb4hDBc1tYLVgf9aNzwruZMCtEcvG3i8ntzTObYbq2/'
        b'ErW/jq5Ejm7ybpRJ/Es0JoZzawaFgPN0x9aZo8HA3jjgtoDdMCS0p/pCnCRZzeoNntcP72l4+OzeamzuscbApFO3CL/rRwfRN9Fa5/RYNTzYTqu+2uPg9Ejse/LHkDSU'
        b'DpiduS0jUW0BmF35qgSTkfT/G766m8Iycj33T+KsXd33A1419LtWfjcpV5gbAEsO+cyJa7nMNQCumUsUu6ZX8uUy5xC3Qtwhg7zyhIr68XHstJR4SMEYLPnW0rP9FR0B'
        b'E0Z3aenozsWFept4gl10/GdxXPzH4xibALnoRSQtTfGj83PpVRZNmF8JnR3gaQ0NoG/7Pf41QSBY0R4csmRWQdjnF5PCpUMl4cyZpBt3ZkMM5XvGnnAJewK4EzSbXTAn'
        b'DV58QSY5fYJg0j8UsNASWcCtMo6tEpGCr0WzUJN/tcgKusm/gZfoSQRKPZ9T0iMYVKDZw69grj0ir+Wd4+nIrhev6Xrwce6uuBgFyQl/6+PQGmOo1rvr3VYHECS6AeWa'
        b'DheUztfXNkzXcz6Zy1MbUlRSsLeOUzz/kK6pkOPCyhToI7sKSR2uNwxZOvCkQ55g4kU+J82AsyggY/QSoiQTCq2TSWOnRsCJlSw0K6+VqWWRMupUwiL6khfJdfJKgDPH'
        b'r5B4M/BlcoO0GIB+zSJXVHkOfKUbc46X/rrauU7MGSaX/cheUJTLqFcJ9SmhnxIUwinrpR8NFCIpqxX6vBBZTj8frAA2HCPEAutVsEOwahqyyhvj7V+lEuKEvnBfaVOx'
        b'8FTiJ4dVQgK9FvoLA5jviUoYyPKDWD4c8oNZfgjLayA/lOV1LK+F/DCWH87yEZAfwfIjWT4S8oksP4rlo8QWVcmE0UIStCUank+xI1t0EzrD7eTKo+F5DPRALyTD0z7Q'
        b'G05IEQxwHcOujYIJrmPDUoWpUlguGgyk49OLkdDbaNbfWG+ct6833tvPm1DVl4XBCiuPa1e1xwtj2zjhGQoHxkTGgmHR0GB96WcKhYniM4A0SZjM7scL49iimubTUlz0'
        b'+0T4uCIfV6hX+Pi5GT4+e7aPn10Cf0t9fGaWT5Yxt8Anm5Wb65PNzSjyybJL4CqrGJLMrDk+WUEhXBXlQZHiQkhKZtMH5bnOVYwkzc0u0kf6+Iy5Pn5WrrOUUjc+G+rO'
        b'Kvbxedk+vqDQxxfl+fhi+Fsy27mQFcgshwJl0JjsTkvfHwmduT5Inx0QI23JA3HQ5U8UBz3k11G7x+2WF3jm0huWWLoO3OTWZNJSaCJt+TS8aEdQURbK05TNDhPmGbLz'
        b'52XB+sihBzLpV1Knk81R+CbePdx+7KNi3kUDbTxQ1Hxu+bUlyZb08yRrltVR5agwWJe88b1v3dw95tCm3dw4Gaq+pPxsyzq9jMWKxifwdnxGgy+OxrsMWf74B33IqzJ8'
        b'Bb/YX4wkeaRwDGktJNtz8smdkSb6ceij/Cp8Bt9nMQfG9VGIX2lOTOr0kWZ8ijz0nzH85s1q3k+p/QcbpeONk1mY/7hglOr88WNFx2a5k34MOPSHXYFusRKjAsUCkK/L'
        b'/FGlNwX/xLwb4gRjyHZUqoOmmgLu/HlMNcOkcOkr4+LyEyPzdHweU90cBtgVBtilZtgVxjBKvT6sJOg6FHbRvnX/QuCgAvG7ES8nknO5/lCC8/DpgaTZaDTRULUsyiu+'
        b'aMgqK2rEW7LwBRkiOxs0ZDe+V+ChC4CcxLfI6x0vA+IVGudL56xzSBvQ6125C5JIywL1ytQJEQ1yhO/hVzQRjnLx037Psg8ERp+YWqP9+6h+iH1gBV9agM/Qw95Wck06'
        b'7012rGDlf7tIjaIRSnu/qsHxwwEjxK/+AVLtrOscld6YnBNHLrIDz6Vi9PdFJarVz5ErLEiLXYHvkhPZudn5uQbSpueQpoAn5/S1YpiX267ElCx6QJzsG5eGrxjS8BZL'
        b'LhpOg7k8KIn1jIEyS4A33UgpoEeE2/LLgo6WJ5mMSaQ5NZnG4a3H+/ApvZrceJ68xA6xk2vzKnNJa3ZeqhIpxxv78ZHr7Aw5WYz8DX3wvhQ61EZ4ivevwK/yE8nOKZ50'
        b'+uZecg2/lELuk6PiZISCOC+JRWAvShLbhbdmydAQvDUC36mYxOCbPGNcK8l1eRoGVMGHEdk161lWfey0etIKFGJ7x0ciG6BgaRL9zLvBkF8mhtEXT9V3hJwkZ2Rasgsf'
        b'hVGlZ82H6RflSp+1I9vzoBexc8uSZeSYk5xhkYgTyWt4T8egGTvC/Af1gcLg8XaeHCIHEb6FH2om4MvkoSeWVfBKPNk3D67WINxckO8iR1lYnbSCSSAQXGtcSW7ilkZy'
        b'3a1EEQPJ8WE8PjwLXxVR/BK+gI+44Nl8+oGB/4+99wCL6sz+x++9MwwDQxNRUVGxM3SxgmJBUTpKs0UFBRRFQAbEriBKFykKqMFeEFQQQVTE5JxserJJNtVNNqZserLJ'
        b'JtkkxsT/W2aGAQZjsrvf5//8ng0B78y99+3lnPOe8/k4YfHCIDfS92SRZFlGOHWWSyFABbaZC3gklXU2Xonc5kJbgrRMkQeWRjo5kfUv3yMs2pBdAHbBhdlQZybIFmXS'
        b'VUIDJVCowla8osGrG6AkK91iA7YKI9YIA8bLIHcJ5Gc60rG7D2qHYxHlQHFzJ21rItjCATgIhTK4iBfhNBv1Ty/nXJc2ZltDhNVZAutNr/RROt5KyA8hfXceziUN2DhO'
        b'pkkk61b7mNToBdfCZONsvn/zb6O2fvjdpOlVLjPn+VvPmFk653Ci3RNzzddMDurjbdnnlVMnA1M/lv1Tds+h+fDsoG+/aHp367fTzpiLBQeev1czc9Hjk20WpY1Y9+Ko'
        b'Z0/86/LwPQWXDzl+M//Y3bKmmV9+eHvk0fZ+xyYveEu2ufWJ6/NeP/D05wV+g+M9Pjxe+/R3Bb7PLtr3pzfGxxwccenFISWxT91JGzplUU72FyXvbDP/V4qi4Ulh9tiq'
        b'8hFLN6wcsiBeOLno+eGPel0N6mOyavMXKdsbvAMGvD326f7bVsz4aULbbi/nd44kzP+iOW55hZT81ktOpvMmJw/2HvDpwZ8WtCaEfVxdlHF9pG/95Y1PfbzsFVP/S/Pv'
        b'LXjt9SMBn21eaT6vpA5WTnzszQ/v/TLl0tIjvg4tBas9P7MrTsm+ebM2a3tt2P0Pxx97ZFhkwTc5oz4YbWV/KWD88m93frF58jBvq3c17aP9//7hVwOmJ/yaUhv+xY9v'
        b'/PTR0D/Vf/3U/beXF+xYHKoeycL5J87YrqLz0mBfxHNbyNaIZZjLIQEuQHUYHp9FppOO20kFlyQ8jRWwmwEVwHlshHwdiDPsjjZkY9iHZxi+kBdUOEBRlpWlefoIN2zR'
        b'YGuGpUKw2yCLJCkVMHyhHVMGUNweLIYCgQH3tEEZ254nbcYKRuVwnc5wTudA5u4RrOR8EadWT4F6OM5YP4vVmM+KeFHCk7Z4nCWgTKO0mI7TrDdiaxq2ZJKcVQOkNZg7'
        b'lGU8cB0e1MFQjFpIUSim+nG5YP+2KVoCz+VLDEgiliWz90gJjsHxYPdQxYyFgrRZnAb7IhhghNxvMZlzhVgaOoGWV+4tQhNUxzJ8IugYvYXRWJH9pUhgPFbHojPYZnAa'
        b'qpI1Gy02ZOJVayK0FFsrLc2x0XpO4EYyCbE1awMpd6hcAdcGr+LgEpcXrnNxw5IQotAosHXYYhEbYC8c5YhQVVP9sCgALpA5BqcEabs4dzxcZagX2GzTlzJbFEFDQCiW'
        b'jwOy07lTsPNB0CLPwnwtA8bp7fPh6HRGgUGpjopCiNgzU8KDyxZp+bpsdurYQt3cJ0axJaB/iNxyrglrPLKON2AVFHnQ8UWhJq5FxkojoByz+evHXPAAlC8gD2gXMBNB'
        b'FS7hgc2bOb7HIXg0Q0spFk73YpIJ2SEV6/CoMAxPy7HZcyDnWd0PNaQqRXgOcroTkK1awZGfWki2lQxxqySEtNUCzA2UBkDNDjZ+h6wzYQDgbu5hJJ/CkHBGCysKg/CI'
        b'fANkmzIZEDqWkW2mCGuhLLxzH7GKlIWGzmL1icO25BhajnB3NyJJBMvIGCSbwVk868KaYyvpG1KE8CDXQCIXjMYcQTlFWklmzpUMKrLhnjnYQW/jRbxJH4F8LdNqIBmW'
        b'zk4mmA05E1l5bSHbiTwZ5goFHtr13KQ/nCGtctXEBPNWskkhLV3CiqLHTrElq3Ie1MqwaOSYDK38c5xsykXWTDzXy+ZQAKUeVGuFdijp1FtdyN5SMtIcjsIFf8Zd67Vp'
        b'TM93z+AR9j7UYX6IWiGECKZwmdSxlIGVDIOCpYZstwmjO/luu5Ld4sEUNlIdMU/iA4QS3u4bhKX0DQVRkmV4C69BtnHJ+z9P38osCkyCp+Q7XSV4c18lY2yVS/YMs1Qu'
        b'9RftRQtJLmqNA6KNaEPum5PvacCs8r6VjNyR6D1bmUJSSJ2uq/xgrvMT/TtU3NKvm1RuQPNaZ66NnNL5MsupsS2dtl76LKoRqlbFZejdkhWaVWsS1id0R0MxfYjGqFOm'
        b'p4vaRNMz6B+WCMsok35kdnONaNhiV41rHmOeMKJ5GK/j76FdNV2hrV2vgKp6k3nXzH63rTw960F27bv6s2knRmmiC7/gpXPUApV0gad/eB9dLVuOaoXWp2rFA0hzftEX'
        b'xNWYF1aSprNsv5vRU+uIxU6qe8ufKm88/6FRzP2KOl/9YY5bboOn3vGZGamJib3mKtPnyihVydNu5HFHGhDQ6QhGS8Icqv8Y063Tg/pfoS+AM3OMSErUekKsp/4npNUT'
        b'UmgkS/zvz5uf09y2WGEwp3sthpm+GMxNizplrKZAbnqPxj9U830P6nALfZZje0cs7pqxQb5sgdUD+FFDrh4MnhsRBBpds13cYrZNYEYEkRkOhB1ipME1ZzcK65GwMWq5'
        b'3nljJ7DcE8XfyRpLQQPpYmgUprYLu1BXpw+No2ZNamZyPCOQTUhngOKOcavjqKuI0bT0FE2zkxPiqAuV4xwWOkM7WIt/yzwQtdjgWuejJOP4uVrY8NjYqPTMhNhYTm+b'
        b'4Oi8LjUlI3UVpbx1dkxOWpkeRxKnTmY6pN1e6QUzesx2ipCv9T3gqILceW2zgU/Yb+Onx8bOjUvWkBL2xPNjsV5Ct//EHl0uC0v64iVHEw2VxPstOf557NMrlYl3iGSb'
        b'M1NZILaOF9UisxoGDcCTBoIHlzrWTGVyhwIe5YY5sfshkjxxdQIDMPuWhsh3lRKEnYqhW0Z12XY0q5JXsNbtPBuhCfAEKRktPyvqZKGl/Jg2ci3ASdctVci2+KznpspM'
        b'sESAu75V1VVSQ2bO0NcND0IzeawgnCpQ0Aq7p2NFMANRxUa8aulJFPt9/z0W257mZP1BmqE5mRKZ4E1KBWUgQ9LSU3NMQYhzkCucj+KmJfpFeAijlKonAunlSSpvOLc8'
        b'SXr2DbmGrlN1L8//PNb9fUpu7PSRa1wIMyO/PPqL2E9iUxK/iC1cHRRHhsXzglBppxRtm9SyDLqo4V64Oa575obi6w5o0kmwUIlHM0aSl6ANT2C+HoEXazXdOJQCYrhS'
        b'dppoKe1kzEXAja7Djg26jRseytJMhqBGOwT7GxmC5sMp0dBDDEONdhjWyQ0Q/HsnENSBdO3QD9V8MlQH9TZUbe8YGao07mhTys7fNVCHYBUZqC5hdKA2DbacBm1z1RJD'
        b'o4bS2b5sBLsPEuTWIpzFCrzIrE8r8ArWsXeGOwjy8SI0L0pP+mWTk8TW/Me8fD+IX7M6YFUIGRVr3ztncvmvA/9a80p1ZHXkosB/7tr25KC9g560e9075HGLI58KT541'
        b'S7J/X3deamiL7x2zQN/cTJ2gerwkdu8ni3425ubyLf2N9xPvGekB/WGwLReTjrDurSNsPjciiPeS63+BY33Nw819smj77b0j11BV/vbLf/6czNLnV65JtCALt0zQFPf9'
        b'WoK0p8jCTcsRvyW+d5W2izorxxqu0eLxhB492M21g3WVsTXd3KnHiQnz8uhcw3shFKepDu+tW6zeeoiTmZ7eJP8JASbRWJf03EflYVFJ0qAWEw39+pTbyuA43hvysS6u'
        b'otPbYqdw2GOXZCfvvW6ScpceiiB3Zel9V6Tpjep1VzQG02k8h/+btuwphpLhvdtkqaihZpvvLn7mEvcJkUoeeezK/uM14+p2V2c3mwij+sutU3aRbYiZ/Yot4DoWuQZC'
        b'Q6ibJMhnitBCN8UMelwg7Uj+rfEPbb5dLDp4Ga8zM9mU5XbsHOo8VqlD3RSCEm9IUAaVU3vpSI8HzQwr954aPffE7bUjaXpje+3IvzyMzUDv6yv0OLN00DX8WoGdWVJX'
        b'AQumYOicBaS8PkyM6eIykGeSN5CdZQ7KG5znkOigP89U/bHzTAvDgaUfA9PC+PnhnqF4ORiLTFbyo7YBkhXkDecnbVQsXbBxoSodW7DFmp7L0PMiH7gp2MApCa9D6YpM'
        b'6vKyHvbMZsdFAWSLDIcG1xin3g6MErNIL+PeTSoygG44qhVs5+wH57BBg63CPFJu3C9AcQocYXdcLGAvNmcqlhBJDI8KZGgU4ll2AuhD9uVsFbaawD5oIDdbBDgOuV6s'
        b'TliGrW6aDBGvL6Ho/AJJoxwaeXUr4RruU2nkozIo07YA1SSdmsw+5Fagy1BNlvTIIHqCKEBhTAo7TtrmpBCcdpAvHWOTX4kPFtiZKJ7CjkB6jCaH83iF8lkKcNAEdrOS'
        b'BeI5vE5rAwexTFufxZibScffyplwg7VUtwbCxgy8FZOOVyIDXKgVn5+s7Ydqs+3BI1mqI+DCzvG4f7ynXBBJS8RH4S7ShHsZe4fTjNWGJ7pweGoAw5WhZ8zzF+KB8UGR'
        b'pkI0VitIPx4NYseDsH8Unh5PLsbBqZ3kTzbcyLRlXfGoM1KvNA88OE/w2Ii1yT/ev3+/JMZEiB9PGnBmbPLZMdYCo4FNGAzHg/UZYX4AIyMv8QiKdsICUoJIJzWWLgwI'
        b'pEJUcSiTniJovag0q0ixXAZXoYPJYHADayXqnGH4MB1MVO7yCNe2UScXCO7Hc1EspXq4YYGXVXgqM46kYwZVfpbknTJL2OWpNMFd0VirwH1RlnNtBymnESkXbmItXvKH'
        b'E3hq9SazxAEbzLFdkaWEQrNwC2jE3XjKE29uVQ/D/KnueEgBVbPV0Dx9AtbYk3FyEU9n0kBmPAB5eMgEszHbUhinlEGjQ1o0XF6CBxRQgHlwwBly8SaWwr6owUk7yNDe'
        b'NRhurh0xmFS3GPZAa+JWzJWNcyIlKRmGTXP6hkbCSbZ+sPEmSoPEXUvXyAWb2O37JroLbILJ8aCDntLWgM6283DVgNH2Il5VQRuUrgrARpZki3egULlwNGXJNf9kgyhk'
        b'0pCOlHQHWoUaM8HRwoQeXWXHLF8H5dCA1/G4OA5y8PTU8aRPKmLJMGvAQ9Fj8eQSUuZd/aIgJwHyV+MxbDNdA+02m+EynMykthNotsRqLCLyclvPsga4BZnY9qNONlCn'
        b'Jv+TKYb1ZngVmv2j1CI73x0Ht4h0TcYB2TxwX6ArWTTcFPZkgg1Qyj3nQDVzokhPg1PB3Rl6ycAbR2Z5LxS9hWqLJLzyCGPoXT5ilAuZ3w9zRF1nRofqLlI4OgEn4WU4'
        b'SjUDUZBgn7gcr8/GS3iB6bvbiOp+2SWANF5xKJ8LeA4uewQFukVwh5Ae7gcBRHFMowvB/Ai3GEnYHGW9OTM4kwYIkRY8ZMt9AwIXaH1DtEpnQEg4HoUaVmP3BcqN2Log'
        b'ICg0zNUtLJqTGxu4JLCTfSyO6AOnSeGOsYGwto8kPLbIklzFJp/z2Uz2V8bkA3u3zw/WHSEpsVHCUyGQPwRKMqn7QJb9qshwdSiHqo9e2OntUoS5nR4vlLvlPOwi3VuO'
        b'xY84Eh24DU4FDIdbAcPHwyW5QHb8bFuogcPQnMl0z8pU8lUzNlubKclFA5yyxuaMDZmiYKeRhS+HXNbmkJdC+ocuYDKy6jUITmOxIRjqmCMLtsxxDVa7MUU8zBXzBgZG'
        b'O3WVuGXCMkclGcgVMayaqhnTIqEkCksoGZGJs4h7SCkPwakFfM/IwVveqo1WIsnooABnSDPWK5axtXKqAh7FohDRkmw04hQyJuSTWYI750KzzpkHW2NcREG1RMKLkTPY'
        b'3ekiFZlCgvTHx0Xk5zC2C2xjWwAlDuxMlp7HmkObB57Gc6wgIyEHrnAnBxNBPlQcJIcTfQM45dLxSCzTuY2snQXn5YKFjayfc3DmaNYggXDQBUvUDN6fgvPzk1ITAWth'
        b'3xjYZZK4zpshj2HDPFP9wk0ppaulFWQSH3D3Zb4pUDEW8l34pIBCuBRmIlislllDK5zlTXUKOmK0/MhyEToS4CgUpvMSHiELZTkWuWH29jB2pKlYJvWDqr7sxclQ5YtF'
        b'7NxXPklMw3ayFuTacSqoYrKs3gjmBNhDRT84AifJPnqMD4OzcNpbx449XRwTBfVEkzrAXEegYxMe0hY2jAxSOoVNhOFQYeKETWakfy9lMkNKlV8sGbFMi4cCUm812Z1z'
        b'e7RUGGSb4v5NeITli2dJEdrocbyabDZm3pKdCZwenckKHDedjLxm6rDSbCpIeEHciJfcBuDepPpquaQ5QuSnlScd/SOfS+k7zq7FtzRkTM2oF9aVd6xoPz5zc/+mc0+0'
        b'Tm1tvGE3ruzE2ojMhOD8Pq+8cKJfRFZjTdmikR27Jg57rH/dsJdK72wqL3zB91/fXHvqjTcmWduWBZefMk+Q3yg49EXFyT8VBGx9yuratIC3O57+cGxgbVn15oLwnHt/'
        b'XutUnPPr/edfDpo6cuw7qydfshvxzmv7Dn791huFziMPdLxkZTLyR7x6/tEal62uTs9/GHDK9M66L174afjWwP3PtAd97zeoasSX8NyaydZq51ETG08+tf7LhPJ7ZYf3'
        b'7X/n1a8OrJPOnlqeuGlzvG+EzP+5i89PVDl8OyLLKvrMK6lvf9SWkf7K+E/6B/nfmztw5yCN/881R7aZvNt6r+3Jjuiz73pPmp555ptFC5768fafT/p9WOJn3/DXcenr'
        b'YsyO/JS14FOPH78Lut/6/enpbe/eeb+8/uyAl17/+N6wr3cPtD7rY5n0TdTxJ1VfB48edrrKYcjk8PgtZik1J3/6VBH4eVHI0uYb1SW2Jg0bxi9uXOV0+0q6eYrtCM1r'
        b'6c1vNz31TvvsdXsqc2Z/aPFy/f6lNS+8+9Hev++LSRpitez2lOi/pDkcLIyre/O96R/MPTv+4pL0rQ4f+X73QdDARRv/+Vlb+OGEluCvC79c975Pu/WaotYvg+/YD/ln'
        b'qP/CxulTmj7eVLTk0gvhU56496h/3+LBmtLh768ccy1vSNUnW4aPf0P+98WpxcmjhwVWO2999ZPCuskbmz5OvyzNvaxxmqG8XufycXlKU9Gmv8bI21dtlbWrHjH5m+yi'
        b'mLXr88d+/mK4/b+mvzT93s41b/8yfKPPXbPKO8PS89uKBk3aVZqx68fqz/PDM/p9o56X/+dnbyW8U/uXv12bVjFG3lwTPOTOL29kWP5y97kg00+We2hcK1KTilWj91xc'
        b'fMFquflfz25buvCLdz79uuVcx33TwV9bv/XZQPVodmQfDbVwqdPdAq7Z6jwuIHtJBl37dkQ6MqOstFGEJmybBVUrmSOKJZYu0q9fo/CQRx8iwlJ9Zwy2rO3Cru4PZdwx'
        b'J2wZ94xohqa1LnoHDCW0SJAfsXG7kpNttctgv35RLcMa3aoKxyz562c88LDhuhpKtsTDWJ3BXCKWe0CRzm0ILqbqPYdgrx1zUUlzgwaXYCicqiUjoUwkrVksYdw9aIKL'
        b's7saC8nuYrZYsiX7/WnMgQ7mSzGHpNHk4g65UEV3HFeysME+yc0THuVuO9VeeIjxxkjTDZhjppFdeAy7TcSJ3dTlg8o24Z1CrkIYFizHXUQur5Ut4CWEvfNc3P08eDkU'
        b'0CCNh8PbedVLLaHdxQ1P4k3uOUT9hvAW7GXeEXKyg13RQIlygyVe1lDvPq0zD3fl8enDnXmwRQEdY+axIwd33O/s0tXyaxsow0dJix4bAme4MbkOquBksM7yHM76vA/m'
        b'yYiE00FW7UehgrtE5WPxNqCk9x5ucGYSYzE0FazDZWsW4lXO93bcBE66hLsS/YYoK9A0ndxXYYdERMBLeJPZGSKW494ukkiMBvIXYA1zY/In+06JftuJ8yS7zrlwnvJF'
        b'BzzX3alMBpe2wwUs92XNivsXDyClS8VdWoecQGmAwpo5QSUs78V+x1xKFKt1TiVEft/Pmi3MlmxzOmem6Uu7+jItNeHscq3xeFzne9PdscaTKAjZvn7c2e0I7oVGF3d1'
        b'kAsU9ddS2lnjLlkqUR24LxoUkK0rlPLPuc7Dw6T6qhSJzIG2IOb5tZmMyMOdmyOUzod6VyJLMWa680uHGYgSzsPhxDpvNpZWk73rsE6UyFqpEyUW2rFOd4PrS4xKEu7L'
        b'mBwB7VtZS0x1IrJbEXVj0rkwTYZCoT/ulduSFizJYErBGbyykTSw3cyHMZFq7UNlWJ5BdfK53qbBIYFk+YkQ3eY5b8ZaNkxGElH/sJ5Wj5LqDbHfLOIFtcW/43qjdvgv'
        b'gs/+G45At627AW0yA5icmg67G8C8FJKSkcXYMJ4ihSjdp+Fk3PWHItZZMQeh/pTHiHwjkR/5faWMhqeTJ2WU84gSzXCGI/7LP9N3aRq2EuX4s6I8HzJbWX/tU+bsX1uJ'
        b'gohbSNw1yYp/kjH3I0mihrT7ckn6VS6TflHIpXsKE+lnhUK6qzCVflIopR/lZtIPdubSLulfcpX0vcJC+k5uKX0rt5L+KbeWvpHbSF8r+0j/kNvKv7Lor9CGylkwzr4u'
        b'BrluTcXNiNxfifsSsQizifSPN3NVStjU6dbQGbTVec7R7/+sx9VKgxLO05Uwfb++UBP1Lk/MdllKPjr3Zrv0e8kYveGDmkotssi1sN84dKXHriIDHP59h67UTeEtyYib'
        b'wqzEDEphGJeczGBVDaiCSQGTaMnikrugrXKkrvh4DkUY55iSkNUjUe784hQbO399RmBKYmys48rk1FXr1O5aZFyd40OmJiExM5l6H2xOzXTMiuO8ivFJlAqxJ42xYSGS'
        b'UtiDiQxAQBsumqDhMaQcHtGRAj05JsVrHp61kOIe+DgGMgcEMiI1SRR9luRDnRHiHFdlajJS1/Nk9VULjI+NVVOcnF59Nkj76NqDXialOG6c7E6Zsv1IM2bRxsxYE5eh'
        b'L22nW4jRFLV1Y5C4zL+JO1+QBChAbpcm0kXjrk5PzUxj+HlGUyRVz0halZkcl87dS7T09hzOQePoRKPhXUkTkGwZ2srmNPIxIWOVu5p1Qi/uJbRBMxJ0/aLtd+Z+ltKd'
        b'nlLb+/GpLBY4jYIpG0uzSwf8Br2jKBijdzQPY2plPJwfzUNbsAMuc5s75kVzmzvVabHR16ZnNIRpPI+GgGJozaRRUDOIrl2ptUPiyQhHpYxaPK9v8MTKQUMD+o7esB0v'
        b'RcAeGmpRudQvMINozcehUekb5joEj+BxPDIHbgzbAudtPMmHw8xC9PnOAOGJZWOpqTDoa8VSIZPLMnjYiuntkZSpt5QG0xTAxWVEKDAVRqyVY/3CpeztGa5yQTm1D7US'
        b'W0wfMVtIGp8wUK7ZSO7s9/9g9LNTrXZ72vi/PHnVt1/2cwt8Rtp/rtmm/8xv57w3oWxWnZ/shfgB/wrbPScrMyNUVj7/3OKsl7Z/M+uL0N1Ppmi+W/iTaZj3E43/+iii'
        b'rM+zUQn3YvN3L9thXlRVijHN7X/+IaD6xZK6eWsW+x6vXrrSr/meuGTXoJdm/axWMaVgTZ+V3V3KR2IDHhyBRdw/vh1ODmFxAHmreRjAGSxlR7vh3i7GRUOv+b1ILkRc'
        b'buQhCmVwxVkD17ZSy6ybk84i1Qf3y6ARK72Y7IaN4zbrVaHhpkwZ2hg1n9/brYa93Nd+moYIrNTVXoQyVmLr8YLW0X4v1jNH+37Qyokja+PxCossgMr+OhVh91zutn7G'
        b'Gs5S3QwrnPTqmTZoIl/OSo1VeGi4XrbVSrZrR2pl21lzmGwbh9f7dBdtV0GOgdt45Srt0d1vOo+Y0Wg/NkmZVENJCrtLNUSumcJ4gyU5kyGsZMy1WbTt7jegT0rnt6KH'
        b'1XiA34Ja4k907qvl5ONJuZbiqPu+KmTbGjve7aUg1HeUbDEryB7TBRdBFxrbm9ehLF/2UIGxiWRT/VFuZFONTEjRIqZ2hWPP1PBNNoEtc2RN9vcLnB1pALHe286UsDJp'
        b'lWbFquQkkgrn1NVhTCVSzMhVa9zZE+7+9O9s9lhvyO0GqWrbxof5KbrqHRUpwrAmgRUzNT2efkHWfKNrshaJvtcyuM+NDollKHOZacmpcfG62usaxGiiFMZUjxpHtwut'
        b'C68mMymD48HrC2V8p/jNUs2eHRXr+kdfjf7DrwbO/6Ovzlq05A/nOmfOH3/V74++usjf64+/Oj7WsRd56iFentCLq2hgImeo4dJNQryro7N2+Dt38Tft6hDL3OOMiyO9'
        b'ubnOTY9jYN2dY/j3eLQupAIsXxU2jnf37DJbmCcuh8jl04lkuDEp7o+1lF9UtJEidHJu0zWGl4NPt6T435C55IIBV6xe5urLKbXfieKx056ala4BW5fwqFAbNdRrVGSz'
        b'wGPC/BVQg/vxCjudsZu/Cps9PT1NBGkgHAgUsDYIatkd3LUI213C3Okh4EGRbK/Bc+ASu7PGKt4lLEgi3+eIeBjKpuAuvMCycaNHGy5h1IwB+SI0LZ62yl4tZyciSRtI'
        b'nvQUDC+bCLJUPD9I9E3byulhLsGlRHKvMQOvCuTN61CJB8ThcIzHJ5tMCNB4kY1OTBXghBqu4iFoYknKYS/s1WCrNdnNJAcfPCM6Q6MFeweOzsMcrCApV9ETfsFDhAIm'
        b'kXrgRSimLgvcXYFGrhXDqdlqiZ8PFsRoOguJzXCElJJIHvvZQYgrnsvoLKbvKFbIHOQHeGqs264ry3asZ4Upg2LelGfwCt7UVSITauHq0FFqGauERZZtZ45QF08ytMOL'
        b'LMnZcyd0Zoc35Cy/DmtWwfQVcEG10Yz0vgwvYZuZ6KG05dHkl7wnqywpdoyMiDilruIMpyGsEJtEIkQ34xWVlUjaH05ZiDP8JmUuJHdi4VZ6MBV3I5lzLz0rJoKvgCeg'
        b'fBvswRO2UIy5RHSshCNRRMiuxHY8heU0RBTabU3wwEoTS/InlDxaPM2xLxEPba3hnKeYNMzvM1HzHslgz6hXlv05eB3MtDH9uuatHwO2nXazu+vvnH/02BubXvMbOO0J'
        b'209e2bJBk9Tv9YrVx/NemPz9sA+GP708cee3K6d9XNlc/s9Zy8+N8giaER85z3nw1xe9CwdM/b6y6FBJU2TJ1z63X/vbTrvij6edb4t/6l/RPx/fvfONb5bEvu/9nbNz'
        b'ydmXst4PGT2w37AXoqZ6HMxfOecf31uEtsa/O3/g1otTTtZb7l/2WPlByziXN481rdz4Wp/rt2wsvxybfnKp754N9ZriF4ckv3LZ7Ash+B+ttbHWWUv/3PjUkx1HJ1zw'
        b'uKDZ9/pHNb/+WPXBLyY+4TEnop9W2zHxewbS48wQKJ+tD2JkFn3cpWGm2e1ZIXp7viqQBdouwWs8BLI4ALNdguEqHO2M17NwlZn2h1IuujfikR26Awq8ETYLjkO79pwA'
        b'W8e48EBQOR7LhFwRd0M57OKRomdnUls8dbVh4bIJeIpGzPrjBX4WUGSFR7qeUQTN3BgJZ5iMHfSIowt1RKHyrhKLpImDIBtzJvMC3Qjrp1FhCz1GLhLWjMNzROPiFugG'
        b'bIqHorSJZLhjnhCzAvdD8Up2KwPKnekdBbmTL8ChECyD82Esvdl95tE7NLkCgczSWixXjWTS/NR1WAtFkEOWrW4hqJgHR7gKUU6Uw3oNO9SGM0J4HB7GFqzgwbpt6ZYa'
        b'MsvzaXH2C8EheGUT5LBbm6diAXnJhLx0VoCmPngErkEbuzVqkDuZzmQhFeGisJ3oB4+S5eA4tzUfcojVbNxAs6oWsDAei9eR1mQ6yWVoH0tukZzgIGl6aMXCIXCTWZAj'
        b'4dByDVyAFpOeWhJUzO0l2PIBzs5yDRF9mS4Rb1SXsIml1k0rTvd1n9o9qbWUWjGlX5RyibF6dP5QPmPG/C6Zi11/5EQHkch9xf0tfbp6L5P8dSgqLEzSwlB2Tq/ooo4w'
        b'f0RSnYN6FaRCH814gFw93rseYtNmRA/prSgiczBKf4deD+gGXXVbviI8MOy2asXs6IgI/7DZgf6RHO1TD2l1W5UWl5SiC3WkwUa3zQ1iAZnVUh/9aRCoWdwV+oohYVGr'
        b'JVOxWP146Qb9/8ncnr6A6n8y7QBSCjam5jKKyqb4xUphbyLNJIrofUn6Y6CbNnIbGyuJcsBJ8kn3lZvtROUQO5H5WcJR2O/bLRJBFAbN2zlenrQJcns49Vpo/9V4iV0p'
        b'4ShgFwfrOiLXwnXxawraZUZ+6DUF76LQXfz7zmsbipgZ35dd28X301/3jx9Aru3Z9cD4QfGD4x2OqCjZXJ4iUYwfEj80V0kROytNK8V4VaVFpbLSlv7EDysxNRthNjJ+'
        b'XB4FBFMQBXdU/GgGbWXKiNrG5grxTvFqSkRH361UVUqJEnmzL/m1qbRN4p9sSYq2lWaV5onyeOd4F5LmSDPXeC8KOEZTzTPLs8yzzbNLVDKILpq6GfOqVTAv2z6JiniP'
        b'eM9cJUUKlQtLVCyucPxtWzpXZjPiCgbylpiQfteri4jZ8wEt15rhQ3fdibzqk6RJ9dFkxLN/vTw9vbx8qNjrs0kT70Pnjrun5zjySwTq8WrZbXlYeETobXlA4LyA2/Lo'
        b'iHnz68Tb0hx/8teMZrkiPCxkcZ08nVoIbpswNfO2GUf4TSKXJolEWdb8nmzH0Wzl6bV0wh2lf47RKSwPDIvkmI+/My1vsrJ1TSv9PEswck7MrLt+azIy0nw8PLKystw1'
        b'SZvcqAKQTuNe3VZp4wbdV6Wu94hP8OhWQneiJnh6uZP81FJn+nUSQxlLT6JAiqSBQsJnzwpZQfSCu2NooWf7BbISkn/nx22mq14ENRRrMkii7p4TyF+y9tHE6sT0hSIz'
        b'95yiZbWIDAybF+K/wm9W1OyAh0xqHFmoa7tU+e7kbi/OTk/VaPyYwtI1jZDU1aGa1SylcTQlqTMlUsDLNC3rbu1xd1Dvlbrbz2jjqVVdUqHDLb3FSNre6Vfpt90S8WaJ'
        b'jE9vpfd6z3zcXZffUdPbpvEJiXGZyRms+Vlf/sejHowG9RiLIOF6xwmohpOqkW46Zz+snzMu6f6AZyQWWlIf8rk2tET2liAfKzq92+cBoSW3lZTqNYOMaiZzGIuAYzEm'
        b'8zhCa9fVxF33bu8BCh2kGr7kSuNkVAgQsi1uGBEDHpRXnSnfsDVGdu1M/dZNR+entCxRYT3CGsx1LUsRBFhYg6DjIeUgbInm+pAF84cNWXgvx9SIHTOQxxInbUkwsGZy'
        b'siF+1kTX5AdYLyN1fMCOaYz6gUkwGp+eD7o5dps3jk5z/NUPfozOu998wtvRyVmTRA+uNk52n+T8EEnyqezoNDvgtx/WTln6sKvjb+XT+3Li6BQY9bveGPeANx52ZaBJ'
        b'dC90b4ZirbGLW4V4mLeWZkpHYdDbm3T75K91HzZp6Ump6UkZmzlUsJMz3ZQpgRfdlp2N2w6d6WZNn6FbpzM1FDvTPc9Z7d55tjrJ3cvd00f7iPFkOo9hPdmj2lQ7v57E'
        b'vuZJ91YxDkmhrZoRwAnePmM1DHOi1+ZhxxQ+XXEC2CQzDh+hjfPvtUydGBE+eqranjAQFJJBfxJv5KCd/kfuMbZBartnNlPmBZAQl0EHlEbHxWaAqkHPoXsBG6B2V5JO'
        b'Vly61mnAgAKDtY5jZEICrWtmsgG9m9GkZs+K8p8XHrF4BeUaCo/0X0FpZiJZKfUH9px0rtdG4osQbx9GC6UFadH1m05701qMjZ9vd1qR2ckET6HTyOvcbU1x7tVDgPVQ'
        b'Gp+nGk5Z122Jcea10z2SlGIcCYHjbRABVce8uyYuxdE/OqIXa3iKY2RWUsaWhPRk1nEZDyg8XxB7mUtkwgRmxCVvZi/2vsI59z5mtUAhvEM68UPoyNd2iR5LhB9M9VKj'
        b'DO7wYIAl3uXdLjgwva5aLKUeJwWkebRSlEY3fLula7xPtCyOnfky9syVCcmpKatpSr9hUadSiVkPMco6jAcR1GViPlYE4z7cLxOgIkbCk6IT+VTOQ+SuYQ5e0yF4Os9g'
        b'gYUFWM29HJhB7EpcIgUu5ailzXALL2DNYgZSads/marCUIxXyU8zFMiFcXjGEnMlLFrtzILPgrEK9gbrQ8Ki5uuAVA2CbHyhoCvMZ6hJkCRMhN1WmItXoEItsYJs9YJ8'
        b'nQ0YGmxkFuKMkdjGZcUD4VDJDcdQulzmKs7A9g2ZEfTOHjwADQZYrrwotphNS6OPkkmztIyggK5ObmHRTk5YiMUeWOhKYTw5NqkbtflV9RU9oGwuM2+LKz0Z7igHHW3A'
        b'RizFi3CWHWJsdaaHGPaiyjHWdY/vdh4bBoVuvljUGfkT4B4UigWk0h4RmB+yIEAWQZqd/lyD05tHC7aPwC25CqsTU5MGLZ0n0xwnSVyY/uHokiarnJkWe/86NM3B8/CP'
        b'ti/uS37yrReq2yZYtQ3Za9b/5Q9/cLsT+uWnL415941//WP3TKfVi+1zdklWA6f987Xmn8KmLx+445i6bKlXv8z6kOTKdRuzml7b9mH2+18tWFPmei900oRvK/q86v7B'
        b'38aMhndLXr06aP7yXy5VPWn64+g1LenTnB9VvhIdtORWwuEdrx9Mm/TGdwOeS4qYezuo3/IVrooWyf3m0Di1JTMkToUDO1zc3ajv8yhoUsApyRNK8SgzJI7HnAwOmUxx'
        b'nl2pl4apoIIGqwjZOF9sZVbflSo44hJmA9WGht2NRB+4wFxxdwyHGkNHEawconWGL8Z6bsM9kwCNen/4fdAyC3dBGbNy44W+cD7YAP3OcRv1AIdK2MNN2RfN8KqhY/wQ'
        b'e63vha8D9844hh1QqIUf5NZc2D2TGXShZQxzI/fDW1DfBaBwAt7iGIVagEIy61pYcRZjHVzVAkmyKWDjwYEkN7lpLdxYOF5ndvdYpsW33IUXmIPt2OgdJBs6967I6KP7'
        b'ZKHiXDyzk4UESGbQQmZ9CGmElSKc2DjOa2oXJArzf8v6pke98+tFlbLdRi1wChl1ZjWnGHjUNndfKclF7mJK8eusJLk0iLqx3jeuChmi2aVvEI1ZlDd2QZULfZAKNrT+'
        b'YVWwP4AwZ7KCgev1Bn9VQq44vpyxDPVszu4PIQB3x4ajhqrIgFkRt+WUq/W2nNK2qk2NedFyH1XqsnrbVMvunf4n0UhAvLVuM5kv6APiue5oodUeLTmId551ovXvD3t/'
        b'75wxHXJWfLymKz+1bg81Yt/TS189VdFERx8qG/rE6vFJYo0c3LtqZRk9pBb1jezpStqda5FTDVMVvVNCzaAtmaGV3x9KM9LKtHo23t9SjjgZF3/XCGVunMYxMTk1jloN'
        b'HBk3rJb8sjevmbiULkRz3Zl2eytFF43BGBFuRsImLg5n6Llj13O/zl4cNckzSfFUlutsik66Pl4HRyfGIU+rxmS1ERFz3d3dR6h7kTK57wNzOo6jo8mAQVqfMqfI5NJv'
        b'532j6enf6WS81A4BrV9WV/5Lo2k4RfjP9acHNv4rwqJD/fwjXB11SgknCe3Vl4t5GfdOFpuaxr2uH5DCJmN6Xi+srA9Ijv6nVwNpCz9IS9PDvGlHtdHUdBTgxhQ6R9Iq'
        b'/hFhs0J6Km/GHZMfUqHTUXbxptCTJ9MBqx03dF4QHTiB8WPHxoalptCV4gEe25syOnNn1Lq0jeKSqZc0XSD0QzcxPXU9aar4uF5cq5Mzud1sddLGhBTdyCdTM5768Dit'
        b'Sk3RJJHmoimRhkti35JW7rVgPBlDa4PasJpaKumVaxNWZfD1wLh+Exk+ZZLnOEdObsvrQ8vgqgUI1daXqf90bpJF0Wg6iZnpbK6x2c5JantV8viu5OMYqVWqdNTy1Pl8'
        b'M8klOZlMvrh0rlrxh42vLRpN6qok1gl6FS8tPZUyxNNWJE2r7WwyEfiwN96YBsSLjmFE2YtLS0tOWsW8C6m2zeaToTO98bkzW8tQ30n0SjdsRyfyV+3qSLdtR6fw6Ag1'
        b'7Qy6fTs6+fmH9TIPnQ2iAyapnR8iZkHvqjVLv9R3Y0x6kAtoF01TaVTTHMb95d2IwN4ePBWP6eggqL/8o3FMEmJ60dIgU8He3J5itLgOyEwUWNR+YOpwvXYp98IL06iG'
        b'RX2BUqzhkmYiUcV07k7FvmruJFTq7oPNdtuwSa6FdPEZEMUd8jsGQ3F3jZSpo5VEbC9ajhczg5hOuHQmFml5GpTk8SgtIkGwm3NMgGtQtCH/hO/arqoph3y55N8HigJn'
        b'sXqPxTJLvW+ShQgH4PiMsXCGoUQMcXDsnhNegIO95sbz6qS+WeCkR6tQKwQfTztsHITHOUROOVFDarXeUq4invWcgQcUmZQgyGcunAhmgD5uQeFU63UiClcBS8kEy3GP'
        b'+eiBUGfeqW/OxGw8Qm6csIU9cCoKjsUvgAK/HXAIcogiUw8nyb97122C/XDGb+VyKPRLT1qwYO3y9NGPQM26NTYC7vN1gCMjLFi5opfgJRW2pllIgoTtog3RknZAGVfG'
        b'T22K7lougzJhwUAomAllK2FPl8LswRNYSa/LTWjo6p5Ya8xzFKBhQR/7NYu49n8O6tO0/mRmInVO8TCVZdKBCw2mol73V8doQXvSMjOjcH+apTWWR2lbvBO0JoqaAmi3'
        b'kE6ox7Mc10OHcAPZcE7JMrLC/P6kJ0+PzpxJ89mLdeaG0Ep4Hpp7wCvRN6O6dCi2QJ7lvBGrGDrJaDJzDgcb8h+VQAm0QcN8NnJIysEMaIQMpwoTTRAU2pIBXogVEUSf'
        b'LhTx1gbLeXgLOzJDqEI2FLO7JdUwP6ATLD+mS2qwRwWVdqPxTD8K4dC/n0yAmtA+Hkg+LILdvIYV0JFgBBJJiiEa6HGsJFldmUY6KQdzSRsz7zooXylgXoRFBJl7FZlU'
        b'lcBiyA81sMWEBKqD3Nw5e0k3oKV8MuQu8dJZdp2hpNUezbSFsrWkZAyIpSEEL+kwI0iaYaZw5GEy6CXxiCA7aF83iE+x2ilY2WnmSYvH0rXYwnx0mP0Ld/e1dPEaqCfW'
        b'MWTVWZ1EuRqThr+110RTTZSsJ/wmhy64mfJXT5sx6gVX3J7Z9+jRSYFPndj6w/SZPwjLS6S8M43igGO2Hr5umTmPHDxW6rh+6D355t1hA70Svz701NPz5oqX9//wy9vf'
        b'fOUkC/S/EHqgyC/q+T7v7l06ee+EmtdfNXeqOXvK6dqkp86//s+hA8+1jmtYumxs+Yv9Th+5N8Hly1vlF/7y9/yJCaoPbjUNH5DyWXbo4ubF1T4HTj2z5Puff143xj54'
        b'e4zL388m13+656T42Q/7Xl1y/7X8u5Unn/RYM+NYv7LM167Fv3As+mrKT6O3BG2yrzWvjftu0SA32/ummzzu/H3U3Se/fqfp+8l3xr5c9fy3n1mtubX1H+sH/f0f2eYR'
        b'VbdT39pr/33rO8mD77ySOuVC69Nz6n0/SVddrnr6g8YXbL/auiZv1uzVUzdlbTAtePdPC+/P9v1si/1d0yMnP+vzdt7FJbFH3/c9v/HOjI3bLr118oOYn1c3ZbZOyIhY'
        b'PWBV9uVJL8z5emR5cPjd96esW/blE5cPf5m1+eyFX8/+kuv24r31muyyiL0vzCq6gNvt754NdzH5+4SQ8S4fZFx6/uPGksWPfxXy/aXlwsGaU3NeWqbuz+w+MxZjAzcL'
        b'HYKbBtAA2I7t3O5zAi5SngcXfLQ77cUwrGcWFzjpG62zOtlvmAW12MoJLY7CSUUwNi4L6epZ6QtHmBknoL/SECmBzKByOIxnhvOA/TI4vE7Lj2LAjrJOJotUxvInLkAO'
        b'SQAbcVc3IhZoCWVGNzIfb0CLCk4sMUR84Gat8VjBCgEdwd5aV8qpU3U2t2lwgntpHsYOqNK5aUKuuNUad0MTKQxdf6fA5Wkujl5kBgZCg1xQJEsjgjl/Cl6CmjF6/Ikl'
        b'Kzy8cR9r7j5Q9ojOhjYjy8AnsoQ0N0PJ2TeM1KsnyQc3oB3WYPMMbGStG+0ATcEUXU67yuti5P3xPKtYujM+Goz7XClrnNxVhD1KuI7ZkM9xLA5hqYPLdDxqYILjBriB'
        b'Ezik4gWyyF5w8YHD3KDJrJlzoYEzkeQE49ngkEAo8Ijp3x3UyBPaFB7KecyiuRrL8BazWQa49t0eFE5ECKs5Ml+o0PBMDkHhKLo3Fek4W1gUmTn3AG1K9SUr/A085RHq'
        b'piYl8JUcLdPUyoeOV7b+7/jfleowHiupZGjEAijsNJ9uIVpJNpKVaEF+FZIN+VXKbEULG+rWqbhvLpOz0HWlKO0yl+g1DUmXtN+zIHnJTsaC2cmvjaTQBrvTwDILExpq'
        b'ZitxK6MVtendt6CB8xINO6f3towwYmr7nYHnnSaz9Ke7Bqg9fPsbxos/bSRo3Ei8+H4TXZCdETumkO30sRFL5kPUtnePnunU0EcNfNw1REhU6H17ZA+LaHo3tofyEJGQ'
        b'QvRWzW9Z8ZjJQKumUCU1TuO4KDTkN3QRijsxtIcu4hqWSeviPG14cCARCwyIJbvC0GHRQqcesaF4BC5Y9utnwjb3xK2ZlDIPjszqublPcGbygUOUOZMOYHeclnwOdsEl'
        b'5ic6JCSL3spwJyut+0byJyjQTRqMV4RRy00me2n4ydrhJCqCjPeUz4DTgjhUgP3T4Cw7lhvbn0g/2kO7wXBJYId2O2AP06PCsiQWRWMTl2wx2W8mx7qUk6WsnCFPCtQP'
        b'n+hTtQLc8u7PYSRPwCWy6lV4efGAkknQygUcip9WozJLly1LJ2/U0eWuKJrdmrodbrqonUNNsCJSkG8WyZJ5BSs5zlcLHIZbzmbBdDcJMxEU/SULqNrOw1qGwJlILJFD'
        b'PXbQJwUonYj1rISLfTCHg8T5QCPDicMGOA3nuQzfDo1YyrSZOdBBFZoZccs5Vllu/whdJEkwqZhEI0nwBJRyQLJDmWRt1cagTFohyGjMyw0sYYkOxksTqDooV5HMZILo'
        b'TLbBi6yYY1dAuVZng9wBVG2bIcA1dmAa594n0mISlGBlNNmNDlAUOmW4iFd2rGGNv3paqeAgCvbC5iyrv42fxDXbGK+RAj3tPOa9QbJzHs6/zPMKEPYLgufMnavMJ65J'
        b'E3oQLutnn6OgJVxWkfkmHBO2ifFCvLhHGigc11EvJxJp8lNq7qdsNrPi00OSUhLqtOTL8mTyoTt7NLXhL1MIwrcSmyeZ9F2ilRQtYc7L/PDRTCf3EoFjL1axaAkxYpI3'
        b'XsMCKPDGPRtnzk3cEJi+IwWyhwjbvGwoWZknq9yWAEvSBoLTfPdVrrg9gdf4RccBgisZlzOt4qfVRY4WOIRgDp4Z0Qkh2AalhhCCKyCbdUgYXMWjXG2c78MUR481ZJDS'
        b'XlwUQaFDWzdYysj8PCzI7MSpsWYsv/xUHi32UuAWi8hhMYJaYgaC9XCgDxtJeADOs6E0dQubBnhjkhfTEycmU03RAxvWshzETf2wmbxhilfJCBpDRtBVvKkW2b1EMkSb'
        b'NWFEHhwCtYKkEh3xnPe/1ZVrSFemP0cX/efpnxdFoQf1N+28C6Tz0l8StUyaRE3PxxOqjdhqLSXjQVr8KUuwjM/HdmybqkqXQSsVXshQhxpowSJ2bxqecMBmC2w1hYrl'
        b'ZNJV0EmXsynThtxT+UCdakMquVogLFgFe/h0ywuYp3JydsGmEBHOwFlBGSQtwWOkm+jdoXFTonA3NnsE4dUQUTCB3SIehP24Jyly9RoTjQ9ZljwTGhOiA5Mdom1+uf/D'
        b'F+Nra5545s0Ppmw4+PhGODQlTJk7OvYxV6vs3NHDFX7msiHv1X43x/vYuwOe3K+YNUFp1nZ6acDbM1eW2aQ9bZn7RLYqa37bY/3MNtx5rP6zlPixeYd2fL/8l7tLXzvq'
        b'OaD/3esLfc4G/PD95z6ubT5e8SuHnLOb+tjAo7JJMVuHfDPk2acee/3VqDvzs6996zxz7uSPv2zyTp08f+iS2sJZw1+N+uzzY/aDGqu/dUtouWUzptmuzmGdc2u/EUGt'
        b'dpVV9ccLgxrTG1a+t8jy2bi4MMvn3z9wbKXLgtExs17rn5x5y9z84/Oxa8etPvfWiQvZLrfTJ+Q6ZC7CmLcTG7JfX+Df8fm4bxvfPbs2a8/aptbrZ9qL7kx+af+F1qhn'
        b'tykTR762PrR62z/Koye+duOJqd/uyHu9/NylO6XzPyiWnTqx4JtDq4vvm0y8seIVn4E/LRu0qn1Yn7/sLUkovu878fqMl+4uempJW9ycX3LyQx388fnnpi08tu+Dhf6H'
        b'//LNBw1/8t60tOGzX5KG3Pe4Y/bFxnVXSiY13v5ldYtp5tRk0yc3vv15fMe+qd4v/S2uMTJGLDGb7BbgP7Vvqd36bXjlc+ef7KZ8pIjLMot4+fuCvOrXz1fL5pe3DT5e'
        b'PMq87XC5t/f5JzeoBrxafmbB2kuVc65ttrpq//Gq3W8ujb0Rt3VOzTNh0smw3e+oNvZ3mPfV7i+vbjn2yxu7UvYMCXjyJfv1QR/tO75xhu2/Jj1x86n6796d++GXZmPv'
        b'Cr8+/vwKd7ix+42ZzwR+e++n7K/8p1X84FY5tXnpnIt/9l71j/Eu1ZNG/nWyw5c7Q5fKF759Y//xwsKhl/tFXV5ukbOlujnzh686zpg98834rWNDX1Iees4/Ytbu7XW/'
        b'nhlSvmW6/IbpRo9Kb++Xf9711VMWO792/vsX9xXfCjuPvzj+yXYruw++bP4k8Ncx76iVmUeiPe+9/NrEaZ47ig7J/jLkPZ/lkdeW/nnVlRnP2N+1Wx/8eZaDd+KlugWm'
        b'YxPbf4o6WuV9ad9796z3Prtd6bLjze1zdqxO+vnG3LB3Mkqfe2fwP+yOTn3V5OvMHzyrFz4+7dnMFzrejnjHN2fppL9NjR1Wcfuxp2tb3jx+C7Jq59x5MbRq3Z3Yj85+'
        b'vmnaCxtzb8zpqHj6X0tvj37y56i2pLlvjy64eia4OGvxm8uK24JtU0Or7P8x9ivbBRc/K49/8Upw8Q/1Gc9Ykc8xWc+83BA8pybw88pvxhXfG/Bs3/v/+GjReV/vtGk7'
        b'4o6+Pzh2xjs//KV1XNq9mzOfihsb++fHwp4NfrWsyfJe3zshnh2yjWVj/mK17fVJ9m+NsVv+gqb1mV8f+zR98nSP2n3fvL426pO3nlsdfmf7dP+34zweCztpHhDz9cpP'
        b'vqsYf+dq20tBnrfgT3Yey77NeeHOF2N+/OLOzdzrGe3hyRfHvPthcvWKwW/FTNhzd+O9yUmD1rXPnNq8fN5pn19/tv3Fq9JafhM8rP+5/cg3M9u35v3w5uR7z109Hl19'
        b'9cezf3n24IjJMfOiN3864+8vTO0fFatex1DN+sVjpZ4VRaesQjvkamlR4JAJU0oHJHfyFZv0JZIBU1k1mMPuenpMcHEPnGbZTa1zdeQ4gXFzgk2ggOx3+rvWnrLVcDqF'
        b'K/uNAXKifO7HGz2C9oqhmZVybGaQEfV0h5/Ow+MkdrCk+sFJynWJpcFQqelkxKV0mBKWsMKo8MpwsobudXE3xCwkIg7XlS3hlKlmfJRhvJEl3pLNhD14jcMWNoZHadxJ'
        b'/m7pYWqyp9sSfb+ZuddggUyYgPWKyB14hfuTVC3A4pl4OlhniFCskJzhAGYzA8ayTZQz21lhhTWCtEyc7AO8LefDzZGYb0k6xIMI0LR8pRK1Vp7naRaH4VUdzBsexSoG'
        b'9bZ5xU6uYV8hjUh29nw3bMLiYBkcchNM8YoUPgirOJbJCczFWhWcCNE9g81ka7GEfCIFYN46HpvYME7kkLSjoJ6i0kIdNONZDurYSF1/eA5ugSIRqesFpbm0cMVMTvOe'
        b'B8fhnMY5EPelsUDS0jBTbA4VbKBRljFyHbdvVEIpnJuOucGchFMwwZuSbAUUc9zCa1gZic1E7C0KxsvhKqhzUghmeFWC0z54kpt4rkCZtSYhg+JSmpFuMhHMcZ+ERRlY'
        b'y5NoVUGuajpeJaU0U2MjbQlSxXZZXyyDat6MLaQi17iNJT2QWVnITnuMdBxNYB2RvnNpr7q4q82dnKFODsdHCLb2MtyFJaN4sCwRoOGqyj0YW9VYJELFPEFpJS0NghMZ'
        b'FDI+ek6kJkx8BK9zEeHceCcOgHMSbjhhM6k1bXsXWgETKIEcoU9/GdTYmzMKIsiH6yODOa8o7lmkpRYVBkOOnMgIByCf1cABDgZpyJRwD4RLFk5uRH+1UshmOMJeZqaa'
        b'4AdVqiC3kA1wAa6MDiDDVaMWhYFR8nnhmM+G3wJsm0S+C6IdQLQHuBa0hDduDbRBU/D2sTp4axMyFytl0/rgKVbxGKiZ4TIkkWIzGgIzwuXF3Busxc5JE+isluDiMkEG'
        b'lSKU9IUr/FZxMhkSzVhkAoUpgqiiotQVNR+3F+GAeTDmYXE3q10C5HGjTW0UZGtRG7EyngI3wok5WMmK5E+kpOD5ZFJ3tUnF4y2W+PLNQNHw8ZYTaYYNIWqJDJdDEtyA'
        b'R0l3M3WowNeBgk2GuomekwWzcRJU+2xi2c4ZGKtyVzuTziKFvpkoKJOkJKjEUu69dnxVkosTHCXd4x7IIZatoUS2knYum0erkjarSDc4uW8Io9LbWTpfa0merMyDKHQB'
        b'nFGpySShbUJmQbWILS7z2KsboQhqtIY0KAlgtrTrg0ezQoWQ6XhD407rCY8GCDIsEMmy15HOXpweMiAYS1O5LV4hqIIkPAv70tiQeQTKoVWDl6GSdFB6CAVssPSQKSfJ'
        b'tbOedHwtXQ58fUibtAlwkXzRzO49gtnLiB6RjldkEz0ECTrEwdAIRXw6V4yy01pUoRqu6Gihb6UxsMrRa92YPJ+pZOK8MoY1nRLPwIlg6DD0DWQG4DLSZwNZHc9ikwYv'
        b'+LKSeoiC+UwJ6rKwjU2juVvggoYCps5P4bOUjES6jNmRJRirxqgy2Plk3vbFGtynNoeLrpgPB7GVLuiXyWMDbeRkm4MzfLzfoBiqeWR70902iRHJ3cNka6PzJBI7sphR'
        b'dQuUMp7o6THM2jpZEzt5IT2j2YjNckHeR1xuasOGefJ4aKLfK/AA2elEoseQRVDLFN0ALVuIPI8FThKeV5CmqiX3J4XylfUkmdt1pMROQVnOEu5bJRAtQvKOxINsRq+F'
        b'ExNIlffOQDIr6RkZs7FaS7J4qDLjHbE7EutcsGKBjo2YIZQnYQ1fFA+YR2jYjgVly8iqql0W7aFePm7eXD4L85Kwg4znar68M5XjMBm0UIYN3PhdND6MKvJwjC9etLXM'
        b'sYWMBw9SYRbqf6vfTLr/hojTMUeQYkS3cDjIu+MQXrfTkL6eBM1mWJBFrlgWfbFCBkfhMNl/mRH7otM2hnjuR7ZFOstPzpnHTebllNQ+ZTYUdVpmIQ8fZcutLdatVWVa'
        b'mkm+DoJsuDgriOMGY54aTxE5wE3EDlocO3GkJ9bz5miDerL3kSYvYMe/G+hTZKuvk43Gxngul9RDDuZ0YsKPwDIGC0928FxsZ8JAZCBJhyKDeWBhqKs6MBQK5JDvEcyR'
        b'lKdMU8CJcXiY+8LmbwUqmpwcxgzTerM03pqSMY7mdgaKB5G0SNuWGkKy94CbjcaLSg/MHc7222nQ7qViT7ltoKsukWNOCH3INCWj6QJWsG6NgmoFWU6OwN5ulNl4YTTf'
        b'DE+RkuVosqAiTK2dbf4SnB/mxRuxDlpmkJFDlvTTGrKkHxRhX4IpH8/tg0Zrls1kb7HVZKLMjEyz3axt1kATXOwEzMXLeMKgFgwydwTpPnZkcgXaluqqwXIqIlp3H2yV'
        b'ASnaGDbnTaHDvDukPZYsY6j2ZlmkV+nwi5kzXEX3Qji2mEyuqyIRRbCAT/OLizBPhYVawQivwwGBLEkLFhCxg65wy0knk6U+SMQzeJO8e4VMzDjI5sWrgIaxpAVmYKHa'
        b'PCiULjlk5thBrgzzLeA8G4F2myJVagEKzAVxkIB7XPAI3yMqx2KZJgybPIgcQVdsPOkg2KyVQeG8gawJp8IlsrK6urtLkEuEORnWkI1tMBER2Wy6htc8VWQy7MRjgqQW'
        b'hxJZ8ySTEXxwFxRryCqPBWb9yE6iq5dgj/vlPnPhOOs6NyiDk5NNVG60YoJiqNQXr8JFPpVzyOAuZww5YW7OIpbARTK4yVQm6+Rw3rmNsM9K4+GMjQFkXJVGkh5olwLS'
        b'g3lzlhNxqRYvkm212S2Mmye2i3hgNN7kc6ddhFMUBRkvunYCIXMU5IkDeRJV5MtCzRoocw/KVJMlgYhxkkSEwwtDeAkbLYmoNEPFZOtAaye63FniNZk3nCOiHu0zS6zv'
        b'q3fJVsFJgXpkW65j+85SsloHu4cqNisEabM4LX0LB/+4hSeHMj9tOITnqK/2OLisFWxwjwAdOgwTdzuGYkJkjjLIV/f572DbKn7jvhaggoXUKtKZdZ+dAS0xAnOs+1E6'
        b'KxkQMAU0pnCAcgYLKCdLHz2lUTBoY+ohzs926D0leYr+2JFnbETpPoUwlu7bKx1E6VsLaxsG9yH9KpfT855R4ihpEHmT3LtLvrOk3Or0DemeXCEndxXSmPvSLitR+kW6'
        b'b6McStP7VfGc+VQbifKxU9BjCn1sI9qTJxwUNqIdhRqROdD8ZNJPtmY27DP91t7SnoI2i07kmnxn0nvu0n0HE3uRpsvgSxhssx0pkVIh/WRlpviXUiV9Z/4n6UfzSHMG'
        b'j0wBki1ER/J3jEjzJmX5lZZX+kXxs9JOKW4ZaORsh7e+AZ3gb/SdQbTyy6S3HBSk2yiuuvEjJiG7/20jh0y9F4Rkz0LlHxNpMHJYmFpO/jD38jqLbkgm6ckCi8iOnB3g'
        b'H+ofybBLWAQ1hzLR6PFHaDnTGZkQO6az+z9BGJmqb6bDdFDTk7i9VD4U5JKkkDgY9z3J9D93pXhemmwlKq2VDLFEEu3uS74ch8RebkWf+1WSSeLQ+8LOoeaZTN+vN4X8'
        b'nmZ8X4dgN0mYtkRBRMUqrO0RaW+u/Vdj+2AoElm8UnttZnBtTq5V8Rbs2pJcW2m/tza41sKSHDHTQ47YxfczgByRGUCO9C8xNRtoNih+jB5yZHC8gx5yhEKVCPHD4h1/'
        b'B+TI8BKF2SCS4lg94Ihlokn8iPiRRqFGKMCJIdRIrtrptjWD5WFs2XMSViZl3PXogTNicPffABmZwqPXvdTSbfns8Aj/2zI/L7/043S4n6R/TosPj/YxhYdfev0uiBDt'
        b'S1N+PwyILjsW7TmOwoCkX+SRORSwI/0SQx2K8A8Nj/Jn8B+jukFvRM6ZE5GwoWuMuWd6E63wwzw6To+RoSvIXfveUtUDZ3Qts9qsSxq0H9LfNUTf0DVO+nu0Rnford7y'
        b'GJd+kz7z38PMeEgSbBPOEqmAAo7jB214xkSQKJBf1Bh2jpWaArmms1QM+Yvi4x2BdtyXFLbzryYaKr2FXn2KUp4HxD2f6LwyPM488RPhnzkDp4wXvG1PvyS/UHhSLTIR'
        b'bOmg8cxEhfuhw0RnpLoEp3shAu3QOYlQfas3AYG5ijhSVoMt9t3m2ENCb9iSZtZ4PmAzYxAc7xvZ0HrP8Bbt0zcovgZ19fk/wddYo5a9N1zxsPga8azUFECA+vX/J8E1'
        b'dNPiN8A1dNPqN5+Y8tDgGl1nam/gGr1N+AegXRidvMaf/x3gFt0juHiwQVwKjROggVi9hBXpXzMGltoDEKNLP2tBMOimwYEtyMbh3HsE0G+hT+hK8nvwJ5IS/wc98f8O'
        b'9IRuxhlBXqD/PQwARNdJ+5AAEEYn8P/gH/4A/AP9r2dQjklYVOY08sHfDwoMcAf64zED6AEsx5IQLW1vpyEOblG71GmHRUmDNC4mGkr9+0vV45R9/JM7axKXPPbm468+'
        b'/tbjrz/+9uOvPP63x6/vf7Rs+J6m3SNr63ari64tOpE7ek9dTVPBuD3Dq7PHL6kYIuyKsHR4XFKbZGgJPOuHubjLbTvdaSdjMT+pu5iFe3qAA8AlgYIDuIYz65X1jMVd'
        b'Yu+xHi/z4PvzScw47h5nPitYH/c+Dm9qzT/x2IZthoH9TnBV6wKNuwbq/ED/IyHxxtkRDELj53KnVerOKr9vRAT53XHv9g8j/wx9+6Hkn98T/J6rFsPSQdTJY0YC3/1I'
        b'yXjge4+c9FHvI3rZ5XpEuise7KK7yrTbjFDpZkUAldBMu8loKiqlJaq0Mpopk9GUREYzZTKaksllpjuUkQbX2vj17cZktAfHrxvqjf9PBK93xfXSCj7aiO71ZKugobX/'
        b'i2f/Xzy74//i2f8Xz/7b8eyuvYpHyWQXMKQw+13h7Q9YMv4vw9v/q0HZMqPyny0Pyp4KzYuDifx3Fto6g7L3juXwXtQYH4kXkrivRGQAFoTr4LkCgrCE+rUFL6SwWDQA'
        b'VU7Pu4tg9zgzuA6745hvt9tKIil2j7eGQjjLIMDw1k5mehqChbhbY2m5HG9pUcQuDJiRSW05DoPxnP40e4FBEK4emAvOQHMajQ+HCjxqhu3QsI0ThXeE4VE9AfFZvOyy'
        b'APMDXHlkB+ZzGtZAE2HFWOUsOILHGRe9qym0QGtCcDf5l4bHuuK+UO76FaEyxRKfJZkzyAsTvdIopevV9Ty56PkL3WIW0hDfoNAQqIsKgAsBoe5ugaEkCQ8JLqu8oCgi'
        b'UhgKR6ySGUkJPYY112CRxis9dT4nAbk62jeTHq774mFKVx9qkPJMPL6QhqqmeaXT+FQWNS4XYqHIFA6olLza1/A6nI9c6LY+LYY9q+2tKP6OvtpLE03hNLTO4VEeVVgy'
        b'V5U+GkqsSEPK+oi+UIJHePhE9RLqzk36rkWepZEJEt4SXebABeZeL3rId5wUbChPnOt6R6WQZPtkjUzzJLnz1/Dh0aW+tjkzLfZULDu4Ys+LoHpzi7Rl3brrz09pjrjj'
        b'HjFrZGi7yduvfhEwu6L9w60e49+rHLl38U85s6JS/HfOfsq/T/mS1+QNA27mzPihz0drPx04I+BlpaxNNa//09NabigLZHHrX8gdebc+ubxx4MtPXrSKThkzqX/WO2cr'
        b'f32r/Jl3Dj9fM+WffZMLcu6UXLR8dmL51Pnu1+Zu+9PfPv5rifMb5r5ffPLyzU/e9HYe+6czg8/dPdQR/+G2mOA/Lel4YcpHuS+ce/1Dq7c+MLW08XcI8lXbcB8T0g2Q'
        b'p/X7wXxo0Pv+yKeyY2HzscOgfWZ3bjo8CKXD2EE77rJ1CA5324q7WejnLPlmThl8DZuwYRVp66LucZkHbbjrY6UTHCE6yQnq8dEtLpMkX8SdcBq24a61RCcr0vcuIxYe'
        b'ncW8U5Qzs6i2AxfhhlbjKdzJLLVj+ifKTIK7Oa+ZwVUeubgLbsV3d7LFWmiXdE625SJrnGFQv5yXn8xT5SAsIHqVFd6QhWC+Vp+rhlOJWOTmG65jNq6HwyvYLbEP1Ad7'
        b'BcFhZOwVlwS8CjejmX9HANRCgQvUYRU06WJKcfdwLSmI5bQFLkGhvENIyfuOsB0rw8M78RxzQeiH+/xc3Kdt7VQgH4ETrFbmKaY8GlM9bJGxaEzYhed7Msup/oOxkCG/'
        b'ofqZp9GISErlS6MaFQp6NmzHTr2t2Cm0FfslT2gjG7cM6641GQ1gNHuYAMbO2EWT3g/4TXsntzUSp+j/MHqn4yUjeudv1eu/GKqYq5bdXfaboYrGFLY/FKdIjyt6ximO'
        b'DGMbDLZCuzK4R5ii76iHCVT02cx5P6umTHXRYxBAo7Bytq9MJYzABhk0hWMu5MMBbbSfKpLFK8qxShuviE2PaMHWvbGNhSLaQRUPRQwIZZvAL6tlysESvYpNrpqs0kYj'
        b'PTp6PY81pHGGbiQpuAUnVmZSN5f+cFSDFSzOcBGUeqQuYLtgxgBs0VBTBu7bNEKAAi8nTnVVtdCeRRkK8s1QuFTEbKWS51CKN+ESjTCc76CLMQzHFg4AczEUz9EgQxpg'
        b'mOkgQKlVX1bB9fZTeYAhjS7MxFLq3XggklXQB29hBYsFJKNpBuwSnW3gZiZbhM+TNf9wpD7gD8qgRR/0B/kWrBUcR+xz3CSbIgmesSmn5k/j4W4Nw0fGDhTzadP4XVu+'
        b'kH8ZPyMgw0vmSKlZzV3X7Pj3ov5WP1yo2HVqZGGhYoECgxs4jvu1HCWuZB3dEBiKha5YpvUkwnJopngm1KFPDa0yLyK1BNNwSI0qBiuwQZiN+dZRcMyL1WdIiMWYsRLp'
        b'6PmxyfMXRPBKavwGLD8qLaJIPg7NjmkCC3kdAbd26OP8rLF5Ctbqw/x8cQ/rBjgBJybzYD5BZtcfD4tT7fxYkjWbTOd+KjBwIIs5sTJBLbJxg+3rNzBvXdN45q1rYvNv'
        b'NWjuwzWoTCkYxN7BCdwl8tA7QWYWj83iFHgUylhIoTPkwn4V9YrChsQ5AtTsyGIVXbjMn4fdUZolHnaXaMbmh00SnKaGqQUCkUvbFoQM4ILYMcjZoYu7E5RBcHW7tGQ+'
        b'GaIcBRSumdKgu/V42iDubuzwpB3PrJE0u0juvs9tzYx6KsVuls2XX9WE/m3DY7u+ua2oKH6m2iGk9RnveX0HD37yzrh1qzZ88t5jOfZWAc9ZH/v/ePsOuKiOru977+7C'
        b'wi69iooURZaODRXsjY4IYheQJoqALGAvFJUiSBFQFBUEpQgKSBU0OWN6TExMMSYmMT3G9G40flOWZsmT5Hm+V3/Azt47febMOXPO/5xho/09R/wm28llG4xtGqHnafF9'
        b'/Vbjdyy0J676dvGbybVvj+wKbLd67oePZ7+Us93h5BnniJrFVnMK72pvj428+sr115zOvX74anb1/A1fzNfU67A6LrN+abjVirLXuube9vWysI4YF55abZo9WfbSGKvw'
        b'/KrwSS/+kltvZqqjtDH53EDvs7yIH4bP+4Iz2S17dqIk7O3Ij6e+cW2XR/GPXxlonJ31+Za4y2f8okJN5u9LWZX+81arzdzOcqfy7bmehxeElbfFaF5+6rj2Ef5I3fdu'
        b'0cult0JbF72Xc9g79uf13234Ladz2pV1J89cltye+f6dzfnxnl9NDVcWur56/LinuYl4xlOOE6x+e6pTdjLLZFmo7OZvwSVrK6x+u7zSbb6ec/v0j/x2fRT6lHP4TsVv'
        b'saXqHS+/MmfK0q9/jVmz8Hb0tPtex37/9P4X84q8DMcteSoEQjZW73vL1/3Miyf4O+vOrX8q8LPl16daN7S8J0mYFpfR+Nr4n3zdlelfrB3VOryw480PZ0S9+F7klPxf'
        b'hYSmW4Ujrhovz4i/ZXA+5q2GmO87J6662b7c+O0Nn1/Xvu7/buPcmjbzn4Jjkq4WjphsbGz9tuH9VUZ1K/YZhfxQcDXKaGv4fU//3KvWL99ocEs5U3vz3PSlM6y2bS7t'
        b'/e6X8Dedt+zI+WVUT+XOH9emjF8sqv3h15O3d+8quLQ++UtJxQeW18Ov651bcD/iz41/Psg2rDhafSio+l1xh1bztUOfW3eOr7aC9yzrn9Y4sOOz1XW7468t+ybATPGg'
        b'qnXUH+vWfvBBrWgSjPzNa2TtrQfJH66c+kHgIscDMpdXxzSs2Hzz5ZTCBTfa1rak6jUrk4sX3MUfd+q946P52fOhmu3K5RLrb63Wd+ZNeLnwBbPpoddcFmy9Y3790u4X'
        b'NeY6/fnOlT0TUjUKnwtzDvq2arj09B/mLqsXl3zw9AXhguYFtQuvOM9xf3vrZg33xHy7zZJf9h6reP/AkWcj9rxh/YPx0uGvn6qvf+3XmR37F69zLdSv6JqRfEnn7PUT'
        b'r1hMEl/Quv/eLaPfCoOaY2Y6lxZfDPgppKtuxr1Xc1/PaF1f0yrqdres978a/mrmd2/sL7qqTBwe/Pvpby7f2PllV9ufc97173rqnV/rX6ldcmH9ZfUaM50DqV9ffd8u'
        b'51vzbot5mZt60nsP+3oUZQVVffeJm9XMT0Ot3lIkUCPY0LWolLLVvnMHo9f6mOqLmpS/NYe8tUPC1kE6HBFSp2+mDP8Mkxj7h9yRrB4pXo3qF6qstqEi3keFXDPw6Meu'
        b'RaAqZhpciNonU8DZYLQZHEYVYi3UGMTMq8+jBqgieDPR0kGIsxIXyvMrIVdXqeJJFsYPAM6wxHqIOmcx9dNX4c0U3vh0IWAUhjaznSvi3CFTDVpXjaVCiClkrCdYM290'
        b'th9uhuogjaED8qYrCaYMNaDsAVyZOmLh+xSmG/pAZQRQhi7ECFvGQCHNGSqWDSDKCJxs7CQhAOXAUQZpOgsHoK7/BUw98wdByhxYOEOoWb+KIco48SRUho7yUOexhI1O'
        b'BnTP78eTcVJNHVQtLEGXkuj4TjeEuqFoMgIlWwx5omTMBO1mc3QY0/Y2H28HSEeHBwBlUAyddIpTNu/00UWtD6PJ4PxImn2cbP5MtEf5MJgMNaFCZsrcAr0esj4oWSmq'
        b'HoCTaaMaOnqBoeb9SDBOqm0M2cIKdFhMBahpqAelK/0JM3ZGCnUc1MKxZFrwSh1U/hAWjNMzXuArgsP6aA8bnFMKaBnwBBSNyokFUCVcZNbM9ZoeMn+8kkzkCtxpOMmj'
        b'JjglZ3L2KQ8roolkWBG0Z1Y/XGSDDq3dHNXtUoHMHO0U3GCMGTo4g8WIh9PorJIBzFB+eB/GDH9bwYBqndrQTFBmlls3Ek4aZSsYzsxcLIZmY7x8qF31QTg33oehydAR'
        b'h35A2cJlfUC6Oht7BieznD0AKNs5nEm8BfxoCj4gyAPUCqd5yA9TY4/KIWM2w07xMlQNxznoCVOnLd+BOVM8//kPS+QRmEsiI7fJiNi+MySC2BztxSc8VCU6M7v38zMs'
        b'A3b6PAQmm7GU7aIS6xmWfrKHkGTeqI5hVEqhDBpVUDJOwxXtnSPAIXsPdrVQimenph9Oxkljh6FiIdYVGEoNpYegLnsVlgxTlIv9eDJbKzbbh0bMxRVHLB6EJuuCXNbm'
        b'Ni0TgiSTRAzGkkkm0oqD0UWoGXDKBBfQWR66oasvrmcTJk95DE9GwGTozDQeToqhjbW6E0qgG3NCPT5DMGWKQFrxtkhIV1L8Bzqp6IOAaOPhoEFMHVZQUsBhaecAqiOA'
        b'srNoP5v1I+aoV4UoI3gyOAUN/HAsgB1k2IBcaID6QX66QqGCgMpKID9Z5UrlLGRRVhVal1Be1QPvRVKyuhIuqa6X4m0GgGU1cJj21jseL6IGVK4cAnWBfDm905iA5ZPT'
        b'FFn2MK4MSkJIlNw2VEqp3pQEVN8PLmtHeZaQMYAtg14V4c+HlmEUV+Y0cxCyrMuF6s7FmxMprkwDtVBcmQDH2VxegNMbCYDM16AfWoZpyFn6UIS60RmKLoO8NSpwGTSi'
        b'DFpfIG54rwpeRrBl6JgHT4KjTmOtqYgP7kOXEWgZHsMiYcpSVMDMAVpCp5Mx0cQbBk9DCdrjh9pwk03RObG9rSdbgRdQFTQM4pvjLIXlGosYbqsEGiKoJcBSZ3YzVqbH'
        b'yOdBdBpKUN4kGS0Zl0oWqCYUCXCGt6HluoyBblyqNtTTNYilTysCaKSttl6M6XwtnLYfAmqDFjtKgWbM2K7EpyI+0xrxyajRj2ob6S7GkmUdppMUhJO/HI7QI+Y0FtYG'
        b'4dr2oHQVGGa5li0UqBC/g2BtQA5h6tPnUuxEhmvTFyisbYFAUW26O9BFAmp7CNGGad4BERzHIm057WE0dEVRVBuhNuUoC28wKER5bOOfjYplNXttXIn7PYBDq4+jrbND'
        b'J2DfAAyNYNBwN48LeGOecaJQK7wCqyc9hEMjV4jRqKcfh2atTmtbNlxDyfgIPFq4/SgdFcAxUTKqQGfokK6C1mCyZn0UGihH4QXFeHDZyT8M0sQL1NazRp/Ajahl79FO'
        b'q6OjxC+nMEtiTHfw9pAI3CBGfmvwSPRhzoLgNJ1XbQ9pQNLDt6yQjXrYSqtF55ejXDZi052n8njLHkOVLCIFXhB7lbjWALyiDthjIqy7BZrhpGh7GLQwhuDIWKiwx2sR'
        b's2XkbgEzCPl4rW9zxcwOKcFEDXKJdwC8u/Psaed4Ts/IHV0Q7dgkTqY3/5njMFHM0CNT/p/BeBtlbEwadi0cDGIjALbFqEUE1e5idjwcWYtaxoQqh2Ba0bltjKQ1Qm0Y'
        b'RU4T2HQC6uQhj9Nj/cG8FtSwbHBybR9uFxOKQ8wlQTOcMbN/XPMIym4aKozGlOuMKqAGZMHBwYhBghYcJxfBSWMVtAx1zNcnuw0uzB2MtWNAO0yUW9m5cBEdQYUUbEeQ'
        b'dnh2cINriU8u1uRqvDaaBvB2nJS4J2wQAkMllCtKXOFB0XYEaQellEzl6qpiguz0poRoMNAuJVyEt68aA8XtHoEKZJjh4c1wt9o5tAeanNgEFJsvHIy143TXrYAyEeSM'
        b'xNw6WVazcJv3MbQdQdqNxQS0aho+GOjdR1lCDIHaxcIZCrXTXUbpog3eqiqcHe7M5KWDYXaQvp7Svl0ob7nM0ckDHeqD2Xnqs2MsTQ2y+jF2BF+3FNIFKLXGZz5dEMeG'
        b'GfYh7Ai8bo2l4IkKUDPNPAxzvA0EXQctRGfUh7DDs76XtszZFw4QhN1QeB20ojaxPuaVaAUaHpBvuUk5FGC3HGXTtbDGFnpUriu8dLai8gGEHZYfKumAKVdA40DQE5Ef'
        b'tMv5+auYq0TUiHmuXIKxQyfRboqyg9qlfY4eK1H74HjgWAzBjFIaHNip0P6/R89RbBNVGYT8BXROBaAbxgB0urxY9CTonPQh6JyYqhI0CTDtnq6amOa34C0EU/zX7G9A'
        b'5aTqYhV4Ta4CsAl/EmCb8EDtuuakh8Fzwp/6Yl0KchPTmolKg5RiKjUmV/6CAysXlyBW+y9hc28Iv2nOHQybM30ybM74YSXDf4mZyyLqjnE49VfqDi7N+KvHKDye0Bbc'
        b'AoIxSPq0DzYnIrC513nVlaTC4P8O7vYGrvQWQQXGc/8ruJvadcFem5dKBkHbxg5A29h3pg/MZ6UQjzqYgyhBvUPvrUdg4pbjwHO2cEmyYebaR+xetVV/lemPYNqWiw+q'
        b'H9Q4aBAtkN8HtVWfDVV/NdnfWFG0KFKUJ0Ta9euUSLQb+T6tfdr7dGm4ajnBxlEMmSRKLVItUj2TI+G684Tl6jitSdMympbitJymtWhaA6e1aVqHpjVxWpem9WhahtP6'
        b'NG1A03KcNqRpI5rWwmljmjahaW2cNqXpYTStg9NmND2cpnVxegRNj6RpPZw2p+lRNK2P0xY0bUnTBjhtRdPWNG24TxLNq5BxRvQzCf0tXW5MrSZFVN8m3SfDY6ODx0aP'
        b'jo1tpAK/YRLJnBTa35DPmeUX3Bfa/la78JClJDFVGvwGA9H1G9okJ5BQD0r2zsRxDuzveBoYgXyaMKSwPr2c0sli1iAbQJVJG8UCqAzn8NPkqCQatyEhlcSiTR5qwzc4'
        b'hoODRVR4xFqLpKjEpChlVPygIgYZGRIL1SElPMmKZ6h2cEjCP4EYb3lFW9AgrEqLTVFJURbKlDUbYqk5Umz8IIgFtY/Cj8PxT/LapKihlW+ISl6bEEmtznGbE+JSo6ge'
        b'M4VQmLgtxM5qSJAKi3mx1GTJdpZCZXcbN9SQi9g7qUwB2UQ4q+ahb8QdLGxnK/peC7dQRhGTtOSov5okMoe2cxQElxE+yOxPZXCXkBQbExsfHkcAAipgMR4CAn54qKNK'
        b'ZXgMhYZEsWAc+C3We4vIqERMUpUWCazh1HbPVvVsNllhGxKUQ024IhI2bCD2xXTtPWQn6K8Qbog2b4i7oRYRviF54oQI0SCyI1GRHqp28se/VKAv9X194bJklITwmIgI'
        b'0doqBbUoSy2D2yHeqrFdRBXUYqqUFu0UBw36zHzp3rrL/w0Y2JCN9GRrsScZEOLeMdvBpX6+KuM3GhmFljswb3iGqIEo3paPtyq1jWLL6Ul79i/gSXRopxKUSUQ43vVh'
        b'uElhzIiPFdZfyOCl94R4NeGRkbHM5FNV75ClRxbpxpQo1fZVpuB91U8+Hg/LGGIYy8LQkN0XnpKcsCE8OTaCLtYNUUkxg4LMPAHgkYR3ZWJCfCQZYban/zpozJBzTku1'
        b'4IYaEIz0VxLB0f73I62v/WqvqE9WvKBoz1W81ZKm5GKfHrVDWpPa/SPJnmLP0fANWe6YES9EHeQCMRkLDwpoh1wFKoUWIFms3HdIocYfnaI8ajBVVe5aOAkaJES+7dnA'
        b'7VwF56im1tdc4LbLqUWA/CupjIVxwUJOOrQKxODwFJzk3EMgPe63Bw8eyC0k3GWJMbEh89WxVnJUnwkdC2ZQl8ro4HgXgUMXxkum8AtRb6hCYBYNJ1dCmxLlaKPsTUzP'
        b'4OvvpGFny3Pj4LgEHVSzn61klgDVEWivDD9YS9h9P97NAs7iMojMuNNw2uASNMkvnrOaivaPkVihcjhJLQaUcBjaZfSZbxC5yuKhzjcOF0EGzRzl+wxphZcdlqJRs72X'
        b'D06KHIdzIeiQdASqR3W0W9MSgdjSFUK56g1OOlGIR60BChELxbpXDeWQqByO+J18u/EuEwVOvkNY77wuhQqoB6bsUj21ghb8VI2T7xTioBv2sVFr39KfPVkdP+c5+S5h'
        b'g9ggBUue3EYeelm0D8+xhsGe5LVAz8E+A+fqqJugPKikunpnLHSWMyEy0BG1UwHSYKkJ5JMrou5A6i3YCS5Ao49R7CDrlL5oKSjb18fHUdg4DSpGoF7IMUItqMXHEHJ8'
        b'ZJqoBXK9FwVxUdG6bo7QzSwlZkk4Tz9qSRj3h+cULmUp/jLWapHPo2UTY0xn78W2KNsT7Q8iZpA+ppCzGJ3rX7fUKAaL//pjNLGgXSORoK55Y6BOwc3bZIgqNHk82lRr'
        b'X2aAilCrTmISD2cNOQF18jbQ4szMEC5NCJNJk2hw0NMcFlrsoDmE6uGnwB44gVrlG3GuEnQMZzvDj1ZD5XS5JfppKBPJDe9wtIf4jA6TwGFmWdOOcqyUG1GLnIdcfZxp'
        b'Nz9ab6oqbm04NMxVonZcIiqw4wTo4Y0DUA2zcjmCStFhVl0IqmO1ha6hy2Gqi5ZqsvFcXeqfbtQGBSnElYYUOiSDQ7z4OXoHLPZkOcajNM5lompIYTdq5dDxOBnUhkE9'
        b'NYQNc5jxSNaFjiHsfQ4VbYVKApiScpApxDYu0RMpiTRyO/jPDUXuCQazdJ/b9O1bv3437YfUj3QtMvelzUwUJuuMnZk212uWT1bm/OyW0jO/8W/Go4lfvWJk5LlJIqn6'
        b'cPxMvwMfGiycX1UZmbpjo8vC995/edefrT++2xuUn3OwYunXnkZBgqGDUVSq87pum440raQ9Uw31ffRnBZ9bILkVsi6jODDxJbG1jvWlM+t9JUdr9twZnbq7x+LrkSe7'
        b'F768ttZeW6w7W/z98BWLZgU5W+u88M3rQT7LXzeedPGwQ/KOWeI53XOurTIMme9+AV53P/7GaNfCaKVtrPHyA938/jE/fVxYEi2vsV9p/r2p+7OZJ5f93vmCzQ9xRc8t'
        b'sDtw2jdq+e/Xx6OPM9eEwGbjaQnq5qYme/RnnU195dMdUe8pzaeNevD8q58ojffeWLYz//iCtz/Xi3qt00neNmbna7Zle1+MKg7lTd7OSfyu9K3qsR7T5t0Ft+JdH7of'
        b'f97ELPWPzm1GNi+P3HzPLPVyS+3KwE/eNtAs1nrr9IacfMXXa+8H89Y96Sk/2SRXLI08+/pdpxFHO/Zvcv2w8+mEH5Y+4GubTN90u91YufxKRcPkBB81qw/X35t0KePn'
        b'L8vEY9Otam9+2rw6/JSv7xKt1pSfDpoZbzUfXmr225Hyqr2nl3157RXlUZPvtC6+8PH0aVujP8oLMrv/5h/n2+R3L9WndBwsu9ZoM6HywdWXzcp1HtTUHbjaM2nCz0dP'
        b'5U9YXL1lxuwfv3EuX+d/DX81pzfefsfHl87tGusIK+e7/vFGr3rUjgcvBvqGO68LNfT5Nqb6ufK0wGlG36zofv33+uv8167PfDchd1xwcKZGSaU0YNOdER/n/7h1b8iv'
        b'jfquH8yYGzW8RP3dzbffcrMIyNp5L+ODDUrpzns7FbOYH8AMdJoosfwEX1SMd1At7wOFcJDeDWqiBuiBXDhLCAcmJyiH3O7slkEP3kz4rVp6HwbNE1GrvZev+rwAnD+L'
        b'nxYMRfTScBc6CxmDHK8W41ORqMKPxTA/jEfmyiDXmak71XaYhQlWLvNomzTHOJKgQ84BxAgVVaIDOwU76PBOJgeHnxSTAWeiPvV1guwA6lMUspw9HewoBlPdcBEXik/b'
        b'RpQ/kl1OHUd7UTXT6Q/DEu+AQ9pQObt8PrVmDLkTQ3mOapyaD6paLVij3Qn0Us4cXUDtPgGOXg7kghedQS0yOC+gnji0lxW+d/Hmh+wJjKDAQrx6EaQzg4F66IIc2dDQ'
        b'MJH4231iqRn0smvBveu0lK67Bl0MCp5QhtLY9BSjfeMGnG55ysil4JTZKrinHdTZe0GjLY86tThxDI/2Wk5nutpalBdErrPZhaEd6lDdGZqho+KNi1XBZaAHdaQynR10'
        b'TqA+IEM9aX6fbQZ4lL39fBzJrZ6/KvNoVOIIbRJ3bVRF1WLacJzwEnleZDp8tP0d0XkfIWkdZz5fDDVwNJaOkf5GU6L2PqCBuwBZ9BVOa56AulDxRKqFmwJNJOi0s7+j'
        b'g99AZSgNZXEWrmJUA/tgH1NpHVgzZeByEzJFzIFYUSS7fS1FWSMhN8DJm4QSO+Hg5cdz2mtFk5ejbjZX+ZCGStm5vGiB6mJXa6JIHQ5qsjvuQ2tQM1UBELsGdbzy2uCw'
        b'hiAfzeLtBFrvUhK3d3AQFXKi9fz2SaiH5cPFLlQpN9F5KGIOM1ETYp5bUecqaOvzAtlhrvICCS1erNXHoDaJqpqo7lOCTiQRrX832r+TLY5DqAfvOCcfJwGad+DM9Tzm'
        b'InqXU3XUWHRgwmPUl5AmUM+YY6GJttw+VY/qEAPnqFSIqEmHNa0OjqC6Aa+W3qhUj189F44z5Xct9SQYQLSWY1Nw1UfwkY6O4VVLeh2J9mwnvTpgL6AMqMCPW3k4jQ/c'
        b'S3RpOeDDXqWshzwRcf6qAe20R+oRln0WNBJOomOPugUaR5ytyCOQiWqopneENVX0DkfFdCeZ4QWTRqa334Uo2uPK6UOTCOU6QQNTQ+Si6smYXlUnBfTZAUjJRXT2NAVd'
        b'1V7xwY84v05NVRkQYW6dqZTRYagh/oCpNQCc98Zda+OhSYEq2To6YDeNPUxGtYmEaVLjtCNF89A51JtMTLgxI1gMlZC7KRWd19o4wIURyLUzyvf0c1SoYVY8aJ5UG2VK'
        b'mBK4RG6sxAUU2GtihljBc+o7hAnbMRklD6N0oVm5FlXaJ7GFrx4ljEPl6BzdgpNjd+BB8SJaoAAagU/CGSGi7K0X65HdyXqUO1uQofOogxTOyoB6YZoSd4Eu4ANztrFC'
        b'PCIgDy9UdU7bXzSTQzV0+YShknglXp38JOjgeNTB62o6US3pFA0JVcygvUuJE0Q4B6eZfvU8XicXB6tm5NuZF0SUOYNOc1QidFMjGciBLOoxeSJcomXGo8KlzIVnppR6'
        b'8PTlqVnUajghwm3EzfDC25PSCGdPlCfirNEpdGqRxA13j3l4XYtybJT+CpXplA+f6srpjhQFQhE6y6hmJqoaS8xWOLwta6gvZF04TB9pQ364kg4QlEMrJ4I9/NbNS+gY'
        b'hUM2qrf3dvRxxFTsop0/Ji46MaJwVDaNNg/TqD1BqvbBRUvWRIJpySY6bMVqCRxJVU8m4HWJeOajSwPVWZHVETAJM6Lu0KTmT8yO2MroRo3xzCQI9bqpsBz6eGVQ9V41'
        b'OqsnIw9VizkQCjk91C2CRk+8JUi7d+BJP2QPlTb0CMInnBRdEKBQHw4xHE0L9M54WK2UEEr8NtpFKbT+e7XN/0j98zhXAMBx/0G5w+3SjNLltQVNXo0fwcuZOkWgl+f3'
        b'dSVSquhQ4zWpUkT4Q6pOPmvzZvhnBD+at+H1VXGxpLwpVQDpUrWJMf7OGP/XFvTJb/xfypsTpcpdNanxY75Tw3VoUw+MpAQ1FSKFeF8U/yxW32o0+KZpqH8ChYRhQu4Q'
        b'lcXXQ3Em8v9qWkSsuIHS+4fWS6pyqPXXehguzabuMZqYx3fmb/k7iPmP/g4aieU49XcwtJp+ZweufTfg9ArZwSIqxsnCjtyDOblMHN/ni+VR3wd/q3nRpHlb/6p55/qa'
        b'd3c4aYfqOtUiNnJIjX+7sjr+hjQ0gt2zP7HO1v46LSlQmaJzoy1oNgK3/8c1r8U1K/gbWqH9t8ihsU+uvr2/eptZFinxsRtToh6Dyv83vcdtkIf23Sr+VRO6+ptgR0ZA'
        b'mYyHgN5L9l9J/jfNSLL6qxnv6a/bKSiBeACKj06gng0swtckpCQPcSj0L+snDmKeWP+loStukIObfzXvSZ5/VRn0V2Y2UNlsrzn/vC66033+qq5n+upK8uP+5v6k7lLy'
        b'/6rQ5/s7YBv8GLdEfd42/u2W0aQOA0IJfP+JTXhp6IRRzD/btP+2VimrNTnhiXW+0l/nMJV/iH9ZY0wfaVgTHkeUIaEJiVHxT6z2tf5qJ5Nqybvshj5usJrvYYci/3oc'
        b'tPtbFRGXoIx6YrPeGNos8vJ/1az/hR/KtY/zQ8lzD2slRP6xr4zdJ1ESBtqydpvrOOJUUhr94cscJ83hOz6YoWCw4pRodIACqvslIFQFJVgKgqZhT3Al6dpnMEPk8f/E'
        b'U3G71GK2Gj500MdFxfc5VXqcI0lSwduEsyDeiv8TZ8Glycsfw1s8tsr/+WRE/73JEPsHx5YdqRMpydfeS275hMujP4zj9xzlxPP4+UHmA2vv0dFu59hoJ+Xzj/AyoaFr'
        b'EhLi/mooSe4b/2Aoy/4Gm8bqHDKWpM2kZiJSMTXsgPfNPn9PTBXL79PqV8MKWRI8yiI8ygIdZREdWWGnKGjQ58eNMrHJIwEXxw8ZZQt/qjhAJ1DDHKoCQCdNeaYCgFp0'
        b'iWrBvDeIOamtWMLNDJO7hgxXgWiL4VKAUjtJA076kAxVvBO6gGqpwkTHlGS4rU5cL3wZK+JSCBe8KFhGL1F8oNyUQCio54r9PviDP3FmsWjhIscQgVs9Ux0qF6OSFBpG'
        b'+STkT/Xxplf9TRMhf+C6TMLZRUigAS7CbqrbGCkoqW4DDq0TU90GSrejeggrqIHKQba+U6GEhZzwXEE7vhRafcn9jg/KdSb+2sSOPDTKURtVtIxFuToE3zsTdUtYFFHU'
        b'PYJqs+SoDu0mwur8KY52/gT9g2XVKHTcIZjqyqBpKsqxJwKho5eYQ4cSNdQFyIeTqnChSZtQN7HSdTbCxYp5OI7/72aj2o7HtYFceCqwJLlovcYUAWrsN9E+WlrtpJCf'
        b'TdEiVQypgykMfZmGcuACynUMSvGn8qXaKsEIjsylY7gFFUG5D8r3chgvdSImvLl0vJlfAftpEpS3CXofWZeyvnXpObAuh65Kvt/32N9dkY84AyYXAhqPrEgnf7roQIrX'
        b'EMdZuMyPln++w4SFiZWizK0MvALNqJWFzsBLN4OOj0TTgZn7ouphLFBSYCRTPZZooB56s0CmSiNENVk9yVTBtQuKoZXeO3LoeCi5diRga6oWTkInUZGSWBYL0BIr5Ucu'
        b'sKM1eUPNNlVc8HDf1bwzFuvb2UzkQIVHH8rCbKEqcs8FQzq3Y1AJOtYHkpmF8mnIpY0TUuiV18UVqGMwRAZl6hOUDBxGvVSlTeHEBkQdFoR2k6osOUtIW6yQ0OxQjRpQ'
        b'3eD826CZ5Ee759AhcEWN5n2IFehGTTT8EVxCmTS7hTYU2vdHXYJi877ASxWqOJwSlB/MUDiQDid5FtJpnR+NNDwXnV1gj6slOJyc8X5OCkdvPx7vuz2SKQtgLx0WjWTN'
        b'frAL5MEZCngJQ5V0/LcvTFaZT/PrUQWnJhVMUtAZ6ioeFaA2KBliiL1GPiTgCdThLtBoOE2LU6i1vi+9XcYr3NDFGXLodrBZIlk/25wSIbRnjStRfAy1QJ/jN8TI2x/S'
        b'1FFBCpSxLZmBe8EUpxyqcqDEpRhq6T5PhJLgfuKyA9p5VTwbRQBtlE801DDyhWnXzJCHqddSyGTE96Cjs4oGqZOIGtmUCOmsZcrZihQ4xKAO/iiTBvBB+4axR0VOxMyb'
        b'PvOcS52XmEEpUx83e6fiJ5QcwFnIoyRh7EbmtSBj2zYVdjB2FiUkCi263I2hE2fynYbyeI6fzKH8VJ5mMDJHHfY0RhDsnyAOx2RQrEG7bwGN7nhVeTo6+EEj1BMwaKmw'
        b'nQQ8or4JpqKLiSqYScSGh+zeUTtcYJ0vwUu3dgCNojOL4FFMOboA1i2CC5R2EfefZXDmMdQLMg0VAu3zLL1tkItaUsUcD71429Vy6DRqd6FdS/WLVKJmH6hQIzVyUDBy'
        b'K7URmWwbi4qjluNvHTgH1Is66fk1aqYmhzsuLXBW+p52Xs28BmyWsbjVM6ek+P6ewLMvv1ghoVTqnHOSw0fqUvalxg45jS4cNio8riLZl33pvlaDOCNy+W5qdNykpWaP'
        b'elag3CH5ISObRhwBqO/gt/OJ6pFcCCaiG4XIfsmOMj2q8Ml86kNM+A0Nj5io+KjNiUnTozRUhFXYbcylLCej3RGTqlRdjaLM2f23o4XMcamDlyMmYQfwUA/2sYCKRagV'
        b'ivV9oGi87ppJqA7qtkCdkWReKgeHAo3wqX4cHU+ZhYufl4xngPw/gIodncg9MiqAUi8H78CFjiGeqokcPInQKmjyxIdRvTwMmtAlZkCzWw/lY3qtcMTnWr+2CNO+am7E'
        b'YjGcgRPQE6v/9Rti5Qu41+bPHo8K6op/d6buzVU5+orb0+Ou/brjs/MVJ3XlJt8skvDpE+bnOERulpi2ZIqlLivEqU/b7O0+P7rAxq/AKlTPYlTBDM8K5+fvOFx5fqPl'
        b'971uCfkVY2acq918ef5Hm2uXHcxdBhMOeLywbc3Vg7NlX6793GHfA+GwyHdjhchJaTncydIgQ/R8WsE3o2WHk4L9u+73Dvc239WU+nSeZv3V8TvVM596MfjKnJhjRy/a'
        b'rfnmxwfnZ3Zdb7wa3tGdnLBp1umYitqS4GGrEoJCTtUen2c/VWfL4jFt18PH+poUvJ1/fePibR+Gf1Yi/2grqB0/oeu2vyjxlVdOZh3eX1B5IfudLW8uanJ4ZsNcg0M/'
        b'z1PLstHbUTJryej33vji7su7yuSaLfdeS244NCzSSOwXf/qe66nrXuvfqc4vf9F/SYCyovm9DyJyrmw4kVu30K/h8J+j5o6/ob7rsvqW70rWH9Nzk25/R/7Onqye0ilB'
        b'uS3RKXo561757W5K8LuV2W2KSQG3HX7QWDR2oWO95PYUr82F3xneGpP0raXOCyOLun1v8z/ELjrttaqyZxg0ZMZonNU7dvKbr9ZlJB3QSFgUecxqxdTJrm3GBZJ1K76u'
        b'df/t2ZITmTE7En4quKVV+rLfIffRr67q+bLFKSbwvfdStl9+deLWbwpPFk2xcxuxpDDB2sTj65ff2NFW17DQ7/N7e+9aVWxsRg7m2U+P3z/jKbfoLyuiqp/T+TQJUhyT'
        b'KlOf/tRbx12+c5Zj/PNP/TT87X0zKm2WuMa4uRp5RK5//pdnD6dIw4+NRG9NfXviW9vg7kc77r3+1ZeNOZXqKdtOLnP+2H3Cy2/cPV19c8MldP6P+GcnzbYRfTzimxWp'
        b'I3O3dyk6nDaWW5+ZvwL1HpUETt85uuPrkDuT9Pcd2aB5c/ferb7vGt5fkvn9WykGrxlsbz+Rver9mbKG47MNlq9K+919s6A3ZdXOHPcHL5/tjBdl/PLV6as7X/juj5TR'
        b'256+99Kl3zJcP775o2IK05afX4AI0XOGWnzgHFtPKHTPZHcqePobowMygiLTsF2DN4Qv5hH14LQIji6EPKZRrPcgJmUK1EI2zV44IeKkw4UQjwlUKbR6I+YvW33noy5e'
        b'FZBQCU200nFmmIFUoUe98KYk+lVD6GIK8g60T8KU4NxMzEAQJThcEqviGDau7ANIojInpnmdJlZpbdeR44kxQ9ADBxk7ZAAlNKutiwHtykZfZ8XKtWqcFn7NRrBnse1q'
        b'FkK5Eh+b2S6PIkdFqGxHBNWbCZGok+pdOd7AjOpdPRRUzSTRW9Cncx2HyT1FfDasV9lEwMEJMgrNEVDOtGB++k78Jsk0CmExnmhU0W6UL2HxNO15NqxVM2QDGGVPA4ZS'
        b'dkFVTIPUjA7KVHjfORNV4SPx2FNl2QxIX630JROCCZ6PBM+QgaZcwCTs3FpWdDbqQKcpWt2Bi0zk1OCMMB6qcJtI0cNRJuxTORKAzASeBadVTGWa7fxNy/vDXWJCu1cF'
        b'U46CbjrCW7HcwoJloipoVkGcHafTgudvgt24p8QHAJ6deabiKTw0w9GtdCRmmqLzfbhqfx8JjdI5yps19yJeDnuVKMfLCzOswxwFTn2jYLccGtnazVwkUcFZIQPSeBp+'
        b'nVtNW7sAOq2I3nEjU+hiYeik5hIBc6EnWTBN2B+JSmRQl0h0k0EauLnlPDobBWfZtPWakdhzBMspLIZCQ94a5auC6zaMgSKZt589LrPRVATdPBTCkQQWlPAAFJgR3l7D'
        b'ycdJE3M8mDep40yhTewGzWFUP2e0epnSd7kmBaT1w10NMfeLitWdGH6vaSyWAlBejN7DqFQSZ7FdBXmFNlRKrBBUAE4oRy0UxCnMcoKKPrcKLQPh3dxQoQp/dhjO0RKS'
        b'Ryhlg4IIo24s3qi8PqzVp92ZgDrHDMbUok7UxnC1+HA8SVF302aMpXEbuVHzSNxGKHShdU/AC66FgJWJcQg6C2WcZB6P8lA5lNFBNNBFjQx7COkok0X6C0cFDKp7fD2v'
        b'9Hcm08li7zosZIYT9f7QIVNF4TsC5RRnTNzckYfmqAsO9cMVp1qKaHBAj0W0NiM8QxUMrohrYrEBp+CWUHue1k3QoPQP9lA8EhoQGlAv7eQWb8gi0EJO8INOBW++3Zpm'
        b'jbNH+QPQQmZ/MhUVM2yhXiCzmoD2eBa+D2WgoxRbaLuIttgNXYR8YjCLl6C/I5b51H0ESz3IojvCbLK6CuYI56QspiA6Nont/lMjTPtMsFDRKOaMxAvPOdUfn1XiKc91'
        b'8MfEGrNXPGbMU2V4C6MmOIMOMl3+acw7Z9N39itQlqeYc90pgyYBnYS9qiB7OXAmjshnmOKF4Ims5BdiobeXwcxr4ATqtg9wwFuZiBDqxP1AqwxdFFDHdjhKGz8bNcBR'
        b'mR3KJx4ye1C9Hz8Bju9gJKR7vSkbMjpcvqEqg50yKKDGD1snzHjIOg0TyT7ztDrIURj//0Z4PaRW/e/dHd7QJGCaUGrITnnujyiD/J/vZLldmoZEsyym8EXyW1uwobpt'
        b'B96ON6e6bjHVb8t5YTe9ESRvMu33n2KRcF8QCWqaP9roGPM2vK6gzZvyagLRc7PogsaqOINmVCMux7/1KUBQUzAlenH8pimvLSW6du0HIwQzkbYKMmmBvxE/ID8jBFKi'
        b'nLrnN+ZVsEtBTcBtLtyqeFhxTEYh1MmDqpmU050GRoXJF+IbGsmbI6OSw2PjlDfUQ5M3rwlXRg1Sj/+LcANYZsGUiUuSCn1Xrer4k4hIKcSZ73++auXSLL5+9LI1haiw'
        b'UBtU4v37sNnH3xZsOFTgMAkd1nEg1mcKERWwV0NlkI83FGsPCqtuE0dFe2M4buijMo3sVwSY4XO/LkKMqyyFSooKhJ6JBqQF23G9rBEBqhjto9zF6CA+Tfdi6ZUcf8no'
        b'MCrz8SZ3qINqi0CFDF14QQ31PK4+qNyB68MidDo1+kfZK1GWPWEWGuHiZltPPycvv8BEMig0TgZxZsBzYUbS0c5W9OZnC6Yth6ih9lLMaBX222nj7OVUAo+Uoos+KM8R'
        b'M0zBtBzXiYGeqi64QMXU0WrcVjhLzbKjgxxYqI756Ci1FF3CKrYddO+xEsqlOnNRDR1D6J2zjgyODeY9Hzc4BxNTiEIJ7V+GypQPFeUet1jlPJh0i3hZit4lxUS5nekF'
        b'Yuc254mUpfhj1Y9HooIuxBvMMqw4XNH266dLzP0nabya6TZasuHFq6+lFRTodw1btsZqynB3i5xhGkurV5lFBp4+N+aLL34XfRH0lMnCUzOtxqSP35SXOffWzzeVr077'
        b'9T33Vudl71yN25f3+/sBL8mvHf0o6KWXbsz1PWy0d32AzzO/PpM4L9st7uphS/OClDFp4gUXf7A//1LSnznWTbGHb05cs2hJm8Jt9pvty748LzjeDHozqPTd67lFji6f'
        b'pG9Qc5j7zI56aZ3V6Alm04LvfNice3X8DZPnL1/NSbs8lS/9RHu97oVbBXd2V50qfUv0qnL/na6Pq5tWFB9yvKk2/rSnsEHvxmvKELO6zwu3LVh945OavDNvyBb+lDfj'
        b'qOmoFSsu3xuVde1w0r6Mtw/XJf9cdE193ALPt99aebTltSVBwz86Xab49s9ru6qMcmonuc8aOe/+Yf+nZYGb9zjcs3Koqgo8V/XOgTd6lm8eeX3qz6vaZg176kuz27sO'
        b'VmokHVMOh6+7bn3bEh/5SmuoTXBS6I21Vzn9L368m+5e4vqqVY/l7HmRVa6j3lca1HTqvDNunMnNe63DmvXATXp87Ah3OwPRMxc3C89u+7P03c4fwj56v+Z1+/vTl2Rr'
        b'+J0xPtA7zNo1zWtrmfoKI4NXxFO/NW8s1j/rgTb+ujTYKLFM/mHMywuW1fw+Q73+aPCY+M+KLhRef+rZT3KWH0t6oyJ8yZJbf+4pbA83i3f6ySOjo3qT1p9F76eccHMx'
        b'+vSu8PwVu72vNMa83LwqOFzR6nftjY43uy4pvz3XO/JdmNv43s9/iE0UO0wcd6h/G1oQ+/qZpm9jIpesTNW90JNuftNJp6vYdca9tfq9U94p/8j+5oobRu0b3E+dvB7U'
        b'abpjScMpv53+gRdiE+3yNyQa1957dtiGsLytYw+Yxux7rTL4Di/7YxeXO0K2sDhc4ZJMl/YRgWD+hxirJaOCh0wZqSEjlKIulU8k1OLHzCNnBYhVppPmcIEy0VHoECpg'
        b'wqMx2i2meoIeqIfj9LS3hCOoZbDlHrHbM0cdgTN4lcuM5Wg3lfSkkTyzdkbHVydTQnbaDZXL7Ebg2odad/Y5hyuVUm7GZSS6NJjhJsw2ljHKxG6oXZ2yk/rQpuUTsBzy'
        b'HZm/aS3IppyZCGpXYgZ/HBSSB4TB78QSKbkPSvVE2Upf1JrA+BTSc3SeuaVBJWI4j1/sohLnNEcs8GDpgzoA80nw5zmZAbGdrVb5msqx9pT5oA48Cvs3KnhOsonHlOqi'
        b'yghzAdSoEaPFnUYcNVmE06pw3xGYqmHRg7lL26QIQQd5TnOTAA2zoZqZ1FbqWVKjRgG1SphNY4rApJbOEMiVOUEvOounUVjCu6O8cexJOeZn25TU81QDY6u95zN+sBJV'
        b'T2bzi4XIouQB+9d4VMokZ3QeKqgTN2Ms87EI4unTUhj7XO2oy6SIkZDLBIk+IQLznBfYNJesXIXFkEDZoDjTyh3Mp3cW7IUeaq4IVXD0oUDTXDLjePMgM7mPU8Ys7V49'
        b'wiqPELGHGXAYc4i2qGib3YD3oTqVxHoOC5ldSuKaH+UtmCnCba/j4QDkY2GZ9Mx5Xiixts7DrOXeFLy2AUsGh5V2TMA6Ew0tMie/JPZCMq5Zz1BkGrMOb5VWWvUM4hiQ'
        b'SJBsyMwnSbWESKjawIb1sHTVgM86lImy+vzW6UFvMjm/INMtZijwAWUlPYR9YMiH0Bi2nprcUVe/SDtxjRpHBVqpiFV4EbLQSVwZSoMMKtSqRFosdHWwndyIJ6WHiK6B'
        b'0KrGqUTX5rF0KCQexEdRPjrg6dzvezAOnWMSacuWmUPYcszX5AocY8uxRMmGYw0qwVORi1kBW3wwZuENHcCj3QoDWnxEMLrIQmG2BPc5MJ+D2pnHmEuhy4gKEiqNB7tx'
        b'FK+eDzV0lYShbrdBUgMV0njONGp8sNgKi8QMdBGEGZoKYrDLjvTtdtLJwprhKJORk54JqJGYUFTGPszUjDIVo3rUJqE7Wmsk8SJFJGY8622+3sPx1vMVoGD7COaoJxOI'
        b'XiCX8HOOkE31w3gEalTchstyNYMleJPS2S3Aa67+8Tbj1CrYBWqpYTBkqdFRmLHCSsU7YlrQw/hHdU57uch14SLaB4+QOAZxy3VSVd2n3EFZEjgPx+AIlQHno7xhpKQA'
        b'lD0NTpOlRQsSiSwxEWBO1FBRGB6tXAd0DFWpYDKrBWsFnFDo/3+Upf5XjmMGO4Zx7rNz+fBvSlXyDXIqqajRH13BWBiBJSEz3hD/JzIRkXuYf3nidZ5IN1JBk0Zil94z'
        b'V5cmGWJRQJ83E6kJplj60cdPqBOPB2IWe1pQ+1NKnHUQm+QHaqrvNP9UE8mJAPEAixIPpCKpoC2SizSpvKYv6FLbYVKfVKJN7ZH1sbSnT6O5i3eLefI+lyacEj941BiX'
        b'ylQq+YnZ/lKB539lVKySn5yGDPfNv2+qYnPw71gUs07cJBWaPjb4uVEowdtHJDNxMZSA60nMWRr/nIZDp0HQy/GvG+oq+9ob8sHmrjdkgw1PPcjbxJ980gbyayb5tYvU'
        b'o9Fv73dDXWWEd0M+2DbuhtZQmzRiBEXNd+jAsHkw+r+7oRgwQLqNq3cj87KbY95oxNoOgg0vrGH+YwTR/81fuVgushFRRHkylEPlw+Ixzw1DtcbO4ijo8XiynReZEOpB'
        b'heuPDazeb/Ml/DsDPMINyLmHbb7W+acEcAQXZYlOjneZMG6S68Tx0AHnkpOTvKembkxR4nPgHD7lW1A7PnnaUKuOVK6praElwzxEFuxHRagkaCEqRGUhEnIP1iWTQTcU'
        b'UDOFlTZyqpnMtSeIKhKeRsQZoIqtgSLUrcP033DMETKJMYorPtqnuOJTqYJmhYuoaBLNgn+JID2JM1gWjs4S15G5kEf1yJttoX087sY4DuXKx8HFsRSnjltZG9xXJ8uI'
        b'+Z/dqAJnnQe1NCc0pkDdeIFYwaCj3HgNGTVbghIoRGdxdfbO69BxnJnnDMfgXHCUNXUEZKJT49U4bgKH0iFvAuqIpTVCoT4DRqvq1Mc1noMW3FnUnYpHgtZ4bhQ6MB7P'
        b'9kQOsuImOi2mNwEaodqsiySbwBli5uGMAakxH+2mxidAvAKfGI+X9yTOEjVPmrWU2gBMg/00RCfOqMoZksTjfNsMWWXpbiPH49Xkxo3Y4IZ5w0JamQxdMFC1Eg6kqkMl'
        b'GZkuMqCZfIouGblstEc+Hq/AyZxk7WRJErOq6kX7IcceFerShqpbc4akJqgyp1XN3DIOWvHfKdz6wCmoFNWzAAlHcPcr+wYED4QVrmo/Xhxk/raohsTZhsCR8PxN5bbM'
        b'mSpDh5nHgy7/XWzGdVF6koVA1gvO5I2O0Db6joKLZOnO5hLVZqOMrfQaZ4E/uoArK5vMFos1zkPGPnQy8/hwEpVuUOLJnkMs7o7PwbzaOTrfYXpYrqHrcgdqE0GlB2dI'
        b'Bh8dhy46+F48nFXi6Z7LOaKquXAJStl056A64ni3b8bV13AGcoKIxXmDUCXtGypbM4vQ43ncyKnz8LA00woXKO3pdNNc+nggoZeOZSMqYn7+4fQ2JZ7r+RwqsZyP2new'
        b'G5t9IYE0D1mYLDvZRWfxzBwgzT3kkEICEETEGynxnC/gtHQXGMI5Sn+gxxlV0QyQTvwtQE8SGU8vOE0ynkB1tJ+22hOVeNY9Cai40xOOwEW2kdrg+Gg2FSyvB87bY0Hn'
        b'ELoX0xZvS7RDZPq9uJQtXtAGnWyEzk1ExaomkzWDBwgLgHV0IjegVrbvd09QEnQm582hU6jSG7WPoktnC9qDhcD+wXXuIxq5CwNwbl07NlBT4CAirkN8OANfH+jwY0un'
        b'Z7GpPTo5lzQ5A7UkqZYBdLgwE5wcuADlCDP9nC83c5cvOgZNrLl5eJPVqdpLe0t2xtEldEa9ptPmLkAlM1ArnlE/Ev2j2g9yVtIpnSNHvWwN0Yx4CdnMIHOKGpewYBTp'
        b'JiZEQOX8OWuiuzm/NIXIKY76Bv19VIcqXN+IBXRSYA+00i6OXOSNWvF8BnDDSUiW4onMZK0Oimeo1hCUxtmrW5KVQPJVz2EEA+9M4mIaz+dCbphy4So7totzh2PiRWsb'
        b'7TO7f1cJ6CjdVVvWjmTxJYahvEAzVEMpMGpaDHvY4klLxGu4hY1LCamtTZfVVpeiJcNzuAjLo5C3SBOvc9JKW2i0oiOSthrX2kKGhdWHMmezfLnozEqZQMze4cLUoHWo'
        b'i164Dp+BdvcvGxVVJJMIRKeOaz2I9tHsHlBoKcPTGMyhBjgZjIoc2L3veSzepPWPK9suIkLkxhE/LVjE3k93iok39MrwVC7mXCIWT59OLaLGR6Dj9twuemRkJKloXCE+'
        b'J2hzj07eJcNzGMJB9dwQOIMJGBM29aGdNRN/V427m9Q3G3uYNxxXyAiU4UlcwqHO2CWjgJEBLAefI0S4Cpoo+RZxhm6UDGBCbcied0G9DE/hUmJmemwpKlfQClcYjVQN'
        b'jghnJnt51zg2rhl4KZNlOnICHIRc/GEZ8Wx5aBk0+bPdVjVjCeTimVqO5Vi4uHwl9NDv0T4oMSJiLLeCG42yVqAydebtpAgOuaJi3GcnLCehDidMzY/RsbBHp+CUKljP'
        b'GFtndNqcFVS+yYpgGCwJua2yxMuwma4sDy9Uhopx+fbcelf7VJ693Al1lkF4BsYQbWr9GNQ8g+3QTjhDYgrhnrtwK6xcoFVlEwodW/DhUUwtxhSQ72AIjHKhS6jeNwi3'
        b'0obTh9M20DhKoUlHCsrQiSWqs4cMFd6X6Cw9zNEpW3pmuPho97Ml5AB12UYP3oLtdO277yK2vX27mpHNEjkjJ+26LMLKPr+FdIGhzhDBgmdnB3Qi1SHRMAy6+o4/nG8N'
        b'Z4g30yFKGs5BCWtkrvq2fhqJ0skm2Q2H6AISPNgb+9EhXCRtiOtOlEY7QpdmG5SxenrxFGax1U57i2ntekfGJx1EjbSUbWi/w8CmUp9NNjHaRxfOokm0LylRS1Cu1kz2'
        b'fI6KbqIsqFHwdMWK4RKq9KEBEFfCIRJETQpnBUiTo8OfU86yIGmmQpOa3C0LEdksVQV/0h8Tw+zw9i3TWv2piEUEupw4m315yVa65msRpvlhYQ5PeW5jXz4VYMD9JiIG'
        b'0GHba6ePZl++EiKZu0tgvoDGahizL7vVtFfrY1aFcwmL2zxlFvvyGXc1l90iFhIoe6Mq6JLedD27o8JMjksMc6gIUJVp7625CFMqfJaEOaxcF8e+tHYyXFPNLyQVjXg/'
        b'ThW5KG29JPEWT2uXzwxdzL4MmSRauUBEu+ngb6jGUfNpxSQT/20iGuNo5fw5xlh0DJ5PH/S6SJZOY2ERfeMXa7K3e2aom+0UaFt9reZrcJ+XHyb/XphBK/jDWH3ns+yp'
        b'vNBhOPf5ePrvR7ZT5kOZKzkXuQS8z6EnAdPNEsb6nfHaZY/3z2YOFSzbjKr1Vb65KL0qQLt1H1pw5WF0rUxjkxfuYjzTkWcdCNi4lnX1VpRRvLVAB2V7yijHR40o+z2N'
        b'EUIaozKiZNGU+qMoRatAIzcksfGRUZuTyHHzuDBKOlhgJ7waZ8ylED+jRuMhzd6fGA5Tm0Q/JTrrG4DZ5CeFoyKXumdRuWzWrjm08fPGLdM/JQojsbWWH53jg6fE3z/2'
        b'aGytWFmHa7E4a51X9IK/YaDh3m8bbzeXnzpyaoFuzNyjYy/z6roLjvLz+OwfZJoazWkVnzeZRTS7FJ17s3rq3sYVm+K2iD54qkTnw7ceGM9d1V377fvbXtn1rOFPLVsb'
        b'P3xq1ZtZFt7P6o418CwyXxQpej3SelyksV+k9pVIc0lLlv6y+XviZtl3aW34JPWOxaY1Jl3Dt4VM/OrOPPfQP67O+mbB2C2c+gtzJvuaPx34g2l+8djEIo89Tj9M6H5h'
        b'/GSfY2hLi7rJ87mdc1fPd35nn33kjKam2xPz1nfmD+/MXmH61Ib3nl71Hrof8H75pBcP3G06GxN8ZdnSH1JO7OhoKlv1QcVG3Zqbz2To+P+Wv3/K/OHPbcpYu2rY2wey'
        b'MvY11p/yE2fcXzfvgE557ajTKbVnRtsV9tjZyz8u7H3zvYWvrV9z7cXLda9PvHn22Ws2lt9b2DRdnvt5yWjv+qrbyxtuu3loW0/1LdIzP+j1+8YZNt+Xt/+OvvC/ZrEx'
        b'tta2uPSTezrbniu4Emb2+QivI/Pfe9XLZ91bFQ/G5K04bXLZJfLHa0fqd5roWAfedn2jceWbJ2fnpm/93GXB/HGzeppqr1z9JfLaZwuuz9k7zePKuy+0FhU6zH9ny6Sf'
        b'x66b53x+iZuxQUhHjfn6xY0vTthjsLntyjtHrvfGXCg7tcx/6ge53xvdP6Xz6pm2faXrTGzSqzenbEi6815r773mCRGXPxkz9kqQtrJxUWFH6xGPvX6WXhUKbyfPW12G'
        b't/MVnjwKL/m9q8PUZczF0IWrPos9qbmoKmHVi3ecl1yrTKp456XUt9979bczrV8+N/pNo8BZGT97P/PKfo0QWy8NUeXtl1YeMayZu6rw7hW7B4U7blmPPbbSt2dJkNlT'
        b'L9VkGnb9qreiMvSdivD6Wt9cw4zzZ6uf+XPsyz/+ePbFTaNDrwXlo2n3/9C6sSr9g7UpJ++23R12LcPu99tu3vtlbusaFNr0enfJKswbt6IzS/BO8A2QcJLtPKqeigro'
        b'7fJkdNAZ5TL3EWJPaHLgoXUKqmWuMsoniejFtr0P8eEtM41ER0QCPjqYcgMurMEnbyvx0I3lD5GmVSDvOhkdpVkXwz7Yb4/l8jPeEk5MnPy085iVKgWm/vGBku3ElZCX'
        b'gxeJVdqLjqYK6Ag+MzOZgY/5CmJJNx2q+qLyCFtQMRyhWqnklXNwwc64QeIUF3ceZQeZMNubE/iMrLaHDmMaykaAVj5EgIusOUlUtFDZ0ImnoNMoh4dmdCmB2T82Q8Yu'
        b'FexEwslRjp+agHpJoGGmKEnDQn6TD7XawbWarEe1PFQtE1j0h0LleJ81qD5ApSTDEovKN8oJTF364ifBEc1+X0tor4li+P+tMc6T7ynV/+G18Q1NZUR4fGjshvCYKHp7'
        b'PPM/uhXv+y/2I5eY9L6X/QjCn/0/IuF+/49YuNf/IxH+6P9RE+6K1cR36V914ff+H6nwW/+PhvBr/4+m8Ev/j0z4uf9HLv5JLGcWP9Lv5Xqa1IE5sePR5K1EzNU3cw1O'
        b'3IuLBXInTd4gN87sBlyX1+fJtZ2hSJe3oHk1qYtwYnEk0E+a9C+xQbKhkVdJmqbuiqVWOP9oXvw17t/vwi3cx6lJxkLfHajohih2Q8yga+i/OUEm/YY6pKwLxFBnKjlq'
        b'/4ahDpdmev4xpjrk8J+5JGDwOboO5RECYrxaLIUck0c81Wr2HenEkcQggCSvAqMJ0Zr9HmrFf8tD7SNANHIRKeUevow093/ylSi5FcdtEKKF/wX4VXikbok/A42swHSF'
        b'uzpRxoXJ0URLLsWW0JXSTcSmkIRW9aGxqLpRjW+gradXkCchJl4Szm2bmq3ZtthZo37hlcQq6J0S0VdhnuEvR9t+9GXYyqfOHbpckFZYmem6p+5wc3ZzhuWhtPFaXPwl'
        b'tVccGhUCU23WbRP7QDaWt1QOdtQ8BBMsf5RR/WM0qnF5xM2Trq3KFCAQKvoQKo+5Gr8hi1gbFbE+lPJedK/TCLx/a69zu6S2zAJv66hQ4rU5lPiDGDBhG1Ry37rnYwet'
        b'emHI4h7Wv7hN8Scjwu15/O3FzaVpv/OY5T2XjF1+AuxG5fhoIR7XPLHgxBAsjxifEeiUH8pXgxyogeoQIkGZylAFlrmLKKBpLuyHcz4OJMzPfjGnBi2eZoKmTziVilfC'
        b'MXRyDmq0R0X+Aifo8RwUh9I1Y7KSrJnNgVpcmK9yqS4JRUqP3UO4UY2QDqU+vv7+BIknDRCUqFrlFnevm4wz5LKmibEMsiEghVMSDt7MqjRIK3GjiBNCruIaXs2mwsJy'
        b'E4LMlErVsQi0VseQiyMD7OIpJpgnLA7EORQl/2JZxymJVBw+0iloccrPm0ScSL9Owo/54QqtrVOdwKZc1slmhjnc0dHhlIT9vj1z7ccCd8OTk3GynPv0vYpwNbw5sxaI'
        b'sOTxs6sDe88w97uPJVzxHU6b0/7NVElYdX37i2VuH38qEOnbNKpTSUGaIauCFmulaiUGc5yaIx/ecPC5YiUxf5iY0WTv5PXpdge7OltioWLQLPrk6BV6GFGsuWXv872J'
        b'13RecHgBbyV1XhgXOJfW+3rqqWtYxsKMO6d4JimYfveqUfo1MWetydlxdiPm0K+2r5qdy3MF2dwqbtVKa9q8CLWECc/lvoY/fcTt6Q2g34XvPvAR/g6vxY+5vYlRbI72'
        b'wQlhzE6U60XhUePxOEOu4O0G9bFLf9MUlA2YHn3zaui8RVfi35gpb4/5KNLmws3S43aKad/JRxRMDu6Za2/5zSkhZPksbuP3R4Ub74iqDhT0qC85lrnkw2drfokcM+H1'
        b'y3c/+/HzV/N/jdfpyC+82VGw2zLcZq/z5JWfRaf7jje3vZZ5xyc4yuzr3K5P1yXPeDCmLGP7x9vGxv8w3iV25cb7aJRFg7HbBzclidfv3trDPacX+H12tOefyiujj71r'
        b'Pr/MzrXnVklw63DXQDXL1b9uPTK7vuaz4sbh7xtuvzYqNPdu3a3tIZN1pnrmKbwivBWeYTegwGRHlMedD5fO+WDRyxPulPX4jhyxtqOwIGOCdf0i22Wz1mmMQdcvvTHr'
        b'k0VT2qZcnzDa+4vKfecXpRo6N2hHf3WwevGqhTovXhrXmKr2RtfaiuFoTPkr58tvoW835Xx2V3vf+J3VD8I2/rF544q7We++uPqK3vEj1qtNDtyY5zC9q7j2vaUjbtzJ'
        b'mfrr1PuX3Mf5/v79x8cflBho+q+/+KHyyoqPxr438mODi0ebJ79z6Kslty+8Pn5r5qrtapt++/LLJV+//sr6c/Fv3vzxzoE/ZpVfivMdX+G0YvTabTVnyqYO60l5u1yp'
        b'9f3X0yoijvykFaHQZRxt7fytPgpiQ6nGqelDWoxgBwVQzxT/hyDTZGwEYegYOFIKBUICtGvRnKl2KJ1Yu/g5cJzYdToc5eEMCXZI7kFMIQ8TgM2Uf/RCeQQ6KoVKYSdq'
        b'mkQhNHA0Fg5vgQvK5NRULW3I19FBLfKN+JhFx0RQAcQGhVShNQIVD3DUnoQH7YGiRMahHpsGpyEXDqJcPziDjynI5BfAIU/2MB3SFPbeKvZVDTpCFgmGTkgVMKoV9sKB'
        b'Ad4WdaFCzNzCcZTN7ICq1UbgY+sC5o5VdWvIBCiGPZBPh8UTv1uJsysciemIGpY0jocJ1qhiFrO3Or4xXAWY4dTiJxHAzOaNlOVe6gGnSZlZXiRuqAyahRRdTFCPQSHt'
        b'rLqvDTTACR8vP9VgrxKiUPUq+szd2sqn/7CDcjN83mF+nokzLuikN0UN+yrwFE7a7i4YYhnl7H+pzP83BtRDeOaBI5Ceo8f+wTmqPVZMvbMxDtWY+l2T0qA7hPcUU36U'
        b'cJgshI6wW455VTHlUbXpu2q8IQngQ3lcXcqfyvHbhBsV7sklcsqravLmb6g5slo06amdZNbPkUpuiBPDk9feEEeGJ4ff0IiJSg5Njk2Oi/qnPKooaQQpcyT5Nbz/QCf1'
        b'GP7TA938xmMOdAuy3mpQp9/gw1wvhUK1jf3EhpCG2iOEQbwcaVU/m0hMJqjenI8W9XtLEP6d/46+wh/2koLPd3L7Gj0GC5MBxAiK3o3CAVSJV7g+dIjwTs0YHptYliFW'
        b'kr3354XEr8K+CLsd5ht+69U7UZrUvc3wIlHwPe1BLlVET7RtuKFFJmvo0rP7B0tPvjbJvH8ZiNmkjRxqJDOYTxMenluSefE/nVvdw4+Z29FkbveMwWxtCXSwsRvMr6lz'
        b'Y+ZIgs1R3v/d/IoemV+Rf2y6zxUJjZZw2VaLzVxc9JpIz3BpdGXih74ibtQ7Is+5r/3NuVP+V3OnvT5p1MNzN+Kv5m7E0LkjmZf+47krfczcUSVbtj7q0pph7/+YmUPH'
        b'JWGQs/7JU0fk2H1k8vh94mjxP5y8R8xZyMQ9GuVC05+ydbYkgnM/H48Owhk1zMijTmhml9pbzIXtmGPXdbq1qzPYQYt+2YRZZvGE33FRYb4Gq4PY9bewHIuKm4dJucTw'
        b'GSGhYo6p6PZIoDUIGtVI/SiTg2ObN7C3V6lz8glaArm2Xzcqibnt8UW924McUam9p5eIU1umAz0CD9U7YnPkUolyE37hTfOykfvdtcFFd27MW79nyeZ+JF2pvvxFo8JF'
        b'RQcvlBypuSWfNDbPz21rQMJsTbvp+nJFcEj0VG3X2sjXkvdE7Ln23cX7XxZ8qtA2ifCaWu6wf6Fthn9bSWZ4qNko+xvf7Mz/7EL2eb93RyyNvfd9fsKDT0Rlb2toPWs+'
        b'W6dUIWVxhNXREXtHW6LWQSWoBh/EgiOU+1GmYBLRgw3hlEYvFxLQHg3GUlRC9xiqFyJBmokjjv32UIVZFg9Tdu3YA1mGg0NyY+EqQ9gShmpp4VtjUTM0UHYGZfOcVbza'
        b'TsEK9qFK+lQCvSgdMzvdjn23efQqr302Y/DqUp3sPelNnNjNBs7wxJMBaqY5wzDrc2jwJeFOKx6a56CMR3Yp3k9/aVN2Q07obmJkdCg5ONkt2T/YutJ4bV5boAHuBHyu'
        b'3ydWkeR8J3Yt/Rs6ktQjfgjo9UhDhSRLkieyr2W0iBX/dFvrFz+JJOfDRdTA6LGnFz532dCOQplwaLMYnYIWaHiEcmqo/irNHgqldlB0UH5QPVqIFPJ4emskDDgxipZG'
        b'iiLFmdIMfrk4ShIpiVTL5CLVI6V5wnI1nNagaU2aVsdpGU3LaVqK01o0rU3TGjitQ9O6NK2J03o0rU/TMpw2oGlDmpbjtBFNG9O0Fk6b0LQpTWvj9DCaNqNpHZweTtMj'
        b'aFqXhHvDvRoZaZ4pXa6Hn1rFclF6GVw1n88v18NPyS2ZBqZsoyIt8Bv6kZbUlZ/1DXW/8HhiTHnXcUjgHhL5y2IDe8TCmg0N7INZT0LHHyGoGn1Uj1x9UE9R1EKQDjE5'
        b'FzX6Sav4b5HWGIXobsZ/jB01pLUDsaOeFKmJ7BgWLIp8IjGhwlkRC+fOt4iOjXtM2KkhK4ys8sddENLYNd5oP5yg+5+ElglwXAaZISpsGjSiLAcnnlvAq7s5JKYQF3Nh'
        b'DqhclrgxCD/oe0sJbcFSclFBojmrwvdGWEjlE8MoyQ5ejMr7Q/fyO+A8pl3noUkVdQftpgKcL+yX9kfnFbaloCx69Cw00bf39mMe3e2hCT82GCsiYO2FzPnOBZQBp3zG'
        b'eUOahsDx6CyHOlA9qqQHy1S0T9+HBv2FLJ6GoOZ5qqL3gb0oy8fJ249GAJBB57AEAR12QV3MDOAgHBtNiTDBPPcQDa8vCRSAjotmQ7YZrddZiXp8oNHTzyl+liMpRMda'
        b'tBR1azNrhj3eblQUmwIVzsQNuBQ6hG2oUFPlYmsuZta8/PSW2WFhTaA3JJA2Qka7O9cS7RkIqw6VqIp4mkK9kM5GKw/LvQWDoqDzqIA4C8BMIO3xAhuURvx6Yfm4U43G'
        b'EPeMo1MwH4vTA+HteUf8QtV8dERlz4SP96wh4e2j1+qKjGZvprdlpgliznCyPjUYaOI1mCMvHyWUUBMVEgmesxSjVnpip+J35Qv0yLsOuyO2kqs7C9LsU5C/hLjYwufR'
        b'eSeF3RAfW6jVjOY9tFDgfppAdNlh8rLVGow3WDR6wkCcen5KHHSbTWP2pS2QtYO5/FqDitmBSl1+BU6lHQ6yXIclbGhHp7z9HFX+vnShirJdI1M8mEsuyJ/7mPDI0VDK'
        b'DL1EcGk9WSUo2yPZgc6VNjohWoXq5sVGRPASJT6kuZbXOnYUTVuEZsr31LQV+R3NvDf2fZc5zyyezKt7nqz0nHUrclHjcN9mxaFb0tQrsZ16y6N+P8y//vy3L7x+8b6H'
        b'tmGcS5vixzD7sMnvPOf3xZ0TT4et8Fj2ps3t+58VuL71W6alrP1ZTY87CTqXbX7xSPzM4qf2iqtGftrrDMd2N78Xe/Kbum/qv2lor/8x8djttlr3jE/+eEGn+NXiUXXD'
        b'v/jG6LmXm1P3OoZ80bz988LnrA8m8B4/lOSm3Pnw6eeV/4+59wCr8j4bh89iI1tARcXNFsGFAooDkKkyBBd7ypIhCKIge++9ZMuSDYIgyX03afK2SZs0bZM0SdN0vW3a'
        b'piNNm7R5892/5zkgKCbG/ntdX70aj+c8z2/ee3bEGE1/L1H1+q8ywlQaFX5w/Y3G/5G4vP9rJe93/Cquvxv2s74DV93ecnnL6cfWrq3vw/caHvzlmqHfn4+NvTX5k2MD'
        b'VQ8Sf3npo5jxytdftisyuJj67nkFpR1z2sf++mnhr1vM31Q/8b6jdoR2t8mbJl90mJz46uSpIwa/27rjyw4TjV8vvHr2p+eVhtqqT7631umLnvd+ndr671t//WDPe8e/'
        b'+lxcUFubYDBguJ43kCzA3VtLEolQLIF78qm8T7Jmu4Wzi5EZ/5sSNIuiRJwzIZc3+2f4i1glAhg2lboS5LFIlB57NlEaB52BdazVirdoWbMV1mnFEgu4nBgsvIb1zDWw'
        b'eeuqWYJjMMVP9ABmnICIBGZhGUfaOJG4T4NbpdgogNj+Ur9xJUO4nSDCRijcw23vFg4C6xlDYlY97x61h0I+c6kg2YF1Vdl5dZHmscy1Vskh7Nfm3bm3Yf4mFLlbOIkE'
        b'4igh9MJDbyFM8ra4RisTrqqrC+ui3SYkQlhCMqb0V1VHaON7n1zG3KXWJ0owwqXd+cPsHs6dxVM9oniYc0go0DgghvZonOaLkbRAhYSG4OgeUT0iNPREmhim6ZdC7hEt'
        b'IlWd3BqYIYojrqWYd4btfRyyOTn3spoi6yThylM/JWyFth0ivIP3sZo/2R5fLUJsyH/UFaiUZOjbG/g1tGnD6GLpWjno4gmWqoI4kc60iReUx4go3oEiNRhwl9IOWXnR'
        b'OiyR53K/DIn4t7HbWSoX2AflMgIN7BZjJhbt58FsNi2YS6XjqIdS1AWCIpyGAmjkzYNzlkQ1i9yJUkMBZnPUWuW42D4CSxN3cRdc5cVrdUul//xCl5GZo0ly6mtwgU+z'
        b'ayImNsw14mEFLKCBY58qYeJDWMsXgYFCaIvnr44zjezGLngoEmgcFMPc9vXcIHpxUMkEzUVpE/JYJLmGihh6guMMZZ5uflJ43gQRlivDyfD3mXzxjDK84JaiIqs7ocx5'
        b'jOU5Ox1Xb0LMN9hmf5RJoFbkfhGJVPgaFF9qyalIrXDs76Xv+T9fqMnLc+/ILv/tG99hv6SqSWXJx5oqSFOfNqy0DMg/s5VTxL9qtuK04piCYctO6xkVDEGm3perpDs9'
        b'seZnr6i+6etK1b9G6+N7JyzNsNQ2YSvXrkAqrj4q3/98fRKkVcLl/BIiwmK+pnPBDxcXxE+/2LmAvRWQmBT/HPXJpW0DJH6BFoFPnfZHS9Ma2EcFhOlHhOpHJPJdUY9Z'
        b'HFs6heerae8n+Job+MnSzHpc5fH4kOCIxNj45+4PEf/Xr7vvd5Zm2ySdjW8I8R8Vm1fwi44NjgiN+JprfW9p3l1cl4CAhER9/qWg/2QBoYsLCEkJCUr6uo4YP19awPal'
        b'BfAvPf/sSzDN5fE9fe6PluY2WgSuxGWoRVDGD/DtV5C9uILgkEACmqeu4NdLK9jMYRX39H/c2kDBbxFanzrx/y5NvGUFdD/31Es3vmhTeurUHy9NvWO5Ds1OflGBXjn9'
        b'stk5Lvd43IxwKW5GkC/IEqQLUxVuCDizgJAzBQhuCj2WfV4tZocN+6S5XP5rYnaev3fAFz6rdkbmIDA5PIRrH50Yznp0P4LD+BC+/QXXvjkmNvFJC8MTVobFy3rCA3Dq'
        b'R/18UwKFI4bSlgQucvPhAvkC4VRmkKGQk2E8D0M+11GQl3yhz31R+JWBoqfUyc9dzNZmrPbZpRDBLVm51M2LXG5pp48CcULDQhKfXl+fzfqJ4qL98pm5uSBTeRV+nmQj'
        b'YImWMBCE47z1JB3aT2HNI7MHVjwed+PMwiphXlYJ5oMx97/i3lm148STcV50udrRnULOvSP82xbm3okMffnXf/AvDmMOHuaa23pf3PvzWrpkvl5b2j7pJWuaLFdw/Dy+'
        b'yfcTn/+8l62i9PWXnbB42YXCx6K+ioTLJ//see5c7bNV7pzZmWHu0OnFK7fY+g03TtoEu3EjJZLtu6HcUMSZRzZZrGWwADOOQoFElTVXbE7la35X79dj75ASPEI/WQpJ'
        b'/aqApoj/G0RxggU9YPLWwC+Dw8Mcg1wCXAIif3FXZuxn635Uf7b+4/sePhnWL6/PXf+y1k+sXF5Ubl4nGJOT/zBh2xMhcauHx8WHSuGEI1ci4be5J2WRipyiKFX9ibvi'
        b'hy95/HZWTvqn57kdlf9bRcJ+cgFPJ8qcG47vLyBYcsN9G9Ls+gRdPc6iABN40YAI8UpTcYJ+QmJEVJT+tYCoiOBvsPoKBauxGFk3T3vO4mZmlio4sYsFxupf0xWYX4n4'
        b'wNZIlMAk1NhfvPax/+uBBqGuAcqh/0ufTD6SrXQ5OWfo4m+bMGpQHmyokfNXX8Wuo/2R6w7VR+oe0m1qKPSM1NUeMQsWFJqb+F945TTqv1j+0qvurdD82tku1TfFFnXj'
        b'MoIxNZ2+C68Z8qWWMA+a1I2XeUigDvpUYErsAAPrOGpxGBqx3XjJjiKPDdC2QZQG/Xibs4ZsTIE7zku2BnmYdlEVpVkmcKNvgWmcfYRSzHCMU/hQTPr2wHFOyTc+AQvO'
        b'i8YMIdHgLZwVNx/b+BD2Tr21vC1bIrHYJ4S2OOBr2mpCFVYaE3aewjGYgEGJQDZKtPVSFGfbOXvspvMpGDSRFUj0YBIahDCWECZlXN/oIZOPSPDjLpZDoBPflqdpSrgK'
        b'jtz/RVy9EaFkhca4OPwj1vaUJT3idYfo0X89D2Zp/OXrdNfFlUhrwWuuVqZjWT0OzlUXwo5IzFQ3dj3xLOf1XflFdeNd+UW5/11ZXoR+V5aXbd+VXxQ135VfkhRDF/fG'
        b'z/+ft7FcRoy20scr7MjYJKx2hrJYTyi68N+pkKEiUVPSFvEJzY1pmInjWA7VS24YRSgVwQOVmCdYuYb074TCx/2NstW61YJgUQnzwMnlrcnTyNMMlXl2PyP/FskbSsHK'
        b'2fKcn3F7hCBEXurZk2fjB68pEXJx8Eo0tiRYJViVG1th6TcZknLVgtW5bxW5FekGa5SIgndw72hwb2kFr81WoN+V6HcBe6Jajv7oBmuXyCpoKmgG7+RKfshI272syVPJ'
        b'U8tTz9PM0w1VDl4XvJ57V5kfm/7IVyvQmjeUiIN3cT5WGc4ByJoXqeSpshnztPLW5mnn6dD7asF6wRu599dI3+ferpYL3sS9LyN9U5V7S5veUOC8mOwNFW6PW9geaRei'
        b'4K3B27hdqgZrcmqkwbsqUhyhvwLCQuJ/sZcuaAWdt9Nf+QRjDvR3gn4A8YXl3IK5GgMS9QPimc3malIEocGKgUJJsueeD6afghKZLhiRqJ8YHxCTEBDElOGExzySpxKJ'
        b'+8TGS6damiUgYUmNIrYVox+gHxZxLSRGOmxs/PXHhjEz008OiGfN3g4detLlyTS0xza4xPWOnfS0M9M/ERuzK1E/KSGE20FcfGxwErfcLSsdvlIrXDyd3xNJGStrwyzV'
        b'hWFXv1QbRpwvfqZ0jFBD8S/OP35J3HE95vRdZOLRi9t6Lr/v0qky1Y2udvlVrKqjsfvnri3YTP8UZ8wKjqUVkU6nH5ISkZDIvklmpxsotQKFrCJYSBckVdb5NT2hwidH'
        b'sEXSL6FJNFxAcDCBylPWFBNM/9cPiIuLjYihCZcbu75BqhELVvNlr3HjFKn1eDuAL+LKV3B1NHPCSqhfNJxXYokLV3H1rKOL22LBNljAPCXsNtPnOuwoQjdXwGL5ENLX'
        b'6aVThk6+/szcfw3zFNJd7blchtM3sAGrSNx2lGwWCWR2CbFeJZBLIb6IdQbGVyCDyyJOgZJzHKG+jJ1OHqbYg2PYbSEQ2+KEmUDVWrQds3GYK1oL1fuMcBxGvVm7Mb7X'
        b'mAHnn+d7jB0wlIGKaFW+nkITzsCYsY2yiHVfSbDHfE62+90ZvtmLYHe6y4/8NvIdzLAR7mEz59KcvS7dEuZzfcxKTLDUlS90dyZWDjMg7xZfRqBFC0sTrsoI9CwFWCaA'
        b'QiE2RVRP2EkSfkK/Bpn/PqR8IVK8R/nlI5+7/8ksuuqKKNPa/k5Cj+3RLcd/99ZLwXFbcg6VKz/cMW1w6a+KnzV5f+Ypf+xY2/abGoEp2b9xLLWfVcMBc83ufovLu3D/'
        b'j378k/fGkg4NCL1cnXbNjZ1yfVV+cFvzuh8PbTY4G9mydpO3wXzyQd3RM5oqf5QNSKuMHFX9CzrvuHYmFJv+oPOZYpP833MhKnvm7vcj7FPVbn0/7o/rs2Z/+cVX740d'
        b'6d/9ZYJ26Lnrtbva3NU1wi5+1FxQ88nCrZDPrEzf2/u9XV0PE99u/9lXwkvr7Nz+bGyoxWVUmvlAJwsfEJ4QccEDUOTE++jyY8XMh2h4wmKlDxF6pM0W5uA2NDI3Pg66'
        b'8Z585sU33cwXrxzDObGxoxHeXnRvwj0TdW7krTBM8qyLkRlOwIjUw8m5N3twkJNY92HdLi4Wq2vrYjgW63rQhNncxBpGBs5cxEYyVJkZygoUtETQDnM4zo1unWaDRSQY'
        b'uDFoNroMBbICFZgQnyE5OZ8TXdXdsd94NxaS3HBwo0AW7opMfA5x88rIJXL13YvwHtQ+cqsqQT8nKTslwR1jp7VWri6ka24RQouKtHcEie/5pNfyoe44ANnS7hCDMM17'
        b'Wyu3kYzOOfqgGFidRq7JhKmsQAemJI6YCWV8rH4jNissqgm++FAgqylaAzW2nEPPDvtPswqKzqxCYVEUtnALVIc6MZRBL7TzZeZzoRh7mctOivbYhr1CgYqH2JUOsDeR'
        b'Cbx+UI73aY8stffWflaXkktvgtLdzqZc+UxWAcUBRuWgLEGRW5fbFWjDIpdQ7aV4DLqLUqkvVJH0m0JWhtIOx1aWoYRsUjHY0g2g1YLFZdPgFVAIizPKCrRpsAWrI0+G'
        b'rj1LTPlqXjrWO+lb6RJW8lwfcmWuGjyrDK8h1PuKxdErc/H2el8piuSl3jQ9YarOSoa9eo/yJW68zKf2Na5JMf/sKp60DUrPoY/ovrGKPvK0dX8b07fM19uerZWktucn'
        b'JlvyrlkuMfgnOfoy7v0fuNvi07/OE3RkcYnx+1iE3HJmu8L4zZkTuRDEJXPi///N3ySdxecIH9vW4nk9YcxMv/8n3lItF36es1Rf+Gsoi1GXzxdONvsYCvkaxfV4J53H'
        b'2+U4u1WdYW1g/DfYquPzWE/XnY8BQ0JQlB+X/vltjNDHnwcRlPtWMUgyaDK3gY5Fg+QpnKQPdledXdxNsdJ4+U6xdlVztO4mFRuYxfpviFjnDGV5wm8dsR72bPZoiVsS'
        b'c7FjC5ThHSktX6LkLF6xwMXIyQT6PVnoInZt3M2EnwJ3F2YAggEoULJKxfII0bo3ZBIYZhx9+cHH/mYf/cH/+4EGvzEJcAmICo0K/IP///rHhP7BP/+twjAnZuQm+KjW'
        b'kPvqnVJDMcdItIO4cr8r5ja2XY2PXII8Ltnt5FW4yyckZ4WuEnYkhj4ubzkB+vEBAR7U+z4GewzyoFBuMXzh67nCoiE9vuBZIXGlhfwJG/1KM7nr80ClRtsqUOnIXSVO'
        b'x60ESyzBwWcCTM5qrntM5VQ4LhiK+J6Tt/2tpf6TbGzijOYwqsn/NBOHD6WW9jFZ3mjedCHickovT3xmrijxNvOxrmVW8581vFnvUe/hk3FjudXcVPDydxRyf7rhSav5'
        b'1zg4ioXPbzr3VlNUlKTqPu0ul1nQv2EBx57n9tT6V2GuT10M0UZm0Hs6pWDuERYfTpRChmiFzBKtED9ratIXPU8okQ4hiaQ9S1npcjPJ09Xv6PiQUF7VfSL2ZRUNOT4k'
        b'MSk+JuGQvt1Sc3jpCfjrxwZGktL+DZrt6jxRxi2J1XTF+zDJCpUyRPDbTajgdfqcqfc5LmL78XBtyNirELnxBhevnQ7VKc6PQsdIA8Z5KH9c6TurJIclznsiSvUHBQms'
        b'hK39x0of+//B//f+rwaGh/aHMCeAzws+OFI+6nM321DGYNvLP/z+2995+8XT4q4r667ojtdnRvqO1Y83FGk5+3jUHx3bV0xY8DtByfcKNdVP5nzHUJZTMXacwQxpXOdp'
        b'mOZ0nwuOnO5iKWJ1QDkdQ6pf6GKXKD1dzHPcURFWc0rXcpULsjCL1K48qb52iqtI4MJCveWjSV97sIevu3/HCPudH6n7SpiFpedZB6tqqObUECcV6HqiHAQjvbiAgyzq'
        b's1huBQo/XWhdXiaCZbtIwUa0yP6+FUrHKXNJrCp8wYj1j2HTsuG5WfukQWucqfyRgL0qL+gT8Y89EqsdaQjP58F8rfpVMP9r1vp0pH8itOJZRQOSLb+YXBXdE58McIkN'
        b'XUyd+O9jvx0/5zNi/+reOpJJw78yFSUwLMhLlPvY/+ILP3yRsLC2PXdL0Z76jvZMS7FgN0puKF8yFHF6Z6h1NJd7xAeUcl6A9diiTswuFe7ZcXqr9QUlZxaB25y8LAUB'
        b'p88v+qlWd7KaLLIni28JyYJbLDhzVaiQXgs/yynRopjrJFo+afDzAKZK/jMCpnQJhjxOvCuXEHAtxC8gwe3pNmMmYUqZkyynDcl+S4sxQewvAlezGC8CLTOnB0sr2j8T'
        b'yNotmf5DEgNYDFsAH8MTHXuNuB2rQL847v8reOffkR7WIWZY5oz+JsyaHJ2UkMisyTz+JSRGxPCRfUzHXdUczOu9K+KxmM2fBl/NFL2Eamyt8QHJ/HHRnr8Bwxg8P2k5'
        b'VnRLYgCdquLNM9dVWCs8xNbH2euubZz99ZgX3DN2Ym5zoaMAa6DXkqvBUtenxRdvkQgkDcJL4kSjRM4uezmR77dtLhsqMDp9XeAZ/wnBAWdFxoaLYmN3Ec5gmUB4lhlr'
        b'W2AkoujXOaKEdvr5S8GrXq/tURTZKcv8sC34J15qSkovKb2dVmt64of2ItDWvudfFaGXnXg54Dc9r583bOty/PBIXtUBGw2H+5++Emyw1+STwV9NHOvYZbWhWnPhtxXF'
        b'Y1onPjiuHlmpdu9HG3P/mCUfpJJUnHD6jdP/fKWis/5X9k3HziRW7vI+UqgTa/6m6HKx608m38A//iHpyoXul85FljhHfzlZfNjzj58OJ9Vfsq3/xHCq9hfSDFhoc4UF'
        b'xuNLYGbJwOmTwofmN4n2rWTyojQsTk+BNj7QvXUjlq7g8liSyttWMceCz3+o2gutxiTNjGLlorUxBJr40nJNOAdlxkaLiQMKh0WQA/ehDbL8OXPbGTPIl3a6XLI0mkCx'
        b'1Ng4lsjNkHZtK5/uetV3ycJKy+D31pmkKbWQMvsolECDyMTz4upM1lD2Wc1078pJM2M56nr6W1NXZTW+8aKiUO8rNTHXWkQo4b/5SiJS+z+JKFV7FcJHE66wz3EigYvo'
        b'm8UHUiEePftIhnCjf8YyUn3sW5JqQab2v1ch1k9ZM50rZxjkqLXCUjQ479I/zIICJFEBMWGe9kFyy3CfbUljEfe9GQFnKZ7MmKXI+WqZf1iUp5qnlifOU5e6AzVCNaSE'
        b'XS5fgQi7PBF2OY6wy3PEXO6mvMeyz7yV4hc3JasQdrvgYBZAHhOSvDKeh/nBeJ8b7yIMio2PD0mIi40JjogJ+5rsTiK3hwISE+MP+S9pVf4cyWQMJFbf398zPinE399E'
        b'Grp+LSSei5LgHMJPDBbwVAewflBADCPk8bEssmIxZjYxIJ7uQj8wIObK07nJCk/hY0LYqn7Cp/KYr+NL7CCYIzMhLiSI26EJf8qrcplHiQsxSdGBIfHP7PVcAjJ+GY8y'
        b'EJLDI4LCV7A7bkcxAdEhq64glg/3XjyH8NioYALsZczzsWDw6ID4K4857ZcuLUGfz58w03dnAbzJEQn8CkgCCI8N1j8UmhQTROBBzyzK3v6rDrS4+qCAqCi648CQ0Fgp'
        b'L17KpuaBIInFpTOPe8Cq4yyHoaee5FJE3SH9x5MrHgUcL877tMBj6ViBFoFPjrI8ReMb3mdUggQXD3f9/ZZWpnu4fycRpSEkDA5ZvKrFsQj0eShZPQ76REhoQFJUYsIi'
        b'iiyNteqN70rQ58Xe698k3Ughk20ljnQK+vQMstkKoUdVSvRWCj0G0lr2+YppCRbxIpe1AmGsAKYhewtfk2NW31vp2lWhBVQKhJgvwObIrYZ8wfm4ZBlmdRP6bheIoFR4'
        b'HCblk/YIWDPVwlh65QxvijAwMzXA/N1Gp1xJbOr3jCPu6n36rKlcuLdIANVGCgd9tvMu6WHIhixPaF/hceezA3l3O/OfBl2Wh3aoVeZEqN5kZVapz8Bc9rpFns1aAZfD'
        b'Dt2s6RqJFcZ4f/eiy5wPHDQxNHWSEdgYy2KjBrRx23PHQpg0xkpZAStaq06Cx0EvbuxGOzlWTFPNXNvPRfe6EV+1xGKXhJfZdv44+LToIP/lzQu8g9089ON9cmf8BJy7'
        b'f2foTXOswU5iQkoCJSxS5Kpdcc+7q8uzouXm5qGOieuvpwiSWFxbSIABlxjv4cgZi0/RuouNmcRZbOwcHs/vgn5yNHFyMTtlaiQrwCJD5aupcCeJeQTMsEayJLJCB0ws'
        b'iq3Fhk6uLtDnKRVYWbP6TJxRgE5frLM3lOcihKF0zbllieSnoEsITfYO3PHY4uQhlkZOwlE9l0WOlXJ8uv0c1JHctJRI7qwqhI4dmMulvcu6n1uRRK52EAvEa+HuOe5X'
        b'O8yBgke53GynQpjFYT7VeudeGZwhsXEpKVOazW0YyefMF0Vhl7GZoRMMPkrnDsVyLlgCc+RI6ltKtHwsmxtvQ14oFAUZKnHLgHrMpgcWqxFE4x0hDEAlZnPznPbDET7c'
        b'VNFiqRSBJt7mGwi0w4ztyoDSCOhn8aTl0MVJ8IabIc/Zwkl08+BiKYJmqOPDKO7AHSfOOKXnxAUTYLcNt54wL2h+VIkgdh08FLFGenCbbxtSAHO4cEB9qRrBo0oE5ljA'
        b'DbAN26xOBC4LY+ViWGvobLg81tskvDbxIbKq9ku1CNZhJr+lEcz2w9uRj+yD0hx3KIY+vqJjETRgM2csKA9cZiy4lMZBkXw8FrBIlrOmBGMlTuIQ4WHIhEruMC+fgH4P'
        b'0p/KvU6zfoCmvp5CaIXh7VxVAb/1Uj0o9LuOLx69KeAM8HgH7ibTXqvcJYpeApEy60kxG26oyLfu6aabG0pQiU/CUWUcVYVCnE7ECdZIRjNSfAp6fZN20GM3oMN05UMJ'
        b'OJHETCA9YuzBXGxJg27uSazA7qjljyYnXlWIX6MiK1DTMRBLCHBqsZSrCBHgja04noQTCVeVr0KJKr1yH7vFAk098QF86ME1j5Y/DVMJV5MUuZFUcVKBNJSJJPb44gqO'
        b'XNaGXFmZNYQuXD+hCrrdh0uv8E9hPzTICDRDxHYE+cw0uRMGcG7poWQilsWLq9wE9yQ7IdOIH202FjuXDZYYjxM+UEdrPCk+BGP4gNtI6hq8+2gwosl0a0Q31GRFeG8z'
        b'5vNRpEMGl5RwKpEWpKywhiT7NTdx9JIIxmEkiX+gxgaL6GJPn2b3KsNKI0KWkLYzil18u7G5Dfpw19PDFSs8sARrPKCEFQJtFOKUOzbw7RMqoXnP47PkQQtNs16eJzW9'
        b'cF81AadU6TcRXdwcZgiNMHdb0l5Ox8ScICwieum829XFb627FwuMOiu1gpsw+l98ygULiYzAbS+FBFYFkudrD6FwszOr6h6sIDwkwOorhGlMNTyNI1iF445ERpxNCdPc'
        b'JAJ1aMYBWTHUkh7bztFwNN4goOnlzc0iNv05KZon7DPbjASe7Murh7annNAW8E08BP88Iv1gcNRQwlkKEsPphOrpBgfoH9cF1xUC+E5oQenYAKMwQNwkVZCKHdKObKHy'
        b'OOOGtXwDihSsDOX67fjL3nLwQ9aVJkIQcUyd7xU+GPNvSQL7qOw2Fn321Zi3jqoNTdn8Mv3lhu2WVz+rsam43/FnuffU9P+0Q6Ky/mTrUcGk1XdESSqZn2fovZd/+N8a'
        b't3/w4QsffyZRUPD1utf/j9nUvt4vZGpm4hWFn+iUFlRf+MxH7x/vBPwDGn61yyytx7brfLPCiQ+CNSdLX7PoOddhfbrifyJffH+bkWrG59rOGWc+P6Pw492H9N56/bf/'
        b'WnsqcrZx/Wbt8P7swq4PzR0++Z8zCUb3/+fg+hcPtCdOmE8eH7f4yEcpoKO+amfFsSLf1kiNrjd78u4Pv+rZplaVN3xNpiTrwd7rCYX9n7fCwX0fW330gdwuua+szxT8'
        b'/m6XtkOM1Usbv/hM5ZLnv056H64ZeHPrld90DZz8XCalp/KdopTXBAf+8sL3/yf2zSu/uTot4/rdnzd4us/4LPgon3EY+ruLddjAto9z/u78k9/+ZPeFhcAv+/9+xfq+'
        b'8p8/23Z4i1xUr3nChdyhF7wDavFvdVd/HHHY+/1r0Z836bzreK3N6vgxm6mZvHP/uD76vu8X1t9/9cOdh7bH6X1P/oUXYiz+WSSnHfvJjyer/rzvN9Gvm6/97r/G/2bq'
        b'u/2HH/3+vRf+9Jd8j8uzxf2nQzzO2H6oFzv2+vf8Q6aSXzH+X9d9XhXxL6Z8J/T9oMtDgWu33uqD0OM/un4XqlzX/fbT9SnXswsG+0ZaXknxv/Yd47zQqa8CFn7797/5'
        b'3rszZVRRcKbrc50Lc/8Q9f7TyFbhV2fGTTU/+NDVbfJct4XRtTsfm/47+fqVE3OvHZ5LeyNTtjPUvUfvt95pr9zrC9a+FNu753sxr5QWDDbGrN/nZbPh55U2JeOuN+f/'
        b'1v7Ln+20XL9J1frQjOXa2FtT736Z969fKp/fVOTxo+Sff/pZiKjVuuvPn2/+wZovwmRfNTTjLDdnDGHaeKVLWuMUtkGrGO6YOPPpFLXR5zmhAqsucUJFHNzlnNrQiT3+'
        b'zouxVu7sEYE6EYMZyBZD8Uns4bvZYq3TSgeQvCsfdVejxUfdlfhC8aPaOU5p+ECEvfowydeNGNdVfRQkthghdhgqxFDmF8/5psLNcZTYO2dVgns4K4QW+bXcL8d2pC+W'
        b'az19notgw+m9nN9eIRmrH7cocWI0Z1KCVrzDN0ouumG1rDgbtu9k1dnsd3EBgVtJ+B00dnPFElmBZO95PSHrlWDL28vGoTl50eDEAti4oDyiuHc5c9Re6Ny1vDSbcrQQ'
        b'Rq/oclPGaEDLUgHaUOyRZfVnS2CUH7d6D/Q7G9Mui51pvRUwL3tdtJ24bTlf3qIv6SZfl3cj3F5WmjcAu7kVYx3OmSyVZzllIYR7JHZLR47x42MQSXLoWApC3AwPuZPU'
        b'jIZxVvl9t5xRPKkPHUIvM6jiwyIH9uOdxXQb6IccIbTF2HJXL1m3nrUWJtAooqNwNSGGvxtaVMRYYxvAe/j6cdJ9uYfvPNbjEPPwDdHojMgGpARy0tc5Ess48atwJw80'
        b'D3FOeZkYvCOWpGCYwF6+x3mOfOojYddmLQm7jo7cCd3EKU6sWibtbsUH4rVYeUBah4b11Xkk7horMWG3h+6N46C3PROSsfMJaRcnpEWNsWUvdjN5V9NrSdzFu9u5ZvKs'
        b'CrvPU8Xdy1ah61FqDm2PJdBou8DG4T2bNA1miGN9oIQDkVi6WhbvWLDb3VQkcINZAkojbL/GlTCBrMPYtyT0YHckyT1XcXINjpBSeFtogh0yClC8jtut6PpeZ+5uoO4C'
        b'ux55bBRBoQEW8FbdQZw1lRYuhILdp2DIIGibULDBXgIttsf4kNomHHPlyiLS7hb2Ee4I5LBdJE+STEEiY4b6aTAIWVcWmeS+QH6HGVf8pGVWGP7RMWpuOxQnxtI9eJsj'
        b'LUfhAbTwT5i5YiHJ7qkwR1NjvYSY+zjOcMOEh2I995C7CbF+uhSRIFJGZ5/kyEHs58NUB6Hl/NOqdHpc8YdsZz6hbRjntbgSjoX8jShBCcyqibAd8vdxF7tzTzJn/y4w'
        b'EQkIjatl3UR6cTjHv12MtbuhCu4si9KVhug6CbiFHo7ALBxXvSYlgArY5wn3RKzlJXRzN2qDI6zO125TQ2hdY8AgJ0wEYzsVDVX/8/ymR9bf/2JL7+X+84Dg4BX+8y+Y'
        b'NPXt7OL7dYUqXBir1lJ5aGXhJq7kszz9X+9zDXllkbyQt56zgjMaXPNtPqyV+ySSXV42Rij5p0SJpdQt+/NP2T/Ib5bnRmYNUrQ5G7Y8V1BawtnhWZMT2c9klbVZe3Bu'
        b'NSykVvSVhlhFyLdHYWVv1nNlalS4UFsVekOF+8O1+P5KUbyK63LZ8fBWfAXeFL9kG493Z+b5Jat4/OmVlv3/rPa3HD/Po4G5GbnJzJbm5rwCnvSp8Pm8Ama/eAYX7rJz'
        b'MBS/K7/oNX2UMhgkETz6n6xgmTXMRyDgM394V4CC1BUg5JwBzBUgylPP08gT52mGakodAZJ82SxBukyqAvPnnhPckOGM/5KbMh7LPvOZvb/wEK3iCPCKk4b1rvQDcBbx'
        b'AKlFd8n1+3Tr+uITK5ODEqXG6WVDmEht1EEBMasaLgOZD0Kfa1zEjIxP9zg8jzGeuTdWndVocXlG+lwCEGc3XVwHbwXnl8RcGrT0GN7yvLohXP94bHCIpZV+YEA8Z7nl'
        b'NxwfEhcfkhDCjf3tXNrcAUr9Fo/XHFrN4UDDr14bQ2rOXjTmM/v5N9l7v611d/XOP5vdklisNskT45jn/Khd+hneQHgRa1aNGis1VCAWNhvI+cMhMx3yOIuq1JzqyBzj'
        b'mO/uscyuup7EANJZexWgxH0330a0OWa7sZOIecM9cRJrrM9yWvKncqw9C2nJ3mXrXt2ixLdnETeNeqyJm/yEa9AiFPi8mORA316DHhJN7zKBOh/LPEgPKGMWUVcXju2e'
        b'eyyG93F9X+y1huSsXqkSjeNn98FCuLTbsKtoO5/5PrTnC/sbQn2JwNw/pN4kxoFX1d9uOOrJ/WyQeuGYg+C+UOCfEZniZyPhf7bvOMqXpT4YKXxLJFAbsek6fdBPlbf8'
        b'Qs6mBDq7Cr6HusUNcdJJ9m0pjh9ZZtmGOhNav6mTK1Yxuy5Jj6ek9nKu85HzGUcnEydeIMRpLFvjhGXQxd0GdgqeGp5Qk/5k8J/bDWntTXOsIPHEfbmQpAGsgXQbq6tf'
        b'fJ6vWHpPc8dSmj30YD1v+VRO56wtmA33g5+YnDMy6+pAn6fBUoI+ZMJDhXTIx27upLJNxLyNfH+i5+ntTlLTyNFI/hzrUrz3HxKHCwVHM1J9Ul+UjddgPIMZzA1leKNp'
        b'NY5gK95jxVEEnMlE4M17LcZx+hQU4eyiPGidzn2/GdrcSPLuWbSZlEAb9/12nAuHri2LZhNSMyd442a3C0wyARiLoXYHFpH+tV8Iw9DCdyTAeZJoC5dsoyTH5i7ZRwsI'
        b'wJhAFwS1MZyKYL6FL60KHaRGDUQszKVLEtoJ6mq//IvNmcMxPzuq1vLOpZveXbbVwbvG3u9Rea/3dZmLEuFFlYuOGUpnjza+s9NljxFBmlmtl1uF5a80bPPDIl7WVatv'
        b'+cdnf2xy6PtM7cx7GZfS93a9v+PTf2p2/25/YMfGD9+yTjXsrkiKfXdDX/fv/vJWseZAlfubJ+p8Ujd9LvfTm947LPu//52KsdZaoW6g/RcqIXKaf96gdnDog63WtdM/'
        b'TP8yU77v4cfffXvN7fff39N7460XfbaXvThSsGNt7Psf/LzJP6vTIjjq1Y+/52D49hvFf9wXlaT60o0RT/GY4Z/uev+77qPa3/xh53tnh5qzw/7oO/n3nQ/kqj59KfkH'
        b'FmHv//KD5huvWMW21Zx546P3vxv/0ZdvpJ/rdN985TVw3nlZO+1/XQ2CXep/nPCPc9dL/mn4i2al/vD0/bMn11nXTbxj9y93q58lu2n+Vrz9V0Whbz58xcjsO321duU7'
        b'dC5+1ve3ZP0fHj/68v2uIs+s3zjVBbxsee2C4/XsQuMv4uIWRic/3dPytlHHKQOlfxjv/13rX43ffePHVu63tuz/g5zeg8l/f7L/979NlUscz4oY+3X8783ebI0t/Tca'
        b'G4zVJFZcNtTmi2feDYdS0mlhDOaWwlYImGZ5tXYY6xWdF90pMAI1vF67LYYTzN2VMOOJ6FSJHSzI6zpJy3baQR5XMoIrFwG3r0SJtl67xBc7HQEa+5TJVqzjlF9SfG+k'
        b'cjpxJBSbsViXwi2LoS6EinzCALRZ4PATMavWmCnNGDCK5TXYaqtY1sdybQrfyVII47qRnAZ7OhJyIAf7lneyZH0sfSCH33EHVnPOEBgUwRTXXId11qmDe7yCm+1gttT8'
        b'BvIU+P43pljF/XoSB7HXmFbE9HktuC1Q2CiCckVo4aNoyk7AqLRIvqyMiCuRP4BlXIgO0Y425gB5Qt33EHNODe64Y/ywlCnfcNeFkc1IbGYa9H7xxWO0ui3cttPDOH0N'
        b'y1yJoBLfMJYVbIAmVxghpTMQM7l1nMcFuMcG4Pp/yp410BNJ9mMHH3A8gJVcSu8K5dLKlZRL6KT3OcPVFMyfXqFdcqolnVI7qZeQd51T6yywX+cx7ZJ0y70wemQnARfT'
        b'6DdCheUy7RK63R5rA1GFpbwZqQfyt3DqHdPtIINX7xwN/kNZXvO/qM89ptQpLw9H4LS6e4wlfCutjvQ6M2VOr+JbTPKtflj5UL2vJCK+pKiiWFEoEclzrX0kwsW/JULW'
        b'tFL6rohvRMnrfmrST3yTSomq7N9UFj/Tf7W5uTS4/5IGsuHxvIZle+JVMVleCfJaUoyYHrJM91L7f33EhpJlk5ktzcgpYOeZGqK8WE/mWylggkzzD1dRwb7uABZjw2zY'
        b'cmxFq6hfTGTlxFUnARfwLUMKF19wX8SpYGKmhIUqLylckmdWuOxWC6ldVLgeVd1fipDlAmv/H4eB8+8s1qLh31ulwqSZ/nE+qIZbylOChbiocaaV0aOnPNwP7jffw7Sg'
        b'6IBEFhKSkBgfERP21CXwRXAeBcg8Xt+P//25MlLk+YjZ/QrWT42YJXl0B+avEEldodiec+35ee2Q+qtvQPOiyxpyfbkfQ+CBKdF2h52PijqJ0rBBnfdXT+mEP/KF05/u'
        b'JX+4W2zE6/prhQm36LGbMn8zLdyiDeZakn/EvnnMLvOFj844SqY/VDyzNv/opUjHl+KLftWT/Y/+a7997ZW+n5pvTcjdv61wh2faxp8r9/xfdtTmKvfoME3xru8kHB37'
        b'8E8pm76T4rUrsm3d7ncL33moVTRwZZvERTv2i/HYqJfODT68Muf8x5C3Dc5/vEm3drOl3DbDAwcNZXieP4K1MO9m/aiOOXGb3jMcd93hhrXE5HxgZnksbDoWHuNMpiYb'
        b'ceEJecISGiXymIl5PINiJaMzFhmlUdoSq2R8cs6akx80oEqPt7YLruIwZ27H3G0rUln+I86xjLCrJHFotoK0uz0HaSfivp43xvHdgxfJuzzXuS1142OUZ+WsK4jvSiq0'
        b'jPh+u5LXRFm5921WkleOsl6k764rSzv7flvKKsjc+udVaOvX75AVeE2NiGMWmv9W1ccv+p4MXo0PCo+4Jq36I61Pu6LO0CrE8zhv/Ii6zllLIqLjokKYvSckeMtTCa10'
        b'Y4/Xu6Gvn6XFiWBVUiVx48LMUrFtH+/RWqG+Yjmh0fI4qUAd+QiRb0Skv6w4gUV1vOLyAcsC93nh7Rcnykfze30asw1lXtEICg+NCjQJiAkND/zV9wWCnHfk7nlPG0r4'
        b'WhV5UH5IivPQuo9H+3HM4OvKEzZuWNIjSIdIg15Wo6NGzHsp81y1l+M9lGks1haZggwutxjaovVoOBKNR7GYNYrkLTunXK9KKQW0r3GGATkY2QBz39hOTS2Av9pF+EoQ'
        b'LQLQcyCulTLL8tn8uH32sRlWVFi/tBI1V1aXfPQEh21+9Knh+bFN7YerYNszLTb+fbYeGTc3T3u3+CsCTn77+nJ1jypdsIxaLrmOS2TiQuQ5izgnlXEEhNsXfyjr/tuC'
        b'+DNS8/hj9FFlMemKVbBTVNIWijavrDynJlFTkxdpCeVVVYSKitpC+fWyzFtBx7vzK42bZkKNGH2h/GYtIRe9tXnHiWU53NAE01y3A+Z4NNglcw0KJUl/o0lNsCoNWqDS'
        b'JhabzNUgF6fxwdoD+yEjCIdlD5FAUQGV8qTWteDtzWugHHPgDgxC1YkT0KEElVAo3IAPYRofroGGQzgBpTAWAJPY57mGOYOzcNjGGh7CiCM8dKCnyrDwOjOFwaDZDeh0'
        b'gXvWN3Aee+VwBPrpz+w+6GaxCWFXLXZgwx5itu0x0IrZ2Idj2HTDBoqgBwtgVMfhqrW7NhRtw4zj6ZGWXH7tdIQ15l5xWL85YL39IWcZX4s0M3fo9NUzJV1u0hpmsBfG'
        b'oTwG+rGChplyhCmraCMss/DD4jXYE4wjmqSW34FK0sI78AHW+h/HxtOWkVAShEOy0ApTmBsLo1iBrR44BCPJ0awlRDo8wDpPqFiHHVcukOzRdWAt3nOEB+asUxxNVKp+'
        b'AoY9IGuXMy1gChsPwnA6DpyBBiH2QCPexmrSWhuxLBzuYiN0JG8SK0E1TGCbhQl24lT4QUVrurq8ID3IcIiG7GAats4V5gyD7GM322NpBD7EJies8dWFoRQ7vA9jdE0j'
        b'NrJQf8bQi/ZdBDWQo7jTE8d1sR076F/TrpAHzT50GDVQZ4LTB2132GzX0sQxb/qiOW3XBWNswH41TczDcpj0TKBvK1QUt+ICvdGPozBMyxkRYJ1lyGFsuAhNFjCngW0q'
        b'ga5QGpZoixlnsYZOqm4TFPntlydl/76eJtyPgoUNkBtGQwzGkT5ev0cPO4K3ep+32Y1VBAv3oSchgMCuFhs9ldddTI05nIYTepc2QqMbdKy7QPyiGerwrjxtaIJgqhE7'
        b'jmKxPOSdxFlzuspaGLCinQ7SGqchy4duocz0CIFEYQqM6WzAQjqjB3hH5aYY57DAYfsGrEsqE3FhqS30WstZOyglyFdmRZvW3jhKV9x7EjI2QTPWmyrvxXt0SaPQKj4J'
        b'PUEB2wyhPFwCRfq3dkP3waTUcFVm1ocOvEvHWxznfw7m1/pA41FohFHogqwAbDbCOuOdeB9nYVoMIwpYvQGnAmTisAUmvHyTj2BTukcUDGATncS8Aa2HgASHYpwP0xCt'
        b'etCEmad9aOxKH6g7APWQF0jYlymycsVKGDGlZ8bwLvSnX0jXVPO5FbjXIQyb1a/vVcch2msRQXMW62O1jzCrwGGzy/brOwneyqABB/cQnA8QfN7H/ACsjII52tNJfAAF'
        b'cthti5Vp0JbkbBeBQ7swz4B0i4UbB8xuQe5lBQ+4r7uJeGEx9qoflMTigj+OibA8RTvgJGbDuCIU33Skg83Uc4BSX8ggKBrDnGBVaIO77h5eFkEaO9dhn52DopaGmbnM'
        b'BksvwqQWF8z3oDuux35dyCfSkhGAPfvpMh/AbcwRY6Ubi3PUx2Y3LPTBfhiXqBMMFupAB22FUaccPwt2upCPgzCRnLIOSjbRfEMEVndTCCLyUtXl6abHQ7EaZ25YaEEV'
        b'sIjAURgh6jUpH6bihG3rSF64c94bBwj5cnB68yWYd3WGBehV2A6VCUQXeiDXKgTHo7HAB+bN1jMD4EV3mN5AUDeAJWeh0tlJ/WIyTtJ8PQQMrRcgk/BogbaVaYEDmrs8'
        b'tq91Z1G6OOmL3VF0fHfdYcwQ78tAfeB2INiJTvoRwaQaFCcTRNpAGYNIWvWMMUwkWWHzRQmNegezYwLgzlUlOta6fadNoEfN3xn6bKEYp+is5rBuA0HSQyikjY3B8CnI'
        b'vUA4m7MV5x1tbW2w3gk6g9UUMYfVsyaYmobsbdCof41AuE5kC3PXBftZPv+VRGO6uHHoIZGpEGYJdyoJ6ZoCL1yKIQrSYYJNkXTYD1hP0kKC1X7ohFqsvniSKOOCsc65'
        b'xEuX4Y4rrbCLJL0JA8KNiiNbLVKwWEsBZpZDLOFH7el1tI7JZMwyVbgFEzEc0axWuQ4NRC177Fz2p24JghG3tBva4ssOUKQDmaG0sQUaoIeoU9Z+W4LferloKIFeP6ha'
        b'Qxfcp78Gqg5igyPcSaRHMpHtpA1biS31QoaqCLNsiIZ0r5WD6YM4q7uTQGEMZi3woVYydsasvS4Jj8IMqCF8zcVqVTqoLtpeD87B+Gm6yw51LPTdGE6QloWjR6GLjnzu'
        b'4i5iTvd8U/QIctujbbDcn1hYnSH0JRNCFJvRVXTYWRCRKyCYJNZ5ce+VfVhhEIl304+ppNICsyCD4LgDxvfoGwQHwDgOHyGKM62shVU4i1nKmG8PrRaeBBLQfp3WUIBl'
        b'BjBJ8usAlKVih9yG7XTOD7DL3nc3PMRmRXsj2nMuEck7xLqbTsC4Q9hZustxuJ3gSzfaQEyxDR6kYtE1qL8kF4K1NqEOZhxbL3NOJJ6Tm0RkoZyeqbV20PHBOmi6AoWi'
        b'a7rQTOBNh0jgDa3nI7lCDW3iHbFO9lgQswYrQs7JbbyMQ+uhjgHXbkLnDnt1KAxO+jHLzKBXhxipjeFkjDkcNsYp4clN/nBHDhvOKgphlEUSlxLO1EN5IowJiNxuX4sZ'
        b'e+iI6/XS8J4czEJXiIOBLuFo43EY0CSO0LiO3ihVwWa5aL1IgpxGVULHegtDfOhl5ghNZ9KwWg+KnTYdIGYwrUin8xCL5E5Dnz9DmABh3EVW2aYlBofxwaVztD5GgweJ'
        b'EpAcErsfmjSPGp/VwGFfqPA/AbdPwqwa3nG4dYGO5s6BNE0o9nDxhb4dOHFr43F/WlU/3cgAi7UbgKYL14VYa28JM57maSrHMZOEr3rbIOLPt+mmO3TV6bxzsUsMC+pY'
        b'6aWjtp6YX6EWlF9yCfAk7J23PHMoivC4ygeqzCDLRWu3Ft6NgsGjhH/5kVC9E28fF2KGzGmYDT4GNfYRMG7rBg8g/5jV8ZM312MDIQDRxW6aL08QTVygA0dl4Q5hQoE2'
        b'YcwYHVUZNlvAPBSvI0Rt3gEP0nHqqi0Bbj3xulKstb6KHXZEVDKCz6RArkMsIcGddKhNX0twNRl8HfvCdLGeiGA7UYrCw1hyTn0/EsyXY5cDiUcE1d36B2gNLfSp8+iB'
        b'FAc14osn1rOWw+NEOyau7yW0n8f+41jMwg6J67Ud2MTEsngoDtXfxWARK7SOcOSgg5aZAa0RUBuonnrNFZtplglCrTqojKDV9JFQkCWC0iQ6+OJ1abS9JmKhA8Q5E3yg'
        b'3QxbsUvXfY0HMYreSG1sD8GaU3S/PfjgIrT40xLv2cI9QuR8K8hGhunzWOtFQ+RdDr/GWBBmRq/D8TiiMMTHttufV8SRDXvsz2wkHGtOKifIPmBH62s5i0WPhAhjvC+M'
        b'xlISImwOGsO0OYxcU9plJRdPYmy9vTdWHjtKw9USI7ejO56nycfjWUd4Roh8tkKuJWbtCYAWmr0QRuLSbJQ3OcM8DgdiGz1zj2hI3a3NkGHsTRd+X3KQqGEtzBjtP4ID'
        b'l0hWq8GZEJIzS4mP9RObnkSibVm3TLFag8A2/9gluOOEtWePEm8tDzkKDV5GJHh0wYNDNFspiSR3YE6V8LsF2tWwzxFK96RgpYrr5rBoIniZcoQgrWmKfjCy49AJF12b'
        b'NQRjg1CjYrpRQsfWoqhhhRObd8qL7fH2FjrJjB0E993qG4jFl9KYQxcx6xJU2wHRJltihESeSEzAWT9sxtbDV4lk1UAv8ZMukvdH6KKEp029oWhHDKu1CYPumHUeOy4e'
        b'gkIXE1c6tiwoOB65wd3hDBNkCi/dhJ5AQ7wdBBmaafpYRxyr4gJOxRPw1J7BAX/MNzWHOhFBWpsL5rG0qAUi7UNhl0gzKSfyXbBOl454wh+rDmMetMUepKO/awG5tgQ2'
        b'XVixx1crdL+VeyB0+eP92ItEmO8cVlXcYXlAa52lIRH2CWUs0Dzhtov44cIOaPaiUSvXEGw9jIbCs96EJLMX4c5O6NEKxtEYmrCJttlymVCh+0LIWqI+lTBkBsNKdJiF'
        b'WBcGBZth7FLcZZ0j0B9FDw1BQyjRhwZxJK0qw4MgfsISymxgfhdx3BnMvqWFDwVR2GRMpByqkn5KQHnB1YbBZGYMB5LzBJIpOBCCd6/Lk9CTpZlGx5e5cyNJuBN65hpY'
        b'pUai5LmzqY5QfmvzjrQkyA3QPe2nfJY4eCf7A1n7iHzXEhWh12yY0HRDbQ0MptC1zmKb9xEl4pZTsKDqj93YEEnctlcGM5KwxjME5tNi6KemwEskytzjpAcg6eEBzEcQ'
        b'4I8H6mJO/GbsNiCY6CDMGfCMwYob+kQbmpm4G04LyL98KFpXid6oILpRS2dR5OpLYl5/ukf6ufCUrcpuSBJrJ3ZvZXbei7YpKqztLTDELYf7MXG2GjClmkgYkhlPEkW5'
        b'j5ulwnYcCXRjiUYe9MgUZMth/5oQzD/DeqWyxLU4aFQlRSUbWlNwzI/AdGS3srETEaeGCDX7yOu2pD51bCT0HCZSU7TBQEJnWWNOsma5jhZUx+hvPkl4OrgRZxyIapWQ'
        b'djJBpGI2hoXpY+XVHdizjfTbfsxOh0YDUyJ+9+VosizssXQIsUzZcjGUMDyTMCEriZCgUREq92DpFUtsctlBeDCuqZ4QSMRvDvvPY/8lQpmuLSQrEC5A8wESW6YtIQ/v'
        b'x8VAZyIp4vmkMOuYa7F8uCNE5ccPb6Oll4dDCQkNMnjXi3hlPkFqle0VnPRahzkSqMbhEJq7haCtUbAt2SbufIL2abrj0a1GhC4tUBGcCM22KVC4DQtkLmJRJDRY07Os'
        b'IcMAIV2BN+tDSZJJs5aLCrQ57bzlThA6iPdSfaNIWKzzsD15gGlnA1bQbRdvdBGmCazKXGE0LUIrlAhQgyoB+IQpdp654YBV9kYEFfd0tmLmbpdILyyVgRJDWT5GZfws'
        b'gcOkgvMpGYFwtwALkyGPzzTKTsX5naZcrhGXaYQTe7gkQTqWETecFzsbiwTCowJCzU7I4F7Zjt2B1/AOSyEQHqEfiBgV8ZVBxiTsPFmb0yKhQOgkwCYHvj/uFnxoJkc0'
        b'oMhEyNUfaQ2A+iRHsUBwiaZppmOqwhJCjcajynTqwzcVN19QgNrDZ1UDNIkxVZgRQHTQ9DVMZN+J2afsXSE30lbbkEjNNHavSyXu1A6tp9TsLhD1LofmQCwjcYVwGNv2'
        b'M7sLaeAVKWZJx6Ffm4l56dAdEoB5StAeH0CIUwULtpBx7gzWuNFN0u8sbeskfeyCXgHR1zwvDZLhmnbThbVYnN9OsJe5kRSCUSNfGrdM4E5z5oQQSR0mDlxFN00qTsQN'
        b'yDUj7lrhCeU7SVcYI3g4T+JLxU46xyGotCI9KSfRzxUeOhPAdxGTKCKwGtMjnSmL9LJ8K8MbzJEyS6rEfQLqIWIyI1tIIL4LDQdDDl4TY5lciCrWO16Bvv14P954M85c'
        b'xoHzp9ZCn9yNpBDXeD+ioBXQpcAsB1Cvt475Y0jI6iD2QlrKxfM0VjGdZ62vViSh7QwtoXwfbbXHZr3iOWVsDfLnFK9GMWZZkCKTQacyhERHFyygWIwjvkbuFpjjQ2St'
        b'/TCO7CS06bU0Bpbh0Qflh0kcKqP9ZMTrJEmIMZUn0B66YP7EBZIlq6DQCFrlcDACyx2h5gje8SKdqpiUl3m5tVjkvyXI8PgGHJSHGn+oib8MfYQp84YqSdgXFB+PPfSn'
        b'Mn0Nrbhgv7cPaZFDRI8rLHHsuMMN9dBgmDRYA1Mq2OZImHX7AA7tPkXg1Qe5yEw8BaqkxE9A5npo9iNiALVHHM+7XYg/d16HK//cAjM6B7E6frclUYuxa2JgDYwGTbVh'
        b'ISkcBw6QOlBupImNOoyWE8PLM79FaDq5j+TFAmaUMnQLJYYK07uhKZFgKg+mL0BeDPHwLug/QQg85HwLhvxI62ulWx1yOsTZYObExGjaLoSRRtUNZQd0Ntw0Jslzwo1p'
        b'ElgRCg+ww5z+s4Dz+tpQG5JgkqhLIteALd6/vAYz1+CcEFov37qAtZ5Jd4mFbSTK+/Bx4wyR0nu2+kdVr+Ggtuz6ZGwPJuTIDCTiPHr6AhY6aWnbkeqyAHXxdJa5Sloy'
        b'5/1czhLpKbdcT6BTC8PrsGePrvMWaxhPI3Ugz0fX3TTITo4o6P0z3pyVZsx9M03SCFX76UTmFGkHYzFElTqIrcyH41QSTBnCMBRZGxNq9GBzDP2j7NpeaDThilCXM1Dt'
        b'hFEjuGceS7J+6yEcC75Ap5zr6q3DhE0kOt19Tkji3hwhdaYe4c+oA7G5Voke9hoT5R3HTk1vuLuVyGopNB2NdyExuzWMhM+so4y6jkJmehTJ9xuOkqjQuU6VGbdcsDdV'
        b'47gi9EdfIkJczBsCEoIIA8qv7KBlEU/D9ptECWb0CBFaSM+FXtfLgkjMOxZFJKf58rEw1roWm0NohZWJxImz6A0SyrElKBiGo04fwAkdNXi47TxBQr0WdtuZsRMxwj6d'
        b'EJyJIKBhYn4/qQ5z8Th/WcZaDRs27MFK9zgiacWa2KFB6ldVGpHSDFi4SsLOxBHoU3c3OGK5nfjvHazxlcd2h1g69CaDXUmbDCO0TztoqOMdzVtJh9ZA7jGRGwF8P0Ff'
        b'AfTcJELQnuTtCEUXiMzeNob7WiGElnOEFFPp56KJXcZAqRhH6d+DJOXNBFwjYttsc8MHu31NiSo14oAhPDh2GYY27zhFRKGKXTBdwkOiaw0sd0mdtjGPCzdPsy70Xfug'
        b'MnqtgzvNPbuBzuPBceLzI4ftiAjn+clsPULqclTST5gpsW7/YWjxwKIl9fYczV8CdXs3Mw3X96ySECY1MN8NhmVNYeiCrDYRAyKCE/sIDoatvHEeCs0irAhCKzizSf9W'
        b'UxaCSzjeoG4COUTWCERzYYRUA3yY7G5qSBc2gHO2dtCnBw2qeuvp+IthIpiQtfOItQD61hFZ6d8BDVaYsYWo3RgM+mCbFzRZ+BLVyTsFzcG+xBOGvZmQ0oHtvvG7ZMTh'
        b'1li7G7tTsMAMxrZ5YlaMOXRFHiO+0EUb7iW5tdme6A3MuGChiS9xjiYjwuZs0y3nwrH7wNrz8fjQjcCtlnhHzl4teWiLjIERIl6tNMOImxxhwUKcO2ntFQQxxdBFrJqG'
        b'XViPPbuhJon4SZ1bJMETqS11JmtiIEdR/xAOWUVgvZN2NMxBXxI2WcGsXTzW0dmV4Yj3JljwFBzE7DXyuCCmVea6roUZGWYb6bSCnjBtR6g9uWG9FWldhbQlHDpMdHyO'
        b'gGKYsGCaIGH+Kmmfg5p06A2BQQxzQsMNiKaWiC7ahV1VhskL2BPp7hYReplE1TEVWkIj8dsBRRxzhqIgqPM21gHSMG7T6YxgSaRyAA56QpnmUf9Ladjq5LpxD1aY4+jG'
        b'8ItYaili4ivRoRzSpNtwziXlBp1AUaAa8a92fLhJsgNqNc9ibpCPw+VjrvaE5cU2WJNwMBhnthJNukfXWkS6oawfEYhBJV89jsgwwl1Nh1kftBdGcXKrIWFvPXZeJ6Qr'
        b'hREDVtlTXY5YZH+cz1pWMT8Y509fpfspQZIQyhVgSuOwGVG11uuat1R3EYY1EMl5aIL5ftB6IJoklYexSSfErPk3ZG5dAduk306JRTp4FyuOqsZDl5Zs5C6iui20mVGi'
        b'ibV7hE6ep5gCFYT3g3B8DSHXJO293eSwCpbrnd8oISBvJA5eTHL8YCqdeM1eTwUvuLcfG30IvhuJdM8qMaUcBvS86MhJs4ZSbczxsGfCjyYNNuS3GbotcOikEZJE47SR'
        b'TqhoK7SZbSYcrbGGprWsy1kCsZ3eEBj10SNIbxSd3bsBOtdZQUYgFOwm8deGKOJmL8MNrKhZOGYpwGhI/C3iXFkw4bufuMp4CCPjRXKJpy2hT/kAHXEZNuj60SHNaGBH'
        b'2Fq8J2+Qamd9VQdaDsCwyw0CrG5ifV3YsA6nEp2wT4NknTLiog/CiRukKh6PpztspUEqtx5MhK7Dkj04dGQ73LVVxOZEHFQLvaQLPepqV6FqLRY7h9FAmVBtImfhSvdJ'
        b'ogYdy32Jvmvc0QNnI/HeVqINfYRGzf5bccGe6FcdtJyys2F5ioWEmCSBE/WqhCmlUMzbR+yZoLToOIysVxASMZj2u0iUr5uu5D6NmqO+9hxx8RLolIfscMi1wj5TYgH5'
        b'N69B5cGLyOzkHSRxXz68gUjKLORG7CJU69WFdlPC8wbCihHSqpv9Fdbtwwc6UOd50DnOgTjoXbiLQxJ65TaM62tZkdLRCT120C+jR9jUDAs71q4jYbbECMtvYDk7moJk'
        b'GBPH7TxM31ZYQ8euczhDrBJr1bdbb8fWg1Af4kNwk4+18cSa5lMu4PBeay/IikokylhtJtgPPQEpWoGBdOpR4fgASgKxdB+MXCUJuoJkuBI6sNFDRFtztluRbjiDefGH'
        b'nENtiBbkY2GaKZ3vmLKQgK9fmUnHdJcNwQkp6XDfnf7ZCY0upKS3wXCcI947x/HGCXxgfcEW6gyIb5IO7GCDE04kwA0rBe8hSa7el5BjQS6QxLWMrdAVkyQRc5Gr9+jA'
        b'CJMyCaAZKs3jA2Mix/UEn1NWOKFL8q4PVilGHIeB7dh0fDdLlCYGtYY9YaMWQXrjXFqYoyNJBFlOXlb6mJsaSzL2PPbaEQSMQZsCzu2XiyLGMyDEdg+c3ZEOGaSQ1Oy0'
        b'V1XywNpgzsM2xKz9t9KgGmaZVasTZs7SHglRepi5iITdbuhx1MaG62d3nd9Nu6vBfmvMvIWlOKlHDDL/IrR5kbw1aSobHmuhCyOOioT5g/RgiQUdbG4UYcG8Kt65BDkk'
        b'FIwQeyndg+Ub5GiP3QqmeO9GOMmAuYEpkG1DnLkU7ohxTFcBm7x17XUJZAYNZNQ24v0jXlCuclSeqOYsZjiQRDPAaNo+vCcgHl6DZeYqIach54KzwcHESEWcVzuXuouI'
        b'PEnmttGnoSwOqyw8SLVmgui4VfgNpiDvghH1Q86Exe06MKsIUz7Xo4zw7g6iW9PYBDmXcTZFEXNPehBm5JBmcpeoTgVpLVvosOs2YYuyojhUB4vOR0Zc8rPERmcV4Ult'
        b'em8IKmShUl2HMK4KpiOVTxnvxqlNzPxJrDsD5tbDNHPh9eptJK2vOPCIDYnvrXvpLNrh3kbTGKhw2UZ4UUrKT0ISNOylO8g9hZPWSiTAPyDJoPlkqg52KN+UoR1UYvk+'
        b'e2jUVLhBQFRJX1TAgnGM/3Vo3ULEOkvjoDtM6kKz2gEb5WS87YQ5en5y2OsJleHQCgMsnPmsL7OaYm8SM3rR1T8g+jtCbCILu8ww/6bfFuLVJAl507MtbrSf2+dwKtWM'
        b'xDPoJoSpInadr+QbmHSesLINGDshqbRrP21vIR2qN2FlCAnek1cJYIaSdQmuBtIx7xYUEC0n8eO2D9RtxeykD0hYuuZIKsQiGhxl5qmyc8SJiYhFHtE/q7odywkFzm1P'
        b'o5+b14UFKehi17qD2+l+F/BeGAzKOfrTHFMkJXWL9uPUBljA3gORLOs3B+8kAvMDZ563hkoJ1OoSNZ9LxgZn6BDTxx6YDSF2c/cmEccywqZquo0KxU3Y6UTEdIAOvxgr'
        b'b+ACPLDWwoL98MAUO7a7YlEU83adYvaq4NN0Njk7iaYUKEuwP2Q9Af7EdX1C85k97rEEcV2aFrS2SnNtrN222RCbdp4koYGQ4ziBw7xWOE4qY+PhLdi9hnTHnIuQdRxn'
        b'jsKAQgqRlyqSgGqIOncKCOZnZaFFzxHqlEhJ6DZXhXa7PdBgSbJCjq7nWry7ba+sLOafOY4FSnj7+GnSix+YkZCVZ4WjqnE4uVvZ2QI6LLHK7tBROpRxaJQQ2ncRuc9N'
        b'9ddXY2leM0QJZiBTn4B9SEii2a1rewjeqs5CjhIHEzN+RMEXruwketCMebF0aj2MDkyak+hRFRoOnQcJoJkVvgoLdXB8P2k2FWGQLwsd4fpwVwLDtodwimnomHGGyNeE'
        b'SzIRv4eWsiRbd0KxAWaZ+JPc1YjD2tCRDnXqBJf5W5lTWeaG7P4wTxq82loFa0l8kE1mQlCW5r4Y0vlIrL9NVKICejSx4YROCgux8KDDa4TZy9d2QL8pzNlDp6EMNGwh'
        b'AavJB/qukN4zBJ2mfiQCEevefyh2L8w67bqKHTug3gl6jM1P4rgM8ZW6U1sYWOLYHuJyfQxHGjw0TliSmD1ghgte24m41Z31V/FL91zvS7CTjxn7XGiO+m02m4+mC0jI'
        b'zL+CfUewwFDEl/q644Qjj0rpnL8qNCL0yOZ+20/coZBVgBMIY4lTt7LiFZkwYijmEqeweo05Fnk7M+vSQQHd02QcZ3ayMoomejrhzGpLCM1Z5vqUtEBYCTRswlZkiYMF'
        b'EoHwOHtpGDO4HDnnUKU0KFiylPldpPVxszRiR8AlKHZ2p1VY0C+Cm3yaV5+utlAFi1zoBSsBlhGH4cxhyVhwEh6EPDKtEUB0LLZ3mD0OrRKmMRrSW+4CIuxVUMwtOkgF'
        b'mCO4G4tceQNbhY0+P39e8FbsCloyyGG5nLTWHd43JNrWf8nZiQYzFmC+2IifpXG7EwlQLcsMcthlaii05zoCcdltLwaLr1kK2Sd/5b/vYoW8ua91bcQuL/JfR+0LCeRL'
        b'CL0oEfurSr/8jaVE4GYocqOhuFy4iPv//KE4YZBo1WZT/fSqc+4b7LRywpLf1zb/8ctvHzV42XODyyfzP9WqLO+w9jlk4VS+dcdfPCS7fbseNPX+W3Az6vXSczt/s2Vs'
        b'7oO0178MfV3rq01f+CbqvDcY9ML90Zu/+jK5PuKld9/8e8Sk/Ss/fc8je+P7585MPnQ8tqXxbH705+v/FTP4yUuFwp/tubnu3O8Hog2++mWrl8veg7nD3r67i+zdZxRd'
        b'DX+9b9bDb/Bs/g/iDCFsQquq+WK163feuLH5b7N/8V7f11xnOtHxxw8+e/fqS6l23ncnOrOcxg38AlqOVrpcee2TE4VJGz4+v3f/H5O3vDYr88ndxFf21CjPWh3T+cDD'
        b'0FFnUi31h86mf/G9bth//dSryn83b20vS/xuu0bVF7q/u6n83nfNP2w9WBs2e/hdhR9tqN0TUes9JhNRF9EQ0nrynerjVobTAWq+Z32/m6j8g7jk97ziaz99JUNZNsqu'
        b'sHncyfTVxj9UWRtNB8lbVVq1bb9yyXjY8MM1r0edqvq+xW/N7d/ep5H4zrvTX75Rn6IV9OnLn763pvHjCt33ZV9/7/9r7sqDorjS+Ex3M8wBOCIqAiJ4gsMh4IGIByUe'
        b'w7lZZb2iLQwDjA4zwxyoROMJyI1aBtBN1ALFC0QMgkqweC8Vs7UpqS1dxU5042bVdeOmllKzQY3s+14Dmk3+2a2tYmtqftPz+s3rfq+73/u+qe/3++oeme6vS7FNqX4V'
        b'lp8Uejf6sMtnYZ3vTPa5UfI4xTtq+7nYXa96BeXD6Z803CmxMls8lo76qloXFlNXXv66ImTTevdl6fXMTK8nrZP8H447+2Bc1e8u31zTXN87sbh68vyG27775/W57L5+'
        b'1+oRUf3g8YmemBePSz8/+cWNVSciCrfcK4w0pyX9ub1GtTL97pjl8SsnV3UuuTWiuXPuus6pP6Y3zXx6BHLmPfryH/9s9rnmdasmc+0jhfPdruozV3MLTz+qnPh8s/u3'
        b'h5LjF7tFxnl5d/8l4PDrgE3KNd2fueWeL9zmEx1r2TvB5xuuPvLG897dq5pzOurn/f3emLavza+un+1ulfV923Xj9IvcjY2n5j9snbbuZm/okR+07aefko/Z7Y1P/xTd'
        b'86h3xtGQg9t+HN31x6T8hM2BSlEo5jSZCcpRfhR5iMUppDwdnRfj1xuIVVY3GOzKE1NqMJHeeFIHdDc2pOCGX8zLQJbyFo7MK7VSke5VjGoY1CRVWV0VrmSFLxlmdbiQ'
        b'ZbmVlfjkcXLHFHrEsejy9sEam/DFTTmuMonnAimuYVFj6G/soAnHkmmtxpbrkuPArcNQMSqFKA25qxI3Dct1kgS6cfhsaC6Nw6VxOB0/qdpfD5VB40tHQvOJnAxdUgfT'
        b'wZBnL1X5LR9sTI7rmdDpufZp4gyYv8qGyuQ55ORsZIUr+mljDlxMW8MtMtTB42Y76B7K5we/LUonirNE4ra39FnO4vqfp5CLGNoo0yGHQB86sf6/gJj4m+eN5tR0nqfx'
        b'1zcJMBqGmS71AwWRPhnjIpUzHCuXylgZI2PcWHcnd3e1Qu2rdnaXeSi5ER6Mp5YZP10q2c5EMNJImjqIYyEW1xfKNJ7S2ElQxvDR/WmFGF0U3WJWDJR4yrxWqWNI2yyj'
        b'DoJfTYgdqDuBmcoEkreGCZTs5M7QMhkTREvIi5QdhxBrWe9ALLhcLZd6St9+c31cr3X9YKgza30MnX8T+h0+9DfGkN2QUnEwaOg1DJEGbgIwWSy3fyEpFsxlSZGjUQlu'
        b'In5PBa6A/GWoCFU4S9zGsPAH1AVD17UQJ9tIKWnB6+6MMm0SXqBufrnozNyuHOOUHHe53D9Moa71LO9kzreiE3M08cOHP6l8/2+j7p+we9Wubufznl/x/kNlXeiLurKs'
        b'hnGdPVH3usuOX5h08s7qwmULq14W+I4+dPHZwa4OZfcy/6qHt/btK76TopizdtaDz6d982nTNRb/VpO44vuUzrq41y9/f+CglyWr+dzTSjbmTN7Iv86tnJByQf0sruTm'
        b'sdxXPSFZcx7Ozb6X5f/BGm/vL3M/eF3WoXoQmzh71odLvzu59vrl16Xv+bmE7VrgqtJ1V69XOodkdON50T9ELtixcE8kCktS3/fI3Lvva5/RbZ+O/PVXfjj4O0uFr/VZ'
        b'zw5mkm/Pnszlnl+cO9ym7WAv3v5elf+Un5G35tI1R+A4UTbsnMEIdmpyMuXbOks2ZKtQM0Ms4iJUTvkYzl74QnxyMD5PK1WiJohXH47bWXRMj/fTVWUK2kEm/5IRGGQq'
        b'qBAX/MFDLoU76+uHC6j6mMoeoIwCDdVEZ4mMY+S4PZxK4qG9uBAYIaHEHl0mcdHiWl9R6Am1oQKFBpcHAGO4VEocsiqJIoQhTspHy0S2OvH12wZEvTjihTcmSYmzVL2d'
        b'skxMcvAzSxTaIG1wfx03XMwmqZPpYcPDcVu/0hr6MAH45jkxtLuBybhObDRRi8vU6HCglpO44wMscUNqg0QK8i7imbTFxwUlzYiQjp0iccb7GdkKtJNyyt9dGBUfHkF+'
        b'ShwDdGkr1TXzZ+cQ50zUlRuDLqEmqKFNxOUx7rDfDTeyYbhULurO7aX5ZUsgSV4FK+GGE49Niq6gI/3yVvjyHIgjx2WJQRJy7kWjwqRkiTsup1R35QheE4zLgClvCMqW'
        b'Eg/zOKoWc782Gjw1IGOXANIaiaTnnMR7G26ZwaFdqMifjriOGBVH4+G8SO/JkEviXFSBDLnkJ/EZ8dzKxqIq21sV0B5fpZZYHSlJ1HJYg46iGhVujoHQgRYbsVBaLfjj'
        b'HGKLuEokPhM4Z4j0ohR34hHV4hbKRtJAe6SkEu9WoUMMhtjtT2hXJ6J6+6AuHY1Qgtyy68dTbTYyTufeiUcNAeTyFsfP88OlVHcxWYvKQpOCA2WSJYuct07rT5ixD+WP'
        b'UpGp4mNigOF9uIE4WCem54kc/1PEvT40G12BIGpKgnfaKoUQLC3VGMAFuMEMu4JByXuAX+TlwBULOFSATqFTYpLf/fPxKTL0xaCAmMCsQAckiskMRJtMEo+yNwTVa+KC'
        b'gxKDQ6QS4sMfdhnJKnELyhfl4a6iY9viyfWJDyENVIwnD0UF6cKICBZ/9O4SeoRwfFKiWRo0FVifMPJXUakKVzK4cUOu+BxdQueDNOCjxUvGE4e4OgAdHUhlFDD08/v/'
        b'aJUYNQSGyZsEwrkE5G7KfjImKKqp+7dE7TMXqpfWv9XH7QBdNaYP0gXLpSb2P2eTDby4aSKviloNUwXWqDdZbWRhE5zsDotRL3BGg80ucOkGHUGzRW8SWJvdKjilbbHr'
        b'bQKXZjYbBdZgsgtOGcTCIh/WVFOmXnAymCwOu8DqsqwCa7amC7IMg9GuJ1+yUy0Cm2ewCE6pNp3BILBZ+s2kCmleabAZTDZ7qkmnF2QWR5rRoBNcFom8xsTUjeTHLhar'
        b'3m43ZGzhN2cbBXmCWbdxsYGcpCItYqbeBOJUgqvBZubthmw9aSjbInCLfxW7WHC1pFptep7sAo63MDzbnD57lpjVg083ZBrsgnOqTqe32G2CK+0YbzcTg9GUKbArExME'
        b'lS3LkGHn9Var2Sq4Oky6rFSDSZ/O6zfrBAXP2/RkqHhecDOZeXNahsOmo9mYBMXAF9IdhwnUqd7YY+J4B1g3gcW2FWALwE6APQDbKcUNIA8gCyATYAdANmXLApgBNgAA'
        b't9BqBDAAOADeA0gFADqr1QLwPkA+QAGAHQAIxVYTwDaAzQC5ABsBdlGhO4A0eiBg2u2GrUKAnEEGIdxIigHbanXvz20rWuOFPIPcL3pdVoig5vn+7X7z/IVX/3c/S6pu'
        b'IwiUAbsV9unTkwLllAcoOPN8qtHI8+KNS5mCCrhjZWI6VesTKCkaMIX/LSGzII8mV99h1M+DfHA2yIDKSTiZnPnvHyGPFIayqP8Ff6MmOg=='
    ))))
