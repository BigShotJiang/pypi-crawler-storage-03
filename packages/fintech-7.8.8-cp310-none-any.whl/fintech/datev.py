
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
DATEV module of the Python Fintech package.

This module defines functions and classes
to create DATEV data exchange files.
"""

__all__ = ['DatevCSV', 'DatevKNE']

class DatevCSV:
    """DatevCSV format class"""

    def __init__(self, adviser_id, client_id, account_length=4, currency='EUR', initials=None, version=510, first_month=1):
        """
        Initializes the DatevCSV instance.

        :param adviser_id: DATEV number of the accountant
            (Beraternummer). A numeric value up to 7 digits.
        :param client_id: DATEV number of the client
            (Mandantennummer). A numeric value up to 5 digits.
        :param account_length: Length of G/L account numbers
            (Sachkonten). Therefore subledger account numbers
            (Personenkonten) are one digit longer. It must be
            a value between 4 (default) and 8.
        :param currency: Currency code (Währungskennzeichen)
        :param initials: Initials of the creator (Namenskürzel)
        :param version: Version of DATEV format (eg. 510, 710)
        :param first_month: First month of financial year (*new in v6.4.1*).
        """
        ...

    @property
    def adviser_id(self):
        """DATEV adviser number (read-only)"""
        ...

    @property
    def client_id(self):
        """DATEV client number (read-only)"""
        ...

    @property
    def account_length(self):
        """Length of G/L account numbers (read-only)"""
        ...

    @property
    def currency(self):
        """Base currency (read-only)"""
        ...

    @property
    def initials(self):
        """Initials of the creator (read-only)"""
        ...

    @property
    def version(self):
        """Version of DATEV format (read-only)"""
        ...

    @property
    def first_month(self):
        """First month of financial year (read-only)"""
        ...

    def add_entity(self, account, name, street=None, postcode=None, city=None, country=None, vat_id=None, customer_id=None, tag=None, other=None):
        """
        Adds a new debtor or creditor entity.

        There are a huge number of possible fields to set. Only
        the most important fields can be set directly by the
        available parameters. Additional fields must be set
        by using the parameter *other*.

        Fields that can be set directly
        (targeted DATEV field names in square brackets):

        :param account: Account number [Konto]
        :param name: Name [Name (Adressatentyp keine Angabe)]
        :param street: Street [Straße]
        :param postcode: Postal code [Postleitzahl]
        :param city: City [Ort]
        :param country: Country code, ISO-3166 [Land]
        :param vat_id: VAT-ID [EU-Land]+[EU-USt-IdNr.]
        :param customer_id: Customer ID [Kundennummer]
        :param tag: Short description of the dataset. Also used
            in the final file name. Defaults to "Stammdaten".
        :param other: An optional dictionary with extra fields.
            Note that the method arguments take precedence over
            the field values in this dictionary. For possible
            field names and type declarations see
            `DATEV documentation <https://www.datev.de/dnlexom/client/app/index.html#/document/1003221/D18014404834105739>`_.
        """
        ...

    def add_accounting(self, debitaccount, creditaccount, amount, date, reference=None, postingtext=None, vat_id=None, tag=None, other=None):
        """
        Adds a new accounting record.

        Each record is added to a DATEV data file, grouped by a
        combination of *tag* name and the corresponding financial
        year.

        There are a huge number of possible fields to set. Only
        the most important fields can be set directly by the
        available parameters. Additional fields must be set
        by using the parameter *other*.

        Fields that can be set directly
        (targeted DATEV field names in square brackets):

        :param debitaccount: The debit account [Konto]
        :param creditaccount: The credit account
            [Gegenkonto (ohne BU-Schlüssel)]
        :param amount: The posting amount with not more than
            two decimals.
            [Umsatz (ohne Soll/Haben-Kz)]+[Soll/Haben-Kennzeichen]
        :param date: The booking date. Must be a date object or
            an ISO8601 formatted string [Belegdatum]
        :param reference: Usually the invoice number [Belegfeld 1]
        :param postingtext: The posting text [Buchungstext]
        :param vat_id: The VAT-ID [EU-Land u. USt-IdNr.]
        :param tag: Short description of the dataset. Also used
            in the final file name. Defaults to "Bewegungsdaten".
        :param other: An optional dictionary with extra fields.
            Note that the method arguments take precedence over
            the field values in this dictionary. For possible
            field names and type declarations see
            `DATEV documentation <https://www.datev.de/dnlexom/client/app/index.html#/document/1003221/D36028803343536651>`_.
    
        """
        ...

    def as_dict(self):
        """
        Generates the DATEV files and returns them as a dictionary.

        The keys represent the file names and the values the
        corresponding file data as bytes.
        """
        ...

    def save(self, path):
        """
        Generates and saves all DATEV files.

        :param path: If *path* ends with the extension *.zip*, all files are
            stored in this archive. Otherwise the files are saved in a folder.
        """
        ...


class DatevKNE:
    """
    The DatevKNE class (Postversanddateien)

    *This format is obsolete and not longer accepted by DATEV*.
    """

    def __init__(self, adviserid, advisername, clientid, dfv='', kne=4, mediumid=1, password=''):
        """
        Initializes the DatevKNE instance.

        :param adviserid: DATEV number of the accountant (Beraternummer).
            A numeric value up to 7 digits.
        :param advisername: DATEV name of the accountant (Beratername).
            An alpha-numeric value up to 9 characters.
        :param clientid: DATEV number of the client (Mandantennummer).
            A numeric value up to 5 digits.
        :param dfv: The DFV label (DFV-Kennzeichen). Usually the initials
            of the client name (2 characters).
        :param kne: Length of G/L account numbers (Sachkonten). Therefore
            subledger account numbers (Personenkonten) are one digit longer.
            It must be a value between 4 (default) and 8.
        :param mediumid: The medium id up to 3 digits.
        :param password: The password registered at DATEV, usually unused.
        """
        ...

    @property
    def adviserid(self):
        """Datev adviser number (read-only)"""
        ...

    @property
    def advisername(self):
        """Datev adviser name (read-only)"""
        ...

    @property
    def clientid(self):
        """Datev client number (read-only)"""
        ...

    @property
    def dfv(self):
        """Datev DFV label (read-only)"""
        ...

    @property
    def kne(self):
        """Length of accounting numbers (read-only)"""
        ...

    @property
    def mediumid(self):
        """Data medium id (read-only)"""
        ...

    @property
    def password(self):
        """Datev password (read-only)"""
        ...

    def add(self, inputinfo='', accountingno=None, **data):
        """
        Adds a new accounting entry.

        Each entry is added to a DATEV data file, grouped by a combination
        of *inputinfo*, *accountingno*, year of booking date and entry type.

        :param inputinfo: Some information string about the passed entry.
            For each different value of *inputinfo* a new file is generated.
            It can be an alpha-numeric value up to 16 characters (optional).
        :param accountingno: The accounting number (Abrechnungsnummer) this
            entry is assigned to. For accounting records it can be an integer
            between 1 and 69 (default is 1), for debtor and creditor core
            data it is set to 189.

        Fields for accounting entries:

        :param debitaccount: The debit account (Sollkonto) **mandatory**
        :param creditaccount: The credit account (Gegen-/Habenkonto) **mandatory**
        :param amount: The posting amount **mandatory**
        :param date: The booking date. Must be a date object or an
            ISO8601 formatted string. **mandatory**
        :param voucherfield1: Usually the invoice number (Belegfeld1) [12]
        :param voucherfield2: The due date in form of DDMMYY or the
            payment term id, mostly unused (Belegfeld2) [12]
        :param postingtext: The posting text. Usually the debtor/creditor
            name (Buchungstext) [30]
        :param accountingkey: DATEV accounting key consisting of
            adjustment key and tax key.
    
            Adjustment keys (Berichtigungsschlüssel):
    
            - 1: Steuerschlüssel bei Buchungen mit EU-Tatbestand
            - 2: Generalumkehr
            - 3: Generalumkehr bei aufzuteilender Vorsteuer
            - 4: Aufhebung der Automatik
            - 5: Individueller Umsatzsteuerschlüssel
            - 6: Generalumkehr bei Buchungen mit EU-Tatbestand
            - 7: Generalumkehr bei individuellem Umsatzsteuerschlüssel
            - 8: Generalumkehr bei Aufhebung der Automatik
            - 9: Aufzuteilende Vorsteuer
    
            Tax keys (Steuerschlüssel):
    
            - 1: Umsatzsteuerfrei (mit Vorsteuerabzug)
            - 2: Umsatzsteuer 7%
            - 3: Umsatzsteuer 19%
            - 4: n/a
            - 5: Umsatzsteuer 16%
            - 6: n/a
            - 7: Vorsteuer 16%
            - 8: Vorsteuer 7%
            - 9: Vorsteuer 19%

        :param discount: Discount for early payment (Skonto)
        :param costcenter1: Cost center 1 (Kostenstelle 1) [8]
        :param costcenter2: Cost center 2 (Kostenstelle 2) [8]
        :param vatid: The VAT-ID (USt-ID) [15]
        :param eutaxrate: The EU tax rate (EU-Steuersatz)
        :param currency: Currency, default is EUR (Währung) [4]
        :param exchangerate: Currency exchange rate (Währungskurs)

        Fields for debtor and creditor core data:

        :param account: Account number **mandatory**
        :param name1: Name1 [20] **mandatory**
        :param name2: Name2 [20]
        :param customerid: The customer id [15]
        :param title: Title [1]

            - 1: Herrn/Frau/Frl./Firma
            - 2: Herrn
            - 3: Frau
            - 4: Frl.
            - 5: Firma
            - 6: Eheleute
            - 7: Herrn und Frau

        :param street: Street [36]
        :param postbox: Post office box [10]
        :param postcode: Postal code [10]
        :param city: City [30]
        :param country: Country code, ISO-3166 [2]
        :param phone: Phone [20]
        :param fax: Fax [20]
        :param email: Email [60]
        :param vatid: VAT-ID [15]
        :param bankname: Bank name [27]
        :param bankaccount: Bank account number [10]
        :param bankcode: Bank code [8]
        :param iban: IBAN [34]
        :param bic: BIC [11]
        """
        ...

    def as_dict(self):
        """
        Generates the DATEV files and returns them as a dictionary.

        The keys represent the file names and the values the
        corresponding file data as bytes.
        """
        ...

    def save(self, path):
        """
        Generates and saves all DATEV files.

        :param path: If *path* ends with the extension *.zip*, all files are
            stored in this archive. Otherwise the files are saved in a folder.
        """
        ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzsvQdcW9fZMH7u1UAgMQwYY+MhbwRITDOMJ16AWDbeCwQSIFsIrOGBt7ENNsbYgPfee+/dnpO3X/ImaZsmbVKSNGmTtnGS9k2b0dTN+J5zriSEJTlOv/f9/77/7/cZ'
        b'c7lnr+c86zzPuR+gp/6J4HcM/FpHwEOPZqNKNJvTc3p+PZrNG0SHxXrREc4SqhcbJPVoMbL2mMMbpHpJPbeOM/gZ+HqOQ3ppMfKvUvk9WRkwfuzUCdOV1TV6u8mgrKlQ'
        b'2qoMyqJltqoas3Ki0WwzlFcpa3XlC3WVBk1AwNQqo9WZV2+oMJoNVmWF3VxuM9aYrUqdWa8sN+msVoM1wFajLLcYdDaDUmhAr7PplIal5VU6c6VBWWE0GayagPLebsPq'
        b'B7994FdOh2aCRwNq4Br4BlGDuEHSIG3wa5A1+DcENMgbFA2BDUENwQ0hDd0aQhvCGsIbujdENPRoiGzo2dCrIaqhd0UfNh2ylX0aUT1a2bfOf0WfejQDrehbjzi0qs+q'
        b'vsVu70uQf4VKVFDuPsc8/PaC3zDaGTGb52KkkheYZPD+UCVCW9KC4K00b3BfNbIPhFdy2BRHmsimwrzJpJE0F6pIc860IjU5OlOKhk4Qk0dlsSrOHkVzrsmUWnPyyVay'
        b'JZ9s4SaTRyggh8eX8cnpKt7eHXIUryTt2py4HNKKt0qQWMzhQ0MzWVncyCXQFDXZBKUlKIhszseHRQWD8V4o2xdyjCePQnET2RxXC73ZkiMhp/BNFICv8fg6T47Y+0OW'
        b'6GDyALJcVeDGJYvs5NoixSI7h5au7kFaRHiLCO+AjtJ8CaQ9HjfhlnitOob2lrTQkF/OaBQ1SIzrFYvKuafAMso5ZVV0/YTVQz9u/SqiHGvHNQL4ruRh7Ti2djxbL24V'
        b'X+z2Dmu3/um1ox2J8Fi7fsLavTPVDykQCkkwVCuOTgpDLDK1gkc0Y+3o5Ypb4zKEyBdT/FEITIJywGLFl/ZkIbJPfwmCv8raRTVx73HR6AwyBVBQ6dVT/EUoGvNZ2DLu'
        b'7ZkvLzjV84+cyR8SHvfZzV32Q8qEnheDn1gMK+cgFv3uzM+D24O56M/Qe4k/nSmOeh11IHs8Xd8TeDO+AyvXFD85Oppsjs9Wk834zNToXHLTmk9a4jQ56tx8DpmD/UdW'
        b'kkceCyB3jjtbWICumwfR6a+QuyaYf64JrvK2OaQeE6wosNAe2MMpiO8ZGlY8RT2dR7wIhUWRA/3xRns3SBhUis8V84ic6IMGooGr8S47raRoAcRO4SMAUlEVmoCPk8Ms'
        b'flFqHWkTIbKOnETxKJ604bWsloqi6aSNQ6SFHERqpB7sxxrtmzawOH8yaZYgfjmXkdobH8d77UMhIU/Wj+6FWC2A8Ka8ydH4DNmN98Vlw/aUIg05I8HryHVyljVpDCcP'
        b'8TUpwgeUaAQagdeTFiN5+5zYugsSA/7zhXmvJgbhBMUG3eg0Y9jiOlHQT34u7THmvDIybvHZqyfkuoRbVeZcPnTK7hEr/mvXjeIef7MM3HHv2Ov/fDEsXxZy9/XL4afl'
        b'Fx9eP7Lv9dQxKz/UDe6dMK5X4qblZ9+pKDkX3GivbL+4v/pfN+bOMYbNiNK/d27GnIjVIxd+/jj+n8naXauGp/7BNnnzwQF9Q0ZH2f39/v6LtG221IOyxSqJjSJOOz40'
        b'REuaY0kzubUsX50blyNBoeS2iDRMI1tsPSFH/5q5sblq0piTiffkFUiQHF/hyQF8ZaiNImJyHa9fHatRzcRHc2Md+CWYrBHVkHULWIYBZBdul+MzcdmSVXZACZvjedSN'
        b'3BXhC5Z0WySt4dGkyTDTm2FhtoiQOIMbGI2v9MONKr6Dj1ZZKKio5OzPv/GgUPckYkSFpabOYAYKwmiTBuiKYfGojkCLwaw3WEoshvIai55mtSrhIRsVwsm4APiJgN8g'
        b'+KF/Q+FvCBfCB3AWqbNmlahDKhTu8CspsdjNJSUd8pKScpNBZ7bXlpT82/1WcRY/+i6hD9rcaNo5Cq9KIuV5TsrRp5iTfkefDO+S+/jS6Nhc0qzNUePN8blAKuJzOTQY'
        b'XykhdyUlQyZ22Y30n9jxl+FdA2UHgBXQc7NF8Cs2otkS+CvV87P99EENqILTi/WS9f6zZexdqvdbL5vtz95len94DxAob4VIH6CXQ1gOYUAkEFboAyGs0HPAPlSqgjuk'
        b'U9iUFbApfPwdYKNykVu36Jj9nIgiHTlJOlQkYCBRowgwkBgwkIhhIDHDOqJV4mK39yW0KS8YSOSBgcQCihcZxAxHJ0QsXb6sJBMZT4X+BFmLIGX5kuuflL5S9tGvb5a2'
        b'6ht1H5duqTxv+AhiZv9kLrm8LXHD5P1HdnZ7oVB3WmeSnOXOlv6neHtcH8WEmD5b5DMz13wc2XNK5Lqf7k4ORFdF3cLvjVJJ2cYDaroDX4vtpJJny2KlKBifFNXNHGmj'
        b'bMQscp60dGYQ9S1DijiRXyY+yfYlOR81XEua8oBlUEmRDG/m53NLyVrSJKRuxufILorB8O1MbQ6+ANg3ne+5qgfbc+X4IW7GTYUi8hD4AjGSkP0cuRtYwNrNIY/wrVh1'
        b'dg7FBTJynZ+Nj+L1eC05qOLdQFTkba8xiO2QlZQYzUZbSQnbU5TnCZkNewfAVgy7SPx9XbAAAhpnPmE3STrEVoOpokNM+b4Ov8UGixVYRAtdHgslgGc4Z8u0SksgfQS7'
        b'tgkQaDTHuU1CTnluE49Wy/mndoML7FIdYFfBO4COZ2RPBEDHM6ATMUDjV4mK3d698RXIB9DZY+kibcfbSasccG8TrHFTPGkpzhZWdHLRFLWZHAZaOJockXaTqoxj/7pV'
        b'bE2AQtU9lnxSSuEvujzuDxpdnu7T0pDyqgpTmf3X4s2J6tK/ls58MfKVn/yWR4eKZNs/H64S23pAsVDcEOYAlwHlDoBZmjPUNgBRBgKYxj3kGuDvFtKiUdfi3UEOVN1r'
        b'lRhvUPdjMIUb8TZyC8DGCTM2HqAGr9fb6JSrcAO5pC1Uc4hfzC3Dh8YuxGeEdeW9AgkgykqDzWgzVDvghOK5gDIFp+DqQl0r5coiVCVmq94hNuuqDZ2AYQkRmgl1gQWD'
        b'CEr1y50QEXTIC0R4aed/BBd5iArPBotd+L6FQQU+P9ILYDihogifNxaLD3LWJCj0rxmr3cAiZoUbYHxaym9Osie8lXA8QZxcC+zS+b/KFo8OVYlslPVeSRqSGGAcBTBw'
        b'4ZKlgHy22ihhgTU/FOAGG+rpA91AAx+MEKj4sWXQXQoauDXUhVFikx100jeuADCweoJBpQIQhdvyWLuCgURYZbreHZLFOpPdAxhEbsAQ7oIIOt1VLhyx95kQ4WrSN5oY'
        b'LkAE5Ze5CvH/KargHNV3hQlJgV1Dd30WZtLdVNKoVmsmZ/fC+3KnkcbC4mjKWk3LBh5VwyEbeeAvjSQt9ji6JK1ZnDfcgk+T4+5gBMzcbuOBpAUiawGUivnip5+UfgyQ'
        b'ZKqI+VOcLltnYhBUq2v84wXDad1HpYvn/rwsrjyuNVqXqzurCylHL0VYRBP29LhsS4jT6/XZOlnF+yYOJeYHH4ooBC6TypfRsnI5cIoNtK9dmUDoXzOjOrnkQaSWbM3v'
        b'QtGW4pvkAINCO1430h0IoQ6ynZx2giFfyKBwNDlaQDYBVHbiKIDCqgWsBXyXXMabY/E2d9oGvHp9jMpBWMQ+eUgBVqX2Wso6uqhagEnGOEUFx38fwtcFOmBHyOWOsASC'
        b'5QJRj/0AuKuTpDFIpRJ9tRNSQ3d4gdSurXkIdV3RFpOpXWiLa+SeS4jzYKHEXkFUVGD8/E+9xdZciHj52+laXXblpwBA/1lWVRGuOy25EtkjQa2nANSkO2v44NJ5A/+S'
        b'uvSibu6LM1+eS6aSImIiRS++/dOZoje6vfKTPUFI3D142o0PHXQrlzwqdrE5dSoBLKIWshUFYLhMbjoWG+/u7ljvNNxoo/O3VGYlTXE5pFktxScKkHQ+P7CwVsBWpxOC'
        b'KG/EGCNyGp9hzFFMmXcIeBb6Ar7farM4UBeV6kNsoQAPAQAXdUGduIRmYaXOiIRF9g0LwOV0ggFVSdhdCKvZCxg81YiKL7BQeV4VSLkwSiZBJgkoKRH0b/CuKClZZNeZ'
        b'hBQBg8rKAYAqayzLOmQOnsvK+KoOaYXRYNJbGWvFqClDoAw2Wc+cyPiZ4pcwEDo1xXQgtJwMiXkxJ/wE8QqZQhIiCZfZ6XL74UPkkNwhvcwhN5FMwZfa5vkWXihy7CK8'
        b'8LPFehEVVvbzsyXtSC89DMLKEa6eA0FGVkzxrn+HdIIZkPuyJ+HjDWVGWw3IgfFai0EvvD4WuInHtIknodMNljp7pbVWZ7eWV+lMBmUyJNEhPVHkGWx1NoNyosVotZ3h'
        b'2bQ//hkM+cs9MK3aGrOtJrMAplkZPVZvMVitMMlm27Ja5TQQQi1mQ1W1wazKdAtYKw2V8LTpzHqv5cw6G7lvMWmURbBINVB2eo3F/Dz5vFW20GA0G5RjzZW6MoMqs0ta'
        b'ptZuqSsz1BmM5VVmu7kyc8I0dR7tFPydVmxT54Dopskca4YJM2ROBRppih+7UKfXKCdZdHqoymCyUsppYu2arYtrLFBznbMNiy2z2GbRkUOGzKIaq61CV17FXkwGo61O'
        b'V2XKLIQcrDmYeSv8rbO7FXcGypbQ3lHxXenoCERplLPtVmjY5NZ5ZaLPlKRMrcFsrtMotTUWqLu2Bmoz1+lYOwZHewblJHLfZDNWKhfXmD3iyozWzKkGk6EC0rIMwJEu'
        b'pPVGO6JUzjTlJAPADjleYbPSUdIp9cytnJSnypygztcZTe6pQowqM0eAE5t7mjNOlTlRt9Q9AYKqzGLYxtBJg3uCM06VmaUzL3ROOcwRDXadNRqzkMKwusBeDRVAVB45'
        b'TvUlC+msCdMPkTlZYwtomsFgqQBkAa/FM3ImTlWPq4G1cUw+2wtGcxXAGq3HMe3ZOnutTU3bAaxTpnG06XjvMu/e4uncdxlEkscgkjwHkeRtEEnCIJI6B5HkPogkL4NI'
        b'8jWIJLfOJvkYRJLvQSR7DCLZcxDJ3gaRLAwiuXMQye6DSPYyiGRfg0h262yyj0Ek+x5EiscgUjwHkeJtECnCIFI6B5HiPogUL4NI8TWIFLfOpvgYRIrvQQzzGMQwz0EM'
        b'8zaIYcIghnUOYpj7IIZ5GcQwX4MY5tbZYT4GMazLIDo3Iuwni9FQoRPw4ySLnRyqqLFUA2LW2imqM7MxADY2gPjkDNRaACED9jNbay2G8qpawNdmiAdcbLMYbDQHpJcZ'
        b'dJYymCgIjjdSlsGgFsjdWLuVEpQ6YBsyZ5DjVRaYN6uVNUCxnkBjTcZqo00Z7SC9qszZMN00XxkkmitpvonkuMlkrAQaZVMazcqpOqCLbgWK2RrQlCKm13WvrJOMq2dD'
        b'LwBhRNPiXRIc5SFpsGeBJN8FkrwWSFZmWew2SPYsx9JTfFeY4rXCYb4LDGMF8nUCXWZzDnwJ8CcszmZYanO9ACZyvSa7Z7W6sgkLkWUAclzpFjE4c7bRDKtB15+1Q5Pq'
        b'IIqSXsDSXYJJXYOAfnRWG1A7i7HCRqGmQlcF/YdMZr0OOmMuA7B1rbjNQo5XAhDlmPXGxRrlRIF+uIeSuoSSu4RSuoSGdQmldgmldQmldwlldG09oWuwa28Su3YnsWt/'
        b'Ert2KHGYFzZFGT3FMatWB6Oh6mSMvCU6eCVvSU72yVeaC5V5SS/03hrlu7zFd2HFfI/hGem+uLMfkznJd8td+LTnyQao0lu2LiQg1YMEpHqSgFRvJCBVIAGpndg41Z0E'
        b'pHohAam+SECqG6pP9UECUn3TsTSPQaR5DiLN2yDShEGkdQ4izX0QaV4GkeZrEGlunU3zMYg034NI9xhEuucg0r0NIl0YRHrnINLdB5HuZRDpvgaR7tbZdB+DSPc9iAyP'
        b'QWR4DiLD2yAyhEFkdA4iw30QGV4GkeFrEBlunc3wMYgM34MABOkhKyR4ERYSvEoLCQ5xIcGNTUnoIjAkeJMYEnyKDAnuskGCL6Ehoct4HF2caDFU663LAMtUA9621pgW'
        b'AyeRWTyhaKyaUSub1WKoACJopjTPa3SS9+hk79Ep3qOHeY9O9R6d5j063Xt0ho/hJFCEvtBM7tdW2AxWZWFRYbGDgaPE3FprAHlYYCY7iblbrJN8u0VNMpSR+5TSP8U2'
        b'VArxDq7BGUrqEkrOLHIoV9wKe6hdEj2jkjyjQMwxUaFYZ6N8qbLYDtXpqg1ARnU2u5WytcJolNU6sx3Ii7LSIIApkENvagCVWxEjJe5GPSv2g5m91O+FKHmv2zMjUzF1'
        b'zo4SmG+lg+VlU1lB0x2TLLwnub1TmbBTU/WEyyw4I7PQAz0LVaJa6CGQcFpC7TUs9HC6Q2KtNRltlr4uJV5IV3Uetbtb6dRLCuo8XsRz0m95Cc9LE2WvMmWeOZWzUtuS'
        b'TXH4jFgjR7JUflUK3vrfqMyrUvl3BIwtL6+xm20gPHQEZcGKC0KHrtZgetxdUOVRZfiTXuMBBqqBsaDqUqUg9gAEGwHvQBaqi+0QUwbIMgRev7wPEdOqBX6mpspsUBbX'
        b'mEzx2YCQzGptHVWvdAY7UVzmDO1spVCMqtEo8rQarXYhgqa5h4UtN4lq/QT2Xmgoa5q6uLzKRO7D0puAJXEPZmYZTIZKPR2I8OrQuXS+JznEo0znTDB2n/KDBsfOdsps'
        b'SoEnckh+nToqh8zHOHUq7UFm2Fs2JhU4amDNmYyQgb0ZzRU1SrVyrMXm7IojJsdMSz4VSbMlecuW5JEt2Vu2ZI9sKd6ypXhkG+Yt2zCPbKnesqV6ZEvzli3NI1u6t2zA'
        b'YhQWT02ECK2wMJTVNbDIJI9ICCjzDYAunYpYpV2j7FTEQqQAy07NqEZJ2XWn0C1oXDuXUZkXm5c50W5eyMxvDZZKwE91FKfQ+KxpypQMgcpWOLNQjbC3eAfcCEleKsyc'
        b'zaQBOnBLtY4mukDEW4oLVHwVS3pWMe+JAgg9o5j3RAGknlHMe6IAYs8o5j1RALlnFPOeKIDgM4p5TxRA8hnFvCfSYhnPKuY9kS13wjPX23sqK/hsQPENKYnPBBUfqazg'
        b'M4HFRyor+Exw8ZHKCj4TYHyksoLPBBkfqazgM4HGRyor+Eyw8ZHKCj4TcHyksh3/TMiB1GIbuV++EEjXEiC+NsaXLjEYrYbMiUDiO7EfoEOd2aSjqkXrAl2VBWqtNEAO'
        b's4HyRJ26RgflpAhvrL2CasVcSM5JSyGJYt5OgqyMHmuuE/hhepwHyDjfaAPSaNADB6KzPZX8FB72LNyJyZ9Os5jITauDTeiSks0OdypswJW4pCpGSdSM3/EqAjhG6qDm'
        b'QPqB0lAOuoLxztWUwNsMRpgWm0tNnAOMrs1YYVyoc8f+s5kU6FIfu7MZguzodozoziZNNAiChcFYRpPyYNXouZhV4Gx8M2ruqmHoN7SsM9mrFxqqnHpsRgQZF6cCLq7A'
        b'EuOLg6UWMvd9crA9ZX9kjhEDyc2R1rwCsjWe8bFki9YPdS8T4x3kgGK12IORVTgZWRvXlZFtl7bL2+V6vj2sPUxgaJv9/KX+Afq4BklDYENYhUgv1yvW+wNjKzZI9IH6'
        b'oPVIH6wPaeZnSyHcjYVDWdgPwmEsHM7CMgh3Z+EIFvaHcA8WjmThAAj3ZOFeLCyHcBQL92ZhBe1BBa/vo++7XjY7kPU07Kkff32/5gB/mb9Mr27gHT0W65X6/qzHQcLo'
        b'2gPauQo6Qj/2dJYc0OwP5TTMck7C3DhCoLSffqB+ECsdrI+HNEmDjDl5hLK0wfoh6/1nh0BsN+jZUH009KwbtBKmVzU7/ROCGoIrJPoYfex6GdQS6jjbT+iQjafW3eOK'
        b'pz+JD1C6/XNGKwVcIjgddclxRmKh1pCWQfQgnxl5U++Kx8xUg8oEKsVjamXzmNktUxubzuyWNGd2C7W3sSTSLNTm4TGzCqBwofLrCNDpFwN6spQY9R3+5YAkzDb6GqQT'
        b'BJgSE3B5tqoOWbkd9o+5fFmHjBqqGnUmhz2GvMIIjF1JNezdKtZ2h2jCtCmCwYclAx7lMjdgDHD8MmOdiegp3yj/BmlDQINfRYDDJkjWKKtHK/3r/FfImE2QP7MDkq3y'
        b'L3Z7F0wZv2yDwXeZOfovR+iqsc5gZf5grvk2MpuGcoPGo4hHxHCQPXTVys5pGu7wBAP8QjVBDlczx3zpzDaPGui/6CxACzYnUlJplGNpeUAg5UpmK6i01yoBjaYp9cZK'
        b'o83q2S9HN1wr5L0XQrL3HrjOO36gD8N+qA9dQWO4Mo/9pV2YFJ/nTHV0zOq9L5ToUHQPxEKjnFoFBAB2gEFptZeZDPpKGM9z1SIYkwiSKtSk1EEVEBb6rzTVADGyaJQ5'
        b'NmW1HeSVMoPXWnSOwZcZbEsM9LxXGa03VOjsJpuKOQKm+14Lx5YYrhzneFOWU4VhtOuY0U3RqPJVi3M7DXdCq9W1mNTvsMaijBaMVhaS+5Y6kL59VeSwkxrORC3KlkA1'
        b'Aow4sEu0oVKjHJaYEKdMS0zwWY3bfh6unEgDShag1VUYzbBroI/KZQYddCzGbFhCzzwXp2pSNIkxKs+peg4LY4Xg7fCNNATVGscgVFua5zcnBNmpVyjeXZlJmobh2/n4'
        b'fBFpzCHN2niyqYgamWbnqUhTXIEabyYteZOz8YXsgvz8nHyOWrAfVtQsNrJaX85SoDhbAkJFpaY3FsYg+0iI7Ic3kGukyUudZCvZlAdkFW96utL1UaJlCjSS3GHV+sn9'
        b'UXYfQMClpXlDh01Edopw0/Nq3d2zsvEasUYdQ91f8EUxSp0rtfr1YK5lrIrF0/1QijgSIWVpnlgsQvZREEnWDUnv0jG8Ht92dI40Qr1NcbSDW1TT3fqG71jk+CpeO8W4'
        b'L3ERb10F9bw5a0mfV172X5MQMuG1vFVtH/08KG7sZZH2Mkr77emobrFFPYo3Lv7YKhsh/fng1g1DB64fvOlDU+t6zf2sc+/tIxHLX8spO1Lw67PDq+Rfnv3r3y6N7Vb0'
        b'Wej7Ovtyv5aPdZ/IR0+O+s3G1wZ9k3j4pY5vdr5Q/vk37+0wz3ul6u/fcuWrov/18SaVgllxk6uDbbiJOl0mZDj8RVDwYFFFHrnDTPzJHdKAL+OmQveV5NBosrYXqRfX'
        b'VZJ1NqrTw1tww3g5TKoq32GnO43sRt1xg1iG95N6lmd+lj/U02X1OMtIFNFfLCcXyQHmDED2G3vGqqOz1TyS4r2LevBqrpxZApOjE0KhtEZNHpLDrvUKxRdFpGmihFl8'
        b'ju2OH8ZqVGQzsGhSfB7vxVf55MRuNiWkDScXp+Mm6ipGmlb2d6yPFIUuFuEHsGb3bNGQqf9Mco6O1MG20R46AI+6p25Q4c1SDW7B+20UkPD5HC1umo+vFsK8xGhoZtJM'
        b'WmJpZqVVEkgekOPMYSdyFps/qHCGnWyiTauhYbxLRDbMymJzPHc5ue3WroNdNJMDvfBtMW4aQuoFg8mAf9ORrdPPhVmb0t6j1dIVUo76qwlP6q8mYz5rEMNLITaAq+vm'
        b'JMVP+dsECIam1LfMMoY+xtJHFn2MQ07fmvHo2ZbLMqFUZyVZrlKsEi9eOo+Rww4Ure2724tJq2d/u1g3c45fZk5Ke7YCLUCM+eMKVFyHvKSTfbBEuubOzTtphElXXabX'
        b'jeoGtXwu+KW6telMfeJA6I7anMQ/GgiFXl1jNi1TneE6RPqa8ufqXIXQuYASF1PhrW8W6oEbDuUtOfDypJ/QA6GIlw78mJaDS7qyEj6b7+FqXvVMZuNHd6RS6Ih/iZOW'
        b'++xCL1cXembprAYX8f/RTa53Nunio3012cfV5ECfrMGPbLxKaFxW4nRk89W2srNtn+zEv7foihJ3icFX+wM7V/wHeBAfvejib8B85/gG5PKde15vg+f0nRMVGOsKgsTM'
        b'VXftL3cITk9VFf+q+RS9tuXVLX9Q/FSx/zEadVTc8VaFimdUA18ll2cJuFvA3INxvQt5jyTnmYdJDDk1yBN798L7pzDsbZ/xLGc2vxK6rdw8mNBqtDp8aF2IGypjGYQy'
        b'PZ6uKdK1ILPgMQQm10qj0Fq0NqjDC4r0qFcV0OHn2KCCUb/UarMYDLYOWW2N1UZZ5Q5xudG2rMNPyLOsQ7pYx6RPeTkw7DXVglQqsukqOyQ1APaWcrnbMlAsHuRcCuom'
        b'1CB3SZOBrusCgoTbGiqCHCsvb1TAyitg5eVs5RVsteWrFMVu78JlAV++K/EiU47V660gNFDOV28oo5sQ/pc7zOKUBmbE/xxiJRN6mMSiU1bZKw1ughzMjtUIgpBScHWg'
        b'MpnVYNMoCwHIPeqh2KCaHscYq2trLFT+dBYr15lBqKFFQSCyGMptpmXKsmW0gEclusU6o0lHm2QyADWqtGroSI1UsQZbzVGlQ46idXrUAVXbrUZzJeuRqxplDFu4mOeY'
        b'kYmO0VZRRYhn3z3yR9t0lkpoQ+9ES7S8kqoKrVQmsS6y09kts+jKFxpsVtXw5xf1BZgdrhzbhboo57DD0Xm+itGWhyuZY8OcH3Rv8FmLsEWGK4vZX+Uch7Gdz/zOrTRc'
        b'SRWdsFRMBJ3jbmznsyzdfCC8wlM5p9Bi851P2J6QVXhhbcQpc4oL1cmJqanKOVS56bO0sKdBLB07VZ0zXjnHcWI4L3aOu/OG78Y7UQEVtIWAklbkbjLsszggD5jMKtga'
        b'sF2t5RZjrc1BzCicUq9utrfGmqw1AL8GvVcdAYATzU1Jj4nd+cMWW6McLygK2BYdUGzTVVdTvzfzAJ8qA7YZALCgA7WOraU3sluHdDCtS4xA4gxLYcUdG86zHvqvoMZm'
        b'ELYJ2/wGW1WNHjBJpb0aAA36olsIGxA2jQFmp9ygrAFa77UeYUh00zANiFUYptHq1iWNciIgNSdC8lqL+7aj+hIAdXqnUrkJBixcp2Q1eC9Z6rhRqaac9Vw4SxlRZbPV'
        b'WofHxy9ZskS4FEOjN8TrzSbD0prqeIHtjNfV1sYbYfGXaqps1aaB8c4q4hMTEpKTkhLjxyemJySmpCSkpCenJCYMS0vOGFVa8gPaCUoFPR0JQwvsVI7Kx6fIenwNH7Lm'
        b'qXLVmgLqwheLz4A4OKhYUoXPkkvsQheyLwtfTs6bDK+JKBGvL2ei/t5hwmU7CSX6uLvjJyI75UeqRpGdWidln0waY0lzfq56CnWCnRJNnUpnRFtBfIQXIPm4FV/yJzuq'
        b'5OwEAK/HN/ExfBFvJNdA5qWCoR+SkD28Am8nV9ktTtXhI8g1Db15gzR3J4dIE71NpTkfZN9++ISY3O1F1ggKhwe4JYNcA+k6fxrZVpunsi1wH14RaSyAglu002rhUZiX'
        b'S3aI6T0O6+TkuJFstVOGYNqEcrlGlYvv40N2XQDyz+XJIbwGH7VTS56MAWQDuZYDAuxFqIBDIryLg8RT5CKbVnxn0Sw5aYzXkE05eBc+RJrj8JlckKQbOaScJBGvGMnu'
        b'kcI78f2V5Fp8DIf4fqQtm0slt/uzqS3oKVyDhMItcaN6JSDWaFYifmQNJDvIjRzWKNkols3lJ0Xj7cINV1tnkHs0PTBQgw9JyHZyI49ciSWtItRjmQifJ/vq2DT3T0qW'
        b'a8humMItMHX0GqtmEepO7oiDyR5y0Vh2Yb/EugfyfWX6Rv3z/ACcECJ5Py3nyXtnY09o/+v3fcQP8JqjUf72N81xuPexB2filde+Xvr7xLD67tNHJtzzHzi1Lvp3jZl2'
        b'1YHSPb8ektygnrz6J8kvfPB+yu5PE1+elPfWK28pUk5lqKvGaT82TtDOfv36nSPzRsw59cuvPnliu6et6Yj5bhl556Hm7oFfVT9aP9k8893W5pkTvv5F7Nl/BRemBR+O'
        b'aboXoZIy/QZHmsgdQRHjuNfjcp6giSF38QnbYDolx0l7kDZvmtKbfiI2WQLrd3UEqwzfwmfD5Fp8Et9208gI6pgV8xnX2gOvJwfcWVvK15L95B7jbfFZoVf4YF+8ObaA'
        b'nCPb1Dk5+do40qziUAS5L06ajB8xrQtpqlZp46KzoSNZIBjL8Dl+Gdk3t8uVH0H/7jU8Pt1nA3R6fYnAxzHWeYiDdVZkKzgZF8HRp/uPmN7BA38jubowFwvcWYfAogcK'
        b'SofZyGnXRq8Fscylj3n0MZ8+SuijlD509FGGuqg5vPsBy4U6OyspdTVR5moi0NWiztUO4+z1tAp3zn7Im144e2/DUvl3KPTU3M/BLXUECjywMyjVVbO/9OIUQ4e/45S3'
        b'3NAhpxwL8InUBkzoiWuw5QFu6JhqZUKc6HgKZe8DujD4QcDiBzuY/BDK5FeEOFj8AMbiy4HFD2Asvpyx9QGr5MVu7w4Wv8Xv2Sy+zmXHpxRuVXoORnYCdYAQciuBmsKc'
        b'AY8KHILO/QpBykXEKSstNfZaSAXmWedJnWqqy4xmnZNfiQFWJoYRWoHOUjWAy+KTdtAlGXvURCXl/yeT/P9ZJnHfasPpQgkxLgXYD8gmXfamUF6IclbglUGb8wN2oD6b'
        b'E/a+0I5juzviBB7XXEMVOhbGxZq986ZLaigTaazWmXxwwXOeYQkLsoV3W1ifPaZYSuhvWU3NQtpfGqNR5jugS8fCypqyBbDwIPF7P0o0U5koPTUh0aEjo4AAAh2tbk6n'
        b'lazPTriQ5HDlNKtdZzKxnQGAs7jGWO7ajXPcjGyfKRY6kGzXZWDOd3PcDXF/UHCjxZ8S3rqYe/5fIHtlGZYYKh3GOv9P/vq/QP5KTk1ISk9PSE5OSR6WnJo6LNGr/EX/'
        b'PVsok3gVypTCkfHXfSQovAR4nTGlcY/5kcieDJH+S8hVbU4+2RyXkxdNDjsFLDe5yiVVrcYP/FPmk7tMjOk1PAikqSOzuwpUC6faqRlNOGknm7Wa3HxgaHMcQlsKvu69'
        b'WtxEmvzxqZHknJ0ePJHDZBcgzML8QsfFR7T6GWQb5G8hjUp8CoSrABBGoFaIulM8F+/He/Exf4TPkZ3yAjm5Zqdnfbil10BrLhWQduTkF2rpvVsJYhSZJSJbKmMEueYk'
        b'bsIHrTH5ZGs05d01OfhCNIf6kSv4YqVEgu/g/awmbd8hcnILb50iI83qGXMKQOTiUWiyCB8Zj/fYqY0aaccPyE6YjrX4qNuBNohA+MYUetloIm6SLCVrxwni6LVInvYM'
        b'upVTRerjVPTq0nByTETuzSAX2Up9UMaj/fH0rVQxe3kcYsIyPdHeKZciNJVsmIam6g32YbTt87PIeTmdJpjO7eRWNgidzaSN3Chgt4+dg1CeHG8lW7OpODa3p2xSJtnA'
        b'rjwdRx5mkWuI3hbYMgDl4Ov4sJ1ykKSVrIunoJFonYcSQ0WscXxxZTq9kxXF98TbUbx6nOnr77///o1ICXpnQXcKUYo/z0sRTuptg6VozKye9KTeJB2kRmxVy9PwHjov'
        b'zQ7xPTtuOr0uOT53GkBDNtlSDCJXa7QK4CLbdUWyCt9ksyc1B87L7sncUfwBOrYXkx3JuSKQ0673JedhApbNtGdC2oTEJXJYIbo+U5zgol2JG6bJvMwOvkhaxQgS/Wfh'
        b'9aPt1Mawu9XWKQWbhkyOJjuKZYEad3l3dHdpUBq5w2TxohX4rjVXXZgPI0oK0MYXOCReFdktwddpk8Ktz9f7hsUKl+Go8OUaKZLjRzy5hg+QfexKYC6rkH+h4ow/qtWF'
        b'vR05q+Y9wZKDnF4iItccSo6VgYK1BYAV2RRfmD852lGhu1kDyJCnFGRbJm5jMzVgJt4em4uPaHLiYjgkxS18PL6EdzD9gFSUARsCJH2e7CZ7LVw63kMuqUR2dkPgIRBu'
        b'r8TivUnuJS+QI+yuXVy/fLqjaD4+BCXJTpMwzKNDyCnnOMmN6a5xbq00/q/9VSJrOohNS4dXz9s2skA0VrHhLz1rUvflZ3+tvfrNO2sGHj858ejJcZnX1rVny9Tdfp1H'
        b'Uk6+z8uOfxjxxRu1Q35Xcevonn98uuzJiPKBn7xdO+GlCVffmbhzcMGWoNhfVKm/NH3wxqzUEy/Em2Ypv2xKffz94Evbwj+f96uBe/rPylr+Sy6lIWjGq/n9LlaWHfvw'
        b'44WxeaGPNr/0emCk5K3TmVuVI8d0GO+cfFLQcHqSvC5kZFWfX2n+Nt12/4MXh/t/k2e/PuKz1Ndf2vrlZT6n5TMse7Looxf3HbxycPfCsy+UHlg37OJ7JsXoDbum9e3z'
        b'84rRkopHfqdGDP0iqO9o+2/e8bv1xWt+LS+g4tVRgQ+PRu+OH/5e4cXfzPr2hurL8/9q+WjZhPdX3uq7es9f353wa9PfTn350c63Wt5pm7/q68b5L88vevndsuDMiil3'
        b'T5T90y+0wJw9cYkqkJkv4GZcj/cJmgkjWe9uIzIzzkbl7gy8scqlJAsmxz31EvgwPsr0CUvwvhCnlQg5hk+56SUyyAZmkIIf2uZqmUnONmhNMPMIni4ySXETu4LLjlsm'
        b'xsZoyLlkwdLDfxaPT+ADMpboj2+UxebhzRqK5+MoHG3l1XizzsYu8COHRdq8GCnicYtqHpdGjkXaqDUB3kV2yfG5vPw4Hon7rNZy+Op8cp3dXFlcA3u4Cd/o7zLtkK7g'
        b'h07A620Ul8+fA2No8mb/QSfBKgmcM1m4JrM9rYSeEOIz5NLTp4T0iDBgFpvpkSlLrHRnqSmpYpPcDa+vIdtE+HJpBNO1ZM7Ha7Rx0eRiRDbbDkzZIg56xk1aqpD/JtWL'
        b'NyVMENU0dArfTBEznTIEq5kqhhfUMJ3KmAB2vZmYKWJoSMYHcX0hNRziqNkJzRfCctEcCj6AleTX0LdQrq5HFw1HZ7uC8kYhKFAM9FFBH5X0QS9ttBjpY4FLqeJNb+P3'
        b'PJcrBwh1VrgqNrhqWuBqJ9DVRKcGh35gYLa7BifmpBcNjq/xlUvceC16XN713nVJg18DYgeoXEMA07vIG8Sue9cljdJ6tFJa579CwvQsUqZbkaySFru9eztEpw153rse'
        b'JDB1n5SLgOP7aKYMlZqSzUPRVBabuZSq0JcGi4DV040sRgztjxqFN1txsypKtkiEREGAvG/hvXaKN/A2srmmGDdPJc3T8ieTG0VAIFvxqWmBqQkJCPXpIcJrJ+H7AqI/'
        b'p8DtxaR56rAEsjklgaq3e8gWceRwkInRjxhyQSnUlIG3TwO6JInhgD/bMY3xHOQhuTiR3bN+F9F71uPIdoGuXBoyLQXvJ8fICQChIShyADnL+mxbhtdpNQkptZakYTyS'
        b'ruLwwUF2O/VyXYFvktOAEh8IV5t33mtObvQ3Rv7jT5z1U4oRe71d3TI2V5wYMuFca8Hwx5MnjR0f/H7+iLUX581KHxe7WaRZ/8bPfvfGzZptvX+SOTsneODRpm+e/HPZ'
        b'iinregYkZA/d+lmAeMi1zF0JA46d1Y3b+BdtdlHYr/eiDzRv64/3+0vYpxfDWh+IfxZYlHbs5LQ5b34U9PN+cy/9fMiLa+f+1L9y0Ncrr/dP7ROTM2paTb9XJVNnf7vg'
        b'Z/qSfi/k/nLnKuNrH84K+7ztxV9+dOyrrwpuvho8e+bvflE4eOv33/3+kVX+TvWaeZZ/jl/x8ZC4xqKa8L/XPXrXaDxzO+p2y6dRUW0lb92K37zsgO2/VkwUXdh8p/72'
        b't9KPo0ob+oxVhQo3I+43kSPsUwJ+RbgVUOxRbhq+S44zq7658uGAXycOZBiW4le8Qy5crbl7EZD+JkCcR3G9G4btvpDZ2JEDY0YLCJa0LvVmY7eNHBOIVCu5N8ldey5C'
        b'OnyIac9vLRWuzT6pwK3agjjg81ri8VngwtbgrUH4oajESm4xMrAyJIM0afEGsoFdRi/uy+GjqSNYNzmys4w8ImfcLtVmV2oPzWPJoiGTYjUq1zX22lXsInt8E+8UTBcb'
        b'yCW51mU/uXwBs6CMwBfEUWRjMTM0IZf6kQ3aTtNINb7EMoUuEOHzPFnD9P+mSrP2advEPBh0J5lthemglpbk/nhST81cXaaoUiTG54L7iuaD3HOd3a+PL+CdC7Rutq/4'
        b'CHlICS2+PpyNSgYbaAvT7J+BylzkBp/szmiRLIlcptfvZ3d3XcCPryQg4RLxg33xWuHyzYmjXXeyzsQXGKjMwifmU3aObJ1WU0ivU8Xb+Bp8fNrzIeH/oyv9nUY3wgX+'
        b'jGAddxEsWXwQRckMLdMbxymx4unP92Ke/04m4r+ViflvZBL+Xwop/4T34//Jy/iveX/+H3wA/5VYzn8pVvBfhATyn4uD+L+HBPN/CwnhP+O78f8lDuX/Kg3j/yIN5z+V'
        b'duc/kUXwH/M9+Md8JP8R35P/M9+L/xMfxf+R781/yPfhP+D78n/g+0l/L+4fxEdAIyGU/LmZ7gjdF+ieXyfF6fATFNrWDonVprPYOkSQ78cSOYmllr6bXbSsxkXQGC2j'
        b'l8teoLSsl4OWobXKXz3b0kjo7v+A5VeVSvTkjx66CcG9y+Z0J3HoeE0O1YvFYLNbzCytWqmjRwhumpznUr8rFxqWWaGeWovBSu0rBRWRQ+dlden9Hfoib2rzp48ETIKi'
        b'jXanbJnN4EWl1YU0S90nz81EX1AL3ITN1ER24ha8CV8hrfjqDMC3V/C5ybhRgiLxGtEQsnn5BLyGSdh5i/E60iYJtSKkQRp8s0z4JsRxP3IPiLZsEW6aoSY7tRqNCFjd'
        b'KygcbxLhM0NrGbn/RR5lAlA0LytVPOgehuwUSQ0ge8h+Z1F8YZJaOoDsKMMPQL47moRihknSy/BmO2O7z+ATobGCvDeWbGAi36QF7GwY7yNnyTYg6ORaBuMOHAQ9KI7R'
        b'87Tl5A4gkGp8moqEIA9OWcGkz8I6vL5YyE7a8UMeN3O98f2lxikbT4qt6yHDuP6981/pH4THhGz4/T8qFqseoON9SZ9t7yC5+VfH7V/3bDj9B8U9fz/DuOnvr/p8tZyP'
        b'mhE+fe7f0n83OPLqkcbXXpg17I03vlzzy+YJBzTTel/sMaJh8clVB9/eM2D51ZT+Vf987zPTPf/Bbxf9tu77P/X75Irlr3/teGePfMTqryveLNwa9bM3e8RLBp/75zbH'
        b'ZxyKC8OfOn0ld3nBsFBjEA5WW+cBFXDcQwyS02Z6D3FgjiCybMdHcWushpxS5/NAbE9zWgk5L5DUR90TgCgIH/TgEbkwWm7gyWHcMkyw5z9Ddpk8zBXTkUMUUeLzjDoM'
        b'IofJ7VgN3lel6vp5Fnx8gUr6AyjEh6mjzlpCtxrDugNcWFdsChVRq/NQLlRE8a2C/Ui/jZSIeTck4ij8g2aQFnh82BU9Be17Jnpy1HyG6xDX6mxVvm9tH4UcF2LT80z6'
        b'kQep6+Z28XPd3A7o6vcizstZZifGosjDqltM30wmd9z1/E5wdBDDlTkVyhj6FqME5GsVtOYUKxmWUkdbqkSO0dQZa2PiWEMO9GjxroO20rsE9S7Nt85SXmVcbNAoC6mi'
        b'fonRanChQFYHGwDLrlNW1JgA9f8APqML5++Bz2SOjxq0rcRNsdmwSYqygZHJzQcxemo2vkAa4zTAWWTj05PIRr9afJlcZLfXQ8rFMC3sqtx8DdkErN5U0kg/cAUSszoa'
        b'nxEjLTmymtz0wztHrRCQzVqynlwibfhcNOVnoA6RicPrFuBtglnLRlIPWQ6QdbEACUvRUtgNV+307L4vbilNmRNbyCNuCiJ7dfiGMbJ1jdh6C9KMF1Uj8xMD+LGKvKvL'
        b'65bUffWbr9bFX75y9fKVkLH31OPHpxde/m31O0MOlLz43RufBiSJW/e8otgXK7ua/3XVoQ8T/hCVYT1Za00tW73v7FTu8zdyz4q5t/4zeu2WA5Ptr+79fdy4FG5k9oFS'
        b'0Z+/Gr923d+im4fWhPb/QvugQywL+qpo75CM1W8teD2lRrb6+z/8uTJmdZ85hZvmdn/8uuSTC6+kFH8fvNfQ/TXlO590V9zadbXnpAOrdu3b+3KPV/3SI6oLVcHsAnRA'
        b'vDd6xmZLZ8VR3lKcxuGL+eUO7cw4co4yssL33hDZPlFGmviV3fAplj6qRyi5Rq4vcVic+MO8NeNTPD4WncWQmgXkp0us/KY4XlmDpAV8b3J7nsCib6Pa9CZI0eTQZJCs'
        b'rq8kl3lyfyq5KrTegvfjA9o4vLVQ+G6BfNWsMTzZvZzsYLVPwg/xdVpDfKGa1ywFyY2PwVeDBEenbYvw9tA4yniqNKSFjSw4QVSJH1azssUikEcd2FaJH7Bb3/Gpvqzs'
        b'IrxVOY7cio2nBxZqjYoHXHhIhDfY8GbG0eLj5PhYxr7HF0jwQdyApCP4HhUFAjN8dwbZrnUBLD4u9w/n8ZHRFgHL3wRaSSUgNiNcDyTN4iNRGEPlBnyA3GSfuGod5sZk'
        b'q8hB1moevp4pdEmCb5F7SIpP83H4YOaz1EE/gLrd0LWY7mKGq+NcuBqtVvhThY6M+QopuBD2pOqZEKbm6f09v0b8fV2gC7fSOoTr6x3fM7ChLmoX3z09wwt5O6+0XwyP'
        b'7ylm7+3C7GhtxPfevnDQpX2Vwzt7AqJ+/S6XZ8Avjn8qifCHh9+wp+63ogb6+prykhLmgNQhq7XU1BostmXP4/xELfKZ8Q7T/zDGmZEnNhKBeQ//b9fOPXNRLSnw+AA5'
        b'Pt1FLy8IEIOk8z0Psxf+PT9YCvQX5lD04/4GiRWiAEctEd8r4kPou6j3970mB6XJonpx7OQuMyfQqq6gH5O0BgWJUGAfnhwBTLHNTuVVHbk0Us6PxadtFK3I6VlMET2D'
        b'6Z0kHmgj9f9ffW/J8wzTr4Bh+vHkAjlOXWX6k41kA+ofImOUAwhLPW7DJ4K0Gnw5YRhUQG5yi/A9vI7piuDlKL7AFEVz8H03XVEO3s/KL8rWk6acOMpeJYsRacCtMtzE'
        b'5+LTEca5F95DVgqx7++4ffDxJ6Vzf3J525G2xA2LuHK/D/iTGxTynplj4/4UfjL8TxvySlO1AfKZ7UeyL9YnbjhSf2RHTis3KIx9EqNK2m3k/i9VEse3vcg+fCQf33Lz'
        b'kuSTs8galpqr07l/Tg/vJjsA2YyERWEo7qaINOI9wLC7q9YXxQnf02giFyYKIj0V6Ed0YyI92YHPCizpDdJaTo97WSo5iR/K5vEGyqI/yzVGAfIVcDSGEmr/wBBRhBsi'
        b'kg0K4unnMsSAdsScZblrS4k7xLRAh9ThrubxsSd6/ZxlhWtL0JL9+afQStC7Xr6WRyE1rl9ZLNkVGZ2rzo7Lxc3xwumtkuyUhAOMtHqAVIjjr3U473axxwh6pQXALK8X'
        b'rfefLTKI2TfyEP06XjM/WwJhGQv7s7AUwgEsLGdhPwgrWDiQhWUQDmLhYBb2h3AIC3dj4QBozQ9aC9WH0e/r6UfCfuH03fUR0LbCkdZDH0kv8dCPYmm99FGQFkRDwOpS'
        b'zxyxvre+D8QF60dDnBhK9NMr6VUb7QHtfLuoQtQubpfQH33PCh7i6F+R668QKzzFQg63p/jpd33//cFGpB/QLmnj9APbA+A5yFkXvA8W8sLbENfbUNdbtF4FzxhXONb1'
        b'Fud6U7veNK63eNdbgust0fWW5HpLdr65j0Gfsp8/wemH7edndzOEGrrpU3uiw2FHUD3HQmnOEMsRzswjBd8nGcytnz5dnwGz350ZTvqx+Zboh+szIS5C35O5I47p8C8B'
        b'qqabCEw2c0/3OBToKqYIJphS9iVFqesoQPJcRwEen2Cl/zz96QKEo4CPssRVrXwIPY3PMyq6C6fxyZbm3j1FCTwqKjX3KnBEnkQru7+KPpOgBN3yA1qx8A3aNCPZ38Uh'
        b'nwqm+B656hJO6QmcHyqulIWYSbtgqm8eOPwbrhHeSgfE9JyM/uzs5Of0Ydw63Cq20lOZcW0X+mwZG7AmQSFOMy740i/g2x3Bn4UWfXThCd8Usrr6Y0NFj53Dkn5b+tOy'
        b'TzaNOPKavH7KTzPu3cl+9a9FWa/2OJdy96X3Pyk9/8uvP/vVvqrKbzI+ej9v71ffDY+Znve//Nrie/7yXsBFu8qfMXEzSItC+JqQWoRkU8nF7rxtAD7O0Gq8nVzETfgS'
        b'O14EindeOpTvBkNcz3jevqr4Ll7z9CwURJlGsSweb2U68HyyDp97WmCnc0L2zPFDg3tKqqIEHXIk2TdWcHGPjVYLuWDeevTG+8lx8YiiOkH8363Ex4XPrd3D13OA0aca'
        b'dUD43cg+ET5CWgsEx8cz+HQfIdvZxSxXPj6PINMOET5GThcKn3Ddi9fNY/rn+ByyhUMyIB43ZvB4/WB81MZEt5NRg3DTEpgWRtehHvq1YdxSCBk3FZKtGinK0ErxTnzK'
        b'gbufmzvtdGbv60YTpEkBnEwSyZzanapc+lFA1855yo9dUJ12SJgFVYeYGuB2KDrP3cw1Hf5Gc63dxq4R62Ra3S3bJZZ6+r6WPqiGSeBX13XpZ/zT1CXiF94+IOfZyx/j'
        b'HS0pod336ao7FoLMVde9HZfHeu/Om1A9HHY1Fi1FNz/CeTiwxH0OfXZpvLNLT/q6Ne/prK75cX7ynSvmq+FJrob75DgzOy1Af3S7VU5PcQpEJdVG397aua5mI6h8oqyw'
        b'1FT/+PYqu7anW+qzvXxXe+GsPWof/G+2Ji2x1dh0Jp9NFbma6jmVZnTaEfts73/Q8ZtHnl9CZFRj13KmrkYJEdUrXhlTJdCkftGOL7SntqMhC0uRceGvj0qsVI8e+uEp'
        b'+vnebF27Prqi8D/+rlNUfFT6Efr7vp7Fu1/oua5n+utc6UDJB6NDVZyN5tf2zHgK17nwHH6ITzlx3YyFz+B5mcjo+kqgE60FTKdfv63r5o4gnt8nvNiDtz3n7eoMj8of'
        b'fw///gckL6/chafk5Vg0k0GC9s+mBwtrTDOD9lSwibnV6yKtgfvFS4iLHG382elIsZXe39Lv0Hfsi8ul2/Qzf7Ib78bXt50RvXJLRz8t+b/s7+f5oQUPpOuMg1W8jZre'
        b'AcNxaaXXNZtMTrmRJ/9M4YT73EAJ1S3F4HUT1RoqAK3jk/GeymfJMMElzCTaWGcoKTPVlC90fe3Puba959b1dJv6rrm7fLpWwmx5PcWZNtRFS9IKj5keS+7N3MR3u122'
        b'qnPVKZg5P2UrgnUX/Xd8ttTbKRZb99Cgf3CXp3T4AQO52hKfJ9ii4t1Tx+NzkLXOjO+iunHjWew4vI4cwOdgzMvn2NHysensHIqsnTDXja8sJneZaezU6AI1h1LwJmkQ'
        b'bh3MzEnfGypB7yvDGAP7+rIExAwk3xtasEInaQwUDCTHR6UiO1UakU34ntx59xOutzhMJQVDSQdT0+XWpyNkTwDZq5xlWQOlmdA/dkCSm9BPBf65pDkX38T3jOPGjOes'
        b'DZAnpWL/4FcTg3BCuKjoX0ONjyVj/qLeHVm6Pizh2kr/TXn5w0/K51m2fHjyuu2afnTGB1vfLJ+YZZr0Ut7M01+k9g0LmBrzwbbDP9s3um9C3tR7n738Sly/yW9eenve'
        b'/st7at/d++u0+XhZUsd3b04xSa7s+cMXRXcq7UHfPpnT6y8x8Qm3deH/Efbuv/zspP+GklUqP8bn9QknRx1q0y240V11eiyEMbEqshNvp2zsvMynnA3JpXkMOU7ykwMP'
        b'fGC5d/zo3GhlZBvzTSwdR5rkMQ5e11VhP3xNTA7JyaWSscL23R4JHCi1DqGs7rnJdJ3xeRDKndVKUQI+K+3dR8P48GiQMxocjoqCKQO+pFyWg++yzT11MG7tVGBQ9cUo'
        b'crJmdrXK9elwn4pSackSi9HxcVel29aWlYg5nusL3GgvhwWcAt7EX9WFuG08VrTrJ6p1lkqrD26Tt+zoutvb4TH36d0ectTbedfTjRaUi902Y5cjZcfniZkTn+vzxGJ2'
        b'yCWBfS5m+1zC9rZ4laTY7d0XUZZ47HNpATvKxQ/weXwWt03HIIOgfqhfeD8m3rLz3Dx8cXbsZPV0NTVP8VtW1I3vi+/gB8bEczliK70p8+fpI6lqbBt+66fv/PTytjtt'
        b'dw72rb+zO3ODanf/DXfqz9RnNOds6b97bbIIncuXTflkMdBqqsUZqsVtILhQ5Q0GSGniF9LPxHIoqkqMG+OGO9fj2QpyaQnz6mDrHuK27kEmMdNKdZlyllXQhEvdTATZ'
        b'F6aZQqorXj8jFmKfysnWfCc8jE+vudcv/Xp0wPeSj0HMkhA1SJkKgi6833/HwnuqDSQFwgJTZd5M3LKymDSNpUu8k0Mico/Ln6cybuo4KbJSjfrE7058UqrVRRuiy7QC'
        b'/1X6SamxIuZP/1X6uN5UurDiU/0npfzmhNRk+9UTCfbLiy+fSNyUKE6urUBo0U3Fn3KaO7nV57J+6fJ9capGdFvjcPe9bRHMg6iFal13t2nuLCNUtcs3JO12rSj1T695'
        b'ekUjW7ysqPemHtNDBt9rO0LYzhLHhpb8yHX1yrB5bmjnulJcO2N5abF6OtlBjuL25GwRkvhxQKQ3kOPG/VeXi6zUzWPJa/M+Kc1hSysPoIubrfu4VKP7qPRTWOBPS0N0'
        b'VRV55aHlsor380To1Ha/L2Lfhc3LDifv4AZcTw25++CHiJ/HpSnImuf/onBHUInjQlW3tXVnt2V1YuomHuk21V0KOFUVXfdmh7RCV26rsfjA3GLLfl/7eR+djadXP7zB'
        b'y+r77JIqWLBH7jRPppbJHYGdcvhCw7KOwMU19vIqg4UVSewaTOqQl9NLagz007CJ7oGkDpneaBVul6FWzh2SxTobvYfYYLeB9Envy6VbtUNhWFpepaO3udKo2SwnNYhK'
        b'7Ahw3g5j1Ls5089hOWxGm8mgkrETOQulOxbqVOPtfuSCDhn9sgitskNO35xO7CyaXVTF2kuyHKM1+1FfyrKapczfvkNSW1VjNnSIKnRLOySGavplXL5DbISSHaIyYzkE'
        b'/MaOG1c4rWBqh3hc4ZQJFuqhZLmOnlJ80KWk60tPBhmCctyJLGUm2FyDrEL2I7lijy+lixzVd91c5QJXvEK5gvuaR0unDdNF8ciCmBVzWOY4vD3LSm4GAzzx5CQXk50u'
        b'GDY0GcZZbYshgdzARxRyDvmRvXwQ3h/AeFkbOewfS20/L0Rn52ty8ieTxgJ8IY60xOdOzu5hisuNB+YWmDCnQxRpm6MYh6+QG+xIrDvejDeTtskx9PykDuVPiBLo+bqV'
        b'BckpCbhhkhhxQxFuUyxg7l3Z5HhhMr8QX0QoGSUnVAsWYPXkJG6G7GRTOo+4aITbyfbhzOAb354e6jR2Ba4wlkPy2Ty5iC/jRsYapJI2fJKW3I9vSBGnQngHMKEn2bil'
        b'5OZ40kRvSxkmxmfIAyQhVzjSNgKvZ5N4vyIGTUVI+afupQMeKrMEK/WsJNwC1enwIw5xMfQuk7PkKHOcIy35g7Ua+Wi1hnoO5qvJ5jwO9cDHxWPIEdzEaszprURjgJqt'
        b'XV7aWzGvD3IMDq+dR6diLzklQlwcSC9BeLNQZT2+XRZLGsl9vDZekyPwnMG4WVQGYsBGVuWCMREoDkSSsf1L51bSK3FZlcdx2wha5SPc7oc4NcJ7SOskdrw6B58iuwvw'
        b'XmBg6TeTkDiOw3eDyQVWWULyKLQCoaL1aaWWioi5wojx8WxyLTkFX44YBrKYBuG9CbjFLlgzDCfXqEEzDHZPTw75J/IgS182sLpeHJqLgOuUtfUozT2XO0eoKwK346u0'
        b'rkULYNnjqf1em5jVRe7OxVsFG7ccSd+ZIDRv5AeSa0Jd00vYlTtj8seUmrYuzxHq0gXTlUiFFgFj0mnbQTavZuep08eRW9rcVfgitWsmW7XMKC0IrxeNGrOI1TepOB3V'
        b'IlSbZCi19IvrJWwPcr43aYUKJ+D1PBvnrvTpzMgR18dGaOk1Nk0FTt06J8W3US/cLgbg3jObdWcsvmym3blM1knZ0Hbj+lJG5BIWWrS58/qzCoQlDKoVpeMzWtaXl5LD'
        b'ECCw9C+lpb338VZhAcmFuNzkpARST3ZL2dh2kn2kgdVWB5thjQNq+UogmeQqR9rxFj/Wi5GVZF/ysARyDB+GSUmCghnkDNsIUWRrWqyWmhByZCM5i6RGvuc42Ah0j+Lr'
        b'tQHJaQm5sVAmHXqum8HmkRyKwldj6YU+OWTzRACqSwgpRohC8Hp8gU1ZD7IjC8pF4aMwY8MBMshFg1DyAW4gd7XCZKlw62hqSK8IEXXHx4VLlB4N9adHntlrFpaaFpdN'
        b'd3iAkAeW5LSURNZ3qG4PrGCDsMs3Av+/ke4EECu1klTyCEnL+SgY5hFWsgxfmQYlCUwTwFUm7UlDAsMzNlWgVovPZxHgnfgabkxvfJqV6AciajsUicZroe8jABJT8AM2'
        b'931je2gpQttCtnA5C5E0jPfHZ5JZr0PsdegL2B8zwksXS/pHIQFyG8kFfABfS0ghl0dJEJeF8CFAC21C4s6ccryLGgzl5dLTExF5yOF9Q2SsuuaMSWgLCJxVqtIFRdHx'
        b'wiSQU+SaldV2qQ7QwTiEDw8yCUBxGZ/K0wJaSSKXpIifz8XjRnyf1XRtQCRKgJp+Ul664l8jRgo1LZsBItOJZC2I0hIkFnP4ELk9m633IHKG7CVtkkh8hZnzzuSYiyne'
        b'OYFcZf5tU7JBMFZPxy1knWAURxrz4wD/wNYJ9YsqmyUscgO5AKvhdJsNI5vp0c5uHu9Ymtp5M/auJYI2dX5QqalbfIqgoOkbgS+RNumsHATIKw5vETM/n2RyiyoQbiU+'
        b'dYQF1EaMBuOzEjs+ClQlkoHKIXKYNE2mbj5i0oAvIHEoN2+cmk2Uhqwna7RTSfMqA0ADrDy5PBTIATNYPjAqUDsVb+/q/A1UY3ChxIjvk7sCyru6ZADZJycH9NSQDf7j'
        b'i/gwc6sle0hDRCx+MBMmJZ9szVbnMueFnEQxGjJVkoT3pbJB52VFoRSEql7rUbri0JzZDkR6aDzs3H1+ZNMAan0L/6vIOVbrcHKQnIr1I7uerpVHQ6ZJksnugWwLk/Wj'
        b'8WbtZDW+Bnw7R52LH0DBGyytPzlOHuET+EIx0OdmoO/Lud7dcYNADs7Nwue100izqZTOxwlEruONK4XxXMKXFzod7J2zfhof51A/3CQmN5c4cOORiB5kX+BweraH78P/'
        b'QaTeroSEmeT+XLrNNTkFUDJHnSTG9yFTFN4rNgHcX2EDX0EekpNkn6iY3KeCPPwfivcIqPUo3jCpS3kelrgVyu8TV+MT5CJrfR5ZV0qaqD0IcAVGZCSb8TmGFuy4kZzR'
        b'kk0ZA+JcCxkcJlqAb05km78Qb4O1axNV461MZ4A3VrJek0cT+scKF5UBgAm2GQQoZW98Q0w2l9ayTdIvegTZJ1kaR+1z4H8FbmKDWYxPkqOkiQfcfA6hhWghvkO2C0jq'
        b'bi1pD8bXtWp1Dj4fnUu3XdgYEWkfH+Ugfm2Qd59ChvdQlAv/8ZUIYSftwnsMWg2+VdXpZcM8bC6RrWwgg42LrYGBC6WAqmATkgtT8FYGZ22lAQhmKGRneKnptxE8Yh2f'
        b'1wMfI02iSqDkNagG3yRH2KCHkBOkFZi4bOpsv0VbqIYOjpZKkDJKTC4PIOuYOnNx+CDul7B33x8xxfzu0nNjiGP924H+bMLnxPjUQMrF1U3Gu4y454uc9R/A9vYq7T7v'
        b'V7NqXh8T4vfZb+2fDqpuu31k/d3eR975x6+z1u7cmTXnr9fembE0cm37/fGT+x7oMeD4yqxvZb+r+Y833xcp//aPpQtnjRj/0jcDU0ZkHvx0i//dF86e8jP85tuA5QN7'
        b'xXwwtONXM/cc/uQ/wl+La556XvoX3Sbtp0NXnT+/4Pf/DO4etnD/t9XrBv3k1Cvcrgs7S7ofa/7Fr2XLCoaEFE58ofg3bbc3/mPqbXP3tP3rB7y+7WTbyAHJ2x4UzB7w'
        b'L+W1ggHbM15cNdRvfFBWUIaxqbdm6sEeGXzGxx/ufnHRi+aGoeMLIoaPGGy5W/TnLS/OejFj6J8naMI/nht+Z+q2lwfMUMoLIiZczLqYMSv0TtAd3cjMY43GfVsa5tzv'
        b'uV3V8uX7Lf2LW5dvTFj0+amt0Wf+fnVa+bdNU0qOfGpcwr++/9Nl9Y+Ian5OZcPtm8ek02YET24JeXPJBwWB0xte+WPPL+f7L8r8xemoTwPey60ckVvZ+7MFf/jgXreF'
        b'89sWyO/fP/akaUXmb95a98X35+dI3vsw81f/qKu7ueGV7yIu/X3eleZXioZ+mJ9xbUPm7aG3Qv++crvfns/I+V36vf1OZL7UcgK3ZW041fp93CHri7+YMP/DX72/a8Db'
        b'qW+/sa0k55vh793d9t43t/wDV8X+XTP68/l/CP7mtQXffWgZ1bTyp2eC6r59MnL8zSkfnRv/bsX5XdnFp/YU3Hjyl36fvvyk/6qlqjDm3ByFN63CTVq9p+GBYHVANqQw'
        b'3z7clAokvEA9lFzjEI/3cvlBg5icnhicnBsJvBHIFFIkHs/hB+RIb6bfzVgKW70puFZhAYzVHLw40F9KrpA1KBwfEtWQu+Sa4KC2Y0X2ZKscn4nLdqqAu5G7InyBnCsT'
        b'7A+2k0sK4ASPuputcfgKPoYPCDXcKhqAm+KZiSx5RK4Ct0mO8bgJeOVWwSZ4Iz63jKmQKVrGl3A7kLp8Xr8K72JDCMUbDbCjyE28B8a2mBuLD5Bmpk3Gd8l2fMhpDIcb'
        b'hgr2cPPVrBy5FpM2dJnTpZw6PJLm+SylR0g3pzHIRMB91BYkOpP1RVs3Sq7FB2Z5XNjXd5LgRH4XN+OteFOgYGjytOUGXrOKWW70Dyen8PmazkxuhhuAqHbahtKlIVfL'
        b'qKkIPb6gAg21pz6wVJgFDsVmSEAOOYLrGRwAM3ZmtbuylGWCubomqEvLyQPBBXMj3rUilh4RXH/aZeT0SDbCHv5lLmsRfKKOGYzwwHQewJe8fR7gR1u3doh0ekGdsxQe'
        b'TnUOWh2qieDEXChzPaeO5NSbzvXDh3IePxAn+ziozyDHjYEB7Jeq8HvxSi6IpVPLZ5o3hJbnQ7hweOc52aehEXWBnVoa6I+7bt9CVXI/1h+PF0p16vxvwOMs7zR9Wev8'
        b'6fW6N0voLn3xfQTPVITCB7JQg8SlIuSYFuO5/PA8z/aU6GktxlBBi8HVwaYo2g+Nl+btlqiRoDdkjtpb8PFuuA2GGY5P9UV9rSCQsP10XE9ZbwaN5E5P1JM04fNMr1CM'
        b't/RPhgZK45NQEr5ZLHz4pZ8MhYRHSOmHXwrH9ELsmM9eCpG2mxKIjLOPGyNwsb/vtZL7eso6ETVJuxMV62DVG8ZUJoOoszNFTLEQKodGtwgphwDR7E4Gcn8pRUovjkCG'
        b'unFCk5wfUiSUS5GyNM5vaJRQu9y/G1KGTxOh2lLFju4RQj/6ToPIEbU8RMbFh08ScqbNCESRIb/gUFFpHj9hhZAzqxAild+J6WdxZNK+Qs5STo7Cl/5OgkJK4waP1wo5'
        b'J0yAyPGpiEaem7lQiOxWKUWKuGCOfrvmZO5AQTMLcuzxqmKyKY2yk9MoAy5ZzOG7q4MFUeQOSFjbkhMSxHhvX8QNolfarqti7dbqBqLxVcfoVA8YmtJfYEmmrpzAzmNB'
        b'vGgH7mEAOcjYCq4HuU/2BVDOtg++ifDNaLJBcLi/GwbYSkpvdx2NbwF+LiePWEUT0zNJGwANPonr1UhNHnZjjR6Ui5EsvJ6nR7NfTVQi4S6A3UvNpA0fmkp20B8QzchG'
        b'hG9QWVKQeql0swXT6iI1fVAfNEqwxj5P1iwBuNn+v5v7ErimjrX9k5MQAoRFRFTUEhUUEJBFEMEFZFF2FETrBoEEiIbFLCJa9wURBRVcUHEX9xYFFRG1nam93W69tb3f'
        b'temqrV1uW1ut2qqtfrOchAQSxLb/3/8jPybnnMyZec+cWd6ZeZ/3sTbZfE1A/WAFefiX0OxpVTrea0oF5SjRTTxneMGHzGuGwPMyjP4BzZEYAHSSWoUvzgFHwXEsUb22'
        b'jEHdvR3Nv3zcQrIdDWucFjGLlsLLZPOXvJP7hWgMculB9prX58XShefdV6W48fRv5TG8NccVUcfu89TY3+cX371duCk5BQY4rR4z/9qQ5KXXQuNtbp271adk3W7mnmCy'
        b'T5qLTWbjuo0q9rpuwv5hVfB1G8Xq69d/Gbsob/eYXlOOefwr0/WFr+IyfHruCDm4Na3ki6BJdQdm3RPvc7zj/8GjTMfPMnsN++2h28oE3YzFgkMfvsBG7xua+XhXyFcn'
        b'Jm07dJrXFNgU/86u1sz4pOiGD/hu094+E/D4g/tbD+x7QVrkdXnlD78NnvDl1nEDfs6PeWj3/Ru3BPu0b/2xXfR65pXMo76fzPWYtdrR925q/9di51w8qnz78pCSmY8f'
        b'7ZFW9PRwTIxeuCY9Os75cuTVqDU73hTpLn+3M35V8OzcPJvUGJessKulLUfObKoo+GXQzBcyX034z6WH9/6Z4qj54IfvPx/Ta+HyYRE9M/9zc4py1dKn/F/vLPlxX7N3'
        b'Hw1Bfm3BWCP0Pi95db3PDLaMJYO4rSfYDSuR3g7XIwXGBw9IZ1iwdcBcsiU8fT6ahlT6IfXaWLnoISHj+JDYJFA5391g8slqRnMsR6FgPWwDlZEz0dCLJ6PYpTNG8kfx'
        b'0WyzTkpxTKvhKjTwHU/oP5Sg9Ct4GKo0CI3QzcTmkw82B5kz+bRmwLoBWPmKBRXkCSLAcoBUKZR0avwwvAzxMg/sRZrJSvJrDwd4DFuswKokn3aLlZ3wJPXtWw+Pj0PK'
        b'yIFxem4nsrTpOk3QDzYFE0UNrgDbhNhjQLyBtgkvNDHOnnxwAhXbKmL92g9Uz8JKDWhZShQeYuBa70UdG9SDy6jAK19cYE5piY6kelp1LGgy9qDgCBrCseYAt8UQUd0D'
        b'+EiKtXClGaXG1oVmtBE2Yp4luAfUDJ/o6++P17GRpPAoH9bA1ZOpLtOIpmQvo0irke7YyVBWMBqeiaKmPvVFzqBy+igUpyrRihGwPFRRzoFlFAlRa5uROGe8ibFAMTi5'
        b'lFBIFSancyYJYaAx0ZJJgqaAKrBNoKkElVxNINVRDfrpbvAK0dPyHRehs6NI5TVR1Uz0tApYS30+rEYd33EUvQWsMDbJRRoWGr8uUwDIdlDdYxjc1dfH39h5UlO23syh'
        b'WxtoAmzVR/SsPBM9S6wS8MQs8ZiA9CGsZbmgjyv69EEffO6AQpb8s0Rfcqb+FdBHcEvYX/CV7QARa8uzZV14oqe2fGwwIWIx3gxpMg7tmgzO3sj0rQuZ2y3hzqLgdmel'
        b'ycXcJmuHrFDZYAUFfW0iXynoaAc+6t0BK0aMfVULcUAMgIllMDYK1on0xqH6I7wNRU0qCUgMG20RWw6yuU/2g8m2oE6clRY1OSo5K+PFtNh0HV8t1+gE2PuAzo77IT02'
        b'I51ohOQJqbL51z1kqDA9nS8urhYG73g58dkez4sJc7BC//YuQieRyJq+YyExghF2+AjusD0EnI8NWyMfGyIh+0hgzT4UidjfRDbsryJb9oHIjr0vErP3RPbsLyIH9q7I'
        b'kb0jcmJ/FvVgfxI6o9R+FN528HFA+fex6hNDtIVeU52NTfyQ3pQxtpA/HR4DNZ02tfXENerIjiy8glpHwk7rqP+WsYYj/gZrG4HMAynPGLrhmCeQWctEBkZeG5ktAe6I'
        b'OUZee3LuQM4xI68jOXci5yLC2GtLGHvFHCNvT3LuQs5tCWOvLWHsFXOMvL3JeR9yLq4VyDyxXLK+u9haIYbmzLGXufVl9jpg8Al33k9/3hv9H+RV8WRDOFS7NfEiZVfu'
        b'WO6UZ0N4fQnPLvrNhrDmCgjoRzTdCZeHbOAGXjmdNIjL7dGUYZBsMGHU7SHrT+yih3KMuokpsY+2mgDAM/Qsr+gnSqcr8cJcKJjvSlokw01E0ZGM0+TEJwPj0DmKK3RU'
        b'nKMuVmJSbgyfx36LKa0o9pssL9FQ190ES9/BnbQKW7F6W+tsOK42zGrEHZJ9ZhF1pYr5jWR583X8uUXoWqFcptAWomuiEiR5abFKpmrn9DVLpmvqr0vvHd0GTbZsuc1j'
        b'O4O/ru7S6eZ782/c6TadLi7oP02n+2w23U7MuWbdCPxJNl2jF2KQA/tX70IK9LMlGYokUmVJgdTPnCijJLkFKMtc4sW8a3Lfrrl9zfD4PkeJPJPbF9VF6vA5Ji5TopTm'
        b'YDZ5dGjsQ9vbv4N3akpNZ1YKU9FJ2XoFGRWFGeE5QVB7eAazsCUWYfN+JiwxC3eTRdhsou3Mwn+BRVjf5mmx0zOJQsa9sOBnvTB9R8F5+ebOJCp5vkKNShh1UKgfI9XJ'
        b'V6LlXpu2CHvb/lNkvY50neVfBT3wIkxYgNCVL81N4Mh6a+HxaGP22jFgb0e2XqRmmtDqro4UO4H9YANJ1U/bi/HCPDkpqWFZC1hGi5HwzmCTD5rzrzLL12tIlRDYGCe8'
        b'p0QMD5aAFsq1K7NnkMLmFeCqDm8KSaYswD4Q+2PrigWYsviiNJeAdZzRdQtYawf29eCTZO/yOYSH8JfUm9lJDHEVjaJcQPM0c+nGD0vnRJwLGkhyy2C1DZpb7oAnSIK3'
        b'vUR4jzsgIK7GK8Q/jsqZVAoOm0sOrm2fBFIx0aSy2SDnWTtwIHgmSfaaP9nzEQW4bpT6aR0YLbaGyoFVbuaS9dLPcLg0K+25JFvBcTu4Fuzur2h5r0GgXo/SaN2Y7/fu'
        b'BXs2Shw7adGT2WuPLHPzWu4qEo081Tz9TadeARXvLEspy00uqH+srPQ88F59cubpnLuvHvo96ZUPdoZonjTa2xW1hID3Gr8KfSC9fWBkj+Q4dVR6W8XcTZ/fG7xg/tWf'
        b'bS+DnYvW9Hqa8c3h/3r696otra3cVrhkzu1p3/MuvVYNf5Xu1wz+6Mm270OfhF/3tiXzX1fYVtJOKTwpwDDxLE0mEyMR2G/fDos8Xtq+GD5oHlkMtwPLwJr2FGjVsmKW'
        b'KNzhdgF8JREepGjHvbASVBhIh49kmExg4SnYTLwpwfVsBAeJV71EQfHeoJwi21vQzO0AqF6IF9TbZ9hn4AHqvaPWq+coDM80nin2CSGTZ9Dil4J/wBUA1eEGk5UAuAvs'
        b'JdM2d1gOVoJKPGWFW0C9ybQVnIjV+BP5wArsaRarsX6wCZ5Vk1UNdJaElVp7VbyfkEkGq6xBvQRu+9smAQaMJfYa0T7NY5Y6jHfgMJZ6ymBbjjjY+MxAIIyUD/MEwq/i'
        b'4DUcABxAHLyOgys4eINhns2sI+pOIvYmj+TN1xvqL2//SMytnncW/3lAc7ZZBv3JInBuCpKFwjLb8zLiEcaXuuAR7j4yM19P62qkTFkUappeqEcvdJCAqAZ/mr2XU5ws'
        b'5jvDkK87zfev8RdzHL6CLKQuWcxztiHPfjRPI5Xqz1HnCrKQVmQxP6khP692vUnaEf76FziS9ZqKRQlkBgnc8DKHkTLzp0mSDfMgS3nmm+SJStmgAhnl6c1SBDVZNjHY'
        b'36bk8o1EwXbtuA0TA9wEFJANK+ykguVmr7bE/7E4T2ywcrfqlpU7mk/dt3LuNs+UHFNsdpdmikR+HpYpY1apTklilikDyNnHV+JjjLZG5wTAjSIZc+QQ9ZaKgalHuj8F'
        b'NGQULkkvLsQTCTrrxg7kOMi0NKdYq+HIm9RIZbVUNvgPE6XIcZHIFHmERkfDqeSmD8WVN3GMiYotn3OPZ0Ybxn/xBtonaVezu8BQozmNxEvPLWN5dmNcrlRz79RQJV5R'
        b'OSp5bkERprXhpnrESZ5ZQdvrgVqtyC8iVYGSx3RiMFNLFMZPpUCznnwLDDX62UwgecmhowyTGpxToLcvXifRsyDjGAYa5FxL8zBSKxXkfkykhcsubFT3ibjyTB8IP7VC'
        b'rv77aLS8MG0UIbzylvj4FOKZNnqcMh+fP02sJfEiJFp+lIvqeZLugkSrW/c/L6WVxAIVlyVKK//uiWGCDOmS2MrLQGwV6C2ZERhkmZjKGF3CvUatnD6OoogIStjqY5KT'
        b'X3wRP5k5R7n4r0RaVkjc7MpVeJjyJax1hgmykUBBXQvUJduW6XIJbS3D9S3FrFhUGTLm6ELZBwdYplszxuLoF4+Mmgm6ilpkkVpBhSrOM89eJpuDagYpD3wD8TUsXYCP'
        b'u0nchP+iTBJRk3UzRW6BRkHYudTt3HGd26zFNP0kgZgPW65FnashAVSDFRKuiFAPVYhaXOwUvwypJkeO1yLNc4n5SVB1oR5RldrCufIC8+XvJwnuEI3kJtXmLdRq5Gjk'
        b'wD6nJZnFKjURykIaI8IlUdq8AnmOFjc9dEOUVlOMx7e5Fm4ICZfEF8kU8xWoMiuV6AbKcKfu8OQW7g41J/LzF9BIc8kojMQqfD6xwsyl93zlMooUZHvRP6PkzV7MoDUZ'
        b'Lxp2kPu5a6Lx4+ep0NN44bI1yCTNWajN97Zc/Yxvl4z0tFwBTSIGjrIUE1WzouGdyUPpjyEdkwm1lExoV8mgSmF4vi7SCDOOZvHRRpkkZua5LA5oHFYQ9XDcEdEHkE6K'
        b'+lZ9V+6VTsdYiwN2OxQR89mjoZCeIR3HKxGdyovQP6rmEjwGhVkm1GwHMZomE9QhmaAukyF4RxOGRS9CqxiDx5sQi7cZ8JH01tgppKfGFyReqJFzVRy9dsvFoFVhpkk0'
        b'WkRzR74SI90udspkiddUeLBAhRopkmWEZVGMoJntiRkuc0Lpk1LP1arUnYXqSt2zpF4SVbL7mp9BRYsyWf/vng5DwKbhkhT8JZkRFDCr+7cF0duCyG2W34YexcqpkNw5'
        b'njp3VQ8IxBXdgr9QxM7xLPdiE+UqVdHwOJVUiwKl//A4BdLuLPdaJLrlvgqnY7l/whlY7qC6yhn1SrEFSAlDfb/lronIhnQ2mXkxLBUe0mLlcg3WLPA3UrBCu9TvcooX'
        b'hEvwVjLSn/Kw1oouoDK3/FLxTRg7TO+SKiX4pMs7chUa3CBR2KW6RwHTOCY9IAn7Yj3dLzgwNBTVNMsyYawyEgh/dVkj86ToaeNQp9JVJIJ2Rm8If0lmhFqOyHVzehLZ'
        b'Lmq0HocdLhmPjqgmPCNoZJfxDU2b3GK6v9dleevR3dyd9P1Y7qwxphupaOOjUtDrsdwj5ihyUYLx0ShrMy2yEyIb7+Kb3WMLSWCpU7G8wTG3eQEMMTWdC047zcD+ZDgI'
        b'nR4/B2rASnJX6TQBBr5KAoa8q3xzWiA1Ox42JycxHmwva4f1nYCnSfSFhQQM7BQw+wdXT58YDnbWDI8OhDXwGMT20v6MP8qtjlCHjoJH4REOPH0CbCMCEPQ0bIHnSIL/'
        b'LluMceTTGseES85n+DFaP5wLXAbb4JHoYegGTKmYSqjvTiQkU8dJDDwFKiczC0bY5IP6LIIqsndIYV8XMgsa4wuTAoKD+f9mCCVmYjoo129aGTtIQqksgSszJhJDHD8T'
        b'FskNoE7sDVqDyLqhYrvnWZ5ah47KLim0VVdTQLbT6/kPHusmR+a23WF2hS0MuuH98xd2yt/5Npt1kcoq3+mOoUPeOXSVecNam3j1s/mlS4Ij3piV9sLRnNMTTgVcSg3p'
        b'rzha8UZf5ScJgeeyByeuqRxfU1x3Q5B8VXkoemlWTtp/lI0X//3D5vk/KUrD7zaXbP5l75Wggs/uVoasd90zHu7Y+sqXu6+8d3rJnKNfbnA5HvR+fGrmVOE7e+of37B9'
        b'crVuR+LonEU9JzW4F8cMjulVODnxp7TPx916lX/s++UP8upSsi7eGh5x7eI665mffPr09u+3HJvKxt9g7bxFeo/M69IxisQKHG73qpwB64iR6eRseBgcTxqwwAAjmQNO'
        b'0H2nPWkvDYMVqWAdeDkenBAwQiU7KDyLADF4Mwe0752dg5vaN89sQa0Gv2m4agCstrid1L9n+3YSaBUTw0lwHmwsKganLHhlegUe6UtBKmvD4eWOJIZwOdxFWAxhFVxH'
        b'xa+Ep2EruADPJCbF8xh2Ms8HopPOKBDx3+T3HFvIka2sONyilxp/RKkYF4I97HkQjAd13kPsEMk2FstzI9+iZexTlu1vOF4oNuzYGGAenFOQ9mVsbN5ttIdl81zyewuM'
        b'EiFpmoJA5pjbyBq02cxGlomollEgxO8TNk1iygUGv0/P4YxRNQ8lYNJ34sdw79R3etK+041P4P8TV8RmKz38pBxAoQJudFJrMQJ4g4BBVasf3MFbnA1bKUqEoBZrwBFQ'
        b'bseHG7GLgKnMVLgqgzou2ABrfMFm+3R6Mw9eYGDzXEidNEziEd8ZXneCpIuulwZQAIMP2DUzmEI5XEADI5/oS/vWTc5zgin6A7cwJhdUg8sklZ5OQmJNsNAjW/xdTw7n'
        b'sVhODC28tr6UnXTSX0lN/Z/2dsIXIx8szhZ7RrjRmD/NIzYOoqLZ2eJTyhAaM1gjxhedtk/OVvIWLaUxx2fZEQhocq9s8UzBLBrzlzByUZTRO9v3WnEpvVgiIwYO2cuG'
        b'ZIsnzXiBltGIsZg/Nz0tLQ11CDEMWB4EjxCUwwB4Kg9sCQ8OwByLPHiQQa2zxoc+9Xm4xzo9jcEwvoZZtviXgz6kYMXFKelGgBHUK23lgVZhKn0dp4WJGDLC8DwiwT4M'
        b'GdkcRgoX+yOYms54wQaGGcgMhFVDCWQnCZ60CRaI0MsOYoJgZQR17XciqxTW8HpLGQbjP3YWE08eDrA54UWwF41yplCPCjkBR3uANnjpJZ/0NAkfE1z3EoJ9qKOqp/Xo'
        b'NKgIMXW0Ny6bTZC4UjAGLmJ7b+KsoKBSke07eS732kb3IBdFYlm27wpHAS3NVFjBpOOiZODKsgxGCjYC6on6fZELMYYRTsyeGSgfQN2WecKzBaAF7ExPA3u9GSZ8sR3c'
        b'B/dPIWU8OMAGlsONavtgVGAsOM7Ai2FqRdzc91i1J2qXoceZwk2JGPKxJn/XweRHSdN3XLvr88MNge953tz54wTrNl5rHK+6HjNx1Bq/eSMcQJh3j8q3N4c8HbroSVlb'
        b'WnzfLTOP+/U9q5ng+PmhY/HH133+5SyPHlPEsyd/p5DX9rI/dLG2KL7pzhd93ceyE5p1wm8vHrvp9sfvQumPpx84TXn7Xo8XD4/vKc3uG/3K1//aNn3TxuUbN228s3uB'
        b'f+KV8UPHH376beO+zdbzEiMuT/B42DOvfgkcPTxmw7t9JmyNeDLw9/QPD96aNqJXSqDCR7Mk6uOyhGmSK5Pfm/fjWzun5UVmf7NwbfZqwffKwo88wk4p6xS9b3z42/Sb'
        b'm0N6jSuafLd4yJhdFR+Ufcz3d0i6MiXkHw1H5wweXfjNhcvDm36+OuGd2TL3qaftWg9/+7D38uh5/PcmebtosEMgeBBuLkWjGLwAqs2PZO3jmByUU8P+jf0KhpHBEf0k'
        b'ghecVSzYtAAcJ0jWafCyAOwJQspPEo8RDOSB+sAgetchP3DM1HXgebZs6RQyhM+HLZ4KYUcI6ja4kwyI2TyHRDMwDkksalw7rGyKwU6aw8rcCHiceuY2WJkEwWZKn3Ci'
        b'lxT9tIY4HzXgOOB+sJ1YkMwDJ0GV3hZmBlxrhOMAR2A9ETIYNsyHawdiYnYjvMlQcJCkALaChmiDlQw1kRm1gEN5lAcRXeTF+ZPgGZUxpBXs8SB3qybCXYnx8DwsNwZ4'
        b'OICV/PFwO6ijSIfNcMO0Yf7T4boO2FAbWE0EdJyRnRhvC3cbwTscFvNjbEZRd+Q7UAe8hlrJUAsZeBYe4axk5sMLVJd6BV7oI4XNpsY4sGkmRW2cUs40cfAIqoawxUMH'
        b'E3xJSHKA3lKHs9KJQ2MHhexUzSYvchE/rLO9kTt6wGPOaJACbaDVgoXKM9wIEkYYoprM76SaCEoEnAoi5jmxIjKuO3HwVQyrcCLACpZwJrOGTzvEggArvhb2E96y7Y/U'
        b'GpZCLpyIKT420xf8JrIR/Sqw5cjQiH7QiWbNvPwdCNf4ekq35cYf520WideM81JjrcGio+G/zLqWhxQTbUfFxDzlmDVHObYaHgUthHNsqI951jFMOYYq3F7qaKsF7AUt'
        b'mEHMQB+2JxusWAS2aDEbkNcieJJyh9kMX2CtIEjXCdMHE+IweHkA5g5D7eyEYsrEh3w1tnmIG9A4JjnCFkQ61V+NqykQ2KVm5+cXDnM96zqo4Fxso1OOYOenbxQ2/GJ7'
        b'YaQ2lFcmbqsrc78REeNS05iV8HXtQ7Vn/zLZ8NzAL6wPrY1lHXNuekTtmn7tp5QP574oaZxgfSqpsXzGYs/U3QPeeHvTlzGiT+POhfNWrO4pTm7ad39v8i/vOj15cv/b'
        b'3m6aDX0mVJyw+Se8V9g2b4j/iPT7+f8MWveqqFplt/jx/8x9I/ZwxNcNx/7gObSE9t+yy9uRNsJdsIqjayPEYWj6UYUaUYs7ZfhaBnaDl2HlZHDUwCBG6MOQ9r+G3L8U'
        b'7kENkPKDwRZQxxKGMPDyaAoUa8qxgZVFoNqII4wQhJUBygMMLzqCWthUDPYbcZAR/jElrCKd6cDi0YngOGgz4hDDDGLZYAvpJhaBk2kcgRjqVNezlEJsTx6F7a0V4h7E'
        b'lEAMXIjI78enfczy0QqOQqwE1Asphdh5sJLI3mdkaUf+sCqwE6yGO+BuYoWoCOnHUYjBhmArwiAGmhbSUl0/XZoogGsN9Y8wiMGzmdQXweYw7M2HUoglW7GEQgwchC9T'
        b'HwcH4OX+JsPTcFiLRqh6uJbMxYJhM1xBJQNnUq0oi1ig4m8hESNMV6RzC+jUuTFLB/l1i0cMdxUGHjFVKdM15GuBSd7u6Jrao1PHxCx3/dgib5g+P9TzmeI66Cnn7Rsf'
        b'p3g7d4SAlTGMMQ7sVeaZxomtDHHurZEXqimQqwNFWI+/NAXuxju6hFsF7sCnMZQTzEkoJgxerk9Z7z/HCCYW4GFG8FTwVMJ3LhVFuPGo37tNsA7uVoPLoNWgsFkx9m4s'
        b'rJkNTnjzUhSOdUsE6t48DAj/ILYqomhlJFKEeze+dr1PgGPuD1/wD/7c49otxlu1PGvE1skeGZM+kW0Sqv77bk5twc764if/+P3E2OHRYwVxUbPqqyc8Ln95Yl7+jp2P'
        b'xf85vW95/pBZE5a2xsZN2yp4+lbQ+7Pqf008LKn7/L9bPmNjH9h/k5KbHiGvPVT6U5+fV0RXLXgn8HDbl+vtxs77YI3o1O0/3l805KOhQP1gumO/mIvVb37b762v9025'
        b'PsjVeemmeXEhTYKjjZqcER+Oj1/oMvyjbc3//HDru4tH/XT+Jt/9oy/Td0rLk9rq3o/71OWudNa/jsz7Kk1lV7s4oHXzYc9vnn69K3H+lQE51QmfbHn/QPB9XVz+7aS8'
        b'woFzPvZ2GHvOxuHIlfTUDW73xkc9tmOnynraf+/N1+DRIwueyoeVSMnjhTHuUaiHXaMlfcx8n+md2GQEi0GrCK6VU4Po1Xlgrx3cEmthHWfekM5rMP3+31TA5w5Qt8M3'
        b'tEJzAQGnirKylMVSWVYW6Xaw9TTrxrIjeBK8tPNUyOKlHYmbm4uLj8s4dmg4jywBjXbgD7FjlrLzw3iq64aWx9exWVlGqzdu/wfKgKf6yNBwsaS45yGeiSO/tcBYBqrT'
        b'4CFQicZMNGqmJoEKUG3NOPQF22L4A2xBm8J1g1agrkYRwx4eGVAxCjudt3r6622nyInKdZE5o5ynNo7PLa2NL7/32znRSM+WHX2Tb8bUxbkV3NyWsvzR3Tf5qeFHP+qV'
        b'/ihr8KVrCduPNg2bfWRsTXRFTqLT1I+/bvCN2ZLZcvadd047QwEbHTUY7I2ysysPCb2eUz7GIWz/yn/Y5Atmllyx//VS4tjVpU5/vO+47qq7KN3ro5eGIIWCjLnlPUPw'
        b'gJyKl6PXJ1rHZjF24DQLj7AiorrDSrDSCfvoOYXjpPphJ0Ft/AnwINg3FVBEvhOshQ20BLDajqeIqAScwfIY/gtwrRcZBRVocG2Fe2FrYnyyT7I1IxSwIvhKNGlt4FSW'
        b'FFYOFzK8dO8YNJ5OhQc0eH0jD+yLHJZgxfASB8MGBm5nZhOJS8C6TEJ2h/KC63lw40LGzpuFG2PgSo7mFE1lWtVGMdoiGNt4FjTCY0OJjlJYAC8lkh6SzpQc4LoEcICf'
        b'MiaAzFPHxgzCv7rLuX0CUA9O01nWyYWgmSihdI3daoyEEfdk0QC/nwLOBbA6G2CO2xL6O9ymZGxBEwual/A0hDXhAjwDtqMop8Vgbek8LWyaJ56n5TGweWRvWM0H60Er'
        b'OEvd/bTNxt5GMcMCfhIGOzdAb2YHC/cnDiFrxhPgCjRvQ8U+PBH1MVV4MRifWXuMZ/p5CMBKV1Bl4iJ5wP//5tWxtdk8o8cx0wG1oyaw60ORva3B9z+euYl5Y/kd1SCB'
        b'B1UYSJ/jruMr5UU6AbbS1VlptCVKuU6gVKg1OgGeK+kExSXoZ75ao9JZEap4nSCnuFip4yuKNDqrPNT1oS8V3tTHhCElWo2On1ug0vGLVTKdME+h1MjRSaG0RMdfqCjR'
        b'WUnVuQqFjl8gX4CioORtFWo9TFQnLNHmKBW5OmuKolXr7NQFijxNllylKlbp7EukKrU8S6EuxnaHOnttUW6BVFEkl2XJF+TqbLKy1HIkfVaWTkjt9Iwc3LP0bd/Hx3dw'
        b'8AMObuLgBg4wnZvqMxx8h4OvcPAjDr7GAaYvVf2EA7xDpPoUB//FwW0cfI6Db3GAueBUP+PgFg7u4uALHHyCg49xcA8HD3Dwvcnrs9V3qjG/de5USYxHojxskptb4K9z'
        b'ysrijrmB55Ebdy4pkebOlebLOUSyVCaXpXiLiIqIaWWlSiVHK0uUSJ0tKneVRo2ZunVCZXGuVKnWiSdj68BCeSwuc9Vv+tLrYGOvE40uLJZplfKxeGmfuDgQMAJrEdux'
        b'qrmMZElV/F8eS591'
    ))))
