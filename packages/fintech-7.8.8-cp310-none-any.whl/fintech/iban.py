
###########################################################################
#
# LICENSE AGREEMENT
#
# Copyright (c) 2014-2024 joonis new media, Thimo Kraemer
#
# 1. Recitals
#
# joonis new media, Inh. Thimo Kraemer ("Licensor"), provides you
# ("Licensee") the program "PyFinTech" and associated documentation files
# (collectively, the "Software"). The Software is protected by German
# copyright laws and international treaties.
#
# 2. Public License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this Software, to install and use the Software, copy, publish
# and distribute copies of the Software at any time, provided that this
# License Agreement is included in all copies or substantial portions of
# the Software, subject to the terms and conditions hereinafter set forth.
#
# 3. Temporary Multi-User/Multi-CPU License
#
# Licensor hereby grants to Licensee a temporary, non-exclusive license to
# install and use this Software according to the purpose agreed on up to
# an unlimited number of computers in its possession, subject to the terms
# and conditions hereinafter set forth. As consideration for this temporary
# license to use the Software granted to Licensee herein, Licensee shall
# pay to Licensor the agreed license fee.
#
# 4. Restrictions
#
# You may not use this Software in a way other than allowed in this
# license. You may not:
#
# - modify or adapt the Software or merge it into another program,
# - reverse engineer, disassemble, decompile or make any attempt to
#   discover the source code of the Software,
# - sublicense, rent, lease or lend any portion of the Software,
# - publish or distribute the associated license keycode.
#
# 5. Warranty and Remedy
#
# To the extent permitted by law, THE SOFTWARE IS PROVIDED "AS IS",
# WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
# LIMITED TO THE WARRANTIES OF QUALITY, TITLE, NONINFRINGEMENT,
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, regardless of
# whether Licensor knows or had reason to know of Licensee particular
# needs. No employee, agent, or distributor of Licensor is authorized
# to modify this warranty, nor to make any additional warranties.
#
# IN NO EVENT WILL LICENSOR BE LIABLE TO LICENSEE FOR ANY DAMAGES,
# INCLUDING ANY LOST PROFITS, LOST SAVINGS, OR OTHER INCIDENTAL OR
# CONSEQUENTIAL DAMAGES ARISING FROM THE USE OR THE INABILITY TO USE THE
# SOFTWARE, EVEN IF LICENSOR OR AN AUTHORIZED DEALER OR DISTRIBUTOR HAS
# BEEN ADVISED OF THE POSSIBILITY OF THESE DAMAGES, OR FOR ANY CLAIM BY
# ANY OTHER PARTY. This does not apply if liability is mandatory due to
# intent or gross negligence.


"""
IBAN module of the Python Fintech package.

This module defines functions to check and create IBANs.
"""

__all__ = ['check_iban', 'create_iban', 'check_bic', 'get_bic', 'parse_iban', 'get_bankname']

def check_iban(iban, bic=None, country=None, sepa=False):
    """
    Checks an IBAN for validity.

    If the *kontocheck* package is available, for German IBANs the
    bank code and the checksum of the account number are checked as
    well.

    :param iban: The IBAN to be checked.
    :param bic: If given, IBAN and BIC are checked in the
        context of each other.
    :param country: If given, the IBAN is checked in the
        context of this country. Must be an ISO-3166 ALPHA 2
        code.
    :param sepa: If *sepa* evaluates to ``True``, the IBAN is
        checked to be valid in the Single Euro Payments Area.
    :returns: ``True`` on validity, ``False`` otherwise.
    """
    ...


def create_iban(bankcode, account, bic=False):
    """
    Creates an IBAN from a German bank code and account number.

    The *kontocheck* package is required to perform this function.
    Otherwise a *RuntimeError* is raised.

    :param bankcode: The German bank code.
    :param account: The account number.
    :param bic: Flag if the corresponding BIC should be returned as well.
    :returns: Either the IBAN or a 2-tuple in the form of (IBAN, BIC).
    """
    ...


def check_bic(bic, country=None, scl=False):
    """
    Checks a BIC for validity.

    :param bic: The BIC to be checked.
    :param country: If given, the BIC is checked in the
        context of this country. Must be an ISO-3166 ALPHA 2
        code.
    :param scl: If set to ``True``, the BIC is checked for occurrence
        in the SEPA Clearing Directory, published by the German Central
        Bank. If set to a value of *SCT*, *SDD*, *COR1*, or *B2B*, *SCC*,
        the BIC is also checked to be valid for this payment order type.
        The *kontocheck* package is required for this option.
        Otherwise a *RuntimeError* is raised.
    :returns: ``True`` on validity, ``False`` otherwise.
    """
    ...


def get_bic(iban):
    """
    Returns the corresponding BIC for a given German IBAN.

    The *kontocheck* package is required to perform this function.
    Otherwise a *RuntimeError* is raised.
    """
    ...


def parse_iban(iban):
    """
    Splits a given IBAN into its fragments.

    Returns a 4-tuple in the form of
    (COUNTRY, CHECKSUM, BANK_CODE, ACCOUNT_NUMBER)
    """
    ...


def get_bankname(iban_or_bic):
    """
    Returns the bank name of a given German IBAN or European BIC.
    In the latter case the bank name is read from the SEPA Clearing
    Directory published by the German Central Bank.

    The *kontocheck* package is required to perform this function.
    Otherwise a *RuntimeError* is raised.
    """
    ...



from typing import TYPE_CHECKING
if not TYPE_CHECKING:
    import marshal, zlib, base64
    exec(marshal.loads(zlib.decompress(base64.b64decode(
        b'eJzNfAlUVFe29q1bt4pidh5RyylSTAo4T1FRAjIqEI1GGQshIoU1gBpnkGIGRVFAUcQBBEEEZ9Bk76RfXuak06/z6AydpLuTdLqT9Ov0n37pTuff51yqAMFOev1vrffj'
        b'oqq459xz9jln729/3zm3/ER46EdJvyvo17SUXlKETcI2YZMiRZEi5gmbRL3ynJSirFcYR6RIelWukC2Yxm4W9eoUVa7isELvoBdzFQohRR0jOKbqHL5LdQpdtTJSu8OQ'
        b'YsnQaw2pWnOaXhu925xmyNQGp2ea9clp2qzE5O2J2/R+Tk6xaekmW90UfWp6pt6kTbVkJpvTDZkmrdmgTU7TJ2/XJmamaJON+kSzXstaN/k5JXv0s38K/U6iX2c2hgx6'
        b'sQpWhVW0Kq2SVWVVWx2sGquj1cnqbHWxulrdrO7WYdbh1hHWkdZR1tHWMdax1nHW8dYJ1olWj9RJfNyafZMKhFxh3+Q9jnsn5QobhL2TcwWFsH/S/skx/T7nsDErI5P7'
        b'T6ZIv670O5IZI/EJjRF0TpEZGvoMk5SCJGQFuAgJLiGjnhUsM+gilmPxPizGwqjwdViApVE6LA2Ni/ZVC9nOs9ZI+ABObrLMZRWboN2ZKpZhuTfVxrKQCCx7km4pnr0u'
        b'xCcMS7AkNByLQlVCBhzOhnLHp8d48W63easFF+HdLW7aBB/XiYGCZStdHA1tcBg7HF3XhVCbJaFxIXDVE/PnYoHP2gg8GqPBwpA4anxgb54h4VgWGR4V50kFBbPJ0nUh'
        b'a+M8fUNCfRRwRRLMUDh6PlR6JisecjA325xE/sgCpbr1LoGiQKQlEGkJFHwJRD7tiv1iTL/PtATbHl4CR/p1GrQE1+QlyIhzoLkQhg3z3++zJcBD4Bc/CxMFVlHrn+Ty'
        b'223T5YurjI7CMEGYk6DLCI+Y7yJffGm5JNC7dti6bT7NOY8LTUIG60q5aryQ5vzZTEH4aNZ/iTf9D7m/p8hgdsRNqFZcc6iYoViREPBewPsbYgR+eaHvn92Pu//7GPfo'
        b'Xyv+sbErzCL0CBZftsadkLeM1oOW1NMTi2aH+GIRNMV60pKU+/i5JIX6ro1QCJnujsugcbFutmUM86qukVhhcqEZx1MCnFwDVVAJ5yyjqSgWzkCFyaiiomKqB1YoCNxk'
        b'GcVuKp+FNSajA5WUCguCoUjCw5ZxrKAFz8EtE95k1lQIeH85lMB1OGwZywqPT8VDJiijycJ6gS5fhDNarOd9QX2sLxVRAOB5AS4vg7oZ2MhLPOHoZNNOZkQ59QY1UOSH'
        b'd+R7uvdGm7BdTUUnBCzCDqgYHcJL8BY07zdZ2E1HhXSalmI4vVC2/BYFwgWTK7vprOA7F6r3jeDzMO9ZvGzCDmbbSQE7UqECa/G+3Fr7qEwTlLBPp2mWpkENXn6al4wf'
        b'BQ0mZ2b0OQG7tkA1dKHVwlwnHu7sMuWQ72KVsBRuQdnuybLNrcE0P+4Cv2U53XAKzim4Zc88Ng07XFn/V4WVkXAWT8EdXuCB16DNmS9Ds+D1JJxKxVu8AE/h6T1QTGun'
        b'0AjQMApa9yj4WGbDXbhowutsUY8JaMWzUL42ki9QBuTRFHRYlHyi8SwWwnG8TQ3y1Ts7H8474zXWVZuAh+Eo1OH53t6mwAXoMOWIvE3LfChajW28N9/teNKEt5jl1QI+'
        b'QCscHQ5HZAs7Z7LRyqu62QtqpsFdPj3e643YoWHXLwhbsR5qHZfxG4Ih15MKmAGXhZkLoc4fu+R5uxYYhx1mFe8EjiZCeSie492PXAmnscNFzW/Bu9vgDN6EFj6eOViD'
        b'nVTG5qGRvApqoY58uoN3tc/PjB3YzsxuIO8Ogaq9Wl7wrJ9IyMbuaRWgeAHUw+U1vCfRD29SSe/s5NJAz0+HZu7aWAOHEqiMTes1chPqpwE6kmS3r8TWMJpy2eVosPVw'
        b'FG9k8L5m4hmspmVX8PumzITzsSP5eDfiebICO1jBFZpVM9QG6HlJFrbGsxIH7ilQ6gF1c5daxjMjrpGj3aD1k23HQ3CbJuMQHpVn8I5B6axhRTepPXgAF9fjeV6ywgkO'
        b'OuN11uANwbQIzuMF7JTXrzsozTlbxXvCkzlQjbf38Fv8XeCiM95kk9fOctAdOOPqxud8IzTDSSpio+2gcCMfOgt5eEQelT8cpzIV7wkfDIP6J/EE78kdCqHNZGbmFQgT'
        b'4SbkG57lk45l0AInnBkUs1lv2QCnsqFKnthLcB/uOzuxru4IcMwHLmEl3LNM4OluKhZD8XysgBtQohKUeF4xDK9GPbHVwrL/UsilyCvOxuNQCkUqQUpTULw1wCG8oLFo'
        b'qcLE2dAIxWgVeZUAWzOOUCqOhfNQqlNaRnAICsI66qh8H628QTCsXszdG+8QGNWH4S0dmZ0kJEGjl2U4XZ+M5wLDsGaDmqWVFFeUA3zNvAO2kZPr5kO+mlx0FmumdIOE'
        b'lVgAzfOhSZUYAaV44ZkgaNgUIcw1qcjAKjgBR2byLoP37jLx8Cik29aDVYACixdd30yVWmyNtOIJPM4/zoVmPCEx1Cz1wFLJEY49wad7CV7B8ybsVHD8hsZ9UAY311l0'
        b'bKwVeHO83BKtTyNrKgRabS2lQJ4HdEvKVXBCBs1mqlZoSyxbp5AZraEWTypJ3YsHbQZd7WdQCzeoBio88JikDnSUA+sYdOA5Ql+GFXVkRDucfhzLZYPu7acGKkOghabH'
        b'3lAAM40aqqWR+SrxNpSF8glyxXwoMRmZH1mFnBDIe3IVn2SXVSPs08PnGLqecdbSmjY+OVJYq3XYDE3Os+CUHA+HN8FtW0actQwK4PYYiw8ruDJ80eBJhjZKWPR2hRnk'
        b'a1TtWbcTL6/n1qyM22DLn7QGnVCUo+cpPDMKiuxDKlUmyfZAAyHZhWegmFY+BG+r8fB+vKFR8xXzwSYsIrDnsUJ+j11QHGawTKO/05al9p8etlrS+pU+wkTsUOI1bCVk'
        b'YC2QyZQunESZArTQEpzA3GDLIjbFBQps6bfmpQ8vWmMEa75LhJYIdVKEsBPaNHAnHGT4mAkV7iYiBxz4NHAMTi/ebfGjgoBA6GSWtdoXjuyuVsIxLMQTkJ9KwVYj+ONZ'
        b'FXlffpKMAzewfGIfsWjHNigJVHMXh3q8vH2AR8l+yad9L5R4QKWSZqWaUgmzahY0pZvc2GhrKP0QEFa57eSOiTcXwrWhQqWJNbQQyTGtkoNqM8e5MTQXN+1khnLBXcos'
        b'RyDXMptZdBdKRvW1VNrfMLw32hYzc59VEQNoiZGJ2GEs2t1Hge5gI9Tt2GkJYIa1Yf5IOxD0uVczaxkb8AFbCNZgAJar4Fw6lHMfS9i/00acvOEwFEVCu8WbuwnlscqB'
        b'kWxbTh469dM98KqkgfINsmUXt8AlO9EaScBZgR0T+UCxBXL3DrKMGm2RB81j2pcQ1i/UtJzCdiz3ivtQQ805yLn8ThwxkNN4gXeVSMnnsI24wQMNEbdSbJLJ7ZnIrbae'
        b'rrCeiAbsZt4C+Vo4T7Eagd0O1HRbAJxM440tpsRUY6N65D/XiewRtWVToM2ZNhBYKcgwdxMc3+g5X54EE5zVYMl6eMDRbKYjttrZYepUmoBCPMjNWijZF7p5UOD3Dr9K'
        b'hXd3m3KwW4a0Yic4bpIT+BnibXgXqvDYepmeVqahnVEOh5NQnTVCBpi8eVTT5uP2XBCEF6FTS1mPgVUU1jn4LcBD8qLVH8CDNro2Eg8SrJyGKzz6oCkQu/tAZoDpsj9I'
        b'gh/cUy3LeeZpLOLjj6b4PGHKUXEPIOZeA6VjMi2P8Ux6h6ZZbuzKw+nFd6PHLCXe813DB6eOj+njiaUOxIJOOXMgx9r5wQ8D1VwWMOSLLXhoIt5UUsDX4g057Rdh4XJq'
        b'SMH5uD+543GiGHIqdYPOQBvfDKIFr8FTU+SIzMcKPPxQSNo62xppj8idKjg1F6/JKawCT+wxuSs4S8WuKcQzWx6XDS6DIrjbH8HYJ1vmKdvjoVQSPp0mssva2RxLhMrG'
        b'domL50Ltln0cubAUT4yxGdX2cBzCxSwPbJAciMA3yAZ1YedyOz2GyzugLnu1ZR4rOegMufbRLaSRlg7ECgmuu0SsXA1XHxOMeEKDFWlQx/1kDxyCe3ZmTWSHyIxmJy+a'
        b'tADKiGlyLnBOmDiT3LQaLvKkSdN5WTEobQZpVUw11MyFcyoSMLWySPLPWEAcnC37RYEGWQa108FqmcM5gg82DnREO+ziuVE2CA/EWhVjd8c5qm13iu6j+9fc4Uy0Qoai'
        b'w+79MLLUDhP8ipKG7/rMPMU6lQON9sTCBd5yKJZg5TS7QPAkZl6HzcRV53ClCN1YH8ZsozB+OPA4CVsP5MXNcHsq9STjBHQuXERTxrn0RYFxyBqzG1/qkSQ+bvfP7HgV'
        b'um2NsbweCDco3XmQ6uXh2024fhI73Bw47/XFM9DgHCfTnhNwn8H3wHgJkOdqpmEitpPzUXo/xhuSnCmrdshp5TpRzJ1EkhtX872jSOPaAdmulx9Ao+ABhyls4QEWytN0'
        b'lxyqADt2irIEPjMJyoOwgluT7kk0uX8C6B8JLdDoAVYlIVzns3JLXRSqtdSSmoMfqc8uqBAnWKZTmRFOGR4elbgeLxiIr9wiAICa8TIJqxk7oU+5mfZAlesoec5ax1Eq'
        b'sUu3VhWtZ/dqeV1IgTzWp92uK+G8+1M2NKmgybJJN6iOI5w9EcCxbUsgseFBuNTKY7Nk/0S8RhM9YyLvYE4Y5TCbxpu+mLDtODTKHTTiXfIJixxFIXT9GFzHw5aZrAP3'
        b'Ub0gcsXWPnTKczd3IgORThdaAub1mXCdWBtPjPXCgt1QudvCsXx7mHooxkIAl43ddu7pjzUqqIt24tPkSemClgBvyDG04wBUe5GM9ePa8qQ0yCUYGpXi6dF9rW1QUQK8'
        b'pZFXtJv6OUgSVpRF58UgOAe5Gdw3VsGdjQNzFgOJIIpAe86KDndY5LCdT6FuFIPJXikcRtz6PFbm8FDcBm3KgTBhI1NQZLDPWCA8UEE5VsFVGSybXKnvDlcV16ijAqBh'
        b'PM2lP1uRKlorO8teQkqetSkm99o3jEy7PX84FMxTQO0Kp0jX8XJ717BkbJ8kVztAbVwyB8NxcDVskAyxc6l1Hjol3sKOSdx5TebEPvEeux3qRuBNGQsf4C1S648geTYq'
        b'YVGREGjMyqIxjpF3CfAyCX41by7GhVJOId7jvquYiccG+y5PcvGLJ+IdJV5fQFV53NwIZnvDvdsGpG4L4EzEDI5a2XDEd0iiKKvHqsc98IHkRiz6Jte3XpkTnDVqru5d'
        b'LXDBMI17OdTF+g2GKz6gEdkTsVWJrUbZBai0bqNtk2LZU3ARz+I57krLxw4mbEFB5JN2R/JxWICXIE8WCw1h2Oxs7s05h2gGKxdAE1+ACGhIsG92LBkG55dBK+97hyPe'
        b'se8ldBKVvwQNKby1ZKx52jmbNdZEzB5Pkjw6Q8HNzNq4KXgAJ+0fwXgFOjn6PXAkWcD6Xr8Fbztnsy6aSU3PInp3WcM9cvjWPqF29cmB7ggdmyj88p7Bhk2CcTupK/Kf'
        b'XHmUZ6FigW17how6SxLnzkI5GTZjwaSHgAHvY5G8dqoRvQKrhdQCsaR83txSgvly+6bOjjDyxkK4x5sboY0apNj79KAsb6FSlQ5VZqJj8r4t3V49x74R5OYIZ2PhEJdO'
        b'xOUeQK19H4i4RBPUZ0GbfNsJYhAXnd2YD3QJrk9RJ6cjuBHjvPHq0OqsdH5wP6irJ+4BhRK/JwyO4L2+FSodhJOqnfMU0RoHKJkxH+4peTiPGj9joJhcR4OlZW1RJdFa'
        b'RAgBY1VQMnYlrzthQd9eRnM/B+DOnQ2VHnBdktzny6Tx1jg4NdQAONGNQ8r9RSS6jj0l167E7gNDoAoPPGgN8ViiJOi9j/mWQE5WsCtkMHjI0F0PF/tNT6WKUKIbO3Ua'
        b'OeRuEn0+4+zG0t99QTmcqh1T85JFSrUztvduGHbTutarqTe2gJvxDhDstLN7bgt4hHpowAqo4E4eAtZZzo4iX74V5CSX4ehOvlc2EqrGOlvkDW7nXXAyMYe7XSQ5Q6Vt'
        b'f49yRzNN0sW9shqikax1NsmxCs0aqFscKnv+Nf8tRDs47nULcD8aLmDpbq6Vc2KfYYQECnr39uBqb2hCAdsMvGWGGxJ0xEJxnLBhixrPEjxLfMcQbk+ixFAcvhZLlIIS'
        b'7ysyKL3Uwr3erR9fExSFYVG4WgieJm5VzKY4bOG7roY5vmFEam/sn42l3jp2jOUyTDlaCx08PYbCSbztHekbIgnSCgWc8CNjyuFBcDI7MbL90DD4uRM/c1ot8CMudrTF'
        b'jrnY8ZbS6pjq2HuwJRVIucI+1R7HvRI/2FLxwyxpvyqm32f5bPGjr2kVnLT9foLYiahJm5jJj0K1qQajNjsxIz0l3bzbb0DFAX+EygexXtsNmWYDP1T1sh3DatOptezE'
        b'9IzEpAy9D2/wCb1xR28HJnbfgKaSEjO3a5MNKXp+LMta5e2ZLDtsx72JyckGS6ZZm2nZkaQ3ahONvVX0KdpE04C2cvQZGX5OAy4tzko0Ju7QplM3i7WxafKJLzsKTrK3'
        b'4jfUDUnpyYvZMLelZ+szfeS7mIGrQoMGWJCeOWhE7CeZJka/y8yGoE9MTtMaqJJxyI742Iy7+3dmtplJU/nT+zGzw+/e1vy0ERaTmY2RzXtMlG+g//z52pXh0SErtQFD'
        b'NJKiH9I2kz4rkRvmxT55afXkGpZEs56fpSckxBot+oSEAfYObrvXfnnGuWv1jkUbk565LUOvXWMxGrTRibt36DPNJu1Koz7xIVuMerPFmGlabO9Ra8i0O6kPXQ1OzDDx'
        b'y2ySc9JNDw1m0Hm6Rnj4MHd4ZDAHODMeWgEtUGHbJCOwqF3ID2onTBovECmb8/XaA087Ld8tcPxK50eMxdCqpT+eEp5yS+V1q/c4CwQQmmh9tosYPV8+6e2Z7iZ4UMrS'
        b'btntk7BlicD726XHQ3BwuG17h7L1RczXuctQdwGLorFtfV/hBi9+UwbptTa8DMW200QoGxsp66Bz87M0OttZIuFzMxTIx3hds6ATT+E5+3kiifE2gme+KQgtmev9bMeJ'
        b'cEqJ5bIB19fDZScod85ScjEMJ1UZMju8T9ShBa9McN7ZK5FqE+BCr9GuW1Lxmv0IsnWdbYvrLInUe3h7HHaY1FyykOg5t4S3tw+sISux1n48SZTd2rt7EwZH1+sop9mO'
        b'J+F47Hq5vQpC9BIshiv200moy3DkA4rbFZMGHc58dm7S5YV4VD4Nu02itZtYyHXs4KOtJc5FcrNaHhVR1pExkG/KceB7emRFERT1HjXuCiGCd922eQZFqXBUp5RvK9ke'
        b'T80e6SuDrl7FHqulJHyYCGu/3k6puIm7t3tSf419fcVulnNvwXg89TgU2XcWoSJnhU6USdJlODsJrdjWr5AW4pB8Wkb5/fDcIPuhNNRsMnC/U8yXH1DQRu5y+T4hSODd'
        b'u419DEqHBc6R2P6ikESZqzt93ObvlSbKFkLW5zPnvdkeqfR3UScsifzSs1PzfLQl6SPFZz97yXuFtag+fPK5E15HQ8419zSdN27IvlD8Qm7SxHqfk2+0//D0jKqXFioL'
        b'l8UuDD60d/avP9Tqon5xNOjFpe8/HfL73BeKNs16rGxei+eHrz7/3afX7pf0tJe873v46qxv3Yctm93p/tvXTY2f7Y18b2++o0eopyFvafnS5l+0PDF1+e53LP/294RJ'
        b'X2z/9tB3Hd81fQffv/x9+L6m5bEHLIbXjnhVLYjKMM2aMb/tz99F/1Z79NAT2Q5tHv/44Ncf/mHriHcevJf7pvRdyg/3c32PG355/MA3aybEfBXhsrz8Zzcn7rz+/rhs'
        b'z9fGfPvSp81zcp9/ZfaVzC0NH3ysczDzhS3EWxO8fT1DRkCnryiooUb0VU8zT2RFR6Wp3n6hPl46PyzHC8/6YCGLbGlrVoCZHzVehK6dYVG+UBhFCFFrJIrgvE4kOjeX'
        b'3443iIGeYY/oePmCFfP9FNT6YTEwEfPNnrxnM2m6jt5HZXKwLASq50ZgWbavFxbNFgU/6FZhp880M/OKyXiERFFxhE8otBOJKyPuMFd0M3maGSbBkRC8EyY/awPUXLjD'
        b'NE5mRmOeEm+7z9aJPaKnjnmnoHPkbz/5hQHpd6OXphoNe/SZ2lT5WSw/lmeX9zhx1I9nf7BqpiSGvAcknaTQKNivm0JUjFGoFdIPbqJaIf7gJEp03YWXObE6ovgPJyWr'
        b'y8ps73IN8eAoXpdddVNI/J+TwkN0UbDDM9kunbpHYp33KCmN9zj0JsUeiWWxHof4eKMlMz6+xzk+PjlDn5hpyYqP16n/+XB1kpHRMSN7OMfIwsrIng4zMprGu61iw2Re'
        b'Ixzy+EItijQ49iop1P9gr3w3Kx6b2LG/fTGwfHV4v9WAB1hCmMIcZPcIuBYG3WoqxeJILIsKVQluWcqFeC+AE1M3qIbmsHAoN1EhI5kKwXmTiK1ej8tp4MIii0xM4e5s'
        b'xkxd4F6ysl8SZCNysCXBxYL9ASopVerllMoCJXFKiTilknNKifNI5X4ppt9n4pR5xCnfVTzMKfmzdf1IpdGwQ5too4EDCd9AcvcQeYv9JxzTqN9pSTfKzCJLbySeuUOm'
        b'QLYH/gaSgCgbNyBDvNZTj+k79GuMRoPRizeWSCUpQ1NHZi8zV6aPDw9iSN7UOyj5jodHOFQXjGwGZyRu06bLlDfZYDTqTVmGzBTiSJxzmtIMlowUxqFkOsTJby/hHZot'
        b'rUlnQ+4jZ0TEE7UBvmZLFpGuXgrGZ424oyer4cM60v0Id1IN4k6qSMsyluzgBnvObPDThIXhXmt94Eqs/GAhuxAVHhqhIPU2A+5AofMiqAiLTd+oLFeaWDuFX/h9keCX'
        b'6p0YkpiRmpH0h4Stz737/LvPV0BnxepPF+U3VdVXtec2hXTm1+f7l+pO1edPPXUo0FXQ3XcumHZBJ5rZKTfkBz/p7EVxgYVYsh+7Iiy9yDkFOiRsG4NVZvaQ5y44ioVh'
        b'fmsZdpYSOPJgnACd0tzYTOjeqxMHxP+jQJCDQI+z/EBpH+a5yZiXolGMUMi4Z3S345OqR2Nzqx6HXgeRAcaFvbAHPgf0rjSyvTTjMPbiaAce1t4v+4BnxJUhgIeNkwTn'
        b'iRkPjROuD+dDzQyRlw+r8Bactenk8h19UpkUN+TBdSiBcz7KLWFzoWwnXIVL0O0kJOExVzyzYaZMhNi5c4NztptCwHyjgngpNq+dKgNSmwK6nLN3KgTPDQr2TMvp3Ytk'
        b'FteApXDPhDfdAyRBxGMKLFswxiuCcxRPKNaYAmi+YrYpDOzs5WCcvHt+hj7XOWdnqwXvBQo8IlCuvAE3bXTsKLRgl4x+q/A4Q780rJHlfIMEZwl/40YM0OXYNVqmXtUH'
        b'oMCbAJVcM2+VCGWKoCmeg2DTrh1WMdhUcuCUnzkVrZpUjR0+pZ8En0ySf/8oSc7jfqAgfyR4MKBh1X9c2D5Cb7Kb/9flZnIGN8ukNw8WmA8ZyObFkJxsIZzMTB5sqE1i'
        b'roleqQ2iJG9kOLqa8kWy2WAk0ZhlScpIN6VRQ0m7ec1eXA8iEWpMzBjU3iqKVr9+tiWyRbHwJ9K9YoJivXzobfVq9hYUtd6f3sk8r1UBq3hBUJCXz6AW+42J5KthSKHM'
        b'BsnnOUuWx9RqCoP03VkPTSD7+UnJ0t6iIWtwjmQ/Py1PDli8/1F9rhCG0ufupM+X8xDG84ztDsoyJNY6/0mmYWnGcyvXQzXLiTV7p5LsTdj70iI/WZxHJ48QfIQI+pSw'
        b'dHLsNlkkYTvkjYdi+vQUHHYSnsJzm2UAegBnvaA4ayQUQAFlxZEKR2iFW7yhJ9e7CXmTl7HHvF2SF7gTivONArzv9zjblPWH49hErw0jZaEKtZsCaZDsYcI6eq2FXN5K'
        b'Wspw4dqiJ0iKJfis3aFlrTD8XwFto+RWuvCy4L/J0cISQgrk5fDjo2j9YiH6qWzewpy1TsLT23Wk+xIyXpsQI8SmT/goTmFqpaIX2/JmlnW7wRyXvDfSa96E57qf6Tm6'
        b'4LOfLTFffeGNTEvTCxWxa7QbGyte3XzBsPbtl1/JWX7Wsmpr4I1hTqf+NN2/dcwfv1W213wWFOW92LO++oOFnzz5jMt/frIixLRm7QdTq8e1Vxr/4ryy2PG/S6r3dv99'
        b'zRzdH8uLXz7y2MctG1qHJ2059OcTufqRbTU3nH/1WUbwX2N+M824CLaMibrj9+XNjAdXirxufBn4y5nlOb5FX7p/uDDAdPB1ncbMpLse7kM9E2OyEoN6psZICzeaGbPG'
        b'm4F42Z7webavhqv9Mv7mhWb+jEIhdmUyiCdhxtTZbKriy24JcxD88dw2jToUz8EF82TW5tVV2OkcRpy8lz3AMT9RGA1WSbMF2s1s+aBNjQ1hU0noKQQxW7EST07hxkLT'
        b'FPa9isLZUdzaU1C4X/QirV4ni8Pj9E9WbFytwWWsIsUGHXvN7DlU1So4HoalYUxacl3pPgfK4Kpy2wa4olPIdEDzL6k0maA4ypqMsgWnJ3NkenJApibsVSQ55aKQ5RgT'
        b'VkxwTaP3cb2/RGBG9hGYPjnUoyTc7sdbfkxJKfspqVF2LsOa/rKPy0yoHILLaNnctm+Ak3YRFcXz/HC0Kp8izV2yBOp1Ch6jmzNm9N+4D8RmqIUjg79GYldB8wWugsRU'
        b'0f51EcVP+rpImk753esD8Gy9jIePIPKpnIfzzNt/Y/x/W/k8EpBtMzUQkNWRFvbtrhyoiHkU5x8DdY8GY2yZJpOuTszDUr7dmjiGb7iOhU75Ec4mR2yj0MKiiEw9lsRg'
        b'Qbg4Yg00wRG4CNX0QSdED3OAm0vHpr+/e5vCtITuWfQ7/CLBp5922Pjc7Yr6SsV7xpDAi3N8U3zG+CVGJqpfmeOX8HnCxpfGvfpctUKI3u/yZfQcnYojCTQvw0O9SJJF'
        b'cVrykHSAe/v4rgscJ+3Q2gdI+CBa9IUH3jzCxenYYd8ekveGnpyrlbZm+srIch1uY1d/aCFccYpiyGKAOxxBpmD5Htv+Ubg62l/ePsKba+XoE4eMcIdterM9vofx+KYI'
        b'n6rp3VRxUhjH2G5oUsqbGEOqjSaFXMjjkt0yjqLGNI7HpXDI7bMhIpN9XQ7ysAvKwqLgJNy3WS7bPRrzfiTwRKvwLwcecefvrgzw25isjHSzyR5d8pEEhZCWXU01Jm7j'
        b'RwwPRZotWhO1c4fUxgMqewZFxUXGrn/KRxsUsiYoLCYugkTzysiw+KCo1Wt8tCuDeHl8ZFzEqjXrdf9cSQ8VVDx3f+XJdmwLlgnaBJfi0AiBP3a9AbrgIPtinTf7Yl5h'
        b'+LoQeeeHyRg8ho1P6aDJCap3028oFO4mlaR2In7SpOLPdUU77et/L8USh8bJG7ECGyU4j7l4NH3n9yiYoqj211mq0f/e7npQO2rNWzn11280JHlu0Lqd+9nvf54Wfn/z'
        b'c5eSni37+fj77/zl41Gj6ypi9cYzGX9e6bhg7PIZTarLMf7/Z+lj/0jufPdG2qbH888OP9z4gk6S91OvwPUZfRGzYT0l8LwEnvMeg9uBzsmjBkYEiwc8lSFn1Bt4CO/0'
        b'5cy5I/Gs6IYtc+XSu9jkGMaTuadacFRnjxOJILTj/QEaeuigcSLpYeon20f1xo3Gn20xavgWI3s3TrDfN/bh1sbZo4VV8hwQLe8+QpPjhWio8g7x8Ypkkhyto+QVGQP3'
        b'pNGQO00nZztseTZFzmOkzMtnQxGPKvbc9YQDUto2p0eHVe+uHv9SpH1X718IrY+2PLyr1z+t8e2vzMQdXAANkc2Y/GHnell6ukBZb2B+CZUDLCPRbCY1k5xIqWlgozzJ'
        b'JabIG4eDdNyAtuya7scknSzh/n/NsoohAUETaWFpbcswvN8vy15V/5TNNZZlAwI4oHwQNE7tKyQwyeNxxOOAID8wcTEb8kw73TDPdtSJt6CNPwo/HS5sljPvUHkXb6b2'
        b'pl6ojebtG8Y4uGgFcnltQsadGfFCepHbHtEURyXPFvz3wIT8+4S01PDEl1N9Rvwh4enn3n3+WoX/qfrcRMXPV+VHDnvtNHRVtG9szZt5RNVSN76lbtGEuGP1VYrGuhvq'
        b'lrpApVD55eiJG6br1HKqrp+0y875p+KthzN1KR6XSf8ZV6kf54/im+rIDiPLCHAiVMKCSPX+jRJP69iAVjjujR3BdpwSfb2gkKMUVs9b2T+t43UX+dQHr8/j+4lwa/ZA'
        b'yYA3l/QCGZTCETN78o00XocxrNeQE9jKjek1ZAock/DM03jcxvN/bNPRhWd88msWNRy+xtjS/hoNkXlK+yJL/eyT0cN2r07Z48zwLt5gZHShHwkYsj8yZpId4Fgji/sD'
        b'3IifDQFwU6ksYjcelce574m1g0c554BOGRkZrFME68TI4HRr+8cKUzBZd6vjZNzbDjEjV45T//r97rAQzRapPcnQ2PjuunXtOevaD/5l3kFPpxfyc87P2JOTNuq1d9eN'
        b'nJv9Q8NXOwJKXn9tqSn+/e7w/FzlXzKPTiwIeymz4cHrB6xXhpe4Tjr5adKp/a/7Oiz5fm94ybcqb5XTFdWqiP1l+94Pjt8XPs3jZND1uG/yLn495da0S9HjTu6fv+AL'
        b'1WJpWvLbgevyko6fM79zbc3JFeNfjhkx+tQKb/+jT9bXRK5yPVOiM3u9+Paltz4/tXK7f+XrkLHYwfT50lcvO1+r8IOkTdaZZl3VW3t8okLrOlZ9tblQfdep+fMJLRe/'
        b'+Pvi/0hW7ngh+K5jbfrIm29evXvX9TXzkuw3z7y7JifZ/f3mv32b+Piyg7m66r9ELc7DkvJzRya/6L/H4+o3UuTbMQsjfvVm5Buf1Z79xYfPRm544xOxu9GgfPr8OvOb'
        b'kea3Xvns0oaseQfWu7f63y/b2mPdPwFd94y89dmO9+qVt8N8v8/84vfLuncO+/ZzpctbC0d8M3Xyuid+yG693/3pG6kzn5lT8m+7Ds+o+3h88Nd75x4/UWeM63mpIPWt'
        b'rb+6lJHuHfabTzTJON/3xHxfDAh8+cnp128pZvvEzcz4bdUlZdXLIRueur7u2vpPq25PvRX+eOKFY4/tX6QqMx8fubNoUuCEF8K61uZ9/0PlpHFfuX5iefs5Q3bweSfD'
        b'1/M/HP7Nt59sCd7z8dkPvh33osPeF2Zlhpm+LJ++8KmXRhadDvhdwLhXXns2YMGRN0KrP/xe9Z+rQ77y+2vbpY1/KzLcqdn2m+0fmkzvbV8d8ffn3vh7hub8mrwlP4iH'
        b'Lwxf8OdYggimLiZBBRyh/KkQFAv5g2RY9piOH8Ead7raAlWY359wnM2Ww7QOKvFsL7wshvxBQgAr4bqZMYFwuHkAi4mXlPqqBfVWEY9NmY6dkVwIZOxL8V4LuWj1xYLQ'
        b'8EiV4AztIp4JgUuyEOheCHWkZbEjG8upCpaEsiptIl7B2gn/4oGszu1fO799ZDsqI0tEQ75w0NHEx2cYElPi4zngZCmY3hHFuQot20n4QS0SbxI1StFJVBAufC86sMNb'
        b'dqArKcXvJUn8u6QS/yapxe8kB/G/JY34V8lR/FZyEv+P5Cz+RXIRv5FcxT9LbuJ/Se7in6Rh4tfScOkraYT4pTRS/KM0SvyDNFr8Qhoj/l4aK34ujRM/k8aLn0oTxN9J'
        b'E8XfSh7ib6RJ4ifSZPFjaYr4kaQVfy1NFT+Upqk/kKaL70szxPekmeKvpMfEHmmW+J+Sp/iupBN/KXmJ/yF5i7+QfMR3JF/x55Kf+LY0W3xLmiO+KfmLb0gB4utSoPo1'
        b'aa74qjRPfEWaL74sLRD/XVooviQtEv9NWiz+TFoivigtFV+QlokoLRdBelx8XlohPietFB9Iq8T7UpDYLa2WusQ1bGb6/mk6h0UOUwxTsIMiUemm8FCIj7soRimcRori'
        b'OPaXJy9x46/DNIoJCuPkflAuxsf3Q3DX//f1Vxin2OGedcRyLafFj334qD2Z6mz2zWooJyJL/AMKodxBIL5Q4zZeOQnzl6e/+qeNStMpqll58BXf4ggnmDMq79OL6T3f'
        b'5arGFn3muDT/iaypfkee2PB2qWpdz5k5r/nW1NYUlN55NfV3fxs3+sVJyj3hb1drc78J0D+TtECM+I89Dbd/a/h28+uvqHbseGt0W4N2zUc/b37Hp+DXRdl/e8EzZvTH'
        b'3n/yi1p6rLrnQK3D0si3fL/5VJPaaX563UbTa66uOe/9+U2fX6T/Sbcs+PS6efEXgzz/+M58nSsPyAVqGkNxKDbTMKJoMGxf0Bmui9gIx7GAA8d0PDyFcaN2VoXt7y0J'
        b'G45dSqj3XmZmaY+Y2gm8KE8Gy3eU+Gky8CrecBuhnJyNZbJiOYOn4WBYaIRXBBVWwl21JGrgENbwfcVl6zDXe61KwKPYoggT8JRplJl/S+/sE+LDuy1QNjuMgKmMMmy5'
        b'ku6IeALaHaDcCU7JR5zzNz98h5p9Iat67GrJa/8o/pAINsDBkdiBJQRBs712Ums10znSTbBIkB+YxWHOyX8iU5BhWEwGt46QfBVwNRUr+Ji3Qu6TPNXLpozbJRszEWol'
        b'uITXsYrTJ6jC1vFYrKN6sp8QSy3VuK9Txi3dxU9tM1evshX7sGFxraoQ1h3Q4g0V+x8UKnk7K57FWm+o84nywSJuEq0R3heJvR6aO0DwTfqfAcT/wRed8lGImp6Zbu5F'
        b'VPYEkMbVSX7ERSnSuwt/1EX8h0Zy6t3JmaHkJG+2UWtHgik9ygx9Zo/EDod6VHwno0ciQWTukVLSk+mVxFhmj9JkNvaoknab9aYeKclgyOhRpmeae1SpBOn0ZkzM3EZ3'
        b'p2dmWcw9yuQ0Y4/SYEzpUaemZ5BU61HuSMzqUe5Jz+pRJZqS09N7lGn6XVSFmndKN6VnmsyJmcn6HjWXYsn8ZFufZTb1DN9hSFm0IF7egU5J35Zu7nE2paWnmuP1TCL1'
        b'uJKkSktMz9SnxOt3Jfc4xsebSGxmxcf3qC2ZFlJOfQgnD3aSke0+GheyF3YiYmTPxxvZzBlZoBhZCjeyLW4j0zNG9r8dGdlXc41sZ9HItpyMzHGNbG/EyL5uYWR7LEb2'
        b'vUkj+6qMkX1TwLiAvbCv2hqZmjYyMWHkX0tj3mpkyszIjs6NAXa8ZMvhZMPL1X8djJe8xnca2+NSPcPi43s/9ybV7yakDvxvrbSZBrOWlelTInUa9vRSiiGZZoY+JGZk'
        b'EPhre12IaQC67kSLYDSbctLNaT3qDENyYoapx6W/IDU+bpvGfi+yHy6V/++s5UyNmti5lSRIag33tVFhIhcS/xdBJ44s'
    ))))
