"""MCP (Model Context Protocol) integration for Langroid."""
