"""
My Flask App - A simple Flask server with API endpoints
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .app import app

__all__ = ["app"]
