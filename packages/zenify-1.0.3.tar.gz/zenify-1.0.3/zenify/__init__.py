"""
Zenify - A beautiful terminal meditation app with multi-language support
"""

__version__ = "1.0.0"
__author__ = "Zenify"
__description__ = "A beautiful terminal-based meditation app with multi-language support"
