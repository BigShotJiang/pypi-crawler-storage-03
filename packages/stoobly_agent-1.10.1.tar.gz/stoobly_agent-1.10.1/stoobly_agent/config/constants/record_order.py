from typing import Literal

APPEND = 'append'
OVERWRITE = 'overwrite'

RecordOrder = Literal[APPEND, OVERWRITE]