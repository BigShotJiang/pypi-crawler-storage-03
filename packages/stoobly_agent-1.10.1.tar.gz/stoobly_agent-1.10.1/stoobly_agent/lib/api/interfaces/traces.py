from typing import TypedDict

class TraceShowResponse(TypedDict):
  created_at: str
  id: int