TEST = 'test'
DEVELOPMENT = 'development'
PRODUCTION = 'production'