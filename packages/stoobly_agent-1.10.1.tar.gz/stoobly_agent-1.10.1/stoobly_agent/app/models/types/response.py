from typing import TypedDict

class ResponseShowResponse(TypedDict):
  id: int
  mime_type: str
  text: str