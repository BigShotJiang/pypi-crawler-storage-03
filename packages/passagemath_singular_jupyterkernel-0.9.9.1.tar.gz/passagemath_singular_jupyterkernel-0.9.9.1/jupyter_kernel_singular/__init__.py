"""A singular kernel for Jupyter"""

__version__ = '0.9'
