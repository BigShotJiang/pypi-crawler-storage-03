#!/usr/bin/env python3
"""rlottie-python"""

__version__ = "1.3.8"

from .rlottie_wrapper import LottieAnimation  # type: ignore # noqa: F401
from .rlottie_wrapper import LottieAnimationProperty  # type: ignore # noqa: F401
