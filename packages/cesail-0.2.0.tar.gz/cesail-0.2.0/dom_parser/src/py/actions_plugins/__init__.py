"""
Actions plugins package for DOM parser.
"""

from .base_action import BaseAction

__all__ = ['BaseAction'] 