"""Characterization tests for individual commands."""
