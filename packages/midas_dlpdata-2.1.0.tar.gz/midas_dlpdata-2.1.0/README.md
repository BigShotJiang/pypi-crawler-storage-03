# Midas Default Load Profiles Data Simulator

The *dlpdata* module, provided by the *midas-dlpdata* package, provides a simulator for the default load profiles provided by the BDEW set.

Version: 2.1

## Installation

This package will usually installed automatically together with `midas-mosaik`, if you opt-in the `bh` extra. 
It is available on pypi, so you can install it manually with

```bash
    pip install midas-dlpdata
```

## Usage

The intended use-case for the time simulator is to be used inside of midas.
However, it can be used in any mosaik simulation scenario.

### Inside of midas

To use the dlp data inside of midas, add `dlpdata` to your modules

```yaml
    my_scenario:
      modules:
        - dlpdata
        # - ...
```

and provide a *scope* and a configuration:

```yaml
    my_scenario:
      # ...
      dlp_data_params:
        my_scenario:
          meta_scaling: 1.5
          interpolate: True
          randomize_data: True
          randomize_cos_phi: True
          active_mapping:
          15: [[G4, 262.8]]
          17: [[H0, 1038.06]]
```

The numbers 15 and 17 stand for the bus number which depends on the used grid.

### Any Mosaik Scenario

If you don't use midas, you can add the `dlpdata` manually to your `mosaik scenario`_ file. 
First, the entry in the `sim_config`:

.. _`mosaik scenario`: https://mosaik.readthedocs.io/en/latest/tutorials/demo1.html

```python
    sim_config = {
        "DLPSimulator": {
          "python": "midas_powerseries.simulator:PowerSeriesSimulator"},
        # ...
    }
```

Next, you need to start the simulator (assuming a `step_size` of 900). 
Since it uses a custom data model, you have to specify it here:

```python
    dlpdata_sim = world.start(
        "DLPSimulator",
        step_size=900,
        model_import_str="midas_dlp.model:DLPModel",
        use_custom_time_series=True,
        start_date="2020-01-01 00:00:00+0100",
        data_path="/path/to/folder/where/dataset/is/located/",
        filename="bdew_default_load_profiles.csv",  # this is default
    )
```

Then the models can be started:

```python
    houshold = dlpdata_sim.CalculatedQTimeSeries(name="H0", scaling=1038.06)
    trade = dlpdata_sim.CalculatedQTimeSeries(name="G4", scaling=262.8)
```

Finally, the models need to be connected to other entities:

```python
    world.connect(trade, other_entity, "p_mw", "q_mvar")
```

## License

The data is taken from [BDEW](https://www.bdew.de/energie/standardlastprofile-strom/).
