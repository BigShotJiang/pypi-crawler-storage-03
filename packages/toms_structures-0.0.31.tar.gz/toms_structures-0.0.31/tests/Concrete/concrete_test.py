import pytest
import structures.Concrete.concrete as concrete

class TestConcrete:
    def test_works(self):
        x = concrete.OneWaySlab()