import math

import dataclasses

@dataclasses
class TimberConnection:
    pass