#!/usr/bin/env python3

"""Mesures d'Encodage et Décodage Vidéo."""

from .utils import Activity


__all__ = ["Activity"]
__author__ = "Robin RICHARD (robinechuca)"
__version__ = "0.2.1"  # pep 440
