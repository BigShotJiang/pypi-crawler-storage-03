# hjy-datamanager-v2

Hjy datamanager package version 2.0.0.

## Installation

```bash
pip install hjy-datamanager-v2
```

## Usage

```python
import hjy_datamanager_v2
print(hjy_datamanager_v2.__version__)
```
