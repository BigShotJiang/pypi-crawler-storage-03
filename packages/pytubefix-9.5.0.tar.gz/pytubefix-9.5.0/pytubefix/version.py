__version__ = "9.5.0"

if __name__ == "__main__":
    print(__version__)