"""
Kelly Criterion

Calculates the Kelly Criterion for a given set of odds and probabilities.
"""

from .criterion import criterion  # noqa

__all__ = [
    "criterion",
]
