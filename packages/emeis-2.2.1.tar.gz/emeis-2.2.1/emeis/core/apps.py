from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = "emeis.core"
    label = "emeis_core"
