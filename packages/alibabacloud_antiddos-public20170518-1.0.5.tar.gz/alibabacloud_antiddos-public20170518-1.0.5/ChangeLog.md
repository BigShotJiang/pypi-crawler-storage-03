2025-03-27 Version: 1.0.4
- Update API ModifyDefenseThreshold: add request parameters ClientToken.


2024-05-13 Version: 1.0.3
- Generated python 2017-05-18 for antiddos-public.

2022-07-12 Version: 1.0.2
- Automatically generate sdk tasks.

2021-12-09 Version: 1.0.1
- AMP version.

2020-12-29 Version: 1.0.0
- AMP Version Change.

