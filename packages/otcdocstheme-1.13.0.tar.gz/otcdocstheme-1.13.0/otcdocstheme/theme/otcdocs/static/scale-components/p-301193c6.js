import{h as n}from"./p-d52b3602.js";
/**
 * @license
 * Scale https://github.com/telekom/scale
 *
 * Copyright (c) 2021 Egor Kirpichev and contributors, Deutsche Telekom AG
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */const o=(o,s)=>"function"==typeof o?n("span",{innerHTML:o(),class:s}):"string"==typeof o?n("scale-icon",{name:o}):n(o.tag,Object.assign({},o.attributes));export{o as r}