# Import the central logger
from imagesorcery_mcp.logging_config import logger

logger.info("🪄 ImageSorcery MCP tools package initialized")
