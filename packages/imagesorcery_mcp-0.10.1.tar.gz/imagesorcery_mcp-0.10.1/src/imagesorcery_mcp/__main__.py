from imagesorcery_mcp.server import main

from .logging_config import logger

logger.info("🪄 ImageSorcery MCP server __main__ executed")

if __name__ == "__main__":
    main()
