"""ImageSorcery MCP - Powerful Image Processing Tools for AI Assistants"""

from .server import main, mcp

__all__ = ["main", "mcp"]
