#
# __init__.py
#
"""
Pyvider Namespace Package.

This file makes 'pyvider' a namespace package.
"""

# 🐍🔭


