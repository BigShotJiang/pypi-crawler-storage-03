"""
Examples for multi-browser-crawler package.
"""
