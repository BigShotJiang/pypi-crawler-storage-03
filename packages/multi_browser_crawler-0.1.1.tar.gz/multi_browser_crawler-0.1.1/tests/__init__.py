"""
Test suite for multi-browser-crawler package.
"""
