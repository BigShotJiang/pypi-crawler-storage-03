from ._view import MisfitPerRealView
