# pylint: disable=too-few-public-methods
class PluginIds:
    class ParaCorrGroups:
        GROUPNAME = "parameter-correlation-group"
        PARACORR = "paracorr"
