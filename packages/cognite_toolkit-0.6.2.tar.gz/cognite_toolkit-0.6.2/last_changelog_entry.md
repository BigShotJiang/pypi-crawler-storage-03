## cdf 

### Fixed

- [alpha] The commands `cdf migrate files/timeseries` no longer fails
with `TypeError` when upgrading the `cognite-sdk` to >=`7.78.1`.

## templates

No changes.