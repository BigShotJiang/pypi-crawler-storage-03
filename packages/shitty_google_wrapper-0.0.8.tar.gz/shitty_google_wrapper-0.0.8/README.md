A Python class to simplify interactions with Google Drive, Sheets, and Publisher APIs.
