from ..base import ASSETS

DEFAULT_SETTINGS = ASSETS.joinpath("default_settings")
