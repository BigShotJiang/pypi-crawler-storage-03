"""Common filenames for processes."""

METADATA_FILENAME = "metadata.json"
TEMPERATURES = "temperature.csv"
