"""Headers for time-related items."""

from .datatime import HEADER

TIME = "Time (seconds)"
TIME_DATETIME = f"Time ({HEADER})"
