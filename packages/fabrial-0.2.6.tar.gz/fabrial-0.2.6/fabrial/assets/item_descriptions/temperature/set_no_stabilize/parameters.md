- **{{ SETPOINT }}**

    The temperature to set the oven to.
