from ..base_widget import CategoryWidget


class FlowControlCategoryWidget(CategoryWidget):
    def __init__(self):
        CategoryWidget.__init__(self, "Flow Control")
