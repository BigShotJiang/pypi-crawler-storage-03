from typing import Final

DEFAULT_READ_EC_PRODUCT_HEADER: Final[bool] = False
DEFAULT_READ_EC_PRODUCT_MODIFY: Final[bool] = True
DEFAULT_READ_EC_PRODUCT_META: Final[bool] = True
