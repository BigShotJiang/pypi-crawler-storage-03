from ..utils._cli._parse._exceptions import InvalidInputError


class BadResponseError(Exception):
    pass
