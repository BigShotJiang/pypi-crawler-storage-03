cd ..
git add .
git commit -m "no_message"