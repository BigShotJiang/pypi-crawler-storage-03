# 1. Introduction

> Important: This specification describes an early iteration of the system and may not match the current Pitaya implementation. Some naming, defaults, and behaviors have evolved. For up-to-date usage and guidance, refer to the README and documentation.

## 1.1 Purpose and Goals

The Orchestrator enables parallel execution of AI coding agents to explore multiple solution paths simultaneously. When using AI for software development, outcomes vary significantly between runs - even with identical prompts. This tool leverages that variability as a strength, running multiple instances in parallel and implementing selection strategies to identify the best results.

Key goals:

- **Scale AI coding horizontally** - Run N instances of Claude Code (or similar tools) in parallel
- **Implement complex workflows** - Chain instances for review, scoring, and iterative refinement
- **Abstract infrastructure complexity** - Handle containerization, git operations, and state management transparently
- **Enable rapid experimentation** - Define sophisticated multi-stage strategies in ~50 lines of code
- **Maintain solution traceability** - Every task has a branch plan, and by default a branch is created whenever the agent produced commits. You can force a branch even with no changes via `import_policy="always"`.

The tool transforms single-threaded AI coding into a parallel, strategy-driven process where you can run approaches like "generate 5 implementations, have AI review each one, pick the best scoring result, then iterate on it with feedback" - all automated.

## 1.2 Core Concepts

**Instance** - A single isolated execution of an AI coding agent (Claude Code) with a specific prompt. Each instance runs in its own Docker container with a clean git workspace, producing commits in an isolated clone; the runner imports these commits as a new branch in the host repository.

**Strategy** - A composable execution pattern that coordinates multiple durable tasks via `ctx.run`. Strategies schedule tasks, wait for results, and make decisions (e.g., best‑of‑n selection, iterative refinement).

**RunnerResult** - The runner-level output from a completed task containing: branch artifact info, token usage, cost, execution time, and final message. Strategy-specific scoring/selection metadata lives in orchestration, not in runner results.

**TaskResult (public API)** - Exposed via canonical events (`task.*`, `strategy.*`). A separate typed "TaskResult" structure is not required beyond the canonical event schema. External consumers observe results through the event stream; internal orchestration uses an implementation type (e.g., `InstanceResult`).

**Orchestration Run** - A complete execution of the orchestrator with a chosen strategy. Identified by a unique run ID, it tracks all scheduled tasks, aggregate metrics, and final results.

**Event Stream** - Real-time runner events (internal) and canonical task/strategy events written by orchestration. The TUI consumes the public `task.*` and `strategy.*` events for monitoring.

**Branch-per-Task** - By default (`import_policy="auto"` with `skip_empty_import=true`), a task creates a branch named `orc/<strategy>/<run_id>/k{short8(qual_key)}` only if changes exist, enabling easy comparison and cherry-picking. With `import_policy="always"`, an empty branch is created pointing at the base. This hierarchical namespace supersedes the older flat pattern `{strategy}_{run_id}_k{short8(qual_key)}`.

Where `short8(y)` means the first 8 hex characters of `sha256(y)`, and `qual_key = f"{strategy_execution_id}|{durable_key}"` (durable key namespaced by the strategy execution). This prevents collisions when multiple strategy executions reuse the same durable key strings.

Default: branch only if there are commits. To always create a branch pointing to the base, set `import_policy="always"`.

Terminology: “Task” is the orchestration unit scheduled via `ctx.run`; each task is executed by a runner instance identified by `instance_id`. The TUI surfaces tasks; runner logs surface instances. Container labels carry `instance_id` for debugging, while public events and UI use task keys and `k{short8(qual_key)}` short hashes.

Shorthand: “k8” denotes `k{short8(qual_key)}` — the 8‑hex short of the fully‑qualified durable key.

## 1.3 Example Workflows

### Simple Parallel Exploration

```bash
orchestrator "implement user authentication with OAuth2" --strategy simple --runs 5
```

Schedules 5 strategy executions (each strategy schedules one task). Concurrency is still bounded by `max_parallel_instances`; excess tasks queue. Creates up to 5 branches with different implementations and displays real-time progress in TUI.

### Best-of-N (Inline Scoring)

```python
import json

# N-way generation with inline scoring and one repair attempt
async def best_of_n(prompt: str, base_branch: str, ctx):
    # Stage 1: Generate candidates
    gens = [
        ctx.run({"prompt": f"{prompt}", "base_branch": base_branch}, key=ctx.key("gen", i))
        for i in range(5)
    ]
    ok, failed = await ctx.wait_all(gens, tolerate_failures=True)

    # Stage 2: Score each successful candidate
    def try_parse(msg):
        try:
            data = json.loads(msg)
            return data if isinstance(data.get("score"), (int, float)) else None
        except Exception:
            return None

    scored = []
    for r in ok:
        # Select next base: use created branch when available; otherwise use base_branch
        bb = r["artifact"]["branch_final"] or base_branch
        review1 = await ctx.wait(
            ctx.run(
                {
                    "prompt": f"Return ONLY JSON {{score:0..10,rationale:string}} reviewing this result: {r['final_message']}",
                    "base_branch": bb,
                    "import_policy": "never",
                },
                # Note: For durable idempotency, use the generation handle's durable key
                # e.g., ctx.key("score", gen_key, "attempt-1"). Using instance_id here is illustrative only.
                key=ctx.key("score", r["instance_id"], "attempt-1")
            )
        )
        data = try_parse(review1["final_message"])  # try initial parse
        if data is None:
            review2 = await ctx.wait(
                ctx.run(
                    {"prompt": "Return ONLY JSON {score:0..10,rationale:string} reviewing this result again:\n"
                                f"{r['final_message']}",
                     "base_branch": bb, "import_policy": "never"},
                    # Use: ctx.key("score", gen_key, "attempt-2") for durable lineage
                    key=ctx.key("score", r["instance_id"], "attempt-2")
                )
            )
            data = try_parse(review2["final_message"])  # repair attempt
        if data is None:
            continue
        scored.append((data["score"], r))

    # Select max score among valid ones
    if not scored:
        raise ctx.errors.NoViableCandidates()
    return max(scored, key=lambda t: t[0])[1]
```

Note: Review/scoring tasks use `import_policy="never"` and, by default, a read‑only `/workspace`. Reviewers MUST write scratch output to `/tmp` or `/home/node`.

### Plan → Score → Implement

```python
import json

async def plan_score_implement(prompt: str, base_branch: str, ctx):
    # Stage 1: plans
    approaches = ["performance", "simplicity", "extensibility"]
    sgk = ctx.key("plan-bundle")  # share session volume across tasks in this flow
    plan_handles = [
        ctx.run({
            "prompt": f"Create a detailed plan for: {prompt} (focus: {a})",
            "base_branch": base_branch,
            "import_policy": "never",
            "session_group_key": sgk
        }, key=ctx.key("plan", a))
        for a in approaches
    ]
    plan_results = await ctx.wait_all(plan_handles)

    # Stage 2: score plans (with one repair attempt)
    def parse_json(msg):
        try:
            d = json.loads(msg)
            return d if isinstance(d.get("score"), (int, float)) else None
        except Exception:
            return None
    scored = []
    for p in plan_results:
        s1 = await ctx.wait(ctx.run({
            "prompt": "Return ONLY JSON {score:0..10,rationale:string} rating this plan:\n"
                      f"{p['final_message']}\nBe strict.",
            "base_branch": base_branch,
            "import_policy": "never"
        }, key=ctx.key("score-plan", p["instance_id"], "attempt-1")))
        data = parse_json(s1["final_message"]) 
        if not data:
            s2 = await ctx.wait(ctx.run({
                "prompt": "Your previous response did not match the schema. Return ONLY JSON {score:0..10,rationale:string} rating this plan again:\n"
                          f"{p['final_message']}",
                "base_branch": base_branch,
                "import_policy": "never"
            }, key=ctx.key("score-plan", p["instance_id"], "attempt-2")))
            data = parse_json(s2["final_message"]) 
        if data:
            scored.append((data["score"], p))

    if not scored:
        raise ctx.errors.NoViableCandidates()
    best_score, best_plan = max(scored, key=lambda t: t[0])

    # Stage 3: implement with session/branch resume
    # Select base: use created branch when available; otherwise use base branch
    impl_base = best_plan["artifact"]["branch_final"] or best_plan["artifact"]["base"]
    # Note: On resume, orchestration uses the latest persisted session id.
    return await ctx.wait(ctx.run({
        "prompt": f"Implement this plan with all details:\n{best_plan['final_message']}",
        "base_branch": impl_base,
        "resume_session_id": best_plan["session_id"],
        "session_group_key": sgk
    }, key=ctx.key("implement", "plan", best_plan["instance_id"])))
```

### Complex Multi-Stage Pipeline

Use the durable `ctx.run` primitive to compose multi-stage flows. See the examples above for Best‑of‑N and Plan → Score → Implement patterns.

### Resumable Long-Running Exploration

```bash
# Start massive exploration - runs 20 parallel strategies
orchestrator "build complete e-commerce backend" --strategy best-of-n --runs 20 -S n=5

# Ctrl+C after some strategies complete
# Resume from saved state - continues remaining strategies
orchestrator --resume run_20250114_123456
```

Each workflow produces branches in your repository, detailed logs, and a final summary with costs, tokens used, and execution times for informed decision-making.

## 1.4 Non-Goals

- Formal correctness proofs of fsync/clock behavior: out of scope. Instead, the system enforces a single durability invariant tying snapshots to fsynced events (see Event ↔ Snapshot Durability) and uses atomic snapshot renames.

## 1.5 Conventions and RFC Keywords

The key words MUST, MUST NOT, REQUIRED, SHALL, and SHALL NOT in this document are to be interpreted as described in RFC 2119 and RFC 8174 when, and only when, they appear in all capitals. Optional or configurable behavior is labeled explicitly.

## 1.6 UX Guardrails & Principles

- Smart defaults, fewer knobs: expose only options a typical developer will change; expert tuning stays in config files, not CLI flags.
- Two primary modes: Interactive TTY launches the TUI by default; non‑TTY/CI prints concise, colorless human logs; JSON is opt‑in via `--json`.
- Consistency: identifiers, ordering, and messages are consistent across TUI, streaming output, and logs. Public events (`task.*`, `strategy.*`) remain the single source of truth.

# 2. System Architecture

## 2.1 Three-Layer Design

The orchestrator implements strict separation of concerns through three independent layers, each with a single, well-defined responsibility:

**Instance Runner** - Executes individual AI coding instances in isolation. Knows nothing about strategies or UI. Provides a simple async function: give it a prompt and git repo, get back a result with a branch name. Handles all Docker lifecycle, git operations, and AI tool process management internally. Accepts orchestration-provided names and configurations (including run_id) as opaque identifiers without understanding their semantic purpose.

**Orchestration** - Coordinates multiple durable tasks according to strategies. Owns the event bus, manages parallel execution, and tracks global state. Depends only on Instance Runner's public API. Strategies schedule durable tasks with `ctx.run` and make decisions based on results. Provides branch names and container names to tasks.

**TUI (Interface)** - Displays real-time progress and results. Subscribes to orchestration events for real-time updates and periodically polls state for reconciliation. Has zero knowledge of how tasks run or how strategies work—it visualizes events and state only. The TUI is replaceable with other UIs or CLI-only output without changes to other layers.

Components are decoupled: replacing the TUI does not modify instance execution, and supporting alternative AI tools requires changing only the Instance Runner.

## 2.2 Event-Driven Communication

Components communicate through a simple event system that lives within the Orchestration layer:

```python
# Instance Runner emits events via callback
await run_instance(
    prompt="implement feature",
    event_callback=lambda e: orchestrator.ingest_runner_event(e)
)

# TUI subscribes to events it cares about
orchestrator.subscribe("task.started", update_display)
orchestrator.subscribe("task.completed", show_result)
```

Events flow unidirectionally upward:

- Instance Runner emits fine-grained events (git operations, tool usage, token updates)
- Orchestration writes strategy-level events (strategy.started, strategy.completed) and maps runner events to the public task lifecycle.
- TUI consumes events to update displays

Orchestration ingests runner events for live state and diagnostics, but ONLY canonical `task.*` and `strategy.*` events are written to `events.jsonl`. Runner events are routed to `runner.jsonl` (one line per `instance.*` event) and are not part of the public file contract. A single writer per run writes both files under `logs/<run_id>/`.

The event system uses append-only file storage (`events.jsonl`) with monotonic byte offsets for position tracking. A single writer task computes the `start_offset` (byte position before writing the line), appends the JSON line, and flushes using a fixed interval-based batching policy. The event records this `start_offset`. Clients request events from a specific `start_offset` when recovering after disconnection.

**Offset & Writer Semantics**

- Offsets are byte positions (not line counts). Readers MUST open in binary mode and advance offsets by the exact number of bytes consumed.
- Readers MUST align to newline boundaries: if an offset lands mid-line, scan forward to the next `\n` before parsing.
- Readers MUST tolerate a truncated final line (e.g., during a crash) by skipping it until a terminating newline appears.
- Writers MUST be single-process per run (single-writer model), emit UTF-8 JSON per line, and flush using a fixed interval-based batching policy. The event carries the `start_offset` (byte position before the record was written).
  The single-writer invariant is enforced by an OS lockfile `events.jsonl.lock` (see Event Log Contract below).
  (Implementation detail) The writer uses a small fixed batch size per flush to balance latency and throughput.
  Single durability invariant: `state.json.last_event_start_offset` MUST point to an event the writer has already fsynced. Snapshot persistence MUST never happen ahead of durable event fsync.

**Event Envelope**

- Public events in `events.jsonl`: `task.scheduled`, `task.started`, `task.progress`, `task.completed`, `task.failed`, `task.interrupted`, `strategy.started`, `strategy.completed`, and `strategy.rand`. See the “Minimum Payload Fields” section for the canonical schema and required payload fields. The public contract consists of `task.*` and `strategy.*`; the diagnostic `strategy.debug` is informational only and not part of the public contract.
- Envelope fields are authoritative for `ts`, `run_id`, and `strategy_execution_id`. Payloads MUST NOT duplicate these.
- Each event includes `{id, type, ts, run_id, strategy_execution_id, key?, start_offset, payload}`.
  - For `task.*` events, `key` is REQUIRED.
  - For `strategy.*` events, `key` is ABSENT.
  - `id` MUST be a UUIDv4 string; `ts` MUST be UTC ISO‑8601 with milliseconds and a trailing `Z` (e.g., `2025-08-16T12:34:56.789Z`).
  - `strategy_execution_id` MUST be a UUIDv4 generated once per strategy execution and persisted across resumes of that execution.
- `task.scheduled.payload` includes a stable `task_fingerprint_hash` used for audit/deduplication. Fingerprint = SHA‑256 of the JCS‑normalized (RFC 8785) JSON over the exact inputs that define execution semantics:
  - Object to hash (canonical input schema, normative):
    ```json
    {
      "schema_version": "1",
      "prompt": "...",
      "base_branch": "...",
      "model": "...",
      "import_policy": "auto|never|always",
      "import_conflict_policy": "fail|overwrite|suffix",
      "skip_empty_import": true,
      "session_group_key": "...",
      "resume_session_id": "...",
      "plugin_name": "...",
      "system_prompt": "...",
      "append_system_prompt": "...",
      
      "runner": {
        "container_cpu": 2,
        "container_memory": "4g",
        "network_egress": "online|offline|proxy"
      }
    }
    ```
  - Remove non‑semantic fields: drop `metadata` entirely
  - Before hashing, drop all keys whose value is `null`
  - Normalize defaults before hashing (see §6.1.1) and include `schema_version` to avoid spurious conflicts across releases
  - Compute the SHA‑256 over the UTF‑8 bytes of a canonical JSON representation.
    Canonicalization uses JSON with sorted keys, no extra whitespace, and consistent number formatting (JCS‑equivalent semantics).
  The engine MUST reject scheduling a task with the same key if the fingerprint differs from previously recorded history for that key (`KeyConflictDifferentFingerprint`). On resume, orchestration MUST reuse the previously stored normalized input when computing/validating fingerprints to avoid drift from default changes.
- Runner-specific events are not written to `events.jsonl` and instead go to `runner.jsonl`.

Components follow a strict communication pattern: downward direct calls (Orchestration → Runner) are allowed for control flow, while upward communication (Runner → Orchestration, any → TUI) happens primarily through events, with periodic state polling for reconciliation. The `subscribe()` function sets up file watching on `events.jsonl`, enabling capabilities like multiple processes monitoring the same run by tailing the event file or replaying events for debugging.

### Minimum Payload Fields

 Minimum payload fields per event type (MUST be present, alongside envelope fields `run_id`, `strategy_execution_id`, and `start_offset`):

- `task.scheduled`: `{ key, instance_id, container_name, model, task_fingerprint_hash }`
- `task.started`: `{ key, instance_id, container_name, model }`
- `task.progress`: `{ key, instance_id, phase, activity?, tool? }` where `phase` is an enum among `{workspace_preparing, container_creating, container_env_preparing, container_env_prepared, container_created, claude_starting, tool_use, assistant, system, result_collection, branch_imported, no_changes, cleanup}`. `activity` is an optional human-readable string; `tool` is the tool name when `phase=tool_use`.
- `task.completed`: `{ key, instance_id, artifact, metrics, final_message, final_message_truncated, final_message_path }`  # success only
  `final_message` is truncated when it exceeds a fixed byte budget. When truncated, `final_message_truncated=true` and `final_message_path` MUST be a run‑relative path under `logs/<run_id>/` (no absolute host paths) and is retained according to the events retention policy; otherwise `final_message_truncated=false` and `final_message_path` is empty. The budget is fixed at 65536 bytes.
- `task.failed`: `{ key, instance_id, error_type, message, network_egress? }` where `error_type ∈ { docker, api, network, git, timeout, session_corrupted, auth, unknown }` (closed set) and `network_egress` (optional) is one of `online|offline|proxy` when relevant.
- `task.interrupted`: `{ key, instance_id }`
- `strategy.started`: `{ name, params }`
- `strategy.completed`: `{ status, reason? }` where `status ∈ {"success","failed","canceled"}` and `reason` is an optional short summary for failed/canceled strategies.
- `strategy.rand`: `{ seq, value }` where `seq` is a monotonically increasing integer per strategy execution, and `value` is a float in [0,1).

 Implementations MAY include additional non‑normative payload fields for recovery and diagnostics as long as they do not duplicate envelope fields. For example, `task.scheduled` may include `base_branch` to facilitate robust recovery when replaying events without a recent snapshot.

### Strategy Status Semantics

- `success`: At least one scheduled child task for the strategy execution completed with status `success`.
- `failed`: All scheduled child tasks reached terminal states and none succeeded (i.e., all `failed` or `interrupted`).
- `canceled`: The run was explicitly stopped by the user before any child task reached `success`.

Note: `interrupted` is not success; success requires at least one `task.completed` with `status="success"`.

TUI and summaries MUST use the same criteria to avoid ambiguity.

### Event Log Contract

- Exactly one writer per run: enforced by `logs/<run_id>/events.jsonl.lock` held for the run duration (OS-level exclusive lock).
- Writer computes `start_offset` as the byte position before writing each line, appends UTF‑8 JSON + `\n`, and flushes at a small fixed interval.
- Truncated last line rule: readers MUST skip any unterminated last line until a newline appears.
- Snapshots (`state.json`) persist a durable offset reference: the `start_offset` of the last applied event (`last_event_start_offset`). On recovery, readers resume from this position.
- Timestamp queries: `get_events_since(ts)` MUST locate the first event with `ts ≥ T` (by scanning or index) and return from that event’s `start_offset` to avoid partial-line reads. If `ts` refers to an event that was written but not yet fsynced (writer crash window), readers MUST start from the last durable `start_offset` ≤ that event. Snapshots (`state.json.last_event_start_offset`) MUST reference only fsynced offsets.
- Sanitization: Before writing any record to `events.jsonl`, orchestration MUST pass the entire event object (envelope + payload) through the recursive sanitizer to redact secrets.

## 2.3 Data Flow

The system follows a clear request/response + event stream pattern:

**Downward Flow (Requests)**

1. User provides prompt and strategy selection via CLI
2. TUI passes request to Orchestration
3. Orchestration interprets the strategy and schedules durable tasks via the runner API
4. Runner executes Claude Code in containers

**Upward Flow (Results + Events)**

1. Claude Code outputs structured logs in JSON format
2. Runner parses logs, emits runner-level events, collects results
3. Orchestration aggregates results, makes strategy decisions, emits higher-level events
4. TUI receives events and displays progress

**State Queries**

- TUI queries Orchestration for current state snapshots
- Orchestration maintains authoritative state derived from events
- No component stores UI state - everything derives from event stream

This unidirectional flow prevents circular dependencies and makes the system predictable. Each layer exposes a narrow API to the layer above it, maintaining clear boundaries and separation of concerns.

## 2.4 Technology Choices

**Python 3.13** - Requires Python 3.13. Modern async performance and improved error messages. Type hints enable clear interfaces between components. Rich ecosystem for required functionality.

**asyncio** - Natural fit for I/O-bound operations (Docker commands, git operations, API calls). Enables high concurrency for managing hundreds of container operations and git commands without thread complexity. Built-in primitives for coordination (locks, queues, events).

**docker-py 7.1.0** - Python library for Docker container management. Provides programmatic control over container lifecycle, resource limits, and cleanup. Supports Docker daemon 20.10+.

**Local Docker image** - The runner uses a local image named `claude-code`. Build it from this repo: `docker build -t claude-code .`.

**uv** - Lightning-fast Python package and project manager. Replaces pip, pip-tools, pipenv, poetry, and virtualenv with a single tool. Near-instant dependency resolution and project setup. Written in Rust for performance. Use the latest stable uv; dependency versions are pinned via `uv.lock` for reproducibility.

**Git** - Natural version control for code outputs. Branch-per-task model enables easy comparison. Local operations are fast and reliable. Universal developer familiarity.

**Rich 14.0.0** - Modern terminal UI capabilities with responsive layouts. Live updating without flicker. Built-in tables, progress bars, and syntax highlighting.

**Structured JSON output** - Claude Code outputs structured JSON logs that enable real-time parsing of agent actions. Provides detailed metrics and session IDs for resume capability.

**No database** - Event sourcing with file-based persistence. Reduces operational complexity. State rebuilds from event log. Git itself acts as the "database" for code outputs.

**No message queue** - Simple file-based event system suffices for single-machine operation. Append-only `events.jsonl` with offset tracking enables multi-process monitoring. Direct callback pattern reduces latency.

Pinning explicit versions avoids drift, and uv simplifies Python project management.

# 3. Instance Runner Component

## 3.1 Overview and Responsibilities

The Instance Runner is the atomic unit of execution - it runs exactly one AI coding instance in complete isolation and returns the result. This is the only component that directly interfaces with Docker, Git, and Claude Code. Its responsibility is singular: given a prompt and repository, reliably produce a git branch containing the AI's solution.

Core responsibilities:

- Spawn and manage Docker containers with proper resource limits
- Create isolated git clones and manage branch operations
- Execute Claude Code with correct parameters and parse its output
- Stream events upward via callbacks without knowing what consumes them
- Manage container lifecycle for resumability
- Track metrics (tokens, cost, duration) from execution

The Runner knows nothing about strategies, parallel execution, or UI. It accepts configuration from orchestration (branch names, container names) without understanding their purpose or conventions. This isolation enables swapping Claude Code for other AI tools or changing container runtimes without touching the rest of the system.

## 3.2 Public API

The Runner exposes a single async function `run_instance()` that accepts:

- **prompt**: The instruction for Claude Code
- **repo_path**: Path to host repository (not the isolated clone)
- **base_branch**: Starting point for the new branch (default: "main")
- **branch_name**: Target branch name for import (provided by orchestration)
- **run_id**: Run identifier for correlation (provided by orchestration)
- **strategy_execution_id**: Strategy execution identifier (provided by orchestration)
- **strategy_index**: 1-based index of the strategy execution within the run (optional; used for container labels/UX)
- **instance_id**: Opaque 16‑hex string provided by orchestration; stable within a run across retries/resumes. The derivation is normative in Orchestration and not part of the Runner’s contract.
- **task_key**: Durable key for this task (for labeling/reattach; opaque to runner)
- **container_name**: Full container name including run_id (provided by orchestration)
- **model**: Claude model to use (default: "sonnet")
  Accepted examples: `sonnet`, `haiku`, `opus`. Orchestration maps these friendly names to the tool’s concrete model IDs and validates them at run start; unknown names MUST fail fast in orchestration before any tasks are scheduled.
  Runner assumes model names are pre‑validated by orchestration, and it MUST defensively validate against its configured allowed models; unknown values are a fast failure.
- **session_id**: Resume a previous Claude Code session
  Mapping: the strategy/task input field `resume_session_id` maps directly to this runner parameter `session_id`.
  
Task vs instance: The orchestration schedules tasks; the runner executes each task as an instance. `instance_id` uniquely identifies the runner instance executing a task and is surfaced in container labels and runner logs.
- **session_group_key**: Optional key to group tasks that share the same persistent session volume; defaults to the task key if not provided
- **event_callback**: Function to receive real-time events
- **timeout_seconds**: Maximum execution time (default: 3600).
- **container_cpu**: CPU cores for the container
- **container_memory_gb**: Memory limit in GiB (integer)
- **network_egress**: `online|offline|proxy` (default: `online`); controls Docker networking mode
- **auth_config**: Authentication configuration (OAuth token or API key)
- **reuse_container**: Reuse existing container if name matches (default: True)
- **finalize**: Stop container after completion (default: True)
- **retry_config**: Retry configuration with pattern-based error matching
- **docker_image**: Custom Docker image to use (default: from config)
- **plugin_name**: AI tool plugin to use (default: "claude-code")
- **system_prompt**: System prompt to prepend to Claude's instructions
- **append_system_prompt**: Additional system prompt to append
- **import_policy**: "auto" | "never" | "always" (default: "auto")
- **import_conflict_policy**: "fail" | "overwrite" | "suffix" (default: "fail")
- **skip_empty_import**: Whether to skip import when no changes (default: True)

Returns `RunnerResult` (a superset of `TaskResult`) containing:

- `artifact` object mapping to the orchestration-facing shape:
  - `artifact.branch_planned`: deterministic name provided by orchestration
  - `artifact.branch_final`: actual branch created or `null` if no import
  - `artifact.base`: base branch name used for the workspace
  - `artifact.commit`: tip commit of the artifact; equals `BASE_COMMIT` when no import
  - `artifact.has_changes`: `true` when commits exist relative to base
  - `artifact.duplicate_of_branch` (optional): name of existing branch used due to idempotency/dedupe; `null` otherwise
  - `artifact.dedupe_reason` (optional): one of `"same_task_provenance" | "crash_window" | "by_commit" | "by_commit_no_changes" | null`
- Execution metrics: `metrics.cost_usd`, `metrics.tokens_in`, `metrics.tokens_out`, `metrics.duration_s`
- Session ID for resume capability
- Final message from Claude
- Status (success/failed/timeout/interrupted)
- Container details and identifiers
- Timestamps (started_at, completed_at)
- Number of retry attempts
- Path to detailed logs (runner.jsonl)
- Workspace path (until cleanup; not exposed in public events)
- Error information if failed

`TaskResult` is the stable subset exposed to strategies (artifact, metrics, final_message, session_id, instance_id, status). Orchestration MUST drop runner‑only fields when emitting `task.completed` public events and when persisting strategy‑facing results.

The API is designed for both simple usage (`await run_instance("fix bug", repo)`) and advanced control when needed. The runner remains agnostic about why the container is named a certain way or how branches are named - it simply uses what orchestration provides. This separation keeps the runner generic and testable.

## 3.3 Execution Pipeline

The runner follows six strict phases ensuring consistent execution and proper cleanup:

1. **Validation** - Verify Docker daemon, repository exists, validate provided container_name, check disk space
2. **Workspace Preparation** - Create isolated git clone in temporary directory BEFORE container creation. This ensures the workspace is ready when the container starts
3. **Container Creation** - If `reuse_container=True` and container exists, reuse it. Otherwise, start new container with provided name and resource limits, mount the pre-prepared workspace. Container runs with `sleep infinity` for persistence
4. **Claude Code Execution** - Execute via `docker exec` with structured JSON output, parse events
5. **Result Collection** - Extract metrics, and (if `import_policy` is `auto` or `always`) import branch from workspace to host repository as the final step. Before any import, the runner MUST perform an idempotent pre-check (compare workspace HEAD to existing branch HEAD) and treat exact matches as already imported to avoid duplicates across the crash window. Orchestration emits `task.completed` only after the runner finishes and import (per policy) succeeds; for `auto` with zero changes, import is skipped and the task completes with `artifact.has_changes=false`.
6. **Cleanup Decision** - For successful instances: delete workspace immediately. If `finalize=True`, stop the container (retained for 2h). If `finalize=False`, leave the container running (see persistence semantics below). For failed instances: keep both workspace and container for 24h debugging

Each phase emits structured events for observability. The pipeline is designed for resumability - if execution fails at phase 4, a retry can resume from that point using the session_id without repeating setup.

Key architectural boundaries:

- Runner receives container names from orchestration (the runner does not generate IDs)
- Git isolation happens through separate clones, not shared mounts
- Each instance works in complete isolation

The runner executes these phases mechanically without interpreting orchestration semantics. It follows the contract defined by orchestration.

## 3.4 Docker Management

Containers follow a careful lifecycle designed to provide complete isolation while preserving Claude Code sessions for resumability:

**Container Creation**: Uses the container name provided by orchestration, ensuring consistent naming across the system. The runner treats run_id and other identifiers as opaque values provided by orchestration. Each container represents one isolated AI coding instance.

**Pre-Container Setup**: Before starting any container, the Instance Runner prepares an isolated workspace:

```bash
# Create temporary directory for this task (key-derived)
# Note: Orchestration computes short hashes cross-platform (Python), not via shell utilities.
# Provided environment vars:
#   TASK_KEY              # durable task key (fully qualified)
#   SESSION_GROUP_KEY     # optional session group key; defaults to TASK_KEY
#   KHASH                 # short8(TASK_KEY) = first 8 hex of SHA-256
#   GHASH                 # per §3.5 GHASH (run/global scope)

WORKSPACE_DIR="/tmp/orchestrator/${run_id}/k_${KHASH}"
mkdir -p "$WORKSPACE_DIR"

# Clone the specific branch in isolation (handled by git operations)
# ... git clone happens here ...
```

**Volume Mounts**: Three mounts required for proper operation:

```
/tmp/orchestrator/<run-id>/k_<hash(key)> → /workspace
orc_home_<run_id>_s<strategy_index>_g{GHASH} → /home/node
tmpfs → /tmp
```

Platform-specific mount handling ensures compatibility. The named volume (pattern: `orc_home_{run_id}_s{strategy_index}_g{GHASH}`) provides persistent storage for Claude Code's session data, ensuring sessions survive container restarts and enabling cross-task continuity when the same session group key is used. Names are per strategy execution to avoid copy-up races. Note: The implementation uses `/home/node` due to the base Docker image using the `node` user.

`GHASH`:
  • Run scope (default): `GHASH = short8( sha256( JCS({"session_group_key": EFFECTIVE_SGK}) ) )`, where `EFFECTIVE_SGK = session_group_key if provided else durable task key`. Namespacing is provided by the run-scoped volume name `orc_home_{run_id}_g{GHASH}`.
  • Global scope: `GHASH = short8( sha256( JCS({"session_group_key": "...", "plugin": "...", "model": "..."}) ) )` to avoid cross‑tool contamination. Here, `model` is the resolved concrete model ID (not a friendly alias from `models.yaml`).
In global scope (when explicitly enabled), the named volume omits the `run_id` prefix and uses only `GHASH`. Global scope is advanced and requires `--allow-global-session-volume`.
Runner MUST set these variables inside the container environment.

**Container Execution**: Containers run with these security constraints:

```bash
# Compute mount flags for workspace; apply SELinux and read-only for reviews
mount_flags=""
if [[ "$(uname)" == "Linux" ]] && [[ -e /sys/fs/selinux ]]; then
  mount_flags=":z"
fi
if [ "${import_policy:-auto}" = "never" ]; then
  if [[ "$mount_flags" == ":z" ]]; then
    mount_flags=":ro,z"
  else
    mount_flags=":ro"
  fi
fi

docker run \
  -v "$WORKSPACE_DIR:/workspace${mount_flags}" \
  --mount "type=volume,source=orc_home_${run_id}_s${SIDX}_g${GHASH},target=/home/node" \
  --tmpfs /tmp:rw,size=512m \  # Writable temporary space (fixed)
  --read-only \                     # Entire filesystem read-only except mounts
  --name "$container_name" \
  --cpus="2" \
  --memory="4g" \
  --label "orchestrator=true" \
  --label "run_id=${run_id}" \
  --label "strategy_execution_id=${strategy_execution_id}" \
  --label "strategy_index=${strategy_index}" \
  --label "task_key=${TASK_KEY}" \
  --label "session_group_key=${SESSION_GROUP_KEY:-$TASK_KEY}" \
  --label "instance_id=${instance_id}" \
  claude-code \
  sleep infinity                    # Keep container running for exec
```

The `--read-only` flag locks down the entire container filesystem except for explicitly mounted volumes. Containers have access to exactly three locations: `/workspace` (isolated git clone), `/home/node` (session state), and `/tmp` (temporary files). The `sleep infinity` command keeps the container running, allowing subsequent `docker exec` commands to run Claude Code. Mount flags include `:z` on SELinux systems and `:ro` when `import_policy="never"`.

Writable mounts: `/home/node` is a writable named volume that persists across container restarts and is used for session state. `/tmp` is a writable tmpfs. The container root filesystem remains read‑only.

When a task declares `import_policy="never"`, the runner MUST mount the `/workspace` path as read-only. If `reuse_container=True` would prevent a read-only remount, the runner MUST start a fresh container (ignoring `reuse_container`) to honor read-only. Review/scoring tasks write only to `/tmp` and `/home/node`. Attempted writes to `/workspace` MUST error fast with a clear message. Plugins write scratch output to `/tmp` in strict RO mode.

Hardening requirements:

- Capabilities: containers MUST drop all capabilities (`--cap-drop ALL`) and run with `--security-opt no-new-privileges` and the default Docker seccomp profile (or stricter if available).
- Process/resource limits: containers MUST set a `--pids-limit` and strict `--ulimit nofile` to prevent resource exhaustion. Sensible defaults should be applied and remain configurable.
- Mount policy: exactly three mounts are permitted (`/workspace`, `/home/node`, `/tmp`). The runner MUST prevent mounting host paths other than these and MUST reject any attempt to mount the Docker socket or other host device/special files.
 

**Container Reuse**: When `reuse_container=True`:

- If a container exists and is running: Execute Claude Code in the existing container
- If a container exists but is stopped: Start the container, then execute
- If no container exists: Create a new container as above

**Runner Decision Tree**:

1. If `import_policy="never"`, **force** RO `/workspace`.
2. If a container exists but cannot be remounted read-only, **replace** it (same name, same session volume) and log `runner.container.replaced`.

Priority order when constraints conflict:

1. Safety — enforce read-only `/workspace` for `import_policy="never"`
2. Session continuity — reuse the same session volume via `session_group_key`
3. Container reuse — reuse an existing container if it does not violate (1)

If (1) and (3) conflict, the runner MUST stop and remove the existing container and create a fresh one with the same deterministic `container_name`, attached to the same session volume, to satisfy read-only.

Container replacement protocol: To honor mount mode changes (e.g., switching to read‑only for review tasks), the runner MUST stop and remove the existing container and re-create a new one with the same `container_name` and the same session volume. The new container MUST apply current task labels (`run_id`, `strategy_execution_id`, `task_key`, `instance_id`). Emit a runner‑internal event `runner.container.replaced` with `{ old_id, new_id, reason: "ro_required" }`. Public `task.*` events are unaffected. Retention timers apply to the latest active container; replaced containers are not retained.

**Container Persistence**: Containers are kept after execution to enable Claude Code session resume (subject to global retention caps and on‑run GC/backpressure policies):

- Failed/timeout instances: Retained for 24 hours (configurable)
- Successful instances with `finalize=True`: Container is stopped (not removed) after successful completion and retained for 2 hours (configurable)
- Successful instances with `finalize=False`: Container continues running until explicitly stopped by the operator or via an orchestration cleanup command; there is no implicit auto‑stop

This persistence is crucial because Claude Code maintains session state inside the container. If an instance times out after partial work, the session is resumed by using the same container with the preserved session. The orchestrator does not auto‑stop non‑finalized containers by default; operators manage them explicitly. When the runner deletes the workspace, it MUST first fsync its own `runner.jsonl` completion record; public events MUST NOT include host workspace paths.

**Network Egress**:

- `online` (default): standard Docker networking; outbound internet allowed.
- `offline`: containers MUST run with `--network none`. Strategies MUST NOT request `offline` unless explicitly configured by the user/environment.
- `proxy`: outbound traffic routed via a configured proxy; credentials MUST never be logged. Configuration precedence: CLI flags override environment, which override config.

Failure classification for offline runs: if a task runs with `offline` and fails due to blocked egress, classify as `error_type="network"`, set `network_egress="offline"` in the payload, and include `egress=offline` in the human message for clarity.

**Session Groups**: To maintain session continuity across multiple tasks (e.g., plan → implement → refine), strategies supply a `session_group_key` in `ctx.run`. Containers and the `/home/node` named volume are keyed by this group (default = the task key). Passing the same `session_group_key` for related tasks ensures they share the same session volume; passing a different key isolates sessions. By default, volumes are run‑scoped and MUST be unique per strategy execution to avoid Docker's copy-up race when multiple containers mount the same named volume concurrently. A global scope is available but requires explicit `--allow-global-session-volume` consent.

Global scope naming: `orc_home_g{GHASH}`.

Session group hashing:

- Run scope (default): `GHASH = short8(sha256(JCS({"session_group_key": EFFECTIVE_SGK})))` and the home volume name is `orc_home_{run_id}_s{strategy_index}_g{GHASH}`.
- Global scope: requires `--allow-global-session-volume`; `GHASH = short8(sha256(JCS({"session_group_key": EFFECTIVE_SGK, "plugin": PLUGIN, "model": MODEL})))` and the home volume name is `orc_home_g{GHASH}`.

**Resource Limits**: Each container gets configurable CPU/memory limits with sensible defaults:

- CPUs: 2 (prevents CPU starvation of parallel instances)
- Memory: 4GB (sufficient for most coding tasks)
- No disk quotas (workspace size limited by temporary directory)

These limits prevent runaway instances from affecting system stability while providing enough resources for complex coding tasks.

**Post-Container Cleanup**: After the container completes and branches are successfully imported:

```bash
# For successful instances - immediate workspace cleanup
if [ "$status" = "success" ]; then
    rm -rf "$WORKSPACE_DIR"  # Remove isolated clone immediately
    # Respect finalize: stop container only when finalize=true
    if [ "$finalize" = "true" ]; then
        docker stop "$container_name"  # Stop but retain container for 2h
    fi
fi
# Failed instances keep both workspace and container for 24h debugging
```

**Orphan Cleanup**: Removed. Orchestration owns scanning and cleanup of orphan containers by run namespace (see §4.10). The Runner only cleans up its current container and workspace on task failure.

**Image Structure**: The custom Docker image includes:

- Claude Code CLI with all dependencies
- Git and essential development tools
- Python, Node.js, and common runtimes
- Non-root user configuration per Claude Code requirements
- Minimal size while supporting typical development scenarios

**Environment Configuration**: Each container receives base configuration plus authentication:

```yaml
environment:
  - GIT_AUTHOR_NAME="AI Agent"
  - GIT_AUTHOR_EMAIL="agent@orchestrator.local"
  - GIT_COMMITTER_NAME="AI Agent"
  - GIT_COMMITTER_EMAIL="agent@orchestrator.local"
  - PYTHONUNBUFFERED="1"
  # Plus authentication based on auth_config:
  # For subscription mode:
  - CLAUDE_CODE_OAUTH_TOKEN="${oauth_token}"
  # For API mode:
  - ANTHROPIC_API_KEY="${api_key}"
  - ANTHROPIC_BASE_URL="${base_url}"  # if provided
```

Session resumption is handled via Claude Code's `--resume` CLI flag with the session_id.

**Container Status Tracking**: Container labels are set at creation time and are not updated at runtime. The authoritative status lives in orchestration state and public events. The runner writes a heartbeat file inside the persistent session volume at `/home/node/.orc/last_active` (ISO‑8601 UTC), updating at least every 15 seconds while active. Orchestration also maintains `last_active_ts` in `state.json`. Cleanup/retention considers, in order: (1) timestamps in `state.json`, (2) the heartbeat file’s mtime, (3) Docker `CreatedAt` when neither is available.

The Docker management layer remains agnostic about orchestration strategies or git workflows. It simply provides isolated execution environments with proper resource controls and session preservation. The true isolation comes from each container working with its own complete git repository, with no possibility of cross-contamination between instances or with the host system.

## 3.5 Container Environment

Runner MUST set the following environment variables inside the container for observability and correlation:

- `TASK_KEY`: Durable task key used by orchestration
- `SESSION_GROUP_KEY`: Session group key used to scope the home volume
- `KHASH`: `short8(sha256(task_key))` or empty when unavailable

Note: `KHASH` is derived from the durable task key and can differ from the UI shorthand `k8 = short8(qual_key)`. Do not use `KHASH` to match UI identifiers.
- `GHASH`: `short8(sha256(session_group_key or fallback))`

On Linux with SELinux enabled, the workspace bind mount MUST be labeled with `:z` (and `:z,ro` when review workspace mode is read-only). The home directory MUST be a named Docker volume scoped as documented (per-run by default).

## 3.6 Git Operations

Git operations use an isolation strategy that provides complete separation between parallel instances while maintaining efficiency. Each AI agent works in complete isolation, seeing only the branch it needs to modify, without the possibility of interfering with other instances or accessing the host repository.

**The Isolation Strategy**: Before starting each container, the Instance Runner creates a completely isolated git repository on the host:

Note: Shell snippets in this section are illustrative. The reference implementation performs these steps in Python for cross‑platform portability (Linux/macOS/Windows/WSL2), avoiding dependencies on non‑portable shell tools.

```bash
# On the host, before container starts
git clone --branch <base-branch> --single-branch --no-hardlinks \
          /path/to/host/repo /tmp/orchestrator/${run_id}/k_${KHASH}
cd /tmp/orchestrator/${run_id}/k_${KHASH}
git remote remove origin        # Complete disconnection from source
# Store base branch reference
echo "<base-branch>" > .git/BASE_BRANCH
git rev-parse HEAD > .git/BASE_COMMIT
```

Let's break down why each flag matters:

- `--branch <base-branch> --single-branch` ensures the clone contains only the target branch. No other refs exist in `.git/refs/heads/`; the agent has no visibility into other branches.
- `--no-hardlinks` forces Git to physically copy all object files instead of using filesystem hardlinks. This prevents any inode-level crosstalk between repositories - critical for true isolation
- `git remote remove origin` completes the isolation. With no remote configured, pushing to a remote is impossible.
- Store the base branch reference to preserve traceability of change origin

**Isolation Mode**:

- `full_copy` only: The runner MUST clone with `--no-hardlinks --single-branch` and MUST remove any remotes. The runner MUST NOT configure alternates, partial clone, or shared objects.

**Agent Commits**: The AI agent works directly on the base branch in its isolated clone. It does not create new branches; it commits changes to the single available branch. This simplifies the agent's task and ensures predictable behavior.

**Protected refs and branch validation**:

- Protected ref denylist: `main`, `master`, `develop`, `release/*`, `stable`, `hotfix/*`, and any pattern configured under `git.protected_refs`. The runner MUST refuse ref updates to protected refs unless `--allow-overwrite-protected-refs` is explicitly set at the CLI or config level. This applies even when `import_conflict_policy="overwrite"`.
- Reserved namespace: Target branches generated by orchestration MUST live under an orchestrator-owned hierarchical namespace derived from the durable key, using the pattern `orc/<strategy>/<run_id>/k{short8(qual_key)}`, and MUST NOT collide with protected refs. This supersedes the older flat pattern `{strategy}_{run_id}_k{short8(qual_key)}`. The `orc/` prefix is reserved for the orchestrator; user-created branches MUST NOT use this namespace to avoid collisions with orchestrator-managed refs.
- Scope: This namespace requirement applies to local branches (`refs/heads/*`). Tags and remotes are out of scope for this specification.
 - Recommendation: When pushing to remotes, mirror the local hierarchical path (`orc/<strategy>/<run_id>/k{short8}`) to avoid ambiguity across environments and CI.
- Branch name validation: Orchestration MUST validate `branch_name` against a strict regex (e.g., `^[A-Za-z0-9._\-\/]{1,200}$`) and reject names with forbidden segments (`..`, `.lock`, `@{`, trailing `/`, leading `-`). The total branch name length MUST be ≤200 characters for the `refs/heads/<branch_name>` path excluding the `refs/heads/` prefix. Rationale: path safety and compatibility with common tooling. Invalid names MUST fail scheduling before a runner starts with a clear message, e.g., `invalid branch name orc/bestofn/run_20250114_123456/k1234abcd (201 chars; max 200)`. Confirmed worst‑case `run_id` length fits under this limit when combined with the hierarchical prefix.

**Container Workspace**: Each container receives its isolated clone as a volume mount:

```bash
# Compute mount flags for workspace; apply SELinux and read-only for reviews
mount_flags=""
if [[ "$(uname)" == "Linux" ]] && [[ -e /sys/fs/selinux ]]; then
  mount_flags=":z"
fi
if [ "${import_policy:-auto}" = "never" ]; then
  if [[ "$mount_flags" == ":z" ]]; then
    mount_flags=":ro,z"
  else
    mount_flags=":ro"
  fi
fi

docker run \
  -v /tmp/orchestrator/${run_id}/k_${KHASH}:/workspace${mount_flags} \
  --read-only \
  --name ${container_name} \
  claude-code
```

Apply the SELinux flag only on Linux systems with SELinux enabled. The `--read-only` flag locks down everything except the mounted volumes. The container MUST modify only its isolated git repository.

Note: This minimal example omits the `/home/node` named volume and `/tmp` tmpfs shown in 3.5; those mounts are required in the full runner configuration.

Reviewer scratch space: For review/scoring tasks using `import_policy="never"`, tools MUST write any temporary files to `/tmp` or `/home/node` and MUST NOT write to `/workspace`.

**Branch Import After Completion**: After the container exits, as the final step of `run_instance()`, Git fetch from a local filesystem path is used instead of push coordination:

```bash
# After container exits, back on the host
cd /path/to/host/repo

# Acquire per-repo import lock to serialize ref/pack updates
# (Cross-platform, process-internal lock implemented by the runner
# using fcntl/msvcrt/portalocker; do not rely on shell flock.)

# Idempotent import pre-check (handles crash window)
# (Illustrative shell; reference implementation performs these checks in Python under the process-level lock.)
if git show-ref --verify --quiet "refs/heads/${branch_name}"; then
  WS_HEAD=$(git --git-dir="/tmp/orchestrator/${run_id}/k_${KHASH}/.git" rev-parse HEAD)
  BR_HEAD=$(git rev-parse "refs/heads/${branch_name}")
  if [ "$WS_HEAD" = "$BR_HEAD" ]; then
    echo "Branch already matches workspace HEAD; treating as completed."
    # Return success to orchestration; it will emit task.completed
    exit 0
  fi
fi

### Provenance-Based Suffix Idempotency
if [ "${import_conflict_policy:-fail}" = "suffix" ] && ! git show-ref --verify --quiet "refs/heads/${branch_name}"; then
  WS_HEAD=$(git --git-dir="/tmp/orchestrator/${run_id}/k_${KHASH}/.git" rev-parse HEAD)
  CANDIDATE=$(git for-each-ref --format='%(refname:short) %(objectname)' refs/heads \
    | awk -v base="${branch_name}" -v head="$WS_HEAD" 'match($1, "^" base "(_[0-9]+)?$") && $2==head {print $1; exit}')
  if [ -n "$CANDIDATE" ]; then
    if git notes --ref=orchestrator show "$WS_HEAD" 2>/dev/null | grep -q "task_key=${TASK_KEY}"; then
      echo "Found existing suffixed branch $CANDIDATE with matching HEAD + provenance; treating as completed."
      exit 0
    fi
  fi
fi

# Determine target branch honoring import_conflict_policy
TARGET_BRANCH="${branch_name}"
if git show-ref --verify --quiet "refs/heads/${TARGET_BRANCH}"; then
  case "${import_conflict_policy:-fail}" in
    fail)
      echo "Error: Branch ${TARGET_BRANCH} already exists" >&2; exit 1 ;;
    overwrite)
      # Only allow forced updates for non-protected refs
      if printf "%s\n" "${TARGET_BRANCH}" | grep -Eq '^(main|master|develop|stable|release\/|hotfix\/)' ; then
        echo "Error: overwrite of protected ref ${TARGET_BRANCH} requires --allow-overwrite-protected-refs" >&2; exit 1
      fi
      : # proceed; fetch will move ref (forced update)
      ;;
    suffix)
      i=2
      while git show-ref --verify --quiet "refs/heads/${TARGET_BRANCH}_${i}"; do i=$((i+1)); done
      TARGET_BRANCH="${TARGET_BRANCH}_${i}"
      ;;
  esac
fi

# Skip empty imports if enabled (no commits relative to base)
BASE_BRANCH=$(cat /tmp/orchestrator/${run_id}/k_${KHASH}/.git/BASE_BRANCH)
if [ "${import_policy:-auto}" = "never" ]; then
  echo "Import policy is 'never'; skipping branch import"
  exit 0
fi

if [ "${skip_empty_import:-true}" = "true" ] && [ "${import_policy:-auto}" != "always" ]; then
  BASE_COMMIT=$(cat /tmp/orchestrator/${run_id}/k_${KHASH}/.git/BASE_COMMIT)
  COUNT=$(git --git-dir="/tmp/orchestrator/${run_id}/k_${KHASH}/.git" rev-list --count "${BASE_COMMIT}..HEAD" || echo 0)
  if [ "$COUNT" = "0" ]; then
    echo "No changes; skipping branch creation for ${TARGET_BRANCH}"
    # Caller records artifact.has_changes=false and planned branch name
    exit 0
  fi
fi

# Import from the base branch to new (or suffixed) branch name
if [ "${import_conflict_policy:-fail}" = "overwrite" ]; then
  git fetch /tmp/orchestrator/${run_id}/k_${KHASH} +HEAD:${TARGET_BRANCH}
else
  git fetch /tmp/orchestrator/${run_id}/k_${KHASH} HEAD:${TARGET_BRANCH}
fi
```

This import operation:

- Copies all new commits and their associated blobs/trees
- Creates the branch atomically in the host repository
- Requires no network operations or remote configuration
- Fails cleanly if the branch already exists (according to `import_conflict_policy`)
- Refuses forced updates to protected refs unless explicitly allowed via `--allow-overwrite-protected-refs`
- Preserves the connection to the original base branch
- For `import_policy="always"`, handles the "no changes" case by creating a branch pointing to the base.
- For `import_policy="auto"` with `skip_empty_import=true` (default), no branch is created when there are no commits.

**Runner-internal event emission and cleanup**: The Runner MUST NOT write to `events.jsonl`. Only Orchestration emits public `task.*`/`strategy.*` events after `run_instance()` returns. The instance runner must emit the final runner-internal completion event BEFORE cleaning up the workspace:

```bash
# Emit runner-specific completion event with workspace path (to runner.jsonl, not events.jsonl)
emit_runner_event("runner.instance.completed", {
    "workspace_path": "/tmp/orchestrator/${run_id}/k_${KHASH}",
    "branch_imported": TARGET_BRANCH
})

# Then clean up after successful import
rm -rf /tmp/orchestrator/${run_id}/k_${KHASH}
```

This ensures the runner log contains the workspace path for audit trails before it's deleted. Public events in `events.jsonl` do not include host workspace paths to avoid leaking host paths; when provenance is needed, write sidecar metadata (results directory) or attach git notes rather than adding host paths to public events. On success, the workspace path is only valid until the completion event is emitted; callers must not rely on it afterward.

**Isolation Properties**:

- Each agent works in a complete, disconnected repository and cannot affect other instances
- No inter-instance coordination is required during execution
- Branch creation via fetch is atomic (succeeds fully or fails without partial updates)
- All operations are local to the host (no network required for import)
- Temporary workspaces enable post‑execution inspection when retained by policy

 

## 3.7 Claude Code Integration

Integration focuses on reliable execution and comprehensive event extraction:

**Process Management**: Claude Code runs via `docker exec` within the persistent container. The `--print` mode with `--output-format stream-json` provides non-interactive execution with structured JSONL (JSON Lines) output for parsing.

**Event Stream Parsing**: Real-time parsing of Claude's JSONL output where each line is a JSON object:

```json
// Initial system message
{"type":"system","subtype":"init","session_id":"...","tools":[...],"model":"..."}

// Assistant messages with tool usage
{"type":"assistant","message":{"content":[{"type":"tool_use","name":"Write","input":{...}}]}}

// User messages with tool results
{"type":"user","message":{"content":[{"type":"tool_result","content":"..."}]}}

// Final result with metrics
{"type":"result","subtype":"success","total_cost_usd":0.42,"usage":{"input_tokens":1200,"output_tokens":900}}
```

Key events extracted:

- Tool usage (Write, Edit, Bash commands, etc.) - emitted as `runner.tool_use` events
- Token consumption from usage field - tracked in real-time
- Cost accumulation from total_cost_usd - aggregated across the session
- Error states from is_error flag
- Session ID for resume capability
- Tool results and output - emitted as `runner.tool_result` events
- Phase transitions and workspace events

**Session Handling**: Each execution gets a unique session_id from Claude Code (e.g., `"2280667e-25e1-46ac-b7f4-722d7e486c9c"`). This ID enables resuming interrupted work via the `--resume <session_id>` CLI flag. Sessions persist in the named volume mounted at `/home/node`, surviving container restarts.

**Authentication**: Based on auth_config, the appropriate environment variables are set:

- Subscription mode: `CLAUDE_CODE_OAUTH_TOKEN`
- API mode: `ANTHROPIC_API_KEY` and optionally `ANTHROPIC_BASE_URL`

**Model Selection**: Models are selected by alias via a shared `models.yaml` mapping. The default alias is `sonnet`.

## 3.8 Error Handling

Errors are categorized for appropriate recovery strategies:

**Container Errors**: Docker daemon issues, resource exhaustion, network problems. Generally retriable with new container.

**Git Errors**: Clone failures, missing branches, fetch issues. Usually require configuration fixes, not retriable.

**Claude Code Errors**: API failures, timeout, cost limits. Retriable using session resume to continue from last checkpoint.

**Timeout Handling**: Tool-level turn/time limits as supported by the selected plugin (optional `runner.max_turns` config; default: unset). Container-level timeout (default 1 hour) as a fallback. Timed-out instances keep containers for resume.

**Retry Strategy**: Automatic exponential backoff for transient failures during execution. Session-based resume for Claude Code failures. Maximum retry attempts configurable (default: 3). Retries handle temporary issues like network blips or API rate limits. After exhausting retries, the instance is marked as failed. This is distinct from orchestration-level resume after interruption, where already-failed instances remain failed.

**Retryable Error Patterns**: Specific error strings trigger automatic retry:

- Docker: "connection refused", "no such host", "timeout", "daemon", "Cannot connect"
- Claude: "rate limit", "API error", "connection reset", "overloaded_error"
- General: "ECONNREFUSED", "ETIMEDOUT", "ENETUNREACH"
- System: OSError, IOError

The retry configuration supports pattern-based matching with tuples of (pattern, error_type) for fine-grained control.
Runners MUST normalize failures to one of `{ docker, api, network, git, timeout, session_corrupted, auth, unknown }` for `task.failed.error_type`.

**Cancellation Semantics**: `asyncio.CancelledError` is terminal and reported as `INTERRUPTED`; cancellations are not retried by the runner. When resuming a run, orchestration resumes pending work from checkpoints; already‑failed/interrupted instances remain terminal.

**Failure Reasons**: `task.failed` payloads include a normalized `error_type` and human-readable `message` to enable precise categorization (docker/api/network/git/timeout/etc.) for dashboards and analytics.

## 3.9 Runner Plugin Interface

Abstract interface enables supporting multiple AI coding tools:

**Core Methods**:

- `validate_environment()`: Check tool is available and configured
- `prepare_environment()`: Return environment variables including authentication
- `build_command()`: Construct tool-specific command with all parameters
- `execute()`: Run tool and parse its output format
- `parse_events()`: Transform tool output into common event schema
- `handle_error()`: Process tool-specific errors and determine retry strategy

**Capability Flags**: Each plugin declares its supported features:

```python
class PluginCapabilities:
    supports_resume: bool = False
    supports_cost: bool = False
    supports_streaming_events: bool = True
    supports_token_counts: bool = True
    supports_streaming: bool = True
    supports_cost_limits: bool = False
    auth_methods: List[str] = ["oauth", "api_key"]
```

Semantics:

- `supports_streaming`: tool streams assistant content incrementally (partial responses)
- `supports_streaming_events`: tool emits structured step events while running (distinct from content streaming)

Orchestration checks required plugin capabilities before scheduling tasks and fails fast with clear errors if unsupported features are needed. This capability gating happens once at run start, not per task. If a strategy requires session resume and the selected plugin has `supports_resume=False`, the run MUST fail at startup with a clear message.

**Authentication Handling**: Each plugin manages its own authentication approach:

```python
# Plugin receives auth config and decides how to use it
auth_config = {"oauth_token": "...", "api_key": "...", "base_url": "..."}
env = await plugin.prepare_environment(auth_config)
```

This keeps tool-specific auth logic encapsulated within the appropriate plugin.

**Implementation Strategy**: The runner controls the full container lifecycle and mounts. Plugins provide capabilities, authentication environment, command construction, event parsing, and error handling. Container creation and teardown remain in the runner (plugins MUST NOT create containers).

**Selection**: Runners are selected via configuration. Allows users to choose their preferred AI tool while keeping same orchestration features.

**Graceful Degradation**: When plugins lack certain capabilities:

- If `supports_cost` is False but `supports_token_counts` is True: estimate costs using configured rates
- If neither cost nor token support: display "N/A" for these metrics
- If `supports_resume` is False: strategies requiring resume capability fail with clear message

# 4. Orchestration Component

## 4.1 Overview and Responsibilities

The Orchestration layer coordinates multiple tasks according to strategies. While Instance Runner handles "how to run one instance", Orchestration handles "how to run many tasks intelligently". This separation enables complex workflows like "generate 5 solutions and pick the best" without complicating the runner logic.

Core responsibilities:

- Execute strategies that schedule and coordinate tasks
- Manage parallel execution with resource limits
- Own the event bus for component communication
- Track current state of all tasks and strategies
- Generate container names from durable task keys for grouping (`orchestrator_{run_id}_s{strategy_index}_k{short8(qual_key)}`), where `strategy_index` is the 1-based index of the strategy execution within the run and `qual_key = f"{strategy_execution_id}|{durable_key}"`.
- Generate deterministic branch names from durable task keys (provided to the runner) using the hierarchical namespace `orc/<strategy>/<run_id>/k{short8(qual_key)}`.
- Handle task failures according to strategy logic
- Support resumption of interrupted runs
- Clean up orphaned containers on startup
- Export comprehensive results including metrics and branches
- Validate disk space before execution

The orchestration depends only on Instance Runner's public API. It exposes clean interfaces for running strategies and querying state, hiding all complexity of parallel coordination.

Key architectural decisions:

- Container naming scheme (`orchestrator_{run_id}_s{strategy_index}_k{short8(qual_key)}`) is orchestration's responsibility (derived from the durable task key namespaced by strategy execution)
- Branch naming pattern is deterministic from the durable task key (orchestration provides the final name)
- Strategies work with high-level abstractions, unaware of these coordination details

This layer transforms the simple "run one instance" capability into powerful multi-instance workflows while keeping both runners and strategies clean.

## 4.2 Public API

The Orchestration component provides five essential interfaces:

**Strategy Execution**: The `run_strategy()` function accepts a strategy name, prompt, base branch, and strategy-specific configuration. Returns a list of task results representing the final outputs. This simple interface hides all complexity - whether the strategy runs 1 or 100 tasks internally.

**State Management**: The `get_current_state()` function returns a complete snapshot of the system: running tasks, active strategies, aggregate metrics. This enables the TUI to display current status without tracking individual events. State includes derived data like "5 of 10 tasks complete" for progress displays.

**Event System**: The `subscribe()` function sets up file watching on `events.jsonl` to receive real-time events. Orchestration writes the canonical public events (`task.scheduled|started|progress|completed|failed|interrupted` and `strategy.started|completed`) — see the “Minimum Payload Fields” section for the canonical schema. Runner-specific events are kept in `runner.jsonl` and are not part of the public file contract. The runner NEVER writes public `task.*`/`strategy.*` events; orchestration emits them, and `task.completed` is written only after `run_instance()` returns. Exactly one writer per run is enforced by `events.jsonl.lock` (see Event Log Contract). This decoupling means TUI never directly calls Instance Runner. Even in-process components use file watching for consistency.

Shutdown/Interruption Semantics: When the operator interrupts the run (e.g., Ctrl+C), orchestration MUST:

- Transition all RUNNING tasks to `INTERRUPTED` in state, capturing `interrupted_at`.
- Emit a canonical `task.interrupted { key, instance_id }` for each such task immediately upon transition and synchronously flush pending events to disk to ensure durability before process exit.
- For each strategy execution that has not yet produced any successful `task.completed`, emit a canonical `strategy.completed { status: "canceled", reason: "operator_interrupt" }` and flush pending events.
- Stop any still-running containers in parallel as part of graceful shutdown. Use a short stop timeout (≤1s) by default to avoid the Docker default 10s grace period (PID 1 ignores SIGTERM by default).

**Event History**: The `get_events_since()` function retrieves historical events from `events.jsonl` starting at a given `start_offset` (byte position before the line) or timestamp. Accepts run_id, offset/timestamp, optional event type filters, and result limit. The events file is never rotated during an active run; rotation/archival occurs only after the run completes. The system scans the file when no index is present; indexing is optional for long runs.
Timestamp to offset: When called with a timestamp, the implementation MUST locate the first record with `ts ≥ T` (by scanning or via an index) and begin returning events from that record’s `start_offset`.

**Run Resumption**: The `resume_run()` function restores an interrupted run from saved state. It loads the state snapshot, replays events, verifies container existence, checks plugin capabilities, and continues execution from where it left off. Supports both session-based resume and fresh restart options.

Resumption behavior:

- Re-open previously terminal strategy executions that require continuation (clear `completed_at`, set state to `running`). Orchestration emits a canonical `strategy.started { name, params, resumed: true }` for each re-opened strategy to prime consumers that attach after the initial run.
- Backfill canonical terminal events for any terminal tasks that are missing from `events.jsonl` (exactly once per task): emit a synthetic `task.completed|task.failed|task.interrupted` with the correct payload, preserving idempotency.
- Enqueue only `QUEUED`, `RUNNING`, or `INTERRUPTED` tasks for execution and preserve parallelism gating via the same executor/queue. Already-terminal tasks are NOT re-enqueued.
- Downstream scheduling MUST be per-candidate: as each generation task completes, dependent scoring/review tasks are scheduled immediately (no batch barrier across candidates).
- Fresh resume option (`--resume-fresh`) MUST clear `resume_session_id`, set `reuse_container=false`, and assign a new container name; otherwise orchestration attempts session resume when the plugin advertises `supports_resume=true` and the original container exists.

Completion and summary:

- On successful resumption to completion, set the run’s `completed_at` to the final completion time (not the initial interruption time) and write a `run.completed` management event for local consumers.
- The `results/summary.json` status MUST be `"interrupted"` if and only if at least one task’s final state is `INTERRUPTED`; otherwise it MUST be `"completed"`. For resumed runs that finish successfully, the top-level `completed_at` MUST reflect the final completion time after resumption.

These APIs follow a key principle: make simple things simple, complex things possible. Running a basic strategy is one function call, but power users can subscribe to detailed events for monitoring.

## 4.3 Strategy System

Durable strategies reduce orchestration to a single primitive while guaranteeing seamless resume and no duplicate work. Strategies are deterministic async Python that schedule durable tasks and wait for their results using a tiny surface area:

**API Surface**:

- `handle = ctx.run(task: dict, *, key: str, policy: RetryPolicy|None=None)` — schedules a durable task and returns a Handle immediately.
- `result = await ctx.wait(handle)` / `results = await ctx.wait_all(list[Handle])` — await completion.
- `ctx.parallel([ ... ])` — sugar for schedule-many + wait_all.
- Deterministic utilities: `ctx.key(*parts) -> str` (stable idempotency keys), `ctx.now()`, `ctx.rand()` (recorded + replayed), `await ctx.sleep(seconds)` (checkpointed). `ctx.rand()` values MUST be recorded per strategy execution (e.g., strategy-scoped events/state) so replay is deterministic without re-seeding.
Determinism recording: Each call to `ctx.rand()` MUST emit a `strategy.rand` event with a monotonic sequence index and value in `events.jsonl`, and the latest sequence index/value MUST be mirrored into `state.json` for fast resume. On replay, the strategy runtime MUST consume the recorded values in order and MUST NOT generate new randomness.

Handle contract:

```python
class Handle:
    key: str            # fully-qualified durable key (run_id/strategy_execution_id/..)
    scheduled_at: float # monotonic timestamp (seconds)
    # Opaque; not awaitable directly
```

Waiting contract:

- `await ctx.wait(handle)` → returns `TaskResult` or raises `TaskFailed(key, error_type, message)`
- `await ctx.wait_all(handles, tolerate_failures=False)` →
  - default: returns `list[TaskResult]` or raises `AggregateTaskFailed([key...])`
  - if `tolerate_failures=True`: returns a 2‑tuple `(successes: list[TaskResult], failures: list[TaskError])` in that order.

Example:
```python
successes, failures = await ctx.wait_all(handles, tolerate_failures=True)
```

Retry policy: The `policy` parameter defaults to `None` (no orchestration-level retry). Orchestration-level `policy` applies only to scheduling/reattach failures (e.g., queuing, container start/attach). Once the runner starts executing a task, runner-level `retry_config` handles transient execution errors (API/rate-limit/network) with session-resume.

RetryPolicy schema (orchestration-level):

```json
{
  "max_attempts": 3,
  "backoff": {"type": "exponential", "base_s": 10, "factor": 6, "max_s": 360},
  "retry_on": ["docker", "api", "network"]
}
```

This augments runner retries; orchestration retries at the task level only for schedule/attach failures.

Exceptions (thrown by orchestration utilities):

- `TaskFailed(key, error_type, message)` — raised by `wait()` when a single task fails.
- `AggregateTaskFailed([key...])` — raised by `wait_all()` when one or more tasks fail and `tolerate_failures=False`.
- `NoViableCandidates()` — used to signal selection failure in strategies (e.g., Best‑of‑N scoring yields zero valid candidates).
- `KeyConflictDifferentFingerprint(key)` — scheduling error: same key with a different canonical fingerprint.

`ctx.key(...)` always expands to an internal fully-qualified key namespaced by the current run and strategy execution: `run_id/strategy_execution_id/<joined parts>`. Authors only supply the `<joined parts>`; namespacing prevents collisions across parallel runs. Orchestration MUST derive `instance_id = sha256(JCS({"run_id": ..., "strategy_execution_id": ..., "key": ...})).hex()[:16]`, which is stable within a run across retries/resumes. UI short form is `inst-{first5}` for display only; the full 16‑hex `instance_id` MUST appear in labels and events.

**Task Input Schema** (single provider under the hood); `TaskResult` returned to strategies maps directly from `RunnerResult` fields exposed by the runner:

```json
{
  "prompt": "string",
  "base_branch": "string",
  "model": "string (optional)",
  "import_policy": "auto|never|always (optional, default: auto)",
  "import_conflict_policy": "fail|overwrite|suffix (optional)",
  "skip_empty_import": true,
  "session_group_key": "string (optional)",
  "resume_session_id": "string (optional)",
  "metadata": { "any": "json" }  // optional, stored for traceability
}

Field mapping to Runner API: `resume_session_id` (strategy input) maps to Runner `session_id`.
```

**Result Shape (TaskResult)** returned by `wait`/`wait_all` (fields stable; optional fields are explicitly marked):

```json
{
  "artifact": {
    "type": "branch",
    "branch_planned": "<name>",
    "branch_final": "<name|null>",
    "base": "<base>",
    "commit": "<sha>",
    "has_changes": true
  },
  "final_message": "string",
  "metrics": {"tokens_in":0,"tokens_out":0,"cost_usd":0.0,"duration_s":0.0},
  "session_id": "string",
  "instance_id": "string",
  "status": "success|failed|timeout|interrupted"
}
```

Artifact field semantics:

- `artifact.commit` is the tip commit of the imported branch and is the primary stable identifier of the artifact. For `import_policy="always"` with no changes, it equals the base commit. For `import_policy="never"` or skip-empty cases, `artifact.has_changes=false`, `artifact.branch_final=null`, and `artifact.commit` equals the base commit for provenance.
- `artifact.branch_planned` is the deterministic name planned from the durable key; `artifact.branch_final` is the actual created branch (can differ when `import_conflict_policy="suffix"`).
  A branch exists with `artifact.has_changes=false` when `import_policy="always"`; use `artifact.branch_final is not null` to test for branch existence.

Optional dedupe fields:

- `artifact.duplicate_of_branch` (optional): when import short‑circuits due to idempotency/dedupe, this field carries the branch that was used instead of creating a new one.
- `artifact.dedupe_reason` (optional): one of `same_task_provenance | crash_window | by_commit | by_commit_no_changes` indicating why no new branch was created.

Mapping of dedupe reasons:
- `same_task_provenance`: Idempotent pre‑check or suffix check found an existing branch whose HEAD equals `WS_HEAD` and whose commit note already includes the same `task_key`.
- `crash_window`: Exactly one candidate branch had `HEAD == WS_HEAD` but lacked provenance for this `task_key`; treat as resume and append provenance without allocating a new branch.
- `by_commit`: Non‑suffix import pre‑check found that the planned branch already equals `WS_HEAD`; treat as already imported without creating a new branch.
- `by_commit_no_changes`: `import_policy="always"` created or pointed a branch at the base when there were zero commits relative to base.

Population responsibility: The runner sets `artifact.base` from `.git/BASE_BRANCH` in the workspace and MUST set `artifact.commit` to `.git/BASE_COMMIT` when no import occurs.

`instance_id` is stable across runner-level retries, container replacements, and resumes within a run. Normative derivation: `instance_id = sha256(JCS({"run_id": ..., "strategy_execution_id": ..., "key": ...})).hex()[:16]`. `TaskResult` is the strategy-facing view of the runner's `RunnerResult`.

There are no other orchestration operations. Generation, review/scoring, and refinement are all regular `ctx.run` tasks with distinct keys.

`wait(handle)` raises on task failure. `wait_all(handles)` raises an aggregated error by default; callers opt into partial tolerance via `await ctx.wait_all(handles, tolerate_failures=True)` which returns `(successes, failures)`.

**Durability Semantics**:

- Exactly-once by key: each `ctx.run(..., key=...)` is idempotent; on resume, completed keys return recorded results.
- Checkpointed at task boundaries with a single writer fsyncing `events.jsonl`; each event records its `start_offset`.
- Replay on resume: strategy code re-executes deterministically; completed runs are short-circuited; pending keys are resumed or reattached by key.

Key reuse contract:

- Same key + same fingerprint → idempotent: return the recorded result.
- Same key + different fingerprint → hard error `KeyConflictDifferentFingerprint`.

## 4.4 Built-in Strategies

The system provides reference patterns implemented purely with the durable `ctx.run` primitive:

**Single Task**: Schedule exactly one `ctx.run` and await its result. Baseline for tasks where a single attempt is sufficient.

**Best-of-N (inline scoring)**: Generate N candidates with `ctx.run`. For each candidate, run a reviewer `ctx.run` that returns JSON `{score:0..10, rationale:string}`. If the JSON is invalid, do one repair attempt with a stricter “return ONLY JSON” prompt. Exclude candidates that still fail schema validation. Pick the max score among valid results and return that candidate’s result.

**Iterative Refinement**: Generate an initial solution, run a scoring/review `ctx.run` for feedback, then schedule an improvement `ctx.run` using the prior `session_id`. Repeat for a fixed number of iterations (default 3).

These patterns are expressed directly in strategy code using keys like `gen/<i>`, `score/<instance_id>/attempt-1`, and `improve/iter-<n>`. There are no special strategy types; everything reduces to idempotent `ctx.run` calls plus deterministic selection logic.

## 4.5 Parallel Execution Engine

Managing concurrent tasks requires careful resource control:

**Resource Pool**: Maximum parallel instances configurable (default adaptive). The default limit is `max(2, min(20, floor(host_cpu / runner.cpu_limit)))`. This prevents host oversubscription while allowing parallelism. When at capacity, new task requests queue until a slot opens. A warning MUST be logged if the configured value oversubscribes the host (i.e., `max_parallel_instances * runner.cpu_limit > host_cpu`). Operators can also select presets via `--parallel {conservative|balanced|aggressive}`, which set `runner.cpu_limit` and `runner.memory_limit` together (e.g., conservative: 1 CPU/2GiB, balanced: 2 CPU/4GiB [default], aggressive: 3 CPU/6–8GiB) to keep CPU and RAM in sync.

Host CPU detection:

- Baseline = `os.cpu_count()`.
- If cgroup CPU quota is detected (Linux), clamp by `ceil(quota / period)`.
- On macOS/Windows without cgroups, use `os.cpu_count()`.

**FIFO Scheduling**: Simple first-in-first-out queue ensures fairness. No complex priority systems - strategies that submit first get resources first. This predictability makes debugging easier.

**Task Scheduling**: Admission is multi-resource: a task is admitted only if all guards pass:

1) Pool slot available
2) CPU tokens: `sum(running.container_cpu) + new.container_cpu ≤ host_cpu`
3) Memory tokens: `sum(running.container_memory_gb) + new.container_memory_gb ≤ host_mem * mem_guard_pct` (default `mem_guard_pct=0.8`)
4) Disk guard: free space on the workspace filesystem `≥ disk.min_free_gb` and recent Git pack growth slope `≤ disk.max_pack_growth_mib_per_min`

When `max_parallel_instances="auto"`, the pool size is derived from CPU tokens via the adaptive default above. Memory and disk guards apply regardless of pool size.

The engine:

- Generates container names using pattern `orchestrator_{run_id}_s{strategy_index}_k{short8(durable_key)}` (derived from the durable task key) and computes them before scheduling; container_name MUST NOT change thereafter
- Uses deterministic branch names derived from the durable task key (orchestration provides the final name)
- Persists `strategy_index` label on containers with the 1-based value for easier grouping and debugging (the display alias `sidx` is used in UI only)
- Tracks task-to-container mapping for monitoring and cleanup
- Manages multiple background executor tasks (configurable count) for true parallel execution
- Applies a disk guard before starting tasks (configurable minimum free space and pack‑growth slope); on breach, pauses admissions and triggers on‑run GC (see §4.10)

**Execution Tracking**: Each task tracked from schedule to completion. Strategies can wait for specific tasks or groups. Essential for patterns like "wait for all 5 to complete, then pick best".

**Capacity Model**:

- Each task declares `container_cpu` and `container_memory_gb` at scheduling time (defaults/presets apply).
- Scheduler maintains aggregate CPU and memory token ledgers; both MUST be within limits to admit a task.
- Disk guard is evaluated on each admission attempt; if breached, admission is paused until healthy.
- Tasks not admitted wait in FIFO order. This prevents oversubscription even with per-task overrides.
- Oversubscription warnings are emitted when `max_parallel_instances * runner.cpu_limit > host_cpu` or when a single task requests `container_cpu > host_cpu` or `container_memory_gb > host_mem`.

**Resource Cleanup**: When tasks complete, their slots immediately return to the pool. Failed tasks do not block resources. This ensures maximum utilization without manual intervention.

The engine uses a FIFO queue and a fixed pool size. Strategies provide the intelligence about what to run and when.

## 4.6 State Management

State tracking serves two purposes: enabling UI displays and crash recovery:

**In-Memory State**: Primary state lives in memory as simple data structures:

- Running tasks with their status and progress
- Active strategies with their configuration
- Completed results awaiting processing
- Aggregate metrics (total cost, duration, token usage)

**Event Sourcing**: Every state change emits an event to `events.jsonl`. The current state can be reconstructed by replaying events from this file. This pattern enables resumability - after a crash, replay events to restore state.

**State Persistence Implementation**: State is persisted through two mechanisms:

- `events.jsonl`: Append-only log containing every state change with monotonic byte offsets. A single writer computes the `start_offset`, writes the record, flushes, and fsyncs.
- `state.json`: Periodic snapshot (every 30 seconds) containing full state and the `last_event_start_offset` (the byte position of the last applied event's start). Snapshots MUST persist, per instance: `state`, `started_at`, `completed_at`, `interrupted_at`, `branch_name`, `container_name`, and `session_id` to enable resumability. Written atomically using temp file + rename. Snapshots MUST only reference offsets that the writer has confirmed durable (fsynced).

Recovery process:

1. Load `state.json` if it exists (includes `last_event_start_offset`)
2. Read `events.jsonl` from the saved `last_event_start_offset`
3. Apply events to reconstruct current state
4. Handle cases where state directory structure changed (e.g., run_ prefix removal)

**Event Bus Features**: The event system includes:

- Ring buffer implementation (default 10,000 events) to prevent memory issues
- File watching for external processes via the public `subscribe()` API
- Event filtering by type, timestamp, run_id, and instance_id
- Monotonic offset tracking for reliable position management (using `start_offset` semantics)
- 20+ internal runner event types (workspace lifecycle and Claude-specific) parsed for diagnostics; public `events.jsonl` remains limited to `task.*` and `strategy.*`

**Atomic Snapshots**: The `get_current_state()` function returns consistent snapshots. No partial updates or race conditions. UI can poll this API for smooth updates without event subscription complexity.

This approach balances simplicity with reliability. Memory is fast for normal operation, while file-based persistence enables recovery when needed. The combination of event log and periodic snapshots ensures quick recovery without replaying the entire event history.

**Idempotent Recovery**

- `state.json` MUST include `last_event_start_offset` (byte position of the last applied event's start).
- Recovery MUST replay only events after `last_event_start_offset`.
- Event application MUST be idempotent: re-applying a transition already reflected in the snapshot MUST NOT double count aggregate metrics (e.g., completed/failed counters).
- Aggregate counters MUST be derived from guarded state transitions (increment only when moving from a non-terminal to a terminal state).
- Internal runner events include `session_id` updates used for in-memory tracking. These are not part of the public `events.jsonl` contract. The public event set remains `task.*` and `strategy.*` only.

## 4.7 Git Synchronization

Parallel tasks work in complete isolation, requiring no coordination during execution. The synchronization happens after containers complete through a simple branch import process:

**Branch Import Process**: After each container exits, the Instance Runner performs the git import as the final atomic step of `run_instance()`. This uses git's filesystem fetch capability to import the isolated workspace into the host repository. The runner MUST serialize imports per repository using a cross‑platform, process‑internal file lock at `<realpath(git-dir)>/.orc_import.lock` (determine `git-dir` via `git rev-parse --git-dir` and resolve to a realpath to avoid aliasing). Use fcntl on POSIX, msvcrt on Windows, or a cross‑platform library. Do not rely on shell `flock`. The import respects the per‑task `import_policy` ("auto" | "never" | "always"). The import is atomic — either all commits transfer successfully or none do. Collision policy is enforced while holding the import lock. Alternates/partial clones are disallowed; locking per `<realpath(git-dir)>` is sufficient.

**Branch Naming**: `branch_name = f"orc/{strategy_name}/{run_id}/k{short8(qual_key)}"` where `qual_key = f"{strategy_execution_id}|{durable_key}"` and `short8(x) = sha256(x).hex()[:8]`. This hierarchical namespace supersedes the older flat pattern `{strategy}_{run_id}_k{short8(qual_key)}`. Using `run_id` (not a timestamp) guarantees stability across resumes of the same run. Runner never invents names; it receives the final branch name from orchestration and creates that branch during import.

Segment and length constraints:
- The `strategy_name` path segment MUST be sanitized to contain only `[A-Za-z0-9._-]`. Disallowed characters MUST be replaced with `-`, repeated separators collapsed, and leading/trailing separators trimmed. Slashes are disallowed in `strategy_name` to prevent deeper nesting beyond `orc/<strategy>/<run_id>/k…`.
- If sanitization produces an empty `strategy_name` segment, orchestration MUST substitute the fallback value `unknown`.
- The complete branch name MUST satisfy the global validation rule (≤200 characters); orchestration MUST enforce this limit when generating names.

**Clean Separation**: The synchronization mechanism maintains architectural boundaries:

- Orchestration owns branch naming policy
- Instance Runner performs the mechanical git fetch operation
- Isolated workspaces eliminate any possibility of conflicts
- Neither component needs to understand the other's logic

**Import Operation**: The actual branch import preserves the original base branch reference and MUST perform an idempotent pre-check to avoid duplicate imports across crashes:

```bash
# Performed by Instance Runner as final step
cd /path/to/host/repo
BASE_BRANCH=$(cat /tmp/orchestrator/${run_id}/k_${KHASH}/.git/BASE_BRANCH)

# Idempotent import pre-check (handles crash window)
# (Illustrative shell; reference implementation performs these checks in Python under the process-level lock.)
if git show-ref --verify --quiet "refs/heads/${branch_name}"; then
  WS_HEAD=$(git --git-dir="/tmp/orchestrator/${run_id}/k_${KHASH}/.git" rev-parse HEAD)
  BR_HEAD=$(git rev-parse "refs/heads/${branch_name}")
  if [ "$WS_HEAD" = "$BR_HEAD" ]; then
    echo "Branch already matches workspace HEAD; treating as completed."
    # Return success to orchestration; it will emit task.completed
    exit 0
  fi
fi

if [ "${import_conflict_policy:-fail}" = "overwrite" ]; then
  git fetch /tmp/orchestrator/${run_id}/k_${KHASH} +HEAD:${branch_name}
else
  git fetch /tmp/orchestrator/${run_id}/k_${KHASH} HEAD:${branch_name}
fi
```

Alternate import paths such as `git bundle` are not implemented. The supported import path is `git fetch` from the isolated workspace under the repository lock defined above.

This operation runs under the per-repo import lock to serialize updates to refs and packs. Unique branch names avoid cross-branch conflicts; the lock prevents ref/pack races.

The idempotent pre-check ("does the branch already equal the workspace HEAD?") **and** the subsequent `git fetch` MUST both occur while holding the same per-repo import lock.

**Import Policies & Edge Cases**:

- Empty changes (auto): with `skip_empty_import=true` (default) and `import_policy="auto"`, if there are no commits relative to the base (detected via `BASE_COMMIT..HEAD`), no branch is created. The task result sets `artifact.has_changes=false`, `artifact.branch_final=null`, and records the planned branch name in `artifact.branch_planned` for reporting.
- Empty changes (always): with `import_policy="always"`, a branch is created even when there are zero commits; it points at the base commit.
- Never import: with `import_policy="never"`, no branch is created regardless of changes. The result MUST set `artifact.has_changes=false`, `artifact.branch_final=null`, and `artifact.branch_planned` MUST carry the planned branch name for traceability. Strategies MUST pick a real base for subsequent tasks (e.g., the candidate’s imported branch if `has_changes=true`, else the original `base_branch`).
- Name collisions: controlled by `import_conflict_policy = "fail" | "overwrite" | "suffix"` (default `"fail"`). For `"suffix"`, `_2`, `_3`, … are appended atomically to the leaf after `k{short8}` while holding the import lock (e.g., `orc/bestofn/run_20250114_123456/k7aa12cc_2`). For `"overwrite"`, a forced ref update is used.
- Failures: if git fetch fails (disk space/corruption), the instance is marked failed with details. The isolated workspace is preserved for debugging.

**Deduplication policy (suffix)**: By provenance. Different tasks importing the same commit create separate suffixed branches; this preserves branch‑per‑task traceability.

**Suffix idempotency with provenance**: Under the per‑repo import lock and when `import_conflict_policy="suffix"` (candidate regex example: `.../k(?P<k8>[0-9a-f]{8})(?:_(?P<n>\d+))?$`):

1) If any candidate branch matching `^${branch_name}(_[0-9]+)?$` has `HEAD == WS_HEAD` and the commit’s note already includes this `task_key`, treat as idempotent success and return that branch (no new suffix).

2) If there is exactly one candidate branch with `HEAD == WS_HEAD` but the commit note does not include this `task_key`, treat this as a resume of the same task: append provenance now and return that branch (do not allocate a new suffix).

3) Otherwise, allocate the lowest unused numeric suffix while holding the import lock and fetch `HEAD:chosen_branch` (without force, i.e., no `+`).

On any success (existing or newly created), append a provenance line to `refs/notes/orchestrator` before releasing the lock:

```bash
git notes --ref=orchestrator add -m 'task_key=<fully_qualified_key>; run_id=<run_id>; strategy_execution_id=<strategy_execution_id>; branch=<branch_name>; ts=<iso-utc>' <WS_HEAD>
```

Idempotency rule: treat as already imported only if both (a) `HEAD`s match and (b) the note includes the same `task_key`. The note MUST be written before releasing the import lock to minimize duplication in a crash window.

Determinism note: `import_conflict_policy="suffix"` breaks strict determinism of branch names across resumes and is intended for manual/experimental runs. For reproducibility, use `"fail"`.

**No Remote Operations**: By design, containers never push to any remote. All git operations are local to the host machine. If remote synchronization is needed, it happens as a separate post-processing step after all tasks complete, completely decoupled from instance execution.

**Workspace Cleanup**: After successful import, the temporary workspace is immediately deleted to free disk space. Failed instances retain their workspaces according to the retention policy, allowing post-mortem analysis of what the AI agent attempted.

Workspaces are reused on resume when available. The orchestrator reattaches the previous isolated git workspace path (derived deterministically from `run_id` and container name) instead of re-cloning from the base. This preserves uncommitted filesystem state across interruption and resume, so agents can continue exactly where they left off. If the workspace is missing or invalid, the system falls back to a fresh clone. A separate `--resume-fresh` mode forces a new workspace for that instance.

**Audit Trail**: Each import operation is logged with:

- Source workspace path
- Target branch name
- Commit count and size
- Success/failure status
- Timestamp and duration

This provides visibility into what each AI agent produced and when it was integrated.

**Provenance**: Do not mutate the imported branch tip after import. Implement provenance using one of the following mechanisms:

- Write provenance as a sidecar file in `results/<run_id>/strategy_output/`, or
- Attach provenance via git notes or a lightweight tag referencing the imported commit.

If provenance must live in-repo history, write it into the workspace before import so it becomes part of the agent’s own commit(s). Avoid adding commits after import to preserve the “import HEAD” auditability guarantee.

To display orchestrator provenance notes in `git log` output, configure `git config notes.displayRef 'refs/notes/orchestrator:refs/notes/commits'` in the repository. This configuration is not required at runtime.

## 4.8 Resume Capabilities

Resumption produces identical final outcomes with no duplicate work using durable task keys:

**Seamless Resume Algorithm**:

1. Load last `state.json` snapshot (if any).
2. Replay `events.jsonl` from the saved `last_event_start_offset` to rebuild: completed tasks map (`key → result`), pending tasks (`scheduled` without `completed/failed`), and strategy completion state.
3. Reattach pending tasks by key:
   - Find the container via labels for `run_id/strategy_execution_id/key`.
   - If running → reattach streams.
   - If stopped but a session-group volume exists (see 3.5 Session Groups) → start container and continue using `resume_session_id`.
   - Else → start fresh with the same key.
4. Re-enter the strategy function deterministically: completed `ctx.run` calls return recorded results immediately; execution advances to the first unfinished run.
5. Continue to completion. Container and branch names derive from the durable key, preventing duplicates.

**Crash Inference**: On resume, any task that is `RUNNING` in `state.json` and has no terminal event at or after `last_event_start_offset` MUST be marked `INTERRUPTED` before resuming.

**State Recovery**: The system handles various failure scenarios:

- Graceful shutdown: Full state preserved, seamless resume
- Crash during execution: State recovered from last snapshot + event replay
- Partial container failure: Failed instances marked, others continue

### Resume Semantics

On resumption of an interrupted run, orchestration MUST:

- Recover state from the latest snapshot and apply canonical events since the recorded offset.
- Backfill canonical terminal events for terminal tasks missing from the log.
- Re-enter all strategy executions concurrently so downstream stages (e.g., scoring) proceed as soon as prerequisites complete.

Resumption MUST respect resource gates (queue and semaphore) and MUST NOT serialize strategy re-entry.

## 4.9 Results Export

After run completion, the orchestrator exports comprehensive results:

**Directory Structure**:

```
results/
  run_20250114_123456/
    summary.json       # Overview with metrics and branch list
    branches.txt       # Simple list of created branches
    metrics.csv        # Time-series metrics data
    strategy_output/   # Strategy-specific data
      best_branch.txt  # For BestOfN strategy
      scores.json      # Scoring details
```

**Summary Format**: The `summary.json` includes:

- Run metadata (ID, strategy, configuration)
- Complete list of created branches with status
- Aggregate metrics (total cost, duration, tokens)
- Task-level details and outcomes
- Strategy-specific results
 - Top-level `status` where `"interrupted"` indicates at least one task ended `INTERRUPTED` at run end; otherwise `"completed"`. On resumed runs that reach completion, `completed_at` reflects the final end-of-run time.
 - Optional: `provenance_excerpt` for each imported artifact (latest orchestrator note line) for quick audit

**Metrics Export**: Time-series data in CSV format:

- Timestamp, task count, cost accumulation
- Token usage over time
- Task state transitions
- Useful for cost analysis and optimization

## 4.10 Resource Management

**Startup Validation**:

- Check minimum free disk space before starting (configurable; default 20GiB)
- Verify Docker daemon accessibility
- Clean up orphaned containers from previous runs (owned by orchestration)
- Validate git repository and base branch

**Container Cleanup**: On startup, orchestration owns orphan cleanup by run namespace:

1. Consider only containers labeled `orchestrator=true`.
2. Match containers to active runs by `run_id` label and the presence of `orchestrator_state/<run_id>/`.
3. Remove containers that either (a) have no corresponding active run directory, or (b) exceed the retention threshold, using age based on, in order: `state.json` timestamps, heartbeat file mtime at `/home/node/.orc/last_active`, then Docker `CreatedAt`.
4. Log cleanup actions for audit trail.

Runner cleanup is limited to its own container on task failure; it MUST NOT scan for or delete unrelated containers to avoid races with orchestration.

**Session Volume Cleanup**: Session volumes (`orc_home_{run_id}_g{GHASH}` in run scope or `orc_home_g{GHASH}` in global scope) are not auto‑cleaned on startup. Cleaning volumes is an explicit operator action via `orchestrator --clean-volumes`. The command removes only unreferenced volumes older than a configurable threshold (default 24h) and MUST never remove volumes still referenced by any container.

**On-run GC and backpressure**:

- Disk guard thresholds:
  - `disk.min_free_gb` (default 10GiB)
  - `disk.max_pack_growth_mib_per_min` (default 256 MiB/min over a 5‑minute window)
- If free space drops below `min_free_gb` or the pack‑growth slope exceeds the threshold, orchestration MUST:
  1) Pause task admissions immediately
  2) Trigger GC of retained artifacts: purge oldest failed workspaces/containers first; optionally compress logs/artifacts when configured
  3) Resume admissions only after both thresholds return to healthy ranges
- Retention is size‑aware: in addition to age (e.g., 24h), the system MUST cap total bytes retained for failed workspaces/containers (configurable, e.g., `retention.max_failed_artifacts_gb`). Exceeding the cap purges oldest first.

**Parallel Shutdown**: On Ctrl+C or error:

1. Set shutdown flag to prevent new tasks
2. Cancel all pending task operations
3. Stop all running containers in parallel (runner writes a final heartbeat to `/home/node/.orc/last_active` before exit when possible)
4. Save final state snapshot
5. Clean up temporary resources

The parallel container stopping significantly improves shutdown speed when many instances are running.

# 5. TUI Component

## 5.1 Overview and Responsibilities

The TUI presents the orchestrator’s state. It provides a real-time dashboard during execution and clean CLI output for both interactive and non-interactive use.

Core responsibilities:

- Display real-time progress of all tasks and strategies
- Adapt visualization based on scale (5 vs 500 tasks)
- Provide CLI interface for launching runs
- Show aggregate metrics and individual task details
- Stream important events to console in non-TUI mode
- Present final results and branch information

The TUI knows nothing about how tasks run or how strategies work—it simply subscribes to events and queries state. This separation allows full replacement with alternative UIs without changing orchestration logic.

**Multi-UI Support**: Multiple UIs can monitor the same run by tailing the shared `events.jsonl` file and periodically reading `state.json` snapshots.

## 5.2 Display Architecture

The TUI is display-only (no interactive shortcuts). Interactive features (e.g., search/filter) are out of scope for this release. It uses a hybrid approach combining event streams with periodic state polling for both responsiveness and reliability:

**Event Handling**: The TUI watches `events.jsonl` for new events using a portable file watcher with a polling fallback (to support macOS/Windows/Linux uniformly). As new events are appended to the file, the TUI reads and processes them, updating its internal state immediately. Events do not trigger renders directly. Whether 1 event or 100 events arrive, they update only the internal data structures. This prevents display flooding when hundreds of tasks generate rapid events.

**Fixed Render Loop**: A separate render loop runs at 10Hz by default (every 100ms), reading the current internal state and updating the display. The refresh rate is configurable via `tui.refresh_rate_ms`. Do not render directly from watcher callbacks. This decoupling is crucial - event processing and display rendering operate independently. Users see smooth, consistent updates regardless of event volume.

**State Reconciliation**: Every 3 seconds, the TUI reads the latest `state.json` snapshot to reconcile any drift. This is a safety net catching missed events or recovering from disconnections, not the primary update mechanism.

**Buffer Management**: Events update a simple in-memory representation:

- Task map keyed by ID with current status
- Strategy progress counters
- Aggregate metrics accumulation
- Last-updated timestamps for staleness detection

The display model decouples event ingestion from rendering: events update internal state, while a fixed 10Hz render loop updates the UI. Progress bars are time-based heuristics unless tools emit explicit progress events; the TUI labels them accordingly.

## 5.3 Layout Design

The dashboard uses a three-zone layout maximizing information density while remaining non-interactive:

**Header Zone**: Single-line header: `RunID • strategy=name(params) • model • tasks: running/queued/done • runtime` (e.g., `strategy=best-of-n(n=5)`). Parentheses are used for display only; for CLI pass params via `-S/--set` (e.g., `-S n=5`).

**Dashboard Zone**: Dynamic grid grouped by strategy; within each group tasks are ordered running → queued → done, then chronological. Cards show, by default, and only:
1) Phase (e.g., `container_created`, `tool_use`)
2) Runtime
3) Branch (planned/final as applicable)
4) Instance short ID
5) Last activity (e.g., `stalled 45s` when applicable)

Cost/tokens are not shown in cards by default (they appear in the details pane and footer).

**Footer Zone**: Fixed 2-line footer with aggregate metrics: total runtime, per‑task running subtotal (sum of active tasks) and run total cost, tokens (in/out/total), failures count (subtle), and queue depth. Failures are surfaced via the counter only—no banners. Footer totals should update smoothly (≈≤1s perceived latency).

The layout prioritizes current activity. Completed tasks fade visually while active ones draw attention. This focus on "what needs attention now" helps users manage large runs.

## 5.4 Adaptive Display

The display intelligently adapts to task count, showing maximum useful information without clutter:

**Detailed Mode (≤5 tasks)**:

- Larger cards; always show Phase and Runtime, plus the default fields above
- Live progress bars when available

**Compact Mode (6–30 tasks)**:

- Medium cards with Phase + Runtime always visible; other fields elide as needed

**Dense Mode (31+ tasks)**:

- Minimal cards in tight grid with Phase + Runtime always visible; other fields elide progressively
- Strategy-level progress more prominent; summary stats matter more than individuals

The adaptation is automatic but overridable via `--display {detailed|compact|dense|auto}`. This flexibility handles both overview monitoring and detailed debugging.

**Optional Details Pane (no interactivity)**: When enabled with `--display-details right`, a right-side panel shows the most recently updated task’s details: last N public messages (sanitized), cost, tokens, metrics, and the final message (with truncation note and run‑relative path). Only public event data (`task.*`, `strategy.*`) is shown; runner internals remain file‑only. Defaults: `--display auto`, `--display-details none`, and N=10 (configurable via `tui.details_messages=10`).

**Accessibility & palette**: Use a deuteranopia‑friendly palette with minimum 4.5:1 contrast for text on background. Emoji are permitted but the UI MUST NOT rely on color alone—pair color + icon + label (e.g., RUN, DONE, FAIL). Provide `--no-emoji` for environments that prefer ASCII only.

## 5.5 CLI Interface

The CLI provides the primary interface for launching and controlling runs:

**Command Structure**: Clean, intuitive commands following Unix conventions:

```bash
orchestrator "your prompt" --strategy best-of-n --runs 3 -S n=5
orchestrator --resume <run-id>
orchestrator --list-runs
orchestrator --clean-containers
orchestrator doctor
orchestrator config print [--json]
```

**Output Modes**:

- TTY (interactive): launch the full TUI dashboard by default.
- Non‑TTY/CI: print concise, colorless human logs; opt into JSON via `--json`.
- `--no-tui`: force streaming logs even in a TTY.

The same identifiers, ordering, and lifecycle semantics appear across TUI, streaming, and logs.

**Cleanup Commands** (confirmation required):

- `--clean-containers`: Removes stopped or orphaned containers labeled `orchestrator=true` older than the configured retention. Running containers are not removed. Prompts interactively; use `--yes` to bypass. `--dry-run` lists targets without deleting.
- `--clean-volumes [--dry-run] [--older-than <hours>]`: Removes unreferenced session volumes matching `orc_home_{run_id}_g{GHASH}` (run scope) and `orc_home_g{GHASH}` (global scope) older than the threshold (default 24h). Never removes volumes referenced by any container. Prompts interactively; use `--yes` to bypass.
- `--quiet`: Only show final results

In non‑TTY environments, operations requiring confirmation will fail fast with a clear hint to re‑run with `--yes`.

**Exit Codes**:

- `0`: success
- `1`: internal error (configuration, I/O, unexpected exception)
- `2`: canceled/interrupted by operator
- `3`: completed with failures (partial success)

Writer safety options:

 

**Strategy Configuration**:

- `--runs`: Number of parallel strategy executions within a single run ID (one run folder; N executions).
- `-S key=value` and `--set key=value`: Set strategy‑specific parameters (repeatable). Both forms are merged.
- `--config`: Load configuration from YAML or JSON file

Examples:

```bash
# Single execution with parameters
orchestrator "fix bug" --strategy best-of-n -S n=3

# Multiple parallel executions
orchestrator "refactor" --strategy best-of-n --runs 5 -S n=3

# Using config file
orchestrator "build feature" --config prod-strategy.yaml

# Override config values
orchestrator "optimize" --config base.yaml --runs 10 -S timeout=600

# Force branch creation even with no changes
orchestrator "analyze code" -S import_policy=always
```

**Escaping and Quoting**:

- Use single quotes for prompts containing spaces or special characters
- For prompts with single quotes, use double quotes or backslash escaping
- For complex multi-line prompts, use `--config` file instead
- Strategy parameters (`-S`) follow standard shell parsing rules

Examples:

```bash
# Simple prompt
orchestrator "implement hello world"

# Prompt with quotes
orchestrator 'implement "Hello, World!" program'

# Complex prompt with special characters
orchestrator "implement function that returns \"it's working!\""

# Multi-line or very complex prompts - use config file
orchestrator --config complex-prompt.yaml
```

**Non-TUI Output**: When TUI is disabled, events stream to console with:

- Hybrid line style with compact prefix and key=value fields (no ANSI colors in non‑TTY):

  `[k7aa12cc][inst-7a3f2] ▶ started model=sonnet base=main`

  `[k7aa12cc][inst-7a3f2] ✅ completed time=3m24s cost=$0.42 tokens=2.5k branch=orc/bestofn/run_20250114_123456/k7aa12cc`

  `[k19bb44a][inst-8b4c1] ❌ failed type=timeout after=60m retries=3`

- Prefix is always `[k{short8(qual_key)}][inst-{first5}]`. Status glyphs: `▶` started, `✅` completed, `❌` failed, `⏸` interrupted. Use `--no-emoji` to disable glyphs.
- Field order is stable; missing fields are omitted (no empty `key=`).
- Verbosity: lifecycle events only by default; `--verbose` additionally prints notable phases like `container_created`, `branch_imported`, and `no_changes`.

Note: The TUI reads only the canonical public events (`task.*`, `strategy.*`) from `events.jsonl`. Detailed tool-use/activity feeds from runner internals are available in `runner.jsonl` for debugging but are not part of the public event stream.

**Configuration**: CLI arguments take precedence over all other config sources. Complex strategies can be configured via `--config` with YAML or JSON files for repeatability. Environment variables provide defaults without cluttering commands. At start of run, the orchestrator prints a truncated Effective Config header (sources shown; secrets redacted), e.g.:

```
Effective config (sources: cli>env>.env>project>global>default)
model: sonnet                 (project)
strategy: best-of-n           (cli)
strategy.params.n: 5          (cli)
runner.network_egress: online (default)
auth: REDACTED                (env)
… see `orchestrator config print` for full details
```

Additional flags and mappings:

- `--allow-global-session-volume` enables global session volume scope; requires explicit consent.
- `--parallel {conservative|balanced|aggressive}` sets CPU+RAM presets for containers (maps to `runner.cpu_limit` and `runner.memory_limit`).
- Budgets: (removed — budgets not enforced; see Cost Tracking)
- Disk guard: `--disk-min-free-gb` and `--disk-max-pack-growth-mib-per-min` tune admission backpressure thresholds.
- Git safety: `--allow-overwrite-protected-refs` must be set to allow forced updates to protected refs.
- Proxy settings (no secrets logged):
  - Proxy configuration is supported via CLI, environment, and config file. Specific option names are implementation‑defined and may vary by environment.

- TUI display controls (non‑interactive toggles): `--display {detailed|compact|dense|auto}` (default `auto`), `--display-details {right|none}` (default `none`).
- Identifier verbosity: `--show-ids full` expands to full IDs in streaming and prints a note in the TUI header.
- Emoji control: `--no-emoji` disables emojis in streaming output.
- CI artifacts: `--ci-artifacts out.zip` writes a deterministic, small zip with `results/summary.json`, `results/branches.txt`, and `results/tasks/k{short8(qual_key)}.json` (TaskResult + minimal metadata). All contents follow the public event shapes, use run‑relative paths, and are redacted.

**Helper Commands**:

- `orchestrator doctor`: Performs mandatory checks (Docker daemon reachable and version, disk free threshold, repo validity, base branch exists, temp dir writable, presence of either OAuth token or API key, `models.yaml` load and checksum agreement) and informational checks (SELinux detection on Linux, WSL2 hints on Windows). Outputs a short pass/fail table with concise “Try:” bullets on failures. Exits `0` only if all mandatory checks pass; otherwise `1`.

- `orchestrator config print`: Prints effective merged config honoring precedence (CLI > env > .env > project file > global defaults > built‑in). Shows source per key (cli/env/file/default); secrets are redacted by default. Supports `--json`. Unredaction is allowed only when `ORC_ALLOW_UNREDACTED=1` is set and `--redact=false` is provided (intended for development).

Additional flags:
- `--debug`: Enables debug mode (also streams full logs to stderr in addition to files).

Cleanup semantics: On startup, orchestration performs a conservative orphan scan limited to containers labeled `orchestrator=true` in the current run namespace. Age calculations use the following precedence: `state.json` timestamps, then heartbeat file mtime, then Docker `CreatedAt`. Explicit `--clean-containers` is an operator action that removes across runs according to retention settings.

CLI design follows conventional Unix patterns; common tasks require minimal flags while complex workflows remain configurable.

## 5.6 Standalone TUI Operation

The TUI can run independently of the orchestrator for monitoring:

**Standalone Mode**: Launch with `python -m src.tui` to monitor existing runs:

```bash
# Monitor a specific run
python -m src.tui --run-id run_20250114_123456
```

**Use Cases**:

- Monitor runs from different terminals

Implementation notes (current TUI):
- The TUI renders via Rich at a fixed 10Hz. If the optional `watchdog` package is not available, it automatically falls back to a pure polling tail of `events.jsonl` without any loss of fidelity.
- Forcing display density: pass `--display {detailed|compact|dense|auto}` to override the automatic mode selection. This is useful when you want one-line summaries even for small runs.
- Non-TTY environments: TUI is not started; concise human logs are printed by default. Use `--json` for JSON events or `--no-tui` in a TTY to force streaming logs.
- Stalled indicator: For running instances that haven’t updated in >30s, the Activity shows a “stalled Ns” suffix to highlight potential hangs while keeping the last known step (e.g., “Container created (stalled 45s)”).
- Debug event processing separately
- Test display layouts without running instances
- Multiple team members viewing same run

## 5.7 Implementation Notes

**Missing Features from Specification**:

- Task-based progress tracking (shows time-based progress instead)
- Global progress bar in header (uses counts instead)

These were omitted as they required deeper Claude Code integration than available through the event stream.

# 6. Cross‑Cutting Concerns

## 6.1 Configuration System

Configuration follows a strict precedence hierarchy, making defaults sensible while allowing complete control when needed:

**Precedence Order** (highest to lowest):

1. CLI arguments — direct control for one‑off runs
2. Environment variables — deployment‑specific settings
3. `.env` file — development convenience (prints exactly one warning when used)
4. Project file `orchestrator.yaml` — shared team configuration
5. Global defaults — `~/.orchestrator/config.yaml` (preferred) or XDG fallback `~/.config/orchestrator/config.yaml` if the preferred path is absent. If both exist, the loader MUST prefer `~/.orchestrator/config.yaml` and print a one‑line info noting the XDG fallback was ignored.
6. Built‑in defaults

On invalid config, render a compact validation table with three columns: `field | reason | example`. At run start, print a truncated “Effective config” header (≤20 lines) including sources (cli/env/.env/project/global/default) with `secrets=REDACTED`, ending with “see `orchestrator config print` for full details”.

**Authentication**: Two credential types are supported. No explicit mode is required; the presence of credentials determines behavior.

- OAuth token (`CLAUDE_CODE_OAUTH_TOKEN`) — subscription access.
- API key (`ANTHROPIC_API_KEY`, optional `ANTHROPIC_BASE_URL`) — API access and custom endpoints.

Selection: If an OAuth token is set, use it. Otherwise, if an API key is set, use it. If neither is set, error with a clear message. A `--mode` flag may be provided but does not override missing credentials; credentials take precedence.

**Custom LLM Support**: When using API mode, `ANTHROPIC_BASE_URL` enables routing to custom endpoints. This allows local LLMs, proxies, or alternative providers that implement Claude's API. The Instance Runner passes this through to Claude Code without modification.

**Authentication Flexibility**:

- Fallback authentication from environment variables at startup
- Support for both OAuth tokens (subscription) and API keys
- Custom LLM endpoints via `ANTHROPIC_BASE_URL`

**Configuration Namespacing**: Each component reads its own config section:

- `runner.*` - Instance Runner settings
- `orchestration.*` - Parallelism limits, timeouts
- `tui.*` - Display preferences
- `logging.*` - Output paths, verbosity

This separation ensures components remain independent. Adding TUI color schemes does not affect runner configuration.

**Environment Variables**: Only authentication-related variables are supported:

```bash
CLAUDE_CODE_OAUTH_TOKEN=...
ANTHROPIC_API_KEY=...
ANTHROPIC_BASE_URL=...   # optional
```

**Configuration Merging**: Complex deep merge with recursive dictionary merging for nested configurations. Arrays are replaced, not merged.

**Model Mapping**: Friendly model names MUST resolve via a single shared mapping file `models.yaml`. Both orchestration and runner load from this single file. At process start, each component computes a checksum (e.g., SHA‑256) of the loaded `models.yaml`. Orchestration passes its checksum to the runner; the runner fails fast on mismatch. Any divergence or failure to load the same mapping in multi‑process deployments is a configuration error. Only when a mismatch/warn condition exists should the system print the checksum and resolved model IDs. If no message is printed at startup, the mappings match.

### 6.1.1 Default Values Catalog

Defaults used by orchestration and runner. Fingerprinting canonicalization treats missing fields as these explicit defaults, and **removes keys with `null` values prior to hashing** (i.e., `null` ≡ missing).

- model: `sonnet`
- import_policy: `auto`
- import_conflict_policy: `fail`
- skip_empty_import: `true`
- max_parallel_instances: `"auto"`  # auto => max(2, min(20, floor(host_cpu / runner.cpu_limit)))
- runner.max_turns: unset (tool decides)
- runner.timeout: `3600`
- runner.cpu_limit: `2`
- runner.memory_limit: `4g`
 - tui.refresh_rate_ms: `100`

Read-only review enforcement: If `import_policy="never"`, the runner MUST mount `/workspace` read‑only, replacing an existing container if necessary to satisfy RO semantics.

Events configuration (subset):
- events.retention_days: `30`            # prune terminal runs after this many days
- events.retention_grace_days: `7`       # wait at least this many days after strategy completion before pruning

Retention configuration:
- results.retention_days: `null`         # null means do not prune results by age
- orchestration.container_retention_success: `7200`   # seconds (2h)
- orchestration.container_retention_failed: `86400`   # seconds (24h)
- orchestration.retention.volume_hours: `24`

All defaults are validated and logged at run start. Fingerprint computation (RFC 8785 JCS) must apply these defaults before hashing.

### 6.1.2 Fingerprinting Defaults Scope

Defaults that participate in fingerprint canonicalization (set missing values to these before hashing):
- model
- import_policy
- import_conflict_policy
- skip_empty_import
- session_group_key
- resume_session_id
- plugin_name
- system_prompt
- append_system_prompt
- runner.cpu_limit
- runner.memory_limit
- runner.network_egress
- runner.max_turns (when present; drop if null)

Non‑semantic defaults (do NOT affect fingerprint):
- retention settings (logs/events/results/containers/volumes)
- TUI/console settings (refresh rates, verbosity)
- file paths and directory locations
- cleanup policies not affecting execution semantics

## 6.2 Logging System

Logging serves both debugging and audit purposes without cluttering the user experience:

**Structured JSON Logs**: All components emit structured logs with consistent fields:

- `timestamp` - ISO 8601 with milliseconds
- `component` - Origin (runner/orchestration/tui)
- `level` - Standard levels (debug/info/warn/error)
- `run_id` - Correlation across entire run
- `instance_id` - When applicable
- `message` - Human-readable description

**Message Sanitization**: All public events are sanitized recursively before write (see §6.3). Redaction applies to all public strings in event payloads, including but not limited to `final_message`, `message`, and any textual metadata fields present in `task.*` or `strategy.*` events.
- Additional context fields as relevant

**File Organization**: Logs are separated by component and run:

```
logs/
  run_20250114_123456/
    orchestration.jsonl
    runner.jsonl
    tui.jsonl
    events.jsonl  # Complete event stream
```

**Console Output & Levels**: Clean, purposeful console output (console level = INFO; files = DEBUG):

- TTY/TUI mode: TUI handles display. Only critical errors/warnings are surfaced outside the TUI frame; all other logs go to files.
- Non‑TTY/streaming: concise human logs using the hybrid line style (no ANSI colors), emojis permitted and disableable via `--no-emoji`.
- Debug mode (`--debug`): Full log stream to stderr in addition to files.

**Rotation and Cleanup**:
- Public event/state data (`logs/<run_id>/events.jsonl`, `logs/<run_id>/state.json`, and `orchestrator_state/<run_id>/state.json`) MUST NOT be pruned while a run is non‑terminal. They become eligible for pruning only after all top‑level strategies emit `strategy.completed` and after a grace period `events.retention_grace_days` (default: 7). `events.retention_days` controls total retention for terminal runs.
- Results (`results/<run_id>/`) are retained per `results.retention_days` (default: do not prune unless configured).

Logging captures detailed data to files while minimizing console noise.

**Advanced Logging Features**:

- Component-specific log file routing (runner.jsonl, orchestration.jsonl, tui.jsonl)
- JSON formatter with serialization fallback for complex objects
- Dynamic logger configuration based on debug mode
- Headless mode console output integration
- File size-based rotation with configurable backup count (applies to component logs only; never to `events.jsonl`)
- `events.jsonl` is never rotated during an active run; rotation/archival occurs only after the run completes
- Async rotation tasks to prevent blocking
 
**Final message truncation**: Maintain a 64KB limit for `final_message` in public events. When truncated, always write the full text under `logs/<run_id>/…` (run‑relative path) and print that path in streaming output and expose it in the TUI details pane.

**Failure diagnostics microcopy**: Console/TUI errors SHOULD follow a terse, helpful pattern:

`title` (lowercase, action‑oriented) — optional short context

`Try:`
- one or two imperative, specific suggestions

Examples:
- `docker error: cannot connect to daemon. Try: start Docker; check $DOCKER_HOST; run 'orchestrator doctor'.`
- `git error: base branch 'main' not found. Try: fetch 'origin'; verify branch name; run 'git branch --all'.`
- `auth error: no credentials. Try: set CLAUDE_CODE_OAUTH_TOKEN or ANTHROPIC_API_KEY.`
- `network blocked (egress=offline). Try: set runner.network_egress=online or configure proxy.`

**Custom redaction patterns**: In addition to built‑in redaction, teams MAY configure `logging.redaction.custom_patterns` (array of regex) to extend provider coverage. Public events MUST remain sanitized; environment/header dumps are forbidden.
  
Cost estimation configuration:

- When a plugin does not report cost but reports tokens, costs are estimated from `pricing.*` config keys (USD):
  - `pricing.anthropic.sonnet.input_per_1k_usd`
  - `pricing.anthropic.sonnet.output_per_1k_usd`
  - (similarly for other models)
- Orchestration performs the estimate and reports in results and TUI.

Estimation semantics: Currency is USD. Per-task cost is computed from the task’s model attribution and rounded to 4 decimal places; run totals sum per-task costs and are also rounded to 4 decimals.


## 6.3 Security and Isolation

Security focuses on protecting the host system and preventing instance interference:

**Container Isolation**: Each instance runs in a Docker container with:

- No privileged access
- Three volume mounts only: isolated workspace, /home/node persistent volume, and /tmp tmpfs
- Entire container filesystem read-only except the mounted volumes
- Container-specific network namespace with outbound internet access (configurable via `runner.network_egress = online|offline|proxy`; default `online`)
- Resource limits preventing system exhaustion
- Non-root user execution

**API Key Handling**: Authentication tokens are:

- Never logged or displayed
- Passed via environment variables to containers
- Validated on startup with clear errors
- Support for both OAuth tokens (subscription) and API keys
- Secrets MUST be redacted from logs and error traces; environment dumps are forbidden in runner events

**Centralized Redaction**: Orchestration MUST sanitize every public event (envelope + payload) in two stages before writing to `events.jsonl`:

1) Field-name redaction (case-insensitive): for any key name containing `token`, `key`, `secret`, `password`, `authorization`, or `cookie`, replace the value with `[REDACTED]` regardless of content shape (string/array/object).
2) Pattern sweep over all strings (values and nested text): redact bearer tokens and common credential formats, including but not limited to:
   - `Authorization: Bearer <...>`
   - Provider prefixes like `sk-...`, `ghp_...`, `gho_...`, `ghs_...`
   - JWT-like blobs (`^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$`)
   - Base64 basic-auth and API tokens (heuristic length thresholds)

By default, environment variables and headers MUST NOT be logged to public events. Only an allowlist of safe metadata keys may be included. Runner-internal logs MUST also avoid raw env/header dumps.

Patterns are configurable to extend provider coverage.

Sanitization scope: Redaction applies to all public strings in event payloads, including but not limited to `final_message`, `message`, and textual metadata.

**File System Boundaries**: Instances MUST NOT:

- Access the original host repository or any host paths except their isolated workspace at `/tmp/orchestrator/<run_id>/k_<short8(durable_key)>`
- See or modify the original repository
- Read other instances' working directories
- Escape their container boundaries
- Access any system paths outside their designated mounts

**Git Safety**: The isolated clone approach ensures:

- Host repository never exposed to containers
- Each task works in a completely separate git repository
- No shared git objects or metadata between instances
- Physical file copying with `--no-hardlinks` prevents inode-level interference
- Branch imports happen after container exits, eliminating concurrent access

Public event path policy: Public events MUST NOT include absolute host paths or host workspace paths. Run‑relative log paths under `logs/<run_id>/` are allowed (e.g., `final_message_path`).

These measures provide strong isolation without enterprise complexity and protect against accidents and basic isolation violations. Complete workspace isolation is the key defense—containers have no access to the host repository or other instances' work.

## 6.4 Resource Management

Resource management keeps things simple and functional:

**Parallel Instance Limit**: Single configuration value `max_parallel_instances` (default adaptive: `max(2, min(20, floor(host_cpu / runner.cpu_limit)))`). Prevents system overload and API rate limit issues. No complex scheduling or priorities; a simple pool is used. A warning MUST be logged if the configured value oversubscribes the host.

**Container Resources**: Fixed defaults that work well:

- 2 CPUs per container
- 4GB memory per container
- No disk quotas (rely on system capacity)

Override only if needed via `runner.cpu_limit` and `runner.memory_limit` settings. Most users never touch these.

**Cost Tracking**: Simple accumulation from Claude Code's reported costs. No budgets or limits are implemented. Users monitor costs in real time and cancel when needed.

**Timeouts**: Two-level timeout system:

- Tool-level turn/time limits as supported by the plugin (optional `runner.max_turns`; default unset)
- Container-level timeout (default 1 hour) as a fallback safety net

This dual approach catches both API-level runaway usage and container-level hangs. Both are configurable but defaults work for most cases.

Provide essential limits that prevent system failure while avoiding unnecessary complexity.

## 6.5 Data Persistence

Persistence focuses on essential data for resumability and results:

**Event Log**: Append-only `events.jsonl` with a single-writer model:

- One writer task computes `start_offset`, appends, and flushes according to the configured flush policy (buffers events and writes+fsyncs every `interval_ms` or `max_batch`, whichever comes first). The writer MUST acquire an OS-level exclusive lock on `logs/<run_id>/events.jsonl.lock` for the duration of the run. Crash semantics: state snapshots carry `last_event_start_offset`; on crash, replay up to the last fsynced batch.

**Lock Metadata (diagnostic)**: The lockfile SHOULD include `{ pid, hostname, started_at_iso }` metadata written after acquiring the OS lock to aid diagnostics. OS-level locking ensures locks are released when the writer process exits. Implementations MAY additionally implement stale-lock heuristics; they are not required for correctness.


**Filesystem Requirements**: The logs/state directories MUST be on a local filesystem; network filesystems are unsupported.

- Enables state reconstruction after crashes and provides an audit trail.
- Simple UTF-8 JSONL for easy parsing; partial final lines are ignored by readers until newline.
- Event envelope fields: `{id, type, ts, run_id, strategy_execution_id, key?, start_offset, payload}`.
- Task lifecycle events: `task.scheduled`, `task.started`, `task.completed`, `task.failed`, `task.interrupted`, plus `strategy.started/strategy.completed`. See the “Minimum Payload Fields” section for the canonical schema.
- Readers MUST resume from a durable offset (`last_event_start_offset`) rather than attempting to consume an unterminated final line. The writer-only lock and snapshot offset guarantee a safe resume point.

**State Snapshots**: Periodic `state.json` dumps of current state (primary snapshot is authoritative; the logs copy is best‑effort only):

- Every 30 seconds during execution.
- Contains full state, `last_event_start_offset`, and task index (completed/pending).
- Includes per-task: `state`, `started_at`, `completed_at`, `interrupted_at`, `branch_name`, `container_name`, `session_id`, `session_group_key`.
- Speeds up recovery by replaying only events after the `last_event_start_offset`.

Atomicity constraint: Snapshots MUST be written via temp-file-then-rename on the same filesystem as the target to ensure atomic replace semantics; cross-filesystem renames are forbidden.

**File Organization**: Data is organized per-run (primary state dir + optional duplicate under logs):

```
orchestrator_state/
  run_20250114_123456/
    state.json         # Primary state snapshot with last_event_start_offset

logs/
  run_20250114_123456/
    events.jsonl       # Events for this run only
    state.json         # Optional duplicate snapshot
    orchestration.jsonl  # Component logs
    runner.jsonl
    tui.jsonl

results/
  run_20250114_123456/
    summary.json       # Overview with metrics
    branches.txt       # List of created branches
    strategy_output/   # Strategy-specific data
```

**Event Ordering**: Critical events MUST be durably written before cleanup operations:

- Runner completion log entries include workspace paths; public `task.completed` events do not carry paths.
- Writer flushes and fsyncs before workspace deletion.
- Ensures audit trail remains complete for reconstruction.

**Crash Tolerance & Sessions**: Readers tolerate truncated last lines, resuming from the `last_event_start_offset`. Claude Code sessions are preserved via container+volume naming. On resume, orchestration reattaches by durable task key without duplicating containers or branches.

This approach balances durability with simplicity. No databases to manage and no complex schemas to migrate. Files are easy to inspect, back up, and understand. State snapshots are written atomically (temporary file + rename) and duplicated under `logs/<run_id>/state.json`.

## 6.6 Platform Support

The orchestrator includes extensive platform-specific support:

**Primary Platform**: Linux is the primary development and deployment platform with full feature support.

**macOS Support**: Fully supported via Docker Desktop. The SELinux `:z` flag is automatically excluded on macOS. Path length limitations are generally not an issue. Requires Docker Desktop installation.

**Windows Support**:

- WSL2 (Windows Subsystem for Linux) provides the supported configuration for best compatibility
- Alternative: Native Docker Desktop works but has limitations:
  - Path length restrictions (260 character limit)
  - Different path separators cause issues in some edge cases
  - Performance is typically slower than WSL2
  
WSL2 note: Place the repository inside the WSL filesystem (e.g., `~/repo`), not under `/mnt/c/...`, to avoid slow bind mounts. Bind-mounting NTFS paths into Linux containers can significantly degrade performance.

Native Windows note: If running outside WSL, enable Windows long‑path support or keep repository paths short to avoid path length issues. WSL2 remains the supported approach.

**Windows Subsystem for Linux (WSL)**: Automatic detection and path conversion:

- Detects WSL via /proc/version inspection
- Converts Windows paths to WSL format (C:\\Users → /mnt/c/Users)
- Provides WSL-specific Docker setup recommendations
- Handles Docker Desktop vs native Docker in WSL

**Docker Path Normalization**: Platform-aware path handling:

- Windows: Converts to Docker Desktop format (/c/Users/...)
- Unix/WSL: Uses standard paths
- Automatic detection of Docker environment

**SELinux Support**: Container security on systems with SELinux:

- Detects SELinux via kernel checks
- Applies `:z` volume mount flags when needed
- Ensures containers can access mounted volumes

Normative rule: Apply `:z` only on Linux with SELinux; never apply on macOS or Windows.

**Platform Recommendations**: On startup, provides platform-specific advice:

- WSL users: Docker backend configuration tips
- Windows users: WSL2 installation suggestions
- All platforms: Temp directory accessibility checks

**Cross-Platform Temp Directories**:

- Windows: Uses %TEMP% or C:\\Temp
- Unix: Uses /tmp
- Validates write permissions on startup

## 6.7 Operational Notes

If a `final_message` must be truncated, implementations MUST set `final_message_truncated=true` and write the full message to a run-relative path under `logs/<run_id>/` in `task.completed`.

- Events retention (pruning):
  - `events.retention_days` (default: 30)
  - `events.retention_grace_days` (default: 7)
  The orchestrator deletes `events.jsonl` and `runner.jsonl` for terminal runs older than the retention + grace window.

- Adaptive parallelism (default):
  - When `--max-parallel` is not specified, the orchestrator sets `max_parallel_instances = max(2, min(20, floor(host_cpu / runner.cpu_limit)))`.
  - The system detects cgroup CPU quota on Linux and warns when configured parallelism oversubscribes host CPUs.

- Error classification mapping:
  - When `network_egress=offline`, failures are classified as `task.failed.error_type="network"` unless canceled.

- Model mapping handshake:
  - A shared `models.yaml` mapping MUST be loaded at runtime. A checksum is emitted and validated to ensure consistency between orchestration and runner.

# 7. Operations

## 7.1 Starting a Run

Starting a run is designed to be frictionless while catching common errors early:

**Basic Invocation**: The simplest case requires only a prompt:

```bash
orchestrator "implement user authentication"
```

This uses defaults: SimpleStrategy, main branch, Sonnet model. Perfect for quick tasks.

**Model Selection**: Choose specific models for different tasks:

```bash
orchestrator "complex task" --model opus
orchestrator "standard task"  # Uses default: sonnet
```

**Strategy Selection**: Real power comes from choosing strategies:

```bash
orchestrator "refactor database layer" --strategy best-of-n -S n=5
```

Strategy-specific parameters are passed with `-S` flags. For multiple parameters:

```bash
orchestrator "build API" --strategy best-of-n --runs 3 -S n=5
```

Parameters are validated immediately with clear errors for missing required options.

**Pre-flight Checks**: Before scheduling any tasks, the orchestrator verifies:

- Docker daemon is running and accessible
- Repository exists and the requested `base_branch` exists and is cleanly check‑outable (warn on dirty working tree by default, which is safe to proceed since imports touch refs, not your working tree; use `--require-clean-wt` to enforce cleanliness)
- Authentication is configured (OAuth token or API key)
- Required tools are available in containers
- Sufficient disk space for logs and results

These checks take milliseconds but prevent frustrating failures mid-run. Better to fail fast with helpful errors.

**Run ID Generation**: Each run gets a unique ID `run_YYYYMMDD_HHMMSS_<short8>` where `<short8>` is the first 8 hex chars of a random UUID. This guarantees uniqueness under concurrent starts while preserving sortability.

**Configuration Loading**: Settings are resolved in precedence order and logged at startup. Users see exactly what configuration is active. No guessing about which config file was loaded or which environment variable took precedence.

The startup sequence is deliberately verbose in non-TUI mode, showing each initialization step. This transparency helps debugging configuration issues and builds confidence the run is properly set up.

## 7.2 Monitoring Progress

Monitoring is designed to answer the key question: "Is everything going as expected?"

**TUI Dashboard**: The default monitoring experience shows:

- Real-time task status with visual grouping by strategy
- Live cost accumulation for visibility
- Progress indicators based on Claude's task completion
- Clear failure indication with error snippets

The dashboard adapts to run scale automatically. Users do not configure view modes; behavior scales from small runs to large runs (for example, 3 to 300 tasks).

**Non-TUI Monitoring**: When TUI is disabled, progress streams to console (showing both the task key and instance id):

Identifier formats:

- `k{short8(qual_key)}` = first 8 hex chars of SHA‑256 of the fully‑qualified durable key `qual_key = f"{strategy_execution_id}|{durable_key}"` (shorthand: "k8")
- `inst-{first5}` = first 5 hex chars of the stable `instance_id`
- Prefix MUST be `[k{short8(qual_key)}][inst-{first5}] <message>` and uses the `k8` shorthand for `k{short8(qual_key)}`.

```
[k7aa12cc][inst-7a3f2] Started → feat_auth_1
[k7aa12cc][inst-7a3f2] Implementing authentication module...
[k7aa12cc][inst-7a3f2] Created auth/jwt.py with JWT handler
[k7aa12cc][inst-7a3f2] ✅ completed time=3m24s cost=$0.42 tokens=2.5k

[k19bb44a][inst-8b4c1] Started → reviewing feat_auth_1  
[k19bb44a][inst-8b4c1] Analyzing implementation quality...
[k19bb44a][inst-8b4c1] Strategy output → score=8.5, feedback="Good error handling"
[k19bb44a][inst-8b4c1] ✅ completed time=45s cost=$0.12 tokens=0.8k

[k2f88e01][inst-9d5e3] ❌ failed type=timeout after=60m cost=$2.41
```

Clean prefixes, instance correlation, key metrics. No timestamp spam or debug noise.

**Remote Monitoring**: The event log enables remote monitoring:

```
tail -f logs/run_20250114_123456/events.jsonl | jq
```

Teams build custom dashboards or alerts from this stream. The orchestrator does not prescribe monitoring solutions.

**Health Indicators**: Key metrics visible at all times:

- Queue depth (waiting tasks)
- Active task count vs limit
- Total cost accumulation rate
- Average task duration

These indicators reveal system health without overwhelming detail. Rising queue depth indicates too aggressive parallelism. Unusual cost rates prompt investigation.

## 7.3 Handling Failures

Failure handling follows a simple principle: assume transient issues and retry with session resume before declaring defeat.

**Instance-Level Retries**: Every instance failure triggers automatic retry:

- Default 3 attempts before marking as permanently failed
- Each retry resumes from the last Claude Code session checkpoint
- Exponential backoff between attempts (10s, 60s, 360s)
- Container preserved across retries for session continuity

This approach handles the reality of AI coding: API timeouts, rate limits, and temporary network issues. Most failures are transient. Session resume ensures retry does not waste prior work—if Claude wrote half the solution before failing, retry continues from that point.

**Failure Categories**: After exhausting retries, failures are marked with cause:

- Timeout: Exceeded instance time limit
- API Error: Persistent API failures (rate limit, auth)
- Container Error: Docker issues, out of memory
- Git Error: import/fetch failures (e.g., ref lock, pack corruption, insufficient disk)
 - Network Error: Blocked or unreachable network. When `runner.network_egress=offline`, failures due to blocked egress MUST be classified as `network`, include `egress=offline` in the message, and append a one‑time hint (once per task): `egress=offline → tool needs network; set runner.network_egress=online/proxy`. Orchestration MUST track an emitted‑hint flag per task key to avoid repeated hints.

The Instance Runner reports failure type but does not interpret it. Strategy code is responsible for interpretation.

**Cancellation vs Failure**

- Async cancellations caused by orchestrator-initiated shutdown (e.g., Ctrl+C) are treated as interruption, not failure, and MUST NOT be retried.
- `INTERRUPTED` is a first-class terminal state recorded for tasks halted by graceful shutdown or inferred after a crash.
- Strategies MUST NOT treat `INTERRUPTED` as `FAILED`.

**Strategy-Level Handling**: Strategies decide how to respond to failures:

- Best-of-N patterns: Continue with successful candidates; exclude failed or unscorable ones.
- Inline scoring patterns: If scoring fails after one repair attempt, exclude the candidate rather than coercing a score.
- Custom patterns: Implement domain-specific recovery and selection logic.

This separation is crucial. Infrastructure (Runner) handles retries for transient issues. Business logic (Strategy) handles semantic failures. A network blip gets retried automatically. A fundamental task impossibility gets surfaced to strategy.

**Partial Success Scenarios**: Reality is messy - some instances succeed, others fail:

- 47 of 50 succeed: Results show both successes and failures
- User decides if 94% success rate is acceptable
- Failed instances preserved for debugging
- Clear accounting of what worked and what didn't

No hidden failures or averaged-away problems. Users see exactly what happened and make informed decisions.

**Container Preservation**: Failed instance containers are kept longer than successful ones:

- Failed: 24 hour retention for debugging
- Successful: 2 hour retention
- Contains full Claude session, logs, partial work

This enables post-mortem analysis. Why did instance 3 fail after retries? Check its container, review Claude's session, understand the issue.

Be optimistic about recovery, transparent about failures, and pragmatic about partial success.

## 7.4 Resume and Recovery

Resume capability preserves work across interruptions while keeping control explicit:

**Graceful Interruption**: Ctrl+C triggers immediate shutdown:

1. Stop all running containers (preserving their state), regardless of `finalize` settings
2. Save current orchestration state snapshot
3. Set all RUNNING tasks to `INTERRUPTED` and persist `interrupted_at`; emit canonical `task.interrupted` for tasks with a durable key
4. Display resume command
5. Exit quickly (typically under 10 seconds for 20 containers)

Users see: `Run interrupted. Resume with: orchestrator --resume run_20250114_123456`

The key insight: stopping containers preserves their state. When resumed, instances continue from their last checkpoint. No work is lost, but shutdown is responsive. Users pressing Ctrl+C want immediate response, not graceful completion.

Note: The CLI flag `--respect-finalize-on-shutdown` preserves containers with `finalize=false` that would otherwise keep running; default behavior is to stop all. After a forced stop, standard retention timers apply (successful: 2h, failed: 24h) from the time of stop.

**Container Stop vs Kill**: Containers are stopped, not killed:

- `docker stop` sends SIGTERM, allowing clean shutdown
- 10-second grace period before SIGKILL
- Containers stopped in parallel to minimize total time
- Session remains resumable after stop

This balance ensures quick shutdown while maximizing resumability.

**Interrupted State Representation**

- The system MUST persist which tasks were interrupted by recording state=`INTERRUPTED` and an `interrupted_at` timestamp in `state.json`.
- Graceful shutdown MUST NOT mark tasks `FAILED` solely due to cancellation.

**Crash vs Graceful Interruption**

- In a hard crash or power loss, interruption markers are not written. On resume, any instance that is `RUNNING` in `state.json` and has no terminal state event at or after `last_event_start_offset` MUST be treated as "interrupted by crash" and handled under the Interrupted rules.

**Explicit Resume**: Recovery requires deliberate action:

```bash
orchestrator --resume run_20250114_123456
```

No automatic detection of previous runs. No "found interrupted run, continue?" prompts. If users want to resume, they explicitly say so. This prevents confusion and unexpected behavior.

**Resume State Rules**:

- **Completed instances**: No action, remain completed

- **Failed instances**: No action, remain failed

- **Interrupted instances** (including those inferred after a crash):
  - If container exists AND plugin supports resume: Resume from saved session
- If container exists BUT plugin does not support resume: Record diagnostic `resume_diagnostic=cannot_resume` in state metadata
  - If container missing BUT workspace exists: Record diagnostic `resume_diagnostic=container_missing` in state metadata
  - If both container and workspace missing: Record diagnostic `resume_diagnostic=artifacts_missing` in state metadata

- **Queued instances**: Start normally

Override rule: On resume, orchestration MUST override any `resume_session_id` present in a task input with the most recent persisted `session_id` from `state.json` before calling the runner. This prevents races with subsequent session updates.

Execution scope: Resume re-enters strategy code so downstream phases (e.g., scoring/review) can be scheduled as each generation completes. Durable task keys and fingerprint checks ensure idempotency: re-entry MUST NOT duplicate already-registered work. Only tasks that were previously registered (QUEUED/RUNNING/INTERRUPTED) or deterministically rescheduled by strategy re-entry will execute; no speculative replay of arbitrary past code occurs.

Diagnostic note: The isolated workspace is a first-class resume artifact. On resume, the runner reuses the prior workspace when present and valid, preserving uncommitted changes. If the workspace is missing or invalid, resume proceeds with a fresh clone (files from the prior attempt will not be present in that case). Status diagnostics reference workspace presence for post‑mortem analysis.

**Immediate Finalization on Resume**

- If after restoration and verification there are no runnable tasks (all are terminal or not resumable), the orchestrator immediately finalizes the run and exits. Completion is inferred when all top‑level strategies emit `strategy.completed`.

Notes on Sessions:

- Each instance's `session_id` MUST be persisted in `state.json`. Resume MUST rely on this persisted `session_id` rather than event replay to determine resumability. If event replay does occur and includes newer `session_id` updates, those MUST overwrite the in-memory value before any resume checks.
 - When resuming a task (operator-initiated resume), the runner MUST pass the session identifier to the tool's CLI resume flag and MUST NOT re-send the original prompt. The session state drives continuation; no duplicate prompt text is provided on resume.

Resume knobs:

- `--resume-fresh` MUST re-run incomplete instances with fresh containers (new container name, `reuse_container=false`, and no session). Branch naming remains unchanged. appends a short suffix to the container name for uniqueness (e.g., `_r<short>`).
- stores `reuse_container` in per-instance metadata to drive container reuse on subsequent runs.

Special cases:

- Plugin without session support: Strategy can choose to restart fresh or fail
- Corrupted session: Detected by plugin, treated as failed with `session_corrupted` error
- User can pass `--resume-fresh` to restart interrupted instances without sessions

**State Reconstruction**: Resume follows a simple sequence:

1. Load run snapshot (instance states, strategy progress) from `state.json`
2. Read events from saved `last_event_start_offset` in `events.jsonl`
3. Verify containers still exist for interrupted instances
4. Restart stopped containers and resume sessions where possible
5. Continue strategy execution from saved point

Missing containers or workspaces are handled according to the rules above. No complex recovery heuristics.

**Run Management Commands**: Simple tools for run inspection:

```bash
orchestrator --list-runs              # Show all runs with status
orchestrator --show-run <run-id>      # Display run details
orchestrator --cleanup-run <run-id>   # Remove containers and state
```

These commands provide visibility without magic. Users control their runs explicitly.

Preserve work through session continuity, while requiring explicit decisions about recovery; no implicit automatic behaviors.

## 7.5 Snapshot Atomicity

All snapshots MUST be written atomically using a temp-file-then-rename pattern to avoid partial/corrupt files:

- Primary snapshot: `orchestrator_state/<run_id>/state.json`
- Duplicate snapshot (for convenience and multi-UI): `logs/<run_id>/state.json`

Both MUST be written via a temporary file (e.g., `state.json.tmp`) and then `rename()`d to the final path so readers never observe partial JSON. Readers use the primary snapshot and fall back to the duplicate if the primary is missing or corrupt.

## 7.6 Results and Reporting

Results presentation focuses on actionability - what branches were created and how to evaluate them:

**Summary Display**: At run completion, users see:

```
═══ Run Complete: run_20250114_123456 ═══

Strategy: best-of-n
  n: 2
  
Runs: 3

Results by strategy:

Strategy #1 (best-of-n):
  ✓ orc/bestofn/run_20250114_123456/k5d3a9f2  3m 12s • $0.38 • 2.3k tokens
    strategy_output (example): score=7.5, complexity=medium, test_coverage=85%
  ✓ orc/bestofn/run_20250114_123456/k7aa12cc  3m 45s • $0.41 • 2.5k tokens  
    strategy_output (example): score=8.5, complexity=low, test_coverage=92%
  → Selected: orc/bestofn/run_20250114_123456/k7aa12cc

Strategy #2 (best-of-n):
  ✓ orc/bestofn/run_20250114_123456/k19bb44a  4m 23s • $0.52 • 3.1k tokens
    strategy_output (example): score=9.0, complexity=high, test_coverage=78%
  ✗ orc/bestofn/run_20250114_123456/k2f88e01  Failed: timeout after 3 retries
  → Selected: orc/bestofn/run_20250114_123456/k19bb44a

Strategy #3 (best-of-n):  
  ✓ orc/bestofn/run_20250114_123456/k8c0d3aa  3m 56s • $0.44 • 2.7k tokens
    strategy_output (example): score=8.0, complexity=medium, test_coverage=88%
  ✓ orc/bestofn/run_20250114_123456/k0a9f3de  3m 33s • $0.39 • 2.4k tokens
    strategy_output (example): score=7.0, complexity=low, test_coverage=90%
  → Selected: orc/bestofn/run_20250114_123456/k8c0d3aa

Summary:
  Total Duration: 8m 45s
  Total Cost: $2.14
  Success Rate: 5/6 tasks (83%)
  
Final branches (3):
  orc/bestofn/run_20250114_123456/k7aa12cc
  orc/bestofn/run_20250114_123456/k19bb44a
  orc/bestofn/run_20250114_123456/k8c0d3aa

Full results: ./results/run_20250114_123456/
```

**Results Directory**: Structured output for further analysis:

- `summary.json` - Machine-readable version of above
- `branches.txt` - Simple list for scripting
- `metrics.csv` - Task-level metrics for analysis
- `strategy/` - Strategy-specific outputs (scores, feedback)

**Branch Comparison**: Practical next steps are suggested:

```
To compare implementations:
  git diff main..orc/bestofn/run_20250114_123456/k7aa12cc
  git checkout orc/bestofn/run_20250114_123456/k8c0d3aa
  
To merge selected solution:
  git merge orc/bestofn/run_20250114_123456/k8c0d3aa
```

**Export Formats**: Results can be exported for different audiences:

- JSON for tooling integration
- Markdown for documentation
- CSV for spreadsheet analysis

No complex reporting engine; structured data users can process with familiar tools.

Results aim to make it clear what was produced and how to use it. The orchestrator's job ends at branch creation; users decide what to merge.

## 7.7 Maintenance and Pruning

The orchestrator provides maintenance commands to prune old artifacts according to retention settings:

- `--prune`: deletes old run logs and results.
  - Logs under `logs/run_*` are pruned when `completed_at` (or mtime fallback) is older than `events.retention_days + events.retention_grace_days`.
  - Results under `results/run_*` are pruned when older than `results.retention_days` when configured; when unset, results are not pruned by age.
- `--prune-dry-run`: prints what would be removed without deleting.

 
## 7.8 UX Non‑Goals & Risks

- No interactive TUI controls or shortcuts; display‑only with non‑interactive flags.
- No shell completions in this release.
- No additional PII redaction by default (beyond centralized secret redaction); teams can extend with `logging.redaction.custom_patterns`.
- No budget/threshold nags; footer shows totals only.
- Branch namespace changed to hierarchical `orc/<strategy>/<run_id>/k{short8(qual_key)}`; this may affect scripts relying on the older flat pattern. Document migration and provide a deprecation note in release notes.

## 7.9 Migration Tips

Existing runs may contain branches using the older flat pattern `{strategy}_{run_id}_k{short8(qual_key)}`. New branches are hierarchical only. The orchestrator continues to read/display old branches; migration is optional. If you want to rename existing branches:

- List flat‑pattern branches:
  `git for-each-ref --format '%(refname:short)' refs/heads | grep -E '^[^/]+_run_[0-9]{8}_[0-9]{6}(_[0-9a-f]{8})?_k[0-9a-f]{8}$'`

- Preview mapping to hierarchical:
  `git for-each-ref --format '%(refname:short)' refs/heads | \
   while read -r b; do \
     n=$(echo "$b" | sed -nE 's@^([^_]+)_(run_[0-9]{8}_[0-9]{6}(?:_[0-9a-f]{8})?)_k([0-9a-f]{8})$@orc/\1/\2/k\3@p'); \
     if [ -n "$n" ]; then printf "%-60s -> %s\n" "$b" "$n"; fi; \
   done`

- Rename in a loop (interactive, stops on conflicts):
  `git for-each-ref --format '%(refname:short)' refs/heads | \
   while read -r b; do \
     n=$(echo "$b" | sed -nE 's@^([^_]+)_(run_[0-9]{8}_[0-9]{6}(?:_[0-9a-f]{8})?)_k([0-9a-f]{8})$@orc/\1/\2/k\3@p'); \
     if [ -n "$n" ] && [ "$b" != "$n" ]; then echo "$b -> $n"; git branch -m "$b" "$n"; fi; \
   done`

Notes:
- Use `git branch -M` to force overwrites only if you’re certain no collisions exist.
- Update any CI or scripts that parse branch names accordingly.
