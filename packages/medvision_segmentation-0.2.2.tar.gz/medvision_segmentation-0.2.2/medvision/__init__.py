"""
MedVision - A Medical Image Segmentation Framework based on PyTorch Lightning
"""

__version__ = "0.1.0"
