from serverless.service import Service
from serverless.service.configuration import Configuration
