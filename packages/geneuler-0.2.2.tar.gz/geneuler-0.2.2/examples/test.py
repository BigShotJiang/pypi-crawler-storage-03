# examples/quickstart.py
# --- prefer local source tree (src/) over any installed geneuler -------------
import os, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, "src")
if os.path.isdir(SRC) and SRC not in sys.path:
    sys.path.insert(0, SRC)

# sanity print (so you know which one got imported)
import geneuler as _ge; print("geneuler imported from:", os.path.dirname(_ge.__file__))

# ----------------------------------------------------------------------------- 
from geneuler.mesh import Mesh

# Example 1: from a bbox
m = Mesh.from_bbox({"x":(-60,60), "y":(0,150), "z":(-120,120)}, h=10.0)
m.export_html_viewer("out/mesh_view.html")

# Example 2: from a STEP/STL/OBJ
m = Mesh.from_surface("/Users/mohamadkokh/Desktop/GenEuler/Code/GenEuler_0.1.0/testing.stp", h=8.0, reconstruct_volume=True)
m.export_html_viewer("out/mesh_view2.html")