# common module

::: multiomictree.common