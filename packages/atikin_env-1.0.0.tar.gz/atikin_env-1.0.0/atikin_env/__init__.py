from .core import load_env, get

__all__ = ["load_env", "get"]
__version__ = "1.0.0"
