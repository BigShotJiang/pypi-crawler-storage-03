"""Command-line interface for azure-openai-limits package."""

from . import _main

if __name__ == "__main__":
    _main()
