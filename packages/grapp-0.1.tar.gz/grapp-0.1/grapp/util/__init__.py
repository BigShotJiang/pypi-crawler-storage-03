from .simple import allele_frequencies  # noqa: F401
