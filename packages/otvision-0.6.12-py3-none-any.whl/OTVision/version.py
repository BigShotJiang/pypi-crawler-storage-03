__version__ = "v0.6.12"


def otdet_version() -> str:
    return "1.4"


def ottrack_version() -> str:
    return "1.1"


def otvision_version() -> str:
    return __version__
