# word2speech/__main__.py
from word2speech import main

if __name__ == "__main__":
    main()
