# API

You can find here the organization of the library:

```{eval-rst}

.. autosummary::
   :toctree: _autosummary
   :recursive:

   phileas
```

Function, classes and attributes documentations:

:::{toctree}
:maxdepth: 1

factory
iteration
parsing
:::
