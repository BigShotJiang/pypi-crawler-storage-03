# Iteration

```{eval-rst}

.. automodule:: phileas.iteration
    :members:

.. automodule:: phileas.iteration.base
    :members:
    :show-inheritance:

.. automodule:: phileas.iteration.leaf
    :members:
    :show-inheritance:

.. automodule:: phileas.iteration.node
    :members:
    :show-inheritance:

.. automodule:: phileas.iteration.random
    :members:
    :show-inheritance:

.. automodule:: phileas.iteration.utility
    :members:
    :show-inheritance:
```
