# Factory

```{eval-rst}

.. automodule:: phileas.factory
    :members:
    :show-inheritance:
```
