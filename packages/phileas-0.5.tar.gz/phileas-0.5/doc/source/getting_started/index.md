# Getting started

:::{toctree}
:maxdepth: 1

introduction
installation
simple_example
:::
