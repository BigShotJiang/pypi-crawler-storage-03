from pytest_bdd import scenarios

scenarios("features")
