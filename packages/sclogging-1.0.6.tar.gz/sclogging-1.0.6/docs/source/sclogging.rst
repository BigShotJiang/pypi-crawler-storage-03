sclogging package
=================

.. automodule:: sclogging
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:


Submodules
----------


sclogging.sclogging_main module
-------------------------------

.. automodule:: sclogging.sclogging_main
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex: sclogging

.. autoclass:: Timer
   :members:

.. autofunction:: get_logger

.. autofunction:: set_config
