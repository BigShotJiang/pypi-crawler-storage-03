# Security Policy

## Supported Versions

| Version  | Supported          |
|----------| ------------------ |
| 1.0.6    | :white_check_mark: |
| <= 1.0.5 | :x:                |


## Reporting a Vulnerability

Shoot me a message.
I check my messages several times a day.
