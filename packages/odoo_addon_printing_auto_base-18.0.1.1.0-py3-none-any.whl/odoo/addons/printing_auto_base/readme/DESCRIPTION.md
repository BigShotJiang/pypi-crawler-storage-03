Base module to support automatic printing of a report or attachments.

Check other repo like stock-logistics-reporting module
printingauto_stock_picking for printing documents related to a stock
transfer.
