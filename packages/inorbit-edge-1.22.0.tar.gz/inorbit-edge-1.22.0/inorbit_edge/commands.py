# InOrbit commands constants shared by some modules

COMMAND_INITIAL_POSE = "initialPose"
COMMAND_NAV_GOAL = "navGoal"
COMMAND_CUSTOM_COMMAND = "customCommand"
COMMAND_MESSAGE = "message"
