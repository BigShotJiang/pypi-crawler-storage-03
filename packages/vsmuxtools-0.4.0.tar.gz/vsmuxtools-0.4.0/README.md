# vs-muxtools

The extension to muxtools with vapoursynth and encoding stuff

## How do I use this?

You might wanna check out the [guide/wiki](https://muxtools.vodes.pw/).

## Installation

Git is always the most updated one obviously but I can't guarantee that everything is in a working state.

You can also grab the latest stable ish versions from pip.

[![PyPI version](https://badge.fury.io/py/vsmuxtools.svg)](https://badge.fury.io/py/vsmuxtools)