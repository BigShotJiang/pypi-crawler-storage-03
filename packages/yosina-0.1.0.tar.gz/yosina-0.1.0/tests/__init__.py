"""Tests for the yosina library."""
