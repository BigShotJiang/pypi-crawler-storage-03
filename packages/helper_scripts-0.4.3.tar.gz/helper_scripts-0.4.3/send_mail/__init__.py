from send_mail.SendMail import SendMail
from send_mail.ConfigParser import ConfigHandler