Use the bolt widget in the chatter to execute the different AI options.

The options will be filtered according to the configuration.
