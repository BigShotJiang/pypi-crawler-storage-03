- Lorenzo Battistini \<<lorenzo.battistini@agilebg.com>\>
- Miquel Raïch \<<miquel.raich@forgeflow.com>\> (migration to v9 and
  v10)
- Hai Dinh \<<haidd.uit@gmail.com>\> (migration to V11)
- Nedas Zilinskas \<<nedas.zilinskas@xpansa.com>\> (Ventor, Xpansa Group
  \<<https://ventor.tech/>\>)
- Denis Valenchyts \<<denis@ventor.tech>\> (VentorTech OU
  \<<https://ventor.tech>\>)
- Helly kapatel \<<helly.kapatel@initos.com>\>
