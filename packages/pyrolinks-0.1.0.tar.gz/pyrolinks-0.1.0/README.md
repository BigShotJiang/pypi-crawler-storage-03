# PyroLink
A simple Pyrogram-based module to create streaming download links for Telegram files !
