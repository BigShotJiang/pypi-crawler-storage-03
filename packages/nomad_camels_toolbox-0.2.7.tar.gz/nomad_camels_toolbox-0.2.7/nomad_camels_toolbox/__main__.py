if __name__ == "__main__":
    from .qt_viewer import run_viewer

    run_viewer()
