======
String
======

.. currentmodule:: pydiverse.transform.ColExpr
.. autosummary::
    :toctree: _generated/
    :nosignatures:
    :template: accessor_method.rst

    str.contains
    str.ends_with
    str.join
    str.len
    str.lower
    str.replace_all
    str.slice
    str.starts_with
    str.strip
    str.to_date
    str.to_datetime
    str.upper
