===============
Type Conversion
===============

.. currentmodule:: pydiverse.transform

.. autosummary::
    :toctree: _generated/
    :template: short_title.rst
    :nosignatures:

    lit
    ColExpr.cast
