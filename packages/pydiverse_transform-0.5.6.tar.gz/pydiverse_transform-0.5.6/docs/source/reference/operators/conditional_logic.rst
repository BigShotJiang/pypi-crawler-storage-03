=================
Conditional Logic
=================

.. currentmodule:: pydiverse.transform

.. autosummary::
    :toctree: _generated/
    :template: short_title.rst
    :nosignatures:

    when
    coalesce
    ColExpr.map
