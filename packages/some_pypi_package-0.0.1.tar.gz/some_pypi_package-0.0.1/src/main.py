import numpy as np

def hello():
    print(np.array(list('hello from pypi_package')))
    