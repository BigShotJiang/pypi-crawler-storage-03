"""
FLV音视频时间戳分析工具包
"""

from .analyzer import main, cli_main

__version__ = "1.0.6"
__all__ = ["main", "cli_main"]