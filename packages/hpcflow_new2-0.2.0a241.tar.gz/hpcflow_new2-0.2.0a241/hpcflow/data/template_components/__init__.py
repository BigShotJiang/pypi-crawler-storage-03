"""YAML files containing built-in template components, used for demonstrations."""
