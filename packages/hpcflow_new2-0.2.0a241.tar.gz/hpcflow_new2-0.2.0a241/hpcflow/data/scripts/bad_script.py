def bad_script():
    raise SyntaxError("oh no!")
