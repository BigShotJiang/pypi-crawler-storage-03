import sys


def script_exit_test(exit_code):
    sys.exit(exit_code)
