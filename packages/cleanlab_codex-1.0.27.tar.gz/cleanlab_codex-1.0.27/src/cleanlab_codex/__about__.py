# SPDX-License-Identifier: MIT
__version__ = "1.0.27"
