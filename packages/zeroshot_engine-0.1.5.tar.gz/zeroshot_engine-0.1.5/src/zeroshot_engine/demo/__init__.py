"""Demo module for the ZeroShotENGINE package."""

from .demo_runner import run_demo_classification

__all__ = ["run_demo_classification"]
