.. Prezentprogramo! documentation master file.

Prezentprogramo! - Merging convenience and cool!
================================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction.rst
   usage.rst
   presentations.rst
   designing.rst
   templates.rst
