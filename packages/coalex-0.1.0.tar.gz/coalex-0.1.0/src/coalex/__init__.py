"""Coalex SDK for observability and monitoring."""

__version__ = "0.1.0"