# for backward compatility
print(
    "WARNING: Using webapp.material is deprecated. Module has been moved to webapp.components.material"
)
from .components.material import *
