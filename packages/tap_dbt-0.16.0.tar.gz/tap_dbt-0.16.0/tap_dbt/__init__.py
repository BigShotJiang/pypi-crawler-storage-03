"""Singer tap for the dbt Cloud API."""
