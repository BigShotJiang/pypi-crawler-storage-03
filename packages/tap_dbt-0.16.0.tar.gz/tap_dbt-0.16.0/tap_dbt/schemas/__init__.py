"""OpenAPI schema for dbt Cloud."""
