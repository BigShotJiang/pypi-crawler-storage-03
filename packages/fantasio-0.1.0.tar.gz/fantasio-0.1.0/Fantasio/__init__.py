# Fantasio/__init__.py

# Importer tous les modules nécessaires
from .auto import *
from .automatic import *
from .fantasio import *
from .fitting_GUI_functions import *
from .GUI_functions import *
from .inter import *
from .interactive import *
from.test import *
