# compiler-config

OQC's task level compiler configuration. The compiler-config package is an internal dependency of [QAT](https://github.com/oqc-community/qat) 
(OQC's compiler and runtime) and a dependency of our QCaaS (Quantum Computing as a Service) client. *End users should not need to interact with this package except via QAT or QCAAS client.*

#### Licence

This code in this repository is licensed under the BSD 3-Clause Licence.
Please see [LICENSE](LICENSE) for more information.