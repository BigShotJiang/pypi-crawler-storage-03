﻿homodyne.optimization.mcmc
==========================

.. currentmodule:: homodyne.optimization

.. automodule:: mcmc