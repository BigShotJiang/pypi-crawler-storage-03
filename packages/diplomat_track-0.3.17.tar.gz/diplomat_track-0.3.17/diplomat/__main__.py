from diplomat._cli_runner import main

main()
