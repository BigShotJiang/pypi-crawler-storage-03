## Checklist
Please tick off where applicable. Have you:
- [ ] updated the version number in [pyproject.toml](pyproject.toml)?
- [ ] updated the version number in [action.yml](https://github.com/DFE-Digital/splunk-app-packager/blob/composite-deploy-action/action.yml#L41)?
- [ ] explained the change?
- [ ] confirmed the PR checks have passed?

## Explanation of change


## Link to bug report or github issue
