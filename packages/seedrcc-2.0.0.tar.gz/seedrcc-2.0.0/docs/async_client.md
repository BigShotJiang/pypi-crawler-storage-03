# Asynchronous Client

This page contains the API reference for the asynchronous `AsyncSeedr` client.

::: seedrcc.async_client.AsyncSeedr
    options:
      show_root_heading: true
      show_source: true
      members_order: source
