# Synchronous Client

This page contains the API reference for the synchronous `Seedr` client.

::: seedrcc.client.Seedr
    options:
      show_root_heading: true
      show_source: true
      members_order: source
