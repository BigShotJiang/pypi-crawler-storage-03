"""
browsr __main__ hook
"""

from browsr.cli import browsr

if __name__ == "__main__":
    browsr()
