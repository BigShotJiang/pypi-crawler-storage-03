"""
Screens for browsr
"""

from browsr.screens.code_browser import CodeBrowserScreen

__all__ = ["CodeBrowserScreen"]
