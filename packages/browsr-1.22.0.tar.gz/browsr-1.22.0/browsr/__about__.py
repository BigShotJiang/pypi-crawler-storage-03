"""
`browsr` version file.
"""

__author__ = "Justin Flannery"
__email__ = "justin.flannery@juftin.com"
__application__ = "browsr"
__version__ = "1.22.0"
