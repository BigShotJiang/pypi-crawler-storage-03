# Constants
IDENTITY_GRADIENT_DATA = ""  # default gradient value

BACKWARD_PASS_MAX_RETRIES = 3  # max retries of backward pass
