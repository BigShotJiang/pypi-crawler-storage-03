import os

LOG_LEVEL = os.environ.get('LOG_LEVEL', 'WARNING')
