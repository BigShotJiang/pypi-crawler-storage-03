from mjaf.logging._core import set_handlers

__all__ = [
    'set_handlers',
]
