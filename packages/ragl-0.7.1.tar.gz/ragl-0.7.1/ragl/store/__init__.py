"""
Storage and persistence layer for ragl.

The store subpackage supports various backend storage systems and
provides a unified API for data persistence operations.
"""
