#!/usr/bin/env python3
"""
Tests for the NL2Cmd package.
"""

import pytest
from nl2cmd import (
    NL2Cmd, NL2CmdResult, CommandContext, IntentRegistry, 
    TextExtractor, CommandChaining, IntentInference, 
    CommandGenerator, CommandSynthesis, CommandValidator, OSDetector
)


class TestOSDetector:
    """Test OS detection functionality."""
    
    def test_detect_os(self):
        """Test OS detection."""
        os_name = OSDetector.detect_os()
        assert os_name in ["linux", "macos", "windows"]
    
    def test_normalize_os_name(self):
        """Test OS name normalization."""
        assert OSDetector.normalize_os_name("darwin") == "macos"
        assert OSDetector.normalize_os_name("mac") == "macos"
        assert OSDetector.normalize_os_name("linux") == "linux"
        assert OSDetector.normalize_os_name("windows") == "windows"
        assert OSDetector.normalize_os_name("unknown") == "linux"  # default


class TestTextExtractor:
    """Test text extraction functionality."""
    
    def test_extract_path(self):
        """Test path extraction."""
        assert TextExtractor.extract_path("list files in /home/user") == "/home/user"
        assert TextExtractor.extract_path("go to directory ./src") == "./src"
        assert TextExtractor.extract_path("show contents of C:\\Users\\user") == "C:\\Users\\user"
    
    def test_extract_quoted_text(self):
        """Test quoted text extraction."""
        assert TextExtractor.extract_quoted_text('search for "error" in logs') == "error"
        assert TextExtractor.extract_quoted_text("no quotes here") is None
    
    def test_extract_number(self):
        """Test number extraction."""
        assert TextExtractor.extract_number("show first 10 lines") == 10
        assert TextExtractor.extract_number("kill process with pid 1234") == 1234


class TestIntentRegistry:
    """Test intent registry functionality."""
    
    def test_detect_intent(self):
        """Test intent detection."""
        registry = IntentRegistry()
        assert registry.detect_intent("show files") == "ls"
        assert registry.detect_intent("current directory") == "pwd"
        assert registry.detect_intent("create folder") == "mkdir"
    
    def test_get_boolean_flags(self):
        """Test boolean flag extraction."""
        registry = IntentRegistry()
        flags = registry.get_boolean_flags("show hidden files recursively")
        assert flags["hidden"] is True
        assert flags["recursive"] is True
        assert flags["force"] is False


class TestCommandContext:
    """Test command context model."""
    
    def test_context_creation(self):
        """Test context creation."""
        ctx = CommandContext()
        assert ctx.path is None
        assert ctx.recursive is False
        assert ctx.hidden is False
    
    def test_context_with_values(self):
        """Test context with values."""
        ctx = CommandContext(
            path="/home/user",
            recursive=True,
            hidden=True
        )
        assert ctx.path == "/home/user"
        assert ctx.recursive is True
        assert ctx.hidden is True


class TestCommandValidator:
    """Test command validation functionality."""
    
    def test_validation(self):
        """Test command validation."""
        validator = CommandValidator("linux")
        ctx = CommandContext(hidden=True, recursive=True)
        
        # Test valid command
        valid, msg = validator.validate("ls", ctx, "ls -la -R")
        assert valid is True
        
        # Test invalid command (missing hidden flag)
        valid, msg = validator.validate("ls", ctx, "ls -R")
        assert valid is False
        assert "Hidden files requested" in msg
    
    def test_risky_command_detection(self):
        """Test risky command detection."""
        validator = CommandValidator("linux")
        ctx = CommandContext()
        
        assert validator.is_risky_command("rm", ctx) is True
        assert validator.is_risky_command("ls", ctx) is False


class TestCommandGenerator:
    """Test command generation functionality."""
    
    def test_basic_commands(self):
        """Test basic command generation."""
        generator = CommandGenerator("linux")
        ctx = CommandContext()
        
        # Test pwd
        cmd, alts, risky, clarify, explanation, breakdown = generator.generate_commands("pwd", ctx)
        assert cmd == "pwd"
        assert risky is False
    
    def test_ls_with_flags(self):
        """Test ls command with flags."""
        generator = CommandGenerator("linux")
        ctx = CommandContext(hidden=True, long=True, recursive=True)
        
        cmd, alts, risky, clarify, explanation, breakdown = generator.generate_commands("ls", ctx)
        assert "-a" in cmd  # hidden
        assert "-l" in cmd  # long
        assert "-R" in cmd  # recursive


class TestCommandSynthesis:
    """Test command synthesis functionality."""
    
    def test_synthesis(self):
        """Test command synthesis."""
        synthesis = CommandSynthesis("linux")
        ctx = CommandContext(path="/home/user")
        
        cmd, alts, explanation, breakdown, msg = synthesis.synthesize_best_effort(
            "show largest files", ctx
        )
        assert "du -sh" in cmd
        assert "sort -h" in cmd


class TestIntentInference:
    """Test intent inference functionality."""
    
    def test_basic_intents(self):
        """Test basic intent inference."""
        registry = IntentRegistry()
        inference = IntentInference(registry)
        
        intent, ctx = inference.infer_intent("show files", "show files in /home/user")
        assert intent == "ls"
        assert ctx.path == "/home/user"
    
    def test_intent_with_flags(self):
        """Test intent inference with flags."""
        registry = IntentRegistry()
        inference = IntentInference(registry)
        
        intent, ctx = inference.infer_intent(
            "list hidden files recursively", 
            "list hidden files recursively in /tmp"
        )
        assert intent == "ls"
        assert ctx.hidden is True
        assert ctx.recursive is True


class TestCommandChaining:
    """Test command chaining functionality."""
    
    def test_chaining_initialization(self):
        """Test chaining initialization."""
        translator = NL2Cmd(forced_os="linux")
        chaining = CommandChaining(translator)
        assert chaining.translator is translator


class TestNL2Cmd:
    """Test main NL2Cmd class."""
    
    def test_initialization(self):
        """Test NL2Cmd initialization."""
        translator = NL2Cmd(forced_os="linux")
        assert translator.os == "linux"
        assert translator.intent_registry is not None
        assert translator.command_generator is not None
    
    def test_basic_translation(self):
        """Test basic translation."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("show current directory")
        
        assert isinstance(result, NL2CmdResult)
        assert result.command == "pwd"
        assert result.os == "linux"
        assert result.clarification_required is False
    
    def test_translation_with_flags(self):
        """Test translation with flags."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("list all files including hidden ones")
        
        assert isinstance(result, NL2CmdResult)
        assert "ls" in result.command
        assert "-a" in result.command  # hidden flag
    
    def test_translation_with_path(self):
        """Test translation with path."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("list files in /home/user")
        
        assert isinstance(result, NL2CmdResult)
        assert "ls" in result.command
        assert "/home/user" in result.command
    
    def test_translation_requires_clarification(self):
        """Test translation that requires clarification."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("change directory")
        
        assert isinstance(result, NL2CmdResult)
        assert result.clarification_required is True
        assert "Please specify" in result.error
    
    def test_chaining_translation(self):
        """Test chaining translation."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("list files then count them")
    
        assert isinstance(result, NL2CmdResult)
        assert "ls" in result.command
        assert "wc" in result.command or "count" in result.explanation
        # For counting operations, we use pipe (|) instead of && for efficiency
        assert "|" in result.command
    
    def test_piping_translation(self):
        """Test piping translation."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("list files and pipe into grep error")
        
        assert isinstance(result, NL2CmdResult)
        assert "|" in result.command
        assert "ls" in result.command
        assert "grep" in result.command
    
    def test_windows_translation(self):
        """Test Windows-specific translation."""
        translator = NL2Cmd(forced_os="windows")
        result = translator.translate("list files")
        
        assert isinstance(result, NL2CmdResult)
        assert result.os == "windows"
        assert "dir" in result.command
    
    def test_macos_translation(self):
        """Test macOS-specific translation."""
        translator = NL2Cmd(forced_os="macos")
        result = translator.translate("list files")
        
        assert isinstance(result, NL2CmdResult)
        assert result.os == "macos"
        assert "ls" in result.command


class TestIntegration:
    """Test integration scenarios."""
    
    def test_complex_scenario(self):
        """Test a complex translation scenario."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate(
            "find all log files in /var/log, then search for ERROR messages and count them"
        )
        
        assert isinstance(result, NL2CmdResult)
        # Should handle chaining and complex operations
        assert result.command != ""
    
    def test_error_handling(self):
        """Test error handling."""
        translator = NL2Cmd(forced_os="linux")
        result = translator.translate("")
        
        assert isinstance(result, NL2CmdResult)
        assert result.clarification_required is True
        assert "Please provide" in result.error


if __name__ == "__main__":
    pytest.main([__file__])
