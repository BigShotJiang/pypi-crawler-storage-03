#!/usr/bin/env python3
"""
Intent detection and synonym mappings for NL2Cmd.
"""

from typing import Dict, List


class IntentRegistry:
    """Registry of intents and their synonyms for semantic matching."""
    
    def __init__(self):
        # Canonical intents and synonyms for lightweight semantic matching
        self.intent_synonyms = {
            "pwd": ["pwd", "current directory", "current working directory", "where am i", "print working dir"],
            "ls": ["list", "show files", "display files", "ls", "list directory", "list contents"],
            "cd": ["cd", "change dir", "go to", "navigate to", "move to"],
            "mkdir": ["mkdir", "make directory", "create folder", "create directory"],
            "rm": ["rm", "remove", "delete", "erase", "trash"],
            "cp": ["cp", "copy", "duplicate"],
            "mv": ["mv", "move", "rename"],
            "find_files": ["find files", "locate files", "search files by name", "where is file"],
            "grep_text": ["search text", "grep", "find in files", "search in files", "look for text"],
            "ps_list": ["processes", "running processes", "list processes", "tasks"],
            "kill_proc": ["kill", "terminate process", "end process", "stop process", "pkill"],
            "list_ports": ["listening ports", "open ports", "network sockets", "ports"],
            "ip_addr": ["ip", "ip address", "network address"],
            "disk_usage": ["disk usage", "disk space", "free space", "space left", "storage"],
            "memory_usage": ["memory", "ram usage", "free memory", "mem usage"],
            "cpu_usage": ["cpu usage", "load", "system load", "cpu"],
            "compress": ["compress", "archive", "zip", "tar", "gzip"],
            "decompress": ["extract", "unzip", "untar", "decompress"],
            "update_packages": ["update packages", "upgrade packages", "refresh packages", "system update"],
            "install_pkg": ["install", "add package", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco", "scoop"],
            "git_status": ["git status"],
            "git_pull": ["git pull"],
            "git_push": ["git push"],
            "git_clone": ["git clone"],
            "git_commit": ["git commit"],
            "git_branch_list": ["git branch list", "list branches", "branches"],
            "git_branch_create": ["create branch", "new branch"],
            "git_log": ["git log", "commit history"],
            "git_diff": ["git diff"],
            "docker_ps": ["docker ps", "list containers", "containers"],
            "docker_images": ["docker images", "list images"],
            "docker_run": ["docker run", "run container"],
            "docker_build": ["docker build"],
            "docker_logs": ["docker logs", "container logs"],
            "cat_file": ["cat", "show file", "display file", "view file", "read file"],
            "head_file": ["head"],
            "tail_file": ["tail"],
            "chmod": ["chmod", "change permission"],
            "chown": ["chown", "change owner"],
            # Generic data wrangling intents (composition):
            "count_matches": ["count matches", "how many lines", "count lines matching", "number of occurrences"],
            "sort_by_size": ["sort by size", "largest files", "biggest files"],
            "sort_by_time": ["newest files", "oldest files", "sort by time"],
        }

        # Lightweight patterns to inform parsing and synthesis
        self.boolean_flags = {
            "recursive": ["recursive", "recursively", "subfolders", "subdirectories", "sub-folders", "sub dirs", "-r", "--recursive", "all subfolders"],
            "hidden": ["hidden", "dotfiles", "including hidden", "-a", "--all"],
            "long": ["long", "detailed", "attributes", "permissions", "metadata", "human readable", "human-readable", "-l", "--long"],
            "case_insensitive": ["case-insensitive", "case insensitive", "ignore case", "-i", "--ignore-case"],
            "exact": ["exact", "exactly", "whole word", "-w", "--word-regexp"],
            "force": ["force", "forcefully", "-f", "--force"]
        }

    def detect_intent(self, input_text: str) -> str:
        """Detect the primary intent from the input text."""
        best_match = None
        best_score = 0
        
        for intent, synonyms in self.intent_synonyms.items():
            for synonym in synonyms:
                if synonym in input_text:
                    score = len(synonym)  # Longer matches are better
                    if score > best_score:
                        best_score = score
                        best_match = intent
        
        return best_match

    def get_boolean_flags(self, input_text: str) -> Dict[str, bool]:
        """Extract boolean flags from input text."""
        return {k: any(tok in input_text for tok in toks) for k, toks in self.boolean_flags.items()}

    def get_closest_intent_by_overlap(self, input_text: str) -> str:
        """Find closest intent by token overlap when exact match fails."""
        import re
        tokens = set(re.findall(r"[a-z0-9]+", input_text.lower()))
        best_intent, best_score = "ls", 0  # Safe default
        
        for intent, synonyms in self.intent_synonyms.items():
            syn_tokens = set()
            for phrase in synonyms:
                syn_tokens.update(re.findall(r"[a-z0-9]+", phrase.lower()))
            score = len(tokens & syn_tokens)
            if score > best_score:
                best_score = score
                best_intent = intent
        
        return best_intent
