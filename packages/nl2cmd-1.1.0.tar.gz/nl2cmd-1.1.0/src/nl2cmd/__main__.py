"""
Entry point for running nl2cmd as a module: python -m nl2cmd
"""

from .cli import main

if __name__ == "__main__":
    main()
