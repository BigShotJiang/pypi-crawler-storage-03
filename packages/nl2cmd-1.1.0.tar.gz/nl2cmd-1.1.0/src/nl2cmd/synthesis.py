#!/usr/bin/env python3
"""
Best-effort command synthesis for NL2Cmd when exact intent matching fails.
"""

import json
import shlex
from typing import Tuple, List, Dict
from .models import CommandContext


class CommandSynthesis:
    """Synthesize commands using heuristics when exact intent matching fails."""
    
    def __init__(self, os_name: str):
        """Initialize with target operating system."""
        self.os = os_name

    def synthesize_best_effort(self, text: str, ctx: CommandContext) -> Tuple[str, List[str], str, Dict[str, str], str]:
        """
        Try to infer a plausible command using heuristics:
        - Recognize verbs like count/sort/filter/print/top N
        - Map to pipeline patterns with grep/sed/awk/sort/uniq/wc
        - When all else fails, produce a safe 'echo' placeholder demonstrating intent
        """
        from .extractors import TextExtractor
        
        low = text.lower()
        path = ctx.path or "."
        quoted = TextExtractor.extract_quoted_text(text)
        pattern = TextExtractor.extract_pattern(text)
        number = TextExtractor.extract_number(text)

        # Heuristic: "filter ... by ..." => grep pattern
        if "filter" in low or "only" in low or "containing" in low:
            patt = quoted or pattern or ""
            if patt:
                if self.os in ("linux", "macos"):
                    cmd = f'grep -R -n {shlex.quote(patt)} {shlex.quote(path)}'
                    return cmd, [], f"Search for lines containing '{patt}' under {path}", {"command": "grep -R -n", "text": patt, "path": path}, "Proposed a grep-based search; confirm pattern/path."
                else:
                    cmd = f'findstr /s /n /c:{json.dumps(patt)} {path}\\*'
                    return cmd, [], f"Search for lines containing '{patt}' under {path}", {"command": "findstr /s /n", "text": patt, "path": path}, "Proposed a findstr-based search; confirm pattern/path."

        # Heuristic: "top N largest" => size pipeline
        if ("largest" in low or "biggest" in low):
            n = number or 10
            if self.os in ("linux", "macos"):
                cmd = f'du -sh {shlex.quote(path)}/* | sort -h | tail -n {n}'
                return cmd, [], f"Show top {n} largest items under {path}", {"command": "du -sh * | sort -h | tail -n N", "path": path, "n": str(n)}, "Proposed size-based ranking; confirm path/N."
            else:
                cmd = f'powershell -NoProfile -Command "Get-ChildItem {shlex.quote(path)} | Sort-Object Length -Descending | Select-Object -First {n} Name,Length"'
                return cmd, [], f"Show top {n} largest items under {path}", {"command": "Get-ChildItem | Sort Length | Select -First N", "path": path, "n": str(n)}, "Proposed size-based ranking; confirm path/N."

        # Heuristic: "count them" or "count items" => wc -l
        if "count" in low and ("them" in low or "items" in low or "files" in low):
            if self.os in ("linux", "macos"):
                cmd = f'ls {shlex.quote(path)} | wc -l'
                return cmd, [], f"Count the number of items in {path}", {"command": "ls | wc -l", "path": path}, "Proposed a count operation; confirm path."
            else:
                cmd = f'powershell -NoProfile -Command "(Get-ChildItem {shlex.quote(path)} | Measure-Object).Count"'
                return cmd, [], f"Count the number of items in {path}", {"command": "Get-ChildItem | Measure-Object", "path": path}, "Proposed a count operation; confirm path."

        # Heuristic: "newest"/"oldest" N files
        if ("newest" in low or "oldest" in low) and (number or "top" in low):
            n = number or 10
            newest = "newest" in low
            if self.os in ("linux", "macos"):
                cmd = f'ls -lt {shlex.quote(path)} | head -n {n+1}' if newest else f'ls -ltr {shlex.quote(path)} | head -n {n+1}'
                return cmd, [], f"Show {n} {('newest' if newest else 'oldest')} items under {path}", {"command": "ls -lt/-ltr | head -n", "path": path, "n": str(n)}, "Proposed time-based listing; confirm path/N."
            else:
                order = "Descending" if newest else "Ascending"
                cmd = f'powershell -NoProfile -Command "Get-ChildItem {shlex.quote(path)} | Sort-Object LastWriteTime -{order} | Select-Object -First {n} Name,LastWriteTime"'
                return cmd, [], f"Show {n} {('newest' if newest else 'oldest')} items under {path}", {"command": "Get-ChildItem | Sort LastWriteTime | Select -First N", "path": path, "n": str(n)}, "Proposed time-based listing; confirm path/N."

        # Fallback demonstrator: echo the intent outline safely
        safe = f'echo "Requested: {text.strip()}"'
        return safe, [], "Echo the request as a placeholder for further clarification", {"command": "echo", "note": "placeholder"}, "Could not determine a precise action; provided a safe placeholder for clarification."
