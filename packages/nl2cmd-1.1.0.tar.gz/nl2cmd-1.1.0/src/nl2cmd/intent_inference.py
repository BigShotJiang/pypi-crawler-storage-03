#!/usr/bin/env python3
"""
Intent inference and context building for NL2Cmd.
"""

import re
from typing import Tuple
from .models import CommandContext
from .extractors import TextExtractor


class IntentInference:
    """Handle intent inference and context building from natural language."""
    
    def __init__(self, intent_registry):
        """Initialize with intent registry."""
        self.intent_registry = intent_registry

    def infer_intent(self, low: str, original: str) -> Tuple[str, CommandContext]:
        """Infer intent and build context from natural language input."""
        # Extract boolean flags
        flags = self.intent_registry.get_boolean_flags(low)
        
        # Build context
        ctx = CommandContext()
        ctx.path = TextExtractor.extract_path(original)
        ctx.pattern = TextExtractor.extract_pattern(original)
        ctx.query = TextExtractor.extract_quoted_text(original)
        
        # Set boolean flags
        ctx.recursive = flags.get("recursive", False)
        ctx.hidden = flags.get("hidden", False)
        ctx.long = flags.get("long", False)
        ctx.case_insensitive = flags.get("case_insensitive", False)
        ctx.exact = flags.get("exact", False)
        ctx.force = flags.get("force", False)
        ctx.parents = flags.get("recursive", False)  # Use recursive for parents in mkdir

        # Obvious, high-precision matches
        if re.search(r"\b(pwd|current\s+(?:working\s+)?directory|where\s+am\s+i|print\s+working\s+dir)\b", low):
            return "pwd", ctx

        if re.search(r"\b(list|show|display|ls)\b.*\b(files?|contents?|items?|directories|directory|folder)\b", low) or \
           (re.search(r"\b(list|ls)\b", low) and not re.search(r"\b(processes|ports|users)\b", low)):
            ctx.path = ctx.path or "."
            return "ls", ctx

        if re.search(r"\b(cd|change\s+(?:to\s+)?(?:directory|dir|folder)?|go\s+to|navigate\s+to|move\s+to)\b", low):
            if not ctx.path:
                ctx.clarification_required = True
                ctx.clarification_message = "Please specify the destination path for changing directory."
            return "cd", ctx

        if re.search(r"\b(mkdir|make\s+(?:directory|dir|folder)|create\s+(?:directory|dir|folder))\b", low):
            if not ctx.path:
                ctx.clarification_required = True
                ctx.clarification_message = "Please provide the directory name or path to create."
            return "mkdir", ctx

        if re.search(r"\b(remove|delete|rm|del|erase|trash)\b", low):
            target = ctx.path or ctx.pattern
            ctx.path = target
            if not target:
                ctx.clarification_required = True
                ctx.clarification_message = "Please specify the exact file or directory you want to delete."
            return "rm", ctx

        if re.search(r"\b(copy|cp|duplicate)\b", low):
            src, dst = TextExtractor.extract_src_dst(original)
            ctx.src = src
            ctx.dst = dst
            if not src or not dst:
                ctx.clarification_required = True
                ctx.clarification_message = "Please specify both source and destination for copy (e.g., copy ./a to ./b)."
            return "cp", ctx

        if re.search(r"\b(move|mv|rename)\b", low):
            src, dst = TextExtractor.extract_src_dst(original)
            ctx.src = src
            ctx.dst = dst
            if not src or not dst:
                ctx.clarification_required = True
                ctx.clarification_message = "Please specify both source and destination for move/rename."
            return "mv", ctx

        if re.search(r"\b(find|search|locate)\b.*\b(file|files)\b", low) and not re.search(r"\b(text|in\s+files|content|contents|string)\b", low):
            ctx.path = ctx.path or "."
            ctx.pattern = ctx.pattern or TextExtractor.extract_quoted_text(original) or ""
            if not ctx.pattern:
                ctx.clarification_required = True
                ctx.clarification_message = "Please specify a filename or pattern to search for (e.g., *.log or \"report.txt\")."
            return "find_files", ctx

        if re.search(r"\b(search|grep|find)\b.*\b(text|in\s+files|content|contents|string)\b", low):
            ctx.path = ctx.path or "."
            ctx.query = ctx.query or ctx.pattern or ""
            ctx.recursive = True
            ctx.line_numbers = True
            if not ctx.query:
                ctx.clarification_required = True
                ctx.clarification_message = "Please provide the text to search for (e.g., search text \"ERROR\" in ./logs)."
            return "grep_text", ctx

        # System/Network/Processes
        if any(w in low for w in ["processes", "running processes", "tasks"]) and "kill" not in low:
            ctx.format = "detailed" if ctx.long else "simple"
            return "ps_list", ctx

        if any(w in low for w in ["kill", "terminate process", "end process", "stop process", "pkill"]):
            pid = TextExtractor.extract_number(original)
            name = TextExtractor.extract_process_name(original)
            ctx.pid = pid
            ctx.name = name
            if not pid and not name:
                ctx.clarification_required = True
                ctx.clarification_message = "Please specify a PID or process name to terminate."
            return "kill_proc", ctx

        if any(w in low for w in ["ports", "listening", "open ports", "network sockets"]):
            return "list_ports", ctx

        if any(w in low for w in ["ip", "ip address", "network address"]):
            return "ip_addr", ctx

        if any(w in low for w in ["disk usage", "disk space", "free space", "space left", "storage"]):
            ctx.human_readable = True
            return "disk_usage", ctx

        if any(w in low for w in ["memory", "ram usage", "free memory", "mem usage"]):
            ctx.human_readable = True
            return "memory_usage", ctx

        if any(w in low for w in ["cpu usage", "system load", "cpu load", "cpu"]):
            ctx.realtime = True
            return "cpu_usage", ctx

        # File viewing / head / tail
        if re.search(r"\b(cat|show|display|view|read)\b.*\b(file|content)\b", low):
            ctx.file = ctx.path or TextExtractor.extract_filename(original)
            return "cat_file", ctx

        if "head" in low or "tail" in low:
            ctx.file = ctx.path or TextExtractor.extract_filename(original)
            ctx.lines = TextExtractor.extract_number(original) or 10
            if "tail" in low:
                return "tail_file", ctx
            else:
                return "head_file", ctx

        # Permissions/Ownership
        if "chmod" in low or "change permission" in low:
            ctx.file = ctx.path or TextExtractor.extract_filename(original)
            ctx.permissions = TextExtractor.extract_permissions(original)
            return "chmod", ctx

        if "chown" in low or "change owner" in low:
            ctx.file = ctx.path or TextExtractor.extract_filename(original)
            ctx.owner = TextExtractor.extract_word_after(original, ["chown", "owner"])
            return "chown", ctx

        # Compression
        if any(w in low for w in ["compress", "archive", "zip", "tar", "gzip"]):
            ctx.files = TextExtractor.extract_file_list(original)
            ctx.archive_name = TextExtractor.extract_archive_name(original) or "archive.tar.gz"
            return "compress", ctx

        if any(w in low for w in ["extract", "unzip", "untar", "decompress"]):
            ctx.archive = ctx.path or TextExtractor.extract_archive_name(original)
            return "decompress", ctx

        # Package management
        if any(w in low for w in ["update packages", "upgrade packages", "refresh packages", "system update"]):
            return "update_packages", ctx

        if any(w in low for w in ["install", "add package", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco", "scoop"]):
            pkg = TextExtractor.extract_word_after(original, ["install", "add", "brew", "apt", "dnf", "yum", "pacman", "winget", "choco", "scoop"])
            ctx.package = pkg
            ctx.clarification_required = True
            ctx.clarification_message = IntentInference._package_manager_message(pkg)
            return "install_pkg", ctx

        # Git
        if "git" in low:
            if "clone" in low:
                url = TextExtractor.extract_url(original)
                ctx.url = url
                if not url:
                    ctx.clarification_required = True
                    ctx.clarification_message = "Please provide the repository URL to clone."
                return "git_clone", ctx
            if "status" in low:
                return "git_status", ctx
            if "pull" in low:
                return "git_pull", ctx
            if "push" in low:
                ctx.dry_run = True
                return "git_push", ctx
            if "commit" in low:
                message = TextExtractor.extract_quoted_text(original) or ""
                ctx.message = message
                if not message:
                    ctx.clarification_required = True
                    ctx.clarification_message = "Please provide a commit message in quotes."
                return "git_commit", ctx
            if "branch" in low:
                if "list" in low:
                    return "git_branch_list", ctx
                branch_name = TextExtractor.extract_word_after(original, ["branch"])
                ctx.branch = branch_name
                return "git_branch_create", ctx
            if "log" in low:
                return "git_log", ctx
            if "diff" in low:
                return "git_diff", ctx

        # Docker
        if "docker" in low or "container" in low:
            if "ps" in low or "list" in low:
                return "docker_ps", ctx
            if "images" in low:
                return "docker_images", ctx
            if "run" in low:
                image = TextExtractor.extract_word_after(original, ["run"])
                ctx.image = image
                return "docker_run", ctx
            if "build" in low:
                return "docker_build", ctx
            if "logs" in low:
                container = TextExtractor.extract_word_after(original, ["logs"])
                ctx.container = container
                return "docker_logs", ctx

        # Generic compositional intents (count/sort/time/size)
        if any(w in low for w in ["count matches", "how many lines", "count lines matching", "number of occurrences", "count them", "count files", "count items"]):
            text = TextExtractor.extract_quoted_text(original) or ctx.pattern or ""
            base = ctx.path or "."
            ctx.query = text
            ctx.path = base
            return "count_matches", ctx

        if any(w in low for w in ["largest files", "biggest files", "sort by size"]):
            base = ctx.path or "."
            ctx.path = base
            return "sort_by_size", ctx

        if any(w in low for w in ["newest files", "oldest files", "sort by time"]):
            base = ctx.path or "."
            order = "newest" if "newest" in low else "oldest" if "oldest" in low else "newest"
            ctx.path = base
            ctx.order = order
            return "sort_by_time", ctx

        # Fallback: pick closest matching intent by token overlap, then rely on synthesis to propose a command
        best_intent = self.intent_registry.get_closest_intent_by_overlap(low)
        ctx._fallback = True
        return best_intent, ctx

    @staticmethod
    def _package_manager_message(pkg: str) -> str:
        """Generate package manager specific messages."""
        # This would need to be implemented based on OS detection
        return f"Please specify package manager for installing {pkg}."
