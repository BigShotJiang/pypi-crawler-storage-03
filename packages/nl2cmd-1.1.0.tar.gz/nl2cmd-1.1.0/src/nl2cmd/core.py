#!/usr/bin/env python3
"""
Natural Language to Command (NL2Cmd) core module.

This module provides the main NL2Cmd class that orchestrates the translation
of natural language into terminal commands using a modular architecture.
"""

from typing import Optional
from .models import NL2CmdResult, CommandContext
from .intents import IntentRegistry
from .extractors import TextExtractor
from .chaining import CommandChaining
from .intent_inference import IntentInference
from .command_generator import CommandGenerator
from .synthesis import CommandSynthesis
from .validation import CommandValidator
from .os_detection import OSDetector


class NL2Cmd:
    """Main class for translating natural language to terminal commands."""
    
    def __init__(self, forced_os: Optional[str] = None):
        """
        Initialize NL2Cmd translator.
        
        Args:
            forced_os: Optional override ("linux", "macos", "windows") for testing.
                      Otherwise, OS is detected from the runtime environment.
        """
        self.os = forced_os or OSDetector.detect_os()
        
        # Initialize all components
        self.intent_registry = IntentRegistry()
        self.intent_inference = IntentInference(self.intent_registry)
        self.command_generator = CommandGenerator(self.os)
        self.command_synthesis = CommandSynthesis(self.os)
        self.validator = CommandValidator(self.os)
        self.chaining = CommandChaining(self)

    def translate(self, text: str) -> NL2CmdResult:
        """
        Main translation method that takes natural language and returns a command result.
        
        Args:
            text: Natural language input to translate
            
        Returns:
            NL2CmdResult with the translated command and metadata
        """
        try:
            original = text
            normalized = " ".join(text.strip().split())
            low = normalized.lower()

            if not normalized:
                return self._create_result(original, "", [], True,
                                        "Please provide an instruction to translate into a command.",
                                        "", {})

            # 1) Handle chaining expressions early
            chained = self.chaining.handle_chaining(normalized)
            if chained:
                return chained

            # 2) Infer intent and context
            intent, ctx = self.intent_inference.infer_intent(low, normalized)

            # 3) Generate command (with explanations)
            cmd, alts, risky, clarify_msg, explanation, breakdown = self.command_generator.generate_commands(intent, ctx)

            # 4) Risk/ambiguity handling and validation
            clarification_required = ctx.clarification_required or risky or (cmd == "")
            error_msg = clarify_msg or ctx.clarification_message

            valid, validation_msg = self.validator.validate(intent, ctx, cmd)
            if not valid:
                clarification_required = True
                error_msg = (error_msg + " " + validation_msg).strip()

            # 5) If still empty, synthesize a best-effort command rather than saying not implemented
            if not cmd:
                cmd, alts, explanation, breakdown, synth_msg = self.command_synthesis.synthesize_best_effort(normalized, ctx)
                if cmd:
                    clarification_required = True  # propose, but ask to confirm
                    error_msg = (error_msg + (" " if error_msg else "") + synth_msg).strip()

            return self._create_result(original, cmd, alts, clarification_required, error_msg, explanation, breakdown)
            
        except Exception as e:
            return self._create_result(original, "", [], True, str(e),
                                    "An error occurred while processing your request", {})

    def _create_result(self, original: str, command: str, alternatives: list,
                      clarification_required: bool, error: str, explanation: str,
                      breakdown: dict) -> NL2CmdResult:
        """Create a result object with proper formatting."""
        alts, seen = [], set()
        for alt in alternatives:
            alt = alt.strip()
            if alt and alt != command and alt not in seen:
                seen.add(alt)
                alts.append(alt)
        
        return NL2CmdResult(
            input=original,
            os=self.os,
            command=command.strip(),
            alternatives=alts,
            clarification_required=bool(clarification_required),
            error=error.strip(),
            explanation=explanation.strip(),
            command_breakdown=breakdown or {}
        )
