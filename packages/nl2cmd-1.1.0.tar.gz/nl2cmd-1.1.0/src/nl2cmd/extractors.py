#!/usr/bin/env python3
"""
Text extraction and parsing utilities for NL2Cmd.
"""

import re
import json
from typing import List, Optional, Tuple


class TextExtractor:
    """Extract various types of information from natural language text."""
    
    @staticmethod
    def extract_path(text: str) -> Optional[str]:
        """Extract file/directory paths from text."""
        quoted = TextExtractor.extract_quoted_path(text)
        if quoted:
            return quoted
        
        patterns = [
            r'(\.?/[^\s,;]+)',       # Unix-like paths (highest priority)
            r'([A-Za-z]:[^\s,;]*)',  # Windows-like paths
            r'\b(?:in|to|at|into|under|from)\s+([^\s,;]+)',
            r'\b(?:directory|folder|path|location)\s+([^\s,;]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return (match.group(1) if match.lastindex else match.group(0)).rstrip('.,!?')
        return None

    @staticmethod
    def extract_quoted_path(text: str) -> Optional[str]:
        """Extract quoted paths from text."""
        for match in re.finditer(r'(["\'])(.+?)\1', text):
            content = match.group(2)
            if re.search(r'[\\/.~]|^[A-Za-z]:', content):
                return content
        return None

    @staticmethod
    def extract_pattern(text: str) -> Optional[str]:
        """Extract filename patterns from text."""
        match = re.search(r'\b(?:named|pattern|called)\s+([^\s,]+)', text, re.IGNORECASE)
        if match:
            return match.group(1)
        
        star = re.search(r'(\*[\w\.\-\?]*|\?[\w\.\-\*]*|[\w\-]*\*[\w\.\-]*)', text)
        return star.group(1) if star else None

    @staticmethod
    def extract_quoted_text(text: str) -> Optional[str]:
        """Extract quoted text from input."""
        match = re.search(r'["\'](.+?)["\']', text)
        return match.group(1) if match else None

    @staticmethod
    def extract_filename(text: str) -> Optional[str]:
        """Extract filename from text."""
        quoted = TextExtractor.extract_quoted_text(text)
        if quoted and not re.search(r'[\\/]', quoted):
            return quoted
        
        match = re.search(r'([A-Za-z0-9_\-\.]+\.[A-Za-z0-9]{1,5})', text)
        return match.group(1) if match else None

    @staticmethod
    def extract_src_dst(text: str) -> Tuple[Optional[str], Optional[str]]:
        """Extract source and destination from copy/move commands."""
        match = re.search(r'\b(?:copy|cp|move|mv|rename)\s+(.+?)\s+\bto\b\s+(.+)$', text, re.IGNORECASE)
        if match:
            src = match.group(1).strip().strip(",.")
            dst = match.group(2).strip().strip(",.")
            quotes = re.findall(r'(["\'])(.+?)\1', text)
            if len(quotes) >= 1:
                src = quotes[0][1]
            if len(quotes) >= 2:
                dst = quotes[1][1]
            return src, dst
        
        quotes = re.findall(r'(["\'])(.+?)\1', text)
        if len(quotes) >= 2:
            return quotes[0][1], quotes[1][1]
        return None, None

    @staticmethod
    def extract_number(text: str) -> Optional[int]:
        """Extract numbers from text."""
        match = re.search(r'\bpid\s*(\d+)', text, re.IGNORECASE)
        if match:
            return int(match.group(1))
        
        match2 = re.search(r'\b(\d{1,4})\b', text)
        return int(match2.group(1)) if match2 else None

    @staticmethod
    def extract_process_name(text: str) -> Optional[str]:
        """Extract process names from text."""
        match = re.search(r'\b(?:process|proc|name)\b\s*["\']?([A-Za-z0-9_\-\.]+)["\']?', text, re.IGNORECASE)
        return match.group(1) if match else None

    @staticmethod
    def extract_permissions(text: str) -> Optional[str]:
        """Extract permission specifications from text."""
        match = re.search(r'\b([0-7]{3,4})\b', text)
        if match:
            return match.group(1)
        
        match2 = re.search(r'\b([ugo]*[+-=][rwx]+)\b', text)
        return match2.group(1) if match2 else None

    @staticmethod
    def extract_file_list(text: str) -> List[str]:
        """Extract list of files from text."""
        files = []
        for match in re.finditer(r'["\']([^"\']+)["\']', text):
            files.append(match.group(1))
        return files

    @staticmethod
    def extract_archive_name(text: str) -> Optional[str]:
        """Extract archive filenames from text."""
        match = re.search(r'([A-Za-z0-9_\-\.]+\.(?:zip|tar|gz|bz2|xz|7z))', text)
        return match.group(1) if match else None

    @staticmethod
    def extract_url(text: str) -> Optional[str]:
        """Extract URLs from text."""
        match = re.search(r'(https?://[^\s"\'<>]+)', text)
        return match.group(1) if match else None

    @staticmethod
    def extract_word_after(text: str, triggers: List[str]) -> Optional[str]:
        """Extract word that follows any of the trigger words."""
        for trigger in triggers:
            match = re.search(r'\b' + re.escape(trigger) + r'\b\s+([A-Za-z0-9_\-\./:]+)', text, re.IGNORECASE)
            if match:
                return match.group(1)
        return None
