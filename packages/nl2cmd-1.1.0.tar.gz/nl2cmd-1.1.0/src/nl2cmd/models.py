#!/usr/bin/env python3
"""
Data models for NL2Cmd responses and internal structures.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional


@dataclass
class NL2CmdResult:
    """Result of natural language to command translation."""
    input: str
    os: str
    command: str
    alternatives: List[str]
    clarification_required: bool
    error: str
    # Additional, non-breaking fields to give users more usage info:
    explanation: str = ""  # What the command does in plain English
    command_breakdown: Dict[str, str] = None  # Key parts of the command explained


@dataclass
class CommandContext:
    """Context information for command generation."""
    path: Optional[str] = None
    pattern: Optional[str] = None
    query: Optional[str] = None
    src: Optional[str] = None
    dst: Optional[str] = None
    recursive: bool = False
    hidden: bool = False
    long: bool = False
    case_insensitive: bool = False
    exact: bool = False
    force: bool = False
    parents: bool = False
    clarification_required: bool = False
    clarification_message: str = ""
    _fallback: bool = False
