"""
Natural language to terminal command translation tool.

This package provides the NL2Cmd class for translating natural language
descriptions into appropriate terminal commands based on the detected OS.
"""

from .core import NL2Cmd
from .models import NL2CmdResult, CommandContext
from .intents import IntentRegistry
from .extractors import TextExtractor
from .chaining import CommandChaining
from .intent_inference import IntentInference
from .command_generator import CommandGenerator
from .synthesis import CommandSynthesis
from .validation import CommandValidator
from .os_detection import OSDetector

__version__ = "1.1.0"
__all__ = [
    "NL2Cmd",
    "NL2CmdResult", 
    "CommandContext",
    "IntentRegistry",
    "TextExtractor",
    "CommandChaining",
    "IntentInference",
    "CommandGenerator",
    "CommandSynthesis",
    "CommandValidator",
    "OSDetector"
]
