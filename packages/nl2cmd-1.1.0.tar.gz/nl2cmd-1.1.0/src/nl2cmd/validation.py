#!/usr/bin/env python3
"""
Command validation and safety checks for NL2Cmd.
"""

from typing import Tuple
from .models import CommandContext


class CommandValidator:
    """Validate generated commands for safety and correctness."""
    
    def __init__(self, os_name: str):
        """Initialize with target operating system."""
        self.os = os_name

    def validate(self, intent: str, ctx: CommandContext, cmd: str) -> Tuple[bool, str]:
        """Validate a command for safety and correctness."""
        if not cmd:
            return False, ""
        
        c = cmd.lower()

        # LS validation
        if intent == "ls" and ctx.hidden:
            if self.os in ("linux", "macos") and not any(flag in c for flag in ["-a", "-la", "-al"]):
                return False, "Hidden files requested; add -a."
            if self.os == "windows" and "/a" not in c:
                return False, "Hidden files requested; add /a."

        # Recursive validation
        if ctx.recursive and intent in ("ls", "rm", "cp", "grep_text"):
            if self.os in ("linux", "macos"):
                need = {"ls": ["-r", "-R"], "rm": ["-r", "-R"], "cp": ["-r", "-R"], "grep_text": ["-r", "-R"]}.get(intent, [])
                if need and not any(f in c for f in need):
                    return False, f"Recursive requested; consider {' or '.join(need)}."
            else:
                if intent == "ls" and "/s" not in c:
                    return False, "Recursive requested; add /s."

        # Long format validation
        if intent == "ls" and ctx.long and self.os in ("linux", "macos") and "-l" not in c:
            return False, "Detailed listing requested; add -l."

        # Force validation for risky operations
        if intent == "rm" and not ctx.force:
            if self.os in ("linux", "macos") and "-f" not in c:
                return False, "Consider adding -f flag to force deletion without prompts."
            if self.os == "windows" and "/q" not in c:
                return False, "Consider adding /q flag to force deletion without prompts."

        # Path validation
        if intent in ("cd", "mkdir", "rm", "cp", "mv") and not ctx.path:
            return False, f"{intent.upper()} requires a path specification."

        # Source/destination validation
        if intent in ("cp", "mv") and (not ctx.src or not ctx.dst):
            return False, f"{intent.upper()} requires both source and destination."

        return True, ""

    def is_risky_command(self, intent: str, ctx: CommandContext) -> bool:
        """Determine if a command is potentially risky."""
        risky_intents = {
            "rm": "Deletion operations",
            "kill_proc": "Process termination",
            "git_push": "Remote repository updates",
            "docker_run": "Container execution",
            "chmod": "Permission changes",
            "chown": "Ownership changes"
        }
        
        return intent in risky_intents

    def get_risk_warning(self, intent: str, ctx: CommandContext) -> str:
        """Get appropriate warning message for risky commands."""
        warnings = {
            "rm": "Deletion permanently removes data. Confirm the exact path and options.",
            "kill_proc": "Terminating a process may cause data loss. Confirm PID/name.",
            "git_push": "Pushing updates a remote repository. Review branch/remote before proceeding.",
            "docker_run": "Running containers can access system resources. Review image and options.",
            "chmod": "Changing permissions can affect file access. Confirm the new permissions.",
            "chown": "Changing ownership can affect file access. Confirm the new owner."
        }
        
        return warnings.get(intent, "This operation may have system-wide effects. Please review carefully.")
