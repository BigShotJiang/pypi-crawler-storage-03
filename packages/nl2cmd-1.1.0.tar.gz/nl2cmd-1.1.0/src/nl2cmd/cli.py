#!/usr/bin/env python3
"""
Command-line interface for nl2cmd package.
"""

import argparse
import json
import sys
from .core import NL2Cmd


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Natural language to terminal command translation tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  nl2cmd "show current directory"
  nl2cmd "list files in this folder"
  nl2cmd "create a new directory called test"
        """
    )
    
    parser.add_argument(
        "input",
        help="Natural language description of the command you want to execute"
    )
    
    parser.add_argument(
        "--os",
        choices=["linux", "macOS", "windows"],
        help="Override OS detection (useful for testing)"
    )
    
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output result in JSON format"
    )
    
    parser.add_argument(
        "--explain",
        action="store_true",
        help="Show detailed explanation of the command"
    )
    
    args = parser.parse_args()
    
    try:
        # Initialize the translator
        translator = NL2Cmd(forced_os=args.os)
        
        # Translate the input
        result = translator.translate(args.input)
        
        if args.json:
            # Output as JSON
            print(json.dumps(result.__dict__, indent=2))
        else:
            # Human-readable output
            if result.error:
                print(f"Error: {result.error}")
                if result.explanation:
                    print(f"Explanation: {result.explanation}")
                sys.exit(1)
            
            if result.clarification_required:
                print("Clarification required:")
                print(f"  {result.explanation}")
                sys.exit(1)
            
            print(f"Command: {result.command}")
            
            if args.explain and result.explanation:
                print(f"Explanation: {result.explanation}")
            
            if result.alternatives:
                print(f"Alternatives: {', '.join(result.alternatives)}")
            
            if result.command_breakdown:
                print("Command breakdown:")
                for key, value in result.command_breakdown.items():
                    print(f"  {key}: {value}")
    
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
