#!/usr/bin/env python3
"""
Operating system detection and normalization for NL2Cmd.
"""

import platform


class OSDetector:
    """Detect and normalize operating system information."""
    
    @staticmethod
    def detect_os() -> str:
        """Detect the current operating system."""
        sys = platform.system().lower()
        if "linux" in sys:
            return "linux"
        elif "darwin" in sys:
            return "macos"
        elif "windows" in sys:
            return "windows"
        else:
            return "linux"  # Default fallback
    
    @staticmethod
    def normalize_os_name(os_name: str) -> str:
        """Normalize OS names to standard format."""
        os_name = os_name.lower().strip()
        if os_name in ["darwin", "mac", "macos", "osx"]:
            return "macos"
        elif os_name in ["linux", "unix", "gnu/linux"]:
            return "linux"
        elif os_name in ["windows", "win", "nt"]:
            return "windows"
        else:
            return "linux"  # Default fallback
    
    @staticmethod
    def get_os_info() -> dict:
        """Get detailed OS information."""
        return {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python_version": platform.python_version()
        }
