#!/usr/bin/env python3
"""
Command chaining and pipeline detection for NL2Cmd.
"""

import re
from typing import Optional
from .models import NL2CmdResult


class CommandChaining:
    """Handle command chaining expressions and pipeline operations."""
    
    def __init__(self, translator):
        """Initialize with reference to the main translator."""
        self.translator = translator

    def handle_chaining(self, text: str) -> Optional[NL2CmdResult]:
        """
        Recognize chaining phrases and compose with operators:
        - "X then Y" or "X and then Y" -> &&
        - "X or (if that fails) Y" -> ||
        - "X and Y" -> ;
        - "pipe X into Y" or "X and pipe into Y" -> |
        """
        low = text.lower()

        # Piping in natural language
        pipe_match = re.search(r'(.+?)\s+(?:pipe|piped||)\s*(?:into|to)\s+(.+)', low)
        if pipe_match:
            left = text[:pipe_match.start(2)].strip()
            right = text[pipe_match.start(2):].strip()
            a = self.translator.translate(left)
            b = self.translator.translate(right)
            if a.command and b.command:
                # Use RHS as command without its input source; prefer grep/awk/cut where possible
                rhs = b.command
                # If RHS begins with a verb like grep/awk/sed/sort/uniq/wc, keep as-is; else give a generic filter
                pipe_cmd = f"{a.command} | {rhs}"
                explanation = f"Run the first command and feed its output into the second command via a pipeline"
                breakdown = {"operator": "|", "operator_meaning": "Pipe output of left command to input of right command"}
                return self._create_result(text, pipe_cmd, [], False, "", explanation, breakdown)

        # Then => &&
        then_match = re.search(r'(.+?)\s+(?:and\s+)?then\s+(.+)', low)
        if then_match:
            left = text[:then_match.start(2)].strip()
            right = text[then_match.start(2):].strip()
            a = self.translator.translate(left)
            b = self.translator.translate(right)
            if a.command and b.command:
                # Special handling for counting operations
                if "count" in right.lower():
                    # If counting, pipe the output of the first command to wc
                    if self.translator.os in ("linux", "macos"):
                        cmd = f"{a.command} | wc -l"
                        explanation = "List files and count them"
                    else:
                        cmd = f"{a.command} && (Get-ChildItem | Measure-Object).Count"
                        explanation = "List files and count them"
                else:
                    cmd = f"{a.command} && {b.command}"
                    explanation = "Execute the first command, and only if it succeeds, execute the second command"
                breakdown = {"operator": "&&", "operator_meaning": "Right runs only if left succeeds"}
                return self._create_result(text, cmd, [f"{a.command}; {b.command}"], False, "", explanation, breakdown)

        # "or" / "if that fails" => ||
        or_match = re.search(r'(.+?)\s+or\s+(?:if\s+(?:that\s+)?fails?\s+)?(.+)', low)
        if or_match:
            left = text[:or_match.start(2)].strip()
            right = text[or_match.start(2):].strip()
            a = self.translator.translate(left)
            b = self.translator.translate(right)
            if a.command and b.command:
                cmd = f"{a.command} || {b.command}"
                explanation = "Execute the first command, or if it fails, execute the second command as a fallback"
                breakdown = {"operator": "||", "operator_meaning": "Right runs only if left fails"}
                return self._create_result(text, cmd, [], False, "", explanation, breakdown)

        # "and" (sequential regardless) => ;
        and_match = re.search(r'(.+?)\s+and\s+(.+)', low)
        if and_match and "then" not in low and "pipe" not in low:
            left = text[:and_match.start(2)].strip()
            right = text[and_match.start(2):].strip()
            # Avoid false positives like "files and directories"
            if not any(phrase in low for phrase in ["files and directories", "read and write", "input and output"]):
                a = self.translator.translate(left)
                b = self.translator.translate(right)
                if a.command and b.command:
                    cmd = f"{a.command}; {b.command}"
                    explanation = "Execute two commands sequentially, regardless of success or failure of the first"
                    breakdown = {"operator": ";", "operator_meaning": "Always run right after left"}
                    return self._create_result(text, cmd, [f"{a.command} && {b.command}"], False, "", explanation, breakdown)

        return None

    def _create_result(self, original: str, command: str, alternatives: list, 
                      clarification_required: bool, error: str, explanation: str, 
                      breakdown: dict) -> NL2CmdResult:
        """Create a result object for chaining operations."""
        alts, seen = [], set()
        for alt in alternatives:
            alt = alt.strip()
            if alt and alt != command and alt not in seen:
                seen.add(alt)
                alts.append(alt)
        
        return NL2CmdResult(
            input=original,
            os=self.translator.os,
            command=command.strip(),
            alternatives=alts,
            clarification_required=bool(clarification_required),
            error=error.strip(),
            explanation=explanation.strip(),
            command_breakdown=breakdown or {}
        )
