"""Unit tests for lib package."""
