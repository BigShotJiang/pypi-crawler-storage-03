"""Unit tests for aws package."""
