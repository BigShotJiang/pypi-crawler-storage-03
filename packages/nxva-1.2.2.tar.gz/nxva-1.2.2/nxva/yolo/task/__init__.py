from .detect import DetectionPredictor
from .pose import PosePredictor
from .classify import ClassificationPredictor
from .segment import SegmentationPredictor