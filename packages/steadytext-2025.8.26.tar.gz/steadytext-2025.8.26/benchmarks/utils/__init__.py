"""Utility functions for benchmarking."""
