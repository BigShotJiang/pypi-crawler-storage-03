﻿"""
JJ MCP - Multi-database MCP Server
==================================

A comprehensive MCP server supporting multiple databases and filesystem operations.

Features:
- SQL Server database operations
- Oracle database operations  
- Redis operations
- Filesystem operations
- Security features and access control
- Environment variable configuration
- Cross-platform support

Author: PJ
Email: peng.it@qq.com
License: MIT
"""

__version__ = "0.3.1"
__author__ = "PJ"
__email__ = "peng.it@qq.com"
__license__ = "MIT"

# Export main components
try:
    from .server import main
    __all__ = ["main", "__version__", "__author__", "__email__", "__license__"]
except ImportError as e:
    # Handle missing dependencies gracefully
    import logging
    logging.warning(f"Some dependencies missing: {e}")
    __all__ = ["__version__", "__author__", "__email__", "__license__"]
