﻿"""SQL Server database manager."""

import logging
from typing import Any, Dict, List, Optional
from contextlib import contextmanager

try:
    import pyodbc
    from sqlalchemy import create_engine, text, MetaData
    from sqlalchemy.engine import Engine
    from sqlalchemy.pool import QueuePool
    SQLSERVER_AVAILABLE = True
except ImportError:
    SQLSERVER_AVAILABLE = False
    pyodbc = None
    create_engine = None
    text = None
    MetaData = None
    Engine = None
    QueuePool = None

from .database_manager import SQLDatabaseManager, DatabaseConnectionError
from .config import get_config

logger = logging.getLogger(__name__)


class SQLServerManager(SQLDatabaseManager):
    """Manages SQL Server connections and operations."""

    def __init__(self):
        super().__init__(None)  # Pass None as config, will get from get_config()

    def _initialize(self) -> None:
        """Initialize SQLAlchemy engine with connection pooling."""
        try:
            config = get_config()
            if not config.sqlserver.enabled:
                logger.info("SQL Server is disabled in configuration")
                return

            if not SQLSERVER_AVAILABLE:
                logger.error("SQL Server libraries not available. Install with: pip install pyodbc sqlalchemy")
                self._connection_error = "SQL Server libraries not installed"
                return
            
            # Build connection string
            connection_string = self._build_connection_string()
            sqlalchemy_url = f"mssql+pyodbc:///?odbc_connect={connection_string}"
            
            self._engine = create_engine(
                sqlalchemy_url,
                poolclass=QueuePool,
                pool_size=config.sqlserver.pool_size,
                max_overflow=config.sqlserver.max_overflow,
                pool_pre_ping=True,
                pool_recycle=3600,
                echo=config.log_level == "DEBUG",
            )
            
            self._metadata = MetaData()
            
            # Test the connection
            if self.test_connection():
                self._is_available = True
                self._connection_error = None
                logger.info("SQL Server engine initialized and connection test successful")
            else:
                self._is_available = False
                self._connection_error = "Connection test failed"
                logger.warning("SQL Server engine initialized but connection test failed")
                
        except Exception as e:
            self._is_available = False
            self._connection_error = str(e)
            logger.warning(f"Failed to initialize SQL Server engine: {e}")
    
    def _build_connection_string(self) -> str:
        """Build SQL Server connection string."""
        config = get_config().sqlserver
        
        if config.connection_string:
            return config.connection_string
        
        # Build connection string from components
        parts = [
            f"DRIVER={{{config.driver}}}",
            f"SERVER={config.host},{config.port}",
        ]
        
        if config.database:
            parts.append(f"DATABASE={config.database}")
        
        # Authentication
        if config.username and config.password:
            parts.extend([
                f"UID={config.username}",
                f"PWD={config.password}",
            ])
        else:
            parts.append("Trusted_Connection=yes")
        
        # Additional options
        parts.extend([
            f"TrustServerCertificate={'yes' if config.trust_server_certificate else 'no'}",
            f"Encrypt={'yes' if config.encrypt else 'no'}",
            f"MultipleActiveResultSets={'yes' if config.multiple_active_result_sets else 'no'}",
            f"Application Name={config.application_name}",
            f"Connection Timeout={config.connection_timeout}",
            f"Command Timeout={config.command_timeout}",
        ])

        # Azure/Authentication options
        if config.authentication:
            parts.append(f"Authentication={config.authentication}")

        # Performance options
        if config.packet_size:
            parts.append(f"Packet Size={config.packet_size}")

        if config.application_intent:
            parts.append(f"ApplicationIntent={config.application_intent}")

        # MARS connection
        if not config.mars_connection:
            parts.append("MARS_Connection=no")
        
        return ";".join(parts) + ";"
    
    def test_connection(self) -> bool:
        """Test SQL Server connection."""
        if not self._engine:
            return False
        
        try:
            with self.get_connection() as conn:
                conn.execute(text("SELECT 1"))
                return True
        except Exception as e:
            logger.error(f"SQL Server connection test failed: {e}")
            return False
    
    def reconnect(self) -> bool:
        """Attempt to reconnect to SQL Server."""
        logger.info("Attempting to reconnect to SQL Server...")
        self._initialize()
        return self._is_available
    
    @contextmanager
    def get_connection(self):
        """Get a SQL Server connection with automatic cleanup and retry."""
        if not self._is_available:
            raise DatabaseConnectionError(f"SQL Server is not available: {self._connection_error}")

        if not self._engine:
            raise DatabaseConnectionError("SQL Server engine not initialized")

        connection = None
        transaction = None
        max_retries = 3

        for attempt in range(max_retries):
            try:
                connection = self._engine.connect()
                # 开始事务以确保数据一致性
                transaction = connection.begin()
                yield connection
                # 如果没有异常，提交事务
                transaction.commit()
                return

            except Exception as e:
                logger.error(f"SQL Server connection error (attempt {attempt + 1}/{max_retries}): {e}")

                # 回滚事务
                if transaction:
                    try:
                        transaction.rollback()
                    except:
                        pass

                # 关闭连接
                if connection:
                    try:
                        connection.close()
                    except:
                        pass
                    connection = None

                # 如果是最后一次尝试，标记为不可用
                if attempt == max_retries - 1:
                    self._is_available = False
                    self._connection_error = str(e)
                    raise

                # 短暂等待后重试
                import time
                time.sleep(0.5 * (attempt + 1))

            finally:
                # 确保资源清理
                if connection:
                    try:
                        connection.close()
                    except:
                        pass
    
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a SELECT query and return results with enhanced error handling."""
        if not self.ensure_available_for_operation():
            raise DatabaseConnectionError(f"SQL Server is not available: {self._connection_error}")

        self._validate_sql_query(query)

        # 查询超时保护
        query_timeout = getattr(self.config, 'command_timeout', 30)

        try:
            with self.get_connection() as conn:
                # 设置查询超时
                result = conn.execute(
                    text(query).execution_options(autocommit=True),
                    parameters or {},
                    execution_options={"timeout": query_timeout}
                )

                # 安全地转换结果
                columns = list(result.keys()) if result.keys() else []
                rows = []
                row_count = 0

                try:
                    for row in result:
                        row_dict = {}
                        for i, col_name in enumerate(columns):
                            # 安全地处理各种数据类型
                            value = row[i]
                            if value is None:
                                row_dict[col_name] = None
                            elif isinstance(value, (bytes, bytearray)):
                                # 处理二进制数据
                                row_dict[col_name] = f"<binary data: {len(value)} bytes>"
                            else:
                                row_dict[col_name] = value
                        rows.append(row_dict)
                        row_count += 1

                        # 防止内存溢出：限制返回行数
                        if row_count > 10000:
                            logger.warning("Query returned more than 10,000 rows, truncating results")
                            rows.append({"_warning": "Results truncated at 10,000 rows"})
                            break

                except Exception as fetch_error:
                    logger.error(f"Error fetching query results: {fetch_error}")
                    raise DatabaseConnectionError(f"Failed to fetch query results: {fetch_error}")

                logger.info(f"SQL Server query executed successfully, returned {row_count} rows")
                return {
                    'columns': columns,
                    'rows': rows,
                    'row_count': row_count,
                    'truncated': row_count > 10000
                }

        except DatabaseConnectionError:
            raise
        except Exception as e:
            logger.error(f"SQL Server query execution failed: {e}")
            # 检查是否是连接相关错误
            if any(keyword in str(e).lower() for keyword in ['connection', 'timeout', 'network', 'server']):
                self._is_available = False
                self._connection_error = str(e)
            raise DatabaseConnectionError(f"Query execution failed: {e}")
    
    def execute_non_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> int:
        """Execute an INSERT, UPDATE, or DELETE query with enhanced safety."""
        if not self.ensure_available_for_operation():
            raise DatabaseConnectionError(f"SQL Server is not available: {self._connection_error}")

        self._validate_sql_query(query)

        # 额外的安全检查：防止意外的大批量操作
        query_upper = query.upper().strip()
        if any(dangerous in query_upper for dangerous in ['DROP ', 'TRUNCATE ', 'DELETE FROM']) and 'WHERE' not in query_upper:
            logger.warning(f"Potentially dangerous query without WHERE clause: {query[:100]}...")
            # 可以选择阻止或要求确认

        # 操作超时保护
        command_timeout = getattr(self.config, 'command_timeout', 30)

        try:
            with self.get_connection() as conn:
                # 使用事务确保数据一致性（在get_connection中已处理）
                result = conn.execute(
                    text(query),
                    parameters or {},
                    execution_options={"timeout": command_timeout}
                )

                affected_rows = result.rowcount if result.rowcount is not None else 0

                # 记录重要操作
                if affected_rows > 1000:
                    logger.warning(f"Large operation: {affected_rows} rows affected by query: {query[:100]}...")
                else:
                    logger.info(f"SQL Server non-query executed successfully, affected {affected_rows} rows")

                return affected_rows

        except DatabaseConnectionError:
            raise
        except Exception as e:
            logger.error(f"SQL Server non-query execution failed: {e}")
            # 检查是否是连接相关错误
            if any(keyword in str(e).lower() for keyword in ['connection', 'timeout', 'network', 'server']):
                self._is_available = False
                self._connection_error = str(e)
            raise DatabaseConnectionError(f"Non-query execution failed: {e}")

    def get_table_schema(self, table_name: str, schema_name: str = "dbo") -> Dict[str, Any]:
        """Get table schema information."""
        if not self._is_available:
            raise DatabaseConnectionError(f"SQL Server is not available: {self._connection_error}")

        query = """
        SELECT
            c.COLUMN_NAME,
            c.DATA_TYPE,
            c.IS_NULLABLE,
            c.COLUMN_DEFAULT,
            c.CHARACTER_MAXIMUM_LENGTH,
            c.NUMERIC_PRECISION,
            c.NUMERIC_SCALE,
            CASE WHEN pk.COLUMN_NAME IS NOT NULL THEN 1 ELSE 0 END AS IS_PRIMARY_KEY
        FROM INFORMATION_SCHEMA.COLUMNS c
        LEFT JOIN (
            SELECT ku.TABLE_SCHEMA, ku.TABLE_NAME, ku.COLUMN_NAME
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS AS tc
            INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS ku
                ON tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
                AND tc.CONSTRAINT_NAME = ku.CONSTRAINT_NAME
        ) pk ON c.TABLE_SCHEMA = pk.TABLE_SCHEMA
            AND c.TABLE_NAME = pk.TABLE_NAME
            AND c.COLUMN_NAME = pk.COLUMN_NAME
        WHERE c.TABLE_SCHEMA = :schema_name AND c.TABLE_NAME = :table_name
        ORDER BY c.ORDINAL_POSITION
        """

        try:
            result = self.execute_query(query, {
                'schema_name': schema_name,
                'table_name': table_name
            })

            return {
                'table_name': table_name,
                'schema_name': schema_name,
                'columns': result['rows']
            }

        except Exception as e:
            logger.error(f"Failed to get SQL Server table schema: {e}")
            raise

    def list_tables(self, schema_name: str = "dbo") -> List[Dict[str, Any]]:
        """List all tables in the database."""
        if not self._is_available:
            raise DatabaseConnectionError(f"SQL Server is not available: {self._connection_error}")

        query = """
        SELECT
            TABLE_SCHEMA,
            TABLE_NAME,
            TABLE_TYPE
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = :schema_name
        ORDER BY TABLE_NAME
        """

        try:
            result = self.execute_query(query, {'schema_name': schema_name})
            return result['rows']

        except Exception as e:
            logger.error(f"Failed to list SQL Server tables: {e}")
            raise
