﻿"""System monitoring and health check for JJ MCP."""

import asyncio
import logging
import threading
import time
import psutil
import gc
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


@dataclass
class SystemMetrics:
    """System performance metrics."""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_used_mb: float
    memory_available_mb: float
    disk_usage_percent: float
    active_connections: int
    failed_connections: int
    query_count: int
    error_count: int
    uptime_seconds: float


@dataclass
class DatabaseHealth:
    """Database health status."""
    name: str
    is_available: bool
    last_check: datetime
    response_time_ms: float
    error_message: Optional[str]
    connection_pool_size: int
    active_connections: int


class SystemMonitor:
    """System performance and health monitor."""
    
    def __init__(self, check_interval: int = 60):
        self.check_interval = check_interval
        self.start_time = time.time()
        self.running = False
        self._thread = None
        self._lock = threading.Lock()
        
        # Metrics storage
        self.metrics_history: List[SystemMetrics] = []
        self.max_history_size = 1440  # 24 hours of minute-by-minute data
        
        # Database managers
        self.database_managers = {}
        
        # Counters
        self.query_count = 0
        self.error_count = 0
        self.connection_attempts = 0
        self.failed_connections = 0
    
    def register_database_manager(self, name: str, manager):
        """Register a database manager for monitoring."""
        with self._lock:
            self.database_managers[name] = manager
            logger.info(f"Registered {name} for system monitoring")
    
    def increment_query_count(self):
        """Increment query counter."""
        with self._lock:
            self.query_count += 1
    
    def increment_error_count(self):
        """Increment error counter."""
        with self._lock:
            self.error_count += 1
    
    def increment_connection_attempt(self, success: bool = True):
        """Increment connection attempt counter."""
        with self._lock:
            self.connection_attempts += 1
            if not success:
                self.failed_connections += 1
    
    def start(self):
        """Start the system monitor."""
        if self.running:
            return
        
        self.running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        logger.info("System monitor started")
    
    def stop(self):
        """Stop the system monitor."""
        self.running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("System monitor stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop."""
        while self.running:
            try:
                self._collect_metrics()
                self._check_system_health()
                self._cleanup_old_metrics()
            except Exception as e:
                logger.error(f"System monitoring error: {e}")
            
            time.sleep(self.check_interval)
    
    def _collect_metrics(self):
        """Collect system performance metrics."""
        try:
            # System metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # Database connection counts
            active_connections = 0
            for manager in self.database_managers.values():
                if hasattr(manager, '_engine') and manager._engine:
                    try:
                        pool = manager._engine.pool
                        active_connections += pool.checkedout()
                    except:
                        pass
            
            # Create metrics snapshot
            metrics = SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=cpu_percent,
                memory_percent=memory.percent,
                memory_used_mb=memory.used / 1024 / 1024,
                memory_available_mb=memory.available / 1024 / 1024,
                disk_usage_percent=disk.percent,
                active_connections=active_connections,
                failed_connections=self.failed_connections,
                query_count=self.query_count,
                error_count=self.error_count,
                uptime_seconds=time.time() - self.start_time
            )
            
            with self._lock:
                self.metrics_history.append(metrics)
            
            # Log warnings for high resource usage
            if cpu_percent > 80:
                logger.warning(f"High CPU usage: {cpu_percent:.1f}%")
            if memory.percent > 85:
                logger.warning(f"High memory usage: {memory.percent:.1f}%")
            if disk.percent > 90:
                logger.warning(f"High disk usage: {disk.percent:.1f}%")
                
        except Exception as e:
            logger.error(f"Failed to collect system metrics: {e}")
    
    def _check_system_health(self):
        """Perform system health checks."""
        try:
            # Memory cleanup
            if len(self.metrics_history) % 10 == 0:  # Every 10 cycles
                gc.collect()
            
            # Check database health
            for name, manager in self.database_managers.items():
                try:
                    start_time = time.time()
                    is_healthy = manager.is_available()
                    response_time = (time.time() - start_time) * 1000
                    
                    if response_time > 5000:  # 5 seconds
                        logger.warning(f"{name} health check took {response_time:.0f}ms")
                    
                    if not is_healthy:
                        logger.warning(f"{name} health check failed: {manager.get_connection_error()}")
                        
                except Exception as e:
                    logger.error(f"Health check failed for {name}: {e}")
            
        except Exception as e:
            logger.error(f"System health check failed: {e}")
    
    def _cleanup_old_metrics(self):
        """Clean up old metrics to prevent memory growth."""
        with self._lock:
            if len(self.metrics_history) > self.max_history_size:
                # Keep only the most recent metrics
                self.metrics_history = self.metrics_history[-self.max_history_size:]
    
    def get_current_metrics(self) -> Optional[SystemMetrics]:
        """Get the most recent system metrics."""
        with self._lock:
            return self.metrics_history[-1] if self.metrics_history else None
    
    def get_database_health(self) -> List[DatabaseHealth]:
        """Get health status of all databases."""
        health_status = []
        
        for name, manager in self.database_managers.items():
            try:
                start_time = time.time()
                is_available = manager.is_available()
                response_time = (time.time() - start_time) * 1000
                
                # Get connection pool info
                pool_size = 0
                active_connections = 0
                if hasattr(manager, '_engine') and manager._engine:
                    try:
                        pool = manager._engine.pool
                        pool_size = pool.size()
                        active_connections = pool.checkedout()
                    except:
                        pass
                
                health = DatabaseHealth(
                    name=name,
                    is_available=is_available,
                    last_check=datetime.now(),
                    response_time_ms=response_time,
                    error_message=manager.get_connection_error() if not is_available else None,
                    connection_pool_size=pool_size,
                    active_connections=active_connections
                )
                health_status.append(health)
                
            except Exception as e:
                health = DatabaseHealth(
                    name=name,
                    is_available=False,
                    last_check=datetime.now(),
                    response_time_ms=0,
                    error_message=str(e),
                    connection_pool_size=0,
                    active_connections=0
                )
                health_status.append(health)
        
        return health_status
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status."""
        current_metrics = self.get_current_metrics()
        database_health = self.get_database_health()
        
        return {
            "system_metrics": asdict(current_metrics) if current_metrics else None,
            "database_health": [asdict(db) for db in database_health],
            "uptime_seconds": time.time() - self.start_time,
            "total_queries": self.query_count,
            "total_errors": self.error_count,
            "connection_success_rate": (
                (self.connection_attempts - self.failed_connections) / self.connection_attempts * 100
                if self.connection_attempts > 0 else 100
            )
        }


# Global system monitor instance
system_monitor = SystemMonitor()
