﻿"""Database connection managers for multiple database types."""

import logging
import threading
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager

from .reliability import ensure_connection, retry_with_backoff, circuit_breaker

logger = logging.getLogger(__name__)


class DatabaseError(Exception):
    """Base exception for database operations."""
    pass


class DatabaseConnectionError(DatabaseError):
    """Raised when database connection fails."""
    pass


class DatabaseSecurityError(DatabaseError):
    """Raised when a database operation fails security checks."""
    pass


class BaseDatabaseManager(ABC):
    """Abstract base class for database managers."""

    def __init__(self, config):
        self.config = config
        self._is_available = False
        self._connection_error: Optional[str] = None
        self._last_health_check = 0
        self._health_check_interval = 30  # seconds
        self._lock = threading.RLock()  # Reentrant lock for thread safety

        # 🔥 智能重连机制
        self._last_connection_attempt = 0
        self._connection_attempt_count = 0
        self._max_backoff_seconds = 300  # 最大5分钟退避
        self._base_backoff_seconds = 1   # 基础1秒退避

        self._initialize()
    
    @abstractmethod
    def _initialize(self) -> None:
        """Initialize the database connection."""
        pass
    
    @abstractmethod
    def test_connection(self) -> bool:
        """Test database connection."""
        pass
    
    @abstractmethod
    def reconnect(self) -> bool:
        """Attempt to reconnect to the database."""
        pass
    
    def is_available(self) -> bool:
        """Check if database is available for operations."""
        with self._lock:
            # Perform periodic health check
            current_time = time.time()
            if (current_time - self._last_health_check) > self._health_check_interval:
                self._last_health_check = current_time

                if self._is_available:
                    # Health check for available connections
                    try:
                        if not self.test_connection():
                            logger.warning(f"{self.__class__.__name__}: Health check failed, marking as unavailable")
                            self._is_available = False
                            self._connection_error = "Health check failed"
                    except Exception as e:
                        logger.warning(f"{self.__class__.__name__}: Health check error: {e}")
                        self._is_available = False
                        self._connection_error = str(e)
                else:
                    # 🔥 关键修复：尝试重新连接不可用的数据库
                    logger.info(f"{self.__class__.__name__}: Database unavailable, attempting automatic reconnection...")
                    try:
                        if self.reconnect():
                            logger.info(f"{self.__class__.__name__}: Automatic reconnection successful!")
                            self._is_available = True
                            self._connection_error = None
                        else:
                            logger.debug(f"{self.__class__.__name__}: Automatic reconnection failed, will retry later")
                    except Exception as e:
                        logger.debug(f"{self.__class__.__name__}: Reconnection attempt failed: {e}")
                        self._connection_error = str(e)

            return self._is_available

    def ensure_available_for_operation(self, force_check: bool = False) -> bool:
        """
        🔥 关键方法：确保数据库对操作可用
        每次数据库操作前调用，实现即时重连

        Args:
            force_check: 强制检查，忽略退避算法（用于测试）
        """
        with self._lock:
            # 如果已经可用，快速返回
            if self._is_available:
                return True

            # 检查是否应该尝试重连（智能退避）
            current_time = time.time()
            if not force_check and not self._should_attempt_reconnection(current_time):
                # 在退避期间，返回缓存的可用状态而不是直接失败
                return False

            # 记录重连尝试
            self._last_connection_attempt = current_time
            self._connection_attempt_count += 1

            logger.debug(f"{self.__class__.__name__}: Attempting reconnection (attempt #{self._connection_attempt_count})...")

            try:
                # 尝试重新初始化连接
                self._initialize()

                if self._is_available:
                    logger.info(f"{self.__class__.__name__}: ✅ Reconnection successful!")
                    # 重置重连计数器
                    self._connection_attempt_count = 0
                    return True
                else:
                    logger.debug(f"{self.__class__.__name__}: ❌ Reconnection failed, will retry later")
                    return False

            except Exception as e:
                logger.debug(f"{self.__class__.__name__}: ❌ Reconnection error: {e}")
                self._connection_error = str(e)
                return False

    def _should_attempt_reconnection(self, current_time: float) -> bool:
        """
        智能退避算法：决定是否应该尝试重连
        - 首次失败：立即重试
        - 后续失败：指数退避，最大5分钟
        """
        if self._connection_attempt_count == 0:
            return True  # 首次尝试

        # 计算退避时间（指数退避 + 随机抖动）
        backoff_seconds = min(
            self._base_backoff_seconds * (2 ** (self._connection_attempt_count - 1)),
            self._max_backoff_seconds
        )

        # 添加随机抖动（±20%）避免雷群效应
        import random
        jitter = backoff_seconds * 0.2 * (random.random() - 0.5)
        backoff_seconds += jitter

        time_since_last_attempt = current_time - self._last_connection_attempt
        should_retry = time_since_last_attempt >= backoff_seconds

        if not should_retry:
            remaining_time = backoff_seconds - time_since_last_attempt
            logger.debug(f"{self.__class__.__name__}: Waiting {remaining_time:.1f}s before next reconnection attempt")

        return should_retry

    def get_connection_error(self) -> Optional[str]:
        """Get the last connection error message."""
        with self._lock:
            return self._connection_error
    
    @abstractmethod
    @contextmanager
    def get_connection(self):
        """Get a database connection with automatic cleanup."""
        pass


class SQLDatabaseManager(BaseDatabaseManager):
    """Base class for SQL database managers (SQL Server, Oracle)."""
    
    def __init__(self, config):
        self._engine = None
        self._metadata = None
        super().__init__(config)
    
    def _validate_sql_query(self, query: str) -> None:
        """Validate SQL query for security issues."""
        # Skip validation if security is disabled
        if not getattr(self.config, 'enable_sql_injection_protection', True):
            logger.debug("SQL security validation skipped - full access mode enabled")
            return
        
        # Check query length
        max_length = getattr(self.config, 'max_query_length', 100000)
        if len(query) > max_length:
            raise DatabaseSecurityError(f"Query exceeds maximum length of {max_length}")
        
        logger.debug("SQL query passed security validation")
    
    @abstractmethod
    @ensure_connection
    @retry_with_backoff
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a SELECT query and return results."""
        pass

    @abstractmethod
    @ensure_connection
    @retry_with_backoff
    def execute_non_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> int:
        """Execute an INSERT, UPDATE, or DELETE query and return affected rows count."""
        pass
    
    @abstractmethod
    def get_table_schema(self, table_name: str, schema_name: str = "dbo") -> Dict[str, Any]:
        """Get table schema information."""
        pass
    
    @abstractmethod
    def list_tables(self, schema_name: str = "dbo") -> List[Dict[str, Any]]:
        """List all tables in the database."""
        pass


class NoSQLDatabaseManager(BaseDatabaseManager):
    """Base class for NoSQL database managers (Redis)."""
    
    @abstractmethod
    def get(self, key: str) -> Optional[str]:
        """Get value by key."""
        pass
    
    @abstractmethod
    def set(self, key: str, value: str, expire: Optional[int] = None) -> bool:
        """Set key-value pair with optional expiration."""
        pass
    
    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete key."""
        pass
    
    @abstractmethod
    def keys(self, pattern: str = "*") -> List[str]:
        """Get keys matching pattern."""
        pass
    
    @abstractmethod
    def exists(self, key: str) -> bool:
        """Check if key exists."""
        pass
