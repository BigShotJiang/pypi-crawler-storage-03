﻿"""MCP Server for multi-database and filesystem access."""

import asyncio
import logging
import sys
from typing import Any, Dict, List, Optional, Sequence
import json

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel,
    ServerCapabilities,
    ToolsCapability
)

from .config import get_config
from .sqlserver_manager import SQLServerManager
from .oracle_manager import OracleManager
from .mysql_manager import MySQLManager
from .redis_manager import RedisManager
from .filesystem import fs_manager, FilesystemSecurityError, FilesystemOperationError
from .database_manager import DatabaseConnectionError, DatabaseSecurityError
from .reliability import health_checker, resource_manager
from .monitoring import system_monitor
from . import __version__

# Initialize managers
sqlserver_manager = None
oracle_manager = None
mysql_manager = None
redis_manager = None

def initialize_managers():
    """Initialize database managers."""
    global sqlserver_manager, oracle_manager, mysql_manager, redis_manager
    
    config = get_config()
    
    # Configure logging
    logging.basicConfig(
        level=getattr(logging, config.log_level),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler(sys.stdout)]
    )
    
    logger = logging.getLogger(__name__)
    
    # Initialize SQL Server manager
    try:
        sqlserver_manager = SQLServerManager()
        health_checker.register_manager("SQL Server", sqlserver_manager)
        system_monitor.register_database_manager("SQL Server", sqlserver_manager)
        logger.info(f"SQL Server manager initialized: {'available' if sqlserver_manager.is_available() else 'unavailable'}")
    except Exception as e:
        logger.error(f"Failed to initialize SQL Server manager: {e}")
        sqlserver_manager = None

    # Initialize Oracle manager
    try:
        oracle_manager = OracleManager()
        logger.info(f"Oracle manager initialized: {'available' if oracle_manager.is_available() else 'unavailable'}")
    except Exception as e:
        logger.error(f"Failed to initialize Oracle manager: {e}")
        oracle_manager = None

    # Initialize MySQL manager
    try:
        mysql_manager = MySQLManager()
        logger.info(f"MySQL manager initialized: {'available' if mysql_manager.is_available() else 'unavailable'}")
    except Exception as e:
        logger.error(f"Failed to initialize MySQL manager: {e}")
        mysql_manager = None

    # Initialize Redis manager
    try:
        redis_manager = RedisManager()
        logger.info(f"Redis manager initialized: {'available' if redis_manager.is_available() else 'unavailable'}")
    except Exception as e:
        logger.error(f"Failed to initialize Redis manager: {e}")
        redis_manager = None

# Initialize managers on module load
initialize_managers()

logger = logging.getLogger(__name__)


def ensure_database_available(manager, db_name: str) -> tuple[bool, str]:
    """
    🔥 智能数据库可用性检查
    每次工具调用时都会尝试确保数据库可用
    使用智能退避算法避免频繁重连
    """
    if not manager:
        return False, "Manager not initialized"

    # 🔥 使用新的智能重连方法
    try:
        if manager.ensure_available_for_operation():
            return True, ""
        else:
            error_msg = manager.get_connection_error() or "Database service not available"
            # 提供更友好的错误信息
            if "attempt" in error_msg.lower() or "connection" in error_msg.lower():
                error_msg += f" (Will automatically retry when {db_name} service starts)"
            return False, error_msg
    except Exception as e:
        error_msg = f"Connection error: {str(e)}"
        logger.error(f"{db_name}: Availability check error: {error_msg}")
        return False, error_msg


# Create MCP server instance
server = Server("jj-mcp")


@server.list_resources()
async def handle_list_resources() -> List[Resource]:
    """List available resources."""
    resources = [
        Resource(
            uri="config://server",
            name="Server Configuration",
            description="Current server configuration settings",
            mimeType="application/json",
        ),
        Resource(
            uri="config://filesystem",
            name="Filesystem Configuration", 
            description="Current filesystem configuration settings",
            mimeType="application/json",
        ),
        Resource(
            uri="status://databases",
            name="Database Status",
            description="Current database connection status for all databases",
            mimeType="application/json",
        ),
        Resource(
            uri="status://system",
            name="System Status",
            description="Comprehensive system health and performance metrics",
            mimeType="application/json",
        ),
        Resource(
            uri="status://monitoring",
            name="Monitoring Dashboard",
            description="Real-time monitoring dashboard with metrics and alerts",
            mimeType="application/json",
        ),
    ]
    
    return resources


@server.read_resource()
async def handle_read_resource(uri: str) -> str:
    """Read a specific resource."""
    config = get_config()
    
    if uri == "config://server":
        return json.dumps({
            "server_name": config.server_name,
            "server_version": config.server_version,
            "log_level": config.log_level,
        }, indent=2)
    
    elif uri == "config://filesystem":
        return json.dumps({
            "allowed_paths": config.filesystem.allowed_paths,
            "max_file_size": config.filesystem.max_file_size,
            "allowed_extensions": list(config.filesystem.allowed_extensions),
            "enable_write": config.filesystem.enable_write,
            "enable_delete": config.filesystem.enable_delete,
            "is_full_access_mode": config.filesystem.is_full_access_mode,
        }, indent=2)
    
    elif uri == "status://databases":
        status = {}
        
        # SQL Server status
        if sqlserver_manager:
            status["sqlserver"] = {
                "available": sqlserver_manager.is_available(),
                "error": sqlserver_manager.get_connection_error(),
                "enabled": config.sqlserver.enabled,
            }
        else:
            status["sqlserver"] = {
                "available": False,
                "error": "Manager not initialized",
                "enabled": config.sqlserver.enabled,
            }
        
        # Oracle status
        if oracle_manager:
            status["oracle"] = {
                "available": oracle_manager.is_available(),
                "error": oracle_manager.get_connection_error(),
                "enabled": config.oracle.enabled,
            }
        else:
            status["oracle"] = {
                "available": False,
                "error": "Manager not initialized",
                "enabled": config.oracle.enabled,
            }

        # MySQL status
        if mysql_manager:
            status["mysql"] = {
                "available": mysql_manager.is_available(),
                "error": mysql_manager.get_connection_error(),
                "enabled": config.mysql.enabled,
            }
        else:
            status["mysql"] = {
                "available": False,
                "error": "Manager not initialized",
                "enabled": config.mysql.enabled,
            }
        
        # Redis status
        if redis_manager:
            status["redis"] = {
                "available": redis_manager.is_available(),
                "error": redis_manager.get_connection_error(),
                "enabled": config.redis.enabled,
            }
        else:
            status["redis"] = {
                "available": False,
                "error": "Manager not initialized",
                "enabled": config.redis.enabled,
            }
        
        return json.dumps(status, indent=2)

    elif uri == "status://system":
        system_status = system_monitor.get_system_status()
        return json.dumps(system_status, indent=2, default=str)

    elif uri == "status://monitoring":
        monitoring_data = {
            "system_metrics": system_monitor.get_current_metrics(),
            "database_health": system_monitor.get_database_health(),
            "uptime": time.time() - system_monitor.start_time,
            "performance_summary": {
                "total_queries": system_monitor.query_count,
                "total_errors": system_monitor.error_count,
                "success_rate": (
                    (system_monitor.query_count - system_monitor.error_count) / system_monitor.query_count * 100
                    if system_monitor.query_count > 0 else 100
                )
            }
        }
        return json.dumps(monitoring_data, indent=2, default=str)

    else:
        raise ValueError(f"Unknown resource: {uri}")


@server.list_tools()
async def handle_list_tools() -> List[Tool]:
    """List available tools."""
    tools = []

    # Add SQL Server tools if available
    if sqlserver_manager and sqlserver_manager.is_available():
        tools.extend([
            Tool(
                name="sql_query_mcp-sqlserver-filesystem",
                description="Execute SQL SELECT query and display results in UI window",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "SQL SELECT query to execute"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Query parameters (optional)",
                            "additionalProperties": True
                        },
                        "show_ui": {
                            "type": "boolean",
                            "description": "Show results in UI window",
                            "default": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="sql_execute_mcp-sqlserver-filesystem",
                description="Execute SQL INSERT/UPDATE/DELETE query",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "SQL query to execute"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Query parameters (optional)",
                            "additionalProperties": True
                        },
                        "confirm_ui": {
                            "type": "boolean",
                            "description": "Show confirmation dialog in UI",
                            "default": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="get_table_schema_mcp-sqlserver-filesystem",
                description="Get table schema information and display in UI",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "table_name": {
                            "type": "string",
                            "description": "Name of the table"
                        },
                        "schema_name": {
                            "type": "string",
                            "description": "Schema name (default: dbo)",
                            "default": "dbo"
                        },
                        "show_ui": {
                            "type": "boolean",
                            "description": "Show schema in UI window",
                            "default": True
                        }
                    },
                    "required": ["table_name"]
                }
            ),
            Tool(
                name="list_tables_mcp-sqlserver-filesystem",
                description="List all tables in database and display in UI",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "schema_name": {
                            "type": "string",
                            "description": "Schema name (default: dbo)",
                            "default": "dbo"
                        },
                        "show_ui": {
                            "type": "boolean",
                            "description": "Show tables in UI window",
                            "default": True
                        }
                    }
                }
            )
        ])

    # Add Oracle tools if available
    if oracle_manager and oracle_manager.is_available():
        tools.extend([
            Tool(
                name="oracle_query",
                description="Execute Oracle SELECT query",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Oracle SQL SELECT query to execute"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Query parameters (optional)",
                            "additionalProperties": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="oracle_execute",
                description="Execute Oracle INSERT/UPDATE/DELETE query",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Oracle SQL query to execute"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Query parameters (optional)",
                            "additionalProperties": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="oracle_table_schema",
                description="Get Oracle table schema information",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "table_name": {
                            "type": "string",
                            "description": "Name of the table"
                        },
                        "schema_name": {
                            "type": "string",
                            "description": "Schema name (optional)",
                            "default": None
                        }
                    },
                    "required": ["table_name"]
                }
            ),
            Tool(
                name="oracle_list_tables",
                description="List all Oracle tables",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "schema_name": {
                            "type": "string",
                            "description": "Schema name (optional)",
                            "default": None
                        }
                    }
                }
            )
        ])

    # Add MySQL tools if available
    if mysql_manager and mysql_manager.is_available():
        tools.extend([
            Tool(
                name="mysql_query",
                description="Execute MySQL SELECT query",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "MySQL SQL SELECT query to execute"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Query parameters (optional)",
                            "additionalProperties": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="mysql_execute",
                description="Execute MySQL INSERT/UPDATE/DELETE query",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "MySQL SQL query to execute"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Query parameters (optional)",
                            "additionalProperties": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="mysql_table_schema",
                description="Get MySQL table schema information",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "table_name": {
                            "type": "string",
                            "description": "Name of the table"
                        },
                        "schema_name": {
                            "type": "string",
                            "description": "Schema/database name (optional)",
                            "default": None
                        }
                    },
                    "required": ["table_name"]
                }
            ),
            Tool(
                name="mysql_list_tables",
                description="List all MySQL tables",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "schema_name": {
                            "type": "string",
                            "description": "Schema/database name (optional)",
                            "default": None
                        }
                    }
                }
            )
        ])

    # Add Redis tools if available
    if redis_manager and redis_manager.is_available():
        tools.extend([
            Tool(
                name="redis_get",
                description="Get value from Redis by key",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "key": {
                            "type": "string",
                            "description": "Redis key"
                        }
                    },
                    "required": ["key"]
                }
            ),
            Tool(
                name="redis_set",
                description="Set key-value pair in Redis",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "key": {
                            "type": "string",
                            "description": "Redis key"
                        },
                        "value": {
                            "type": "string",
                            "description": "Value to set"
                        },
                        "expire": {
                            "type": "integer",
                            "description": "Expiration time in seconds (optional)"
                        }
                    },
                    "required": ["key", "value"]
                }
            ),
            Tool(
                name="redis_delete",
                description="Delete key from Redis",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "key": {
                            "type": "string",
                            "description": "Redis key to delete"
                        }
                    },
                    "required": ["key"]
                }
            ),
            Tool(
                name="redis_keys",
                description="Get Redis keys matching pattern",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Key pattern (default: *)",
                            "default": "*"
                        }
                    }
                }
            ),
            Tool(
                name="redis_exists",
                description="Check if Redis key exists",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "key": {
                            "type": "string",
                            "description": "Redis key to check"
                        }
                    },
                    "required": ["key"]
                }
            )
        ])

    # Always add filesystem tools
    tools.extend([
        Tool(
            name="read_file_mcp-sqlserver-filesystem",
            description="Read file content and optionally display in UI",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to read"
                    },
                    "encoding": {
                        "type": "string",
                        "description": "File encoding (default: utf-8)",
                        "default": "utf-8"
                    },
                    "show_ui": {
                        "type": "boolean",
                        "description": "Show content in UI window",
                        "default": False
                    }
                },
                "required": ["file_path"]
            }
        ),
        Tool(
            name="write_file_mcp-sqlserver-filesystem",
            description="Write content to file with optional UI confirmation",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to write"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to file"
                    },
                    "encoding": {
                        "type": "string",
                        "description": "File encoding (default: utf-8)",
                        "default": "utf-8"
                    },
                    "create_dirs": {
                        "type": "boolean",
                        "description": "Create parent directories if needed",
                        "default": True
                    },
                    "confirm_ui": {
                        "type": "boolean",
                        "description": "Show confirmation dialog in UI",
                        "default": True
                    }
                },
                "required": ["file_path", "content"]
            }
        ),
        Tool(
            name="list_directory_mcp-sqlserver-filesystem",
            description="List directory contents and display in UI",
            inputSchema={
                "type": "object",
                "properties": {
                    "dir_path": {
                        "type": "string",
                        "description": "Path to the directory to list"
                    },
                    "recursive": {
                        "type": "boolean",
                        "description": "List recursively",
                        "default": False
                    },
                    "show_ui": {
                        "type": "boolean",
                        "description": "Show directory listing in UI window",
                        "default": True
                    }
                },
                "required": ["dir_path"]
            }
        )
    ])

    return tools


@server.call_tool()
async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """Handle tool calls."""
    try:
        # SQL Server tools
        if name == "sql_query_mcp-sqlserver-filesystem":
            available, error_msg = ensure_database_available(sqlserver_manager, "SQL Server")
            if not available:
                return [TextContent(
                    type="text",
                    text=f"❌ SQL Server is not available: {error_msg}"
                )]

            query = arguments.get("query")
            parameters = arguments.get("parameters", {})

            try:
                result = sqlserver_manager.execute_query(query, parameters)

                # Format result as table
                if result["rows"]:
                    # Create table header
                    headers = result["columns"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    # Add data rows
                    for row in result["rows"]:
                        row_values = [str(row.get(col, "")) for col in headers]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    response_text = f"✅ Query executed successfully. Returned {result['row_count']} rows.\n\n{table_text}"
                else:
                    response_text = "✅ Query executed successfully. No rows returned."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ SQL Server query failed: {str(e)}")]

        elif name == "sql_execute_mcp-sqlserver-filesystem":
            available, error_msg = ensure_database_available(sqlserver_manager, "SQL Server")
            if not available:
                return [TextContent(
                    type="text",
                    text=f"❌ SQL Server is not available: {error_msg}"
                )]

            query = arguments.get("query")
            parameters = arguments.get("parameters", {})

            try:
                affected_rows = sqlserver_manager.execute_non_query(query, parameters)
                return [TextContent(type="text", text=f"✅ SQL Server command executed successfully. {affected_rows} rows affected.")]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ SQL Server command failed: {str(e)}")]

        elif name == "get_table_schema_mcp-sqlserver-filesystem":
            if not sqlserver_manager or not sqlserver_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ SQL Server is not available: {sqlserver_manager.get_connection_error() if sqlserver_manager else 'Manager not initialized'}"
                )]

            table_name = arguments.get("table_name")
            schema_name = arguments.get("schema_name", "dbo")

            try:
                schema_info = sqlserver_manager.get_table_schema(table_name, schema_name)

                # Format schema as table
                if schema_info["columns"]:
                    headers = ["Column", "Type", "Nullable", "Default", "Primary Key"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for col in schema_info["columns"]:
                        row_values = [
                            col.get("COLUMN_NAME", ""),
                            col.get("DATA_TYPE", ""),
                            "Yes" if col.get("IS_NULLABLE") == "YES" else "No",
                            str(col.get("COLUMN_DEFAULT", "")),
                            "Yes" if col.get("IS_PRIMARY_KEY") else "No"
                        ]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    response_text = f"✅ Table schema for {schema_name}.{table_name}:\n\n{table_text}"
                else:
                    response_text = f"❌ Table {schema_name}.{table_name} not found or has no columns."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Failed to get table schema: {str(e)}")]

        elif name == "list_tables_mcp-sqlserver-filesystem":
            if not sqlserver_manager or not sqlserver_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ SQL Server is not available: {sqlserver_manager.get_connection_error() if sqlserver_manager else 'Manager not initialized'}"
                )]

            schema_name = arguments.get("schema_name", "dbo")

            try:
                tables = sqlserver_manager.list_tables(schema_name)

                if tables:
                    headers = ["Schema", "Table", "Type"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for table in tables:
                        row_values = [
                            table.get("TABLE_SCHEMA", ""),
                            table.get("TABLE_NAME", ""),
                            table.get("TABLE_TYPE", "")
                        ]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    response_text = f"✅ Tables in schema {schema_name} ({len(tables)} found):\n\n{table_text}"
                else:
                    response_text = f"❌ No tables found in schema {schema_name}."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Failed to list tables: {str(e)}")]

        # Oracle tools
        elif name == "oracle_query":
            if not oracle_manager or not oracle_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ Oracle is not available: {oracle_manager.get_connection_error() if oracle_manager else 'Manager not initialized'}"
                )]

            query = arguments.get("query")
            parameters = arguments.get("parameters", {})

            try:
                result = oracle_manager.execute_query(query, parameters)

                # Format result as table
                if result["rows"]:
                    headers = result["columns"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for row in result["rows"]:
                        row_values = [str(row.get(col, "")) for col in headers]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    response_text = f"✅ Oracle query executed successfully. Returned {result['row_count']} rows.\n\n{table_text}"
                else:
                    response_text = "✅ Oracle query executed successfully. No rows returned."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Oracle query failed: {str(e)}")]

        elif name == "oracle_execute":
            if not oracle_manager or not oracle_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ Oracle is not available: {oracle_manager.get_connection_error() if oracle_manager else 'Manager not initialized'}"
                )]

            query = arguments.get("query")
            parameters = arguments.get("parameters", {})

            try:
                affected_rows = oracle_manager.execute_non_query(query, parameters)
                return [TextContent(type="text", text=f"✅ Oracle command executed successfully. {affected_rows} rows affected.")]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Oracle command failed: {str(e)}")]

        elif name == "oracle_table_schema":
            if not oracle_manager or not oracle_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ Oracle is not available: {oracle_manager.get_connection_error() if oracle_manager else 'Manager not initialized'}"
                )]

            table_name = arguments.get("table_name")
            schema_name = arguments.get("schema_name")

            try:
                schema_info = oracle_manager.get_table_schema(table_name, schema_name)

                # Format schema as table
                if schema_info["columns"]:
                    headers = ["Column", "Type", "Nullable", "Default", "Primary Key"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for col in schema_info["columns"]:
                        row_values = [
                            col.get("COLUMN_NAME", ""),
                            col.get("DATA_TYPE", ""),
                            "Yes" if col.get("NULLABLE") == "Y" else "No",
                            str(col.get("DATA_DEFAULT", "")),
                            "Yes" if col.get("IS_PRIMARY_KEY") else "No"
                        ]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    schema_display = schema_name if schema_name else "current user"
                    response_text = f"✅ Oracle table schema for {schema_display}.{table_name}:\n\n{table_text}"
                else:
                    response_text = f"❌ Table {table_name} not found or has no columns."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Failed to get Oracle table schema: {str(e)}")]

        elif name == "oracle_list_tables":
            if not oracle_manager or not oracle_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ Oracle is not available: {oracle_manager.get_connection_error() if oracle_manager else 'Manager not initialized'}"
                )]

            schema_name = arguments.get("schema_name")

            try:
                tables = oracle_manager.list_tables(schema_name)

                if tables:
                    headers = ["Schema", "Table", "Type"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for table in tables:
                        row_values = [
                            table.get("TABLE_SCHEMA", ""),
                            table.get("TABLE_NAME", ""),
                            table.get("TABLE_TYPE", "")
                        ]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    schema_display = schema_name if schema_name else "current user"
                    response_text = f"✅ Oracle tables in schema {schema_display} ({len(tables)} found):\n\n{table_text}"
                else:
                    response_text = f"❌ No tables found in schema {schema_name or 'current user'}."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Failed to list Oracle tables: {str(e)}")]

        # MySQL tools
        elif name == "mysql_query":
            available, error_msg = ensure_database_available(mysql_manager, "MySQL")
            if not available:
                return [TextContent(
                    type="text",
                    text=f"❌ MySQL is not available: {error_msg}"
                )]

            query = arguments.get("query")
            parameters = arguments.get("parameters", {})

            try:
                result = mysql_manager.execute_query(query, parameters)

                # Format result as table
                if result["rows"]:
                    headers = result["columns"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for row in result["rows"]:
                        row_values = [str(row.get(col, "")) for col in headers]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    response_text = f"✅ MySQL query executed successfully. Returned {result['row_count']} rows.\n\n{table_text}"
                else:
                    response_text = "✅ MySQL query executed successfully. No rows returned."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ MySQL query failed: {str(e)}")]

        elif name == "mysql_execute":
            if not mysql_manager or not mysql_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ MySQL is not available: {mysql_manager.get_connection_error() if mysql_manager else 'Manager not initialized'}"
                )]

            query = arguments.get("query")
            parameters = arguments.get("parameters", {})

            try:
                affected_rows = mysql_manager.execute_non_query(query, parameters)
                return [TextContent(type="text", text=f"✅ MySQL command executed successfully. {affected_rows} rows affected.")]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ MySQL command failed: {str(e)}")]

        elif name == "mysql_table_schema":
            if not mysql_manager or not mysql_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ MySQL is not available: {mysql_manager.get_connection_error() if mysql_manager else 'Manager not initialized'}"
                )]

            table_name = arguments.get("table_name")
            schema_name = arguments.get("schema_name")

            try:
                schema_info = mysql_manager.get_table_schema(table_name, schema_name)

                # Format schema as table
                if schema_info["columns"]:
                    headers = ["Column", "Type", "Nullable", "Default", "Primary Key", "Extra"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for col in schema_info["columns"]:
                        row_values = [
                            col.get("COLUMN_NAME", ""),
                            col.get("DATA_TYPE", ""),
                            "Yes" if col.get("IS_NULLABLE") == "YES" else "No",
                            str(col.get("COLUMN_DEFAULT", "")),
                            "Yes" if col.get("IS_PRIMARY_KEY") else "No",
                            col.get("EXTRA", "")
                        ]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    schema_display = schema_name if schema_name else "current database"
                    response_text = f"✅ MySQL table schema for {schema_display}.{table_name}:\n\n{table_text}"
                else:
                    response_text = f"❌ Table {table_name} not found or has no columns."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Failed to get MySQL table schema: {str(e)}")]

        elif name == "mysql_list_tables":
            if not mysql_manager or not mysql_manager.is_available():
                return [TextContent(
                    type="text",
                    text=f"❌ MySQL is not available: {mysql_manager.get_connection_error() if mysql_manager else 'Manager not initialized'}"
                )]

            schema_name = arguments.get("schema_name")

            try:
                tables = mysql_manager.list_tables(schema_name)

                if tables:
                    headers = ["Schema", "Table", "Type", "Engine", "Rows"]
                    table_lines = [" | ".join(headers)]
                    table_lines.append(" | ".join(["-" * len(h) for h in headers]))

                    for table in tables:
                        row_values = [
                            table.get("TABLE_SCHEMA", ""),
                            table.get("TABLE_NAME", ""),
                            table.get("TABLE_TYPE", ""),
                            table.get("ENGINE", ""),
                            str(table.get("TABLE_ROWS", ""))
                        ]
                        table_lines.append(" | ".join(row_values))

                    table_text = "\n".join(table_lines)
                    schema_display = schema_name if schema_name else "current database"
                    response_text = f"✅ MySQL tables in {schema_display} ({len(tables)} found):\n\n{table_text}"
                else:
                    response_text = f"❌ No tables found in {schema_name or 'current database'}."

                return [TextContent(type="text", text=response_text)]

            except Exception as e:
                return [TextContent(type="text", text=f"❌ Failed to list MySQL tables: {str(e)}")]

        # Redis tools
        elif name.startswith("redis_"):
            from .tool_handlers import handle_redis_tools
            return handle_redis_tools(name, arguments, redis_manager)

        # Filesystem tools
        elif name.endswith("_mcp-sqlserver-filesystem") and name.startswith(("read_file", "write_file", "list_directory")):
            from .tool_handlers import handle_filesystem_tools
            return handle_filesystem_tools(name, arguments, fs_manager)

        else:
            return [TextContent(type="text", text=f"❌ Unknown tool: {name}")]

    except Exception as e:
        logger.error(f"Tool call error: {e}")
        return [TextContent(type="text", text=f"❌ Tool execution failed: {str(e)}")]


async def main():
    """Main entry point for the MCP server."""
    try:
        # Initialize managers
        initialize_managers()

        # Start monitoring systems
        system_monitor.start()
        health_checker.start()

        logger.info("🚀 JJ Multi-Database MCP Server starting...")
        logger.info("📊 System monitoring enabled")
        logger.info("🔍 Health checking enabled")

        # Run the server
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="jj-mcp",
                    server_version=__version__,
                    capabilities=ServerCapabilities(
                        tools=ToolsCapability()
                    )
                )
            )
    except KeyboardInterrupt:
        logger.info("Server shutdown requested")
    except Exception as e:
        logger.error(f"Server error: {e}")
        raise
    finally:
        # Cleanup
        try:
            system_monitor.stop()
            health_checker.stop()
            resource_manager.cleanup_all()
            logger.info("🛑 JJ Multi-Database MCP Server stopped")
        except Exception as e:
            logger.error(f"Cleanup error: {e}")


if __name__ == "__main__":
    asyncio.run(main())
