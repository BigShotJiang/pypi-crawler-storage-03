﻿"""Reliability and high availability enhancements for JJ MCP."""

import asyncio
import logging
import time
import threading
from typing import Any, Callable, Dict, Optional
from functools import wraps
import random

logger = logging.getLogger(__name__)


class CircuitBreaker:
    """Enhanced circuit breaker pattern for database operations."""

    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60,
                 expected_exception: type = Exception, success_threshold: int = 3):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        self.success_threshold = success_threshold  # Successes needed to close circuit

        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
        self.last_success_time = None
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN
        self._lock = threading.Lock()

        # Statistics
        self.total_calls = 0
        self.total_failures = 0
        self.total_successes = 0
    
    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            with self._lock:
                self.total_calls += 1

                if self.state == 'OPEN':
                    if self._should_attempt_reset():
                        self.state = 'HALF_OPEN'
                        self.success_count = 0  # Reset success counter
                        logger.info(f"Circuit breaker for {func.__name__} is now HALF_OPEN")
                    else:
                        raise Exception(f"Circuit breaker is OPEN for {func.__name__} (failure rate: {self.get_failure_rate():.1f}%)")

                try:
                    result = func(*args, **kwargs)
                    self._on_success(func.__name__)
                    return result
                except self.expected_exception as e:
                    self._on_failure(func.__name__)
                    raise e

        return wrapper
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset."""
        return (
            self.last_failure_time is not None and
            time.time() - self.last_failure_time >= self.recovery_timeout
        )
    
    def _on_success(self, func_name: str):
        """Handle successful operation."""
        self.total_successes += 1
        self.last_success_time = time.time()

        if self.state == 'HALF_OPEN':
            self.success_count += 1
            if self.success_count >= self.success_threshold:
                self.state = 'CLOSED'
                self.failure_count = 0
                logger.info(f"Circuit breaker for {func_name} is now CLOSED after {self.success_count} successes")
        elif self.state == 'CLOSED':
            self.failure_count = 0  # Reset failure count on success

    def _on_failure(self, func_name: str):
        """Handle failed operation."""
        self.total_failures += 1
        self.failure_count += 1
        self.last_failure_time = time.time()

        if self.state == 'HALF_OPEN':
            # Immediately open on failure in half-open state
            self.state = 'OPEN'
            logger.warning(f"Circuit breaker for {func_name} is now OPEN (failed in HALF_OPEN state)")
        elif self.failure_count >= self.failure_threshold:
            self.state = 'OPEN'
            logger.warning(f"Circuit breaker for {func_name} is now OPEN after {self.failure_count} failures")

    def get_failure_rate(self) -> float:
        """Get current failure rate percentage."""
        if self.total_calls == 0:
            return 0.0
        return (self.total_failures / self.total_calls) * 100

    def get_stats(self) -> Dict[str, Any]:
        """Get circuit breaker statistics."""
        return {
            "state": self.state,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "total_calls": self.total_calls,
            "total_failures": self.total_failures,
            "total_successes": self.total_successes,
            "failure_rate": self.get_failure_rate(),
            "last_failure_time": self.last_failure_time,
            "last_success_time": self.last_success_time
        }


class RetryWithBackoff:
    """Retry decorator with exponential backoff."""
    
    def __init__(self, max_retries: int = 3, base_delay: float = 1.0, max_delay: float = 60.0, 
                 backoff_factor: float = 2.0, jitter: bool = True):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.jitter = jitter
    
    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(self.max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    
                    if attempt == self.max_retries:
                        logger.error(f"Function {func.__name__} failed after {self.max_retries + 1} attempts: {e}")
                        raise e
                    
                    # Calculate delay with exponential backoff
                    delay = min(self.base_delay * (self.backoff_factor ** attempt), self.max_delay)
                    
                    # Add jitter to prevent thundering herd
                    if self.jitter:
                        delay *= (0.5 + random.random() * 0.5)
                    
                    logger.warning(f"Function {func.__name__} failed (attempt {attempt + 1}/{self.max_retries + 1}), retrying in {delay:.2f}s: {e}")
                    time.sleep(delay)
            
            raise last_exception
        
        return wrapper


class HealthChecker:
    """Health checker for database connections."""
    
    def __init__(self, check_interval: int = 30):
        self.check_interval = check_interval
        self.managers = {}
        self.running = False
        self._thread = None
        self._lock = threading.Lock()
    
    def register_manager(self, name: str, manager):
        """Register a database manager for health checking."""
        with self._lock:
            self.managers[name] = manager
            logger.info(f"Registered {name} manager for health checking")
    
    def start(self):
        """Start the health checker."""
        if self.running:
            return
        
        self.running = True
        self._thread = threading.Thread(target=self._health_check_loop, daemon=True)
        self._thread.start()
        logger.info("Health checker started")
    
    def stop(self):
        """Stop the health checker."""
        self.running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Health checker stopped")
    
    def _health_check_loop(self):
        """Main health check loop."""
        while self.running:
            try:
                self._perform_health_checks()
            except Exception as e:
                logger.error(f"Health check error: {e}")
            
            time.sleep(self.check_interval)
    
    def _perform_health_checks(self):
        """Perform health checks on all registered managers."""
        with self._lock:
            for name, manager in self.managers.items():
                try:
                    if hasattr(manager, 'is_available') and hasattr(manager, 'test_connection'):
                        if not manager.is_available():
                            logger.warning(f"{name} manager is not available, attempting reconnection...")
                            if hasattr(manager, 'reconnect'):
                                success = manager.reconnect()
                                if success:
                                    logger.info(f"{name} manager reconnected successfully")
                                else:
                                    logger.error(f"{name} manager reconnection failed")
                        elif not manager.test_connection():
                            logger.warning(f"{name} manager connection test failed")
                except Exception as e:
                    logger.error(f"Health check failed for {name}: {e}")


class ResourceManager:
    """Resource manager for proper cleanup."""
    
    def __init__(self):
        self._resources = []
        self._lock = threading.Lock()
    
    def register_resource(self, resource, cleanup_func: Callable):
        """Register a resource for cleanup."""
        with self._lock:
            self._resources.append((resource, cleanup_func))
    
    def cleanup_all(self):
        """Clean up all registered resources."""
        with self._lock:
            for resource, cleanup_func in self._resources:
                try:
                    cleanup_func(resource)
                except Exception as e:
                    logger.error(f"Failed to cleanup resource {resource}: {e}")
            self._resources.clear()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup_all()


class ConnectionPool:
    """Enhanced connection pool with monitoring."""
    
    def __init__(self, create_connection: Callable, max_size: int = 10, 
                 max_idle_time: int = 300, health_check_interval: int = 60):
        self.create_connection = create_connection
        self.max_size = max_size
        self.max_idle_time = max_idle_time
        self.health_check_interval = health_check_interval
        
        self._pool = []
        self._in_use = set()
        self._lock = threading.Lock()
        self._last_health_check = 0
    
    def get_connection(self):
        """Get a connection from the pool."""
        with self._lock:
            self._cleanup_idle_connections()
            
            # Try to get an existing connection
            if self._pool:
                conn = self._pool.pop()
                self._in_use.add(conn)
                return conn
            
            # Create new connection if under limit
            if len(self._in_use) < self.max_size:
                conn = self.create_connection()
                self._in_use.add(conn)
                return conn
            
            raise Exception("Connection pool exhausted")
    
    def return_connection(self, conn):
        """Return a connection to the pool."""
        with self._lock:
            if conn in self._in_use:
                self._in_use.remove(conn)
                self._pool.append(conn)
    
    def _cleanup_idle_connections(self):
        """Clean up idle connections."""
        current_time = time.time()
        if current_time - self._last_health_check > self.health_check_interval:
            # Perform health check and cleanup
            self._last_health_check = current_time
            # Implementation would depend on connection type


# Global instances
health_checker = HealthChecker()
resource_manager = ResourceManager()

# Decorators for easy use
circuit_breaker = CircuitBreaker()
retry_with_backoff = RetryWithBackoff()


def ensure_connection(func: Callable) -> Callable:
    """Decorator to ensure database connection is available."""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if not self.is_available():
            logger.warning(f"Connection not available for {func.__name__}, attempting reconnect...")
            if not self.reconnect():
                raise Exception(f"Failed to establish connection for {func.__name__}")
        
        return func(self, *args, **kwargs)
    
    return wrapper
