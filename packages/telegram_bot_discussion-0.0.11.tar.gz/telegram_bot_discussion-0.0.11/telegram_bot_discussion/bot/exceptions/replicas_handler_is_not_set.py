class ReplicasHandlerIsNotSet(Exception):
    def __str__(self):
        return "Replicas-handler is not set"
