from .dialogue import Dialogue as Dialogue, Phrase as Phrase, Polemic as Polemic
