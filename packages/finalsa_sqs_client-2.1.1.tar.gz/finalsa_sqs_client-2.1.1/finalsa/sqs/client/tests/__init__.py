from .Client import SqsServiceTest

__all__ = [
    "SqsServiceTest",
]