from .SqsException import SqsException

__all__ = [
    "SqsException",
]
