"""Entry point to python_sri"""

from .sri import SRI

__all__ = ["SRI"]
