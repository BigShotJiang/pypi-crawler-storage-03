"""
rumdl: An extremely fast Markdown linter written in Rust.
"""

__version__ = "0.0.12"
