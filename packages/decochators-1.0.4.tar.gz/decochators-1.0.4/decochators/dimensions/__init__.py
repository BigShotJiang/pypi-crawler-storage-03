from . import one_dimension
from . import three_dimensions

__all__ = ["one_dimension", "three_dimensions"]