# Rust-Ripser改进计划: 专门针对CANN分析的高性能实现

## 目标：超越原版ripser在maxdim=1和2场景下的性能

基于当前测试结果，rust-ripser有很大潜力超越原版ripser，特别是在实现了缺失功能并进行专门优化后。

## 现状分析

### 性能对比 (80点，2D)
| 库 | MaxDim=1 (距离矩阵) | MaxDim=2 (距离矩阵) |
|---|-------------------|-------------------|
| **ripser** | 0.0008s 🏆 | 0.0122s 🏆 |
| **GUDHI** | 0.0053s | 0.0812s |
| **rust-ripser** | 不支持 | 不支持 |

### 当前rust-ripser问题
1. ❌ 不支持预计算距离矩阵 (`precomputed` metric)
2. ❌ 不支持cocycles计算
3. ❌ maxdim=2性能差 (2.2s vs 0.012s)
4. ❌ H1结果不准确 (80个H1 vs 正确的18个)

## 重构目标清单

### 🎯 阶段1: 核心功能实现 (高优先级)

#### 1.1 预计算距离矩阵支持
```rust
// 目标API
rust_ripser(distance_matrix, maxdim=1, metric="precomputed")
```

**实现任务:**
- [ ] 在`distance.rs`中添加`Precomputed`枚举值
- [ ] 实现预计算矩阵的验证和处理逻辑
- [ ] 优化内存访问模式 (避免重复计算)
- [ ] 添加对称性和三角不等式验证

#### 1.2 Cocycles计算实现
```rust
// 目标输出格式 (兼容ripser)
result = {
    "dgms": [...],
    "cocycles": [h0_cocycles, h1_cocycles, ...],
    "num_edges": int,
    "dperm2all": distance_matrix
}
```

**实现任务:**
- [ ] 实现cocycle矩阵约化算法
- [ ] 添加cocycle表示的存储和输出
- [ ] 确保与ripser格式完全兼容
- [ ] 优化cocycle计算的内存使用

#### 1.3 修复H1计算错误
**当前问题:** H1返回80个interval，应该是18个
- [ ] 调试filtration构建逻辑
- [ ] 修复边界矩阵约化算法
- [ ] 验证persistent pair计算

### 🚀 阶段2: 性能优化 (中优先级)

#### 2.1 MaxDim=1专门优化
**目标:** 超越ripser的0.0008s性能

**优化策略:**
- [ ] **边构建优化:** 针对maxdim=1，只需要构建边，避免构建三角形
- [ ] **内存布局优化:** 使用cache-friendly的数据结构
- [ ] **SIMD加速:** 利用AVX2/AVX512加速距离计算和比较
- [ ] **并行filtration:** 并行构建Vietoris-Rips复形
- [ ] **早期终止:** 在达到threshold时提前停止

```rust
// 专门的maxdim=1优化路径
fn compute_h1_optimized(distance_matrix: &Array2<f64>) -> PersistenceResult {
    // 只构建边，跳过高维单纯形
    // 使用专门的H1算法
}
```

#### 2.2 MaxDim=2性能提升  
**目标:** 从2.2s提升到接近ripser的0.012s (180x加速)

**优化策略:**
- [ ] **三角形批量处理:** 向量化三角形filtration值计算
- [ ] **稀疏矩阵优化:** 利用距离矩阵的稀疏性
- [ ] **分块并行:** 将大矩阵分块并行处理
- [ ] **内存池:** 避免频繁内存分配
- [ ] **清理-压缩:** 实现高效的矩阵约化算法

### ⚡ 阶段3: 深度优化 (高级)

#### 3.1 算法级优化
- [ ] **Edge Collapse:** 实现类似GUDHI的边坍缩预处理
- [ ] **Apparent Pairs:** 快速识别显然配对，减少矩阵约化工作
- [ ] **Clearing优化:** 实现clearing算法减少计算量
- [ ] **Cohomology算法:** 使用对偶算法可能更快

#### 3.2 CANN特定优化
- [ ] **相关性矩阵特化:** 针对correlation-based距离矩阵的特殊性质优化
- [ ] **神经数据模式:** 利用神经活动数据的典型模式
- [ ] **阈值预估:** 智能估计合适的filtration阈值

#### 3.3 硬件加速
- [ ] **GPU加速:** CUDA/ROCm实现大规模并行
- [ ] **多线程优化:** 更细粒度的并行策略
- [ ] **NUMA优化:** 针对多socket系统优化

## 性能目标

### 短期目标 (阶段1完成后)
- MaxDim=1: **0.0005s** (比ripser快60%)
- MaxDim=2: **0.008s** (比ripser快35%)
- 功能完整性: 100%兼容ripser API

### 中期目标 (阶段2完成后)  
- MaxDim=1: **0.0003s** (比ripser快167%)
- MaxDim=2: **0.005s** (比ripser快144%)
- 内存使用: 比ripser少30%

### 长期目标 (阶段3完成后)
- MaxDim=1: **0.0001s** (比ripser快8x)
- MaxDim=2: **0.002s** (比ripser快6x)
- GPU加速: 支持1000+点的实时计算

## 实现路线图

### Week 1-2: 核心功能补全
1. 实现precomputed距离矩阵支持
2. 修复H1计算错误
3. 基础cocycles实现

### Week 3-4: 性能优化
1. MaxDim=1专门优化路径
2. 内存和缓存优化
3. 并行算法改进

### Week 5-6: 高级优化
1. MaxDim=2深度优化
2. 算法级改进
3. 全面性能测试和调优

## 成功指标

### 功能指标
- [ ] 100%通过ripser兼容性测试
- [ ] 支持precomputed距离矩阵
- [ ] 正确的cocycles计算
- [ ] 与CANN分析无缝集成

### 性能指标
- [ ] MaxDim=1: 至少比ripser快2x
- [ ] MaxDim=2: 至少比ripser快3x  
- [ ] 内存使用不超过ripser的120%
- [ ] 支持至少500点的实时计算

## 风险评估

### 技术风险
- **中等风险:** Cocycles算法复杂性
- **低风险:** Precomputed矩阵支持
- **高风险:** 达到目标性能提升

### 缓解策略
- 分阶段实现，确保每阶段都有可用版本
- 充分的单元测试和基准测试
- 与ripser结果的详细对比验证

## 结论

Rust-ripser有很大潜力超越原版ripser，特别是在：
1. **并行计算优势** - Rust的零成本并行抽象
2. **内存安全性** - 避免C++的内存管理开销
3. **专门优化** - 针对maxdim=1,2的特定优化
4. **现代编译器** - LLVM的先进优化

关键是要系统性地解决当前的功能缺失，然后专注于性能优化。预期在完整实现后，能够在CANN分析的关键场景下提供2-5x的性能提升。