import pytest
import numpy as np
import time
from rust_ripser import compute_ripser_advanced, compute_ripser_optimized, compute_ripser_h2_optimized


class TestPerformance:
    """Performance and benchmarking tests."""
    
    def test_basic_performance_timing(self, random_points_small):
        """Test that basic computation completes in reasonable time."""
        start_time = time.time()
        
        result = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=1.5,
            mode="balanced"
        )
        
        elapsed_time = time.time() - start_time
        
        # Should complete within reasonable time (adjust as needed)
        assert elapsed_time < 5.0  # 5 seconds max for small dataset
        assert 'computation_time' in result
        assert result['computation_time'] > 0
    
    def test_optimization_modes_performance(self, random_points_medium):
        """Compare performance of different optimization modes."""
        modes = ["accurate", "balanced", "fast"]
        times = {}
        results = {}
        
        for mode in modes:
            start_time = time.time()
            
            result = compute_ripser_advanced(
                random_points_medium,
                maxdim=1,
                thresh=1.0,
                mode=mode
            )
            
            elapsed_time = time.time() - start_time
            times[mode] = elapsed_time
            results[mode] = result
            
            # Basic validation
            assert 'dgms' in result
            assert elapsed_time < 30.0  # 30 seconds max
        
        # Fast mode should generally be fastest (though not guaranteed)
        print(f"Performance comparison: {times}")
    
    def test_h1_optimization_performance(self, random_points_medium):
        """Test H1 optimization performance."""
        start_time = time.time()
        
        result = compute_ripser_optimized(
            random_points_medium,
            thresh=1.0
        )
        
        elapsed_time = time.time() - start_time
        
        assert 'dgms' in result
        assert elapsed_time < 10.0  # Should be reasonably fast
        assert result['maxdim'] == 1
    
    def test_h2_optimization_performance(self, random_points_small):
        """Test H2 optimization performance."""
        start_time = time.time()
        
        result = compute_ripser_h2_optimized(
            random_points_small,
            thresh=1.0
        )
        
        elapsed_time = time.time() - start_time
        
        assert 'dgms' in result
        assert elapsed_time < 15.0  # H2 computation is more expensive
        assert len(result['dgms']) == 3  # H0, H1, H2
    
    def test_parallel_performance_benefit(self, random_points_medium):
        """Test that parallel mode provides performance benefit on suitable data."""
        # Serial computation
        start_time = time.time()
        result_serial = compute_ripser_advanced(
            random_points_medium,
            maxdim=1,
            thresh=1.0,
            mode="balanced"
        )
        serial_time = time.time() - start_time
        
        # Parallel computation
        start_time = time.time()
        result_parallel = compute_ripser_advanced(
            random_points_medium,
            maxdim=1,
            thresh=1.0,
            mode="parallel",
            num_threads=2
        )
        parallel_time = time.time() - start_time
        
        # Both should succeed
        assert 'dgms' in result_serial
        assert 'dgms' in result_parallel
        
        # Print timing comparison
        print(f"Serial time: {serial_time:.4f}s, Parallel time: {parallel_time:.4f}s")
        
        # Note: Parallel may not always be faster for small datasets due to overhead
    
    def test_threshold_impact_on_performance(self, random_points_small):
        """Test how threshold affects computation time."""
        thresholds = [0.5, 1.0, 2.0, float('inf')]
        times = {}
        
        for thresh in thresholds:
            start_time = time.time()
            
            result = compute_ripser_advanced(
                random_points_small,
                maxdim=1,
                thresh=thresh,
                mode="fast"
            )
            
            elapsed_time = time.time() - start_time
            times[thresh] = elapsed_time
            
            assert 'dgms' in result
        
        print(f"Threshold performance impact: {times}")
        # Generally, larger thresholds take longer (more simplices to consider)
    
    def test_dimension_impact_on_performance(self, random_points_small):
        """Test how maxdim affects computation time."""
        dimensions = [0, 1, 2]
        times = {}
        
        for maxdim in dimensions:
            start_time = time.time()
            
            result = compute_ripser_advanced(
                random_points_small,
                maxdim=maxdim,
                thresh=1.5,
                mode="fast"
            )
            
            elapsed_time = time.time() - start_time
            times[maxdim] = elapsed_time
            
            assert 'dgms' in result
            assert len(result['dgms']) == maxdim + 1
        
        print(f"Dimension performance impact: {times}")
        # Higher dimensions should generally take longer
    
    def test_dataset_size_scaling(self):
        """Test how computation time scales with dataset size."""
        np.random.seed(42)
        sizes = [10, 20, 30, 40]
        times = {}
        
        for size in sizes:
            points = np.random.randn(size, 2)
            
            start_time = time.time()
            
            result = compute_ripser_advanced(
                points,
                maxdim=1,
                thresh=1.0,
                mode="fast"
            )
            
            elapsed_time = time.time() - start_time
            times[size] = elapsed_time
            
            assert 'dgms' in result
        
        print(f"Size scaling: {times}")
        
        # Verify that computation completes for all sizes
        for size, t in times.items():
            assert t < 20.0  # Should complete within reasonable time


class TestMemoryUsage:
    """Test memory usage and optimization."""
    
    def test_low_memory_mode_functionality(self, random_points_medium):
        """Test that low memory mode produces valid results."""
        result = compute_ripser_advanced(
            random_points_medium,
            maxdim=1,
            thresh=1.0,
            mode="low_memory"
        )
        
        assert 'dgms' in result
        assert len(result['dgms']) >= 1
        
        # Should handle larger datasets without memory errors
        # (This is more of a functional test since memory measurement is complex)
    
    def test_memory_consistent_results(self, random_points_small):
        """Test that low memory mode gives consistent results."""
        # Regular computation
        result_regular = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=1.0,
            mode="balanced"
        )
        
        # Low memory computation
        result_low_mem = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=1.0,
            mode="low_memory"
        )
        
        # Both should succeed
        assert 'dgms' in result_regular
        assert 'dgms' in result_low_mem
        
        # Results should be structurally similar for small datasets
        assert len(result_regular['dgms']) == len(result_low_mem['dgms'])


class TestStressTests:
    """Stress tests for robustness."""
    
    def test_large_threshold_handling(self, random_points_small):
        """Test handling of very large thresholds."""
        result = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=1e6,  # Very large threshold
            mode="fast"
        )
        
        assert 'dgms' in result
        # Should complete without errors
    
    def test_many_identical_points(self):
        """Test handling of datasets with many identical points."""
        # Create dataset with many identical points
        points = np.array([[0.0, 0.0]] * 10 + [[1.0, 1.0]] * 10)
        
        result = compute_ripser_advanced(
            points,
            maxdim=1,
            thresh=2.0,
            mode="balanced"
        )
        
        assert 'dgms' in result
        # Should handle gracefully without crashes
    
    def test_high_dimensional_ambient_space(self):
        """Test computation in high-dimensional ambient space."""
        np.random.seed(42)
        # 20 points in 10D space
        points = np.random.randn(20, 10)
        
        result = compute_ripser_advanced(
            points,
            maxdim=1,
            thresh=2.0,
            mode="fast"
        )
        
        assert 'dgms' in result
        # Should complete without memory issues
    
    def test_zero_distance_points(self):
        """Test handling of points with zero distance."""
        points = np.array([
            [0.0, 0.0],
            [0.0, 0.0],  # Identical point
            [1.0, 1.0]
        ])
        
        result = compute_ripser_advanced(
            points,
            maxdim=1,
            thresh=2.0,
            mode="accurate"
        )
        
        assert 'dgms' in result
        # Should handle zero distances gracefully


@pytest.mark.slow
class TestLargeScaleBenchmarks:
    """Large scale performance benchmarks (marked as slow)."""
    
    def test_medium_dataset_performance(self):
        """Benchmark on medium-sized dataset."""
        np.random.seed(42)
        points = np.random.randn(100, 3)
        
        start_time = time.time()
        
        result = compute_ripser_advanced(
            points,
            maxdim=1,
            thresh=1.5,
            mode="fast"
        )
        
        elapsed_time = time.time() - start_time
        
        assert 'dgms' in result
        assert elapsed_time < 60.0  # Should complete within 1 minute
        
        print(f"100 points, 3D: {elapsed_time:.4f}s")
    
    def test_high_dimensional_performance(self):
        """Benchmark on high-dimensional dataset."""
        np.random.seed(42)
        points = np.random.randn(50, 5)
        
        start_time = time.time()
        
        result = compute_ripser_advanced(
            points,
            maxdim=1,
            thresh=1.0,
            mode="fast"
        )
        
        elapsed_time = time.time() - start_time
        
        assert 'dgms' in result
        assert elapsed_time < 30.0
        
        print(f"50 points, 5D: {elapsed_time:.4f}s")