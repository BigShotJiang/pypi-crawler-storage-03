import pytest
import numpy as np


@pytest.fixture
def simple_triangle():
    """Simple equilateral triangle point cloud."""
    return np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [0.5, 0.866]
    ])


@pytest.fixture
def simple_square():
    """Simple square point cloud."""
    return np.array([
        [0.0, 0.0],
        [1.0, 0.0],
        [1.0, 1.0],
        [0.0, 1.0]
    ])


@pytest.fixture
def random_points_small():
    """Small random point cloud for testing."""
    np.random.seed(42)
    return np.random.randn(20, 3)


@pytest.fixture
def random_points_medium():
    """Medium random point cloud for testing."""
    np.random.seed(42)
    return np.random.randn(50, 3)


@pytest.fixture
def circle_points():
    """Points arranged in a circle."""
    n_points = 20
    angles = np.linspace(0, 2 * np.pi, n_points, endpoint=False)
    return np.column_stack([np.cos(angles), np.sin(angles)])


@pytest.fixture
def torus_points():
    """Points sampled from a torus."""
    np.random.seed(42)
    n_points = 100
    u = np.random.uniform(0, 2*np.pi, n_points)
    v = np.random.uniform(0, 2*np.pi, n_points)
    
    R, r = 2.0, 1.0  # Major and minor radius
    x = (R + r * np.cos(v)) * np.cos(u)
    y = (R + r * np.cos(v)) * np.sin(u)
    z = r * np.sin(v)
    
    return np.column_stack([x, y, z])


@pytest.fixture
def precomputed_distance_matrix():
    """Simple precomputed distance matrix."""
    return np.array([
        [0.0, 1.0, 2.0],
        [1.0, 0.0, 1.5],
        [2.0, 1.5, 0.0]
    ])