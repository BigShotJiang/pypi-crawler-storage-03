#!/usr/bin/env python3
"""
Test script for cocycles functionality in rust-ripser
"""

import numpy as np
import sys
import os

# Add the python package to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'python'))

try:
    from rust_ripser import compute_ripser_with_cocycles
    print("✅ Successfully imported compute_ripser_with_cocycles")
except ImportError as e:
    print(f"❌ Failed to import compute_ripser_with_cocycles: {e}")
    sys.exit(1)

def test_cocycles_basic():
    """Test basic cocycles computation"""
    print("\n🧪 Testing basic cocycles computation...")
    
    # Create a simple 4-point dataset that should have some H1
    points = np.array([
        [0.0, 0.0],
        [1.0, 0.0], 
        [1.0, 1.0],
        [0.0, 1.0]
    ])
    
    try:
        # Test without cocycles
        result_no_cocycles = compute_ripser_with_cocycles(
            points, maxdim=1, thresh=2.0, metric="euclidean", cocycles=False
        )
        print(f"✅ Without cocycles: {len(result_no_cocycles['dgms'])} dimensions computed")
        print(f"   H0 intervals: {len(result_no_cocycles['dgms'][0])}")
        print(f"   H1 intervals: {len(result_no_cocycles['dgms'][1])}")
        print(f"   Number of edges: {result_no_cocycles['num_edges']}")
        
        # Test with cocycles
        result_with_cocycles = compute_ripser_with_cocycles(
            points, maxdim=1, thresh=2.0, metric="euclidean", cocycles=True
        )
        print(f"✅ With cocycles: {len(result_with_cocycles['dgms'])} dimensions computed")
        
        if 'cocycles' in result_with_cocycles:
            print(f"   Cocycles computed for dimensions: {list(result_with_cocycles['cocycles'].keys())}")
            if '1' in result_with_cocycles['cocycles']:
                print(f"   H1 cocycles count: {len(result_with_cocycles['cocycles']['1'])}")
                for i, cocycle in enumerate(result_with_cocycles['cocycles']['1']):
                    print(f"   H1 cocycle {i}: representatives = {cocycle}")
        else:
            print("   No cocycles in result")
            
        return True
        
    except Exception as e:
        print(f"❌ Error during cocycles computation: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_cocycles_circle():
    """Test cocycles on a circle (should have 1 H1 interval)"""
    print("\n🧪 Testing cocycles on circle data...")
    
    # Create points on a circle
    n_points = 8
    theta = np.linspace(0, 2*np.pi, n_points, endpoint=False)
    points = np.column_stack([np.cos(theta), np.sin(theta)])
    
    try:
        result = compute_ripser_with_cocycles(
            points, maxdim=1, thresh=1.5, metric="euclidean", cocycles=True
        )
        
        print(f"✅ Circle test completed")
        print(f"   H0 intervals: {len(result['dgms'][0])}")
        print(f"   H1 intervals: {len(result['dgms'][1])}")
        
        if 'cocycles' in result and '1' in result['cocycles']:
            print(f"   H1 cocycles: {len(result['cocycles']['1'])}")
            print(f"   Number of edges: {result['num_edges']}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error during circle cocycles test: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("🚀 Testing Rust-Ripser Cocycles Functionality")
    print("=" * 50)
    
    success_count = 0
    total_tests = 2
    
    # Run tests
    if test_cocycles_basic():
        success_count += 1
        
    if test_cocycles_circle():
        success_count += 1
    
    # Summary
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {success_count}/{total_tests} tests passed")
    
    if success_count == total_tests:
        print("🎉 All cocycles tests passed!")
        return 0
    else:
        print("⚠️  Some cocycles tests failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())