#!/usr/bin/env python3
"""
H2 Accuracy testing for rust-ripser
Detailed comparison between original and optimized H2 implementations
"""

import numpy as np
import sys
import os

# Add the python package to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'python'))

def create_simple_test_data():
    """Create simple test data with known topology"""
    # 4 points forming a tetrahedron - should have clear H0, H1, H2 structure
    points = np.array([
        [0.0, 0.0, 0.0],
        [1.0, 0.0, 0.0], 
        [0.5, np.sqrt(3)/2, 0.0],
        [0.5, np.sqrt(3)/6, np.sqrt(6)/3]
    ])
    return points

def create_circle_data():
    """Create points on a circle - should have H1 but no H2"""
    n_points = 8
    theta = np.linspace(0, 2*np.pi, n_points, endpoint=False)
    points = np.column_stack([np.cos(theta), np.sin(theta), np.zeros(n_points)])
    return points

def detailed_comparison(result1, result2, name1, name2):
    """Detailed comparison of two results"""
    print(f"\n🔍 Detailed Comparison: {name1} vs {name2}")
    print("=" * 60)
    
    try:
        dgms1 = result1['dgms']
        dgms2 = result2['dgms']
        
        for dim in range(max(len(dgms1), len(dgms2))):
            print(f"\n📊 H{dim} Analysis:")
            
            intervals1 = dgms1[dim] if dim < len(dgms1) else []
            intervals2 = dgms2[dim] if dim < len(dgms2) else []
            
            print(f"   {name1}: {len(intervals1)} intervals")
            print(f"   {name2}: {len(intervals2)} intervals")
            
            if len(intervals1) > 0:
                print(f"   {name1} intervals:")
                for i, interval in enumerate(intervals1[:5]):  # Show first 5
                    print(f"      [{i}]: ({interval[0]:.6f}, {interval[1]:.6f})")
                if len(intervals1) > 5:
                    print(f"      ... and {len(intervals1) - 5} more")
            
            if len(intervals2) > 0:
                print(f"   {name2} intervals:")
                for i, interval in enumerate(intervals2[:5]):  # Show first 5
                    print(f"      [{i}]: ({interval[0]:.6f}, {interval[1]:.6f})")
                if len(intervals2) > 5:
                    print(f"      ... and {len(intervals2) - 5} more")
            
            # Check for exact matches
            if len(intervals1) == len(intervals2) and len(intervals1) > 0:
                intervals1_array = np.array(intervals1)
                intervals2_array = np.array(intervals2)
                
                # Sort both by birth time for comparison
                sort1 = np.argsort(intervals1_array[:, 0])
                sort2 = np.argsort(intervals2_array[:, 0])
                
                sorted1 = intervals1_array[sort1]
                sorted2 = intervals2_array[sort2]
                
                diff = np.abs(sorted1 - sorted2)
                max_diff = np.max(diff)
                print(f"   Maximum difference: {max_diff:.10f}")
                
                if max_diff < 1e-10:
                    print(f"   ✅ H{dim} intervals match perfectly!")
                elif max_diff < 1e-6:
                    print(f"   ⚠️  H{dim} intervals match within tolerance")
                else:
                    print(f"   ❌ H{dim} intervals differ significantly")
            else:
                print(f"   ❌ H{dim} interval counts don't match")
        
        # Print additional statistics
        print(f"\n📈 Additional Statistics:")
        
        if 'optimized_h2' in result2:
            print(f"   {name2} is using H2 optimization")
        if 'n_triangles' in result2:
            print(f"   {name2} triangles: {result2['n_triangles']}")
        if 'n_edges' in result2:
            print(f"   {name2} edges: {result2['n_edges']}")
            
    except Exception as e:
        print(f"❌ Error in detailed comparison: {e}")
        import traceback
        traceback.print_exc()

def test_simple_case():
    """Test simple tetrahedron case"""
    print("\n🧪 Testing Simple Tetrahedron Case")
    print("-" * 40)
    
    try:
        from rust_ripser import rust_ripser, compute_ripser_h2_optimized
        
        points = create_simple_test_data()
        print(f"Test data: {points.shape[0]} points (tetrahedron)")
        
        # Test with moderate threshold
        thresh = 2.0
        
        # Original implementation
        print("\n⏱️ Running original implementation...")
        result_orig = rust_ripser(points, maxdim=2, thresh=thresh, metric="euclidean")
        
        # H2 optimized implementation  
        print("⏱️ Running H2 optimized implementation...")
        result_h2_opt = compute_ripser_h2_optimized(points, thresh=thresh, metric="euclidean")
        
        # Compare results
        detailed_comparison(result_orig, result_h2_opt, "Original", "H2 Optimized")
        
        return True
        
    except Exception as e:
        print(f"❌ Simple case test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_circle_case():
    """Test circle case - should have H1 but no H2"""
    print("\n🧪 Testing Circle Case")
    print("-" * 40)
    
    try:
        from rust_ripser import rust_ripser, compute_ripser_h2_optimized
        
        points = create_circle_data()
        print(f"Test data: {points.shape[0]} points (circle)")
        
        # Test with threshold that includes all edges
        thresh = 3.0
        
        # Original implementation
        print("\n⏱️ Running original implementation...")
        result_orig = rust_ripser(points, maxdim=2, thresh=thresh, metric="euclidean")
        
        # H2 optimized implementation
        print("⏱️ Running H2 optimized implementation...")
        result_h2_opt = compute_ripser_h2_optimized(points, thresh=thresh, metric="euclidean")
        
        # Compare results
        detailed_comparison(result_orig, result_h2_opt, "Original", "H2 Optimized")
        
        return True
        
    except Exception as e:
        print(f"❌ Circle case test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def diagnose_h2_implementation():
    """Diagnose issues with H2 implementation"""
    print("\n🔬 H2 Implementation Diagnosis")
    print("=" * 50)
    
    try:
        from rust_ripser import compute_ripser_h2_optimized
        
        # Test very simple case - 4 points
        points = create_simple_test_data()
        result = compute_ripser_h2_optimized(points, thresh=2.0, metric="euclidean")
        
        print(f"H2 Optimized Result Structure:")
        for key, value in result.items():
            if key == 'dgms':
                print(f"   {key}: {len(value)} dimensions")
                for i, dgm in enumerate(value):
                    print(f"      H{i}: {len(dgm)} intervals")
            else:
                print(f"   {key}: {value}")
        
        # Check if the results make sense
        dgms = result['dgms']
        
        # For 4 points, we expect:
        # H0: 3 death events (4 components -> 1 component)
        # H1: Depends on triangle structure
        # H2: Usually 0 for simple cases
        
        h0_count = len(dgms[0]) if len(dgms) > 0 else 0
        h1_count = len(dgms[1]) if len(dgms) > 1 else 0
        h2_count = len(dgms[2]) if len(dgms) > 2 else 0
        
        print(f"\nTopological Analysis:")
        print(f"   H0 intervals: {h0_count} (expected: 3 for 4 points)")
        print(f"   H1 intervals: {h1_count}")
        print(f"   H2 intervals: {h2_count}")
        
        if 'n_triangles' in result:
            print(f"   Triangles generated: {result['n_triangles']}")
        if 'n_edges' in result:
            print(f"   Edges generated: {result['n_edges']}")
            
        # Basic sanity checks
        if h0_count != 3:
            print("   ⚠️ H0 count unexpected for 4 points")
        
        if 'n_triangles' in result and result['n_triangles'] > 4:
            print("   ⚠️ Too many triangles for 4 points (max should be 4)")
            
        return True
        
    except Exception as e:
        print(f"❌ H2 diagnosis failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("🔍 Rust-Ripser H2 Accuracy Testing")
    print("=" * 60)
    
    success_count = 0
    total_tests = 3
    
    # Run tests
    if test_simple_case():
        success_count += 1
        
    if test_circle_case():
        success_count += 1
        
    if diagnose_h2_implementation():
        success_count += 1
    
    # Summary
    print(f"\n" + "=" * 60)
    print(f"📊 Accuracy Test Results: {success_count}/{total_tests} tests completed")
    
    if success_count == total_tests:
        print("✅ All H2 accuracy tests completed successfully")
        print("🔍 Check detailed output above to assess correctness")
        return 0
    else:
        print("⚠️ Some H2 accuracy tests failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())