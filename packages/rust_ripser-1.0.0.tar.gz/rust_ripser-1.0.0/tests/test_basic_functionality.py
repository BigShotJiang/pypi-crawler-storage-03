import pytest
import numpy as np
from rust_ripser import compute_ripser_advanced, compute_ripser, compute_ripser_optimized


class TestBasicFunctionality:
    """Test basic persistent homology computation functionality."""
    
    def test_simple_triangle_h0_h1(self, simple_triangle):
        """Test persistence computation on a simple triangle."""
        result = compute_ripser_advanced(
            simple_triangle, 
            maxdim=1, 
            thresh=2.0,
            mode="accurate"
        )
        
        assert 'dgms' in result
        assert len(result['dgms']) == 2  # H0 and H1
        assert 'computation_time' in result
        assert 'n_points' in result
        
        # Triangle should have some H0 intervals (components merging)
        h0_intervals = result['dgms'][0]
        assert len(h0_intervals) >= 2  # At least 2 death events
        
        # Triangle should form a cycle (H1 interval)
        h1_intervals = result['dgms'][1]
        assert len(h1_intervals) >= 1
    
    def test_simple_square_h0_h1(self, simple_square):
        """Test persistence computation on a simple square."""
        result = compute_ripser_advanced(
            simple_square, 
            maxdim=1, 
            thresh=2.0,
            mode="accurate"
        )
        
        assert 'dgms' in result
        assert len(result['dgms']) == 2
        
        # Square should have H1 features (loop)
        h1_intervals = result['dgms'][1]
        assert len(h1_intervals) >= 1
    
    def test_different_computation_modes(self, random_points_small):
        """Test that different computation modes produce valid results."""
        modes = ["accurate", "balanced", "fast", "parallel"]
        
        results = {}
        for mode in modes:
            result = compute_ripser_advanced(
                random_points_small,
                maxdim=1,
                thresh=1.5,
                mode=mode
            )
            results[mode] = result
            
            # Basic structure checks
            assert 'dgms' in result
            assert len(result['dgms']) == 2
            assert 'computation_time' in result
            assert result['mode_used'] in ["Accurate", "Balanced", "Fast", "Parallel"]
    
    def test_threshold_parameter(self, simple_square):
        """Test that threshold parameter affects results."""
        thresholds = [0.5, 1.0, 1.5, 2.0]
        h1_counts = []
        
        for thresh in thresholds:
            result = compute_ripser_advanced(
                simple_square,
                maxdim=1,
                thresh=thresh,
                mode="accurate"
            )
            h1_count = len(result['dgms'][1])
            h1_counts.append(h1_count)
        
        # Generally, larger thresholds should not decrease interval count
        # (monotonicity property of persistent homology)
        for i in range(1, len(h1_counts)):
            assert h1_counts[i] >= h1_counts[i-1]
    
    def test_maxdim_parameter(self, simple_triangle):
        """Test maxdim parameter controls output dimensions."""
        # Test maxdim=0
        result_0 = compute_ripser_advanced(
            simple_triangle,
            maxdim=0,
            mode="accurate"
        )
        assert len(result_0['dgms']) == 1  # Only H0
        
        # Test maxdim=1
        result_1 = compute_ripser_advanced(
            simple_triangle,
            maxdim=1,
            mode="accurate"
        )
        assert len(result_1['dgms']) == 2  # H0 and H1
        
        # Test maxdim=2
        result_2 = compute_ripser_advanced(
            simple_triangle,
            maxdim=2,
            mode="accurate"
        )
        assert len(result_2['dgms']) == 3  # H0, H1, and H2


class TestDistanceMetrics:
    """Test different distance metrics."""
    
    def test_euclidean_distance(self, simple_triangle):
        """Test euclidean distance metric."""
        result = compute_ripser_advanced(
            simple_triangle,
            maxdim=1,
            metric="euclidean",
            mode="accurate"
        )
        assert 'dgms' in result
    
    def test_manhattan_distance(self, simple_triangle):
        """Test manhattan distance metric."""
        result = compute_ripser_advanced(
            simple_triangle,
            maxdim=1,
            metric="manhattan",
            mode="accurate"
        )
        assert 'dgms' in result
    
    def test_cosine_distance(self, simple_triangle):
        """Test cosine distance metric."""
        result = compute_ripser_advanced(
            simple_triangle,
            maxdim=1,
            metric="cosine",
            mode="accurate"
        )
        assert 'dgms' in result
    
    def test_precomputed_distance_matrix(self, precomputed_distance_matrix):
        """Test precomputed distance matrix."""
        result = compute_ripser_advanced(
            precomputed_distance_matrix,
            maxdim=1,
            metric="precomputed",
            mode="accurate"
        )
        assert 'dgms' in result
        assert len(result['dgms']) == 2
    
    def test_minkowski_distance_custom_p(self, simple_square):
        """Test minkowski distance with custom p parameter."""
        result = compute_ripser_advanced(
            simple_square,
            maxdim=1,
            metric="minkowski(1.5)",
            mode="accurate"
        )
        assert 'dgms' in result


class TestCocycles:
    """Test cocycle computation functionality."""
    
    def test_cocycles_basic(self, simple_square):
        """Test basic cocycle computation."""
        result = compute_ripser_advanced(
            simple_square,
            maxdim=1,
            cocycles=True,
            mode="accurate"
        )
        
        assert 'cocycles' in result
        # Should have cocycles for dimension 1 if there are H1 intervals
        if len(result['dgms'][1]) > 0:
            assert '1' in result['cocycles']
    
    def test_cocycles_circle(self, circle_points):
        """Test cocycle computation on circle (should have clear H1)."""
        result = compute_ripser_advanced(
            circle_points,
            maxdim=1,
            thresh=0.5,  # Reasonable threshold for circle
            cocycles=True,
            mode="accurate"
        )
        
        assert 'cocycles' in result
        # Circle should have H1 intervals and corresponding cocycles
        if len(result['dgms'][1]) > 0:
            assert '1' in result['cocycles']
            assert len(result['cocycles']['1']) > 0


class TestParallelComputation:
    """Test parallel computation features."""
    
    def test_parallel_mode(self, random_points_medium):
        """Test parallel computation mode."""
        result = compute_ripser_advanced(
            random_points_medium,
            maxdim=1,
            mode="parallel",
            num_threads=2
        )
        
        assert 'dgms' in result
        assert result['mode_used'] in ["Parallel", "Balanced"]  # May fall back
    
    def test_parallel_vs_serial_consistency(self, random_points_small):
        """Test that parallel and serial modes give consistent results."""
        # Serial computation
        result_serial = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=1.0,
            mode="accurate"
        )
        
        # Parallel computation
        result_parallel = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=1.0,
            mode="parallel",
            num_threads=2
        )
        
        # Results should be structurally similar
        assert len(result_serial['dgms']) == len(result_parallel['dgms'])
        
        # H0 intervals should be identical (or very close)
        h0_serial = result_serial['dgms'][0]
        h0_parallel = result_parallel['dgms'][0]
        assert len(h0_serial) == len(h0_parallel)


class TestMemoryOptimization:
    """Test memory optimization features."""
    
    def test_low_memory_mode(self, random_points_medium):
        """Test low memory computation mode."""
        result = compute_ripser_advanced(
            random_points_medium,
            maxdim=1,
            thresh=1.0,
            mode="low_memory"
        )
        
        assert 'dgms' in result
        # Low memory mode should still produce valid results
        assert len(result['dgms']) >= 1


class TestLegacyAPI:
    """Test legacy API functions for backward compatibility."""
    
    def test_compute_ripser_basic(self, simple_triangle):
        """Test legacy compute_ripser function."""
        result = compute_ripser(
            simple_triangle,
            maxdim=1,
            thresh=2.0
        )
        
        assert 'dgms' in result
        assert 'rust_powered' in result
    
    def test_compute_ripser_optimized(self, simple_square):
        """Test optimized H1 computation."""
        result = compute_ripser_optimized(
            simple_square,
            thresh=2.0
        )
        
        assert 'dgms' in result
        assert 'optimized' in result
        assert result['maxdim'] == 1


class TestErrorHandling:
    """Test error handling and edge cases."""
    
    def test_empty_input(self):
        """Test handling of empty input."""
        with pytest.raises(Exception):
            compute_ripser_advanced(np.array([]), maxdim=1)
    
    def test_single_point(self):
        """Test handling of single point."""
        single_point = np.array([[0.0, 0.0]])
        result = compute_ripser_advanced(single_point, maxdim=1)
        
        # Should handle gracefully
        assert 'dgms' in result
        # H0 should be empty (no death events)
        assert len(result['dgms'][0]) == 0
        # H1 should be empty (no cycles possible)
        assert len(result['dgms'][1]) == 0
    
    def test_invalid_metric(self, simple_triangle):
        """Test handling of invalid distance metric."""
        with pytest.raises(Exception):
            compute_ripser_advanced(
                simple_triangle,
                metric="invalid_metric"
            )
    
    def test_negative_threshold(self, simple_triangle):
        """Test handling of negative threshold."""
        # Should handle gracefully or raise appropriate error
        try:
            result = compute_ripser_advanced(
                simple_triangle,
                thresh=-1.0
            )
            # If it succeeds, should return empty or minimal results
            assert 'dgms' in result
        except Exception:
            # It's also acceptable to raise an error for negative threshold
            pass