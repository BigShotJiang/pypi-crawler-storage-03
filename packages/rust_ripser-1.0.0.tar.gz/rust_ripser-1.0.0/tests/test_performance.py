#!/usr/bin/env python3
"""
Performance benchmarking for rust-ripser optimizations
Compare original vs optimized implementations
"""

import numpy as np
import sys
import os
import time

# Add the python package to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'python'))

def generate_test_data(n_points=80, seed=42):
    """Generate test data similar to TODO_STATUS.md benchmark"""
    np.random.seed(seed)
    return np.random.randn(n_points, 2)

def benchmark_function(func, data, name, **kwargs):
    """Benchmark a function with multiple runs"""
    times = []
    results = []
    
    # Warm up
    try:
        result = func(data, **kwargs)
        results.append(result)
    except Exception as e:
        print(f"❌ {name} failed: {e}")
        return None, None
    
    # Benchmark runs
    n_runs = 10
    for _ in range(n_runs):
        start_time = time.perf_counter()
        try:
            result = func(data, **kwargs)
            end_time = time.perf_counter()
            times.append(end_time - start_time)
            results.append(result)
        except Exception as e:
            print(f"❌ {name} run failed: {e}")
            return None, None
    
    avg_time = np.mean(times)
    min_time = np.min(times)
    std_time = np.std(times)
    
    print(f"✅ {name}")
    print(f"   Average: {avg_time:.6f}s")
    print(f"   Best:    {min_time:.6f}s") 
    print(f"   Std dev: {std_time:.6f}s")
    
    return results[0], min_time

def compare_results(result1, result2, name1, name2):
    """Compare results between two implementations"""
    print(f"\n🔍 Comparing {name1} vs {name2}:")
    
    try:
        dgms1 = result1['dgms']
        dgms2 = result2['dgms']
        
        for dim in range(len(dgms1)):
            intervals1 = dgms1[dim]
            intervals2 = dgms2[dim]
            
            print(f"   H{dim}: {len(intervals1)} vs {len(intervals2)} intervals")
            
            if len(intervals1) != len(intervals2):
                print(f"   ⚠️  Different number of H{dim} intervals!")
                return False
                
            # Check if intervals are approximately equal
            if len(intervals1) > 0:
                diff = np.abs(np.array(intervals1) - np.array(intervals2))
                max_diff = np.max(diff)
                print(f"   Max difference: {max_diff:.10f}")
                
                if max_diff > 1e-10:
                    print(f"   ⚠️  Large difference in H{dim} intervals!")
                    return False
        
        print("   ✅ Results match!")
        return True
        
    except Exception as e:
        print(f"   ❌ Error comparing results: {e}")
        return False

def main():
    print("🚀 Rust-Ripser Performance Benchmarking")
    print("=" * 60)
    
    # Import functions
    try:
        from rust_ripser import rust_ripser, compute_ripser_optimized
        print("✅ Successfully imported rust-ripser functions")
    except ImportError as e:
        print(f"❌ Failed to import: {e}")
        return 1
    
    # Generate test data (80 points as in TODO_STATUS.md)
    print(f"\n📊 Generating test data (80 points, 2D)...")
    points = generate_test_data(80)
    print(f"   Data shape: {points.shape}")
    
    # Benchmark parameters
    maxdim = 1
    thresh = 2.0
    metric = "euclidean"
    
    print(f"   Parameters: maxdim={maxdim}, thresh={thresh}, metric={metric}")
    
    # Benchmark original implementation
    print(f"\n⏱️  Benchmarking original implementation...")
    original_result, original_time = benchmark_function(
        rust_ripser, points, "Original rust-ripser", 
        maxdim=maxdim, thresh=thresh, metric=metric
    )
    
    if original_result is None:
        print("❌ Original implementation failed")
        return 1
    
    # Benchmark optimized implementation
    print(f"\n⏱️  Benchmarking optimized implementation...")
    optimized_result, optimized_time = benchmark_function(
        compute_ripser_optimized, points, "Optimized rust-ripser",
        thresh=thresh, metric=metric
    )
    
    if optimized_result is None:
        print("❌ Optimized implementation failed")
        return 1
    
    # Compare results
    match = compare_results(original_result, optimized_result, "Original", "Optimized")
    
    # Performance summary
    print(f"\n📈 Performance Summary:")
    print(f"   Original:  {original_time:.6f}s")
    print(f"   Optimized: {optimized_time:.6f}s")
    
    if optimized_time < original_time:
        speedup = original_time / optimized_time
        print(f"   🚀 Speedup: {speedup:.2f}x faster!")
    else:
        slowdown = optimized_time / original_time
        print(f"   🐌 Slowdown: {slowdown:.2f}x slower")
    
    # Target comparison (ripser: 0.0008s)
    ripser_target = 0.0008
    print(f"\n🎯 Compared to ripser target ({ripser_target}s):")
    print(f"   Original:  {original_time/ripser_target:.1f}x slower than target")
    print(f"   Optimized: {optimized_time/ripser_target:.1f}x slower than target")
    
    if optimized_time <= ripser_target:
        print("   🎉 Optimized version meets or exceeds ripser target!")
    else:
        print(f"   📈 Still {optimized_time/ripser_target:.1f}x slower than target")
    
    # Final verdict
    print(f"\n" + "=" * 60)
    if match and optimized_time < original_time:
        print("✅ OPTIMIZATION SUCCESS: Faster with correct results!")
        return 0
    elif match:
        print("⚠️  OPTIMIZATION PARTIAL: Correct results but not faster")
        return 1
    else:
        print("❌ OPTIMIZATION FAILED: Incorrect results")
        return 1

if __name__ == "__main__":
    sys.exit(main())