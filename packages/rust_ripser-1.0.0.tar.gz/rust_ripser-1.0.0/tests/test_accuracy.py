import pytest
import numpy as np
from rust_ripser import compute_ripser_advanced, compute_ripser_optimized, compute_ripser_h2_optimized


class TestAccuracy:
    """Test accuracy and correctness of computations."""
    
    def test_deterministic_results(self, simple_triangle):
        """Test that results are deterministic across multiple runs."""
        results = []
        
        for _ in range(5):
            result = compute_ripser_advanced(
                simple_triangle,
                maxdim=1,
                thresh=2.0,
                mode="accurate"
            )
            results.append(result)
        
        # All results should be identical
        for i in range(1, len(results)):
            for dim in range(len(results[0]['dgms'])):
                dgm_0 = np.array(results[0]['dgms'][dim])
                dgm_i = np.array(results[i]['dgms'][dim])
                
                if len(dgm_0) > 0 and len(dgm_i) > 0:
                    np.testing.assert_array_almost_equal(dgm_0, dgm_i, decimal=10)
                else:
                    assert len(dgm_0) == len(dgm_i) == 0
    
    def test_mode_consistency(self, random_points_small):
        """Test that different modes produce consistent results."""
        # Use a fixed threshold to ensure comparable results
        threshold = 1.0
        
        # Compute with different modes
        result_accurate = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=threshold,
            mode="accurate"
        )
        
        result_balanced = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=threshold,
            mode="balanced"
        )
        
        result_fast = compute_ripser_advanced(
            random_points_small,
            maxdim=1,
            thresh=threshold,
            mode="fast"
        )
        
        # All should have same structure
        assert len(result_accurate['dgms']) == len(result_balanced['dgms']) == len(result_fast['dgms'])
        
        # H0 and H1 should be very similar (allowing for small numerical differences)
        for dim in [0, 1]:
            dgm_acc = np.array(result_accurate['dgms'][dim])
            dgm_bal = np.array(result_balanced['dgms'][dim])
            dgm_fast = np.array(result_fast['dgms'][dim])
            
            # Number of intervals should match
            assert len(dgm_acc) == len(dgm_bal)
            
            # For maxdim <= 2, fast mode should be identical to accurate
            if len(dgm_acc) > 0:
                np.testing.assert_array_almost_equal(dgm_acc, dgm_fast, decimal=8)
    
    def test_h1_optimization_accuracy(self, simple_square):
        """Test that H1 optimization produces accurate results."""
        # Standard computation
        result_standard = compute_ripser_advanced(
            simple_square,
            maxdim=1,
            thresh=2.0,
            mode="accurate"
        )
        
        # Optimized H1 computation
        result_optimized = compute_ripser_optimized(
            simple_square,
            thresh=2.0
        )
        
        # Should have same number of dimensions
        assert len(result_standard['dgms']) == len(result_optimized['dgms'])
        
        # H0 and H1 should match
        for dim in [0, 1]:
            dgm_std = np.array(result_standard['dgms'][dim])
            dgm_opt = np.array(result_optimized['dgms'][dim])
            
            assert len(dgm_std) == len(dgm_opt)
            
            if len(dgm_std) > 0:
                np.testing.assert_array_almost_equal(dgm_std, dgm_opt, decimal=10)
    
    def test_h2_optimization_accuracy(self, simple_triangle):
        """Test that H2 optimization produces accurate results."""
        # Standard computation
        result_standard = compute_ripser_advanced(
            simple_triangle,
            maxdim=2,
            thresh=2.0,
            mode="accurate"
        )
        
        # Optimized H2 computation
        result_optimized = compute_ripser_h2_optimized(
            simple_triangle,
            thresh=2.0
        )
        
        # Should have same number of dimensions
        assert len(result_standard['dgms']) == len(result_optimized['dgms'])
        
        # H0, H1, H2 should match
        for dim in [0, 1, 2]:
            dgm_std = np.array(result_standard['dgms'][dim])
            dgm_opt = np.array(result_optimized['dgms'][dim])
            
            assert len(dgm_std) == len(dgm_opt)
            
            if len(dgm_std) > 0:
                np.testing.assert_array_almost_equal(dgm_std, dgm_opt, decimal=10)
    
    def test_cocycles_accuracy(self, simple_square):
        """Test accuracy of cocycle computation."""
        result = compute_ripser_advanced(
            simple_square,
            maxdim=1,
            thresh=2.0,
            cocycles=True,
            mode="accurate"
        )
        
        assert 'cocycles' in result
        
        # If there are H1 intervals, there should be corresponding cocycles
        h1_intervals = result['dgms'][1]
        if len(h1_intervals) > 0:
            assert '1' in result['cocycles']
            h1_cocycles = result['cocycles']['1']
            
            # Number of cocycles should match number of H1 intervals
            assert len(h1_cocycles) == len(h1_intervals)
            
            # Each cocycle should be a valid representative
            for cocycle in h1_cocycles:
                assert len(cocycle) > 0  # Non-empty cocycle
                assert all(isinstance(x, (int, np.integer)) for x in cocycle[0])  # Integer indices
    
    def test_threshold_monotonicity(self, random_points_small):
        """Test monotonicity property: larger threshold should not decrease intervals."""
        thresholds = [0.5, 1.0, 1.5, 2.0]
        results = []
        
        for thresh in thresholds:
            result = compute_ripser_advanced(
                random_points_small,
                maxdim=1,
                thresh=thresh,
                mode="accurate"
            )
            results.append(result)
        
        # Check monotonicity for H1 (H0 intervals should also be monotonic)
        for i in range(1, len(results)):
            h1_prev = len(results[i-1]['dgms'][1])
            h1_curr = len(results[i]['dgms'][1])
            
            # Current threshold should have at least as many intervals
            assert h1_curr >= h1_prev, f"Monotonicity violated: thresh {thresholds[i]} has {h1_curr} intervals, but thresh {thresholds[i-1]} had {h1_prev}"
    
    def test_persistence_properties(self, simple_triangle):
        """Test mathematical properties of persistence diagrams."""
        result = compute_ripser_advanced(
            simple_triangle,
            maxdim=1,
            thresh=float('inf'),
            mode="accurate"
        )
        
        # Test basic properties
        for dim in range(len(result['dgms'])):
            intervals = np.array(result['dgms'][dim])
            
            if len(intervals) > 0:
                # Birth times should be <= death times
                births = intervals[:, 0]
                deaths = intervals[:, 1]
                assert np.all(births <= deaths), f"H{dim}: Birth > death in some intervals"
                
                # All times should be non-negative
                assert np.all(births >= 0), f"H{dim}: Negative birth times"
                assert np.all(deaths >= 0), f"H{dim}: Negative death times"
    
    def test_empty_result_consistency(self):
        """Test consistent handling of edge cases that produce empty results."""
        # Single point - should have no H1
        single_point = np.array([[0.0, 0.0]])
        result = compute_ripser_advanced(single_point, maxdim=1)
        
        assert len(result['dgms'][0]) == 0  # No H0 intervals (no death events)
        assert len(result['dgms'][1]) == 0  # No H1 intervals
        
        # Two points with large threshold - should have minimal structure
        two_points = np.array([[0.0, 0.0], [10.0, 10.0]])
        result = compute_ripser_advanced(two_points, maxdim=1, thresh=0.1)  # Small threshold
        
        assert len(result['dgms'][1]) == 0  # No H1 possible with small threshold
    
    def test_numerical_stability(self):
        """Test numerical stability with edge cases."""
        # Points with very small distances
        close_points = np.array([
            [0.0, 0.0],
            [1e-12, 1e-12],
            [1.0, 1.0]
        ])
        
        result = compute_ripser_advanced(
            close_points,
            maxdim=1,
            mode="accurate"
        )
        
        assert 'dgms' in result
        # Should handle very small distances without numerical issues
        
        # Points with very large coordinates
        large_points = np.array([
            [0.0, 0.0],
            [1e6, 1e6],
            [2e6, 0.0]
        ])
        
        result = compute_ripser_advanced(
            large_points,
            maxdim=1,
            mode="accurate"
        )
        
        assert 'dgms' in result
        # Should handle large coordinates without overflow
    
    def test_distance_metric_accuracy(self, simple_square):
        """Test that different distance metrics produce reasonable results."""
        metrics = ["euclidean", "manhattan", "chebyshev", "cosine"]
        
        for metric in metrics:
            result = compute_ripser_advanced(
                simple_square,
                maxdim=1,
                metric=metric,
                mode="accurate"
            )
            
            assert 'dgms' in result
            assert len(result['dgms']) == 2
            
            # Square should generally have some topological features regardless of metric
            # (though the exact persistence values will differ)
            total_intervals = sum(len(dgm) for dgm in result['dgms'])
            assert total_intervals > 0


class TestReferenceComparison:
    """Compare against known reference results."""
    
    def test_known_simple_cases(self):
        """Test against hand-computed simple cases."""
        # Equilateral triangle - should have one H1 interval
        triangle = np.array([
            [0.0, 0.0],
            [1.0, 0.0],
            [0.5, np.sqrt(3)/2]
        ])
        
        result = compute_ripser_advanced(
            triangle,
            maxdim=1,
            thresh=2.0,
            mode="accurate"
        )
        
        # Should have H1 interval (triangle forms a loop)
        h1_intervals = result['dgms'][1]
        assert len(h1_intervals) >= 1
        
        # Birth time should be at the formation of the triangle
        # (when the longest edge is added)
        triangle_birth = h1_intervals[0][0] if len(h1_intervals) > 0 else None
        if triangle_birth is not None:
            # Birth should be approximately the circumradius or similar
            assert triangle_birth > 0.5  # Should be > edge length
    
    def test_line_segment_points(self):
        """Test points arranged in a line (should have minimal H1)."""
        # Points on a line
        line_points = np.array([
            [0.0, 0.0],
            [1.0, 0.0],
            [2.0, 0.0],
            [3.0, 0.0]
        ])
        
        result = compute_ripser_advanced(
            line_points,
            maxdim=1,
            thresh=1.1,  # Just enough to connect adjacent points
            mode="accurate"
        )
        
        # Should have minimal H1 (no significant cycles)
        h1_intervals = result['dgms'][1]
        # Most intervals should be very short-lived (numerical artifacts)
        if len(h1_intervals) > 0:
            lifetimes = [death - birth for birth, death in h1_intervals]
            significant_intervals = [lt for lt in lifetimes if lt > 0.1]
            assert len(significant_intervals) == 0  # No significant cycles


class TestEdgeCaseAccuracy:
    """Test accuracy in edge cases and corner conditions."""
    
    def test_identical_points_handling(self):
        """Test accurate handling of identical points."""
        points_with_duplicates = np.array([
            [0.0, 0.0],
            [0.0, 0.0],  # Duplicate
            [1.0, 1.0],
            [1.0, 1.0],  # Duplicate
        ])
        
        result = compute_ripser_advanced(
            points_with_duplicates,
            maxdim=1,
            mode="accurate"
        )
        
        assert 'dgms' in result
        # Should handle duplicates gracefully without crashing
    
    def test_collinear_points_accuracy(self):
        """Test accuracy with collinear point configurations."""
        # Three collinear points
        collinear = np.array([
            [0.0, 0.0],
            [1.0, 1.0],
            [2.0, 2.0]
        ])
        
        result = compute_ripser_advanced(
            collinear,
            maxdim=1,
            mode="accurate"
        )
        
        # Should not produce spurious H1 intervals
        h1_intervals = result['dgms'][1]
        # Any H1 intervals should be very short-lived (numerical artifacts)
        if len(h1_intervals) > 0:
            lifetimes = [death - birth for birth, death in h1_intervals]
            max_lifetime = max(lifetimes)
            assert max_lifetime < 1e-10  # Should be essentially zero