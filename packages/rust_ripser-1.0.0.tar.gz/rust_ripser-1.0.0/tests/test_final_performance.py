#!/usr/bin/env python3
"""
Final performance testing for rust-ripser
Comprehensive test of all optimizations with accuracy verification
"""

import numpy as np
import sys
import os
import time

# Add the python package to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'python'))

def generate_test_datasets():
    """Generate various test datasets"""
    datasets = {}
    
    # Small dataset for accuracy verification
    np.random.seed(42)
    datasets['small_2d'] = np.random.randn(20, 2)
    
    # Medium dataset for performance testing  
    datasets['medium_3d'] = np.random.randn(40, 3)
    
    # Circle data for topology verification
    n_points = 16
    theta = np.linspace(0, 2*np.pi, n_points, endpoint=False)
    datasets['circle'] = np.column_stack([np.cos(theta), np.sin(theta)])
    
    return datasets

def count_intervals_by_lifetime(intervals, lifetime_threshold=1e-6):
    """Count intervals by lifetime to filter noise"""
    if len(intervals) == 0:
        return 0
    
    intervals_array = np.array(intervals)
    
    # Handle infinite intervals separately
    finite_mask = np.isfinite(intervals_array[:, 1])
    infinite_count = np.sum(~finite_mask)
    
    # Count finite intervals with significant lifetime
    if np.any(finite_mask):
        finite_intervals = intervals_array[finite_mask]
        lifetimes = finite_intervals[:, 1] - finite_intervals[:, 0]
        significant_count = np.sum(lifetimes > lifetime_threshold)
    else:
        significant_count = 0
    
    return significant_count + infinite_count

def compare_results_robust(result1, result2, name1, name2, tolerance=1e-8):
    """Robust comparison of results focusing on significant intervals"""
    print(f"\n🔍 Robust Comparison: {name1} vs {name2}")
    
    dgms1 = result1['dgms']
    dgms2 = result2['dgms']
    
    all_match = True
    
    for dim in range(max(len(dgms1), len(dgms2))):
        intervals1 = dgms1[dim] if dim < len(dgms1) else []
        intervals2 = dgms2[dim] if dim < len(dgms2) else []
        
        # Count significant intervals
        count1 = count_intervals_by_lifetime(intervals1)
        count2 = count_intervals_by_lifetime(intervals2)
        
        print(f"   H{dim}: {count1} vs {count2} significant intervals")
        
        if count1 != count2:
            print(f"   ⚠️  H{dim} significant interval counts differ")
            all_match = False
        elif len(intervals1) > 0 and len(intervals2) > 0:
            # Compare intervals numerically (excluding very short-lived ones)
            try:
                intervals1_array = np.array(intervals1)
                intervals2_array = np.array(intervals2)
                
                # Filter by lifetime for comparison
                finite1 = np.isfinite(intervals1_array[:, 1])
                finite2 = np.isfinite(intervals2_array[:, 1])
                
                if np.any(finite1) and np.any(finite2):
                    lifetimes1 = intervals1_array[finite1, 1] - intervals1_array[finite1, 0]
                    lifetimes2 = intervals2_array[finite2, 1] - intervals2_array[finite2, 0]
                    
                    significant1 = intervals1_array[finite1][lifetimes1 > 1e-6]
                    significant2 = intervals2_array[finite2][lifetimes2 > 1e-6]
                    
                    if len(significant1) == len(significant2) and len(significant1) > 0:
                        # Sort and compare
                        sorted1 = significant1[np.argsort(significant1[:, 0])]
                        sorted2 = significant2[np.argsort(significant2[:, 0])]
                        
                        diff = np.abs(sorted1 - sorted2)
                        max_diff = np.max(diff)
                        
                        if max_diff < tolerance:
                            print(f"   ✅ H{dim} significant intervals match (diff: {max_diff:.2e})")
                        else:
                            print(f"   ⚠️  H{dim} intervals differ (max diff: {max_diff:.2e})")
                            all_match = False
            except Exception as e:
                print(f"   ⚠️  H{dim} comparison failed: {e}")
                all_match = False
    
    return all_match

def benchmark_implementation(func, points, name, **kwargs):
    """Benchmark with multiple runs and error handling"""
    n_runs = 3
    times = []
    results = []
    
    for i in range(n_runs):
        try:
            start_time = time.perf_counter()
            result = func(points, **kwargs)
            end_time = time.perf_counter()
            
            times.append(end_time - start_time)
            results.append(result)
            
        except Exception as e:
            print(f"❌ {name} run {i+1} failed: {e}")
            return None, None
    
    avg_time = np.mean(times)
    min_time = np.min(times)
    
    print(f"✅ {name}: {min_time:.6f}s (avg: {avg_time:.6f}s)")
    
    return results[0], min_time

def test_implementation_suite():
    """Test all implementations comprehensively"""
    print("🚀 Comprehensive Rust-Ripser Performance & Accuracy Test")
    print("=" * 70)
    
    try:
        from rust_ripser import (
            rust_ripser, 
            compute_ripser_optimized, 
            compute_ripser_h2_optimized,
            compute_ripser_with_cocycles
        )
        print("✅ All implementations imported successfully")
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False
    
    datasets = generate_test_datasets()
    
    success_count = 0
    total_tests = 0
    
    for dataset_name, points in datasets.items():
        print(f"\n📊 Testing Dataset: {dataset_name} ({points.shape})")
        print("-" * 50)
        
        # Choose appropriate parameters for each dataset
        if 'circle' in dataset_name:
            maxdim, thresh = 1, 2.0
        elif '2d' in dataset_name:
            maxdim, thresh = 1, 3.0
        else:
            maxdim, thresh = 2, 2.0
        
        print(f"Parameters: maxdim={maxdim}, thresh={thresh}")
        
        # Test original implementation
        original_result, original_time = benchmark_implementation(
            rust_ripser, points, "Original",
            maxdim=maxdim, thresh=thresh, metric="euclidean"
        )
        
        if original_result is None:
            print(f"❌ Original failed on {dataset_name}")
            continue
        
        # Test appropriate optimized implementation
        if maxdim == 1:
            opt_result, opt_time = benchmark_implementation(
                compute_ripser_optimized, points, "H1 Optimized",
                thresh=thresh, metric="euclidean"
            )
        else:
            opt_result, opt_time = benchmark_implementation(
                compute_ripser_h2_optimized, points, "H2 Optimized", 
                thresh=thresh, metric="euclidean"
            )
        
        if opt_result is None:
            print(f"❌ Optimized failed on {dataset_name}")
            continue
        
        # Compare results
        match = compare_results_robust(
            original_result, opt_result, 
            "Original", "Optimized"
        )
        
        # Performance summary
        if original_time > 0 and opt_time > 0:
            speedup = original_time / opt_time
            print(f"\n📈 Performance: {speedup:.1f}x speedup")
            
            if speedup > 1.0:
                print(f"   🚀 Optimization successful!")
            else:
                print(f"   🐌 Optimization slower than original")
        
        total_tests += 1
        if match:
            success_count += 1
            print(f"   ✅ {dataset_name}: Results match!")
        else:
            print(f"   ⚠️  {dataset_name}: Results differ")
    
    # Test cocycles functionality
    print(f"\n🧪 Testing Cocycles Functionality")
    print("-" * 30)
    
    try:
        points = datasets['small_2d']
        cocycles_result, cocycles_time = benchmark_implementation(
            compute_ripser_with_cocycles, points, "Cocycles",
            maxdim=1, thresh=2.0, metric="euclidean", cocycles=True
        )
        
        if cocycles_result and 'cocycles' in cocycles_result:
            print("✅ Cocycles computation successful")
            success_count += 1
        else:
            print("❌ Cocycles computation failed")
        
        total_tests += 1
        
    except Exception as e:
        print(f"❌ Cocycles test failed: {e}")
        total_tests += 1
    
    # Final summary
    print(f"\n" + "=" * 70)
    print(f"📊 Final Results: {success_count}/{total_tests} tests passed")
    
    success_rate = success_count / total_tests if total_tests > 0 else 0
    
    if success_rate >= 0.8:
        print("🎉 COMPREHENSIVE TEST SUCCESS!")
        print("   All major optimizations working correctly")
        return True
    else:
        print("⚠️  Some tests failed - needs investigation")
        return False

def main():
    return 0 if test_implementation_suite() else 1

if __name__ == "__main__":
    sys.exit(main())