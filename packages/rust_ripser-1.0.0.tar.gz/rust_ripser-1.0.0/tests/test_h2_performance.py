#!/usr/bin/env python3
"""
H2 Performance benchmarking for rust-ripser optimizations
Compare maxdim=2 performance against ripser targets
"""

import numpy as np
import sys
import os
import time

# Add the python package to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'python'))

def generate_test_data_h2(n_points=50, seed=42):
    """Generate test data for H2 benchmarking"""
    np.random.seed(seed)
    # Generate points that might have some H2 structure
    # Create points on a sphere-like structure
    theta = np.random.uniform(0, 2*np.pi, n_points)
    phi = np.random.uniform(0, np.pi, n_points)
    
    x = np.sin(phi) * np.cos(theta)
    y = np.sin(phi) * np.sin(theta) 
    z = np.cos(phi)
    
    # Add some noise
    noise = np.random.normal(0, 0.1, (n_points, 3))
    
    return np.column_stack([x, y, z]) + noise

def benchmark_h2_function(func, data, name, **kwargs):
    """Benchmark a function for H2 computation"""
    times = []
    results = []
    
    # Warm up
    try:
        result = func(data, **kwargs)
        results.append(result)
    except Exception as e:
        print(f"❌ {name} failed: {e}")
        return None, None
    
    # Benchmark runs
    n_runs = 5  # Fewer runs for H2 since it's more expensive
    for _ in range(n_runs):
        start_time = time.perf_counter()
        try:
            result = func(data, **kwargs)
            end_time = time.perf_counter()
            times.append(end_time - start_time)
            results.append(result)
        except Exception as e:
            print(f"❌ {name} run failed: {e}")
            return None, None
    
    avg_time = np.mean(times)
    min_time = np.min(times)
    std_time = np.std(times)
    
    print(f"✅ {name}")
    print(f"   Average: {avg_time:.6f}s")
    print(f"   Best:    {min_time:.6f}s") 
    print(f"   Std dev: {std_time:.6f}s")
    
    return results[0], min_time

def analyze_h2_results(result, name):
    """Analyze H2 computation results"""
    print(f"\n📊 {name} Results:")
    
    try:
        dgms = result['dgms']
        
        for dim in range(len(dgms)):
            intervals = dgms[dim]
            print(f"   H{dim}: {len(intervals)} intervals")
            
            if len(intervals) > 0:
                intervals_array = np.array(intervals)
                lifetimes = intervals_array[:, 1] - intervals_array[:, 0]
                print(f"        Avg lifetime: {np.mean(lifetimes):.6f}")
                print(f"        Max lifetime: {np.max(lifetimes):.6f}")
        
        # Print additional stats if available
        if 'n_triangles' in result:
            print(f"   Triangles: {result['n_triangles']}")
        if 'n_edges' in result:
            print(f"   Edges: {result['n_edges']}")
            
    except Exception as e:
        print(f"   ❌ Error analyzing results: {e}")

def compare_h2_results(result1, result2, name1, name2):
    """Compare H2 results between implementations"""
    print(f"\n🔍 Comparing {name1} vs {name2}:")
    
    try:
        dgms1 = result1['dgms']
        dgms2 = result2['dgms']
        
        matches = True
        for dim in range(min(len(dgms1), len(dgms2))):
            intervals1 = dgms1[dim]
            intervals2 = dgms2[dim]
            
            print(f"   H{dim}: {len(intervals1)} vs {len(intervals2)} intervals")
            
            if len(intervals1) != len(intervals2):
                print(f"   ⚠️  Different number of H{dim} intervals!")
                matches = False
            elif len(intervals1) > 0:
                # Check if intervals are approximately equal
                diff = np.abs(np.array(intervals1) - np.array(intervals2))
                max_diff = np.max(diff)
                print(f"   Max difference: {max_diff:.10f}")
                
                if max_diff > 1e-8:
                    print(f"   ⚠️  Large difference in H{dim} intervals!")
                    matches = False
        
        if matches:
            print("   ✅ Results match!")
        
        return matches
        
    except Exception as e:
        print(f"   ❌ Error comparing results: {e}")
        return False

def main():
    print("🚀 Rust-Ripser H2 Performance Benchmarking")
    print("=" * 60)
    
    # Import functions
    try:
        from rust_ripser import rust_ripser, compute_ripser_h2_optimized
        print("✅ Successfully imported rust-ripser H2 functions")
    except ImportError as e:
        print(f"❌ Failed to import: {e}")
        return 1
    
    # Generate test data (50 points for H2)
    print(f"\n📊 Generating H2 test data (50 points, 3D)...")
    points = generate_test_data_h2(50)
    print(f"   Data shape: {points.shape}")
    
    # Benchmark parameters
    maxdim = 2
    thresh = 1.5
    metric = "euclidean"
    
    print(f"   Parameters: maxdim={maxdim}, thresh={thresh}, metric={metric}")
    
    # Benchmark original implementation
    print(f"\n⏱️  Benchmarking original implementation (maxdim=2)...")
    original_result, original_time = benchmark_h2_function(
        rust_ripser, points, "Original rust-ripser", 
        maxdim=maxdim, thresh=thresh, metric=metric
    )
    
    if original_result is None:
        print("❌ Original implementation failed")
        return 1
    
    analyze_h2_results(original_result, "Original")
    
    # Benchmark H2 optimized implementation
    print(f"\n⏱️  Benchmarking H2 optimized implementation...")
    h2_optimized_result, h2_optimized_time = benchmark_h2_function(
        compute_ripser_h2_optimized, points, "H2 Optimized rust-ripser",
        thresh=thresh, metric=metric
    )
    
    if h2_optimized_result is None:
        print("❌ H2 optimized implementation failed")
        return 1
    
    analyze_h2_results(h2_optimized_result, "H2 Optimized")
    
    # Compare results
    match = compare_h2_results(original_result, h2_optimized_result, "Original", "H2 Optimized")
    
    # Performance summary
    print(f"\n📈 H2 Performance Summary:")
    print(f"   Original:     {original_time:.6f}s")
    print(f"   H2 Optimized: {h2_optimized_time:.6f}s")
    
    if h2_optimized_time < original_time:
        speedup = original_time / h2_optimized_time
        print(f"   🚀 Speedup: {speedup:.2f}x faster!")
    else:
        slowdown = h2_optimized_time / original_time
        print(f"   🐌 Slowdown: {slowdown:.2f}x slower")
    
    # Target comparison (ripser H2: ~0.012s target)
    ripser_h2_target = 0.012
    print(f"\n🎯 Compared to ripser H2 target ({ripser_h2_target}s):")
    print(f"   Original:     {original_time/ripser_h2_target:.1f}x vs target")
    print(f"   H2 Optimized: {h2_optimized_time/ripser_h2_target:.1f}x vs target")
    
    if h2_optimized_time <= ripser_h2_target:
        print("   🎉 H2 optimized version meets or exceeds ripser target!")
    else:
        print(f"   📈 Still {h2_optimized_time/ripser_h2_target:.1f}x away from target")
    
    # Final verdict
    print(f"\n" + "=" * 60)
    if match and h2_optimized_time < original_time:
        print("✅ H2 OPTIMIZATION SUCCESS: Faster with correct results!")
        return 0
    elif match:
        print("⚠️  H2 OPTIMIZATION PARTIAL: Correct results but not faster")
        return 1
    else:
        print("❌ H2 OPTIMIZATION FAILED: Incorrect results")
        return 1

if __name__ == "__main__":
    sys.exit(main())