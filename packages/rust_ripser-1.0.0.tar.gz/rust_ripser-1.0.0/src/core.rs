//! # Core Algorithms
//!
//! Unified interface for all persistent homology algorithms in rust-ripser.
//! This module provides a clean API that internally uses the most appropriate
//! optimization for each case.

use crate::cocycles::CocycleComputer;
use crate::complex::VietorisRipsComplex;
use crate::distance::compute_distance_matrix_rust;
use crate::matrix_reduction::SparseMatrix;
use crate::optimized_h2::OptimizedH2Computer;
use crate::parallel::compute_persistence_parallel;
use crate::simple_h1::SimpleH1Computer;
use anyhow::Result;
use ndarray::ArrayView2;
use std::collections::HashMap;

/// Main computation modes
#[derive(Debug, Clone, Copy)]
pub enum ComputationMode {
    /// Prioritize accuracy over speed
    Accurate,
    /// Balanced accuracy and speed
    Balanced,
    /// Prioritize speed over accuracy (where safe)
    Fast,
    /// Use parallel computation
    Parallel,
    /// Memory-optimized for large datasets
    LowMemory,
}

/// Configuration for persistent homology computation
#[derive(Debug, Clone)]
pub struct PersistenceConfig {
    pub maxdim: usize,
    pub threshold: f64,
    pub metric: String,
    pub mode: ComputationMode,
    pub compute_cocycles: bool,
    pub num_threads: Option<usize>,
    pub memory_limit_mb: Option<usize>,
    pub progress: bool,
}

impl Default for PersistenceConfig {
    fn default() -> Self {
        Self {
            maxdim: 1,
            threshold: f64::INFINITY,
            metric: "euclidean".to_string(),
            mode: ComputationMode::Balanced,
            compute_cocycles: false,
            num_threads: None,
            memory_limit_mb: None,
            progress: false,
        }
    }
}

/// Main result structure
#[derive(Debug)]
pub struct PersistenceResult {
    pub intervals: HashMap<usize, Vec<(f64, f64)>>,
    pub cocycles: Option<HashMap<usize, Vec<Vec<usize>>>>,
    pub statistics: ComputationStatistics,
}

/// Computation statistics
#[derive(Debug)]
pub struct ComputationStatistics {
    pub n_points: usize,
    pub n_edges: usize,
    pub n_triangles: usize,
    pub computation_time: f64,
    pub memory_used_mb: f64,
    pub mode_used: ComputationMode,
}

/// Main unified computation function
pub fn compute_persistence(
    points: ArrayView2<f64>,
    config: PersistenceConfig,
) -> Result<PersistenceResult> {
    use crate::progress::{ComputationPhase, ProgressAwareComputation, ProgressReporter};

    let start_time = std::time::Instant::now();

    // Set up progress reporting
    let reporter = if config.progress {
        ProgressReporter::with_console()
    } else {
        ProgressReporter::new()
    };

    let total_phases = if config.compute_cocycles {
        4 + config.maxdim
    } else {
        3 + config.maxdim
    };
    let mut progress = ProgressAwareComputation::new(reporter, total_phases);

    if config.progress {
        progress.start_phase(ComputationPhase::DistanceMatrix);
    }

    // Choose the best algorithm based on configuration and data characteristics
    let mode = choose_optimal_mode(&config, points.nrows(), points.ncols());

    let (intervals, cocycles) = match mode {
        ComputationMode::Parallel => compute_parallel_impl(points, &config, &mut progress)?,
        ComputationMode::Fast => compute_fast_impl(points, &config, &mut progress)?,
        ComputationMode::LowMemory => {
            compute_memory_optimized_impl(points, &config, &mut progress)?
        }
        ComputationMode::Accurate | ComputationMode::Balanced => {
            compute_accurate_impl(points, &config, &mut progress)?
        }
    };

    if config.progress {
        progress.finish();
    }

    let computation_time = start_time.elapsed().as_secs_f64();

    let statistics = ComputationStatistics {
        n_points: points.nrows(),
        n_edges: 0,     // Would need to count actual edges
        n_triangles: 0, // Would need to count actual triangles
        computation_time,
        memory_used_mb: 0.0, // Would need actual memory tracking
        mode_used: mode,
    };

    Ok(PersistenceResult {
        intervals,
        cocycles,
        statistics,
    })
}

fn choose_optimal_mode(
    config: &PersistenceConfig,
    n_points: usize,
    n_dims: usize,
) -> ComputationMode {
    match config.mode {
        ComputationMode::Parallel if n_points > 100 => ComputationMode::Parallel,
        ComputationMode::Fast if config.maxdim <= 2 => ComputationMode::Fast,
        ComputationMode::LowMemory if n_points > 1000 => ComputationMode::LowMemory,
        _ => ComputationMode::Balanced,
    }
}

fn compute_parallel_impl(
    points: ArrayView2<f64>,
    config: &PersistenceConfig,
    progress: &mut crate::progress::ProgressAwareComputation,
) -> Result<(
    HashMap<usize, Vec<(f64, f64)>>,
    Option<HashMap<usize, Vec<Vec<usize>>>>,
)> {
    let intervals = compute_persistence_parallel(
        points,
        config.maxdim,
        config.threshold,
        &config.metric,
        config.num_threads,
    )?;

    // Cocycles not yet implemented for parallel mode
    Ok((intervals, None))
}

fn compute_fast_impl(
    points: ArrayView2<f64>,
    config: &PersistenceConfig,
    progress: &mut crate::progress::ProgressAwareComputation,
) -> Result<(
    HashMap<usize, Vec<(f64, f64)>>,
    Option<HashMap<usize, Vec<Vec<usize>>>>,
)> {
    if config.maxdim <= 2 {
        let computer = OptimizedH2Computer::new(points, config.threshold, &config.metric)?;
        let (h0, h1, h2) = computer.compute_h0_h1_h2_optimized()?;

        let mut intervals = HashMap::new();
        intervals.insert(0, h0);
        intervals.insert(1, h1);
        if config.maxdim >= 2 {
            intervals.insert(2, h2);
        }

        // Add fast cocycles computation if requested
        let cocycles = if config.compute_cocycles && config.maxdim >= 1 {
            let complex = VietorisRipsComplex::new(points, config.threshold, config.maxdim)?;
            let mut cocycle_computer = CocycleComputer::new(complex, config.threshold);
            let h1_cocycles = cocycle_computer.compute_h1_cocycles()?;

            let mut cocycle_result = HashMap::new();
            let cocycle_representatives: Vec<Vec<usize>> = h1_cocycles
                .iter()
                .map(|cocycle| cocycle.representatives.clone())
                .collect();
            cocycle_result.insert(1, cocycle_representatives);

            Some(cocycle_result)
        } else {
            None
        };

        Ok((intervals, cocycles))
    } else {
        // Fall back to accurate implementation for higher dimensions
        compute_accurate_impl(points, config, progress)
    }
}

fn compute_memory_optimized_impl(
    points: ArrayView2<f64>,
    config: &PersistenceConfig,
    progress: &mut crate::progress::ProgressAwareComputation,
) -> Result<(
    HashMap<usize, Vec<(f64, f64)>>,
    Option<HashMap<usize, Vec<Vec<usize>>>>,
)> {
    use crate::memory_optimized::LowMemoryPersistence;

    let memory_limit = config.memory_limit_mb.unwrap_or(1024); // Default 1GB
    let mut low_mem = LowMemoryPersistence::new(memory_limit);

    // Create distance function closure
    let points_owned = points.to_owned();
    let metric = config.metric.clone();

    let distance_fn = move |i: usize, j: usize| -> f64 {
        // Simple euclidean distance for now
        let mut dist_sq = 0.0;
        for k in 0..points_owned.ncols() {
            let diff = points_owned[[i, k]] - points_owned[[j, k]];
            dist_sq += diff * diff;
        }
        dist_sq.sqrt()
    };

    let intervals =
        low_mem.compute_with_memory_limit(points.nrows(), config.threshold, distance_fn)?;

    Ok((intervals, None))
}

fn compute_accurate_impl(
    points: ArrayView2<f64>,
    config: &PersistenceConfig,
    progress: &mut crate::progress::ProgressAwareComputation,
) -> Result<(
    HashMap<usize, Vec<(f64, f64)>>,
    Option<HashMap<usize, Vec<Vec<usize>>>>,
)> {
    use crate::progress::ComputationPhase;

    // Use the proven algorithms for maximum accuracy
    if config.progress {
        progress.start_phase(ComputationPhase::DistanceMatrix);
    }
    let distances = compute_distance_matrix_rust(points, &config.metric)?;

    if config.progress {
        progress.start_phase(ComputationPhase::ComplexConstruction);
    }
    let complex = VietorisRipsComplex::new(distances.view(), config.threshold, config.maxdim)?;

    let mut intervals = HashMap::new();

    // H0 and H1 computation using simple algorithm
    if config.progress {
        progress.start_phase(ComputationPhase::H0Computation);
    }
    let simple_computer = SimpleH1Computer::new(points, config.threshold)?;
    let (h0_intervals, h1_intervals) = simple_computer.compute_h0_h1()?;

    intervals.insert(0, h0_intervals);

    if config.maxdim >= 1 {
        if config.progress {
            progress.start_phase(ComputationPhase::H1Computation);
        }
        intervals.insert(1, h1_intervals);
    }

    // H2+ computation using matrix reduction
    for dim in 2..=config.maxdim {
        if config.progress {
            progress.start_phase(ComputationPhase::H2Computation);
        }
        let h_dim_pairs = compute_higher_dimensional_homology(&complex, dim, config.threshold)?;
        intervals.insert(dim, h_dim_pairs);
    }

    // Cocycles computation if requested
    let cocycles = if config.compute_cocycles && config.maxdim >= 1 {
        if config.progress {
            progress.start_phase(ComputationPhase::CocycleComputation);
        }
        let mut cocycle_computer = CocycleComputer::new(complex, config.threshold);
        let h1_cocycles = cocycle_computer.compute_h1_cocycles()?;

        let mut cocycle_result = HashMap::new();
        let cocycle_representatives: Vec<Vec<usize>> = h1_cocycles
            .iter()
            .map(|cocycle| cocycle.representatives.clone())
            .collect();
        cocycle_result.insert(1, cocycle_representatives);

        Some(cocycle_result)
    } else {
        None
    };

    Ok((intervals, cocycles))
}

/// Compute higher dimensional homology (H2+) using matrix reduction
fn compute_higher_dimensional_homology(
    complex: &VietorisRipsComplex,
    dimension: usize,
    threshold: f64,
) -> anyhow::Result<Vec<(f64, f64)>> {
    if dimension == 0 {
        return Err(anyhow::anyhow!("Use Union-Find for H0 computation"));
    }

    // Get simplices of dimension and dimension+1
    let simplices_d = get_filtered_simplices(complex, dimension, threshold);
    let simplices_d_plus_1 = get_filtered_simplices(complex, dimension + 1, threshold);

    if simplices_d.is_empty() {
        return Ok(vec![]);
    }

    // If no higher dimensional simplices, we have no persistence pairs for this dimension
    // This is because there are no (d+1)-simplices to create death events for d-cycles
    if simplices_d_plus_1.is_empty() {
        // No death events means no finite persistence pairs
        // Essential cycles (if any) would need different detection logic
        return Ok(vec![]);
    }

    // Build boundary matrix from (d+1)-simplices to d-simplices
    let boundary_matrix = build_boundary_matrix(&simplices_d, &simplices_d_plus_1, complex)?;

    // Perform matrix reduction to find persistence pairs
    let persistence_pairs =
        reduce_boundary_matrix(boundary_matrix, &simplices_d, &simplices_d_plus_1)?;

    Ok(persistence_pairs)
}

/// Get filtered simplices of a given dimension with their filtration values
fn get_filtered_simplices(
    complex: &VietorisRipsComplex,
    dimension: usize,
    threshold: f64,
) -> Vec<(Vec<usize>, f64)> {
    let simplices = complex.simplices_of_dimension(dimension);
    let mut filtered_simplices = Vec::new();

    for simplex in simplices {
        let filtration = compute_simplex_filtration(complex, &simplex);
        if filtration <= threshold {
            filtered_simplices.push((simplex, filtration));
        }
    }

    // Sort by filtration value
    filtered_simplices.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    filtered_simplices
}

/// Compute the filtration value of a simplex (max edge distance)
fn compute_simplex_filtration(complex: &VietorisRipsComplex, simplex: &[usize]) -> f64 {
    let mut max_dist = 0.0f64;

    // Find maximum pairwise distance in the simplex
    for i in 0..simplex.len() {
        for j in (i + 1)..simplex.len() {
            let u = simplex[i];
            let v = simplex[j];

            // Look up distance from complex's edges
            for ((edge_u, edge_v), dist) in complex.edges_with_filtration() {
                if (u == *edge_u && v == *edge_v) || (u == *edge_v && v == *edge_u) {
                    max_dist = max_dist.max(*dist);
                    break;
                }
            }
        }
    }

    max_dist
}

/// Build boundary matrix between consecutive dimensions
fn build_boundary_matrix(
    simplices_d: &[(Vec<usize>, f64)],
    simplices_d_plus_1: &[(Vec<usize>, f64)],
    complex: &VietorisRipsComplex,
) -> anyhow::Result<SparseMatrix> {
    let n_rows = simplices_d.len();
    let n_cols = simplices_d_plus_1.len();
    let mut matrix = SparseMatrix::new(n_rows, n_cols);

    // For each (d+1)-simplex (column), find its d-faces (rows)
    for (col_idx, (simplex_d_plus_1, _)) in simplices_d_plus_1.iter().enumerate() {
        let faces = get_faces(simplex_d_plus_1);

        for face in faces {
            // Find this face in the d-dimensional simplices
            for (row_idx, (simplex_d, _)) in simplices_d.iter().enumerate() {
                if simplex_d == &face {
                    matrix.set_entry(row_idx, col_idx, 1);
                    break;
                }
            }
        }
    }

    Ok(matrix)
}

/// Get all faces of a simplex (remove one vertex at a time)
fn get_faces(simplex: &[usize]) -> Vec<Vec<usize>> {
    let mut faces = Vec::new();

    for i in 0..simplex.len() {
        let mut face = simplex.to_vec();
        face.remove(i);
        face.sort(); // Canonical ordering
        faces.push(face);
    }

    faces
}

/// Reduce boundary matrix to find persistence pairs
fn reduce_boundary_matrix(
    mut matrix: SparseMatrix,
    simplices_d: &[(Vec<usize>, f64)],
    simplices_d_plus_1: &[(Vec<usize>, f64)],
) -> anyhow::Result<Vec<(f64, f64)>> {
    let mut pairs = Vec::new();
    let mut low = vec![None; matrix.ncols];

    // Standard matrix reduction algorithm
    for j in 0..matrix.ncols {
        // Reduce column j
        while let Some(i) = matrix.lowest_one_in_column(j) {
            if let Some(prev_j) = low[i] {
                // Add column prev_j to column j
                matrix.add_column(prev_j, j);
            } else {
                // Record the pairing
                low[i] = Some(j);

                // This creates a persistence pair
                let birth_time = simplices_d[i].1;
                let death_time = simplices_d_plus_1[j].1;

                if birth_time < death_time {
                    pairs.push((birth_time, death_time));
                }
                break;
            }
        }
    }

    Ok(pairs)
}
