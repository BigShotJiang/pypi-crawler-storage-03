//! # Progress Reporting Module
//!
//! Provides progress reporting functionality for long-running computations,
//! with support for Python tqdm callbacks and console output.

use std::sync::{Arc, Mutex};
use std::time::Instant;

/// Progress callback function type
/// Arguments: (current_step, total_steps, stage_name)
pub type ProgressCallback = Arc<dyn Fn(usize, usize, &str) + Send + Sync>;

/// Progress reporter for persistent homology computations
#[derive(Clone)]
pub struct ProgressReporter {
    callback: Option<ProgressCallback>,
    enabled: bool,
    start_time: Arc<Mutex<Option<Instant>>>,
}

impl Default for ProgressReporter {
    fn default() -> Self {
        Self::new()
    }
}

impl ProgressReporter {
    /// Create a new progress reporter
    pub fn new() -> Self {
        Self {
            callback: None,
            enabled: false,
            start_time: Arc::new(Mutex::new(None)),
        }
    }

    /// Create a progress reporter with callback
    pub fn with_callback(callback: ProgressCallback) -> Self {
        Self {
            callback: Some(callback),
            enabled: true,
            start_time: Arc::new(Mutex::new(None)),
        }
    }

    /// Enable console progress reporting with modern styling
    pub fn with_console() -> Self {
        let callback = Arc::new(|current: usize, total: usize, stage: &str| {
            let percentage = if total > 0 {
                (current as f64 / total as f64 * 100.0).round() as usize
            } else {
                0
            };

            let bar_length = 50;
            let filled_length = (current * bar_length) / total.max(1);

            // Modern progress bar with colors and Unicode characters
            let filled_char = "█";
            let partial_char = "▉";
            let empty_char = "░";

            let mut bar = String::new();

            // Add filled portions
            for _ in 0..filled_length {
                bar.push_str(filled_char);
            }

            // Add partial fill if needed
            if filled_length < bar_length && current < total {
                let remainder = (current * bar_length) % total.max(1);
                if remainder > total / 8 {
                    bar.push_str(partial_char);
                } else {
                    bar.push_str(empty_char);
                }

                // Add empty portions
                for _ in (filled_length + 1)..bar_length {
                    bar.push_str(empty_char);
                }
            } else {
                // Add remaining empty portions
                for _ in filled_length..bar_length {
                    bar.push_str(empty_char);
                }
            }

            // Add color codes for better visibility
            let green = "\x1b[32m";
            let blue = "\x1b[34m";
            let reset = "\x1b[0m";

            print!(
                "\r{}{}{} {}[{}]{} {}{}%{} ({}/{}) ",
                blue, stage, reset, green, bar, reset, green, percentage, reset, current, total
            );

            use std::io::{self, Write};
            io::stdout().flush().unwrap();

            if current >= total {
                println!(); // New line when complete
            }
        });

        Self::with_callback(callback)
    }

    /// Enable minimal console progress reporting (no colors)
    pub fn with_simple_console() -> Self {
        let callback = Arc::new(|current: usize, total: usize, stage: &str| {
            let percentage = if total > 0 {
                (current as f64 / total as f64 * 100.0).round() as usize
            } else {
                0
            };

            let bar_length = 40;
            let filled_length = (current * bar_length) / total.max(1);
            let bar = "=".repeat(filled_length) + &"-".repeat(bar_length - filled_length);

            print!(
                "\r{}: [{}] {}% ({}/{})",
                stage, bar, percentage, current, total
            );
            use std::io::{self, Write};
            io::stdout().flush().unwrap();

            if current >= total {
                println!(); // New line when complete
            }
        });

        Self::with_callback(callback)
    }

    /// Start progress tracking
    pub fn start(&self) {
        if self.enabled {
            let mut start_time = self.start_time.lock().unwrap();
            *start_time = Some(Instant::now());
        }
    }

    /// Report progress
    pub fn report(&self, current: usize, total: usize, stage: &str) {
        if let Some(ref callback) = self.callback {
            callback(current, total, stage);
        }
    }

    /// Finish progress tracking
    pub fn finish(&self, stage: &str) {
        if self.enabled {
            if let Some(ref callback) = self.callback {
                // Report 100% completion
                callback(1, 1, stage);
            }

            if let Ok(start_time) = self.start_time.lock() {
                if let Some(start) = *start_time {
                    let elapsed = start.elapsed();
                    if self.callback.is_some() {
                        println!("Completed {} in {:.3}s", stage, elapsed.as_secs_f64());
                    }
                }
            }
        }
    }

    /// Check if progress reporting is enabled
    pub fn is_enabled(&self) -> bool {
        self.enabled
    }
}

/// Progress-aware computation phases
#[derive(Debug, Clone, Copy)]
pub enum ComputationPhase {
    DistanceMatrix,
    ComplexConstruction,
    H0Computation,
    H1Computation,
    H2Computation,
    CocycleComputation,
    MatrixReduction,
}

impl ComputationPhase {
    pub fn name(&self) -> &'static str {
        match self {
            ComputationPhase::DistanceMatrix => "Computing distance matrix",
            ComputationPhase::ComplexConstruction => "Building simplicial complex",
            ComputationPhase::H0Computation => "Computing H0 persistence",
            ComputationPhase::H1Computation => "Computing H1 persistence",
            ComputationPhase::H2Computation => "Computing H2 persistence",
            ComputationPhase::CocycleComputation => "Computing cocycles",
            ComputationPhase::MatrixReduction => "Reducing boundary matrix",
        }
    }
}

/// Progress-aware wrapper for computations
pub struct ProgressAwareComputation {
    reporter: ProgressReporter,
    total_phases: usize,
    current_phase: usize,
}

impl ProgressAwareComputation {
    pub fn new(reporter: ProgressReporter, total_phases: usize) -> Self {
        Self {
            reporter,
            total_phases,
            current_phase: 0,
        }
    }

    pub fn start_phase(&mut self, phase: ComputationPhase) {
        self.current_phase += 1;
        self.reporter
            .report(self.current_phase, self.total_phases, phase.name());
    }

    pub fn update_phase_progress(&self, current: usize, total: usize, phase: ComputationPhase) {
        // Calculate overall progress including phase progress
        let phase_weight = 1.0 / self.total_phases as f64;
        let phase_progress = if total > 0 {
            current as f64 / total as f64
        } else {
            0.0
        };
        let overall_progress = ((self.current_phase - 1) as f64 + phase_progress) * phase_weight;

        let overall_current = (overall_progress * 1000.0) as usize;
        let overall_total = 1000;

        self.reporter
            .report(overall_current, overall_total, phase.name());
    }

    pub fn finish(&self) {
        self.reporter.finish("Persistent homology computation");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, Mutex};

    #[test]
    fn test_progress_reporter() {
        let calls = Arc::new(Mutex::new(Vec::new()));
        let calls_clone = calls.clone();

        let callback = Arc::new(move |current: usize, total: usize, stage: &str| {
            calls_clone
                .lock()
                .unwrap()
                .push((current, total, stage.to_string()));
        });

        let reporter = ProgressReporter::with_callback(callback);

        reporter.start();
        reporter.report(1, 10, "Test stage");
        reporter.report(5, 10, "Test stage");
        reporter.report(10, 10, "Test stage");
        reporter.finish("Test stage");

        let calls = calls.lock().unwrap();
        assert_eq!(calls.len(), 4); // 3 reports + 1 finish
    }

    #[test]
    fn test_computation_phases() {
        assert_eq!(
            ComputationPhase::H0Computation.name(),
            "Computing H0 persistence"
        );
        assert_eq!(
            ComputationPhase::H1Computation.name(),
            "Computing H1 persistence"
        );
        assert_eq!(
            ComputationPhase::H2Computation.name(),
            "Computing H2 persistence"
        );
    }
}
