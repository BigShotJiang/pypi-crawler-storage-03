//! # Rust-Ripser: High-Performance Persistent Homology
//!
//! A high-performance persistent homology computation library implemented in Rust,
//! designed to exceed the performance of numba implementations.

use numpy::{PyArray2, PyReadonlyArray2};
use pyo3::prelude::*;

// Import submodules
pub mod cocycles;
pub mod complex;
pub mod core;
pub mod distance;
pub mod matrix_reduction;
pub mod memory_optimized;
pub mod optimized_h2;
pub mod parallel;
pub mod progress;
pub mod simple_h1;
pub mod union_find;

// Re-export main types
pub use complex::*;
pub use distance::*;
pub use matrix_reduction::*;
pub use union_find::*;

/// Rust version of ripser main function (complete implementation)
#[pyfunction]
#[pyo3(signature = (points, maxdim=1, thresh=f64::INFINITY, metric="euclidean"))]
fn compute_ripser<'py>(
    py: Python<'py>,
    points: PyReadonlyArray2<'_, f64>,
    maxdim: usize,
    thresh: f64,
    metric: &str,
) -> PyResult<PyObject> {
    // Get numpy array view
    let points_view = points.as_array();

    // Call complete persistent homology computation
    match compute_persistent_homology_rust(points_view, maxdim, thresh, metric) {
        Ok(result) => {
            // Convert result to Python objects
            let mut dgms = Vec::new();

            for dim in 0..=maxdim {
                if let Some(pairs) = result.get(&dim) {
                    let pairs_vec: Vec<Vec<f64>> =
                        pairs.iter().map(|pair| vec![pair[0], pair[1]]).collect();
                    let array = PyArray2::from_vec2(py, &pairs_vec)?;
                    dgms.push(array.to_object(py));
                } else {
                    // Empty persistence diagram
                    let empty_pairs: Vec<Vec<f64>> = vec![];
                    let array = PyArray2::from_vec2(py, &empty_pairs)?;
                    dgms.push(array.to_object(py));
                }
            }

            // Create result dictionary
            let result_dict = pyo3::types::PyDict::new(py);
            result_dict.set_item("dgms", dgms)?;
            result_dict.set_item("rust_powered", true)?;
            result_dict.set_item("n_points", points_view.nrows())?;
            result_dict.set_item("n_dims", points_view.ncols())?;
            result_dict.set_item("metric", metric)?;
            result_dict.set_item("threshold", thresh)?;

            Ok(result_dict.to_object(py))
        }
        Err(e) => Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
            "Rust ripser computation failed: {}",
            e
        ))),
    }
}

/// Optimized Rust version of ripser (specifically optimized for maxdim=2)
#[pyfunction]
#[pyo3(signature = (points, thresh=f64::INFINITY, metric="euclidean"))]
fn compute_ripser_h2_optimized<'py>(
    py: Python<'py>,
    points: PyReadonlyArray2<'_, f64>,
    thresh: f64,
    metric: &str,
) -> PyResult<PyObject> {
    use crate::optimized_h2;

    // Get numpy array view
    let points_view = points.as_array();

    // Call optimized H0+H1+H2 computation
    match optimized_h2::compute_h0_h1_h2_optimized(points_view, thresh, metric) {
        Ok(result) => {
            // Convert result to Python objects
            let mut dgms = Vec::new();

            for dim in 0..=2 {
                if let Some(pairs) = result.get(&dim) {
                    let pairs_vec: Vec<Vec<f64>> = pairs.clone();
                    let array = PyArray2::from_vec2(py, &pairs_vec)?;
                    dgms.push(array.to_object(py));
                } else {
                    // Empty persistence diagram
                    let empty_pairs: Vec<Vec<f64>> = vec![];
                    let array = PyArray2::from_vec2(py, &empty_pairs)?;
                    dgms.push(array.to_object(py));
                }
            }

            // Create result dictionary
            let result_dict = pyo3::types::PyDict::new(py);
            result_dict.set_item("dgms", dgms)?;
            result_dict.set_item("optimized_h2", true)?;
            result_dict.set_item("maxdim", 2)?;
            result_dict.set_item("n_points", points_view.nrows())?;
            result_dict.set_item("metric", metric)?;
            result_dict.set_item("threshold", thresh)?;

            // Add statistical information
            match optimized_h2::OptimizedH2Computer::new(points_view, thresh, metric) {
                Ok(computer) => {
                    let stats = computer.get_statistics();
                    for (key, value) in stats {
                        result_dict.set_item(key, value)?;
                    }
                }
                Err(_) => {
                    // If statistical information retrieval fails, ignore but don't affect main result
                }
            }

            Ok(result_dict.to_object(py))
        }
        Err(e) => Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
            "Optimized H2 rust ripser computation failed: {}",
            e
        ))),
    }
}

/// Optimized Rust version of ripser (specifically optimized for maxdim=1)
#[pyfunction]
#[pyo3(signature = (points, thresh=f64::INFINITY, metric="euclidean"))]
fn compute_ripser_optimized<'py>(
    py: Python<'py>,
    points: PyReadonlyArray2<'_, f64>,
    thresh: f64,
    metric: &str,
) -> PyResult<PyObject> {
    // Get numpy array view
    let points_view = points.as_array();

    // Call simple H0+H1 computation (optimized version removed)
    match crate::simple_h1::compute_h0_h1_simple(points_view, thresh) {
        Ok(result) => {
            // Convert result to Python objects
            let mut dgms = Vec::new();

            for dim in 0..=1 {
                if let Some(pairs) = result.get(&dim) {
                    let pairs_vec: Vec<Vec<f64>> = pairs
                        .iter()
                        .map(|(birth, death)| vec![*birth, *death])
                        .collect();
                    let array = PyArray2::from_vec2(py, &pairs_vec)?;
                    dgms.push(array.to_object(py));
                } else {
                    // Empty persistence diagram
                    let empty_pairs: Vec<Vec<f64>> = vec![];
                    let array = PyArray2::from_vec2(py, &empty_pairs)?;
                    dgms.push(array.to_object(py));
                }
            }

            // Create result dictionary
            let result_dict = pyo3::types::PyDict::new(py);
            result_dict.set_item("dgms", dgms)?;
            result_dict.set_item("optimized", true)?;
            result_dict.set_item("maxdim", 1)?;
            result_dict.set_item("n_points", points_view.nrows())?;
            result_dict.set_item("metric", metric)?;
            result_dict.set_item("threshold", thresh)?;

            Ok(result_dict.to_object(py))
        }
        Err(e) => Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
            "Optimized rust ripser computation failed: {}",
            e
        ))),
    }
}

/// Unified advanced Rust ripser interface
#[pyfunction]
#[pyo3(signature = (points, maxdim=1, thresh=f64::INFINITY, metric="euclidean", mode="balanced", cocycles=false, num_threads=None, progress=false))]
fn compute_ripser_advanced<'py>(
    py: Python<'py>,
    points: PyReadonlyArray2<'_, f64>,
    maxdim: usize,
    thresh: f64,
    metric: &str,
    mode: &str,
    cocycles: bool,
    num_threads: Option<usize>,
    progress: bool,
) -> PyResult<PyObject> {
    use crate::core::{compute_persistence, ComputationMode, PersistenceConfig};

    // Parse computation mode
    let computation_mode = match mode {
        "accurate" => ComputationMode::Accurate,
        "balanced" => ComputationMode::Balanced,
        "fast" => ComputationMode::Fast,
        "parallel" => ComputationMode::Parallel,
        "low_memory" => ComputationMode::LowMemory,
        _ => ComputationMode::Balanced,
    };

    let config = PersistenceConfig {
        maxdim,
        threshold: thresh,
        metric: metric.to_string(),
        mode: computation_mode,
        compute_cocycles: cocycles,
        num_threads,
        memory_limit_mb: None,
        progress,
    };

    // Get numpy array view
    let points_view = points.as_array();

    match compute_persistence(points_view, config) {
        Ok(result) => {
            // Convert result to Python objects
            let mut dgms = Vec::new();

            for dim in 0..=maxdim {
                if let Some(pairs) = result.intervals.get(&dim) {
                    let pairs_vec: Vec<Vec<f64>> = pairs
                        .iter()
                        .map(|(birth, death)| vec![*birth, *death])
                        .collect();
                    let array = PyArray2::from_vec2(py, &pairs_vec)?;
                    dgms.push(array.to_object(py));
                } else {
                    let empty_pairs: Vec<Vec<f64>> = vec![];
                    let array = PyArray2::from_vec2(py, &empty_pairs)?;
                    dgms.push(array.to_object(py));
                }
            }

            // Create result dictionary
            let result_dict = pyo3::types::PyDict::new(py);
            result_dict.set_item("dgms", dgms)?;
            result_dict.set_item("computation_time", result.statistics.computation_time)?;
            result_dict.set_item("n_points", result.statistics.n_points)?;
            result_dict.set_item("mode_used", format!("{:?}", result.statistics.mode_used))?;

            // Add cocycles (if computed)
            if let Some(cocycles_result) = result.cocycles {
                let cocycles_dict = pyo3::types::PyDict::new(py);
                for (dim, cocycle_list) in cocycles_result {
                    let cocycle_arrays: Vec<PyObject> = cocycle_list
                        .iter()
                        .map(|representatives| {
                            let representatives_i32: Vec<i32> =
                                representatives.iter().map(|&x| x as i32).collect();
                            PyArray2::from_vec2(py, &vec![representatives_i32])
                                .unwrap()
                                .to_object(py)
                        })
                        .collect();
                    cocycles_dict.set_item(dim.to_string(), cocycle_arrays)?;
                }
                result_dict.set_item("cocycles", cocycles_dict)?;
            }

            Ok(result_dict.to_object(py))
        }
        Err(e) => Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
            "Advanced rust ripser computation failed: {}",
            e
        ))),
    }
}

/// Rust version of ripser main function (includes cocycles)
#[pyfunction]
#[pyo3(signature = (points, maxdim=1, thresh=f64::INFINITY, metric="euclidean", cocycles=false))]
fn compute_ripser_with_cocycles<'py>(
    py: Python<'py>,
    points: PyReadonlyArray2<'_, f64>,
    maxdim: usize,
    thresh: f64,
    metric: &str,
    cocycles: bool,
) -> PyResult<PyObject> {
    // Get numpy array view
    let points_view = points.as_array();

    // Call persistent homology computation with cocycles
    match compute_persistent_homology_with_cocycles_rust(
        points_view,
        maxdim,
        thresh,
        metric,
        cocycles,
    ) {
        Ok((dgms_result, cocycles_result, num_edges)) => {
            // Convert dgms result to Python objects
            let mut dgms = Vec::new();

            for dim in 0..=maxdim {
                if let Some(pairs) = dgms_result.get(&dim) {
                    let pairs_vec: Vec<Vec<f64>> =
                        pairs.iter().map(|pair| vec![pair[0], pair[1]]).collect();
                    let array = PyArray2::from_vec2(py, &pairs_vec)?;
                    dgms.push(array.to_object(py));
                } else {
                    // Empty persistence diagram
                    let empty_pairs: Vec<Vec<f64>> = vec![];
                    let array = PyArray2::from_vec2(py, &empty_pairs)?;
                    dgms.push(array.to_object(py));
                }
            }

            // Create result dictionary
            let result_dict = pyo3::types::PyDict::new(py);
            result_dict.set_item("dgms", dgms)?;
            result_dict.set_item("num_edges", num_edges)?;

            // Add cocycles (if computed)
            if cocycles && !cocycles_result.is_empty() {
                let mut cocycles_dict = pyo3::types::PyDict::new(py);
                for (dim, cocycle_list) in cocycles_result {
                    let cocycle_arrays: Vec<PyObject> = cocycle_list
                        .iter()
                        .map(|representatives| {
                            let representatives_i32: Vec<i32> =
                                representatives.iter().map(|&x| x as i32).collect();
                            PyArray2::from_vec2(py, &vec![representatives_i32])
                                .unwrap()
                                .to_object(py)
                        })
                        .collect();
                    cocycles_dict.set_item(dim.to_string(), cocycle_arrays)?;
                }
                result_dict.set_item("cocycles", cocycles_dict)?;
            }

            Ok(result_dict.to_object(py))
        }
        Err(e) => Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
            "Rust ripser with cocycles computation failed: {}",
            e
        ))),
    }
}

/// Performance testing function (simplified version)
#[pyfunction]
fn benchmark_rust_distance(points: PyReadonlyArray2<'_, f64>, _metric: &str) -> PyResult<f64> {
    let points_view = points.as_array();
    let n_points = points_view.nrows();

    let start = std::time::Instant::now();

    // Simple distance calculation test
    let mut total_distance = 0.0;
    for i in 0..n_points {
        for j in (i + 1)..n_points {
            let p1 = points_view.row(i);
            let p2 = points_view.row(j);

            // Calculate Euclidean distance
            let mut dist_sq = 0.0;
            for k in 0..p1.len() {
                let diff = p1[k] - p2[k];
                dist_sq += diff * diff;
            }
            total_distance += dist_sq.sqrt();
        }
    }

    let elapsed = start.elapsed();

    // Prevent compiler from optimizing away computation
    if total_distance < 0.0 {
        return Ok(-1.0);
    }

    Ok(elapsed.as_secs_f64())
}

/// Simple addition test function (for verifying bindings work correctly)
#[pyfunction]
fn add_numbers(a: f64, b: f64) -> f64 {
    a + b
}

/// Version information
#[pyfunction]
fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Get Rust compiler information
#[pyfunction]
fn rust_info() -> PyResult<PyObject> {
    Python::with_gil(|py| {
        let info_dict = pyo3::types::PyDict::new(py);
        info_dict.set_item("version", env!("CARGO_PKG_VERSION"))?;
        info_dict.set_item("rust_version", "unknown")?;
        info_dict.set_item("features", get_enabled_features())?;
        info_dict.set_item("optimizations", "release+lto")?;
        Ok(info_dict.to_object(py))
    })
}

fn get_enabled_features() -> Vec<&'static str> {
    let mut features = vec![];

    #[cfg(feature = "rayon")]
    features.push("rayon");

    #[cfg(feature = "experimental")]
    features.push("experimental");

    features
}

/// Python module definition
#[pymodule]
fn rust_ripser(_py: Python, m: &PyModule) -> PyResult<()> {
    // Add functions
    m.add_function(wrap_pyfunction!(compute_ripser, m)?)?;
    m.add_function(wrap_pyfunction!(compute_ripser_advanced, m)?)?;
    m.add_function(wrap_pyfunction!(compute_ripser_optimized, m)?)?;
    m.add_function(wrap_pyfunction!(compute_ripser_h2_optimized, m)?)?;
    m.add_function(wrap_pyfunction!(compute_ripser_with_cocycles, m)?)?;
    m.add_function(wrap_pyfunction!(benchmark_rust_distance, m)?)?;
    m.add_function(wrap_pyfunction!(add_numbers, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    m.add_function(wrap_pyfunction!(rust_info, m)?)?;

    // Add aliases
    m.add("rust_ripser", m.getattr("compute_ripser")?)?;

    // Add constants
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;

    Ok(())
}

/// Rust implementation of main computation function - using corrected H1 calculation
fn compute_persistent_homology_rust(
    points: ndarray::ArrayView2<f64>,
    maxdim: usize,
    thresh: f64,
    metric: &str,
) -> anyhow::Result<std::collections::HashMap<usize, Vec<Vec<f64>>>> {
    // 1. Calculate distance matrix
    let distances = compute_distance_matrix_rust(points, metric)?;

    // 2. Build Vietoris-Rips complex
    let complex = VietorisRipsComplex::new(distances.view(), thresh, maxdim)?;

    let mut result = std::collections::HashMap::new();

    // 3. H0 and H1 using simple but correct boundary matrix reduction
    let simple_computer = crate::simple_h1::SimpleH1Computer::new(points, thresh)?;
    let (h0_pairs, h1_pairs) = simple_computer.compute_h0_h1()?;

    // Format H0 pairs
    let formatted_h0_pairs: Vec<Vec<f64>> = h0_pairs
        .iter()
        .map(|(birth, death)| vec![*birth, *death])
        .collect();
    result.insert(0, formatted_h0_pairs);

    // Format H1 pairs (if maxdim >= 1)
    if maxdim >= 1 {
        let formatted_h1_pairs: Vec<Vec<f64>> = h1_pairs
            .into_iter()
            .map(|(birth, death)| vec![birth, death])
            .collect();
        result.insert(1, formatted_h1_pairs);
    }

    // 4. H2+ computation using proper homology algorithms
    if maxdim >= 2 {
        for dim in 2..=maxdim {
            let h_dim_pairs = compute_higher_dimensional_homology(&complex, dim, thresh)?;
            let formatted_pairs: Vec<Vec<f64>> = h_dim_pairs
                .into_iter()
                .map(|(birth, death)| vec![birth, death])
                .collect();
            result.insert(dim, formatted_pairs);
        }
    }

    Ok(result)
}

/// Persistent homology computation function including cocycles
fn compute_persistent_homology_with_cocycles_rust(
    points: ndarray::ArrayView2<f64>,
    maxdim: usize,
    thresh: f64,
    metric: &str,
    compute_cocycles: bool,
) -> anyhow::Result<(
    std::collections::HashMap<usize, Vec<Vec<f64>>>,
    std::collections::HashMap<usize, Vec<Vec<usize>>>,
    usize,
)> {
    use crate::cocycles::CocycleComputer;

    // 1. Calculate distance matrix
    let distances = compute_distance_matrix_rust(points, metric)?;

    // 2. Build Vietoris-Rips complex
    let complex = VietorisRipsComplex::new(distances.view(), thresh, maxdim)?;

    let mut dgms_result = std::collections::HashMap::new();
    let mut cocycles_result = std::collections::HashMap::new();

    // Calculate number of edges
    let num_edges = complex.edges_with_filtration().count();

    // 3. H0 and H1 using simple but correct boundary matrix reduction
    let simple_computer = crate::simple_h1::SimpleH1Computer::new(points, thresh)?;
    let (h0_pairs, h1_pairs) = simple_computer.compute_h0_h1()?;

    // Format H0 pairs
    let formatted_h0_pairs: Vec<Vec<f64>> = h0_pairs
        .iter()
        .map(|(birth, death)| vec![*birth, *death])
        .collect();
    dgms_result.insert(0, formatted_h0_pairs);

    // Format H1 pairs (if maxdim >= 1)
    if maxdim >= 1 {
        let formatted_h1_pairs: Vec<Vec<f64>> = h1_pairs
            .into_iter()
            .map(|(birth, death)| vec![birth, death])
            .collect();
        dgms_result.insert(1, formatted_h1_pairs);

        // Calculate H1 cocycles (if needed)
        if compute_cocycles {
            let mut cocycle_computer = CocycleComputer::new(complex.clone(), thresh);
            let h1_cocycles = cocycle_computer.compute_h1_cocycles()?;
            let cocycle_representatives: Vec<Vec<usize>> = h1_cocycles
                .iter()
                .map(|cocycle| cocycle.representatives.clone())
                .collect();
            cocycles_result.insert(1, cocycle_representatives);
        }
    }

    // 4. H2+ computation using proper homology algorithms
    if maxdim >= 2 {
        for dim in 2..=maxdim {
            let h_dim_pairs = compute_higher_dimensional_homology(&complex, dim, thresh)?;
            let formatted_pairs: Vec<Vec<f64>> = h_dim_pairs
                .into_iter()
                .map(|(birth, death)| vec![birth, death])
                .collect();
            dgms_result.insert(dim, formatted_pairs);

            if compute_cocycles {
                // TODO: Implement cocycles for H2+
                cocycles_result.insert(dim, vec![]);
            }
        }
    }

    Ok((dgms_result, cocycles_result, num_edges))
}

/// Compute higher dimensional homology (H2+) using matrix reduction
fn compute_higher_dimensional_homology(
    complex: &VietorisRipsComplex,
    dimension: usize,
    threshold: f64,
) -> anyhow::Result<Vec<(f64, f64)>> {
    if dimension == 0 {
        return Err(anyhow::anyhow!("Use Union-Find for H0 computation"));
    }

    // Get simplices of dimension and dimension+1
    let simplices_d = get_filtered_simplices(complex, dimension, threshold);
    let simplices_d_plus_1 = get_filtered_simplices(complex, dimension + 1, threshold);

    if simplices_d.is_empty() {
        return Ok(vec![]);
    }

    // If no higher dimensional simplices, we have no persistence pairs for this dimension
    // This is because there are no (d+1)-simplices to create death events for d-cycles
    if simplices_d_plus_1.is_empty() {
        // No death events means no finite persistence pairs
        // Essential cycles (if any) would need different detection logic
        return Ok(vec![]);
    }

    // Build boundary matrix from (d+1)-simplices to d-simplices
    let boundary_matrix = build_boundary_matrix(&simplices_d, &simplices_d_plus_1, complex)?;

    // Perform matrix reduction to find persistence pairs
    let persistence_pairs =
        reduce_boundary_matrix(boundary_matrix, &simplices_d, &simplices_d_plus_1)?;

    Ok(persistence_pairs)
}

/// Get filtered simplices of a given dimension with their filtration values
fn get_filtered_simplices(
    complex: &VietorisRipsComplex,
    dimension: usize,
    threshold: f64,
) -> Vec<(Vec<usize>, f64)> {
    let simplices = complex.simplices_of_dimension(dimension);
    let mut filtered_simplices = Vec::new();

    for simplex in simplices {
        let filtration = compute_simplex_filtration(complex, &simplex);
        if filtration <= threshold {
            filtered_simplices.push((simplex, filtration));
        }
    }

    // Sort by filtration value
    filtered_simplices.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    filtered_simplices
}

/// Compute the filtration value of a simplex (max edge distance)
fn compute_simplex_filtration(complex: &VietorisRipsComplex, simplex: &[usize]) -> f64 {
    let mut max_dist = 0.0f64;

    // Find maximum pairwise distance in the simplex
    for i in 0..simplex.len() {
        for j in (i + 1)..simplex.len() {
            let u = simplex[i];
            let v = simplex[j];

            // Look up distance from complex's edges
            for ((edge_u, edge_v), dist) in complex.edges_with_filtration() {
                if (u == *edge_u && v == *edge_v) || (u == *edge_v && v == *edge_u) {
                    max_dist = max_dist.max(*dist);
                    break;
                }
            }
        }
    }

    max_dist
}

/// Build boundary matrix between consecutive dimensions
fn build_boundary_matrix(
    simplices_d: &[(Vec<usize>, f64)],
    simplices_d_plus_1: &[(Vec<usize>, f64)],
    complex: &VietorisRipsComplex,
) -> anyhow::Result<SparseMatrix> {
    let n_rows = simplices_d.len();
    let n_cols = simplices_d_plus_1.len();
    let mut matrix = SparseMatrix::new(n_rows, n_cols);

    // For each (d+1)-simplex (column), find its d-faces (rows)
    for (col_idx, (simplex_d_plus_1, _)) in simplices_d_plus_1.iter().enumerate() {
        let faces = get_faces(simplex_d_plus_1);

        for face in faces {
            // Find this face in the d-dimensional simplices
            for (row_idx, (simplex_d, _)) in simplices_d.iter().enumerate() {
                if simplex_d == &face {
                    matrix.set_entry(row_idx, col_idx, 1);
                    break;
                }
            }
        }
    }

    Ok(matrix)
}

/// Get all faces of a simplex (remove one vertex at a time)
fn get_faces(simplex: &[usize]) -> Vec<Vec<usize>> {
    let mut faces = Vec::new();

    for i in 0..simplex.len() {
        let mut face = simplex.to_vec();
        face.remove(i);
        face.sort(); // Canonical ordering
        faces.push(face);
    }

    faces
}

/// Reduce boundary matrix to find persistence pairs
fn reduce_boundary_matrix(
    mut matrix: SparseMatrix,
    simplices_d: &[(Vec<usize>, f64)],
    simplices_d_plus_1: &[(Vec<usize>, f64)],
) -> anyhow::Result<Vec<(f64, f64)>> {
    let mut pairs = Vec::new();
    let mut low = vec![None; matrix.ncols];

    // Standard matrix reduction algorithm
    for j in 0..matrix.ncols {
        // Reduce column j
        while let Some(i) = matrix.lowest_one_in_column(j) {
            if let Some(prev_j) = low[i] {
                // Add column prev_j to column j
                matrix.add_column(prev_j, j);
            } else {
                // Record the pairing
                low[i] = Some(j);

                // This creates a persistence pair
                let birth_time = simplices_d[i].1;
                let death_time = simplices_d_plus_1[j].1;

                if birth_time < death_time {
                    pairs.push((birth_time, death_time));
                }
                break;
            }
        }
    }

    Ok(pairs)
}
