//! # Parallel Processing Support
//!
//! Implements parallel algorithms for distance computation, complex construction,
//! and matrix operations using Rayon for multi-threading.

use anyhow::Result;
use ndarray::ArrayView2;
use rayon::prelude::*;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

/// Parallel distance matrix computation
pub fn compute_distance_matrix_parallel(
    points: ArrayView2<f64>,
    metric: &str,
    chunk_size: Option<usize>,
) -> Result<ndarray::Array2<f64>> {
    let n_points = points.nrows();
    let n_dims = points.ncols();

    // Create output matrix
    let mut distances = ndarray::Array2::zeros((n_points, n_points));

    match metric {
        "euclidean" => {
            // Create chunks of row pairs to process in parallel
            let chunk_size = chunk_size.unwrap_or(64);
            let total_pairs = n_points * (n_points - 1) / 2;
            let num_chunks = (total_pairs + chunk_size - 1) / chunk_size;

            // Generate all pairs and chunk them
            let mut pairs = Vec::new();
            for i in 0..n_points {
                for j in (i + 1)..n_points {
                    pairs.push((i, j));
                }
            }

            // Process chunks in parallel
            let results: Vec<Vec<(usize, usize, f64)>> = pairs
                .par_chunks(chunk_size)
                .map(|chunk| {
                    let mut chunk_results = Vec::new();

                    for &(i, j) in chunk {
                        let point_i = points.row(i);
                        let point_j = points.row(j);

                        // Vectorized distance computation
                        let mut dist_sq = 0.0;

                        // Unroll for better performance
                        let mut k = 0;
                        while k + 4 <= n_dims {
                            let d0 = point_i[k] - point_j[k];
                            let d1 = point_i[k + 1] - point_j[k + 1];
                            let d2 = point_i[k + 2] - point_j[k + 2];
                            let d3 = point_i[k + 3] - point_j[k + 3];

                            dist_sq += d0 * d0 + d1 * d1 + d2 * d2 + d3 * d3;
                            k += 4;
                        }

                        // Handle remaining dimensions
                        while k < n_dims {
                            let diff = point_i[k] - point_j[k];
                            dist_sq += diff * diff;
                            k += 1;
                        }

                        let dist = dist_sq.sqrt();
                        chunk_results.push((i, j, dist));
                    }

                    chunk_results
                })
                .collect();

            // Collect results back into matrix
            for chunk_result in results {
                for (i, j, dist) in chunk_result {
                    distances[[i, j]] = dist;
                    distances[[j, i]] = dist;
                }
            }
        }

        "precomputed" => {
            distances.assign(&points.slice(ndarray::s![..n_points, ..n_points]));
        }

        _ => {
            return Err(anyhow::anyhow!(
                "Unsupported metric for parallel computation: {}",
                metric
            ));
        }
    }

    Ok(distances)
}

/// Parallel triangle generation
pub fn generate_triangles_parallel(
    edges: &[((usize, usize), f64)],
    max_distance: f64,
    chunk_size: Option<usize>,
) -> Vec<(Vec<usize>, f64)> {
    if edges.len() < 3 {
        return vec![];
    }

    // Build edge lookup for fast triangle validation
    let edge_map: HashMap<(usize, usize), f64> = edges
        .iter()
        .map(|((u, v), d)| ((*u.min(v), *u.max(v)), *d))
        .collect();

    // Generate potential triangles from edges
    let chunk_size = chunk_size.unwrap_or(1000);

    let triangles: Vec<Vec<(Vec<usize>, f64)>> = edges
        .par_chunks(chunk_size)
        .map(|edge_chunk| {
            let mut local_triangles = Vec::new();

            for ((u, v), _) in edge_chunk {
                // Find all vertices that form triangles with edge (u, v)
                for ((a, b), _) in edges {
                    if *a == *u || *a == *v || *b == *u || *b == *v {
                        continue; // Skip if shares a vertex
                    }

                    // Check if we can form triangles u-v-a or u-v-b
                    let candidates = [*a, *b];

                    for &w in &candidates {
                        if w == *u || w == *v {
                            continue;
                        }

                        // Check if all three edges exist
                        let edge1 = (*u.min(&w), *u.max(&w));
                        let edge2 = (*v.min(&w), *v.max(&w));
                        let edge3 = (*u.min(v), *u.max(v));

                        if let (Some(&d1), Some(&d2), Some(&d3)) = (
                            edge_map.get(&edge1),
                            edge_map.get(&edge2),
                            edge_map.get(&edge3),
                        ) {
                            let max_dist = d1.max(d2).max(d3);

                            if max_dist <= max_distance {
                                let mut triangle = vec![*u, *v, w];
                                triangle.sort_unstable();

                                // Avoid duplicates by checking canonical form
                                if triangle[0] == *u.min(v) {
                                    local_triangles.push((triangle, max_dist));
                                }
                            }
                        }
                    }
                }
            }

            local_triangles
        })
        .collect();

    // Flatten and deduplicate
    let mut all_triangles: Vec<(Vec<usize>, f64)> = triangles.into_iter().flatten().collect();

    // Remove duplicates and sort
    all_triangles.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| a.1.partial_cmp(&b.1).unwrap()));
    all_triangles.dedup_by(|a, b| a.0 == b.0);

    // Sort by filtration value
    all_triangles.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    all_triangles
}

/// Parallel sparse matrix operations
pub struct ParallelSparseMatrix {
    /// Number of rows
    pub nrows: usize,
    /// Number of columns
    pub ncols: usize,
    /// Column data with thread-safe access
    pub columns: Arc<Mutex<Vec<Vec<usize>>>>,
}

impl ParallelSparseMatrix {
    /// Create new parallel sparse matrix
    pub fn new(nrows: usize, ncols: usize) -> Self {
        Self {
            nrows,
            ncols,
            columns: Arc::new(Mutex::new(vec![Vec::new(); ncols])),
        }
    }

    /// Set entries in parallel
    pub fn set_entries_parallel(&self, entries: Vec<(usize, usize, u8)>) {
        let chunks: Vec<Vec<(usize, usize, u8)>> = entries
            .into_iter()
            .fold(HashMap::new(), |mut acc, (row, col, val)| {
                acc.entry(col)
                    .or_insert_with(Vec::new)
                    .push((row, col, val));
                acc
            })
            .into_values()
            .collect();

        chunks.into_par_iter().for_each(|chunk| {
            let columns = self.columns.clone();

            for (row, col, val) in chunk {
                if val != 0 {
                    let mut cols = columns.lock().unwrap();
                    if !cols[col].contains(&row) {
                        cols[col].push(row);
                        cols[col].sort_unstable();
                    }
                }
            }
        });
    }

    /// Parallel matrix reduction
    pub fn reduce_parallel(&self, chunk_size: Option<usize>) -> Result<Vec<(usize, usize)>> {
        let chunk_size = chunk_size.unwrap_or(100);
        let mut pairs = Vec::new();
        let mut pivot_to_column: HashMap<usize, usize> = HashMap::new();

        // Process columns in chunks (this is a simplified version)
        let column_chunks: Vec<Vec<usize>> = (0..self.ncols)
            .collect::<Vec<_>>()
            .chunks(chunk_size)
            .map(|chunk| chunk.to_vec())
            .collect();

        for chunk in column_chunks {
            // Process chunk sequentially for now (matrix reduction has dependencies)
            for col_idx in chunk {
                let columns_guard = self.columns.lock().unwrap();

                if let Some(col) = columns_guard.get(col_idx) {
                    if let Some(&pivot_row) = col.last() {
                        if let Some(&other_col) = pivot_to_column.get(&pivot_row) {
                            // Would need to perform column addition here
                            // This is simplified for the example
                        } else {
                            pivot_to_column.insert(pivot_row, col_idx);
                            pairs.push((pivot_row, col_idx));
                        }
                    }
                }
            }
        }

        Ok(pairs)
    }
}

/// Parallel persistent homology computation
pub fn compute_persistence_parallel(
    points: ArrayView2<f64>,
    maxdim: usize,
    threshold: f64,
    metric: &str,
    num_threads: Option<usize>,
) -> Result<HashMap<usize, Vec<(f64, f64)>>> {
    // Set thread pool size if specified
    if let Some(threads) = num_threads {
        rayon::ThreadPoolBuilder::new()
            .num_threads(threads)
            .build_global()
            .unwrap_or_else(|_| {
                // Thread pool already initialized, continue with existing one
            });
    }

    // 1. Parallel distance computation
    let distances = compute_distance_matrix_parallel(points, metric, None)?;

    // 2. Generate edges in parallel
    let mut edges = Vec::new();
    let n_points = points.nrows();

    for i in 0..n_points {
        for j in (i + 1)..n_points {
            let dist = distances[[i, j]];
            if dist <= threshold {
                edges.push(((i, j), dist));
            }
        }
    }

    edges.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    // 3. Generate triangles in parallel if needed
    let triangles = if maxdim >= 2 {
        generate_triangles_parallel(&edges, threshold, None)
    } else {
        vec![]
    };

    // 4. Compute persistence (using existing sequential algorithms for correctness)
    use crate::optimized_h2::compute_h0_h1_h2_from_distances;

    let result = compute_h0_h1_h2_from_distances(distances.view(), threshold)?;

    // Convert to expected format
    let mut persistence = HashMap::new();
    for (dim, intervals) in result {
        let pairs: Vec<(f64, f64)> = intervals
            .into_iter()
            .map(|interval| (interval[0], interval[1]))
            .collect();
        persistence.insert(dim, pairs);
    }

    Ok(persistence)
}

/// Get optimal number of threads for the current system
pub fn get_optimal_thread_count() -> usize {
    // Use 75% of available cores, leaving some for system processes
    (num_cpus::get() * 3 / 4).max(1)
}

/// Parallel performance statistics
#[derive(Debug)]
pub struct ParallelStats {
    pub num_threads: usize,
    pub distance_computation_time: f64,
    pub complex_construction_time: f64,
    pub matrix_reduction_time: f64,
    pub total_time: f64,
}

impl ParallelStats {
    pub fn new() -> Self {
        Self {
            num_threads: rayon::current_num_threads(),
            distance_computation_time: 0.0,
            complex_construction_time: 0.0,
            matrix_reduction_time: 0.0,
            total_time: 0.0,
        }
    }
}
