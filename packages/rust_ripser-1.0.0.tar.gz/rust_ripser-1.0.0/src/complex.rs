//! # Vietoris-Rips Complex Construction Module
//!
//! Efficient simplicial complex construction, with support for parallel optimization and memory-efficient data structures.

use anyhow::{anyhow, Result};
use ndarray::{Array2, ArrayView2};
#[cfg(feature = "rayon")]
use rayon::prelude::*;
use std::collections::{HashMap, HashSet};

/// A simplified implementation of the Vietoris-Rips complex.
#[derive(Debug, Clone)]
pub struct VietorisRipsComplex {
    /// Number of vertices.
    n_vertices: usize,
    /// Distance matrix.
    distance_matrix: Array2<f64>,
    /// Maximum edge length threshold.
    threshold: f64,
    /// Maximum dimension.
    max_dim: usize,
    /// List of edges (cached).
    edges: Vec<((usize, usize), f64)>,
}

impl VietorisRipsComplex {
    /// Constructs a new Vietoris-Rips complex.
    pub fn new(distance_matrix: ArrayView2<f64>, threshold: f64, max_dim: usize) -> Result<Self> {
        let n_vertices = distance_matrix.nrows();

        if distance_matrix.nrows() != distance_matrix.ncols() {
            return Err(anyhow!("Distance matrix must be square"));
        }

        let mut edges = Vec::new();

        // Build the edge list.
        for i in 0..n_vertices {
            for j in (i + 1)..n_vertices {
                let dist = distance_matrix[[i, j]];
                if dist <= threshold {
                    edges.push(((i, j), dist));
                }
            }
        }

        // Sort edges by distance.
        edges.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

        Ok(Self {
            n_vertices,
            distance_matrix: distance_matrix.to_owned(),
            threshold,
            max_dim,
            edges,
        })
    }

    /// Gets the number of vertices.
    pub fn n_vertices(&self) -> usize {
        self.n_vertices
    }

    /// Gets the edges and their filtration values.
    pub fn edges_with_filtration(&self) -> impl Iterator<Item = &((usize, usize), f64)> {
        self.edges.iter()
    }

    /// Gets simplices of a specific dimension.
    pub fn simplices_of_dimension(&self, dim: usize) -> Vec<Vec<usize>> {
        match dim {
            0 => (0..self.n_vertices).map(|i| vec![i]).collect(),
            1 => self.edges.iter().map(|((i, j), _)| vec![*i, *j]).collect(),
            2 => self.get_triangles(),
            3 => self.get_tetrahedra(),
            _ => vec![], // Higher dimensions are not yet supported.
        }
    }

    /// Gets the triangles (2-simplices).
    fn get_triangles(&self) -> Vec<Vec<usize>> {
        let mut triangles = Vec::new();

        // Build an adjacency list from the edges.
        let mut adjacency: HashMap<usize, Vec<usize>> = HashMap::new();
        for ((i, j), dist) in &self.edges {
            if *dist <= self.threshold {
                adjacency.entry(*i).or_default().push(*j);
                adjacency.entry(*j).or_default().push(*i);
            }
        }

        // Find triangles.
        for ((i, j), _) in &self.edges {
            if let Some(neighbors_i) = adjacency.get(i) {
                if let Some(neighbors_j) = adjacency.get(j) {
                    for &k in neighbors_i {
                        if k > *j && neighbors_j.contains(&k) {
                            // Check the maximum edge length of the triangle.
                            let dist_ik = self.distance_matrix[[*i, k]];
                            let dist_jk = self.distance_matrix[[*j, k]];
                            let max_dist = dist_ik.max(dist_jk).max(self.distance_matrix[[*i, *j]]);

                            if max_dist <= self.threshold {
                                triangles.push(vec![*i, *j, k]);
                            }
                        }
                    }
                }
            }
        }

        triangles
    }

    /// Gets the tetrahedra (3-simplices).
    fn get_tetrahedra(&self) -> Vec<Vec<usize>> {
        let mut tetrahedra = Vec::new();
        let triangles = self.get_triangles();

        // Build tetrahedra from triangles.
        for i in 0..triangles.len() {
            for j in (i + 1)..triangles.len() {
                let tri1 = &triangles[i];
                let tri2 = &triangles[j];

                // Check if two triangles share two vertices.
                let mut shared = Vec::new();
                let mut all_vertices = HashSet::new();

                for &v in tri1 {
                    all_vertices.insert(v);
                    if tri2.contains(&v) {
                        shared.push(v);
                    }
                }
                for &v in tri2 {
                    all_vertices.insert(v);
                }

                if shared.len() == 2 && all_vertices.len() == 4 {
                    let mut tet: Vec<usize> = all_vertices.into_iter().collect();
                    tet.sort();

                    // Check if all edges of the tetrahedron are within the threshold.
                    let mut valid = true;
                    for a in 0..4 {
                        for b in (a + 1)..4 {
                            if self.distance_matrix[[tet[a], tet[b]]] > self.threshold {
                                valid = false;
                                break;
                            }
                        }
                        if !valid {
                            break;
                        }
                    }

                    if valid {
                        tetrahedra.push(tet);
                    }
                }
            }
        }

        tetrahedra
    }

    /// Gets the pentachorons (4-simplices or 5-cells).
    fn get_pentachorons(&self) -> Vec<Vec<usize>> {
        let mut pentachorons = Vec::new();
        let tetrahedra = self.get_tetrahedra();

        // Build pentachorons from tetrahedra.
        for i in 0..tetrahedra.len() {
            for j in (i + 1)..tetrahedra.len() {
                let tet1 = &tetrahedra[i];
                let tet2 = &tetrahedra[j];

                // Check if two tetrahedra share three vertices (a face).
                let mut shared = Vec::new();
                let mut all_vertices = HashSet::new();

                for &v in tet1 {
                    all_vertices.insert(v);
                    if tet2.contains(&v) {
                        shared.push(v);
                    }
                }
                for &v in tet2 {
                    all_vertices.insert(v);
                }

                if shared.len() == 3 && all_vertices.len() == 5 {
                    let mut penta: Vec<usize> = all_vertices.into_iter().collect();
                    penta.sort();

                    // Check if all edges of the pentachoron are within the threshold.
                    let mut valid = true;
                    for a in 0..5 {
                        for b in (a + 1)..5 {
                            if self.distance_matrix[[penta[a], penta[b]]] > self.threshold {
                                valid = false;
                                break;
                            }
                        }
                        if !valid {
                            break;
                        }
                    }

                    if valid {
                        pentachorons.push(penta);
                    }
                }
            }
        }

        pentachorons
    }

    /// Gets the hexachorons (5-simplices or 6-cells).
    fn get_hexachorons(&self) -> Vec<Vec<usize>> {
        let mut hexachorons = Vec::new();
        let pentachorons = self.get_pentachorons();

        // Build hexachorons from pentachorons (computationally expensive).
        for i in 0..pentachorons.len() {
            for j in (i + 1)..pentachorons.len() {
                let penta1 = &pentachorons[i];
                let penta2 = &pentachorons[j];

                // Check if two pentachorons share four vertices (a tetrahedral face).
                let mut shared = Vec::new();
                let mut all_vertices = HashSet::new();

                for &v in penta1 {
                    all_vertices.insert(v);
                    if penta2.contains(&v) {
                        shared.push(v);
                    }
                }
                for &v in penta2 {
                    all_vertices.insert(v);
                }

                if shared.len() == 4 && all_vertices.len() == 6 {
                    let mut hexa: Vec<usize> = all_vertices.into_iter().collect();
                    hexa.sort();

                    // Check if all edges of the hexachoron are within the threshold.
                    let mut valid = true;
                    for a in 0..6 {
                        for b in (a + 1)..6 {
                            if self.distance_matrix[[hexa[a], hexa[b]]] > self.threshold {
                                valid = false;
                                break;
                            }
                        }
                        if !valid {
                            break;
                        }
                    }

                    if valid {
                        hexachorons.push(hexa);
                    }
                }
            }
        }

        hexachorons
    }

    /// Computes the boundary of a simplex.
    pub fn boundary_of_simplex(&self, simplex: &[usize]) -> Result<Vec<Vec<usize>>> {
        let dim = simplex.len();
        if dim == 0 {
            return Ok(vec![]);
        }

        let mut boundary = Vec::new();

        for i in 0..dim {
            let mut face = simplex.to_vec();
            face.remove(i);
            boundary.push(face);
        }

        Ok(boundary)
    }

    /// Gets the maximum possible dimension (for dynamic computation).
    pub fn get_max_possible_dimension(&self) -> usize {
        // Theoretically, the maximum dimension is n-1, but it's practically limited by the threshold.
        // Conservative estimate: compute up to min(6, n-1).
        (self.n_vertices - 1).min(6)
    }
}
