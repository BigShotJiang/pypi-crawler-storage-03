//! Simple and direct H1 computation using standard boundary matrix reduction
//!
//! This is a simplified but correct implementation that follows the classic
//! persistent homology algorithm, prioritizing correctness over performance.

use crate::complex::VietorisRipsComplex;
use crate::matrix_reduction::SparseMatrix;
use crate::union_find::UnionFind;
use anyhow::Result;
use ndarray::ArrayView2;
use std::collections::HashMap;

/// Edge with filtration time
#[derive(Debug, Clone)]
pub struct Edge {
    pub u: usize,
    pub v: usize,
    pub filtration: f64,
}

/// Triangle with filtration time
#[derive(Debug, Clone)]
pub struct Triangle {
    pub vertices: [usize; 3],
    pub filtration: f64,
}

/// Simple H1 computer using standard boundary matrix reduction
pub struct SimpleH1Computer {
    complex: VietorisRipsComplex,
    threshold: f64,
}

impl SimpleH1Computer {
    pub fn new(points: ArrayView2<f64>, threshold: f64) -> Result<Self> {
        // First compute distance matrix from points
        use crate::distance::compute_distance_matrix_rust;
        let distance_matrix = compute_distance_matrix_rust(points, "euclidean")?;

        // Build complex with maxdim=2 to get triangles for proper H1 computation
        let complex = VietorisRipsComplex::new(distance_matrix.view(), threshold, 2)?;

        Ok(Self { complex, threshold })
    }

    /// Compute H0 and H1 using standard algorithms
    pub fn compute_h0_h1(&self) -> Result<(Vec<(f64, f64)>, Vec<(f64, f64)>)> {
        // H0 computation using Union-Find
        let h0_pairs = self.compute_h0()?;

        // H1 computation using boundary matrix reduction
        let h1_pairs = self.compute_h1()?;

        Ok((h0_pairs, h1_pairs))
    }

    /// H0 computation using Union-Find (this is already correct)
    fn compute_h0(&self) -> Result<Vec<(f64, f64)>> {
        let mut uf = UnionFind::new(self.complex.n_vertices());
        let mut pairs = Vec::new();

        // Get all edges sorted by filtration time
        let mut edges: Vec<_> = self
            .complex
            .edges_with_filtration()
            .map(|((u, v), filtration)| Edge {
                u: *u,
                v: *v,
                filtration: *filtration,
            })
            .collect();
        edges.sort_by(|a, b| a.filtration.partial_cmp(&b.filtration).unwrap());

        // Track component birth times
        let mut birth_times = vec![0.0; self.complex.n_vertices()];

        for edge in edges {
            let root_u = uf.find(edge.u);
            let root_v = uf.find(edge.v);

            if root_u != root_v {
                // Determine which component dies
                let (older_root, younger_root) = if birth_times[root_u] <= birth_times[root_v] {
                    (root_u, root_v)
                } else {
                    (root_v, root_u)
                };

                // Record death of younger component
                pairs.push((birth_times[younger_root], edge.filtration));

                // Merge components
                uf.union_simple(edge.u, edge.v);
                let new_root = uf.find(edge.u);
                birth_times[new_root] = birth_times[older_root];
            }
        }

        // Add surviving components (infinite intervals)
        let mut roots = std::collections::HashSet::new();
        for i in 0..self.complex.n_vertices() {
            roots.insert(uf.find(i));
        }
        for &root in &roots {
            pairs.push((birth_times[root], f64::INFINITY));
        }

        Ok(pairs)
    }

    /// H1 computation using standard boundary matrix reduction
    fn compute_h1(&self) -> Result<Vec<(f64, f64)>> {
        // Get edges and triangles
        let edges = self.get_edges();
        let triangles = self.get_triangles();

        if triangles.is_empty() {
            // No triangles means no H1 death events
            // This is the case when maxdim=1
            return Ok(Vec::new());
        }

        // Build boundary matrix: triangles -> edges
        let boundary_matrix = self.build_boundary_matrix(&edges, &triangles)?;

        // Perform matrix reduction
        let h1_pairs = self.reduce_boundary_matrix(boundary_matrix, &edges, &triangles)?;

        Ok(h1_pairs)
    }

    /// Get all edges with filtration times
    fn get_edges(&self) -> Vec<Edge> {
        let mut edges: Vec<_> = self
            .complex
            .edges_with_filtration()
            .map(|((u, v), filtration)| Edge {
                u: *u,
                v: *v,
                filtration: *filtration,
            })
            .collect();
        edges.sort_by(|a, b| a.filtration.partial_cmp(&b.filtration).unwrap());
        edges
    }

    /// Get all triangles with filtration times
    fn get_triangles(&self) -> Vec<Triangle> {
        let triangles_vertices = self.complex.simplices_of_dimension(2);
        let mut triangles = Vec::new();

        for vertices in triangles_vertices {
            if vertices.len() == 3 {
                let filtration = self.compute_triangle_filtration(&vertices);
                if filtration <= self.threshold {
                    triangles.push(Triangle {
                        vertices: [vertices[0], vertices[1], vertices[2]],
                        filtration,
                    });
                }
            }
        }

        // Sort by filtration time
        triangles.sort_by(|a, b| a.filtration.partial_cmp(&b.filtration).unwrap());
        triangles
    }

    /// Compute triangle filtration (max of edge distances)
    fn compute_triangle_filtration(&self, vertices: &[usize]) -> f64 {
        if vertices.len() != 3 {
            return f64::INFINITY;
        }

        let mut max_dist = 0.0f64;
        for i in 0..3 {
            for j in (i + 1)..3 {
                // Find this edge in our edges list
                for ((u, v), dist) in self.complex.edges_with_filtration() {
                    if (vertices[i] == *u && vertices[j] == *v)
                        || (vertices[i] == *v && vertices[j] == *u)
                    {
                        max_dist = max_dist.max(*dist);
                        break;
                    }
                }
            }
        }
        max_dist
    }

    /// Build boundary matrix from triangles to edges
    fn build_boundary_matrix(
        &self,
        edges: &[Edge],
        triangles: &[Triangle],
    ) -> Result<SparseMatrix> {
        let n_edges = edges.len();
        let n_triangles = triangles.len();

        let mut matrix = SparseMatrix::new(n_edges, n_triangles);

        // For each triangle (column), find its boundary edges (rows)
        for (tri_idx, triangle) in triangles.iter().enumerate() {
            let [v0, v1, v2] = triangle.vertices;

            // The boundary of triangle (v0,v1,v2) consists of edges (v0,v1), (v0,v2), (v1,v2)
            let boundary_edges = [
                (v0.min(v1), v0.max(v1)),
                (v0.min(v2), v0.max(v2)),
                (v1.min(v2), v1.max(v2)),
            ];

            // Find these edges in our edge list and set matrix entries
            for &(u, v) in &boundary_edges {
                for (edge_idx, edge) in edges.iter().enumerate() {
                    let edge_pair = (edge.u.min(edge.v), edge.u.max(edge.v));
                    if edge_pair == (u, v) {
                        matrix.set_entry(edge_idx, tri_idx, 1);
                        break;
                    }
                }
            }
        }

        Ok(matrix)
    }

    /// Reduce boundary matrix to find persistence pairs
    fn reduce_boundary_matrix(
        &self,
        mut matrix: SparseMatrix,
        edges: &[Edge],
        triangles: &[Triangle],
    ) -> Result<Vec<(f64, f64)>> {
        let mut pairs = Vec::new();
        let mut lowest_ones = vec![None; matrix.n_cols()];

        // Standard matrix reduction algorithm
        for col in 0..matrix.n_cols() {
            loop {
                if let Some(pivot_row) = matrix.lowest_one_in_column(col) {
                    if let Some(other_col) = lowest_ones.get(pivot_row).copied().flatten() {
                        // Clear: add other_col to col
                        matrix.add_column(other_col, col);
                    } else {
                        // Found new persistence pair
                        if pivot_row >= lowest_ones.len() {
                            lowest_ones.resize(pivot_row + 1, None);
                        }
                        lowest_ones[pivot_row] = Some(col);

                        // Get filtration times
                        let birth_time = edges.get(pivot_row).map(|e| e.filtration).unwrap_or(0.0);
                        let death_time = triangles.get(col).map(|t| t.filtration).unwrap_or(0.0);

                        if birth_time < death_time {
                            pairs.push((birth_time, death_time));
                        }
                        break;
                    }
                } else {
                    // No pivot in this column
                    break;
                }
            }
        }

        Ok(pairs)
    }
}

/// High-level interface for simple H0+H1 computation
pub fn compute_h0_h1_simple(
    points: ArrayView2<f64>,
    threshold: f64,
) -> Result<HashMap<usize, Vec<(f64, f64)>>> {
    let computer = SimpleH1Computer::new(points, threshold)?;
    let (h0_pairs, h1_pairs) = computer.compute_h0_h1()?;

    let mut result = HashMap::new();
    result.insert(0, h0_pairs);
    result.insert(1, h1_pairs);

    Ok(result)
}
