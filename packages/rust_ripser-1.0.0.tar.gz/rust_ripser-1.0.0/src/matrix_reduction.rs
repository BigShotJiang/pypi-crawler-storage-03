//! # Matrix Reduction Module - Based on Ripser++ Optimizations
//!
//! Implements the core optimization algorithms of Ripser++:
//! 1. Apparent pairs optimization
//! 2. Clearing optimization
//! 3. Cohomology algorithm
//! 4. Emergency optimization

#[cfg(feature = "rayon")]
use rayon::prelude::*;

/// Sparse matrix representation (used for boundary matrices).
#[derive(Debug, Clone)]
pub struct SparseMatrix {
    /// Number of rows.
    pub nrows: usize,
    /// Number of columns.
    pub ncols: usize,
    /// Column storage: non-zero row indices for each column.
    pub columns: Vec<Vec<usize>>,
    /// Row storage: non-zero column indices for each row (used for cohomology).
    pub rows: Vec<Vec<usize>>,
}

impl SparseMatrix {
    /// Creates a new sparse matrix.
    pub fn new(nrows: usize, ncols: usize) -> Self {
        Self {
            nrows,
            ncols,
            columns: vec![Vec::new(); ncols],
            rows: vec![Vec::new(); nrows],
        }
    }

    /// Sets a matrix entry.
    pub fn set_entry(&mut self, row: usize, col: usize, value: u8) {
        if value != 0 {
            // Add to the column.
            if !self.columns[col].contains(&row) {
                self.columns[col].push(row);
                self.columns[col].sort_unstable();
            }

            // Add to the row.
            if !self.rows[row].contains(&col) {
                self.rows[row].push(col);
                self.rows[row].sort_unstable();
            }
        }
    }

    /// Gets the position of the lowest 1 in a column.
    pub fn lowest_one_in_column(&self, col: usize) -> Option<usize> {
        self.columns.get(col)?.last().copied()
    }

    /// Adds one column to another (mod 2).
    pub fn add_column(&mut self, source_col: usize, target_col: usize) {
        if source_col >= self.ncols || target_col >= self.ncols {
            return;
        }

        let source_entries = self.columns[source_col].clone();
        let mut target_entries = self.columns[target_col].clone();

        // Symmetric difference (XOR operation for mod 2).
        for &row in &source_entries {
            if let Some(pos) = target_entries.iter().position(|&x| x == row) {
                target_entries.remove(pos);
            } else {
                target_entries.push(row);
                target_entries.sort_unstable();
            }
        }

        self.columns[target_col] = target_entries;
    }

    /// Gets the number of columns in the matrix.
    pub fn n_cols(&self) -> usize {
        self.ncols
    }
}
