//! # Distance Calculation Module
//!
//! High-performance distance matrix computation with support for multiple metrics and parallel optimization

use anyhow::{anyhow, Result};
use ndarray::{Array2, ArrayView2, Axis};
#[cfg(feature = "rayon")]
use rayon::prelude::*;

/// Supported distance metric types
#[derive(Debug, Clone, Copy)]
pub enum DistanceMetric {
    Euclidean,
    Manhattan,
    Cosine,
    Chebyshev,
    Minkowski(f64), // p-parameter for Minkowski distance
    Hamming,
    Jaccard,
    Precomputed,
}

impl DistanceMetric {
    pub fn from_str(s: &str) -> Result<Self> {
        match s.to_lowercase().as_str() {
            "euclidean" => Ok(DistanceMetric::Euclidean),
            "manhattan" | "l1" => Ok(DistanceMetric::Manhattan),
            "cosine" => Ok(DistanceMetric::Cosine),
            "chebyshev" | "linf" => Ok(DistanceMetric::Chebyshev),
            "minkowski" => Ok(DistanceMetric::Minkowski(2.0)), // Default p=2
            "hamming" => Ok(DistanceMetric::Hamming),
            "jaccard" => Ok(DistanceMetric::Jaccard),
            "precomputed" => Ok(DistanceMetric::Precomputed),
            _ => {
                // Try to parse Minkowski with custom p
                if s.starts_with("minkowski") && s.contains('(') {
                    if let Some(p_str) = s
                        .strip_prefix("minkowski(")
                        .and_then(|s| s.strip_suffix(')'))
                    {
                        if let Ok(p) = p_str.parse::<f64>() {
                            return Ok(DistanceMetric::Minkowski(p));
                        }
                    }
                }
                Err(anyhow!("Unsupported distance metric: {}", s))
            }
        }
    }
}

/// Main distance matrix computation function
pub fn compute_distance_matrix_rust(points: ArrayView2<f64>, metric: &str) -> Result<Array2<f64>> {
    let metric_enum = DistanceMetric::from_str(metric)?;

    // Handle precomputed distance matrix
    if matches!(metric_enum, DistanceMetric::Precomputed) {
        return validate_and_process_precomputed_matrix(points);
    }

    let n_points = points.nrows();

    // Choose computation strategy based on data size
    if n_points <= 50 {
        // Small dataset: simple serial computation
        compute_distance_matrix_serial(points, metric_enum)
    } else if n_points <= 500 {
        // Medium dataset: parallel computation
        compute_distance_matrix_parallel(points, metric_enum)
    } else {
        // Large dataset: chunked parallel computation
        compute_distance_matrix_chunked(points, metric_enum)
    }
}

/// Validate and process precomputed distance matrix
fn validate_and_process_precomputed_matrix(matrix: ArrayView2<f64>) -> Result<Array2<f64>> {
    let n = matrix.nrows();
    let m = matrix.ncols();

    // Verify matrix is square
    if n != m {
        return Err(anyhow!(
            "Precomputed distance matrix must be square, got {}x{}",
            n,
            m
        ));
    }

    // Verify diagonal elements are 0
    for i in 0..n {
        if matrix[[i, i]].abs() > 1e-10 {
            return Err(anyhow!(
                "Diagonal element at ({}, {}) is {}, should be 0",
                i,
                i,
                matrix[[i, i]]
            ));
        }
    }

    // Verify matrix symmetry
    for i in 0..n {
        for j in i + 1..n {
            let diff = (matrix[[i, j]] - matrix[[j, i]]).abs();
            if diff > 1e-10 {
                return Err(anyhow!(
                    "Matrix not symmetric at ({}, {}): {} vs {}",
                    i,
                    j,
                    matrix[[i, j]],
                    matrix[[j, i]]
                ));
            }
        }
    }

    // Verify non-negativity
    for i in 0..n {
        for j in 0..n {
            if matrix[[i, j]] < -1e-10 {
                return Err(anyhow!(
                    "Negative distance at ({}, {}): {}",
                    i,
                    j,
                    matrix[[i, j]]
                ));
            }
        }
    }

    // Verify triangle inequality (optional, but important for distance matrices)
    // Since this is O(n³) operation, it may be slow for large matrices, so only verify for small matrices
    if n <= 100 {
        for i in 0..n {
            for j in 0..n {
                for k in 0..n {
                    let direct = matrix[[i, j]];
                    let indirect = matrix[[i, k]] + matrix[[k, j]];
                    if direct > indirect + 1e-10 {
                        return Err(anyhow!(
                            "Triangle inequality violated: d({}, {}) = {} > d({}, {}) + d({}, {}) = {} + {} = {}",
                            i, j, direct, i, k, k, j, matrix[[i, k]], matrix[[k, j]], indirect
                        ));
                    }
                }
            }
        }
    }

    // Return copied matrix
    Ok(matrix.to_owned())
}

/// Serial distance matrix computation (small datasets)
fn compute_distance_matrix_serial(
    points: ArrayView2<f64>,
    metric: DistanceMetric,
) -> Result<Array2<f64>> {
    let n = points.nrows();
    let mut distances = Array2::<f64>::zeros((n, n));

    for i in 0..n {
        for j in i..n {
            if i == j {
                distances[[i, j]] = 0.0;
            } else {
                let dist = compute_distance_pair(points.row(i), points.row(j), metric);
                distances[[i, j]] = dist;
                distances[[j, i]] = dist; // Symmetric matrix
            }
        }
    }

    Ok(distances)
}

/// Parallel distance matrix computation (medium datasets)
fn compute_distance_matrix_parallel(
    points: ArrayView2<f64>,
    metric: DistanceMetric,
) -> Result<Array2<f64>> {
    let n = points.nrows();
    let mut distances = Array2::<f64>::zeros((n, n));

    // Create upper triangular index pairs
    let indices: Vec<(usize, usize)> = (0..n).flat_map(|i| (i..n).map(move |j| (i, j))).collect();

    // Calculate distances
    #[cfg(feature = "rayon")]
    let dist_values: Vec<f64> = indices
        .par_iter()
        .map(|&(i, j)| {
            if i == j {
                0.0
            } else {
                compute_distance_pair(points.row(i), points.row(j), metric)
            }
        })
        .collect();

    #[cfg(not(feature = "rayon"))]
    let dist_values: Vec<f64> = indices
        .iter()
        .map(|&(i, j)| {
            if i == j {
                0.0
            } else {
                compute_distance_pair(points.row(i), points.row(j), metric)
            }
        })
        .collect();

    // Fill distance matrix
    for ((i, j), dist) in indices.iter().zip(dist_values.iter()) {
        distances[[*i, *j]] = *dist;
        if *i != *j {
            distances[[*j, *i]] = *dist;
        }
    }

    Ok(distances)
}

/// Chunked parallel distance matrix computation (large datasets)
fn compute_distance_matrix_chunked(
    points: ArrayView2<f64>,
    metric: DistanceMetric,
) -> Result<Array2<f64>> {
    let n = points.nrows();
    let mut distances = Array2::<f64>::zeros((n, n));

    // Calculate appropriate chunk size
    #[cfg(feature = "rayon")]
    let chunk_size = std::cmp::max(32, std::cmp::min(128, n / rayon::current_num_threads()));

    #[cfg(not(feature = "rayon"))]
    let chunk_size = std::cmp::max(32, std::cmp::min(128, n / 4));

    // Process by row chunks
    #[cfg(feature = "rayon")]
    {
        distances
            .axis_chunks_iter_mut(Axis(0), chunk_size)
            .enumerate()
            .par_bridge()
            .for_each(|(chunk_idx, chunk)| {
                process_chunk(chunk_idx, chunk, &points, metric, n);
            });
    }

    #[cfg(not(feature = "rayon"))]
    {
        for (chunk_idx, chunk) in distances
            .axis_chunks_iter_mut(Axis(0), chunk_size)
            .enumerate()
        {
            process_chunk(chunk_idx, chunk, &points, metric, n);
        }
    }

    // Fill lower triangle (using symmetry)
    for i in 0..n {
        for j in 0..i {
            distances[[i, j]] = distances[[j, i]];
        }
    }

    Ok(distances)
}

/// Process one chunk of the distance matrix
fn process_chunk(
    chunk_idx: usize,
    mut chunk: ndarray::ArrayViewMut2<f64>,
    points: &ArrayView2<f64>,
    metric: DistanceMetric,
    n: usize,
) {
    let chunk_size = chunk.nrows();
    let start_i = chunk_idx * chunk_size;

    for (local_i, mut row) in chunk.axis_iter_mut(Axis(0)).enumerate() {
        let global_i = start_i + local_i;
        if global_i >= n {
            break;
        }

        for j in 0..n {
            if global_i == j {
                row[j] = 0.0;
            } else if global_i < j {
                // Only calculate upper triangle
                let dist = compute_distance_pair(points.row(global_i), points.row(j), metric);
                row[j] = dist;
            } else {
                // Lower triangle copied from already calculated upper triangle
                row[j] = 0.0; // Temporary value, will be set correctly later
            }
        }
    }
}

/// Calculate distance between two points
#[inline]
fn compute_distance_pair(
    point1: ndarray::ArrayView1<f64>,
    point2: ndarray::ArrayView1<f64>,
    metric: DistanceMetric,
) -> f64 {
    match metric {
        DistanceMetric::Euclidean => euclidean_distance(point1, point2),
        DistanceMetric::Manhattan => manhattan_distance(point1, point2),
        DistanceMetric::Cosine => cosine_distance(point1, point2),
        DistanceMetric::Chebyshev => chebyshev_distance(point1, point2),
        DistanceMetric::Minkowski(p) => minkowski_distance(point1, point2, p),
        DistanceMetric::Hamming => hamming_distance(point1, point2),
        DistanceMetric::Jaccard => jaccard_distance(point1, point2),
        DistanceMetric::Precomputed => {
            panic!("Precomputed metric should not reach this function")
        }
    }
}

/// Euclidean distance (optimized version)
#[inline]
fn euclidean_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>) -> f64 {
    let mut sum_sq = 0.0;

    // Manual loop unrolling for performance improvement
    let len = p1.len();
    let mut i = 0;

    // 4-way unrolling
    while i + 4 <= len {
        let d1 = p1[i] - p2[i];
        let d2 = p1[i + 1] - p2[i + 1];
        let d3 = p1[i + 2] - p2[i + 2];
        let d4 = p1[i + 3] - p2[i + 3];

        sum_sq += d1 * d1 + d2 * d2 + d3 * d3 + d4 * d4;
        i += 4;
    }

    // Handle remaining elements
    while i < len {
        let diff = p1[i] - p2[i];
        sum_sq += diff * diff;
        i += 1;
    }

    sum_sq.sqrt()
}

/// Manhattan distance
#[inline]
fn manhattan_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>) -> f64 {
    p1.iter().zip(p2.iter()).map(|(a, b)| (a - b).abs()).sum()
}

/// Cosine distance
#[inline]
fn cosine_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>) -> f64 {
    let dot_product: f64 = p1.iter().zip(p2.iter()).map(|(a, b)| a * b).sum();
    let norm1: f64 = p1.iter().map(|x| x * x).sum::<f64>().sqrt();
    let norm2: f64 = p2.iter().map(|x| x * x).sum::<f64>().sqrt();

    if norm1 == 0.0 || norm2 == 0.0 {
        1.0 // Maximum distance
    } else {
        1.0 - (dot_product / (norm1 * norm2))
    }
}

/// Chebyshev distance (L∞ distance)
#[inline]
fn chebyshev_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>) -> f64 {
    p1.iter()
        .zip(p2.iter())
        .map(|(a, b)| (a - b).abs())
        .fold(0.0, f64::max)
}

/// Minkowski distance (Lp norm)
#[inline]
fn minkowski_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>, p: f64) -> f64 {
    if p == 1.0 {
        manhattan_distance(p1, p2)
    } else if p == 2.0 {
        euclidean_distance(p1, p2)
    } else if p.is_infinite() {
        chebyshev_distance(p1, p2)
    } else {
        p1.iter()
            .zip(p2.iter())
            .map(|(a, b)| (a - b).abs().powf(p))
            .sum::<f64>()
            .powf(1.0 / p)
    }
}

/// Hamming distance (for binary data)
#[inline]
fn hamming_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>) -> f64 {
    p1.iter()
        .zip(p2.iter())
        .map(|(a, b)| {
            if (a - b).abs() > f64::EPSILON {
                1.0
            } else {
                0.0
            }
        })
        .sum()
}

/// Jaccard distance (for binary data)
#[inline]
fn jaccard_distance(p1: ndarray::ArrayView1<f64>, p2: ndarray::ArrayView1<f64>) -> f64 {
    let mut intersection = 0.0;
    let mut union = 0.0;

    for (a, b) in p1.iter().zip(p2.iter()) {
        let a_bool = *a > f64::EPSILON;
        let b_bool = *b > f64::EPSILON;

        if a_bool && b_bool {
            intersection += 1.0;
        }
        if a_bool || b_bool {
            union += 1.0;
        }
    }

    if union == 0.0 {
        0.0
    } else {
        1.0 - (intersection / union)
    }
}

/// Batch distance calculation (for specific optimization scenarios)
pub fn compute_distances_to_point(
    points: ArrayView2<f64>,
    target_point: ndarray::ArrayView1<f64>,
    metric: DistanceMetric,
) -> Vec<f64> {
    #[cfg(feature = "rayon")]
    {
        let point_rows: Vec<_> = points.axis_iter(Axis(0)).collect();
        point_rows
            .par_iter()
            .map(|point| compute_distance_pair(*point, target_point, metric))
            .collect()
    }

    #[cfg(not(feature = "rayon"))]
    {
        points
            .axis_iter(Axis(0))
            .map(|point| compute_distance_pair(point, target_point, metric))
            .collect()
    }
}

/// Calculate k-nearest neighbor distances (for threshold estimation)
pub fn compute_knn_distances(points: ArrayView2<f64>, k: usize, metric: &str) -> Result<Vec<f64>> {
    let metric_enum = DistanceMetric::from_str(metric)?;
    let n = points.nrows();

    if k >= n {
        return Err(anyhow!(
            "k ({}) must be less than number of points ({})",
            k,
            n
        ));
    }

    #[cfg(feature = "rayon")]
    let knn_distances: Vec<f64> = (0..n)
        .into_par_iter()
        .map(|i| {
            let mut distances: Vec<f64> = (0..n)
                .filter(|&j| i != j)
                .map(|j| compute_distance_pair(points.row(i), points.row(j), metric_enum))
                .collect();

            distances.sort_by(|a, b| a.partial_cmp(b).unwrap());
            distances[k - 1] // k-th nearest neighbor distance
        })
        .collect();

    #[cfg(not(feature = "rayon"))]
    let knn_distances: Vec<f64> = (0..n)
        .map(|i| {
            let mut distances: Vec<f64> = (0..n)
                .filter(|&j| i != j)
                .map(|j| compute_distance_pair(points.row(i), points.row(j), metric_enum))
                .collect();

            distances.sort_by(|a, b| a.partial_cmp(b).unwrap());
            distances[k - 1] // k-th nearest neighbor distance
        })
        .collect();

    Ok(knn_distances)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ndarray::Array;

    #[test]
    fn test_euclidean_distance() {
        let p1 = Array::from_vec(vec![0.0, 0.0]);
        let p2 = Array::from_vec(vec![3.0, 4.0]);

        let dist = euclidean_distance(p1.view(), p2.view());
        assert!((dist - 5.0).abs() < 1e-10);
    }

    #[test]
    fn test_distance_matrix_symmetry() {
        let points = Array::from_shape_vec((3, 2), vec![0.0, 0.0, 1.0, 0.0, 0.0, 1.0]).unwrap();

        let distances = compute_distance_matrix_rust(points.view(), "euclidean").unwrap();

        // Check symmetry
        for i in 0..3 {
            for j in 0..3 {
                assert!((distances[[i, j]] - distances[[j, i]]).abs() < 1e-10);
            }
        }

        // Check diagonal is 0
        for i in 0..3 {
            assert!(distances[[i, i]].abs() < 1e-10);
        }
    }
}
