//! # Cocycles Computation Module
//!
//! Implements cocycle representation for persistent homology,
//! providing compatible output with the original ripser library.

use crate::complex::VietorisRipsComplex;
use crate::matrix_reduction::SparseMatrix;
use anyhow::Result;
use std::collections::HashMap;

/// Represents a cocycle with its coefficients and representative elements
#[derive(Debug, Clone)]
pub struct Cocycle {
    /// Birth time of the cocycle
    pub birth: f64,
    /// Death time of the cocycle (if finite)
    pub death: Option<f64>,
    /// Dimension of the cocycle
    pub dimension: usize,
    /// Representative elements with coefficients (mod 2)
    /// Maps simplex index to coefficient (always 1 in Z/2Z)
    pub representatives: Vec<usize>,
}

impl Cocycle {
    pub fn new(birth: f64, death: Option<f64>, dimension: usize) -> Self {
        Self {
            birth,
            death,
            dimension,
            representatives: Vec::new(),
        }
    }

    pub fn add_representative(&mut self, simplex_idx: usize) {
        if !self.representatives.contains(&simplex_idx) {
            self.representatives.push(simplex_idx);
            self.representatives.sort_unstable();
        }
    }
}

/// Cocycle computer that implements the cohomology algorithm
/// to compute representative cocycles for persistent homology classes
pub struct CocycleComputer {
    complex: VietorisRipsComplex,
    threshold: f64,
    /// Stores cocycles by dimension
    cocycles: HashMap<usize, Vec<Cocycle>>,
}

impl CocycleComputer {
    pub fn new(complex: VietorisRipsComplex, threshold: f64) -> Self {
        Self {
            complex,
            threshold,
            cocycles: HashMap::new(),
        }
    }

    /// Compute cocycles for H1 using the cohomology algorithm
    pub fn compute_h1_cocycles(&mut self) -> Result<Vec<Cocycle>> {
        // Get edges and triangles sorted by filtration value
        let edges = self.get_sorted_edges();
        let triangles = self.get_sorted_triangles();

        if triangles.is_empty() {
            // No triangles means no H1 death events, all edges create infinite cocycles
            let mut cocycles = Vec::new();
            for (edge, birth_time) in edges {
                let mut cocycle = Cocycle::new(birth_time, None, 1);
                // Find edge index for representative
                if let Some(edge_idx) = self.find_edge_index(&edge) {
                    cocycle.add_representative(edge_idx);
                }
                cocycles.push(cocycle);
            }
            return Ok(cocycles);
        }

        // Create edge index mapping
        let mut edge_to_index = HashMap::new();
        for (i, (edge, _)) in edges.iter().enumerate() {
            edge_to_index.insert(*edge, i);
        }

        // Build coboundary matrix: rows = triangles, cols = edges
        let n_edges = edges.len();
        let n_triangles = triangles.len();
        let mut coboundary_matrix = SparseMatrix::new(n_triangles, n_edges);

        // Fill coboundary matrix (transpose of boundary matrix)
        for (tri_idx, (triangle, _)) in triangles.iter().enumerate() {
            let triangle_edges = self.get_triangle_edges(triangle);

            for tri_edge in triangle_edges {
                if let Some(&edge_idx) = edge_to_index.get(&tri_edge) {
                    coboundary_matrix.set_entry(tri_idx, edge_idx, 1);
                }
            }
        }

        // Perform cohomology reduction to find cocycles
        let cocycles = self.reduce_cohomology_matrix(coboundary_matrix, &edges, &triangles)?;

        self.cocycles.insert(1, cocycles.clone());
        Ok(cocycles)
    }

    /// Cohomology reduction algorithm
    fn reduce_cohomology_matrix(
        &self,
        mut matrix: SparseMatrix,
        edges: &[((usize, usize), f64)],
        triangles: &[(Vec<usize>, f64)],
    ) -> Result<Vec<Cocycle>> {
        let mut cocycles = Vec::new();
        let mut pivot_to_edge: HashMap<usize, usize> = HashMap::new();
        let mut edge_to_cocycle: HashMap<usize, Vec<usize>> = HashMap::new();

        // Initialize edge cocycles (each edge starts as its own cocycle)
        for edge_idx in 0..edges.len() {
            edge_to_cocycle.insert(edge_idx, vec![edge_idx]);
        }

        // Process triangles in order of filtration value
        let mut triangle_order: Vec<usize> = (0..triangles.len()).collect();
        triangle_order.sort_by(|&a, &b| triangles[a].1.partial_cmp(&triangles[b].1).unwrap());

        for &tri_idx in &triangle_order {
            // Reduce this row (triangle)
            loop {
                // Find the rightmost non-zero entry (pivot) in this row
                let mut pivot_col = None;
                if let Some(row_entries) = matrix.rows.get(tri_idx) {
                    pivot_col = row_entries.last().copied();
                }

                if let Some(pivot) = pivot_col {
                    if let Some(&other_tri) = pivot_to_edge.get(&pivot) {
                        // Add other row to this row (Z/2Z arithmetic)
                        self.add_rows(&mut matrix, other_tri, tri_idx);

                        // Update cocycle representatives
                        if let (Some(current_rep), Some(other_rep)) = (
                            edge_to_cocycle.get(&pivot).cloned(),
                            edge_to_cocycle.get(&pivot).cloned(),
                        ) {
                            let mut combined_rep = current_rep.clone();
                            for &edge_idx in &other_rep {
                                if let Some(pos) = combined_rep.iter().position(|&x| x == edge_idx)
                                {
                                    combined_rep.remove(pos);
                                } else {
                                    combined_rep.push(edge_idx);
                                }
                            }
                            combined_rep.sort_unstable();
                            edge_to_cocycle.insert(pivot, combined_rep);
                        }
                    } else {
                        // This is a death event - create finite cocycle
                        pivot_to_edge.insert(pivot, tri_idx);

                        let birth_time = edges[pivot].1;
                        let death_time = triangles[tri_idx].1;

                        if birth_time < death_time {
                            let mut cocycle = Cocycle::new(birth_time, Some(death_time), 1);

                            // Add representative edges
                            if let Some(representatives) = edge_to_cocycle.get(&pivot) {
                                for &edge_idx in representatives {
                                    cocycle.add_representative(edge_idx);
                                }
                            }

                            cocycles.push(cocycle);
                        }
                        break;
                    }
                } else {
                    // Row is zero, no more reduction needed
                    break;
                }
            }
        }

        // Add infinite cocycles for unpaired edges
        for (edge_idx, (_, birth_time)) in edges.iter().enumerate() {
            if !pivot_to_edge.values().any(|&tri_idx| {
                // Check if this edge was killed by any triangle
                matrix
                    .rows
                    .get(tri_idx)
                    .map_or(false, |row| row.contains(&edge_idx))
            }) {
                let mut cocycle = Cocycle::new(*birth_time, None, 1);
                if let Some(representatives) = edge_to_cocycle.get(&edge_idx) {
                    for &rep_edge_idx in representatives {
                        cocycle.add_representative(rep_edge_idx);
                    }
                }
                cocycles.push(cocycle);
            }
        }

        // Sort cocycles by birth time
        cocycles.sort_by(|a, b| a.birth.partial_cmp(&b.birth).unwrap());

        Ok(cocycles)
    }

    /// Add one row to another in the sparse matrix (Z/2Z arithmetic)
    fn add_rows(&self, matrix: &mut SparseMatrix, source_row: usize, target_row: usize) {
        if source_row >= matrix.nrows || target_row >= matrix.nrows {
            return;
        }

        let source_entries = matrix.rows[source_row].clone();
        let mut target_entries = matrix.rows[target_row].clone();

        // Symmetric difference (XOR for mod 2)
        for &col in &source_entries {
            if let Some(pos) = target_entries.iter().position(|&x| x == col) {
                target_entries.remove(pos);
            } else {
                target_entries.push(col);
                target_entries.sort_unstable();
            }
        }

        matrix.rows[target_row] = target_entries;

        // Update column representation as well
        for col in 0..matrix.ncols {
            let source_has = source_entries.contains(&col);
            let target_has = matrix.columns[col].contains(&target_row);

            if source_has != target_has {
                if target_has {
                    matrix.columns[col].retain(|&x| x != target_row);
                } else {
                    matrix.columns[col].push(target_row);
                    matrix.columns[col].sort_unstable();
                }
            }
        }
    }

    /// Get the three edges of a triangle
    fn get_triangle_edges(&self, triangle: &[usize]) -> Vec<(usize, usize)> {
        if triangle.len() != 3 {
            return vec![];
        }

        let mut edges = vec![
            (triangle[0].min(triangle[1]), triangle[0].max(triangle[1])),
            (triangle[0].min(triangle[2]), triangle[0].max(triangle[2])),
            (triangle[1].min(triangle[2]), triangle[1].max(triangle[2])),
        ];

        edges.sort();
        edges
    }

    /// Get edges sorted by filtration value
    fn get_sorted_edges(&self) -> Vec<((usize, usize), f64)> {
        let mut edges: Vec<_> = self
            .complex
            .edges_with_filtration()
            .map(|((u, v), f)| ((*u, *v), *f))
            .filter(|(_, f)| *f <= self.threshold)
            .collect();

        edges.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
        edges
    }

    /// Get triangles sorted by filtration value
    fn get_sorted_triangles(&self) -> Vec<(Vec<usize>, f64)> {
        let triangles = self.complex.simplices_of_dimension(2);
        let mut triangle_data = Vec::new();

        for triangle in triangles {
            let filtration = self.compute_triangle_filtration(&triangle);
            if filtration <= self.threshold {
                triangle_data.push((triangle, filtration));
            }
        }

        triangle_data.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
        triangle_data
    }

    /// Compute the filtration value of a triangle (max edge distance)
    fn compute_triangle_filtration(&self, triangle: &[usize]) -> f64 {
        if triangle.len() != 3 {
            return f64::INFINITY;
        }

        let mut max_dist: f64 = 0.0;

        // Check all three edges of the triangle
        for i in 0..3 {
            for j in (i + 1)..3 {
                let u = triangle[i];
                let v = triangle[j];

                // Find this edge in the complex
                for ((edge_u, edge_v), dist) in self.complex.edges_with_filtration() {
                    if (u == *edge_u && v == *edge_v) || (u == *edge_v && v == *edge_u) {
                        max_dist = max_dist.max(*dist);
                        break;
                    }
                }
            }
        }

        max_dist
    }

    /// Find the index of an edge in the complex
    fn find_edge_index(&self, target_edge: &(usize, usize)) -> Option<usize> {
        for (idx, ((u, v), _)) in self.complex.edges_with_filtration().enumerate() {
            if (*u, *v) == *target_edge || (*v, *u) == *target_edge {
                return Some(idx);
            }
        }
        None
    }

    /// Get all computed cocycles for a given dimension
    pub fn get_cocycles(&self, dimension: usize) -> Option<&Vec<Cocycle>> {
        self.cocycles.get(&dimension)
    }

    /// Convert cocycles to ripser-compatible format
    pub fn cocycles_to_ripser_format(&self, dimension: usize) -> Vec<Vec<usize>> {
        if let Some(cocycles) = self.cocycles.get(&dimension) {
            cocycles
                .iter()
                .map(|cocycle| cocycle.representatives.clone())
                .collect()
        } else {
            Vec::new()
        }
    }
}
