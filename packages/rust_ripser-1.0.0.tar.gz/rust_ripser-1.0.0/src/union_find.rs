//! # Union-Find Data Structure
//!
//! High-performance union-find implementation for H0 persistent homology computation
//! Includes path compression and union by rank optimizations

use std::collections::HashMap;

/// High-performance union-find data structure
#[derive(Debug, Clone)]
pub struct UnionFind {
    /// Parent node array
    parent: Vec<usize>,
    /// Rank array (for union by rank optimization)
    rank: Vec<usize>,
    /// Component birth times
    birth_times: Vec<f64>,
    /// Current number of components
    num_components: usize,
}

impl UnionFind {
    /// Create a new union-find structure with n independent elements
    pub fn new(n: usize) -> Self {
        Self {
            parent: (0..n).collect(),
            rank: vec![0; n],
            birth_times: vec![0.0; n], // All components are born at time 0
            num_components: n,
        }
    }

    /// Find the root of an element (with path compression)
    pub fn find(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find(self.parent[x]);
        }
        self.parent[x]
    }

    /// Immutable version of find (without path compression)
    pub fn find_immutable(&self, mut x: usize) -> usize {
        while self.parent[x] != x {
            x = self.parent[x];
        }
        x
    }

    /// Check if two elements are in the same component
    pub fn connected(&mut self, x: usize, y: usize) -> bool {
        self.find(x) == self.find(y)
    }

    /// Merge two components, returns whether merge was actually performed
    pub fn union(&mut self, x: usize, y: usize, time: f64) -> bool {
        let root_x = self.find(x);
        let root_y = self.find(y);

        if root_x == root_y {
            return false; // Already in the same component
        }

        // Union by rank
        if self.rank[root_x] < self.rank[root_y] {
            self.parent[root_x] = root_y;
            self.birth_times[root_x] = time; // Component root_x dies at time
        } else if self.rank[root_x] > self.rank[root_y] {
            self.parent[root_y] = root_x;
            self.birth_times[root_y] = time; // Component root_y dies at time
        } else {
            self.parent[root_y] = root_x;
            self.rank[root_x] += 1;
            self.birth_times[root_y] = time; // Component root_y dies at time
        }

        self.num_components -= 1;
        true
    }

    /// Simplified merge method (without timestamp recording)
    pub fn union_simple(&mut self, x: usize, y: usize) -> bool {
        let root_x = self.find(x);
        let root_y = self.find(y);

        if root_x == root_y {
            return false;
        }

        if self.rank[root_x] < self.rank[root_y] {
            self.parent[root_x] = root_y;
        } else if self.rank[root_x] > self.rank[root_y] {
            self.parent[root_y] = root_x;
        } else {
            self.parent[root_y] = root_x;
            self.rank[root_x] += 1;
        }

        self.num_components -= 1;
        true
    }

    /// Get the current number of components
    pub fn component_count(&self) -> usize {
        self.num_components
    }

    /// Get all component root nodes
    pub fn get_roots(&mut self) -> Vec<usize> {
        let n = self.parent.len();
        (0..n).filter(|&i| self.find(i) == i).collect()
    }

    /// Get component size mapping
    pub fn component_sizes(&mut self) -> HashMap<usize, usize> {
        let n = self.parent.len();
        let mut sizes = HashMap::new();

        for i in 0..n {
            let root = self.find(i);
            *sizes.entry(root).or_insert(0) += 1;
        }

        sizes
    }

    /// Generate H0 persistence pairs
    pub fn generate_h0_persistence_pairs(&mut self) -> Vec<(f64, f64)> {
        let mut pairs = Vec::new();
        let n = self.parent.len();

        // Collect dead components
        for i in 0..n {
            if self.parent[i] != i {
                // This component died
                pairs.push((0.0, self.birth_times[i]));
            }
        }

        // Add surviving components (infinite lifetime)
        let surviving_count = self.component_count();
        for _ in 0..surviving_count {
            pairs.push((0.0, f64::INFINITY));
        }

        pairs
    }
}

/// Optimized union-find specifically for the ripser algorithm
#[derive(Debug)]
pub struct RipserUnionFind {
    parent: Vec<usize>,
    rank: Vec<u8>, // Use u8 to save memory, rank is typically small
    death_times: Vec<f64>,
}

impl RipserUnionFind {
    pub fn new(n: usize) -> Self {
        Self {
            parent: (0..n).collect(),
            rank: vec![0; n],
            death_times: vec![f64::INFINITY; n],
        }
    }

    /// Find root node (with path compression)
    #[inline]
    pub fn find(&mut self, mut x: usize) -> usize {
        let mut path = Vec::new();

        // Collect path
        while self.parent[x] != x {
            path.push(x);
            x = self.parent[x];
        }

        // Path compression
        for &node in &path {
            self.parent[node] = x;
        }

        x
    }

    /// Fast version of find (minimal path compression)
    #[inline]
    pub fn find_fast(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find_fast(self.parent[x]);
        }
        self.parent[x]
    }

    /// Merge operation (optimized for ripser)
    #[inline]
    pub fn link(&mut self, x: usize, y: usize, death_time: f64) {
        let mut root_x = x;
        let mut root_y = y;

        // Find root nodes without path compression (to maintain correct death_time)
        while self.parent[root_x] != root_x {
            root_x = self.parent[root_x];
        }
        while self.parent[root_y] != root_y {
            root_y = self.parent[root_y];
        }

        if root_x == root_y {
            return;
        }

        // Union by rank
        if self.rank[root_x] < self.rank[root_y] {
            std::mem::swap(&mut root_x, &mut root_y);
        }

        self.parent[root_y] = root_x;
        self.death_times[root_y] = death_time;

        if self.rank[root_x] == self.rank[root_y] {
            self.rank[root_x] += 1;
        }
    }

    /// Generate persistence pairs
    pub fn get_persistence_pairs(&self) -> Vec<(f64, f64)> {
        let mut pairs = Vec::new();
        let n = self.parent.len();

        // Dead components
        for i in 0..n {
            if self.parent[i] != i && self.death_times[i] != f64::INFINITY {
                pairs.push((0.0, self.death_times[i]));
            }
        }

        // Surviving components
        let surviving_count = (0..n).filter(|&i| self.parent[i] == i).count();

        for _ in 0..surviving_count {
            pairs.push((0.0, f64::INFINITY));
        }

        pairs
    }
}

/// Parallel version of union-find (for large-scale data)
#[derive(Debug)]
pub struct ParallelUnionFind {
    data: Vec<std::sync::atomic::AtomicUsize>,
    n: usize,
}

impl ParallelUnionFind {
    pub fn new(n: usize) -> Self {
        use std::sync::atomic::AtomicUsize;

        let data: Vec<AtomicUsize> = (0..n).map(|i| AtomicUsize::new(i)).collect();

        Self { data, n }
    }

    /// Thread-safe find operation
    pub fn find(&self, mut x: usize) -> usize {
        use std::sync::atomic::Ordering;

        while x != self.data[x].load(Ordering::Acquire) {
            let parent = self.data[x].load(Ordering::Acquire);
            let grandparent = self.data[parent].load(Ordering::Acquire);

            // Attempt path compression
            if parent != grandparent {
                self.data[x]
                    .compare_exchange_weak(
                        parent,
                        grandparent,
                        Ordering::Release,
                        Ordering::Relaxed,
                    )
                    .ok();
            }

            x = parent;
        }

        x
    }

    /// Thread-safe merge operation
    pub fn union(&self, x: usize, y: usize) -> bool {
        use std::sync::atomic::Ordering;

        loop {
            let root_x = self.find(x);
            let root_y = self.find(y);

            if root_x == root_y {
                return false;
            }

            let (smaller, larger) = if root_x < root_y {
                (root_x, root_y)
            } else {
                (root_y, root_x)
            };

            // Attempt to connect larger root to smaller root
            if self.data[larger]
                .compare_exchange_weak(larger, smaller, Ordering::Release, Ordering::Relaxed)
                .is_ok()
            {
                return true;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_union_find_basic() {
        let mut uf = UnionFind::new(5);

        assert_eq!(uf.component_count(), 5);
        assert!(!uf.connected(0, 1));

        uf.union(0, 1, 1.0);
        assert!(uf.connected(0, 1));
        assert_eq!(uf.component_count(), 4);

        uf.union(2, 3, 2.0);
        assert_eq!(uf.component_count(), 3);

        uf.union(0, 2, 3.0);
        assert!(uf.connected(0, 3));
        assert_eq!(uf.component_count(), 2);
    }

    #[test]
    fn test_persistence_pairs() {
        let mut uf = UnionFind::new(4);

        uf.union(0, 1, 1.0);
        uf.union(2, 3, 2.0);
        uf.union(0, 2, 3.0);

        let pairs = uf.generate_h0_persistence_pairs();

        // Should have 3 dead components and 1 surviving component
        assert_eq!(pairs.len(), 4);

        let death_times: Vec<f64> = pairs
            .iter()
            .filter(|(_, death)| death.is_finite())
            .map(|(_, death)| *death)
            .collect();

        assert_eq!(death_times.len(), 3);
        assert!(death_times.contains(&1.0));
        assert!(death_times.contains(&2.0));
        assert!(death_times.contains(&3.0));
    }

    #[test]
    fn test_ripser_union_find() {
        let mut uf = RipserUnionFind::new(3);

        uf.link(0, 1, 1.5);
        uf.link(1, 2, 2.5);

        let pairs = uf.get_persistence_pairs();
        assert_eq!(pairs.len(), 3); // 2 deaths + 1 survival

        let finite_pairs: Vec<(f64, f64)> = pairs
            .iter()
            .filter(|(_, death)| death.is_finite())
            .copied()
            .collect();

        assert_eq!(finite_pairs.len(), 2);
    }
}
