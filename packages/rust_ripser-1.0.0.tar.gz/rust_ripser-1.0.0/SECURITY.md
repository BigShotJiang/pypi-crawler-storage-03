# Security Policy

## Supported Versions

We provide security updates for the following versions:

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a Vulnerability

We take security vulnerabilities seriously. If you discover a security vulnerability in rust-ripser, please report it responsibly.

### How to Report

1. **Do NOT** create a public issue for security vulnerabilities
2. **Email** the maintainers directly at: [security contact email]
3. **Include** the following information:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if available)

### Response Timeline

- **Acknowledgment**: Within 48 hours
- **Initial Assessment**: Within 1 week  
- **Fix Development**: Within 2-4 weeks (depending on severity)
- **Public Disclosure**: After fix is released

### Security Considerations

#### Input Validation
- All user inputs are validated for type and range
- Distance matrices are checked for validity (symmetry, non-negativity)
- Memory limits are enforced for large datasets

#### Memory Safety
- Rust's ownership system prevents buffer overflows
- All array accesses are bounds-checked
- Memory allocations are tracked and limited

#### Numerical Stability
- Floating-point operations use robust algorithms
- Edge cases (NaN, infinity) are handled gracefully
- Precision loss is minimized in critical computations

#### Dependencies
- Regular security audits with `cargo audit`
- Minimal dependency tree to reduce attack surface
- All dependencies are from trusted sources

### Known Security Considerations

1. **Large Input DoS**: Very large datasets can consume significant memory and CPU
   - Mitigation: Memory limits and timeout mechanisms
   
2. **Malformed Distance Matrices**: Invalid input matrices could cause computation errors
   - Mitigation: Comprehensive input validation
   
3. **Floating-Point Attacks**: Specially crafted inputs might exploit numerical instabilities
   - Mitigation: Robust numerical algorithms and bounds checking

### Best Practices for Users

1. **Validate Inputs**: Check your input data before processing
2. **Set Limits**: Use reasonable thresholds and memory limits
3. **Update Regularly**: Keep rust-ripser updated to the latest version
4. **Monitor Resources**: Watch memory and CPU usage for large computations

Thank you for helping keep rust-ripser secure!