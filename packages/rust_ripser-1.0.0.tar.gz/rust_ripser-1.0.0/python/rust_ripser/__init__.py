"""
Rust-Ripser: High-Performance Persistent Homology

A Rust implementation of persistent homology computation with Python bindings.
"""

# The actual Rust implementation will be imported from the compiled module
# This will be available after building with maturin

__version__ = "0.1.0"

try:
    from .rust_ripser import (
        rust_ripser,
        compute_ripser_optimized,
        compute_ripser_h2_optimized,
        compute_ripser_with_cocycles,
        benchmark_rust_distance,
        add_numbers,
        version,
        rust_info,
    )
    
    def ripser(X, maxdim=1, thresh=float('inf'), metric='euclidean'):
        """
        Compute persistent homology using Rust implementation.
        
        Args:
            X: Point cloud data (n x d array) or distance matrix (n x n array)
            maxdim: Maximum homology dimension to compute (default 1)
            thresh: Maximum edge length threshold (default infinity)
            metric: Distance metric ('euclidean', 'cosine', 'manhattan')
            
        Returns:
            dict: Results dictionary containing persistence diagrams
        """
        return rust_ripser(X, maxdim=maxdim, thresh=thresh, metric=metric)
    
    def info():
        """Get information about the Rust implementation."""
        return rust_info()
    
    def benchmark_distance_computation(points, metric='euclidean'):
        """Benchmark distance matrix computation."""
        return benchmark_rust_distance(points, metric)
        
    __all__ = [
        "ripser",
        "rust_ripser",
        "compute_ripser_optimized",
        "compute_ripser_h2_optimized",
        "compute_ripser_with_cocycles", 
        "benchmark_distance_computation",
        "add_numbers",
        "version",
        "info",
    ]

except ImportError:
    # If the Rust module isn't built yet, provide a helpful error
    def _not_built(*args, **kwargs):
        raise ImportError(
            "Rust module not built yet. Please run 'maturin develop' to build the extension."
        )
    
    ripser = _not_built
    rust_ripser = _not_built
    benchmark_distance_computation = _not_built
    add_numbers = _not_built
    version = lambda: "0.1.0"
    info = _not_built
    
    __all__ = ["ripser", "rust_ripser", "benchmark_distance_computation", "add_numbers", "version", "info"]