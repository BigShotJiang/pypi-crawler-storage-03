# 🚀 Quick Release Guide for rust-ripser

## 📋 Prerequisites

1. **PyPI Account Setup**:
   - Create account at https://pypi.org/
   - Create API token at https://pypi.org/manage/account/token/
   - For testing: also create account at https://test.pypi.org/

2. **Install maturin** (if not already installed):
   ```bash
   uv add maturin
   # or
   pip install maturin
   ```

## 🎯 Quick Release Methods

### Method 1: Use the Release Script (Recommended)

```bash
# Test release first
./release.sh test

# Production release
./release.sh prod
```

### Method 2: Manual Release

```bash
# Build the wheel
maturin build --release

# Test locally
pip install target/wheels/rust_ripser-1.0.0-*.whl --force-reinstall

# Upload to Test PyPI
maturin publish --repository testpypi --username __token__ --password YOUR_TEST_TOKEN

# Upload to PyPI
maturin publish --username __token__ --password YOUR_PYPI_TOKEN
```

### Method 3: GitHub Actions (Automated)

1. **Set up GitHub Secrets**:
   - `PYPI_API_TOKEN`: Your PyPI API token
   - `TEST_PYPI_API_TOKEN`: Your Test PyPI API token

2. **Release via Git Tag**:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```

3. **Or use manual trigger**: Go to GitHub → Actions → "Release to PyPI" → Run workflow

## ✅ Verification

After release, verify installation:

```bash
pip install rust-ripser==1.0.0

python -c "
import rust_ripser
import numpy as np
print(f'Version: {rust_ripser.version()}')
points = np.random.randn(5, 2)
result = rust_ripser.rust_ripser(points, maxdim=1)
print('Success!')
"
```

## 🔗 Links

- **PyPI**: https://pypi.org/project/rust-ripser/
- **Test PyPI**: https://test.pypi.org/project/rust-ripser/
- **GitHub**: https://github.com/your-username/rust-ripser

## 🛠️ Troubleshooting

- **Build fails**: Check Rust toolchain with `rustup update`
- **Upload fails**: Verify API token and network connection
- **Import fails**: Ensure numpy is installed

That's it! Your rust-ripser package is now ready for the world! 🎉