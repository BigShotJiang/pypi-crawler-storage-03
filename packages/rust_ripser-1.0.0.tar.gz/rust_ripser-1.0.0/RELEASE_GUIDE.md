# Release Guide for rust-ripser

This guide covers how to release rust-ripser as a Python package to PyPI.

## Prerequisites

### 1. Install Required Tools

```bash
# Install maturin for building Rust-Python packages
pip install maturin

# Install twine for uploading to PyPI
pip install twine

# Install build tools
pip install build
```

### 2. Set up PyPI Account

1. Create account at https://pypi.org/
2. Create API token at https://pypi.org/manage/account/token/
3. Save token securely (you'll need it for upload)

### 3. Set up Test PyPI (Optional but Recommended)

1. Create account at https://test.pypi.org/
2. Create API token at https://test.pypi.org/manage/account/token/

## Release Process

### Step 1: Pre-release Checks

```bash
# Ensure all tests pass
python -m pytest tests/

# Run accuracy tests
python simple_accuracy_test.py

# Check compilation
cargo check
```

### Step 2: Build the Package

```bash
# Clean previous builds
rm -rf target/wheels/ dist/

# Build wheels for current platform
maturin build --release

# Build source distribution
maturin sdist
```

### Step 3: Test the Package Locally

```bash
# Install the wheel locally
pip install target/wheels/rust_ripser-1.0.0-*.whl --force-reinstall

# Test the installation
python -c "import rust_ripser; print(rust_ripser.version())"

# Run a quick test
python -c "
import numpy as np
import rust_ripser
points = np.random.randn(10, 2)
result = rust_ripser.rust_ripser(points, maxdim=1)
print('Success! H0 intervals:', len(result['dgms'][0]))
"
```

### Step 4: Upload to Test PyPI (Recommended)

```bash
# Upload to test PyPI first
maturin publish --repository testpypi --username __token__ --password <your-test-pypi-token>

# Test installation from test PyPI
pip install --index-url https://test.pypi.org/simple/ rust-ripser==1.0.0

# Test the installed package
python -c "import rust_ripser; print('Test PyPI installation successful!')"
```

### Step 5: Upload to Production PyPI

```bash
# Upload to PyPI
maturin publish --username __token__ --password <your-pypi-token>
```

### Step 6: Verify the Release

```bash
# Install from PyPI
pip install rust-ripser==1.0.0

# Verify installation
python -c "import rust_ripser; print(f'rust-ripser version: {rust_ripser.version()}')"
```

## Alternative Method: Using GitHub Actions

### Set up GitHub Actions (Automated Release)

Create `.github/workflows/release.yml`:

```yaml
name: Release

on:
  push:
    tags: ["v*"]

jobs:
  linux:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        target: [x86_64, aarch64]
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    - name: Build wheels
      uses: PyO3/maturin-action@v1
      with:
        target: ${{ matrix.target }}
        args: --release --out dist
        sccache: 'true'
        manylinux: auto
    - name: Upload wheels
      uses: actions/upload-artifact@v3
      with:
        name: wheels
        path: dist

  windows:
    runs-on: windows-latest
    strategy:
      matrix:
        target: [x64, x86]
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v4
      with:
        python-version: '3.11'
        architecture: ${{ matrix.target }}
    - name: Build wheels
      uses: PyO3/maturin-action@v1
      with:
        target: ${{ matrix.target }}
        args: --release --out dist
        sccache: 'true'
    - name: Upload wheels
      uses: actions/upload-artifact@v3
      with:
        name: wheels
        path: dist

  macos:
    runs-on: macos-latest
    strategy:
      matrix:
        target: [x86_64, aarch64]
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    - name: Build wheels
      uses: PyO3/maturin-action@v1
      with:
        target: ${{ matrix.target }}
        args: --release --out dist
        sccache: 'true'
    - name: Upload wheels
      uses: actions/upload-artifact@v3
      with:
        name: wheels
        path: dist

  sdist:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Build sdist
      uses: PyO3/maturin-action@v1
      with:
        command: sdist
        args: --out dist
    - name: Upload sdist
      uses: actions/upload-artifact@v3
      with:
        name: wheels
        path: dist

  release:
    name: Release
    runs-on: ubuntu-latest
    needs: [linux, windows, macos, sdist]
    steps:
    - uses: actions/download-artifact@v3
      with:
        name: wheels
    - name: Publish to PyPI
      uses: PyO3/maturin-action@v1
      env:
        MATURIN_PYPI_TOKEN: ${{ secrets.PYPI_API_TOKEN }}
      with:
        command: upload
        args: --skip-existing *
```

### GitHub Actions Release Process

1. Add PyPI API token to GitHub Secrets as `PYPI_API_TOKEN`
2. Create a git tag and push:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
3. GitHub Actions will automatically build and upload to PyPI

## Manual Release Script

For convenience, here's a script that automates the manual process:

```bash
#!/bin/bash
# save as release.sh

set -e

echo "🚀 Starting rust-ripser release process..."

# Pre-release checks
echo "📋 Running pre-release checks..."
python -m pytest tests/ --tb=short
python simple_accuracy_test.py
cargo check

# Clean and build
echo "🔨 Building package..."
rm -rf target/wheels/ dist/
maturin build --release

# Test installation
echo "🧪 Testing local installation..."
pip install target/wheels/rust_ripser-1.0.0-*.whl --force-reinstall --quiet
python -c "import rust_ripser; print(f'✅ Version: {rust_ripser.version()}')"

# Upload to PyPI
echo "📦 Uploading to PyPI..."
read -p "Enter your PyPI API token: " -s PYPI_TOKEN
echo
maturin publish --username __token__ --password $PYPI_TOKEN

echo "🎉 Release complete! Check https://pypi.org/project/rust-ripser/"
```

## Troubleshooting

### Common Issues

1. **Build fails**: Ensure Rust toolchain is installed and up to date
2. **Upload fails**: Check API token and network connection
3. **Import fails**: Verify numpy is installed and compatible

### Build for Multiple Platforms

To build for multiple platforms without GitHub Actions:

```bash
# Use cross-compilation (Linux/macOS)
rustup target add x86_64-pc-windows-gnu
maturin build --release --target x86_64-pc-windows-gnu

# Or use docker for Linux builds
maturin build --release --manylinux 2014
```

## Post-Release

1. Update version numbers for next development cycle
2. Create GitHub release with changelog
3. Update documentation and examples
4. Announce on relevant channels

## Security Notes

- Never commit API tokens to version control
- Use environment variables or GitHub Secrets for CI/CD
- Consider using trusted publishing for GitHub Actions