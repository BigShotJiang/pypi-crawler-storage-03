#!/bin/bash
# Rust-Ripser Release Script
# Usage: ./release.sh [test|prod]

set -e

RELEASE_TYPE=${1:-test}

echo "🚀 Starting rust-ripser release process..."
echo "📋 Release type: $RELEASE_TYPE"

# Check if maturin is installed
if ! command -v maturin &> /dev/null; then
    echo "❌ maturin is not installed. Installing..."
    pip install maturin
fi

# Pre-release checks
echo "📋 Running pre-release checks..."

echo "  🧪 Testing basic functionality..."
python3 -c "
import numpy as np
import sys
sys.path.insert(0, '.')

try:
    import rust_ripser
    points = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]])
    result = rust_ripser.rust_ripser(points, maxdim=1)
    print('    ✅ Basic functionality test passed')
except Exception as e:
    print(f'    ❌ Basic test failed: {e}')
    exit(1)
"

echo "  🔧 Checking Rust compilation..."
if cargo check --quiet; then
    echo "    ✅ Rust compilation check passed"
else
    echo "    ❌ Rust compilation failed"
    exit 1
fi

# Clean previous builds
echo "🧹 Cleaning previous builds..."
rm -rf target/wheels/ dist/ build/

# Build the package
echo "🔨 Building package..."
maturin build --release

# Find the built wheel
WHEEL_FILE=$(find target/wheels -name "rust_ripser-*.whl" | head -1)
if [[ -z "$WHEEL_FILE" ]]; then
    echo "❌ No wheel file found!"
    exit 1
fi

echo "📦 Built wheel: $WHEEL_FILE"

# Test local installation
echo "🧪 Testing local installation..."
pip install "$WHEEL_FILE" --force-reinstall --quiet

python3 -c "
import rust_ripser
import numpy as np

print(f'    ✅ Version: {rust_ripser.version()}')

# Quick test
points = np.random.randn(5, 2)
result = rust_ripser.rust_ripser(points, maxdim=1)
print(f'    ✅ Test result: H0={len(result[\"dgms\"][0])}, H1={len(result[\"dgms\"][1])}')
"

# Upload based on type
if [[ "$RELEASE_TYPE" == "test" ]]; then
    echo "🚀 Uploading to Test PyPI..."
    echo "📝 You'll need your Test PyPI API token"
    echo "🔗 Get it from: https://test.pypi.org/manage/account/token/"
    
    read -p "Enter your Test PyPI API token: " -s TEST_PYPI_TOKEN
    echo
    
    if [[ -z "$TEST_PYPI_TOKEN" ]]; then
        echo "❌ No token provided. Skipping upload."
        echo "💡 To upload manually: maturin publish --repository testpypi --username __token__ --password YOUR_TOKEN"
    else
        maturin publish --repository testpypi --username __token__ --password "$TEST_PYPI_TOKEN"
        echo "🎉 Uploaded to Test PyPI!"
        echo "🔗 Check: https://test.pypi.org/project/rust-ripser/"
        echo "📦 Install with: pip install --index-url https://test.pypi.org/simple/ rust-ripser"
    fi

elif [[ "$RELEASE_TYPE" == "prod" ]]; then
    echo "🚀 Uploading to Production PyPI..."
    echo "⚠️  WARNING: This will upload to the PRODUCTION PyPI!"
    echo "📝 You'll need your PyPI API token"
    echo "🔗 Get it from: https://pypi.org/manage/account/token/"
    
    read -p "Are you sure you want to upload to PRODUCTION PyPI? (yes/no): " CONFIRM
    if [[ "$CONFIRM" != "yes" ]]; then
        echo "❌ Upload cancelled."
        exit 1
    fi
    
    read -p "Enter your PyPI API token: " -s PYPI_TOKEN
    echo
    
    if [[ -z "$PYPI_TOKEN" ]]; then
        echo "❌ No token provided. Skipping upload."
        echo "💡 To upload manually: maturin publish --username __token__ --password YOUR_TOKEN"
    else
        maturin publish --username __token__ --password "$PYPI_TOKEN"
        echo "🎉 Uploaded to PyPI!"
        echo "🔗 Check: https://pypi.org/project/rust-ripser/"
        echo "📦 Install with: pip install rust-ripser"
    fi

else
    echo "❌ Invalid release type. Use 'test' or 'prod'"
    exit 1
fi

echo "✅ Release process complete!"