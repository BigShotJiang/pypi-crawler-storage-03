#!/usr/bin/env python3
"""
Accuracy verification test for rust-ripser against original ripser.

This script compares the persistent homology results from rust-ripser
with the original ripser implementation to ensure identical accuracy.
"""

import numpy as np
from sklearn.datasets import make_circles, make_blobs
import sys
import os

# Add the current directory to path for rust_ripser import
sys.path.insert(0, '.')

try:
    import rust_ripser
    print(f"✓ Loaded rust-ripser version: {rust_ripser.version()}")
except ImportError as e:
    print(f"✗ Failed to import rust-ripser: {e}")
    print("Please compile the Rust extension first with: maturin develop")
    sys.exit(1)

try:
    import ripser
    print(f"✓ Loaded original ripser")
except ImportError as e:
    print(f"✗ Failed to import original ripser: {e}")
    print("Please install ripser with: pip install ripser")
    sys.exit(1)

def generate_test_datasets():
    """Generate various test datasets for comprehensive testing."""
    datasets = {}
    
    # 1. Simple circle data (should have clear H1)
    X_circle, _ = make_circles(n_samples=50, noise=0.1, factor=0.3, random_state=42)
    datasets['circle'] = X_circle
    
    # 2. Two clusters (should have clear H0)
    X_clusters, _ = make_blobs(n_samples=30, centers=2, cluster_std=0.5, random_state=42)
    datasets['clusters'] = X_clusters
    
    # 3. Random points (minimal structure)
    np.random.seed(42)
    X_random = np.random.randn(25, 2) * 0.5
    datasets['random'] = X_random
    
    # 4. Line segment (1D structure)
    t = np.linspace(0, 1, 20)
    X_line = np.column_stack([t, np.zeros_like(t)])
    datasets['line'] = X_line
    
    # 5. Triangle vertices (simple 2D structure)
    X_triangle = np.array([
        [0, 0],
        [1, 0], 
        [0.5, np.sqrt(3)/2],
        [0.1, 0.1],
        [0.9, 0.1],
        [0.5, np.sqrt(3)/2 - 0.1]
    ])
    datasets['triangle'] = X_triangle
    
    return datasets

def compare_persistence_diagrams(dgm1, dgm2, tolerance=1e-10):
    """Compare two persistence diagrams with tolerance for floating point differences."""
    if len(dgm1) != len(dgm2):
        return False, f"Different number of intervals: {len(dgm1)} vs {len(dgm2)}"
    
    if len(dgm1) == 0:
        return True, "Both diagrams are empty"
    
    # Sort both diagrams by birth time, then death time
    dgm1_sorted = sorted(dgm1, key=lambda x: (x[0], x[1]))
    dgm2_sorted = sorted(dgm2, key=lambda x: (x[0], x[1]))
    
    max_diff = 0.0
    for i, (p1, p2) in enumerate(zip(dgm1_sorted, dgm2_sorted)):
        birth_diff = abs(p1[0] - p2[0])
        death_diff = abs(p1[1] - p2[1])
        
        # Handle infinity values
        if np.isinf(p1[1]) and np.isinf(p2[1]):
            death_diff = 0.0
        elif np.isinf(p1[1]) or np.isinf(p2[1]):
            death_diff = float('inf')
        
        max_diff = max(max_diff, birth_diff, death_diff)
        
        if birth_diff > tolerance or death_diff > tolerance:
            return False, f"Interval {i}: birth diff {birth_diff:.2e}, death diff {death_diff:.2e}"
    
    return True, f"All intervals match within tolerance {tolerance:.2e} (max diff: {max_diff:.2e})"

def test_dataset_accuracy(name, X, maxdim=2, thresh=np.inf):
    """Test accuracy for a single dataset."""
    print(f"\n{'='*50}")
    print(f"Testing dataset: {name}")
    print(f"Shape: {X.shape}, maxdim: {maxdim}, threshold: {thresh}")
    print(f"{'='*50}")
    
    # Original ripser computation
    print("Computing with original ripser...")
    try:
        ripser_result = ripser.ripser(X, maxdim=maxdim, thresh=thresh)
        ripser_dgms = ripser_result['dgms']
        print(f"✓ Original ripser completed")
    except Exception as e:
        print(f"✗ Original ripser failed: {e}")
        return False
    
    # Rust ripser computation (basic)
    print("Computing with rust-ripser (basic)...")
    try:
        rust_result_basic = rust_ripser.compute_ripser(X, maxdim=maxdim, thresh=thresh)
        rust_dgms_basic = rust_result_basic['dgms']
        print(f"✓ Rust-ripser (basic) completed")
    except Exception as e:
        print(f"✗ Rust-ripser (basic) failed: {e}")
        return False
    
    # Rust ripser computation (advanced with progress)
    print("Computing with rust-ripser (advanced)...")
    try:
        rust_result_advanced = rust_ripser.compute_ripser_advanced(
            X, maxdim=maxdim, thresh=thresh, 
            mode="accurate", progress=True
        )
        rust_dgms_advanced = rust_result_advanced['dgms']
        print(f"✓ Rust-ripser (advanced) completed")
    except Exception as e:
        print(f"✗ Rust-ripser (advanced) failed: {e}")
        return False
    
    # Compare results
    all_match = True
    tolerance = 1e-8  # Stricter tolerance for accuracy verification
    
    print(f"\nComparing persistence diagrams (tolerance: {tolerance}):")
    for dim in range(maxdim + 1):
        print(f"\nDimension H{dim}:")
        
        # Get diagrams for this dimension
        ripser_dgm = ripser_dgms[dim] if dim < len(ripser_dgms) else np.array([])
        rust_basic_dgm = rust_dgms_basic[dim] if dim < len(rust_dgms_basic) else np.array([])
        rust_advanced_dgm = rust_dgms_advanced[dim] if dim < len(rust_dgms_advanced) else np.array([])
        
        print(f"  Original ripser:     {len(ripser_dgm)} intervals")
        print(f"  Rust basic:          {len(rust_basic_dgm)} intervals") 
        print(f"  Rust advanced:       {len(rust_advanced_dgm)} intervals")
        
        # Compare basic vs original
        match_basic, msg_basic = compare_persistence_diagrams(
            ripser_dgm.tolist() if len(ripser_dgm) > 0 else [],
            rust_basic_dgm.tolist() if len(rust_basic_dgm) > 0 else [],
            tolerance
        )
        
        # Compare advanced vs original  
        match_advanced, msg_advanced = compare_persistence_diagrams(
            ripser_dgm.tolist() if len(ripser_dgm) > 0 else [],
            rust_advanced_dgm.tolist() if len(rust_advanced_dgm) > 0 else [],
            tolerance
        )
        
        if match_basic:
            print(f"  ✓ Basic matches original: {msg_basic}")
        else:
            print(f"  ✗ Basic differs from original: {msg_basic}")
            all_match = False
            
        if match_advanced:
            print(f"  ✓ Advanced matches original: {msg_advanced}")
        else:
            print(f"  ✗ Advanced differs from original: {msg_advanced}")
            all_match = False
    
    return all_match

def run_accuracy_tests():
    """Run comprehensive accuracy tests."""
    print("Rust-Ripser Accuracy Verification")
    print("=" * 60)
    
    datasets = generate_test_datasets()
    
    all_tests_passed = True
    test_results = {}
    
    # Test each dataset
    for name, X in datasets.items():
        # Test with different parameters
        test_configs = [
            (1, np.inf),      # H0 + H1 only
            (2, np.inf),      # H0 + H1 + H2
            (2, 1.0),         # H0 + H1 + H2 with threshold
        ]
        
        dataset_passed = True
        for maxdim, thresh in test_configs:
            config_name = f"{name}_maxdim{maxdim}_thresh{thresh}"
            try:
                passed = test_dataset_accuracy(name, X, maxdim, thresh)
                test_results[config_name] = passed
                if not passed:
                    dataset_passed = False
                    all_tests_passed = False
            except Exception as e:
                print(f"✗ Test {config_name} failed with exception: {e}")
                test_results[config_name] = False
                dataset_passed = False
                all_tests_passed = False
    
    # Summary
    print("\n" + "=" * 60)
    print("ACCURACY TEST SUMMARY")
    print("=" * 60)
    
    passed_count = sum(1 for result in test_results.values() if result)
    total_count = len(test_results)
    
    print(f"Tests passed: {passed_count}/{total_count}")
    
    for test_name, result in test_results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"  {status} {test_name}")
    
    if all_tests_passed:
        print(f"\n🎉 ALL ACCURACY TESTS PASSED!")
        print("Rust-ripser produces identical results to original ripser.")
    else:
        print(f"\n❌ SOME ACCURACY TESTS FAILED!")
        print("Rust-ripser results differ from original ripser.")
    
    return all_tests_passed

if __name__ == "__main__":
    success = run_accuracy_tests()
    sys.exit(0 if success else 1)