# Contributing to Rust-Ripser

Thank you for your interest in contributing to Rust-Ripser! This document provides guidelines and instructions for contributors.

## 🚀 Quick Start

1. **Fork the repository** on GitHub
2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/your-username/rust-ripser.git
   cd rust-ripser
   ```
3. **Set up development environment**:
   ```bash
   # Install Rust
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   
   # Install Python dependencies
   pip install maturin numpy pytest
   
   # Build the project
   maturin develop --release
   ```

## 🛠️ Development Workflow

### Building and Testing

```bash
# Build Rust library
cargo build --release

# Run Rust tests
cargo test --all-features

# Build Python package
maturin develop --release

# Run Python tests
python test_final_performance.py
python test_h2_accuracy.py
python test_cocycles.py
```

### Code Quality

Before submitting changes, ensure your code passes all quality checks:

```bash
# Format Rust code
cargo fmt

# Lint Rust code
cargo clippy -- -D warnings

# Security audit
cargo audit

# Run benchmarks
python test_performance.py
python test_h2_performance.py
```

## 📋 Areas for Contribution

We welcome contributions in the following areas:

### 🔬 Algorithms & Performance
- **Higher-dimensional optimizations** (H3, H4+)
- **GPU acceleration** with CUDA/OpenCL
- **SIMD optimizations** for specific architectures
- **Memory-efficient algorithms** for massive datasets
- **Streaming algorithms** for real-time processing

### 📊 Distance Metrics
- **Additional metrics**: Wasserstein, Earth Mover's Distance
- **Custom metrics**: User-defined distance functions
- **Sparse metrics**: Optimizations for sparse data
- **Geodesic distances**: On manifolds and graphs

### 🌐 Bindings & Interfaces
- **R bindings** via extendr
- **Julia bindings** via PyCall or direct
- **WebAssembly** for browser usage
- **Command-line interface** for standalone usage

### 📚 Documentation & Examples
- **Tutorial notebooks** with real-world examples
- **API documentation** improvements
- **Performance guides** for different use cases
- **Visualization examples** with matplotlib/plotly

### 🧪 Testing & Validation
- **Property-based testing** with proptest
- **Fuzzing** for robustness testing
- **Cross-validation** against other TDA libraries
- **Large-scale benchmarks** on real datasets

## 📝 Code Style Guidelines

### Rust Code
- Follow `rustfmt` formatting (run `cargo fmt`)
- Use meaningful variable names
- Add documentation comments (`///`) for public APIs
- Keep functions focused and modular
- Use `anyhow::Result` for error handling

Example:
```rust
/// Computes the k-th nearest neighbor distances for threshold estimation.
/// 
/// # Arguments
/// * `points` - Input point cloud as 2D array
/// * `k` - Number of nearest neighbors to consider
/// * `metric` - Distance metric to use
/// 
/// # Returns
/// Vector of k-th nearest neighbor distances for each point
/// 
/// # Errors
/// Returns error if k >= number of points
pub fn compute_knn_distances(
    points: ArrayView2<f64>,
    k: usize,
    metric: &str,
) -> Result<Vec<f64>> {
    // Implementation...
}
```

### Python Code
- Follow PEP 8 style guide
- Use type hints where appropriate
- Write comprehensive docstrings
- Include usage examples in docstrings

## 🧪 Testing Guidelines

### Rust Tests
```rust
#[cfg(test)]
mod tests {
    use super::*;
    use approx::assert_relative_eq;
    
    #[test]
    fn test_distance_computation() {
        let points = Array::from_shape_vec((3, 2), vec![
            0.0, 0.0,
            1.0, 0.0, 
            0.0, 1.0,
        ]).unwrap();
        
        let distances = compute_distance_matrix_rust(points.view(), "euclidean").unwrap();
        
        // Test symmetry
        assert_relative_eq!(distances[[0, 1]], distances[[1, 0]], epsilon = 1e-10);
        
        // Test known distances
        assert_relative_eq!(distances[[0, 1]], 1.0, epsilon = 1e-10);
        assert_relative_eq!(distances[[0, 2]], 1.0, epsilon = 1e-10);
    }
}
```

### Python Tests
```python
def test_ripser_compatibility():
    """Test that rust-ripser produces identical results to ripser."""
    points = np.random.randn(30, 3)
    
    # Test with multiple configurations
    for maxdim in [1, 2]:
        for thresh in [1.0, 2.0, float('inf')]:
            result = compute_ripser_advanced(
                points, 
                maxdim=maxdim,
                thresh=thresh,
                mode="accurate"
            )
            
            # Verify structure
            assert 'dgms' in result
            assert len(result['dgms']) == maxdim + 1
            assert 'computation_time' in result
```

## 📊 Performance Considerations

When contributing performance improvements:

1. **Benchmark before and after** your changes
2. **Profile** to identify bottlenecks
3. **Test accuracy** - ensure optimizations don't break correctness
4. **Document trade-offs** - explain performance vs accuracy considerations

### Benchmarking Template
```python
import time
import numpy as np
from rust_ripser import compute_ripser_advanced

def benchmark_improvement():
    """Template for benchmarking improvements."""
    points = np.random.randn(100, 3)
    
    # Baseline
    start = time.time()
    result_old = compute_ripser_baseline(points)
    time_old = time.time() - start
    
    # Your improvement
    start = time.time()
    result_new = compute_ripser_improved(points)
    time_new = time.time() - start
    
    # Verify correctness
    assert np.allclose(result_old['dgms'][1], result_new['dgms'][1])
    
    print(f"Speedup: {time_old / time_new:.2f}x")
    print(f"Old: {time_old:.4f}s, New: {time_new:.4f}s")
```

## 🔄 Pull Request Process

1. **Create a feature branch** from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes** following the guidelines above

3. **Test thoroughly**:
   ```bash
   cargo test --all-features
   python -m pytest tests/
   ```

4. **Update documentation** if needed

5. **Commit with descriptive messages**:
   ```bash
   git commit -m "optimize: add SIMD vectorization for distance computation
   
   - Implement 8-way SIMD for euclidean distance
   - Add AVX2 support with fallback to SSE
   - Achieves 2.3x speedup on large point clouds
   - Maintains numerical accuracy within 1e-15"
   ```

6. **Push and create pull request**:
   ```bash
   git push origin feature/your-feature-name
   ```

### PR Checklist
- [ ] Code follows style guidelines
- [ ] Tests pass locally
- [ ] Documentation updated
- [ ] Performance benchmarks included (if applicable)
- [ ] Breaking changes documented
- [ ] Commit messages are clear and descriptive

## 🐛 Bug Reports

When reporting bugs, please include:

1. **Minimal reproduction example**
2. **Expected vs actual behavior**
3. **System information** (OS, Python version, Rust version)
4. **Error messages and stack traces**

## 💡 Feature Requests

For feature requests:

1. **Check existing issues** to avoid duplicates
2. **Describe the use case** and motivation
3. **Provide examples** of how the feature would be used
4. **Consider implementation challenges**

## 📞 Getting Help

- **GitHub Issues**: For bugs and feature requests
- **GitHub Discussions**: For questions and general discussion
- **Email**: For security issues or private inquiries

## 🏆 Recognition

Contributors will be:
- Listed in the project's contributors section
- Mentioned in release notes for significant contributions
- Invited to join the core team for sustained contributions

## 📜 License

By contributing to Rust-Ripser, you agree that your contributions will be licensed under the MIT License.