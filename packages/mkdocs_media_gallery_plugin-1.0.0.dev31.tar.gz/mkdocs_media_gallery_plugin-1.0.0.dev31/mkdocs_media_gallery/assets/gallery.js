// Lightbox handled by mkdocs-glightbox. This file intentionally left minimal.
