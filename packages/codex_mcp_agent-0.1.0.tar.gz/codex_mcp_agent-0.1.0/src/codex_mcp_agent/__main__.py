"""Allow running the MCP server as a module with python -m codex_mcp_agent"""

from .server import main

if __name__ == "__main__":
    main()
