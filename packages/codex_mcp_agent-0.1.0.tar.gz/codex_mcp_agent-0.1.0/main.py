def main():
    print("Hello from codex-mcp-agent!")


if __name__ == "__main__":
    main()
