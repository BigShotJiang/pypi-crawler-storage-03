"""A package containing all schemas required by ansible-creator."""
