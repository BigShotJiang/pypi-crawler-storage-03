"""Unit tests for ansible-creator."""
