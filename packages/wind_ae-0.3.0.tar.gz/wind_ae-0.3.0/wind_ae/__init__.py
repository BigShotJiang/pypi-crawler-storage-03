# import McAstro as McAstro
# from McAstro.atoms import atomic_species as McAtom 
# from .McAstro.mcastro_file import McAstro
from wind_ae.wrapper.relax_wrapper import wind_simulation as wind_sim

import os

__version__ = "0.2.0"