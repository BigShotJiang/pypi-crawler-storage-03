# lsp-tree-sitter

```{autofile} ../../src/*/*.py
---
module:
---
```
