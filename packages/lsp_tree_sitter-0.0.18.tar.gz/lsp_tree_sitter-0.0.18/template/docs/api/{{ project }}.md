# {{ project }}

```{autofile} ../../src/*/*.py
---
module:
---
```
