Welcome to **Lineage RPG**, an offline RPG that you can play right from your terminal. Follow the below steps below to install and start playing!

## 📦 Requirements
* Python **3.6+** ([Download here](https://www.python.org/downloads/))
* Internet connection (for installation)

--- 

## 🚀 Installation
### 1. Open your terminal or command prompt.
Then press `Windows + R`, then type `cmd`, and hit Enter.

### 2. Install the game with:
```bash
pip install lineage-rpg
```

To upgrade to the latest version when a new version releases:
```bash
pip install --upgrade lineage-rpg
```

---

## 🕹️ How to Play
Once installed, launch the game from your terminal using:
```bash
lineage-rpg
```

You'll see:
```
Welcome to Lineage RPG! Type 'exit' or CTRL+C to quit.
>
```

Then, type `help` and press ENTER. You'll see a list of commands to start playing.

---

## ❓ Came across an error?
* **Command not found?** Make sure Python and Pip are correctly installed and added to your PATH.
* **Corrupted save file?** The game will reset and start fresh if your save file is invalid.
* **Game doesn’t run?** Try running with `python -m lineage_rpg.main` as a fallback.