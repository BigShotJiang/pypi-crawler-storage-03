## Locations

COLOMBIA = "www.datos.gov.co"

SEATTLE = "data.seattle.gov"

CHICAGO = "data.cityofchicago.org"
