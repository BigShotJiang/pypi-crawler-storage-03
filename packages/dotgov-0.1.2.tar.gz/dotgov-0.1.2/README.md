# dotgov

## A library for accessing government Open Data

## Documentation

### User guide and API reference:

[![Docs](https://img.shields.io/badge/docs-mkdocs--material-blue)](https://munozbravo.github.io/dotgov/)
