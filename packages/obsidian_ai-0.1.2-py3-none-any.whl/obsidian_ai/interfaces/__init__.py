"""Interface layer for CLI, chat, and tool definitions."""
