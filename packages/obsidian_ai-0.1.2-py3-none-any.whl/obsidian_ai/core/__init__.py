"""Core business logic for Obsidian AI."""
