from ms_image_gen_mcp import main

main()