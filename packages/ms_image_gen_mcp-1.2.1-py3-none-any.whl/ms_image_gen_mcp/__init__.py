from .server import mcp

def main():
    """Main entry point for the package."""
    mcp.run()

if __name__ == "__main__":
    main()