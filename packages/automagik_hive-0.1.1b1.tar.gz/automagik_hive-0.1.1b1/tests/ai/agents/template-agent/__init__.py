"""
Tests for Template Agent

This package contains tests for the template-agent implementation.
"""