"""
Tests for Genie Debug Agent

This package contains tests for the genie-debug agent implementation.
"""