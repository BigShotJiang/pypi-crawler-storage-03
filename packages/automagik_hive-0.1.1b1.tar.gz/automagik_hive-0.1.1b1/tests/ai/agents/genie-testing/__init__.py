"""
Tests for Genie Testing Agent

This package contains tests for the genie-testing agent implementation.
"""