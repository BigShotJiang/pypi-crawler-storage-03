"""
Tests for Genie Quality Agent

This package contains tests for the genie-quality agent implementation.
"""