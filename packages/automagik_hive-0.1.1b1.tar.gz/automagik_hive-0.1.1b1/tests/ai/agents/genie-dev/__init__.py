"""
Tests for Genie Dev Agent

This package contains tests for the genie-dev agent implementation.
"""