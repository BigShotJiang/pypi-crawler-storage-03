# Template Tool Module
# Foundational template for creating new tools

from .tool import TemplateTool

__all__ = ["TemplateTool"]
