"""Genie Debug Agent - Specialized debugging agent for systematic issue investigation"""

from .agent import get_genie_debug_agent

__all__ = ["get_genie_debug_agent"]