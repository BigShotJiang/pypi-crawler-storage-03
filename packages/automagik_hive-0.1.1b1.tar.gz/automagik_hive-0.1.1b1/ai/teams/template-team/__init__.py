"""Template team for routing and coordination."""
