"""
Automagik Hive Library Package

Core library modules for the Automagik Hive multi-agent framework.
"""
