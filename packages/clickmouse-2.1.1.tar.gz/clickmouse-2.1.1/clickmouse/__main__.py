"""
ClickMouse命令行工具，可以使用 python -m clickmouse 命令运行
"""

from clickmouse.command_tools import main

if __name__ == '__main__':
    main()