"""读取版本号信息"""

__version__ = "2.1.1"
__author__ = "xystudio"