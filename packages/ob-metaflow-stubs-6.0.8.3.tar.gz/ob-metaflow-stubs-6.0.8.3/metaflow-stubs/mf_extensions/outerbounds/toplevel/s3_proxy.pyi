######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.1.0+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-08-25T21:23:22.218006                                                            #
######################################################################################################

from __future__ import annotations



USE_CSPR_ROLE_ARN_IF_SET: str

AWS_SECRETS_MANAGER_DEFAULT_REGION: None

DEFAULT_PROXY_HOST: str

DEFAULT_PROXY_PORT: int

def get_aws_client_with_s3_proxy(module, with_error = False, role_arn = None, session_vars = None, client_params = None, s3_config = None):
    ...

def get_S3_with_s3_proxy(s3_config, *args, **kwargs):
    ...

