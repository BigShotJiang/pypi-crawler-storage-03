######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.1.0+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-08-25T21:23:22.441856                                                            #
######################################################################################################

from __future__ import annotations



class EventBridgeClient(object, metaclass=type):
    def __init__(self, name):
        ...
    def cron(self, cron):
        ...
    def role_arn(self, role_arn):
        ...
    def state_machine_arn(self, state_machine_arn):
        ...
    def schedule(self):
        ...
    def delete(self):
        ...
    ...

def format(name):
    ...

