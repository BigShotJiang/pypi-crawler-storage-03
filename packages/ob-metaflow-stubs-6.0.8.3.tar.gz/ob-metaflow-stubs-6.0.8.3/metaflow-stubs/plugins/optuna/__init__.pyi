######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.1.0+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-08-25T21:23:22.189650                                                            #
######################################################################################################

from __future__ import annotations



def auth():
    ...

def get_deployment_db_access_endpoint(name: str):
    ...

def get_db_url(app_name: str):
    """
    Example usage:
        >>> from metaflow.plugins.optuna import get_db_url
        >>> s = optuna.create_study(..., storage=get_db_url("optuna-dashboard"))
    """
    ...

