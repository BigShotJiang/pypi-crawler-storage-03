######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.17.1.0+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-08-25T21:23:22.264620                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

