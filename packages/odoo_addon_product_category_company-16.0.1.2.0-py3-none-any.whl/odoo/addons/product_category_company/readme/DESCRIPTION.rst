This module allows to set product categories as company dependent.

You could be interested by concurrent module named ``product_category_company_favorite``,
(same repository), that propose similar features but with alternative implementation.