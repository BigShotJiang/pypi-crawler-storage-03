> [!CAUTION]
> This project is in active development and not ready for production use. It has not been publicly announced yet.

# Microsoft Teams Cards

Adaptive cards functionality for Microsoft Teams applications.
Provides utilities for creating and handling interactive card components.