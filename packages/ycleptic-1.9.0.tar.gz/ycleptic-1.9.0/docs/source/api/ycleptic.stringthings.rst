ycleptic.stringthings module
============================

.. automodule:: ycleptic.stringthings
   :members:
   :show-inheritance:
   :undoc-members:
