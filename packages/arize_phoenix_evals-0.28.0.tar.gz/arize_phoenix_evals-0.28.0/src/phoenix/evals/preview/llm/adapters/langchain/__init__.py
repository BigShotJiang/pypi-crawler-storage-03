"""LangChain adapter for the Universal LLM Wrapper."""

from .adapter import LangChainModelAdapter

__all__ = [
    "LangChainModelAdapter",
]
