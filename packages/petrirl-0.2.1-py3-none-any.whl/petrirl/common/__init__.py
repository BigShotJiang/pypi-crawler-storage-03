from petrirl.common.instance_loader import InstanceLoader
from petrirl.common.build_blocks import  Token,Place,Transition


