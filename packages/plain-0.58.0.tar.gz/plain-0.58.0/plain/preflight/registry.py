from plain.utils.inspect import func_accepts_kwargs
from plain.utils.itercompat import is_iterable


class CheckRegistry:
    def __init__(self):
        self.registered_checks = set()
        self.deployment_checks = set()

    def register(self, check=None, deploy=False):
        """
        Can be used as a function or a decorator. Register given function
        `f`. The function should receive **kwargs
        and return list of Errors and Warnings.

        Example::

            registry = CheckRegistry()
            @registry.register('mytag', 'anothertag')
            def my_check(package_configs, **kwargs):
                # ... perform checks and collect `errors` ...
                return errors
            # or
            registry.register(my_check, 'mytag', 'anothertag')
        """

        def inner(check):
            if not func_accepts_kwargs(check):
                raise TypeError(
                    "Check functions must accept keyword arguments (**kwargs)."
                )
            checks = self.deployment_checks if deploy else self.registered_checks
            checks.add(check)
            return check

        if callable(check):
            return inner(check)
        else:
            return inner

    def run_checks(
        self,
        package_configs=None,
        include_deployment_checks=False,
        database=False,
    ):
        """
        Run all registered checks and return list of Errors and Warnings.
        """
        errors = []
        checks = self.get_checks(include_deployment_checks)

        for check in checks:
            new_errors = check(package_configs=package_configs, database=database)
            if not is_iterable(new_errors):
                raise TypeError(
                    f"The function {check!r} did not return a list. All functions "
                    "registered with the checks registry must return a list.",
                )
            errors.extend(new_errors)
        return errors

    def get_checks(self, include_deployment_checks=False):
        checks = list(self.registered_checks)
        if include_deployment_checks:
            checks.extend(self.deployment_checks)
        return checks


checks_registry = CheckRegistry()
register_check = checks_registry.register
run_checks = checks_registry.run_checks
