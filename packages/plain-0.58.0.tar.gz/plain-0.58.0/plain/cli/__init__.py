from .registry import register_cli

__all__ = ["register_cli"]
