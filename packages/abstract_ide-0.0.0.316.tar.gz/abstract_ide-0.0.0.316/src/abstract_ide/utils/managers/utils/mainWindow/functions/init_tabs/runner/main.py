from ..imports import *
from .initFuncs import initFuncs
import logging

class Runner(QWidget):
    def __init__(self, layout):
        super().__init__()                 # ← fixed


Runner= initFuncs(Runner)
