# Python file wrappers.

## Installation

You can install from [pypi](https://pypi.org/project/python-filewrap/)

```console
pip install -U python-filewrap
```

## Usage

```python
import filewrap
```
