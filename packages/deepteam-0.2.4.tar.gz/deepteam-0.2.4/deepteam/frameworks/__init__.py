from .frameworks import OWASPTop10

__all__ = [
    "OWASPTop10",
]
