from .types import IntellectualPropertyType
from .template import IntellectualPropertyTemplate
