from enum import Enum


class GuardType(Enum):
    INPUT = "Input Guard"
    OUTPUT = "Output Guard"
