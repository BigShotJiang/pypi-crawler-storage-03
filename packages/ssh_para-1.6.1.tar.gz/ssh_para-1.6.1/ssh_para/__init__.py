""" package ssh-para """

__author__ = "Franck Jouvanceau"
