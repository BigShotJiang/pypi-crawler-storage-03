# instutil
utility for instrumentation suite for qc and inhouse lab
done using
https://packaging.python.org/en/latest/tutorials/packaging-projects/

py -m build

 py -m  twine upload --repository pypi dist/* -u __token__ -p <api token>