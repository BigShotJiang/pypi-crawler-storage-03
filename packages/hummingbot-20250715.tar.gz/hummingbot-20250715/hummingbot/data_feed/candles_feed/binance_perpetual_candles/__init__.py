from hummingbot.data_feed.candles_feed.binance_perpetual_candles.binance_perpetual_candles import (
    BinancePerpetualCandles,
)

__all__ = ["BinancePerpetualCandles"]
