
Project Idea:
	* Constraining the Evolution of the Escape Fraction of Ionizing Photons Using Redshift-Dependent Ionization Fraction Data
		- Develops a semianalytical model to study the evolution of the escape fraction of ionizing photons as a function of redshift and halo mass.
		- Utilizes constraints on ionization fraction from table 5.1 to inform the model.
		- Incorporates a Bayesian framework to quantify uncertainties and break degeneracies with other parameters such as source luminosity and clumping factor.
		- Aims to provide a novel parameterization of the escape fraction and explore its impact on the reionization history.
		- Proposes methods to model the shape of the reionization history and validate predictions against additional observables like UV luminosity functions.
		- Findings will help refine theoretical models of reionization and aid in interpreting future observational data.

        