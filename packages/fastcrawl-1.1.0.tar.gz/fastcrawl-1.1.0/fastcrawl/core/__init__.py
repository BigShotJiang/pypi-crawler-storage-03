from .app import FastCrawl
from .components import Depends, LoggerDependency
from .crawler import Crawler
