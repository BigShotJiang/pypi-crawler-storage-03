from . import discriminators, discriminators_v2

__all__ = ["discriminators", "discriminators_v2"]
