'''Python MAVLink library - see https://mavlink.io/en/'''
__version__ = '0.1.8'
