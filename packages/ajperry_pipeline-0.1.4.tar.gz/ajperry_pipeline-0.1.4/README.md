# Kubeflow Pipelines


## Install Package


Note: Mainly installed in kubeflow instance.


`pip install ajperry_pipeline`


# Usage



1. Open the notebooks at `./notebooks` in kubeflow notebook
2. Launch pipeline components as desired



![Pipeline GUI](./images/test_pipeline_run.png "Pipeline that will run in kubeflow")