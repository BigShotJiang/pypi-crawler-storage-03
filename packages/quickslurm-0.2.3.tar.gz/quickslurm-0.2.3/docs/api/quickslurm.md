# API reference

::: quickslurm.quickslurm
