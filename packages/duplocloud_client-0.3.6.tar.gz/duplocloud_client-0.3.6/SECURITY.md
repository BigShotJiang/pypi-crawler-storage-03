# Security Policy

## Supported Versions

The following versions are actively supported. 

| Version | Supported          |
| ------- | ------------------ |
| 0.2.x   | :white_check_mark: |

## Reporting a Vulnerability

If a vulnerability is discovered please file an issue in the Github repo. A repository admin will respond as soon as possible. 
