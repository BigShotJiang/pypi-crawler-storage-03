from .content_media import ChattyContentMedia

class ChattyContentVideo(ChattyContentMedia):
    pass

