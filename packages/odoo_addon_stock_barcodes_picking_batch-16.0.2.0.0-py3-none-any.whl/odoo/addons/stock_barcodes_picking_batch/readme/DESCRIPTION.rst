This module extends barcode reader interface to allow to read quant barcodes.
After barcode has been readed the product, lot and location are been filled.
