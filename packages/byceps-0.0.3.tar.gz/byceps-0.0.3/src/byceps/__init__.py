TEXT = """
Hey there!

It seems you have tried to install BYCEPS from PyPI via `pip install byceps`.
However, as of now, that is not the way to install BYCEPS (at least not yet).

Please visit the homepage at https://byceps.nwsnet.de/ to learn how to
actually install BYCEPS.

Thanks a lot and have a great time!
"""


def main():
    print(TEXT)


if __name__ == "__main__":
    main()
