class AbstractMetadataObjectType:
    def __init__(self, instance, info):
        self.instance = instance
        self.info = info
