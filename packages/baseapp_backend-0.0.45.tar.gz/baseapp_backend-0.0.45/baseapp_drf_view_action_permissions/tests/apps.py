from django.apps import AppConfig


class TestAppConfig(AppConfig):
    default = True
    name = "baseapp_drf_view_action_permissions.tests"
    label = "baseapp_drf_view_action_permissions_tests"
