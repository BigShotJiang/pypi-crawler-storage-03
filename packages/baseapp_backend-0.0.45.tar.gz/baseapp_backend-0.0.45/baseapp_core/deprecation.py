class RemovedInBaseApp04Warning(DeprecationWarning):
    pass
