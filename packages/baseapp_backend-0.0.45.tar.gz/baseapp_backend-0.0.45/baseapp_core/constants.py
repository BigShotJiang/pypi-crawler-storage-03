DEFAULT_ACTIONS = ["list", "update", "partial_update", "create", "retrieve", "destroy"]
