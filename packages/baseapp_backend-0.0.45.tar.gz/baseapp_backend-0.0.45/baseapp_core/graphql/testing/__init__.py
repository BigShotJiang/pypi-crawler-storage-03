from .fixtures import graphql_query  # noqa
