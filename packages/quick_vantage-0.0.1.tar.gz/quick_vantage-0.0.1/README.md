 Quick-Vantage-Python-flavour
******************************
Usage - Run the Quick-Vantage.py file with elevated privileges
eg : sudo python3 Quick-Vantage.py

P.S : Add this to your ".zshrc" or ".bash_aliases" file for convenience - alias vantage="sudo python3 quick-vantage.py" 
