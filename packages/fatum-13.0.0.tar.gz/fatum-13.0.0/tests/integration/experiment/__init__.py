"""Integration tests for experiment module."""
