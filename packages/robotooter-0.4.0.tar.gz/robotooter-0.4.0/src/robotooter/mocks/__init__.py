plugin_filters: list[str] = []
plugin_bots: list[str] = ['robotooter.mocks.fake_bot.FakeBot']
