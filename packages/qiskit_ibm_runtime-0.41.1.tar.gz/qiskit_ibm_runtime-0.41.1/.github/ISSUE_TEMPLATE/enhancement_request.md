---
name: Enhancement request
about: Suggest an idea or improvement for this project
title: ''
labels: enhancement
assignees: ''

---

**What is the expected feature or enhancement?**


**Acceptance criteria**
