..
   SPDX-FileCopyrightText: Copyright DB InfraGO AG
   SPDX-License-Identifier: Apache-2.0

The |project| Sphinx extension
==============================

.. automodule:: capellambse.sphinx
