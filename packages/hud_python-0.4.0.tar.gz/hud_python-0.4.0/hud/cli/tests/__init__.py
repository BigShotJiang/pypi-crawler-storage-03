"""Tests for HUD CLI module."""

from __future__ import annotations
