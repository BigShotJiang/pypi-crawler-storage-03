"""Tests for OpenTelemetry integration."""
