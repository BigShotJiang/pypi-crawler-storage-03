version = "1.1.0"
"""software version"""
