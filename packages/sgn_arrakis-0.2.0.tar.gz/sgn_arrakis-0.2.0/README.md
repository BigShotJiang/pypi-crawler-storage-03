# sgn-arrakis

[Arrakis](https://git.ligo.org/ngdd/arrakis-python) source and sink
elements for [`sgnts`](https://git.ligo.org/greg/sgn-ts).
