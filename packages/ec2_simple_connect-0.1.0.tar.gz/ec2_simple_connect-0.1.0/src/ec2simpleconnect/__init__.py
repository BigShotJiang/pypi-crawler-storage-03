"""EC2 Simole Connect - Easy EC2 instance connection manager"""

__version__ = "0.1.0"