"""Translator package."""

from .translator import Translator

__all__ = ["Translator"]
