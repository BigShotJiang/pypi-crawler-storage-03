# Static Tools

The static_tools directory contains tools that don't have to make 
any API calls.