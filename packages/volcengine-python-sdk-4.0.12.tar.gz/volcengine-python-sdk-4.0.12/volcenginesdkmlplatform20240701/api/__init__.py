from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from volcenginesdkmlplatform20240701.api.ml_platform20240701_api import MLPLATFORM20240701Api
