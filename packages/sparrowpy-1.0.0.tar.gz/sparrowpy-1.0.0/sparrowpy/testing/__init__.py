"""Testing utilities for the sparrowpy package."""
from .stub_utils import shoebox_room_stub

__all__ = [
    'shoebox_room_stub',
]
