Examples
========

.. toctree::
    :maxdepth: 1

    examples/fast_radiosity
    examples/kang_radiosity