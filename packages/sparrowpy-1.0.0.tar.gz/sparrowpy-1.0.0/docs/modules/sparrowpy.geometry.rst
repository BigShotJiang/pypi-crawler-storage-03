sparrowpy.geometry
==================

.. automodule:: sparrowpy.geometry
   :members:
   :undoc-members:
   :show-inheritance:
