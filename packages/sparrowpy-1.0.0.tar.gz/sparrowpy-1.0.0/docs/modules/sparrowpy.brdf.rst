sparrowpy.brdf
==============

.. automodule:: sparrowpy.brdf
   :members:
   :undoc-members:
   :show-inheritance:
