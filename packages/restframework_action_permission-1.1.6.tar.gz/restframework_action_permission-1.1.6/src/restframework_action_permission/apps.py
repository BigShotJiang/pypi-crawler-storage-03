from django.apps import AppConfig


class RestframeworkActionPermissionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "restframework_action_permission"
