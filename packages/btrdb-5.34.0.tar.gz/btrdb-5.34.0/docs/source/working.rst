Working with btrdb
====================

Please review the guided tour linked below to get a better understanding of how
to interact with the BTrDB database.


.. toctree::
  :maxdepth: 2

  working/server
  working/stream-query-manage
  working/stream-manage-data
  working/stream-manage-metadata
  working/stream-view-data
  working/streamsets
  working/multiprocessing
  working/multistream
  working/arrow-enabled-queries
  working/dash
  working/ray
