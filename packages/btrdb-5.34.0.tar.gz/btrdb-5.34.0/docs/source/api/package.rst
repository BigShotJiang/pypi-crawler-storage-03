btrdb
=============

.. automodule:: btrdb

.. autofunction:: connect
