from pydantic import BaseModel


class QCMetrics(BaseModel):
    """QC metrics analysis model."""
