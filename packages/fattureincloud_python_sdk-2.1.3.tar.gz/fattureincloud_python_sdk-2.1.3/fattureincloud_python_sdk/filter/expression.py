class Expression:
    def build_query(self) -> str:
        """Build the query for the current expression."""
        pass
