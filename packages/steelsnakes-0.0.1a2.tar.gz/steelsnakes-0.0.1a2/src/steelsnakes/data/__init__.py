# TODO: review sql schema against data models

import pathlib

SECTIONS_DIR = pathlib.Path(__file__).parent / "sections"
UK_SECTIONS_DIR = SECTIONS_DIR / "UK"
