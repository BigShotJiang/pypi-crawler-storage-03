# Hyperspex : Hyperspectral Explorator GUI

A Python package to help 3D hyperspectral data exploration through a Graphical User Interface.

## Installation
```bash
pip install hyperspex