"""
Floxs package
"""
from . import flock, predator_prey
