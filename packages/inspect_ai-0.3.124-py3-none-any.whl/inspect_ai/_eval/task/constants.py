TASK_FILE_ATTR = "__task_file__"
TASK_RUN_DIR_ATTR = "__task_run_dir__"
TASK_ALL_PARAMS_ATTR = "__task_all_params__"
