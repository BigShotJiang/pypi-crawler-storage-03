import os
import json
import importlib

# Default config source = config.py
config = importlib.import_module("config")

# If user provides JSON, override values
CONFIG_FILE = os.getenv("VIREC_CONFIG", "config.json")
if os.path.exists(CONFIG_FILE):
    try:
        with open(CONFIG_FILE, "r") as f:
            json_config = json.load(f)
        for key, value in json_config.items():
            if hasattr(config, key):
                setattr(config, key, value)
    except Exception as e:
        print(f"⚠️ Could not load config.json: {e}")

# Expose final config variables
connection_string = config.connection_string
data_base = config.data_base
input_table = config.input_table
export_data_table = config.export_data_table
pagesave_path = config.pagesave_path
tracetuneel_path = config.tracetuneel_path
output_dir = config.output_dir