from cellxgene_ontology_guide.ontology_parser import OntologyParser

ONTOLOGY_PARSER = OntologyParser(schema_version="v6.0.0")
