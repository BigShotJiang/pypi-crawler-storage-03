# QuicDraw

```
    -----------
    QuicDraw: HTTP/3 Fuzzing and Racing (Client)
    -----------
                _         _
     __ _ _   _(_) ___ __| |_ __ __ ___      __
    / _` | | | | |/ __/ _` | '__/ _` \ \ /\ / /
   | (_| | |_| | | (_| (_| | | | (_| |\ V  V /
    \__, |\__,_|_|\___\__,_|_|  \__,_| \_/\_/
       |_|    _______
          \  |QD ____| ---------- HTTP/3
           \ |_//
             |_|

    GitHub: https://github.com/cyberark/quicdraw
    License: Apache-2.0 License
    Author: Maor Abutbul <CyberArk Labs>
    -----------
```

QuicDraw is a security research tool designed for fuzzing and racing HTTP/3 servers.
QuicDraw implements the `last-bytes-sync` on HTTP/3 (over QUIC), for race-condition testing.

The tool was originally published as part of CyberArk Labs research: "TODO - BLOG link"

##  Main Features

- Implements the `last-bytes-sync` on HTTP3 (over QUIC), for race-condition testing.
- Supports fuzzing multiple requests with the `FUZZ` and wordlist (`-w` argument) mechanisms.
- Custom HTTP headers functionality (`-H` argument).
  - Note: Custom headers are converted to lowercase since we have seen some issues with some server implementations.
- Supports SSLKEYLOGFILE (`-l` argument) for TLS decryption/inspection via packet analyzers such as Wireshark.
- Based on aioquic (http3_client)
  - [aioquic](https://github.com/aiortc/aioquic) is a library for the QUIC network protocol in Python.
  - It features a minimal TLS 1.3 implementation, a QUIC stack, and an HTTP/3 stack.

# Quick Start

Prerequisite:

- python 3.x
- pip3

## Install using pip

The easiest way to install quicdraw is to run:

```
pip install quicdraw
```

### Runinig

```
quicdraw -h
```

# Contributing

We welcome contributions of all kinds to this repository.
For instructions on how to get started and descriptions of our development workflows, please see our [contributing guide](CONTRIBUTING.md)

# Limitaitions

- The `last-bytes-sync` is mostly effective in POST requests (using the `-d` argument).
      - GET requests will benefit from the mechanism but according to our tests only a few requests "fit" on a single QUIC packet.
- The fuzzing mechanism (`FUZZ` and `--wordlist/-w`) only works in POST messages data **or** in the GET request URL (:path) argument.
- Currently, the fuzzing mechanism only works **once**, meaning if the data argument is supplied (`-d`), we assume fuzzzing on the POST data, supplying the `FUZZ` keyword in the URL (:path) will result in sending the URL (:path) as-is (including the `FUZZ` keyword).
- We do not support multiple different domains in the current version. (for different paths you can use the FUZZ keyword in the URL's path part).

# Known issues

- "socket.gaierror: [Errno 11001] getaddrinfo failed" error returned on DNS error

## License

Copyright (c) 2025 CyberArk Software Ltd. All rights reserved
This repository is licensed under Apache-2.0 License - see [`LICENSE`](LICENSE) for more details.

## Contact

Feel free to contact us via github issues if there are any feature requests or issues in the project
And contact us through linkedin:<br />
[Maor Abutbul](https://il.linkedin.com/in/maor-abutbul)
