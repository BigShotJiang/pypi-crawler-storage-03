Baseprinter 
===========

Baseprinter is an authoring tool that:

* generates [Baseprint document snapshots](https://perm.pub/HKSI5NPzMFmgRlb4Vboi71OTKYo),
* reads [Pandoc](https://pandoc.org) source formats such as LaTeX and Markdown,
* can generate HTML and PDF previews, and
* is open-source.

Visit [try.perm.pub](https://try.perm.pub/baseprinter/) for documentation.
