# TestSubInterval

Subinterval for round-robin testing (in seconds). Must be less than or equal to interval and must evenly divide interval.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


