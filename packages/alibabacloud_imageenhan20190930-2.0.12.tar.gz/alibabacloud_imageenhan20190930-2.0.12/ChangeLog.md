2024-02-20 Version: 2.0.11
- Update API GenerateCartoonizedImage: update param ImageType.
- Update API GenerateCartoonizedImage: update response param.
- Update API GenerateImageWithTextAndImage: update response param.
- Update API GenerateSuperResolutionImage: update response param.


2023-02-17 Version: 2.0.10
- Release GenerateSuperResolutionImage.

2023-02-09 Version: 2.0.9
- Release GenerateSuperResolutionImage.

2023-02-08 Version: 2.0.8
- Generated python 2019-09-30 for imageenhan.

2023-02-03 Version: 2.0.7
- Release GenerateImageWithText GenerateImageWithTextAndImage.

2022-12-14 Version: 2.0.6
- Update MakeSuperResolutionImage.

2022-12-09 Version: 2.0.5
- Update MakeSuperResolutionImage.

2022-10-17 Version: 2.0.4
- Update MakeSuperResolutionImage.

2022-09-29 Version: 2.0.3
- Update MakeSuperResolutionImage.

2022-06-20 Version: 2.0.2
- Update MakeSuperResolutionImage.

2021-09-26 Version: 2.0.1
- Update imageenhan.

2021-03-17 Version: 2.0.0
- Update MakeSuperResolutionImage.

2020-12-02 Version: 1.0.5
- Release ColorizeImage.

2020-11-13 Version: 1.0.4
- Release ErasePerson.

2020-10-13 Version: 1.0.3
- Release GenerateDynamicImage.

