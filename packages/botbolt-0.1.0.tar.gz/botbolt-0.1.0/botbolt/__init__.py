from .core import Bot, embed

__all__ = ["Bot", "embed"]
__version__ = "0.1.0"
