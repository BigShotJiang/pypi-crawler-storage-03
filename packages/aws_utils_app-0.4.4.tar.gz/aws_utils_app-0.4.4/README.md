# aws_utils_app

Biblioteca para facilitar o uso dos serviços AWS (SNS, SQS, Lambda, DynamoDB, RDS, S3).