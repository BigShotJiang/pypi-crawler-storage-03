class DuplicateValueError(ValueError):
    pass


class MaxRetriesError(RuntimeError):
    pass
