This module adds functionality to the customer portal in Odoo to allow downloading an Excel file with serial numbers (lots) for each delivery order.
This feature is only available for delivery orders that include products tracked by lot or serial number.
