1. Go to **My Account > Orders**.
2. Open a **sales order**.
3. If any delivery order contains tracked products (with lot/serial numbers), a section will appear titled:

   **Delivery Lot List**

4. Click the Excel icon next to the delivery name to download the file.
