API_URL = "https://superstaq.infleqtion.com"
API_VERSION = "v0.2.0"
