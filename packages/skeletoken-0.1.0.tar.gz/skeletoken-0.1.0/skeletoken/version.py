__version_triple__ = (0, 1, 0)
__version__ = ".".join(map(str, __version_triple__))
