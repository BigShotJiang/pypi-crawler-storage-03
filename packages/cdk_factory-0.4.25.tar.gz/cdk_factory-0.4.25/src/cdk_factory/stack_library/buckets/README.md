# S3 Bucket Stack

The sole purpose is to wrap-up a deployment for S3 Buckets.