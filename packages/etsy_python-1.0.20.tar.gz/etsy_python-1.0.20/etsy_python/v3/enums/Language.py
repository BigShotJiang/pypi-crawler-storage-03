from enum import Enum


class Language(Enum):
    EN = "en"
    DE = "de"
    ES = "es"
    FR = "fr"
    IT = "it"
    JA = "ja"
    NL = "nl"
    PL = "pl"
    PT = "pt"
    RU = "ru"
