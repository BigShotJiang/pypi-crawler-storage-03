"""CLI tools for Genesis MCP Core."""

from .main import cli

__all__ = ["cli"]