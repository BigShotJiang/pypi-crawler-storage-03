import pandas as pd


def T(x):
    return pd.Timestamp(x)
