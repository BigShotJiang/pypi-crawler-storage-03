## Supported edit codes:

- `whitespace/blank_line`
- `whitespace/comments`
- `whitespace/end_of_line`
- `whitespace/ending_newline`
- `whitespace/indent`
