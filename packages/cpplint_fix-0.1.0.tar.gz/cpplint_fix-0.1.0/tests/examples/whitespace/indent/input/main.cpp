// Copyright 2023 Some Guy

class Example {
public:
    int x;
    protected:
    float y;

    class Inner {
        public:
      int inner_x;
      };
 private:
   double z;
 };
