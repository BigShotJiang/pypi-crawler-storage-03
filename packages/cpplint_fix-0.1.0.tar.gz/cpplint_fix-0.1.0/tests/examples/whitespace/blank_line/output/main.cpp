// Copyright 2023 Some Guy

int main() {
    int x = 42;
}
