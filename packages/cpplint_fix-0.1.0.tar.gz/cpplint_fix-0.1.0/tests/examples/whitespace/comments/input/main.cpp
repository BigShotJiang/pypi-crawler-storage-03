// Copyright 2023 Some Guy

class Example {
    int x; // Comment too close
};
