// Copyright 2023 Some Guy

int main() {
    // The next line has trailing whitespace
    int x = 42;    
}
