from . import WebBrowseToolSet
from ..utils.toolset import toolset_cli


toolset_cli(WebBrowseToolSet, "web-browse")
