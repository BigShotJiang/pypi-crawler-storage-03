from . import ScraperToolSet
from ..utils.toolset import toolset_cli


toolset_cli(ScraperToolSet, "scraper") 