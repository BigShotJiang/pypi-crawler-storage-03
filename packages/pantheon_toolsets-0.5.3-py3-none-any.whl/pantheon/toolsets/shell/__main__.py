from .shell import ShellToolSet
from ..utils.toolset import toolset_cli


toolset_cli(ShellToolSet, "shell")
