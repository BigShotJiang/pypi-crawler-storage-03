from .core import FileManagerToolSet
from ..utils.toolset import toolset_cli


toolset_cli(FileManagerToolSet, "file-manager")
