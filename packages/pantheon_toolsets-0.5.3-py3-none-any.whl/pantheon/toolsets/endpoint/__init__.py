from .core import Endpoint, EndpointConfig


__all__ = ["Endpoint", "EndpointConfig"]
