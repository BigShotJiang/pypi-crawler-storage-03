"""File Editor Toolset - Claude-like file editing capabilities"""

from .core import FileEditorToolSet

__all__ = ["FileEditorToolSet"]