from .smart_core import SmartGeneratorToolSet

# Use smart version as default  
GeneratorToolSet = SmartGeneratorToolSet

__all__ = ["GeneratorToolSet", "SmartGeneratorToolSet"]