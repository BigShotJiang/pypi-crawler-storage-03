from .python_interpreter import PythonInterpreterToolSet
from ..utils.toolset import toolset_cli


toolset_cli(PythonInterpreterToolSet, "python-interpreter")
