"""Web Toolset - Complete web functionality like Claude Code"""

from .core import WebToolSet

__all__ = ["WebToolSet"]