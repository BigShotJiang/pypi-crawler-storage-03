from .r_interpreter import RInterpreterToolSet
from ..utils.toolset import toolset_cli


toolset_cli(RInterpreterToolSet, "r-interpreter")
