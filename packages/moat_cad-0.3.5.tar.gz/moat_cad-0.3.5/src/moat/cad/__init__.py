from __future__ import annotations
import contextlib

try:
	from .lib import *
except ImportError:
	pass
