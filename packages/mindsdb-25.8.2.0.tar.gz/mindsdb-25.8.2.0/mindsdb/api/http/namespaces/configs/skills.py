from flask_restx import Namespace

ns_conf = Namespace('skills', description='API to perform operations on MindsDB Agent Skills')
