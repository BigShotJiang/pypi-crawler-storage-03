from flask_restx import Namespace

ns_conf = Namespace('handlers', description='Represent hanlder object')
