=======
Credits
=======

Development Lead
----------------

* Stavros Korokithakis <hi@stavros.io>

Contributors
------------

* theychx <theychx@fastmail.com>
