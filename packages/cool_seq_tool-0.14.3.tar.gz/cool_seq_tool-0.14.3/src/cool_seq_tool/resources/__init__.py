"""Provide tools for acquiring and managing Cool-Seq-Tool data resources."""
