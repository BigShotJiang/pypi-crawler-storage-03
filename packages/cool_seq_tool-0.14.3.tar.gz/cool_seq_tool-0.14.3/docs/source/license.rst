License
=======

.. include:: ../../LICENSE
