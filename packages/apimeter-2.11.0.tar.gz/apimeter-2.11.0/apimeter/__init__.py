__version__ = "2.11.0"
__description__ = "One-stop solution for HTTP(S) testing."

__all__ = ["__version__", "__description__"]
