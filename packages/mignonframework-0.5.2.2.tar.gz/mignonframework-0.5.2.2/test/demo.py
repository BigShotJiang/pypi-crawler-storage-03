from mignonFramework import start, MicroServiceByNodeJS


MicroServiceByNodeJS().startAsMicro()


