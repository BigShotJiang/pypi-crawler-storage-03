This module extends the functionality of Payment Orders to support a tier
validation process.
