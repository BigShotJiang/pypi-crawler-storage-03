* `Escodoo <https://www.escodoo.com.br>`__:

  * Marcel Savegnago

* XCG Consulting, part of `Orbeet <https://orbeet.io/>`__:

  * Vincent Hatakeyama
