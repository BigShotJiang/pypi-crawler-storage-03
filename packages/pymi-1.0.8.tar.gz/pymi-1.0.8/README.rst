This repository includes the following projects:

MI++
----

A C++ wrapper over the Windows Management Infrastructure API.

PyMI
----

Windows Management Infrastructure API for Python.

For more details read the project's `README.rst <PyMI/README.rst>`_.
