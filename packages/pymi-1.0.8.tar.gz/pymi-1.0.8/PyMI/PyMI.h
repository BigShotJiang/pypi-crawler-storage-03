#pragma once

#include <Python.h>

extern PyObject *PyMIError;
extern PyObject *PyMITimeoutError;
