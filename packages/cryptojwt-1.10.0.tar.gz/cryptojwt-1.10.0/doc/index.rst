.. CryptoJWT documentation master file, created by
   sphinx-quickstart on Wed Oct  3 09:24:06 2018.

Welcome to CryptoJWT's documentation!
=====================================

CryptoJWT is supposed to provide you (a Python programmer) with all you need,
 to deal with what is described in RFC 7515-7519.

.. toctree::
   :maxdepth: 2

   keyhandling
   jws
   jwe
   source/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
