"""Range Sum Query sample problem."""
