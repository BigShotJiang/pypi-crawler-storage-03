"""Sample problems and solutions using segment trees."""
