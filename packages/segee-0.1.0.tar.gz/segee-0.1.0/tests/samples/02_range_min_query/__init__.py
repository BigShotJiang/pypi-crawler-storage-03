"""Range Minimum Query sample problem."""
