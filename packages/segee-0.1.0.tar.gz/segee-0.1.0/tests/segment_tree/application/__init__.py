"""Application tests for specialized segment tree classes."""
