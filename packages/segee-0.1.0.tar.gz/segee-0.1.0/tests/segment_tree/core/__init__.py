"""Core tests for segment tree functionality."""
