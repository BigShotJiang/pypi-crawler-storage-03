from enum import Enum


class EventSubTopics(Enum):
    CHANNEL_MODERATE = 'channel.moderate'