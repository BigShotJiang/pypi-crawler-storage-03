# CMeel Boost

[![PyPI version](https://badge.fury.io/py/cmeel-boost.svg)](https://pypi.org/project/cmeel-boost)
[![Release](https://github.com/cmake-wheel/cmeel-boost/actions/workflows/release.yml/badge.svg)](https://github.com/cmake-wheel/cmeel-boost/actions/workflows/release.yml)

[Boost](https://www.boost.org/) distribution for cmeel packages.
