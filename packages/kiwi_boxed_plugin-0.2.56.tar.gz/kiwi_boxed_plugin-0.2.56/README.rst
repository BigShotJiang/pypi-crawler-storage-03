KIWI - Boxed Build Plugin
=========================

.. |GitHub CI Action| image:: https://github.com/OSInside/kiwi-boxed-plugin/workflows/CILint/badge.svg
   :target: https://github.com/OSInside/kiwi-boxed-plugin/actions

|GitHub CI Action|

KIWI plugin to provide self contained build support. For further
details see:

`Building in a Self-Contained Environment <https://osinside.github.io/kiwi/plugins/self_contained.html>`__
