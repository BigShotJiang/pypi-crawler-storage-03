"""CLI module for treesitter-chunker."""
