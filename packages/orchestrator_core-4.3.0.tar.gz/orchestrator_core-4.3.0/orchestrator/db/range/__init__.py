from orchestrator.db.range.range import apply_range_to_query, apply_range_to_statement

__all__ = [
    "apply_range_to_query",
    "apply_range_to_statement",
]
