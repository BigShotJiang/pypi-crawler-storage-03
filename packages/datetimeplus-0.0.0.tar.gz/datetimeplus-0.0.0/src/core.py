from datetime import datetime as base_datetime


class datetime(base_datetime):
    """extended datetime class"""
