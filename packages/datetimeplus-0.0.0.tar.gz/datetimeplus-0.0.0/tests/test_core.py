class TestCore:
    def test_sample(self) -> None:
        assert True
