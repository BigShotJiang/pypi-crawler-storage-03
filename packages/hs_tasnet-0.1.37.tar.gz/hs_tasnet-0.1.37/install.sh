apt install ffmpeg portaudio19-dev -y
