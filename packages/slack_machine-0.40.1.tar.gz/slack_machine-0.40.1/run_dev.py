from src.machine.bin.run import main

if __name__ == "__main__":
    main()
