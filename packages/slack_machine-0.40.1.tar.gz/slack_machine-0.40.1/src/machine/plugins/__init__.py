from pyee.asyncio import AsyncIOEventEmitter

ee = AsyncIOEventEmitter()
