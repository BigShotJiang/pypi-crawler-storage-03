from .channel import Channel  # noqa
from .user import User  # noqa

# TODO: introduce more models, e.g. for bot info
