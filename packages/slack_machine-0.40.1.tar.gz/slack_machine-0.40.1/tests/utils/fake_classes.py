class FakeA:
    pass


class FakeB:
    pass


def fake_function():
    pass
