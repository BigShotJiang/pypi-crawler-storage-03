PLUGINS = ["tests.fake_plugins"]
SLACK_BOT_TOKEN = "xoxb-abc123"
SLACK_APP_TOKEN = "xapp-abc123"
STORAGE_BACKEND = "machine.storage.backends.memory.MemoryStorage"
