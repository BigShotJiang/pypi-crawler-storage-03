"""
TP1 Sintaxis - Lexer
Autor: FDFattor
"""

from .main import lexer

# Definir qué se exporta
__all__ = ['lexer']

# Información del paquete
__version__ = "1.0.0"
__author__ = "FDFattor"
__description__ = "Lexer para TP1 de Sintaxis"
