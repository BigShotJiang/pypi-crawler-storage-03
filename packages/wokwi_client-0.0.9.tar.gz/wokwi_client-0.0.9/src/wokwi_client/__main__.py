# SPDX-FileCopyrightText: 2025-present CodeMagic LTD
#
# SPDX-License-Identifier: MIT

import sys

if __name__ == "__main__":
    from wokwi_client.cli import wokwi_client

    sys.exit(wokwi_client())
