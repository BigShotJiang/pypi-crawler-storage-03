


## Reporting on Default Base Attributes - Perhaps couldn't find a valid combination of output_format_set and output_format?

# Update Digital Product

## Digital Product Name 

Opposition spending data - again

## Display Name
Opposition spending data - again

## Qualified Name
[DigitalProduct::Opposition-spending-data---again](#e7db9e6a-c53d-4358-b25d-e3bff5151599)

## Category
None

## Description
Sensitive spending data for the political opposition.

## GUID
e7db9e6a-c53d-4358-b25d-e3bff5151599

## Type Name
Collection

## Metadata Collection Id
9905c3cb-94c5-4494-9229-0d6f69c0b842

## Metadata Collection Name
qs-metadata-store

## Version Identifier
1.0

## Classifications
[]

## Additional Properties
None

## Created By
erinoverview

## Create Time
2025-08-18T02:04:59.690+00:00

## Updated By
None

## Update Time
None

## Effective From
None

## Effective To
None

## Version
1

## Open Metadata Type Name
Collection


#  Don't Create Data Sharing
## Name
Leak to fox

## Description
Leak sensitive personal data only to the conservative media.

## Status
PROPOSED

___

# Don't View Data Sharing Agreements
## Output Format
LIST

___

# Don't View Data Sharing Agreements
## Output Format
REPORT
___
#  Don't View Collections
## Output Format
LIST
# Provenance

* Results from processing file product.md on 2025-08-17 21:04
