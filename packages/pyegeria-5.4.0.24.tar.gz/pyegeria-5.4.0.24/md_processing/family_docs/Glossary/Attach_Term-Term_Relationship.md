# **Attach Term-Term Relationship**
>	Create a relationship between terms.

## **Term  1**
>	**Input Required**: True

>	**Description**: The name of the first term term to connect.

>	**Alternative Labels**: Term Name 1


## **Term  2**
>	**Input Required**: True

>	**Description**: The name of the second term term to connect.

>	**Alternative Labels**: Term Name 2


## **Relationship**
>	**Input Required**: True

>	**Description**: The type of relationship to connecting the two terms.

>	**Valid Values**: Synonym;  Translation;  PreferredTerm; TermISATYPEOFRelationship;  TermTYPEDBYRelationship;  Antonym; ReplacementTerm;  ValidValue; TermHASARelationship; RelatedTerm;   ISARelationship

