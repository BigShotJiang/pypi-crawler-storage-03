"""Entry point for python -m oe command."""

from .cli import main

if __name__ == "__main__":
    main()
