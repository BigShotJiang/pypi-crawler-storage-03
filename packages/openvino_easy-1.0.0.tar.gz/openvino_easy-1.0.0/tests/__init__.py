"""Test package for OpenVINO-Easy."""
