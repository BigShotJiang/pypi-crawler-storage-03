from granule.api_simple import simple_youtube_summary
from granule.models.simple import SimpleGranule

def test_simple_pipeline_no_llm(monkeypatch):
    # Monkeypatch ingest to avoid network
    import granule.api_simple as api_simple
    from granule.models.core import StructuredDoc, SourceMeta
    monkeypatch.setattr(api_simple, 'ingest_youtube', lambda url: StructuredDoc(text='Alpha beta gamma delta epsilon.', source=SourceMeta(type='youtube')))
    res = simple_youtube_summary('dummy')
    assert isinstance(res, SimpleGranule)
    assert res.text_chars > 0
    assert res.transcript.startswith('Alpha')
