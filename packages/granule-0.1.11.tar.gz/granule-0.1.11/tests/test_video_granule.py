"""Live integration test: fetch transcript for a real YouTube video and build card.

Video: https://www.youtube.com/watch?v=xWYb7tImErI

This test will hit the network to retrieve the transcript. If the transcript
is unavailable or rate-limited, the fallback minimal card still validates.
LLM parsing will occur only if OPENAI_API_KEY is set in the environment.
"""
from pathlib import Path
import granule.api_simple as api_simple
from granule.models.video_insight import VideoInsightCardPayload

VIDEO_URL = "https://www.youtube.com/watch?v=Jlqzy02k6B8"

def test_video_insight_card_live(tmp_path):
    card = api_simple.video_insight_card(VIDEO_URL)
    assert isinstance(card, VideoInsightCardPayload)
    assert card.video.id and len(card.video.id) == 11
    # Must have header + footer always
    assert card.header.title
    assert card.footer is not None
    # TL;DR section or at least one section present
    assert len(card.sections) >= 0
    out_path = tmp_path / 'live_video_card_output.json'
    # out_path = Path.cwd() / 'live_video_card_output.json'
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(card.model_dump_json(indent=2))
    assert out_path.exists()