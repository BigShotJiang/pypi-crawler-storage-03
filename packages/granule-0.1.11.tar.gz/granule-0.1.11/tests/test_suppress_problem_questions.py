from granule.models.video_insight import (
    VideoInsightCardPayload,
    VideoSection,
    VideoClaimItem,
    VideoQuestionItem,
    Problem,
)
from granule.llm.video_card import _enrich_questions
from granule.config import settings


def test_suppress_problem_questions_flag_behavior(monkeypatch):
    # Create a minimal card with a claim referencing a problem that normally has questions.
    claim = VideoClaimItem(claim="Claim about polarization and distrust", associated_problems=[Problem(label="Polarization"), Problem(label="Distrust of institutions")])
    card = VideoInsightCardPayload(
        header={"title": "T", "subtitle": None, "badges": []},
        video={"url": "u", "id": "vid"},
        sections=[
            VideoSection(title="Claims", items=[claim]),
            VideoSection(title="Questions Raised", items=[VideoQuestionItem(q="How does polarization fuel distrust?")]),
        ],
        footer={"persuasion_modes": [], "devices": [], "timeline": []},
    )
    # Force suppression on
    monkeypatch.setattr(settings, "suppress_problem_questions", True)
    # Enrichment should early return (no synthesis) and keep existing items only
    _enrich_questions(card, target_min=10)
    q_sec = next(s for s in card.sections if s.title.startswith("Questions Raised"))
    assert len(q_sec.items) == 1  # no additions


def test_enrich_questions_without_suppression(monkeypatch):
    monkeypatch.setattr(settings, "suppress_problem_questions", False)
    claim1 = VideoClaimItem(claim="Claim about climate change impacts", associated_problems=[Problem(label="Climate change")])
    claim2 = VideoClaimItem(claim="Claim about biodiversity collapse drivers", associated_problems=[Problem(label="Biodiversity collapse")])
    card = VideoInsightCardPayload(
        header={"title": "T", "subtitle": None, "badges": []},
        video={"url": "u", "id": "vid"},
        sections=[
            VideoSection(title="Claims", items=[claim1, claim2]),
            VideoSection(title="Questions Raised", items=[]),
        ],
        footer={"persuasion_modes": [], "devices": [], "timeline": []},
    )
    _enrich_questions(card, target_min=4, max_total=6)
    q_sec = next(s for s in card.sections if s.title.startswith("Questions Raised"))
    # Should have synthesized some questions (>= target_min or until available)
    assert len(q_sec.items) >= 2
