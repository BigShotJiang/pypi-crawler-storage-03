from fastapi.testclient import TestClient
from granule.fastapi_app import app

client = TestClient(app)

def test_ingest_endpoint():
    r = client.post("/ingest", json={"source": "Some text", "kind": "blog"})
    assert r.status_code == 200
    body = r.json()
    assert "text" in body

def test_dissect_endpoint():
    doc = client.post("/ingest", json={"source": "Doc text", "kind": "blog"}).json()
    r = client.post("/dissect", json={"doc": doc, "max_tokens": 40})
    assert r.status_code == 200
    body = r.json()
    assert "atoms" in body

def test_expand_endpoint():
    doc = client.post("/ingest", json={"source": "Doc text", "kind": "blog"}).json()
    graph = client.post("/dissect", json={"doc": doc, "max_tokens": 40}).json()
    r = client.post("/expand", json={"graph": graph, "target_seconds": 10})
    assert r.status_code == 200
    assert r.json()
