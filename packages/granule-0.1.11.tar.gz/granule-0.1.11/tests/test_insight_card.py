from granule.api_full import process_youtube


def test_process_youtube_includes_insight_card(monkeypatch):
    # Monkeypatch ingest to avoid network call; override youtube ingest
    from granule import api_full
    import granule.api as api_mod

    def fake_ingest(source: str, kind: str):
        from granule.models.core import StructuredDoc
        return StructuredDoc(text="Alpha beta gamma delta epsilon zeta eta theta iota kappa.")

    monkeypatch.setattr(api_mod, "ingest", fake_ingest)
    # Run
    data = api_full.process_youtube("dummy")
    assert "insight_card" in data
    card = data["insight_card"]
    assert "header" in card and "sections" in card
