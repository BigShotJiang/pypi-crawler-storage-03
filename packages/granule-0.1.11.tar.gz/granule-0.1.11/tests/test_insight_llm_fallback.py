from granule.api_full import process_youtube


def test_insight_card_fallback_no_llm(monkeypatch):
    # Ensure no LLM key
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    import granule.api as api_mod
    from granule.models.core import StructuredDoc

    def fake_ingest(source: str, kind: str):
        return StructuredDoc(text="Alpha beta gamma delta epsilon zeta eta theta iota kappa lambda mu.")

    monkeypatch.setattr(api_mod, "ingest", fake_ingest)
    data = process_youtube("dummy")
    card = data["insight_card"]
    assert card["header"]["title"].startswith("Transcript") or card["header"]["title"]
    assert any(sec for sec in card["sections"])  # should have at least one section
