from granule.process.segment_v2 import improved_segments, batch_summarize_segments
from granule.models.segments import Segment
from granule.config import settings

def test_improved_segments_basic():
    text = """Sentence one. Sentence two is a bit longer and might continue. Sentence three. Sentence four. Sentence five which is quite a long sentence that maybe pushes boundaries a little bit. Sentence six. Sentence seven. Sentence eight."""
    segs = improved_segments(text, target_tokens=30, hard_max_tokens=60)
    assert segs, "Should produce segments"
    # Ensure no segment exceeds hard max
    assert all(s.token_count <= 70 for s in segs)
    # Ensure ordering
    assert [s.index for s in segs] == list(range(len(segs)))


def test_batch_summarize_fallback_without_llm(monkeypatch):
    # Force disable llm
    monkeypatch.setenv("OPENAI_API_KEY", "")
    segs = [Segment(index=0, text="Alpha beta gamma delta.", token_count=5)]
    summaries = batch_summarize_segments(segs)
    assert len(summaries) == 1
    assert summaries[0].micro_summary
