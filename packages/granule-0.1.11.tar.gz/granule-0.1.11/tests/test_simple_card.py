from granule.api_simple import simple_youtube_card

def test_simple_card_no_llm(monkeypatch):
    import granule.api_simple as api_simple
    from granule.models.core import StructuredDoc, SourceMeta
    monkeypatch.setenv('OPENAI_API_KEY', '')
    monkeypatch.setattr(api_simple, 'ingest_youtube', lambda url: StructuredDoc(text='Alpha beta gamma.', source=SourceMeta(type='youtube')))
    card = simple_youtube_card('dummy')
    assert 'header' in card and 'sections' in card
    assert any(sec for sec in card['sections'])
