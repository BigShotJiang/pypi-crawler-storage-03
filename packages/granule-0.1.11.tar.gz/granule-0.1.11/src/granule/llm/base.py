from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Iterable, Optional

@dataclass
class LLMRequest:
    prompt: str
    model: Optional[str] = None
    temperature: float = 0.2

@dataclass
class LLMResponse:
    text: str

class LLMProvider(Protocol):
    def complete(self, req: LLMRequest) -> LLMResponse: ...
    def stream(self, req: LLMRequest) -> Iterable[str]: ...

def get_provider(provider_name: str | None) -> Optional[LLMProvider]:
    if provider_name in (None, "openai"):
        try:
            from .openai_provider import OpenAIProvider  # type: ignore
            return OpenAIProvider()
        except Exception:
            return None
    return None
