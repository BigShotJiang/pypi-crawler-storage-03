"""LLM integration package.

Provides a lightweight provider abstraction so core pipeline can
optionally enrich atoms when an API key is present.
"""
from .base import LLMProvider, LLMRequest, LLMResponse, get_provider
from .enrich import enrich_atoms

__all__ = [
    "LLMProvider",
    "LLMRequest",
    "LLMResponse",
    "get_provider",
    "enrich_atoms",
]
