from fastapi import FastAPI
from pydantic import BaseModel
from datetime import timedelta
from .api import ingest as api_ingest, dissect as api_dissect, expand as api_expand
from .models.core import StructuredDoc, GranularitySpec, AtomGraph
from .api_simple import simple_youtube_summary, simple_youtube_card
from .models.simple import SimpleGranule

app = FastAPI(title="Granule API", version="0.1.1")

class IngestRequest(BaseModel):
    source: str
    kind: str = "blog"

@app.post("/ingest")
def ingest(req: IngestRequest):
    return api_ingest(req.source, req.kind)

class DissectRequest(BaseModel):
    doc: StructuredDoc
    max_tokens: int = 80
    kinds: list[str] | None = None

@app.post("/dissect")
def dissect(req: DissectRequest):
    spec = GranularitySpec(max_tokens_per_atom=req.max_tokens, atom_types=req.kinds)
    return api_dissect(req.doc, spec)

class ExpandRequest(BaseModel):
    graph: AtomGraph
    target_seconds: float = 55.0

@app.post("/expand")
def expand(req: ExpandRequest):
    spec = GranularitySpec(target_duration=timedelta(seconds=req.target_seconds))
    return api_expand(req.graph, spec)

class SimpleYouTubeRequest(BaseModel):
    url: str

@app.post("/simple/youtube", response_model=SimpleGranule)
def simple_youtube(req: SimpleYouTubeRequest):
    return simple_youtube_summary(req.url)

@app.post("/simple/card")
def simple_card(req: SimpleYouTubeRequest):
    return simple_youtube_card(req.url)
