import json, pathlib
from pydantic import BaseModel
def write_json(obj, path:str):
    p = pathlib.Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(obj, BaseModel):
        data = json.loads(obj.model_dump_json())
    else:
        data = obj
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
