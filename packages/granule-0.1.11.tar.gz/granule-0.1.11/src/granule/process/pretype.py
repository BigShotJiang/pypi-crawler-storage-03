import re
def weak_label(chunk:str):
    if re.search(r"\bDefinition\b|\bis\s+(?:a|an|the)\b", chunk): return "definition"
    if re.search(r"for example|e\.g\.", chunk, re.I): return "example"
    if re.match(r"^\s*(?:\d+\.|Step\s+\d+|First|Next|Then)\b", chunk, re.I): return "step"
    return "claim"
