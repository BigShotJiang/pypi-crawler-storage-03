import re
def naive_segments(text:str, max_len:int=1200):
    paras = re.split(r"\n\n+", text.strip())
    chunks, cur = [], ""
    for p in paras:
        if len(cur)+len(p) < max_len:
            cur = f"{cur}\n\n{p}" if cur else p
        else:
            if cur: chunks.append(cur)
            cur = p
    if cur: chunks.append(cur)
    return chunks
