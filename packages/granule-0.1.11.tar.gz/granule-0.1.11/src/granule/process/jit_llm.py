"""On-demand LLM integration placeholder.

Currently emits a stub atom; if enrichment is enabled (OPENAI_API_KEY set),
we attach a side-channel list of enrichment payloads under key `_enriched`.
"""
from ..config import settings
from ..llm import enrich_atoms
from ..models.core import SemanticAtom, SourceMeta, AtomEvidence


def emit_atoms_from_chunk(chunk: str, kind: str):
    atom = SemanticAtom(
        kind=kind,
        title=kind.title(),
        text=chunk.strip()[:240],
        evidence=[AtomEvidence(source=SourceMeta(type="blog", credibility_score=0.5), span="L1-L3")],
        bloom="understand",
    )
    result = [atom.model_dump()]
    if settings.llm_enabled:
        enriched = enrich_atoms([atom], limit=1)
        if enriched:
            result[0]["_enriched"] = enriched[0]
    return result
