from ..models.core import SemanticAtom, AtomGraph, GranularitySpec
from .pretype import weak_label
from .segment import naive_segments
from .complexity import estimate_duration_sec
from .jit_llm import emit_atoms_from_chunk

def dissect_text_to_atoms(text:str, spec:GranularitySpec) -> AtomGraph:
    atoms = []
    for chunk in naive_segments(text):
        kind = weak_label(chunk) or "claim"
        for a in emit_atoms_from_chunk(chunk, kind):
            atom = SemanticAtom(**a)
            atom.est_duration = atom.est_duration.__class__(seconds=int(estimate_duration_sec(atom.text, kind)))
            atoms.append(atom)
    return AtomGraph(atoms=atoms)
