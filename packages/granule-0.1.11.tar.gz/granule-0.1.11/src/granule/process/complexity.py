def estimate_tokens(text:str) -> int:
    return max(1, len(text.split()))
def estimate_duration_sec(text:str, kind:str) -> float:
    wpm = 200.0
    minutes = estimate_tokens(text)/wpm
    if kind == "step": minutes += 0.25
    return max(3.0/60.0, minutes) * 60.0
