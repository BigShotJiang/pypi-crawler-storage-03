from __future__ import annotations
from datetime import timedelta
from typing import List, Optional
from pydantic import BaseModel, Field
from .core import AtomEvidence

class DurationRange(BaseModel):
    min: timedelta
    max: timedelta
    label: Optional[str] = None

class Outcome(BaseModel):
    description: str
    bloom: str
    kpis: List[str] = Field(default_factory=list)

class AssessmentPlan(BaseModel):
    types: List[str] = Field(default_factory=list)
    weightings: Optional[dict[str,float]] = None
    passing_threshold: Optional[float] = None

class IntervalBucket(BaseModel):
    name: str
    duration: DurationRange
    purpose: str
    recommended_media: List[str]
    organization: List[str]
    example_uses: List[str] = Field(default_factory=list)
    evidence: List[AtomEvidence] = Field(default_factory=list)

class MicroLearning(BaseModel):
    title: str
    summary: str
    buckets: List[IntervalBucket]
    outcomes: List[Outcome]
