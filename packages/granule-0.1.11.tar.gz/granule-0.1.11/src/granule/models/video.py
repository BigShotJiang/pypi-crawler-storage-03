from typing import Any
from pydantic import BaseModel, Field
from granule.ingest.youtube import ingest_youtube

from pydantic import BaseModel
from pydantic_ai import Agent

from dotenv import load_dotenv  # type: ignore

class Video(BaseModel):
    url: str
    text: str = ""

    def __init__(self, **data: Any) -> None:
        super().__init__(**data)
        self.text = ingest_youtube(self.url)


class VideoGranule(BaseModel):
    summary: str
    actionable_next_steps: str


if __name__ == "__main__":
    load_dotenv()
    video = Video(url="https://www.youtube.com/watch?v=LCEmiRjPEtQ")
    agent = Agent(model="gpt-5-2025-08-07", output_type=VideoGranule)
    result = agent.run_sync(
        f'Extract the summary and actionable next steps from the video transcript. <transcript>{video.text}</transcript>'
    )
    # save the result to json
    with open("video_summary.json", "w") as f:
        f.write(result.output.model_dump_json())
