from __future__ import annotations
from pydantic import BaseModel
from typing import Optional

class SimpleGranule(BaseModel):
    source: str
    transcript: str  # full raw transcript text
    text_chars: int
    summary: Optional[str] = None
    model_used: Optional[str] = None
    error: Optional[str] = None
