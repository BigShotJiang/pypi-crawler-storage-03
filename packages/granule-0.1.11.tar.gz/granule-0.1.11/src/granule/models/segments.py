from __future__ import annotations
from pydantic import BaseModel, Field
from typing import List, Optional

class Segment(BaseModel):
    index: int
    start: float | None = None
    end: float | None = None
    text: str
    token_count: int
    kind_hint: Optional[str] = None

class SegmentSummary(BaseModel):
    segment_index: int
    micro_summary: str
    key_points: List[str] = Field(default_factory=list)
    retrieval_qas: List[dict] = Field(default_factory=list)  # {q,a}
