from __future__ import annotations
"""Video insight card schema and LLM extraction helper.

This mirrors the user-provided VideoInsightCardPayload shape allowing a richer,
section-oriented insight card distinct from the simpler TranscriptInsightCard.
"""
from typing import List, Optional, Union, Literal, Dict, Any, Tuple
from pydantic import BaseModel, Field, ConfigDict, TypeAdapter, model_validator

Number = Union[int, float]

# --------------------------
# Human Problems Ontology & Problem model (placed early to avoid fwd refs)
# --------------------------

HUMAN_PROBLEMS_ONTOLOGY: Dict[str, Any] = {
    "HumanProblemsOntology": {
        # (ontology content unchanged; moved up)
        "Survival & Physical Integrity": {
            "Mortality": {
                "problems": ["Inevitability of death", "Fear or denial of death"],
                "questions": [
                    "When I think about death, do I avoid the thought, or use it to sharpen my life priorities?",
                    "If I knew I had one year left, what would I stop doing? What would I finally begin doing?",
                ],
            },
            "Health & Bodily Integrity": {
                "problems": [
                    "Illness and injury",
                    "Disability and chronic conditions",
                    "Aging and degeneration",
                    "Exposure to pollution and toxins",
                    "Reproductive health risks",
                ],
                "questions": [
                    "Am I proactively maintaining my health through prevention, not just treatment?",
                    "Do I have systems in place to deal with unexpected illness or injury?",
                    "How do my habits today shape the body and mind I’ll inhabit in the future?",
                ],
            },
            "Basic Needs & Safety": {
                "problems": [
                    "Hunger and thirst",
                    "Malnutrition",
                    "Lack of shelter",
                    "Sleep deprivation",
                    "Violence and accidents",
                    "Natural disasters and climate risks",
                ],
                "questions": [
                    "Do I consistently meet my needs for food, water, shelter, and rest?",
                    "Am I living with a false sense of invulnerability, or am I realistically prepared for risk?",
                ],
            },
        },
        "Biological Drives & Limitations": {
            "Reproduction & Sexuality": {
                "problems": [
                    "Desire and intimacy",
                    "Parenting burdens",
                    "Infertility or unwanted pregnancy",
                    "Gender and sexual conflicts",
                ],
                "questions": [
                    "Am I intentional about how I express sexuality and intimacy?",
                    "Have I fully considered the legacy of bringing new life into the world, or choosing not to?",
                ],
            },
            "Pleasure & Addiction": {
                "problems": [
                    "Physical suffering",
                    "Addiction to substances or behaviors",
                    "Overindulgence",
                    "Dopamine dysregulation",
                    "Hedonic treadmill (diminishing returns)",
                ],
                "questions": [
                    "Do I pursue pleasures that nourish me, or ones that deplete me?",
                    "When I suffer, do I seek to escape or to learn?",
                ],
            },
            "Energy & Biological Rhythms": {
                "problems": [
                    "Sleep/wake constraints",
                    "Fatigue and burnout",
                    "Circadian disruption",
                    "Hormonal cycles and imbalances",
                ],
                "questions": [
                    "Do I treat sleep as sacred recovery or as negotiable downtime?",
                    "What would my best self look like if I mastered my energy cycles?",
                ],
            },
            "Aging & Genetic Limits": {
                "problems": [
                    "Physical decline",
                    "Cognitive decline",
                    "Genetic lottery and inequality",
                    "Fear of frailty",
                ],
                "questions": [
                    "Am I caring for my body in a way that prepares me for older age?",
                    "Do I accept aging, or resist it in unhelpful ways?",
                ],
            },
        },
        "Cognition & Knowledge": {
            "Ignorance & Uncertainty": {
                "problems": [
                    "Incomplete knowledge of world/self/universe",
                    "Future unknowability",
                    "Risk and probability miscalculation",
                ],
                "questions": [
                    "What’s the most important thing in my life I haven’t learned enough about?",
                    "Do I make peace with uncertainty, or does it paralyze me?",
                ],
            },
            "Cognitive Bias & Error": {
                "problems": [
                    "Heuristics and illusions",
                    "Misjudgments",
                    "Self-deception",
                    "Rationalization",
                ],
                "questions": [
                    "When was the last time I realized I was wrong, and how did I handle it?",
                    "Do I seek information that challenges me, or only confirms me?",
                ],
            },
            "Memory & Continuity": {
                "problems": [
                    "Forgetfulness",
                    "Distortion of memory",
                    "Trauma and intrusive memories",
                    "Identity continuity over time",
                ],
                "questions": [
                    "Do I intentionally preserve important memories?",
                    "Do I feel like the same person I was 10 years ago, and why or why not?",
                ],
            },
            "Language & Expression": {
                "problems": [
                    "Limits of language to express thought",
                    "Miscommunication of inner states",
                ],
                "questions": [
                    "Do I communicate my inner life effectively, or do I often feel misunderstood?",
                    "What truths about me cannot be fully put into words?",
                ],
            },
            "Information Ecology": {
                "problems": [
                    "Overload of information",
                    "Misinformation",
                    "Disinformation",
                    "Epistemic fragmentation",
                    "Conflicting knowledge systems",
                ],
                "questions": [
                    "Am I curating what information I consume, or letting it overwhelm me?",
                    "Do I critically evaluate sources, or take them at face value?",
                ],
            },
        },
        "Emotion & Psychology": {
            "Fear & Anxiety": {
                "problems": [
                    "Survival fear",
                    "Existential dread",
                    "Chronic worry",
                    "Paranoia",
                ],
                "questions": [
                    "Do I recognize when fear is guiding my choices?",
                    "If fear were removed, what risk would I finally take?",
                ],
            },
            "Suffering & Pain": {
                "problems": [
                    "Emotional pain",
                    "Grief and loss",
                    "Trauma",
                    "Heartbreak",
                ],
                "questions": [
                    "Have I learned to metabolize suffering into wisdom?",
                    "Do I run from discomfort so often that I miss growth?",
                ],
            },
            "Desire & Attachment": {
                "problems": [
                    "Insatiability",
                    "Clinging and dependency",
                    "Jealousy",
                    "Ambivalence about wants",
                ],
                "questions": [
                    "What do I want most, and why?",
                    "If I got everything I wanted, would I actually be content?",
                ],
            },
            "Identity & Ego": {
                "problems": [
                    "Fragile self-concept",
                    "Shame",
                    "Guilt",
                    "Pride",
                    "Conflict between authenticity and conformity",
                ],
                "questions": [
                    "Do I know who I am beyond roles and possessions?",
                    "Am I able to adapt my self-image when life changes?",
                ],
            },
            "Hope & Disappointment": {
                "problems": [
                    "Cycle of expectation and collapse",
                    "Disillusionment",
                ],
                "questions": [
                    "Do I place my hope wisely, or do I set myself up for disappointment?",
                    "How do I recover when life falls short of my expectations?",
                ],
            },
            "Mental Health": {
                "problems": [
                    "Depression",
                    "Anxiety disorders",
                    "Psychosis",
                    "Personality disorders",
                    "Compulsions",
                    "Addiction",
                ],
                "questions": [
                    "Do I regularly check in on my mental well-being?",
                    "Am I seeking help when I recognize patterns of distress?",
                ],
            },
        },
        "Social & Relational Life": {
            "Conflict & Power": {
                "problems": [
                    "Violence",
                    "War",
                    "Oppression",
                    "Exploitation",
                    "Injustice",
                ],
                "questions": [
                    "Do I avoid hard conversations, or face them with courage?",
                    "Am I a peacemaker, or do I fuel unnecessary battles?",
                ],
            },
            "Trust & Cooperation": {
                "problems": [
                    "Betrayal",
                    "Manipulation",
                    "Coordination failures",
                    "Free-rider problems",
                ],
                "questions": [
                    "Am I someone others can reliably trust?",
                    "How do I respond when trust is broken?",
                ],
            },
            "Connection & Loneliness": {
                "problems": [
                    "Isolation",
                    "Alienation",
                    "Lack of belonging or intimacy",
                ],
                "questions": [
                    "Do I feel truly connected to others?",
                    "How often do I let others really see me as I am?",
                ],
            },
            "Status & Hierarchy": {
                "problems": [
                    "Inequality",
                    "Comparison",
                    "Envy",
                    "Rivalry",
                ],
                "questions": [
                    "Am I at peace with my place in the hierarchy of life?",
                    "Do I measure my worth internally, or against others?",
                ],
            },
            "Communication & Misunderstanding": {
                "problems": [
                    "Misrepresentation",
                    "Miscommunication",
                    "Deception",
                    "Propaganda",
                ],
                "questions": [
                    "Do I listen deeply and communicate clearly?",
                    "Am I aware of when I misrepresent myself or deceive?",
                ],
            },
            "Intergenerational Dynamics": {
                "problems": [
                    "Parent-child tensions",
                    "Legacy burdens",
                    "Caregiving stress",
                ],
                "questions": [
                    "Am I navigating generational conflicts with empathy?",
                    "Do I carry burdens that belong to past or future generations?",
                ],
            },
            "Collective Behavior": {
                "problems": [
                    "In-group/out-group bias",
                    "Stereotyping",
                    "Mob mentality",
                    "Mass hysteria",
                ],
                "questions": [
                    "Do I unconsciously 'other' people who live differently than me?",
                    "Am I aware of when I’m being swept into collective irrationality?",
                ],
            },
        },
        "Meaning & Purpose": {
            "Existential Orientation": {
                "problems": [
                    "Absurdity of life",
                    "Lack of given purpose",
                    "Nihilism",
                    "Loss of faith",
                ],
                "questions": [
                    "Do I feel my life has meaning?",
                    "If not, am I actively searching or passively drifting?",
                ],
            },
            "Value Conflicts & Morality": {
                "problems": [
                    "Freedom vs. security",
                    "Individual vs. collective good",
                    "Moral ambiguity",
                ],
                "questions": [
                    "When values collide, do I resolve it consciously or by default?",
                    "Do my daily choices reflect my stated values?",
                ],
            },
            "Boredom & Emptiness": {
                "problems": [
                    "Ennui",
                    "Disengagement",
                    "Hedonic numbness",
                    "Lack of novelty",
                ],
                "questions": [
                    "Do I fill the void with distractions, or with creation?",
                    "Is my life too full of noise to hear the whisper of meaning?",
                ],
            },
            "Transcendence & Legacy": {
                "problems": [
                    "Need for legacy",
                    "Spiritual yearning",
                    "Desire for afterlife or immortality",
                ],
                "questions": [
                    "What do I seek to leave behind?",
                    "Am I pursuing a sense of connection beyond myself?",
                ],
            },
            "Authenticity & Identity": {
                "problems": [
                    "Role conflict",
                    "Struggle between conformity and authenticity",
                    "Quest for perfection",
                ],
                "questions": [
                    "Do I know who I am at my core?",
                    "Am I comfortable with the different roles I inhabit?",
                ],
            },
        },
        "Time & Scarcity": {
            "Finite Lifespan": {
                "problems": [
                    "Awareness of limited time",
                    "Midlife crises",
                    "Aging anxiety",
                ],
                "questions": [
                    "Am I spending my limited time on what matters most?",
                    "What am I postponing that can’t wait forever?",
                ],
            },
            "Resources & Attention": {
                "problems": [
                    "Scarcity of money, energy, opportunities",
                    "Distraction as a scarce resource",
                    "Zero-sum competition",
                ],
                "questions": [
                    "Do I live within my means of money, energy, and attention?",
                    "Am I prioritizing what truly matters when resources are scarce?",
                ],
            },
            "Irreversibility & Regret": {
                "problems": [
                    "Lost opportunities",
                    "Irreversible commitments",
                    "Path dependence",
                ],
                "questions": [
                    "Which regrets still haunt me, and why haven’t I released them?",
                    "Do I let past mistakes stop me, or teach me?",
                ],
            },
            "Tradeoffs & Opportunity Cost": {
                "problems": [
                    "Sacrifice",
                    "Prioritization dilemmas",
                    "Generational time horizons",
                ],
                "questions": [
                    "Do I choose wisely what to sacrifice when not everything fits?",
                    "Am I clear about what I’m willing to trade for what?",
                ],
            },
            "Urgency vs. Patience": {
                "problems": ["Balancing short-term and long-term"],
                "questions": [
                    "Am I leaning too heavily toward urgency, or too much toward delay?",
                    "Do I have a rhythm between immediate action and long-term patience?",
                ],
            },
        },
        "Meta-Problems of Existence": {
            "Conflicting Goods": {
                "problems": [
                    "Justice vs. mercy",
                    "Freedom vs. equality",
                    "Good vs. evil",
                ],
                "questions": [
                    "Do I recognize when there is no perfect choice?",
                    "How do I decide when two values I cherish collide?",
                ],
            },
            "Tragedy of Progress": {
                "problems": [
                    "Progress creating new problems",
                    "Solutions generating unintended consequences",
                ],
                "questions": [
                    "Do I evaluate long-term costs of my short-term solutions?",
                    "How often do my fixes simply move the problem elsewhere?",
                ],
            },
            "Mortality Awareness": {
                "problems": [
                    "Paradox of knowing we must die",
                    "Motivator vs. paralyzer",
                ],
                "questions": [
                    "Does knowing I will die make me timid or bold?",
                    "Am I using death as an excuse to waste life, or to cherish it?",
                ],
            },
            "Freedom & Determinism": {
                "problems": [
                    "Free will vs. fate",
                    "Responsibility vs. inevitability",
                ],
                "questions": [
                    "Do I act as if I am free, even if fate limits me?",
                    "Do I claim responsibility for my choices, or blame circumstances?",
                ],
            },
            "Self-Awareness & Consciousness": {
                "problems": [
                    "Infinite regress of doubt",
                    "Burden of metacognition",
                    "Problem of suffering",
                ],
                "questions": [
                    "Do I overthink to the point of paralysis?",
                    "Does my awareness deepen life or make it heavier?",
                ],
            },
        },
        "Modern Amplifiers & Global Problems": {
            "Technology & Identity": {
                "problems": [
                    "Privacy loss",
                    "Surveillance",
                    "Addiction to devices",
                    "Social media distortion",
                    "Digital identity conflicts",
                    "AI/automation displacement",
                ],
                "questions": [
                    "Does technology make me more human, or less?",
                    "Am I using it consciously, or is it using me?",
                ],
            },
            "Work & Economy": {
                "problems": [
                    "Burnout",
                    "Alienation from labor",
                    "Economic precarity",
                    "Inequality",
                    "Consumerism",
                    "Globalization dependencies",
                ],
                "questions": [
                    "Do I work for meaning, survival, or escape?",
                    "When I rest, do I actually recover?",
                ],
            },
            "Politics & Tribalism": {
                "problems": [
                    "Polarization",
                    "Extremism",
                    "Manipulation",
                    "Distrust of institutions",
                    "Nationalism vs. globalism",
                ],
                "questions": [
                    "Do I engage politically to understand, or just to win?",
                    "Do I define myself more by what I’m for, or by what I’m against?",
                ],
            },
            "Ecology & Planetary Risk": {
                "problems": [
                    "Climate change",
                    "Biodiversity collapse",
                    "Nuclear risk",
                    "Pandemics",
                    "AI existential risk",
                    "Mass migration and displacement",
                ],
                "questions": [
                    "Am I living as if the planet is expendable?",
                    "If everyone lived as I do, what future would exist?",
                ],
            },
            "Cultural Change": {
                "problems": [
                    "Rapid change outpacing adaptation",
                    "Fragmented identities",
                    "Cultural saturation and choice paralysis",
                    "Postmodern uncertainty",
                ],
                "questions": [
                    "Am I adapting to change, or resisting it?",
                    "Do I feel grounded in who I am despite cultural shifts?",
                ],
            },
        },
    }
}


def _build_problem_index() -> Dict[str, Tuple[List[str], List[str]]]:
    """Flatten ontology into mapping: problem label -> (path, questions)."""
    index: Dict[str, Tuple[List[str], List[str]]] = {}

    def walk(node: Any, path: List[str]):
        if not isinstance(node, dict):
            return
        problems = node.get("problems")
        questions = node.get("questions", [])
        if isinstance(problems, list):
            for p in problems:
                if isinstance(p, str):
                    index[p] = (path.copy(), list(questions))
        for k, v in node.items():
            if k in {"problems", "questions"}:
                continue
            walk(v, path + [k])

    for k, v in HUMAN_PROBLEMS_ONTOLOGY.items():
        walk(v, [k])
    return index


PROBLEM_INDEX: Dict[str, Tuple[List[str], List[str]]] = _build_problem_index()


class Problem(BaseModel):
    """Reference to a human problem entry in the ontology.

    label: canonical problem string (exact match required)
    path/questions auto-populate if omitted to keep LLM output minimal.
    """

    label: str
    path: Optional[List[str]] = Field(default=None)
    questions: List[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _enrich(self):  # type: ignore[override]
        if self.label not in PROBLEM_INDEX:
            raise ValueError(f"Unknown problem label '{self.label}'")
        expected_path, expected_questions = PROBLEM_INDEX[self.label]
        # We expose path without the artificial root "HumanProblemsOntology" for cleaner display.
        display_path = (
            expected_path[1:] if expected_path and expected_path[0] == "HumanProblemsOntology" else expected_path
        )
        if self.path is None:
            self.path = display_path
        else:
            # Accept either full path (with root) or trimmed path (without root); normalize to trimmed.
            if self.path == expected_path:
                self.path = display_path
            elif self.path != display_path:
                raise ValueError("Incorrect path for problem label")
        if not self.questions:
            # We no longer auto-populate per-problem reflective questions to reduce noise.
            self.questions = []
        return self


def list_problem_labels() -> List[str]:
    """Return all valid problem labels (flat). Useful for tooling or prompting."""
    return sorted(PROBLEM_INDEX.keys())


class VideoBadge(BaseModel):
    label: str
    value: Union[str, Number]


class VideoHeader(BaseModel):
    title: str
    subtitle: Optional[str] = None
    badges: List[VideoBadge] = Field(default_factory=list)


class VideoMeta(BaseModel):
    url: str
    id: str


class VideoEvidenceItem(BaseModel):
    kind: Literal[
        "statistic",
        "experiment",
        "expert_opinion",
        "anecdote",
        "demonstration",
        "document",
        "analogy",
        "reasoning",
        "quote",
        "other",
    ]
    text: str
    time: Optional[Number] = None


class VideoFactCheck(BaseModel):
    status: Literal["unverified", "accurate", "false", "mixed"] = "unverified"
    notes: Optional[str] = None


class VideoCounterargumentItem(BaseModel):
    text: str
    time: Optional[Number] = None


class VideoClaimItem(BaseModel):
    claim: str
    strength: Literal["weak", "moderate", "strong", "unsupported"] = "moderate"
    time: Optional[Number] = None
    evidence: List[VideoEvidenceItem] = Field(default_factory=list)
    assumptions: List[str] = Field(default_factory=list)
    counterarguments: List[VideoCounterargumentItem] = Field(default_factory=list)
    fact_check: Optional[VideoFactCheck] = None
    associated_problems: List[Union[Problem, str]] = Field(
        default_factory=list,
        description="0-5 ontology problem labels or objects; strings auto-coerced to Problem.",
    )

    @model_validator(mode="after")
    def _normalize_problems(self):  # type: ignore[override]
        if self.associated_problems:
            unique: Dict[str, Problem] = {}
            for item in self.associated_problems:
                prob = Problem(label=item) if isinstance(item, str) else item
                if prob.label not in unique:
                    unique[prob.label] = prob
            self.associated_problems = list(unique.values())  # type: ignore[assignment]
        return self


class VideoGlossaryItem(BaseModel):
    term: str
    definition: str


class VideoRhetoricDeviceItem(BaseModel):
    name: str
    time: Optional[Number] = None


class VideoMisconceptionItem(BaseModel):
    statement: str
    correction: str


class VideoQuestionItem(BaseModel):
    q: str


class VideoSegmentItem(BaseModel):
    title: str
    start_s: Number
    end_s: Number
    summary: Optional[str] = None
    key_points: Optional[List[str]] = None


class VideoTextMetricsItem(BaseModel):
    word_count: Optional[int] = None
    wpm: Optional[Number] = None
    lexical_diversity: Optional[Number] = None
    sentiment: Optional[Number] = None
    subjectivity: Optional[Number] = None


VideoSectionItem = Union[
    str,
    VideoClaimItem,
    VideoGlossaryItem,
    VideoRhetoricDeviceItem,
    VideoMisconceptionItem,
    VideoQuestionItem,
    VideoSegmentItem,
]


class VideoSection(BaseModel):
    title: str
    items: Union[List[VideoSectionItem], VideoTextMetricsItem]


class VideoFooterDevice(BaseModel):
    name: str
    time: Optional[Number] = None


class VideoFooterTimelineItem(BaseModel):
    title: Optional[str] = None
    start_s: Optional[Number] = None
    end_s: Optional[Number] = None
    detail: Optional[str] = None


class VideoFooter(BaseModel):
    persuasion_modes: List[str] = Field(default_factory=list)
    devices: List[VideoFooterDevice] = Field(default_factory=list)
    timeline: List[VideoFooterTimelineItem] = Field(default_factory=list)


class VideoInsightCardPayload(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    header: VideoHeader
    video: VideoMeta
    sections: List[VideoSection]
    footer: VideoFooter



def video_insight_schema() -> dict:
    """Return JSON schema for VideoInsightCardPayload (strict)."""
    adapter = TypeAdapter(VideoInsightCardPayload)
    return adapter.json_schema()


def minimal_video_card(
    *,
    url: str,
    video_id: str,
    title: str,
    subtitle: Optional[str] = None,
    transcript_text: Optional[str] = None,
) -> VideoInsightCardPayload:
    """Produce a minimal valid card (fallback when LLM disabled)."""
    header = VideoHeader(title=title or "Video Insight", subtitle=subtitle, badges=[])
    video = VideoMeta(url=url, id=video_id)
    sections: List[VideoSection] = []
    if transcript_text:
        # Provide a tiny TL;DR section using first lines
        snippet_lines = [l.strip() for l in transcript_text.splitlines() if l.strip()][:5]
        if snippet_lines:
            sections.append(VideoSection(title="TL;DR & Key Takeaways", items=snippet_lines[:7]))
    footer = VideoFooter()
    return VideoInsightCardPayload(header=header, video=video, sections=sections, footer=footer)
