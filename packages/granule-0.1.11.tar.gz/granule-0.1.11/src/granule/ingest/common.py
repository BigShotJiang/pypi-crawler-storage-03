from __future__ import annotations
from ..models.core import StructuredDoc, SourceMeta

def make_structured(text:str, kind:str, url:str|None=None, title:str|None=None)->StructuredDoc:
    meta = SourceMeta(type=kind, url=url, title=title)
    return StructuredDoc(source=meta, text=text, sections=[], extras={})
