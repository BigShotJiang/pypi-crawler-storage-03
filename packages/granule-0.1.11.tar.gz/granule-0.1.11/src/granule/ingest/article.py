from __future__ import annotations
try:
    from trafilatura import fetch_url, extract  # type: ignore
except Exception:  # pragma: no cover
    fetch_url = None  # type: ignore
    extract = None  # type: ignore
from .common import make_structured
from ..models.core import StructuredDoc

def ingest_article(url_or_text:str) -> StructuredDoc:
    if url_or_text.startswith("http"):
        if fetch_url and extract:
            downloaded = fetch_url(url_or_text)
            if downloaded:
                res = extract(downloaded, include_comments=False, include_tables=True, with_metadata=True, output_format="json")
                if res:
                    import json as _json
                    data = _json.loads(res)
                    text = data.get("text") or data.get("raw_text") or ""
                    title = data.get("title") or "Article"
                    return make_structured(text, kind="blog", url=url_or_text, title=title)
        # fallback path
        return make_structured(f"[FAILED TO PARSE] {url_or_text}", kind="blog", url=url_or_text, title="Article")
    else:
        return make_structured(url_or_text, kind="blog", url=None, title="Article Draft")
