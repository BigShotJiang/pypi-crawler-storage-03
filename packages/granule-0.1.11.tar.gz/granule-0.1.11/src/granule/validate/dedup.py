def dedup(atoms):
    seen, out = set(), []
    for a in atoms:
        key = (a.kind, a.text[:80])
        if key in seen: continue
        seen.add(key); out.append(a)
    return out
