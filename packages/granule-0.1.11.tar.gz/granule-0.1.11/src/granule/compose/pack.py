from datetime import timedelta
def pack_to_duration(atoms, target:timedelta):
    target_s = target.total_seconds()
    sel, total = [], 0.0
    for a in atoms:
        dur = a.est_duration.total_seconds()
        if total + dur <= target_s:
            sel.append(a); total += dur
        if total >= target_s*0.95: break
    return sel
