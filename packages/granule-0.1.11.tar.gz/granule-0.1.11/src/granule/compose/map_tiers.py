from datetime import timedelta
from ..models.tiers import MicroLearning, IntervalBucket, DurationRange, Outcome
def to_micro(atoms, name:str, target:timedelta) -> MicroLearning:
    bucket = IntervalBucket(
        name=name,
        duration=DurationRange(min=target, max=target, label=f"{int(target.total_seconds())}s"),
        purpose="Auto-composed micro unit",
        recommended_media=["text","visual"],
        organization=["fact","example"],
        example_uses=["Flashcards","Quick brief"],
    )
    return MicroLearning(title=name, summary="Auto microlearning bundle", buckets=[bucket],
                         outcomes=[Outcome(description="Understand essentials", bloom="understand")])
