Sample output file for Hubbard V parser for 6 nearest neighbors.
Material: LiCoO2.

Source: https://gitlab.com/QEF/q-e/-/blob/da5186dcfa9bd90f7012e8b0f22e057afc0d92df/HP/examples/example10/reference/HUBBARD.dat
