Sample output file for Hubbard V parser. Material: CoO.
