# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""A module containing Model response definitions."""
