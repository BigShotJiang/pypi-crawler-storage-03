#pragma once

int func1(void);
int func2(void);
int func3(void);
int func4(void);
