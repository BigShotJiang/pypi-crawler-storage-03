# EXAR: A Unified Experience-Grounded Agentic Reasoning Architecture
