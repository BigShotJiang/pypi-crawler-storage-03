# -*- coding: utf-8 -*-
"""
Created on Mon Aug 11 15:04:24 2025

@author: lotfy
"""

