#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# pygenutils/dictionaries/__init__.py

# Define what should be available when using 'from pygenutils.dictionaries import *'
__all__ = [
    'dict_handler',
    'dict_operators'
]