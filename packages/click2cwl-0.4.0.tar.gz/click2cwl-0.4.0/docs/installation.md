# Installation

Install this Python module in your conda environment using pip:

```console
pip install -c terradue click2cwl
```