from ..config.load import load_config

config = load_config()
