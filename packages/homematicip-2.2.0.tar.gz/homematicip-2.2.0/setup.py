from setuptools import setup

if __name__ == "__main__":
    setup()
    # setup(
    #     scripts=["bin/hmip_cli.py", "bin/hmip_generate_auth_token.py"],
    # )
