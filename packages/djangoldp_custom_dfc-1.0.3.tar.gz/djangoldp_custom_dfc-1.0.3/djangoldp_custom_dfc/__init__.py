__version__ = "1.0.3"
name = "djangoldp_custom_dfc"
