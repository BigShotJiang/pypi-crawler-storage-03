from django.apps import AppConfig


class DjangoldpCustomDFCConfig(AppConfig):
    name = "djangoldp_custom_dfc"
