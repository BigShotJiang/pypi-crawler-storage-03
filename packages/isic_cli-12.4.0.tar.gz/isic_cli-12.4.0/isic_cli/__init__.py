from __future__ import annotations

import logging

log = logging.getLogger("isic_cli")
log.addHandler(logging.NullHandler())
