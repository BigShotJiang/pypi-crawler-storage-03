from __future__ import annotations

from isic_cli.cli import main

if __name__ == "__main__":
    main()
