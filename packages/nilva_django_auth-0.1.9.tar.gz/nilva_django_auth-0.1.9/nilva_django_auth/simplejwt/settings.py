# This file is kept for backward compatibility
# All settings have been moved to nilva_django_auth/settings.py

from nilva_django_auth.settings import api_settings

# Re-export api_settings for backward compatibility
# This ensures that existing imports continue to work
