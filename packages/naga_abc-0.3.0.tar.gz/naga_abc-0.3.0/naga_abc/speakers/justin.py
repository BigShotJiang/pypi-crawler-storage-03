from naga_abc.speaker import Speaker

class Justin(Speaker):
    name = "Justin"
