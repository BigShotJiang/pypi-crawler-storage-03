# bpandas/__init__.py

__version__ = "0.1.0"

# Importa as funções públicas
from .btables import bfrequencies

# (no futuro você pode importar outras funções daqui também)
