from .lazy_fixture import lf
from .lazy_fixture_callable import lfc

__all__ = ("lf", "lfc")
