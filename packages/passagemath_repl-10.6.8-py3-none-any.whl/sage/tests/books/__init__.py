# sage_setup: distribution = sagemath-repl
# Here so that cython creates the correct module name
