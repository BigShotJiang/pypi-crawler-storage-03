2024-07-19 Version: 3.0.1
- Update API SegmentCloth: add param OutMode.


2023-12-06 Version: 3.0.0
- Generated python 2019-12-30 for imageseg.

2022-11-18 Version: 2.0.4
- Update RefineMask.

2022-11-01 Version: 2.0.3
- Update RefineMask.

2022-10-17 Version: 2.0.2
- Update RefineMask.

2022-09-29 Version: 2.0.1
- Update RefineMask.

2021-02-22 Version: 2.0.0
- Generated python 2019-12-30 for imageseg.

2020-12-22 Version: 1.0.15
- Update SegmentAnimal SegmentCommonImage.

2020-12-17 Version: 1.0.14
- Update SegmentFood.

2020-12-09 Version: 1.0.13
- Update SegmentCommodity.

2020-12-02 Version: 1.0.12
- Update SegmentHead.

2020-11-19 Version: 1.0.11
- Update SegmentBody.

2020-11-13 Version: 1.0.7
- Release SegmentHDSky SegmentHDCommonImage.

2020-10-13 Version: 1.0.6
- Release SegmentSkin.

2020-09-09 Version: 1.0.5
- Release ChangeSky.

