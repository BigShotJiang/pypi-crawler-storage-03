

## masim

multi-agent simulation

## Installation

To install the package with pip:

```bash
pip install masim
```
