from masim.foo import foo


def test_foo():
    assert foo() == "foo"
