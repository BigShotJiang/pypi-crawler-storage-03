import click


@click.group()
def cli():
    """masim command line interface"""
    pass
