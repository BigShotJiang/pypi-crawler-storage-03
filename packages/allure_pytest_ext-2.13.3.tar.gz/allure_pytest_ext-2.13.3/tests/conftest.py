# Intentionally empty: the plugin is auto-discovered via pytest entry points
