from .main import set_mcp

__all__ = [
    "set_mcp",
]