try:
    from .__version__ import version as __version__
except ImportError:
    __version__ = None
