import torch


def op_reference(Q, K, V, O, l):
    S = Q @ K.transpose(-1, -2)
    O = S @ V
    return O