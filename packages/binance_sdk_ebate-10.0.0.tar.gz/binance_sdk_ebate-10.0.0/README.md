# Binance SDK Ebate

This is a demo Python SDK package for migration testing from the old Binance connector.

## Installation

```bash
pip install binance-sdk-ebate

## Usage

from binance_sdk_ebate import Client

client = Client()
print(client.hello())
print(client.add(2, 3))
