class Client:
    def __init__(self):
        self.name = "Binance SDK Ebate"

    def hello(self):
        return f"Hello from {self.name}!"

    def add(self, a, b):
        """Dummy add function just for demo"""
        return a + b
