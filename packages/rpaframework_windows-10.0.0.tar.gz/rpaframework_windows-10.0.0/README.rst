rpaframework-windows
====================

This library enables Windows automation for the  `RPA Framework`_
libraries based on `uiautomation`_ dependency.

.. _RPA Framework: https://rpaframework.org
.. _uiautomation: https://github.com/yinkaisheng/Python-UIAutomation-for-Windows
