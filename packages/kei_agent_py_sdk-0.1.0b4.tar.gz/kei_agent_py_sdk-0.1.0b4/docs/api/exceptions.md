# ❗ Exceptions

<!-- API aus Code generieren -->

::: exceptions.KeiSDKError

::: exceptions.ProtocolError

::: exceptions.SecurityError

::: exceptions.AgentNotFoundError

::: exceptions.CommunicationError

::: exceptions.DiscoveryError

::: exceptions.RetryExhaustedError

::: exceptions.CircuitBreakerOpenError

::: exceptions.CapabilityError

::: exceptions.TracingError
