---
description: "Shell usage tips."
applyTo: "**"
---

# Shell usage tips

- On Windows, your commands should be run in Nushell. Don't use PowerShell commands by mistake!
- On macOS and Linux, you can use the default terminal.
