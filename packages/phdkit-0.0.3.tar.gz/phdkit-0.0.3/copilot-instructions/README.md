# copilot-instructions

Reusable general instructions for Copilot.
