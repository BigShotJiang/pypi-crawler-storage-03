# Design of the reader combinators of `configlib`

TODO
