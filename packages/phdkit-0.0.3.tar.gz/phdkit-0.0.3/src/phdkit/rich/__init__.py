"""A wrapper over `rich` to implement simple TUIs.

TODO
"""

from .subshell_mod import subshell

__all__ = ["subshell"]
