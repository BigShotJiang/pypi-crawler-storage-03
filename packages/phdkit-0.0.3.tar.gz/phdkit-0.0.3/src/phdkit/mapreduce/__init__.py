"""Enable multi-process parallelism via a simple map-reduce interface.

TODO
"""
