from ..util import todo


def configurable_fn(func):
    todo()


def setting_fn(func):
    todo()
