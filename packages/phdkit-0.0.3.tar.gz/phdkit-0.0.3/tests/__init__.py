"""Tests for phdkit package."""
