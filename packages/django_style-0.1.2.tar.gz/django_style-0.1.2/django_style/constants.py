# Known themes, for validation
THEMES = {
    "simple",
    "bootstrap",
    "tailwind",
}
