__version__ = "1.0.0"

import warnings

warnings.filterwarnings("ignore", module="azure.ai.ml")
