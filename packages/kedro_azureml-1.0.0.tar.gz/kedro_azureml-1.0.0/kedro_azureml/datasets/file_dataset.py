from kedro_azureml.datasets.pandas_dataset import AzureMLPandasDataset


class AzureMLFileDataset(AzureMLPandasDataset):
    pass
