from abacustest.lib_prepare.abacus import ReadInput, WriteInput, AbacusStru, ReadKpt, WriteKpt
from abacustest.lib_collectdata.collectdata import RESULT