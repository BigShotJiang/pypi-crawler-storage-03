* Dennis Sluijk <d.sluijk@onestein.nl>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * Vicent Cubells
  * Cristina Martin R
  * Víctor Martínez

* Helly kapatel <helly.kapatel@initos.com>
