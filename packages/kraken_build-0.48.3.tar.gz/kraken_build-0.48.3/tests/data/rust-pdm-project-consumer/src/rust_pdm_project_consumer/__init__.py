from rust_pdm_project import sum_as_string

sum_as_string(1, 2)
