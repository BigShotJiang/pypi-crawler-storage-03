use hello_world_parent::print_hello;

pub fn say_hello() {
    print_hello();
}
