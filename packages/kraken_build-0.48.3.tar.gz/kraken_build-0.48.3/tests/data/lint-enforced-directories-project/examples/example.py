"""Example module."""

import os  # Intentionally unused import


def example() -> str:  # intentionally missing return
    """Example function"""
    print("Salut!")
