__version__ = "0.1.0"


def foo() -> None:
    print("Hello, world from slap-project!")
