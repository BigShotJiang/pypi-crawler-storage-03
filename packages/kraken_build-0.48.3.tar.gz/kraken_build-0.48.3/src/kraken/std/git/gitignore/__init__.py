"""
Tools for parsing and generating `.gitignore` files.
"""
