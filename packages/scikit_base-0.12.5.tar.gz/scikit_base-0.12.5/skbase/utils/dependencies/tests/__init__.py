# -*- coding: utf-8 -*-
"""Testing utilities for depeendency checkers."""
