from .functions import *
def initFuncs(self):
    self.browse_dir = browse_dir
    self.make_params = make_params
    self.start_collect = start_collect
    self.append_log = append_log
    self.populate_results = populate_results
    self.open_one = open_one
    self.open_all_hits = open_all_hits
    return self
