from project.api.blank.common import SimpleBlankAPI


class ClientBlankAPI(SimpleBlankAPI):
    pass
