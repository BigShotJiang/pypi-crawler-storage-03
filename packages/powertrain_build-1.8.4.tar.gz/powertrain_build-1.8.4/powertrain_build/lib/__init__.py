# Copyright 2024 Volvo Car Corporation
# Licensed under Apache 2.0.

"""powertrain_build.lib."""
