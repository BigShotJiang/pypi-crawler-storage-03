# NOMAD-CAMELS Driver for Thorlabs MFF

Driver for the Thorlabs MFF motorized filter flip mount written for the measurement software [NOMAD-CAMELS](https://fau-lap.github.io/NOMAD-CAMELS/).


## Features
The position can be set and read, together with transit time.


## Documentation

For more information visit the [documentation](https://fau-lap.github.io/NOMAD-CAMELS/doc/instruments/instruments.html).