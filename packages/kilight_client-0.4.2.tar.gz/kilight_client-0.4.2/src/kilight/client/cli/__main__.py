from sys import exit
from kilight.client.cli.entrypoint import entrypoint


if __name__ == "__main__":
    exit(entrypoint())