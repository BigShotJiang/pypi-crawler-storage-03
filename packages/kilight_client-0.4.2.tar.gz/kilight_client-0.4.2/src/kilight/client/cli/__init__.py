from __future__ import annotations

from .entrypoint import entrypoint

__all__ = [
    "entrypoint"
]