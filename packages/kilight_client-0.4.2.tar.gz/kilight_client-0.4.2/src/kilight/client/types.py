from collections import namedtuple

WhiteLevels = namedtuple(
    "WhiteLevels",
    [
        "warm_white",
        "cold_white"
    ]
)
