
class InvalidStingerStructure(Exception):
    pass