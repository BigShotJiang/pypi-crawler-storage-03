"""Test package for git-sync-files."""
