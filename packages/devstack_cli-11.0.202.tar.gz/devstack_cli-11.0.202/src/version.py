"""
constants, set by build
"""

MAJOR = '11'
BRANCH_NAME = 'release-11'
BUILD_DATE = '2025-08-22-035525'
SHORT_SHA = '000400e'
VERSION = '11+release-11.2025-08-22-035525.000400e'
