"""Gene information tools for BioMCP."""

from .getter import get_gene

__all__ = ["get_gene"]
