class InvalidIdentifierXMLRepresentationException(Exception):
    pass


class IdentifierValidationException(Exception):
    pass
