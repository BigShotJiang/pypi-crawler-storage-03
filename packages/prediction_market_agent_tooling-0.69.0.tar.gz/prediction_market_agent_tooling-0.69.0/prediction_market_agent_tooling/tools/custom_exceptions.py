class CantPayForGasError(ValueError):
    pass


class OutOfFundsError(ValueError):
    pass
