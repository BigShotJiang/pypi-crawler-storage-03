# flake8: noqa: F401
"""packaging.version

Since distutils is deprecated, we keep our own copy of version parsing.
"""
from .version import parse
