This directory contains model- and geometry-specific hooks
for analyzing FEM data. These scripts are used by the fem*.py
scripts in the parent directory and basically just contain
optional hooks.
