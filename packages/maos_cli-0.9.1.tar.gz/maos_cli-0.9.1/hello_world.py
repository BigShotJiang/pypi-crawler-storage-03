def hello_world():
    """A simple function that prints Hello, World!"""
    print("Hello, World!")

if __name__ == "__main__":
    hello_world()