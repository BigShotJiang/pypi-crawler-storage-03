def test():
    return 42