"""Initialize the app"""

__version__ = "0.1.9.2"
__title__ = "corptax"
