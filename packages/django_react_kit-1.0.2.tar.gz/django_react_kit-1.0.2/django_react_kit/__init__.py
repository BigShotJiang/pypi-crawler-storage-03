"""
Django React Kit - Server-Side Rendering for React in Django
"""

__version__ = "1.0.2"
__author__ = "Django React Kit Team"

default_app_config = 'django_react_kit.apps.DjangoReactKitConfig'