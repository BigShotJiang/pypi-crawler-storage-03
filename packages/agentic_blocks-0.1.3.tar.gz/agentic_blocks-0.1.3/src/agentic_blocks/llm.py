"""
Simplified LLM client for calling completion APIs.
"""

import os
from typing import List, Dict, Any, Optional, Union

from dotenv import load_dotenv
from openai import OpenAI

from agentic_blocks.messages import Messages


class LLMError(Exception):
    """Exception raised when there's an error calling the LLM API."""

    pass


def call_llm(
    messages: Union[Messages, List[Dict[str, Any]]],
    tools: Optional[List[Dict[str, Any]]] = None,
    api_key: Optional[str] = None,
    model: str = "gpt-4o-mini",
    **kwargs,
) -> str:
    """
    Call an LLM completion API with the provided messages.

    Args:
        messages: Either a Messages instance or a list of message dicts
        tools: Optional list of tools in OpenAI function calling format
        api_key: OpenAI API key (if not provided, loads from .env OPENAI_API_KEY)
        model: Model name to use for completion
        **kwargs: Additional parameters to pass to OpenAI API

    Returns:
        The assistant's response content as a string

    Raises:
        LLMError: If API call fails or configuration is invalid
    """
    # Load environment variables
    load_dotenv()

    # Get API key
    if not api_key:
        api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise LLMError(
            "OpenAI API key not found. Set OPENAI_API_KEY environment variable or pass api_key parameter."
        )

    # Initialize OpenAI client
    client = OpenAI(api_key=api_key)

    # Handle different message input types
    if isinstance(messages, Messages):
        conversation_messages = messages.get_messages()
    else:
        conversation_messages = messages

    if not conversation_messages:
        raise LLMError("No messages provided for completion.")

    try:
        # Prepare completion parameters
        completion_params = {
            "model": model,
            "messages": conversation_messages,
            **kwargs,
        }

        if tools:
            completion_params["tools"] = tools
            completion_params["tool_choice"] = "auto"

        # Make completion request
        response = client.chat.completions.create(**completion_params)

        # Extract and return response content
        return response.choices[0].message.content or ""

    except Exception as e:
        raise LLMError(f"Failed to call LLM API: {e}")


def example_usage():
    """Example of how to use the call_llm function."""
    # Example 1: Using with Messages object
    messages_obj = Messages(
        system_prompt="You are a helpful assistant.",
        user_prompt="What is the capital of France?",
    )

    # Example 2: Using with raw message list
    messages_list = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is the capital of France?"},
    ]

    # Example tools
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get current weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "City and state, e.g. San Francisco, CA",
                        }
                    },
                    "required": ["location"],
                },
            },
        }
    ]

    try:
        # Call with Messages object
        print("Using Messages object:")
        response1 = call_llm(messages_obj, temperature=0.7)
        print(f"Response: {response1}")

        # Call with raw message list
        print("\nUsing raw message list:")
        response2 = call_llm(messages_list, tools=tools, temperature=0.5)
        print(f"Response: {response2}")

    except LLMError as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    example_usage()
