# Version
POKIE_GUNICORN_VERSION = ["1", "1", "1"]


def get_version():
    return ".".join(POKIE_GUNICORN_VERSION)
