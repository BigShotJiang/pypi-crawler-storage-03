# Contributing

## Development install

> [!NOTE]
> NodeJS is required to build the extension package. Installation instructions [here](https://nodejs.org/en/download/).

The `jlpm` command is JupyterLab's pinned version of
[yarn](https://yarnpkg.com/) that is installed with JupyterLab. You may use
`yarn` or `npm` in lieu of `jlpm` below.

```bash
# Clone the repo to your local environment
# Change directory to the qiskit-code-assistant-jupyterlab directory
# Install package in development mode
pip install -e "."
# Link your development version of the extension with JupyterLab
jupyter labextension develop . --overwrite
# Server extension must be manually installed in develop mode
jupyter server extension enable qiskit_code_assistant_jupyterlab
# Rebuild extension Typescript source after making changes
jlpm build
```

You can watch the source directory for changes in the extension's source and automatically rebuild the extension, then run JupyterLab at the same time in a different terminal.

```bash
# Watch the source directory in one terminal, automatically rebuilding when needed
jlpm watch
# Run JupyterLab in another terminal
jupyter lab
```

With the watch command running, every saved change will immediately be built locally and available in your running JupyterLab. Refresh JupyterLab to load the change in your browser (you may need to wait several seconds for the extension to be rebuilt).

By default, the `jlpm build` command generates the source maps for this extension to make it easier to debug using the browser dev tools. To also generate source maps for the JupyterLab core extensions, you can run the following command:

```bash
jupyter lab build --minimize=False
```

## Development uninstall

```bash
# Server extension must be manually disabled in develop mode
jupyter server extension disable qiskit_code_assistant_jupyterlab
pip uninstall qiskit_code_assistant_jupyterlab
```

In development mode, you will also need to remove the symlink created by `jupyter labextension develop`
command. To find its location, you can run `jupyter labextension list` to figure out where the `labextensions`
folder is located. Then you can remove the symlink named `qiskit-code-assistant-jupyterlab` within that folder.

## Packaging the extension

See [RELEASE](RELEASE.md)
