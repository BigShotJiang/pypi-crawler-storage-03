from technical_analysis.main import main

if __name__ == "__main__":
    main()