import time

def gen_id():
    return int(time.time()) << 32
