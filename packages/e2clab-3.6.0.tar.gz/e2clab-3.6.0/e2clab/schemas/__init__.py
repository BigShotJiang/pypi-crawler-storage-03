from e2clab.schemas.utils import is_valid_conf

__all__ = ["is_valid_conf"]
