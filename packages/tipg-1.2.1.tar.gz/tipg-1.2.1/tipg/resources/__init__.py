"""tipg.resources"""
