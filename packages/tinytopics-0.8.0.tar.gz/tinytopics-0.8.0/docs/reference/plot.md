# Plots

::: tinytopics.plot
    options:
      members:
        - plot_loss
        - plot_structure
        - plot_top_terms
      show_root_heading: true
      show_source: false
