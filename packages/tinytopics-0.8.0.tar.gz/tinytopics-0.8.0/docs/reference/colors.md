# Colors

::: tinytopics.colors
    options:
      members:
        - pal_tinytopics
        - scale_color_tinytopics
      show_root_heading: true
      show_source: false
