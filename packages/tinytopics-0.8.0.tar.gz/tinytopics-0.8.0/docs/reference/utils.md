# Utilities

::: tinytopics.utils
    options:
      members:
        - NumpyDiskDataset
        - set_random_seed
        - generate_synthetic_data
        - align_topics
        - sort_documents
      show_root_heading: true
      show_source: false
