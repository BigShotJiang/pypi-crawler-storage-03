# Models

::: tinytopics.models
    options:
      members:
        - NeuralPoissonNMF
      show_root_heading: true
      show_source: false
