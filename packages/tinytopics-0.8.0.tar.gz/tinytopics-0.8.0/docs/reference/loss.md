# Losses

::: tinytopics.loss
    options:
      members:
        - poisson_nmf_loss
      show_root_heading: true
      show_source: false
