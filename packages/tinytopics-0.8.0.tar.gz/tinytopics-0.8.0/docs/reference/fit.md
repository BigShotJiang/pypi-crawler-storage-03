# Fit topic models

::: tinytopics.fit
    options:
      members:
        - fit_model
      show_root_heading: true
      show_source: false

::: tinytopics.fit_distributed
    options:
      members:
        - fit_model_distributed
      show_root_heading: true
      show_source: false
