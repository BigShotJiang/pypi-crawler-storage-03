# Settings Models

::: cjkcms.models.wagtailsettings_models.LayoutSettings
::: cjkcms.models.wagtailsettings_models.SocialMediaSettings