# Management Commands in CjkCMS

* ```./manage.py init-collections.py``` - [Initialize collections](init-collections.md)
* ```./manage.py clear-embeds``` - [Clear oembed cache](clear-embeds.md)