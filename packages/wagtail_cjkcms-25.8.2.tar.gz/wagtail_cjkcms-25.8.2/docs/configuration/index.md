# Configuration of wagtail-cjkcms

## Settings

### Layout settings

#### Breadcrumbs

CjkCMS provides breadcrumbs for pages. You can enable them by activating a checkbox in:
```Settings -> Layout -> Breadcrumbs```

You can use any svg file as a separator. Built in icons are (bootstrap icons):
* chevron-right
* caret-right
* caret-right-fill
* slash