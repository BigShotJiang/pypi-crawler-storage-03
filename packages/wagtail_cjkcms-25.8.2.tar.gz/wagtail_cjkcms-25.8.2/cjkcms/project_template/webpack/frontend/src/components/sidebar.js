window.console.log("sidebar is loaded");
