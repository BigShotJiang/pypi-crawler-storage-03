// import scss entry file here for app2.js

// import other JS components as we like
import "../components/sidebar";

window.document.addEventListener("DOMContentLoaded", function () {
  window.console.log("dom ready 2");
});
