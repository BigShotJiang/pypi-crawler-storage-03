from txgraffiti.heuristics.fajtlowicz import *
from txgraffiti.heuristics.delavina import *
from txgraffiti.heuristics.davila import *
