from watercrawl_plugin import get_settings


OPENAI_API_KEY = get_settings('OPENAI_API_KEY', None)
EXTRACT_SYSTEM_PROMPT = get_settings('EXTRACT_SYSTEM_PROMPT', None)
