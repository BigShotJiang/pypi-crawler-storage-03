initial.res: written by SWAT+ editor v3.0.8 on 2025-07-29 21:28 for SWAT+ rev.61.0.1
name                       org_min              pest              path              hmet              salt  description       
initwet1                   no_init              null              null              null              null  null              
