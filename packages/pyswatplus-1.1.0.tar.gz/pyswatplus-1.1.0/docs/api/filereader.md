::: pySWATPlus.FileReader
