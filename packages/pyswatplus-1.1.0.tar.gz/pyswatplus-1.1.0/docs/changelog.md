# Release Notes


## Version 1.1.0 (August 26, 2025)

- Added a new class `pySWATPlus.SensitivityAnalyzer` to support sensitivity simulations with two main methods:

    - `simulated_timeseries_df`: Generates a time series `DataFrame` directly from a simulation output file.  
    - `simulation_by_sobol_sample`: Provides a high-level interface for running sensitivity simulations with parallel computing and extracting results from multiple output files.

- Changes in `pySWATPlus.TxtinoutReader` class:

    - `copy_required_files`: New method to copy required files into a separate directory before running simulations. This protects the main `TxtInOut` folder and enables safer, more controlled workflows.
    - `run_swat_in_other_dir`: Enhanced with new optional parameters, allowing users to configure all necessary inputs in a single call for improved usability.

- The `has_units` input parameter, which specifies whether the third line of `SWAT+` input or output files contains column units, is now **mandatory** across the `pySWATPlus` package (previously optional) to ensure consistent file handling.

- Added [Contributing Guidelines](https://swat-model.github.io/pySWATPlus/CONTRIBUTING) with clear instructions for setting up the development environment, reporting issues, and submitting contributions.

- Added [Code of Conduct](https://github.com/swat-model/pySWATPlus/blob/main/CODE_OF_CONDUCT.md) to define standards for a welcoming, respectful, and inclusive community.


## Version 1.0.3 (July 30, 2025)

- Configured GitHub Actions for automatic documentation builds.

- Configured GitHub Actions for testing with `pytest` and integrated **Codecov** to monitor and report test coverage.

- Switched testing environment from `Ubuntu` to `Windows` with `pytest` to run the `.exe` file of the SWAT+ model.


## Version 1.0.2 (July 25, 2025)

- Updated sample data.

- Added additional test functions.

- Added several badges to the `README` for improved code visibility.

- Fixed code bugs and updated documentation.

- Modified `pySWATPlus` citation.


## Version 1.0.1 (July 23, 2025)

- Added sample data.

- Added more test functions using the sample data.

- Renamed some methods and variables for better consistency and clarity.

- Fixed code bugs and updated documentation.


## Version 1.0.0 (July 22, 2025)

- Refactored `TxtinoutReader` and `FileReader` for improved consistency, clarity, and simplicity.

- Removed `SWATProblem` and `SWATProblemMultimodel` classes due to usability issues; a better user interface for SWAT+ parameter calibration will be developed in the future.

- Fixed bugs in reading TXT files.

- Added GitHub Actions for static type checking with `mypy` to verify annotations throughout the codebase.

- Updated documentation on sensitivity analysis and other code changes.

- Removed `LICENSE` PyPI classifier from `pyproject.toml` and updated configuration according to packaging guidelines.

- Added Development Status PyPI classifier `Beta` to `pyproject.toml`.

- Added new package dependency `typing-extensions`.


## Version 0.2.20 (July 19, 2025)

- Updated key parts of the documentation to reflect recent code changes.


## Version 0.2.19 (July 19, 2025)

- Updated minimum Python requirement from 3.6 to 3.10.

- Added GitHub Actions for linting with `flake8` to enforce PEP8 formatting.

- Added GitHub Actions for testing with `pytest` to ensure code reliability.

- Fixed variable type annotations for static type checking.

- Added classifiers and keywords to `pyproject.toml`.

- Configured `pyproject.toml` to suppress `DeprecationWarning`.

- Removed `numpy` dependency as it is included with other required packages.


## Version 0.2.18 (May 4, 2025)

- Migrated all configurations to `pyproject.toml` for improved packaging.


## Version 0.2.17 (May 4, 2025)

- Renamed several variables to improve consistency across functions.

- Modified input and output variable type annotations to align with advanced-style static type checking.

- Fixed multiple code bugs.

- Improved code documentation.


## Version 0.2.16 (March 30, 2025)

- Updated `publish.yml` deploy-docs task to grant `contents: write` permission


## Version 0.2.15 (March 30, 2025)

- Simplified workflow by creating GitHub releases via `gh` CLI instead of the `release` action


## Version 0.2.14 (March 30, 2025)

- Docs: Published project documentation to GitHub Pages.


## Version 0.2.13 (March 23, 2025)

- Fixed bugs on `SWATProblemMultimodel` module


## Version 0.2.12 (March 15, 2025)

- Added new sections `README`


## Version 0.2.11 (March 10, 2025)

- Updated `publish.yml` workflow to grant `contents: write` permission (enables pushing to the repository).


## Version 0.2.9 (March 9, 2025)

- Updated MkDocs installation in workflow with additional plugins/extensions.


## Version 0.2.8 (March 9, 2025)

- Updated workflow to install documentation dependencies (`mkdocstrings`, `mkdocs-jupyter`).


## Version 0.2.7 (March 9, 2025)

- Removed automatic GitHub Release creation from `publish.yml`.


## Version 0.2.6 (March 9, 2025)

- Enabled dynamic versioning in `pyproject.toml` (`dynamic = ["version"]`).


## Version 0.2.5 (March 9, 2025)

- Fixed bug in `setuptools_scm` configuration


## Version 0.2.4 (March 9, 2025)

- Configured versioning with setuptools_scm (post-release, no local version).

- Updated publish workflow to trigger only on version tags (v*).


## Version 0.2.0 (March 9, 2025)

- Added Zenodo badges to the `README` for improved code visibility.

- Completed migration from the TestPyPI repository to the main PyPI repository.

- Implemented GitHub Actions workflow for automated releases to PyPI and GitHub repositories.


## Version 0.1.36 (March 15, 2024)

- Migrated project to this repository.

- Initial release under the new repository structure.
