# create_python_app

A short description of your package.

## Installation
```bash
pip install create_python_app
```

## Usage
```python
import create_python_app
```
