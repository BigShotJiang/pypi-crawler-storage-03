Using DynamicForms
==================

.. toctree::

   Quick start <quick_start>
   templates

.. todo:: Custom page template
.. todo:: Custom dialog classes for dialog formatting
.. todo:: SingleRecordViewSet
.. todo:: RenderMixin - parameters and what they do
