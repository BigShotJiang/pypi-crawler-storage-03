### INTENTION and CONTEXT
Extend the examples for Scenario Outline `{Scenario Name}` in `{Feature File}` as described in task `{Task Name}`
