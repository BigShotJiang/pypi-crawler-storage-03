### INTENTION and CONTEXT
My intention and goal is to find the artifact among all the given artifacts that best fits the context of the provided context here, or to which given artefact this context contributes the most to it:

```
{specific context}
```