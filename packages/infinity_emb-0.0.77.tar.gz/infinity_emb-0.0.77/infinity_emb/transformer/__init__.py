# SPDX-License-Identifier: MIT
# Copyright (c) 2023-now michaelfeil
