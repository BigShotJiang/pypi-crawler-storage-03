# logger-console

A lightweight and flexible logging utility for Python projects.  
`logger-console` provides a simple way to configure and use logging across applications, with support for console and file handlers, log rotation, and custom formatting.

---

## 🚀 Features

- Easy-to-use logger with minimal configuration
- Console and file logging out of the box
- Log rotation support
- Customizable log levels and formats
- Designed for reuse in any Python project

---

## 📦 Installation

```bash
pip install logger-console
