from pathlib import Path

__version__ = "0.4.1"

# Get the absolute path of the directory where this file is located
FRANKEN_DIR = Path(__file__).resolve().parent
