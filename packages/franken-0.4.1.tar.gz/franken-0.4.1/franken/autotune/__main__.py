from franken.autotune.script import cli_entry_point


if __name__ == "__main__":
    cli_entry_point()
