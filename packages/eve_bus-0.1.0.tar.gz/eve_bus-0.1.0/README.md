# Eve Bus

A lightweight, reliable event bus implementation using Redis as the message broker. This library provides a simple interface for publishing and subscribing to events in distributed systems.

## Features

- Publish and subscribe to events using Redis
- Thread-safe implementation
- Support for multiple event handlers per event
- Automatic retry mechanism for failed event handlers
- Clean shutdown and resource management
- Easy integration with dependency injection frameworks

## Installation

```bash
pip install eve-bus
```

## Usage

### Basic Setup

```python
from eve.adapters.events import RedisEventBus, subscribe, publish
from eve.domain.events import Event
from redis import Redis

# Create a Redis client
redis_client = Redis(host='localhost', port=6379, db=0)

# Create an event bus instance
event_bus = RedisEventBus(redis_client)

# Define an event class
class UserCreated(Event):
    user_id: str
    username: str

# Subscribe to an event
@subscribe('UserCreated')
def handle_user_created(event_data):
    print(f"User created: {event_data['username']}")

# Publish an event
user_created_event = UserCreated(user_id='123', username='john_doe')
publish(user_created_event)

# When done, shutdown the event bus
event_bus.shutdown()
```

### Using with Dependency Injection

```python
from dependency_injector import containers, providers
from eve.adapters.events import RedisEventBus
from redis import Redis

class Container(containers.DeclarativeContainer):
    # Redis client provider
    redis_client = providers.Singleton(
        Redis,
        host='localhost',
        port=6379,
        db=0
    )

    # Event bus provider
    event_bus = providers.Singleton(RedisEventBus, redis_client=redis_client)

# Create a container instance
container = Container()

# Get the event bus instance
event_bus = container.event_bus()
```

## Configuration

You can configure the event bus by setting the following environment variables:

- `EVENT_CHANNEL`: Prefix for Redis channels (default: 'event')

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.