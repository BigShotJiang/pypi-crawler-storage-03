"""Eve Event Bus

A lightweight event bus implementation using Redis.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"