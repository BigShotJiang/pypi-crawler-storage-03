from typing import Final

from ..schema.xwt import XWT


class MainClass(XWT):
    URL: Final = 'https://xtremewrestlingtorrents.net/'
