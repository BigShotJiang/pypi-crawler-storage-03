import jianpu_ly;jianpu_ly.main()
