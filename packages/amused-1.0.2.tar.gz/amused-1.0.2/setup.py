"""
Amused - Open Source Muse S BLE Protocol Implementation

This setup.py exists for backwards compatibility and special configurations.
Main configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()