from .md import multiplicacion
from .md import division
from .md import suma
from .md import resta