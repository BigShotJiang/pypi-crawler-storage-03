from .v19 import HanifX_v19

__version__ = "19.0.0"
