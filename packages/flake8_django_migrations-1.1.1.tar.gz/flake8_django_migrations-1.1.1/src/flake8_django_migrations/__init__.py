from .plugin import Plugin

__version__ = "1.1.1"
__all__ = ("Plugin",)
