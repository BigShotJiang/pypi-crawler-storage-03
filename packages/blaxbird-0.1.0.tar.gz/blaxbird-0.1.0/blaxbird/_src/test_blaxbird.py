import chex


def test_blaxbird():
  chex.assert_equal(1, 1)
