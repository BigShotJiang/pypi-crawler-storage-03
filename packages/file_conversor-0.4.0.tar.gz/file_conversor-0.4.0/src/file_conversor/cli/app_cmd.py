# src\file_conversor\cli\app_cmd.py

import tomllib
import sys
import typer

from rich import print

from pathlib import Path
from typing import Annotated, Any

# user-provided imports
from file_conversor.cli import *

from file_conversor.system import CURR_PLATFORM, PLATFORM_WINDOWS

from file_conversor.config import Environment, Configuration, State, Log
from file_conversor.config.locale import get_translation

# Get app config
CONFIG = Configuration.get_instance()
STATE = State.get_instance()
LOG = Log.get_instance()

_ = get_translation()
logger = LOG.getLogger()

# Create a Typer CLI application
app_cmd = typer.Typer(
    rich_markup_mode="markdown",
    no_args_is_help=True,
    context_settings={
        "help_option_names": ["-h", "--help"],
    }
)

# PANELS
UTILS_CONFIG_PANEL = _("Utils and Config")
OFFICE_PANEL = _("Office files")
FILE_PANEL = _("Other files")

###############
# OFFICE PANEL
###############

app_cmd.add_typer(doc_cmd,
                  name="doc",
                  help=f"{_('Document file manipulation')} {_('(requires MS Office / LibreOffice)')})",
                  rich_help_panel=OFFICE_PANEL)

app_cmd.add_typer(xls_cmd,
                  name="xls",
                  help=f"{_('Spreadsheet file manipulation')} {_('(requires MS Office / LibreOffice)')})",
                  rich_help_panel=OFFICE_PANEL)

app_cmd.add_typer(ppt_cmd,
                  name="ppt",
                  help=f"{_('Presentation file manipulation')} {_('(requires MS Office / LibreOffice)')})",
                  rich_help_panel=OFFICE_PANEL)


###############
# FILE PANEL
###############

app_cmd.add_typer(audio_video_cmd,
                  name="audio-video",
                  help=_("Audio / Video file manipulation (requires FFMpeg external library)"),
                  rich_help_panel=FILE_PANEL)

app_cmd.add_typer(hash_cmd,
                  name="hash",
                  help=_("Hashing manipulation (check, gen, etc)"),
                  rich_help_panel=FILE_PANEL)

app_cmd.add_typer(image_cmd,
                  name="image",
                  help=_("Image file manipulation"),
                  rich_help_panel=FILE_PANEL)

app_cmd.add_typer(pdf_cmd,
                  name="pdf",
                  help=_("PDF file manipulation"),
                  rich_help_panel=FILE_PANEL)

app_cmd.add_typer(text_cmd,
                  name="text",
                  help=_("Text file manipulation (json, xml, etc)"),
                  rich_help_panel=FILE_PANEL)

######################
# UTILS/CONFIG PANEL
######################

if CURR_PLATFORM == PLATFORM_WINDOWS:
    app_cmd.add_typer(win_cmd,
                      name="win",
                      help=_("Windows OS commands (for Windows ONLY)"),
                      rich_help_panel=UTILS_CONFIG_PANEL)

app_cmd.add_typer(config_cmd,
                  name="config",
                  help=_("Configure default options"),
                  rich_help_panel=UTILS_CONFIG_PANEL)

app_cmd.add_typer(pipeline_cmd,
                  name="pipeline",
                  help=f"""{_('Pipeline file processing (task automation)')}

{_('The pipeline processsing by processing an input folder, passing those files to the next pipeline stage, and processing them inside that stage. This process continues (output of the current stage is the input of the next stage), until those files reach the end of the pipeline.')}



{_('Example')}:

- {_('Input folder')} => {_('Stage 1')} => {_('Stage 2')} => ... => {_('Output Folder')}
""",
    rich_help_panel=UTILS_CONFIG_PANEL)

#####################
#     APP PANEL
#####################


def version_callback(value: bool):
    if value:
        project_toml = Environment.get_resources_folder() / "pyproject.toml"
        if not project_toml.exists():
            project_toml = Path() / "pyproject.toml"
        PYPROJECT = tomllib.loads(project_toml.read_text())
        VERSION = str(PYPROJECT["project"]["version"])
        typer.echo(f"File Conversor {VERSION}")
        raise typer.Exit()


# Main callback, to process global options
@app_cmd.callback(
    help=f"""
        # File Conversor - CLI
    """,
    epilog=f"""
        {_('For more information, visit')} [http://www.github.com/andre-romano/file_conversor](http://www.github.com/andre-romano/file_conversor)
    """)
def main_callback(
        no_log: Annotated[bool, typer.Option(
            "--no-log", "-nl",
            help=_("Disable file logs"),
            is_flag=True,
        )] = False,
        no_progress: Annotated[bool, typer.Option(
            "--no-progress", "-np",
            help=f"{_('Disable progress bars')}",
            is_flag=True,
        )] = False,
        quiet: Annotated[bool, typer.Option(
            "--quiet", "-q",
            help=f"{_('Enable quiet mode (only display errors and progress bars)')}",
            is_flag=True,
        )] = False,
        verbose: Annotated[bool, typer.Option(
            "--verbose", "-v",
            help=_("Enable verbose mode"),
            is_flag=True,
        )] = False,
        debug: Annotated[bool, typer.Option(
            "--debug", "-d",
            help=_("Enable debug mode"),
            is_flag=True,
        )] = False,
        version: Annotated[bool, typer.Option(
            "--version", "-V",
            help=_("Display version"),
            callback=version_callback,
            is_flag=True,
        )] = False,
        overwrite: Annotated[bool, typer.Option(
            "--overwrite", "-o",
            help=f"{_("Overwrite output files")}. Defaults to False (do not overwrite).",
            is_flag=True,
        )] = False,
):
    STATE.update({
        "no-log": no_log,
        "no-progress": no_progress,
        "quiet": quiet,
        "verbose": verbose,
        "debug": debug,
        "overwrite": overwrite,
    })
    logger.debug(f"Command: {sys.argv}")
    Environment.get_executable()
