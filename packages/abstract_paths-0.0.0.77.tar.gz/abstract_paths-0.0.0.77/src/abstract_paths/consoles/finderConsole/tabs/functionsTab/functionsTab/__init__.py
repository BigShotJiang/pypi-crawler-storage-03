from .main import functioinsTab
from abstract_gui.QT6.startConsole import  startConsole

def startFunctionsConsole():
    startConsole(functionTab)
