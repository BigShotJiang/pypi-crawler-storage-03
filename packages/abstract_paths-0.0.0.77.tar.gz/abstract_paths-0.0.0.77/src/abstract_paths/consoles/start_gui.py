from finderConsole import *

startFinderConsole()
