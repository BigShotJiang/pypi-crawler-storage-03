"""Modules related to AlphaFold Knowledge Base."""
