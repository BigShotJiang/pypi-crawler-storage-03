# from mymodule import *

from .cuda import add_one
