from .exception_handler import exception_handler

__all__ = ("exception_handler",)
__version__ = "2.1.0"
