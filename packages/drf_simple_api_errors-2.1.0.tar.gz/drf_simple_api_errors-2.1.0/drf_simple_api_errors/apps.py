from django.apps import AppConfig


class DRFSimpleAPIErrors(AppConfig):
    name = "drf_simple_api_errors"
