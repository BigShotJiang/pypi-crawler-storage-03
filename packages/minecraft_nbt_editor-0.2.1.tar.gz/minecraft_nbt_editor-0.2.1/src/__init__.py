"""
Minecraft NBT Editor - Python 版本
支援 Java 和 Bedrock Minecraft 的 NBT 文件編輯
"""

__version__ = "0.2.0"
__author__ = "geniusshiun"
__license__ = "MIT"
