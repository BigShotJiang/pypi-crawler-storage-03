
OUTPUT_TYPE = 'default'

def set_output_type(output_type):
    global OUTPUT_TYPE
    OUTPUT_TYPE = output_type
