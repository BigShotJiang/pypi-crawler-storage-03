"""Dummy Test."""


class TestDummy:
    """Dummy Test."""

    def test_dummy(self):
        """Dummy Test."""
        assert True
