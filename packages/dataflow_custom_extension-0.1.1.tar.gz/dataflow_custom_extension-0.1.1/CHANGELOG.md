# Changelog

## 0.1.0

- Added new command `dataflow-custom:hub-restart`
- modified connectionLost dialog to use `dataflow-custom:hub-restart` instead of `hub:restart`
