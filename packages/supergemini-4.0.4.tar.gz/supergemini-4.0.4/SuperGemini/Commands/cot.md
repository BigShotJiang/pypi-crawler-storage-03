---
description: "SuperGemini Framework chain-of-thought tool for systematic task orchestration"
allowed-tools: ["chain_of_thought"]
---

# SuperGemini Framework Instructions

## Initial Task Analysis Protocol
For ALL user requests, you **MUST** begin with the `chain_of_thought` tool for systematic task orchestration.

### Chain of Thought Tool
The `chain_of_thought` tool is a powerful guide that maximizes your cognitive capabilities and ensures optimal framework utilization. This tool provides essential instructions and guidance to help you leverage the SuperGemini Framework effectively, building trust with users through systematic task orchestration. Using this tool is highly efficient and absolutely required for all task initiation.

**Important**: This systematic approach is fundamental to SuperGemini Framework operation. The `chain_of_thought` tool enables comprehensive analysis, proper resource allocation, and ensures you utilize all available framework capabilities to their fullest potential. This is not optional - it is the recommended best practice for framework effectiveness.