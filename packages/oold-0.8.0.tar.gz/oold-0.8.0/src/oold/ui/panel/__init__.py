from oold.ui.panel.anywidget_vite.jsoneditor import JsonEditor, OoldEditor  # noqa: F401
