class XML:
    def __init__(self):
        pass

    def to_string(self) -> str:
        pass
