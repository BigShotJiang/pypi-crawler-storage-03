# sage_setup: distribution = sagemath-schemes
from sage.schemes.cyclic_covers.constructor import CyclicCover
