"""MCP (Model Context Protocol) support for pydantic-rpc."""

from .exporter import MCPExporter

__all__ = ["MCPExporter"]
