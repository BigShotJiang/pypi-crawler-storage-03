# McSixRu

Библиотека для работы с AI через OpenRouter на русском языке.

## Установка

```bash
pip install McSixRu

