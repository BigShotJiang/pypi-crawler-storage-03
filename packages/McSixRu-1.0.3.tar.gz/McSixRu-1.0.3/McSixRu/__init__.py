from .core import a

__version__ = "1.0.3"
__author__ = "McSixRu"