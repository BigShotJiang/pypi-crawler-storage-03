# Expose the simple example for quick access
from .simple_model import make_model, SCHEMA, objective  # noqa: F401