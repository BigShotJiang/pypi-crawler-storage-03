#!/usr/bin/env python3


class Settings(object):

    def __init__(self):

        self.hub_dir = None
        self.valid_files = False
    
    def export_settings(self):

        pass

