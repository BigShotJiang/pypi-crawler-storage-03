Scaffold Finder
===============
.. automodule:: useful_rdkit_utils.scaffold_finder
    :members:
