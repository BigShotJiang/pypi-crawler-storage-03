REOS
====
.. automodule:: useful_rdkit_utils.reos
    :members:
