Miscellaneous Utilities
=======================
.. automodule:: useful_rdkit_utils.misc_utils
    :members:
