Jupyter
=======
.. automodule:: useful_rdkit_utils.jupyter_utils
    :members:
