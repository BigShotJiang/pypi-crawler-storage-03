Molecular Geometry
==================
.. automodule:: useful_rdkit_utils.geometry
    :members:
