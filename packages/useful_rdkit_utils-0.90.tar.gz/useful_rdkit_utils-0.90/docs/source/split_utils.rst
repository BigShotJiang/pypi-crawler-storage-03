Cross-validation and data splitting
===================================
.. automodule:: useful_rdkit_utils.split_utils
    :members:
