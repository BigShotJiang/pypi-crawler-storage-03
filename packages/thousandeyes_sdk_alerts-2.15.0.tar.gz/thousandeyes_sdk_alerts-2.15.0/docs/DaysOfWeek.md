# DaysOfWeek

Specifies the day to activate the alert suppression window. Applicable only when `intervalType` is set to `week`.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


