from atproto_core.exceptions import AtProtocolError


class LexiconParsingError(AtProtocolError): ...
