##################################################################
# THIS IS THE AUTO-GENERATED CODE. DON'T EDIT IT BY HANDS!
# Copyright (C) 2024 Ilya (Marshal) <https://github.com/MarshalX>.
# This file is part of Python atproto SDK. Licenced under MIT.
##################################################################


import typing as t

HostStatus = t.Union[
    t.Literal['active'], t.Literal['idle'], t.Literal['offline'], t.Literal['throttled'], t.Literal['banned'], str
]  #: Host status
