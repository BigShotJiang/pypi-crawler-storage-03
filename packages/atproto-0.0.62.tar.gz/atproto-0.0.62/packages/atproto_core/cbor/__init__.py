from .cbor import decode_dag, decode_dag_multi

__all__ = ['decode_dag', 'decode_dag_multi']
