"""SCIP indexing strategies."""

from .base_strategy import SCIPIndexerStrategy

__all__ = ['SCIPIndexerStrategy']