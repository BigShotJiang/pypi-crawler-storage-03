from .main import hello, is_potential_hash
