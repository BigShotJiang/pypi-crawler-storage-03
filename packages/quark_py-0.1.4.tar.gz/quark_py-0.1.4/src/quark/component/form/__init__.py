from .form import Component as Form
from .rule import Rule