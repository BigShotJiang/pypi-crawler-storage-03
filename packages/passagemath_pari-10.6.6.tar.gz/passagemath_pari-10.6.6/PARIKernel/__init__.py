# sage_setup: distribution = sagemath-pari
__version__ = "1.4.3"
