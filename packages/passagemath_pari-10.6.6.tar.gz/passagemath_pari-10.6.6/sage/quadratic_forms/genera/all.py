# sage_setup: distribution = sagemath-pari
# ****************************************************************************
#       Copyright (C) 2007 David Kohel <kohel@maths.usyd.edu.au>
#
#  Distributed under the terms of the GNU General Public License (GPL)
#
#                  https://www.gnu.org/licenses/
# ****************************************************************************
from sage.quadratic_forms.genera.genus import Genus, LocalGenusSymbol, is_GlobalGenus
