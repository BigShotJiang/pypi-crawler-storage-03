from enum import Enum


class PostActionEnum(Enum):
    YUN_DUN_CHECK = 1
    DEDUPLICATE = 2
    CHINESE_DETECT = 3
