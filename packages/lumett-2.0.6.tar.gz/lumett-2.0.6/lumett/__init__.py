"""
LumeTT - Multi-platform TinTin++ MUD client with scalable GUI

A wrapper around TinTin++ that provides enhanced MUD gaming experience.
"""

__version__ = "2.0.5"
__author__ = "Federico"
__description__ = "Multi-platform TinTin++ MUD client with scalable GUI"
