# NOTE: this file exists as a backwards compatible alias. please directly
# use `casbin.persist.update_adapter` instead.

from ..update_adapter import UpdateAdapter

__all__ = ["UpdateAdapter"]
