<div align="center">

# A simple collection of tools by tianxiu2b2t

![GitHub Issues or Pull Requests](https://img.shields.io/github/issues-pr/tianxiu2b2t/py-tianxiu2b2t)
![GitHub Issues or Pull Requests](https://img.shields.io/github/issues/tianxiu2b2t/py-tianxiu2b2t)
![GitHub License](https://img.shields.io/github/license/tianxiu2b2t/py-tianxiu2b2t)
![GitHub Release](https://img.shields.io/github/v/release/tianxiu2b2t/py-tianxiu2b2t)
![GitHub Tag](https://img.shields.io/github/v/tag/tianxiu2b2t/py-tianxiu2b2t)
![GitHub Repo stars](https://img.shields.io/github/stars/tianxiu2b2t/py-tianxiu2b2t)
[![Create tagged release](https://github.com/tianxiu2b2t/py-tianxiu2b2t/actions/workflows/pipy.yaml/badge.svg)](https://github.com/tianxiu2b2t/py-tianxiu2b2t/actions/workflows/pipy.yaml)

[赞助](https://afdian.net/a/atianxiua)
