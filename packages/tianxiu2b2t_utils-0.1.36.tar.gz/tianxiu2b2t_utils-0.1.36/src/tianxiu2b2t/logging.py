import logging as log

logging = log.getLogger("tianxiu2b2t")
logging.setLevel(log.INFO)
logging.addHandler(log.StreamHandler())
logging.propagate = False

