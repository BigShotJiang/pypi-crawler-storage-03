Matthew Martin
ChatGPT (4o models, mostly)
Gemini (2.5 Flash and 2.5 Pro)
Kimi (K2)