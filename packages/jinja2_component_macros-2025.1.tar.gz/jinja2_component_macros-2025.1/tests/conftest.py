pytest_plugins = [
    "_fixtures",
]
