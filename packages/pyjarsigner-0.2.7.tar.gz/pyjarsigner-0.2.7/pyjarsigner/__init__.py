# flake8: noqa

from pyjarsigner.jarutil import sign
