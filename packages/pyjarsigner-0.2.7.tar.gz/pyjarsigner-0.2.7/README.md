# pyjarsigner

Pure Python3 implementation to sign JAR and APK files which was inspired and borrowed from python-javatools.
