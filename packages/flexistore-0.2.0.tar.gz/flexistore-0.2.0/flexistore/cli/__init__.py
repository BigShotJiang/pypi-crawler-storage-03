"""Command-line interface for FlexiStore."""

from .main import main

__all__ = ["main"]
