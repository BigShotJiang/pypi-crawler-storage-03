# nano-roman
[![PyPI](https://img.shields.io/pypi/v/nano-roman.svg?color=blue)](https://pypi.org/project/nano-roman/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
![Size](https://img.shields.io/badge/size-~1KB-lightgrey.svg)
[![CI](https://github.com/ozgunlu/nano-roman/actions/workflows/ci.yml/badge.svg)](https://github.com/ozgunlu/nano-roman/actions)

World’s *tiniest* **Roman ↔ Decimal** number converter — ~1 KB, zero deps.
Single-file, CLI included. Perfect for code-golf, minimal containers, or just for fun.

---

## ✨ Features
- ✅ `int → ROMAN` and `ROMAN → int` (case-insensitive)
- ✅ Standard subtractive forms: `IV, IX, XL, XC, CD, CM`
- ✅ Classic 1–3999 supported; >3999 continues with repeated `M`
- ✅ Zero dependencies, single tiny file
- ✅ CLI: `nano-roman`

---

## 🚀 Usage
```bash
# Local (from repo)
python app_min.py 3999   # MMMCMXCIX
python app_min.py XL     # 40
```

After installing:

```bash
# CLI
pip install nano-roman
nano-roman 1984   # -> MCMLXXXIV
nano-roman XLII   # -> 42
nano-roman mmxxv  # -> 2025
```

---

## 🤓 Why so small?

- Minimal token table (S and V) + greedy subtractive matching
- No heavy parsing/regex trees, no dependencies
- Single module + tiny CLI wrapper

---

## 🎉 Fun Ideas

- **Convert the current year**
```powershell
(Get-Date -Format yyyy) | % { nano-roman $_ }   # 2025 -> MMXXV
```
```bash
date +%Y | xargs nano-roman                     # 2025 -> MMXXV
```
- **“Roman clock” (hour only)**
```powershell
  (Get-Date -Format HH) | % { nano-roman $_ }     # 14 -> XIV
```
```bash
date +%I | xargs nano-roman                     # 07 -> VII
```
- **Git tag in Roman**
```bash
git tag "v$(nano-roman 2025)" && git push origin "v$(nano-roman 2025)"
```
- **Batch convert a list**
```bash
printf "4\n9\n42\n1999\n" | while read n; do nano-roman "$n"; done
# IV, IX, XLII, MCMXCIX
```
- **Quick Windows alias**
```powershell
Set-Alias r nano-roman
r 3999   # -> MMMCMXCIX
```

Note: Classical Roman numerals have no zero and no negative values.

---

## 📜 License

MIT © 2025

