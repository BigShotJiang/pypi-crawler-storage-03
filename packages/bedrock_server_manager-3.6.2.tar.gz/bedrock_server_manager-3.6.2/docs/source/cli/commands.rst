.. click:: _click_helper:cli
   :prog: bedrock-server-manager
   :nested: full