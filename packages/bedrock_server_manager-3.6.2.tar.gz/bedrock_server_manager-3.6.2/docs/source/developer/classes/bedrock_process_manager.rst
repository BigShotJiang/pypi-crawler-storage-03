.. Bedrock Server Manager Bedrock Process Manager Core documentation file

Bedrock Process Manager Core Documentation
==========================================

.. autoclass:: bedrock_server_manager.BedrockProcessManager
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   .. automethod:: __init__