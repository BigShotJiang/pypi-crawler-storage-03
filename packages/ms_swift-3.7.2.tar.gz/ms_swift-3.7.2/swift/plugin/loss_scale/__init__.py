from .loss_scale import loss_scale_map
