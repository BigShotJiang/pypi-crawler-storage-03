# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm import eval_main

if __name__ == '__main__':
    eval_main()
