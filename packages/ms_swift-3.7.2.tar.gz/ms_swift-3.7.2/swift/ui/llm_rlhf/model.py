# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.llm_train import Model


class RLHFModel(Model):

    group = 'llm_rlhf'
