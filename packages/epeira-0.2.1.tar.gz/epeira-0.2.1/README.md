# epeira
Convenience model tooling for [Io Kleiser Consulting](https://www.iokleiser.com/).

In general, these tools are created for use in multiple siloed private repos,
so not all of them will have full demonstrations in this package or repo.

## Revision history

### 0.2.1
- Added get_variant_catalog_suffix function to parsing

### 0.2.0
- Added ability to create or add to input csv files any new models or parameters from catalogs

### 0.1.1
- Downgraded required version of Python to >= 3.11 for compatibility with other tooling

### 0.1.0
- Initial set of functions, primarily for marking classes and fields
- String parsing tools for convenience
