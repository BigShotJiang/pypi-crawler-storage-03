"""Agent implementations for FastAPI AgentRouter."""
