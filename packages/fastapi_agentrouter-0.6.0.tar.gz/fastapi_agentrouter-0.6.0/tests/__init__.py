"""Tests for FastAPI AgentRouter."""
