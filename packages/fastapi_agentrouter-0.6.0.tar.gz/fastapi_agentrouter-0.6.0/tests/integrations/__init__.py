"""Tests for integration modules."""
