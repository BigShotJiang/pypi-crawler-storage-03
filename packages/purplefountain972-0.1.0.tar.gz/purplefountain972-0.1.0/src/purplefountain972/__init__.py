from purplefountain972._core import hello_from_bin


def hello() -> str:
    return hello_from_bin()
