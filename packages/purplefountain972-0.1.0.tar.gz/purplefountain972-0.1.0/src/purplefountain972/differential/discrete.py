# Author metadata:
# Name: Syed Raza
# email: sar0033@uah.edu

# Python code to calculate some discrete derivatives

def diff (x, t):
    """
    Params: The distance and tiome arrays (x and t) of the same length
    Returns: The velocity array calculated from the backward difference method
    """
    # Initializing the velociy array:
    v = [] 
    if len(x) == len(t):
       s = len(x)
       for i in range(1, s):    # backward difference cannot start at index 0
           bd = (x[i] - x[i - 1]) / (t[i] - t[i-1])
           v.append(bd)

    else:
        print("Well the two arrays are not equal. Why would you go ahead and do that :(")
    
    return v