Unit tests can be run by, for example:

 python -m unittest test_dynamixel_XL430

