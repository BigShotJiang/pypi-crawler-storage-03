"""systemd_watchdog."""

from .systemd_watchdog import WatchDog
