from .diagnostic_all import allDiagnostics
from .diagnostic_8gig import diagnostic8Gig
from .diagnostic_20gig import diagnostic20Gig
from .diagnostic_ipv6 import diagnosticIPv6
from .diagnostic_network import diagnosticNetwork
