[2025/08/17]

- New tool `PasteToClipboard` for chatbot
- OpenAI API configurable via env vars
- Azure OpenAI API configuration option added
- Upgrade to LLMBrix 0.1.3
- Pre-commit config improvements

[2025/07/27]

- Light mode fixed for mac terminal
- `aaa` mode added for chat with clipboard copied context

[2025/07/26]

- Initial implementation
- Terminal with special commands
- Rich formatting and console printing
- Code generation
- Chat
- Smart error fixing terminal
- Configuration
- Arize integration
- Optimization for light color mode
