"""Tests for the spatial polygon generation module."""
