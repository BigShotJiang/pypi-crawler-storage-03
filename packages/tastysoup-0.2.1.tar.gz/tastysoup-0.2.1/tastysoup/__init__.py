from .core import TastySoup

__version__ = "0.2.0"
__all__ = ["TastySoup"]
