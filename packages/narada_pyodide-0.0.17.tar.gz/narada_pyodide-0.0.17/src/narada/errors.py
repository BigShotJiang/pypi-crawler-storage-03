class NaradaError(Exception):
    pass


class NaradaTimeoutError(NaradaError):
    pass
