# NequIP Developers

Present and past contributors include, in alphabetical order by last name:

 - [Simon Batzner](https://simonbatzner.github.io/)
 - [Vivek Bharadwaj](https://vivek-bharadwaj.com)
 - [Marc Descoteaux](https://www.marcdescoteaux.com/)
 - Olav Førland
 - [Mario Geiger](https://mariogeiger.ch/)
 - Austin Glover
 - Y. Richard Hu
 - Anders Johansson
 - [Seán Kavanagh](https://seankavanagh.com/)
 - [Mit Kotak](https://mitkotak.github.io/)
 - [Prof. Boris Kozinsky](https://mir.g.harvard.edu/)
 - Albert Musaelian
 - Gabriel de Miranda Nascimento
 - Aadit Saluja
 - Viraj Uday Singh
 - [Prof. Tess Smidt](https://blondegeek.github.io/)
 - Lixin Sun
 - [Myles Stapelberg](https://github.com/mstapelberg)
 - [Chuin Wei Tan](https://cw-tan.github.io/)
 - Ulrik Unneberg
 - Menghang (David) Wang
 - William C. Witt
 - Albert Zhu
 - Laura Zichi