from .script_tcp_client import myHawkGUI_PLC_API

__version__ = "0.1.0"
__all__ = ['myHawkGUI_PLC_API']