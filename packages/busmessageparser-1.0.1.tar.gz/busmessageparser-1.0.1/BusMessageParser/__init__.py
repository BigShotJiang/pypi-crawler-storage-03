#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import sys
r=os.path.abspath(os.path.dirname(__file__))
rootpath=os.path.split(r)[0]
sys.path.append(os.path.split(r)[0])