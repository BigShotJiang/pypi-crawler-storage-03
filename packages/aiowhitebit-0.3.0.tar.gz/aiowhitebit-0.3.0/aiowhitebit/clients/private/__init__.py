"""Private API clients."""

from aiowhitebit.clients.private.v4 import PrivateV4Client

__all__ = [
    "PrivateV4Client",
]
