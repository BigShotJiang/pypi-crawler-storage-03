"""Tests for aiowhitebit."""
