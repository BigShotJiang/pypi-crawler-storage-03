"""Setup script for aiowhitebit."""

from setuptools import setup

setup(
    name="aiowhitebit",
    packages=["aiowhitebit"],
    package_dir={"": "."},
)
