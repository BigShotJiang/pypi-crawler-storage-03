__version__ = (7, 0, 66)

def version():
    return '%s.%s.%s' % __version__

