-- init.sql
CREATE TABLE users (id INT, name TEXT);