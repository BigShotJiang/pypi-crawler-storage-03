## Registry

Manage multiple configuration instances with `YRegistry`.

### Multiple instances

```python
--8<-- "examples/registry/40_registry_get_set_multiple.py"
```


