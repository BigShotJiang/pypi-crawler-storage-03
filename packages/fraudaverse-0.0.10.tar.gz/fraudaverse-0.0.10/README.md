# Python Library for FraudAverse AI/ML

This library is work in progress.

It can be used to connect python with fraudaverse, mostly to upload a scoring model that was generated
with xgboost.
