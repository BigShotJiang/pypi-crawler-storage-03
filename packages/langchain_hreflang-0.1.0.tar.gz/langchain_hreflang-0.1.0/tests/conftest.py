"""Test configuration for langchain-hreflang."""
import pytest

@pytest.fixture
def sample_api_key():
    return "test_api_key_123"
