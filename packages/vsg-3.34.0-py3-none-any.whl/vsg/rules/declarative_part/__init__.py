# -*- coding: utf-8 -*-

from .rule_400 import rule_400
