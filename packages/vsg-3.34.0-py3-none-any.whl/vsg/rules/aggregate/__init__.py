# -*- coding: utf-8 -*-

from .rule_500 import rule_500
