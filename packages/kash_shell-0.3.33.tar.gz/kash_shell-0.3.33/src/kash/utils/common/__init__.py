"""
A few generally useful utilities that should have very few or no dependencies
elsewhere in this codebase (except in a few cases for our custom logging).
"""
