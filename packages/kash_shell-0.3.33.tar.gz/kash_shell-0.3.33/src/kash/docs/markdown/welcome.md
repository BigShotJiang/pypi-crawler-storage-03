**Welcome to Kash!**

Use `help` for the manual and full list of available commands.
Press **tab** for contextual autocomplete of commands, questions, actions, and files.
You may simply ask a question and the kash assistant will help you.
Press **space** (or type **?**), then write your question or request.
Use `logs` for detailed logs.

*I’d love to hear from you with issues, bugs, and ideas.
Discuss at github.com/jlevy/kash or contact me github.com/jlevy or x.com/ojoshe (DMs
open).*

Try: `What is kash?`, `How can I transcribe a YouTube video?`, `getting_started`, `faq`,
`self_check`, `self_configure`
