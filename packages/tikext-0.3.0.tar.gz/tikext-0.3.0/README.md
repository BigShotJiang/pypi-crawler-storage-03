# TikExt

A simple Python library to extract username from email.

## Installation

```bash
pip install TikExt
```

## Usage

```python
import TikExt

t = TikExt.GetUser("example@example.com")
print(t)  # Output: example
```

## Author

@D_B_HH @PPH9P


