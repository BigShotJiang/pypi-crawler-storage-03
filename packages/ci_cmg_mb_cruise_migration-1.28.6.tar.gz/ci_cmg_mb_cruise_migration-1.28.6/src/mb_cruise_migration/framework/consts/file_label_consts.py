class FileLabels(object):
    SURVEY_METADATA = "survey_metadata"
    EXTRANEOUS = "has_extraneous"
    LEG = "has_leg"
    REGION = "has_region"
    ZONE = "has_zone"
    STANDARD = "standard"
