class LogLevels(object):
    INFO = 'info'
    WARNING = 'warning'
    CRITICAL = 'critical'
    DEBUG = 'debug'
