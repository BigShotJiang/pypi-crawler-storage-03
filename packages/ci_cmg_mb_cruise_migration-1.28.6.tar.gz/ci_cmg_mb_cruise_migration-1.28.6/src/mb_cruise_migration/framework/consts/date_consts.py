TRUNC_DATE_FORMAT = "%d-%b-%y"
TRUNC_DATE_FORMAT_CAP = "%d-%^b-%y"
SHORT_DATE_FORMAT = "%d-%b-%Y"
ORM_ISO_DATE_FORMAT = "%Y-%m-%dT%H:%M:%S"
