"""Run the main entry point."""

from .pylendar import main

__all__ = ["main"]
