# pylendar

Python port of the "calendar" reminder utility
commonly found on BSD-style systems,
which displays upcoming relevant dates.

* [FreeBSD calendar(1) man page](https://man.freebsd.org/cgi/man.cgi?calendar)

This utility has also been ported to Debian GNU/Linux,
so please see
[the Debian package](https://packages.debian.org/source/bookworm/bsdmainutils)
for more information.
