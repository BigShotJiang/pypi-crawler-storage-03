See [Docs](https://paddlepaddle.github.io/PaddleOCR/latest/en/ppstructure/overview.html) for details.

请移步[Docs](https://paddlepaddle.github.io/PaddleOCR/latest/ppstructure/overview.html)查看。
