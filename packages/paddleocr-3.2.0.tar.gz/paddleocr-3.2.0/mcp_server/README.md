# PaddleOCR MCP 服务器

中文 | [English](./README_en.md)

请查看 [文档](../docs/version3.x/deployment/mcp_server.md)。
