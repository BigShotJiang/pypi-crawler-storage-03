import basic_model_operations


basic_model_operations.main()
