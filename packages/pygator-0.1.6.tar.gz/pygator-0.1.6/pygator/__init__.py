# my_package/__init__.py
from pygator.module.module import *
from ._version import __version__