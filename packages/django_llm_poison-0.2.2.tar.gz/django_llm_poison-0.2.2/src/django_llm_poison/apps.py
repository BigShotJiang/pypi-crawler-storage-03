from django.apps import AppConfig


class DjangoLlmPoisonConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_llm_poison"
