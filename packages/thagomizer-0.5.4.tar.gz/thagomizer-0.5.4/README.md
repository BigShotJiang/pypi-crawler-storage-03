# thagomizer

General tools in python


## Installing for development

```bash
git clone https://github.com/sg-s/thagomizer.git
cd thagomizer
uv run ipython kernel install --user --name=thagomizer
uv sync
uv run --with jupyter jupyter lab
```