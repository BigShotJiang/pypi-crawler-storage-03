

::: thagomizer.video
    options:
      filters: 
        - "!^_"
      show_root_toc_entry: false
      show_root_heading: false
      show_category_heading: false
      show_object_full_path: false


