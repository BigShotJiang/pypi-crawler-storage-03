# def test_import_and_ping():
#     from devnotify import DevNotify
#     client = DevNotify(api_key="test")
#     client.
