## Exercutar testes

```sh
uv run -m pytest --cov=duden_webscraper --cov-report=term-missing
```