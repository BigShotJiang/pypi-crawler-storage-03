class WordNotFoundError(Exception):
    pass
