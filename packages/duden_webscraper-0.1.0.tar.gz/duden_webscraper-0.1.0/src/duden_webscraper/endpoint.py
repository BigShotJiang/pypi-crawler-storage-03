
class Endpoint:
    BASE = "https://www.duden.de"
    DICTIONARY_SEARCH = "/search_api_autocomplete/dictionary_search"
    ORTHOGRAPHY = "/rechtschreibung"
