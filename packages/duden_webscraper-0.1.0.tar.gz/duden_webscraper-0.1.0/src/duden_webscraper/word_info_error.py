class WordInfoError(Exception):
    pass
