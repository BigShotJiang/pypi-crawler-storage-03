# Release 2.0.0

Initial public release.

## Major Features and Improvements

*   Tutorial code and dataset released

## Breaking Changes

*   SCAAML full rearchitecting around Tensorflow 2.2+
*   Models reworked
*   Attack code refactored
*   Visualization redone
*   SCAAML tutorial available

## Thanks to our Contributors

This release contains contributions from many people at Google, as well as our
our research collaborators.
