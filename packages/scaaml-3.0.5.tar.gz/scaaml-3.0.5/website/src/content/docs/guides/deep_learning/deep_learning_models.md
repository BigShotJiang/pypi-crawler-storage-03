---
title: Deep Learning Models
description: Deep Learning Models
---

Import GPAM model:

```python
from scaaml.models import get_gpam_model
```

A tutorial on its use: TODO
