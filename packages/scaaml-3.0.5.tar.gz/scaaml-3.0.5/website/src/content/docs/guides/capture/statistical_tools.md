---
title: Statistical Tools
description: Statistical Tools
---

A support for computing basic statistics of traces (mean, variance) as well as
statistics about inputs / attack points is present.

## Code Examples

```python
# TODO
```
