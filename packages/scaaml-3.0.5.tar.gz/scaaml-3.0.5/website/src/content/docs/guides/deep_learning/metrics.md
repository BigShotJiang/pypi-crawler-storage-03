---
title: Metrics
description: Metrics
---

We provide the following metrics:

-   MeanRank
-   MaxRank
-   Confidence (the version of difference between the maximum and second
    largest value in predictions)
