---
title: SCAAML Intro
description: SCAAML Side Channel Attacks Assisted with Machine Learning
---

![SCAAML banner](https://storage.googleapis.com/scaaml-public/visuals/scaaml-banner.png)

SCAAML (Side Channel Attacks Assisted with Machine Learning) is a deep learning
framework dedicated to side-channel attacks.
