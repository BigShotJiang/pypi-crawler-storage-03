# SCAAML documentation

Website available at [google.github.io/scaaml](https://google.github.io/scaaml)

## Adding more documentation

Local development preparation:

-   Install requirements: `sudo apt-get install nodejs npm`
-   Install project: `cd website/ ; npm install`

Run local server: `npm run dev`

## Deploy to github pages

Manually run the "Deploy to GitHub Pages" workflow (needs maintainer
permission).
