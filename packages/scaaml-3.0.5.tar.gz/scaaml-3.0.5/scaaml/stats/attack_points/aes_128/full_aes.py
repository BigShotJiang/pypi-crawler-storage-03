# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Full AES128 implementation.
"""

from typing_extensions import TypeAlias  # from typing since 3.10

import numpy as np
import numpy.typing as npt

# AES operates on a 4 × 4 column-major order array of 16 bytes b0, b1, ..., b15:
# [b0  b4  b8  b12]
# [b1  b5  b9  b13]
# [b2  b6  b10 b14]
# [b3  b7  b11 b15]
# For NumPy that is order="F" (indexing state[row][column]).

AesStateType: TypeAlias = npt.NDArray[np.uint8]


def mul(a: int, b: int) -> int:
    """AES finite field multiplication. This could also be a lookup table.
    """
    a = int(a)
    b = int(b)

    assert 0 <= a < 256
    assert 0 <= b < 256

    p: int = 0

    for _ in range(8):
        if b % 2:
            p = p ^ a

        high_bit_set = bool(a & 0x80)
        a <<= 1
        if high_bit_set:
            a = a ^ 0x1B  # x^8 + x^4 + x^3 + x + 1
        b >>= 1

    return p % 256


# yapf: disable
SBOX = np.array(
    [
        # pylint: disable=C0301
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
    ],
    dtype=np.uint8,
)

SBOX_INV = np.array(
    [
        # pylint: disable=C0301
        0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
        0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
        0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
        0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
        0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
        0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
        0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
        0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
        0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
        0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
        0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
        0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
        0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
        0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
        0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
        0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d,
    ],
    dtype=np.uint8,
)
# yapf: enable


def rot_word(w: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Rotate a single word (row).
    """
    assert w.dtype == np.uint8
    assert w.shape == (4,)
    return np.roll(w.copy(), -1)


def sub_word(w: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Run S-BOX on each input of a word.
    """
    assert w.dtype == np.uint8
    assert w.shape == (4,)
    return np.array([SBOX[x] for x in w], dtype=np.uint8)


def sub_word_inv(w: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Run inverse S-BOX on each input of a word.
    """
    assert w.dtype == np.uint8
    assert w.shape == (4,)
    return np.array([SBOX_INV[x] for x in w], dtype=np.uint8)


def get_words(key: npt.NDArray[np.uint8]) -> AesStateType:
    """Turn 16 bytes into a state (reshape in the correct way from an array
    of shape (16,) to state (4, 4)).
    """
    assert key.dtype == np.uint8
    assert key.shape == (16,), f"Wrong shape expected (16,) got {key.shape}"
    return key.copy().reshape((4, 4), order="C")


def key_schedule(key: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Return the columns of key schedule.
    """
    n = 4
    r = 11
    rcon_0 = np.array([
        [0x01, 0, 0, 0],
        [0x02, 0, 0, 0],
        [0x04, 0, 0, 0],
        [0x08, 0, 0, 0],
        [0x10, 0, 0, 0],
        [0x20, 0, 0, 0],
        [0x40, 0, 0, 0],
        [0x80, 0, 0, 0],
        [0x1B, 0, 0, 0],
        [0x36, 0, 0, 0],
    ],
                      dtype=np.uint8)
    key_words = get_words(key)
    w = np.zeros((44, 4), dtype=np.uint8)

    for i in range(4 * r):
        if i < n:
            w[i] = key_words[i]
        elif i % n == 0:
            w[i] = w[i - n] ^ sub_word(rot_word(
                w[i - 1])) ^ rcon_0[(i // n) - 1]
        else:
            w[i] = w[i - n] ^ w[i - 1]

    return w


def key_schedule_inv(last_key: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Return the columns of key schedule given the last round key.
    """
    n = 4
    r = 11
    rcon_0 = np.array([
        [0x01, 0, 0, 0],
        [0x02, 0, 0, 0],
        [0x04, 0, 0, 0],
        [0x08, 0, 0, 0],
        [0x10, 0, 0, 0],
        [0x20, 0, 0, 0],
        [0x40, 0, 0, 0],
        [0x80, 0, 0, 0],
        [0x1B, 0, 0, 0],
        [0x36, 0, 0, 0],
    ],
                      dtype=np.uint8)
    key_words = get_words(last_key)
    w = np.zeros((44, 4), dtype=np.uint8)
    w[-4:] = key_words

    for i in reversed(range(4 * r - n)):
        if i % n == 0:
            w[i] = w[i + n] ^ sub_word(rot_word(w[i + n - 1])) ^ rcon_0[i // n]
        else:
            w[i] = w[i + n] ^ w[i + n - 1]

    return w


def add_round_key(state: AesStateType, scheduled: AesStateType) -> AesStateType:
    """Round keys are columns which need to be transposed.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    assert scheduled.shape == (4, 4)
    assert scheduled.dtype == np.uint8

    return state ^ scheduled.transpose()


def sub_bytes(state: AesStateType) -> AesStateType:
    """Apply S-BOX to the whole state.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    return np.array([sub_word(w) for w in state], dtype=np.uint8)


def sub_bytes_inv(state: AesStateType) -> AesStateType:
    """Apply inverse S-BOX to the whole state.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    return np.array([sub_word_inv(w) for w in state], dtype=np.uint8)


def shift_rows(state: AesStateType) -> AesStateType:
    """Shift rows in the state.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    for shift_by in range(1, 4):
        state[shift_by] = np.roll(state[shift_by].copy(), -shift_by)
    return state


def shift_rows_inv(state: AesStateType) -> AesStateType:
    """Unshift rows in the state.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    for shift_by in range(1, 4):
        state[shift_by] = np.roll(state[shift_by].copy(), shift_by)
    return state


def mix_columns(state: AesStateType) -> AesStateType:
    """Mix columns of the state.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    return np.array([mix_single_column(state[:, i]) for i in range(4)],
                    dtype=np.uint8).transpose()


def mix_columns_inverse(state: AesStateType) -> AesStateType:
    """Unmix columns of the state.
    """
    assert state.shape == (4, 4)
    assert state.dtype == np.uint8
    return np.array([mix_single_column_inverse(state[:, i]) for i in range(4)],
                    dtype=np.uint8).transpose()


def matmul(matrix: npt.NDArray[np.uint8],
           column: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Matrix multiplication used for mix columns and inversion.
    """
    assert column.shape == (4,)
    assert column.dtype == np.uint8
    assert matrix.shape == (4, 4)
    assert matrix.dtype == np.uint8

    result = np.zeros(4, dtype=np.uint8)

    for row_i in range(4):
        for col_i in range(4):
            result[row_i] ^= mul(matrix[row_i][col_i], column[col_i])

    return result


def mix_single_column(column: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Mix single column.
    """
    matrix = np.array(
        [
            [2, 3, 1, 1],
            [1, 2, 3, 1],
            [1, 1, 2, 3],
            [3, 1, 1, 2],
        ],
        dtype=np.uint8,
    )

    return matmul(matrix=matrix, column=column)


def mix_single_column_inverse(
        column: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Unmix single column.
    """
    matrix = np.array(
        [
            [14, 11, 13, 9],
            [9, 14, 11, 13],
            [13, 9, 14, 11],
            [11, 13, 9, 14],
        ],
        dtype=np.uint8,
    )

    return matmul(matrix=matrix, column=column)


def encrypt(key: npt.NDArray[np.uint8],
            plaintext: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Run AES128 on 16 byte plaintext.
    """
    round_keys = key_schedule(key)
    assert round_keys.dtype == np.uint8
    assert round_keys.shape == (44, 4)
    state = np.array(plaintext.copy().reshape((4, 4), order="F"))

    state = add_round_key(state, round_keys[:4])

    for i in range(1, 10):
        state = sub_bytes(state)
        state = shift_rows(state)
        state = mix_columns(state)
        state = add_round_key(
            state=state,
            scheduled=round_keys[4 * i:4 * (i + 1)],
        )

    state = sub_bytes(state)
    state = shift_rows(state)
    state = add_round_key(state=state, scheduled=round_keys[-4:])

    return state.reshape(16, order="F")


def _my_flatten(state: npt.NDArray[np.uint8]) -> list[int]:
    """Reimplement flatten to ensure mypy is not confused.
    """
    return [int(s) for s in state.reshape(16, order="F")]


def encrypt_with_states(
        key: npt.NDArray[np.uint8],
        plaintext: npt.NDArray[np.uint8]) -> dict[str, npt.NDArray[np.uint8]]:
    """Run AES128 on 16 byte plaintext and return all intermediate states.
    """
    intermediates: dict[str, list[int]] = {
        "state": [],
        "key_schedule": [],
        # Be explicit since mypy is confused by tolist which can return a
        # scalar.
        "key": [int(k) for k in key],
        "plaintext": [int(p) for p in plaintext],
    }

    round_keys = key_schedule(key)
    assert round_keys.dtype == np.uint8
    assert round_keys.shape == (44, 4)

    for r in round_keys:
        intermediates["key_schedule"].extend(r.tolist())

    state = np.array(plaintext.copy().reshape((4, 4), order="F"))
    intermediates["state"].extend(_my_flatten(state))  # 0

    state = add_round_key(state, round_keys[:4])
    intermediates["state"].extend(_my_flatten(state))  # 1

    for i in range(1, 10):
        state = sub_bytes(state)
        intermediates["state"].extend(
            _my_flatten(state))  # 2, 6, 10, 14, 18, 22, 26, 30, 34
        state = shift_rows(state)
        intermediates["state"].extend(
            _my_flatten(state))  # 3, 7, 11, 15, 19, 23, 27, 31, 35
        state = mix_columns(state)
        intermediates["state"].extend(
            _my_flatten(state))  # 4, 8, 12, 16, 20, 24, 28, 32, 36
        state = add_round_key(
            state=state,
            scheduled=round_keys[4 * i:4 * (i + 1)],
        )
        intermediates["state"].extend(
            _my_flatten(state))  # 5, 9, 13, 17, 21, 25, 29, 33, 37

    state = sub_bytes(state)
    intermediates["state"].extend(_my_flatten(state))  # 38
    state = shift_rows(state)
    intermediates["state"].extend(_my_flatten(state))  # 39
    state = add_round_key(state=state, scheduled=round_keys[-4:])
    intermediates["state"].extend(_my_flatten(state))  # 40

    ciphertext = state.reshape(16, order="F")
    intermediates["ciphertext"] = ciphertext.tolist()

    return {k: np.array(v, dtype=np.uint8) for k, v in intermediates.items()}


def decrypt(key: npt.NDArray[np.uint8],
            ciphertext: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """Decrypt AES128 on 16 byte plaintext.
    """
    round_keys = key_schedule(key)
    assert round_keys.dtype == np.uint8
    assert round_keys.shape == (44, 4)
    state = np.array(ciphertext.copy().reshape((4, 4), order="F"))

    state = add_round_key(state=state, scheduled=round_keys[-4:])
    state = shift_rows_inv(state)
    state = sub_bytes_inv(state)

    for i in range(9, 0, -1):
        state = add_round_key(
            state=state,
            scheduled=round_keys[4 * i:4 * (i + 1)],
        )
        state = mix_columns_inverse(state)
        state = shift_rows_inv(state)
        state = sub_bytes_inv(state)

    state = add_round_key(state, round_keys[:4])

    return state.reshape(16, order="F")
