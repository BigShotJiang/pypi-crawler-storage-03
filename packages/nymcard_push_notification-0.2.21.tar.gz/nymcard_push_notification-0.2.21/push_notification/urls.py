from django.urls import include, path

app_name = "push_notification"

urlpatterns = [
]
