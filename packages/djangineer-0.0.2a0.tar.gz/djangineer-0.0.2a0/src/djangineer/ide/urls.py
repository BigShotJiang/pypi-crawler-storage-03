
from django.urls import path
# from .views import open_project

urlpatterns = [
    # path('project/', open_project, name='project'),
]
