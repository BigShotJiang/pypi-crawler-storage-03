# Simple chatbot example
