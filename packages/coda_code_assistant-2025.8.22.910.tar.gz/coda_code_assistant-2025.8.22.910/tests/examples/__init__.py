# Example applications demonstrating Coda module usage
