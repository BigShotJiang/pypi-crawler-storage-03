"""Tests for vector storage backends."""
