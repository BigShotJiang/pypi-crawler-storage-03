"""Web UI testing framework."""
