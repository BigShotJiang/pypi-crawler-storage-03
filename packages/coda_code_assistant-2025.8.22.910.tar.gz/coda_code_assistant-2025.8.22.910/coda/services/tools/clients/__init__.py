"""MCP client implementations using Strategy pattern."""
