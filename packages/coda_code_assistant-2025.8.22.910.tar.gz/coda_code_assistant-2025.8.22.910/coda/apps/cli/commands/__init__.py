"""Modular CLI command definitions."""
