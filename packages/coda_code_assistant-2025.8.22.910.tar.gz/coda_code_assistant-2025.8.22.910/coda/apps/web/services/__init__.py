"""Web services for Coda application."""
