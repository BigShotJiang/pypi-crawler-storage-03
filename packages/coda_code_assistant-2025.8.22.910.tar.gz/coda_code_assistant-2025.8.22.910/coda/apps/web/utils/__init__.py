"""Web UI utility functions."""
