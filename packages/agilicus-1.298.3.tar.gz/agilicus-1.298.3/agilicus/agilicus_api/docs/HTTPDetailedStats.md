# HTTPDetailedStats

Detailed statistics for http requests made to a server. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requests_latency** | [**LatencyHistogram**](LatencyHistogram.md) |  | [optional] 
**requests_status_counters** | [**[HTTPResponseCodeCounter]**](HTTPResponseCodeCounter.md) | Counters for each specific request response code. Only includes codes which the server has replied with.  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


