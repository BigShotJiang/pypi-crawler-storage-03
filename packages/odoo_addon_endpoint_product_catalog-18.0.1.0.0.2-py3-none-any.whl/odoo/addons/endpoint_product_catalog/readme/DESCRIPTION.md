This addon allows configuring an endpoint for product catalogs.
