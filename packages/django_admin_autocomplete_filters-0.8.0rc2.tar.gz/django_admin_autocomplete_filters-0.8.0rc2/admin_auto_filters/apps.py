from django.apps import AppConfig


class AdminAutoFiltersConfig(AppConfig):
    name = 'admin_auto_filters'
