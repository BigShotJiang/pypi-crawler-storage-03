# tab

## Syntax:
`tab`

## Examples:
`print tab cat tab cat Value`

## Description:
Returns a tab character (`\t`).

Next: [tan](tan.md)  
Prev: [symbol](symbol.md)

[Back](../../README.md)
