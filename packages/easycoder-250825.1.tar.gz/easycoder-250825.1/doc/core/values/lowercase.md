# lowercase

## Syntax:
`lowercase {text}`

## Examples:
``print lowercase MixedCase` ``

## Description:
Converts all the characters in a string into lower case.

Next: [memory](memory.md)  
Prev: [length](length.md)

[Back](../../README.md)
