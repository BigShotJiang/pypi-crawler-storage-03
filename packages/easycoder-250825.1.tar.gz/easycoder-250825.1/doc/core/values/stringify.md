# stringify

## Syntax:
`stringify {value}`

## Examples:
`print stringify Data`

## Description:
Returns the supplied data item converted to a string. See also [json](json.md).

Next: [tab](tab.md)  
Prev: [sin](sin.md)

[Back](../../README.md)
