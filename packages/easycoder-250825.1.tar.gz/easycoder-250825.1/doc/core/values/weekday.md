# weekday

## Syntax:
`[the] weekday`

## Examples:
`print the weekday`

## Description:
Returns the number of the current day, where Monday is 0, Tuesday is 1, etc.

Next: [arg](arg.md)  
Prev: [value](value.md)

[Back](../../README.md)
