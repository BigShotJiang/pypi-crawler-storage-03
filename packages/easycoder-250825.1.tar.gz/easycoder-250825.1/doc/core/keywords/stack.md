# stack

## Syntax:
`stack {name}`

## Example:
`stack MyStack`

## Description:
Declares a stack variable, a special kind of array that permits elements to be [push](push.md)ed onto it and [pop](pop.md)ped off later.

Next: [stop](stop.md)  
Prev: [split](split.md)

[Back](../../README.md)
