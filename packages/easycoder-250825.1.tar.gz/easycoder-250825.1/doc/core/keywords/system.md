# system

## Syntax:
`system {command}`

## Example:
``system `ls >files` ``

## Description:
Issue a command to the operating system.

Next: [take](take.md)  
Prev: [stop](stop.md)

[Back](../../README.md)
