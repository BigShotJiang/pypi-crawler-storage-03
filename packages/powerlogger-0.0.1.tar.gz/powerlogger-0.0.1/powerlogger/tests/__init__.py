"""Test package for powerlogger"""
