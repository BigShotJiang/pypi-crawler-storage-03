# RAG MCP 服务器使用指南

## 什么是 RAG MCP 服务器？

这是一个基于 MCP (Model Context Protocol) 的 RAG (Retrieval-Augmented Generation) 服务器，它允许 AI 助手访问和管理知识库，进行智能问答和文档检索。

## 功能特性

- 📚 **文档管理**: 添加、删除、查询文档
- 🔍 **智能搜索**: 基于语义相似度的文档检索
- 💬 **问答系统**: 根据知识库内容回答问题
- 🏷️ **元数据支持**: 为文档添加分类、标签等元信息
- 📊 **统计分析**: 查看知识库状态和统计信息

## 快速开始

### 1. 启动服务器

```bash
# 在后台启动服务器
python rag_server.py

# 或者直接运行（会阻塞终端）
python rag_server.py
```

### 2. 配置 MCP 客户端

在支持 MCP 的 AI 客户端（如 Claude Desktop）中，添加以下配置：

```json
{
  "mcpServers": {
    "rag-server": {
      "command": "python",
      "args": ["/path/to/your/rag-mcp-server/rag_server.py"],
      "env": {
        "PYTHONPATH": "/path/to/your/rag-mcp-server"
      }
    }
  }
}
```

### 3. 使用示例

启动后，AI 助手就可以使用以下工具：

#### 添加文档
```
add_document("文档内容", {"category": "技术", "language": "中文"})
```

#### 搜索文档
```
search_documents("人工智能")
```

#### 获取文档
```
get_document("doc_0")
```

#### 列出所有文档
```
list_documents()
```

#### 删除文档
```
delete_document("doc_0")
```

#### 获取服务器信息
```
get_server_info()
```

## 配置选项

服务器支持以下配置：

- `max_results`: 最大搜索结果数量 (默认: 5)
- `similarity_threshold`: 相似度阈值 (默认: 0.7)
- `supported_formats`: 支持的文档格式
- `enable_logging`: 是否启用日志记录

## 支持的文档格式

- 纯文本
- Markdown
- 结构化数据 (JSON)

## 故障排除

### 常见问题

1. **服务器无法启动**
   - 检查 Python 环境
   - 确认依赖包已安装
   - 查看错误日志

2. **MCP 连接失败**
   - 确认服务器正在运行
   - 检查客户端配置路径
   - 验证 Python 路径设置

3. **文档添加失败**
   - 检查文档内容格式
   - 确认元数据格式正确
   - 查看服务器日志

### 日志查看

服务器运行时会输出详细日志，包括：
- 文档操作状态
- 搜索请求处理
- 错误和警告信息

## 开发说明

### 项目结构

```
rag-mcp-server/
├── rag_server.py          # 主服务器文件
├── rag_engine.py          # RAG 核心引擎
├── mcp_client_config.json # MCP 客户端配置示例
├── requirements.txt       # 依赖包列表
└── README.md             # 使用说明
```

### 扩展功能

你可以通过修改 `rag_engine.py` 来：
- 添加新的文档格式支持
- 自定义相似度算法
- 集成外部数据源
- 优化搜索性能

## 技术支持

如果遇到问题，请：
1. 查看服务器日志输出
2. 检查配置文件格式
3. 确认环境依赖
4. 参考错误信息进行排查

---

**注意**: 这是一个示例实现，生产环境使用前请进行充分测试和安全评估。
