git add .
git commit -m "add"
git push
