"""
desktop_access_mcp_server

A brief description of what this package does.
"""

__version__ = "0.1.1"
