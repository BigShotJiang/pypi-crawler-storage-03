from django.apps import AppConfig


class DauthzConfig(AppConfig):
    name = "dauthz"
