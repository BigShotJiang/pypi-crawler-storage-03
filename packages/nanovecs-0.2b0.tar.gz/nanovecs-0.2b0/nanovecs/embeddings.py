# nanovecs/nano4_embeddings.py
import numpy as np

class Embeddings:
    def __init__(self, vocab_size, dim=50):
        self.dim = dim
        self.vectors = np.random.uniform(-0.5, 0.5, (vocab_size, dim))

    def get(self, idx):
        return self.vectors[idx]

    def update(self, idx, grad, lr=0.01):
        self.vectors[idx] -= lr * grad

def cosine(v1, v2):
    return np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-9)
