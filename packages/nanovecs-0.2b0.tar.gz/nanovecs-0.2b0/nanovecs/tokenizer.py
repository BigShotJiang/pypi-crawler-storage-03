# nanovecs/nano1_tokenizer.py
import regex as re

class Tokenizer:
    def __init__(self, lower=True, keep_punct=False):
        self.lower = lower
        self.keep_punct = keep_punct

    def tokenize(self, text: str):
        if self.lower:
            text = text.lower()
        # \p{L}+ = secuencias de letras (soporta unicode)
        tokens = re.findall(r"\p{L}+", text)
        return tokens
