# nanovecs/nano2_corpus.py
import os

def load_corpus(path: str):
    texts = []
    for fname in os.listdir(path):
        if fname.endswith(".txt"):
            with open(os.path.join(path, fname), "r", encoding="utf-8") as f:
                texts.append(f.read())
    return texts
