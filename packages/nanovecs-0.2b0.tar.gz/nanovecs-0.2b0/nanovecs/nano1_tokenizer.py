# nanovecs/nano1_tokenizer.py
import re

class Tokenizer:
    def __init__(self):
        self.vocab = {}
        self.inv_vocab = {}

    def tokenize(self, text: str):
        text = text.lower()
        tokens = re.findall(r"\b\w+\b", text)
        return tokens

    def build_vocab(self, corpus, min_freq=1):
        freq = {}
        for text in corpus:
            for tok in self.tokenize(text):
                freq[tok] = freq.get(tok, 0) + 1
        self.vocab = {w:i for i,(w,c) in enumerate(freq.items()) if c >= min_freq}
        self.inv_vocab = {i:w for w,i in self.vocab.items()}
