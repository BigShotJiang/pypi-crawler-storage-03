# nanovecs/nano4_embeddings.py
import random
import math

class Embeddings:
    def __init__(self, vocab_size, dim=10):
        self.dim = dim
        self.vectors = [[random.uniform(-0.5,0.5) for _ in range(dim)] for _ in range(vocab_size)]

    def get(self, idx):
        return self.vectors[idx]

    def update(self, idx, grad, lr=0.01):
        for d in range(self.dim):
            self.vectors[idx][d] -= lr * grad[d]

def cosine(v1, v2):
    dot = sum(a*b for a,b in zip(v1,v2))
    n1 = math.sqrt(sum(a*a for a in v1))
    n2 = math.sqrt(sum(b*b for b in v2))
    return dot / (n1*n2 + 1e-9)
