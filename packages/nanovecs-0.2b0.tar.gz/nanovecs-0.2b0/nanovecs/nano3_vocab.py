# nanovecs/nano3_vocab.py
class Vocabulary:
    def __init__(self, tokens):
        self.word2id = {w:i for i,w in enumerate(sorted(set(tokens)))}
        self.id2word = {i:w for w,i in self.word2id.items()}

    def encode(self, tokens):
        return [self.word2id[t] for t in tokens if t in self.word2id]

    def decode(self, ids):
        return [self.id2word[i] for i in ids if i in self.id2word]
