# nanovecs/nano5_trainer.py
import random

def generate_pairs(tokens, window=2):
    pairs = []
    for i, target in enumerate(tokens):
        for j in range(max(0,i-window), min(len(tokens), i+window+1)):
            if i != j:
                pairs.append((target, tokens[j]))
    return pairs

def train(pairs, emb, epochs=5, lr=0.01):
    for _ in range(epochs):
        random.shuffle(pairs)
        for center, context in pairs:
            v_c = emb.get(center)
            v_o = emb.get(context)
            grad = [(a-b) for a,b in zip(v_c,v_o)]
            emb.update(center, grad, lr)
            emb.update(context, [-g for g in grad], lr)
