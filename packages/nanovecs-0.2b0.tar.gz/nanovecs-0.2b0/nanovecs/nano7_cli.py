# nanovecs/nano7_cli.py
from .nano1_tokenizer import Tokenizer
from .nano3_vocab import Vocabulary
from .nano4_embeddings import Embeddings
from .nano5_trainer import generate_pairs, train
from .nano6_search import most_similar

def main():
    text = "gato perro gato juega con perro perro y gato"
    tok = Tokenizer()
    tokens = tok.tokenize(text)
    vocab = Vocabulary(tokens)
    ids = vocab.encode(tokens)

    emb = Embeddings(len(vocab.word2id), dim=5)
    pairs = generate_pairs(ids, window=2)
    train(pairs, emb, epochs=50, lr=0.01)

    print("Más similares a 'gato':")
    for w,score in most_similar("gato", vocab, emb):
        print(w, score)

if __name__ == "__main__":
    main()
