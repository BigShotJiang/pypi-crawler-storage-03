# nanovecs/nano6_search.py
from .nano4_embeddings import cosine

def most_similar(word, vocab, emb, topn=5):
    if word not in vocab.word2id:
        return []
    wid = vocab.word2id[word]
    vec = emb.get(wid)
    sims = []
    for w,i in vocab.word2id.items():
        if w != word:
            sims.append((w, cosine(vec, emb.get(i))))
    sims.sort(key=lambda x: x[1], reverse=True)
    return sims[:topn]

