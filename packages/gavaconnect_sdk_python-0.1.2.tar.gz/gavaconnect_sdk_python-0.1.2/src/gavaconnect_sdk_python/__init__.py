def main() -> None:
    print("Hello from gavaconnect-sdk-python!")
