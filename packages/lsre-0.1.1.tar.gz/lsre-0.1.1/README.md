# Learn Simple Regular Expressions

[![pr-checks](https://github.com/rohit1998/lsre/actions/workflows/pr-checks.yml/badge.svg)](https://github.com/rohit1998/lsre/actions/workflows/pr-checks.yml)
[![PyPI version](https://img.shields.io/pypi/v/lsre.svg)](https://pypi.org/project/lsre/)
[![Python versions](https://img.shields.io/pypi/pyversions/lsre.svg)](https://pypi.org/project/lsre/)

A project to learn simple regular expressions.

## Overview

Create a package to do simple regular expressions. Also publish package to pypi to learn automated publishing.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
