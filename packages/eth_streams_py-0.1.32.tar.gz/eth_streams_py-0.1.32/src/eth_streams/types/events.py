from enum import Enum, auto


class StreamEvents(Enum):
    stopped = auto()
