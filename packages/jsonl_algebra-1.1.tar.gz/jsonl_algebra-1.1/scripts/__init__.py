"""
Scripts module for jsonl-algebra

This module contains command-line utilities and tools for working with
jsonl-algebra datasets and examples.
"""

__version__ = "1.0.0"
