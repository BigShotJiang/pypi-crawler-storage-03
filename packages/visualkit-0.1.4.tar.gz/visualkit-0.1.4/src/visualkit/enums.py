from enum import Enum


class AnimationType(Enum):
    TYPEWRITER = "typewriter"
    FADE_IN = "fade_in"
    SIMPLE = "simple"
