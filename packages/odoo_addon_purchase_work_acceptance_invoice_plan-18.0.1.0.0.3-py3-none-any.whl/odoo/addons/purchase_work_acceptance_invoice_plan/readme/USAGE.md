**Usual process of Purchasing with Work Acceptance using Invoice Plan**

- Go to menu Purchase \> Create a New Purchase Order.

- Select option "Use Invoice Plan" and fill information in Invoice Plan
  Tab.

- Confirm Purchase Order

- To create Work Acceptance, click button "Create WA by Installment"  
  - Select the installment
  - For better control of product line to be on WA, select **Based
    On** 1) All product lines 2) Product line with matched amount

- Accept the Work Acceptance.

**Note:** the **Based On** option is create by server action, it is
possible to create more option.
