# Judge0-API-wrapper

API wrapper for Judge0.

## Installation
```bash
pip install judge0-api-wrapper