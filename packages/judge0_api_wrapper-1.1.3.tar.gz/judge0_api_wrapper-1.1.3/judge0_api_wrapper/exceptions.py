class LanguageNotFound(Exception):
    pass
