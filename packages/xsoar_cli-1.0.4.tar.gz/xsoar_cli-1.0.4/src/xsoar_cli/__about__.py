# SPDX-FileCopyrightText: 2025-present Torbjørn Lium <torben@lium.org>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.4"
