from .scraper import WikiScraper

__all__ = ["WikiScraper"]
