# GeoFetchr

[![PyPI - Version](https://img.shields.io/pypi/v/geofetchr.svg)](https://pypi.org/project/geofetchr)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/geofetchr.svg)](https://pypi.org/project/geofetchr)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install geofetchr
```

## License

`geofetchr` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
