from __future__ import annotations

from pypistats import cli

if __name__ == "__main__":
    cli.main()
