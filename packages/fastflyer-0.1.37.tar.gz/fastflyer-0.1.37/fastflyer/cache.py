from fastkit.cache import get_redis_pool  # pylint: disable=unused-import  # noqa
