# -*- coding: utf-8 -*-
"""
包入口
"""


class Items():
    """
    Items 逻辑模块
    """

    def __init__(self):
        pass
