# -*- coding: utf-8 -*-


class Relationship():
    """
    用户关系模块
    """

    def __init__(self):
        pass
