# -*- coding: utf-8 -*-


class Relationship():
    """
    用户信息模块
    """

    def __init__(self):
        pass
