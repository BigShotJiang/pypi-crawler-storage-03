from ocp_resources.resource import Resource


class ConsoleQuickStart(Resource):
    """
    ConsoleQuickStart object.
    """

    api_group = Resource.ApiGroup.CONSOLE_OPENSHIFT_IO
