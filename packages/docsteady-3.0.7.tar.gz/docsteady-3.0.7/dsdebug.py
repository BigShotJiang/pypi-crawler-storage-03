# for debugger entry
import sys

from docsteady import cli

sys.exit(cli())
