def hello() -> str:
    return "Hello from nanodjango-compose!"
