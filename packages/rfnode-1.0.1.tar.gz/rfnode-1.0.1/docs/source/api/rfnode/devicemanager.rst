.. automodule:: rfnode.devicemanager
   :members:
   :undoc-members:
   :show-inheritance:

