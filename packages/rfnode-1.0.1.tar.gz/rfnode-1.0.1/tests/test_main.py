def test_main():
    assert 1 == 1
