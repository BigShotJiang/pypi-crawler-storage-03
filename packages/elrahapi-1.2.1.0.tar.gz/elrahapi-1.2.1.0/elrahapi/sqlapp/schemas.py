# from pydantic import BaseModel, Field
# from datetime import datetime
# from decimal import Decimal

# # from .meta_models import EntityBaseModel

# class EntityCreateModel(BaseModel):
#     pass

# class EntityUpdateModel(BaseModel):
#     pass

# class EntityPatchModel(BaseModel):
#     pass

# class EntityReadModel(BaseModel):
#     id : int
#     date_created: datetime
#     date_updated: datetime 
#     class Config:
#         from_attributes=True


# class EntityFullReadModel(EntityReadModel):
#     pass
#     class Config:
#         from_attributes=True
