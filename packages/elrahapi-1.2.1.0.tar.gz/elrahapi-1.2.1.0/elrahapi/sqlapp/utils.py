# Ce fichier pourra servir à créer des utilitaire pour l'application comme des fonctions ou des enumerations
import enum
