from __future__ import annotations
from typing import Annotated

import sys
import typer

import logging

from rich.console import Console
from rich.table import Table

from .preprocessing import app_preprocessing

log = logging.getLogger(__name__)

console = Console()

app = typer.Typer(
    name="¨PrismToolBox",
    help="A CLI for the PrismToolBox library.",
    no_args_is_help=True,
    add_completion=True,
    rich_markup_mode="rich",
)

app.add_typer(app_preprocessing, name="preprocessing", help="Preprocessing commands of the PrismToolBox.")

@app.callback()
def main(
    ctx: typer.Context,
    verbose: Annotated[int, typer.Option("-v", count=True, help="Increase verbosity.", show_default=False)] = 0,
    skip_errors: Annotated[bool, typer.Option(help="Skip slides which raised an error during processing.")] = False,
    skip_existing: Annotated[bool, typer.Option(help="Skip existing files.")] = True,
    tracking_file: Annotated[bool, typer.Option(help="Enable tracking file for processing status.")] = False,
):
    if verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    else:
        level = logging.WARNING
    logging.basicConfig(level=level)
    ctx.ensure_object(dict)
    ctx.obj["skip_errors"] = skip_errors
    ctx.obj["skip_existing"] = skip_existing
    ctx.obj["tracking_file"] = tracking_file

@app.command()
def version():
    """Show the version of PrismToolBox."""
    from prismtoolbox import __version__
    console.print(f"PrismToolBox version: [bold green]{__version__}[/bold green]")

@app.command()
def info():
    """Display detailed information about the installed package and dependencies."""
    from prismtoolbox import __version__
    
    table = Table(title="PrismToolBox Information")
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    
    table.add_row("Version", __version__)
    
    # Check optional dependencies
    try:
        import torch
        table.add_row("Patch Embedding", f"✅ Available (PyTorch {torch.__version__})")
    except ImportError:
        table.add_row("Patch Embedding", "❌ Not available")
        
    try:
        import cellpose
        table.add_row("Nuclei Segmentation", f"✅ Available (Cellpose {cellpose.version})")
    except ImportError:
        table.add_row("Nuclei Segmentation", "❌ Not available")
    
    console.print(table)
    
    if not any([sys.modules.get(m) for m in ['torch', 'cellpose']]):
        console.print("\n[yellow]Tip: Install optional dependencies with:[/yellow]")
        console.print("  [bold]pip install prismtoolbox[seg,emb][/bold]")