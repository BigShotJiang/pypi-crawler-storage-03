from .embedder import SlideEmbedder, PatchEmbedder
from .processing import EmbeddingProcessor
