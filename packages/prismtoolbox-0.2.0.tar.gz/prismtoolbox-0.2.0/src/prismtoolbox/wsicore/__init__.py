from .wsi import WSI
