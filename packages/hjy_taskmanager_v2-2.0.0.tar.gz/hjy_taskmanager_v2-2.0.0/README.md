# hjy-taskmanager-v2

Hjy taskmanager package version 2.0.0.

## Installation

```bash
pip install hjy-taskmanager-v2
```

## Usage

```python
import hjy_taskmanager_v2
print(hjy_taskmanager_v2.__version__)
```
