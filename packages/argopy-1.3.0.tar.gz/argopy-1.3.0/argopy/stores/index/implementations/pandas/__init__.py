from .index import indexstore  # noqa: F401
from .search_engine import SearchEngine  # noqa: F401  # this import will register the .query accessor, don't remove
