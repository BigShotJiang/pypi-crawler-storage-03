"""F5 Distributed Cloud (F5XC) DNS Authenticator plugin for Certbot."""

__version__ = "1.0.0"
