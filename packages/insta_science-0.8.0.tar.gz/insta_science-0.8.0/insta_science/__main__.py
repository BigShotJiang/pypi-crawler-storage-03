# Copyright 2024 Science project contributors.
# Licensed under the Apache License, Version 2.0 (see LICENSE).

from . import shim

if __name__ == "__main__":
    shim.main()
