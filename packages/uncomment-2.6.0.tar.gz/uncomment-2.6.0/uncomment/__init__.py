"""
uncomment: A fast, accurate comment removal tool using tree-sitter for AST parsing
"""

__version__ = "2.6.0"
