# SPDX-FileCopyrightText: 2025-present 0rac130fD31phi
# <william.astley@algebraicwealth.com>
#
# SPDX-License-Identifier: MIT
from __future__ import annotations
