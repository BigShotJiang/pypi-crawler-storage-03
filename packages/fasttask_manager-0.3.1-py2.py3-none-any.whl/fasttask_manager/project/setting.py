# fasttask setting
project_title = "⚡{project_name}⚡"
project_summary = "{project_name} by Fasttask"
project_description = (
    "more info: https://github.com/iridesc/fasttask"
) 
project_version = "ver: 🐕"
