.. automodule:: pydsm.NTFdesign.delsig
