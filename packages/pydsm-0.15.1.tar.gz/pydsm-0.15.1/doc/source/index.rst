Welcome to PyDSM's documentation!
=================================

.. only:: not latex

   Contents:

.. toctree::
   :maxdepth: 2

   intro
   getting-started
   reference
   replicate-results
   license
   included_code
   more-references
   changelog

.. only:: html

   Indices and tables
   ==================

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
