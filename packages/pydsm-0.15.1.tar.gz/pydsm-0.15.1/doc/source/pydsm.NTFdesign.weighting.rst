.. automodule:: pydsm.NTFdesign.weighting
