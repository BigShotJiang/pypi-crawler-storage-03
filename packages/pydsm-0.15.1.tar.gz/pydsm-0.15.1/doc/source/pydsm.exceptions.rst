.. automodule:: pydsm.exceptions
