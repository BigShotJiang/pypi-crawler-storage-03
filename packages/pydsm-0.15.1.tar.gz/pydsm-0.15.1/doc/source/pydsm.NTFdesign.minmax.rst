.. automodule:: pydsm.NTFdesign.minmax
