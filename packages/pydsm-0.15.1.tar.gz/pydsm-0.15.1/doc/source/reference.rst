Reference guide
===============

.. automodule:: pydsm
