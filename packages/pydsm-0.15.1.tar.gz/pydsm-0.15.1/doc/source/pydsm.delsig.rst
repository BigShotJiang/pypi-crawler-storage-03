.. automodule:: pydsm.delsig
