.. automodule:: pydsm.correlations
