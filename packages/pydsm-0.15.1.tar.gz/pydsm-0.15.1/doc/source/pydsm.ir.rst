.. automodule:: pydsm.ir
