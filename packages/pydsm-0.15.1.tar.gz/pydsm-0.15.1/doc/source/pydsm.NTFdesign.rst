.. automodule:: pydsm.NTFdesign

.. toctree::
   :hidden:

   pydsm.NTFdesign.delsig
   pydsm.NTFdesign.weighting
   pydsm.NTFdesign.minmax
   pydsm.NTFdesign.psychoacoustic
   pydsm.NTFdesign.merit_factors
   pydsm.NTFdesign.helpers
   pydsm.NTFdesign.legacy
   pydsm.NTFdesign.filter_based
