# flake8: noqa

# import apis into api package
from eazyrent.core.v2.api.accepted_documents_api import AcceptedDocumentsApi
from eazyrent.core.v2.api.applicant_forms_api import ApplicantFormsApi
from eazyrent.core.v2.api.documents_api import DocumentsApi
from eazyrent.core.v2.api.rental_files_api import RentalFilesApi
from eazyrent.core.v2.api.rental_files_comments_api import RentalFilesCommentsApi
from eazyrent.core.v2.api.share_links_api import ShareLinksApi
from eazyrent.core.v2.api.tags_api import TagsApi
