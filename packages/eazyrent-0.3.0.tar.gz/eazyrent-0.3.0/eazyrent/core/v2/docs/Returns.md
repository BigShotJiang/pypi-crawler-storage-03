# Returns


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from core.v2.models.returns import Returns

# TODO update the JSON string below
json = "{}"
# create an instance of Returns from a JSON string
returns_instance = Returns.from_json(json)
# print the JSON string representation of the object
print(Returns.to_json())

# convert the object into a dict
returns_dict = returns_instance.to_dict()
# create an instance of Returns from a dict
returns_from_dict = Returns.from_dict(returns_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


