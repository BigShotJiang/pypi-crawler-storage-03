# Previous


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from core.v2.models.previous import Previous

# TODO update the JSON string below
json = "{}"
# create an instance of Previous from a JSON string
previous_instance = Previous.from_json(json)
# print the JSON string representation of the object
print(Previous.to_json())

# convert the object into a dict
previous_dict = previous_instance.to_dict()
# create an instance of Previous from a dict
previous_from_dict = Previous.from_dict(previous_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


