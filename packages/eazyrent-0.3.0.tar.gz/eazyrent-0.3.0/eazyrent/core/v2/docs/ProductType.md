# ProductType


## Enum

* `HOUSE` (value: `'house'`)

* `APARTMENT` (value: `'apartment'`)

* `LAND` (value: `'land'`)

* `COMMERCIAL` (value: `'commercial'`)

* `OTHER` (value: `'other'`)

* `PRESTIGE` (value: `'prestige'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


