# ToDownload


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from core.v2.models.to_download import ToDownload

# TODO update the JSON string below
json = "{}"
# create an instance of ToDownload from a JSON string
to_download_instance = ToDownload.from_json(json)
# print the JSON string representation of the object
print(ToDownload.to_json())

# convert the object into a dict
to_download_dict = to_download_instance.to_dict()
# create an instance of ToDownload from a dict
to_download_from_dict = ToDownload.from_dict(to_download_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


