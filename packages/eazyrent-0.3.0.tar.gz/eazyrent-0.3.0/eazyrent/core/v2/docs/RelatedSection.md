# RelatedSection


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from core.v2.models.related_section import RelatedSection

# TODO update the JSON string below
json = "{}"
# create an instance of RelatedSection from a JSON string
related_section_instance = RelatedSection.from_json(json)
# print the JSON string representation of the object
print(RelatedSection.to_json())

# convert the object into a dict
related_section_dict = related_section_instance.to_dict()
# create an instance of RelatedSection from a dict
related_section_from_dict = RelatedSection.from_dict(related_section_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


