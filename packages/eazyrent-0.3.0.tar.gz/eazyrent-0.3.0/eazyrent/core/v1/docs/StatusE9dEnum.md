# StatusE9dEnum


## Enum

* `NEUTRAL` (value: `'NEUTRAL'`)

* `WARNING` (value: `'WARNING'`)

* `ERROR` (value: `'ERROR'`)

* `SUCCESS` (value: `'SUCCESS'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


