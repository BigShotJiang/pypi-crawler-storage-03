# Status6d0Enum


## Enum

* `RECEIVED` (value: `'RECEIVED'`)

* `PROCESSING` (value: `'PROCESSING'`)

* `PROCESSED` (value: `'PROCESSED'`)

* `ACTION_REQUIRED` (value: `'ACTION_REQUIRED'`)

* `EXTRACTING` (value: `'EXTRACTING'`)

* `EXTRACTED` (value: `'EXTRACTED'`)

* `APPLICANT_ACTION_REQUIRED` (value: `'APPLICANT_ACTION_REQUIRED'`)

* `VALIDATING` (value: `'VALIDATING'`)

* `VALIDATED` (value: `'VALIDATED'`)

* `COLLECTED` (value: `'COLLECTED'`)

* `REJECTED` (value: `'REJECTED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


