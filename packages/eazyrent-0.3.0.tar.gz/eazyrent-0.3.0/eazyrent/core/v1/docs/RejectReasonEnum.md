# RejectReasonEnum


## Enum

* `TOO_MANY_PAGES` (value: `'TOO_MANY_PAGES'`)

* `INCOMPLETE_DOCUMENT` (value: `'INCOMPLETE_DOCUMENT'`)

* `UNREADABLE_DOCUMENT` (value: `'UNREADABLE_DOCUMENT'`)

* `WRONG_DOCUMENT` (value: `'WRONG_DOCUMENT'`)

* `NOT_SUPPORTED` (value: `'NOT_SUPPORTED'`)

* `UNPROCESSABLE` (value: `'UNPROCESSABLE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


