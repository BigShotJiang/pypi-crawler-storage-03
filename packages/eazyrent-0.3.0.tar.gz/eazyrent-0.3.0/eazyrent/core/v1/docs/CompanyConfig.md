# CompanyConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from core.v1.models.company_config import CompanyConfig

# TODO update the JSON string below
json = "{}"
# create an instance of CompanyConfig from a JSON string
company_config_instance = CompanyConfig.from_json(json)
# print the JSON string representation of the object
print(CompanyConfig.to_json())

# convert the object into a dict
company_config_dict = company_config_instance.to_dict()
# create an instance of CompanyConfig from a dict
company_config_from_dict = CompanyConfig.from_dict(company_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


