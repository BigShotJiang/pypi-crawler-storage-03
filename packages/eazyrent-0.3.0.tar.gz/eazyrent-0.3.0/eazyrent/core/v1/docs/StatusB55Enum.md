# StatusB55Enum


## Enum

* `NEW` (value: `'NEW'`)

* `OPEN` (value: `'OPEN'`)

* `COLLECT_STARTED` (value: `'COLLECT_STARTED'`)

* `COLLECT_COMPLETE` (value: `'COLLECT_COMPLETE'`)

* `PROCESSING` (value: `'PROCESSING'`)

* `HUMAN_ACTION_REQUIRED` (value: `'HUMAN_ACTION_REQUIRED'`)

* `ANALYZED` (value: `'ANALYZED'`)

* `COLLECTED` (value: `'COLLECTED'`)

* `CLOSED` (value: `'CLOSED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


