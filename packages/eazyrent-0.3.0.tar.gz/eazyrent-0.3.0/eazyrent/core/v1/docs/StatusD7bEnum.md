# StatusD7bEnum


## Enum

* `NEW` (value: `'NEW'`)

* `OPEN` (value: `'OPEN'`)

* `PROCESSING` (value: `'PROCESSING'`)

* `HUMAN_ACTION_REQUIRED` (value: `'HUMAN_ACTION_REQUIRED'`)

* `COLLECTED` (value: `'COLLECTED'`)

* `ANALYZED` (value: `'ANALYZED'`)

* `CLOSED` (value: `'CLOSED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


