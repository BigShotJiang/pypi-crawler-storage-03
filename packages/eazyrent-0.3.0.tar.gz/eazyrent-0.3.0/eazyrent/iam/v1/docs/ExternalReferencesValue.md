# ExternalReferencesValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from iam.v1.models.external_references_value import ExternalReferencesValue

# TODO update the JSON string below
json = "{}"
# create an instance of ExternalReferencesValue from a JSON string
external_references_value_instance = ExternalReferencesValue.from_json(json)
# print the JSON string representation of the object
print(ExternalReferencesValue.to_json())

# convert the object into a dict
external_references_value_dict = external_references_value_instance.to_dict()
# create an instance of ExternalReferencesValue from a dict
external_references_value_from_dict = ExternalReferencesValue.from_dict(external_references_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


