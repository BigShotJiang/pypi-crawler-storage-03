from __future__ import annotations

__version__ = "25.3.5.0"
__vectice_version__ = "25.3"
