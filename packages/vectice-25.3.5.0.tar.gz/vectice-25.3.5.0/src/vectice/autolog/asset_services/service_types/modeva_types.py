from __future__ import annotations

from enum import Enum


class ModevaType(Enum):
    FACTSHEET = "FACTSHEET"
    VALIDATION_RESULT = "VALIDATION_RESULT"
