from __future__ import annotations

from typing import Any, Dict

JsonObject = Dict[str, Any]
