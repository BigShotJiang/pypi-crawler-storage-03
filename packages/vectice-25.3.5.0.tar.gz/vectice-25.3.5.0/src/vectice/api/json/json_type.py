from __future__ import annotations

from typing import Any, Dict

# TODO - This type can be improved, see : https://stackoverflow.com/questions/76345697/type-hinting-json-object-rigorously
TJSON = Dict[str, Any]
