from __future__ import annotations

from typing import TypedDict


class PhaseInput(TypedDict):
    name: str
    description: str | None
