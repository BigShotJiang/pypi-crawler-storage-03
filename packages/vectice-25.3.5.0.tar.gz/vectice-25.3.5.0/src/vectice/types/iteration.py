from __future__ import annotations

from typing import TypedDict


class IterationInput(TypedDict):
    name: str | None
    description: str | None
