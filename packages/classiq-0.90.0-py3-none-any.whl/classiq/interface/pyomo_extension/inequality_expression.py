from typing import Any


def getname(self: Any, *args: Any, **kwds: Any) -> str:
    return "inequality"
