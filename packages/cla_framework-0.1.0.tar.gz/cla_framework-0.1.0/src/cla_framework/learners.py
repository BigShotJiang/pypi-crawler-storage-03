from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import numpy as np

class SklearnLearner:
    def __init__(self, estimator):
        self.model = estimator

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict_proba(self, X):
        return self.model.predict_proba(X)

    def predict(self, X):
        return self.model.predict(X)

    def coef_for_class(self, class_idx):
        base = getattr(self.model, 'base_estimator', None)
        if base is not None and hasattr(base, 'coef_'):
            return base.coef_[class_idx]
        if hasattr(self.model, 'coef_'):
            return self.model.coef_[class_idx]
        return None

    def feature_importances(self):
        base = getattr(self.model, 'base_estimator', None)
        if base is not None and hasattr(base, 'feature_importances_'):
            return base.feature_importances_
        if hasattr(self.model, 'feature_importances_'):
            return self.model.feature_importances_
        return None

def make_calibrated_lr(max_iter=2000):
    lr = LogisticRegression(max_iter=max_iter, solver='lbfgs', multi_class='auto')
    return CalibratedClassifierCV(lr, cv=3, method='isotonic')

def make_calibrated_rf(n_estimators=200, random_state=7):
    rf = RandomForestClassifier(n_estimators=n_estimators, random_state=random_state)
    return CalibratedClassifierCV(rf, cv=3, method='isotonic')
