import matplotlib.pyplot as plt
import numpy as np

def plot_reliability_diagram(confidences, accuracies, n_bins=10):
    # confidences: array of confidence values; accuracies: 0/1 per sample (correct=1)
    bins = np.linspace(0.0, 1.0, n_bins+1)
    binids = np.digitize(confidences, bins) - 1
    bin_accs = []
    bin_confs = []
    for i in range(len(bins)-1):
        idx = np.where(binids == i)[0]
        if len(idx) > 0:
            bin_accs.append(np.mean(accuracies[idx]))
            bin_confs.append(np.mean(confidences[idx]))
        else:
            bin_accs.append(0.0)
            bin_confs.append((bins[i] + bins[i+1]) / 2)
    plt.figure(figsize=(6,6))
    plt.plot([0,1],[0,1], linestyle='--', color='gray')
    plt.plot(bin_confs, bin_accs, marker='o')
    plt.xlabel('Confidence'); plt.ylabel('Accuracy')
    plt.title('Reliability Diagram')
    plt.grid(True)
    plt.show()
