class AbstainPolicy:
    def __init__(self, threshold=0.7):
        self.threshold = threshold

    def decide(self, confidence, agree=True):
        return "answer" if confidence >= self.threshold else "abstain"

    def rationale(self, confidence, agree=True):
        return f"Confidence {confidence:.2f} {'≥' if confidence>=self.threshold else '<'} threshold {self.threshold:.2f}."

class ThresholdAgreementPolicy(AbstainPolicy):
    def __init__(self, threshold=0.7, require_agreement=True):
        super().__init__(threshold)
        self.require_agreement = require_agreement

    def decide(self, confidence, agree=True):
        if confidence < self.threshold:
            return "abstain"
        if self.require_agreement and not agree:
            return "abstain"
        return "answer"

    def rationale(self, confidence, agree=True):
        base = super().rationale(confidence, agree)
        if self.require_agreement:
            return base + (" Alternate model agrees." if agree else " Alternate model disagrees → abstain for safety.")
        return base
