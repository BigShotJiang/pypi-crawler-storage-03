from dataclasses import dataclass
from typing import List, Tuple, Optional
import numpy as np

@dataclass
class Explanation:
    predicted_class: int
    confidence: float
    action: str
    rationale: str
    top_features: List[Tuple[int, float]]
    agreement_with_alt: Optional[bool] = None

@dataclass
class TraceRecord:
    index: int
    y_true: Optional[int]
    explanation: Explanation

class CLAEngine:
    def __init__(self, learner, alt_learner, policy, explainer):
        self.learner = learner
        self.alt_learner = alt_learner
        self.policy = policy
        self.explainer = explainer

    def fit(self, X, y):
        self.learner.fit(X, y)
        self.alt_learner.fit(X, y)
        self.classes_ = np.unique(y)
        return self

    def explain_one(self, x):
        probs = self.learner.predict_proba(x[None, :])[0]
        pred = int(np.argmax(probs))
        conf = float(probs[pred])
        alt_pred = int(self.alt_learner.predict(x[None, :])[0])
        agree = (pred == alt_pred)
        action = self.policy.decide(confidence=conf, agree=agree)
        top = self.explainer.top_contributions(self.learner, x, pred)
        rationale = self.policy.rationale(conf, agree)
        return Explanation(predicted_class=pred, confidence=conf, action=action,
                           rationale=rationale, top_features=top, agreement_with_alt=agree)

    def explain(self, X, y_true=None):
        traces = []
        for i, x in enumerate(X):
            e = self.explain_one(x)
            tr = TraceRecord(index=i, y_true=None if y_true is None else int(y_true[i]), explanation=e)
            traces.append(tr)
        return traces

    def export_traces_json(self, traces, path: str):
        serial = []
        for t in traces:
            e = t.explanation
            serial.append({
                "index": int(t.index),
                "y_true": None if t.y_true is None else int(t.y_true),
                "predicted_class": int(e.predicted_class),
                "confidence": float(e.confidence),
                "action": e.action,
                "rationale": e.rationale,
                "agreement_with_alt": bool(e.agreement_with_alt),
                "top_features": [(int(i), float(v)) for i, v in e.top_features]
            })
        import json
        with open(path, "w") as f:
            json.dump(serial, f, indent=2)
        return path
