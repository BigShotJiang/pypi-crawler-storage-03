import numpy as np

def expected_calibration_error(y_true, y_pred, confidences, n_bins=10):
    bins = np.linspace(0.0, 1.0, n_bins+1)
    binids = np.digitize(confidences, bins) - 1
    ece = 0.0
    for b in range(n_bins):
        idx = np.where(binids == b)[0]
        if len(idx) == 0:
            continue
        acc = np.mean(y_pred[idx] == y_true[idx])
        conf = np.mean(confidences[idx])
        ece += (len(idx) / len(confidences)) * abs(acc - conf)
    return ece

def brier_score(y_true, probs, n_classes):
    onehot = np.eye(n_classes)[y_true]
    return np.mean(np.sum((probs - onehot)**2, axis=1))

def coverage(actions):
    actions = np.array(actions)
    return np.mean(actions == "answer")

def overconfident_error_rate(y_true, y_pred, confidences, threshold):
    y_true = np.array(y_true); y_pred = np.array(y_pred); confidences = np.array(confidences)
    return np.mean((y_true != y_pred) & (confidences >= threshold))
