import numpy as np

class LinearContributionExplainer:
    def __init__(self, top_k=10):
        self.top_k = top_k

    def top_contributions(self, learner, x, class_idx):
        w = learner.coef_for_class(class_idx)
        if w is None:
            contrib = np.zeros_like(x)
        else:
            contrib = x * w
        idxs = np.argsort(np.abs(contrib))[-self.top_k:][::-1]
        return [(int(i), float(contrib[i])) for i in idxs]

class ImportanceExplainer:
    def __init__(self, top_k=10):
        self.top_k = top_k

    def top_contributions(self, learner, x, class_idx):
        imp = learner.feature_importances()
        if imp is None:
            return [(int(i), 0.0) for i in range(min(self.top_k, len(x)))]
        idxs = np.argsort(np.abs(imp))[-self.top_k:][::-1]
        return [(int(i), float(imp[i])) for i in idxs]
