# CLA Framework

[![PyPI version](https://badge.fury.io/py/cla-framework.svg)](https://pypi.org/project/cla-framework/)
[![Python Versions](https://img.shields.io/pypi/pyversions/cla-framework.svg)](https://pypi.org/project/cla-framework/)
[![License](https://img.shields.io/github/license/your-username/cla-framework.svg)](LICENSE)

Framework untuk **Collaborative Learning with Abstention (CLA)** yang menyediakan:
- Engine untuk menjalankan CLA
- Threshold agreement policy
- Linear contribution explainer
- Evaluasi kalibrasi (ECE, Brier Score, Coverage, Overconfident Error Rate)
- Visualisasi calibration curve & reliability diagram

---

## 🚀 Instalasi

Dari **PyPI**:

```bash
pip install cla-framework
