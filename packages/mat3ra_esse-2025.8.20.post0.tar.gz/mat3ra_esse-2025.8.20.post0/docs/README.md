# Overview

This folder is used for the fully-built (without "$ref", "$allOf", "include()" statements) JSON assets and is populated by the [build_schemas.js](../build_schemas.js) (with and appropriate flag).
