Code taken from: https://github.com/NVIDIA/bionemo-examples/tree/main/examples/nims/genmol
Modifications: 
  - include python type-hinting
  - formatted with ruff
  - include composite score function to incorporate tanimoto similarity in the final score
  - functionality to generate fingerprint similarity dataset in a multiprocessing context
