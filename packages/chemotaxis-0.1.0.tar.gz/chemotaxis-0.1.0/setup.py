from setuptools import setup, find_packages

setup(
    name='chemotaxis',
    version='0.1.0',
    author='Aditi Jantikar',
    author_email='aditijantikar5@gmail.com',
    description='A Python package for simulating and analyzing 1D chemotaxis models using noisy spatiotemporal data.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    # Automatically finds all sub-packages in the 'src' directory.
    packages=find_packages(where='src'),
    # Specifies the directory where the source code is located.
    package_dir={'': 'src'},
    install_requires=[
        'numpy',
        'matplotlib',
        'scipy',
        'pandas',
        'torch',
        'pysindy',
        'scikit-learn',
        'tensorflow'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Scientific/Engineering',
    ],
    python_requires='>=3.8',
)
