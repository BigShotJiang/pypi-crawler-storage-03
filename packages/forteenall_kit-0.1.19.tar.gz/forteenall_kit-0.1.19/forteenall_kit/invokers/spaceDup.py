class Data:
    pass

class Feature:
    def execute(self):
        pass

