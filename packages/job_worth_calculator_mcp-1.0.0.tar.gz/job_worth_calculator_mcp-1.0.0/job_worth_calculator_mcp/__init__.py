"""
🚀 工作性价比计算器MCP工具
基于worth-calculator项目的全面工作价值计算工具
"""

__version__ = "1.0.0"
__author__ = "AI助手"
__email__ = "ai@example.com"
__description__ = "基于worth-calculator的全面工作性价比计算MCP工具"