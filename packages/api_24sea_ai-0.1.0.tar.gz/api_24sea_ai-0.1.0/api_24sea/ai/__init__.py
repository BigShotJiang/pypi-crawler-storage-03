# -*- coding: utf-8 -*-
"""Namespace package for api_24sea.ai.

This package is part of the PEP 420 implicit namespace `api_24sea`.
Do not create an `__init__.py` at the top-level `api_24sea/`.
"""

from .version import __version__ as __version__  # noqa: F401
