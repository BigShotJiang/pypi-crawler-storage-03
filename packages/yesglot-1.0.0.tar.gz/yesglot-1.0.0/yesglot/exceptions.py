

class YesGlotException(Exception):
    pass
