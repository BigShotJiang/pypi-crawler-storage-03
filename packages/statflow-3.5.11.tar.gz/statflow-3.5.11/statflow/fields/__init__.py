#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# statkit/fields/__init__.py

# Define what should be available when using 'from statflow.fields import *'
__all__ = [
    'climatology'
]
