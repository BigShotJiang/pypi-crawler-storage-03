from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pyleetpatterns",
    version="0.1.0",
    author="q0d",
    author_email="ceo@q0d.net",
    description="Master 14 essential algorithmic patterns with drop-in Python implementations for LeetCode and coding interviews",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/pyleetpatterns",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=4.0",
            "mypy>=0.900",
        ]
    },
    keywords="leetcode algorithms patterns interview coding data-structures",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/pyleetpatterns/issues",
        "Source": "https://github.com/yourusername/pyleetpatterns",
    },
)

