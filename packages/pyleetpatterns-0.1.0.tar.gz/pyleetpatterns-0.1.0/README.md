# PyLeetPatterns

Master 14 essential algorithmic patterns with drop-in Python implementations for LeetCode and coding interviews.

### Production

```bash
pip install . # This installs the package normally into your Python environment.
```

## Development

### Setup

```bash
git clone https://github.com/njoye/pyleetpatterns.git
cd pyleetpatterns
python3 -m venv .venv
source .venv/bin/activate
pip install -e . # This installs the package in "editable" mode, so changes tothe code are immediately reflected without reinstalling.

# or

pip install -e ".[dev]" # This installs the package in editable mode along with development tools (pytest, black, flake8, mypy).
```

The [dev] packages are already defined in the setup.py
file. Look at lines 30-37:

```py
extras_require={
  "dev": [
      "pytest>=7.0",
      "black>=22.0",
      "flake8>=4.0",
      "mypy>=0.900",
  ]
},
```

This extras_require section in setup.py defines optional
dependencies. When you run:

```bash
pip install -e ".[dev]"
```

It will install:

1. The package itself in editable mode (-e .)
2. PLUS all the packages listed under the "dev" key:

- pytest (for testing)
- black (for code formatting)
- flake8 (for linting)
- mypy (for type checking)

You can add more development dependencies to this list if
needed. For example:

```py
extras_require={
  "dev": [
      "pytest>=7.0",
      "black>=22.0",
      "flake8>=4.0",
      "mypy>=0.900",
      "ipython>=8.0",  # for interactive debugging
      "pre-commit>=2.0",  # for git hooks
  ]
},
```

You could also define other optional dependency groups like:

```py
extras_require={
  "dev": [...],
  "docs": ["sphinx>=4.0", "sphinx-rtd-theme"],
  "viz": ["matplotlib>=3.0", "networkx>=2.0"],
}
```

Then install them with pip install -e ".[docs]" or pip
install -e ".[dev,docs]" for multiple groups.

### Testing

```bash
pytest
```

## Installation

```bash
pip install pyleetpatterns
```

## Quick Start

```python
from pyleetpatterns import PrefixSum, TwoPointers, SlidingWindow

# Example usage
ps = PrefixSum([1, 2, 3, 4, 5])
result = ps.range_sum(1, 3)  # Sum from index 1 to 3
```

See full documentation in `leetcode-patterns-readme.md`
