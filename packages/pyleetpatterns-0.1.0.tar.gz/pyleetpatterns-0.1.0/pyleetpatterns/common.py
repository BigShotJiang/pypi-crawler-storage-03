"""Common data structures used across patterns."""

class ListNode:
    """Simple linked list node implementation."""
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


class TreeNode:
    """Binary tree node definition."""
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right