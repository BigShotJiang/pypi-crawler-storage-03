"""PyLeetPatterns - Master 11 essential algorithmic patterns for coding interviews."""

from .patterns.prefix_sum import PrefixSum
from .patterns.two_pointers import TwoPointers
from .patterns.sliding_window import SlidingWindow
from .patterns.fast_slow_pointers import FastSlowPointers
from .patterns.linked_list_reversal import LinkedListReversal
from .patterns.monotonic_stack import MonotonicStack
from .patterns.top_k_elements import TopKElements
from .patterns.overlapping_intervals import OverlappingIntervals
from .patterns.modified_binary_search import ModifiedBinarySearch
from .patterns.tree_traversal import TreeTraversal
from .patterns.graph_traversal import GraphTraversal
from .patterns.matrix_traversal import MatrixTraversal
from .patterns.dynamic_programming import DynamicProgramming
from .patterns.backtracking import Backtracking
from .common import ListNode, TreeNode

__version__ = "0.1.0"

__all__ = [
    "PrefixSum",
    "TwoPointers",
    "SlidingWindow",
    "FastSlowPointers",
    "LinkedListReversal",
    "MonotonicStack",
    "TopKElements",
    "OverlappingIntervals",
    "ModifiedBinarySearch",
    "TreeTraversal",
    "GraphTraversal",
    "MatrixTraversal",
    "DynamicProgramming",
    "Backtracking",
    "ListNode",
    "TreeNode",
]