"""Backtracking Pattern for exhaustive search with pruning."""

from typing import List


class Backtracking:
    """
    Backtracking pattern for exhaustive search with pruning.
    Key insight: Explore all paths, backtrack when invalid.
    """

    @staticmethod
    def generate_subsets(nums: List[int]) -> List[List[int]]:
        """
        Generate all possible subsets (power set).

        Time Complexity: O(2^n * n)
        Space Complexity: O(2^n * n)
        """
        result = []

        def backtrack(start, path):
            result.append(path[:])

            for i in range(start, len(nums)):
                path.append(nums[i])
                backtrack(i + 1, path)
                path.pop()

        backtrack(0, [])
        return result

    @staticmethod
    def generate_permutations(nums: List[int]) -> List[List[int]]:
        """
        Generate all possible permutations.

        Time Complexity: O(n! * n)
        Space Complexity: O(n! * n)
        """
        result = []

        def backtrack(path):
            if len(path) == len(nums):
                result.append(path[:])
                return

            for num in nums:
                if num not in path:
                    path.append(num)
                    backtrack(path)
                    path.pop()

        backtrack([])
        return result

    @staticmethod
    def solve_n_queens(n: int) -> List[List[str]]:
        """
        Solve N-Queens problem.

        Time Complexity: O(n!)
        Space Complexity: O(n²)
        """
        result = []
        board = ['.' * n for _ in range(n)]

        def is_safe(row, col):
            # Check column
            for i in range(row):
                if board[i][col] == 'Q':
                    return False

            # Check diagonals
            for i, j in zip(range(row-1, -1, -1), range(col-1, -1, -1)):
                if board[i][j] == 'Q':
                    return False

            for i, j in zip(range(row-1, -1, -1), range(col+1, n)):
                if board[i][j] == 'Q':
                    return False

            return True

        def backtrack(row):
            if row == n:
                result.append(board[:])
                return

            for col in range(n):
                if is_safe(row, col):
                    board[row] = board[row][:col] + 'Q' + board[row][col+1:]
                    backtrack(row + 1)
                    board[row] = board[row][:col] + '.' + board[row][col+1:]

        backtrack(0)
        return result

    @staticmethod
    def generate_parentheses(n: int) -> List[str]:
        """
        Generate all valid parentheses combinations.

        Time Complexity: O(4^n / √n)
        Space Complexity: O(4^n / √n)
        """
        result = []

        def backtrack(current, open_count, close_count):
            if len(current) == 2 * n:
                result.append(current)
                return

            if open_count < n:
                backtrack(current + '(', open_count + 1, close_count)

            if close_count < open_count:
                backtrack(current + ')', open_count, close_count + 1)

        backtrack('', 0, 0)
        return result

    @staticmethod
    def word_search(board: List[List[str]], word: str) -> bool:
        """
        Search for word in 2D board.

        Time Complexity: O(m * n * 4^L) where L is word length
        Space Complexity: O(L)
        """
        rows, cols = len(board), len(board[0])

        def backtrack(r, c, index):
            if index == len(word):
                return True

            if (r < 0 or r >= rows or c < 0 or c >= cols or
                board[r][c] != word[index]):
                return False

            # Mark as visited
            temp = board[r][c]
            board[r][c] = '#'

            # Explore all 4 directions
            found = (backtrack(r+1, c, index+1) or
                    backtrack(r-1, c, index+1) or
                    backtrack(r, c+1, index+1) or
                    backtrack(r, c-1, index+1))

            # Restore cell
            board[r][c] = temp
            return found

        for i in range(rows):
            for j in range(cols):
                if backtrack(i, j, 0):
                    return True
        return False

    @staticmethod
    def combination_sum(candidates: List[int], target: int) -> List[List[int]]:
        """
        Find all combinations that sum to target.

        Time Complexity: O(2^n)
        Space Complexity: O(target/min(candidates))
        """
        result = []

        def backtrack(start, path, remaining):
            if remaining == 0:
                result.append(path[:])
                return

            for i in range(start, len(candidates)):
                if candidates[i] <= remaining:
                    path.append(candidates[i])
                    backtrack(i, path, remaining - candidates[i])
                    path.pop()

        backtrack(0, [], target)
        return result