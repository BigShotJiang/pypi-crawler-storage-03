"""Modified Binary Search pattern implementation."""

from typing import List


class ModifiedBinarySearch:
    """
    Modified Binary Search for special array conditions.
    Handles rotated arrays, duplicates, and unknown lengths.
    """
    
    @staticmethod
    def search_rotated_array(nums: List[int], target: int) -> int:
        """
        Search in a rotated sorted array.
        Example: [4,5,6,7,0,1,2] was [0,1,2,4,5,6,7] before rotation.
        
        Args:
            nums: Rotated sorted array
            target: Target value to find
            
        Returns:
            Index of target or -1 if not found
            
        Time Complexity: O(log n)
        Space Complexity: O(1)
        """
        left, right = 0, len(nums) - 1
        
        while left <= right:
            mid = (left + right) // 2
            
            if nums[mid] == target:
                return mid
            
            # Check which side is sorted
            if nums[left] <= nums[mid]:
                # Left side is sorted
                if nums[left] <= target < nums[mid]:
                    right = mid - 1
                else:
                    left = mid + 1
            else:
                # Right side is sorted
                if nums[mid] < target <= nums[right]:
                    left = mid + 1
                else:
                    right = mid - 1
        
        return -1
    
    @staticmethod
    def find_minimum_rotated(nums: List[int]) -> int:
        """
        Find minimum element in rotated sorted array.
        
        Args:
            nums: Rotated sorted array
            
        Returns:
            Minimum element in the array
            
        Time Complexity: O(log n)
        Space Complexity: O(1)
        """
        left, right = 0, len(nums) - 1
        
        while left < right:
            mid = (left + right) // 2
            
            if nums[mid] > nums[right]:
                # Minimum is in the right half
                left = mid + 1
            else:
                # Minimum is in the left half (including mid)
                right = mid
        
        return nums[left]
    
    @staticmethod
    def search_2d_matrix(matrix: List[List[int]], target: int) -> bool:
        """
        Search in a 2D matrix where each row is sorted.
        
        Args:
            matrix: 2D matrix with sorted rows
            target: Target value to find
            
        Returns:
            True if target exists, False otherwise
            
        Time Complexity: O(m + n)
        Space Complexity: O(1)
        """
        if not matrix or not matrix[0]:
            return False
        
        rows, cols = len(matrix), len(matrix[0])
        
        # Start from top-right corner
        row, col = 0, cols - 1
        
        while row < rows and col >= 0:
            if matrix[row][col] == target:
                return True
            elif matrix[row][col] > target:
                col -= 1  # Move left
            else:
                row += 1  # Move down
        
        return False
    
    @staticmethod
    def find_first_last_position(nums: List[int], target: int) -> List[int]:
        """
        Find first and last occurrence of target in sorted array.
        
        Args:
            nums: Sorted array
            target: Target value
            
        Returns:
            [first_position, last_position] or [-1, -1] if not found
            
        Time Complexity: O(log n)
        Space Complexity: O(1)
        """
        def find_bound(is_first: bool) -> int:
            left, right = 0, len(nums) - 1
            result = -1
            
            while left <= right:
                mid = (left + right) // 2
                
                if nums[mid] == target:
                    result = mid
                    if is_first:
                        right = mid - 1  # Search left for first occurrence
                    else:
                        left = mid + 1   # Search right for last occurrence
                elif nums[mid] < target:
                    left = mid + 1
                else:
                    right = mid - 1
            
            return result
        
        return [find_bound(True), find_bound(False)]