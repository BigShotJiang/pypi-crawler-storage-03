"""Graph Traversal pattern implementation."""

from typing import List, Dict, Set
from collections import deque, defaultdict


class GraphTraversal:
    """
    Graph traversal patterns using DFS and BFS.
    Handles cycle detection, path finding, and connected components.
    """
    
    @staticmethod
    def has_cycle_directed(num_nodes: int, edges: List[List[int]]) -> bool:
        """
        Detect cycle in directed graph using DFS with colors.
        
        Args:
            num_nodes: Number of nodes in graph
            edges: List of directed edges [from, to]
            
        Returns:
            True if cycle exists, False otherwise
            
        Time Complexity: O(V + E)
        Space Complexity: O(V)
        """
        # Build adjacency list
        graph = defaultdict(list)
        for u, v in edges:
            graph[u].append(v)
        
        # Colors: 0 = unvisited, 1 = visiting, 2 = visited
        colors = [0] * num_nodes
        
        def dfs(node):
            if colors[node] == 1:  # Back edge found
                return True
            if colors[node] == 2:  # Already processed
                return False
            
            colors[node] = 1  # Mark as visiting
            for neighbor in graph[node]:
                if dfs(neighbor):
                    return True
            colors[node] = 2  # Mark as visited
            return False
        
        # Check each component
        for i in range(num_nodes):
            if colors[i] == 0:
                if dfs(i):
                    return True
        return False
    
    @staticmethod
    def find_path_bfs(graph: Dict[int, List[int]], start: int, end: int) -> List[int]:
        """
        Find shortest path between two nodes using BFS.
        
        Args:
            graph: Adjacency list representation
            start: Starting node
            end: Target node
            
        Returns:
            Shortest path from start to end, or empty list if no path
            
        Time Complexity: O(V + E)
        Space Complexity: O(V)
        """
        if start == end:
            return [start]
        
        visited = {start}
        queue = deque([(start, [start])])
        
        while queue:
            node, path = queue.popleft()
            
            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    new_path = path + [neighbor]
                    
                    if neighbor == end:
                        return new_path
                    
                    visited.add(neighbor)
                    queue.append((neighbor, new_path))
        
        return []
    
    @staticmethod
    def dfs_all_paths(graph: Dict[int, List[int]], start: int, end: int) -> List[List[int]]:
        """
        Find all paths from start to end using DFS.
        
        Args:
            graph: Adjacency list representation
            start: Starting node
            end: Target node
            
        Returns:
            List of all possible paths
            
        Time Complexity: O(2^V * V) worst case
        Space Complexity: O(V)
        """
        result = []
        
        def dfs(node, path):
            if node == end:
                result.append(path[:])
                return
            
            for neighbor in graph.get(node, []):
                if neighbor not in path:  # Avoid cycles
                    path.append(neighbor)
                    dfs(neighbor, path)
                    path.pop()
        
        dfs(start, [start])
        return result
    
    @staticmethod
    def connected_components(num_nodes: int, edges: List[List[int]]) -> int:
        """
        Count number of connected components in undirected graph.
        
        Args:
            num_nodes: Number of nodes
            edges: List of undirected edges
            
        Returns:
            Number of connected components
            
        Time Complexity: O(V + E)
        Space Complexity: O(V)
        """
        # Build adjacency list
        graph = defaultdict(list)
        for u, v in edges:
            graph[u].append(v)
            graph[v].append(u)
        
        visited = set()
        components = 0
        
        def dfs(node):
            visited.add(node)
            for neighbor in graph[node]:
                if neighbor not in visited:
                    dfs(neighbor)
        
        for i in range(num_nodes):
            if i not in visited:
                dfs(i)
                components += 1
        
        return components