"""Matrix Traversal Pattern for 2D grid problems."""

from typing import List
from collections import deque


class MatrixTraversal:
    """
    Matrix Traversal patterns for 2D grid problems.
    Common techniques: DFS for connected components, BFS for shortest paths.
    """

    @staticmethod
    def flood_fill(image: List[List[int]], sr: int, sc: int, new_color: int) -> List[List[int]]:
        """
        Flood fill algorithm - change connected pixels to new color.

        Args:
            image: 2D grid representing image
            sr: Starting row
            sc: Starting column
            new_color: New color to fill

        Returns:
            Modified image after flood fill

        Time Complexity: O(m*n)
        Space Complexity: O(m*n) for recursion stack
        """
        if not image or not image[0]:
            return image

        original_color = image[sr][sc]
        if original_color == new_color:
            return image

        def dfs(r, c):
            if (r < 0 or r >= len(image) or
                c < 0 or c >= len(image[0]) or
                image[r][c] != original_color):
                return

            image[r][c] = new_color

            # Traverse 4 directions
            dfs(r + 1, c)  # down
            dfs(r - 1, c)  # up
            dfs(r, c + 1)  # right
            dfs(r, c - 1)  # left

        dfs(sr, sc)
        return image

    @staticmethod
    def num_islands(grid: List[List[str]]) -> int:
        """
        Count number of islands in a grid.

        Args:
            grid: 2D grid where '1' is land, '0' is water

        Returns:
            Number of islands

        Time Complexity: O(m*n)
        Space Complexity: O(m*n)
        """
        if not grid or not grid[0]:
            return 0

        rows, cols = len(grid), len(grid[0])
        islands = 0

        def dfs(r, c):
            if (r < 0 or r >= rows or c < 0 or c >= cols or
                grid[r][c] != '1'):
                return

            grid[r][c] = '0'  # Mark as visited

            # Check all 4 directions
            dfs(r + 1, c)
            dfs(r - 1, c)
            dfs(r, c + 1)
            dfs(r, c - 1)

        for i in range(rows):
            for j in range(cols):
                if grid[i][j] == '1':
                    dfs(i, j)
                    islands += 1

        return islands

    @staticmethod
    def shortest_path_binary_matrix(grid: List[List[int]]) -> int:
        """
        Find shortest path from top-left to bottom-right in binary matrix.

        Args:
            grid: Binary matrix where 0 is passable, 1 is blocked

        Returns:
            Length of shortest path, -1 if no path exists

        Time Complexity: O(m*n)
        Space Complexity: O(m*n)
        """
        if not grid or grid[0][0] == 1 or grid[-1][-1] == 1:
            return -1

        n = len(grid)
        if n == 1:
            return 1

        queue = deque([(0, 0, 1)])  # (row, col, distance)
        visited = set([(0, 0)])

        # 8 directions (including diagonals)
        directions = [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]

        while queue:
            row, col, dist = queue.popleft()

            for dr, dc in directions:
                new_row, new_col = row + dr, col + dc

                if (new_row == n-1 and new_col == n-1):
                    return dist + 1

                if (0 <= new_row < n and 0 <= new_col < n and
                    grid[new_row][new_col] == 0 and
                    (new_row, new_col) not in visited):

                    visited.add((new_row, new_col))
                    queue.append((new_row, new_col, dist + 1))

        return -1