"""Overlapping Intervals pattern implementation."""

from typing import List


class OverlappingIntervals:
    """
    Pattern for dealing with overlapping intervals or ranges.
    Key technique: Sort intervals by start time, then process sequentially.
    """
    
    @staticmethod
    def merge_intervals(intervals: List[List[int]]) -> List[List[int]]:
        """
        Merge all overlapping intervals.
        
        Args:
            intervals: List of intervals [start, end]
            
        Returns:
            List of merged intervals
            
        Time Complexity: O(n log n)
        Space Complexity: O(n)
        """
        if not intervals:
            return []
        
        # Sort intervals by start time
        intervals.sort(key=lambda x: x[0])
        
        merged = [intervals[0]]
        
        for current in intervals[1:]:
            last_merged = merged[-1]
            
            if current[0] <= last_merged[1]:
                # Overlapping intervals, merge them
                last_merged[1] = max(last_merged[1], current[1])
            else:
                # Non-overlapping interval, add to result
                merged.append(current)
        
        return merged
    
    @staticmethod
    def insert_interval(intervals: List[List[int]], 
                        new_interval: List[int]) -> List[List[int]]:
        """
        Insert new interval into sorted intervals list and merge if necessary.
        
        Args:
            intervals: Sorted list of non-overlapping intervals
            new_interval: Interval to insert
            
        Returns:
            List of intervals after insertion
            
        Time Complexity: O(n)
        Space Complexity: O(n)
        """
        result = []
        i = 0
        n = len(intervals)
        
        # Add all intervals before new_interval
        while i < n and intervals[i][1] < new_interval[0]:
            result.append(intervals[i])
            i += 1
        
        # Merge overlapping intervals
        while i < n and intervals[i][0] <= new_interval[1]:
            new_interval[0] = min(new_interval[0], intervals[i][0])
            new_interval[1] = max(new_interval[1], intervals[i][1])
            i += 1
        
        result.append(new_interval)
        
        # Add remaining intervals
        while i < n:
            result.append(intervals[i])
            i += 1
        
        return result
    
    @staticmethod
    def can_attend_all_meetings(intervals: List[List[int]]) -> bool:
        """
        Check if a person can attend all meetings (no overlaps).
        
        Args:
            intervals: List of meeting times [start, end]
            
        Returns:
            True if can attend all meetings, False otherwise
            
        Time Complexity: O(n log n)
        Space Complexity: O(1)
        """
        if not intervals:
            return True
        
        intervals.sort(key=lambda x: x[0])
        
        for i in range(1, len(intervals)):
            if intervals[i][0] < intervals[i-1][1]:
                return False
        
        return True