"""Linked List In-Place Reversal pattern implementation."""

from typing import Optional
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import ListNode


class LinkedListReversal:
    """
    In-place reversal pattern for linked lists.
    Modifies the original list structure without extra space.
    """
    
    @staticmethod
    def reverse_linked_list(head: Optional[ListNode]) -> Optional[ListNode]:
        """
        Reverse entire linked list in-place.
        
        Args:
            head: Head of the linked list
            
        Returns:
            New head of reversed list
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        prev = None
        current = head
        
        while current is not None:
            next_temp = current.next
            current.next = prev
            prev = current
            current = next_temp
        
        return prev
    
    @staticmethod
    def reverse_between(head: Optional[ListNode], left: int, right: int) -> Optional[ListNode]:
        """
        Reverse linked list from position left to right.
        
        Args:
            head: Head of the linked list
            left: Start position (1-indexed)
            right: End position (1-indexed)
            
        Returns:
            Head of modified list
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        if not head or left == right:
            return head
        
        dummy = ListNode(0)
        dummy.next = head
        pre = dummy
        
        # Move pre to the node before the reversal
        for _ in range(left - 1):
            pre = pre.next
        
        # Reverse the sublist
        current = pre.next
        for _ in range(right - left):
            temp = current.next
            current.next = temp.next
            temp.next = pre.next
            pre.next = temp
        
        return dummy.next
    
    @staticmethod
    def swap_pairs(head: Optional[ListNode]) -> Optional[ListNode]:
        """
        Swap every two adjacent nodes in the linked list.
        
        Args:
            head: Head of the linked list
            
        Returns:
            Head of modified list
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        dummy = ListNode(0)
        dummy.next = head
        prev = dummy
        
        while head and head.next:
            # Nodes to be swapped
            first = head
            second = head.next
            
            # Swapping
            prev.next = second
            first.next = second.next
            second.next = first
            
            # Move pointers for next swap
            prev = first
            head = first.next
        
        return dummy.next