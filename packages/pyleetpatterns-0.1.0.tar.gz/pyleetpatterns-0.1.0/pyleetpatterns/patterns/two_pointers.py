"""Two Pointers pattern implementation."""

from typing import List, Tuple


class TwoPointers:
    """
    Two Pointers pattern for pair searching and palindrome validation.
    Reduces time complexity from O(n²) to O(n) for many problems.
    """
    
    @staticmethod
    def two_sum_sorted(nums: List[int], target: int) -> Tuple[int, int]:
        """
        Find two numbers that add up to target in a sorted array.
        
        Args:
            nums: Sorted array of integers
            target: Target sum
            
        Returns:
            Tuple of indices (i, j) where nums[i] + nums[j] = target
            Returns (-1, -1) if no solution exists
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        left, right = 0, len(nums) - 1
        
        while left < right:
            current_sum = nums[left] + nums[right]
            if current_sum == target:
                return (left, right)
            elif current_sum < target:
                left += 1
            else:
                right -= 1
        
        return (-1, -1)
    
    @staticmethod
    def is_palindrome(s: str) -> bool:
        """
        Check if a string is a palindrome using two pointers.
        
        Args:
            s: Input string
            
        Returns:
            True if palindrome, False otherwise
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        left, right = 0, len(s) - 1
        
        while left < right:
            if s[left] != s[right]:
                return False
            left += 1
            right -= 1
        
        return True