"""Sliding Window pattern implementation."""

from typing import List, Tuple


class SlidingWindow:
    """
    Sliding Window pattern for subarray/substring problems.
    Maintains a window that slides through the array/string.
    """
    
    @staticmethod
    def max_subarray_sum(arr: List[int], k: int) -> Tuple[int, List[int]]:
        """
        Find subarray of size k with maximum sum.
        
        Args:
            arr: Input array
            k: Window size
            
        Returns:
            Tuple of (max_sum, subarray)
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        if not arr or k <= 0 or k > len(arr):
            return (0, [])
        
        # Calculate initial window sum
        window_sum = sum(arr[:k])
        max_sum = window_sum
        max_start = 0
        
        # Slide the window
        for i in range(k, len(arr)):
            window_sum = window_sum - arr[i - k] + arr[i]
            if window_sum > max_sum:
                max_sum = window_sum
                max_start = i - k + 1
        
        return (max_sum, arr[max_start:max_start + k])
    
    @staticmethod
    def longest_substring_without_repeating(s: str) -> int:
        """
        Find length of longest substring without repeating characters.
        
        Args:
            s: Input string
            
        Returns:
            Length of longest substring without repeating characters
            
        Time Complexity: O(n)
        Space Complexity: O(min(n, m)) where m is size of character set
        """
        char_index = {}
        max_length = 0
        start = 0
        
        for end, char in enumerate(s):
            if char in char_index and char_index[char] >= start:
                start = char_index[char] + 1
            
            char_index[char] = end
            max_length = max(max_length, end - start + 1)
        
        return max_length