"""Prefix Sum pattern implementation."""

from typing import List


class PrefixSum:
    """
    Prefix Sum pattern for efficient range sum queries.
    Perfect for problems requiring multiple subarray sum calculations.
    
    Time Complexity: O(n) preprocessing, O(1) per query
    Space Complexity: O(n)
    """
    
    def __init__(self, nums: List[int]):
        """Initialize prefix sum array."""
        self.prefix = [0]
        for num in nums:
            self.prefix.append(self.prefix[-1] + num)
    
    def range_sum(self, i: int, j: int) -> int:
        """
        Get sum of elements from index i to j (inclusive).
        
        Args:
            i: Start index
            j: End index
            
        Returns:
            Sum of elements in range [i, j]
        """
        return self.prefix[j + 1] - self.prefix[i]