"""Fast and Slow Pointers pattern implementation."""

from typing import Optional
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import ListNode


class FastSlowPointers:
    """
    Fast and Slow Pointers (Floyd's Tortoise and Hare) pattern.
    Used for cycle detection and finding middle elements.
    """
    
    @staticmethod
    def has_cycle(head: Optional[ListNode]) -> bool:
        """
        Detect if a linked list has a cycle.
        
        Args:
            head: Head of the linked list
            
        Returns:
            True if cycle exists, False otherwise
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        if not head or not head.next:
            return False
        
        slow = head
        fast = head.next
        
        while fast and fast.next:
            if slow == fast:
                return True
            slow = slow.next
            fast = fast.next.next
        
        return False
    
    @staticmethod
    def find_middle(head: Optional[ListNode]) -> Optional[ListNode]:
        """
        Find the middle node of a linked list.
        
        Args:
            head: Head of the linked list
            
        Returns:
            Middle node of the linked list
            
        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        if not head:
            return None
        
        slow = fast = head
        
        while fast.next and fast.next.next:
            slow = slow.next
            fast = fast.next.next
        
        return slow