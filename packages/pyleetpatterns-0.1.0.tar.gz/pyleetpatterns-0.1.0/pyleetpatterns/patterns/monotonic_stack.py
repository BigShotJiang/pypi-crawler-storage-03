"""Monotonic Stack pattern implementation."""

from typing import List


class MonotonicStack:
    """
    Monotonic Stack pattern for finding next greater/smaller elements.
    Maintains stack in monotonic increasing or decreasing order.
    """
    
    @staticmethod
    def next_greater_element(arr: List[int]) -> List[int]:
        """
        Find next greater element for each element in array.
        
        Args:
            arr: Input array
            
        Returns:
            Array where result[i] is next greater element for arr[i]
            Returns -1 if no greater element exists
            
        Time Complexity: O(n)
        Space Complexity: O(n)
        """
        n = len(arr)
        result = [-1] * n
        stack = []  # Stack stores indices
        
        for i in range(n):
            while stack and arr[i] > arr[stack[-1]]:
                result[stack.pop()] = arr[i]
            stack.append(i)
        
        return result
    
    @staticmethod
    def next_smaller_element(arr: List[int]) -> List[int]:
        """
        Find next smaller element for each element in array.
        
        Args:
            arr: Input array
            
        Returns:
            Array where result[i] is next smaller element for arr[i]
            Returns -1 if no smaller element exists
            
        Time Complexity: O(n)
        Space Complexity: O(n)
        """
        n = len(arr)
        result = [-1] * n
        stack = []  # Stack stores indices
        
        for i in range(n):
            while stack and arr[i] < arr[stack[-1]]:
                result[stack.pop()] = arr[i]
            stack.append(i)
        
        return result
    
    @staticmethod
    def daily_temperatures(temperatures: List[int]) -> List[int]:
        """
        Find number of days to wait for warmer temperature.
        
        Args:
            temperatures: Daily temperatures
            
        Returns:
            Array where result[i] is days to wait for warmer temperature
            
        Time Complexity: O(n)
        Space Complexity: O(n)
        """
        n = len(temperatures)
        result = [0] * n
        stack = []  # Stack stores indices
        
        for i in range(n):
            while stack and temperatures[i] > temperatures[stack[-1]]:
                idx = stack.pop()
                result[idx] = i - idx
            stack.append(i)
        
        return result