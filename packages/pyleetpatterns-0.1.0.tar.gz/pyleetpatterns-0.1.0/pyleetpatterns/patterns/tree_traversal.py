"""Binary Tree Traversal pattern implementation."""

from typing import List, Optional
from collections import deque
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import TreeNode


class TreeTraversal:
    """
    Binary Tree Traversal patterns for different processing orders.
    Key insights:
    - PreOrder (root→left→right): Tree serialization/copying
    - InOrder (left→root→right): BST sorted values
    - PostOrder (left→right→root): Tree deletion, size calculation
    - LevelOrder: Level-by-level processing, finding width
    """
    
    @staticmethod
    def preorder(root: Optional[TreeNode]) -> List[int]:
        """
        PreOrder traversal: root → left → right.
        Use for: Tree serialization, creating copies.
        
        Time Complexity: O(n)
        Space Complexity: O(h) where h is height
        """
        result = []
        
        def traverse(node):
            if not node:
                return
            result.append(node.val)
            traverse(node.left)
            traverse(node.right)
        
        traverse(root)
        return result
    
    @staticmethod
    def inorder(root: Optional[TreeNode]) -> List[int]:
        """
        InOrder traversal: left → root → right.
        Use for: Getting sorted values from BST.
        
        Time Complexity: O(n)
        Space Complexity: O(h) where h is height
        """
        result = []
        
        def traverse(node):
            if not node:
                return
            traverse(node.left)
            result.append(node.val)
            traverse(node.right)
        
        traverse(root)
        return result
    
    @staticmethod
    def postorder(root: Optional[TreeNode]) -> List[int]:
        """
        PostOrder traversal: left → right → root.
        Use for: Tree deletion, calculating sizes/heights.
        
        Time Complexity: O(n)
        Space Complexity: O(h) where h is height
        """
        result = []
        
        def traverse(node):
            if not node:
                return
            traverse(node.left)
            traverse(node.right)
            result.append(node.val)
        
        traverse(root)
        return result
    
    @staticmethod
    def levelorder(root: Optional[TreeNode]) -> List[List[int]]:
        """
        Level-order traversal using BFS.
        Use for: Level-by-level processing, finding tree width.
        
        Time Complexity: O(n)
        Space Complexity: O(w) where w is max width
        """
        if not root:
            return []
        
        result = []
        queue = deque([root])
        
        while queue:
            level_size = len(queue)
            current_level = []
            
            for _ in range(level_size):
                node = queue.popleft()
                current_level.append(node.val)
                
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            
            result.append(current_level)
        
        return result
    
    @staticmethod
    def binary_tree_paths(root: Optional[TreeNode]) -> List[str]:
        """
        Find all root-to-leaf paths.
        
        Time Complexity: O(n)
        Space Complexity: O(n)
        """
        if not root:
            return []
        
        result = []
        
        def dfs(node, path):
            if not node.left and not node.right:
                result.append(path + str(node.val))
                return
            
            if node.left:
                dfs(node.left, path + str(node.val) + "->")
            if node.right:
                dfs(node.right, path + str(node.val) + "->")
        
        dfs(root, "")
        return result