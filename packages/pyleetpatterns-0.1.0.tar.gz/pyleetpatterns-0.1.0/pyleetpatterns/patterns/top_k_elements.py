"""Top K Elements pattern implementation."""

from typing import List
import heapq
from collections import Counter


class TopKElements:
    """
    Top K Elements pattern using heaps and quickselect.
    Key insight: Use min-heap for K largest, max-heap for K smallest.
    """
    
    @staticmethod
    def kth_largest(nums: List[int], k: int) -> int:
        """
        Find the kth largest element using min-heap.
        
        Args:
            nums: Input array
            k: The k value
            
        Returns:
            The kth largest element
            
        Time Complexity: O(n log k)
        Space Complexity: O(k)
        """
        # Use min heap of size k
        heap = nums[:k]
        heapq.heapify(heap)
        
        for num in nums[k:]:
            if num > heap[0]:
                heapq.heapreplace(heap, num)
        
        return heap[0]
    
    @staticmethod
    def kth_largest_quickselect(nums: List[int], k: int) -> int:
        """
        Find the kth largest element using quickselect.
        
        Args:
            nums: Input array
            k: The k value
            
        Returns:
            The kth largest element
            
        Time Complexity: O(n) average, O(n²) worst
        Space Complexity: O(1)
        """
        def partition(left: int, right: int, pivot_index: int) -> int:
            pivot = nums[pivot_index]
            # Move pivot to end
            nums[pivot_index], nums[right] = nums[right], nums[pivot_index]
            
            # Move all smaller elements to the left
            store_index = left
            for i in range(left, right):
                if nums[i] < pivot:
                    nums[store_index], nums[i] = nums[i], nums[store_index]
                    store_index += 1
            
            # Move pivot to its final place
            nums[right], nums[store_index] = nums[store_index], nums[right]
            return store_index
        
        def select(left: int, right: int, k_smallest: int) -> int:
            if left == right:
                return nums[left]
            
            # Select random pivot
            pivot_index = left + (right - left) // 2
            pivot_index = partition(left, right, pivot_index)
            
            if k_smallest == pivot_index:
                return nums[k_smallest]
            elif k_smallest < pivot_index:
                return select(left, pivot_index - 1, k_smallest)
            else:
                return select(pivot_index + 1, right, k_smallest)
        
        n = len(nums)
        return select(0, n - 1, n - k)
    
    @staticmethod
    def top_k_frequent(nums: List[int], k: int) -> List[int]:
        """
        Find k most frequent elements.
        
        Args:
            nums: Input array
            k: Number of most frequent elements to find
            
        Returns:
            List of k most frequent elements
            
        Time Complexity: O(n log k)
        Space Complexity: O(n)
        """
        count = Counter(nums)
        # Use min heap to keep k most frequent
        heap = []
        
        for num, freq in count.items():
            heapq.heappush(heap, (freq, num))
            if len(heap) > k:
                heapq.heappop(heap)
        
        return [num for freq, num in heap]