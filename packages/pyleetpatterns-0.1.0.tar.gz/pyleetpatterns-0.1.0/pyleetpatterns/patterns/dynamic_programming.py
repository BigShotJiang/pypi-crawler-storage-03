"""Dynamic Programming Pattern for optimization problems."""

from typing import List


class DynamicProgramming:
    """
    Dynamic Programming pattern for optimization problems.
    Key insight: Overlapping subproblems + optimal substructure = DP
    """

    @staticmethod
    def climbing_stairs(n: int) -> int:
        """
        Find number of ways to climb n stairs (1 or 2 steps at a time).

        Time Complexity: O(n)
        Space Complexity: O(1)
        """
        if n <= 2:
            return n

        prev2, prev1 = 1, 2
        for i in range(3, n + 1):
            curr = prev1 + prev2
            prev2, prev1 = prev1, curr

        return prev1

    @staticmethod
    def coin_change(coins: List[int], amount: int) -> int:
        """
        Find minimum coins needed to make amount.

        Time Complexity: O(amount * len(coins))
        Space Complexity: O(amount)
        """
        dp = [float('inf')] * (amount + 1)
        dp[0] = 0

        for coin in coins:
            for i in range(coin, amount + 1):
                dp[i] = min(dp[i], dp[i - coin] + 1)

        return dp[amount] if dp[amount] != float('inf') else -1

    @staticmethod
    def longest_increasing_subsequence(nums: List[int]) -> int:
        """
        Find length of longest strictly increasing subsequence.

        Time Complexity: O(n²)
        Space Complexity: O(n)
        """
        if not nums:
            return 0

        dp = [1] * len(nums)

        for i in range(1, len(nums)):
            for j in range(i):
                if nums[j] < nums[i]:
                    dp[i] = max(dp[i], dp[j] + 1)

        return max(dp)

    @staticmethod
    def longest_common_subsequence(text1: str, text2: str) -> int:
        """
        Find length of longest common subsequence between two strings.

        Time Complexity: O(m*n)
        Space Complexity: O(m*n)
        """
        m, n = len(text1), len(text2)
        dp = [[0] * (n + 1) for _ in range(m + 1)]

        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if text1[i-1] == text2[j-1]:
                    dp[i][j] = dp[i-1][j-1] + 1
                else:
                    dp[i][j] = max(dp[i-1][j], dp[i][j-1])

        return dp[m][n]

    @staticmethod
    def knapsack_01(weights: List[int], values: List[int], capacity: int) -> int:
        """
        0/1 Knapsack problem - maximize value within weight capacity.

        Time Complexity: O(n * capacity)
        Space Complexity: O(n * capacity)
        """
        n = len(weights)
        dp = [[0] * (capacity + 1) for _ in range(n + 1)]

        for i in range(1, n + 1):
            for w in range(capacity + 1):
                if weights[i-1] <= w:
                    dp[i][w] = max(
                        dp[i-1][w],  # Don't take item
                        dp[i-1][w - weights[i-1]] + values[i-1]  # Take item
                    )
                else:
                    dp[i][w] = dp[i-1][w]

        return dp[n][capacity]