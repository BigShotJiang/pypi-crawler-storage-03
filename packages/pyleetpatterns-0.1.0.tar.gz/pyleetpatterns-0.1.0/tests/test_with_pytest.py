"""Pytest tests for PyLeetPatterns - Professional testing with pytest framework."""

import sys
import os
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pyleetpatterns import (
    PrefixSum, TwoPointers, SlidingWindow, FastSlowPointers,
    LinkedListReversal, MonotonicStack, TopKElements, OverlappingIntervals,
    ModifiedBinarySearch, TreeTraversal, GraphTraversal,
    ListNode, TreeNode
)


# Helper functions
def create_linked_list(values):
    """Helper to create linked list from values."""
    if not values:
        return None
    head = ListNode(values[0])
    current = head
    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next
    return head


def linked_list_to_list(head):
    """Helper to convert linked list to Python list."""
    result = []
    current = head
    seen = set()
    while current:
        if id(current) in seen:
            break
        seen.add(id(current))
        result.append(current.val)
        current = current.next
    return result


def create_binary_tree():
    """Helper to create a sample binary tree."""
    root = TreeNode(7)
    root.left = TreeNode(9)
    root.right = TreeNode(11)
    root.left.left = TreeNode(13)
    root.left.right = TreeNode(15)
    return root


class TestPrefixSum:
    """Test cases for PrefixSum pattern."""
    
    def test_basic_range_sum(self):
        ps = PrefixSum([1, 2, 3, 4, 5, 6, 7])
        assert ps.range_sum(2, 5) == 18
        assert ps.range_sum(0, 2) == 6
        assert ps.range_sum(0, 6) == 28
    
    def test_single_element(self):
        ps = PrefixSum([5])
        assert ps.range_sum(0, 0) == 5
    
    def test_negative_numbers(self):
        ps = PrefixSum([-1, -2, -3, 4, 5])
        assert ps.range_sum(0, 2) == -6
        assert ps.range_sum(3, 4) == 9


class TestTwoPointers:
    """Test cases for TwoPointers pattern."""
    
    def test_two_sum_sorted(self):
        nums = [1, 2, 3, 4, 5, 6, 7]
        assert TwoPointers.two_sum_sorted(nums, 9) == (1, 6)
        assert TwoPointers.two_sum_sorted(nums, 3) == (0, 1)
        assert TwoPointers.two_sum_sorted(nums, 100) == (-1, -1)
    
    def test_palindrome(self):
        assert TwoPointers.is_palindrome("racecar") == True
        assert TwoPointers.is_palindrome("hello") == False
        assert TwoPointers.is_palindrome("a") == True
        assert TwoPointers.is_palindrome("") == True


class TestSlidingWindow:
    """Test cases for SlidingWindow pattern."""
    
    def test_max_subarray_sum(self):
        arr = [3, 2, 7, 5, 9, 6, 2]
        max_sum, subarray = SlidingWindow.max_subarray_sum(arr, 3)
        assert max_sum == 21
        assert subarray == [7, 5, 9]
    
    def test_max_subarray_edge_cases(self):
        assert SlidingWindow.max_subarray_sum([], 1) == (0, [])
        assert SlidingWindow.max_subarray_sum([5], 1) == (5, [5])
    
    def test_longest_substring(self):
        assert SlidingWindow.longest_substring_without_repeating("abcabcbb") == 3
        assert SlidingWindow.longest_substring_without_repeating("bbbbb") == 1
        assert SlidingWindow.longest_substring_without_repeating("") == 0


class TestFastSlowPointers:
    """Test cases for FastSlowPointers pattern."""
    
    def test_cycle_detection(self):
        head = create_linked_list([1, 2, 3, 4, 5])
        assert FastSlowPointers.has_cycle(head) == False
        
        # Create cycle
        nodes = [ListNode(i) for i in [1, 2, 3, 4, 5]]
        for i in range(len(nodes) - 1):
            nodes[i].next = nodes[i + 1]
        nodes[-1].next = nodes[2]
        assert FastSlowPointers.has_cycle(nodes[0]) == True
    
    def test_find_middle(self):
        head = create_linked_list([1, 2, 3, 4, 5])
        assert FastSlowPointers.find_middle(head).val == 3
        
        head = create_linked_list([1, 2, 3, 4, 5, 6])
        assert FastSlowPointers.find_middle(head).val == 3


class TestLinkedListReversal:
    """Test cases for LinkedListReversal pattern."""
    
    def test_reverse_entire_list(self):
        head = create_linked_list([1, 2, 3, 4, 5])
        reversed_head = LinkedListReversal.reverse_linked_list(head)
        assert linked_list_to_list(reversed_head) == [5, 4, 3, 2, 1]
    
    def test_reverse_between(self):
        head = create_linked_list([1, 2, 3, 4, 5])
        result = LinkedListReversal.reverse_between(head, 2, 4)
        assert linked_list_to_list(result) == [1, 4, 3, 2, 5]
    
    def test_swap_pairs(self):
        head = create_linked_list([1, 2, 3, 4])
        swapped = LinkedListReversal.swap_pairs(head)
        assert linked_list_to_list(swapped) == [2, 1, 4, 3]


class TestMonotonicStack:
    """Test cases for MonotonicStack pattern."""
    
    def test_next_greater_element(self):
        arr = [1, 4, 6, 3, 2, 7]
        assert MonotonicStack.next_greater_element(arr) == [4, 6, 7, 7, 7, -1]
    
    def test_next_smaller_element(self):
        arr = [1, 4, 6, 3, 2, 7]
        assert MonotonicStack.next_smaller_element(arr) == [-1, 3, 3, 2, -1, -1]
    
    def test_daily_temperatures(self):
        temps = [73, 74, 75, 71, 69, 72, 76, 73]
        assert MonotonicStack.daily_temperatures(temps) == [1, 1, 4, 2, 1, 1, 0, 0]


class TestTopKElements:
    """Test cases for TopKElements pattern."""
    
    def test_kth_largest_heap(self):
        nums = [3, 2, 1, 5, 6, 4]
        assert TopKElements.kth_largest(nums, 2) == 5
    
    def test_kth_largest_quickselect(self):
        nums = [3, 2, 1, 5, 6, 4]
        assert TopKElements.kth_largest_quickselect(nums.copy(), 2) == 5
    
    def test_top_k_frequent(self):
        nums = [1, 1, 1, 2, 2, 3]
        frequent = TopKElements.top_k_frequent(nums, 2)
        assert set(frequent) == {1, 2}


class TestOverlappingIntervals:
    """Test cases for OverlappingIntervals pattern."""
    
    def test_merge_intervals(self):
        intervals = [[1, 3], [2, 6], [8, 10], [15, 18]]
        assert OverlappingIntervals.merge_intervals(intervals) == [[1, 6], [8, 10], [15, 18]]
    
    def test_insert_interval(self):
        existing = [[1, 3], [6, 9]]
        new = [2, 5]
        result = OverlappingIntervals.insert_interval(existing, new)
        assert result == [[1, 5], [6, 9]]
    
    def test_can_attend_meetings(self):
        meetings = [[0, 30], [5, 10], [15, 20]]
        assert OverlappingIntervals.can_attend_all_meetings(meetings) == False
        
        meetings = [[7, 10], [2, 4]]
        assert OverlappingIntervals.can_attend_all_meetings(meetings) == True


class TestModifiedBinarySearch:
    """Test cases for ModifiedBinarySearch pattern."""
    
    def test_search_rotated_array(self):
        rotated = [4, 5, 6, 7, 0, 1, 2]
        assert ModifiedBinarySearch.search_rotated_array(rotated, 0) == 4
        assert ModifiedBinarySearch.search_rotated_array(rotated, 3) == -1
    
    def test_find_minimum_rotated(self):
        assert ModifiedBinarySearch.find_minimum_rotated([4, 5, 6, 7, 0, 1, 2]) == 0
        assert ModifiedBinarySearch.find_minimum_rotated([3, 4, 5, 1, 2]) == 1
    
    def test_search_2d_matrix(self):
        matrix = [
            [1, 4, 7, 11],
            [2, 5, 8, 12],
            [3, 6, 9, 16]
        ]
        assert ModifiedBinarySearch.search_2d_matrix(matrix, 5) == True
        assert ModifiedBinarySearch.search_2d_matrix(matrix, 20) == False
    
    def test_find_first_last_position(self):
        sorted_arr = [5, 7, 7, 8, 8, 10]
        assert ModifiedBinarySearch.find_first_last_position(sorted_arr, 8) == [3, 4]
        assert ModifiedBinarySearch.find_first_last_position(sorted_arr, 6) == [-1, -1]


class TestTreeTraversal:
    """Test cases for TreeTraversal pattern."""
    
    def test_preorder(self):
        root = create_binary_tree()
        assert TreeTraversal.preorder(root) == [7, 9, 13, 15, 11]
    
    def test_inorder(self):
        root = create_binary_tree()
        assert TreeTraversal.inorder(root) == [13, 9, 15, 7, 11]
    
    def test_postorder(self):
        root = create_binary_tree()
        assert TreeTraversal.postorder(root) == [13, 15, 9, 11, 7]
    
    def test_levelorder(self):
        root = create_binary_tree()
        assert TreeTraversal.levelorder(root) == [[7], [9, 11], [13, 15]]
    
    def test_binary_tree_paths(self):
        root = create_binary_tree()
        paths = TreeTraversal.binary_tree_paths(root)
        assert set(paths) == {'7->9->13', '7->9->15', '7->11'}


class TestGraphTraversal:
    """Test cases for GraphTraversal pattern."""
    
    def test_cycle_detection(self):
        edges = [[0, 1], [1, 2], [2, 0]]
        assert GraphTraversal.has_cycle_directed(3, edges) == True
        
        edges = [[0, 1], [1, 2]]
        assert GraphTraversal.has_cycle_directed(3, edges) == False
    
    def test_bfs_path_finding(self):
        graph = {
            0: [1, 2],
            1: [3],
            2: [3],
            3: [4],
            4: []
        }
        path = GraphTraversal.find_path_bfs(graph, 0, 4)
        assert path in [[0, 1, 3, 4], [0, 2, 3, 4]]
    
    def test_dfs_all_paths(self):
        graph = {
            0: [1, 2],
            1: [3],
            2: [3],
            3: []
        }
        all_paths = GraphTraversal.dfs_all_paths(graph, 0, 3)
        assert len(all_paths) == 2
        assert [0, 1, 3] in all_paths
        assert [0, 2, 3] in all_paths
    
    def test_connected_components(self):
        edges = [[0, 1], [1, 2], [3, 4]]
        assert GraphTraversal.connected_components(5, edges) == 2
        
        edges = [[0, 1], [2, 3], [1, 2]]
        assert GraphTraversal.connected_components(4, edges) == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])