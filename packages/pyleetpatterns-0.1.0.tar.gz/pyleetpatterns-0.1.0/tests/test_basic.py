"""Basic tests for PyLeetPatterns package."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pyleetpatterns import (
    PrefixSum, TwoPointers, SlidingWindow, MonotonicStack,
    TopKElements, OverlappingIntervals, ModifiedBinarySearch,
    ListNode, TreeNode
)


def test_prefix_sum():
    """Test PrefixSum pattern."""
    nums = [1, 2, 3, 4, 5, 6, 7]
    ps = PrefixSum(nums)
    assert ps.range_sum(2, 5) == 18  # 3 + 4 + 5 + 6 = 18
    assert ps.range_sum(0, 2) == 6   # 1 + 2 + 3 = 6
    print("✓ PrefixSum tests passed")


def test_two_pointers():
    """Test TwoPointers pattern."""
    # Test two sum
    sorted_nums = [1, 2, 3, 4, 5, 6, 7]
    indices = TwoPointers.two_sum_sorted(sorted_nums, 9)
    assert indices == (1, 6)  # 2 + 7 = 9
    
    # Test palindrome
    assert TwoPointers.is_palindrome("racecar") == True
    assert TwoPointers.is_palindrome("hello") == False
    print("✓ TwoPointers tests passed")


def test_sliding_window():
    """Test SlidingWindow pattern."""
    arr = [3, 2, 7, 5, 9, 6, 2]
    max_sum, subarray = SlidingWindow.max_subarray_sum(arr, 3)
    assert max_sum == 21
    assert subarray == [7, 5, 9]
    
    # Test longest substring
    s = "abcabcbb"
    length = SlidingWindow.longest_substring_without_repeating(s)
    assert length == 3  # "abc"
    print("✓ SlidingWindow tests passed")


def test_monotonic_stack():
    """Test MonotonicStack pattern."""
    arr = [1, 4, 6, 3, 2, 7]
    next_greater = MonotonicStack.next_greater_element(arr)
    assert next_greater == [4, 6, 7, 7, 7, -1]
    
    temps = [73, 74, 75, 71, 69, 72, 76, 73]
    days = MonotonicStack.daily_temperatures(temps)
    assert days == [1, 1, 4, 2, 1, 1, 0, 0]
    print("✓ MonotonicStack tests passed")


def test_top_k_elements():
    """Test TopKElements pattern."""
    nums = [3, 2, 1, 5, 6, 4]
    k = 2
    kth = TopKElements.kth_largest(nums, k)
    assert kth == 5
    
    # Test top k frequent
    nums = [1, 1, 1, 2, 2, 3]
    k = 2
    frequent = TopKElements.top_k_frequent(nums, k)
    assert set(frequent) == {1, 2}
    print("✓ TopKElements tests passed")


def test_overlapping_intervals():
    """Test OverlappingIntervals pattern."""
    intervals = [[1, 3], [2, 6], [8, 10], [15, 18]]
    merged = OverlappingIntervals.merge_intervals(intervals)
    assert merged == [[1, 6], [8, 10], [15, 18]]
    
    meetings = [[0, 30], [5, 10], [15, 20]]
    can_attend = OverlappingIntervals.can_attend_all_meetings(meetings)
    assert can_attend == False
    print("✓ OverlappingIntervals tests passed")


def test_modified_binary_search():
    """Test ModifiedBinarySearch pattern."""
    rotated = [4, 5, 6, 7, 0, 1, 2]
    index = ModifiedBinarySearch.search_rotated_array(rotated, 0)
    assert index == 4
    
    min_val = ModifiedBinarySearch.find_minimum_rotated(rotated)
    assert min_val == 0
    
    sorted_arr = [5, 7, 7, 8, 8, 10]
    positions = ModifiedBinarySearch.find_first_last_position(sorted_arr, 8)
    assert positions == [3, 4]
    print("✓ ModifiedBinarySearch tests passed")


def run_all_tests():
    """Run all tests."""
    print("Running PyLeetPatterns tests...")
    print("-" * 40)
    
    test_prefix_sum()
    test_two_pointers()
    test_sliding_window()
    test_monotonic_stack()
    test_top_k_elements()
    test_overlapping_intervals()
    test_modified_binary_search()
    
    print("-" * 40)
    print("All tests passed! ✨")


if __name__ == "__main__":
    run_all_tests()