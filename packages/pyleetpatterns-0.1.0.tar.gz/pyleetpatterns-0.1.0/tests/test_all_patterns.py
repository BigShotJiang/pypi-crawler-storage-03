"""Comprehensive tests for all PyLeetPatterns implementations."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pyleetpatterns import (
    PrefixSum, TwoPointers, SlidingWindow, FastSlowPointers,
    LinkedListReversal, MonotonicStack, TopKElements, OverlappingIntervals,
    ModifiedBinarySearch, TreeTraversal, GraphTraversal,
    MatrixTraversal, DynamicProgramming, Backtracking,
    ListNode, TreeNode
)


def create_linked_list(values):
    """Helper to create linked list from values."""
    if not values:
        return None
    head = ListNode(values[0])
    current = head
    for val in values[1:]:
        current.next = ListNode(val)
        current = current.next
    return head


def linked_list_to_list(head):
    """Helper to convert linked list to Python list."""
    result = []
    current = head
    seen = set()
    while current:
        if id(current) in seen:
            break
        seen.add(id(current))
        result.append(current.val)
        current = current.next
    return result


def create_binary_tree():
    """Helper to create a sample binary tree."""
    root = TreeNode(7)
    root.left = TreeNode(9)
    root.right = TreeNode(11)
    root.left.left = TreeNode(13)
    root.left.right = TreeNode(15)
    return root


def test_prefix_sum():
    """Test PrefixSum pattern."""
    print("Testing PrefixSum...")
    
    # Basic test
    nums = [1, 2, 3, 4, 5, 6, 7]
    ps = PrefixSum(nums)
    assert ps.range_sum(2, 5) == 18  # 3 + 4 + 5 + 6 = 18
    assert ps.range_sum(0, 2) == 6   # 1 + 2 + 3 = 6
    assert ps.range_sum(0, 6) == 28  # Sum of all elements
    assert ps.range_sum(3, 3) == 4   # Single element
    
    # Edge cases
    ps_single = PrefixSum([5])
    assert ps_single.range_sum(0, 0) == 5
    
    ps_negative = PrefixSum([-1, -2, -3, 4, 5])
    assert ps_negative.range_sum(0, 2) == -6
    assert ps_negative.range_sum(3, 4) == 9
    
    print("✓ PrefixSum tests passed")


def test_two_pointers():
    """Test TwoPointers pattern."""
    print("Testing TwoPointers...")
    
    # Two sum sorted
    sorted_nums = [1, 2, 3, 4, 5, 6, 7]
    assert TwoPointers.two_sum_sorted(sorted_nums, 9) == (1, 6)  # 2 + 7 = 9
    assert TwoPointers.two_sum_sorted(sorted_nums, 3) == (0, 1)  # 1 + 2 = 3
    assert TwoPointers.two_sum_sorted(sorted_nums, 100) == (-1, -1)  # No solution
    assert TwoPointers.two_sum_sorted([1, 1, 2, 3], 2) == (0, 1)  # Duplicates
    
    # Palindrome
    assert TwoPointers.is_palindrome("racecar") == True
    assert TwoPointers.is_palindrome("hello") == False
    assert TwoPointers.is_palindrome("a") == True
    assert TwoPointers.is_palindrome("") == True
    assert TwoPointers.is_palindrome("ab") == False
    assert TwoPointers.is_palindrome("aa") == True
    
    print("✓ TwoPointers tests passed")


def test_sliding_window():
    """Test SlidingWindow pattern."""
    print("Testing SlidingWindow...")
    
    # Max subarray sum
    arr = [3, 2, 7, 5, 9, 6, 2]
    max_sum, subarray = SlidingWindow.max_subarray_sum(arr, 3)
    assert max_sum == 21
    assert subarray == [7, 5, 9]
    
    # Edge cases
    assert SlidingWindow.max_subarray_sum([], 1) == (0, [])
    assert SlidingWindow.max_subarray_sum([1, 2, 3], 5) == (0, [])
    assert SlidingWindow.max_subarray_sum([5], 1) == (5, [5])
    
    # Longest substring without repeating
    assert SlidingWindow.longest_substring_without_repeating("abcabcbb") == 3  # "abc"
    assert SlidingWindow.longest_substring_without_repeating("bbbbb") == 1     # "b"
    assert SlidingWindow.longest_substring_without_repeating("pwwkew") == 3    # "wke"
    assert SlidingWindow.longest_substring_without_repeating("") == 0
    assert SlidingWindow.longest_substring_without_repeating("abcdef") == 6
    
    print("✓ SlidingWindow tests passed")


def test_fast_slow_pointers():
    """Test FastSlowPointers pattern."""
    print("Testing FastSlowPointers...")
    
    # Test cycle detection
    head = create_linked_list([1, 2, 3, 4, 5])
    assert FastSlowPointers.has_cycle(head) == False
    
    # Create cycle
    nodes = []
    for i in [1, 2, 3, 4, 5]:
        nodes.append(ListNode(i))
    for i in range(len(nodes) - 1):
        nodes[i].next = nodes[i + 1]
    nodes[-1].next = nodes[2]  # Create cycle at node 3
    assert FastSlowPointers.has_cycle(nodes[0]) == True
    
    # Edge cases
    assert FastSlowPointers.has_cycle(None) == False
    assert FastSlowPointers.has_cycle(ListNode(1)) == False
    
    # Test find middle
    head = create_linked_list([1, 2, 3, 4, 5])
    middle = FastSlowPointers.find_middle(head)
    assert middle.val == 3
    
    head = create_linked_list([1, 2, 3, 4, 5, 6])
    middle = FastSlowPointers.find_middle(head)
    assert middle.val == 3
    
    head = create_linked_list([1])
    middle = FastSlowPointers.find_middle(head)
    assert middle.val == 1
    
    assert FastSlowPointers.find_middle(None) == None
    
    print("✓ FastSlowPointers tests passed")


def test_linked_list_reversal():
    """Test LinkedListReversal pattern."""
    print("Testing LinkedListReversal...")
    
    # Test reverse entire list
    head = create_linked_list([1, 2, 3, 4, 5])
    reversed_head = LinkedListReversal.reverse_linked_list(head)
    assert linked_list_to_list(reversed_head) == [5, 4, 3, 2, 1]
    
    # Edge cases
    assert LinkedListReversal.reverse_linked_list(None) == None
    single = ListNode(1)
    assert LinkedListReversal.reverse_linked_list(single).val == 1
    
    # Test reverse between
    head = create_linked_list([1, 2, 3, 4, 5])
    result = LinkedListReversal.reverse_between(head, 2, 4)
    assert linked_list_to_list(result) == [1, 4, 3, 2, 5]
    
    head = create_linked_list([1, 2, 3, 4, 5])
    result = LinkedListReversal.reverse_between(head, 1, 5)
    assert linked_list_to_list(result) == [5, 4, 3, 2, 1]
    
    head = create_linked_list([1, 2])
    result = LinkedListReversal.reverse_between(head, 1, 2)
    assert linked_list_to_list(result) == [2, 1]
    
    # Test swap pairs
    head = create_linked_list([1, 2, 3, 4])
    swapped = LinkedListReversal.swap_pairs(head)
    assert linked_list_to_list(swapped) == [2, 1, 4, 3]
    
    head = create_linked_list([1, 2, 3])
    swapped = LinkedListReversal.swap_pairs(head)
    assert linked_list_to_list(swapped) == [2, 1, 3]
    
    head = create_linked_list([1])
    swapped = LinkedListReversal.swap_pairs(head)
    assert linked_list_to_list(swapped) == [1]
    
    assert LinkedListReversal.swap_pairs(None) == None
    
    print("✓ LinkedListReversal tests passed")


def test_monotonic_stack():
    """Test MonotonicStack pattern."""
    print("Testing MonotonicStack...")
    
    # Next greater element
    arr = [1, 4, 6, 3, 2, 7]
    next_greater = MonotonicStack.next_greater_element(arr)
    assert next_greater == [4, 6, 7, 7, 7, -1]
    
    assert MonotonicStack.next_greater_element([5, 4, 3, 2, 1]) == [-1, -1, -1, -1, -1]
    assert MonotonicStack.next_greater_element([1, 2, 3, 4, 5]) == [2, 3, 4, 5, -1]
    assert MonotonicStack.next_greater_element([]) == []
    
    # Next smaller element
    arr = [1, 4, 6, 3, 2, 7]
    next_smaller = MonotonicStack.next_smaller_element(arr)
    assert next_smaller == [-1, 3, 3, 2, -1, -1]
    
    assert MonotonicStack.next_smaller_element([5, 4, 3, 2, 1]) == [4, 3, 2, 1, -1]
    assert MonotonicStack.next_smaller_element([1, 2, 3, 4, 5]) == [-1, -1, -1, -1, -1]
    
    # Daily temperatures
    temps = [73, 74, 75, 71, 69, 72, 76, 73]
    days = MonotonicStack.daily_temperatures(temps)
    assert days == [1, 1, 4, 2, 1, 1, 0, 0]
    
    assert MonotonicStack.daily_temperatures([30, 40, 50, 60]) == [1, 1, 1, 0]
    assert MonotonicStack.daily_temperatures([30, 60, 90]) == [1, 1, 0]
    assert MonotonicStack.daily_temperatures([]) == []
    
    print("✓ MonotonicStack tests passed")


def test_top_k_elements():
    """Test TopKElements pattern."""
    print("Testing TopKElements...")
    
    # Kth largest using heap
    nums = [3, 2, 1, 5, 6, 4]
    assert TopKElements.kth_largest(nums, 2) == 5
    assert TopKElements.kth_largest([1], 1) == 1
    assert TopKElements.kth_largest([3, 2, 3, 1, 2, 4, 5, 5, 6], 4) == 4
    
    # Kth largest using quickselect
    nums = [3, 2, 1, 5, 6, 4]
    assert TopKElements.kth_largest_quickselect(nums.copy(), 2) == 5
    assert TopKElements.kth_largest_quickselect([1], 1) == 1
    assert TopKElements.kth_largest_quickselect([3, 2, 3, 1, 2, 4, 5, 5, 6], 4) == 4
    
    # Top k frequent
    nums = [1, 1, 1, 2, 2, 3]
    frequent = TopKElements.top_k_frequent(nums, 2)
    assert set(frequent) == {1, 2} or set(frequent) == {2, 1}
    
    nums = [1]
    assert TopKElements.top_k_frequent(nums, 1) == [1]
    
    nums = [4, 1, -1, 2, -1, 2, 3]
    frequent = TopKElements.top_k_frequent(nums, 2)
    assert set(frequent) == {-1, 2}
    
    print("✓ TopKElements tests passed")


def test_overlapping_intervals():
    """Test OverlappingIntervals pattern."""
    print("Testing OverlappingIntervals...")
    
    # Merge intervals
    intervals = [[1, 3], [2, 6], [8, 10], [15, 18]]
    merged = OverlappingIntervals.merge_intervals(intervals)
    assert merged == [[1, 6], [8, 10], [15, 18]]
    
    assert OverlappingIntervals.merge_intervals([[1, 4], [4, 5]]) == [[1, 5]]
    assert OverlappingIntervals.merge_intervals([[1, 4], [2, 3]]) == [[1, 4]]
    assert OverlappingIntervals.merge_intervals([[1, 4]]) == [[1, 4]]
    assert OverlappingIntervals.merge_intervals([]) == []
    
    # Insert interval
    existing = [[1, 3], [6, 9]]
    new = [2, 5]
    result = OverlappingIntervals.insert_interval(existing, new)
    assert result == [[1, 5], [6, 9]]
    
    existing = [[1, 2], [3, 5], [6, 7], [8, 10], [12, 16]]
    new = [4, 8]
    result = OverlappingIntervals.insert_interval(existing, new)
    assert result == [[1, 2], [3, 10], [12, 16]]
    
    assert OverlappingIntervals.insert_interval([], [5, 7]) == [[5, 7]]
    
    # Can attend all meetings
    meetings = [[0, 30], [5, 10], [15, 20]]
    assert OverlappingIntervals.can_attend_all_meetings(meetings) == False
    
    meetings = [[7, 10], [2, 4]]
    assert OverlappingIntervals.can_attend_all_meetings(meetings) == True
    
    assert OverlappingIntervals.can_attend_all_meetings([]) == True
    assert OverlappingIntervals.can_attend_all_meetings([[1, 2]]) == True
    
    print("✓ OverlappingIntervals tests passed")


def test_modified_binary_search():
    """Test ModifiedBinarySearch pattern."""
    print("Testing ModifiedBinarySearch...")
    
    # Search in rotated array
    rotated = [4, 5, 6, 7, 0, 1, 2]
    assert ModifiedBinarySearch.search_rotated_array(rotated, 0) == 4
    assert ModifiedBinarySearch.search_rotated_array(rotated, 3) == -1
    assert ModifiedBinarySearch.search_rotated_array([1], 1) == 0
    assert ModifiedBinarySearch.search_rotated_array([1], 0) == -1
    
    # Find minimum in rotated array
    assert ModifiedBinarySearch.find_minimum_rotated([4, 5, 6, 7, 0, 1, 2]) == 0
    assert ModifiedBinarySearch.find_minimum_rotated([3, 4, 5, 1, 2]) == 1
    assert ModifiedBinarySearch.find_minimum_rotated([1]) == 1
    assert ModifiedBinarySearch.find_minimum_rotated([2, 1]) == 1
    
    # Search in 2D matrix
    matrix = [
        [1, 4, 7, 11, 15],
        [2, 5, 8, 12, 19],
        [3, 6, 9, 16, 22],
        [10, 13, 14, 17, 24],
        [18, 21, 23, 26, 30]
    ]
    assert ModifiedBinarySearch.search_2d_matrix(matrix, 5) == True
    assert ModifiedBinarySearch.search_2d_matrix(matrix, 20) == False
    assert ModifiedBinarySearch.search_2d_matrix([[]], 1) == False
    assert ModifiedBinarySearch.search_2d_matrix([], 1) == False
    
    # Find first and last position
    sorted_arr = [5, 7, 7, 8, 8, 10]
    assert ModifiedBinarySearch.find_first_last_position(sorted_arr, 8) == [3, 4]
    assert ModifiedBinarySearch.find_first_last_position(sorted_arr, 6) == [-1, -1]
    assert ModifiedBinarySearch.find_first_last_position([], 0) == [-1, -1]
    assert ModifiedBinarySearch.find_first_last_position([1], 1) == [0, 0]
    
    print("✓ ModifiedBinarySearch tests passed")


def test_tree_traversal():
    """Test TreeTraversal pattern."""
    print("Testing TreeTraversal...")
    
    root = create_binary_tree()
    
    # Preorder: root -> left -> right
    assert TreeTraversal.preorder(root) == [7, 9, 13, 15, 11]
    
    # Inorder: left -> root -> right
    assert TreeTraversal.inorder(root) == [13, 9, 15, 7, 11]
    
    # Postorder: left -> right -> root
    assert TreeTraversal.postorder(root) == [13, 15, 9, 11, 7]
    
    # Level order
    assert TreeTraversal.levelorder(root) == [[7], [9, 11], [13, 15]]
    
    # Binary tree paths
    paths = TreeTraversal.binary_tree_paths(root)
    assert set(paths) == {'7->9->13', '7->9->15', '7->11'}
    
    # Edge cases
    assert TreeTraversal.preorder(None) == []
    assert TreeTraversal.inorder(None) == []
    assert TreeTraversal.postorder(None) == []
    assert TreeTraversal.levelorder(None) == []
    assert TreeTraversal.binary_tree_paths(None) == []
    
    # Single node
    single = TreeNode(42)
    assert TreeTraversal.preorder(single) == [42]
    assert TreeTraversal.inorder(single) == [42]
    assert TreeTraversal.postorder(single) == [42]
    assert TreeTraversal.levelorder(single) == [[42]]
    assert TreeTraversal.binary_tree_paths(single) == ['42']
    
    print("✓ TreeTraversal tests passed")


def test_graph_traversal():
    """Test GraphTraversal pattern."""
    print("Testing GraphTraversal...")
    
    # Test cycle detection in directed graph
    edges = [[0, 1], [1, 2], [2, 0]]  # Cycle: 0 -> 1 -> 2 -> 0
    assert GraphTraversal.has_cycle_directed(3, edges) == True
    
    edges = [[0, 1], [1, 2]]  # No cycle
    assert GraphTraversal.has_cycle_directed(3, edges) == False
    
    edges = [[0, 1], [0, 2], [1, 2]]  # No cycle
    assert GraphTraversal.has_cycle_directed(3, edges) == False
    
    # Test BFS path finding
    graph = {
        0: [1, 2],
        1: [3],
        2: [3],
        3: [4],
        4: []
    }
    path = GraphTraversal.find_path_bfs(graph, 0, 4)
    assert path == [0, 1, 3, 4] or path == [0, 2, 3, 4]
    
    assert GraphTraversal.find_path_bfs(graph, 0, 0) == [0]
    assert GraphTraversal.find_path_bfs(graph, 1, 2) == []  # No path
    
    # Test DFS all paths
    graph = {
        0: [1, 2],
        1: [3],
        2: [3],
        3: []
    }
    all_paths = GraphTraversal.dfs_all_paths(graph, 0, 3)
    assert len(all_paths) == 2
    assert [0, 1, 3] in all_paths
    assert [0, 2, 3] in all_paths
    
    # Test connected components
    edges = [[0, 1], [1, 2], [3, 4]]
    assert GraphTraversal.connected_components(5, edges) == 2
    
    edges = [[0, 1], [2, 3], [1, 2]]
    assert GraphTraversal.connected_components(4, edges) == 1
    
    edges = []
    assert GraphTraversal.connected_components(3, edges) == 3
    
    print("✓ GraphTraversal tests passed")


def test_matrix_traversal():
    """Test MatrixTraversal pattern."""
    print("Testing MatrixTraversal...")
    
    # Test flood fill
    image = [[1,1,1],[1,1,0],[1,0,1]]
    result = MatrixTraversal.flood_fill([row[:] for row in image], 1, 1, 2)
    assert result == [[2,2,2],[2,2,0],[2,0,1]]
    
    # Edge case: same color
    image = [[0,0,0],[0,0,0]]
    result = MatrixTraversal.flood_fill([row[:] for row in image], 0, 0, 0)
    assert result == [[0,0,0],[0,0,0]]
    
    # Test num islands
    grid = [
        ["1","1","0","0","0"],
        ["1","1","0","0","0"],
        ["0","0","1","0","0"],
        ["0","0","0","1","1"]
    ]
    # Make a deep copy since the function modifies the grid
    grid_copy = [row[:] for row in grid]
    assert MatrixTraversal.num_islands(grid_copy) == 3
    
    # Edge cases
    assert MatrixTraversal.num_islands([]) == 0
    assert MatrixTraversal.num_islands([["1"]]) == 1
    assert MatrixTraversal.num_islands([["0"]]) == 0
    
    # Test shortest path binary matrix
    grid = [[0,1],[1,0]]
    assert MatrixTraversal.shortest_path_binary_matrix(grid) == 2
    
    grid = [[0,0,0],[1,1,0],[1,1,0]]
    assert MatrixTraversal.shortest_path_binary_matrix(grid) == 4
    
    # No path
    grid = [[1,0,0],[1,1,0],[1,1,0]]
    assert MatrixTraversal.shortest_path_binary_matrix(grid) == -1
    
    # Single cell
    assert MatrixTraversal.shortest_path_binary_matrix([[0]]) == 1
    
    print("✓ MatrixTraversal tests passed")


def test_dynamic_programming():
    """Test DynamicProgramming pattern."""
    print("Testing DynamicProgramming...")
    
    # Test climbing stairs
    assert DynamicProgramming.climbing_stairs(2) == 2
    assert DynamicProgramming.climbing_stairs(3) == 3
    assert DynamicProgramming.climbing_stairs(5) == 8
    assert DynamicProgramming.climbing_stairs(1) == 1
    
    # Test coin change
    assert DynamicProgramming.coin_change([1, 2, 5], 11) == 3  # 5 + 5 + 1
    assert DynamicProgramming.coin_change([2], 3) == -1  # No solution
    assert DynamicProgramming.coin_change([1], 0) == 0
    assert DynamicProgramming.coin_change([1, 3, 4], 6) == 2  # 3 + 3
    
    # Test longest increasing subsequence
    assert DynamicProgramming.longest_increasing_subsequence([10,9,2,5,3,7,101,18]) == 4
    assert DynamicProgramming.longest_increasing_subsequence([0,1,0,3,2,3]) == 4
    assert DynamicProgramming.longest_increasing_subsequence([7,7,7,7,7,7,7]) == 1
    assert DynamicProgramming.longest_increasing_subsequence([]) == 0
    assert DynamicProgramming.longest_increasing_subsequence([1]) == 1
    
    # Test longest common subsequence
    assert DynamicProgramming.longest_common_subsequence("abcde", "ace") == 3
    assert DynamicProgramming.longest_common_subsequence("abc", "abc") == 3
    assert DynamicProgramming.longest_common_subsequence("abc", "def") == 0
    assert DynamicProgramming.longest_common_subsequence("", "abc") == 0
    
    # Test 0/1 knapsack
    weights = [1, 3, 4, 5]
    values = [1, 4, 5, 7]
    assert DynamicProgramming.knapsack_01(weights, values, 7) == 9  # items with weight 3 and 4
    
    weights = [1, 2, 3]
    values = [60, 100, 120]
    assert DynamicProgramming.knapsack_01(weights, values, 5) == 220  # items with weight 2 and 3
    
    print("✓ DynamicProgramming tests passed")


def test_backtracking():
    """Test Backtracking pattern."""
    print("Testing Backtracking...")
    
    # Test generate subsets
    subsets = Backtracking.generate_subsets([1, 2, 3])
    assert len(subsets) == 8  # 2^3
    assert [] in subsets
    assert [1, 2, 3] in subsets
    
    subsets = Backtracking.generate_subsets([])
    assert subsets == [[]]
    
    # Test generate permutations
    perms = Backtracking.generate_permutations([1, 2, 3])
    assert len(perms) == 6  # 3!
    assert [1, 2, 3] in perms
    assert [3, 2, 1] in perms
    
    perms = Backtracking.generate_permutations([1])
    assert perms == [[1]]
    
    # Test N-Queens
    solutions = Backtracking.solve_n_queens(4)
    assert len(solutions) == 2
    # Check one solution
    assert '.Q..' in solutions[0] or '..Q.' in solutions[0]
    
    solutions = Backtracking.solve_n_queens(1)
    assert solutions == [['Q']]
    
    # Test generate parentheses
    parens = Backtracking.generate_parentheses(3)
    assert len(parens) == 5
    assert "((()))" in parens
    assert "(()())" in parens
    assert "()()()" in parens
    
    parens = Backtracking.generate_parentheses(1)
    assert parens == ["()"]
    
    # Test word search
    board = [
        ["A","B","C","E"],
        ["S","F","C","S"],
        ["A","D","E","E"]
    ]
    assert Backtracking.word_search([row[:] for row in board], "ABCCED") == True
    assert Backtracking.word_search([row[:] for row in board], "SEE") == True
    assert Backtracking.word_search([row[:] for row in board], "ABCB") == False
    
    # Test combination sum
    candidates = [2, 3, 6, 7]
    combos = Backtracking.combination_sum(candidates, 7)
    assert len(combos) == 2
    assert [7] in combos
    assert [2, 2, 3] in combos
    
    candidates = [2, 3, 5]
    combos = Backtracking.combination_sum(candidates, 8)
    assert len(combos) == 3  # [2,2,2,2], [2,3,3], [3,5]
    
    print("✓ Backtracking tests passed")


def run_all_tests():
    """Run all comprehensive tests."""
    print("=" * 50)
    print("Running Comprehensive PyLeetPatterns Tests")
    print("=" * 50)
    
    test_prefix_sum()
    test_two_pointers()
    test_sliding_window()
    test_fast_slow_pointers()
    test_linked_list_reversal()
    test_monotonic_stack()
    test_top_k_elements()
    test_overlapping_intervals()
    test_modified_binary_search()
    test_tree_traversal()
    test_graph_traversal()
    test_matrix_traversal()
    test_dynamic_programming()
    test_backtracking()
    
    print("=" * 50)
    print("🎉 All comprehensive tests passed successfully!")
    print("=" * 50)


if __name__ == "__main__":
    run_all_tests()