::: any_guardrail.guardrails.shield_gemma.shield_gemma
