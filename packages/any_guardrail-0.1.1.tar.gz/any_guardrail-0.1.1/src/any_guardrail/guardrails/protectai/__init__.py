from .protectai import Protectai

__all__ = ["Protectai"]
