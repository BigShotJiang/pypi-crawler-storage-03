from enum import Enum


class Personality(Enum):
    PRUDENT = "prudent"
    INQUISITIVE = "inquisitive"
