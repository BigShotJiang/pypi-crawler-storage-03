from exifdata.framework import (
    Namespace,
    Groupspace,
    Structure,
    Type,
    Field,
    Value,
    Metadata,
)
