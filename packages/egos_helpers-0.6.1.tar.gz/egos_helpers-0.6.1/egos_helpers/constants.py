#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" Constants declarations """

# These get overwritten at build time. See build.sh
VERSION = '0.6.1'
BUILD = None
NAME = 'egos-helpers'
