#!/bin/bash
asv run --show-stderr >asv-run.log
asv publish
