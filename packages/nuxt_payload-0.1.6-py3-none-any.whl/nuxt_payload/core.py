import json

WRAPPERS = {"ShallowReactive", "Reactive", "Ref", "ShallowRef", "ComputedRef"}

class LazyRef:
    """Lazy proxy for a reference to a Nuxt payload entry (via the factory)."""
    def __init__(self, factory, idx):
        self._factory = factory
        self._idx = idx
        self._resolved = None

    def resolve(self, recursive: bool = False, _seen=None):
        if self._resolved is None:
            self._resolved = wrap(self._factory, self._factory.raw_payload[self._idx])

        if recursive:
            return LazyRef.deep_resolve(self._resolved, _seen=set() if _seen is None else _seen)
        return self._resolved

    @staticmethod
    def deep_resolve(value, _seen):
        if isinstance(value, LazyRef):
            key = (id(value._factory), value._idx)
            if key in _seen:
                return UnresolvableRef(value._factory, value._idx)
            _seen.add(key)
            return value.resolve(recursive=True, _seen=_seen)

        elif isinstance(value, dict):
            return {k: LazyRef.deep_resolve(v, _seen) for k, v in value.items()}

        elif isinstance(value, list):
            return [LazyRef.deep_resolve(v, _seen) for v in value]

        else:
            return value

    def __getitem__(self, key):
        return self.resolve()[key]

    def __getattr__(self, name):
        return getattr(self.resolve(), name)

    def __iter__(self):
        return iter(self.resolve())

    def __repr__(self):
        return f"<LazyRef idx={self._idx} resolved={self._resolved is not None}>"

    @property
    def value(self):
        return self._idx


def get_path(obj, path, default=None, resolve=False):
    parts = path.split(".") if isinstance(path, str) else path
    current = obj
    for key in parts:
        if isinstance(current, LazyRef):
            current = current.resolve()
        if isinstance(current, dict):
            current = current.get(key, default)
        elif isinstance(current, list) and isinstance(key, int):
            if 0 <= key < len(current):
                current = current[key]
            else:
                return default
        else:
            return default
    if resolve and isinstance(current, LazyRef):
        return current.resolve()
    else:
        return current


class UnresolvableRef(LazyRef):
    """Represents a circular reference that cannot be fully resolved."""
    def __init__(self, payload, idx: int):
        super().__init__(payload, idx)
        self._resolved = None

    def resolve(self, recursive: bool = False, _seen=None):
        return self  # Always return itself; cannot resolve further

    def __repr__(self):
        return f"<UnresolvableRef idx={self._idx}>"


def wrap(factory, value):
    if isinstance(value, int) and 0 <= value < len(factory.raw_payload):
        return LazyRef(factory, value)
    elif isinstance(value, list):
        if len(value) == 2 and isinstance(value[0], str) and value[0] in WRAPPERS:
            return wrap(factory, factory.raw_payload[value[1]])
        return [wrap(factory, v) for v in value]
    elif isinstance(value, dict):
        return {k: wrap(factory, v) for k, v in value.items()}
    return value


class PayloadFactory:
    def __init__(self, payload):
        self.raw_payload = payload   # keep raw json
        self.by_id = {}
        self.by_index = {}
        self._consolidate()

    def _consolidate(self):
        for idx, entry in enumerate(self.raw_payload):
            wrapped = wrap(self, entry)

            if isinstance(entry, dict) and "_id" in entry:
                obj_id = entry["_id"]
                if obj_id == 1587:
                    print("_id 1587 pour ", idx)

                if obj_id not in self.by_id:
                    # first time we see this object: store it as this
                    self.by_id[obj_id] = wrapped
                    if obj_id == 1587:
                        print("\non store direct", wrapped["content"].resolve(True) if "content" in wrapped else '..')
                else:
                    # Merge with existing version
                    existing = self.by_id[obj_id]
                    for k, v in wrapped.items():
                        if (
                            k not in existing
                            or existing[k] is None
                            or existing[k] == ""
                            or (isinstance(existing[k], dict) and not existing[k])
                            or (isinstance(existing[k], LazyRef) and (existing[k].resolve() is None or existing[k].resolve() == {}))
                        ):
                            if obj_id == 1587 and k == "content":
                                print("\non remplace", wrapped["content"].resolve(True) if "content" in wrapped else '..')
                            existing[k] = v

                # Indexed object is the consolidated one
                self.by_index[idx] = self.by_id[obj_id]

            else:
                # no id: no consolidation
                self.by_index[idx] = wrapped

    def get(self, obj_id, resolve=False):
        obj = self.by_id.get(obj_id)
        if resolve and obj is not None:
            return LazyRef.deep_resolve(obj, set())
        return obj

    def get_by_index(self, idx, resolve=False):
        obj = self.by_index.get(idx)
        if resolve and obj is not None:
            return LazyRef.deep_resolve(obj, set())
        return obj


def load_payload(path: str):
    """
    Load a Nuxt 3 _payload.json file into a lazy-resolving Python structure.

    Each entry in the payload is wrapped using `wrap`, so references and
    Vue/Nuxt wrappers are resolved on demand.
    """
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    factory = PayloadFactory(payload)
    return [wrap(factory, v) for v in payload]
