"""
Example of wrapping Fortran so it can be accessed via Python
"""

import importlib.metadata

__version__ = importlib.metadata.version("example_fgen_basic")
