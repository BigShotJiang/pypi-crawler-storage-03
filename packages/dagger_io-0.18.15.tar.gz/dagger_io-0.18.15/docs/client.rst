Client
======

Automatically generated client from Dagger API.

.. automodule:: dagger
   :members:
   :undoc-members:
