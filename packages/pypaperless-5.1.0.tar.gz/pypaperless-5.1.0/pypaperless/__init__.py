"""PyPaperless."""

from .api import Paperless

__all__ = ("Paperless",)
