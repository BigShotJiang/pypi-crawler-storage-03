"""Mixins for PyPaperless models."""
