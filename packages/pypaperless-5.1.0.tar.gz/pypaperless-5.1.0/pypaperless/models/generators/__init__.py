"""PyPaperless generators."""

from .page import PageGenerator

__all__ = ("PageGenerator",)
