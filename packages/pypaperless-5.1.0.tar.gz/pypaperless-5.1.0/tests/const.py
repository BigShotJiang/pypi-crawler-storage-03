"""Test constants."""

PAPERLESS_TEST_URL = "https://paperless.not-existing.internal"
PAPERLESS_TEST_TOKEN = "abcdef0123456789"
PAPERLESS_TEST_USER = "test-user"
PAPERLESS_TEST_PASSWORD = "not-so-secret-password"
PAPERLESS_TEST_REQ_ARGS = {"ssl": False}
