"""Remote version snapshot."""

DATA_REMOTE_VERSION = {"version": "v2.15.3", "update_available": True}
