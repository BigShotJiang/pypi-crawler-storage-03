"""Token snapshot."""

from tests.const import PAPERLESS_TEST_TOKEN

DATA_TOKEN = {"token": PAPERLESS_TEST_TOKEN}
