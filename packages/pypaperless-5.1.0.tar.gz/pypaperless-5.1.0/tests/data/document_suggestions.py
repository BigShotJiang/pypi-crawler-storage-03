"""Document suggestions snapshot."""

DATA_DOCUMENT_SUGGESTIONS = {
    "correspondents": [26],
    "tags": [
        1,
        2,
        3,
    ],
    "document_types": [4],
    "storage_paths": [
        3,
        5,
    ],
    "dates": [
        "2022-01-07",
        "2023-01-07",
    ],
}
