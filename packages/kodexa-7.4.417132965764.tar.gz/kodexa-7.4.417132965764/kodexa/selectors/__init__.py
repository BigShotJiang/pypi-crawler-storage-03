"""
Selectors allow you to work with a Kodexa document to find content
"""

from .core import parse
