===========================
Wizata Data Science Package
===========================

This module is intended to be used to create and distribute data science modules within Wizata Platform.

Documentation can be found https://<your_tenant>.onwizata.com/docs

For more information please visit https://www.wizata.com