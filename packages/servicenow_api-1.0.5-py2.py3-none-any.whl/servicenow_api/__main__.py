#!/usr/bin/python
# coding: utf-8
from .servicenow_api_mcp import main

if __name__ == "__main__":
    main()
