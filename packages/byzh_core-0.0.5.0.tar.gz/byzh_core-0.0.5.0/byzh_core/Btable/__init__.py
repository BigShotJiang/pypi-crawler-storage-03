from .auto_table import B_Table2d


__all__ = ['B_Table2d']