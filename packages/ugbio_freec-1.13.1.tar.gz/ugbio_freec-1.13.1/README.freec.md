# ugbio_freec

A docker for running ultimagen [FREEC](https://github.com/Ultimagen/FREEC)
