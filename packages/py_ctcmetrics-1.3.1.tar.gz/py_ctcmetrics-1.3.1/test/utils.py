
test_root = "test_dataset_ctc/train"
test_seq_res = "test_dataset_ctc/train/BF-C2DL-HSC/01_RES"
test_seq_gt = "test_dataset_ctc/train/BF-C2DL-HSC/01_GT"


test_det = 0.95377521
test_seg = 0.903990207454052
test_tra = 0.9588616
test_ct = 0.0190476
test_tf = 0.72417699
test_bc0 = 0.434782
test_bc1 = 0.47826086
test_bc2 = 0.47826086
test_bc3 = 0.47826086
test_cca = 0.060606060606061

