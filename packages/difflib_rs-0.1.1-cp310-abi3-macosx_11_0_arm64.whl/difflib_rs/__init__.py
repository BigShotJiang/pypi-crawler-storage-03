from .difflib_rs import *

__doc__ = difflib_rs.__doc__
if hasattr(difflib_rs, "__all__"):
    __all__ = difflib_rs.__all__