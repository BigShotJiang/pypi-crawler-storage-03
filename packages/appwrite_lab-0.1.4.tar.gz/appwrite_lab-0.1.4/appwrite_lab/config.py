PLAYWRIGHT_IMAGE = "mcr.microsoft.com/playwright/python:v1.52.0-jammy"
APPWRITE_CLI_IMAGE = "docker.io/syntaxsdev/appwrite-cli:latest"
APPWRITE_PLAYWRIGHT_IMAGE = "docker.io/syntaxsdev/appwrite-playwright:latest"
