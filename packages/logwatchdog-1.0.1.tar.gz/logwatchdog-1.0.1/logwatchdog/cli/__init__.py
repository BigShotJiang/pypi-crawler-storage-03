"""
LogWatchdog CLI Package
=======================

Command-line interface for LogWatchdog.
"""

__all__ = ["main"]
