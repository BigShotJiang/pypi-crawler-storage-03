import logging

import pysquirrel

logger = logging.getLogger(__name__)

nuts = pysquirrel.nuts
