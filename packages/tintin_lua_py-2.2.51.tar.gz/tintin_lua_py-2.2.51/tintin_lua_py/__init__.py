"""
TinTin++ MUD client with Lua and Python scripting support

Enhanced version of TinTin++ with additional scripting languages support.
"""

__version__ = "2.02.50"
__author__ = "Federico"
__description__ = "TinTin++ MUD client with Lua and Python scripting support"
