from .interface import IQueueConnector
