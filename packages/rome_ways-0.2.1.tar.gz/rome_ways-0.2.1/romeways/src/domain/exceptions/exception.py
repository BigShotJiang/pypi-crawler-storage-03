class ResendException(Exception):
    pass
