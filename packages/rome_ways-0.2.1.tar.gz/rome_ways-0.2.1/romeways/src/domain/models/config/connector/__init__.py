from .model import GenericConnectorConfig
