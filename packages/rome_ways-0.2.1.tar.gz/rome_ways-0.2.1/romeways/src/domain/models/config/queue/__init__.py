from .model import GenericQueueConfig
