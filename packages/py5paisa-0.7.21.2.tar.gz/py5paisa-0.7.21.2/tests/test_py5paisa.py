#!/usr/bin/env python

"""Tests for `py5paisa` package."""


import unittest

from py5paisa import py5paisa


class TestPy5paisa(unittest.TestCase):
    """Tests for `py5paisa` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
