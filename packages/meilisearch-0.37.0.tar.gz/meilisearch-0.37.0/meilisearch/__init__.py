from meilisearch.client import Client as Client  # pylint: disable=useless-import-alias
