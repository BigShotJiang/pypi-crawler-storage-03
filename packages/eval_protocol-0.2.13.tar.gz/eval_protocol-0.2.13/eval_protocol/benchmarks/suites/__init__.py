# Suite modules are auto-imported by eval_protocol.benchmarks.run to register benchmarks.
