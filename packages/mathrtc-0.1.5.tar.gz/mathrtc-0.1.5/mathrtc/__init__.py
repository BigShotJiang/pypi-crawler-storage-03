from .main import fact
from .main1 import fib
from .main2 import add_or_even
from .main3 import calcuator