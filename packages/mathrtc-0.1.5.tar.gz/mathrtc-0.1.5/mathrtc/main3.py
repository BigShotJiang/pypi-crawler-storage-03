def calculator():
    try:
        expr = input("Enter an expression: ")
        result = eval(expr)
        print("Result:", result)
    except ZeroDivisionError:
        print("Error! Division by zero.")
    except:
        print("Invalid expression!")