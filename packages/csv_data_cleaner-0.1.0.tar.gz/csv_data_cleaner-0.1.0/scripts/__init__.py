"""
Scripts package for CSV Data Cleaner.

This package contains deployment and utility scripts for the CSV Data Cleaner project.
"""

__version__ = "1.0.0"
__author__ = "Faizal"
__email__ = "jai.crys@gmail.com"
