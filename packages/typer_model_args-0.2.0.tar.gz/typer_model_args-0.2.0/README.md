An extension for [Typer](https://typer.tiangolo.com/) that enables
model arguments.

