# import time
#
# from nacos_center import NacosConfig, NacosStore
# if __name__ == '__main__':
#     nacos_config = NacosConfig(
#         server_addresses="https://nacos-api.banyanph.com:6443",
#         data_id="storage.yaml",
#         group="STORAGE",
#         username="nacos",
#         password="8uhb(IJN0okm"
#     )
#     nacos_store = NacosStore(nacos_config, True)
#     try:
#         for index, _ in enumerate(range(3)):
#             if index == 2:
#                 nacos_store.refresh_config()
#             config = nacos_store.get_config()
#             print(config)
#             time.sleep(10)
#     finally:
#         nacos_store.client.stop()
#
