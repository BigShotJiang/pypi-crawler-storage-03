from enum import Enum


class ProductType(Enum):
    CNC = "CNC"
    MIS = "MIS"
    NRML = "NRML"
