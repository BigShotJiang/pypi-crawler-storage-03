```
ProAlgoTrader Core

bash cythonize.sh -c -b
bash publish.sh
```
