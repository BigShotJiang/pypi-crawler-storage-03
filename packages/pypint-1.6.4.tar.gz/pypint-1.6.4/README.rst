Python interface to Pint
------------------------

Pint is a static analyser for the transient dynamics of automata networks.

This python module provides an interface to Pint command line tools.
It also provides customization for the Jupyter notebook interface to ease user
interaction.

See http://loicpauleve.name/pint for more information.

