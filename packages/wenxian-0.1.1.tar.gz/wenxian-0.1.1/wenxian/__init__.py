"""A tool to generate BibTEX."""

from __future__ import annotations

__tool__ = "wenxian"
__email__ = "jinzhe.zeng@ustc.edu.cn"
