"""
NetIntel-OCR Worker Module
Handles PDF processing and data extraction
"""

__version__ = "0.1.13"