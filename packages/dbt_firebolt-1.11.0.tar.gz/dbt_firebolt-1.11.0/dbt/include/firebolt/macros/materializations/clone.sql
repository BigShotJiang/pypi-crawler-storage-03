{% macro firebolt__can_clone_table() %}
    {{ return(False) }}
{% endmacro %}
