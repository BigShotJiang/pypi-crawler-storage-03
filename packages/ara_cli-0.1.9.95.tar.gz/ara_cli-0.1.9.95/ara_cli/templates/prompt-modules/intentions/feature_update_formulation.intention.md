### INTENTION and CONTEXT
Update the feature file: `{feature file}`

update it with the behavior described in file `{filename}` and
implemented in `{source file}`
