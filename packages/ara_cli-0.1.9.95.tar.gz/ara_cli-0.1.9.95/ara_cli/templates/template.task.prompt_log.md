# Task Exploration: <descriptive title of exploration challenge>

- [Task Exploration: ](#task-exploration-)
- [initial exploration ...](#initial-exploration-)

# initial exploration ...
...