# version.py
__version__ = "0.1.9.95"   # fith parameter like .0 for local install test purposes only. official numbers should be 4 digit numbers
