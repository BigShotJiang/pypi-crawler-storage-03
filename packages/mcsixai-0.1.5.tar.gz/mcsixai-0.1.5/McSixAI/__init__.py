"""
McSixAI - AI ассистент для программирования
"""

__version__ = "0.1.5"
__author__ = "McSix"