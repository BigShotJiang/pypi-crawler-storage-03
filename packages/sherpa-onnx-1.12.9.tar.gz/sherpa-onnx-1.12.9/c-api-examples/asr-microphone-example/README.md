# Introduction

This folder contains examples for real-time speech recognition from a microphone
using sherpa-onnx C API.

**Note**: You can call C API from C++ files.


## ./c-api-alsa.cc

This file uses alsa to read a microphone. It runs only on Linux. This file
does not support macOS or Windows.
