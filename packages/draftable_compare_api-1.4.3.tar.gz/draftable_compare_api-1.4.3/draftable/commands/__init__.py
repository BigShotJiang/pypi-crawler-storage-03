# Ideally shouldn't be necessary, as this isn't a module but a command. However, without
# an __init__ file it won't be included in the wheel distribution.
