# thousandeyes-sdk-core

This package provides core functionality for interacting with the ThousandEyes API and should be installed before using any of the published SDKs.
