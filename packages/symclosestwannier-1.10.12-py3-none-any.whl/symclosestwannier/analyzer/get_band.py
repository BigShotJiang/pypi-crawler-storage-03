# ****************************************************************** #
#                                                                    #
# This file is distributed as part of the symclosestwannier code and #
#     under the terms of the GNU General Public License. See the     #
#     file LICENSE in the root directory of the symclosestwannier    #
#      distribution, or http://www.gnu.org/licenses/gpl-3.0.txt      #
#                                                                    #
#          The symclosestwannier code is hosted on GitHub:           #
#                                                                    #
#            https://github.com/CMT-MU/SymClosestWannier             #
#                                                                    #
#                            written by                              #
#                        Rikuto Oiwa, RIKEN                          #
#                                                                    #
# ------------------------------------------------------------------ #
#                                                                    #
#                     get_band: band properties                      #
#                                                                    #
# ****************************************************************** #

import numpy as np


# ==================================================
def dos_main():
    pass


# ==================================================
def k_path():
    pass


# ==================================================
def k_slice():
    pass


# ==================================================
def spin_get_moment():
    pass


# ==================================================
def geninterp_main():
    pass
