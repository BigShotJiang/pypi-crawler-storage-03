import os

__version__ = "1.10.12"
__top_dir__ = os.path.normpath(os.path.dirname(__file__) + "/../") + "/"
