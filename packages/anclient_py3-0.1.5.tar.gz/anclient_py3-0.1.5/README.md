# Anclient.py3

Anclient in Python 3, the equivalent of [Typscript @anclient/semantier](https://github.com/odys-z/Anclient/tree/master/js)
and [Java anclient.jserv](https://github.com/odys-z/Anclient/tree/master/java/eclipse-workspace/anclient.jserv).