from datetime import date
def age():
		birthyear=2004
		currentyear=date.today().year
		age=currentyear-birthyear
		print(f"AGE:{age}")
def full_name():
		print("NAME:VIJAYASARATHI.A")
def dob():
		print("DOB:02/MAY/2004")
	
def degree():
		print("DEGREE:B.TECH-AI&DS")
def fan():
		print("THALAPATHY VIJAY")
