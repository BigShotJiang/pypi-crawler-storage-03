## 0.0.2 (2025-08-22)

#### Features
* introduce requirements schema, ci pipeline, and test coverage improvements

#### Fixes
* none
## 0.0.1 (2025-08-21)

#### Features
* initialize project structure with core configuration and cli entrypoint

#### Fixes
* none
