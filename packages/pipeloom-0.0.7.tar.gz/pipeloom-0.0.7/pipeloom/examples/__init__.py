"""
Examples demonstrating typical pipeloom patterns.
Run with: python -m pipeloom.examples.<module>
"""
