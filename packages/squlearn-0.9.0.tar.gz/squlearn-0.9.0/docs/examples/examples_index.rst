.. _examples:

Examples
========

.. toctree::
    :maxdepth: 1
    :glob:

    example_kernel_digit_classification
    example_kernel_grid_search
    example_quantum_bayesian_optimization
    example_qnn_backend_mitigation
    example_qnn_ode_solver