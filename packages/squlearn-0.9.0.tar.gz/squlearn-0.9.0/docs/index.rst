.. sQUlearn documentation master file, created by
   sphinx-quickstart on Thu Apr 27 16:53:35 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the sQUlearn documentation!
======================================

.. include:: ../README.md
   :parser: myst_parser.sphinx_
   :start-line: 4

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   install/install
   user_guide/user_guide_index
   modules/classes
   examples/examples_index
