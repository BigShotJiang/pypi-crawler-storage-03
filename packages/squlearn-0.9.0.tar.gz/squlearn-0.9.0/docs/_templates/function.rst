:mod:`{{module}}`.\ :spelling:word:`{{objname}}`
{{ underline }}=================================

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

