:mod:`{{module}}`.\ :spelling:word:`{{objname}}`
{{ underline }}=================================

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
