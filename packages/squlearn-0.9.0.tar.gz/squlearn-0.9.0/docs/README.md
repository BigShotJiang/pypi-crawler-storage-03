Requirements:

```bash
pip install sphinx
pip install sphinx-rtd-theme
```

Command for generating the documentation:

```bash
sphinx-build.exe -b html . _build/
```

Or execute in the windows shell:

```bash
make.bat html
```

Spell checking with
```bash
make.bat spelling
```
