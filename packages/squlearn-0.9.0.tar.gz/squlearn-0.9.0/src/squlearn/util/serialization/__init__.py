from squlearn.util.serialization.serializable_model_mixin import SerializableModelMixin

__all__ = ["SerializableModelMixin"]
