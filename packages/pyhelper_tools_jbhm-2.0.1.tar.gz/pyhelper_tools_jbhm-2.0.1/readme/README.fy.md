# Helperbibleteek

[! [LISENS: MIT] (https://img.shields.io/Badge/license-Mit-Yellow.svg) (LICENS)  
[! [PYPI] (https://img.shields.io/pypi/v/pyhelper-Dols-jbhm?tyle=Py-PLeEn) (https://pypi.org/pOject/Pyhelper-BBHM/)  

## 🌍 Beskikbere talen

[! [en] (https://img.shields.io/Badge/lang-en-Red.svg)] (readme.md)  
[! [es] (https://img.shields.io/Badge/elang-es-es-es-es.SVG) (readme.es.md)  
[! [FR] (https://img.shield.io/badge/lang-fr-frlue.svg)] (readme.fr.md)  
[! [DE] (https://img.shields.io/Badge/lang-de-de-de-de-hren.svg)] (readme.de  
[! [ru] (https://img.shields.io/badge/lang-ru-purple.svg)] (readme.ru.md)  
[! [TR] (https://img.shields.io/Badge/lang-tr-orange.svg)] (readme.tr.md)  
[! [ZH] (https://img.shield.io/BADGE/Lang-zh-Black.svg)] (readme.zh.md)  
[! [IT] (https://img.shields.io/Badge/Lang-it-lightgrey.svg)] (readme.it)  
[! [PT] (https://img.shields.io/BADGE/Lang-Pt-brightgreen.svg)] (readme.pt.md)  
[! [SV] (https://img.shields.io/Badge/lang-sv-Blue.svg)] (readme.sv.md)  
[! [JA] (https://img.shields.io/Badge/jang-Ja-red.svg)] (readme.24.Ma.md)  
[! [AR] (https://img.shields.io/Badge/lang-ar-Broonn.svg)] (readme.ar.md)  
[! [AF] (https://img.shields.io/Badge/-lang-Of-orange.svg)] (Reader.af.md)  
[! [SQ] (https://img.shields.io/Badge/lang-sq-blue.svg)] (readme.sq.md)  
[! [AM] (https://img.shield.io/Badge/lang-am-am-am-ham-havy.svg)] (readme.am.md)  
[! [HY] (https://img.shields.io/Badge/lang-hy-red.svg)] (Readme.hy.md)  
[! [AS] (https://img.shields.io/badge/lang-as-purple.svg)] (readme.as.md)  
[! [AY] (https://img.shields.io/Badge/Lang-ay-Broonn.svg)] (ReaderMe.ay.mD)  
[! [AZ] (https://img.shields.io/Badge/-lang-az-az-lightblue.svg)] (readme.az.md)  
[! [BM] (https://img.shields.io/Badge/lang-bm-darkggreen.svg)] (readme.bm.md)  
[! [EU] (https://img.shields.io/BADGE/Lang-eu-pink.svg)] (readme.eu.md)  
[! [BE] (https://img.shields.io/Badge/lang-be-derkblue.svg)] (readme.be.md)  
[! [BN] (https://img.shields.io/Badge/lang-bn-eal.svg)] (readme.bn.md)  
[! [BHO] (https://img.shields.I/Badge/lang-bo-orange.svg)] (readme.bhoo.md)  
[! [BS] (https://img.shields.io/Badge/lang-Furple.svg)] (readme.bm.md)  
[! [BG] (https://img.shields.io/Badge/lang-bg-gg-gg-gg-hreen.svg)] (readme.bg.md)  
[! [CA] (https://img.shields.io/Badge/lang-ca-Yo-Yellow.svg)] (readme.ca  
[! [Ceb] (https://img.shields.io/Badge/Cang-Ceb-Blue.svg)] (readme.ceb.md)  
[! [NY] (https://img.shields.io/Badge/lang-ny-red.svg)] (readme.ny.md)  
[! [CO] (https://img.shield.io/Badge/Lang-Cang-Ce-Ce-Creen.svg)] (readme.co.md)  
[! [HR] (https://img.shields.I/Badge/lang-hr-blue.svg)] (Readme.hr.md)  
[! [CS] (https://img.shields.io/Badge/lang-cs-red.svg)] (readme.cs.md)  
[! [DA] (https://img.shields.io/Badge/Lang-Da-purple.svg)] (readme.da.md)  
[! [DV] (https://img.shields.io/BADGE/Lang-V-orange.svg)] (readme.dv.md)  
[! [DOI] (https://img.shields.io/Badge/Lang-doi-Broon.svg)] (readme.doi.md)  
[! [NL] (https://img.shields.I/Badge/lang-nl-nl-NoRangeHe.svg) (README.NL.NL.CD)  
[! [EO] (https://img.shields.io/Badge/Lang-E-Green.svg)] (readme.eo.md)  
[! [ET] (https://img.shields.io/Badge/et-et-Blue-Blue.svg)] (Reader.et.md)  
[! [EE] (https://img.shields.io/Badge/lang-ee-red.svg)] (readme.ee.md)  
[! [TL] (https://img.shields.io/badge/lang-tl-purple.svg)] (readme.tl.md)  
[! [Fi] (https://img.shields.io/Badge/lang-Bli-blue.svg)] (readme.fi.md)  
[! [FY] (https://img.shields.io/Badge/lang-Y-orange.svg)] (readme.fy.md)  
[! [GL] (https://img.shields.io/Badge/lang-gl-ggl-luy.svg)] (readme.gl.md)  
[! [Ka] (https://img.shields.io/Badge/Lang-Ka-red.svg)] (lader)] (lader)] (Lader HAST.KA.md)  
[! [El] (https://img.shields.io/Badge/el-el-el-Blue.svg)] (readme.el.md)  
[! [GN] (https://img.shields.io/Badge/lang-Gn-Purple.svg)] (readme.gn.md)  
[! [GU] (https://img.shields.io/BADGE/GANG-GU-VERANGE.SVG)] (readme.gu.md)  
[! [HT] (https://img.shields.io/Badge/Lang-HTHE--gge-hre-gebrence.SVG) (ReadMe.ht.md)  
[! [ha] (https://img.shield.io/badge/lang-ha-blueblue.svg)] (readme.ha.md)  
[! [HAWS] (https://img.shields.io/Badge/Lang-Haw-Red.svg)] (Readme.HaW.Dd)  
[! [IW] (https://img.shields.io/BADGE/Lang-Iw-Purple.svg)] (readme.iw.md)  
[! [Hi] (https://img.shields.io/Badge/lang-Hi-Oorange.svg)] (ReadMe.hi.md)  
[! [HMN] (https://img.shields.io/Badge/lang-hmn-hmn-hre-hreen.svg) (readme.hmn.md)  
[! [Hu] (https://img.shields.io/Badge/lang-hu-Blue.svg)] (Readme.Hu.md)  
[! [Is] (https://img.shields.io/Badge/lang-is-red.svg)] (readme.is.md)  
[! [ig] (https://img.shields.io/Badge/ig-ig-ig-purple.svg)] (readme.ig.md)  
[! [ilo] (https://img.shields.io/BADGE/Lang-ilange.svg)] (readme.ilo.md)  
[! [ID] (https://img.shields.io/Badge/Lang-Id-Id-D-Dreen.svg)] (Readme.ID..mD)  
[! [GA] (https://img.shield.io/Badge/lang-ga-blue.svg)] (readme.ga.md)  
[! [JW] (https://img.shields.io/Badge/lang-Jw-R-red.svg)] (Readme.Aww.md)  
[! [kn] (https://img.shields.io/badge/lang-kn-kn-purple.svg)] (readme.kn.md)  
[! [KK] (https://img.shields.io/Badge/lang-kk-orange.svg)] (readme.kk.md)

[! [km] (https://img.shields.io/Badge-kamp-gm-hreen.svg)] (readme.km.md)  
[! [rw] (https://img.shields.io/BADGE/Lang-RWW-BLUE.SVG)] (readMe.rw.md)  
[! [GOM] (https://img.shields.io/Badge/Lang-Dom-red.svg)] (ReadMe.gOM.md)  
[! [KO] (https://img.shields.io/BADGE/Lang-ko-purple.svg)] (readme.jowo)  
[! [KRI] (https://img.shields.io/Badge/lang-kri-orange.svg) (Reader.Kri.md)  
[! [Ku] (https://img.shields.io/Badge/lang-ku-g-g-guer.svg)] (README.KU..mD)  
[! [CKB] (https://img.shields.io/Badge/lang-ckb-blue.svg)] (readme.ckb.md)  
[! [KY] (https://img.shields.io/Badge/lang-ky-red.svg)] (readme.ky)  
[! [Lo] (https://img.shields.io/Badge/lang-lo-purple.svg)] (readme.lowd)  
[! [la] (https://img.shields.io/Badge/lang-la-orange.svg)] (Reader README.LA.mD)  
[! [LV] (https://img.shields.io/Badge/lang-lv-lv-lv-lv-gge.svg)] (readme.lv.md)  
[! [LN] (https://img.shields.I/Badge/lang-ln-llu-.svg)] (readme.ln.md)  
[! [LT] (https://img.shields.io/Badge/lang-lt-red.svg)] (README.LT.MT.MD)  
[! [LG] (https://img.shields.io/Badge/lang-lg-purple.svg)] (readme.lg.md)  
[! [LB] (https://img.shields.io/Badge/lang-lb-orange.svg)] (readme.lb.md)  
[! [MK] (https://img.shields.io/Badge/lang-MK-g-g-Drading.svg)] (readme.mk.md)  
[! [Mai] (https://img.shield.io/Badge/mang-Mui-Blue.svg)] (Readme.Mai.md)  
[! [MG] (https://img.shields.io/Badge/lang-mg-red.svg)] (readme.mg.md)  
[! [MS] (https://img.shields.I/Badge/Lang-Purple.svg)] (readme.md)  
[! [ML] (https://img.shields.I/Badge/lang-R-orange.svg)] (readme.ml.md)  
[! [MT] (https://img.shields.io/Badge/lang-Gt-Hreen.svg)] (readme.mt.md)  
[! [Mi] (https://img.shields.io/Badge/lang-mi-blue.svg)] (readme.md)  
[! [MR] (https://img.shields.I/Badge/lang-mr-red.svg)] (readme.md)  
[! [LUS] (https://img.shields.io/BADGE/Lang-lus-purple.svg)] (readme.lus.md)  
[! [MN] (https://img.shields.io/Badge/lang-mn-orange.svg)] (readme.mn.md)  
[! [MY] (https://img.shield.io/Badge/lang-My-my-we.svg)] (readme.my.md)  
[! [NE] (https://img.shields.io/Badge/lang-ne-Blue.svg)] (readme.ne.md)  
[! [NO] (https://img.shields.io/Badge/langn-red.svg)] (readme.No.Omd)  
[! [OF] (https://img.shields.io/Badge/lang-or-Purple.svg)] (readme.or.md)  
[! [om] (https://img.shields.io/Badge/om-om-orange.svg)] (Reader README.OM.mD)  
[! [PS] (https://img.shields.io/Badge/lang-Ps-Ps-Ps-gpge.se (ReadMe.Ps.MD)  
[! [Fa] (https://img.shields.io/Badge/lang-Fa-Blue.svg)] (readme.fa.md)  
[! [QU] (https://img.shields.io/Badge/lang-qu-red.svg)] (Readme.qu.md)  
[! [ro] (https://img.shields.io/badge/lang-ro-purple.svg)] (readme.ro.o.md)  
[! [SM] (https://img.shields.io/Badge/lang-sorm.svg)] (readme.sm.md)  
[! [SA] (https://img.shields.io/Badge/lang-sa-Lang-sa-Lange.svg)] (readme.Sa.md)  
[! [GD] (https://img.shields.io/Badge/lang-gd-blue.svg)] (readme.gd.md)  
[! [NSO] (https://img.shields.io/Badge/lang-n-So-red.svg)] (readme.nso.md)  
[! [ST] (https://img.shields.io/Badge/lang-st-Turple.svg)] (readme.st.md)  
[! [SL] (https://img.shields.io/Badge/lang-sn-orange.svg)] (readme.sn.md)  
[! [SD] (https://img.shield.io/Badge/lang-sd-D-D-Dreen.svg)] (readme.sd.md)  
[! [SI] (https://img.shields.io/Badge/lang-si-blue.svg)] (readme.Si.md)  
[! [SK] (https://img.shields.io/Badge/lang-sk-red.svg)] (readme.sk.md)  
[! [SL] (https://img.shields.io/Badge/lang-sl-purple.svg)] (readme.sl.md)  
[! [SO] (https://img.shields.I/Badge/lang-so-orange.svg)] (readme.So.md)  
[! [SU] (https://img.shield.io/Badge/lang-su-ger.svg)] (readme.su.md)  
[! [SW] (https://img.shields.I/Badge/lang-sw-Blue.svg)] (readme.sw.Dd)  
[! [TG] (https://img.shields.io/Badge/lang-dr-red.svg)] (readme.tg.md)  
[! [TA] (https://img.shields.io/Badge/Lang-ta-purple.svg)] (readme.ta.md)  
[! [TT] (https://img.shields.io/Badge/lang-T-Toerange.svg)] (readme.tt.md)  
[! [TE] (https://img.shields.io/badge/lang-te-ge-ge-ge-creien.svg)] (readme.te.md)  
[! [TH] (https://img.shield.io/Badge/lang-th-Blue.svg)] (readme.th.md)  
[! [TI] (https://img.shields.io/Badge/Lang-ti-red.svg)] (readme.ti)  
[! [TS] (https://img.shields.io/BADGE/Lang-ts-Purple.svg)] (readme.t.tv)  
[! [TK] (https://img.shields.I/Badge/LangTk-orange.svg)] (readme.tk.md)  
[! [AK] (https://img.shields.io/Badge/lang-K-k-krepen.svg)] (readme.ak.md)  
[! [UK] (https://img.shield.io/Badge/lang-uk-Blue.svg)] (readme.uk.md)  
[! [ur] (https://img.shields.io/Badge/lang-ur-red.svg)] (readme.ur.md)  
[! [UG] (https://img.shields.io/BADGE/Lang-ug-ug-purple.svg)] (readme.ug.md)  
[! [UZ] (https://img.shields.io/Badge/uz-orange.svg)] (Readme.uz.md)  
[! [VI] (https://img.shields.io/Badge/lang-gi-gi-gi-gi-gg)] (readme.vi.md)  
[! [CY] (https://img.shields.io/Badge/Lang-Cy-Blue-Blue.svg)] (readme.cy.md)

[! [XH] (https://img.shields.io/Badge/Lang-xh-red.svg)] (readme.xh.md)  
[! [YI] (https://img.shields.io/Badge/ylang-yi-purple.svg)] (readme.yi.md)  
[! [YO] (https://img.shields.io/Badge/Lang-Yo-Rowwa.svg)] (Readme.yo.md)  
[! [ZU] (https://img.shields.io/Badge/Lang-Zu-Hreen.svg)] (readme.zu.md)

---

## 📖 oersjoch

** Pyhelper ** is in alsidige python Toolkit ûntworpen om ** gegevensanalyse te ferienfâldigjen, fisualisaasje, statistyske operaasjes en workflowlows **.  
It yntegreart naadloos yn akademysk, ûndersyk, en profesjonele projekten, wêrtroch jo moatte konsintrearje op ynsjoch, ynstee fan ynsjoch.

Kaai foardielen:
- 🧮 Boud-in ** statistiken en wiskundeprogramma's **
- 📊 Easy-to-GEBRUK ** Gegevens fisualisaasjeprappers **
- 🗂 Handy ** Bestân ôfhanneling en sykje **
- 🔍 ** Syntaksisjouwing ** Foar Python-bestannen
- 🌍 ** Multi-taal-stipe ** mei read-to-gebrûk-oersettingen
- 🚀 Optimalisearre foar ** snelle prototyping ** en ** edukative doelen **

---

## ✨ Funksjes

### 📊 gegevens visualisaasje
- Horizontale & fertikale bar charts (`hbar`,` vbar`)
- Pie charts (`pie`)
- Box plots (`Boxplot`)
- histogrammen (`Histo`)
- Heatmaps (`Heatmap`)
- gegevens tabellen (`Tabel`)
- Avansearre Visualizations (Scatter, Violin, KDE, Pairplot, ensfh.)

### 📈 statistyske analyse
- Maatregels fan sintrale oanstriid:  
  `GET_MEDIA`,` GET_MEDIAN`, 'GET_MODA`
- Maatregels fan fersprieding:  
  `get_rank`,` get_var`, `get_desv`,` disp`
- Gegevens Normalisaasje (`normalisearje ')
- Outlier Detrection (iqr & Z-skoare metoaden)
- Betingsten gegevenstransformaasje (`Betingsten ')

### 🛠 Utilities
- File Discovery and Loading (`Call`)
- Enhanced ** Skeakelje / asyncswitch ** systeem
- Synntax Kontrolearje en analyse (`pythonfileChecker`,` check_syntax`)
- Flater by it rapportearjen mei kontekst
- Yntegreare helpsysteem (`Help ', foarbyldings, dokuminten)

### 🌍 Support Multi-Taal
- Ynboude oersettingen foar ** 12 talen **
- útwreidjend mei `load_user_translations ()`
- Dynamyske seleksje mei `set_language (Lang_code)`
- Standert Fallaback nei Ingelsk

---

## 🚀 Ynstallaasje

Ynstallearje út Pypi:

`` `bash
Pip ynstallearje Pyhelper-tools-JBHM
`` ``

---

## 🔧 Brûk foarbylden

### SET Taal sette
`` `python
Fan helper ymport set_letuage

set_language ("en") # Ingelsk
set_language ("es") # Spaansk
set_language ("fr") # Frânsk
Set_Language ("de") # Dútsk
set_language ("ru") # Russysk
set_language ("TR") # Turksk
set_language ("zh") # Sineesk
set_language ("it") # Italjaansk
Set_Language ("PT") # Portugeesk
Set_Language ("SV") # Sweedsk
Set_Language ("ja") # Japansk
set_language ("ar") # Arabysk
# ... Support foar 100+ talen
`` ``

### Basisstatistiken
`` `python
ymportearje helper as HP

DATA = [1, 2, 2, 3, 4, 5]

Ofdrukke (HP.Get_media (gegevens)) # betsjutte
Ofdrukke (hp.get_median (gegevens)) # mediaan
Ofdrukke (HP.GET_MODA (gegevens)) # modus
`` ``

### Visualisaasje
`` `python
ymportearje helper as hp
fan helper.Submodules ymportearje grafyk as GR

df = hp.pd.dataframe ({"wearden": [5, 3, 7, 2, 9]})
gr.histo (DF, "wearden", bins = 5, title = "Foarbyld histogram")
`` ``

### Bestânbehanneling
`` `python
Fan helper ymport oprop

gegevens = skilje ("my_data", Type = "csv") # fynt en lade in csv-bestân automatysk
`` ``

### Oanpaste oersettings
`` `python
fan helper ymport load_user_translations

# Laad oanpaste oersettingen fan Lang.json
load_user_translations ("custom / lang.json")
`` ``

---

## 📂 Projektstruktuer

`` ``
helper/
 ├── core.py # haadfunksjes
 ├── Lang / # oersettingssbestannen (JSON)
 ├── Submodules /
 │ ├── Graph.py # Visualisaasjefunksjes
 │ ├── statics.py # statistyske funksjes
 │ ├── Utils.Py # nutsbedriuwen
 └── __init__.py
`` ``

---

## 🤝 Bydrage

Bydragen binne wolkom!  
Iepenje asjebleaft problemen, stel ferbetteringen foar, of yntsjinje Pull-oanfragen op it [Github-repository] (https://github.com/jbhmdev/pyhelper-Pools).

---

## 📜 License

Dit projekt wurdt fergunning ûnder de ** MIT-lisinsje **.  
Sjoch de [lisinsje] (lisinsje) bestân foar details.

---

⚡ Klear om jo Python-workflows te stypjen mei ** Pyhelper **? Begjin hjoed te ferkennen!