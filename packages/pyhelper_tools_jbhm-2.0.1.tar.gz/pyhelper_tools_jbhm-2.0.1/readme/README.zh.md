＃帮手库

[！[许可：MIT]（https://img.shields.io/badge/license-mit-yellow.svg）]（许可证）  
[！  

##🌍可用语言

[！[en]（https://img.shields.io/badge/lang-en-red.svg）]（readme.md）  
[！[es]（https://img.shields.io/badge/lang-es-yellow.svg）]  
[！[fr]（https://img.shields.io/badge/lang-fr-blue.svg）]（readme.fr.md）  
[！[de]（https://img.shields.io/badge/lang-de-green.svg）]  
[！[ru]（https://img.shields.io/badge/lang-ru-purple.svg）]（readme.ru.md）  
[！[tr]（https://img.shields.io/badge/lang-tr-orange.svg）]（readme.tr.md）  
[！[zh]（https://img.shields.io/badge/lang-zh-black.svg）]（readme.zh.md）  
[！[it]（https://img.shields.io/badge/lang-it-lightgrey.svg）]（readme.it.it.md）  
[！[pt]（https://img.shields.io/badge/lang-pt-brightgreen.svg）]（readme.pt.md）  
[！[sv]（https://img.shields.io/badge/lang-sv-blue.svg）]（readme.sv.md）  
[！[JA]（https://img.shields.io/badge/lang-ja-red.svg）]（readme.ja.md）  
[！[ar]（https://img.shields.io/badge/lang-ar-brown.svg）]  
[！[af]（https://img.shields.io/badge/lang-af-reange.svg）]（readme.af.md）  
[！[sq]（https://img.shields.io/badge/lang-sq-blue.svg）]（readme.sq.md）  
[！[am]（https://img.shields.io/badge/lang-am-green.svg）]（readme.am.md）  
[！[hy]（https://img.shields.io/badge/lang-hy-red.svg）]（readme.hy.md）  
[！[as]（https://img.shields.io/badge/lang-as-purple.svg）]  
[！  
[！[az]（https://img.shields.io/badge/lang-az-lightblue.svg）]（readme.az.md）  
[！[bm]（https://img.shields.io/badge/lang-bm-darkgreen.svg）]（readme.bm.md）  
[！[eu]（https://img.shields.io/badge/lang-eu-pink.svg）]  
[！[BE]（https://img.shields.io/badge/lang-be-darkblue.svg）]（readme.be.md）  
[！[bn]（https://img.shields.io/badge/lang-bn-teal.svg）]（readme.bn.md）  
[！[bho]（https://img.shields.io/badge/lang-bho-orange.svg）]（readme.bho.md）  
[！[bs]（https://img.shields.io/badge/lang-bs-purple.svg）]（readme.bm.md）  
[！[bg]（https://img.shields.io/badge/lang-bg-green.svg）]（readme.bg.md）  
[！[CA]（https://img.shields.io/badge/lang-ca-yellow.svg）]  
[！[CEB]（https://img.shields.io/badge/lang-ceb-blue.svg）]（readme.ceb.md）  
[！[ny]（https://img.shields.io/badge/lang-ny-red.svg）]（readme.ny.ny.md）  
[！[CO]（https://img.shields.io/badge/lang-co-green.svg）]  
[！[hr]（https://img.shields.io/badge/lang-hr-blue.svg）]（readme.hr.md）  
[！[CS]（https://img.shields.io/badge/lang-cs-red.svg）]  
[！[da]（https://img.shields.io/badge/lang-da-purple.svg）]  
[！[DV]（https://img.shields.io/badge/lang-dv-orange.svg）]（readme.dv.md）  
[！[doi]（https://img.shields.io/badge/lang-doi-brown.svg）  
[！[nl]（https://img.shields.io/badge/lang-nl-orange.svg）]（readme.nl.md）  
[！[eo]（https://img.shields.io/badge/lang-eo-green.svg）]（readme.eo.md）  
[！[et]（https://img.shields.io/badge/lang-et-blue.svg）  
[！[EE]（https://img.shields.io/badge/lang-ee-red.svg）]  
[！[tl]（https://img.shields.io/badge/lang-tl-purple.svg）]（readme.tl.md）  
[！[fi]（https://img.shields.io/badge/lang-fi-blue.svg）]  
[！[fy]（https://img.shields.io/badge/lang-fy-orange.svg）]（readme.fy.md）  
[！[gl]（https://img.shields.io/badge/lang-gl-green.svg）]（readme.gl.md）  
[！[ka]（https://img.shields.io/badge/lang-ka-red.svg）]（readme.ka.md）  
[！[el]（https://img.shields.io/badge/lang-el-blue.svg）]（readme.el.md）  
[！[gn]（https://img.shields.io/badge/lang-gn-purple.svg）]（readme.gn.md）  
[！[GU]（https://img.shields.io/badge/lang-gu-orange.svg）  
[！[ht]（https://img.shields.io/badge/lang-ht-green.svg）]（readme.ht.md）  
[！[ha]（https://img.shields.io/badge/lang-ha-blue.svg）]（readme.ha.md）  
[！[HAW]（https://img.shields.io/badge/lang-haw-red.svg）]（readme.haw.md）  
[！[iw]（https://img.shields.io/badge/lang-iw-purple.svg）]（readme.iw.md）  
[！  
[！[hmn]（https://img.shields.io/badge/lang-hmn-green.svg）]（readme.hmn.md）  
[！  
[！[is]（https://img.shields.io/badge/lang-is-red.svg）]（readme.is.md）  
[！[ig]（https://img.shields.io/badge/lang-ig-purple.svg）]（readme.ig.ig.md）  
[！[ilo]（https://img.shields.io/badge/lang-ilo-orange.svg）]（readme.ilo.md）  
[！[id]（https://img.shields.io/badge/lang-id-green.svg）]（readme.id.md）  
[！[GA]（https://img.shields.io/badge/lang-ga-blue.svg）  
[！[JW]（https://img.shields.io/badge/lang-jw-red.svg）]（readme.jw.md）  
[！[kn]（https://img.shields.io/badge/lang-kn-purple.svg）]（readme.kn.md）  
[！[kk]（https://img.shields.io/badge/lang-kk-orange.svg）]（readme.kk.md）

[！[km]（https://img.shields.io/badge/lang-km-green.svg）]（readme.km.md）  
[！[rw]（https://img.shields.io/badge/lang-rw-blue.svg）]（readme.rw.md）  
[！[gom]（https://img.shields.io/badge/lang-gom-red.svg）]（readme.gom.md）  
[！[ko]（https://img.shields.io/badge/lang-ko-purple.svg）]（readme.ko.md）  
[！[kri]（https://img.shields.io/badge/lang-kri-orange.svg）]（readme.kri.md）  
[！[ku]（https://img.shields.io/badge/lang-ku-green.svg）]（readme.ku.md）  
[！[ckb]（https://img.shields.io/badge/lang-ckb-blue.svg）]（readme.ckb.md）  
[！[ky]（https://img.shields.io/badge/lang-ky-red.svg）]（readme.ky.md）  
[！[lo]（https://img.shields.io/badge/lang-lo-purple.svg）]（readme.lo.md）  
[！[la]（https://img.shields.io/badge/lang-la-orange.svg）]（readme.la.md）  
[！[lv]（https://img.shields.io/badge/lang-lv-green.svg）]（readme.lv.md）  
[！[ln]（https://img.shields.io/badge/lang-ln-blue.svg）]（readme.ln.md）  
[！[lt]（https://img.shields.io/badge/lang-lt-red.svg）]（readme.lt.md）  
[！[lg]（https://img.shields.io/badge/lang-lg-purple.svg）]（readme.lg.md）  
[！[lb]（https://img.shields.io/badge/lang-lb-orange.svg）]（readme.lb.md）  
[！[mk]（https://img.shields.io/badge/lang-mk-green.svg）]（readme.mk.md）  
[！  
[！[mg]（https://img.shields.io/badge/lang-mg-red.svg）]（readme.mg.md）  
[！[ms]（https://img.shields.io/badge/lang-ms-purple.svg）]（readme.ms.md）  
[！[ml]（https://img.shields.io/badge/lang-ml-orange.svg）]（readme.ml.md）  
[！[mt]（https://img.shields.io/badge/lang-mt-green.svg）]  
[！[mi]（https://img.shields.io/badge/lang-mi-blue.svg）]  
[！[MR]（https://img.shields.io/badge/lang-mr-red.svg）]  
[！[lus]（https://img.shields.io/badge/lang-lus-purple.svg）]  
[！[mn]（https://img.shields.io/badge/lang-mn-orange.svg）]（readme.mn.md）  
[！[my]（https://img.shields.io/badge/lang-my-green.svg）]（readme.my.md）  
[！[ne]（https://img.shields.io/badge/lang-ne-blue.svg）]（readme.ne.ne.md）  
[！[no]（https://img.shields.io/badge/lang-no-red.svg）]  
[！  
[！[om]（https://img.shields.io/badge/lang-om--erange.svg）]（readme.om.om.md）  
[！[ps]（https://img.shields.io/badge/lang-ps-green.svg）]（readme.ps.md）  
[！[fa]（https://img.shields.io/badge/lang-fa-blue.svg）]（readme.fa.md）  
[！  
[！[ro]（https://img.shields.io/badge/lang-ro-purple.svg）]  
[！[sm]（https://img.shields.io/badge/lang-sm-orange.svg）]（readme.sm.md）  
[！[sa]（https://img.shields.io/badge/lang-sa-green.svg）]  
[！[gd]（https://img.shields.io/badge/lang-gd-blue.svg）]（readme.gd.md）  
[！[nso]（https://img.shields.io/badge/lang-nso-red.svg）]（readme.nso.md）  
[！[ST]（https://img.shields.io/badge/lang-st-purple.svg）  
[！[sn]（https://img.shields.io/badge/lang-sn-orange.svg）]（readme.sn.md）  
[！[sd]（https://img.shields.io/badge/lang-sd-green.svg）]（readme.sd.md）  
[！[si]（https://img.shields.io/badge/lang-si-blue.svg）]（readme.si.md）  
[！[SK]（https://img.shields.io/badge/lang-sk-red.svg）]（readme.sk.md）  
[！[SL]（https://img.shields.io/badge/lang-sl-purple.svg）]（readme.sl.md）  
[！  
[！[su]（https://img.shields.io/badge/lang-su-green.svg）]  
[！[SW]（https://img.shields.io/badge/lang-sw-blue.svg）]（readme.sw.md）  
[！[tg]（https://img.shields.io/badge/lang-tg-red.svg）]  
[！[ta]（https://img.shields.io/badge/lang-ta-purple.svg）]  
[！[tt]（https://img.shields.io/badge/lang-tt-orange.svg）]（readme.tt.md）  
[！[TE]（https://img.shields.io/badge/lang-te-green.svg）]  
[！[th]（https://img.shields.io/badge/lang-th-blue.svg）]（readme.th.md）  
[！[ti]（https://img.shields.io/badge/lang-ti-red.svg）]（readme.ti.md）  
[！[ts]（https://img.shields.io/badge/lang-ts-purple.svg）]（readme.ts.md）  
[！[tk]（https://img.shields.io/badge/lang-tk-orange.svg）]  
[！[ak]（https://img.shields.io/badge/lang-ak-green.svg）]  
[！[英国]（https://img.shields.io/badge/lang-uk-blue.svg）  
[！[ur]（https://img.shields.io/badge/lang-ur-red.svg）]（readme.ur.md）  
[！[ug]（https://img.shields.io/badge/lang-ug-purple.svg）]  
[！[uz]（https://img.shields.io/badge/lang-uz-orange.svg）]（readme.uz.md）  
[！[vi]（https://img.shields.io/badge/lang-vi-green.svg）]（readme.vi.md）  
[！

[！[xh]（https://img.shields.io/badge/lang-xh-red.svg）]（readme.xh.md）  
[！[yi]（https://img.shields.io/badge/lang-yi-purple.svg）]（readme.yi.md）  
[！[yo]（https://img.shields.io/badge/lang-yo-orange.svg）  
[！[zu]（https://img.shields.io/badge/lang-zu-green.svg）]（readme.zu.md）

---

##📖概述

** Pyhelper **是一种多功能的Python工具包，旨在简化数据分析，可视化，统计操作和实用程序工作流程**。  
它无缝集成到学术，研究和专业项目中，使您可以专注于见解而不是样板代码。

关键优势：
 - 内置**统计和数学公用事业**
 - 📊易于使用**数据可视化包装器**
 - 方便**文件处理和搜索**
 -  **语法验证** python文件
 -  **多语言支持**，带有现成的翻译
 - 为**快速原型**和**教育目的优化**

---

##✨功能

###📊数据可视化
 - 水平和垂直条形图（`hbar'，`vbar'）
 - 饼图（`pie'）
 - 盒子图（``boxplot'）
 - 直方图（`histo'）
 - 热图（“热图”）
 - 数据表（`table'）
 - 高级可视化（散点，小提琴，KDE，配对等）

###📈统计分析
 - 中心趋势的度量：  
  “ get_media”，“ get_median”，“ get_moda”
 - 分散度量：  
  `get_rank`，`get_var`，`get_desv`，`dexp`
 - 数据归一化（“标准化”）
 - 离群值检测（IQR＆z得分方法）
 - 条件数据转换（“条件”）

###🛠实用程序
 - 文件发现和加载（“调用”）
 - 增强** switch / asyncswitch **系统
 - 语法检查与分析（`PythonFileChecker`，`check_syntax`）
 - 与上下文报告的错误报告
 - 集成帮助系统（“帮助”，预览，文档）

###🌍多语言支持
 -  ** 12语言**的内置翻译
 - 可扩展使用`load_user_translations（）``
 - 使用`set_language（lang_code）`动态选择
 - 默认退回英语

---

##🚀安装

从PYPI安装：

``bash
PIP安装Pyhelper-Tools-JBHM
````````

---

##🔧用法示例

###设置语言
``python
从助手导入set_language

set_language（“ en”）＃英语
set_language（“ es”）＃西班牙语
set_language（“ fr”）＃法语
set_language（“ de”）＃德语
set_language（“ ru”）＃俄语
set_language（“ tr”）＃土耳其语
set_language（“ zh”）＃中文
set_language（“ it”）＃italian
set_language（“ pt”）＃葡萄牙语
set_language（“ sv”）＃瑞典语
set_language（“ ja”）＃日本
set_language（“ ar”）＃阿拉伯语
＃...支持100多种语言
````````

###基本统计
``python
进口助手作为惠普

数据= [1，2，2，3，4，5]

打印（hp.get_media（data））＃均值
打印（hp.get_median（data））＃中位数
打印（hp.get_moda（data））＃模式
````````

###可视化
``python
进口助手作为惠普
从助手。submodules导入图作为gr

df = hp.pd.dataframe（{“ values”：[5，3，7，2，9]}）
Gr.Histo（DF，“值”，BINS = 5，title =“样本直方图”）
````````

###文件处理
``python
从助手进口电话

data =呼叫（“ my_data”，type =“ csv”）＃自动找到并加载csv文件
````````

###自定义翻译
``python
从助手导入load_user_translations

＃从lang.json加载自定义翻译
load_user_translations（“ custom/lang.json”）
````````

---

##📂项目结构

````````
帮手/
 ├─Core.py＃主要功能
 ├ -  lang/＃translation文件（JSON）
 ├─-子模块/
 ││├─pragh.py＃可视化功能
 │││─-静态＃＃统计功能
 ││├站是Utils.py＃实用程序帮助者
 └ -  __init__.py
````````

---

##🤝贡献

欢迎捐款！  
请在[GitHub存储库]（https://github.com/jbhmdev/pyhelper-tools）上打开问题，建议改进或提交拉动请求。

---

##📜许可证

该项目已根据** MIT许可**许可。  
有关详细信息，请参见[许可]（许可证）文件。

---

⚡准备用** pyhelper **增强您的python工作流程？今天开始探索！