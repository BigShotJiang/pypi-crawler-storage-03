# Kpekpeɖeŋunaƒe ƒe Agbalẽdzraɖoƒe .

[! [mɔɖegbalẽ: MIT] (https://img.shields.io/badge/license-mit-yellow.svg)](mɔɖegbalẽ)  
[![Pypi](https://img.shields.io/pypi/v/pyhelper-dɔwɔnuwo-jbhm?style=na-afɔdzideƒe&label=pypi&color=blue)]](https://pypi.org/pyhel  

## 🌍 Gbe siwo li .

[! [en] (https://img.shields.io/badge/lang-en-red.svg)] (Readme.md)  
[! [ES] (https://img.shields.io/badge/lang-es-yellow.svg)](readme.es.md)  
[! [fr] (https://img.shields.io/badge/lang-fr-blue.svg)] (readme.fr.md)  
[! [de] (https://img.shields.io/badge/lang-de-amagbe.SVG)] (Readme.de.md)  
[! [ru] (https://img.shields.io/badge/lang-ru-purple.svg)] (readme.ru.md)  
[! [tr] (https://img.shields.io/badge/lang-tr-orange.svg)] (Readme.tr.md)  
[! [zh] (https://img.shields.io/badge/lang-zh-yibɔ.svg)] (Readme.zh.md)  
[![e] (https://img.shields.io/badge/lang-it-lightgrey.svg)] (readme.it.md)  
[! [pt] (https://img.shields.io/badge/lang-pt-brightgreen.svg)] (Readme.pt.md)  
[! [SV] (https://img.shields.io/badge/lang-sv-blue.svg)] (Readme.sv.md)  
[! [ja] (https://img.shields.io/badge/lang-ja-red.svg)] (Readme.ja.md)  
[! [AR] (https://img.shields.io/badge/lang-ar-brown.svg)] (readme.ar.md)  
[! [af] (https://img.shields.io/badge/lang-af-orange.svg)] (readme.af.md)  
[! [sq] (https://img.shields.io/badge/lang-sq-blue.svg)] (Readme.sq.md)  
[! [Am] (https://img.shields.io/badge/lang-am-amadede dzẽ.svg)] (Readme.am.md)  
[! [hy] (https://img.shields.io/badge/lang-hy-red.svg)] (Readme.hy.md)  
[![wo] (https://img.shields.io/badge/lang-as-purple.svg)] (readme.as.md)  
[![ay] (https://img.shields.io/badge/lang-ay-brown.svg)] (Readme.ay.md)  
[! [AZ] (https://img.shields.io/badge/lang-az-kekeli.svg)] (Readme.az.md)  
[! [BM] (https://img.shields.io/badge/lang-bm-darkgreen.svg)] (Readme.bm.md)  
[! [EU] (https://img.shields.io/badge/lang-eu-pink.svg)] (readme.eu.md)  
[! [be] (https://img.shields.io/badge/lang-be-darkblue.svg)] (readme.be.md)  
[! [bn] (https://img.shields.io/badge/lang-bn-teal.svg)] (Readme.bn.md)  
[! [bho] (https://img.shields.io/badge/lang-bho-orange.svg)] (Readme.bho.md)  
[! [bs] (https://img.shields.io/badge/lang-bs-purple.svg)] (readme.bm.md)  
[! [bg] (https://img.shields.io/badge/lang-bg-green.svg)] (Readme.bg.md)  
[! [CA] (https://img.shields.io/badge/lang-ca-yellow.svg)] (readme.ca.md)  
[![ceb] (https://img.shields.io/badge/lang-ceb-blue.svg)] (Readme.ceb.md)  
[! [Ny] (https://img.shields.io/badge/lang-ny-red.svg)] (Readme.ny.md)  
[! [co] (https://img.shields.io/badge/lang-co-amadede dzẽ.svg)] (readme.co.md)  
[! [hr] (https://img.shields.io/badge/lang-hr-blue.svg)] (readme.hr.md)  
[![cs] (https://img.shields.io/badge/lang-cs-red.svg)] (Readme.cs.md)  
[! [da] (https://img.shields.io/badge/lang-da-purple.svg)] (readme.da.md)  
[! [dv] (https://img.shields.io/badge/lang-dv-orange.svg)] (Readme.dv.md)  
[! [doi] (https://img.shields.io/badge/lang-doi-brown.svg)] (Readme.doi.md)  
[! [nl] (https://img.shields.io/badge/lang-nl-orange.svg)] (Readme.nl.md)  
[! [EO] (https://img.shields.io/badge/lang-eo-green.svg)] (Readme.eo.md)  
[! [et] (https://img.shields.io/badge/lang-et-blue.svg)] (readme.et.md)  
[![ee] (https://img.shields.io/badge/lang-ee-red.svg)] (readme.ee.md)  
[! [tl] (https://img.shields.io/badge/lang-tl-purple.svg)] (Readme.tl.md)  
[! [Fi] (https://img.shields.io/badge/lang-fi-blue.svg)] (readme.fi.md)  
[! [FY] (https://img.shields.io/badge/lang-fy-orange.svg)] (Readme.fy.md)  
[! [gl] (https://img.shields.io/badge/lang-gl-green.svg)] (Readme.gl.md)  
[! [ka] (https://img.shields.io/badge/lang-ka-red.svg)] (Readme.ka.md)  
[! [el] (https://img.shields.io/badge/lang-el-blue.svg)] (Readme.el.md)  
[! [gn] (https://img.shields.io/badge/lang-gn-purple.svg)] (Readme.gn.md)  
[! [gu] (https://img.shields.io/badge/lang-gu-orange.svg)] (Readme.gu.md)  
[! [ht] (https://img.shields.io/badge/lang-ht-amagbe.SVG)] (Readme.ht.md)  
[![ha] (https://img.shields.io/badge/lang-ha-blue.svg)] (Readme.ha.md)  
[![Haw] (https://img.shields.io/badge/lang-haw-red.svg)] (Readme.haw.md)  
[! [iw] (https://img.shields.io/badge/lang-iw-purple.svg)](readme.iw.md)  
[! [Hi] (https://img. shields.io/badge/lang-hi-orange.svg)] (Readme.hi.md)  
[! [hmn] (https://img.shields.io/badge/lang-hmn-amagbe.svg)] (Readme.hmn.md)  
[! [hu] (https://img.shields.io/badge/lang-hu-blue.svg)] (readme.hu.md)  
[![nye] (https://img.shields.io/badge/lang-is-red.svg)] (readme.is.md)  
[! [IG] (https://img.shields.io/badge/lang-ig-purple.svg)] (readme.ig.md)  
[! [ilo] (https://img.shields.io/badge/lang-ilo-orange.svg)] (readme.ilo.md)  
[! [id] (https://img.shields.io/badge/lang-id-amagbe.svg)] (readme.id.md)  
[! [ga] (https://img.shields.io/badge/lang-ga-blue.svg)] (readme.ga.md)  
[! [JW] (https://img.shields.io/badge/lang-jw-red.svg)] (Readme.jw.md)  
[! [kn] (https://img.shields.io/badge/lang-kn-purple.svg)] (Readme.kn.md)  
[! [kk] (https://img.shields.io/badge/lang-kk-orange.svg)] (Readme.kk.md)

[! [km] (https://img.shields.io/badge/lang-km-amadede dzẽ.svg)] (Readme.km.md)  
[! [rw] (https://img.shields.io/badge/lang-rw-blue.svg)] (Readme.rw.md)  
[![Gom] (https://img.shields.io/badge/lang-gom-red.svg)] (readme.gom.md)  
[! [KO] (https://img.shields.io/badge/lang-ko-purple.svg)] (readme.ko.md)  
[! [kri] (https://img.shields.io/badge/lang-kri-orange.svg)] (Readme.kri.md)  
[! [ku] (https://img.shields.io/badge/lang-ku-green.svg)] (Readme.ku.md)  
[! [ckb] (https://img.shields.io/badge/lang-ckb-blue.svg)] (Readme.ckb.md)  
[! [ky] (https://img.shields.io/badge/lang-ky-red.svg)] (readme.ky.md)  
[! [lo] (https://img.shields.io/badge/lang-lo-purple.svg)] (readme.lo.md)  
[! [la] (https://img.shields.io/badge/lang-la-orange.svg)] (Readme.la.md)  
[! [lv] (https://img.shields.io/badge/lang-lv-amagbe.svg)] (Readme.lv.md)  
[! [ln] (https://img.shields.io/badge/lang-ln-blue.svg)] (Readme.ln.md)  
[! [LT] (https://img.shields.io/badge/lang-lt-red.svg)] (Readme.lt.md)  
[! [lg] (https://img.shields.io/badge/lang-lg-purple.svg)] (Readme.lg.md)  
[! [lb] (https://img.shields.io/badge/lang-lb-orange.svg)] (Readme.lb.md)  
[! [MK] (https://img.shields.io/badge/lang-mk-amadede dzẽ.svg)] (Readme.mk.md)  
[! [mai] (https://img.shields.io/badge/lang-mai-blue.svg)] (Readme.mai.md)  
[! [mg] (https://img.shields.io/badge/lang-mg-red.svg)] (Readme.mg.md)  
[! [Aƒenɔ] (https://img.shields.io/badge/lang-ms-purple.svg)](Readme.ms.md)  
[! [ml] (https://img.shields.io/badge/lang-ml-orange.svg)] (Readme.ml.md)  
[! [mt] (https://img.shields.io/badge/lang-mt-green.svg)] (Readme.mt.md)  
[! [mi] (https://img.shields.io/badge/lang-mi-blue.svg)] (readme.mi.md)  
[! [Aƒetɔ] (https://img.shields.io/badge/lang-mr-red.svg)] (Readme.mr.md)  
[! [Lus] (https://img.shields.io/badge/lang-lus-purple.svg)] (Readme.lus.md)  
[! [mn] (https://img.shields.io/badge/lang-mn-orange.svg)] (Readme.mn.md)  
[![nye] (https://img.shields.io/badge/lang-nye-amagbe.SVG)] (Readme.my.md)  
[! [ne] (https://img.shields.io/badge/lang-ne-blue.svg)] (readme.ne.md)  
[! [ao] (https://img.shields.io/badge/lang-no-red.svg)] (readme.no.md)  
[![alo] (https://img.shields.io/badge/lang-alo-purple.svg)] (readme.or.md)  
[! [om] (https://img.shields.io/badge/lang-om-orange.svg)] (Readme.om.md)  
[![ps] (https://img.shields.io/badge/lang-ps-amadede dzẽ.svg)] (readme.ps.md)  
[! [FA] (https://img.shields.io/badge/lang-fa-blue.svg)] (Readme.fa.md)  
[![qu] (https://img.shields.io/badge/lang-qu-red.svg)] (readme.qu.md)  
[! [ro] (https://img.shields.io/badge/lang-ro-purple.svg)] (readme.ro.md)  
[![sm] (https://img.shields.io/badge/lang-sm-orange.svg)](Readme.sm.md)  
[! [sa] (https://img.shields.io/badge/lang-sa-green.svg)] (readme.sa.md)  
[! [GD] (https://img.shields.io/badge/lang-gd-blue.svg)] (Readme.gd.md)  
[! [No] (https://img.shields.io/badge/lang-nso-red.svg)] (readme.nso.md)  
[! [St] (https://img.shields.io/badge/lang-st-purple.svg)] (Readme.st.md)  
[![sn] (https://img.shields.io/badge/lang-sn-orange.svg)](Readme.sn.md)  
[! [SD] (https://img.shields.io/badge/lang-sd-amagbe.SVG)](Readme.sd.md)  
[! [Si] (https://img.shields.io/badge/lang-si-blue.svg)] (Readme.Si.md)  
[! [SK] (https://img.shieds.io/badge/lang-sk-red.svg)] (Readme.sk.md)  
[![sl] (https://img.shields.io/badge/lang-sl-purple.svg)] (Readme.sl.md)  
[! [ale] (https://img.shields.io/badge/lang-so-orange.svg)] (Readme.So.md)  
[! [su] (https://img.shields.io/badge/lang-su-amagbe.SVG)] (Readme.su.md)  
[! [SW] (https://img.shields.io/badge/lang-sw-blue.svg)] (Readme.sw.md)  
[! [tg] (https://img.shields.io/badge/lang-tg-red.svg)] (Readme.tg.md)  
[! [ta] (https://img.shields.io/badge/lang-ta-purple.svg)] (readme.ta.md)  
[! [TT] (https://img.shields.io/badge/lang-tt-orange.svg)] (Readme.tt.md)  
[! [te] (https://img.shields.io/badge/lang-te-amagbe.SVG)] (Readme.te.md)  
[! [th] (https://img.shields.io/badge/lang-th-blue.svg)] (Readme.th.md)  
[! [ti] (https://img.shields.io/badge/lang-ti-red.svg)] (Readme.ti.md)  
[! [ts] (https://img.shields.io/badge/lang-ts-purple.svg)](Readme.ts.md)  
[! [tk] (https://img.shields.io/badge/lang-tk-orange.svg)] (Readme.tk.md)  
[! [AK] (https://img.shields.io/badge/lang-ak-amadede dzẽ.svg)] (readme.ak.md)  
[![uk] (https://img.shields.io/badge/lang-uk-blue.svg)] (readme.uk.md)  
[![ur] (https://img.shields.io/badge/lang-ur-red.svg)] (Readme.ur.md)  
[! [ug] (https://img.shields.io/badge/lang-ug-purple.svg)] (Readme.ug.md)  
[![uz] (https://img.shields.io/badge/lang-uz-orange.svg)] (Readme.uz.md)  
[! [vi] (https://img.shields.io/badge/lang-vi-green.svg)] (readme.vi.md)  
[! [cy] (https://img.shields.io/badge/lang-cy-blue.svg)] (Readme.cy.md)

[! [xh] (https://img.shields.io/badge/lang-xh-red.svg)] (Readme.xh.md)  
[! [yi] (https://img.shields.io/badge/lang-yi-purple.svg)] (Readme.yi.md)  
[![yo] (https://img.shields.io/badge/lang-yo-orange.svg)] (Readme.yo.md)  
[! [zu] (https://img.shields.io/badge/lang-zu-amagbe.SVG)] (Readme.zu.md)

--- .

## 📖 Kpɔɖeŋu .

**Pyhelper** nye Python dɔwɔnu si woate ŋu azã le mɔ vovovowo nu si wowɔ be wòana **nyatakakawo me dzodzro, nukpɔkpɔ le susu me, akɔntabubu ƒe dɔwɔwɔwo, kple viɖekpɔkpɔ ƒe dɔwɔwɔwo** nanɔ bɔbɔe.  
Ewɔa ɖeka kple sukudede, numekuku, kple dɔnyala ƒe dɔwo nyuie, si wɔnɛ be nète ŋu léa fɔ ɖe gɔmesesewo ŋu tsɔ wu be nàtsɔ wò susu aɖo boilerplate code ŋu.

Viɖe Veviwo:
- 🧮 Wotu **Akɔntabubu kple Akɔntabubu ƒe Dɔwɔnuwo**
- 📊 Blewu zazã **Data Visualization Wrappers**
- 🗂 Asi **File Handling and Searching**
- 🔍 **Syntax ƒe kpeɖodzi** na python faɛlwo .
- 🌍 **Gbegbɔgblɔ ƒe kpekpeɖeŋunala geɖe** kple gɔmeɖeɖe siwo sɔ na zazã
- 🚀 Optimized na **Fast Prototyping** kple **Hehenana Taɖodzinuwo**

--- .

## ✨ Nɔnɔmewo .

### 📊 Nyatakakawo ƒe Nɔnɔmetatawo .
- Horizontal & Vertical bar charts (`Hbar`, `vbar`)
- Pie ƒe nɔnɔmetatawo (`pie`) .
- Aɖaka ƒe nɔnɔmetatawo (`Aɖaka me Nyawo`) .
- histogramwo (`Histo`) .
- Dzoxɔxɔ ƒe nɔnɔmetatawo (`Heatmap`)
- Nyatakakawo ƒe kplɔ̃wo (`Table`) .
- Nukpɔkpɔ deŋgɔwo (kaka, violin, KDE, pairplot, kple bubuawo)

### 📈 Akɔntabubuwo me dzodzro .
- Dzidzenu siwo le titina ƒe nɔnɔme ŋu:  
  `get_media`, `get_median`, `get_moda`
- Nuwo kaka ƒe dzidzenuwo:  
  `Get_rant`, `get_var`, `get_desv`, `disp`
- Nyatakakawo ƒe ɖoɖowɔwɔ ɖe ɖoɖo nu (`normalize`) .
- Outlier Detection (IQR & Z-Score Mɔnuwo)
- Nɔnɔme ƒe nyatakakawo ƒe tɔtrɔwo (`nɔnɔme`) .

### 🛠 Dɔwɔnu siwo wozãna .
- Faɛl didi kple agbatsɔtsɔ (`call`) .
- Enhanced **Trɔtrɔ / AsyncSwitch** ɖoɖo
- Nyagɔmeɖegbalẽ me dzodzro & numekuku (`pythonfilechecker`, `check_syntax`)
- Vodadawo ŋuti nyatakaka kple nya siwo ƒo xlãe .
- Kpekpeɖeŋunana ƒe ɖoɖo si wowɔ ɖekae (`kpekpeɖeŋu`, ŋgɔdonyawo, docs)

### 🌍 Gbegbɔgblɔ geɖe ƒe kpekpeɖeŋu .
- Gɔmeɖeɖe siwo wotu ɖe **12 gbegbɔgblɔwo me**
- Woate ŋu akeke ɖe enu kple `load_user_translations()`
- Tiatia si trɔna kple `set_language(lang_code)`
- Default fallback na Eŋlisigbe .

--- .

## 🚀 ƒe ɖoɖo .

Dee tso PYPI me:

```bash .
PIP De Pyhelper-Dɔwɔnuwo-JBHM .
```

--- .

## 🔧 Zãzã ƒe Kpɔɖeŋuwo .

### Ðo Gbegbɔgblɔ .
```Python .
tso kpeɖeŋutɔ import set_language .

set_language("en") # Eŋlisigbe
set_language("es") # Spaingbe
set_language("fr") # Fransegbe
set_language("de") # Germanygbe
set_language("ru") # Russiagbe
set_language("tr") # Turkeygbe .
set_language("zh") # Chinagbe
set_language("e") # Italygbe
Set_Language("Pt") # Portugalgbe
set_language("sv") # Swedengbe .
set_language("ja") # Japangbe
set_language("ar") # Arabgbe
# ... Kpekpeɖeŋu na gbegbɔgblɔ 100+ .
```

### Akɔntabubu veviwo .
```Python .
Import Helper abe HP ene .

Nyatakakawo = [1, 2, 2, 3, 4, 5].

Print(hp.get_media(nyatakakawo)) # mean
Print(hp.get_median(nyatakakawo)) # titina
Print(hp.get_moda(nyatakakawo)) # nɔnɔme
```

### Nukpɔkpɔ le nukpɔkpɔ me .
```Python .
Import Helper abe HP ene .
tso kpeɖeŋutɔ.submodules import graph abe GR ene .

df = hp.pd.dataframe ({"values": [5, 3, 7, 2, 9]})
Gr.Histo(df, "Asixɔxɔwo", Bins=5, Tanya="Kpɔɖeŋu Histogram")
```

### faɛlwo gbɔ kpɔkpɔ .
```Python .
Tso Helper Import Call dzi .

Data = call("my_data", type="csv") # Ke ɖe CSV faɛl aɖe ŋu eye wòdae ɖe eme le eɖokui si
```

### gɔmeɖeɖe siwo wowɔ ɖe ɖoɖo nu .
```Python .
Tso kpeɖeŋutɔ ƒe tsɔtsɔ yi teƒe bubu dzi la, import_user_translations .

# Agba ɖe gɔmeɖeɖe siwo wowɔ ɖe ɖoɖo nu tso lang.json gbɔ
load_user_gɔmeɖeɖewo ("kɔkɔe/lang.json")
```

--- .

## 📂 Dɔwɔwɔ ƒe ɖoɖo .

```
Kpekpeɖeŋunala/ .
 ├── Core.py # Dɔwɔwɔ veviwo .
 ├── Lang/ # Gbegɔmeɖeɖe ƒe faɛlwo (JSON)
 ├── Submodules/ .
 │ ├── Graph.PY # Nukpɔkpɔ ƒe Dɔwɔwɔwo
 │ ├── statics.py # Akɔntabubu ƒe dɔwɔwɔwo
 │ ├── Utils.py # Dɔwɔnu Kpekpeɖeŋunalawo
 └── __init__.py .
```

--- .

## 🤝 Nudzɔƒe

Woxɔa nudzɔdzɔwo nyuie!  
Taflatse ʋu nyawo, do susua ɖa be woawɔ ŋgɔyiyi, alo atsɔ hehe ƒe biabiawo aɖo ɖe [GitHub Repository](https://github.com/jbhmdev/pyhelper-tools).

--- .

## 📜 ƒe mɔɖegbalẽ .

Dɔ sia nye mɔɖegbalẽ le **mit mɔɖegbalẽ** te.  
Kpɔ [License](License) ƒe faɛl la hena numeɖeɖe tsitotsito.

--- .

⚡ Èle klalo be yeatsɔ **Pyhelper** aɖo wò Python dɔwɔwɔwo dzi? Dze numekuku gɔme egbea!