# Helperi raamatukogu

[! [Litsents: MIT] (https://img.shields.io/badge/license-mwel-ywellow.svg)]] (Litsents)  
[!.  

## 🌍 Saadaolevad keeled

[!  
[!.  
[!.  
[! [de] (https://img.shields.io/badge/lang-de-green.svg)] (readme.de.md)  
[! [ru] (https://img.shields.io/badge/lang-mu-purple.svg)] (readme.ru.md)  
[! [TR] (https://img.shields.io/badge/lang-tr-orange.svg)] (Readme.tr.md)  
[! [zh] (https://img.shields.io/badge/lang-zh-black.svg)] (readme.zh.md)  
[! [IT] (https://img.shields.io/badge/lang-it-lightgrey.svg)] (readme.it.md)  
[! [pt] (https://img.shields.io/badge/lang-pt-brightgreen.svg)] (Readme.pt.md)  
[! [SV] (https://img.shields.io/badge/lang-sv-blue.svg)] (readme.sv.md)  
[! [ja] (https://img.shields.io/badge/lang-ja-red.svg)] (Readme.ja.md)  
[! [ar] (https://img.shields.io/badge/lang-ar-brown.svg)] (Readme.ar.md)  
[!  
[! [SQ] (https://img.shields.io/badge/lang-sq-blue.svg)] (readme.sq.md)  
[! [Am] (https://img.shields.io/badge/lang-am-green.svg)] (readme.am.md)  
[! [Hy] (https://img.shields.io/badge/lang-hy-red.svg)] (Readme.hy.md)  
[! [As] (https://img.shields.io/badge/lang-as-purple.svg)] (readme.as.md)  
[! [ay] (https://img.shields.io/badge/lang-ay-brown.svg)] (readme.ay.md)  
[!.  
[! [BM] (https://img.shields.io/badge/lang-bm-darkgreen.svg)] (Readme.bm.md)  
[! [EU] (https://img.shields.io/badge/lang-eu-pink.svg)] (Readme.eu.md)  
[!  
[!  
[!  
[! [BS] (https://img.shields.io/badge/lang-bs-purple.svg)] (Readme.bm.md)  
[!  
[! [ca] (https://img.shields.io/badge/lang-ca-ywellow.svg)] (Readme.ca.md)  
[!  
[! [NY] (https://img.shields.io/badge/lang-ny-red.svg)] (readme.ny.md)  
[! [Co] (https://img.shields.io/badge/lang-co-green.svg)] (Readme.co.md)  
[! [hr] (https://img.shields.io/badge/lang-hr-blue.svg)] (Readme.hr.md)  
[! [CS] (https://img.shields.io/badge/lang-cs-red.svg)] (Readme.cs.md)  
[!.  
[!.  
[! [doi] (https://img.shields.io/badge/lang-do-brown.svg)] (Readme.doi.md)  
[! [nl] (https://img.shields.io/badge/lang-nl-orange.svg)] (readme.nl.md)  
[! [EO] (https://img.shields.io/badge/lang-eo-green.svg)] (Readme.eo.md)  
[! [et] (https://img.shields.io/badge/lang-et-blue.svg)] (Readme.et.md)  
[! [ee] (https://img.shields.io/badge/lang-ee-red.svg)] (readme.ee.md)  
[!.  
[! [fi] (https://img.shields.io/badge/lang-fi- blue.svg)] (Readme.fi.md)  
[! [FY] (https://img.shields.io/badge/lang-fy-orange.svg)] (Readme.fy.md)  
[! [GL] (https://img.shields.io/badge/lang-gl-green.svg)] (readme.gl.md)  
[! [Ka] (https://img.shields.io/badge/lang-ka-red.svg)] (Readme.ka.md)  
[! [El] (https://img.shields.io/badge/lang-el-blue.svg)] (readme.el.md)  
[! [Gn] (https://img.shields.io/badge/lang-gn-purple.svg)] (readme.gn.md)  
[! [Gu] (https://img.shields.io/badge/lang-gu-orange.svg)] (readme.gu.md)  
[! [ht] (https://img.shields.io/badge/lang-ht-green.svg)] (readme.ht.md)  
[! [ha] (https://img.shields.io/badge/lang-ha-blue.svg)] (Readme.ha.md)  
[! [Haw] (https://img.shields.io/badge/lang-haw-red.svg)] (Readme.haw.md)  
[! [iw] (https://img.shields.io/badge/lang-iw-purple.svg)] (readme.iw.md)  
[! [Tere] (https://img.shields.io/badge/lang-hi-orange.svg)] (Readme.hi.md)  
[! [hmn] (https://img.shields.io/badge/lang-hmn-green.svg)] (readme.hmn.md)  
[!.  
[! [on] (https://img.shields.io/badge/lang-is-red.svg)] (readme.is.md)  
[! [ig] (https://img.shields.io/badge/lang-ig-purple.svg)] (readme.ig.md)  
[! [ILO] (https://img.shields.io/badge/lang-ilo-orange.svg)] (readme.ilo.md)  
[! [id] (https://img.shields.io/badge/lang-id-green.svg)] (readme.id.md)  
[! [GA] (https://img.shields.io/badge/lang-ga-blue.svg)] (Readme.ga.md)  
[! [JW] (https://img.shields.io/badge/lang-jw-red.svg)] (readme.jw.md)  
[!.  
[! [KK] (https://img.shields.io/badge/lang-kk-orange.svg)] (Readme.KK.MD)

[! [KM] (https://img.shields.io/badge/lang-km-green.svg)] (Readme.km.md)  
[!.  
[! [GOM] (https://img.shields.io/badge/lang-gom-red.svg)] (Readme.gom.md)  
[! [Ko] (https://img.shields.io/badge/lang-ko-purple.svg)] (Readme.ko.md)  
[! [Kri] (https://img.shields.io/badge/lang-kri-orange.svg)] (readme.kri.md)  
[! [Ku] (https://img.shields.io/badge/lang-ku-green.svg)] (Readme.ku.md)  
[!.  
[! [KY] (https://img.shields.io/badge/lang-ky-red.svg)] (readme.ky.md)  
[!  
[!  
[! [lv] (https://img.shields.io/badge/lang-lv-green.svg)] (readme.lv.md)  
[! [ln] (https://img.shields.io/badge/lang-ln-blue.svg)] (readme.ln.md)  
[! [LT] (https://img.shields.io/badge/lang-lt-red.svg)] (Readme.lt.md)  
[! [LG] (https://img.shields.io/badge/lang-lg-purple.svg)] (readme.lg.md)  
[!.  
[!.  
[! [Mai] (https://img.shields.io/badge/lang-mai-blue.svg)] (Readme.mai.md)  
[! [MG] (https://img.shields.io/badge/lang-mg-red.svg)] (Readme.mg.md)  
[!.  
[! [ml] (https://img.shields.io/badge/lang-ml-orange.svg)] (Readme.ml.md)  
[! [MT] (https://img.shields.io/badge/lang-mt-green.svg)] (readme.mt.md)  
[!.  
[! [MR] (https://img.shields.io/badge/lang-mr-red.svg)] (Readme.mr.md)  
[! [Lus] (https://img.shields.io/badge/lang-lus-purple.svg)] (readme.lus.md)  
[! [Mn] (https://img.shields.io/badge/lang-mn-orange.svg)] (readme.mn.md)  
[! [minu] (https://img.shields.io/badge/lang-my-green.svg)] (readme.my.md)  
[! [NE] (https://img.shields.io/badge/lang-ne-blue.svg)] (readme.ne.md)  
[! [ei] (https://img.shields.io/badge/lang-no-red.svg)] (Readme.no.md)  
[!  
[! [om] (https://img.shields.io/badge/lang-om-orange.svg)] (readme.om.md)  
[! [PS] (https://img.shields.io/badge/lang-ps-green.svg)] (readme.ps.md)  
[! [FA] (https://img.shields.io/badge/lang-fa-blue.svg)] (Readme.fa.md)  
[! [qu] (https://img.shields.io/badge/lang-qu-red.svg)] (Readme.qu.md)  
[! [ro] (https://img.shields.io/badge/lang-ro-purple.svg)] (readme.ro.md)  
[! [SM] (https://img.shields.io/badge/lang-sm-orange.svg)] (Readme.sm.md)  
[! [sa] (https://img.shields.io/badge/lang-sa-a-green.svg)] (Readme.sa.md)  
[! [GD] (https://img.shields.io/badge/lang-gd-blue.svg)] (Readme.gd.md)  
[! [NSO] (https://img.shields.io/badge/lang-nso-red.svg)] (readme.nso.md)  
[!.  
[! [Sn] (https://img.shields.io/badge/lang-sn-orange.svg)] (Readme.sn.md)  
[! [SD] (https://img.shields.io/badge/lang-sd-green.svg)] (readme.sd.md)  
[!.  
[! [SK] (https://img.shields.io/badge/lang-sk-red.svg)] (Readme.sk.md)  
[! [Sl] (https://img.shields.io/badge/lang-sl-purple.svg)] (readme.sl.md)  
[! [So] (https://img.shields.io/badge/lang-so-orange.svg)] (Readme.so.md)  
[! [Su] (https://img.shields.io/badge/lang-su-green.svg)] (readme.su.md)  
[! [SW] (https://img.shields.io/badge/lang-sw-blue.svg)] (readme.sw.md)  
[! [TG] (https://img.shields.io/badge/lang-tg-red.svg)] (readme.tg.md)  
[!.  
[! [TT] (https://img.shields.io/badge/lang-tt-orange.svg)] (readme.tt.md)  
[! [te] (https://img.shields.io/badge/lang-te-green.svg)] (Readme.te.md)  
[! [Th] (https://img.shields.io/badge/lang-th-blue.svg)] (readme.th.md)  
[!.  
[! [TS] (https://img.shields.io/badge/lang-ts-purple.svg)] (readme.ts.md)  
[! [TK] (https://img.shields.io/badge/lang-tk-orange.svg)] (Readme.tk.md)  
[! [AK] (https://img.shields.io/badge/lang-ak-green.svg)] (readme.ak.md)  
[! [Suurbritannia] (https://img.shields.io/badge/lang-uk-blue.svg)] (readme.uk.md)  
[! [ur] (https://img.shields.io/badge/lang-ur-red.svg)] (readme.ur.md)  
[! [UG] (https://img.shields.io/badge/lang-ug-purple.svg)] (readme.ug.md)  
[! [Uz] (https://img.shields.io/badge/lang-uz-orange.svg)] (readme.uz.md)  
[! [VI] (https://img.shields.io/badge/lang-vi-green.svg)] (readme.vi.md)  
[!

[! [XH] (https://img.shields.io/badge/lang-xh-red.svg)] (readme.xh.md)  
[! [Yi] (https://img.shields.io/badge/lang-yi-purple.svg)] (Readme.yi.md)  
[!.  
[! [zu] (https://img.shields.io/badge/lang-zu-green.svg)] (Readme.zu.md)

---

## 📖 Ülevaade

** Pyhelper ** on mitmekülgne Pythoni tööriistakomplekt, mis on loodud ** andmete analüüsi, visualiseerimise, statistiliste toimingute ja kasulikkuse töövoogude lihtsustamiseks **.  
See integreerub sujuvalt akadeemilistesse, teadusuuringutesse ja professionaalsetesse projektidesse, võimaldades teil keskenduda teadmistele, mitte keetmiskoodile.

Peamised eelised:
- 🧮 sisseehitatud ** statistika ja matemaatika kommunaalteenused **
-📊 hõlpsasti kasutatav ** andmete visualiseerimise ümbrised **
- 🗂 käepärane ** failide käitlemine ja otsimine **
- 🔍 ** Pythoni failide süntaksi valideerimine **
-🌍 ** Mitmekeelse tugi ** koos kasutamiseks valmis tõlgetega
- 🚀 Optimeeritud ** kiireks prototüüpimiseks ** ja ** hariduslikes eesmärkides **

---

## ✨ funktsioonid

### 📊 Andmete visualiseerimine
- horisontaalsed ja vertikaalsed baaride diagrammid (`hbar`,` vbar`)
- Pie diagrammid ("Pie")
- Boxi proovitükid (`boxplot`)
- histogrammid (`histo`)
- Kuumakaart (`Heatmap`)
- Andmetabelid (`tabel`)
- Täiustatud visualiseerimised (hajumine, viiul, KDE, PaarPlot jne)

### 📈 Statistiline analüüs
- Keskmise tendentsi mõõtmed:  
  `get_media`,` get_median`, `get_moda`
- dispersioonimeetmed:  
  `get_rank`,` get_var`, `get_desv`,` disc`
- Andmete normaliseerimine ("normaliseeri")
- Välis tuvastamine (IQR & Z-Score meetodid)
- Tingimuslikud andmete teisendused ("tingimuslikud")

### 🛠 Utiliidid
- Faili avastamine ja laadimine (`Call`)
- täiustatud ** lüliti / asyncSwitch ** süsteem
- Süntaksi kontrollimine ja analüüs (`pythonfilechecker`,` check_syntax`)
- Vea teatamine kontekstiga
- Integreeritud abisüsteem (abi, eelvaated, dokumendid)

### 🌍 Mitmekeelne tugi
- sisseehitatud tõlked ** 12 keele jaoks **
- pikendatav koos `load_user_translations ()` abil
- dünaamiline valik `set_language (lang_code)`
- Inglise keelde vaikimisi tagasilöök

---

## 🚀 Installimine

Installige PYPI -st:

`` `bash
PIP installige pyhelper-tools-jbhm
`` `

---

## 🔧 Kasutusnäited

### Määrake keel
`` `Python
alates abistaja impordist set_language

set_language ("en") # inglise keel
set_language ("es") # hispaania keel
set_language ("fr") # prantsuse keel
set_language ("de") # saksa keel
set_language ("ru") # venelane
set_language ("tr") # türklane
set_language ("zh") # hiina
set_language ("it") # itaalia keel
set_language ("pt") # portugali keeles
set_language ("sv") # Rootsi
set_language ("ja") # jaapanlased
set_language ("ar") # araabia keel
# ... 100+ keele tugi
`` `

### Põhistatistika
`` `Python
impordi abistaja HP ​​-na

Andmed = [1, 2, 2, 3, 4, 5]

print (hp.get_media (andmed)) # keskmine
print (hp.get_median (andmed)) # mediaan
print (hp.get_moda (andmed)) # režiim
`` `

### visualiseerimine
`` `Python
impordi abistaja HP ​​-na
ettevõttelt abistaja.submodules impordi graafikuna grina

df = hp.pd.dataFrame ({"väärtused": [5, 3, 7, 2, 9]})
Gr.histo (DF, "väärtused", prügikast = 5, tiitel = "proovi histogramm")
`` `

### Faili käitlemine
`` `Python
abistaja impordi kõnest

Data = Call ("My_data", Type = "CSV") # leiab ja laadib CSV -faili automaatselt
`` `

### Kohandatud tõlked
`` `Python
Abiline impordist laadige_user_translations

# Laadige kohandatud tõlked Lang.json
load_user_translations ("custom/lang.json")
`` `

---

## 📂 Projekti struktuur

`` `
abistaja/
 ├── core.py # peamised funktsioonid
 ├── Lang/ # tõlkefailid (JSON)
 ├── alamoodulid/
 │ ├── graafik.py # visualiseerimisfunktsioonid
 │ ├── STATIKA.PY # Statistilised funktsioonid
 │ ├── utils.py # utiliidi abilised
 └── __init__.py
`` `

---

## 🤝 kaastööline

Kaastööd on teretulnud!  
Palun avage numbrid, soovitage parandusi või esitage tõmbetaotlusi [GitHubi hoidla] (https://github.com/jbhmdev/pyhelper-toools).

---

## 📜 Litsents

See projekt on litsentsitud ** MIT litsentsi alusel **.  
Lisateavet leiate failist [Litsentsi] (litsents).

---

⚡ Kas olete valmis oma pythoni töövoogude üle laadima ** pyhelper **? Alustage uurima juba täna!