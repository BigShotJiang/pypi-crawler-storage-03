DEFAULT_PPK_CONF = {
        "pos1-posmode": "kinematic",   # (0:single,1:dgps,2:kinematic,3:static,4:movingbase,5:fixed,6:ppp-kine,7:ppp-static,8:ppp-fixed)
        "pos1-frequency": "l1+2+3+4+5",   # (1:l1,2:l1+2,3:l1+2+3,4:l1+2+3+4,5:l1+2+3+4+5)
        "pos1-soltype": "combined",   # (0:forward,1:backward,2:combined)
        "pos1-elmask": "10",   # (deg)
        "pos1-snrmask_r": "off",   # (0:off,1:on)
        "pos1-snrmask_b": "off",   # (0:off,1:on)
        "pos1-snrmask_L1": "0,0,0,0,0,0,0,0,0",   #
        "pos1-snrmask_L2": "0,0,0,0,0,0,0,0,0",   #
        "pos1-snrmask_L5": "0,0,0,0,0,0,0,0,0",   #
        "pos1-dynamics": "off",   # (0:off,1:on)
        "pos1-tidecorr": "off",   # (0:off,1:on,2:otl)
        "pos1-ionoopt": "off",   # (0:off,1:brdc,2:sbas,3:dual-freq,4:est-stec,5:ionex-tec,6:qzs-brdc)
        "pos1-tropopt": "off",   # (0:off,1:saas,2:sbas,3:est-ztd,4:est-ztdgrad)
        "pos1-sateph": "precise",   # (0:brdc,1:precise,2:brdc+sbas,3:brdc+ssrapc,4:brdc+ssrcom)
        "pos1-posopt1": "off",   # (0:off,1:on)
        "pos1-posopt2": "off",   # (0:off,1:on)
        "pos1-posopt3": "off",   # (0:off,1:on,2:precise)
        "pos1-posopt4": "off",   # (0:off,1:on)
        "pos1-posopt5": "off",   # (0:off,1:on)
        "pos1-posopt6": "off",   # (0:off,1:on)
        "pos1-exclsats": "",   # (prn ...)
        "pos1-navsys": "127",   # (1:gps+2:sbas+4:glo+8:gal+16:qzs+32:bds+64:navic)
        "pos2-armode": "fix-and-hold",   # (0:off,1:continuous,2:instantaneous,3:fix-and-hold)
        "pos2-gloarmode": "on",   # (0:off,1:on)
        "pos2-bdsarmode": "on",   # (0:off,1:on)
        "pos2-arthres": "3",   #
        "pos2-arthres1": "0.9999",   #
        "pos2-arthres2": "0.25",   #
        "pos2-arthres3": "0.1",   #
        "pos2-arthres4": "0.05",   #
        "pos2-arlockcnt": "0",   #
        "pos2-arelmask": "0",   # (deg)
        "pos2-arminfix": "10",   #
        "pos2-armaxiter": "1",   #
        "pos2-elmaskhold": "0",   # (deg)
        "pos2-aroutcnt": "5",   #
        "pos2-maxage": "30",   # (s)
        "pos2-syncsol": "off",   # (0:off,1:on)
        "pos2-slipthres": "0.05",   # (m)
        "pos2-rejionno": "30",   # (m)
        "pos2-rejgdop": "30",   #
        "pos2-niter": "1",   #
        "pos2-baselen": "0",   # (m)
        "pos2-basesig": "0",   # (m)
        "out-solformat": "xyz",   # (0:llh,1:xyz,2:enu,3:nmea)
        "out-outhead": "on",   # (0:off,1:on)
        "out-outopt": "on",   # (0:off,1:on)
        "out-outvel": "off",   # (0:off,1:on)
        "out-timesys": "gpst",   # (0:gpst,1:utc,2:jst)
        "out-timeform": "tow",   # (0:tow,1:hms)
        "out-timendec": "6",   #
        "out-degform": "deg",   # (0:deg,1:dms)
        "out-fieldsep": "",   #
        "out-outsingle": "off",   # (0:off,1:on)
        "out-maxsolstd": "0",   # (m)
        "out-height": "ellipsoidal",   # (0:ellipsoidal,1:geodetic)
        "out-geoid": "internal",   # (0:internal,1:egm96,2:egm08_2.5,3:egm08_1,4:gsi2000)
        "out-solstatic": "all",   # (0:all,1:single)
        "out-nmeaintv1": "0",   # (s)
        "out-nmeaintv2": "0",   # (s)
        "out-outstat": "off",   # (0:off,1:state,2:residual)
        "stats-eratio1": "100",   #
        "stats-eratio2": "100",   #
        "stats-errphase": "0.003",   # (m)
        "stats-errphaseel": "0.003",   # (m)
        "stats-errphasebl": "0",   # (m/10km)
        "stats-errdoppler": "1",   # (Hz)
        "stats-stdbias": "30",   # (m)
        "stats-stdiono": "0.03",   # (m)
        "stats-stdtrop": "0.3",   # (m)
        "stats-prnaccelh": "10",   # (m/s^2)
        "stats-prnaccelv": "10",   # (m/s^2)
        "stats-prnbias": "0.0001",   # (m)
        "stats-prniono": "0.001",   # (m)
        "stats-prntrop": "0.0001",   # (m)
        "stats-prnpos": "0",   # (m)
        "stats-clkstab": "5e-12",   # (s/s)
        "ant1-postype": "llh",   # (0:llh,1:xyz,2:single,3:posfile,4:rinexhead,5:rtcm,6:raw)
        "ant1-pos1": "90",   # (deg|m)
        "ant1-pos2": "0",   # (deg|m)
        "ant1-pos3": "-6335367.6285",   # (m|m)
        "ant1-anttype": "",   #
        "ant1-antdele": "0",   # (m)
        "ant1-antdeln": "0",   # (m)
        "ant1-antdelu": "0",   # (m)
        "ant2-postype": "xyz",   # (0:llh,1:xyz,2:single,3:posfile,4:rinexhead,5:rtcm,6:raw)
        "ant2-pos1": "0",   #
        "ant2-pos2": "0",   # (deg|m)
        "ant2-pos3": "0",   # (m|m)
        "ant2-anttype": "",   #
        "ant2-antdele": "0",   # (m)
        "ant2-antdeln": "0",   # (m)
        "ant2-antdelu": "0",   # (m)
        "ant2-maxaveep": "0",   #
        "ant2-initrst": "off",   # (0:off,1:on)
        "misc-timeinterp": "off",   # (0:off,1:on)
        "misc-sbasatsel": "0",   # (0:all)
        "misc-rnxopt1": "",   #
        "misc-rnxopt2": "",   #
        "misc-pppopt": "",   #
        "file-satantfile": "",   #
        "file-rcvantfile": "",   #
        "file-staposfile": "",   #
        "file-geoidfile": "",   #
        "file-ionofile": "",   #
        "file-dcbfile": "",   #
        "file-eopfile": "",   #
        "file-blqfile": "",   #
        "file-tempdir": "",   #
        "file-geexefile": "",   #
        "file-solstatfile": "",   #
        "file-tracefile": "",   #

}

