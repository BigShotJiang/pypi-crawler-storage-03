# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
from django.contrib import admin

# Register your models here.
