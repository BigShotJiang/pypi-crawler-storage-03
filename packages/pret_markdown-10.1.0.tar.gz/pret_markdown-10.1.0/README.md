# pret-markdown

pret-markdown is a Markdown rendering component for [pret](https://github.com/percevalw/pret), based on [react-markdown](https://github.com/remarkjs/react-markdown/).
