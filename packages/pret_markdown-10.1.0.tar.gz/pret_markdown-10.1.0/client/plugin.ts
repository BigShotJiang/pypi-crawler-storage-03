// noinspection ES6UnusedImports
import './globals';
import "./index.css";

const plugin = {
    id: "pret-markdown:plugin", // app
    activate: () => null,
    autoStart: true,
};

export default plugin;
