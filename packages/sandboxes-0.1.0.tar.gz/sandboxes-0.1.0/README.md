# sandbox

## TODO

- Decide if we want to use the checksum thing for task ids
- Support zip files in the tasks client
- Cloud deployments
- CLI (jobs start and resume done)
- Map from old format to new
- Test if the registry actually works
- Create a BaseInstalledAgent interface
- Convert agents from terminal-bench repo
- Add logging
- Support docker compose in the env definition
