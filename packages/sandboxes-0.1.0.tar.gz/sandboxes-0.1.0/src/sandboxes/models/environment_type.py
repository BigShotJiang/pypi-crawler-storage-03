from enum import Enum


class EnvironmentType(str, Enum):
    DOCKER = "docker"
