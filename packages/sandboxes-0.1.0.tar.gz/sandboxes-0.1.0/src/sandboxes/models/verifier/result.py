from pydantic import BaseModel


class VerifierResult(BaseModel):
    reward: float | None
