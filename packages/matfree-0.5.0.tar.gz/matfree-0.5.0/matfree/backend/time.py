"""Timing."""

import time


def perf_counter():
    return time.perf_counter()
