class CommonApiUrl:
    pass
