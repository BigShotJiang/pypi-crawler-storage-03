from __future__ import annotations

__version__ = "0.19.6"
__supported_client_version__ = "0.19.6"
