


Run 'pip install -e .' in the local terminal to install the project.