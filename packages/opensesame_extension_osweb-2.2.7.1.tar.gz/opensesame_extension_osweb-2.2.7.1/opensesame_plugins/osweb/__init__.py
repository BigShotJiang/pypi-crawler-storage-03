"""Plugins to integrate OSWeb into OpenSesame"""
