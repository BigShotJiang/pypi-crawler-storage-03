<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="28" />
        <source>Experiment started in external browser</source>
        <translation>Expérience commencée dans un navigateur externe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Save as…</source>
        <translation>Enregistrer sous..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>OSWeb and JATOS control panel</source>
        <translation>Panneau de contrôle OSWeb et JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Create online experiments</source>
        <translation>Créer des expériences en ligne</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Open from MindProbe</source>
        <translation>Ouvrir de MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Open from JATOS</source>
        <translation>Ouvrir de JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="29" />
        <source>Open</source>
        <translation>Ouvrir</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Experiment has been published to JATOS</source>
        <translation>L'expérience a été publiée sur JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="30" />
        <source>Select OSWeb results file…</source>
        <translation>Sélectionnez le fichier de résultats OSWeb…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Browse</source>
        <translation>Parcourir</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>You have changed the name of the experiment. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Vous avez changé le nom de l'expérience. Voulez-vous également dissocier l'expérience de JATOS (en réinitialisant l'UUID) afin que vous puissiez créer une nouvelle expérience à distance ?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Save and publish to JATOS</source>
        <translation>Enregistrer et publier sur JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Unlink from JATOS</source>
        <translation>Dissocier de JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Save and publish to MindProbe</source>
        <translation>Enregistrer et publier sur MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>You have saved the experiment under a different file name. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Vous avez enregistré l'expérience sous un autre nom de fichier. Voulez-vous également dissocier l'expérience de JATOS (en réinitialisant l'UUID) afin de pouvoir créer une nouvelle expérience à distance ?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Downloading …</source>
        <translation>Téléchargement ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Uploading …</source>
        <translation>Téléversement ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Hide</source>
        <translation>Cacher</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="31" />
        <source>Please wait …</source>
        <translation>Veuillez patienter ..</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>ICÔNE</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="136" />
        <source>Actions</source>
        <translation>Actions</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="181" />
        <source>Experiment properties</source>
        <translation>Propriétés de l'expérience</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="199" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Sélectionnez le backend OSWeb pour exécuter dans le navigateur&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="215" />
        <source>Open from JATOS</source>
        <translation>Ouvrir de JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="227" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Téléchargez l'expérience directement depuis JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="265" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>Convertir les résultats OSWeb en .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="277" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Convertissez le fichier de résultats JATOS en format de feuille de calcul&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="305" />
        <source>Import from JATOS archive</source>
        <translation>Importer depuis l'archive JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="318" />
        <source>Export to JATOS archive</source>
        <translation>Exporter vers l'archive JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="331" />
        <source>Export to HTML</source>
        <translation>Exporter en HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="343" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Ouvrir l'expérience à partir du fichier jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="355" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Enregistrez l'expérience en tant que fichier jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="367" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Enregistrez l'expérience en tant que fichier html autonome&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;OSWeb et panneau de contrôle JATOS&lt;/b&gt;&lt;br /&gt;Options pour les expériences en ligne et la synchronisation JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="240" />
        <source>Save and publish to JATOS</source>
        <translation>Enregistrer et publier sur JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="252" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Save experiment and upload directly to JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size :small ; color :#78909c ;"&gt;Enregistrez l'expérience et téléchargez-la directement sur JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="126" />
        <source>&lt;h2 style="color:#78909c"&gt;To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color :#78909c"&gt;Pour publier des expériences directement à JATOS, veuillez spécifier un serveur et un jeton API ci-dessous&lt;/h2&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Embeds custom HTML</source>
        <translation>Intègre HTML personnalisé</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>An HTML editor widget</source>
        <translation>Un widget d'éditeur HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>HTML editor</source>
        <translation>Éditeur HTML</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Executes JavaScript code</source>
        <translation>Exécute le code JavaScript</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>Numéros de sujet possibles</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Exécutez l'expérience même si la vérification de compatibilité échoue&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Apparaît sur l'écran d'accueil OSWeb.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>Afficher l'écran de bienvenue OSWeb</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Chargé lorsque l'expérience commence&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>Contourner la vérification de compatibilité</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>Texte de bienvenue</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;S'applique uniquement lors de l'exportation&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>Ne fournissez jamais d'informations personnelles ou sensibles telles que des numéros de carte de crédit ou des codes PIN. Cliquez ou touchez l'écran pour commencer !</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>Une URL par ligne</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>Bibliothèques externes</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Requis pour une lecture média fiable&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>Rendre le navigateur plein écran</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="305" />
        <source>JATOS UUID</source>
        <translation>JATOS UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="415" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Visitez &lt;a href="https ://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; pour demander un compte gratuit&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="387" />
        <source>JATOS server</source>
        <translation>Serveur JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="435" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="403" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https ://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="330" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Identifie l'expérience sur JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="318" />
        <source>undefined</source>
        <translation>indéfini</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="422" />
        <source>JATOS API token</source>
        <translation>Token API JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="447" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Disponible depuis le profil utilisateur de JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="337" />
        <source>Clear UUID</source>
        <translation>Effacer l'UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="353" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Réinitialise le lien entre l'expérience et JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>Appliquer la couleur d'arrière-plan à l'onglet du navigateur entier</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="460" />
        <source>Ignore conflicts</source>
        <translation>Ignorer les conflits</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="472" />
        <source>&lt;small  style="color:#78909c"&gt;Overwrites conflicting files when publishing. This option is automatically reset.&lt;/small&gt;</source>
        <translation>&lt;small style="color :#78909c"&gt;Ecrase les fichiers conflictuels lors de la publication. Cette option est automatiquement réinitialisée.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb: Configure how the experiment runs in the browser</source>
        <translation>OSWeb : Configurez comment l'expérience s'exécute dans le navigateur</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small  style="color :#78909c"&gt;OSWeb est une bibliothèque JavaScript permettant d'exécuter des expériences OpenSesame dans un navigateur Web.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS: Configure experiment properties on the server</source>
        <translation>JATOS : Configurez les propriétés de l'expérience sur le serveur</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279" />
        <source>JATOS end-redirect URL</source>
        <translation>URL de redirection de fin de JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="286" />
        <source>https://</source>
        <translation>https ://</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="298" />
        <source>&lt;small  style="color:#78909c"&gt;Notifies participant platform (Sona Systems, Prolific, etc.) when experiment finishes&lt;/small&gt;</source>
        <translation>&lt;small  style="color :#78909c"&gt;Informe la plateforme de participants (Sona Systems, Prolific, etc.) lorsque l'expérience se termine&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="369" />
        <source>JATOS: Configure the server</source>
        <translation>JATOS : Configurez le serveur</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="484" />
        <source>&lt;small  style="color:#78909c"&gt;JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small  style="color :#78909c"&gt;JATOS est un logiciel serveur pour gérer des expériences en ligne. Vous avez besoin d'un compte sur un serveur JATOS, tel que mindprobe.eu, pour réaliser des expériences en ligne. Vous devez entrer un jeton API JATOS pour connecter OpenSesame à JATOS. Consultez la documentation d'OpenSesame pour les instructions.&lt;/small&gt;</translation>
    </message>
</context>
</TS>