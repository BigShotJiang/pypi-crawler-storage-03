# License

ArchiPy is licensed under the terms of the license file included in the repository.

For more details, see the [LICENSE](https://github.com/SyntaxArc/ArchiPy/blob/master/LICENSE) file.
