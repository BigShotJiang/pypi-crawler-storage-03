BASE_URL_CN = "http://47.117.133.51:30015"
BASE_URL_GLOBAL = "https://api.justoneapi.com"