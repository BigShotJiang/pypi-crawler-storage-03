Shows the equipment's warranty information in the helpdesk ticket.
