# A span attributes that if is set to True, the span will not be exported
SKIP_EXPORT_SPAN_ATTRIBUTE = "SKIP_EXPORT"
