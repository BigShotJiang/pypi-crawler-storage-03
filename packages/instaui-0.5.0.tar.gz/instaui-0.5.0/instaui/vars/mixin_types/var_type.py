from abc import ABC


class VarMixin(ABC):
    pass
