class _MissingType:
    def __repr__(self):
        return "<MISSING>"


MISSING = _MissingType()
TMissing = _MissingType
