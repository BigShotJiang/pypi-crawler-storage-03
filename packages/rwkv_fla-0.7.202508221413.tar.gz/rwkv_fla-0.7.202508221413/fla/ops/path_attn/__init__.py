# -*- coding: utf-8 -*-

from .parallel import parallel_path_attention

__all__ = [
    'parallel_path_attention'
]
