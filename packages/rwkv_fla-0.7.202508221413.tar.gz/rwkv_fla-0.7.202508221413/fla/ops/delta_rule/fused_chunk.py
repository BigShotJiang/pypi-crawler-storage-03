# -*- coding: utf-8 -*-

def fused_chunk_delta_rule(
    **kwargs
):
    raise NotImplementedError("fused_chunk_delta_rule is deprecated. Please use chunk_delta_rule instead.")
