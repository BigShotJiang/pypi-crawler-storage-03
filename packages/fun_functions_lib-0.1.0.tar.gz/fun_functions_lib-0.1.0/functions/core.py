def hello(name):
    return f"hello, {name}!"