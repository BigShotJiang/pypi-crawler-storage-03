#!/usr/bin/env python3
"""Setup script for latent-watermark package."""

from setuptools import setup

setup()