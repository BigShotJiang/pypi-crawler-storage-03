"""Looker action for Concordia CLI."""

from .generate import generate_lookml

__all__ = ["generate_lookml"]
