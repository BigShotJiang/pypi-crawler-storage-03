Future work
===========

.. |check_| raw:: html

    <input checked=""  disabled="" type="checkbox">

.. |uncheck_| raw:: html

    <input disabled="" type="checkbox">


.. todo::
    This section is still under development.


.. 
    |uncheck_| Blablablabla

.. 
    |check_| pgsoirgsr