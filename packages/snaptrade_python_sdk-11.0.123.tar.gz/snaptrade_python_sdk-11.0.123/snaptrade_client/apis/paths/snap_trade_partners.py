from snaptrade_client.paths.snap_trade_partners.get import ApiForget


class SnapTradePartners(
    ApiForget,
):
    pass
