from snaptrade_client.paths.trade_trade_id.post import ApiForpost


class TradeTradeId(
    ApiForpost,
):
    pass
