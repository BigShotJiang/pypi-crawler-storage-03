from snaptrade_client.paths.accounts_account_id_recent_orders.get import ApiForget


class AccountsAccountIdRecentOrders(
    ApiForget,
):
    pass
