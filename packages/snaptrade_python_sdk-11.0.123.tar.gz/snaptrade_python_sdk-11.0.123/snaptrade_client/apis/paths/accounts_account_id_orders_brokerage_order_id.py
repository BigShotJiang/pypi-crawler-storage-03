from snaptrade_client.paths.accounts_account_id_orders_brokerage_order_id.get import ApiForget


class AccountsAccountIdOrdersBrokerageOrderId(
    ApiForget,
):
    pass
