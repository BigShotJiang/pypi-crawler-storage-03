# plugin-python

Python SDK to write plugins for [ganvil](https://codeberg.org/ganvil/ganvil).

Take a look at the [examples](./examples) and the [documentation](https://ganvil.readthedocs.io/en/stable/reference/task/plugins/) to get started.
