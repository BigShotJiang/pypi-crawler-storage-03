This module is an add-on for the Field Service application in Odoo. It
provides stock requests in field service orders.
