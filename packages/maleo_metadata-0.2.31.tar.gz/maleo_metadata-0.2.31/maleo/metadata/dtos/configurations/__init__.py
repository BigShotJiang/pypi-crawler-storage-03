from maleo.soma.dtos.configurations import ConfigurationDTO as BaseConfigurationDTO


class ConfigurationDTO(BaseConfigurationDTO[None, None, None]):
    pass
