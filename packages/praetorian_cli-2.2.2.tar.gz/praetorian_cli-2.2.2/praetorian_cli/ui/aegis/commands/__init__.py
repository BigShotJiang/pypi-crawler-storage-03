"""Command handlers for Aegis TUI."""

