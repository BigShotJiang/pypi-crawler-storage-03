"""Aegis interactive console (TUI) package."""

from .menu import run_aegis_menu, AegisMenu  # re-export for convenience


