from .document import Document, DocumentCreationMode
