# ASCII brand alias CLI for `siper`
from güvenlik.cli import main  # reuse original CLI implementation

if __name__ == "__main__":
    raise SystemExit(main())
