# Alias middleware package for Siper -> re-export güvenlik.middleware
from importlib import import_module as _im
_mod = _im('güvenlik.middleware')
fastapi = _im('güvenlik.middleware.fastapi')
flask = _im('güvenlik.middleware.flask')
__all__ = ['fastapi', 'flask']
