# ASCII brand alias for guard module
from importlib import import_module as _im
_mod = _im('güvenlik.guard')

komut_gecir = _mod.komut_gecir
komut_saglandi_mi = _mod.komut_saglandi_mi
dogrula_komut = _mod.dogrula_komut

__all__ = ['komut_gecir', 'komut_saglandi_mi', 'dogrula_komut']
