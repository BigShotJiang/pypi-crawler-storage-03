# Alias metrics module for Siper
from güvenlik.utils.metrics import *  # noqa
