# ASCII brand alias for `siper.utils` -> re-export `güvenlik.utils`
from importlib import import_module as _im
_mod = _im('güvenlik.utils')
__all__ = getattr(_mod, '__all__', [])
