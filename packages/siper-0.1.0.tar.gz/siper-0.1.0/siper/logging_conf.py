# Alias logging configuration for Siper
from güvenlik.logging_conf import *  # noqa
