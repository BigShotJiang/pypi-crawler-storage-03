# ASCII alias subpackage for `güvenlik.storage`
from importlib import import_module as _im
_mod = _im('güvenlik.storage')
__all__ = getattr(_mod, '__all__', [])
