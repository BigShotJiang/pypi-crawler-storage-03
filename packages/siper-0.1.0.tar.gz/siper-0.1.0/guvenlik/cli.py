from güvenlik.cli import main  # re-export for ASCII alias

if __name__ == "__main__":
    raise SystemExit(main())
