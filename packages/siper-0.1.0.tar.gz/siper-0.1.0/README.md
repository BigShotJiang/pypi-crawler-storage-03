# Siper — Türkçe API'li Güvenlik Duvarı Kütüphanesi

Modern, genişletilebilir ve performans odaklı bir güvenlik duvarı kütüphanesi.
Türkçe ve ASCII dostu API. JSON konfig, kural önceliği, karar önbelleği,
olay aboneliği (audit), gelişmiş filtreler, CLI ve middleware desteği.

## Kurulum

Kaynak koddan (yerel):

```bash
python -m pip install .
```

CLI komutu: `siper` (eski alias: `guvenlik`)

## Hızlı Başlangıç

```python
from siper import GuvenlikDuvari, Kural
from siper.filters import IPFiltre
from siper.guard import komut_gecir

komut_gecir("cyhperinios")
fw = GuvenlikDuvari(varsayilan="blok")
fw.kural_ekle(Kural([IPFiltre(izinli=["127.0.0.1"])], eylem="izin", ad="lokal"))

sonuc = fw.degerlendir(ip="127.0.0.1", port=80, protokol="TCP", yol="/", ek={"yontem": "GET"})
print(sonuc.eylem)  # izin
```

## JSON Konfig ile Kullanım

`ayar.json`
```json
{
  "varsayilan": "blok",
  "kurallar": [
    {
      "ad": "lokal",
      "eylem": "izin",
      "oncelik": 10,
      "durdur": true,
      "filtreler": [
        {"tip": "CIDRIPFiltre", "izinli": ["127.0.0.0/8"]}
      ]
    }
  ]
}
```

CLI:
```bash
siper cyhperinios --json-dosya ayar.json --test
# alias: guvenlik cyhperinios --json-dosya ayar.json --test
```

## Başlıca Özellikler

- Kural motoru: öncelik, durdur, ad, ayrıntılı `Sonuc` açıklamaları
- Filtreler: IP/CIDR, port/port aralığı, protokol, HTTP yöntem/yol glob
- Regex tabanlı denetimler: başlık/param/gövde (WAF için temel yapıtaşları)
- Hız sınırlandırma: sliding window ve Token Bucket (burst destekli)
- Bileşik filtreler: Ve/YaDa/Değil
- Karar önbelleği (TTL + LRU)
- Olay aboneliği (audit + JSON log)
- Middleware: FastAPI ve Flask
- CLI: JSON’dan yükle, test et

## Middleware Örnekleri

FastAPI:
```python
from fastapi import FastAPI
from siper.middleware.fastapi import GuvenlikFastAPIMiddleware
from siper import GuvenlikDuvari
from siper.guard import komut_gecir

komut_gecir("cyhperinios")
fw = GuvenlikDuvari(varsayilan="blok")
app = FastAPI()
app.add_middleware(GuvenlikFastAPIMiddleware, guard=fw)
```

Flask:
```python
from flask import Flask
from siper.middleware.flask import guvenlik_flask_middleware
from siper import GuvenlikDuvari
from siper.guard import komut_gecir

komut_gecir("cyhperinios")
fw = GuvenlikDuvari(varsayilan="blok")
app = Flask(__name__)
guvenlik_flask_middleware(app, fw)
```

## Gelişmiş Log ve Metrikler

```python
from siper.logging_conf import kur_json_logger, olay_gunluk_abonesi
from siper.utils.metrics import PrometheusAbone

logger = kur_json_logger()
fw.abone_ekle(olay_gunluk_abonesi(logger))
fw.abone_ekle(PrometheusAbone(prefix="siper"))
```

Prometheus desteği opsiyoneldir: `pip install prometheus-client`

## Güvenlik Notu — Komut Kapısı

Kütüphane, çalışmadan önce gizli komut ister:
```python
from siper.guard import komut_gecir
komut_gecir("cyhperinios")
```
`config.yukle*` fonksiyonlarında da doğrulama zorunludur.

## Lisans

MIT
