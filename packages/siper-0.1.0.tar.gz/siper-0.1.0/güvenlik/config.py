"""
Sozluk/JSON uzerinden kural yukleyici.

Ornek JSON:
{
  "varsayilan": "izin",
  "kurallar": [
    {
      "ad": "lokal",
      "eylem": "izin",
      "oncelik": 10,
      "durdur": true,
      "filtreler": [
        {"tip": "IPFiltre", "izinli": ["127.0.0.1"]}
      ]
    }
  ]
}
"""

from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List

from .rules import Kural
from .firewall import GuvenlikDuvari
from .guard import dogrula_komut

# Filtre adlari -> siniflar
from .filters import ip_filter, port_filter, protocol_filter, rate_limiter
from .filters import cidr_ip_filter, port_range_filter, http_filter, composite
from .filters import regex_filter, token_bucket

_FILRE_HARITASI = {
    "IPFiltre": ip_filter.IPFiltre,
    "PortFiltre": port_filter.PortFiltre,
    "ProtokolFiltre": protocol_filter.ProtokolFiltre,
    "HizSinirlayici": rate_limiter.HizSinirlayici,
    "CIDRIPFiltre": cidr_ip_filter.CIDRIPFiltre,
    "PortAralikFiltre": port_range_filter.PortAralikFiltre,
    "YontemFiltre": http_filter.YontemFiltre,
    "YolGlobFiltre": http_filter.YolGlobFiltre,
    "VeFiltre": composite.VeFiltre,
    "YaDaFiltre": composite.YaDaFiltre,
    "DegilFiltre": composite.DegilFiltre,
    "BaslikRegexFiltre": regex_filter.BaslikRegexFiltre,
    "ParamRegexFiltre": regex_filter.ParamRegexFiltre,
    "GovdeRegexFiltre": regex_filter.GovdeRegexFiltre,
    "TokenKovaSinirlayici": token_bucket.TokenKovaSinirlayici,
}


def _filtre_yap(f_tanim: Dict[str, Any]):
    tip = f_tanim.get("tip")
    if tip not in _FILRE_HARITASI:
        raise ValueError(f"Bilinmeyen filtre tipi: {tip}")
    cls = _FILRE_HARITASI[tip]
    params = {k: v for k, v in f_tanim.items() if k != "tip"}
    return cls(**params)


def kural_from_dict(d: Dict[str, Any]) -> Kural:
    filtreler = [_filtre_yap(ft) for ft in d.get("filtreler", [])]
    return Kural(
        filtreler=filtreler,
        eylem=d.get("eylem", "blok"),
        aciklama=d.get("aciklama"),
        oncelik=d.get("oncelik", 100),
        durdur=d.get("durdur", True),
        ad=d.get("ad"),
    )


def yukle(ayar: Dict[str, Any]) -> GuvenlikDuvari:
    dogrula_komut()
    fw = GuvenlikDuvari(varsayilan=ayar.get("varsayilan", "izin"))
    for kd in ayar.get("kurallar", []):
        fw.kural_ekle(kural_from_dict(kd))
    return fw


def yukle_json_str(json_metin: str) -> GuvenlikDuvari:
    dogrula_komut()
    return yukle(json.loads(json_metin))


def yukle_json_dosya(dosya_yolu: str) -> GuvenlikDuvari:
    dogrula_komut()
    with open(dosya_yolu, "r", encoding="utf-8") as f:
        data = json.load(f)
    return yukle(data)
