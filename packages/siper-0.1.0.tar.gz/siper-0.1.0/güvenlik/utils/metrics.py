from __future__ import annotations

from typing import Callable, Dict

try:
    from prometheus_client import Counter
except Exception:  # optional
    Counter = None  # type: ignore


class PrometheusAbone:
    def __init__(self, prefix: str = "guvenlik"):
        if Counter is None:
            self._enabled = False
            return
        self._enabled = True
        self.karar = Counter(f"{prefix}_karar_toplam", "Verilen karar sayisi", ["eylem"])  # izin/blok
        self.kural = Counter(f"{prefix}_kural_isabet", "Kural isabetleri", ["kural"])
        self.cache = Counter(f"{prefix}_cache", "Onbellek istatistikleri", ["olay"])  # hit/miss

    def __call__(self, sonuc: "Sonuc"):
        if not self._enabled:
            return
        self.karar.labels(sonuc.eylem).inc()
        if sonuc.kural and getattr(sonuc.kural, "ad", None):
            self.kural.labels(sonuc.kural.ad).inc()


def onbellek_abone(prefix: str = "guvenlik"):
    if Counter is None:
        return lambda *a, **k: None
    c = Counter(f"{prefix}_cache", "Onbellek istatistikleri", ["olay"])  # hit/miss
    def _abone(olay: str):  # olay: "hit"/"miss"
        c.labels(olay).inc()
    return _abone
