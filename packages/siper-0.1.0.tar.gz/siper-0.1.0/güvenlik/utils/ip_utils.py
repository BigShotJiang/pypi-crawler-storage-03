def ip_normalize(ip: str | None) -> str:
    return (ip or "").strip()
