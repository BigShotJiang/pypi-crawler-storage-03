from typing import Iterable, List


class Kural:
    """
    Basit kural: tum filtreler True doneyince kural eslesir.
    """

    def __init__(self, filtreler: Iterable, eylem: str = "blok", aciklama: str | None = None,
                 oncelik: int = 100, durdur: bool = True, ad: str | None = None):
        from .validators import eylem_dogrula
        self.filtreler: List = list(filtreler)
        self.eylem = eylem_dogrula(eylem)
        self.aciklama = aciklama or ""
        self.oncelik = int(oncelik)
        self.durdur = bool(durdur)
        self.ad = ad or ""

    def eslesir_mi(self, istek: "Istek") -> bool:
        return all(f.eslesir_mi(istek) for f in self.filtreler)

    def __repr__(self) -> str:
        parca = self.ad or self.aciklama or "kural"
        return f"<Kural {parca!r} eylem={self.eylem} oncelik={self.oncelik} durdur={self.durdur}>"
