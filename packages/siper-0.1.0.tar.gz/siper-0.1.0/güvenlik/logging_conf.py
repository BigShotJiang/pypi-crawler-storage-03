"""
JSON log ayarlari ve olay aboneligi icin yardimcilar.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Callable


def _json_formatter(record: logging.LogRecord) -> str:
    payload = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "seviye": record.levelname,
        "logger": record.name,
        "mesaj": record.getMessage(),
    }
    if isinstance(record.args, dict):
        payload.update(record.args)
    return json.dumps(payload, ensure_ascii=False)


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return _json_formatter(record)


def kur_json_logger(logger_adi: str = "guvenlik", seviye: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(logger_adi)
    if not logger.handlers:
        h = logging.StreamHandler()
        h.setFormatter(JSONFormatter())
        logger.addHandler(h)
    logger.setLevel(seviye)
    logger.propagate = False
    return logger


def olay_gunluk_abonesi(logger: logging.Logger) -> Callable:
    """GuvenlikDuvari.abone_ekle icin abonelik fonksiyonu uretir."""
    def _abonelik(istek, sonuc):
        logger.info(
            "degerlendirme",
            {
                "eylem": sonuc.eylem,
                "varsayilan": sonuc.varsayilan_mi,
                "kural": getattr(sonuc.kural, "ad", None) or getattr(sonuc.kural, "aciklama", None),
                "nedenler": sonuc.nedenler,
                "istek": {
                    "ip": istek.ip,
                    "port": istek.port,
                    "protokol": istek.protokol,
                    "yol": istek.yol,
                },
            },
        )
    return _abonelik
