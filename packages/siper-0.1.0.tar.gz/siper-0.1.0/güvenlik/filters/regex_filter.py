import re
from typing import Dict, Iterable, Pattern


class BaslikRegexFiltre:
    """HTTP basliklarinda regex eslestirme. istek.ek['basliklar'] sozlugu bekler."""

    def __init__(self, kurallar: Dict[str, Iterable[str]]):
        # {"Header-Name": ["^re1$", "re2"]}
        self.kurallar: Dict[str, Iterable[Pattern[str]]] = {
            k.lower(): [re.compile(p) for p in (v or [])] for k, v in (kurallar or {}).items()
        }

    def eslesir_mi(self, istek: "Istek"):
        headers = ((istek.ek or {}).get("basliklar") or {})
        for ad, desenler in self.kurallar.items():
            deger = None
            for k, v in headers.items():
                if k.lower() == ad:
                    deger = v
                    break
            if deger is None:
                return (False, f"baslik yok: {ad}")
            if not any(d.search(str(deger)) for d in desenler):
                return (False, f"baslik eslesmedi: {ad}")
        return (True, "baslik regex uyumlu")


class ParamRegexFiltre:
    """Sorgu/parametrelerde regex eslestirme. istek.ek['param'] sozlugu bekler."""

    def __init__(self, kurallar: Dict[str, Iterable[str]]):
        self.kurallar: Dict[str, Iterable[Pattern[str]]] = {
            k: [re.compile(p) for p in (v or [])] for k, v in (kurallar or {}).items()
        }

    def eslesir_mi(self, istek: "Istek"):
        params = ((istek.ek or {}).get("param") or {})
        for ad, desenler in self.kurallar.items():
            deger = params.get(ad)
            if deger is None:
                return (False, f"param yok: {ad}")
            if not any(d.search(str(deger)) for d in desenler):
                return (False, f"param eslesmedi: {ad}")
        return (True, "param regex uyumlu")


class GovdeRegexFiltre:
    """Govde (body) icin regex eslestirme. istek.ek['govde'] metni bekler."""

    def __init__(self, desenler: Iterable[str]):
        self.desenler = [re.compile(p) for p in (desenler or [])]

    def eslesir_mi(self, istek: "Istek"):
        body = ((istek.ek or {}).get("govde") or "")
        ok = all(d.search(str(body)) for d in self.desenler)
        return (ok, "govde regex uyumlu" if ok else "govde regex uyumsuz")
