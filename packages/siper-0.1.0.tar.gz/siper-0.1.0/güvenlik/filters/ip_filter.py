from typing import Iterable


class IPFiltre:
    """IP adreslerini izinli/engelli listesi ile eslestirir."""

    def __init__(self, izinli: Iterable[str] | None = None, engelli: Iterable[str] | None = None):
        self.izinli = set(izinli or [])
        self.engelli = set(engelli or [])

    def eslesir_mi(self, istek: "Istek") -> bool:
        ip = (istek.ip or "").strip()
        if self.izinli and ip not in self.izinli:
            return False
        if self.engelli and ip in self.engelli:
            return False
        return True
