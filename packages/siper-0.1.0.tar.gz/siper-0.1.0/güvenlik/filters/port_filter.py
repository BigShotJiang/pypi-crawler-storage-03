from typing import Iterable


class PortFiltre:
    def __init__(self, izinli: Iterable[int] | None = None, engelli: Iterable[int] | None = None):
        self.izinli = set(izinli or [])
        self.engelli = set(engelli or [])

    def eslesir_mi(self, istek: "Istek") -> bool:
        port = istek.port
        if port is None:
            return False if self.izinli else True
        if self.izinli and port not in self.izinli:
            return False
        if self.engelli and port in self.engelli:
            return False
        return True
