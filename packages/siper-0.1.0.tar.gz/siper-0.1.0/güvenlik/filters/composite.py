from typing import Iterable, Tuple, Optional


def _calistir(filtre, istek) -> Tuple[bool, Optional[str]]:
    s = filtre.eslesir_mi(istek)
    if isinstance(s, tuple) and len(s) == 2:
        return bool(s[0]), s[1]
    return bool(s), None


class VeFiltre:
    def __init__(self, filtreler: Iterable):
        self.filtreler = list(filtreler)

    def eslesir_mi(self, istek: "Istek"):
        nedenler = []
        for f in self.filtreler:
            ok, neden = _calistir(f, istek)
            if not ok:
                return (False, "ve kosulu saglanmadi")
            if neden:
                nedenler.append(neden)
        return (True, "; ".join(nedenler) if nedenler else "ve kosulu tamam")


class YaDaFiltre:
    def __init__(self, filtreler: Iterable):
        self.filtreler = list(filtreler)

    def eslesir_mi(self, istek: "Istek"):
        nedenler = []
        for f in self.filtreler:
            ok, neden = _calistir(f, istek)
            if ok:
                return (True, neden or "yada kosulu saglandi")
            if neden:
                nedenler.append(neden)
        return (False, "; ".join(nedenler) if nedenler else "hicbiri saglanmadi")


class DegilFiltre:
    def __init__(self, filtre):
        self.filtre = filtre

    def eslesir_mi(self, istek: "Istek"):
        ok, neden = _calistir(self.filtre, istek)
        return (not ok, f"degil: {neden}" if neden else "degil")
