import fnmatch
from typing import Iterable


class YontemFiltre:
    def __init__(self, izinli: Iterable[str] | None = None, engelli: Iterable[str] | None = None):
        self.izinli = {m.upper() for m in (izinli or [])}
        self.engelli = {m.upper() for m in (engelli or [])}

    def eslesir_mi(self, istek: "Istek"):
        m = (istek.ek or {}).get("yontem", "").upper()
        if self.izinli and m not in self.izinli:
            return (False, "yontem izinli degil")
        if self.engelli and m in self.engelli:
            return (False, "yontem engelli")
        return (True, "yontem uyumlu")


class YolGlobFiltre:
    def __init__(self, desenler: Iterable[str]):
        self.desenler = list(desenler or ["*"])

    def eslesir_mi(self, istek: "Istek"):
        yol = istek.yol or ""
        ok = any(fnmatch.fnmatch(yol, d) for d in self.desenler)
        return (ok, "yol eslesiyor" if ok else "yol eslesmiyor")
