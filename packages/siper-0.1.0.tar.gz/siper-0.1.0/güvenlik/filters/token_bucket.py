import time
from collections import defaultdict
from typing import Callable, DefaultDict, Tuple


class TokenKovaSinirlayici:
    """
    Gelismis hiz sinirlama: token bucket
    - oran: saniye basina uretilecek token
    - kapasite: maksimum token sayisi (burst)
    anahtar_fonk: Istek -> hashlenebilir anahtar (ip, yol, protokol vb.)
    """

    def __init__(self, oran: float, kapasite: int,
                 anahtar_fonk: Callable[["Istek"], Tuple[str, str, str]] | None = None):
        self.oran = float(oran)
        self.kapasite = int(kapasite)
        self.anahtar_fonk = anahtar_fonk or (lambda r: (r.ip or "-", r.yol or "-", (r.protokol or "-").upper()))
        # key -> (tokens, last_ts)
        self._durum: DefaultDict[Tuple[str, str, str], Tuple[float, float]] = defaultdict(lambda: (float(self.kapasite), time.time()))

    def eslesir_mi(self, istek: "Istek"):
        anahtar = self.anahtar_fonk(istek)
        tokens, last = self._durum[anahtar]
        now = time.time()
        # token doldur
        tokens = min(self.kapasite, tokens + (now - last) * self.oran)
        if tokens >= 1.0:
            tokens -= 1.0
            self._durum[anahtar] = (tokens, now)
            return (True, "token verildi")
        else:
            self._durum[anahtar] = (tokens, now)
            return (False, "token yok (limit asildi)")
