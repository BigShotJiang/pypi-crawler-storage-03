import ipaddress
from typing import Iterable


class CIDRIPFiltre:
    """IP adresini CIDR ag listeleriyle eslestirir."""

    def __init__(self, izinli: Iterable[str] | None = None, engelli: Iterable[str] | None = None):
        self.izinli_aglar = [ipaddress.ip_network(c, strict=False) for c in (izinli or [])]
        self.engelli_aglar = [ipaddress.ip_network(c, strict=False) for c in (engelli or [])]

    def eslesir_mi(self, istek: "Istek"):
        if not istek.ip:
            return False
        try:
            addr = ipaddress.ip_address(istek.ip)
        except ValueError:
            return False
        if self.izinli_aglar and not any(addr in ag for ag in self.izinli_aglar):
            return (False, "ip izinli aglarda degil")
        if self.engelli_aglar and any(addr in ag for ag in self.engelli_aglar):
            return (False, "ip engelli aglarda")
        return (True, "cidr ip uyumlu")
