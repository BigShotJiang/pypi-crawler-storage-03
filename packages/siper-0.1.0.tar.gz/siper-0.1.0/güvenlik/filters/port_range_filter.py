class PortAralikFiltre:
    def __init__(self, min_port: int | None = None, max_port: int | None = None):
        self.min = 0 if min_port is None else int(min_port)
        self.max = 65535 if max_port is None else int(max_port)
        if self.min < 0 or self.max > 65535 or self.min > self.max:
            raise ValueError("Gecersiz port araligi")

    def eslesir_mi(self, istek: "Istek"):
        if istek.port is None:
            return (False, "port yok")
        ok = self.min <= int(istek.port) <= self.max
        return (ok, "port aralik icinde" if ok else "port aralik disi")
