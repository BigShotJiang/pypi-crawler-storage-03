import time
from collections import defaultdict, deque
from typing import Deque, Dict, Tuple


class HizSinirlayici:
    """
    Basit kayan pencere hiz sinirlayici.
    anahtar: (ip, yol, protokol) uclusu
    limit: pencere_saniye icinde max istek sayisi
    """

    def __init__(self, limit: int, pencere_saniye: int = 60):
        self.limit = int(limit)
        self.pencere = int(pencere_saniye)
        self.kayitlar: Dict[Tuple[str, str, str], Deque[float]] = defaultdict(deque)

    def _anahtar(self, istek: "Istek") -> Tuple[str, str, str]:
        return ((istek.ip or "-"), (istek.yol or "-"), (istek.protokol or "-").upper())

    def eslesir_mi(self, istek: "Istek") -> bool:
        simdi = time.time()
        dq = self.kayitlar[self._anahtar(istek)]
        # eski kayitlari temizle
        while dq and simdi - dq[0] > self.pencere:
            dq.popleft()
        # bu istek icin kayit ekle
        dq.append(simdi)
        # limit asildiysa False don, boylece kural tutmaz
        return len(dq) <= self.limit
