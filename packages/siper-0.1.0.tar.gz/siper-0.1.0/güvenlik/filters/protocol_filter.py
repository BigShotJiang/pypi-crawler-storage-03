from typing import Iterable


class ProtokolFiltre:
    def __init__(self, izinli: Iterable[str] | None = None, engelli: Iterable[str] | None = None):
        self.izinli = {p.upper() for p in (izinli or [])}
        self.engelli = {p.upper() for p in (engelli or [])}

    def eslesir_mi(self, istek: "Istek") -> bool:
        p = (istek.protokol or "").upper()
        if self.izinli and p not in self.izinli:
            return False
        if self.engelli and p in self.engelli:
            return False
        return True
