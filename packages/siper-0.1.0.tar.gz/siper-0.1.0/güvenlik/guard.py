from __future__ import annotations

import os
from .exceptions import KomutGerekliHatasi

_KOMUT_GECTI = False
_BEKLENEN = os.environ.get("GUVENLIK_KOMUT", "cyhperinios")


def komut_gecir(kelime: str) -> None:
    global _KOMUT_GECTI
    if str(kelime).strip() == _BEKLENEN:
        _KOMUT_GECTI = True
    else:
        raise KomutGerekliHatasi("Gecersiz komut")


def komut_saglandi_mi() -> bool:
    return _KOMUT_GECTI


def dogrula_komut() -> None:
    if not _KOMUT_GECTI:
        raise KomutGerekliHatasi(
            "Komut saglanmadan calismaz. 'guvenlik.guard.komut_gecir(""cyhperinios"")' cagirin "
            "veya ortam degiskeni GUVENLIK_KOMUT ile beklenen degeri degistirin."
        )
