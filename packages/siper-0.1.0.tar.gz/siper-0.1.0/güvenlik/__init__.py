"""
Guvenlik duvari kutuphanesi (Turkce API, ASCII isimler)

Kullanim ornegi:

from guvenlik import GuvenlikDuvari, Kural
from guvenlik.filters import IPFiltre, PortFiltre

fw = GuvenlikDuvari()
fw.kural_ekle(Kural([IPFiltre(izinli=['127.0.0.1'])], eylem='izin'))

sonuc = fw.degerlendir(ip='1.2.3.4', port=80, protokol='TCP')
# sonuc -> Sonuc dataclass (sonuc.eylem: 'izin'|'blok'|'limitle')
"""

from .firewall import GuvenlikDuvari, Istek, Sonuc
from .rules import Kural
from .exceptions import GuvenlikHatasi
from . import config
from .__version__ import __version__

# Alt paketler
from . import filters  # noqa: F401
from . import storage  # noqa: F401
from . import utils    # noqa: F401

__all__ = [
    "GuvenlikDuvari", "Istek", "Sonuc", "Kural", "GuvenlikHatasi", "config", "filters", "storage", "utils", "__version__"
]
