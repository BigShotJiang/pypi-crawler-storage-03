class GuvenlikHatasi(Exception):
    """Guvenlik duvari kutuphanesi icin temel hata."""


class DogrulamaHatasi(GuvenlikHatasi):
    pass


class KomutGerekliHatasi(GuvenlikHatasi):
    """Gerekli komut saglanmadan calistirma girisimi."""
    pass
