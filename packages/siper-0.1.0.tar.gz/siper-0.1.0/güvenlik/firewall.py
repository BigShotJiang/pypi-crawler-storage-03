from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple
import time
from collections import OrderedDict


@dataclass
class Istek:
    ip: str | None = None
    port: int | None = None
    protokol: str | None = None  # "TCP" | "UDP" | "HTTP" ...
    yol: str | None = None       # HTTP path gibi
    ek: dict | None = None       # ekstra bilgiler


@dataclass
class Sonuc:
    eylem: str
    kural: "Kural" | None
    nedenler: List[str]
    varsayilan_mi: bool = False


class GuvenlikDuvari:
    def __init__(self, varsayilan: str = "izin"):
        from .validators import eylem_dogrula
        self.kurallar: List["Kural"] = []
        self.varsayilan = eylem_dogrula(varsayilan)
        self._aboneler: List[Callable[[Istek, Sonuc], None]] = []
        # onbellek
        self._cache_ttl: int = 0
        self._cache_max: int = 0
        self._cache: "OrderedDict[tuple, tuple[float, Sonuc]]" = OrderedDict()

    def kural_ekle(self, kural: "Kural") -> None:
        self.kurallar.append(kural)
        # oncelige gore sirala (kucuk oncelik once)
        self.kurallar.sort(key=lambda k: getattr(k, "oncelik", 100))

    def temizle(self) -> None:
        self.kurallar.clear()

    def abone_ekle(self, fonksiyon: Callable[[Istek, Sonuc], None]) -> None:
        self._aboneler.append(fonksiyon)

    def _bildir(self, istek: Istek, sonuc: Sonuc) -> None:
        for f in list(self._aboneler):
            try:
                f(istek, sonuc)
            except Exception:
                # abonede hata guvenlik duvarini durdurmasin
                pass

    def _filtre_calistir(self, filtre, istek: Istek) -> Tuple[bool, Optional[str]]:
        sonuc = filtre.eslesir_mi(istek)
        if isinstance(sonuc, tuple) and len(sonuc) == 2:
            return bool(sonuc[0]), str(sonuc[1]) if sonuc[1] is not None else None
        return bool(sonuc), None

    def ayarla_onbellek(self, ttl_s: int, kapasite: int) -> None:
        self._cache_ttl = max(0, int(ttl_s))
        self._cache_max = max(0, int(kapasite))
        if self._cache_max == 0 or self._cache_ttl == 0:
            self._cache.clear()

    def _cache_anahtar(self, istek: Istek) -> tuple:
        return (istek.ip, istek.port, (istek.protokol or "").upper(), istek.yol)

    def _cache_al(self, anahtar: tuple) -> Optional[Sonuc]:
        if self._cache_max == 0 or self._cache_ttl == 0:
            return None
        now = time.time()
        item = self._cache.get(anahtar)
        if not item:
            return None
        ts, sonuc = item
        if now - ts > self._cache_ttl:
            # expired
            try:
                del self._cache[anahtar]
            except KeyError:
                pass
            return None
        # LRU move to end
        self._cache.move_to_end(anahtar)
        return sonuc

    def _cache_yaz(self, anahtar: tuple, sonuc: Sonuc) -> None:
        if self._cache_max == 0 or self._cache_ttl == 0:
            return
        now = time.time()
        self._cache[anahtar] = (now, sonuc)
        self._cache.move_to_end(anahtar)
        # evict
        while len(self._cache) > self._cache_max:
            self._cache.popitem(last=False)

    def degerlendir(self, ip: Optional[str] = None, port: Optional[int] = None,
                     protokol: Optional[str] = None, yol: Optional[str] = None,
                     ek: Optional[dict] = None, istek: Optional[Istek] = None) -> Sonuc:
        # Komut kontrolu
        try:
            from .guard import dogrula_komut
            dogrula_komut()
        except Exception:
            # hatayi yukari firlat
            raise
        if istek is None:
            istek = Istek(ip=ip, port=port, protokol=protokol, yol=yol, ek=ek or {})

        # cache kontrolu
        anahtar = self._cache_anahtar(istek)
        cached = self._cache_al(anahtar)
        if cached is not None:
            self._bildir(istek, cached)
            return cached

        for kural in self.kurallar:
            nedenler: List[str] = []
            eslesti = True
            for f in kural.filtreler:
                ok, neden = self._filtre_calistir(f, istek)
                if not ok:
                    eslesti = False
                    break
                if neden:
                    nedenler.append(neden)
            if eslesti:
                sonuc = Sonuc(eylem=kural.eylem, kural=kural, nedenler=nedenler, varsayilan_mi=False)
                self._bildir(istek, sonuc)
                if getattr(kural, "durdur", True):
                    self._cache_yaz(anahtar, sonuc)
                    return sonuc
                # durdur False ise, devam eder; en son uygulanan eylemi dondurelim
                son_uygulanan = sonuc
        # hicbir kural tutmazsa varsayilan
        vars_sonuc = Sonuc(eylem=self.varsayilan, kural=None, nedenler=[], varsayilan_mi=True)
        self._bildir(istek, vars_sonuc)
        self._cache_yaz(anahtar, vars_sonuc)
        return vars_sonuc
