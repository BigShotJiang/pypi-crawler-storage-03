from .exceptions import DogrulamaHatasi


def eylem_dogrula(eylem: str) -> str:
    if eylem not in {"izin", "blok", "limitle"}:
        raise DogrulamaHatasi("Eylem 'izin', 'blok' veya 'limitle' olmali")
    return eylem
