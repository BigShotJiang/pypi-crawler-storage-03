from __future__ import annotations

from typing import Callable, Awaitable
from ..firewall import Istek, GuvenlikDuvari


class GuvenlikFastAPIMiddleware:
    def __init__(self, app, guard: GuvenlikDuvari):
        self.app = app
        self.guard = guard

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        # Istek'e cevir
        headers = {k.decode().title(): v.decode() for k, v in scope.get("headers", [])}
        method = scope.get("method")
        path = scope.get("path")
        client = scope.get("client") or (None, None)
        ip = client[0]
        port = client[1]
        sonuc = self.guard.degerlendir(
            ip=ip,
            port=port,
            protokol="TCP",
            yol=path,
            ek={"yontem": method, "basliklar": headers},
        )
        if sonuc.eylem == "blok":
            async def _send_block(start_res):
                await send({
                    "type": "http.response.start",
                    "status": 403,
                    "headers": [(b"content-type", b"application/json; charset=utf-8")],
                })
                await send({
                    "type": "http.response.body",
                    "body": ("{\"hata\": \"yasak\"}").encode(),
                })
            return await _send_block(None)
        return await self.app(scope, receive, send)
