from __future__ import annotations

from flask import Request, Response
from ..firewall import GuvenlikDuvari


def guvenlik_flask_middleware(app, guard: GuvenlikDuvari):
    @app.before_request
    def _kontrol():
        req: Request = app.request_class
        headers = dict((k.title(), v) for k, v in (req.headers or {}).items())
        yol = req.path
        method = req.method
        ip = req.remote_addr
        port = None
        sonuc = guard.degerlendir(
            ip=ip,
            port=port or 0,
            protokol="TCP",
            yol=yol,
            ek={"yontem": method, "basliklar": headers},
        )
        if sonuc.eylem == "blok":
            return Response("yasak", status=403, mimetype="text/plain")
        return None

    return app
