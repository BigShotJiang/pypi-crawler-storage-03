from __future__ import annotations

import argparse
import json
import sys

from . import config
from .guard import komut_gecir


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="guvenlik", description="Guvenlik duvari CLI")
    p.add_argument("komut", help="Calistirma icin gerekli komut (ornegin: cyhperinios)")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--json-dosya", dest="json_dosya", help="JSON ayar dosyasi")
    g.add_argument("--json", dest="json_str", help="JSON ayari (string)")
    p.add_argument("--test", action="store_true", help="Ornek bir istek degerlendir ve yazdir")
    args = p.parse_args(argv)

    # Gerekli komut
    komut_gecir(args.komut)

    # Yukle
    if args.json_dosya:
        fw = config.yukle_json_dosya(args.json_dosya)
    else:
        fw = config.yukle_json_str(args.json_str)

    if args.test:
        s = fw.degerlendir(ip="127.0.0.1", port=80, protokol="TCP", yol="/", ek={"yontem": "GET"})
        print(json.dumps({
            "eylem": s.eylem,
            "varsayilan": s.varsayilan_mi,
            "nedenler": s.nedenler,
            "kural": getattr(s.kural, "ad", None) or getattr(s.kural, "aciklama", None),
        }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
