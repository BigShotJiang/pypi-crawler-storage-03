class BellekDeposu:
    def __init__(self):
        self._veri = {}

    def al(self, anahtar, varsayilan=None):
        return self._veri.get(anahtar, varsayilan)

    def yaz(self, anahtar, deger):
        self._veri[anahtar] = deger

    def sil(self, anahtar):
        self._veri.pop(anahtar, None)

    def temizle(self):
        self._veri.clear()
