from .memory_store import BellekDeposu

__all__ = ["BellekDeposu"]
