# -*- coding: utf-8 -*-

from .inherit import DEFAULTS
from .inherit import inherit_value
from .inherit import apply_inheritance
from .merge import deep_merge
