Renaming for PQSC
===================

Node Renaming
--------------

.. list-table::
   :widths: 25 25
   :header-rows: 1

   * - old
     - new
   * - pqsc.ref_clock
     - pqsc.system.clocks.referenceclock.in\_.source
   * - pqsc.ref_clock_actual
     - pqsc.system.clocks.referenceclock.in\_.actual
   * - pqsc.ref_clock_status
     - pqsc.system.clocks.referenceclock.in\_.status
   * - pqsc.repetitions
     - pqsc.execution.repetitions
   * - pqsc.holdoff
     - pqsc.execution.holdoff
   * - pqsc.progress
     - pqsc.execution.progress
