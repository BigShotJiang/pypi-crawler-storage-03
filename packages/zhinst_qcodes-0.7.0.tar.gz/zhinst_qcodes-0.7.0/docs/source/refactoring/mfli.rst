Renaming for MFLI
===================

.. note::

    The integration of modules has been refactored. The modules are now
    independent of the devices. For the MFLI this means sweeper and daq usage
    now require to access the modules through the session. (e.g. session.modules.daq)
