License
^^^^^^^

.. literalinclude:: ../../../LICENSE
