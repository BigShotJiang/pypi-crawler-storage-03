"""Generator module that generated the QCoDeS driver based on zhinst-toolkit."""
