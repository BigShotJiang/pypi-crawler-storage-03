from dummyfunction.core import *
from dummyfunction.tests import *

if __name__ == "__main__":
    main()
