from .Agent import register_agent


__all__ = ['register_agent']