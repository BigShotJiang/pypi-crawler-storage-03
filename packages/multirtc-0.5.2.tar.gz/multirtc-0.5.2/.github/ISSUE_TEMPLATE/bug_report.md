---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

### The bug
<!-- Please include a clear and concise description of what the bug is. Describe
what actually happened *and* what you expected to happen. -->

### To Reproduce
<!-- Please include the steps to reproduce the behavior. E.g.,
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error -->

 ### Additional context
<!-- Add any other context or screenshots about the bug here. -->
