# Backup-chan preset library changelog

See what's changed between versions!

## 0.2.2

* Added ability to check if there is a preset.

## 0.2.1

* Added continuing interrupted sequential uploads.

## 0.2.0

* Added support for sequential uploads.

## 0.1.4

* Fixed not returning job ID when uploading folder.

## 0.1.3

* Upload function now returns the ID of the job currently processing the upload.

## 0.1.2

* `Presets` length can now be queried using `len(presets)`.

## 0.1.1

* `Presets` is now iterable.

## 0.1.0

* The first stable version
