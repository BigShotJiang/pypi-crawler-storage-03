"""System Bridge Connector."""
