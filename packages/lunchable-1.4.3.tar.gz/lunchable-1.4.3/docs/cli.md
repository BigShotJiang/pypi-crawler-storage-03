# lunchable CLI

```bash exec="on" source="above" result="markdown"
lunchable --help
```

::: mkdocs-click
    :module: lunchable._cli
    :command: cli
    :prog_name: lunchable
    :style: table
    :list_subcommands: True
