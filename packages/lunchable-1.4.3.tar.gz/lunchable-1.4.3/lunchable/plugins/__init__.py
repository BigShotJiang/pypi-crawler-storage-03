"""
Optional Plugins for LunchMoney
"""

from lunchable.plugins.app import LunchableApp, LunchableModelType

__all__ = [
    "LunchableApp",
    "LunchableModelType",
]
