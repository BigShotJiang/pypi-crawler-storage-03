# Init for projects plugin
