# Device management CLI plugin
