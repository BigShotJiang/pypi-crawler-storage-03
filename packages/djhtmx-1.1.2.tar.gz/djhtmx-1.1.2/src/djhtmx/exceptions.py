class ComponentNotFound(LookupError):
    pass
