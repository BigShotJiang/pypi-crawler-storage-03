# dz_locations

**DZ Locations** is a Django package that provides **Algerian wilayas (states) and communes (municipalities)** ready to use in your Django projects.

This package helps you quickly populate your database with all Algerian locations and access them via Django Admin or API.

---

## **Installation**

Install the package via pip:

```bash
pip install dz-locations
```