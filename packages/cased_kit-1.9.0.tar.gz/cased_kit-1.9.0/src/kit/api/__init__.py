"""kit REST API package."""

from .app import app  # re-export for `uvicorn kit.api:app`
