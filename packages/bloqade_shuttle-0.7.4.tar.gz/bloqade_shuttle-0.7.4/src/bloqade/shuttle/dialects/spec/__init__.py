from bloqade.shuttle.dialects.spec._interface import (
    get_static_trap as get_static_trap,
)

from ._dialect import dialect as dialect
from .concrete import ArchSpecMethods as ArchSpecMethods
from .stmts import (
    GetStaticTrap as GetStaticTrap,
)
