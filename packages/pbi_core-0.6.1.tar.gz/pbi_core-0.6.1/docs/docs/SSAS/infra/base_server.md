# Base SSAS Server

::: pbi_core.ssas.server.server.BaseServer

