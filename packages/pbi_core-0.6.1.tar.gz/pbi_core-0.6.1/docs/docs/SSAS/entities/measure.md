# Measure


::: pbi_core.ssas.model_tables.measure.Measure