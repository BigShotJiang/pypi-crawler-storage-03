# Related Column Detail


::: pbi_core.ssas.model_tables.related_column_detail.RelatedColumnDetail