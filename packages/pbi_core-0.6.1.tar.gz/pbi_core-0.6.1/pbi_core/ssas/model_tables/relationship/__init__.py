# Auto-generated to make this a Python package
from .relationship import Relationship

__all__ = ["Relationship"]
