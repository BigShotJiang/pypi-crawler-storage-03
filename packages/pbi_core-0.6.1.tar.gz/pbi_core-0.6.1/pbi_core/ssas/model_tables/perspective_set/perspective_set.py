from pbi_core.ssas.model_tables.base import SsasTable


class PerspectiveSet(SsasTable):
    """TBD.

    SSAS spec:
    """
