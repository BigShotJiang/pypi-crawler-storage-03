from .detail_row_definition import DetailRowDefinition

__all__ = ["DetailRowDefinition"]
