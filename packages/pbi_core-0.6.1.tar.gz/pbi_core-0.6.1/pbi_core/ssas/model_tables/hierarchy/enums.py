from enum import IntEnum


class HideMembers(IntEnum):
    DEFAULT = 0
    HIDE_BLANK_MEMBERS = 1
