# Auto-generated to make this a Python package
from .query_group import QueryGroup

__all__ = ["QueryGroup"]
