from pbi_core.pydantic.main import BaseValidation


class BaseFileModel(BaseValidation):
    pass
