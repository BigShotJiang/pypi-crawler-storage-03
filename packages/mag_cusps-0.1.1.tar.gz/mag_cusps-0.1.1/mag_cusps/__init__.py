from __future__ import annotations
from .mag_cusps import *
