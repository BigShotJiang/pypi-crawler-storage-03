STOP_CONSTANT = "stop_all_further_operations_with_success_result"
SKIP_OPERATION_CONSTANT = "internal_skip_operation_constant"

PARAMETER_WAS_NOT_EXPANDED = "The parameter was not expanded."

INITIAL_RUN = "INITIAL RUN"
INITIAL = "Initial"
SINGLE_RUN = "SINGLE RUN"
DEFAULT_BRANCH_OPTIONS = "DEFAULT BRANCH OPTIONS"
