# Copyright 2024 The MathWorks, Inc.


def get_executable_name() -> str:
    """Fetches and returns matlab proxy manager executable name"""
    return "matlab-proxy-manager-app"
