from .component import Component
from .storage import Storage,ThermalStorage,ExtStorage
CP_Water = 4.186/3.6 # Specific heat capacity of water in Wh/kg (?)#TODO
class Connection(Component):
    pass

class Conduction(Connection):
    _series_map = {
        'Name': 'name',
        'Storage1': 'storage1.name',
        'Storage2': 'storage2.name',
        'Coeff': 'coeff'}
    def __init__(self, storage1, storage2,coeff,name=None):
        Component.__init__(self,name)
        self.coeff=coeff
        self.storage1 = storage1
        self.storage2 = storage2
        self.storages = [storage1, storage2]
    
    @classmethod
    def newConduction(cls,storage1:Storage,storage2,coeff:float,name:str=None):
        cls=cls(storage1,storage2,coeff,name)
        return cls
        
class GeneralHeatTransfer(Connection):
    '''
    ! This is only for cases where the other methods don't work.
    It only sets the equations for the targetStorage.
    If you want to set up a connection between multiple storages and can't use the other methods, you have to set up the connection for all storages individually.
    '''
    _series_map = {
        'Name': 'name',
        'TargetStorage': 'targestStorage.name',
        'StorageList': 'storageList',
        'CoeffList': 'coeffList',
        'b': 'b'
    }
    def __init__(self,name):
        Component.__init__(self,name)
        self.targestStorage:ThermalStorage = None
        self.storageList:list[Storage] = None
        self.coeffList:list[float] = None
        self.b:float=None
    
    @classmethod
    def newGeneralHeatTransfer(cls, targetStorage:ThermalStorage,storageList:list[Storage],coeffList:list[float],b:float=0, name=None):#TODO was ist mit extStorages
        con = cls(name)
        con.targestStorage = targetStorage
        con.storageList= storageList
        con.coeffList = coeffList
        con.b = b
        return con
        

class FreeConvection(Connection):
    '''
    Free convection in stratified storages between layer a and b where a is below b if temp(a) > temp(b) with given mass flow
    '''
    _series_map = {
        'Name': 'name',
        'Storage1': 'storage1.name',
        'Storage2': 'storage2.name',
        'MassFlow': lambda self: self.get_mFlow(),
        'CpFluid': 'cpFluid',
        'Tolerance': 'tolerance'
    }
    def __init__(self,name):
        Component.__init__(self,name)
        self.storage1:ThermalStorage = None
        self.storage2:ThermalStorage = None
        self.__massFlow:float = None
        self.tolerance:float = None
        self.cpFluid = None
        
    @classmethod
    def newFreeConvection(cls, storage1:ThermalStorage, storage2:ThermalStorage, massFlow:float, cpFluid=CP_Water, tolerance=0.1,name=None):
        con = cls(name)
        con.storage1 = storage1
        con.storage2 = storage2
        con.__massFlow = massFlow
        con.cpFluid = cpFluid
        con.tolerance = tolerance
        return con
    
    def set_mFlow(self, mFlow):
        if mFlow<0:
            raise ValueError("mFlow must be non-negative. For flows in opposite direction set up a seperate ForcedFlow.")
        self.__massFlow = mFlow
    def get_mFlow(self):
        return self.__massFlow
    
class ForcedConvection(Connection):
    _series_map = {
        'Name': 'name',
        'StorageList': 'storageList',
        'MassFlow': lambda self: self.get_mFlow(),
        'CpFluid': 'cpFluid'
    }
    def __init__(self,name):
        Component.__init__(self,name)
        self.storageList = None
        self.__massFlow = None
        self.cpFluid = None
        
    def set_mFlow(self, mFlow):
        if mFlow<0:
            raise ValueError("mFlow must be non-negative. For flows in opposite direction set up a seperate ForcedFlow.")
        self.__massFlow = mFlow
        
    def get_mFlow(self):
        return self.__massFlow
    
    @classmethod
    def newForcedConvection(cls,storageList:list[Storage], massFlow, name=None, cpFluid=CP_Water):
        flow = cls(name)
        flow.cpFluid = cpFluid
        storageList = [x for sub in storageList for x in (sub if isinstance(sub, list) else [sub])]
        if not isinstance(storageList, list):
            raise TypeError("storageList must be a list of ThermalStorage objects")
        if not all(isinstance(storage, Storage) for storage in storageList):
            raise TypeError("All elements in storageList must be instances of Storage")
        flow.storageList = storageList
        flow.__massFlow = massFlow
        return flow
    