# 🎨 ASCII-Me CLI

[![PyPI version](https://img.shields.io/pypi/v/ascii-me-cli?color=blue&label=PyPI)](https://pypi.org/project/ascii-me-cli/)  
[![Python](https://img.shields.io/pypi/pyversions/ascii-me-cli.svg)](https://pypi.org/project/ascii-me-cli/)  
[![License](https://img.shields.io/github/license/WetZap/Ascii-Me)](LICENSE)  
[![GitHub stars](https://img.shields.io/github/stars/WetZap/Ascii-Me?style=social)](https://github.com/WetZap/Ascii-Me/stargazers)  

Convierte **imágenes** y **GIFs animados** en arte **ASCII a color**, directamente en tu terminal.  
Compatible con **Linux, macOS y Windows** 🖥️.

---

## 🚀 Instalación

### Desde PyPI (recomendado)
```bash
pip install ascii-me-cli
```

### Desde GitHub (última versión de desarrollo)
```bash
git clone https://github.com/WetZap/Ascii-Me.git
cd Ascii-Me
pip install .
```

---

## 📌 Uso

### 🔹 Imagen estática
```bash
ascii-art --mode image --file ejemplo.png
```

### 🔹 GIF animado
```bash
ascii-art --mode gif --file ejemplo.gif
```

### 🔹 Eliminar fondo (opcional)
```bash
ascii-art --mode gif --file ejemplo.gif --remove-bg
```

👉 Si no pasas `--file`, tomará automáticamente la primera imagen o GIF encontrado en el directorio actual.

---

## 🎬 Ejemplo

Aquí un ejemplo de cómo se ve una **imagen convertida en ASCII dentro del terminal**:

```
                                                                                  #**M   #*#*#            #*                         *                            
                           *#*    ##o*o#              *****#                **o*oooo#***#               *M*Moo**o*o**               *W*     oo                    
                          #o*#    ******                                      ******o                   **o**     o***              ##*    ***                    
                          ##o   ****o****            ***                      o**oo**                     oo      *#**                  *****                     
                           **    **o**#              **oo*oo*o                 ***                                                      *#                        
                                                                                                                                                                  
                                                                                   98)                                                                            
                                                                                877(r)806                                                                         
                                                                            8779/YOQZCvxt(9890                                                                    
                                                                        7770tzm*@%mCCJUUUYznt089(                                                                 
                                                                   0877)jUqM@$$%aQUUUUUYYYUUUXx(89|                                                               
                                                                877)rCd&$$$8*bZLUUUUUUUUYYYYYUUYf98)                                                              
                                       0444444443           \098/YpMBB&*kqZQCJUUUUUUUUYYYYYYXzUJJx890                                                             
                                     (9)LZOQLCUXvxjt\(0879)0898\oMadw0CXvnXJYYYYYYYYYYYYYYYr)//nYLt89(                                                            
                                    /97u$$$$$$$B8&&M*akpO/98\Z(9CLXurjnYL09cUYYYYYYYYYYYUz|0QowYuvf8988788899990000000999887770)                                  
                                    )97z$$$@oUYYYUC0mdh#k087C8wunvzCwh*#Mw|8rYUUYUYYYUUYr9rb#*#MMat76jOZZwwpddbkkkhhhhkbdqwZOY990                                 
                                    097x$@&WC577777779)\f988\qMM##M###***#hX))rzUJCJUXx(tO*#**##bj69caMMMMM#*ohbdqwZOOZp###MMv78)                                 
                                    )980aW*#p98888888887787767rQbo####*****#hQnttjxrjfvZo#**odQn00vp*kqOCXurt|)09887775n***#U799                                  
                                     997jo**#Y788888888879tXQv\90\xzLmko*ooo*#*obpqqba#***bJnfjc0k*oc07777777888888887na**#J899                                   
                                      997u****c788888870vwo***obwQJYXJqoooooooo*******ooooakha***ooohOn)7888888888878Y****Y799                                    
                                       997v****X77887)zb**ooooo********oooooooooooooooooooooooooooooo**bX)788888887tm***hn799                                     
                                        997uo**#Oj(|ud#*ooooooooooooooooooooooooooo*o***ooooooooooooooo*#bz)77778tQo**#w/790                                      
                                         087ra*o**aa**oooooooooooooooaooooooooooooooo*ahooooooooooooooooo*#kXttuZo#*#oU989)                                       
                                          )97fb#****ooooooooo******kLUChooooooooooooowUYCh****#*ooooooooooo*#o*##**#qf780                                         
                                  0877990090860Cmbo#oooooooooqYxjxOkZ0Zaooooo**oooooopOOqokXxxc0hooooooo****##*ohkbX7688                                          
                                099jwh***ohbw0JcxfjL*oooooo*U766650b#**oooooappaoooooo****v46665\k*ooooooo*wUcuuuuvnuvccunj)9)                                    
                                )98)rX0qka#MWM###appooooooo*0j//jcwoooooooookLCb*oooooooo*qvt|\jJaoooooooo*pZqba*#MWWM#abOc09(                                    
                                  08|jt(80|fcd*ooo**oooooooo**oo*#*oooooooooo***oooooooo**##*oo*#ooooooo****#*kqZQJzurf/(98099                                    
                                 9|wZv/jcCOZwa#*******ooo***#######################****ooahbpd****o**********aCcvxf/\\\trnxrf|990                                 
                                )9xd(67XZqpppqqqwmmZwk*#*akpm0CUYXzccccccczzzzzzzccunxrjtt//)9xo######*ooahhho*##MM#okwv7)nvux/900                                
                                 09/jzOYnt\\||||\||/\)tujttjnXCOwpdbkkbdqZLXuxrjjfjrxnnnnnuvf87LmLYzvnxrjf///tfrrrrrrjt/trnuuf\|)098                              
                                09/Oa#awLXvuuuuvvuun()xJqo8$$$$$@8MokqOLUXcuunnnnnuvvvuuuuun|79\/tffjrrrrrrrrjjrrrrrrrxnunnnuvvvvun\89                            
                               /98mMmUzvnxxnuuunnnuzYZkhhbqm0LUXcunxxrrrrrrrxxxxnnnnnnnnxx/09|jxxxxxxxxxxxxxxxxxxxnnnnnnxxrjf/\|||\(89)                           
                                99|vvnxnxrfftjuunnnnnnxrrrjjjrjrrrrrrrrrrrxxxxxxnnnnxxnxrrjfrxxxxxxrrxnunnnxxxxxrjf/|(0)0988877                                   
                                 088(frt)98089\nvuunnnxxxxxxxxxxxxxxxxxxxxxxxnnnnnxxxxxxxxxxxxxnnnnj()(tjtt/\\||\txcCOn77                                         
                                    88889    )99|frxnnnnxxxxxxxnnnnnnnnnnnnnnnxxxxrjjjjffffffjjjrrxxnr|70XUCL|8Za*#MMMhcczcr98                                    
                                                8899)((||\/tttttftt///\|||(((|||\\/ttffjrrxxxxrjjft/\\(6/#MM&u5LM***o**MWqzurfxt0)                                
                                                  )7\qOCYzvunnxnuuuczXUCQOZwpdbkhaoo****##*###****ahbpZOb**Mq07m#****oooahkdwQYj78                                
                                        &&W&&&&W&8Z08L*W&&WWWMW#dh#WWWWMWWWMMMMMMM#MM###M##oqm*#######MM#obY80juvvvvvvccczXXXJQpM%&&&&&                           
                                      8&&WW&&&88%%%hYtfvJ0ZmmmZL|9jXYUUJCCCLLLQQQQQLLCCJUYz/7jmqqppqmOLJzj/fL*8WMM##MMWW&&&&&&&&&WWW&&&                           
                                             MWWWWW%B*ZXuxxxnvcYCOwmOOQLLCJJJJJJJJJJJJCLL0Z0LUXzzzzzzzXYJOd#%8&888888&8&W&W&                                      
                                                                        $$$@$@$@@@@$$$$$$@                                                                        
                                                                                                                                                                  
                                                                                                                                                                  
❯ 
```

*(Ejemplo simplificado de salida real — cada terminal puede variar en colores y densidad)*

---

## 🛠 Desarrollo

Ejecutar sin instalar:
```bash
python ascii_gif_player.py --mode image --file ejemplo.png
```

Instalar dependencias en local:
```bash
pip install -r requirements.txt
```

---

## 📦 Dependencias
- [Pillow](https://pypi.org/project/Pillow/) (procesamiento de imágenes)
- Librerías estándar de Python (`argparse`, `os`, `sys`, etc.)

---

## 🗺️ Roadmap
- [ ] Guardar ASCII resultante en archivo `.txt`  
- [ ] Exportar animaciones ASCII como `.mp4` o `.gif`  
- [ ] Añadir soporte para vídeos (`.mp4`, `.webm`)  
- [ ] Más estilos de paletas ASCII  

---

## 🤝 Contribuciones
¡Las PRs son bienvenidas! Para cambios mayores, abre un *issue* primero y discutamos la propuesta.

1. Haz un fork 🍴  
2. Crea una rama: `git checkout -b feature/nueva-funcion`  
3. Haz commit: `git commit -m "feat: nueva función"`  
4. Haz push: `git push origin feature/nueva-funcion`  
5. Abre un Pull Request ✅  

---

## 📜 Licencia
Distribuido bajo licencia MIT.  
Consulta el archivo [LICENSE](LICENSE) para más información.

---

✨ Creado con ❤️ por [WetZap](https://github.com/WetZap)  
