"""pyfibot standard modules"""
