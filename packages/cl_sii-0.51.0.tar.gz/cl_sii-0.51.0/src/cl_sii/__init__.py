"""
cl-sii Python lib
=================

"""

__version__ = '0.51.0'
