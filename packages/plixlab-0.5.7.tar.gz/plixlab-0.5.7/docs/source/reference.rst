Reference
###########################################

The technical details will be reported in

G. Romano, Journal of Open Source Software
