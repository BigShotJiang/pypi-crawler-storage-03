class BlockFactor:
    def __init__(self, levels):
        self.n = len(levels)
        self.levels = levels