class DesignWarning(UserWarning):
    pass

class DesignError(Exception):
    """Custom exception for errors in the Design class."""
    pass