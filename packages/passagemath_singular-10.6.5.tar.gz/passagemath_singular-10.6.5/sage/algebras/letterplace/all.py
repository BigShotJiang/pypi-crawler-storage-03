# sage_setup: distribution = sagemath-singular
