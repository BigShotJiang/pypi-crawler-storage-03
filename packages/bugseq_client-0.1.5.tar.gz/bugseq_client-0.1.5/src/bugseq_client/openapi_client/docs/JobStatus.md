# JobStatus


## Enum

* `CREATED` (value: `'created'`)

* `PENDING` (value: `'pending'`)

* `RUNNING` (value: `'running'`)

* `SUCCESS` (value: `'success'`)

* `FAILURE` (value: `'failure'`)

* `MARKED_IN_ERROR` (value: `'marked_in_error'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


