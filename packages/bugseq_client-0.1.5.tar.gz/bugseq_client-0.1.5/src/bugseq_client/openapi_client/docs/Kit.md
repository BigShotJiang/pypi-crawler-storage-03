# Kit


## Enum

* `MINION_R9_4_1` (value: `'MINION_R9_4_1'`)

* `MINION_R10_3` (value: `'MINION_R10_3'`)

* `MINION_Q20` (value: `'MINION_Q20'`)

* `PROMETHION_R9_4_1` (value: `'PROMETHION_R9_4_1'`)

* `PROMETHION_Q20` (value: `'PROMETHION_Q20'`)

* `MINION_R10_4_1` (value: `'MINION_R10_4_1'`)

* `PROMETHION_R10_4_1` (value: `'PROMETHION_R10_4_1'`)

* `HIFI` (value: `'HIFI'`)

* `UNKNOWN` (value: `'UNKNOWN'`)

* `FLONGLE_R9_4_1` (value: `'FLONGLE_R9_4_1'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


