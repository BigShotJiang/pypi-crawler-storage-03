# Platform


## Enum

* `NANOPORE` (value: `'NANOPORE'`)

* `ILLUMINA` (value: `'ILLUMINA'`)

* `ILLUMINA_SINGLE_END` (value: `'ILLUMINA_SINGLE_END'`)

* `OTHER_SHORT_READ_PAIRED_END` (value: `'OTHER_SHORT_READ_PAIRED_END'`)

* `OTHER_SHORT_READ_SINGLE_END` (value: `'OTHER_SHORT_READ_SINGLE_END'`)

* `PACBIO` (value: `'PACBIO'`)

* `ION_TORRENT` (value: `'ION_TORRENT'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


