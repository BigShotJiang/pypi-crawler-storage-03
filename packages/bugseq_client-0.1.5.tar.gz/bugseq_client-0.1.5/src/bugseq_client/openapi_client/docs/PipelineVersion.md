# PipelineVersion


## Enum

* `LATEST` (value: `'latest'`)

* `V1_DOT_2` (value: `'v1.2'`)

* `V5_DOT_6` (value: `'v5.6'`)

* `V5_DOT_7` (value: `'v5.7'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


