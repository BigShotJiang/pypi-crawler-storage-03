# SampleTypeOutput


## Enum

* `METAGENOMIC` (value: `'metagenomic'`)

* `SIXTEEN_S` (value: `'sixteen_s'`)

* `ISOLATE` (value: `'isolate'`)

* `ANY_SAMPLE_TYPE` (value: `'any_sample_type'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


