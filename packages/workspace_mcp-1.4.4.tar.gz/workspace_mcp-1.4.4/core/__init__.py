# Make the core directory a Python package
