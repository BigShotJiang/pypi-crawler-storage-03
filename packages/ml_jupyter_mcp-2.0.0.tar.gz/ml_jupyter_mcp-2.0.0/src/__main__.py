#!/usr/bin/env python3
"""
Entry point for running Jupyter MCP Server as a module
"""

from jupyter_mcp.server import main

if __name__ == "__main__":
    main()