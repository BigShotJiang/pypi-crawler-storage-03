from .modelpool import OpenCLIPVisionModelPool
