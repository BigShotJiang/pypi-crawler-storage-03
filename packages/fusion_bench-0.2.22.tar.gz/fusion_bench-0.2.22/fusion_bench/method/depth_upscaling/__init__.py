# flake8: noqa F401
from .depth_upscaling import DepthUpscalingAlgorithm
from .depth_upscaling_for_llama import DepthUpscalingForLlama
