"""Version information for :mod:`class_resolver`."""

__all__ = [
    "VERSION",
]

VERSION = "0.7.0"
