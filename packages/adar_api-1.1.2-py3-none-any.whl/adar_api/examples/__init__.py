"""
Example for the ADAR API.

This module provides examples for the ADAR API.
"""
