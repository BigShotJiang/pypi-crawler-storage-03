from .cli import autoeis_installer

if __name__ == "__main__":
    autoeis_installer(prog_name="autoeis")
