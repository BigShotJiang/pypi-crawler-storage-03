# API documentation

```{toctree}
:maxdepth: 2

cli.md
```
