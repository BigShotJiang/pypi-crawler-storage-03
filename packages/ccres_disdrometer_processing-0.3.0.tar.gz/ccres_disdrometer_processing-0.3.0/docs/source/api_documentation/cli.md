# Command Line interface

```{eval-rst}
.. automodule:: ccres_disdrometer_processing.cli.cli
   :members:
```
