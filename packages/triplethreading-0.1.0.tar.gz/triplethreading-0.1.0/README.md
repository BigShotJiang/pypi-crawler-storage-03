Make an non empty README
