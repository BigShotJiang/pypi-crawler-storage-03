"""ShiftScan packages for detecting alternative chimeric and non-chimeric sources of mass spectrometry-identified peptides."""
__version__ = "0.1.1"  # Match the version in setup.py
