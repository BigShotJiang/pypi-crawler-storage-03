"""Various utility functions."""
