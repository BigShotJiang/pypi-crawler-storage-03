GEMINI_PRO = "google/gemini-2.5-pro"
GEMINI_FLASH = "google/gemini-2.5-flash"
OLLAMA_EMBEDDING_MODEL = "nomic-embed-text:latest"
OLLAMA_GENERATIVE_MODEL = "llama3.2:3b"
