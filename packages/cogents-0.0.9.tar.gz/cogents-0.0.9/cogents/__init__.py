from cogents.common.logging import setup_logging

# Enable colorful logging by default for cogents
setup_logging(level="INFO", enable_colors=True)
