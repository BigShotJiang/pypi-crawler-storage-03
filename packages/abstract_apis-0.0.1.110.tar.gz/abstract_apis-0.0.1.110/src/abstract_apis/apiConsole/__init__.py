from .apiConsole import apiConsole
from abstract_gui.QT6.startConsole import startConsole 
import traceback,sys
def startApiConsole():
    startConsole(apiConsole)
