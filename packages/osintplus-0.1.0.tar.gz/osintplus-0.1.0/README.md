# OSINTPlus

Un outil OSINT simple en ligne de commande, sans utiliser d'API.

## Installation

```bash
git clone https://github.com/hakersgenie/osintplus
cd osintplus
pip install -e .

## Utilisation
osintplus --domain example.com
osintplus --ping example.com
osintplus --whois example.com
osintplus --headers http://example.com
osintplus --robots example.com
