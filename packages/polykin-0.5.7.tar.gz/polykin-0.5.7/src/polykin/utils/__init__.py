# PolyKin: A polymerization kinetics library for Python.
#
# Copyright Hugo Vale 2023
