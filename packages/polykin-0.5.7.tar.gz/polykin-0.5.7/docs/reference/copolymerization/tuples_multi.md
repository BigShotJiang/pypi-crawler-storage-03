# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - tuples_multi
