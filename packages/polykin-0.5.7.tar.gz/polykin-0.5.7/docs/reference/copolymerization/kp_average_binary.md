# polykin.copolymerization

::: polykin.copolymerization.binary
    options:
        members:
            - kp_average_binary
