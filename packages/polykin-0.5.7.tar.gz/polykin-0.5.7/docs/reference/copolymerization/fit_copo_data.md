# polykin.copolymerization

::: polykin.copolymerization.fitting
    options:
        members:
            - fit_copo_data
