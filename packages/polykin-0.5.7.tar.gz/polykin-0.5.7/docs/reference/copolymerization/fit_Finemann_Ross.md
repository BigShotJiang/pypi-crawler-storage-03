# polykin.copolymerization

::: polykin.copolymerization.fitting
    options:
        members:
            - fit_Finemann_Ross
