# Copolymerization (polykin.copolymerization)

This module implements methods and classes to model and analyze binary and
multicomponent copolymerization systems.

[:simple-jupyter: Tutorial](../../tutorials/copolymerization){ .md-button }
