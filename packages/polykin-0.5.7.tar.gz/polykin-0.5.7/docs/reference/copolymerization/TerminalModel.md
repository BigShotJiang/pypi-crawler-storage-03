# polykin.copolymerization

::: polykin.copolymerization.terminal
    options:
        members:
            - TerminalModel
