# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - inst_copolymer_multi
