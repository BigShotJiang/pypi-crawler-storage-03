# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - monomer_drift_multi
