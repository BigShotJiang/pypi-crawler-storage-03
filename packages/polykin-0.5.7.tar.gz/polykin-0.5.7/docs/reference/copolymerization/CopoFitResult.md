# polykin.copolymerization

::: polykin.copolymerization.fitting
    options:
        members:
            - CopoFitResult
