# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - convert_Qe_to_r
