# polykin.copolymerization

::: polykin.copolymerization.binary
    options:
        members:
            - inst_copolymer_binary
