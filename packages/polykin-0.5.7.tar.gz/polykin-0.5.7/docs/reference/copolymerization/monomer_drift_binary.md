# polykin.copolymerization

::: polykin.copolymerization.binary
    options:
        members:
            - monomer_drift_binary
