# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - radical_fractions_ternary
