# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - transitions_multi
