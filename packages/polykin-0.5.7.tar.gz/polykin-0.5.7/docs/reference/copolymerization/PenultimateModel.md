# polykin.copolymerization

::: polykin.copolymerization.penultimate
    options:
        members:
            - PenultimateModel
