# polykin.copolymerization

::: polykin.copolymerization.multicomponent
    options:
        members:
            - sequence_multi
