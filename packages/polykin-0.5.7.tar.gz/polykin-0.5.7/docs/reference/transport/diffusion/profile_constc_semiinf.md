# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - profile_constc_semiinf
