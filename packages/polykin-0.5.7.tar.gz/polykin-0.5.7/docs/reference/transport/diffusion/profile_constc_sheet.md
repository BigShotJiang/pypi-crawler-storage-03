# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - profile_constc_sheet

### Graphical Illustration

The numbers in the legend are values of $Fo = D t / a^2$.

![profile_constc_sheet](profile_constc_sheet.svg)
