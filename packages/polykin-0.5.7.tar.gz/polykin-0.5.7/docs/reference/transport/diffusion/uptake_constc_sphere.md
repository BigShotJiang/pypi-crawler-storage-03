# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - uptake_constc_sphere

### Graphical Illustration

![uptake_constc_sphere](uptake_constc_sphere.svg)
