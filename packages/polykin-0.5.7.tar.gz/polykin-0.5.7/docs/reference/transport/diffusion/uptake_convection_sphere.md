# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - uptake_convection_sphere
