# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - profile_constc_sphere

### Graphical Illustration

The numbers in the legend are values of $D t / a^2$.

![profile_constc_sphere](profile_constc_sphere.svg)
