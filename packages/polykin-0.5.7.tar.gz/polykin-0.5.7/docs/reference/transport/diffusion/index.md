# Transient Diffusion (polykin.transport.diffusion)

## Overview

This module provides analytical solutions for transient diffusion in plane sheets and spheres
under various boundary conditions. These equations are equally applicable to heat conduction
due to the identical mathematical framework.
