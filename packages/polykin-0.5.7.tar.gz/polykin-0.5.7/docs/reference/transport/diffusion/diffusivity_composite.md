# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - diffusivity_composite
