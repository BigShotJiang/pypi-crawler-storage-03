# polykin.transport.diffusion

::: polykin.transport.diffusion
    options:
        members:
            - uptake_constc_sheet

### Graphical Illustration

![uptake_constc_sheet](uptake_constc_sheet.svg)
