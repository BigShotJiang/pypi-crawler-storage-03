# polykin.transport.hmt

::: polykin.transport.hmt
    options:
        members:
            - Nu_tube

### Graphical Illustration

For a smooth tube of infinite length.

![Nu_tube](Nu_tube.svg)