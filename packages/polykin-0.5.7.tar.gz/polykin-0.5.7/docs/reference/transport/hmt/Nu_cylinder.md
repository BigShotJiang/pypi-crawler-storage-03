# polykin.transport.hmt

::: polykin.transport.hmt
    options:
        members:
            - Nu_cylinder

### Graphical Illustration

![Nu_cylinder](Nu_cylinder.svg)