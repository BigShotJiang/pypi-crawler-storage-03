# polykin.emulsion

::: polykin.kinetics.emulsion.nbar
    options:
        members:
            - nbar_Li_Brooks
