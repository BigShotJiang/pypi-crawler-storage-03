# polykin.kinetics

::: polykin.kinetics.coefficients.arrhenius
    options:
        members:
            - Arrhenius
