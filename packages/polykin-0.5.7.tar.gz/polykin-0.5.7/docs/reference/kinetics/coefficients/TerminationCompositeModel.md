# polykin.kinetics

::: polykin.kinetics.coefficients.cldtermination
    options:
        members:
            - TerminationCompositeModel
