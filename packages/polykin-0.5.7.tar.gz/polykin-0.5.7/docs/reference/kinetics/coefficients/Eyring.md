# polykin.kinetics

::: polykin.kinetics.coefficients.eyring
    options:
        members:
            - Eyring
