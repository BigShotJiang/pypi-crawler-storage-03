# polykin.kinetics

::: polykin.kinetics.coefficients.cldpropagation
    options:
        members:
            - PropagationHalfLength
