# polykin.math

::: polykin.math.special
    options:
        members:
            - roots_xtanx
