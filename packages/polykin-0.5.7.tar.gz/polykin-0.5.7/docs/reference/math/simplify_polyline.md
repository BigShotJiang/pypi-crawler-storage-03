# polykin.math

::: polykin.math.filters
    options:
        members:
            - simplify_polyline
