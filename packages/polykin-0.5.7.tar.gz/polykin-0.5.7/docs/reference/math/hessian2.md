# polykin.math

::: polykin.math.derivatives
    options:
        members:
            - hessian2
