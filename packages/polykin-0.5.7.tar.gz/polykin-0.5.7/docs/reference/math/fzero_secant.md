# polykin.math

::: polykin.math.solvers
    options:
        members:
            - fzero_secant
