# polykin.math

::: polykin.math.special
    options:
        members:
            - i2erfc
