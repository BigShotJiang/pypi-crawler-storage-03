# polykin.math

::: polykin.math.solvers
    options:
        members:
            - ode_rk
