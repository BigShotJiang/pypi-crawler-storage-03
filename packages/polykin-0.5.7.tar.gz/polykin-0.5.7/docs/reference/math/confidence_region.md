# polykin.math

::: polykin.math.jcr
    options:
        members:
            - confidence_region
