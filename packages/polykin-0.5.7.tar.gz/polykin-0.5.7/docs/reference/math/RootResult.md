# polykin.math

::: polykin.math.solvers
    options:
        members:
            - RootResult
