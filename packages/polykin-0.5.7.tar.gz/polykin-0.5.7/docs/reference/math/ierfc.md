# polykin.math

::: polykin.math.special
    options:
        members:
            - ierfc
