# polykin.math

::: polykin.math.derivatives
    options:
        members:
            - derivative_centered
