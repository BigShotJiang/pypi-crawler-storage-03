# polykin.reactors.rtd

::: polykin.reactors.rtd
    options:
        members:
            - E_dispersion_model
