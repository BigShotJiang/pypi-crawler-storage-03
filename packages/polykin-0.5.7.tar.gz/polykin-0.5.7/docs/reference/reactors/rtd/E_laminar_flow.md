# polykin.reactors.rtd

::: polykin.reactors.rtd
    options:
        members:
            - E_laminar_flow
