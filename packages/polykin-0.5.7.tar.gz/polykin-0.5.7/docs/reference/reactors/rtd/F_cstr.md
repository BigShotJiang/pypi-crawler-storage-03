# polykin.reactors.rtd

::: polykin.reactors.rtd
    options:
        members:
            - F_cstr
