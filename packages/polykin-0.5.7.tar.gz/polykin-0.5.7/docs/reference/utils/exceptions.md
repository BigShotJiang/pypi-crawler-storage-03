# Types (polykin.utils.exceptions)

::: polykin.utils.exceptions
    options:
        members:
            - FitError
            - ODESolverError
            - RangeError
            - RangeWarning
            - RootSolverError
            - ShapeError
