# Types (polykin.utils.types)

::: polykin.utils.types
    options:
        members:
            - FloatArray
            - FloatArrayLike
            - FloatVector
            - FloatVectorLike
            - Float2x2Matrix
            - FloatMatrix
            - FloatSquareMatrix
            - FloatRangeArray
            - IntArray
            - IntArrayLike
            - IntVector
            - IntVectorLike
            - Number
