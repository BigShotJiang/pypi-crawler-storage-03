# polykin.thermo.acm

::: polykin.thermo.acm.wilson
    options:
        members:
            - Wilson_gamma
