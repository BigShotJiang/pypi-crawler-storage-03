# polykin.thermo.acm

::: polykin.thermo.acm.ideal
    options:
        members:
            - IdealSolution
