# polykin.thermo.acm

::: polykin.thermo.acm.uniquac
    options:
        members:
            - UNIQUAC_gamma
