# polykin.thermo.acm

::: polykin.thermo.acm.floryhuggins
    options:
        members:
            - FloryHuggins_activity
