# Activity Coefficient Models (polykin.thermo.acm)

This module implements activity models often used in polymer reactor models.

[:simple-jupyter: Tutorial](../../../tutorials/activity_coefficient_models){ .md-button }
