# polykin.thermo.acm

::: polykin.thermo.acm.nrtl
    options:
        members:
            - NRTL_gamma
