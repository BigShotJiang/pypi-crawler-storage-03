# Equations of State (polykin.thermo.eos)

This module implements equations of state (EOS) for gas and liquid mixtures.
