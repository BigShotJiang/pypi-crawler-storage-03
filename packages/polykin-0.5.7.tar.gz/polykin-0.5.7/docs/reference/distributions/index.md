# Distributions (polykin.distributions)

This module implements methods to create, visualize, fit, combine, integrate,
etc. theoretical and experimental chain-length distributions.

[:simple-jupyter: Tutorial](../../tutorials/distributions){ .md-button }
