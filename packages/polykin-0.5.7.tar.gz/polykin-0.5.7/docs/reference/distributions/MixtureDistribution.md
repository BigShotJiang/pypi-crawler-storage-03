# polykin.distributions

::: polykin.distributions.base
    options:
        members:
            - MixtureDistribution
