# polykin.distributions

::: polykin.distributions.analyticaldistributions
    options:
        members:
            - WeibullNycanderGold_pdf
