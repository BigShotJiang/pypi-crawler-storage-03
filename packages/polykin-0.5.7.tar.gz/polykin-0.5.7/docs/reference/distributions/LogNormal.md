# polykin.distributions

::: polykin.distributions.analyticaldistributions
    options:
        members:
            - LogNormal
