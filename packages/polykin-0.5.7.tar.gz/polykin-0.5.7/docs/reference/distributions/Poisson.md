# polykin.distributions

::: polykin.distributions.analyticaldistributions
    options:
        members:
            - Poisson
