# Distributions (polykin.distributions)

::: polykin.distributions.base
    options:
        members:
            - convolve_moments_self
