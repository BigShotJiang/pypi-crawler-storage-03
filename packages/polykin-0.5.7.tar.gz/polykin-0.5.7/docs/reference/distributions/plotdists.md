# Distributions (polykin.distributions)

::: polykin.distributions.base
    options:
        members:
            - plotdists
