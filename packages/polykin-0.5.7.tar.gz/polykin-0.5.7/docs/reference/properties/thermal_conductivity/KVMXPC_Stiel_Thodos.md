# polykin.properties.thermal_conductivity

::: polykin.properties.thermal_conductivity.vapor
    options:
        members:
            - KVMXPC_Stiel_Thodos
