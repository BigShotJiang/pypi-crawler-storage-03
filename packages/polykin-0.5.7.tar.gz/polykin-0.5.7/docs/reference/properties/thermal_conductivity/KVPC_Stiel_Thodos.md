# polykin.properties.thermal_conductivity

::: polykin.properties.thermal_conductivity.vapor
    options:
        members:
            - KVPC_Stiel_Thodos
