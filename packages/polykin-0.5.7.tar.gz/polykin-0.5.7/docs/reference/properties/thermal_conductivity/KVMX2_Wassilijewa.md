# polykin.properties.thermal_conductivity

::: polykin.properties.thermal_conductivity.vapor
    options:
        members:
            - KVMX2_Wassilijewa
