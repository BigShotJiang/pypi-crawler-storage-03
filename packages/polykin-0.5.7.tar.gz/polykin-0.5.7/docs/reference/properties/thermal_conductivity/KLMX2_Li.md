# polykin.properties.thermal_conductivity

::: polykin.properties.thermal_conductivity.liquid
    options:
        members:
            - KLMX2_Li
