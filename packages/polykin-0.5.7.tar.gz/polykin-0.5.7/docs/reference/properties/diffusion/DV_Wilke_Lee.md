# polykin.properties.diffusion

::: polykin.properties.diffusion.vapor
    options:
        members:
            - DV_Wilke_Lee
