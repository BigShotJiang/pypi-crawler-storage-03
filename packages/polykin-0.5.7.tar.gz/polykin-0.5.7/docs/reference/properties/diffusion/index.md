# Diffusion (polykin.properties.diffusion)

This module implements methods to calculate mutual and self-diffusion coefficients in binary
liquid and gas mixtures.

[:simple-jupyter: Tutorial](../../../tutorials/diffusion_coefficients){ .md-button }
