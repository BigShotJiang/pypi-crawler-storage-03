# polykin.properties.diffusion

::: polykin.properties.diffusion.vrentasduda
    options:
        members:
            - VrentasDudaBinary
