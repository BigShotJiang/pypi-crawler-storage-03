# polykin.properties.diffusion

::: polykin.properties.diffusion.liquid
    options:
        members:
            - DL_Hayduk_Minhas
