# polykin.properties.diffusion

::: polykin.properties.diffusion.liquid
    options:
        members:
            - DL_Wilke_Chang
