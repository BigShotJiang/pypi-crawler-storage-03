# polykin.properties.viscosity

::: polykin.properties.viscosity.liquid
    options:
        members:
            - MULMX2_Perry
