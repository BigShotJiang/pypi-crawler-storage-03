# polykin.properties.viscosity

::: polykin.properties.viscosity.vapor
    options:
        members:
            - MUV_Lucas
