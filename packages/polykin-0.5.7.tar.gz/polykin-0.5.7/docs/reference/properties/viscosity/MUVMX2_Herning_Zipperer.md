# polykin.properties.viscosity

::: polykin.properties.viscosity.vapor
    options:
        members:
            - MUVMX2_Herning_Zipperer
