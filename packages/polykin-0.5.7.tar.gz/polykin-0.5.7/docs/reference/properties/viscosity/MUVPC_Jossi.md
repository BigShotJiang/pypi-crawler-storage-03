# polykin.properties.viscosity

::: polykin.properties.viscosity.vapor
    options:
        members:
            - MUVPC_Jossi
