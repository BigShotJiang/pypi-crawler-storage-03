# polykin.properties.viscosity

::: polykin.properties.viscosity.vapor
    options:
        members:
            - MUVMXPC_Dean_Stiel
