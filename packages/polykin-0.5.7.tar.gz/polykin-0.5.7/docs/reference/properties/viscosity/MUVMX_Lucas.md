# polykin.properties.viscosity

::: polykin.properties.viscosity.vapor
    options:
        members:
            - MUVMX_Lucas
