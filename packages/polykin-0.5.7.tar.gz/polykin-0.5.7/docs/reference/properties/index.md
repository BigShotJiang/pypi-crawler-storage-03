# Physical Properties (polykin.properties)

::: polykin.properties
