# polykin.properties.pvt_polymer

This module implements methods to evaluate the PVT behavior of pure polymers.
