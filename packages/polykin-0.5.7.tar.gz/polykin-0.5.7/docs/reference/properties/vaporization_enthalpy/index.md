# polykin.properties.vaporization_enthalpy
