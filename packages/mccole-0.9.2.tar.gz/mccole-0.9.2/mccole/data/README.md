# Title

FIXME

## Learner Persona

FIXME

## Syllabus

<div id="syllabus" markdown="1">

1.  [Introduction](./01_intro/): what this training does and doesn't cover.

</div>

##  Appendices

<div id="appendices" markdown="1">

1.  [License](./LICENSE.md)
1.  [Code of Conduct](./CODE_OF_CONDUCT.md)
1.  [Contributing](./CONTRIBUTING.md)
1.  [Bibliography](./bibliography/)
1.  [Glossary](./glossary/)

</div>

## Acknowledgments {: #acknowledgments}

<p class="center">
  <em>
    start where you are
    &middot;
    use what you have
    &middot;
    help who you can
  </em>
</p>
