"""
Higher-order spectrum analysis.
"""
from .secondspectrum import second_spectrum
from .secondspectrum import chi2_test_gaussianity
