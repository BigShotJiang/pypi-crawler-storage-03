"""
Main entry point for MCP ZIM Server

Author: mobilemutex
"""

from .server import main

if __name__ == "__main__":
    main()

