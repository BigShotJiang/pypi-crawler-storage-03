// Initialize Mermaid
document.addEventListener('DOMContentLoaded', function() {
  mermaid.initialize({startOnLoad: true});
});