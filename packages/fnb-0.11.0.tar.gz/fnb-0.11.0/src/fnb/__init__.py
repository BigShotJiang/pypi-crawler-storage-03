"""fnb — Fetch'n'Backup.

A two-step backup tool powered by rsync providing fetch and backup operations
for automated data transfer workflows.
"""

__version__ = "0.11.0"
