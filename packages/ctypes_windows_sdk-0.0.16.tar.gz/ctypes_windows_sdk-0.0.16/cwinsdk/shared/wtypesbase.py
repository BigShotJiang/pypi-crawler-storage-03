from ctypes import c_char
from ctypes.wintypes import LPCSTR, LPSTR

OLECHAR = c_char
LPOLESTR = LPSTR
LPCOLESTR = LPCSTR
