from typing import Final

DOCS_ATTR_NAME: Final[str] = '_openapi_docs'
