Contents
========

..  toctree::
    :maxdepth: 2

    readme
    contributing
    updating
    changelog
    authors
    license


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
