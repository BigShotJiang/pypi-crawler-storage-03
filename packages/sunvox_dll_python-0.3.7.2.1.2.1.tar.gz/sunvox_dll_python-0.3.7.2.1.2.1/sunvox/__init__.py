__version__ = "0.3.7.2.1.2.1"

SUNVOX_COPYRIGHT_NOTICE = """\
SunVox modular synthesizer
Copyright (c) 2008-2024, Alexander Zolotov <nightradio@gmail.com>, WarmPlace.ru

Ogg Vorbis 'Tremor' integer playback codec
Copyright (c) 2002, Xiph.org Foundation
"""
