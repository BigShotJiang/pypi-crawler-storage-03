from setuptools import setup

setup(
    name="basicsystem",
    version="0.3.0",
    author="Mehmet",
    description="Saf Python ile gelişmiş oyun motoru altyapısı (tek dosya)",
    py_modules=["basicsystem"],  # Tek dosya
    python_requires=">=3.9",
)
