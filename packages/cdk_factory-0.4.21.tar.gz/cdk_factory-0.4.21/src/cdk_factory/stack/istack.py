# Deprecated: IStack has moved to cdk_factory/interfaces/istack.py to avoid circular dependencies.
# This file is retained for backward compatibility and should not be used.
