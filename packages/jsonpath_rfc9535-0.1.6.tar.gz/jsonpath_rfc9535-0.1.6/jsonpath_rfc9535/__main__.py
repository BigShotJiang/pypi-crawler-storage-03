"""CLI entry point."""

from jsonpath_rfc9535.cli import main

main()
