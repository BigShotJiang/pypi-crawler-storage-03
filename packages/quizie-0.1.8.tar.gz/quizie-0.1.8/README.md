# Quizie

Quizie is a Python package that generates quizzes on any topic using Google's Gemini model.
It provides multiple-choice questions with options, ranging from easy to hard difficulty.

## Installation
```bash
pip install quizie
