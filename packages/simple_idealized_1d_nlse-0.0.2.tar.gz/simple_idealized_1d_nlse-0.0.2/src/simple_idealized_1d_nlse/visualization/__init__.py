"""Visualization Module with FiveThirtyEight Style"""
from .animator import Animator

__all__ = ["Animator"]
