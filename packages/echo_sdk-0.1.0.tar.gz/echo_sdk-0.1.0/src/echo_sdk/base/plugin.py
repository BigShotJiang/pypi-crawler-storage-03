"""Base plugin interface for Echo plugins."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from .agent import BasePluginAgent
from .metadata import PluginMetadata


class BasePlugin(ABC):
    """Base interface that all Echo plugins must implement.

    This replaces the direct dependency on echo.plugins.base.BasePlugin
    and provides the same interface through the SDK.

    Each plugin must:
    1. Implement get_metadata() to declare its capabilities
    2. Implement create_agent() to provide an agent instance
    3. Optionally implement validation and configuration methods
    """

    @staticmethod
    @abstractmethod
    def get_metadata() -> PluginMetadata:
        """Return plugin metadata used for discovery and routing.

        This method must be implemented by every plugin to declare:
        - Plugin name and version
        - Capabilities and description
        - LLM requirements
        - Dependencies and compatibility

        Returns:
            PluginMetadata: Complete plugin metadata
        """
        pass

    @staticmethod
    @abstractmethod
    def create_agent() -> BasePluginAgent:
        """Create and return the plugin agent instance.

        This factory method creates the actual agent that will be used
        in the Echo multi-agent workflow.

        Returns:
            BasePluginAgent: Configured agent instance
        """
        pass

    @staticmethod
    def validate_dependencies() -> List[str]:
        """Validate plugin dependencies.

        Override this method to check if required dependencies are available,
        API keys are configured, external services are accessible, etc.

        Returns:
            List[str]: List of error messages; empty if all checks pass
        """
        return []

    @staticmethod
    def health_check() -> Dict[str, Any]:
        """Perform plugin health check.

        Override this method to implement custom health checks for your plugin.
        This might include checking API connectivity, database connections, etc.

        Returns:
            Dict[str, Any]: Health status with 'healthy' boolean and optional details
        """
        return {"healthy": True, "details": "No custom health checks implemented"}
