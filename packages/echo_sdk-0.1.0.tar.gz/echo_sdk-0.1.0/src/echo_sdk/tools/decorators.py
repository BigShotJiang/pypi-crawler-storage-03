"""Tool decorators for Echo plugins."""

from langchain_core.tools import tool as langchain_tool

tool = langchain_tool
