

ILLINI_BLUE = "#13294B"
ILLINI_ORANGE = "#E84A27"

font = {'family': 'serif',
        'color':  'black',
        'weight': 'normal',
        'size': 16,
        }
