"""
This package contains the implementation of the graphical user interface (GUI) for `pymead`.
"""
