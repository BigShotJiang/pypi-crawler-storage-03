"""
Contains example implementations of ``Airfoil`` and ``MEA``
"""