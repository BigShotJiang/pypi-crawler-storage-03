"""
``pymead.core`` contains the main modules that run `pymead`.
"""

from pymead.core.units import Units


UNITS = Units()
