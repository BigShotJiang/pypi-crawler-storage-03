"""
A custom plugin for Initial Graphics Exchange Specification (IGES) 5.3
http://paulbourke.net/dataformats/iges/IGES.pdf
"""
global_section_col_width = 72
