from .interface import LabelInterface
