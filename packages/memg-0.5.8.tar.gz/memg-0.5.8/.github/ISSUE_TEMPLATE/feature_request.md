---
name: Feature request
about: Suggest an idea for MEMG
labels: enhancement
---

### Problem

### Proposal

### Alternatives

### Additional context
