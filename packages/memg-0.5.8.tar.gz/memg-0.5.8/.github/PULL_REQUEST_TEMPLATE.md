### Summary

### What changed

### Why

### Checklist
- [ ] Tests added/updated
- [ ] Docs updated (README/docs site)
- [ ] Lint passes
- [ ] No broad `except Exception` added
