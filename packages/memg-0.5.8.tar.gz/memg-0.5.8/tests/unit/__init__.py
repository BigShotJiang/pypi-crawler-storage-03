"""Unit tests for MEMG components."""
