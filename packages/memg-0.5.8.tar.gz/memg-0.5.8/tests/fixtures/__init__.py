"""Test fixtures and sample data for MEMG tests."""
