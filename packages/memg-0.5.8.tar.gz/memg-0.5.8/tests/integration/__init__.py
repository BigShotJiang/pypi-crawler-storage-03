"""Integration tests for MEMG components."""
