# SPDX-FileCopyrightText: 2024-present Chris O'Neill <chris@purplejay.io>
#
# SPDX-License-Identifier: MIT
__version__ = "4.5.6"
