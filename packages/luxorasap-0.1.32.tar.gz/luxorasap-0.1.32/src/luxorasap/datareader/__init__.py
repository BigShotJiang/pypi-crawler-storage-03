"""
Subpacote de leitura de dados (LuxorQuery e utilidades).
"""

from .core import LuxorQuery

__all__ = ["LuxorQuery"]