This module allows to handle sale price at product variant level
(product.product) instead of product level (product.template), which is
the default.

It replaces the extra price configuration with a fix price that can be
modified on each variant independently, which allows setting absolute
prices instead of relative ones.
