"""OpenHexa Client."""
from ..utils import OpenHexaClient

openhexa = OpenHexaClient()


__all__ = ["openhexa"]
