import fitz  # PyMuPDF
from pptx import Presentation
from pptx.util import Inches
import os

def convert(pdf_path: str, output_ppt: str = None, dpi: int = 200) -> str:
    """
    Convert a PDF into a PowerPoint presentation.
    """
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")

    if output_ppt is None:
        output_ppt = os.path.splitext(pdf_path)[0] + ".pptx"

    doc = fitz.open(pdf_path)
    prs = Presentation()
    blank_layout = prs.slide_layouts[6]

    for page_num in range(len(doc)):
        page = doc[page_num]
        pix = page.get_pixmap(dpi=dpi)
        img_path = f"_temp_page_{page_num}.png"
        pix.save(img_path)

        slide = prs.slides.add_slide(blank_layout)
        slide.shapes.add_picture(img_path, Inches(0), Inches(0),
                                 width=prs.slide_width, height=prs.slide_height)

        os.remove(img_path)

    prs.save(output_ppt)
    return output_ppt

