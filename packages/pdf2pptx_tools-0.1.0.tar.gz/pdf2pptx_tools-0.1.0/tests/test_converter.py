from pdf2pptx_tools import convert
import os

def test_pdf_to_pptx():
    sample_pdf = "sample.pdf"
    output_ppt = "sample.pptx"
    if os.path.exists(sample_pdf):
        result = convert(sample_pdf, output_ppt)
        assert os.path.exists(result)

