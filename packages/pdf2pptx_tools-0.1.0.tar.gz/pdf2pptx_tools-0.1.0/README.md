# 📦 pdf2pptx-tools

Convert PDFs into PowerPoint slides with a single function.

## Installation
```bash
pip install pdf2pptx-tools

Usage

from pdf2pptx_tools import convert
convert("input.pdf", "output.pptx")

