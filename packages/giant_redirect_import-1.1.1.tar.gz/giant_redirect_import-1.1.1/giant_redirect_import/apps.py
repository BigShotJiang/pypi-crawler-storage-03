from django.apps import AppConfig


class RedirectConfig(AppConfig):
    name = "giant_redirect_import"
