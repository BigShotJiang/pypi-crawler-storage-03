"""commands
"""
from . import crypt
from . import confuse
from . import ipinfo
from . import weather

__all__ = ['crypt', 'confuse', 'ipinfo', 'weather']
