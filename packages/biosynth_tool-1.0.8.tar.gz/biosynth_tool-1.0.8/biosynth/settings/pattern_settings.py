# Unwanted Patterns set
P = {
    "TAGTAC",
    "ATATCA",  # BlaI
}

# # # Unwanted Patterns set
# P = {
#     "TACA",  # BlaI
#     "TATC",  #
#     "ATTC",  #
#     "TATA",  #
# }

# P={"TCGA"}

