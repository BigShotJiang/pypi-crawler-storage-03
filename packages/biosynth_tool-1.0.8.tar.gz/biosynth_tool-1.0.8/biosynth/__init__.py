"""
BioSynth - A bioinformatics tool for DNA sequence optimization.
"""

__version__ = "1.0.0"
__author__ = "Hadar Pur <hadarpur13@gmail.com>"
