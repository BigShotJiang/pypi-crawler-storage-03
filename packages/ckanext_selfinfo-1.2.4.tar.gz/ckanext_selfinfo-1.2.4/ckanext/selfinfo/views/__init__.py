from __future__ import annotations

from .selfinfo import selfinfo

__all__: list[str] = [
    "selfinfo",
]
