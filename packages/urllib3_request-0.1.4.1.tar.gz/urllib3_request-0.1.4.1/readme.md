# urllib3 request extension.

## Installation

You can install via [pypi](https://pypi.org/project/urllib3_request/)

```console
pip install -U urllib3_request
```

## Usage

```python
from urllib3_request import request
```
