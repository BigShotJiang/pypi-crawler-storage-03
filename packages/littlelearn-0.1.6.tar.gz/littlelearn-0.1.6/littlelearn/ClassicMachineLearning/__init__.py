from .LinearModels import LogisticRegression
from .LinearModels import LinearRegression
from .KNN import KNNClasification
