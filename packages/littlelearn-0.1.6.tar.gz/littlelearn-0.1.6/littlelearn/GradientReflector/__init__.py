from .GradientReflector import GradientReflector
from .GradientReflector import non_active_grad