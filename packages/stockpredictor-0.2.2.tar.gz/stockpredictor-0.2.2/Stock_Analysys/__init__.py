# stockpredictor/__init__.py
from stockpredictor.stock_predictor import stockpredictor

