"""Make the CLI runnable using python -m mandelbrot_benchmark."""

from .cli import app

app(prog_name="mandelbrot-benchmark")
