from abc import ABC, abstractmethod
from typing import List


class Tag(ABC):
    """ Currently a placeholder for future tagging mechanism used for services"""
