import sys
import os

path_to_scripts = os.path.dirname(os.path.realpath(__file__))
path_to_base = os.path.dirname(path_to_scripts)
path_to_models = os.path.join(path_to_scripts, 'models')