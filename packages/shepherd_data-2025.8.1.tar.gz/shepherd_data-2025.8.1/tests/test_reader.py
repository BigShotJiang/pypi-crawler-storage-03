# TODO:
#  - confirm energy stays same after resampling
#  - length should also stay same
