"""ITables' version number"""

__version__ = "2.4.5"
