from luxonis_ml.utils import setup_logging

setup_logging()
