# STMGraph

This is a STMGraph_pyG package. The GitHub repository for this package is [https://github.com/binbin-coder/STMGraph_pyg.git](https://github.com/binbin-coder/STMGraph_pyg.git).
