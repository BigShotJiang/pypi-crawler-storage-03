#  Copyright (c) 2025 by EOPF Sample Service team and contributors
#  Permissions are hereby granted under the terms of the Apache 2.0 License:
#  https://opensource.org/license/apache-2-0.

from xcube_eopf.prodhandler import ProductHandlerRegistry


def register(_registry: ProductHandlerRegistry):
    # TODO: implement Sentinel-1 ProductHandler
    pass
