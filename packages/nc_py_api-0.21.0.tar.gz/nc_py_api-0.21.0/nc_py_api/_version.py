"""Version of nc_py_api."""

__version__ = "0.21.0"
