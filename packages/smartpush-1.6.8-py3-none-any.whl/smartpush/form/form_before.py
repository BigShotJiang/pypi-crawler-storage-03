from smartpush.base.request_base import FormRequestBase


class FormBefore(FormRequestBase):
    pass
    """
    创建各种类型的表单，确保是上架状态
    """

