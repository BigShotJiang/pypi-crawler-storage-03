"""Task-Agents Multi-Tool MCP Server - Each specialized AI agent as an individual MCP tool."""

__version__ = "4.0.0"

from .server import mcp

__all__ = ["mcp"]