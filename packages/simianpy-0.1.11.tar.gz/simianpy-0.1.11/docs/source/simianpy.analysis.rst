simianpy.analysis package
=========================

Submodules
----------

simianpy.analysis.behaviouraldata module
----------------------------------------

.. automodule:: simianpy.analysis.behaviouraldata
   :members:
   :undoc-members:
   :show-inheritance:

simianpy.analysis.detectsaccades module
---------------------------------------

.. automodule:: simianpy.analysis.detectsaccades
   :members:
   :undoc-members:
   :show-inheritance:

simianpy.analysis.detectspikes module
-------------------------------------

.. automodule:: simianpy.analysis.detectspikes
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: simianpy.analysis
   :members:
   :undoc-members:
   :show-inheritance:
