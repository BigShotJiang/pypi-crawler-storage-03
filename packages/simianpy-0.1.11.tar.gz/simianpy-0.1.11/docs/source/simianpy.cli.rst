simianpy.cli package
====================

Submodules
----------

simianpy.cli.main module
------------------------

.. automodule:: simianpy.cli.main
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: simianpy.cli
   :members:
   :undoc-members:
   :show-inheritance:
