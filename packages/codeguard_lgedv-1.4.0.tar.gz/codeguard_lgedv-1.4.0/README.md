# MCP server
MCP server to detect C++ vulnerability.
