Para aquellas empresas (clientes/proveedores) que no se quieran incluir en el
cálculo del 347, hay que marcar la casilla "No incluida en el modelo 347" desde
su formulario.

Para aquellas facturas que no deban incluirse en el 347 por su naturaleza,
debe marcarse la casilla "No incluida en el modelo 347" desde su formulario.
