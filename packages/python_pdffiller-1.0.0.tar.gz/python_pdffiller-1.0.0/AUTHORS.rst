Contributors
------------

|contributors|

.. |contributors| image:: https://contributors-img.web.app/image?repo=sismicfr/pypdffiller
   :target: https://github.com/sismicfr/pypdffiller/graphs/contributors