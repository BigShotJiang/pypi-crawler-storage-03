# pyppet
pyppet is a robot model format that uses Python instead of XML for better type checking, logic, scripting, and parsing.

## Installation
`pip install pyppet`

## Examples
Examples can be found at https://github.com/david-dorf/pyppet_models, as well as the basic example contained within this repository.
