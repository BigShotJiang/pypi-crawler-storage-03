# Examples
Largely used for testing, these basic examples go through the main capabilities in pyppet.
For more examples, see pyppet_models [https://github.com/david-dorf/pyppet_models]
