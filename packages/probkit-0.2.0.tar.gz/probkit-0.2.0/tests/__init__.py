"""
Tests module for probkit.
"""
