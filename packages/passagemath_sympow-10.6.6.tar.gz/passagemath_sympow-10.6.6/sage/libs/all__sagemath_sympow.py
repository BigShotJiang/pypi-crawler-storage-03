# sage_setup: distribution = sagemath-sympow
