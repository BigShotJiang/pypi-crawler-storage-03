# Check whether the tf tree is reasonable
