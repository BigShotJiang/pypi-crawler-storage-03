"""Dictionary keys for `TreeItem`s."""

TYPE = "type"
WIDGET_DATA = "linked-widget-data"
CHILDREN = "children"

DEFAULT_ICON_FILENAME = "script.png"
