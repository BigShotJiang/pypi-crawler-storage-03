- **{{ MEASUREMENT_INTERVAL }}**

    The measurement interval in milliseconds. Minimum of {{ MINIMUM_INTERVAL }} ms.