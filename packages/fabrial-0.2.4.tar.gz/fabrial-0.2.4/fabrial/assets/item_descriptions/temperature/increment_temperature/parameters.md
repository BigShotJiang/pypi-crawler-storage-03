- **{{ INCREMENT }}**
    
    The amount to increment the setpoint by.
