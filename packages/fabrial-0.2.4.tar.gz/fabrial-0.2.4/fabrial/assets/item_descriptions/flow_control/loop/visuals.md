The visuals of any subitems are shown as they run.
