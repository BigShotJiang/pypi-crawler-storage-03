- **{{ NUM_LOOPS }}**

    The number of times to repeat the contained actions.