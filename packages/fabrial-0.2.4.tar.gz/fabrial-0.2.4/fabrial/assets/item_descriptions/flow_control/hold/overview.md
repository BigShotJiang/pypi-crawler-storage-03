Hold for the provided duration.
