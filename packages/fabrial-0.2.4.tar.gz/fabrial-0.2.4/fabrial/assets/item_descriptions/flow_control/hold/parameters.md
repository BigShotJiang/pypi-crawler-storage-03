- **{{ HOURS }}**

    How many hours to hold for.

- **{{ MINUTES }}**

    How many minutes to hold for.

- **{{ SECONDS }}**

    How many seconds to hold for.

The total hold time is the sum of these entries.
