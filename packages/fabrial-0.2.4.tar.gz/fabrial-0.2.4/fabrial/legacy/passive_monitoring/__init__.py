from .widgets import PassiveMonitoringWidget
