-- simple
drop text search parser foo;

-- full
drop text search parser if exists bar cascade;

-- restrict
drop text search parser bar restrict;

