-- missing option
alter sequence s;
