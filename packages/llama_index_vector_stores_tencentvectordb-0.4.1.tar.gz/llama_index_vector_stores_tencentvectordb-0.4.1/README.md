# LlamaIndex Vector_Stores Integration: Tencentvectordb
