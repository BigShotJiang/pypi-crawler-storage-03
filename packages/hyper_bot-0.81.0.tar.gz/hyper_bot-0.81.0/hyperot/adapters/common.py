from ..utils import logic

reports = logic.KeyQueue()


def init() -> None:
    ...
