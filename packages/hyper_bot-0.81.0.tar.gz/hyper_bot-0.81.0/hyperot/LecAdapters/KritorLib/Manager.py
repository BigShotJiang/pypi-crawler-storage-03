from ...LecAdapters.OneBotLib.Manager import *
