To build the embedded visualization tool, use the following commands:

```sh
# build the frontend
npm install --include=dev
npm run build
# or active development:
npm run dev
```
