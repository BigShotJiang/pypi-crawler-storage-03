# visualization data folder

program will automatically export visualization data to this folder
