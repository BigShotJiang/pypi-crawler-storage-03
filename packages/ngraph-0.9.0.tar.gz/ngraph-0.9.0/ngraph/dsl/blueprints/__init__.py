"""Blueprint DSL types and expansion utilities.

This subpackage defines blueprint structures and expansion helpers that turn
group and adjacency patterns into a `ngraph.model.network.Network`.
"""
