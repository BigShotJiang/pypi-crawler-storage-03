#!/usr/bin/env python3
"""
Minimal setup.py stub for backward compatibility.
All configuration is now in pyproject.toml
"""

from setuptools import setup

setup()
