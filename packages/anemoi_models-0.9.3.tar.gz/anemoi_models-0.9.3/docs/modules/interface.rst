###########
 Interface
###########

.. automodule:: anemoi.models.interface
   :members:
   :no-undoc-members:
   :show-inheritance:
