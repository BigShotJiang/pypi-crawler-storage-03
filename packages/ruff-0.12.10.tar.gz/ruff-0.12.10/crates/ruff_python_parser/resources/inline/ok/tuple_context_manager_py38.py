# parse_options: {"target-version": "3.8"}
with (
  foo,
  bar,
  baz,
) as tup: ...
