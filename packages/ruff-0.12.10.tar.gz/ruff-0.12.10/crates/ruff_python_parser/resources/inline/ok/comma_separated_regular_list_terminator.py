# The first element is parsed by `parse_list_like_expression` and the comma after
# the first element is expected by `parse_list_expression`
[0]
[0, 1]
[0, 1,]
[0, 1, 2]
[0, 1, 2,]
