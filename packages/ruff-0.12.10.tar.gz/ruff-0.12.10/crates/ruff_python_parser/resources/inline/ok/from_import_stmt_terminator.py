from a import (b, c)
from a import (b, c); x, y
from a import b, c; x, y
from a import b, c
x, y
