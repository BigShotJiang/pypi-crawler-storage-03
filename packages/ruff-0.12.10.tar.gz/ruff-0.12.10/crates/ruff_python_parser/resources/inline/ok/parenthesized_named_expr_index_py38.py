# parse_options: {"target-version": "3.8"}
lst[(x:=1)]
