@*x
@(*x)
@((*x))
@yield x
@yield from x
def foo(): ...
