# parse_options: {"target-version": "3.8"}
f((a)=1)
f((a) = 1)
f( ( a ) = 1)
