# parse_options: {"target-version": "3.8"}
{x := 1, 2, 3}
{1, x := 2, 3}
{1, 2, x := 3}
