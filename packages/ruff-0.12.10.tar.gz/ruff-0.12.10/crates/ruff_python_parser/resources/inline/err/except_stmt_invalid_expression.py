try:
    pass
except yield x:
    pass
try:
    pass
except* *x:
    pass
