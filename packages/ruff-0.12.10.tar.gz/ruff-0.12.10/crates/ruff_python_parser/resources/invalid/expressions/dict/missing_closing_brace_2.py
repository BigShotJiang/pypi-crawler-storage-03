{x: 1,

def foo():
    pass