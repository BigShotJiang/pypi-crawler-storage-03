# An expression is present, but it's most likely not what was intended for the
# assignment value.

(x :=

x + y