# 3Dlibrary v0.2

Saf Python 3D kütüphanesi. OpenGL kullanmadan çalışır.

## Özellikler
- 3D vertex ve polygon çizimi
- Matris dönüşümleri (rotate, scale, translate)
- Z-buffer ve backface culling
- Basit kamera sistemi
- Animasyon destekli render döngüsü
- Mesh / OBJ yükleme desteği (temel)
- Polygon renkleri ve basit ışık efektleri
