# Waifu2x Python

Python wrapper para waifu2x-ncnn-vulkan com interface simples e poderosa.

## Instalação
```bash
pip install waifu2x-python