class NoMatchingDataError(Exception):
    pass

class ApiError(Exception):
    pass
