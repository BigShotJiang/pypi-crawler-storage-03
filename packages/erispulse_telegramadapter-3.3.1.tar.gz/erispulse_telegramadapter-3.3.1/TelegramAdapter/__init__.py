from .Core import TelegramAdapter
