from argon2 import Type

ARGON2_TYPE = Type.D
