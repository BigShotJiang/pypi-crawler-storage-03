# Communication between Beacon to Beacon config

HANDSHAKE_MSG = {"status": "OK"}
