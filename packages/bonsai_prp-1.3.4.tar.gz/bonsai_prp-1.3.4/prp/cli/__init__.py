"""Definition of CLI commands."""

from .base import cli
