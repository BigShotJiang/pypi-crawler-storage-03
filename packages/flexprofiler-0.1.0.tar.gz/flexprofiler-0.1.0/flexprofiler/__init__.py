
from .profiler import FlexProfiler
__version__ = "0.1.0"
