""" Entry point to inMOTIFin """
from inmotifin.organizer.main import cli

cli()
