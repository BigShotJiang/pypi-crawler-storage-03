"""
Statistics module test package.

Contains comprehensive unit tests for the ProjectX SDK statistics module.
"""
