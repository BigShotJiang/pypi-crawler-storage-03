User Guide
==========

Welcome to the FlameTrack User Guide.

.. toctree::
   :maxdepth: 1

   installation
   quickstart
   workflows
   troubleshooting
