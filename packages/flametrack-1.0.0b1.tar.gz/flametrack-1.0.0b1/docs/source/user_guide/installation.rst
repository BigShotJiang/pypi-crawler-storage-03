Installation
============

How to install FlameTrack:

1. Download the latest version.
2. Install using::

    pip install flametrack

3. Start the application::

    flametrack-gui
