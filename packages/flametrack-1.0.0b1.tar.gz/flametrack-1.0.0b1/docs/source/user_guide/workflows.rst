Workflows
=========

Typical workflows include:

- Dewarping of room-corner experiment footage
- Edge detection for lateral flame spread
- Exporting analysis results
