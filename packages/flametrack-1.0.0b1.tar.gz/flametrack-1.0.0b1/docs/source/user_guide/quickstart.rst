Quickstart
==========

1. Launch FlameTrack.
2. Select the experiment type from the dropdown menu.
3. Set the dewarping points.
4. Start the analysis.
