Contributing to FlameTrack
==========================

Guidelines for contributing:

1. Fork the repository.
2. Create a feature branch.
3. Write tests for new functionality.
4. Open a pull request.
