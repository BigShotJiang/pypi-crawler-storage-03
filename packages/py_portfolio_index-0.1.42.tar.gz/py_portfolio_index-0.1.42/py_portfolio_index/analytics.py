class Analytics:
    pass
