# For testing anything with a dependency with no contracts.
