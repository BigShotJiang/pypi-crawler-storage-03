def main():
    print("Super secret script output")
