console
*******

.. click:: ape_console._cli:cli
  :prog: console
  :nested: full
