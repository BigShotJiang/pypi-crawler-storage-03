.. click:: ape_networks._cli:cli
  :prog: networks
  :nested: full
