.. click:: ape_pm._cli:cli
  :prog: pm
  :nested: full
