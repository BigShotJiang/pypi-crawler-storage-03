# ape.contracts

```{eval-rst}
.. autoclass:: ape.contracts.base.ContractTypeWrapper
    :members:
    :show-inheritance:
    :special-members:
```

```{eval-rst}
.. autoclass:: ape.contracts.base.ContractInstance
    :members:
    :show-inheritance:
    :special-members:
```

```{eval-rst}
.. autoclass:: ape.contracts.base.ContractContainer
    :members:
    :show-inheritance:
    :special-members:
```

```{eval-rst}
.. autoclass:: ape.contracts.base.ContractEvent
    :members:
    :show-inheritance:
    :special-members:
```
