from typing import Optional

from pydantic_settings import SettingsConfigDict

from ape.api.config import PluginConfig


class CustomNetwork(PluginConfig):
    """
    A custom network config.
    """

    name: str
    """Name of the network e.g. mainnet."""

    chain_id: int
    """Chain ID (required)."""

    ecosystem: str
    """The name of the ecosystem."""

    base_ecosystem_plugin: Optional[str] = None
    """The base ecosystem plugin to use, when applicable. Defaults to the default ecosystem."""

    default_provider: str = "node"
    """The default provider plugin to use. Default is the default node provider."""

    request_header: dict = {}
    """The HTTP request header."""

    model_config = SettingsConfigDict(extra="allow", env_prefix="APE_NETWORKS_")

    @property
    def is_fork(self) -> bool:
        """
        ``True`` when the name of the network ends in ``"-fork"``.
        """
        return self.name.endswith("-fork")


class NetworksConfig(PluginConfig):
    custom: list[CustomNetwork] = []
    model_config = SettingsConfigDict(extra="allow", env_prefix="APE_NETWORKS_")
