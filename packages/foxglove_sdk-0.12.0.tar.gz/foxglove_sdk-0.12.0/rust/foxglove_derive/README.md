# foxglove_derive

Derive macros for the Foxglove SDK.

Note: This module is not intended for use on its own and is designed to be used via the [`foxglove`]
crate.

[`foxglove`]: https://crates.io/crates/foxglove
