# np_queuey
Tools for submitting and processing jobs through a message queue for Mindscope Neuropixels workflows.

## todo 
- setup behavior session upload task
    - path to modules in 
- make __main__ cli and executable