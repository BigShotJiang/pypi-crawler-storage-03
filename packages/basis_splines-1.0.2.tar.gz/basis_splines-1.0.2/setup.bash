#!/bin/bash
export WORKING_DIRECTORY=$(pwd)
export BENCHMARK_BINS=$WORKING_DIRECTORY/build/test/src/benchmarks
export EXAMPLE_BINS=$WORKING_DIRECTORY/build/examples