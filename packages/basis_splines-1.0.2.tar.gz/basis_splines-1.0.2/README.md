# Basis-splines

This project includes a C++ library with Python bindings implementing multi-dimensional polynomial splines in basis form and operations to form new splines that represent the derivative, integral, sum, and product of splines.
Among other things, polynomial splines are relevant for computer graphics and to solve semi-infinite programs resulting from optimal control problems.
For example [omg-tools](https://github.com/meco-group/omg-tools) provides a python framework for the formulation and solution of such problems.
This project provides a performant C++ implementation of relevant spline operations in this context.

## Installation

The library can be integrated in a C++ and a Python project.

### Build from source

Building the project including the documentation (Doxygen 1.14.0), examples and tests is tested under Ubuntu 22.04 with g++13 and CMake 4.1.0.
To build the project, clone the repository and run the following commands:

```bash
cmake -B build
cmake --build build
```

After project build the tests can be run with

```bash
ctest --test-dir build
```

### Integrate in CMake project

If you desire an integration in a CMake project you may utilize the [FetchContent](https://cmake.org/cmake/help/v4.1/module/FetchContent.html) module.

```bash
FetchContent_Declare(
  basisSplines
  GIT_REPOSITORY https://github.com/phdorp/basis-splines.git
)
set(BUILD_TEST OFF)
set(BUILD_EXAMPLES OFF)
set(BUILD_DOCS OFF)
FetchContent_MakeAvailable(basisSplines)
link_libraries(basisSplines)
```

Otherwise, you can directly include the header files in your project.

### Build Python bindings

The Python package *basisSplines* is build locally by invoking

```bash
pip install .
```

at the project root.
Additional dependencies for running the Python examples are installed with

```bash
pip install .[example]
```

### Install from PyPI

The Python package *basisSplines* is also available on [PyPI](https://pypi.org/project/basis-splines/) and installed with

```bash
pip install basis-splines
```

## Examples

The examples showcase the library's functionality and require either a [Build from source](#build-from-source) or a [Build Python bindings](#build-python-bindings).
Run a [C++ example](https://github.com/phdorp/basis-splines/tree/16-python-bindings/examples/cpp) [EXAMPLE_NAME] with

```bash
source setup.bash
./examples/cpp/launch.bash [EXAMPLE_NAME]
```

Run all [C++ examples](https://github.com/phdorp/basis-splines/tree/16-python-bindings/examples/cpp) without interaction with

```bash
source setup.bash
echo | ./examples/cpp/launch.bash -a
```

The examples rely on [Matplot++](https://github.com/alandefreitas/matplotplusplus) for plotting, so make sure to have [gnuplot](http://www.gnuplot.info/) installed.

The equivalent [Python examples](https://github.com/phdorp/basis-splines/tree/16-python-bindings/examples/python) are invoked with

```bash
python examples/python/[EXAMPLE_NAME].py
```

### Basis functions

Basis splines are determine recursively on the knots

```math
\begin{aligned}
\mathbf{k}=\begin{bmatrix}\underbrace{\begin{matrix}\kappa_1&\kappa_1&\ldots&\kappa_1\end{matrix}}_{m_1}&\underbrace{\begin{matrix}\kappa_2&\kappa_2&\ldots&\kappa_2\end{matrix}}_{m_2}&\ldots&\kappa_{\breve{{k}}}&\kappa_{\breve{{k}}}\end{bmatrix}.
\end{aligned}
```

The knots are composed of the repeated breakpoints $`\kappa_i<\kappa_{i+1}`$, $`i=1,2,\ldots,\breve{{\kappa}}`$.
The multiplicity $`m_i=\rho-\omega_i`$ of the $`i`$-th breakpoint determines the spline's order of continuity $`\omega_i`$.
The recursion's base case is the order $`\rho=1`$, considering $`n=1,2,\ldots,\breve{{k}}-1`$ knot intervals [[1, Ch. IX eq. (11)]](#1)

```math
\begin{aligned}
b_{n,1,\mathbf{k}} =
    \begin{cases}
        1 & \text{if } k_n \leq t < k_{n+1}, \\
        0 & \text{otherwise.}
    \end{cases}
\end{aligned}
```

Higher orders $`\rho>1`$ are determined from lower orders, resulting in truncated power functions with $`l=1,2,\ldots,\breve{{k}}-\rho`$ [[1, B-spline Prop. (i)]](#1)

```math
\begin{aligned}
b_{l,\rho,\mathbf{k}}(x)=\frac{t-k_l}{k_{l+\rho-1}-k_l}b_{l,\rho,\mathbf{k}}(x)+\frac{k_{l+\rho}-t}{k_{l+\rho}-k_{l+1}}b_{l+1,\rho,\mathbf{k}}(x).
\end{aligned}
```

![Basis spline basis functions](docs/media/basis.jpg)

The exemplary B-splines of order 3 with 3 breakpoints are found under *examples/basis.cpp*.

### Spline functions

Splines in basis form are a linear combination of basis functions weighted with the coefficients $`c_n`$ for $`n=0,1,\ldots,\breve{{c}}-1`$ [[1, Def. (51)]](#1):

```math
\begin{aligned}
s(x)=\sum_{n=0}^{\breve{{c}}-1}c_nb_{n,\rho,\mathbf{k}}(x).
\end{aligned}
```

The coefficients form a convex hull that contains the spline's graph.

![2-dimensional spline in basis form with convex hull](docs/media/spline2d_allDims.jpg)

The example in *examples/spline2d.cpp* shows 2 splines of order 3 and 4 breakpoints.

### Derivative

The spline derivative $`\dot{s}(x)=\frac{\mathrm{d}}{\mathrm{d}t}s(x)`$ has reduced order and continuity.
The derivative coefficients are determined from the original coefficients $`c_n`$ [[1, B-spline Prop. (viii)]](#1):

```math
\begin{aligned}
\dot{s}(x)=\frac{\mathrm{d}}{\mathrm{d}t}\sum_{n=0}^{\breve{{c}}-1}c_nb_{n,\rho,\mathbf{k}}(x)=(\rho-1)\sum_{n=1}^{\breve{{c}}-1}\frac{c_n-c_{n-1}}{k_n-k_{n-1}}b_{n,\rho-1,\mathbf{k}}(x).
\end{aligned}
```

Thus, the derivative is the result of a linear transformation of the coefficients $`\dot{s}(x)=\left(\mathbf{T}_{\dot{\mathbf{b}}}^{\mathbf{b}}\mathbf{c}\right)^\intercal b_{n,\rho-1,\mathbf{k}}(x)`$:

```math
\begin{aligned}
\mathbf{T}_{\dot{\mathbf{b}}}^{\mathbf{b}}=(\rho-1)
\begin{pmatrix}
\frac{1}{k_1-k_\rho}&\frac{1}{k_\rho-k_1}&0&\ldots&0&0\\
0&\frac{1}{k_2-k_\rho}&\frac{1}{k_\rho-k_2}&0&\ldots&0\\
\vdots&\vdots&\vdots&\ddots&\vdots&\vdots\\
0&0&0&\ldots&\frac{1}{k_{\breve{{k}}-1}-k_{\breve{{c}}}}&\frac{1}{k_{\breve{{c}}}-k_{\breve{{k}}-1}}\\
\end{pmatrix}.
\end{aligned}
```

![Spline derivative](docs/media/splineDeriv.jpg)

The example for differentiating a spline of order 3 is found under *examples/splineDeriv.cpp*.
The file *examples/splineDerivExplicit.cpp* shows the application of the transformation matrix.

### Integral

The spline integral $`s_\mathrm{I}(x)=\int_{\kappa_0}^t s(\tau)\mathrm{d}\tau`$ has increased order and continuity.
The transformation to the integral coefficients $`\mathbf{c}_{\mathrm{I}}`$ is derived from the derivative definition and yields [[1, Ch. X eq. (31)]](#1):

```math
\begin{aligned}
c_{{n+1},\mathrm{I}}=c_{n,\mathrm{I}}+\frac{1}{\rho}(k_{n+\rho}-k_n)c_n
\end{aligned}
```

Assuming an initial condition $`c_{0,\mathrm{I}}=0`$, the spline integral is also determined by a linear transformation of the coefficients $`s_\mathrm{I}(x)=\left(\mathbf{T}_{\mathbf{b}_\mathrm{I}}^{\mathbf{b}}\mathbf{c}\right)^\intercal b_{n,\rho+1,\mathbf{k}}(x)`$ with

```math
\begin{aligned}
\mathbf{T}_{\mathbf{b}_\mathrm{I}}^{\mathbf{b}}=
\begin{pmatrix}
0&0&0&\ldots&0\\
k_\rho-k_0&0&0&\ldots&0\\
k_\rho-k_0&k_{\rho+1}-k_1&0&\ldots&0\\
\vdots&\vdots&\ldots&\ddots&\vdots\\
k_\rho-k_0&k_{\rho+1}-k_1&k_{\rho+2}-k_2&\ldots&k_{\breve{{k}}-1}-k_{\breve{{c}}-1}\\
\end{pmatrix}.
\end{aligned}
```

![Spline integral](docs/media/splineInteg.jpg)

The example for integrating a spline of order 3 is found under *examples/splineInteg.cpp*.
The file *examples/splineIntegExplicit.cpp* shows the application of the transformation matrix.

### Sum and product

The sum and product of two splines $`s_\square(x)`$ and $`s_\triangle(x)`$ are exactly described by another spline.
The coefficients of the sum $`s_+(x)=s_\square(x)+s_\triangle(x)`$ and the product $`s_\times(x)=s_\square(x)\cdot s_\triangle(x)`$ are described implicitly by an interpolation:

```math
\begin{aligned}
s_+(\tau_{{j,+}})&=s_\square(\tau_{{j,+}})+s_\triangle(\tau_{{j,+}}),&j=0,1,\ldots,\breve{{c}}_+-1,\\
s_\times(\tau_{{i,\times}})&=s_\square(\tau_{{i,\times}})\cdot s_\triangle(\tau_{{i,\times}}),&i=0,1,\ldots,\breve{{c}}_\times-1.\\
\end{aligned}
```

![Two splines and their sum representation](docs/media/splineSum.jpg)

![Two splines and their product representation](docs/media/splineProd.jpg)

The coefficients are also determined explicitly with two transformation matrices $`\mathbf{T}_{\mathbf{b}_+}^{\mathbf{b}_{\square}}`$ and $`\mathbf{T}_{\mathbf{b}_+}^{\mathbf{b}_\triangle}`$ in the sum case, and a single matrix in the product case $`\mathbf{T}_{\mathbf{b}_\times}^{\mathbf{b}_{\square}\odot\mathbf{b}_{\triangle}}`$ [[2, Property 2 and 3]]((#2)):

```math
\begin{aligned}
\mathbf{c}_+&=\mathbf{T}_{\mathbf{b}_+}^{\mathbf{b}_{\square}}\mathbf{c}_\square+\mathbf{T}_{\mathbf{b}_+}^{\mathbf{b}_\triangle}\mathbf{c}_\triangle,\\
\mathbf{c}_\times&=\mathbf{T}_{\mathbf{b}_\times}^{\mathbf{b}_{\square}\odot\mathbf{b}_{\triangle}}\left(\mathbf{c}_\square\otimes\mathbf{c}_\triangle\right).
\end{aligned}
```

Examples for the sum and product of splines are found under *examples/splineSum.cpp* and *examples/splineProd.cpp*.
The usage of the transformation matrices is shown in *examples/splineSumExpl.cpp* and *examples/splineProdExpl.cpp*.

### Convex hull reduction

The spline function is enclosed by its convex hull so the hull keeps a certain distance to the spline.
The formulation of constraints depending on the spline coefficients results therefore in a conservative solution.
The solution accuracy is improved by reducing the distance between hull and spline.
Two methods are available to reduce the distance: knot insertion and order elevation.

#### Knot insertion

The knot insertion creates a new spline basis $`\mathbf{b}_{\rho,\mathbf{k}_\mathrm{in}}(x)`$ with a new knot sequence $`\mathbf{k}_\mathrm{in}`$ by inserting additional knots to the original knot sequence $`\mathbf{k}`$ such that $`\{k_i\}_{i=1,2,\ldots,\breve{k}}\subset\{k_{j,\mathrm{in}}\}_{j=1,2,\ldots,\breve{k}_{\mathrm{in}}}`$ while the first $`\mathbf{k}_{1,\mathrm{in}}=\mathbf{k}_{1}`$ and the last $`\mathbf{k}_{\breve{{k}}_\mathrm{in},\mathrm{in}}=\mathbf{k}_{\breve{{k}}}`$ breakpoints coincide.
Thus, $`\mathbf{k}_\mathrm{in}`$ is a refinement of $`\mathbf{k}`$ such that the splines resulting from $`\mathbf{b}_{\rho,\mathbf{k}}(x)`$ are among the possible splines resulting from $`\mathbf{b}_{\rho,\mathbf{k}_\mathrm{in}}(x)`$ [[1, B-spline Prop. (xi)]]((#1)):

```math
\begin{aligned}
s(x)&=\sum_{n=1}^{\breve{{c}}}c_nb_{n,\rho,\mathbf{k}}(x),\\
=s_\mathrm{in}(x)&=\sum_{n=1}^{\breve{{c}}_\mathrm{in}}c_{n,\mathrm{in}}b_{n,\rho,\mathbf{k}_\mathrm{in}}(x).
\end{aligned}
```

In addition, the distance between the coefficients $`\mathbf{c}_\mathrm{in}`$ and $`s_\mathrm{in}(x)`$ is smaller than the distance between the coefficients $`\mathbf{c}`$ and $`s(x)`$.

![Spline function and equivalent spline with refined knot sequence](docs/media/splineKnotInsertion.jpg)

The example *examples/splineKnotInsertion.cpp* demonstrates the insertion of 4 additional knots, introducing 2 new breakpoints at 0.3 and 0.4 to a spline of order 3.
The addition of each knot introduces a new coefficient for a locally more accurate spline approximation with the control polygon.

#### Order elevation

The order elevation creates a new spline basis $`\mathbf{b}_{\hat{\rho},\mathbf{k}}(x):\mathbb{R}\to\mathbb{R}^{\breve{\mathbb{c}}}`$ of increased order $`\hat{\rho}>\rho`$ from the original basis $`\mathbf{b}_{\rho,\mathbf{k}}(x)`$.
Because the basis of higher order is also a basis for lower order splines, an equivalent higher order spline is determined by interpolation:

```math
\begin{aligned}
s(x)&=\sum_{n=1}^{\breve{{c}}}c_nb_{n,\rho,\mathbf{k}}(x),\\
=s_\mathrm{el}(x)&=\sum_{n=1}^{\breve{{c}}_\mathrm{el}}c_{n,\mathrm{el}}b_{n,\hat{\rho},\mathbf{k}}(x).
\end{aligned}
```

Increasing the basis order also introduces additional breakpoints and reduces the distance between the spline and the convex hull [[2, IV. B.]]((#2)).

![Spline function and equivalent spline with increased order](docs/media/splineOrderElevation.jpg)

The example *examples/splineOrderElevation.cpp* demonstrates the elevation of a spline of order 3 to order 5.
Note that the distance between the coefficients and the spline graph is reduced along the entire spline.

### Segment extraction

The spline in basis form represents a sequence of polynomial segments.
The spline is represented in each connected subsequence $`x\in\left[\kappa_{1,\mathrm{se}},\kappa_{\breve{\kappa}_\mathrm{se},\mathrm{se}}\right]`$ by another spline $`s_\mathrm{se}(x)=s(x)`$ using a subset of the original coefficients $`\{\mathbf{c}_\mathrm{se}\}_{n=1,2,\ldots,\breve{c}_\mathrm{se}}\subset\{\mathbf{c}\}_{n=1,2,\ldots,\breve{c}}`$.
In the first step, the example *examples/splineSegment.cpp* demonstrates the extraction of a segment between the breakpoints 0.4 and 0.7 from a spline of order 4.
Note that the splines only coincide in the extracted segment.

![Segment extraction](docs/media/splineSegment.jpg)

The spline representing the extracted segment is not a clamped spline because the first and last coefficients do not coincide with the spline function.
However, an equivalent clamped spline $`s_\mathrm{cl}(x)=s_\mathrm{se}(x)`$ on the same interval $`x\in\left[\kappa_{1,\mathrm{se}},\kappa_{\breve{\kappa}_\mathrm{se},\mathrm{se}}\right]`$ is contained in a tighter convex hull.
An equivalent clamped spline is determined by ensuring the equality of the first and last $`\rho`$ knots

```math
\begin{aligned}
k_{n,\mathrm{cl}}&=k_{\rho,\mathrm{se}},&&n=1,\ldots,\rho,\\
k_{m,\mathrm{cl}}&=k_{\breve{k}_\mathrm{se}-\rho+1,\mathrm{se}},&&m=\breve{k}_\mathrm{se}-\rho+1,\ldots,\breve{k}_\mathrm{se}-\rho,\\
k_{j,\mathrm{cl}}&=k_{j,\mathrm{se}},&&j=\rho+1,\ldots,\breve{k}_\mathrm{se}-\rho.
\end{aligned}
```

In the second step, the example *examples/splineSegment.cpp* reduces the distance between the spline segment and the convex hull by a clamped segment representation.

### References

<a id="1">[1]</a>
C. Boor:
*A Practical Guide to Splines*.
1st ed. Vol. 27.
Applied Mathematical Sciences.
New York, NY, USA: Springer, Nov. 2001.
URL: https://link.springer.com/book/9780387953663.

<a id="2">[2]</a>
W. van Loock, G. Pipeleers, and J. Swevers:
“Optimal motion planning for differentially flat systems with guaranteed constraint satisfaction”.
In: *2015 American Control Conference (ACC)*.
July 2015, pp. 4245–4250.
DOI: 10.1109/ACC.2015.7171996.
