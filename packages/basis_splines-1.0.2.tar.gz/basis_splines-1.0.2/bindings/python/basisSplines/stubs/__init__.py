from __future__ import annotations
from basisSplines._core import Basis
from basisSplines._core import Spline
from . import _core
__all__: list = ['Basis', 'Spline']
