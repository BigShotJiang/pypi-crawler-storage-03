"""An enum stating the functions."""

from enum import StrEnum


class Function(StrEnum):
    """The function to perform."""

    DELETE = "delete"
