"""The scrapesession main module."""

__VERSION__ = "0.0.13"
