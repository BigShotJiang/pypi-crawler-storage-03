funkuhr
=================

.. autofunction:: stopuhr.funkuhr
