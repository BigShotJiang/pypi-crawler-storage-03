StopUhr
=================

.. autoclass::  stopuhr.StopUhr
