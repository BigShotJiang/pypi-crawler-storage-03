*********
Reference
*********

.. toctree::
   :maxdepth: 1

    stopuhr.Chronometer <Chronometer>
    stopuhr.stopwatch <stopwatch>
    stopuhr.stopuhr <stopuhr>
    stopuhr.StopUhr <StopUhr>
    stopuhr.funkuhr <funkuhr>
    stopuhr.FunkUhr <FunkUhr>
