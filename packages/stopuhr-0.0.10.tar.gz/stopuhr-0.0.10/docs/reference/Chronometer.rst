Chronometer
=================

.. autoclass:: stopuhr.Chronometer
