FunkUhr
=================

.. autoclass:: stopuhr.FunkUhr
