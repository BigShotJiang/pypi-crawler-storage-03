stopuhr
=================

.. autofunction:: stopuhr.stopuhr
