=======
History
=======

0.1.0 (2018-08-14)
------------------

* First release on PyPI.
