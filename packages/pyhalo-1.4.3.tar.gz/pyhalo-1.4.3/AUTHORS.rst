=======
Credits
=======

Development Lead
----------------

* Daniel Gilman <gilmanda@uchicago.edu>

Contributors
------------

* Veronica Dike <vdike2@illinois.edu>
* Birendra Dhanasingham <birendradh@unm.edu>
* Charles Gannon <cgannon@ucmerced.edu>
* Alex Laroche <alexander.laroche@mail.mcgill.ca>

