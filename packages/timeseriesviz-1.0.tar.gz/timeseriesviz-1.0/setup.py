from setuptools import setup, find_packages
import pathlib

here = pathlib.Path(__file__).parent.resolve()
long_description = (here / "README.md").read_text(encoding="utf-8")


setup(
    name='timeseriesviz',
    version='1.0',
    description='A package for visualizing time series model performance, with a focus on spatio-temporal datasets',
    long_description=long_description,
    package_dir={'': 'src'},
    author='Junyang He',
    author_email='erichjy0909@gmail.com',
    packages=find_packages(where="src"),
    install_requires=['pandas>=2.2.2', 'numpy>=2.0.2', 'matplotlib>=3.5'],
)