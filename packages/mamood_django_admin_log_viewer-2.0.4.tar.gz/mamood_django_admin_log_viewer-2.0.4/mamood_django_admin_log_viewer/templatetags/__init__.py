"""
Template tags for Django Admin Log Viewer.

This module can contain custom template tags and filters for the log viewer.
Currently, no custom tags are implemented.
"""
