#!/usr/bin/env python
"""
Minimal setup.py for compatibility.
All project metadata is defined in pyproject.toml.
"""

from setuptools import setup

# All configuration is now in pyproject.toml
setup()
